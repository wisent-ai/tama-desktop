//! What a replay sends: the adapter entries a registry declares, the events
//! each adapter event expands into, and the payload one replayed event carries.

use std::path::Path;

use crate::json::Json;
use crate::support;

/// JS `adapterEventsForReplay(adapterEvent, matcher)` from codex-replay.mjs
/// (note: subtly different from `adapterEvents` in core).
pub(crate) fn adapter_events_for_replay(adapter_event: &str, matcher: &str) -> Vec<String> {
    let key = adapter_event.to_lowercase();
    let tools: Vec<String> = matcher
        .split('|')
        .map(|tool| tool.trim().to_lowercase())
        .filter(|tool| !tool.is_empty())
        .collect();
    if key == "stop" {
        return vec!["stop".to_string()];
    }
    if key == "userpromptsubmit" {
        return vec!["user_prompt_submit".to_string()];
    }
    if key == "sessionstart" {
        return vec![if tools.iter().any(|t| t == "compact") {
            "session_start:compact"
        } else {
            "session_start"
        }
        .to_string()];
    }
    if key == "posttooluse" {
        return vec![if tools.iter().any(|t| t == "bash") {
            "post_tool_use:bash"
        } else {
            "post_tool_use"
        }
        .to_string()];
    }
    if key != "pretooluse" {
        return vec![key];
    }
    let mut events: Vec<&str> = Vec::new();
    let mut push = |event: &'static str| {
        if !events.contains(&event) {
            events.push(event);
        }
    };
    for tool in &tools {
        match tool.as_str() {
            "bash" | "run_command" | "runcommands" | "runpackagecommand" | "runpackagescript" => {
                push("pre_tool_use:bash")
            }
            "read" | "readfile" => push("pre_tool_use:read"),
            "edit" | "apply_patch" => push("pre_tool_use:edit"),
            "write" | "writefile" => push("pre_tool_use:write"),
            "task" | "agent" => push("pre_tool_use:task"),
            "todo" => push("pre_tool_use:todo"),
            "goal" => push("pre_tool_use:goal"),
            "grep" | "glob" | "search" | "lsp" | "astgrep" | "ast_grep" => {
                push("pre_tool_use:lookup")
            }
            "eval" | "execute_code" | "mcp__node_repl_js" | "node_repl/js" => {
                push("pre_tool_use:eval")
            }
            "ssh" => push("pre_tool_use:ssh"),
            "notebookedit" | "notebook_edit" => push("pre_tool_use:notebook"),
            "monitor" | "schedulewakeup" | "schedule_wakeup" | "wait" => push("pre_tool_use:wait"),
            _ => {}
        }
    }
    events.into_iter().map(str::to_string).collect()
}

/// One entry of JS `codexAdapterEntries()`.
#[derive(Debug, Clone)]
pub struct ReplayEntry {
    pub event: String,
    pub command: String,
}

/// JS `codexAdapterEntries()` — reads the codex adapter config with the
/// ordered parser so `Object.entries(config.hooks)` order is preserved.
pub fn codex_adapter_entries(root: &Path) -> Result<Vec<ReplayEntry>, String> {
    let registry = tama_core::runtime::load_registry(root).map_err(|e| e.to_string())?;
    let adapter_path = registry
        .adapters
        .get("codex")
        .and_then(|adapter| adapter.path.clone())
        .ok_or_else(|| "Cannot read properties of undefined (reading 'path')".to_string())?;
    let text = support::read(Path::new(&adapter_path))?;
    let config = crate::json::parse(&text)?;
    let mut entries = Vec::new();
    let empty: Vec<Json> = Vec::new();
    if let Some(hooks_root) = config.get("hooks").and_then(Json::as_object) {
        for (adapter_event, blocks) in hooks_root {
            for block in blocks.as_array().unwrap_or(&empty) {
                // `matcher = ''` default applies when the key is absent.
                let matcher = block
                    .get("matcher")
                    .map(Json::js_string)
                    .unwrap_or_default();
                for event in adapter_events_for_replay(adapter_event, &matcher) {
                    for hook in block
                        .get("hooks")
                        .and_then(Json::as_array)
                        .unwrap_or(&empty)
                    {
                        // `if (hook.command)` — truthy (non-empty) string.
                        if let Some(command) = hook
                            .get("command")
                            .and_then(Json::as_str)
                            .filter(|c| !c.is_empty())
                        {
                            entries.push(ReplayEntry {
                                event: event.clone(),
                                command: command.to_string(),
                            });
                        }
                    }
                }
            }
        }
    }
    Ok(entries)
}

/// JS `codexReplayPayload(event, scratchDir)` — returns the payload JSON text
/// (compact, trailing newline) and lazily creates the safe fixtures.
pub fn codex_replay_payload(event: &str, scratch_dir: &Path) -> Result<String, String> {
    let safe_file = scratch_dir.join("codex-replay-safe.txt");
    let safe_notebook = scratch_dir.join("codex-replay-safe.ipynb");
    if !scratch_dir.exists() {
        std::fs::create_dir_all(scratch_dir)
            .map_err(|e| support::io_error_message("mkdir", scratch_dir, &e))?;
    }
    if !safe_file.exists() {
        support::write_file(&safe_file, "before replay\n")?;
    }
    if !safe_notebook.exists() {
        let notebook = Json::obj(vec![
            ("cells".to_string(), Json::arr(vec![])),
            ("metadata".to_string(), Json::obj(vec![])),
            ("nbformat".to_string(), Json::num_i64(4)),
            ("nbformat_minor".to_string(), Json::num_i64(5)),
        ]);
        support::write_file(&safe_notebook, &notebook.to_compact())?;
    }
    let safe_file_str = safe_file.to_string_lossy().into_owned();
    let safe_notebook_str = safe_notebook.to_string_lossy().into_owned();
    let tool_input = |entries: Vec<(&str, Json)>| -> Json {
        Json::obj(
            entries
                .into_iter()
                .map(|(k, v)| (k.to_string(), v))
                .collect(),
        )
    };
    let payload = |tool: &str, input: Json| -> Json {
        Json::obj(vec![
            ("tool_name".to_string(), Json::str(tool)),
            ("tool_input".to_string(), input),
        ])
    };
    let payload = match event {
        "stop" => Json::obj(vec![
            (
                "response".to_string(),
                Json::str("Done. Verified with focused tests. No open items remain."),
            ),
            ("messages".to_string(), Json::arr(vec![])),
        ]),
        "user_prompt_submit" => Json::obj(vec![
            ("hook_event_name".to_string(), Json::str("UserPromptSubmit")),
            (
                "prompt".to_string(),
                Json::str("Run the Codex full-local hook replay smoke."),
            ),
        ]),
        "post_tool_use:bash" => Json::obj(vec![
            ("tool_name".to_string(), Json::str("Bash")),
            (
                "tool_input".to_string(),
                tool_input(vec![("command", Json::str("printf codex_replay"))]),
            ),
            (
                "tool_response".to_string(),
                Json::obj(vec![
                    ("stdout".to_string(), Json::str("codex_replay")),
                    ("stderr".to_string(), Json::str("")),
                    ("exit_code".to_string(), Json::num_i64(0)),
                ]),
            ),
        ]),
        "session_start:compact" => Json::obj(vec![("source".to_string(), Json::str("compact"))]),
        "pre_tool_use:bash" => payload(
            "Bash",
            tool_input(vec![("command", Json::str("printf codex_replay"))]),
        ),
        "pre_tool_use:read" => payload(
            "Read",
            tool_input(vec![("file_path", Json::str(safe_file_str.clone()))]),
        ),
        "pre_tool_use:edit" => payload(
            "Edit",
            tool_input(vec![
                ("file_path", Json::str(safe_file_str.clone())),
                ("old_string", Json::str("before replay")),
                ("new_string", Json::str("after replay")),
            ]),
        ),
        "pre_tool_use:write" => payload(
            "Write",
            tool_input(vec![
                ("file_path", Json::str(safe_file_str.clone())),
                ("content", Json::str("after replay\n")),
            ]),
        ),
        "pre_tool_use:task" => payload(
            "Task",
            tool_input(vec![
                ("description", Json::str("Inspect one file")),
                ("prompt", Json::str("Read only")),
            ]),
        ),
        "pre_tool_use:todo" => payload(
            "Todo",
            tool_input(vec![
                ("i", Json::str("Track requested change")),
                (
                    "items",
                    Json::arr(vec![Json::str("Complete requested change")]),
                ),
            ]),
        ),
        "pre_tool_use:goal" => payload("Goal", tool_input(vec![("op", Json::str("get"))])),
        "pre_tool_use:lookup" => payload(
            "Grep",
            tool_input(vec![
                ("i", Json::str("Search source")),
                ("pattern", Json::str("needle")),
                ("path", Json::str(safe_file_str.clone())),
            ]),
        ),
        "pre_tool_use:eval" => payload(
            "Eval",
            tool_input(vec![
                ("title", Json::str("Compute value")),
                ("language", Json::str("py")),
                ("code", Json::str("1 + 1")),
            ]),
        ),
        "pre_tool_use:ssh" => payload(
            "SSH",
            tool_input(vec![
                ("host", Json::str("example.invalid")),
                ("command", Json::str("printf replay")),
            ]),
        ),
        "pre_tool_use:notebook" => payload(
            "NotebookEdit",
            tool_input(vec![
                ("notebook_path", Json::str(safe_notebook_str.clone())),
                ("cell_id", Json::str("cell-1")),
                ("new_source", Json::str("codex replay notebook")),
            ]),
        ),
        "pre_tool_use:wait" => payload(
            "Monitor",
            tool_input(vec![
                ("timeout_ms", Json::num_i64(1000)),
                ("persistent", Json::Bool(false)),
            ]),
        ),
        // `payloads[event] || {}`.
        _ => Json::obj(vec![]),
    };
    Ok(format!("{}\n", payload.to_compact()))
}

