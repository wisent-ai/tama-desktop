//! The two scripts a run writes into its fixture directory: the recorder the
//! fixture hooks report through, and the driver that hosts the OMP adapter in
//! a real node process, verbatim as the JavaScript harness had them.
#![allow(dead_code)]

// ---------------------------------------------------------------------------
// `recorder.mjs` — the fixture hook runner written by the JS test
// (verbatim file content, including the leading newline).
// ---------------------------------------------------------------------------

pub const RECORDER_MJS: &str = "
import { appendFileSync } from 'node:fs'
let input = ''
for await (const chunk of process.stdin) input += chunk
const payload = JSON.parse(input || '{}')
const id = 'fixture-lifecycle-hook'
const event = String(payload.agent_hook_event || 'unknown')
appendFileSync(process.env.TAMA_TEST_RECORDER_LOG, event + '\\n')
process.stdout.write(JSON.stringify({
  decision: 'pass',
  results: [{ id, code: 0 }],
}))
";

// ---------------------------------------------------------------------------
// OMP adapter driver. The JS harness imports `omp-shared-hooks.js` directly
// and drives the registered tools/handlers in-process; the port spawns a
// `node` process running this script (written into the fixture directory)
// and steers it with newline-delimited JSON requests/responses on stdio.
// The mock `pi` object is a verbatim copy of the one in the JS test.
// ---------------------------------------------------------------------------

pub const DRIVER_MJS: &str = r##"import { createInterface } from 'node:readline'

const adapterPath = process.argv[2]
const adapter = await import(adapterPath + '?test=' + Date.now())
const tools = []
const commands = new Map()
const handlers = new Map()
const entries = []
const pi = {
  zod: {
    z: {
      object: (value) => value,
      string: () => ({ type: 'string', optional() { return this } }),
      boolean: () => ({ type: 'boolean', optional() { return this } }),
      literal: (value) => ({ value, optional() { return this } }),
      enum: (values) => ({ values, optional() { return this } }),
      array: () => ({
        optional() { return this },
        nonempty() { return this },
        min() { return this },
      }),
    },
  },
  registerTool: (tool) => tools.push(tool),
  registerCommand: (name, command) => commands.set(name, command),
  on: (event, handler) => handlers.set(event, handler),
  appendEntry: (customType, data) => entries.push({ customType, data }),
}
adapter.default(pi)

let activeSessionId = null
const context = {
  hasUI: true,
  ui: {},
  sessionManager: { getSessionId: () => activeSessionId },
}

function handlerContext(spec) {
  if (!spec) return undefined
  if (spec.strictUi) {
    return {
      ui: { notify: () => { throw new Error('passing prompt must not notify') } },
      abort: () => { throw new Error('passing prompt must not abort') },
    }
  }
  const ctx = {}
  if (spec.cwd !== undefined) ctx.cwd = spec.cwd
  const sessionManager = {}
  if (spec.branch !== undefined) sessionManager.getBranch = () => spec.branch
  if (spec.sessionFile !== undefined) sessionManager.getSessionFile = () => spec.sessionFile
  ctx.sessionManager = sessionManager
  return ctx
}

function reply(value) {
  process.stdout.write(JSON.stringify(value) + '\n')
}

async function handle(request) {
  if (request.op === 'register') {
    return {
      tools: tools.map((tool) => ({ name: tool.name, approval: tool.approval ?? null })),
      commands: [...commands.keys()],
      handlers: [...handlers.keys()],
    }
  }
  if (request.op === 'execute') {
    const tool = tools.find((candidate) => candidate.name === request.tool)
    if (!tool) return { error: 'tool not registered: ' + request.tool }
    const result = await tool.execute(request.id, request.params, null, null, context)
    return { hasResult: result !== undefined, result: result ?? null }
  }
  if (request.op === 'handle') {
    const handler = handlers.get(request.event)
    if (!handler) return { error: 'handler not registered: ' + request.event }
    if (request.event.startsWith('session_')) {
      const explicit = request.payload?.sessionId || request.payload?.session_id
      const recovered = String(request.ctx?.sessionFile || '').match(
        /([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})(?:\.jsonl)?$/i,
      )?.[1]
      if (explicit || recovered) activeSessionId = String(explicit || recovered)
    }
    const result = await handler(request.payload, handlerContext(request.ctx))
    return { hasResult: result !== undefined, result: result ?? null }
  }
  if (request.op === 'command') {
    const command = commands.get(request.name)
    if (!command) return { error: 'command not registered: ' + request.name }
    const result = await command.handler(request.args ?? {}, {
      ...context,
      reload: async () => {},
      ui: { notify: () => {} },
    })
    return { hasResult: result !== undefined, result: result ?? null }
  }
  if (request.op === 'entries') {
    return { count: entries.length }
  }
  return { error: 'unknown op: ' + request.op }
}

const rl = createInterface({ input: process.stdin })
for await (const line of rl) {
  if (!line.trim()) continue
  let response
  try {
    response = await handle(JSON.parse(line))
  } catch (error) {
    response = { error: error instanceof Error ? error.message : String(error) }
  }
  reply(response)
}
"##;

