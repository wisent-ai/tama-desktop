//! `tama hooks release`: build every native hook the registry names from
//! published main, install the ones that changed, stage, seal and install the
//! live release, and report what this machine now runs.
//!
//! A hook lands in three places and only the first two had commands. The
//! registry and the catalogue are repository documents (`tama hooks declare`
//! writes them); what a machine actually runs is a sealed release under
//! `~/Library/Application Support/Tama/hooks-runtime` plus the binaries in
//! `~/.local/bin` the registry points at. Nothing in the product built or
//! installed those, so every change arrived as a shell file written into an
//! ignored build directory and handed to the operator, and on 2026-09-19 they
//! asked the question that block deserved: "i jak niby mam go uruchomic".
//!
//! Binaries are built from `origin/main` exported into the checkout's ignored
//! build directory, never from the working tree, because a shared checkout
//! carries other sessions' uncommitted edits and a live gate must be the code
//! that was reviewed and pushed. A binary identical to the installed one is
//! left alone, so a repeat run installs nothing and says so.
//!
//! Device-level protected: without `DEVICE_HOOK_EDIT_APPROVED=1` this refuses
//! before building anything.


mod binaries;
mod install;
mod support;

use std::path::{Path, PathBuf};

use super::declare::{consented, refuse, CONSENT_ENV, CONSENT_VALUE};
use binaries::hook_binaries;
use install::build_and_install;
use support::installed_provenance;

/// What this machine's sealed runtime was built from, when it holds one.
pub(super) fn provenance_line() -> Option<String> {
    installed_provenance(&PathBuf::from(std::env::var("HOME").unwrap_or_default()))
}

pub const USAGE: &str = "usage: tama hooks release [--dry-run] [--enforce <hook-id>[,<hook-id>…]]";

/// The export and build directories, under the checkout's ignored build tree,
/// removed when the run ends.
const EXPORT_DIR: &str = "rust/target/hook-release-src";
const BUILD_DIR: &str = "rust/target/hook-release-build";
const STAGE_DIR: &str = "rust/target/hook-release-staged";

/// The programs a machine needs beside its hooks: the engine every provider
/// dispatcher runs, and the CLI that installs them. `tama-run-hook` had no
/// install path at all until 2026-09-20, so the copy in `~/.local/bin` sat
/// at whatever build last happened to put it there — six days behind the
/// engine the sealed release was running, and one release ahead of the fix
/// it never received.
const RUNTIME_PROGRAMS: &[&str] = &["tama-run-hook", "tama-cli"];
/// The built CLI, and the name the product's own sentences tell an operator
/// to type. They are one program installed twice, because a refusal that
/// names a command nobody has is a refusal nobody can act on.
const CLI_PROGRAM: &str = "tama-cli";
const SPOKEN_NAME: &str = "tama";

pub fn main(argv: &[String], root: &Path) -> i32 {
    if argv.iter().any(|arg| arg == "--help" || arg == "-h") {
        println!("{USAGE}");
        return 0;
    }
    let dry_run = argv.iter().any(|arg| arg == "--dry-run");
    let enforce: Vec<String> = argv
        .iter()
        .position(|arg| arg == "--enforce")
        .and_then(|at| argv.get(at + 1))
        .map(|list| list.split(',').map(|id| id.trim().to_string()).collect())
        .unwrap_or_default();
    let registry = root.join("shared-hooks/registry.json");
    let binaries = hook_binaries(&registry);
    if binaries.is_empty() {
        return refuse(&format!(
            "{} names no hook binary of ours; there is nothing to build",
            registry.display()
        ));
    }
    if dry_run {
        println!(
            "would build {} hook binaries from origin/main",
            binaries.len()
        );
        for name in &binaries {
            println!("  {name}");
        }
        println!(
            "would install the runtime programs beside them: {}",
            RUNTIME_PROGRAMS.join(" ")
        );
        println!(
            "would sign every built binary with the tama identity before installing it, \
             because the operating system kills an ad-hoc copy"
        );
        println!("would warm every installed binary and report what each one cost");
        println!("would stage, seal and install the live release from {STAGE_DIR}");
        match enforce.is_empty() {
            true => println!("would leave this machine's hook selection as it is"),
            false => println!("would add to the selection: {}", enforce.join(" ")),
        }
        if let Some(provenance) = provenance_line() {
            println!("{provenance}");
        }
        return 0;
    }
    if !consented() {
        return refuse(&format!(
            "BLOCKED: installing a hook release changes what every session on this machine runs. \
             Run this in your own shell, outside any agent session:\n\n  cd {}\n  \
             {CONSENT_ENV}={CONSENT_VALUE} ./rust/target/release/tama-cli hooks release\n\n\
             The built binary is named because the installed one predates this command; this run \
             installs the new CLI too, so afterwards `tama-cli hooks release` is enough. Read \
             why: https://tama.wisent.com/docs/hook-management/#owner-consent-for-a-hook-change",
            root.display()
        ));
    }
    build_and_install(root, &binaries, &enforce)
}
