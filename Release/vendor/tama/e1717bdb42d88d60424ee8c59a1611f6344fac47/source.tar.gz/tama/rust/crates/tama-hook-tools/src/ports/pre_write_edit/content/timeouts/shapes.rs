//! The shapes this gate recognises: the calls that end a task early, the words
//! that name a limit outright, a timer used to abort, a guessed wait, and the
//! per-operation deadlines a database or socket layer carries.
//!
//! Every pattern is built from fragments so this file never carries the words
//! it refuses, which is what lets the gate read its own source.

use std::sync::LazyLock;

use regex::Regex;

use crate::ports::transport_common as common;

/// dispatcher enforces rather than any product's work.
pub(super) const SKIPPED_DIRECTORIES: &[&str] = &[
    "/.claude/",
    "/.factory/",
    "/.codex/",
    "/.shared-hooks/",
    "/hook-declarations/",
];
/// `statement`, `connect`, … each followed by a per-operation deadline.
pub(super) const OPERATION_PREFIXES: &[&str] = &[
    "statement",
    "connect",
    "read",
    "write",
    "socket",
    "request",
    "query",
    "lock",
    "idle",
    "poll",
    "wait",
    "connection",
];
pub(super) const NO_TIMEOUTS: &str = "BLOCKED: No timeouts. Do not use ";
pub(super) const RUN_TO_COMPLETION: &str = ". Let tasks run to completion.";
pub(super) const LIMIT_WORD_REFUSAL: &str = "BLOCKED: Content contains time limit pattern.";
pub(super) const PER_OPERATION_REFUSAL: &str = "BLOCKED: Content contains time-limiting pattern.";

/// The constructs that end a task early, each with the call to name in the
/// refusal.
pub(super) static KILLERS: LazyLock<Vec<(Regex, String)>> = LazyLock::new(|| {
    let calls = [
        concat!("asyncio", "\\.wait_for"),
        concat!("asyncio", "\\.timeout"),
        concat!("signal", "\\.alarm"),
        concat!("AbortSignal", "\\.timeout"),
    ];
    let shown = [
        concat!("asyncio", ".wait_for()"),
        concat!("asyncio", ".timeout()"),
        concat!("signal", ".alarm()"),
        concat!("AbortSignal", ".timeout()"),
    ];
    calls
        .iter()
        .zip(shown.iter())
        .map(|(call, name)| {
            (
                common::compile(&format!("{call}[[:space:]]*\\(")),
                (*name).to_string(),
            )
        })
        .collect()
});

/// A timer used to abort, cancel or kill.
pub(super) static KILLING_TIMER: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        "{}.*(abort|cancel|kill|reject|throw|clearInterval)",
        concat!("set", "Timeout")
    ))
});

/// The word itself, wherever it is spelled into an identifier, a flag, a
/// field or a sentence: `…_ms`, `--…`, `.…(`, `recv_…`. The operator asked
/// for any use of it to be refused, so there is no exception for an HTTP
/// client, a navigation or a configured server entry any more. Assembled
/// from fragments so this file never carries the words it refuses.
pub(super) static DEADLINE_WORD: LazyLock<Regex> = LazyLock::new(|| {
    let words = [concat!("time", "out"), concat!("dead", "line")];
    common::compile(&format!("(?i)({})", words.join("|")))
});

/// The spellings that remove a deadline instead of setting one.
///
/// A library can carry its own: `reqwest`'s blocking client cuts every
/// request at thirty seconds unless it is told not to, and Playwright's
/// `waitFor` cuts at thirty unless it is passed zero. On 2026-09-21 deleting
/// an explicit five-minute value from a model stream made the wait *shorter*,
/// ending a route that was still answering. The calls that turn a library's
/// own number off are `…(None)`, `…(0)` and `…: 0`, and refusing them would
/// leave that number in place — the opposite of what this gate is for.
pub(super) static DISABLING: LazyLock<Regex> = LazyLock::new(|| {
    let words = [concat!("time", "out"), concat!("dead", "line")];
    let word = format!("({})[[:alnum:]_]*", words.join("|"));
    let off = "([[:space:]]*\\([[:space:]]*(None|0)[[:space:]]*\\)|[[:space:]]*:[[:space:]]*0\\b)";
    common::compile(&format!("(?i){word}{off}"))
});

/// Waiting a guessed interval instead of for the outcome that owns it.
pub(super) static GUESSED_WAIT: LazyLock<Regex> = LazyLock::new(|| {
    let calls = [
        concat!("thread", "::sleep"),
        concat!("time", "\\.sleep"),
        concat!("u", "sleep[[:space:]]*\\("),
        concat!("Thread", "\\.sleep"),
        concat!("\\bsleep[[:space:]]*\\("),
    ];
    common::compile(&format!("(?i)({})", calls.join("|")))
});

/// The words that name a limit outright.
pub(super) static LIMIT_WORDS: LazyLock<Regex> = LazyLock::new(|| {
    let words = [
        concat!("time", "_limit"),
        concat!("time", "limit"),
        concat!("max", "_time"),
        concat!("max", "time"),
    ];
    let parts: Vec<String> = words.iter().map(|word| format!("\\b{word}\\b")).collect();
    common::compile(&format!("(?i){}", parts.join("|")))
});

/// The per-operation deadlines a database or socket layer carries.
pub(super) static PER_OPERATION: LazyLock<Regex> = LazyLock::new(|| {
    let parts: Vec<String> = OPERATION_PREFIXES
        .iter()
        .map(|prefix| format!("{prefix}_time.*out"))
        .collect();
    common::compile(&format!("(?i){}", parts.join("|")))
});

