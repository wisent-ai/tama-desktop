//! Port of `src/tests/live-runtime/runtimes/git-codex-support.mjs`: the real
//! git hooks, the probes that say whether a runtime was reachable, and the
//! coverage a recorded run proves.

mod coverage;
mod hooks;
mod probe;
mod setup;

pub use coverage::{
    basename_from_hook_command, codex_coverage_keys_from_command, codex_router_coverage_entries,
    codex_router_coverage_texts, covered_keys_from_codex_router_coverage, hook_commands_match,
};
pub use hooks::{assert_git_hook_path, run_git_hook_scenario};
pub use probe::{
    codex_auth_unavailable, codex_blocked_hook_config, codex_probe, codex_probe_unavailable_reason,
    codex_router_probe, unavailable_runtime, Probe,
};
pub use setup::{
    init_git_repo, setup_existing_husky_pre_commit, setup_git_config,
    setup_missing_husky_pre_commit,
};
