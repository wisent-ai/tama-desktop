//! Builds, suites, lints and package scripts run by hand, and the reads and
//! help invocations that are not builds at all.




use crate::harness::{passes, refuses};

/// reaching for a build of its own.
#[test]
fn a_suite_a_lint_and_a_build_run_by_hand_are_refused_with_the_rule_they_break() {
    refuses("cargo test --test publication", "commit and a push");
    refuses(
        "cd rust && cargo clippy --all-targets",
        "accumulated commits",
    );
    refuses("cargo check --all-targets", "not your step");
    refuses("cargo test", "stado queue budget");
    refuses(
        "cargo build --release --bin stado",
        "three times in a rolling day",
    );
}

/// `cargo install` is the one that leaves a mark: a session used it all
/// afternoon as a compiler check once `build` and `check` were refused, and
/// every pass replaced the installed CLI with a working copy nobody
/// published — "i kto Ci powiedzial zeby sprawdzac czy Rust sie kompiluje",
/// then "zablokuj cargo install".
#[test]
fn installing_a_working_copy_onto_this_machine_is_refused() {
    refuses(
        "cargo install --path crates/tama-cli --root \"$HOME/.local\" --force",
        "delivered release",
    );
    refuses(
        "cd rust && cargo install --path . --root target/verify",
        "nobody reviewed",
    );
}

/// Formatting by hand is the same private answer: a session ran it twice on
/// 2026-09-21 to get a quality gate to pass and swept other sessions'
/// unformatted files into its own commit — "zablokuj prosze cargo fmt tak jak
/// cargo install". Asking the toolchain for help still passes, because a
/// question runs nothing.
#[test]
fn formatting_by_hand_is_refused_and_asking_for_help_passes() {
    refuses("cargo fmt", "pre-commit dispatcher");
    refuses("cd rust && cargo fmt --all", "release build reads the same check");
    passes("cargo fmt --help");
    passes("cargo test --help");
}

/// Every other driver, because a gate that named only `cargo` watched a
/// session run `swift build` and `swift test` all afternoon: "i jak to jest
/// mozliwe ze budujesz skoro nasz hook mial to blokowac. dodaj swift test i
/// jakiekolwiek komendy do budowania do listy zakazanych zwrotow".
#[test]
fn a_build_or_a_suite_in_any_other_toolchain_is_refused_with_the_ration_route() {
    refuses(
        "swift test --filter JudgeHealthJourneyTests",
        "tama build record",
    );
    refuses(
        "cd oko && swift build --product oko-cli",
        "tama build record",
    );
    refuses(
        "xcodebuild -scheme Oko -configuration Release",
        "tama build record",
    );
    refuses("xcrun swift build", "tama build record");
    refuses("npm run build", "stado queue budget");
    refuses("make -j8 release", "tama build record");
    refuses("go test ./...", "tama build record");
}

/// Every script a package manager runs, because the word after `run` is not
/// evidence of anything: `npm run test:context` compiles the release binary
/// before it runs a case, `npm run dev` compiles it and keeps it running, and
/// this gate used to read `build` and let the rest through. The operator's
/// instruction on 2026-09-21: "dodaj npm run test, npm run build npm run dev
/// i inne tego typy komendy do zakazanych komend robiacych build".
#[test]
fn a_script_run_by_a_package_manager_is_refused_with_the_delivery_route() {
    refuses("npm run dev", "tama build record");
    refuses("npm run test:context", "tama build record");
    refuses("npm test", "tama build record");
    refuses("npm install", "tama build record");
    refuses("pnpm run lint", "tama build record");
    refuses("yarn test", "tama build record");
    refuses("bun run watch", "tama build record");
    refuses("npx tsc --noEmit", "tama build record");
}

#[test]
fn reading_a_package_and_asking_for_help_pass() {
    passes("swift package describe");
    passes("swift test --help");
    passes("npm run --help");
    passes("stado queue budget --limit 3");
}
