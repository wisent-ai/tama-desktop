//! `tama-reconcile-registry-sources` driven as the real binary against real
//! git checkouts.
//!
//! The tool keeps a hook registry's `source` fields pointing at the file that
//! actually holds the hook. Two shapes are stale and repairable — a
//! repository-relative path whose file moved, and a source naming the hook's
//! own installed binary, which is what the registry writer records when it
//! cannot find the source at all. Everything else outside the checkout is
//! left alone. Each case below asserts the registry file on disk, not only
//! what the run printed.


mod support;

#[path = "cases/output.rs"]
mod output;
#[path = "cases/repaired.rs"]
mod repaired;
#[path = "cases/untouched.rs"]
mod untouched;
