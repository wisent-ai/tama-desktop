//! The complaint a piece of content earns for ending work early, and the two
//! readings it needs: which paths are somebody else-s declarations rather than
//! our work, and the first line that actually offends.

use regex::Regex;

use super::shapes::*;

pub(super) fn skipped(path: &str) -> bool {
    SKIPPED_DIRECTORIES
        .iter()
        .any(|directory| path.contains(directory))
}

/// `echo "$LINES" | head -1 | xargs`: the first offending line, trimmed.
pub(super) fn first_match(content: &str, shape: &Regex) -> Option<String> {
    content
        .lines()
        .find(|line| shape.is_match(line))
        .map(|line| line.split_whitespace().collect::<Vec<_>>().join(" "))
}

/// The complaint this content earns for ending work early, if any.
pub(crate) fn complaint(path: &str, content: &str) -> Option<String> {
    if skipped(path) {
        return None;
    }
    for (pattern, name) in KILLERS.iter() {
        if pattern.is_match(content) {
            return Some(format!("{NO_TIMEOUTS}{name}{RUN_TO_COMPLETION}"));
        }
    }
    if let Some(line) = first_match(content, &DEADLINE_WORD) {
        if !DISABLING.is_match(&line) {
            return Some(format!("{NO_TIMEOUTS}{line}{RUN_TO_COMPLETION}"));
        }
    }
    if let Some(line) = first_match(content, &GUESSED_WAIT) {
        return Some(format!("{NO_TIMEOUTS}{line}{RUN_TO_COMPLETION}"));
    }
    if KILLING_TIMER.is_match(content) {
        return Some(format!(
            "{NO_TIMEOUTS}{} to kill/abort tasks.",
            concat!("set", "Timeout")
        ));
    }
    if LIMIT_WORDS.is_match(content) {
        return Some(LIMIT_WORD_REFUSAL.to_string());
    }
    match PER_OPERATION.is_match(content) {
        true => Some(PER_OPERATION_REFUSAL.to_string()),
        false => None,
    }
}

