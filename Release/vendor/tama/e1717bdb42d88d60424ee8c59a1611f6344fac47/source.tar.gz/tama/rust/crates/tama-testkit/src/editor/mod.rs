//! Port of the editor live runtime: the save guard and the watcher, over what
//! an editor scenario is pointed at and what its outcome must say.

mod outcome;
mod save_guard;
mod watch;

pub use outcome::{assert_editor_scenario_outcome, editor_scenario_target, wait_until};
pub use save_guard::run_editor_save_guard_scenario;
pub use watch::run_editor_watch_scenario;
