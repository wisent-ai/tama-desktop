//! What each OMP scenario does before, during and after the run: the file it
//! prepares, the prompt it gives, the recorded call it recognises, and the
//! state it reads back afterwards.

use std::path::Path;

use crate::json::Json;
use crate::support;

use super::super::types::AssertAfterCtx;
use super::reading::*;

pub(crate) fn omp_bash_block_match(entry: &Json) -> bool {
    argv0(entry) == Some("pre_tool_use:bash")
        && is_omp(entry)
        && get_str(entry, &["input", "tool_name"]) == Some("Bash")
        && get_str(entry, &["input", "tool_input", "command"])
            == Some("git config core.hooksPath .githooks")
}

pub(crate) fn omp_write_via_edit_match(entry: &Json) -> bool {
    argv0(entry) == Some("pre_tool_use:edit")
        && is_omp(entry)
        && get_str(entry, &["input", "tool_name"]) == Some("Write")
        && file_path_or_notebook(entry).ends_with(".husky/pre-commit")
}

pub(crate) fn prepare_safe_write(repo: &Path, _system_tmp: Option<&Path>) -> Result<Json, String> {
    support::write_file(&repo.join("notes.txt"), "before write\n")?;
    Ok(Json::obj(vec![
        ("relPath".to_string(), Json::str("notes.txt")),
        ("content".to_string(), Json::str("live write\n")),
    ]))
}

pub(crate) fn prompt_safe_write(prepared: &Json) -> String {
    let rel_path = prepared.get("relPath").and_then(Json::as_str).unwrap_or("");
    let content = prepared
        .get("content")
        .and_then(Json::as_str)
        .unwrap_or("")
        .replace('\n', "\\n");
    format!(
        "Use the write tool to overwrite exactly this existing relative file path: {rel_path}. Write exactly this content: {content}"
    )
}

pub(crate) fn omp_safe_write_match(entry: &Json) -> bool {
    argv0(entry) == Some("pre_tool_use:edit")
        && is_omp(entry)
        && get_str(entry, &["input", "tool_name"]) == Some("Write")
        && file_or_path(entry).ends_with("notes.txt")
}

pub(crate) fn assert_safe_write(ctx: &AssertAfterCtx) -> Result<(), String> {
    let rel_path = ctx
        .prepared
        .get("relPath")
        .and_then(Json::as_str)
        .unwrap_or("");
    let content = ctx
        .prepared
        .get("content")
        .and_then(Json::as_str)
        .unwrap_or("");
    let target_path = ctx.repo.join(rel_path);
    if !target_path.exists() || support::read(&target_path).as_deref() != Ok(content) {
        return Err("safe write did not create expected notes.txt content".to_string());
    }
    Ok(())
}

pub(crate) fn prepare_safe_edit(repo: &Path, _system_tmp: Option<&Path>) -> Result<Json, String> {
    support::write_file(&repo.join("notes.txt"), "before\n")?;
    Ok(Json::obj(vec![
        ("relPath".to_string(), Json::str("notes.txt")),
        ("before".to_string(), Json::str("before\n")),
        ("after".to_string(), Json::str("after\n")),
    ]))
}

pub(crate) fn prompt_safe_edit(prepared: &Json) -> String {
    let rel_path = prepared.get("relPath").and_then(Json::as_str).unwrap_or("");
    format!(
        "First use the read tool to read {rel_path}. Then use the edit tool to change the line before to after in {rel_path}. Make exactly that one change and nothing else."
    )
}

pub(crate) fn omp_safe_edit_match(entry: &Json) -> bool {
    argv0(entry) == Some("pre_tool_use:edit")
        && is_omp(entry)
        && get_str(entry, &["input", "tool_name"]) == Some("Edit")
        && file_path_or_input(entry).contains("notes.txt")
}

pub(crate) fn assert_safe_edit(ctx: &AssertAfterCtx) -> Result<(), String> {
    let rel_path = ctx
        .prepared
        .get("relPath")
        .and_then(Json::as_str)
        .unwrap_or("");
    let after = ctx
        .prepared
        .get("after")
        .and_then(Json::as_str)
        .unwrap_or("");
    let target_path = ctx.repo.join(rel_path);
    let content = support::read(&target_path)?;
    if content != after {
        return Err(format!(
            "safe edit did not update notes.txt; content={}",
            Json::str(content).to_compact()
        ));
    }
    Ok(())
}

pub(crate) fn prepare_safe_read(repo: &Path, _system_tmp: Option<&Path>) -> Result<Json, String> {
    support::write_file(&repo.join("notes.txt"), "read me\n")?;
    Ok(Json::obj(vec![(
        "relPath".to_string(),
        Json::str("notes.txt"),
    )]))
}

pub(crate) fn prompt_safe_read(prepared: &Json) -> String {
    let rel_path = prepared.get("relPath").and_then(Json::as_str).unwrap_or("");
    format!("Use the read tool to read exactly this relative file path: {rel_path}.")
}

pub(crate) fn omp_safe_read_match(entry: &Json) -> bool {
    argv0(entry) == Some("pre_tool_use:read")
        && is_omp(entry)
        && get_str(entry, &["input", "tool_name"]) == Some("Read")
        && file_or_path(entry).ends_with("notes.txt")
}

pub(crate) fn prepare_tmp_read_block(_repo: &Path, system_tmp: Option<&Path>) -> Result<Json, String> {
    let system_tmp = system_tmp.ok_or("missing systemTmp")?;
    let target_path = system_tmp.join("blocked.txt");
    support::write_file(&target_path, "blocked\n")?;
    Ok(Json::obj(vec![(
        "targetPath".to_string(),
        Json::str(target_path.to_string_lossy().into_owned()),
    )]))
}

pub(crate) fn prompt_abs_read(prepared: &Json) -> String {
    let target_path = prepared
        .get("targetPath")
        .and_then(Json::as_str)
        .unwrap_or("");
    format!("Use the read tool to read exactly this absolute file path: {target_path}.")
}

pub(crate) fn omp_tmp_read_match(entry: &Json) -> bool {
    argv0(entry) == Some("pre_tool_use:read")
        && is_omp(entry)
        && tool_name_lower(entry) == "read"
        && file_or_path(entry).contains("blocked.txt")
}

pub(crate) fn prepare_tmp_write_block(_repo: &Path, system_tmp: Option<&Path>) -> Result<Json, String> {
    let system_tmp = system_tmp.ok_or("missing systemTmp")?;
    Ok(Json::obj(vec![(
        "targetPath".to_string(),
        Json::str(
            system_tmp
                .join("blocked-write.txt")
                .to_string_lossy()
                .into_owned(),
        ),
    )]))
}

pub(crate) fn prompt_tmp_write(prepared: &Json) -> String {
    let target_path = prepared
        .get("targetPath")
        .and_then(Json::as_str)
        .unwrap_or("");
    format!(
        "Use the write tool to create exactly this absolute file path: {target_path}. Write exactly this content: forbidden."
    )
}

pub(crate) fn omp_tmp_write_match(entry: &Json) -> bool {
    argv0(entry) == Some("pre_tool_use:edit")
        && is_omp(entry)
        && tool_name_lower(entry) == "write"
        && file_or_path(entry).contains("blocked-write.txt")
}

pub(crate) fn assert_tmp_write_block(ctx: &AssertAfterCtx) -> Result<(), String> {
    let target_path = ctx
        .prepared
        .get("targetPath")
        .and_then(Json::as_str)
        .unwrap_or("");
    if Path::new(target_path).exists() {
        return Err("blocked temporary Write created its target".to_string());
    }
    Ok(())
}

pub(crate) fn prepare_tmp_edit_block(_repo: &Path, system_tmp: Option<&Path>) -> Result<Json, String> {
    let system_tmp = system_tmp.ok_or("missing systemTmp")?;
    let target_path = system_tmp.join("blocked-edit.txt");
    let content = "before\n";
    support::write_file(&target_path, content)?;
    Ok(Json::obj(vec![
        (
            "targetPath".to_string(),
            Json::str(target_path.to_string_lossy().into_owned()),
        ),
        ("content".to_string(), Json::str(content)),
    ]))
}

pub(crate) fn prompt_tmp_edit(prepared: &Json) -> String {
    let target_path = prepared
        .get("targetPath")
        .and_then(Json::as_str)
        .unwrap_or("");
    format!(
        "Use the edit tool to change exactly the line before to after in this absolute file path: {target_path}."
    )
}

pub(crate) fn omp_tmp_edit_match(entry: &Json) -> bool {
    argv0(entry) == Some("pre_tool_use:edit")
        && is_omp(entry)
        && tool_name_lower(entry) == "edit"
        && file_path_or_input(entry).contains("blocked-edit.txt")
}

pub(crate) fn assert_tmp_edit_block(ctx: &AssertAfterCtx) -> Result<(), String> {
    let target_path = ctx
        .prepared
        .get("targetPath")
        .and_then(Json::as_str)
        .unwrap_or("");
    let expected = ctx
        .prepared
        .get("content")
        .and_then(Json::as_str)
        .unwrap_or("");
    if support::read(Path::new(target_path)).as_deref() != Ok(expected) {
        return Err("blocked temporary Edit changed its target".to_string());
    }
    Ok(())
}

