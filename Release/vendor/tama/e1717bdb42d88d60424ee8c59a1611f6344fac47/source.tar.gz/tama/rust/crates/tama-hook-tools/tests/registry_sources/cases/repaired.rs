//! A source entry the reconciler can repair: a stale path with exactly one
//! tracked file of that name, a binding that still carries a deadline, and an
//! installed hook binary whose nested source file is derived from its name.

use std::fs;

use crate::support::{fixture, init_repo, read_registry, run, write_registry};

#[test]
fn stale_source_is_repaired_when_exactly_one_file_matches_name() {
    let root = fixture("repair");
    init_repo(
        &root,
        &["rust/crates/tama-hook-tools/src/bin/block/repo/block_repository_copies.rs"],
    );
    let registry = root.join("shared-hooks/registry.json");
    fs::create_dir_all(registry.parent().unwrap()).expect("create shared-hooks");
    write_registry(
        &registry,
        &[("block-repo", "rust/crates/old/block_repository_copies.rs")],
    );

    let (code, _, stderr) = run(&["--check", registry.to_str().unwrap()]);
    assert_ne!(code, 0, "check should exit non-zero for stale source");
    assert!(stderr.contains("old/block_repository_copies.rs"));
    assert!(stderr.contains("block_repository_copies.rs"));

    let (code, _, _) = run(&[registry.to_str().unwrap()]);
    assert_eq!(code, 0, "rewrite should exit zero");
    let content = read_registry(&registry);
    assert!(content.contains("block/repo/block_repository_copies.rs"));
    assert!(!content.contains("old/block_repository_copies.rs"));

    let (code, _, _) = run(&["--check", registry.to_str().unwrap()]);
    assert_eq!(code, 0, "second check should exit zero");

    fs::remove_dir_all(&root).expect("cleanup");
}

/// A binding's `timeout` is a field nothing reads since the engine stopped
/// killing hooks, and a field nothing reads is one the next reader believes.
/// The reconciler is the writer that keeps the registry honest, so it removes
/// the deadline wherever a registry still carries one — on its own line or
/// inside a one-line binding — and `--check` refuses until it is gone.
#[test]
fn a_binding_that_still_carries_a_deadline_is_repaired() {
    let root = fixture("deadline");
    init_repo(
        &root,
        &["rust/crates/tama-hook-tools/src/bin/block/repo/block_repository_copies.rs"],
    );
    let registry = root.join("shared-hooks/registry.json");
    fs::create_dir_all(registry.parent().unwrap()).expect("create shared-hooks");
    fs::write(
        &registry,
        "{\n  \"events\": {\n    \"pre_tool_use:bash\": {\n      \"blocking\": true,\n      \
         \"hooks\": [\n        {\n          \"id\": \"block-repo\",\n          \
         \"source\": \"rust/crates/tama-hook-tools/src/bin/block/repo/block_repository_copies.rs\",\n          \
         \"timeout\": 10,\n          \"type\": \"command\"\n        },\n        \
         {\"id\": \"inline\", \"timeout\": 5, \"type\": \"command\"}\n      ]\n    }\n  }\n}\n",
    )
    .expect("write registry");

    let (code, _, stderr) = run(&["--check", registry.to_str().unwrap()]);
    assert_ne!(code, 0, "check must refuse a registry that still has one");
    assert!(
        stderr.contains("nothing reads a hook deadline"),
        "the refusal does not say what is wrong: {stderr}"
    );

    let (code, stdout, _) = run(&[registry.to_str().unwrap()]);
    assert_eq!(code, 0, "the rewrite must succeed: {stdout}");
    let content = read_registry(&registry);
    assert!(
        !content.contains("timeout"),
        "a deadline survived the rewrite: {content}"
    );
    assert!(
        content.contains("\"id\": \"inline\"") && content.contains("\"type\": \"command\""),
        "the rewrite lost a binding's other fields: {content}"
    );
    assert!(
        serde_json::from_str::<serde_json::Value>(&content).is_ok(),
        "the rewrite left the registry unparseable: {content}"
    );

    let (code, _, _) = run(&["--check", registry.to_str().unwrap()]);
    assert_eq!(code, 0, "a repaired registry passes the check");

    fs::remove_dir_all(&root).expect("cleanup");
}
/// derives it: drop `tama-`, hyphens become underscores.
#[test]
fn installed_hook_binary_source_is_repaired_to_its_nested_file() {
    let root = fixture("hook-binary");
    let tracked = "rust/crates/tama-hook-tools/src/bin/block/repo/block_repository_copies.rs";
    init_repo(&root, &[tracked]);
    let registry = root.join("shared-hooks/registry.json");
    fs::create_dir_all(registry.parent().unwrap()).expect("create shared-hooks");
    let stale = "$HOME/.local/bin/tama-block-repository-copies";
    write_registry(&registry, &[("block-repository-copies", stale)]);

    let (code, _, stderr) = run(&["--check", registry.to_str().unwrap()]);
    assert_ne!(code, 0, "check should exit non-zero: {stderr}");
    assert!(
        stderr.contains(stale),
        "the stale source is named: {stderr}"
    );
    assert!(
        stderr.contains(tracked),
        "the repaired path is named: {stderr}"
    );

    let (code, _, _) = run(&[registry.to_str().unwrap()]);
    assert_eq!(code, 0, "rewrite should exit zero");
    let content = read_registry(&registry);
    assert!(content.contains(tracked), "the nested file is recorded");
    assert!(
        !content.contains(stale),
        "the command is no longer the source"
    );

    let (code, _, _) = run(&["--check", registry.to_str().unwrap()]);
    assert_eq!(code, 0, "the repaired registry checks clean");

    fs::remove_dir_all(&root).expect("cleanup");
}

/// An installed hook binary whose Rust file is not tracked is undecidable,
