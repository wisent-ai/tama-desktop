//! `Date.now()` and `new Date(ms).toISOString()`, with the same UTC calendar
//! arithmetic, so a timestamp written by the port reads like one written by
//! the JavaScript harness.
#![allow(dead_code)]

use std::time::{SystemTime, UNIX_EPOCH};

// ---------------------------------------------------------------------------
// JS Date semantics: `Date.now()` and `new Date(ms).toISOString()`.
// ---------------------------------------------------------------------------

/// Milliseconds since the Unix epoch, like `Date.now()`.
pub fn now_millis() -> f64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as f64)
        .unwrap_or(0.0)
}

fn civil_from_days(z: i64) -> (i64, i64, i64) {
    let z = z + 719468;
    let era = if z >= 0 { z } else { z - 146096 } / 146097;
    let doe = z - era * 146097; // [0, 146096]
    let yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    let y = yoe + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = doy - (153 * mp + 2) / 5 + 1;
    let m = if mp < 10 { mp + 3 } else { mp - 9 };
    (if m <= 2 { y + 1 } else { y }, m, d)
}

/// `new Date(ms).toISOString()` — always UTC, `YYYY-MM-DDTHH:mm:ss.sssZ`.
pub fn to_iso_string(ms: f64) -> String {
    let ms = ms.trunc() as i64;
    let days = ms.div_euclid(86_400_000);
    let rem = ms.rem_euclid(86_400_000);
    let (y, mo, d) = civil_from_days(days);
    let (hh, mi, ss, mss) = (
        rem / 3_600_000,
        (rem / 60_000) % 60,
        (rem / 1_000) % 60,
        rem % 1_000,
    );
    let year = if (0..=9999).contains(&y) {
        format!("{y:04}")
    } else if y > 9999 {
        format!("+{y:06}")
    } else {
        format!("-{:06}", -y)
    };
    format!("{year}-{mo:02}-{d:02}T{hh:02}:{mi:02}:{ss:02}.{mss:03}Z")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn iso_string() {
        assert_eq!(to_iso_string(0.0), "1970-01-01T00:00:00.000Z");
        assert_eq!(
            to_iso_string(1_735_689_600_123.0),
            "2025-01-01T00:00:00.123Z"
        );
    }
}
