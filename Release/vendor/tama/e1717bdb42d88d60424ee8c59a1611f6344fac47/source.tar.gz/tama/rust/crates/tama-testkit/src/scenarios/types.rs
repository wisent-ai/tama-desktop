//! What a live scenario is: the shapes every runtime answers in, and the
//! ordered-literal pattern every regex in the JS sources reduces to.

use std::path::Path;

use crate::json::Json;
use crate::support::RunResult;

/// JS `TEMPORARY_PATH_BLOCK_HOOK_ID`.
pub const TEMPORARY_PATH_BLOCK_HOOK_ID: &str = "block-temporary-path-operations";

// ---------------------------------------------------------------------------
// minimal JS-regex stand-in (no regex crate allowed)
// ---------------------------------------------------------------------------

/// Ordered-literal-segment pattern: `segments[0].*segments[1].*...` with
/// optional case-insensitivity (`/i`) and dotall (`/s`). Every regex in the
/// JS sources reduces to this shape.
#[derive(Debug, Clone)]
pub struct Pattern {
    pub segments: Vec<&'static str>,
    pub case_insensitive: bool,
    pub dotall: bool,
}

impl Pattern {
    pub fn plain(needle: &'static str) -> Pattern {
        Pattern {
            segments: vec![needle],
            case_insensitive: false,
            dotall: false,
        }
    }

    /// `pattern.test(text)`.
    pub fn test(&self, text: &str) -> bool {
        let haystack;
        let hay: &str = if self.case_insensitive {
            haystack = text.to_lowercase();
            &haystack
        } else {
            text
        };
        let mut prev_end = 0usize;
        for (seg_index, segment) in self.segments.iter().enumerate() {
            let lowered;
            let needle: &str = if self.case_insensitive {
                lowered = segment.to_lowercase();
                &lowered
            } else {
                segment
            };
            let mut search_from = prev_end;
            loop {
                match hay[search_from..].find(needle) {
                    Some(rel) => {
                        let idx = search_from + rel;
                        // For segments after the first, the `.*` between them
                        // cannot cross a newline unless dotall is set.
                        if seg_index == 0 || self.dotall || !hay[prev_end..idx].contains('\n') {
                            prev_end = idx + needle.len();
                            break;
                        }
                        search_from = idx + 1;
                    }
                    None => return false,
                }
            }
        }
        true
    }
}

// ---------------------------------------------------------------------------
// scenario types
// ---------------------------------------------------------------------------

/// Context handed to `assertAfter` closures (`{ repo, systemTmp, prepared, omp, payloads, capturedPayload }`).
pub struct AssertAfterCtx<'a> {
    pub repo: &'a Path,
    pub system_tmp: Option<&'a Path>,
    pub prepared: &'a Json,
    pub omp: &'a RunResult,
    pub payloads: &'a [Json],
    pub captured_payload: Option<&'a Json>,
}

/// One entry of JS `scenarios` (omp-scenarios.mjs).
pub struct OmpScenario {
    pub coverage_key: &'static str,
    pub id: Option<&'static str>,
    pub hook_id: Option<&'static str>,
    pub tools: &'static str,
    pub tool_name: &'static str,
    pub forbidden_action: Option<&'static str>,
    pub prompt: Option<&'static str>,
    pub prompt_fn: Option<fn(&Json) -> String>,
    pub setup: Option<fn(&Path) -> Result<Json, String>>,
    pub prepare: Option<fn(&Path, Option<&Path>) -> Result<Json, String>>,
    pub payload_match: Option<fn(&Json) -> bool>,
    pub assert_after: Option<fn(&AssertAfterCtx) -> Result<(), String>>,
    pub captured: bool,
    pub neutral: bool,
    pub selective_adapter: bool,
    pub system_tmp: bool,
    pub expected_decision: Option<&'static str>,
    pub expected_hook_id: Option<&'static str>,
    pub expected_behavior: Option<&'static str>,
    pub omp_execution_window: Option<&'static str>,
}

/// One entry of JS `gitScenarios`.
pub struct GitScenario {
    pub coverage_key: String,
    pub hook: Json,
}

/// One entry of JS `codexScenarios`.
pub struct CodexScenario {
    pub coverage_key: &'static str,
    pub full_local_lifecycle: bool,
    pub full_local_hook_replay: bool,
    pub prompt: Option<&'static str>,
    pub expected_event: Option<&'static str>,
    pub expected_covered_key: Option<&'static str>,
}

/// One entry of JS `claudeScenarios`.
pub struct ClaudeScenario {
    pub coverage_key: String,
    pub claude_neutral: bool,
    pub claude_captured: bool,
    pub id: Option<&'static str>,
    pub event: Option<&'static str>,
    pub tool_name: Option<&'static str>,
    pub allowed_tools: Option<&'static str>,
    pub prompt: Option<&'static str>,
    pub prepare: Option<fn(&Path) -> Result<(), String>>,
    pub tool_use_match: Option<fn(&Json) -> bool>,
    pub assert_after: Option<fn(&Path) -> Result<(), String>>,
}

/// One entry of JS `editorEditCases` / `editorNotebookCases`.
pub struct EditorCase {
    pub id: &'static str,
    pub hook_id: &'static str,
    pub event: Option<&'static str>,
    pub rel_path: String,
    pub content: String,
    pub expected_decision: &'static str,
    pub expected_reason: Option<Pattern>,
    pub expected_behavior: &'static str,
    pub expected_watch_behavior: Option<&'static str>,
    pub system_tmp: bool,
}

/// An editor case bound to a runtime, as built by `editorScenarios` in
/// `orchestration.mjs`.
pub struct EditorScenario {
    pub runtime: &'static str,
    pub coverage_key: String,
    pub case: EditorCase,
}

/// Unified scenario list entry (mirrors `liveScenarios` in orchestration.mjs).
pub enum LiveScenario {
    Omp(OmpScenario),
    Git(GitScenario),
    Codex(CodexScenario),
    Claude(ClaudeScenario),
    Editor(EditorScenario),
}

impl LiveScenario {
    pub fn coverage_key(&self) -> &str {
        match self {
            LiveScenario::Omp(s) => s.coverage_key,
            LiveScenario::Git(s) => &s.coverage_key,
            LiveScenario::Codex(s) => s.coverage_key,
            LiveScenario::Claude(s) => &s.coverage_key,
            LiveScenario::Editor(s) => &s.coverage_key,
        }
    }
}

// ---------------------------------------------------------------------------
// shared small helpers for the closures
// ---------------------------------------------------------------------------

pub fn get_str<'a>(value: &'a Json, path: &[&str]) -> Option<&'a str> {
    let mut current = value;
    for key in path {
        current = current.get(key)?;
    }
    current.as_str()
}
