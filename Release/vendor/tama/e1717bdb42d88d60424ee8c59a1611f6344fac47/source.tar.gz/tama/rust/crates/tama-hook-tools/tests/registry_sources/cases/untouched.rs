//! A source entry the reconciler leaves exactly as it found it, or refuses to
//! guess at: one that already resolves, a foreign absolute path, a home path
//! that is not a hook binary at all, and every undecidable case.

use std::fs;

use crate::support::{fixture, init_repo, read_registry, run, write_registry};


#[test]
fn resolving_source_is_untouched() {
    let root = fixture("resolves");
    init_repo(
        &root,
        &["rust/crates/tama-hook-tools/src/bin/block/repo/block_repository_copies.rs"],
    );
    let registry = root.join("shared-hooks/registry.json");
    fs::create_dir_all(registry.parent().unwrap()).expect("create shared-hooks");
    write_registry(
        &registry,
        &[(
            "block-repo",
            "rust/crates/tama-hook-tools/src/bin/block/repo/block_repository_copies.rs",
        )],
    );

    let before = read_registry(&registry);
    let (code, _, _) = run(&[registry.to_str().unwrap()]);
    assert_eq!(code, 0, "rewrite should exit zero for resolving source");
    let after = read_registry(&registry);
    assert_eq!(before, after, "resolving source should not be modified");

    fs::remove_dir_all(&root).expect("cleanup");
}

#[test]
fn foreign_absolute_source_is_left_alone() {
    let root = fixture("foreign");
    init_repo(
        &root,
        &["rust/crates/tama-hook-tools/src/bin/block/repo/block_repository_copies.rs"],
    );
    let registry = root.join("shared-hooks/registry.json");
    fs::create_dir_all(registry.parent().unwrap()).expect("create shared-hooks");
    write_registry(&registry, &[("foreign", "/opt/somewhere/else.sh")]);

    let before = read_registry(&registry);
    let (code, _, _) = run(&[registry.to_str().unwrap()]);
    assert_eq!(code, 0, "rewrite should exit zero for foreign source");
    let after = read_registry(&registry);
    assert_eq!(before, after, "foreign source should not be modified");

    fs::remove_dir_all(&root).expect("cleanup");
}

/// A `$HOME` source that is NOT an installed hook binary belongs to another
/// tree and stays. The distinction matters: the sibling case below is also a
/// `$HOME` path and must be repaired, so "leave `$HOME` alone" is not the
/// rule and must not be read as one.
#[test]
fn home_source_that_is_not_a_hook_binary_is_left_alone() {
    let root = fixture("home-var");
    init_repo(
        &root,
        &["rust/crates/tama-hook-tools/src/bin/block/repo/block_repository_copies.rs"],
    );
    let registry = root.join("shared-hooks/registry.json");
    fs::create_dir_all(registry.parent().unwrap()).expect("create shared-hooks");
    write_registry(
        &registry,
        &[("home-script", "$HOME/.local/bin/some-script")],
    );

    let before = read_registry(&registry);
    let (code, _, _) = run(&[registry.to_str().unwrap()]);
    assert_eq!(
        code, 0,
        "rewrite should exit zero for a foreign home source"
    );
    let after = read_registry(&registry);
    assert_eq!(
        before, after,
        "a foreign home source should not be modified"
    );

    fs::remove_dir_all(&root).expect("cleanup");
}

/// The defect that stopped every hook release, in one test.
///
/// `register-hook.mjs` looks for a hook's source only as a flat
/// `src/bin/<stem>.rs`, so a guard living in `src/bin/block/repo/` matched
/// nothing and the writer recorded the hook's own command as its source.
/// `seal_hook_release.py` then refused the release with "External hook source
/// is missing", and no hook release could be sealed at all until this was
/// repaired. The stem comes from the binary name the same way the writer
/// never silently rewritten to something that merely looks close.
#[test]
fn installed_hook_binary_without_a_tracked_file_is_undecidable() {
    let root = fixture("hook-binary-missing");
    init_repo(
        &root,
        &["rust/crates/tama-hook-tools/src/bin/block/repo/block_repository_copies.rs"],
    );
    let registry = root.join("shared-hooks/registry.json");
    fs::create_dir_all(registry.parent().unwrap()).expect("create shared-hooks");
    write_registry(
        &registry,
        &[(
            "block-nothing-here",
            "$HOME/.local/bin/tama-block-nothing-here",
        )],
    );

    let before = read_registry(&registry);
    let (code, _, stderr) = run(&[registry.to_str().unwrap()]);
    assert_ne!(code, 0, "an undecidable source must not pass");
    assert!(
        stderr.contains("no tracked file is named block_nothing_here.rs"),
        "the missing file is named: {stderr}"
    );
    assert_eq!(before, read_registry(&registry), "nothing is rewritten");

    fs::remove_dir_all(&root).expect("cleanup");
}

#[test]
fn undecidable_source_leaves_file_unchanged_and_exits_nonzero() {
    let root = fixture("undecidable");
    init_repo(
        &root,
        &["rust/crates/tama-hook-tools/src/bin/block/repo/block_repository_copies.rs"],
    );
    let registry = root.join("shared-hooks/registry.json");
    fs::create_dir_all(registry.parent().unwrap()).expect("create shared-hooks");
    write_registry(&registry, &[("nonexistent", "rust/crates/nonexistent.rs")]);

    let before = read_registry(&registry);
    let (code, _, stderr) = run(&[registry.to_str().unwrap()]);
    assert_ne!(
        code, 0,
        "rewrite should exit non-zero for undecidable source"
    );
    assert!(stderr.contains("no tracked file is named nonexistent.rs"));
    let after = read_registry(&registry);
    assert_eq!(before, after, "file should not be modified");

    fs::remove_dir_all(&root).expect("cleanup");
}

#[test]
fn multiple_tracked_files_with_same_name_is_undecidable() {
    let root = fixture("duplicates");
    init_repo(
        &root,
        &[
            "rust/crates/tama-hook-tools/src/bin/block/repo/block_repository_copies.rs",
            "rust/other/block_repository_copies.rs",
        ],
    );
    let registry = root.join("shared-hooks/registry.json");
    fs::create_dir_all(registry.parent().unwrap()).expect("create shared-hooks");
    write_registry(
        &registry,
        &[("dupes", "rust/old/block_repository_copies.rs")],
    );

    let before = read_registry(&registry);
    let (code, _, stderr) = run(&[registry.to_str().unwrap()]);
    assert_ne!(code, 0, "rewrite should exit non-zero for multiple matches");
    assert!(stderr.contains("2 tracked files are named block_repository_copies.rs"));
    let after = read_registry(&registry);
    assert_eq!(before, after, "file should not be modified when ambiguous");

    fs::remove_dir_all(&root).expect("cleanup");
}
