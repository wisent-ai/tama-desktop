//! One row per editor edit case: the hook it exercises, the file it touches,
//! and whether the write is expected to go through or be refused.

use crate::json::Json;

use super::super::super::types::{EditorCase, Pattern, TEMPORARY_PATH_BLOCK_HOOK_ID};

/// JS `editorEditCases`.
pub fn editor_edit_cases() -> Vec<EditorCase> {
    vec![
        EditorCase {
            id: "hook-config",
            hook_id: "block-hook-config-edits-without-consent",
            event: None,
            rel_path: ".husky/pre-commit.sh".to_string(),
            content: "#!/bin/sh\nexit 0\n".to_string(),
            expected_decision: "block",
            expected_reason: Some(Pattern::plain(
                "hook source/config changes are device-level protected",
            )),
            expected_behavior: "blocks unapproved hook source/config saves",
            expected_watch_behavior: None,
            system_tmp: false,
        },
        EditorCase {
            id: "device-tests",
            hook_id: "block-device-level-tests-without-consent",
            event: None,
            rel_path: "tests/live.test.js".to_string(),
            content: "export const value = 1;\n".to_string(),
            expected_decision: "block",
            expected_reason: Some(Pattern::plain(
                "creating or editing test/device-level files requires explicit user approval",
            )),
            expected_behavior: "blocks unapproved test/device-level file saves",
            expected_watch_behavior: None,
            system_tmp: false,
        },
        EditorCase {
            id: "pre-write-edit",
            hook_id: "pre-write-edit",
            event: None,
            rel_path: "scratch/prewrite.js".to_string(),
            content: "const scraped = parseBalance(raw) || 0;\n".to_string(),
            expected_decision: "block",
            expected_reason: Some(Pattern::plain("parse/scrape/get(...) || sentinel")),
            expected_behavior: "blocks edit content that masks a missing parsed value",
            expected_watch_behavior: None,
            system_tmp: false,
        },
        EditorCase {
            id: "oko-trajectory",
            hook_id: "block-oko-trajectory-edits",
            event: None,
            rel_path: "mirror/Users/lukaszbartoszcze/Documents/CodingProjects/Wisent/oko/scripts/trajectories/slack_upgrade_install.mjs".to_string(),
            content: "await WSession.start();\n".to_string(),
            expected_decision: "block",
            expected_reason: Some(Pattern {
                segments: vec!["Do not put trajectories", "inside Oko"],
                case_insensitive: false,
                dotall: true,
            }),
            expected_behavior: "blocks Oko-owned trajectory/install automation saves",
            expected_watch_behavior: None,
            system_tmp: false,
        },
        EditorCase {
            id: "openai-api-key",
            hook_id: "block-openai-api-key",
            event: None,
            rel_path: ".claude/cache/openai.js".to_string(),
            content: "const endpoint = \"https://api.openai.com/v1/chat/completions\";\n"
                .to_string(),
            expected_decision: "block",
            expected_reason: Some(Pattern::plain("OpenAI API-key usage is forbidden")),
            expected_behavior:
                "blocks saved content containing OpenAI API endpoint/credential references",
            expected_watch_behavior: None,
            system_tmp: false,
        },
        EditorCase {
            id: "trajectory-evidence",
            hook_id: "pre-edit-trajectory-evidence",
            event: None,
            rel_path: "weles/scripts/trajectories/linkedin_login.mjs".to_string(),
            content: "export async function run() { return \"needs evidence\"; }\n".to_string(),
            expected_decision: "block",
            expected_reason: Some(Pattern::plain(
                "trajectory/keeper/routine edit needs evidence-based justification",
            )),
            expected_behavior: "blocks trajectory edits without recorded pass/fail evidence",
            expected_watch_behavior: None,
            system_tmp: false,
        },
        EditorCase {
            id: "email-infra-pass",
            hook_id: "check-email-infra",
            event: None,
            rel_path: "scratch/email-ok.js".to_string(),
            content: "export const ok = \"regular email UI copy\";\n".to_string(),
            expected_decision: "pass",
            expected_reason: None,
            expected_behavior: "passes ordinary non-workaround email-related edits",
            expected_watch_behavior: None,
            system_tmp: false,
        },
        EditorCase {
            id: "humanized-actions",
            hook_id: "check-humanized-actions",
            event: None,
            rel_path: "content-platform/scripts/browser/raw_playwright.mjs".to_string(),
            content: "export async function run(page) { await page.click(\"button\"); }\n"
                .to_string(),
            expected_decision: "block",
            expected_reason: Some(Pattern::plain(
                "raw Playwright / non-humanized browser action",
            )),
            expected_behavior: "blocks raw Playwright browser actions in browser-driving files",
            expected_watch_behavior: None,
            system_tmp: false,
        },
        EditorCase {
            id: "reward-hacking-pass",
            hook_id: "check-reward-hacking",
            event: None,
            rel_path: "scratch/reward-ok.js".to_string(),
            content: "export const guard = true;\n".to_string(),
            expected_decision: "pass",
            expected_reason: None,
            expected_behavior: "passes edits outside ~/.shared-hooks reward-hacking scope",
            expected_watch_behavior: None,
            system_tmp: false,
        },
        EditorCase {
            id: "raw-api-calls",
            hook_id: "check-raw-api-calls",
            event: None,
            rel_path: "scratch/rawapi.js".to_string(),
            content: "await fetch(\"https://discord.com/api/v9/users/@me\");\n".to_string(),
            expected_decision: "block",
            expected_reason: Some(Pattern::plain(
                "raw HTTP call to bot-classified site detected",
            )),
            expected_behavior: "blocks raw bot-classified site API calls",
            expected_watch_behavior: None,
            system_tmp: false,
        },
        EditorCase {
            id: "overleaf-api",
            hook_id: "block-overleaf-api",
            event: None,
            rel_path: "scratch/overleaf.js".to_string(),
            content: "await fetch(\"https://www.overleaf.com/project/0123456789abcdef01234567/updates\");\n".to_string(),
            expected_decision: "block",
            expected_reason: Some(Pattern::plain("raw Overleaf API usage detected")),
            expected_behavior: "blocks raw Overleaf project API calls",
            expected_watch_behavior: None,
            system_tmp: false,
        },
        EditorCase {
            id: "direct-lsi-api",
            hook_id: "block-direct-lsi-api",
            event: None,
            rel_path: ".claude/cache/lsi.js".to_string(),
            content: "await fetch(\"https://lsi2.ncbr.gov.pl/api/beneficiary/project-sections/123\");\n".to_string(),
            expected_decision: "block",
            expected_reason: Some(Pattern::plain(
                "direct LSI/PARP/NCBR API usage is forbidden",
            )),
            expected_behavior: "blocks direct LSI/PARP/NCBR API calls",
            expected_watch_behavior: None,
            system_tmp: false,
        },
        EditorCase {
            id: "legacy-activation",
            hook_id: "check-legacy-activation-bypass",
            event: None,
            rel_path: "scratch/legacy.py".to_string(),
            content: "from wisent.scripts.activations.extract_and_upload import main\n"
                .to_string(),
            expected_decision: "block",
            expected_reason: Some(Pattern::plain("legacy activation bypass detected")),
            expected_behavior: "blocks legacy foreground activation upload entrypoints",
            expected_watch_behavior: None,
            system_tmp: false,
        },
        EditorCase {
            id: "temporary-path-save",
            hook_id: TEMPORARY_PATH_BLOCK_HOOK_ID,
            event: None,
            rel_path: "blocked-save.md".to_string(),
            content: "temporary save\n".to_string(),
            expected_decision: "block",
            expected_reason: Some(Pattern::plain(
                "Temporary-path Read/Edit/Write/Save operations are not allowed",
            )),
            expected_behavior:
                "returns a blocking editor-save decision for a system temporary path",
            expected_watch_behavior: Some(
                "detects and records a system temporary-path save after the filesystem change",
            ),
            system_tmp: true,
        },
    ]
}

/// JS `editorNotebookCases`.
