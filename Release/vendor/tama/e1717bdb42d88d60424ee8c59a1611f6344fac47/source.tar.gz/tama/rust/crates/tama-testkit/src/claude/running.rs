//! Starting one Claude run and reading what it recorded: the command, the
//! assistant content of an entry, and whether the run ended in success.

use std::path::Path;

use crate::json::Json;
use crate::support::{self, RunResult};

pub(crate) fn claude_command(model: &str, allowed_tools: &str, prompt: &str) -> Vec<String> {
    vec![
        "claude".to_string(),
        "-p".to_string(),
        "--model".to_string(),
        model.to_string(),
        "--verbose".to_string(),
        "--permission-mode".to_string(),
        "bypassPermissions".to_string(),
        "--allowedTools".to_string(),
        allowed_tools.to_string(),
        "--include-hook-events".to_string(),
        "--output-format".to_string(),
        "stream-json".to_string(),
        prompt.to_string(),
    ]
}

pub(crate) fn run_claude(command: &[String], cwd: &Path) -> support::RunResult {
    support::run(
        &command[0],
        &command[1..],
        &RunOpts {
            cwd: Some(cwd.to_path_buf()),
            max_buffer: Some(10_485_760),
            ..RunOpts::default()
        },
    )
}

/// Entries of `(entry.message?.content || [])` for assistant messages.
pub(crate) fn assistant_contents(entry: &Json) -> &[Json] {
    if entry.get("type").and_then(Json::as_str) != Some("assistant") {
        return &[];
    }
    entry
        .get("message")
        .and_then(|m| m.get("content"))
        .and_then(Json::as_array)
        .unwrap_or(&[])
}

/// `entry.type === 'result' && entry.subtype === 'success' && entry.is_error === false
///  && entry.terminal_reason === 'completed' && entry.stop_reason === 'end_turn'`.
pub(crate) fn is_success_result(entry: &Json) -> bool {
    entry.get("type").and_then(Json::as_str) == Some("result")
        && entry.get("subtype").and_then(Json::as_str) == Some("success")
        && entry.get("is_error") == Some(&Json::Bool(false))
        && entry.get("terminal_reason").and_then(Json::as_str) == Some("completed")
        && entry.get("stop_reason").and_then(Json::as_str) == Some("end_turn")
}

