//! Reading one recorded hook call: the fields the OMP matchers ask about, and
//! the small accessors that read them the way the JS sources did.

use crate::json::{self, Json};

use super::super::types::get_str;

pub(crate) fn input_of(entry: &Json) -> Option<&Json> {
    entry.get("input")
}

pub(crate) fn tool_input_of(entry: &Json) -> Option<&Json> {
    input_of(entry).and_then(|input| input.get("tool_input"))
}

/// `String(tool_input?.file_path || tool_input?.path || '')`.
pub(crate) fn file_or_path(entry: &Json) -> String {
    let tool_input = tool_input_of(entry);
    json::js_string_or_empty(json::js_or2(
        tool_input.and_then(|t| t.get("file_path")),
        tool_input.and_then(|t| t.get("path")),
    ))
}

/// `String(tool_input?.file_path || tool_input?.path || tool_input?.input || '')`.
pub(crate) fn file_path_or_input(entry: &Json) -> String {
    let tool_input = tool_input_of(entry);
    json::js_string_or_empty(json::js_or3(
        tool_input.and_then(|t| t.get("file_path")),
        tool_input.and_then(|t| t.get("path")),
        tool_input.and_then(|t| t.get("input")),
    ))
}

/// `String(tool_input?.file_path || tool_input?.path || tool_input?.notebook_path || '')`.
pub(crate) fn file_path_or_notebook(entry: &Json) -> String {
    let tool_input = tool_input_of(entry);
    json::js_string_or_empty(json::js_or3(
        tool_input.and_then(|t| t.get("file_path")),
        tool_input.and_then(|t| t.get("path")),
        tool_input.and_then(|t| t.get("notebook_path")),
    ))
}

pub(crate) fn argv0(entry: &Json) -> Option<&str> {
    entry
        .get("argv")
        .and_then(|argv| argv.at(0))
        .and_then(Json::as_str)
}

pub(crate) fn is_omp(entry: &Json) -> bool {
    get_str(entry, &["input", "runtime"]) == Some("omp")
}

pub(crate) fn tool_name_lower(entry: &Json) -> String {
    json::js_string_opt(input_of(entry).and_then(|input| input.get("tool_name"))).to_lowercase()
}

// ---------------------------------------------------------------------------
// omp scenarios
// ---------------------------------------------------------------------------

