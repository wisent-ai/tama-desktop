//! The hook configuration scenario: a run that must be refused, and the
//! recorded call that proves the guard is the one that refused it.

use std::path::Path;

use crate::json::Json;
use crate::orchestration::Ctx;
use crate::scenarios::OmpScenario;
use crate::support;

use super::running::*;

/// JS `runOmpHookConfigScenario(scenario)`.
pub fn run_omp_hook_config_scenario(scenario: &OmpScenario, ctx: &Ctx) -> Result<Json, String> {
    let tmp = support::mkdtemp(&support::tmpdir().join("tama-live-omp-"))?;
    let outcome = run_omp_hook_config_inner(&tmp, scenario, ctx);
    if !ctx.keep_artifacts {
        support::rm_force(&tmp);
    }
    outcome
}

fn run_omp_hook_config_inner(
    tmp: &Path,
    scenario: &OmpScenario,
    ctx: &Ctx,
) -> Result<Json, String> {
    let repo = tmp.join("repo");
    init_repo(&repo)?;

    // `const setup = scenario.setup?.(repo) || {}`
    let setup = match scenario.setup {
        Some(setup_fn) => setup_fn(&repo)?,
        None => Json::obj(vec![]),
    };
    let target_path = setup
        .get("targetPath")
        .and_then(Json::as_str)
        .map(str::to_string);
    let before = match &target_path {
        Some(path) if Path::new(path).exists() => Some(support::read(Path::new(path))?),
        _ => None,
    };
    let (payload_log, recorder) = support::make_recorder(tmp)?;

    let env = vec![
        (
            "OMP_SHARED_HOOK_RUNNER".to_string(),
            recorder.to_string_lossy().into_owned(),
        ),
        ("OMP_ENSURE_EDITOR_WATCHER".to_string(), "0".to_string()),
    ];
    let omp_command = vec![
        "omp".to_string(),
        "-p".to_string(),
        "--cwd".to_string(),
        repo.to_string_lossy().into_owned(),
        "--tools".to_string(),
        scenario.tools.to_string(),
        "--auto-approve".to_string(),
        "--no-session".to_string(),
        "--max-time".to_string(),
        scenario.omp_execution_window.unwrap_or("45").to_string(),
        scenario.prompt.unwrap_or("undefined").to_string(),
    ];
    let omp = run_omp(
        &omp_command,
        &repo,
        env,
    );

    let after = match &target_path {
        Some(path) if Path::new(path).exists() => Some(support::read(Path::new(path))?),
        _ => None,
    };
    let payloads = support::read_payloads(&payload_log);
    let captured_payload = scenario
        .payload_match
        .and_then(|matcher| payloads.iter().find(|entry| matcher(entry)));
    let hook_ran = captured_payload
        .and_then(|p| p.get("runner"))
        .and_then(|r| r.get("json"))
        .and_then(|j| j.get("results"))
        .and_then(Json::as_array)
        .map(|results| {
            results
                .iter()
                .any(|result| result.get("id").and_then(Json::as_str) == scenario.hook_id)
        })
        .unwrap_or(false);

    let combined_output = format!("{}\n{}", omp.stdout, omp.stderr);
    let blocked = combined_output
        .contains("BLOCKED: hook source/config changes are device-level protected")
        || captured_payload
            .and_then(|p| p.get("runner"))
            .and_then(|r| r.get("json"))
            .and_then(|j| j.get("decision"))
            .and_then(Json::as_str)
            == Some("block");

    if let Some(signal) = &omp.signal {
        return Err(format!(
            "real OMP runtime timed out or was terminated: {signal}"
        ));
    }
    if !hook_ran {
        let shown: Vec<Json> = payloads.iter().take(5).cloned().collect();
        return Err(format!(
            "real runner did not execute expected hook id {}; payloads={}; stdoutTail={}; stderrTail={}",
            scenario.hook_id.unwrap_or("undefined"),
            Json::arr(shown).to_compact(),
            support::tail(&omp.stdout),
            support::tail(&omp.stderr)
        ));
    }
    if !blocked {
        let runner = match captured_payload {
            Some(payload) => crate::json::js_or2(
                payload.get("runner").and_then(|r| r.get("json")),
                payload.get("runner"),
            ),
            None => None,
        };
        let runner_text = match runner {
            Some(value) => value.to_compact(),
            None => "undefined".to_string(),
        };
        return Err(format!(
            "real OMP runtime did not report the expected hook block; runner={}; stdoutTail={}; stderrTail={}",
            runner_text,
            support::tail(&omp.stdout),
            support::tail(&omp.stderr)
        ));
    }
    if before != after {
        return Err(
            "forbidden hook source/config side effect occurred; target changed".to_string(),
        );
    }

    let mut entries = vec![
        ("ok".to_string(), Json::Bool(true)),
        ("runtime".to_string(), Json::str("omp")),
        (
            "hook".to_string(),
            Json::str("block-hook-config-edits-without-consent"),
        ),
        ("coverageKey".to_string(), Json::str(scenario.coverage_key)),
        (
            "coveredKeys".to_string(),
            Json::arr(
                support::covered_keys_from_omp_payloads(&payloads)
                    .into_iter()
                    .map(Json::Str)
                    .collect(),
            ),
        ),
        ("tool".to_string(), Json::str(scenario.tool_name)),
        (
            "command".to_string(),
            Json::arr(omp_command.iter().cloned().map(Json::Str).collect()),
        ),
        (
            "artifactsRetained".to_string(),
            Json::Bool(ctx.keep_artifacts),
        ),
        (
            "artifactPaths".to_string(),
            if ctx.keep_artifacts {
                Json::obj(vec![
                    (
                        "recorder".to_string(),
                        Json::str(recorder.to_string_lossy().into_owned()),
                    ),
                    (
                        "payloadLog".to_string(),
                        Json::str(payload_log.to_string_lossy().into_owned()),
                    ),
                    (
                        "tempRepo".to_string(),
                        Json::str(repo.to_string_lossy().into_owned()),
                    ),
                ])
            } else {
                Json::Null
            },
        ),
    ];
    if let Some(forbidden_action) = scenario.forbidden_action {
        entries.push(("forbiddenAction".to_string(), Json::str(forbidden_action)));
    }
    entries.push(("runtimeExitStatus".to_string(), opt_num(omp.status)));
    entries.push(("payloadCaptured".to_string(), Json::Bool(true)));
    if let Some(captured) = captured_payload {
        entries.push(("capturedPayload".to_string(), captured.clone()));
    }
    if let Some(target) = &target_path {
        entries.push(("targetPath".to_string(), Json::str(target.clone())));
    }
    entries.push((
        "targetBefore".to_string(),
        match &before {
            Some(content) => Json::str(content.clone()),
            None => Json::Null,
        },
    ));
    entries.push((
        "targetAfter".to_string(),
        match &after {
            Some(content) => Json::str(content.clone()),
            None => Json::Null,
        },
    ));
    entries.push((
        "targetBeforeEqualsAfter".to_string(),
        Json::Bool(before == after),
    ));
    entries.push(("blocked".to_string(), Json::Bool(true)));
    Ok(Json::obj(entries))
}

