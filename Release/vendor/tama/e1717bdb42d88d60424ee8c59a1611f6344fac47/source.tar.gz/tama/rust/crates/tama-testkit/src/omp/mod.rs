//! Port of `src/tests/live-runtime/runtimes/omp-runtime.mjs`: the three shapes
//! an OMP scenario takes - refused, passed through, and captured.

mod blocked;
mod passing;
mod running;

pub use blocked::run_omp_hook_config_scenario;
pub use passing::{run_omp_captured_tool_scenario, run_omp_neutral_bash_scenario};
