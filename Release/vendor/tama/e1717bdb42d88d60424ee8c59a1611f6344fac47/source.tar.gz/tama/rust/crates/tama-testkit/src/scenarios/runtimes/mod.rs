//! The scenarios each runtime is driven through, one module per runtime.

pub mod claude;
pub mod codex;
pub mod editor;
pub mod git;
