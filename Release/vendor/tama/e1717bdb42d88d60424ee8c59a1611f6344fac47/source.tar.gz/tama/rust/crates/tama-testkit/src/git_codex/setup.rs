//! The repository a git scenario is run in: the file it points the hook at,
//! the husky layout it does or does not have, and a real git repository.

use std::path::Path;

use crate::json::Json;
use crate::support;

/// JS `setupGitConfig(repo)`.
pub fn setup_git_config(repo: &Path) -> Result<Json, String> {
    Ok(Json::obj(vec![(
        "targetPath".to_string(),
        Json::str(
            repo.join(".git")
                .join("config")
                .to_string_lossy()
                .into_owned(),
        ),
    )]))
}

/// JS `setupMissingHuskyPreCommit(repo)`.
pub fn setup_missing_husky_pre_commit(repo: &Path) -> Result<Json, String> {
    std::fs::create_dir_all(repo.join(".husky"))
        .map_err(|e| support::io_error_message("mkdir", &repo.join(".husky"), &e))?;
    Ok(Json::obj(vec![(
        "targetPath".to_string(),
        Json::str(
            repo.join(".husky")
                .join("pre-commit")
                .to_string_lossy()
                .into_owned(),
        ),
    )]))
}

/// JS `setupExistingHuskyPreCommit(repo)`.
#[allow(dead_code)]
pub fn setup_existing_husky_pre_commit(repo: &Path) -> Result<Json, String> {
    std::fs::create_dir_all(repo.join(".husky"))
        .map_err(|e| support::io_error_message("mkdir", &repo.join(".husky"), &e))?;
    let target_path = repo.join(".husky").join("pre-commit");
    support::write_file(&target_path, "#!/bin/sh\nexit 0\n")?;
    Ok(Json::obj(vec![(
        "targetPath".to_string(),
        Json::str(target_path.to_string_lossy().into_owned()),
    )]))
}

/// JS `initGitRepo(repo)`.
pub fn init_git_repo(repo: &Path) -> Result<(), String> {
    let result = support::run_in("git", &["init", "--quiet"], repo);
    if result.status != Some(0) {
        return Err(format!(
            "failed to initialize temp git repo: {}",
            result.stderr
        ));
    }
    let result = support::run_in(
        "git",
        &["config", "user.email", "live-hook@example.invalid"],
        repo,
    );
    if result.status != Some(0) {
        return Err(format!("failed to configure git email: {}", result.stderr));
    }
    let result = support::run_in("git", &["config", "user.name", "Live Hook Smoke"], repo);
    if result.status != Some(0) {
        return Err(format!("failed to configure git user: {}", result.stderr));
    }
    Ok(())
}

