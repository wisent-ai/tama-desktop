//! The Codex scenarios, one row per hook the live Codex run exercises.

use super::super::types::CodexScenario;

/// JS `codexScenarios`.
pub fn codex_scenarios() -> Vec<CodexScenario> {
    vec![
        CodexScenario {
            coverage_key: "codex:pre_tool_use:bash:block-hook-config-edits-without-consent",
            full_local_lifecycle: false,
            full_local_hook_replay: false,
            prompt: None,
            expected_event: None,
            expected_covered_key: None,
        },
        CodexScenario {
            coverage_key: "codex:full-local:lifecycle",
            full_local_lifecycle: true,
            full_local_hook_replay: false,
            prompt: None,
            expected_event: Some("pre_tool_use:bash"),
            expected_covered_key: None,
        },
        CodexScenario {
            coverage_key: "codex:full-local:edit-lifecycle",
            full_local_lifecycle: true,
            full_local_hook_replay: false,
            prompt: Some(
                "Use apply_patch to create a new file named codex_apply_patch_smoke.txt containing exactly: codex apply patch smoke",
            ),
            expected_event: Some("pre_tool_use:edit"),
            expected_covered_key: Some(
                "codex:pre_tool_use:edit:block-hook-config-edits-without-consent",
            ),
        },
        CodexScenario {
            coverage_key: "codex:full-local:hook-replay-all",
            full_local_lifecycle: false,
            full_local_hook_replay: true,
            prompt: None,
            expected_event: None,
            expected_covered_key: None,
        },
    ]
}

// ---------------------------------------------------------------------------
// claude scenarios
// ---------------------------------------------------------------------------
