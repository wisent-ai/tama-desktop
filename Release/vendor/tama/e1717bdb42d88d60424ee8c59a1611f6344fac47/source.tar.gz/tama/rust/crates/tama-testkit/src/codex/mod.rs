//! Port of `src/tests/live-runtime/runtimes/codex-replay.mjs`: driving a real
//! Codex through the hook configuration scenario, the full local lifecycle and
//! the full local hook replay.

use std::path::Path;

use crate::git_codex::{self, Probe};
use crate::json::Json;
use crate::orchestration::Ctx;
use crate::scenarios::CodexScenario;
use crate::support::{self, RunOpts};

mod replay;
mod results;

pub use replay::{codex_adapter_entries, codex_replay_payload, ReplayEntry};
pub use results::{claude_events_by_hook_name, covered_keys_from_claude_entries, required_keys_for};

use replay::*;
use results::*;

/// JS `runCodexHookConfigScenario(scenario)`.
pub fn run_codex_hook_config_scenario(scenario: &CodexScenario, ctx: &Ctx) -> Result<Json, String> {
    let tmp = support::mkdtemp(&support::tmpdir().join("tama-live-codex-"))?;
    let outcome = run_codex_hook_config_inner(&tmp, scenario, ctx);
    if !ctx.keep_artifacts {
        support::rm_force(&tmp);
    }
    outcome
}

fn run_codex_hook_config_inner(
    tmp: &Path,
    scenario: &CodexScenario,
    ctx: &Ctx,
) -> Result<Json, String> {
    git_codex::init_git_repo(tmp)?;
    let prompt = "Use bash to run exactly: git config core.hooksPath .githooks";
    let primary = if ctx.codex_router_coverage {
        git_codex::codex_router_probe(tmp, prompt)?
    } else {
        git_codex::codex_probe(
            tmp,
            &[
                "exec".to_string(),
                "--skip-git-repo-check".to_string(),
                "--sandbox".to_string(),
                "workspace-write".to_string(),
                prompt.to_string(),
            ],
        )?
    };

    if git_codex::codex_blocked_hook_config(&primary) {
        if primary.target_changed {
            return Err(
                "forbidden hook source/config side effect occurred; target changed".to_string(),
            );
        }
        return codex_block_result(scenario, &primary, ctx);
    }

    let auth_unavailable = git_codex::codex_auth_unavailable(&primary.output);
    if auth_unavailable && !primary.target_changed {
        let label = if primary.via_model_router {
            "model-router"
        } else {
            "cloud"
        };
        return codex_unavailable_result(scenario, &[(label, &primary)], ctx);
    }

    Err(format!(
        "real Codex runtime did not report expected hook block: status={}; outputTail={}",
        match primary.exit_status {
            Some(code) => code.to_string(),
            None => "null".to_string(),
        },
        primary.output_tail
    ))
}

/// JS `runCodexFullLocalLifecycleScenario(scenario)`.
pub fn run_codex_full_local_lifecycle_scenario(
    scenario: &CodexScenario,
    ctx: &Ctx,
) -> Result<Json, String> {
    if std::env::var("MODEL_ROUTER_CODEX_COVERAGE_HOOKS").as_deref() != Ok("full-local") {
        return Err(
            "codex full-local lifecycle scenario requires MODEL_ROUTER_CODEX_COVERAGE_HOOKS=full-local"
                .to_string(),
        );
    }
    let tmp = support::mkdtemp(&support::tmpdir().join("tama-live-codex-full-local-"))?;
    let outcome = run_codex_full_local_lifecycle_inner(&tmp, scenario, ctx);
    if !ctx.keep_artifacts {
        support::rm_force(&tmp);
    }
    outcome
}

fn run_codex_full_local_lifecycle_inner(
    tmp: &Path,
    scenario: &CodexScenario,
    ctx: &Ctx,
) -> Result<Json, String> {
    git_codex::init_git_repo(tmp)?;
    let prompt = scenario.prompt.unwrap_or(
        "Use bash to run exactly this harmless command and nothing else: printf codex_full_local_lifecycle_smoke",
    );
    let probe = git_codex::codex_router_probe(tmp, prompt)?;
    if probe.exit_status != Some(0) {
        return Err(format!(
            "full-local lifecycle router call failed: status={}; outputTail={}",
            match probe.exit_status {
                Some(code) => code.to_string(),
                None => "null".to_string(),
            },
            probe.output_tail
        ));
    }
    if git_codex::codex_blocked_hook_config(&probe) {
        return Err(format!(
            "full-local lifecycle scenario was blocked; outputTail={}",
            probe.output_tail
        ));
    }
    if probe.target_changed {
        return Err("full-local lifecycle scenario changed git config unexpectedly".to_string());
    }
    let covered_keys =
        git_codex::covered_keys_from_codex_router_coverage(&ctx.root, &probe.output)?;
    if covered_keys.is_empty() {
        return Err(format!(
            "full-local lifecycle scenario produced no model-router hook coverage; outputTail={}",
            probe.output_tail
        ));
    }
    if let Some(expected_key) = scenario.expected_covered_key {
        if !covered_keys.iter().any(|k| k == expected_key) {
            return Err(format!(
                "full-local lifecycle missing expected key {expected_key}; coveredKeys={}",
                covered_keys.join(",")
            ));
        }
    }
    if let Some(expected_event) = scenario.expected_event {
        let prefix = format!("codex:{expected_event}:");
        if !covered_keys.iter().any(|k| k.starts_with(&prefix)) {
            return Err(format!(
                "full-local lifecycle missing expected event {expected_event}; coveredKeys={}",
                covered_keys.join(",")
            ));
        }
    }
    Ok(Json::obj(vec![
        ("ok".to_string(), Json::Bool(true)),
        ("runtime".to_string(), Json::str("codex")),
        ("hook".to_string(), Json::str("full-local-lifecycle")),
        ("coverageKey".to_string(), Json::str(scenario.coverage_key)),
        (
            "coveredKeys".to_string(),
            Json::arr(covered_keys.into_iter().map(Json::Str).collect()),
        ),
        (
            "command".to_string(),
            Json::arr(probe.command.iter().cloned().map(Json::Str).collect()),
        ),
        (
            "runtimeExitStatus".to_string(),
            match probe.exit_status {
                Some(code) => Json::num_i64(code as i64),
                None => Json::Null,
            },
        ),
        ("targetBeforeEqualsAfter".to_string(), Json::Bool(true)),
        ("blocked".to_string(), Json::Bool(false)),
        ("payloadCaptured".to_string(), Json::Bool(false)),
    ]))
}

/// JS `runCodexFullLocalHookReplayScenario(scenario)`.
pub fn run_codex_full_local_hook_replay_scenario(
    scenario: &CodexScenario,
    ctx: &Ctx,
) -> Result<Json, String> {
    let scratch_dir = support::make_live_runtime_temp("codex-replay-")?;
    let outcome = run_codex_full_local_hook_replay_inner(&scratch_dir, scenario, ctx);
    if !ctx.keep_artifacts {
        support::rm_force(&scratch_dir);
    }
    outcome
}

fn run_codex_full_local_hook_replay_inner(
    scratch_dir: &Path,
    scenario: &CodexScenario,
    ctx: &Ctx,
) -> Result<Json, String> {
    git_codex::init_git_repo(scratch_dir)?;
    let mut failures: Vec<Json> = Vec::new();
    let mut covered_keys: Vec<String> = Vec::new();
    let entries = codex_adapter_entries(&ctx.root)?;
    for entry in &entries {
        let payload = codex_replay_payload(&entry.event, scratch_dir)?;
        let result = support::run(
            "sh",
            &["-c".to_string(), entry.command.clone()],
            &RunOpts {
                cwd: Some(scratch_dir.to_path_buf()),
                input: Some(payload),
                max_buffer: Some(1_048_576),
                ..RunOpts::default()
            },
        );
        // `const code = result.status ?? (result.signal ? `signal:${result.signal}` : 'unknown')`
        let code: Json = match result.status {
            Some(status) => Json::num_i64(status as i64),
            None => match &result.signal {
                Some(signal) => Json::str(format!("signal:{signal}")),
                None => Json::str("unknown"),
            },
        };
        if result.status != Some(0) {
            failures.push(Json::obj(vec![
                ("event".to_string(), Json::str(entry.event.clone())),
                ("command".to_string(), Json::str(entry.command.clone())),
                ("code".to_string(), code),
                (
                    "stderr".to_string(),
                    Json::str(support::tail(&result.stderr)),
                ),
                (
                    "stdout".to_string(),
                    Json::str(support::tail(&result.stdout)),
                ),
            ]));
            continue;
        }
        covered_keys.extend(git_codex::codex_coverage_keys_from_command(
            &ctx.root,
            &entry.event,
            &entry.command,
        )?);
    }
    if !failures.is_empty() {
        let shown: Vec<Json> = failures.iter().take(10).cloned().collect();
        return Err(format!(
            "Codex full-local hook replay failed {} hook(s): {}",
            failures.len(),
            Json::arr(shown).to_compact()
        ));
    }
    let required_codex_keys = required_keys_for(&ctx.root, "codex", None)?;
    let unique_covered = support::unique(covered_keys);
    let missing: Vec<String> = required_codex_keys
        .iter()
        .filter(|key| !unique_covered.contains(key))
        .cloned()
        .collect();
    if !missing.is_empty() {
        return Err(format!(
            "Codex full-local hook replay missing {} required key(s): {}",
            missing.len(),
            missing.join(",")
        ));
    }
    Ok(Json::obj(vec![
        ("ok".to_string(), Json::Bool(true)),
        ("runtime".to_string(), Json::str("codex")),
        ("hook".to_string(), Json::str("full-local-hook-replay-all")),
        ("coverageKey".to_string(), Json::str(scenario.coverage_key)),
        (
            "coveredKeys".to_string(),
            Json::arr(unique_covered.into_iter().map(Json::Str).collect()),
        ),
        (
            "replayedHookCount".to_string(),
            Json::num_usize(entries.len()),
        ),
        ("blocked".to_string(), Json::Bool(false)),
        ("payloadCaptured".to_string(), Json::Bool(true)),
    ]))
}
