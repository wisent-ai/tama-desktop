//! The one-off repair guard, driven as a real binary against real command
//! lines: what it refuses, the product route each refusal names, and the reads
//! beside every refusal that have to keep passing.

#[path = "one_off_repair/harness.rs"]
mod harness;

#[path = "one_off_repair/builds.rs"]
mod builds;
#[path = "one_off_repair/hosts.rs"]
mod hosts;
#[path = "one_off_repair/machine.rs"]
mod machine;
