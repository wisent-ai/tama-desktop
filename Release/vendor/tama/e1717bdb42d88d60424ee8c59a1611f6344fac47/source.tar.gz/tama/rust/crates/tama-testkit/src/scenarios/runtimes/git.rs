//! The git hook scenarios, read from the shared-hooks registry so the list is
//! the registry itself rather than a second copy of it.

use std::path::Path;

use crate::json::{self, Json};
use crate::support;

use super::super::types::GitScenario;

/// document key order (`hookSource` is echoed back in results).
pub fn git_scenarios(root: &Path) -> Result<Vec<GitScenario>, String> {
    let registry_path = root.join("shared-hooks").join("registry.json");
    let text = support::read(&registry_path)?;
    let registry =
        json::parse(&text).map_err(|e| format!("{e} (in {})", registry_path.display()))?;
    let hooks = registry
        .get("catalog")
        .and_then(|c| c.get("gitHooks"))
        .and_then(Json::as_array)
        .map(<[Json]>::to_vec)
        .unwrap_or_default();
    Ok(hooks
        .into_iter()
        .map(|hook: Json| {
            // `hook.event || hook.id`
            let event = match hook.get("event") {
                Some(value) if value.truthy() => value.js_string(),
                _ => json::js_string_opt(hook.get("id")),
            };
            let hook_id = json::js_string_opt(hook.get("id"));
            GitScenario {
                coverage_key: support::coverage_key_opt("git", &event, &hook_id, &event),
                hook,
            }
        })
        .collect())
}

// ---------------------------------------------------------------------------
// codex scenarios
// ---------------------------------------------------------------------------

