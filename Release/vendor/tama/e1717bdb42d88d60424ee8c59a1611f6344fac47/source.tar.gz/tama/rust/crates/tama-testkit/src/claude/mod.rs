//! Port of the Claude live runtime: the three shapes a Claude scenario takes -
//! refused, passed through, and captured.

mod captured;
mod guarded;
mod running;

pub use captured::run_claude_captured_tool_scenario;
pub use guarded::{run_claude_hook_config_scenario, run_claude_neutral_bash_scenario};
