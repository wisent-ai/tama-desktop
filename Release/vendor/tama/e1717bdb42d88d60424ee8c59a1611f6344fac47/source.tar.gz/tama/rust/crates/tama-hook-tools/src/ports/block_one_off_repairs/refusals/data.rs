//! Data changed by hand: a row through a database client, and a value in a
//! key-value store or a machine setting written from the shell.

use super::super::vocabulary::*;

/// A row in a key-value store changed by hand.
pub(crate) fn store_refusal(program: &str, args: &[String]) -> Option<String> {
    let words = &*VOCABULARY;
    if !has(&words.store_programs, program) || asks_for_help(args) {
        return None;
    }
    let command = args
        .iter()
        .map(|arg| arg.to_ascii_lowercase())
        .find(|arg| has(&words.store_write_commands, arg))?;
    Some(format!(
        "{BANNER}`{program} {command}` changes what a store holds by hand, and the product that \
         owns those keys neither wrote nor recorded it: the next write from the product meets \
         state it never agreed to. The command that owns the keys is the product's own, and a \
         change that has to outlive this machine belongs in its migration or its declaration."
    ))
}

/// A machine setting written by hand.
pub(crate) fn setting_refusal(program: &str, args: &[String]) -> Option<String> {
    let words = &*VOCABULARY;
    if !has(&words.setting_programs, program) || asks_for_help(args) {
        return None;
    }
    let verb = args
        .iter()
        .map(|arg| arg.to_ascii_lowercase())
        .find(|arg| has(&words.setting_write_verbs, arg))?;
    Some(format!(
        "{BANNER}`{program} {verb}` changes a setting on this machine and nothing declares it: the \
         next machine, the next image and this one after a reset do not have it. A setting a \
         product owns is declared where that product reads it — `stado registry set --path \
         <FIELD> --value <VALUE>` for the fleet's own declarations, the product's own command for \
         its runtime, and a browser policy through Weles — so every host that needs it gets it."
    ))
}

/// A row or a table changed by hand through a database client.
pub(crate) fn sql_refusal(program: &str, raw: &str) -> Option<String> {
    let words = &*VOCABULARY;
    if !has(&words.sql_programs, program) {
        return None;
    }
    let statement = quoted(raw).into_iter().find_map(|argument| {
        let head = argument
            .split(|character: char| !character.is_ascii_alphabetic())
            .find(|word| !word.is_empty())?
            .to_ascii_lowercase();
        has(&words.sql_write_statements, &head).then_some(head)
    })?;
    Some(format!(
        "{BANNER}`{program} … {statement} …` changes rows or their shape by hand, and every check \
         the product keeps on them - validation, derived tables, the schema version - is skipped, \
         so the next product write meets data it never agreed to. The rows have an owner: for \
         Oko's catalogue `oko-cli transcripts reindex` and `oko-cli transcripts tasks …`, for a \
         service's own store that service's CLI, and a change of shape belongs in a migration \
         that ships with the product and runs on every host."
    ))
}
