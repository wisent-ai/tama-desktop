//! Reading a JSON document in the order it was written. `serde_json` sorts
//! object keys and `JSON.parse` does not, so the order the tiers were declared
//! in is recovered by scanning the raw text.
#![allow(dead_code)]


// ---------------------------------------------------------------------------
// Insertion-ordered JSON key extraction. `Object.keys(policy.tiers)`
/// preserves the document order; `serde_json::Value` does not, so the order
/// is recovered by scanning the raw JSON text.
// ---------------------------------------------------------------------------

fn skip_ws(bytes: &[u8], pos: &mut usize) {
    while *pos < bytes.len() && matches!(bytes[*pos], b' ' | b'\t' | b'\n' | b'\r') {
        *pos += 1;
    }
}

fn parse_json_string(bytes: &[u8], pos: &mut usize) -> Option<String> {
    if bytes.get(*pos) != Some(&b'"') {
        return None;
    }
    *pos += 1;
    let mut out = String::new();
    while *pos < bytes.len() {
        let b = bytes[*pos];
        *pos += 1;
        match b {
            b'"' => return Some(out),
            b'\\' => {
                let esc = *bytes.get(*pos)?;
                *pos += 1;
                match esc {
                    b'"' => out.push('"'),
                    b'\\' => out.push('\\'),
                    b'/' => out.push('/'),
                    b'b' => out.push('\u{0008}'),
                    b'f' => out.push('\u{000c}'),
                    b'n' => out.push('\n'),
                    b'r' => out.push('\r'),
                    b't' => out.push('\t'),
                    b'u' => {
                        let hex = bytes.get(*pos..*pos + 4)?;
                        *pos += 4;
                        let code = u16::from_str_radix(std::str::from_utf8(hex).ok()?, 16).ok()?;
                        out.push(char::from_u32(code as u32).unwrap_or('\u{fffd}'));
                    }
                    _ => return None,
                }
            }
            _ => {
                // Re-decode multi-byte UTF-8 sequences verbatim.
                if b < 0x80 {
                    out.push(b as char);
                } else {
                    let start = *pos - 1;
                    let len = if b >= 0xf0 {
                        4
                    } else if b >= 0xe0 {
                        3
                    } else {
                        2
                    };
                    *pos = start + len;
                    out.push_str(std::str::from_utf8(bytes.get(start..*pos)?).ok()?);
                }
            }
        }
    }
    None
}

fn skip_json_value(bytes: &[u8], pos: &mut usize) -> Option<()> {
    skip_ws(bytes, pos);
    match *bytes.get(*pos)? {
        b'"' => {
            parse_json_string(bytes, pos)?;
        }
        b'{' | b'[' => {
            let mut depth = 0i64;
            while *pos < bytes.len() {
                let b = bytes[*pos];
                if b == b'"' {
                    parse_json_string(bytes, pos)?;
                    continue;
                }
                *pos += 1;
                match b {
                    b'{' | b'[' => depth += 1,
                    b'}' | b']' => {
                        depth -= 1;
                        if depth == 0 {
                            return Some(());
                        }
                    }
                    _ => {}
                }
            }
            return None;
        }
        _ => {
            while *pos < bytes.len() && !matches!(bytes[*pos], b',' | b'}' | b']') {
                *pos += 1;
            }
        }
    }
    Some(())
}

/// Key order of the object stored under top-level `key` in a JSON document,
/// like `Object.keys(JSON.parse(text)[key])`.
pub fn nested_object_key_order(text: &str, key: &str) -> Option<Vec<String>> {
    let bytes = text.as_bytes();
    let mut pos = 0;
    skip_ws(bytes, &mut pos);
    if bytes.get(pos) != Some(&b'{') {
        return None;
    }
    pos += 1;
    loop {
        skip_ws(bytes, &mut pos);
        if bytes.get(pos) == Some(&b'}') {
            return None;
        }
        let name = parse_json_string(bytes, &mut pos)?;
        skip_ws(bytes, &mut pos);
        if bytes.get(pos) != Some(&b':') {
            return None;
        }
        pos += 1;
        skip_ws(bytes, &mut pos);
        if name == key && bytes.get(pos) == Some(&b'{') {
            pos += 1;
            let mut keys = Vec::new();
            loop {
                skip_ws(bytes, &mut pos);
                if bytes.get(pos) == Some(&b'}') {
                    return Some(keys);
                }
                keys.push(parse_json_string(bytes, &mut pos)?);
                skip_ws(bytes, &mut pos);
                if bytes.get(pos) != Some(&b':') {
                    return None;
                }
                pos += 1;
                skip_json_value(bytes, &mut pos)?;
                skip_ws(bytes, &mut pos);
                match bytes.get(pos) {
                    Some(b',') => pos += 1,
                    Some(b'}') => return Some(keys),
                    _ => return None,
                }
            }
        }
        skip_json_value(bytes, &mut pos)?;
        skip_ws(bytes, &mut pos);
        match bytes.get(pos) {
            Some(b',') => pos += 1,
            Some(b'}') => return None,
            _ => return None,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn key_order() {
        let text =
            r#"{"a": 1, "tiers": {"integrity": {}, "etiquette": {"x": [1, {"}": 2}]}}, "z": 2}"#;
        assert_eq!(
            nested_object_key_order(text, "tiers"),
            Some(vec!["integrity".to_string(), "etiquette".to_string()])
        );
        assert_eq!(nested_object_key_order(text, "missing"), None);
    }
}
