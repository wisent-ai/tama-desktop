//! Driving the real git hooks: the hook path a scenario declares, a commit and
//! a push attempted in a real repository, and what git did about each of them.

use std::path::Path;

use crate::json::{self, Json};
use crate::scenarios::GitScenario;
use crate::support;

use super::setup::init_git_repo;

/// JS `assertGitHookPath(repo, hook)`.
pub fn assert_git_hook_path(repo: &Path, hook: &Json) -> Result<String, String> {
    let hooks_path = match hook.get("hooksPath").and_then(Json::as_str) {
        Some(path) if path.starts_with('/') => path.to_string(),
        _ => support::dirname(&json::js_string_opt(hook.get("source"))),
    };
    let result = support::run_in("git", &["config", "core.hooksPath", &hooks_path], repo);
    if result.status != Some(0) {
        return Err(format!(
            "failed to configure hooksPath {hooks_path}: {}",
            result.stderr
        ));
    }
    Ok(hooks_path)
}

fn opt_str(value: Option<&Json>) -> Option<String> {
    value.and_then(Json::as_str).map(str::to_string)
}

fn git_result_json(
    hook: &Json,
    coverage_key: &str,
    command: Vec<String>,
    hooks_path: &str,
    final_entries: Vec<(String, Json)>,
) -> Json {
    let mut entries = vec![
        ("ok".to_string(), Json::Bool(true)),
        ("runtime".to_string(), Json::str("git")),
    ];
    // `event: hook.event` — dropped by JSON.stringify when undefined.
    if let Some(event) = hook.get("event") {
        entries.push(("event".to_string(), event.clone()));
    }
    // `hook: hook.id` — dropped by JSON.stringify when undefined.
    if let Some(id) = hook.get("id") {
        entries.push(("hook".to_string(), id.clone()));
    }
    entries.push(("coverageKey".to_string(), Json::str(coverage_key)));
    entries.push((
        "coveredKeys".to_string(),
        Json::arr(vec![Json::str(coverage_key)]),
    ));
    entries.push((
        "command".to_string(),
        Json::arr(command.into_iter().map(Json::Str).collect()),
    ));
    if let Some(source) = hook.get("source") {
        entries.push(("hookSource".to_string(), source.clone()));
    }
    entries.push(("hooksPath".to_string(), Json::str(hooks_path)));
    entries.extend(final_entries);
    Json::obj(entries)
}

fn run_git_pre_commit_scenario(hook: &Json, keep_artifacts: bool) -> Result<Json, String> {
    let tmp = support::mkdtemp(&support::tmpdir().join("tama-live-git-pre-commit-"))?;
    let outcome = run_git_pre_commit_inner(&tmp, hook);
    if !keep_artifacts {
        support::rm_force(&tmp);
    }
    outcome
}

fn run_git_pre_commit_inner(tmp: &Path, hook: &Json) -> Result<Json, String> {
    init_git_repo(tmp)?;
    let hooks_path = assert_git_hook_path(tmp, hook)?;
    support::write_file(&tmp.join("staged.txt"), "staged\n")?;
    let result = support::run_in("git", &["add", "staged.txt"], tmp);
    if result.status != Some(0) {
        return Err(format!(
            "failed to stage pre-commit fixture: {}",
            result.stderr
        ));
    }
    support::write_file(&tmp.join("untracked.txt"), "untracked\n")?;
    let result = support::run(
        "git",
        &[
            "commit".to_string(),
            "-m".to_string(),
            "live pre-commit hook smoke".to_string(),
        ],
        &RunOpts {
            cwd: Some(tmp.to_path_buf()),
            ..RunOpts::default()
        },
    );
    let output = format!("{}\n{}", result.stdout, result.stderr);
    if result.status == Some(0) {
        return Err("real git pre-commit did not block dirty worktree".to_string());
    }
    if !output.contains("pre-commit blocked: worktree has unstaged or untracked files") {
        return Err(format!(
            "real git pre-commit did not report expected dirty-worktree block: {}",
            support::tail_n(&output, 1000)
        ));
    }
    let head = support::run_in("git", &["rev-parse", "--verify", "HEAD"], tmp);
    if head.status == Some(0) {
        return Err("blocked pre-commit still created a commit".to_string());
    }
    let event = opt_str(hook.get("event"));
    let hook_id = json::js_string_opt(hook.get("id"));
    let event_or_id = event.clone().unwrap_or_else(|| hook_id.clone());
    let coverage_key = support::coverage_key_opt("git", &event_or_id, &hook_id, &event_or_id);
    Ok(git_result_json(
        hook,
        &coverage_key,
        vec![
            "git".to_string(),
            "commit".to_string(),
            "-m".to_string(),
            "live pre-commit hook smoke".to_string(),
        ],
        &hooks_path,
        vec![
            ("blocked".to_string(), Json::Bool(true)),
            ("commitCreated".to_string(), Json::Bool(false)),
        ],
    ))
}

fn run_git_pre_push_scenario(hook: &Json, keep_artifacts: bool) -> Result<Json, String> {
    let tmp = support::mkdtemp(&support::tmpdir().join("tama-live-git-pre-push-"))?;
    let remote = support::mkdtemp(&support::tmpdir().join("tama-live-git-remote-"))?;
    let outcome = run_git_pre_push_inner(&tmp, &remote, hook);
    if !keep_artifacts {
        support::rm_force(&tmp);
        support::rm_force(&remote);
    }
    outcome
}

fn run_git_pre_push_inner(tmp: &Path, remote: &Path, hook: &Json) -> Result<Json, String> {
    init_git_repo(tmp)?;
    let result = support::run_in("git", &["init", "--bare", "--quiet"], remote);
    if result.status != Some(0) {
        return Err(format!(
            "failed to initialize temp remote: {}",
            result.stderr
        ));
    }
    support::write_file(&tmp.join("tracked.txt"), "tracked\n")?;
    let result = support::run_in("git", &["add", "tracked.txt"], tmp);
    if result.status != Some(0) {
        return Err(format!("failed to stage initial file: {}", result.stderr));
    }
    let result = support::run_in("git", &["commit", "-m", "initial"], tmp);
    if result.status != Some(0) {
        return Err(format!(
            "failed to create initial commit: {}",
            result.stderr
        ));
    }
    let remote_str = remote.to_string_lossy().into_owned();
    let result = support::run_in("git", &["remote", "add", "origin", &remote_str], tmp);
    if result.status != Some(0) {
        return Err(format!("failed to add temp remote: {}", result.stderr));
    }
    let hooks_path = assert_git_hook_path(tmp, hook)?;
    support::write_file(&tmp.join("dirty.txt"), "dirty\n")?;
    let result = support::run(
        "git",
        &[
            "push".to_string(),
            "origin".to_string(),
            "HEAD:refs/heads/main".to_string(),
        ],
        &RunOpts {
            cwd: Some(tmp.to_path_buf()),
            ..RunOpts::default()
        },
    );
    let output = format!("{}\n{}", result.stdout, result.stderr);
    if result.status == Some(0) {
        return Err("real git pre-push did not block dirty worktree".to_string());
    }
    if !output.contains("pre-push blocked: worktree has uncommitted or untracked files") {
        return Err(format!(
            "real git pre-push did not report expected dirty-worktree block: {}",
            support::tail_n(&output, 1000)
        ));
    }
    let pushed = support::run(
        "git",
        &[
            "--git-dir".to_string(),
            remote_str.clone(),
            "show-ref".to_string(),
            "--verify".to_string(),
            "refs/heads/main".to_string(),
        ],
        &RunOpts::default(),
    );
    if pushed.status == Some(0) {
        return Err("blocked pre-push still updated remote main".to_string());
    }
    let event = opt_str(hook.get("event"));
    let hook_id = json::js_string_opt(hook.get("id"));
    let event_or_id = event.clone().unwrap_or_else(|| hook_id.clone());
    let coverage_key = support::coverage_key_opt("git", &event_or_id, &hook_id, &event_or_id);
    Ok(git_result_json(
        hook,
        &coverage_key,
        vec![
            "git".to_string(),
            "push".to_string(),
            "origin".to_string(),
            "HEAD:refs/heads/main".to_string(),
        ],
        &hooks_path,
        vec![
            ("blocked".to_string(), Json::Bool(true)),
            ("remoteUpdated".to_string(), Json::Bool(false)),
        ],
    ))
}

/// JS `runGitHookScenario(scenario)`.
pub fn run_git_hook_scenario(scenario: &GitScenario, keep_artifacts: bool) -> Result<Json, String> {
    match scenario.hook.get("event").and_then(Json::as_str) {
        Some("pre-commit") => run_git_pre_commit_scenario(&scenario.hook, keep_artifacts),
        Some("pre-push") => run_git_pre_push_scenario(&scenario.hook, keep_artifacts),
        other => Err(format!(
            "no live git scenario for event {}",
            match other {
                Some(event) => event.to_string(),
                None => json::js_string_opt(scenario.hook.get("event")),
            }
        )),
    }
}

