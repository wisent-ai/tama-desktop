//! What an editor scenario is pointed at and what its outcome has to say: the
//! wait a real editor integration needs, the target file, and the hook results
//! read out of what the integration wrote.

use std::path::Path;
use std::time::{Duration, Instant};

use crate::json::{self, Json};
use crate::scenarios::{EditorCase, EditorScenario};
use crate::support;

/// JS `waitUntil(predicate, timeoutMs)`.
pub fn wait_until(predicate: impl FnMut() -> bool, timeout_ms: u64) -> bool {
    let deadline = Instant::now() + Duration::from_millis(timeout_ms);
    let mut predicate = predicate;
    while Instant::now() < deadline {
        if predicate() {
            return true;
        }
        std::thread::sleep(Duration::from_millis(200));
    }
    false
}

/// JS `editorScenarioTarget(rootDir, scenario)`.
pub fn editor_scenario_target(root_dir: &Path, case: &EditorCase) -> Result<String, String> {
    let target_path = root_dir.join(&case.rel_path);
    if let Some(parent) = target_path.parent() {
        std::fs::create_dir_all(parent)
            .map_err(|e| support::io_error_message("mkdir", parent, &e))?;
    }
    support::write_file(&target_path, &case.content)?;
    Ok(target_path.to_string_lossy().into_owned())
}

/// JS `editorHookResults(outcome)`: `{...hookResult, event: result.event}`.
pub(crate) fn editor_hook_results(outcome: Option<&Json>) -> Vec<Json> {
    let mut results = Vec::new();
    let entries = outcome
        .and_then(|o| o.get("results"))
        .and_then(Json::as_array)
        .unwrap_or(&[]);
    for result in entries {
        let hook_results = result
            .get("parsed")
            .and_then(|p| p.get("results"))
            .and_then(Json::as_array)
            .unwrap_or(&[]);
        for hook_result in hook_results {
            let mut merged = hook_result.clone();
            match result.get("event") {
                Some(event) => merged.set("event", event.clone()),
                // `{...hookResult, event: undefined}` keeps the key with an
                // undefined value, which behaves like an absent key downstream.
                None => merged.remove("event"),
            }
            results.push(merged);
        }
    }
    results
}

/// JS `assertEditorScenarioOutcome(parsed, scenario, targetPath, details)`.
/// Returns the matching `hookResult`.
pub fn assert_editor_scenario_outcome(
    parsed: Option<&Json>,
    scenario: &EditorScenario,
    target_path: &str,
    details: &str,
) -> Result<Json, String> {
    let outcomes = parsed
        .and_then(|p| p.get("outcomes"))
        .and_then(Json::as_array)
        .unwrap_or(&[]);
    // `outcomes.find((item) => item.file === targetPath) || parsed?.outcomes?.[0]`
    let outcome = outcomes
        .iter()
        .find(|item| item.get("file").and_then(Json::as_str) == Some(target_path))
        .or_else(|| outcomes.first());
    let expected_event = scenario.case.event.unwrap_or("pre_tool_use:edit");
    let hook_result = editor_hook_results(outcome).into_iter().find(|item| {
        item.get("event").and_then(Json::as_str) == Some(expected_event)
            && item.get("id").and_then(Json::as_str) == Some(scenario.case.hook_id)
    });
    let hook_result = match hook_result {
        Some(result) => result,
        None => {
            return Err(format!(
                "{} did not execute {}; {}",
                scenario.runtime, scenario.case.hook_id, details
            ))
        }
    };
    if scenario.case.expected_decision == "block" {
        let reason = json::js_string_or_empty(outcome.and_then(|o| o.get("reason")));
        let decision = outcome
            .and_then(|o| o.get("decision"))
            .and_then(Json::as_str);
        let code_is_zero = hook_result.get("code").and_then(Json::as_f64) == Some(0.0);
        let reason_matches = scenario
            .case
            .expected_reason
            .as_ref()
            .map(|pattern| pattern.test(&reason))
            .unwrap_or(false);
        if decision != Some("block") || code_is_zero || !reason_matches {
            return Err(format!(
                "{} did not block via {}; decision={}; hookCode={}; reason={}; {}",
                scenario.runtime,
                scenario.case.hook_id,
                json::js_string_opt(outcome.and_then(|o| o.get("decision"))),
                json::js_string_opt(hook_result.get("code")),
                reason,
                details
            ));
        }
    } else {
        let decision = outcome
            .and_then(|o| o.get("decision"))
            .and_then(Json::as_str);
        // `hookResult.code !== 0` — strict: an absent code fails the check.
        let code_is_zero = hook_result.get("code").and_then(Json::as_f64) == Some(0.0);
        if decision != Some("pass") || !code_is_zero {
            return Err(format!(
                "{} did not pass through {}; decision={}; hookCode={}; reason={}; {}",
                scenario.runtime,
                scenario.case.hook_id,
                json::js_string_opt(outcome.and_then(|o| o.get("decision"))),
                json::js_string_opt(hook_result.get("code")),
                json::js_string_or_empty(outcome.and_then(|o| o.get("reason"))),
                details
            ));
        }
    }
    Ok(hook_result)
}

