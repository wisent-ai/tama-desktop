//! Decision half of `tama-block-one-off-repairs` (registry hook
//! `block-one-off-repairs`).
//!
//! On 2026-09-19 Oko's one-off repair detector read the week's native harness
//! files: 243 commands that changed live machine state by hand instead of
//! through a product path, in 21 sessions. Three shapes had no gate at all:
//!
//!   * a running service cycled by hand — `launchctl kickstart|bootout|…`,
//!     `kill <pid>`, `pkill` — 12 times, when `stado service restart` and
//!     `stado service refresh-image` own that;
//!   * a grant or bearer written straight into a vault — `skarbiec grant
//!     ensure|issue`, `skarbiec token-mint` — past Stado, so nothing records
//!     it: the one on 2026-09-18 went to the replica the owner overwrites and
//!     was gone within the hour. `stado credentials token mint`, `stado
//!     service grant-sync` and `stado release catalog declare-publisher` are
//!     the product's route and pass;
//!   * a built binary copied over an installed one — `cp .build/debug/oko-cli
//!     ~/.stado/bin/oko-cli` nine times — when `oko-cli install` and
//!     `stado product update` own that.
//!
//! Each refusal names the product command, because a gate that refuses a
//! method without naming the outcome's route is worked around
//! (`~/agents/finishing.md`). The shape is [`crate::ports::block_repository_copies`]'s:
//! a pure [`evaluate`] over the payload returning the refusal, the binary under
//! `src/bin/block/` carrying it to the process boundary. The verbs and roots
//! it matches are data in `vocabulary.json` beside this file — what each
//! program accepts, not a classifier of what anyone meant.
//!
//! The command is read the way a shell reads it: cut at separators outside
//! quotes, quoted text blanked, wrappers stepped over
//! ([`crate::ports::shell_text`]), so `grep 'launchctl kickstart' notes.md`

mod refusals;
mod vocabulary;

use serde_json::Value;

use crate::ports::python_stdlib::shell_tokens;
use crate::ports::shell_text;

use refusals::*;
use vocabulary::{command_from, program_and_args};

/// Why this payload is a one-off repair, if it is one.
pub fn evaluate(payload: &Value) -> Option<String> {
    let command = command_from(payload);
    if command.trim().is_empty() {
        return None;
    }
    let acting = shell_text::effective_command(&command);
    shell_text::commands(&acting)
        .into_iter()
        .map(shell_tokens)
        .find_map(|tokens| {
            // A redirect has no program of its own: `printf … > ~/.stado/x`
            // runs `printf`, and where it lands is the repair.
            if let Some(refusal) = operator_state_refusal(&tokens) {
                return Some(refusal);
            }
            let (program, args) = program_and_args(&tokens)?;
            service_cycle_refusal(program, args)
                .or_else(|| credential_refusal(program, args))
                .or_else(|| binary_copy_refusal(program, args))
                .or_else(|| hook_file_refusal(program, args))
                .or_else(|| sql_refusal(program, &command))
                .or_else(|| adhoc_signature_refusal(program, args))
                .or_else(|| store_refusal(program, args))
                .or_else(|| setting_refusal(program, args))
                .or_else(|| scratch_refusal(program, args))
                .or_else(|| waiting_refusal(program, args))
                .or_else(|| search_refusal(program, args))
                .or_else(|| fleet_one_off_refusal(program, args))
                .or_else(|| toolchain_one_off_refusal(program, args))
                .or_else(|| build_one_off_refusal(program, args))
                .or_else(|| deadline_wrapper_refusal(&tokens))
        })
}
#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    fn payload(command: &str) -> Value {
        json!({ "tool_name": "Bash", "tool_input": { "command": command } })
    }

    #[test]
    fn a_service_cycled_by_hand_is_refused_and_a_read_of_launchd_is_not() {
        assert!(evaluate(&payload(
            "launchctl kickstart -k gui/501/ai.wisent.oko.transcript-index"
        ))
        .is_some());
        assert!(evaluate(&payload(
            "sudo launchctl bootout system/com.wisent.stado.release-agent"
        ))
        .is_some());
        assert!(evaluate(&payload("kill -TERM 40080 || true")).is_some());
        assert!(evaluate(&payload("pkill -f 'next dev'")).is_some());
        assert!(evaluate(&payload("launchctl list")).is_none());
        assert!(evaluate(&payload(
            "launchctl print gui/501/ai.wisent.oko.transcript-index"
        ))
        .is_none());
        assert!(evaluate(&payload("kill -0 4610 && echo alive")).is_none());
        assert!(evaluate(&payload("kill -l")).is_none());
    }

    /// A deadline typed in front of a command is the same guess the product
    /// refuses in written code, and the guard used to step over it silently
    /// while reading what the line ran.
    #[test]
    fn a_command_wrapped_in_a_deadline_is_refused_and_a_plain_run_is_not() {
        let refusal =
            evaluate(&payload("timeout 300 tama-cli hooks warm --json")).expect("refused");
        assert!(refusal.contains("guessed deadline"), "{refusal}");
        assert!(evaluate(&payload("gtimeout 90 stado host gates")).is_some());
        assert!(evaluate(&payload("/usr/bin/timeout 5 ./script.sh")).is_some());
        assert!(evaluate(&payload("tama-cli hooks warm --json")).is_none());
        assert!(evaluate(&payload("stado job watch 1234 --follow")).is_none());
        assert!(evaluate(&payload("echo 'timeout 30 something'")).is_none());
    }

    #[test]
    fn a_vault_write_past_stado_is_refused_and_the_product_route_is_not() {
        let refusal = evaluate(&payload(
            "skarbiec grant ensure stado-release-client jeden-desktop-release-publisher --field token --token-file ~/.stado/t",
        ))
        .expect("refused");
        assert!(refusal.contains("declare-publisher"), "{refusal}");
        assert!(evaluate(&payload(
            "skarbiec token-mint --consumer oko --capabilities read:x#token"
        ))
        .is_some());
        assert!(evaluate(&payload(
            "stado credentials token mint oko --host mini --capabilities call:brama#best"
        ))
        .is_none());
        assert!(evaluate(&payload(
            "skarbiec grant verify stado-release-client jeden-release-publisher --action read"
        ))
        .is_none());
        assert!(evaluate(&payload("skarbiec grant list --json | head")).is_none());
        assert!(evaluate(&payload("skarbiec grant issue --help | head -5")).is_none());
        assert!(evaluate(&payload("echo 'skarbiec grant ensure someone'")).is_none());
        assert!(evaluate(&payload(
            "git commit -F - <<'EOF'\nA skarbiec grant ensure run by hand\nEOF"
        ))
        .is_none());
    }

    #[test]
    fn a_binary_copied_over_an_installed_one_is_refused_and_a_copy_out_is_not() {
        let refusal =
            evaluate(&payload("cp .build/debug/oko-cli ~/.stado/bin/oko-cli")).expect("refused");
        assert!(refusal.contains("oko-cli install"), "{refusal}");
        assert!(evaluate(&payload(
            "cd tama && cp rust/target/release/tama-x rust/target/release/tama-y ~/.local/bin/"
        ))
        .is_some());
        assert!(evaluate(&payload(
            "ln -sf /Users/me/.stado/bin/skarbiec /Users/me/.local/bin/skarbiec"
        ))
        .is_some());
        assert!(evaluate(&payload("cp ~/.stado/bin/oko-cli .build/oko-cli-backup")).is_none());
        assert!(evaluate(&payload("cp .build/release/oko-cli dist/oko-cli")).is_none());
        assert!(evaluate(&payload("ls -la ~/.stado/bin/oko-cli")).is_none());
    }

    #[test]
    fn a_hook_file_changed_from_the_shell_is_refused_and_a_read_of_one_is_not() {
        let refusal = evaluate(&payload(
            "mv ~/.shared-hooks/block_browser_usage.sh ~/.shared-hooks/block_browser_usage.sh.paused",
        ))
        .expect("refused");
        assert!(refusal.contains("tama enforcement only"), "{refusal}");
        assert!(evaluate(&payload("rm ~/.shared-hooks/file_justifications.json")).is_some());
        assert!(evaluate(&payload(
            "chmod -x ~/.shared-hooks/block_inline_execution.sh"
        ))
        .is_some());
        // A path carrying spaces is quoted, and quoted text is blanked before
        // any of this runs so that a mention of a command is never a command
        // (`crate::ports::shell_text`). The runtime release lives under such a
        // path; the roots a shell names without quoting are what this reads.
        assert!(evaluate(&payload("install -m 755 build/x ~/.config/tama/hooks/x")).is_some());
        assert!(evaluate(&payload("rm -rf ~/.claude/hooks")).is_some());
        assert!(evaluate(&payload("ls -la ~/.shared-hooks")).is_none());
        assert!(evaluate(&payload(
            "cp ~/.shared-hooks/registry.json .build/registry.json"
        ))
        .is_none());
        assert!(evaluate(&payload("tama enforcement status")).is_none());
    }

    #[test]
    fn a_row_written_by_hand_is_refused_and_a_query_is_not() {
        let refusal = evaluate(&payload(
            "sqlite3 ~/.oko/index.sqlite \"UPDATE tasks SET status = 'done' WHERE ordinal = 5\"",
        ))
        .expect("refused");
        assert!(refusal.contains("oko-cli transcripts reindex"), "{refusal}");
        assert!(evaluate(&payload(
            "psql -h db.example.co -U postgres -c 'delete from sessions where id = 7'"
        ))
        .is_some());
        assert!(evaluate(&payload("sqlite3 x.db 'DROP TABLE sessions'")).is_some());
        assert!(evaluate(&payload(
            "sqlite3 ~/.oko/index.sqlite \"SELECT COUNT(*) FROM operator_messages\""
        ))
        .is_none());
        assert!(evaluate(&payload("sqlite3 x.db .schema")).is_none());
        assert!(evaluate(&payload("psql --help | head -3")).is_none());
        assert!(evaluate(&payload("echo 'update the docs' >> notes.md")).is_none());
        assert!(evaluate(&payload(
            "git commit -m 'refuse a raw update against the catalogue'"
        ))
        .is_none());
    }

    #[test]
    fn a_wrapper_and_a_pipeline_are_read_through() {
        assert!(evaluate(&payload(
            "cd ~ && timeout 60 skarbiec grant issue oko --capabilities read:x#token"
        ))
        .is_some());
        assert!(evaluate(&payload("echo ok | tee log.txt")).is_none());
        assert!(evaluate(&json!({ "tool_name": "Read", "tool_input": { "path": "x" } })).is_none());
    }

    /// A guessed interval observes nothing. This session ran `sleep 420`
    /// before reading one rollout and `sleep 240` before retrying a
    /// publication, and both reads could as easily have returned the old
    /// state. The commands that report an outcome pass.
    #[test]
    fn time_passed_by_hand_is_refused_and_a_read_of_the_outcome_is_not() {
        assert!(evaluate(&payload("sleep 420")).is_some());
        assert!(evaluate(&payload(
            "sleep 240; stado release doctor skarbiec --target charless-mac-mini"
        ))
        .is_some());
        assert!(evaluate(&payload("stado job watch 5e0f --follow")).is_none());
        assert!(evaluate(&payload("stado release status stado")).is_none());
        assert!(evaluate(&payload("stado space report lukasz-macbook")).is_none());
    }

    /// A tree searched from the shell answers whoever typed it, once. The
    /// operator's rule: a search is a one-off like the rest, and the answer
    /// belongs in the harness's own read or in a product command that any
    /// later reader can run again.
    #[test]
    fn a_shell_search_is_refused_and_a_product_read_is_not() {
        let refusal =
            evaluate(&payload("grep -rn 'brama:account:' src")).expect("a shell search is refused");
        assert!(refusal.contains("searches a tree once"), "{refusal}");
        assert!(evaluate(&payload("rg --files-with-matches account src")).is_some());
        assert!(evaluate(&payload("brama subscriptions --json")).is_none());
        assert!(evaluate(&payload("oko-cli transcripts tasks --open")).is_none());
        assert!(evaluate(&payload("grep --help")).is_none());
    }

    /// Two fleet commands repair one host once where a declaration owns the
    /// outcome: a sweep this session ran three times in one day, and a
    /// release built from whatever the shell's working copy held. Their
    /// refusals name the declaration and the recipe; the reads beside them
    /// pass.
    #[test]
    fn a_fleet_command_that_repairs_one_host_once_is_refused_with_its_declaration() {
        let sweep = evaluate(&payload(
            "stado space reclaim lukasz-macbook --apply --reason 'builds filled the disk'",
        ))
        .expect("a sweep by hand is refused");
        assert!(sweep.contains("stado space cleaners"), "{sweep}");
        assert!(sweep.contains("stado space watermark"), "{sweep}");

        let release = evaluate(&payload(
            "stado release submit --source . --commit 6c9f32cb --version 0.21.49",
        ))
        .expect("a release typed by hand is refused");
        assert!(release.contains("tama build record"), "{release}");

        assert!(evaluate(&payload("stado space report lukasz-macbook")).is_none());
        assert!(evaluate(&payload("stado release status stado --json")).is_none());
        assert!(evaluate(&payload("stado release submit --help")).is_none());
        assert!(evaluate(&payload("stado queue budget")).is_none());
    }
}
