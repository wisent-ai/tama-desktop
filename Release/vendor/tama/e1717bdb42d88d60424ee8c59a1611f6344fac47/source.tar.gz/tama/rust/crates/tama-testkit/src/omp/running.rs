//! Starting one OMP run: the repository it runs in, the command it is given,
//! and the small readings of a recorded entry the runners share.

use std::path::Path;

use crate::json::Json;
use crate::support::{self, RunOpts, RunResult};

pub(crate) fn init_repo(repo: &Path) -> Result<(), String> {
    std::fs::create_dir_all(repo).map_err(|e| support::io_error_message("mkdir", repo, &e))?;
    let init = support::run_in("git", &["init", "--quiet"], repo);
    if init.status != Some(0) {
        return Err(format!(
            "failed to initialize temp git repo: {}",
            init.stderr
        ));
    }
    Ok(())
}

pub(crate) fn run_omp(
    command: &[String],
    repo: &Path,
    env: Vec<(String, String)>,
) -> support::RunResult {
    support::run(
        &command[0],
        &command[1..],
        &RunOpts {
            cwd: Some(repo.to_path_buf()),
            env_overrides: env,
            max_buffer: Some(10_485_760),
            ..RunOpts::default()
        },
    )
}

pub(crate) fn opt_num(value: Option<i32>) -> Json {
    match value {
        Some(code) => Json::num_i64(code as i64),
        None => Json::Null,
    }
}

pub(crate) fn entry_argv0(entry: &Json) -> Option<&str> {
    entry
        .get("argv")
        .and_then(|argv| argv.at(0))
        .and_then(Json::as_str)
}

