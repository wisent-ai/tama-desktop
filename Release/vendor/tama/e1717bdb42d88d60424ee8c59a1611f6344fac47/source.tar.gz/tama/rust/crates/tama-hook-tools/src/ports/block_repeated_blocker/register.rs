//! Oko-s defect register as this gate reads it: where it lives, which defects
//! are still open, and the machine words each one carries - a service-s own
//! code rather than prose, because this gate is not a judge of paraphrase.

use std::collections::BTreeMap;
use std::path::PathBuf;

use serde_json::Value;

/// Where Oko keeps the register, and the variable that moves it.
pub(super) const REGISTER_ENV: &str = "OKO_DEFECT_REGISTER";
pub(super) const REGISTER_PATH: &str = "Library/Application Support/Oko/defects.json";
pub(super) const DEFECTS_KEY: &str = "defects";
pub(super) const FIXED_KEY: &str = "fixed_in";
pub(super) const ID_KEY: &str = "id";
pub(super) const TITLE_KEY: &str = "title";
pub(super) const FOUND_AT_KEY: &str = "found_at";
pub(super) const FOUND_IN_KEY: &str = "found_in";
/// How Oko prints a defect identifier: the first eight characters of its
/// UUID, lowercased. That is what a session is given when it records one and
/// what a later reader looks up, so that is what an answer has to carry.
pub(super) const SHORT_ID_LENGTH: usize = 8;
/// A machine word is long enough that it cannot collide with prose, and
/// carries an underscore or a hyphen — the shape of the things a service
/// prints and a person does not invent while writing a sentence: an error
/// code like `subscription_unavailable`, an item like
/// `brama-sub-wisent-app-codex-primary`, a host like `charless-mac-mini`. A
/// repeat that avoids every one of them has stopped naming what failed, and
/// this gate is not a judge of paraphrase.
pub(super) const MACHINE_WORD_LENGTH: usize = 12;

pub(super) fn register_path() -> Option<PathBuf> {
    if let Some(named) = std::env::var_os(REGISTER_ENV) {
        let named = PathBuf::from(named);
        if !named.as_os_str().is_empty() {
            return Some(named);
        }
    }
    let mut path = PathBuf::from(std::env::var_os("HOME")?);
    path.push(REGISTER_PATH);
    Some(path)
}

/// Every word of every string this record holds, whatever it is called. The
/// fields are not enumerated here on purpose: what the register carries is
/// the register's business, and a gate that named its own list of fields
/// would be deciding which part of a defect counts.
pub(super) fn words_of(record: &Value) -> Vec<String> {
    match record {
        Value::String(text) => text
            .split(|letter: char| {
                !(letter.is_ascii_alphanumeric() || letter == '_' || letter == '-')
            })
            .map(|word| word.trim_matches(['_', '-']).to_ascii_lowercase())
            .collect(),
        Value::Array(items) => items.iter().flat_map(words_of).collect(),
        Value::Object(fields) => fields
            .iter()
            .filter(|(name, _)| name.as_str() != ID_KEY)
            .flat_map(|(_, value)| words_of(value))
            .collect(),
        _ => Vec::new(),
    }
}

/// The machine words one defect carries: a service's own code, not prose.
pub(super) fn machine_words(defect: &Value) -> Vec<String> {
    let mut found: Vec<String> = Vec::new();
    for word in words_of(defect) {
        let machine = word.contains('_') || word.contains('-');
        if word.len() < MACHINE_WORD_LENGTH || !machine {
            continue;
        }
        if !found.contains(&word) {
            found.push(word);
        }
    }
    found
}

pub(super) fn short_id(defect: &Value) -> Option<String> {
    let id = defect.get(ID_KEY).and_then(Value::as_str)?;
    if id.len() < SHORT_ID_LENGTH {
        return None;
    }
    Some(id[..SHORT_ID_LENGTH].to_ascii_lowercase())
}

/// Every open defect, as machine word to the sentence a repeat would earn.
pub(super) fn open_defects(document: &Value) -> BTreeMap<String, String> {
    let mut known: BTreeMap<String, String> = BTreeMap::new();
    let Some(defects) = document.get(DEFECTS_KEY).and_then(Value::as_array) else {
        return known;
    };
    for defect in defects {
        let closed = defect
            .get(FIXED_KEY)
            .and_then(Value::as_str)
            .is_some_and(|revision| !revision.trim().is_empty());
        if closed {
            continue;
        }
        let Some(id) = short_id(defect) else {
            continue;
        };
        let title = defect
            .get(TITLE_KEY)
            .and_then(Value::as_str)
            .unwrap_or("a failure this register already holds");
        let found_at = defect
            .get(FOUND_AT_KEY)
            .and_then(Value::as_str)
            .unwrap_or("earlier");
        let found_in = defect
            .get(FOUND_IN_KEY)
            .and_then(Value::as_str)
            .unwrap_or("an earlier session");
        let said = format!(
            "defect {id} — \"{title}\" — recorded {found_at} by session {found_in}, still open"
        );
        for word in machine_words(defect) {
            known.entry(word).or_insert_with(|| said.clone());
        }
    }
    known
}

pub(super) fn document() -> Option<Value> {
    let text = std::fs::read_to_string(register_path()?).ok()?;
    serde_json::from_str(&text).ok()
}
