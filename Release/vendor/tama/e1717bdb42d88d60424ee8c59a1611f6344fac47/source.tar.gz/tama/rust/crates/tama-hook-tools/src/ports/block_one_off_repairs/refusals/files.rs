//! A file put where only a product should put one: an executable copied over
//! an installed one, a hook file changed from the shell, a redirect into the
//! operator-s own state, a scratch directory outside the build tree, and an
//! ad-hoc signature.

use super::super::vocabulary::*;

/// binary runs on the machine that signed it and on no other.
pub(crate) fn adhoc_signature_refusal(program: &str, args: &[String]) -> Option<String> {
    if program != CODESIGN || asks_for_help(args) {
        return None;
    }
    let at = args.iter().position(|arg| arg == ADHOC_SIGN_FLAG)?;
    if args.get(at + 1).map(String::as_str) != Some(ADHOC_IDENTITY) {
        return None;
    }
    Some(format!(
        "{BANNER}`codesign -s -` signs with the ad-hoc identity, which names nobody and travels \
         nowhere: the binary runs on the machine that signed it and is refused on every other. A \
         product's bytes are signed where they are released — `stado release prepare` and `stado \
         release submit` sign with the Developer ID and record the signature — and a local build \
         is installed with `stado release install-local` or the product's own installer."
    ))
}

/// A scratch directory made outside the repository that asked for it.
pub(crate) fn scratch_refusal(program: &str, args: &[String]) -> Option<String> {
    if !has(&VOCABULARY.scratch_programs, program) || asks_for_help(args) {
        return None;
    }
    Some(format!(
        "{BANNER}`{program}` puts work where the operator's own cleanup removes it, and the next \
         reader of that path finds nothing. Work that has to survive until it is read belongs in \
         the repository's ignored build directory (`.build`, `rust/target`) or under \
         `~/.wisent-output`, both of which are still there on the next run."
    ))
}

/// Time passed by hand instead of an outcome observed.
///
/// `sleep 420 && stado release doctor …` guesses how long a fleet takes and
/// proves nothing about what happened in those seconds: too short and the
/// read is of the old state, too long and the session sat idle. Every
/// outcome this fleet produces has a read that reports it, and where one is
/// A shell redirect that lands in the operator's own state.
pub(crate) fn operator_state_refusal(tokens: &[String]) -> Option<String> {
    let redirects = tokens.iter().any(|token| token.starts_with('>'));
    if !redirects {
        return None;
    }
    let landing = tokens
        .iter()
        .map(|token| token.trim_start_matches('>').to_string())
        .find(|token| {
            let relative = without_home(token);
            VOCABULARY
                .operator_state_roots
                .iter()
                .any(|root| relative.starts_with(root.as_str()))
        })?;
    Some(format!(
        "{BANNER}`> {landing}` writes the operator's own state from a shell: nothing records what \
         was put there, the product that reads it never agreed to it, and the next sync or \
         reinstall removes it. A bearer belongs to `stado credentials token mint <CONSUMER> \
         --host <VAULT HOST> --token-file-name <NAME>`, a fleet declaration to `stado registry \
         set --path <FIELD> --value <VALUE>`, and a product's own configuration to that product's \
         command."
    ))
}

/// A built executable copied over an installed one.
pub(crate) fn binary_copy_refusal(program: &str, args: &[String]) -> Option<String> {
    let is_copy = has(&VOCABULARY.copy_programs, program)
        || (program == LINK_PROGRAM && args.iter().any(|arg| arg.starts_with(SYMLINK_FLAG_PREFIX)));
    if !is_copy {
        return None;
    }
    let target = args
        .iter()
        .rev()
        .map(String::as_str)
        .find(|arg| !is_flag(arg))?;
    if !under_install_root(target) {
        return None;
    }
    Some(format!(
        "{BANNER}`{program} … {target}` replaces an installed program with a file nothing released, signed or recorded, and the units running the old image keep it. A product installs itself: `oko-cli install` for Oko, `stado product update <PRODUCT> --surface cli` for a catalogued product, `stado release install-local` for a delivered release, `stado host reconcile --apply` for a host behind its declaration."
    ))
}

/// A gate turned off by touching its own file.
///
/// Oko's catalogue holds the shape: on 2026-07-31 a session ran
/// `mv ~/.shared-hooks/block_browser_usage.sh ~/.shared-hooks/…​.paused`,
/// ran what the gate forbade, and moved the file back. The write gate sees
/// write and edit payloads, not a shell rename, so nothing refused it. What a
/// machine runs is decided by the selection and the installed release, not by
/// whether a file is still where the registry points.
pub(crate) fn hook_file_refusal(program: &str, args: &[String]) -> Option<String> {
    let words = &*VOCABULARY;
    let plain = || args.iter().map(String::as_str).filter(|arg| !is_flag(arg));
    // A copy or a rename is judged by where it lands: reading a registry out
    // of a hook root into a build directory is a read. A removal or a mode
    // change is judged by every path it names.
    let touched = if has(&words.copy_programs, program) || program == LINK_PROGRAM {
        plain().next_back().filter(|arg| under_hook_root(arg))?
    } else if has(&words.hook_write_programs, program) {
        plain().find(|arg| under_hook_root(arg))?
    } else {
        return None;
    };
    Some(format!(
        "{BANNER}`{program} … {touched}` changes a hook's own file, which turns a gate off for \
         every session on this machine until somebody notices. What this machine runs is chosen \
         with `tama enforcement only <hook-id>…` and `tama enforcement status`, a hook's source is \
         changed through `tama adaptive repair <hook-id> --patch-file <path>` and \
         `DEVICE_HOOK_EDIT_APPROVED=1 tama adaptive apply <proposal-dir>`, and the installed \
         release is rebuilt with `DEVICE_HOOK_EDIT_APPROVED=1 tama hooks release`."
    ))
}
