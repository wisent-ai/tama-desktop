//! The watcher: a real editor watch run, the log it writes, and the coverage
//! keys that log proves.

use std::path::Path;

use crate::json::{self, Json};
use crate::orchestration::Ctx;
use crate::scenarios::{EditorScenario, EDITOR_WATCHER};
use crate::support::{self, RunOpts};

use super::outcome::*;

/// already carries `logPath` (`{ ...matched, logPath }`).
fn editor_watch_covered_keys(
    parsed: Option<&Json>,
    matched: Option<&Json>,
    runtime: &str,
    scenario: &EditorScenario,
    ctx: &Ctx,
) -> Result<Vec<String>, String> {
    let parsed_keys = match parsed {
        Some(value) => support::covered_keys_from_editor_outcomes(Some(value), runtime),
        None => Vec::new(),
    };
    if !parsed_keys.is_empty() {
        return Ok(parsed_keys);
    }
    let stdout = json::js_string_or_empty(
        matched
            .and_then(|m| m.get("data"))
            .and_then(|d| d.get("stdout")),
    );
    let code_is_zero = matched
        .and_then(|m| m.get("data"))
        .and_then(|d| d.get("code"))
        .and_then(Json::as_f64)
        == Some(0.0);
    if scenario.case.event == Some("pre_tool_use:notebook")
        && code_is_zero
        && stdout.contains("\"event\": \"pre_tool_use:notebook\"")
        && stdout.contains(scenario.case.hook_id)
    {
        return crate::codex::required_keys_for(&ctx.root, runtime, Some("pre_tool_use:notebook"));
    }
    let log_path = matched
        .and_then(|m| m.get("logPath"))
        .and_then(Json::as_str)
        .unwrap_or("");
    Ok(support::covered_keys_from_editor_watch_log(
        Path::new(log_path),
        runtime,
    ))
}

/// JS `assertEditorWatchScenarioOutcome(parsed, scenario, targetPath, matched, details)`.
/// `matched` already carries `logPath`.
fn assert_editor_watch_scenario_outcome(
    parsed: Option<&Json>,
    scenario: &EditorScenario,
    target_path: &str,
    matched: Option<&Json>,
    details: &str,
) -> Result<Json, String> {
    if parsed.is_some() {
        return assert_editor_scenario_outcome(parsed, scenario, target_path, details);
    }
    let stdout = json::js_string_or_empty(
        matched
            .and_then(|m| m.get("data"))
            .and_then(|d| d.get("stdout")),
    );
    let code = matched
        .and_then(|m| m.get("data"))
        .and_then(|d| d.get("code"));
    let event = scenario.case.event.unwrap_or("pre_tool_use:edit");
    // Block branch: `matched?.data?.code !== 0` (absent code passes).
    if scenario.case.expected_decision == "block"
        && code.and_then(Json::as_f64) != Some(0.0)
        && stdout.contains(scenario.case.hook_id)
        && scenario
            .case
            .expected_reason
            .as_ref()
            .map(|pattern| pattern.test(&stdout))
            .unwrap_or(false)
    {
        let mut hook_result = Json::obj(vec![
            ("id".to_string(), Json::str(scenario.case.hook_id)),
            ("event".to_string(), Json::str(event)),
        ]);
        if let Some(code) = code {
            hook_result.set("code", code.clone());
        }
        return Ok(hook_result);
    }
    if scenario.case.expected_decision == "pass"
        && code.and_then(Json::as_f64) == Some(0.0)
        && stdout.contains("\"event\": \"pre_tool_use:notebook\"")
        && stdout.contains(scenario.case.hook_id)
    {
        return Ok(Json::obj(vec![
            ("id".to_string(), Json::str(scenario.case.hook_id)),
            ("event".to_string(), Json::str(event)),
            ("code".to_string(), Json::num_i64(0)),
        ]));
    }
    Err(format!(
        "{} did not emit parseable {} result; code={}; stdoutTail={}; {}",
        scenario.runtime,
        scenario.case.hook_id,
        json::js_string_opt(code),
        support::tail(&stdout),
        details
    ))
}

/// JS `runEditorWatchScenario(scenario)`.
pub fn run_editor_watch_scenario(scenario: &EditorScenario, ctx: &Ctx) -> Result<Json, String> {
    let tmp = if scenario.case.system_tmp {
        support::mkdtemp(&support::tmpdir().join("tama-editor-watch-"))?
    } else {
        support::make_live_runtime_temp("editor-watch-")?
    };
    let log_path = tmp.join("editor-hooks.log");
    let pid_path = tmp.join("editor-hooks.pid");
    let mut child = support::spawn_ignored(
        "node",
        &[
            EDITOR_WATCHER.to_string(),
            tmp.to_string_lossy().into_owned(),
        ],
        &tmp,
        &[
            (
                "WISENT_EDITOR_HOOK_REPORT_ONLY".to_string(),
                "0".to_string(),
            ),
            (
                "WISENT_EDITOR_HOOK_LOG".to_string(),
                log_path.to_string_lossy().into_owned(),
            ),
            (
                "WISENT_EDITOR_HOOK_PID".to_string(),
                pid_path.to_string_lossy().into_owned(),
            ),
            (
                "WISENT_EDITOR_HOOK_DEBOUNCE_MS".to_string(),
                "250".to_string(),
            ),
        ],
    )?;
    let outcome = run_editor_watch_inner(&tmp, &log_path, scenario, ctx);
    support::kill_sigterm(&mut child);
    // `spawnSync('sleep', ['0.5'])`
    std::thread::sleep(Duration::from_millis(500));
    if !ctx.keep_artifacts {
        support::rm_force(&tmp);
    }
    outcome
}

fn run_editor_watch_inner(
    tmp: &Path,
    log_path: &Path,
    scenario: &EditorScenario,
    ctx: &Ctx,
) -> Result<Json, String> {
    let ready = wait_until(
        || {
            support::parse_json_lines(log_path).iter().any(|line| {
                line.get("message").and_then(Json::as_str) == Some("ready")
                    && line
                        .get("data")
                        .and_then(|d| d.get("watchers"))
                        .and_then(Json::as_f64)
                        .map(|n| n >= 1.0)
                        .unwrap_or(false)
            })
        },
        5_000,
    );
    if !ready {
        return Err("editor watcher did not report ready".to_string());
    }
    let target_path = editor_scenario_target(tmp, &scenario.case)?;
    let mut matched: Option<Json> = None;
    let found = wait_until(
        || {
            matched = support::parse_json_lines(log_path)
                .into_iter()
                .find(|line| {
                    if line.get("message").and_then(Json::as_str) != Some("guard-result") {
                        return false;
                    }
                    line.get("data")
                        .and_then(|d| d.get("files"))
                        .and_then(Json::as_array)
                        .map(|files| {
                            files
                                .iter()
                                .any(|file| file.as_str() == Some(target_path.as_str()))
                        })
                        .unwrap_or(false)
                });
            matched.is_some()
        },
        20_000,
    );
    if !found {
        return Err(format!(
            "editor watcher did not log guard result for {}: {}",
            target_path,
            support::tail_n(&support::read(log_path)?, 2000)
        ));
    }
    // `{ ...matched, logPath }`
    let mut matched = matched.unwrap_or(Json::Null);
    matched.set(
        "logPath",
        Json::str(log_path.to_string_lossy().into_owned()),
    );
    let stdout_text = json::js_string_or_empty(matched.get("data").and_then(|d| d.get("stdout")));
    let parse_source = if stdout_text.is_empty() {
        "{}".to_string()
    } else {
        stdout_text
    };
    // `let parsed = null; try { parsed = JSON.parse(matched.data?.stdout || '{}') } catch {}`
    let parsed = json::parse(&parse_source).ok();
    let details = format!(
        "watchLogTail={}",
        support::tail_n(&support::read(log_path)?, 2000)
    );
    let hook_result = assert_editor_watch_scenario_outcome(
        parsed.as_ref(),
        scenario,
        &target_path,
        Some(&matched),
        &details,
    )?;
    let mut covered = editor_watch_covered_keys(
        parsed.as_ref(),
        Some(&matched),
        scenario.runtime,
        scenario,
        ctx,
    )?;
    covered.push(scenario.coverage_key.clone());
    let covered = support::unique(covered);
    let expected_behavior = scenario
        .case
        .expected_watch_behavior
        .unwrap_or(scenario.case.expected_behavior);
    let mut entries = vec![
        ("ok".to_string(), Json::Bool(true)),
        ("runtime".to_string(), Json::str(scenario.runtime)),
        ("hook".to_string(), Json::str(scenario.case.hook_id)),
        (
            "coverageKey".to_string(),
            Json::str(scenario.coverage_key.clone()),
        ),
        (
            "coveredKeys".to_string(),
            Json::arr(covered.into_iter().map(Json::Str).collect()),
        ),
        (
            "command".to_string(),
            Json::arr(vec![
                Json::str("node"),
                Json::str(EDITOR_WATCHER),
                Json::str(tmp.to_string_lossy().into_owned()),
            ]),
        ),
        ("targetPath".to_string(), Json::str(target_path)),
        (
            "targetRelativePath".to_string(),
            Json::str(scenario.case.rel_path.clone()),
        ),
        (
            "targetContent".to_string(),
            Json::str(scenario.case.content.clone()),
        ),
        ("expectedBehavior".to_string(), Json::str(expected_behavior)),
        (
            "logPath".to_string(),
            Json::str(log_path.to_string_lossy().into_owned()),
        ),
        (
            "blocked".to_string(),
            Json::Bool(scenario.case.expected_decision == "block"),
        ),
        ("preemptive".to_string(), Json::Bool(false)),
    ];
    if let Some(code) = hook_result.get("code") {
        entries.push(("hookExitCode".to_string(), code.clone()));
    }
    entries.push(("payloadCaptured".to_string(), Json::Bool(true)));
    Ok(Json::obj(entries))
}
