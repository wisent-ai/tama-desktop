//! The save guard: a real editor save driven through the guard, and what the
//! guard did about it.

use std::path::Path;

use crate::json::{self, Json};
use crate::orchestration::Ctx;
use crate::scenarios::{EditorScenario, EDITOR_SAVE_GUARD};
use crate::support::{self, RunOpts};

use super::outcome::*;

/// JS `runEditorSaveGuardScenario(scenario)`.
pub fn run_editor_save_guard_scenario(
    scenario: &EditorScenario,
    ctx: &Ctx,
) -> Result<Json, String> {
    let tmp = if scenario.case.system_tmp {
        support::mkdtemp(&support::tmpdir().join("tama-editor-save-"))?
    } else {
        support::make_live_runtime_temp("editor-save-")?
    };
    let outcome = run_editor_save_guard_inner(&tmp, scenario, ctx);
    if !ctx.keep_artifacts {
        support::rm_force(&tmp);
    }
    outcome
}

fn run_editor_save_guard_inner(
    tmp: &Path,
    scenario: &EditorScenario,
    ctx: &Ctx,
) -> Result<Json, String> {
    let _ = ctx;
    let target_path = editor_scenario_target(tmp, &scenario.case)?;
    let before = support::read(Path::new(&target_path))?;
    let args = vec![EDITOR_SAVE_GUARD.to_string(), target_path.clone()];
    let result = support::run(
        "node",
        &args,
        &RunOpts {
            cwd: Some(tmp.to_path_buf()),
            ..RunOpts::default()
        },
    );
    let after = support::read(Path::new(&target_path))?;
    // `let parsed = null; try { parsed = JSON.parse(result.stdout) } catch {}`
    let parsed = json::parse(&result.stdout).ok();
    let details = format!(
        "status={}; stdout={}; stderr={}",
        match result.status {
            Some(code) => code.to_string(),
            None => "null".to_string(),
        },
        support::tail(&result.stdout),
        support::tail(&result.stderr)
    );
    let hook_result =
        assert_editor_scenario_outcome(parsed.as_ref(), scenario, &target_path, &details)?;
    if before != after {
        return Err("editor-save-guard changed target file".to_string());
    }
    let mut entries = vec![
        ("ok".to_string(), Json::Bool(true)),
        ("runtime".to_string(), Json::str("editor-save-guard")),
        ("hook".to_string(), Json::str(scenario.case.hook_id)),
        (
            "coverageKey".to_string(),
            Json::str(scenario.coverage_key.clone()),
        ),
        (
            "coveredKeys".to_string(),
            Json::arr(
                support::covered_keys_from_editor_outcomes(parsed.as_ref(), "editor-save-guard")
                    .into_iter()
                    .map(Json::Str)
                    .collect(),
            ),
        ),
        (
            "command".to_string(),
            Json::arr(vec![
                Json::str("node"),
                Json::str(EDITOR_SAVE_GUARD),
                Json::str(target_path.clone()),
            ]),
        ),
        ("targetPath".to_string(), Json::str(target_path)),
        (
            "targetRelativePath".to_string(),
            Json::str(scenario.case.rel_path.clone()),
        ),
        (
            "targetContent".to_string(),
            Json::str(scenario.case.content.clone()),
        ),
        (
            "expectedBehavior".to_string(),
            Json::str(scenario.case.expected_behavior),
        ),
        (
            "targetBeforeEqualsAfter".to_string(),
            Json::Bool(before == after),
        ),
        (
            "blocked".to_string(),
            Json::Bool(scenario.case.expected_decision == "block"),
        ),
    ];
    if let Some(code) = hook_result.get("code") {
        entries.push(("hookExitCode".to_string(), code.clone()));
    }
    entries.push(("payloadCaptured".to_string(), Json::Bool(true)));
    Ok(Json::obj(entries))
}

/// JS `editorWatchCoveredKeys(parsed, matched, runtime, scenario)`. `matched`
