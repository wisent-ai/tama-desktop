//! Writing the result somewhere else: the flag that leaves the input registry
//! untouched and puts the reconciled document in its own file.

use std::fs;

use crate::support::{fixture, init_repo, read_registry, run, write_registry};


#[test]
fn out_flag_writes_to_separate_file_leaving_input_untouched() {
    let root = fixture("out-flag");
    init_repo(
        &root,
        &["rust/crates/tama-hook-tools/src/bin/block/repo/block_repository_copies.rs"],
    );
    let registry = root.join("shared-hooks/registry.json");
    fs::create_dir_all(registry.parent().unwrap()).expect("create shared-hooks");
    write_registry(
        &registry,
        &[("block-repo", "rust/crates/old/block_repository_copies.rs")],
    );
    let output = root.join("shared-hooks/registry-new.json");

    let before = read_registry(&registry);
    let (code, _, _) = run(&[
        "--out",
        output.to_str().unwrap(),
        registry.to_str().unwrap(),
    ]);
    assert_eq!(code, 0, "rewrite with --out should exit zero");

    let after_input = read_registry(&registry);
    assert_eq!(
        before, after_input,
        "input file should not be modified with --out"
    );

    let output_content = read_registry(&output);
    assert!(output_content.contains("block/repo/block_repository_copies.rs"));
    assert!(!output_content.contains("crates/old"));

    fs::remove_dir_all(&root).expect("cleanup");
}
