//! What a run came to: a scenario blocked by a guard, a runtime that was not
//! available at all, and the coverage keys a recorded session proves.

use std::path::Path;

use crate::git_codex::{self, Probe};
use crate::json::Json;
use crate::orchestration::Ctx;
use crate::scenarios::CodexScenario;

/// JS `codexBlockResult(scenario, probe)`.
pub(crate) fn codex_block_result(scenario: &CodexScenario, probe: &Probe, ctx: &Ctx) -> Result<Json, String> {
    let router_covered_keys =
        git_codex::covered_keys_from_codex_router_coverage(&ctx.root, &probe.output)?;
    if probe.via_model_router
        && !router_covered_keys
            .iter()
            .any(|k| k == scenario.coverage_key)
    {
        return Err(format!(
            "model-router Codex hook coverage log missing {}",
            scenario.coverage_key
        ));
    }
    Ok(Json::obj(vec![
        ("ok".to_string(), Json::Bool(true)),
        ("runtime".to_string(), Json::str("codex")),
        (
            "hook".to_string(),
            Json::str("block-hook-config-edits-without-consent"),
        ),
        (
            "coveredKeys".to_string(),
            Json::arr(vec![Json::str(scenario.coverage_key)]),
        ),
        ("coverageKey".to_string(), Json::str(scenario.coverage_key)),
        (
            "command".to_string(),
            Json::arr(probe.command.iter().cloned().map(Json::Str).collect()),
        ),
        (
            "forbiddenAction".to_string(),
            Json::str("git config core.hooksPath .githooks"),
        ),
        (
            "runtimeExitStatus".to_string(),
            match probe.exit_status {
                Some(code) => Json::num_i64(code as i64),
                None => Json::Null,
            },
        ),
        (
            "targetBeforeEqualsAfter".to_string(),
            Json::Bool(!probe.target_changed),
        ),
        ("blocked".to_string(), Json::Bool(true)),
        ("payloadCaptured".to_string(), Json::Bool(false)),
    ]))
}

/// JS `codexUnavailableResult(scenario, probes)`.
pub(crate) fn codex_unavailable_result(
    scenario: &CodexScenario,
    probes: &[(&str, &Probe)],
    ctx: &Ctx,
) -> Result<Json, String> {
    let parts: Vec<String> = probes
        .iter()
        .map(|(label, probe)| {
            format!(
                "{label}: {}",
                git_codex::codex_probe_unavailable_reason(probe)
            )
        })
        .collect();
    let blocker = format!(
        "Codex runtime could not dispatch hooks: {}",
        parts.join("; ")
    );
    let _ = scenario;
    let probe_json = probes
        .iter()
        .map(|(_, probe)| probe.to_json_without_output())
        .collect();
    let affected = required_keys_for(&ctx.root, "codex", None)?;
    Ok(git_codex::unavailable_runtime(
        "codex", &blocker, probe_json, affected,
    ))
}

/// JS `requiredKeysFor(runtime, event = null)`.
pub fn required_keys_for(
    root: &Path,
    runtime: &str,
    event: Option<&str>,
) -> Result<Vec<String>, String> {
    let required = tama_core::runtime::build_required_coverage(root).map_err(|e| e.to_string())?;
    Ok(required
        .iter()
        .filter(|item| {
            item.runtime() == runtime && (event.is_none() || Some(item.event()) == event)
        })
        .map(|item| item.coverage_key().to_string())
        .collect())
}

/// JS `claudeEventsByHookName` (lookup only; the JS object's insertion order
/// does not affect the result because `Object.entries(counts)` drives order).
pub fn claude_events_by_hook_name(hook_name: &str) -> &'static [&'static str] {
    match hook_name {
        "UserPromptSubmit" => &["user_prompt_submit"],
        "PostToolUse:Bash" => &["post_tool_use:bash"],
        "PreToolUse:Bash" => &["pre_tool_use:bash"],
        "PreToolUse:Read" => &["pre_tool_use:read"],
        "PreToolUse:Edit" => &["pre_tool_use:edit"],
        "PreToolUse:Write" => &["pre_tool_use:edit", "pre_tool_use:write"],
        "PreToolUse:MultiEdit" => &["pre_tool_use:multiedit"],
        "PreToolUse:NotebookEdit" => &["pre_tool_use:notebook"],
        "PreToolUse:Monitor" => &["pre_tool_use:wait"],
        "PreToolUse:ScheduleWakeup" => &["pre_tool_use:wait"],
        "Stop" => &["stop"],
        "SessionStart" => &["session_start:compact"],
        _ => &[],
    }
}

/// JS `countSuccessfulClaudeHookResponses(entries)` — insertion-ordered.
pub(crate) fn count_successful_claude_hook_responses(entries: &[Json]) -> Vec<(String, u64)> {
    let mut counts: Vec<(String, u64)> = Vec::new();
    for entry in entries {
        if entry.get("type").and_then(Json::as_str) != Some("system")
            || entry.get("subtype").and_then(Json::as_str) != Some("hook_response")
        {
            continue;
        }
        // `entry.exit_code !== 0 || entry.outcome !== 'success'`
        if entry.get("exit_code").and_then(Json::as_f64) != Some(0.0)
            || entry.get("outcome").and_then(Json::as_str) != Some("success")
        {
            continue;
        }
        let hook_name = crate::json::js_string_opt(entry.get("hook_name"));
        if let Some(existing) = counts.iter_mut().find(|(k, _)| *k == hook_name) {
            existing.1 += 1;
        } else {
            counts.push((hook_name, 1));
        }
    }
    counts
}

/// JS `coveredKeysFromClaudeEntries(entries)`.
pub fn covered_keys_from_claude_entries(
    root: &Path,
    entries: &[Json],
) -> Result<Vec<String>, String> {
    let counts = count_successful_claude_hook_responses(entries);
    let mut keys = Vec::new();
    for (hook_name, count) in counts {
        for event in claude_events_by_hook_name(&hook_name) {
            let required = required_keys_for(root, "claude", Some(event))?;
            if count as usize >= required.len() {
                keys.extend(required);
            }
        }
    }
    Ok(support::unique(keys))
}

