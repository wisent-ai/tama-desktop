//! Driving the real guard binary: one command in, its refusal or its silence
//! out, read from the process rather than from the library it was built from.

//! `tama-block-one-off-repairs`, driven as the real binary with a real
//! payload on stdin, the way the Tama engine drives it.
//!
//! Three repairs by hand are refused — a running service cycled, a grant or
//! bearer minted from the shell, a built binary copied over an installed one
//! — and each case holds one command to its exit status and, when refused,
//! to the route the refusal names, so a later rewrite cannot widen the gate
//! onto `launchctl list` or `skarbiec grant verify`, or narrow it off the
//! three repairs the week of 2026-09-12 counted.

use std::io::Write as _;
use std::process::{Command, Output, Stdio};

use serde_json::json;

const EXIT_PASS: i32 = false as i32;
const EXIT_REFUSED: i32 = true as i32 + true as i32;

const GUARD: &str = env!("CARGO_BIN_EXE_tama-block-one-off-repairs");
const BANNER: &str = "BLOCKED: one-off repair by hand. ";

pub fn run(command: &str) -> Output {
    let payload = json!({ "tool_name": "Bash", "tool_input": { "command": command } });
    let mut child = Command::new(GUARD)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .unwrap_or_else(|error| panic!("spawn the guard: {error}"));
    child
        .stdin
        .as_mut()
        .expect("guard stdin")
        .write_all(payload.to_string().as_bytes())
        .expect("write payload");
    child.wait_with_output().expect("guard output")
}

/// Refused, and the refusal names the product route.
pub fn refuses(command: &str, route: &str) {
    let output = run(command);
    let stderr = String::from_utf8_lossy(&output.stderr).into_owned();
    assert_eq!(
        output.status.code(),
        Some(EXIT_REFUSED),
        "{command} should be refused; stderr: {stderr}"
    );
    assert!(stderr.starts_with(BANNER), "banner for {command}: {stderr}");
    assert!(
        stderr.contains(route),
        "{command} must name `{route}`: {stderr}"
    );
}

pub fn passes(command: &str) {
    let output = run(command);
    let stderr = String::from_utf8_lossy(&output.stderr).into_owned();
    assert_eq!(
        output.status.code(),
        Some(EXIT_PASS),
        "{command} should pass; stderr: {stderr}"
    );
    assert!(stderr.is_empty(), "a passing call prints nothing: {stderr}");
}
