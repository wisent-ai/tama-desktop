//! The notebook case, the notebook a run is given to edit, and the two editor
//! hook paths on this device.

use crate::json::Json;

use super::super::super::types::{EditorCase, Pattern, TEMPORARY_PATH_BLOCK_HOOK_ID};

/// JS `editorSaveGuard` / `editorWatcher` — absolute device paths, verbatim.
pub const EDITOR_SAVE_GUARD: &str = "/Users/lukaszbartoszcze/.shared-hooks/editor-save-guard.mjs";
pub const EDITOR_WATCHER: &str = "/Users/lukaszbartoszcze/.shared-hooks/editor-watch.mjs";
/// JS `notebookFixtureContent()`.
pub fn notebook_fixture_content() -> String {
    let notebook = Json::obj(vec![
        (
            "cells".to_string(),
            Json::arr(vec![Json::obj(vec![
                ("cell_type".to_string(), Json::str("markdown")),
                ("metadata".to_string(), Json::obj(vec![])),
                (
                    "source".to_string(),
                    Json::arr(vec![Json::str("live notebook coverage\n")]),
                ),
            ])]),
        ),
        ("metadata".to_string(), Json::obj(vec![])),
        ("nbformat".to_string(), Json::num_i64(4)),
        ("nbformat_minor".to_string(), Json::num_i64(5)),
    ]);
    format!("{}\n", notebook.to_pretty2())
}

pub fn editor_notebook_cases() -> Vec<EditorCase> {
    vec![EditorCase {
        id: "safe-notebook-pass",
        hook_id: TEMPORARY_PATH_BLOCK_HOOK_ID,
        event: Some("pre_tool_use:notebook"),
        rel_path: "notebooks/coverage.ipynb".to_string(),
        content: notebook_fixture_content(),
        expected_decision: "pass",
        expected_reason: None,
        expected_behavior: "passes safe notebook save while notebook-specific hooks run",
        expected_watch_behavior: None,
        system_tmp: false,
    }]
}

