//! Running things the way the JavaScript harness ran them: a temporary
//! directory named like `fs.mkdtemp`, a spawn that captures what the child
//! wrote, and an environment that is put back exactly as it was found.
#![allow(dead_code)]

use std::env;
use std::ffi::{OsStr, OsString};
use std::fs;
use std::io::{Read, Write};
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};

// ---------------------------------------------------------------------------
// `fs.mkdtemp(prefix)`: append six random [A-Za-z0-9] characters, create dir.
// ---------------------------------------------------------------------------

fn random_bytes<const N: usize>() -> [u8; N] {
    let mut buf = [0u8; N];
    if let Ok(mut f) = fs::File::open("/dev/urandom") {
        if f.read_exact(&mut buf).is_ok() {
            return buf;
        }
    }
    let nanos = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_nanos())
        .unwrap_or(0);
    for (i, b) in buf.iter_mut().enumerate() {
        *b = (nanos >> ((i % 16) * 8)) as u8;
    }
    buf
}

/// `await mkdtemp(prefix)` — `prefix` already ends with the `-` separator,
/// exactly like `mkdtemp(join(tmpdir(), 'tama-...-'))` in the JS tests.
pub fn mkdtemp(prefix: &Path) -> Result<PathBuf, String> {
    const ALNUM: &[u8] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    for _ in 0..100 {
        let bytes = random_bytes::<6>();
        let suffix: String = bytes
            .iter()
            .map(|b| ALNUM[(*b as usize) % ALNUM.len()] as char)
            .collect();
        let mut candidate = prefix.as_os_str().to_owned();
        candidate.push(&suffix);
        let candidate = PathBuf::from(candidate);
        match fs::create_dir(&candidate) {
            Ok(()) => return Ok(candidate),
            Err(e) if e.kind() == std::io::ErrorKind::AlreadyExists => continue,
            Err(e) => return Err(format!("mkdtemp {}: {e}", candidate.display())),
        }
    }
    Err(format!("mkdtemp {}: no unique suffix", prefix.display()))
}

// ---------------------------------------------------------------------------
// `spawnSync`: capture status/stdout/stderr with optional stdin input and
// environment overrides on top of the inherited environment. Undefined env
/// values in a Node `env` object are dropped from the child environment;
/// callers express that via `env_remove`.
// ---------------------------------------------------------------------------

pub struct SpawnOutput {
    /// `null` when the child was terminated by a signal (`result.status`).
    pub status: Option<i32>,
    pub stdout: String,
    pub stderr: String,
}

pub fn spawn_sync(
    program: &str,
    args: &[&str],
    input: Option<&str>,
    env_set: &[(String, String)],
    env_remove: &[&str],
) -> Result<SpawnOutput, String> {
    let mut command = Command::new(program);
    command.args(args);
    command.stdin(if input.is_some() {
        Stdio::piped()
    } else {
        Stdio::null()
    });
    command.stdout(Stdio::piped());
    command.stderr(Stdio::piped());
    for (key, value) in env_set {
        command.env(key, value);
    }
    for key in env_remove {
        command.env_remove(key);
    }
    let mut child = command
        .spawn()
        .map_err(|e| format!("spawn {program}: {e}"))?;
    if let Some(text) = input {
        let mut stdin = child.stdin.take().unwrap_or_else(|| unreachable!());
        stdin
            .write_all(text.as_bytes())
            .map_err(|e| format!("spawn {program} stdin: {e}"))?;
        drop(stdin);
    }
    let output = child
        .wait_with_output()
        .map_err(|e| format!("spawn {program}: {e}"))?;
    Ok(SpawnOutput {
        status: output.status.code(),
        stdout: String::from_utf8_lossy(&output.stdout).into_owned(),
        stderr: String::from_utf8_lossy(&output.stderr).into_owned(),
    })
}

// ---------------------------------------------------------------------------
// Environment snapshot/restore — `originalEnv` / `restoreEnv()` from
// `src/tests/session-overrides.mjs`.
// ---------------------------------------------------------------------------

pub struct EnvGuard {
    saved: Vec<(String, Option<OsString>)>,
}

impl EnvGuard {
    pub fn capture(keys: &[&str]) -> Self {
        Self {
            saved: keys
                .iter()
                .map(|key| (key.to_string(), env::var_os(key)))
                .collect(),
        }
    }

    pub fn get(&self, key: &str) -> Option<&OsStr> {
        self.saved
            .iter()
            .find(|(k, _)| k == key)
            .and_then(|(_, v)| v.as_deref())
    }

    pub fn restore(&self) {
        for (key, value) in &self.saved {
            match value {
                Some(value) => env::set_var(key, value),
                None => env::remove_var(key),
            }
        }
    }
}
