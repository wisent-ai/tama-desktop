//! The Claude scenarios: what each one prepares, which recorded call it
//! recognises, and what it reads back from the repository afterwards.

use std::path::Path;

use crate::json::{self, Json};
use crate::support;

use super::super::types::{ClaudeScenario, Pattern, TEMPORARY_PATH_BLOCK_HOOK_ID};


fn claude_prepare_read(repo: &Path) -> Result<(), String> {
    support::write_file(&repo.join("notes.txt"), "read me\n")
}

fn claude_prepare_write(repo: &Path) -> Result<(), String> {
    support::write_file(&repo.join("notes.txt"), "before write\n")
}

fn claude_prepare_edit(repo: &Path) -> Result<(), String> {
    support::write_file(&repo.join("notes.txt"), "before\n")
}

fn claude_prepare_notebook(repo: &Path) -> Result<(), String> {
    let notebook = Json::obj(vec![
        (
            "cells".to_string(),
            Json::arr(vec![Json::obj(vec![
                ("cell_type".to_string(), Json::str("markdown")),
                ("metadata".to_string(), Json::obj(vec![])),
                (
                    "source".to_string(),
                    Json::arr(vec![Json::str("before notebook\n")]),
                ),
            ])]),
        ),
        ("metadata".to_string(), Json::obj(vec![])),
        ("nbformat".to_string(), Json::num_i64(4)),
        ("nbformat_minor".to_string(), Json::num_i64(5)),
    ]);
    support::write_file(&repo.join("coverage.ipynb"), &notebook.to_pretty2())
}

/// `String(input.file_path || input.path || '').endsWith('notes.txt')`.
fn claude_match_notes_txt(input: &Json) -> bool {
    json::js_string_or_empty(json::js_or2(input.get("file_path"), input.get("path")))
        .ends_with("notes.txt")
}

/// `String(input.file_path || input.path || input.input || '').includes('notes.txt')`.
fn claude_match_notes_txt_loose(input: &Json) -> bool {
    json::js_string_or_empty(json::js_or3(
        input.get("file_path"),
        input.get("path"),
        input.get("input"),
    ))
    .contains("notes.txt")
}

/// `String(input.notebook_path || input.file_path || input.path || '').endsWith('coverage.ipynb')`.
fn claude_match_notebook(input: &Json) -> bool {
    json::js_string_or_empty(json::js_or3(
        input.get("notebook_path"),
        input.get("file_path"),
        input.get("path"),
    ))
    .ends_with("coverage.ipynb")
}

/// `Number(input.timeout_ms || 0) <= 10_000 && input.persistent === false`.
fn claude_match_wait(input: &Json) -> bool {
    let timeout = json::js_number_value(json::js_or2(
        input.get("timeout_ms"),
        Some(&Json::num_i64(0)),
    ));
    timeout <= 10_000.0 && input.get("persistent") == Some(&Json::Bool(false))
}

fn claude_assert_write(repo: &Path) -> Result<(), String> {
    let content = support::read(&repo.join("notes.txt"))?;
    if content != "live write" {
        let again = support::read(&repo.join("notes.txt"))?;
        return Err(format!(
            "Claude Write did not overwrite expected notes.txt content; content={}",
            Json::str(again).to_compact()
        ));
    }
    Ok(())
}

fn claude_assert_edit(repo: &Path) -> Result<(), String> {
    let content = support::read(&repo.join("notes.txt"))?;
    if content != "after\n" {
        let again = support::read(&repo.join("notes.txt"))?;
        return Err(format!(
            "Claude Edit did not update notes.txt; content={}",
            Json::str(again).to_compact()
        ));
    }
    Ok(())
}

fn claude_assert_notebook(repo: &Path) -> Result<(), String> {
    let text = support::read(&repo.join("coverage.ipynb"))?;
    let notebook = json::parse(&text).map_err(|e| format!("Unexpected token {e}"))?;
    let source = notebook
        .get("cells")
        .and_then(|cells| cells.at(0))
        .and_then(|cell| cell.get("source"));
    let content = match source {
        Some(Json::Arr(items)) => items
            .iter()
            .map(|item| item.js_string())
            .collect::<Vec<_>>()
            .join(""),
        other => json::js_string_or_empty(other),
    };
    if content != "live notebook coverage" {
        let rendered = match source {
            Some(value) => value.to_compact(),
            None => "undefined".to_string(),
        };
        return Err(format!(
            "Claude NotebookEdit did not update first cell; source={rendered}"
        ));
    }
    Ok(())
}

/// JS `claudeScenarios`.
pub fn claude_scenarios() -> Vec<ClaudeScenario> {
    vec![
        ClaudeScenario {
            coverage_key: "claude:pre_tool_use:bash:block-hook-config-edits-without-consent"
                .to_string(),
            claude_neutral: false,
            claude_captured: false,
            id: None,
            event: None,
            tool_name: None,
            allowed_tools: None,
            prompt: None,
            prepare: None,
            tool_use_match: None,
            assert_after: None,
        },
        ClaudeScenario {
            coverage_key: "claude:neutral:bash-pass-path".to_string(),
            claude_neutral: true,
            claude_captured: false,
            id: None,
            event: None,
            tool_name: None,
            allowed_tools: None,
            prompt: None,
            prepare: None,
            tool_use_match: None,
            assert_after: None,
        },
        ClaudeScenario {
            coverage_key: "claude:pre_tool_use:read:block-openai-api-key".to_string(),
            claude_neutral: false,
            claude_captured: true,
            id: Some("read-pass-path"),
            event: Some("pre_tool_use:read"),
            tool_name: Some("Read"),
            allowed_tools: Some("Read"),
            prompt: Some(
                "Use the Read tool to read exactly this file and nothing else: notes.txt",
            ),
            prepare: Some(claude_prepare_read),
            tool_use_match: Some(claude_match_notes_txt),
            assert_after: None,
        },
        ClaudeScenario {
            coverage_key: "claude:pre_tool_use:write:block-hook-config-edits-without-consent"
                .to_string(),
            claude_neutral: false,
            claude_captured: true,
            id: Some("write-pass-path"),
            event: Some("pre_tool_use:write"),
            tool_name: Some("Write"),
            allowed_tools: Some("Read,Write"),
            prompt: Some(
                "Use the Read tool to read notes.txt, then use the Write tool to overwrite exactly this relative file path: notes.txt. Write exactly this content: live write",
            ),
            prepare: Some(claude_prepare_write),
            tool_use_match: Some(claude_match_notes_txt),
            assert_after: Some(claude_assert_write),
        },
        ClaudeScenario {
            coverage_key: "claude:pre_tool_use:edit:block-hook-config-edits-without-consent"
                .to_string(),
            claude_neutral: false,
            claude_captured: true,
            id: Some("edit-pass-path"),
            event: Some("pre_tool_use:edit"),
            tool_name: Some("Edit"),
            allowed_tools: Some("Edit"),
            prompt: Some("Use the Edit tool to replace before with after in notes.txt."),
            prepare: Some(claude_prepare_edit),
            tool_use_match: Some(claude_match_notes_txt_loose),
            assert_after: Some(claude_assert_edit),
        },
        ClaudeScenario {
            coverage_key: format!("claude:pre_tool_use:notebook:{TEMPORARY_PATH_BLOCK_HOOK_ID}"),
            claude_neutral: false,
            claude_captured: true,
            id: Some("notebook-pass-path"),
            event: Some("pre_tool_use:notebook"),
            tool_name: Some("NotebookEdit"),
            allowed_tools: Some("NotebookEdit,Read"),
            prompt: Some(
                "Use the NotebookEdit tool to change the first cell in coverage.ipynb to exactly: live notebook coverage",
            ),
            prepare: Some(claude_prepare_notebook),
            tool_use_match: Some(claude_match_notebook),
            assert_after: Some(claude_assert_notebook),
        },
        ClaudeScenario {
            coverage_key: "claude:pre_tool_use:wait:pre-wait-tools".to_string(),
            claude_neutral: false,
            claude_captured: true,
            id: Some("wait-pass-path"),
            event: Some("pre_tool_use:wait"),
            tool_name: Some("Monitor"),
            allowed_tools: Some("Monitor,ScheduleWakeup"),
            prompt: Some(
                "Use the Monitor tool to wait briefly for 1 second, then stop. Do not use bash.",
            ),
            prepare: None,
            tool_use_match: Some(claude_match_wait),
            assert_after: None,
        },
    ]
}

// ---------------------------------------------------------------------------
// editor scenarios
// ---------------------------------------------------------------------------

/// JS `editorSaveGuard` / `editorWatcher` — absolute device paths, verbatim.
pub const EDITOR_SAVE_GUARD: &str = "/Users/lukaszbartoszcze/.shared-hooks/editor-save-guard.mjs";
pub const EDITOR_WATCHER: &str = "/Users/lukaszbartoszcze/.shared-hooks/editor-watch.mjs";

