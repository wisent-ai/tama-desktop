//! Shared helpers for the tama-testkit harness binaries: ports of the
//! JavaScript semantics the session-override tests rely on, the document order
//! a JSON reader has to preserve, and the fixtures a run is given.
//!
//! The harnesses exercise the JavaScript hook runtime, so - exactly like the
//! JS tests - the ported binaries spawn `node` and `python3` for those parts.
//! This was one file of eight hundred lines; it is three areas now.
#![allow(dead_code)]

pub mod fixtures;
pub mod js;
pub mod order;

pub use fixtures::*;
pub use js::*;
pub use order::*;

/// Harness assertion (`node:assert/strict` failures exit the process with
/// code 1; `Err` here does the same in the ported binaries).
pub fn check(condition: bool, message: impl Into<String>) -> Result<(), String> {
    if condition {
        Ok(())
    } else {
        Err(message.into())
    }
}
