//! Which coverage keys a recorded run proves: reading a hook command back to
//! the script it names, matching it against the registry, and pulling the
//! coverage markers out of what the router printed.

use std::path::Path;

use crate::json::{self, Json};
use crate::support;

/// `basenameFromCommand` in core, it does not strip quotes).
pub fn basename_from_hook_command(command: &str) -> String {
    let parts: Vec<&str> = command.trim().split_whitespace().collect();
    let first = parts.first().copied().unwrap_or("");
    let script = parts
        .iter()
        .copied()
        .find(|part| {
            part.ends_with(".py")
                || part.ends_with(".sh")
                || part.ends_with(".mjs")
                || part.ends_with(".js")
        })
        .unwrap_or(first);
    script.rsplit('/').next().unwrap_or("").to_string()
}

/// JS `hookCommandsMatch(adapterCommand, registryCommand)`.
pub fn hook_commands_match(adapter_command: &str, registry_command: &str) -> bool {
    if adapter_command == registry_command {
        return true;
    }
    let adapter_base = basename_from_hook_command(adapter_command);
    let registry_base = basename_from_hook_command(registry_command);
    !adapter_base.is_empty() && !registry_base.is_empty() && adapter_base == registry_base
}

/// JS `codexCoverageKeysFromCommand(event, command)`.
pub fn codex_coverage_keys_from_command(
    root: &Path,
    event: &str,
    command: &str,
) -> Result<Vec<String>, String> {
    let registry = tama_core::runtime::load_registry(PathBuf::from(root).as_path())
        .map_err(|e| e.to_string())?;
    let empty = Vec::new();
    let hooks = registry
        .events
        .get(event)
        .map(|config| &config.hooks)
        .unwrap_or(&empty);
    Ok(hooks
        .iter()
        .filter(|hook| hook_commands_match(command, hook.command.as_deref().unwrap_or("")))
        .map(|hook| support::coverage_key_opt("codex", event, &hook.id, event))
        .collect())
}

/// JS `codexRouterCoverageTexts(output)`.
pub fn codex_router_coverage_texts(output: &str) -> Vec<String> {
    let mut texts = vec![output.to_string()];
    // `try { const parsed = JSON.parse(output); ... } catch {}` — raw Codex
    // output is not guaranteed to be JSON.
    if let Ok(parsed) = json::parse(output) {
        let choices = json::js_or2(
            parsed.get("data").and_then(|d| d.get("choices")),
            parsed.get("choices"),
        )
        .and_then(Json::as_array);
        if let Some(choices) = choices {
            for choice in choices {
                if let Some(content) = choice
                    .get("message")
                    .and_then(|m| m.get("content"))
                    .and_then(Json::as_str)
                {
                    texts.push(content.to_string());
                }
            }
        }
    }
    texts
}

/// JS `codexRouterCoverageEntries(output)`.
pub fn codex_router_coverage_entries(output: &str) -> Vec<Json> {
    const MARKER: &str = "[model-router-codex-hook-coverage]";
    let mut entries = Vec::new();
    for text in codex_router_coverage_texts(output) {
        let index = match text.rfind(MARKER) {
            Some(index) => index,
            None => continue,
        };
        for line in text[index + MARKER.len()..].split('\n') {
            let trimmed = line.trim_end_matches('\r').trim();
            if trimmed.is_empty() {
                continue;
            }
            if let Ok(entry) = json::parse(trimmed) {
                entries.push(entry);
            }
        }
    }
    entries
}

/// JS `coveredKeysFromCodexRouterCoverage(output)`.
pub fn covered_keys_from_codex_router_coverage(
    root: &Path,
    output: &str,
) -> Result<Vec<String>, String> {
    let mut keys = Vec::new();
    for entry in codex_router_coverage_entries(output) {
        let event = entry
            .get("event")
            .and_then(Json::as_str)
            .filter(|s| !s.is_empty());
        let hook_id = entry
            .get("hook_id")
            .and_then(Json::as_str)
            .filter(|s| !s.is_empty());
        let command = entry
            .get("command")
            .and_then(Json::as_str)
            .filter(|s| !s.is_empty());
        match (event, hook_id, command) {
            (Some(event), Some(hook_id), _) => {
                keys.push(support::coverage_key_opt("codex", event, hook_id, event));
            }
            (Some(event), None, Some(command)) => {
                keys.extend(codex_coverage_keys_from_command(root, event, command)?);
            }
            _ => {}
        }
    }
    Ok(support::unique(keys))
}
