//! A service cycled by hand, a credential issued from a terminal, a fleet or a
//! toolchain command that repairs one host once, and a build typed instead of
//! registered.

use super::super::vocabulary::*;

/// A service restarted, stopped, unloaded or killed by hand.
pub(crate) fn service_cycle_refusal(program: &str, args: &[String]) -> Option<String> {
    let words = &*VOCABULARY;
    let verb = args.iter().map(String::as_str).find(|arg| !is_flag(arg));
    if program == LAUNCHCTL {
        let verb = verb.filter(|verb| has(&words.launchctl_cycle, verb))?;
        return Some(format!(
            "{BANNER}`launchctl {verb}` cycles a service on this machine once and records nothing; {SERVICE_ROUTE}"
        ));
    }
    if program == SYSTEMCTL {
        let verb = verb.filter(|verb| has(&words.systemctl_cycle, verb))?;
        return Some(format!(
            "{BANNER}`systemctl {verb}` cycles a service once and records nothing; {SERVICE_ROUTE}"
        ));
    }
    // `brew services restart postgresql@17` is the same repair with another
    // launcher, and Oko counted it in the same category from the start while
    // nothing refused it.
    if program == BREW {
        let mut plain = args.iter().map(String::as_str).filter(|arg| !is_flag(arg));
        if plain.next() == Some(BREW_SERVICES) {
            let verb = plain
                .next()
                .filter(|verb| has(&words.brew_service_verbs, verb))?;
            return Some(format!(
                "{BANNER}`brew services {verb}` cycles a service on this machine once and the \
                 declaration that put it there is unchanged; {SERVICE_ROUTE}"
            ));
        }
        return None;
    }
    if !has(&words.kill_programs, program) {
        return None;
    }
    let first = args.first().map(String::as_str)?;
    if has(&words.kill_read_flags, first) {
        return None;
    }
    Some(format!(
        "{BANNER}`{program}` ends a process by hand and launchd or Stado brings back the same fault; {SERVICE_ROUTE}"
    ))
}

/// A grant or bearer written straight into a vault with `skarbiec`, past
/// Stado. `stado credentials token mint` and `stado credentials grant` are
/// the product's own route - they record against the owner's vault and
/// `token sync` delivers the result - so they pass; Oko's detector still
/// lists them for the judge.
pub(crate) fn credential_refusal(program: &str, args: &[String]) -> Option<String> {
    if program != SKARBIEC || asks_for_help(args) {
        return None;
    }
    let words = &*VOCABULARY;
    let mut plain = args
        .iter()
        .map(String::as_str)
        .filter(|word| !is_flag(word));
    let first = plain.next()?;
    if first == SKARBIEC_GRANT {
        let verb = plain
            .next()
            .filter(|verb| has(&words.skarbiec_grant_writes, verb))?;
        return Some(format!(
            "{BANNER}`skarbiec grant {verb}` from the shell writes whichever vault the shell resolves - on 2026-09-18 the replica the owner overwrote within the hour. A consumer's grant goes through Stado, which records it against the owner's vault: `stado release catalog declare-publisher <PRODUCT> --owner <VAULT HOST> --client <HOST>` for a release publisher, `stado service grant-sync <SERVICE> --host <HOST> --consumer <CONSUMER> --capability <CAP> --token-file <PATH>` for a service, `stado credentials grant item-read --host <VAULT HOST> <CONSUMER> <ITEM> --field <FIELD> --token-file <PATH>` for one read."
        ));
    }
    if !has(&words.skarbiec_writes, first) {
        return None;
    }
    Some(format!(
        "{BANNER}`skarbiec {first}` from the shell mints a bearer nothing records; `stado credentials token mint <CONSUMER> --host <VAULT HOST> --capabilities <CAPS> --audience <AUD> --token-file-name <NAME>` records it against the owner's vault, and `stado credentials token sync` delivers it."
    ))
}

/// `~/x`, `$HOME/x` and `/Users/<name>/x` all name the same home; the roots

/// A fleet command that repairs one host once where a declaration owns the
/// outcome. These are the product's own commands, which is what makes them
/// easy to keep typing: each leaves the host exactly as it was found the
/// next time the same pressure arrives.
pub(crate) fn fleet_one_off_refusal(program: &str, args: &[String]) -> Option<String> {
    let words = &*VOCABULARY;
    if program != words.fleet_program || asks_for_help(args) {
        return None;
    }
    let mut plain = args.iter().map(String::as_str).filter(|arg| !is_flag(arg));
    let command = format!("{} {}", plain.next()?, plain.next()?);
    let route = words.fleet_one_off_commands.get(&command)?;
    Some(format!(
        "{BANNER}`{} {command}` repairs one host once: {route}",
        words.fleet_program
    ))
}

/// A toolchain command that produces a verdict nobody but the shell sees.
///
/// The suite and the lint are not the problem — they are the product's own
/// quality gate, and the release worker runs both on every candidate. Typing
/// them here produces the same work with none of the record: no revision
/// bound to the result, no exit status the fleet keeps, and no refusal that
/// stops a bad build reaching a host.
pub(crate) fn toolchain_one_off_refusal(program: &str, args: &[String]) -> Option<String> {
    let words = &*VOCABULARY;
    if program != words.toolchain_program || asks_for_help(args) {
        return None;
    }
    let command = args
        .iter()
        .map(String::as_str)
        .find(|arg| !is_flag(arg))?
        .to_string();
    let route = words.toolchain_one_off_commands.get(&command)?;
    Some(format!(
        "{BANNER}`{} {command}` answers this shell and nothing else: {route}",
        words.toolchain_program
    ))
}

/// Any other build or suite run from a shell.
///
/// `cargo` has its own entry above; this is every other driver, because the
/// operator found a session running `swift build` and `swift test` all
/// afternoon while a gate that named only `cargo` watched it happen: "i jak
/// to jest mozliwe ze budujesz skoro nasz hook mial to blokowac. dodaj
/// swift test i jakiekolwiek komendy do budowania do listy zakazanych
/// zwrotow". A driver is read by the word after it (`swift test`,
/// `npm run build`); a program that only ever builds is refused by name.
pub(crate) fn build_one_off_refusal(program: &str, args: &[String]) -> Option<String> {
    let words = &*VOCABULARY;
    if asks_for_help(args) {
        return None;
    }
    let route = &words.build_route;
    if has(&words.build_programs, program) {
        return Some(format!(
            "{BANNER}`{program}` builds from this working copy: {route}"
        ));
    }
    let verbs = words.build_drivers.get(program)?;
    // `npm run build` names what it runs in the second word, so both are read,
    // and a script runner's script is read too: every `npm run <script>` in
    // these repositories compiles something — `test:context` builds the
    // release binary before it runs a single case — so the refusal names the
    // script it refused rather than the bare runner.
    let mut plain = args.iter().map(String::as_str).filter(|arg| !is_flag(arg));
    let first = plain.next()?;
    let verb = if has(verbs, first) {
        match plain.next() {
            Some(script) if first == SCRIPT_RUNNER_VERB => format!("{first} {script}"),
            _ => first.to_owned(),
        }
    } else {
        let second = plain.next().filter(|word| has(verbs, word))?;
        format!("{first} {second}")
    };
    Some(format!(
        "{BANNER}`{program} {verb}` builds or tests from this working copy: {route}"
    ))
}
