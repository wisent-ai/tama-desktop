//! Real CLI and real hook scripts; source files remain byte-identical.
mod declare_root;
mod fixture;
mod hook_resolution;

#[path = "size/counting.rs"]
mod counting;
#[path = "size/declarations.rs"]
mod declarations;
