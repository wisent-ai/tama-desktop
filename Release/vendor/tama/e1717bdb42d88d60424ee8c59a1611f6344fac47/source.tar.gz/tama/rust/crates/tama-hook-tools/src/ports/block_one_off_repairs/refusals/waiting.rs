//! Waiting and looking: a guessed sleep instead of a read, a tree searched
//! once for whoever typed it, and a deadline written in front of a command.

use super::super::vocabulary::*;

/// missing the missing read is the defect to build, not a longer sleep.
pub(crate) fn waiting_refusal(program: &str, args: &[String]) -> Option<String> {
    if !has(&VOCABULARY.wait_programs, program) || asks_for_help(args) {
        return None;
    }
    let interval = args.first().map(String::as_str).unwrap_or_default();
    Some(format!(
        "{BANNER}`{program} {interval}` waits a guessed interval and observes nothing: the state \
         read after it is as likely to be the old one. An outcome is waited for by the command \
         that owns it — `stado job watch <ID> --follow` to a terminal state, `stado release \
         doctor <PRODUCT> --target <HOST>` for one rollout verdict, `stado release status \
         <PRODUCT>` for the register of attempts, `stado space report <HOST>` for a host's own \
         reading. If the outcome has no such read, that missing read is the defect to build."
    ))
}

/// A tree searched from the shell.
///
/// `grep -rn … src` answers the person who typed it, once, and leaves
/// nothing behind: no product surface gained the answer, and the next
/// reader types it again. Reading a file is a read; searching a repository
/// from the shell is a step somebody has to repeat. The harness has its own
/// search that carries the result into the session, and a question asked of
/// a product is asked through that product's own read.
///
/// `launchctl list | grep wisent` is not that. `grep` with a pattern and no
/// path reads the previous command's output, which is the shape the fleet's
/// own reads are written in, and refusing it told sessions to stop using
/// commands the rule was never about — the test that says so had been red
/// since the rule was written.
pub(crate) fn search_refusal(program: &str, args: &[String]) -> Option<String> {
    if !has(&VOCABULARY.search_programs, program) || asks_for_help(args) {
        return None;
    }
    if has(&VOCABULARY.stream_search_programs, program) && !searches_a_tree(args) {
        return None;
    }
    Some(format!(
        "{BANNER}`{program}` searches a tree once for whoever typed it and leaves nothing a \
         later reader or a product surface can use. Read the file with the harness's own read, \
         search with its search, and ask a product what it holds through its own command — \
         `brama subscriptions`, `stado release status <PRODUCT>`, `oko-cli transcripts tasks \
         --session <ID>`. A question worth asking twice belongs in one of those, not in a \
         shell line."
    ))
}

/// Whether a stream search was pointed at files instead of a pipe: a path
/// after the pattern, or a recursive flag, which names a tree on its own.
/// The flag is read inside a cluster too, because `grep -rn PATTERN src` is
/// how a tree search is actually typed.
pub(super) fn searches_a_tree(args: &[String]) -> bool {
    let recursive = args.iter().any(|arg| {
        arg == RECURSIVE_LONG_FLAG
            || (is_flag(arg)
                && !arg.starts_with(LONG_FLAG_PREFIX)
                && arg
                    .chars()
                    .any(|letter| RECURSIVE_LETTERS.contains(&letter)))
    });
    let positionals = args.iter().filter(|arg| !is_flag(arg)).count();
    recursive || positionals > 1
}
/// A deadline wrapped around somebody else's command.
///
/// The written-code gate refuses a deadline in a file, and this one refuses
/// it in a shell line, because the two are the same guess: a number nobody
/// measured, standing in for the answer the command was going to give. A
/// command killed at that number is reported as a failure it never had, and
/// the question of why it was slow is thrown away with it. The wrapper is
/// stepped over when the guard reads what a line actually runs, which is why
/// it has to be named here rather than left to the program table.
pub(crate) fn deadline_wrapper_refusal(tokens: &[String]) -> Option<String> {
    let words = &*VOCABULARY;
    // A duration has to follow, so `--field timeout` and a path that ends in
    // the word are left alone; `timeout 300 …`, `timeout 1.5m …` and
    // `timeout -k 5 20 …` are not.
    let wrapper = tokens.windows(2).find_map(|pair| {
        let name = basename(&pair[0]);
        let follows_a_duration = pair[1].starts_with('-')
            || pair[1]
                .trim_end_matches(['s', 'm', 'h', 'd'])
                .parse::<f64>()
                .is_ok();
        (has(&words.deadline_wrappers, name) && follows_a_duration).then_some(name)
    })?;
    Some(format!(
        "{BANNER}`{wrapper} <seconds> …` puts a guessed deadline in front of a command. Nobody \
         measured that number, and the command killed at it reports a failure it did not have — \
         a slow answer and a broken one read the same afterwards. Let the command answer and read \
         what it says; when an outcome genuinely has to be waited for, the product that owns it \
         waits: `stado job watch <ID> --follow`, `stado release status <PRODUCT>`, \
         `oko-cli transcripts tasks --session <ID>`."
    ))
}
