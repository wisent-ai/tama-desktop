//! Deadlines a task did not ask for.
//!
//! A cancelled task looks exactly like a failed one, and a deadline chosen by
//! an agent is a number nobody measured. So the constructs that kill work —
//! the async waiters, the alarm, the abort signal, the killing timer — are
//! refused, and so is editing an existing deadline value. The exceptions are
//! the ones a network call genuinely needs: an HTTP client, a page
//! navigation, a configured server entry.
//!
//! The agent tool directories are skipped, because a provider's own
//! configuration files carry their deadlines as data.
//!
//! As in the sibling modules, the patterns, the message text, the constant
//! names and the test fixtures are assembled from fragments: the words this
//! module matches are words it refuses to see in a file.

use std::sync::LazyLock;

mod complaint;
mod shapes;

pub(crate) use complaint::complaint;

#[cfg(test)]
mod tests {
    use super::complaint;

    const SOURCE: &str = "/repo/src/worker.py";
    const DEADLINE: &str = "timeout";

    #[test]
    fn the_killing_constructs_are_refused_and_named() {
        for call in [
            concat!("asyncio", ".wait_for(task)"),
            concat!("asyncio", ".timeout(5)"),
            concat!("signal", ".alarm(3)"),
            concat!("AbortSignal", ".timeout(1000)"),
        ] {
            let found = complaint(SOURCE, call).expect("a deadline");
            assert!(found.contains("No timeouts"), "{found}");
        }
    }

    #[test]
    fn a_timer_that_kills_is_refused() {
        let code = format!(
            "{}(() => controller.abort(), 500)",
            concat!("set", "Timeout")
        );
        let found = complaint(SOURCE, &code).expect("a killing timer");
        assert!(found.contains("No timeouts"), "{found}");
        assert!(found.contains("controller.abort()"), "{found}");
    }

    /// The operator's rule after a session waited out a rollout by the clock:
    /// any use of the word, including the one an HTTP client used to be
    /// allowed. Both lines below passed before 2026-09-21.
    #[test]
    fn a_network_deadline_is_refused_like_any_other() {
        for line in [
            format!("response = httpx.get(url, {DEADLINE}=30)"),
            format!("worker_{DEADLINE} = 45"),
        ] {
            let found = complaint(SOURCE, &line).expect("a deadline");
            assert!(found.contains("No timeouts"), "{found}");
            assert!(found.contains(line.trim()), "{found}");
        }
    }

    /// Turning a library's own deadline off is the opposite of setting one:
    /// `reqwest` says it with `None`, Playwright with zero.
    #[test]
    fn the_calls_that_disable_a_library_deadline_pass() {
        for line in [
            format!(".{DEADLINE}(None)"),
            format!(".{DEADLINE}(0)"),
            format!("await locator.waitFor({{ state, {DEADLINE}: 0 }});"),
            format!("{DEADLINE}Ms: 0,"),
        ] {
            assert_eq!(complaint(SOURCE, &line), None, "{line}");
        }
    }

    /// …and only those: any value beside them is still refused.
    #[test]
    fn a_value_is_refused_even_beside_the_disabling_call() {
        for line in [
            format!(".{DEADLINE}(Some(Duration::from_secs(30)))"),
            format!("await locator.waitFor({{ {DEADLINE}: 30000 }});"),
            format!("{DEADLINE}Ms: 5_000,"),
        ] {
            assert!(complaint(SOURCE, &line).is_some(), "{line}");
        }
    }

    /// A guessed interval is the same mistake spelled as a wait.
    #[test]
    fn a_guessed_wait_is_refused() {
        for call in [
            concat!("thread", "::sleep(Duration::from_secs(20))"),
            concat!("time", ".sleep(20)"),
            "sleep(20)",
        ] {
            let found = complaint(SOURCE, call).expect("a guessed wait");
            assert!(found.contains("run to completion"), "{found}");
        }
    }

    /// The hook runtime's own registry declares per-event limits as data.
    #[test]
    fn the_hook_declarations_are_skipped() {
        let declaration = format!("\"events\": [{{ \"{DEADLINE}\": 10 }}]");
        assert_eq!(
            complaint(
                "/repo/hook-declarations/block-one-off-repairs.json",
                &declaration
            ),
            None
        );
    }

    #[test]
    fn the_limit_words_are_refused() {
        for word in [
            concat!("time", "_limit"),
            concat!("max", "_time"),
            concat!("statement", "_timeout"),
        ] {
            assert!(
                complaint(SOURCE, &format!("x = {word}")).is_some(),
                "{word}"
            );
        }
    }

    /// A provider's own configuration carries its deadlines as data.
    #[test]
    fn the_agent_tool_directories_are_skipped() {
        let code = format!("{}(() => kill(), 10)", concat!("set", "Timeout"));
        assert_eq!(complaint("/Users/someone/.codex/hooks.json", &code), None);
    }

    #[test]
    fn ordinary_code_passes() {
        assert_eq!(complaint(SOURCE, "def run(): return compute()"), None);
    }
}
