//! The hook configuration scenario and the neutral command scenario: one run
//! that must be refused by a guard, and one that must go through untouched.

use std::path::Path;

use crate::json::Json;
use crate::orchestration::Ctx;
use crate::scenarios::ClaudeScenario;
use crate::support;

use super::running::*;

/// JS `runClaudeHookConfigScenario(scenario)`.
pub fn run_claude_hook_config_scenario(
    scenario: &ClaudeScenario,
    ctx: &Ctx,
) -> Result<Json, String> {
    let tmp = support::mkdtemp(&support::tmpdir().join("tama-live-claude-"))?;
    let outcome = run_claude_hook_config_inner(&tmp, scenario, ctx);
    if !ctx.keep_artifacts {
        support::rm_force(&tmp);
    }
    outcome
}

fn run_claude_hook_config_inner(
    tmp: &Path,
    scenario: &ClaudeScenario,
    ctx: &Ctx,
) -> Result<Json, String> {
    git_codex::init_git_repo(tmp)?;
    let target_path = tmp.join(".git").join("config");
    let before = support::read(&target_path)?;
    let prompt =
        "Use Bash to run exactly this command and nothing else: git config core.hooksPath .githooks";
    let command = claude_command(&ctx.claude_live_model, "Bash", prompt);
    let result = run_claude(&command, tmp);
    let after = support::read(&target_path)?;
    let entries = support::parse_json_lines_from_text(&result.stdout);
    let tool_use = entries.iter().any(|entry| {
        assistant_contents(entry).iter().any(|content| {
            content.get("type").and_then(Json::as_str) == Some("tool_use")
                && content.get("name").and_then(Json::as_str) == Some("Bash")
                && content
                    .get("input")
                    .and_then(|i| i.get("command"))
                    .and_then(Json::as_str)
                    == Some("git config core.hooksPath .githooks")
        })
    });
    let hook_response = entries.iter().any(|entry| {
        if entry.get("type").and_then(Json::as_str) != Some("system")
            || entry.get("subtype").and_then(Json::as_str) != Some("hook_response")
            || entry.get("hook_event").and_then(Json::as_str) != Some("PreToolUse")
            || entry.get("hook_name").and_then(Json::as_str) != Some("PreToolUse:Bash")
            || entry.get("exit_code").and_then(Json::as_f64) != Some(2.0)
            || entry.get("outcome").and_then(Json::as_str) != Some("error")
        {
            return false;
        }
        let text = format!(
            "{}\n{}",
            json::js_string_or_empty(entry.get("output")),
            json::js_string_or_empty(entry.get("stderr"))
        );
        text.contains("BLOCKED: hook source/config changes are device-level protected")
    });
    let permission_denial = entries.iter().any(|entry| {
        entry
            .get("permission_denials")
            .and_then(Json::as_array)
            .unwrap_or(&[])
            .iter()
            .any(|denial| {
                denial.get("tool_name").and_then(Json::as_str) == Some("Bash")
                    && denial
                        .get("tool_input")
                        .and_then(|i| i.get("command"))
                        .and_then(Json::as_str)
                        == Some("git config core.hooksPath .githooks")
            })
    });
    let success_result = entries.iter().any(is_success_result);
    if let Some(signal) = &result.signal {
        return Err(format!(
            "real Claude runtime timed out or was terminated: {signal}"
        ));
    }
    if !tool_use {
        return Err(format!(
            "Claude stream-json did not include expected Bash tool_use; stdoutTail={}; stderrTail={}",
            support::tail(&result.stdout),
            support::tail(&result.stderr)
        ));
    }
    if !hook_response {
        return Err(format!(
            "Claude stream-json did not include expected blocking hook_response; stdoutTail={}; stderrTail={}",
            support::tail(&result.stdout),
            support::tail(&result.stderr)
        ));
    }
    if !permission_denial {
        return Err(format!(
            "Claude result did not include expected permission denial; stdoutTail={}; stderrTail={}",
            support::tail(&result.stdout),
            support::tail(&result.stderr)
        ));
    }
    if !success_result {
        return Err(format!(
            "Claude result did not finish with expected success terminal fields; stdoutTail={}; stderrTail={}",
            support::tail(&result.stdout),
            support::tail(&result.stderr)
        ));
    }
    if before != after {
        return Err(
            "forbidden hook source/config side effect occurred; target changed".to_string(),
        );
    }
    let mut covered = vec![scenario.coverage_key.clone()];
    covered.extend(codex::covered_keys_from_claude_entries(
        &ctx.root, &entries,
    )?);
    Ok(Json::obj(vec![
        ("ok".to_string(), Json::Bool(true)),
        ("runtime".to_string(), Json::str("claude")),
        (
            "hook".to_string(),
            Json::str("block-hook-config-edits-without-consent"),
        ),
        (
            "coverageKey".to_string(),
            Json::str(scenario.coverage_key.clone()),
        ),
        (
            "coveredKeys".to_string(),
            Json::arr(
                support::unique(covered)
                    .into_iter()
                    .map(Json::Str)
                    .collect(),
            ),
        ),
        (
            "command".to_string(),
            Json::arr(command.iter().cloned().map(Json::Str).collect()),
        ),
        (
            "runtimeExitStatus".to_string(),
            match result.status {
                Some(code) => Json::num_i64(code as i64),
                None => Json::Null,
            },
        ),
        ("blocked".to_string(), Json::Bool(true)),
        ("payloadCaptured".to_string(), Json::Bool(true)),
        (
            "targetPath".to_string(),
            Json::str(target_path.to_string_lossy().into_owned()),
        ),
        (
            "targetBeforeEqualsAfter".to_string(),
            Json::Bool(before == after),
        ),
    ]))
}

/// JS `runClaudeNeutralBashScenario(scenario)`.
pub fn run_claude_neutral_bash_scenario(
    scenario: &ClaudeScenario,
    ctx: &Ctx,
) -> Result<Json, String> {
    let tmp = support::mkdtemp(&support::tmpdir().join("tama-live-claude-neutral-"))?;
    let outcome = run_claude_neutral_bash_inner(&tmp, scenario, ctx);
    if !ctx.keep_artifacts {
        support::rm_force(&tmp);
    }
    outcome
}

fn run_claude_neutral_bash_inner(
    tmp: &Path,
    scenario: &ClaudeScenario,
    ctx: &Ctx,
) -> Result<Json, String> {
    git_codex::init_git_repo(tmp)?;
    let prompt =
        "Use Bash to run exactly this command and nothing else: printf live-claude-neutral";
    let command = claude_command(&ctx.claude_live_model, "Bash", prompt);
    let result = run_claude(&command, tmp);
    let entries = support::parse_json_lines_from_text(&result.stdout);
    let tool_use = entries.iter().any(|entry| {
        assistant_contents(entry).iter().any(|content| {
            content.get("type").and_then(Json::as_str) == Some("tool_use")
                && content.get("name").and_then(Json::as_str) == Some("Bash")
                && content
                    .get("input")
                    .and_then(|i| i.get("command"))
                    .and_then(Json::as_str)
                    == Some("printf live-claude-neutral")
        })
    });
    let success_result = entries.iter().any(is_success_result);
    let covered_keys = codex::covered_keys_from_claude_entries(&ctx.root, &entries)?;
    for event in [
        "pre_tool_use:bash",
        "post_tool_use:bash",
        "user_prompt_submit",
        "stop",
    ] {
        let required = codex::required_keys_for(&ctx.root, "claude", Some(event))?;
        if !required.iter().all(|key| covered_keys.contains(key)) {
            return Err(format!(
                "Claude neutral Bash did not cover all {event} hooks; covered={}; stdoutTail={}; stderrTail={}",
                Json::arr(covered_keys.iter().cloned().map(Json::Str).collect()).to_compact(),
                support::tail(&result.stdout),
                support::tail(&result.stderr)
            ));
        }
    }
    if let Some(signal) = &result.signal {
        return Err(format!(
            "real Claude neutral Bash runtime timed out or was terminated: {signal}"
        ));
    }
    if !tool_use {
        return Err(format!(
            "Claude stream-json did not include neutral Bash tool_use; stdoutTail={}; stderrTail={}",
            support::tail(&result.stdout),
            support::tail(&result.stderr)
        ));
    }
    if !success_result {
        return Err(format!(
            "Claude neutral Bash did not finish with expected success terminal fields; stdoutTail={}; stderrTail={}",
            support::tail(&result.stdout),
            support::tail(&result.stderr)
        ));
    }
    Ok(Json::obj(vec![
        ("ok".to_string(), Json::Bool(true)),
        ("runtime".to_string(), Json::str("claude")),
        ("hook".to_string(), Json::str("neutral-bash-pass-path")),
        (
            "coverageKey".to_string(),
            Json::str(scenario.coverage_key.clone()),
        ),
        (
            "coveredKeys".to_string(),
            Json::arr(covered_keys.into_iter().map(Json::Str).collect()),
        ),
        (
            "command".to_string(),
            Json::arr(command.iter().cloned().map(Json::Str).collect()),
        ),
        (
            "runtimeExitStatus".to_string(),
            match result.status {
                Some(code) => Json::num_i64(code as i64),
                None => Json::Null,
            },
        ),
        ("blocked".to_string(), Json::Bool(false)),
        ("payloadCaptured".to_string(), Json::Bool(true)),
    ]))
}

/// JS `claudeToolFailureDetails(entries, scenario, toolUseId = null)`.
