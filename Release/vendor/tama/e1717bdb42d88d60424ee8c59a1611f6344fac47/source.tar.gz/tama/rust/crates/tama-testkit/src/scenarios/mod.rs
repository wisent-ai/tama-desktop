//! Port of `src/tests/live-runtime/scenarios/*.mjs`: what each runtime is
//! driven through, and the closures each scenario carries (prepare, prompt,
//! payload match, assert after, tool-use match).
//!
//! The list was one file of thirteen hundred lines. It is one module per
//! runtime now, over the shapes they all share.

pub mod omp;
pub mod runtimes;
pub mod types;

pub use omp::omp_scenarios;
pub use runtimes::claude::claude_scenarios;
pub use runtimes::codex::codex_scenarios;
pub use runtimes::editor::{
    editor_edit_cases, editor_notebook_cases, editor_scenarios, notebook_fixture_content,
    EDITOR_SAVE_GUARD, EDITOR_WATCHER,
};
pub use runtimes::git::git_scenarios;
pub use types::*;
