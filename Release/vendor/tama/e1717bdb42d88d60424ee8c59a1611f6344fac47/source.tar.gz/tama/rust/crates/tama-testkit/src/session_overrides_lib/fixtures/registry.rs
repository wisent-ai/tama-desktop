//! The fixture registry a harness run is given: hooks it can actually run and
//! a catalogue checksum that checks out, so the run exercises the real
//! verification rather than a registry that is waved through.
#![allow(dead_code)]

use std::path::Path;

use serde_json::{json, Map, Value};

use super::super::js::sha256_hex;


fn lifecycle_hook(command: &str) -> Value {
    json!({ "id": "fixture-lifecycle-hook", "command": command, "timeout": 5 })
}

/// `buildFixtureRegistry()`: the events object plus a valid catalog checksum
/// (sha256 of the stable serialization of the registry without the checksum).
pub fn build_fixture_registry() -> Value {
    build_fixture_registry_inner(None)
}

pub fn build_fixture_registry_with_runtime_hooks(pre_write_edit: &Path, recorder: &Path) -> Value {
    build_fixture_registry_inner(Some((pre_write_edit, recorder)))
}

fn build_fixture_registry_inner(runtime_hooks: Option<(&Path, &Path)>) -> Value {
    let lifecycle_command = runtime_hooks
        .map(|(_, recorder)| format!("node \"{}\"", recorder.display()))
        .unwrap_or_else(|| "/usr/bin/true".to_string());
    let mut events = Map::new();
    let mut event = |name: &str, blocking: bool, hooks: Value| {
        events.insert(
            name.to_string(),
            json!({ "blocking": blocking, "hooks": hooks }),
        );
    };
    event(
        "test:integrity",
        true,
        json!([{ "id": "block-numeric-literals", "command": "/usr/bin/false", "timeout": 1 }]),
    );
    event(
        "test:former-protected",
        true,
        json!([{ "id": "block-device-level-tests-without-consent", "command": "/usr/bin/false", "timeout": 1 }]),
    );
    event(
        "test:adapter",
        true,
        json!([{ "id": "fixture-registry-hook", "command": "/usr/bin/false", "timeout": 1 }]),
    );
    event(
        "user_prompt_submit",
        false,
        json!([lifecycle_hook(&lifecycle_command)]),
    );
    event("stop", false, json!([lifecycle_hook(&lifecycle_command)]));
    event(
        "session_start:compact",
        false,
        json!([lifecycle_hook(&lifecycle_command)]),
    );
    event(
        "post_tool_use:bash",
        true,
        json!([lifecycle_hook(&lifecycle_command)]),
    );
    event(
        "pre_tool_use:eval",
        true,
        json!([{ "id": "fixture-registry-hook", "command": "/usr/bin/false", "timeout": 1 }]),
    );
    if let Some((script, _)) = runtime_hooks {
        event(
            "test:selection",
            true,
            json!([
                { "id": "block-numeric-literals", "command": "/usr/bin/true", "timeout": 1 },
                { "id": "fixture-registry-hook", "command": "/usr/bin/false", "timeout": 1 },
            ]),
        );
        event(
            "pre_tool_use:edit",
            true,
            json!([{
                "id": "pre-write-edit",
                "command": format!("\"{}\"", script.display()),
                "timeout": 5,
            }]),
        );
    }

    let mut registry = Map::new();
    registry.insert("events".to_string(), Value::Object(events));
    let stable =
        serde_json::to_string(&Value::Object(registry.clone())).unwrap_or_else(|_| unreachable!());
    registry.insert(
        "catalogChecksum".to_string(),
        json!(sha256_hex(stable.as_bytes())),
    );
    Value::Object(registry)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn fixture_registry_checksum_matches_node() {
        // Reference value for the stable JSON serialization used by the
        // JavaScript registry loader.
        let registry = build_fixture_registry();
        assert_eq!(
            registry["catalogChecksum"].as_str(),
            Some("d5a9e7bcf1b51c0aecb4f01e80148275002cebb446eab00a5a7b1b4dedd5b3da")
        );
    }
}
