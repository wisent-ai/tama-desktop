//! Settings, scratch directories, guessed waits and fleet repairs: the
//! commands that leave a host exactly as they found it the next time.




use crate::harness::{passes, refuses};

/// reported as counted and refused by nothing, and the reads beside them.
#[test]
fn a_machine_setting_a_scratch_directory_and_a_write_into_operator_state_are_refused() {
    refuses(
        "defaults write com.google.Chrome AllowJavaScriptAppleEvents -bool true",
        "stado registry set",
    );
    refuses("work=$(mktemp -d)", "~/.wisent-output");
    refuses(
        "printf '%s' token > ~/.stado/release-client-token",
        "stado credentials token mint",
    );
    refuses(
        "echo '{}' >> $HOME/.config/wisent/settings.json",
        "stado registry set",
    );
}

#[test]
fn reading_a_setting_and_writing_into_a_build_directory_pass() {
    passes("defaults read com.google.Chrome AllowJavaScriptAppleEvents");
    passes("stado release status --json > rust/target/release.json");
    passes("cat ~/.stado/config.json");
    passes("defaults --help");
}

/// The binary this machine runs refuses a guessed wait and the two fleet
/// commands that repair one host once, and names what owns each outcome.
#[test]
fn a_guessed_wait_and_a_one_host_fleet_repair_are_refused_with_their_routes() {
    refuses("sleep 420", "stado job watch");
    refuses(
        "sleep 240; stado release doctor skarbiec --target charless-mac-mini",
        "stado release doctor",
    );
    refuses(
        "stado space reclaim lukasz-macbook --apply --reason 'the disk filled again'",
        "stado space cleaners",
    );
    refuses(
        "stado release submit --source . --commit 6c9f32cb --version 0.21.49 --channel stable",
        "never bound to every commit",
    );
}

#[test]
fn reading_a_host_watching_a_job_and_enqueueing_a_recipe_pass() {
    passes("stado space report lukasz-macbook");
    passes("stado job watch 5e0f --follow");
    passes("stado queue budget");
    passes("stado release resume 05e9e047");
    passes("stado release submit --help");
}

/// The suite, the lint and the check typed into a shell the minute an edit
/// landed. Writing the functionality ends with a commit and a push; the
/// build that carries the accumulated commits runs the suite once, and a
/// failure there reopens the task. Each refusal is held to the sentence that
/// says so, because that sentence is what a session reads instead of
