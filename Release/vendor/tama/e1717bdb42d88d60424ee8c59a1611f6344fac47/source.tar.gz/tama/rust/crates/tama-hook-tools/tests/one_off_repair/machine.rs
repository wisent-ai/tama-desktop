//! Services, credentials, binaries and hook files: the repairs that change
//! what a machine runs, and the reads beside each of them that must pass.




use crate::harness::{passes, refuses};


#[test]
fn a_service_cycled_by_hand_is_refused_with_the_stado_route() {
    refuses(
        "launchctl kickstart -k gui/501/ai.wisent.oko.transcript-index",
        "stado service restart",
    );
    refuses(
        "sudo launchctl bootout system/com.wisent.compute.service.transcript-lake",
        "stado service restart",
    );
    refuses("kill -TERM 40080 || true", "stado service restart");
    refuses("pkill -f transcript-lake", "stado service restart");
}

#[test]
fn reading_launchd_and_probing_a_process_pass() {
    passes("launchctl list | grep wisent");
    passes("launchctl print gui/501/ai.wisent.oko.transcript-index");
    passes("kill -0 4610 && echo alive");
    passes("grep -rn 'launchctl kickstart' ~/agents/operations.md");
}

#[test]
fn a_vault_write_past_stado_is_refused_with_the_stado_route() {
    refuses(
        "skarbiec grant ensure stado-release-client jeden-desktop-release-publisher --field token --token-file ~/.stado/x",
        "stado release catalog declare-publisher",
    );
    refuses(
        "skarbiec token-mint --consumer oko --capabilities read:x#token",
        "stado credentials token mint",
    );
}

#[test]
fn the_product_route_a_read_of_a_grant_and_its_help_pass() {
    passes("stado credentials token mint oko-judge --host charless-mac-mini --capabilities call:brama#best --audience oko");
    passes("stado service grant-sync brama --host mini --consumer oko --capability call:brama#best --token-file ~/.stado/t");
    passes("skarbiec grant verify stado-release-client jeden-release-publisher --action read");
    passes("skarbiec grant list --json");
    passes("skarbiec grant issue --help");
    passes("git commit -m 'refuse skarbiec grant ensure from the shell'");
}

#[test]
fn a_binary_copied_over_an_installed_one_is_refused_with_the_installer_route() {
    refuses(
        "cp .build/debug/oko-cli ~/.stado/bin/oko-cli",
        "oko-cli install",
    );
    refuses(
        "cp rust/target/release/tama-block-one-off-repairs $HOME/.local/bin/",
        "stado product update",
    );
    refuses(
        "install -m 755 target/release/stado /usr/local/bin/stado",
        "stado release install-local",
    );
}

#[test]
fn a_copy_out_of_the_install_root_and_a_build_copy_pass() {
    passes("cp ~/.stado/bin/oko-cli .build/oko-cli-before");
    passes("cp .build/release/oko-cli .build/dist/oko-cli");
    passes("ls -la ~/.local/bin | head");
}

/// On 2026-07-31 a session renamed a gate's own file, ran what it forbade and
/// renamed it back. The write gate reads write and edit payloads, not a shell
/// rename, so nothing refused it.
#[test]
fn a_hook_file_changed_from_the_shell_is_refused_with_the_enforcement_route() {
    refuses(
        "mv ~/.shared-hooks/block_browser_usage.sh ~/.shared-hooks/block_browser_usage.sh.paused",
        "tama enforcement only",
    );
    refuses(
        "rm -f ~/.shared-hooks/block_inline_execution.sh",
        "tama adaptive repair",
    );
    refuses(
        "chmod -x ~/.shared-hooks/pre_write_edit.sh",
        "tama hooks release",
    );
}

#[test]
fn a_read_of_a_hook_root_and_a_copy_out_of_one_pass() {
    passes("cat ~/.shared-hooks/registry.json");
    passes("ls -la ~/.shared-hooks");
    passes("cp ~/.shared-hooks/registry.json rust/target/registry-before.json");
    passes("tama enforcement status");
}

/// The last category Oko's detector counted with no gate behind it: five raw
/// SQL writes, none refused, against stores a product owns.
#[test]
fn a_row_written_by_hand_is_refused_with_the_owning_command() {
    refuses(
        "sqlite3 ~/.oko/index.sqlite \"UPDATE operator_ledgers SET messages = 9\"",
        "oko-cli transcripts reindex",
    );
    refuses(
        "psql -h db.example.co -U postgres -c 'insert into sessions(id) values (1)'",
        "migration",
    );
}

#[test]
fn a_query_and_a_schema_read_pass() {
    passes("sqlite3 ~/.oko/index.sqlite \"SELECT COUNT(*) FROM sessions\"");
    passes("sqlite3 ~/.oko/index.sqlite .schema");
    passes("psql --help");
}

/// The shapes `oko-cli transcripts one-offs --gate-check` reported on
/// 2026-09-20 as counted by the detector and refused by nothing.
#[test]
fn a_brew_service_an_adhoc_signature_and_a_store_write_are_refused() {
    refuses(
        "brew services restart postgresql@17",
        "stado service restart",
    );
    refuses(
        "codesign -f -s - .build/release/oko-cli",
        "stado release prepare",
    );
    refuses("redis-cli SET session:42 open", "owns those keys");
}

#[test]
fn reading_a_service_a_signature_or_a_store_passes() {
    passes("brew services list");
    passes("codesign -dv --verbose=4 ~/.stado/bin/stado");
    passes("codesign -s 'Developer ID Application: Wisent' .build/release/oko-cli");
    passes("redis-cli GET session:42");
    passes("redis-cli --help");
}

/// The last three shapes `oko-cli transcripts one-offs --gate-check` still
