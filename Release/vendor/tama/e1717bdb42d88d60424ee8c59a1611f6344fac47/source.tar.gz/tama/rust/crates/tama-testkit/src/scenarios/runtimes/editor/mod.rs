//! The editor scenarios: the four groups the live editor run is driven
//! through, built from the edit cases and the notebook cases.

use super::super::types::{EditorCase, EditorScenario};

mod cases;
mod notebook;

pub use cases::editor_edit_cases;
pub use notebook::{editor_notebook_cases, notebook_fixture_content, EDITOR_SAVE_GUARD, EDITOR_WATCHER};

/// JS `editorScenarios` from `orchestration.mjs`: the four cartesian groups.
pub fn editor_scenarios() -> Vec<EditorScenario> {
    let mut scenarios = Vec::new();
    for case in editor_edit_cases() {
        scenarios.push(EditorScenario {
            runtime: "editor-save-guard",
            coverage_key: support::coverage_key_opt(
                "editor-save-guard",
                "pre_tool_use:edit",
                case.hook_id,
                "pre_tool_use:edit",
            ),
            case,
        });
    }
    for case in editor_edit_cases() {
        scenarios.push(EditorScenario {
            runtime: "editor-watch-session",
            coverage_key: support::coverage_key_opt(
                "editor-watch-session",
                "pre_tool_use:edit",
                case.hook_id,
                "pre_tool_use:edit",
            ),
            case,
        });
    }
    for case in editor_notebook_cases() {
        let event = case.event.unwrap_or("pre_tool_use:edit");
        scenarios.push(EditorScenario {
            runtime: "editor-save-guard",
            coverage_key: support::coverage_key_opt(
                "editor-save-guard",
                event,
                case.hook_id,
                event,
            ),
            case,
        });
    }
    for case in editor_notebook_cases() {
        let event = case.event.unwrap_or("pre_tool_use:edit");
        scenarios.push(EditorScenario {
            runtime: "editor-watch-session",
            coverage_key: support::coverage_key_opt(
                "editor-watch-session",
                event,
                case.hook_id,
                event,
            ),
            case,
        });
    }
    scenarios
}
