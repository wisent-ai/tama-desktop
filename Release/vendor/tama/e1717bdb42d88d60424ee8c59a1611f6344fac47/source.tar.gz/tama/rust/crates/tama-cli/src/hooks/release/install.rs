//! Building every named hook from published main, installing the ones that
//! changed, then staging, sealing and installing the live release.
//!
//! Kept apart from the command itself so that reading what `tama hooks
//! release` refuses is not the same as reading how a machine is brought up to
//! the release it should be running.

use std::path::{Path, PathBuf};

use super::binaries::{
    build_digest, install, installed_digests, needs_install, python, record_digests, sign_built,
};
use super::support::{enforce_selection, export_main};
use super::super::declare::{refuse, run};
use super::super::warm;
use super::{provenance_line, BUILD_DIR, CLI_PROGRAM, EXPORT_DIR, RUNTIME_PROGRAMS, SPOKEN_NAME, STAGE_DIR};

pub(super) fn build_and_install(root: &Path, binaries: &[String], enforce: &[String]) -> i32 {
    let export = root.join(EXPORT_DIR);
    if let Err(error) = export_main(root, &export) {
        return refuse(&error);
    }
    let build = root.join(BUILD_DIR);
    let cargo = vec![
        "build".to_string(),
        "--manifest-path".to_string(),
        export.join("rust/Cargo.toml").display().to_string(),
        "--release".to_string(),
        "-p".to_string(),
        "tama-hook-tools".to_string(),
        "-p".to_string(),
        "tama-cli".to_string(),
        "-p".to_string(),
        "tama-run-hook".to_string(),
        "--target-dir".to_string(),
        build.display().to_string(),
    ];
    if let Err(error) = run(
        Path::new("/usr/bin/env"),
        &[vec!["cargo".to_string()], cargo].concat(),
        root,
    ) {
        return refuse(&error);
    }
    let _ = std::fs::remove_dir_all(&export);
    let home = PathBuf::from(std::env::var("HOME").unwrap_or_default());
    let mut programs: Vec<String> = binaries.to_vec();
    for name in RUNTIME_PROGRAMS {
        if !programs.iter().any(|known| known == name) {
            programs.push((*name).to_string());
        }
    }
    // What each installed binary was built from, and what this build holds.
    // A signature is not byte-stable, so the installed copy cannot be
    // compared against the built one; the unsigned build is what identifies
    // a release, and the previous one is on record.
    let recorded = installed_digests(&home);
    let mut digests = recorded.clone();
    let mut to_install: Vec<String> = Vec::new();
    let mut missing: Vec<&String> = Vec::new();
    for name in &programs {
        let built = build.join("release").join(name);
        let Some(digest) = build_digest(&built) else {
            if binaries.iter().any(|known| known == name) {
                missing.push(name);
            }
            continue;
        };
        let target = home.join(".local/bin").join(name);
        if needs_install(&recorded, name, &digest, target.is_file()) {
            to_install.push(name.clone());
        }
        digests.insert(name.clone(), digest);
    }
    // The CLI is installed under the name the product's own sentences tell an
    // operator to type, from the same build: on 2026-09-21 one of them ran
    // `tama` in their own terminal and got `zsh: command not found`.
    let spoken_current = recorded
        .get(SPOKEN_NAME)
        .zip(digests.get(CLI_PROGRAM))
        .is_some_and(|(known, built)| known == built)
        && home.join(".local/bin").join(SPOKEN_NAME).is_file();
    if !spoken_current {
        if let Some(digest) = digests.get(CLI_PROGRAM).cloned() {
            digests.insert(SPOKEN_NAME.to_string(), digest);
        }
    }
    let mut installed = 0usize;
    let mut to_sign: Vec<PathBuf> = Vec::new();
    for name in &to_install {
        let built = build.join("release").join(name);
        let target = home.join(".local/bin").join(name);
        if let Err(error) = install(&built, &target) {
            return refuse(&error);
        }
        installed += 1;
        to_sign.push(target.clone());
        println!("installed: {}", target.display());
    }
    for name in &missing {
        println!("not a tama-hook-tools binary, left alone: {name}");
    }
    let spoken = home.join(".local/bin").join(SPOKEN_NAME);
    let built_cli = build.join("release").join(CLI_PROGRAM);
    if !spoken_current && built_cli.is_file() {
        if let Err(error) = install(&built_cli, &spoken) {
            return refuse(&error);
        }
        to_sign.push(spoken.clone());
        println!("installed: {}", spoken.display());
    }
    // Signed where it now lives, never before the copy. A signature made in
    // the build tree does not survive the install: on 2026-09-21 the kernel
    // read the copied pages as tainted and killed `tama-cli` at every exec —
    // `CODE SIGNING: rejecting invalid page … sending SIGKILL` — while
    // `codesign -v` still called the same file valid on disk.
    match sign_built(root, &to_sign) {
        Ok(0) => println!("nothing to sign: every installed binary is this build"),
        Ok(signed) => println!("signed {signed} installed binaries with the tama identity"),
        Err(error) => return refuse(&error),
    }
    if let Err(error) = record_digests(&home, &digests) {
        return refuse(&error);
    }
    // An installed copy run from the operator's own prompt has no checkout
    // under it and no build tree left; without this it reports every hook as
    // uninstalled. What was installed, and from where, is recorded here.
    let recorded = home.join(crate::cli::INSTALLED_CHECKOUT_FILE);
    if let Some(parent) = recorded.parent() {
        if let Err(error) = std::fs::create_dir_all(parent) {
            return refuse(&format!("cannot create {}: {error}", parent.display()));
        }
    }
    if let Err(error) = std::fs::write(&recorded, format!("{}\n", root.display())) {
        return refuse(&format!("cannot write {}: {error}", recorded.display()));
    }
    // Counted over every program this run considered, not over the hook
    // binaries alone: the runtime programs are installed from the same list,
    // so subtracting them from the hook count underflowed and the release
    // ended in `attempt to subtract with overflow` after installing them.
    let already_current = programs.len().saturating_sub(installed + missing.len());
    println!("programs: {installed} installed, {already_current} already current");
    // A binary nobody has run yet still owes the operating system its first
    // assessment, and a hook pays that debt inside a live event, where it
    // reads as a timeout and blocks the turn. Paying it here is the whole
    // reason this step exists; a cold or unusable binary is reported, and
    // reporting is enough, because the release itself succeeded.
    let registry = root.join("shared-hooks/registry.json");
    let mut to_warm = warm::registry_hooks(&registry);
    for name in RUNTIME_PROGRAMS {
        let path = home.join(".local/bin").join(name);
        if path.is_file() {
            to_warm.push(warm::runtime_binary(name, path));
        }
    }
    let warmed = warm::warm_hooks(root, &to_warm);
    let _ = warm::report(&warmed, false);
    let stage = root.join(STAGE_DIR);
    let _ = std::fs::remove_dir_all(&stage);
    let staged = vec!["--destination".to_string(), stage.display().to_string()];
    match python(root, "stage_live_hook_release.py", &staged) {
        Ok(said) => println!("staged: {}", said.lines().last().unwrap_or_default()),
        Err(error) => return refuse(&error),
    }
    match python(root, "seal_hook_release.py", &[stage.display().to_string()]) {
        Ok(said) => println!("sealed: {}", said.lines().last().unwrap_or_default()),
        Err(error) => return refuse(&error),
    }
    let installer = vec![
        "--release".to_string(),
        stage.display().to_string(),
        "--home".to_string(),
        home.display().to_string(),
        "--session-control-only".to_string(),
    ];
    match python(root, "install_hook_release.py", &installer) {
        Ok(said) => println!(
            "installed release: {}",
            said.lines().last().unwrap_or_default()
        ),
        Err(error) => return refuse(&error),
    }
    // The release just installed is a second set of files, and the engine
    // runs those, not the ones warmed above: warming only `~/.local/bin` is
    // how block-unprompted-topics came to be killed at ten seconds inside a
    // live stop event (defect 359667bc).
    let sealed = warm::release_hooks(&home);
    if !sealed.is_empty() {
        let warmed = warm::warm_hooks(root, &sealed);
        let _ = warm::report(&warmed, false);
    }
    if let Some(provenance) = provenance_line() {
        println!("{provenance}");
    }
    enforce_selection(root, enforce)
}
