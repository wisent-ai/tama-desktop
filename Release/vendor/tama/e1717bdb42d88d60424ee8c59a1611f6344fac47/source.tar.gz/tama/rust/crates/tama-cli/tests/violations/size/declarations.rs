//! What a capture is, and what a declaration covers: a folder of recordings is
//! not a layout somebody chose, a build name inside a source tree is still our
//! work, and a declared directory covers its whole tree.

use serde_json::Value;
use std::fs;

use crate::fixture::{Fixture, LIMIT};

/// counted — while the modules beside it still are.
#[test]
fn captured_evidence_is_not_a_crowded_folder() {
    let f = Fixture::new();
    fs::create_dir(f.repo.join("journey")).unwrap();
    fs::write(f.repo.join("journey/official-recording.mp4"), "frames\n").unwrap();
    for state in 1..9 {
        fs::write(
            f.repo.join("journey").join(format!("state-0{state}.png")),
            "pixels\n",
        )
        .unwrap();
    }
    fs::create_dir(f.repo.join("mixed")).unwrap();
    for name in ["a", "b", "c", "d"] {
        fs::write(
            f.repo.join("mixed").join(format!("{name}.js")),
            "// source\n",
        )
        .unwrap();
    }
    for shot in 1..9 {
        fs::write(
            f.repo.join("mixed").join(format!("shot-{shot}.PNG")),
            "pixels\n",
        )
        .unwrap();
    }
    fs::create_dir(f.repo.join("dense")).unwrap();
    for name in ["a", "b", "c", "d", "e", "f"] {
        fs::write(
            f.repo.join("dense").join(format!("{name}.js")),
            "// source\n",
        )
        .unwrap();
    }

    for mode in [vec!["--json"], vec!["--json", "--size-only"]] {
        let out = f.run("scan", "find-violations", &mode);
        let report: Value = serde_json::from_slice(&out.stdout).unwrap();
        let paths: Vec<&str> = report["repos"][0]["violations"]
            .as_array()
            .unwrap()
            .iter()
            .map(|hit| hit["path"].as_str().unwrap_or_default())
            .collect();
        assert!(paths.contains(&"dense"), "{mode:?} {report}");
        assert!(!paths.contains(&"journey"), "{mode:?} {report}");
        assert!(!paths.contains(&"mixed"), "{mode:?} {report}");
    }
}

/// A folder named for a build system is build output at a package root and
/// product code inside a source tree. Stado writes its coverage orchestrator
/// at `src/coverage` and the command that prints it at
/// `src/cli/space/coverage`; this audit read both as build output and
/// exempted thirty-one hand-written modules from both size rules while
/// printing "vendored or build-output dir" beside each of them.
#[test]
fn a_build_name_inside_a_source_tree_is_still_audited() {
    let f = Fixture::new();
    let long = "// source row\n".repeat(LIMIT + 1);
    fs::create_dir_all(f.repo.join("src/coverage")).unwrap();
    fs::write(f.repo.join("src/coverage/orchestrator.rs"), &long).unwrap();
    fs::create_dir_all(f.repo.join("crates/engine/src/build")).unwrap();
    fs::write(f.repo.join("crates/engine/src/build/plan.rs"), &long).unwrap();
    fs::create_dir_all(f.repo.join("target/debug")).unwrap();
    fs::write(f.repo.join("target/debug/generated.rs"), &long).unwrap();
    fs::create_dir_all(f.repo.join("web/dist")).unwrap();
    fs::write(f.repo.join("web/dist/bundle.js"), &long).unwrap();

    for mode in [vec!["--json"], vec!["--json", "--size-only"]] {
        let out = f.run("scan", "find-violations", &mode);
        let report: Value = serde_json::from_slice(&out.stdout).unwrap();
        let paths: Vec<&str> = report["repos"][0]["violations"]
            .as_array()
            .unwrap()
            .iter()
            .map(|hit| hit["path"].as_str().unwrap_or_default())
            .collect();
        assert!(
            paths.contains(&"src/coverage/orchestrator.rs"),
            "{mode:?} {report}"
        );
        assert!(
            paths.contains(&"crates/engine/src/build/plan.rs"),
            "{mode:?} {report}"
        );
        assert!(
            !paths.contains(&"target/debug/generated.rs"),
            "{mode:?} {report}"
        );
        assert!(!paths.contains(&"web/dist/bundle.js"), "{mode:?} {report}");
    }
}

/// A declared directory covers its tree whether or not whoever wrote the
/// line ended it with a slash.
///
/// `echo-web` declared `applications/feng-sciezka-smart/source` for the
/// grant call's own published PDFs and result lists. The line reads exactly
/// right and sits in the file the documentation names, and it excluded
/// nothing: the audit went on ordering three documents the funding body
/// published to be split into modules.
#[test]
fn a_declared_directory_covers_its_tree_without_a_trailing_slash() {
    let f = Fixture::new();
    let long = "// source row\n".repeat(LIMIT + 1);
    fs::create_dir_all(f.repo.join("sources/call")).unwrap();
    fs::write(f.repo.join("sources/call/results.txt"), &long).unwrap();
    fs::write(f.repo.join("kept.js"), &long).unwrap();
    fs::create_dir(f.repo.join(".tama")).unwrap();
    fs::write(
        f.repo.join(".tama/violations-ignore"),
        "# what the funding body published\nsources\n",
    )
    .unwrap();

    for mode in [vec!["--json"], vec!["--json", "--size-only"]] {
        let out = f.run("scan", "find-violations", &mode);
        let report: Value = serde_json::from_slice(&out.stdout).unwrap();
        let paths: Vec<&str> = report["repos"][0]["violations"]
            .as_array()
            .unwrap()
            .iter()
            .map(|hit| hit["path"].as_str().unwrap_or_default())
            .collect();
        assert!(paths.contains(&"kept.js"), "{mode:?} {report}");
        assert!(
            !paths.contains(&"sources/call/results.txt"),
            "{mode:?} {report}"
        );
    }
}
