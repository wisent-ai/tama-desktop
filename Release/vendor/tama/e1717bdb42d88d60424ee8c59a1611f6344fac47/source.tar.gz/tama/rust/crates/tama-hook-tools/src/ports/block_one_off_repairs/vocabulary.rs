//! What the programs this gate reads accept, read from `vocabulary.json`, and
//! the small readings every refusal shares: the command a payload carries, the
//! program a command line actually runs, and whether a path lies under a root
//! the fleet owns.

use std::collections::BTreeMap;
use std::sync::LazyLock;

use serde::Deserialize;
use serde_json::Value;

use crate::ports::pyvalue::{first_truthy_py_str, py_str, truthy};
use crate::ports::shell_text;
use crate::ports::tool_vocabulary::{COMMAND_KEYS, TOOL_INPUT_KEY};

pub(super) const HELP_FLAG: &str = "--help";
pub(super) const FLAG_PREFIX: char = '-';
pub(super) const PATH_SEPARATOR: char = '/';
/// The word a package manager puts its script name after, so the refusal can
/// quote `npm run test:context` rather than `npm run`.
pub(super) const SCRIPT_RUNNER_VERB: &str = "run";
/// What names a tree even when the command line names no path: the long flag,
/// and the letters that mean the same inside a cluster such as `-rn`.
pub(super) const RECURSIVE_LONG_FLAG: &str = "--recursive";
pub(super) const RECURSIVE_LETTERS: [char; 2] = ['r', 'R'];
pub(super) const LONG_FLAG_PREFIX: &str = "--";
pub(super) const LAUNCHCTL: &str = "launchctl";
pub(super) const SYSTEMCTL: &str = "systemctl";
pub(super) const SKARBIEC: &str = "skarbiec";
pub(super) const SKARBIEC_GRANT: &str = "grant";
pub(super) const LINK_PROGRAM: &str = "ln";
pub(super) const SYMLINK_FLAG_PREFIX: &str = "-s";
pub(super) const USERS_PREFIX: &str = "/Users/";

pub(super) const BANNER: &str = "BLOCKED: one-off repair by hand. ";
pub(super) const SERVICE_ROUTE: &str = "the managed unit's own path is `stado service restart <NAME>` or `stado service refresh-image <LABEL> --if-needed`; a unit that must change is redeclared with `stado service deploy|update`.";
pub(super) const BREW: &str = "brew";
pub(super) const BREW_SERVICES: &str = "services";
pub(super) const CODESIGN: &str = "codesign";
pub(super) const ADHOC_SIGN_FLAG: &str = "-s";
pub(super) const ADHOC_IDENTITY: &str = "-";

/// What the programs this gate reads accept, from `vocabulary.json`. A field
/// the file spells differently is refused at first use rather than read as
/// an empty list that matches nothing.
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub(super) struct Vocabulary {
    /// Prose for a reader of the file; the gate does not read it.
    #[allow(dead_code)]
    pub(super) about: String,
    /// `launchctl` verbs that change what runs; `list`, `print`, `blame`
    /// only read.
    pub(super) launchctl_cycle: Vec<String>,
    pub(super) systemctl_cycle: Vec<String>,
    pub(super) kill_programs: Vec<String>,
    /// `kill -0 <pid>` asks whether a process exists and `kill -l` lists
    /// signal names; every other invocation ends or changes a process.
    pub(super) kill_read_flags: Vec<String>,
    /// `grant list`, `grant show` and `grant verify` read; these write.
    pub(super) skarbiec_grant_writes: Vec<String>,
    pub(super) skarbiec_writes: Vec<String>,
    pub(super) copy_programs: Vec<String>,
    /// Where installed executables live. A copy whose last argument is under
    /// one of these replaces an installed program; one whose source is there
    /// copies it out, which is a read.
    pub(super) install_roots: Vec<String>,
    pub(super) home_prefixes: Vec<String>,
    /// Programs that change a file rather than read it. A hook's own file
    /// renamed, removed or made unexecutable from the shell is a gate turned
    /// off, whatever the intent.
    pub(super) hook_write_programs: Vec<String>,
    /// Where the hooks this machine runs live: the shared sources, the
    /// installed runtime release, and the provider hook directories.
    pub(super) hook_roots: Vec<String>,
    /// Database clients. Their statements arrive as a quoted argument, which
    /// the shell reading blanks, so the original command is consulted for
    /// them — and only once the parsed program is one of these.
    pub(super) sql_programs: Vec<String>,
    /// Statements that change rows or shape. `select`, `explain`, `\dt` and
    /// `.schema` read.
    pub(super) sql_write_statements: Vec<String>,
    /// `brew services <verb>` cycles a service the same way `launchctl` does;
    /// `brew services list` reads.
    pub(super) brew_service_verbs: Vec<String>,
    /// Key-value stores whose command is a bare argument rather than a quoted
    /// statement, so the parsed words are enough to read them.
    pub(super) store_programs: Vec<String>,
    /// Store commands that change what is held. `get`, `keys`, `info` read.
    pub(super) store_write_commands: Vec<String>,
    /// Programs that change a machine setting: `defaults`, `plutil` and the
    /// rest read as well as write, so the verb decides.
    pub(super) setting_programs: Vec<String>,
    pub(super) setting_write_verbs: Vec<String>,
    /// A scratch directory made outside the repository's build tree.
    pub(super) scratch_programs: Vec<String>,
    /// Where the operator's own state lives. A shell redirect that lands
    /// here rewrites it under the product that owns it.
    pub(super) operator_state_roots: Vec<String>,
    /// Programs that pass time instead of observing an outcome.
    pub(super) wait_programs: Vec<String>,
    /// Programs whose whole job is to kill another command at a guessed
    /// number of seconds. The shell reading steps over them to find what a
    /// line runs, so they are refused by name.
    pub(super) deadline_wrappers: Vec<String>,
    /// Programs that search a tree from the shell. A search typed once
    /// answers the person typing it and leaves nothing any later reader or
    /// any product surface can use.
    pub(super) search_programs: Vec<String>,
    /// The subset of those that read their input from a pipe when the command
    /// line names no path: `launchctl list | grep wisent` filters what the
    /// previous command printed and searches no tree at all.
    pub(super) stream_search_programs: Vec<String>,
    /// The fleet's own CLI, whose subcommands are read as two words.
    pub(super) fleet_program: String,
    /// Fleet commands that change one host once when a declaration owns the
    /// outcome, keyed by the two words that name them, valued by the route.
    pub(super) fleet_one_off_commands: BTreeMap<String, String>,
    /// Drivers whose first word after the program says what it does:
    /// `cargo test`, `swift build`, `npm run build`. Keyed by the program,
    /// valued by the words that build or test with it.
    pub(super) build_drivers: BTreeMap<String, Vec<String>>,
    /// Programs whose every invocation is a build, whatever the arguments.
    pub(super) build_programs: Vec<String>,
    /// Where a build and its verdict belong instead.
    pub(super) build_route: String,
    /// The Rust toolchain's own driver, whose subcommand is read as one word.
    pub(super) toolchain_program: String,
    /// Toolchain commands that answer only the shell that typed them, keyed
    /// by the subcommand, valued by where the same answer is produced and
    /// kept for everyone.
    pub(super) toolchain_one_off_commands: BTreeMap<String, String>,
}

pub(super) static VOCABULARY: LazyLock<Vocabulary> = LazyLock::new(|| {
    serde_json::from_str(include_str!("vocabulary.json"))
        .expect("vocabulary.json is the gate's own data")
});

pub(super) fn has(list: &[String], word: &str) -> bool {
    list.iter().any(|item| item == word)
}

pub(super) fn command_from(payload: &Value) -> String {
    let Some(raw) = payload.get(TOOL_INPUT_KEY).filter(|value| truthy(value)) else {
        return String::new();
    };
    if raw.is_object() {
        let named = first_truthy_py_str(raw, COMMAND_KEYS);
        if !named.is_empty() {
            return named;
        }
    }
    py_str(raw)
}

pub(super) fn basename(token: &str) -> &str {
    token.rsplit(PATH_SEPARATOR).next().unwrap_or(token)
}

/// The program one command runs and the words after it, with the program's
/// directory dropped and `env`, `sudo`, `nohup`, `timeout` stepped over.
pub(super) fn program_and_args(tokens: &[String]) -> Option<(&str, &[String])> {
    let program = shell_text::program(tokens)?;
    let start = tokens.iter().position(|token| basename(token) == program)?;
    Some((program, &tokens[start + 1..]))
}

pub(super) fn is_flag(word: &str) -> bool {
    word.starts_with(FLAG_PREFIX)
}

pub(super) fn asks_for_help(args: &[String]) -> bool {
    args.iter().any(|arg| arg == HELP_FLAG)
}
/// are compared without it.
pub(super) fn without_home(path: &str) -> &str {
    if let Some(prefix) = VOCABULARY
        .home_prefixes
        .iter()
        .find(|prefix| path.starts_with(prefix.as_str()))
    {
        return &path[prefix.len()..];
    }
    if let Some(rest) = path.strip_prefix(USERS_PREFIX) {
        return rest
            .find(PATH_SEPARATOR)
            .map(|at| &rest[at..])
            .unwrap_or_default();
    }
    path
}

pub(super) fn under_install_root(path: &str) -> bool {
    let relative = without_home(path);
    VOCABULARY.install_roots.iter().any(|root| {
        relative
            .strip_prefix(root.as_str())
            .is_some_and(|rest| rest.is_empty() || rest.starts_with(PATH_SEPARATOR))
    })
}

/// A binary signed with the ad-hoc identity, which is no identity.
///
/// `codesign -f -s - <binary>` makes a signature that says nothing about who
/// built it and that no notarised release carries. Oko counted it under
/// `binary-copy` from the start and nothing refused it: a locally re-signed

pub(super) fn under_hook_root(path: &str) -> bool {
    let relative = without_home(path);
    VOCABULARY
        .hook_roots
        .iter()
        .any(|root| relative.starts_with(root.as_str()))
}

/// The quoted arguments of the original command, in order.
///
/// The shell reading blanks quoted text so that a mention of a command is
/// never a command, and a database statement is exactly that: a quoted
/// argument. It is read here only after the parsed program is a database
/// client, so a sentence that contains the word `psql` still runs nothing.
pub(super) fn quoted(raw: &str) -> Vec<String> {
    let mut out: Vec<String> = Vec::new();
    let mut current = String::new();
    let mut quote: Option<char> = None;
    for character in raw.chars() {
        match (quote, character) {
            (None, '\'') | (None, '"') => quote = Some(character),
            (Some(open), _) if character == open => {
                out.push(std::mem::take(&mut current));
                quote = None;
            }
            (Some(_), _) => current.push(character),
            (None, _) => {}
        }
    }
    out
}

