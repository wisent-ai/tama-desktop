//! The running driver process: a real node hosting the OMP adapter, spoken to
//! over its own standard input and output.
#![allow(dead_code)]

use std::io::{BufRead, BufReader, Write};
use std::path::Path;
use std::process::{Child, ChildStdin, ChildStdout, Command, Stdio};

use serde_json::Value;

/// A running `node` driver process hosting the OMP adapter.
pub struct Driver {
    child: Child,
    stdin: ChildStdin,
    stdout: BufReader<ChildStdout>,
}

impl Driver {
    pub fn spawn(driver_path: &Path, adapter_path: &Path) -> Result<Self, String> {
        let mut child = Command::new("node")
            .arg(driver_path)
            .arg(adapter_path)
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            // The adapter writes malfunction diagnostics to stderr; like the
            // JS harness, let them flow through to our own stderr.
            .stderr(Stdio::inherit())
            .spawn()
            .map_err(|e| format!("spawn node {}: {e}", driver_path.display()))?;
        let stdin = child.stdin.take().unwrap_or_else(|| unreachable!());
        let stdout = BufReader::new(child.stdout.take().unwrap_or_else(|| unreachable!()));
        Ok(Self {
            child,
            stdin,
            stdout,
        })
    }

    /// Send one request, read one response. A driver-level `error` field is
    /// the equivalent of the awaited call throwing in the JS test.
    pub fn request(&mut self, payload: &Value) -> Result<Value, String> {
        let mut line = serde_json::to_string(payload).map_err(|e| e.to_string())?;
        line.push('\n');
        self.stdin
            .write_all(line.as_bytes())
            .and_then(|()| self.stdin.flush())
            .map_err(|e| format!("driver request: {e}"))?;
        let mut response = String::new();
        let read = self
            .stdout
            .read_line(&mut response)
            .map_err(|e| format!("driver response: {e}"))?;
        if read == 0 {
            return Err("driver exited without a response".to_string());
        }
        let value: Value = serde_json::from_str(&response)
            .map_err(|e| format!("driver response is not JSON: {e}: {response}"))?;
        if let Some(error) = value.get("error") {
            let message = error
                .as_str()
                .map(str::to_string)
                .unwrap_or_else(|| error.to_string());
            return Err(message);
        }
        Ok(value)
    }

    pub fn shutdown(mut self) {
        drop(self.stdin);
        let _ = self.child.wait();
    }
}
