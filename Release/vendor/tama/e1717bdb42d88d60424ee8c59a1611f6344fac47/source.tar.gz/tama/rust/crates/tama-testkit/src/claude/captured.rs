//! The captured tool scenario: the tool call the run recorded, and the failure
//! details Claude wrote beside it when the call was refused.

use std::path::Path;

use crate::json::Json;
use crate::orchestration::Ctx;
use crate::scenarios::ClaudeScenario;
use crate::support;

use super::running::*;

/// `tool_use_id == None` models JS `undefined` (matches everything).
fn claude_tool_failure_details(
    entries: &[Json],
    tool_name: &str,
    tool_use_id: Option<&Json>,
) -> String {
    let mut permission_denials: Vec<Json> = Vec::new();
    for entry in entries {
        for denial in entry
            .get("permission_denials")
            .and_then(Json::as_array)
            .unwrap_or(&[])
        {
            if denial.get("tool_name").and_then(Json::as_str) == Some(tool_name) {
                let mut object = vec![];
                if let Some(value) = denial.get("tool_name") {
                    object.push(("tool_name".to_string(), value.clone()));
                }
                if let Some(value) = denial.get("tool_input") {
                    object.push(("tool_input".to_string(), value.clone()));
                }
                permission_denials.push(Json::obj(object));
            }
        }
    }
    let mut tool_results: Vec<Json> = Vec::new();
    for entry in entries {
        for content in entry
            .get("message")
            .and_then(|m| m.get("content"))
            .and_then(Json::as_array)
            .unwrap_or(&[])
        {
            // `content.type === 'tool_result' && (!toolUseId || content.tool_use_id === toolUseId)`
            if content.get("type").and_then(Json::as_str) != Some("tool_result") {
                continue;
            }
            if let Some(id) = tool_use_id {
                if content.get("tool_use_id") != Some(id) {
                    continue;
                }
            }
            let mut object = vec![];
            if let Some(value) = content.get("tool_use_id") {
                object.push(("tool_use_id".to_string(), value.clone()));
            }
            if let Some(value) = content.get("is_error") {
                object.push(("is_error".to_string(), value.clone()));
            }
            object.push((
                "content".to_string(),
                Json::str(support::tail(&json::js_string_or_empty(
                    content.get("content"),
                ))),
            ));
            tool_results.push(Json::obj(object));
        }
    }
    let final_result = entries
        .iter()
        .find(|entry| entry.get("type").and_then(Json::as_str) == Some("result"));
    let final_json = match final_result {
        Some(entry) => {
            let mut object = vec![];
            for key in ["subtype", "is_error", "stop_reason", "terminal_reason"] {
                if let Some(value) = entry.get(key) {
                    object.push((key.to_string(), value.clone()));
                }
            }
            object.push((
                "result".to_string(),
                Json::str(support::tail(&json::js_string_or_empty(
                    entry.get("result"),
                ))),
            ));
            Json::obj(object).to_compact()
        }
        None => "null".to_string(),
    };
    format!(
        "permissionDenials={}; toolResults={}; result={final_json}",
        Json::arr(permission_denials).to_compact(),
        Json::arr(tool_results).to_compact(),
    )
}

/// JS `runClaudeCapturedToolScenario(scenario)`.
pub fn run_claude_captured_tool_scenario(
    scenario: &ClaudeScenario,
    ctx: &Ctx,
) -> Result<Json, String> {
    let id = scenario.id.unwrap_or("undefined");
    let tmp = support::make_live_runtime_temp(&format!("claude-{id}-"))?;
    let outcome = run_claude_captured_inner(&tmp, scenario, ctx);
    if !ctx.keep_artifacts {
        support::rm_force(&tmp);
    }
    outcome
}

fn run_claude_captured_inner(
    tmp: &Path,
    scenario: &ClaudeScenario,
    ctx: &Ctx,
) -> Result<Json, String> {
    let id = scenario.id.unwrap_or("undefined");
    let tool_name = scenario.tool_name.unwrap_or("undefined");
    let event = scenario.event.unwrap_or("undefined");
    git_codex::init_git_repo(tmp)?;
    if let Some(prepare) = scenario.prepare {
        prepare(tmp)?;
    }
    let command = claude_command(
        &ctx.claude_live_model,
        scenario.allowed_tools.unwrap_or("undefined"),
        scenario.prompt.unwrap_or("undefined"),
    );
    let result = run_claude(&command, tmp);
    let entries = support::parse_json_lines_from_text(&result.stdout);
    let tool_use = entries
        .iter()
        .flat_map(|entry| assistant_contents(entry).iter().collect::<Vec<_>>())
        .find(|content| {
            if content.get("type").and_then(Json::as_str) != Some("tool_use")
                || content.get("name").and_then(Json::as_str) != Some(tool_name)
            {
                return false;
            }
            // `!scenario.toolUseMatch || scenario.toolUseMatch(content.input || {})`
            match scenario.tool_use_match {
                None => true,
                Some(matcher) => {
                    let empty = Json::obj(vec![]);
                    let input = match content.get("input") {
                        Some(value) if value.truthy() => value,
                        _ => &empty,
                    };
                    matcher(input)
                }
            }
        })
        .cloned();
    let covered_keys = codex::covered_keys_from_claude_entries(&ctx.root, &entries)?;
    let required = codex::required_keys_for(&ctx.root, "claude", scenario.event)?;
    if let Some(signal) = &result.signal {
        return Err(format!(
            "real Claude {id} runtime timed out or was terminated: {signal}"
        ));
    }
    let tool_use = match tool_use {
        Some(value) => value,
        None => {
            return Err(format!(
                "Claude stream-json did not include expected {tool_name} tool_use; stdoutTail={}; stderrTail={}",
                support::tail(&result.stdout),
                support::tail(&result.stderr)
            ))
        }
    };
    if !required.iter().all(|key| covered_keys.contains(key)) {
        return Err(format!(
            "Claude {id} did not cover all {event} hooks; covered={}; {}; stdoutTail={}; stderrTail={}",
            Json::arr(covered_keys.iter().cloned().map(Json::Str).collect()).to_compact(),
            claude_tool_failure_details(&entries, tool_name, tool_use.get("id")),
            support::tail(&result.stdout),
            support::tail(&result.stderr)
        ));
    }
    if let Some(assert_after) = scenario.assert_after {
        if let Err(error) = assert_after(tmp) {
            return Err(format!(
                "Claude {id} side effect assertion failed: {error}; {}",
                claude_tool_failure_details(&entries, tool_name, tool_use.get("id"))
            ));
        }
    }
    Ok(Json::obj(vec![
        ("ok".to_string(), Json::Bool(true)),
        ("runtime".to_string(), Json::str("claude")),
        ("hook".to_string(), Json::str(id)),
        (
            "coverageKey".to_string(),
            Json::str(scenario.coverage_key.clone()),
        ),
        (
            "coveredKeys".to_string(),
            Json::arr(covered_keys.into_iter().map(Json::Str).collect()),
        ),
        (
            "command".to_string(),
            Json::arr(command.iter().cloned().map(Json::Str).collect()),
        ),
        (
            "runtimeExitStatus".to_string(),
            match result.status {
                Some(code) => Json::num_i64(code as i64),
                None => Json::Null,
            },
        ),
        ("blocked".to_string(), Json::Bool(false)),
        ("payloadCaptured".to_string(), Json::Bool(true)),
    ]))
}
