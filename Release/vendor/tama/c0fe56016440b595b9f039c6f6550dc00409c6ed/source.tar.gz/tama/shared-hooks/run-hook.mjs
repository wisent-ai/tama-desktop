#!/usr/bin/env node

import { spawn } from 'node:child_process'
import { homedir } from 'node:os'
import { dirname, join } from 'node:path'

// This process transports the provider event; the native engine owns policy.
const installedStatePath = process.env.TAMA_INSTALLED_HOOK_RELEASE || join(
  homedir(), 'Library', 'Application Support', 'Tama', 'hooks-runtime', 'installed.json',
)
const executable = join(dirname(installedStatePath), 'current', 'bin', 'tama-run-hook')
const child = spawn(executable, process.argv.slice(2), { stdio: 'inherit' })
const forward = signal => {
  if (!child.killed) child.kill(signal)
}
const interrupt = () => forward('SIGINT')
const terminate = () => forward('SIGTERM')
process.on('SIGINT', interrupt)
process.on('SIGTERM', terminate)
child.on('error', error => {
  process.stderr.write(`TAMA_HOOK_INFRASTRUCTURE: ${executable}: ${error.message}\n`)
  process.exitCode = 1
})
child.on('close', (code, signal) => {
  process.removeListener('SIGINT', interrupt)
  process.removeListener('SIGTERM', terminate)
  if (signal) process.kill(process.pid, signal)
  else process.exitCode = code !== null && code >= 0 ? code : 1
})
