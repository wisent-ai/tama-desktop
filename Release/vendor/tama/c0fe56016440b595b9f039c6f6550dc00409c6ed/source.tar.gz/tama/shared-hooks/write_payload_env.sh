#!/bin/bash
# Shared PreToolUse Write/Edit payload preamble.
#
# The write limits used to live inside pre_write_edit.sh, so they could only
# be enforced or dropped together with every other rule in that script. Each
# limit is its own hook now, and each one needs the same three facts about the
# payload, so the extraction lives here instead of being copied three times.
# Sourced, never run on its own: the caller reads the payload on stdin.
#
# Sets: INPUT, TOOL, FILE_PATH, CONTENT, IS_SYSTEM, WC_CMD. A payload naming
# no file exits the caller cleanly.

WC_CMD=/usr/bin/wc

INPUT=$(cat)
TOOL=$(echo "$INPUT" | jq -r '.tool_name // empty')
FILE_PATH=$(echo "$INPUT" | jq -r '.tool_input.file_path // empty')

if [[ -z "$FILE_PATH" ]]; then exit 0; fi

# === Skip system directories for content checks ===
IS_SYSTEM=false
if echo "$FILE_PATH" | grep -qE '(node_modules|\.git/|\.github/workflows/|/scripts/worker/deploy/|\.next|__pycache__|/\.claude/|/\.factory/|/\.codex/|/\.shared-hooks/|/chromium-build/)'; then
    IS_SYSTEM=true
fi

# === Extract content ===
CONTENT=""
# Codex apply_patch uses .patch or .new_string; Claude/Droid use .content / .new_string
if [[ "$TOOL" == "Write" || "$TOOL" == "Create" ]]; then
    CONTENT=$(echo "$INPUT" | jq -r '.tool_input.content // empty')
elif [[ "$TOOL" == "Edit" || "$TOOL" == "apply_patch" ]]; then
    CONTENT=$(echo "$INPUT" | jq -r '.tool_input.new_string // .tool_input.patch // empty')
fi
