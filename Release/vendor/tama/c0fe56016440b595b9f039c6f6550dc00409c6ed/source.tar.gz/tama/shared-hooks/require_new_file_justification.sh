#!/bin/bash
# New file justification: a new file needs a 50+ word entry keyed by its
# absolute path in ~/.shared-hooks/file_justifications.json.
#
# Moved verbatim out of pre_write_edit.sh. It is its own hook so it can be
# left out of the machine selection while the file-line and folder-file
# limits from that same script stay enforced. The code is kept, not deleted:
# `tama enforcement only <ids>` decides whether it runs.
set -euo pipefail

source "$(dirname "$0")/write_payload_env.sh"

if [[ ! -f "$FILE_PATH" && "$IS_SYSTEM" == "false" ]]; then
    REGISTRY="$HOME/.shared-hooks/file_justifications.json"
    if [[ -f "$REGISTRY" ]]; then
        JUST=$(jq -r --arg p "$FILE_PATH" '.[$p].justification // empty' "$REGISTRY" 2>/dev/null)
        WC=$(echo "$JUST" | $WC_CMD -w | tr -d ' ')
        if [[ -z "$JUST" || "$WC" -lt 50 ]]; then
            echo "BLOCKED: Need 50+ word justification in ~/.shared-hooks/file_justifications.json for new file: $FILE_PATH" >&2
            exit 2
        fi
    else
        echo "BLOCKED: Need 50+ word justification in ~/.shared-hooks/file_justifications.json for new file: $FILE_PATH" >&2
        exit 2
    fi
fi

exit 0
