#!/usr/bin/env node
// Add one hook occurrence to the registry, then reseal it.
//
// Usage: node register-hook.mjs <id> <event> <command> [timeout]
//
// The catalog entry is taken from catalog-metadata.json, so description and
// side effects stay in one place. The writer uses the same canonical checksum
// contract as seal-registry.mjs and replaces the registry atomically.

import { chmod, readFile, rename, rm, stat, writeFile } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const here = dirname(fileURLToPath(import.meta.url))

function stableValue(value) {
  if (Array.isArray(value)) return value.map(stableValue)
  if (!value || typeof value !== 'object') return value
  return Object.fromEntries(Object.keys(value).sort().map(key => [key, stableValue(value[key])]))
}

function registryChecksum(registry) {
  const value = { ...registry }
  delete value.catalogChecksum
  return createHash('sha256').update(JSON.stringify(stableValue(value))).digest('hex')
}

try {
const positional = process.argv.slice(Number('2'))
const [id, event, command] = positional
const timeoutArg = positional.at(Number('3'))?.startsWith('--') ? null : positional.at(Number('3'))
if (!id || !event || !command) {
  process.stderr.write(
    'Usage: register-hook.mjs <id> <event> <command> [timeout] [--remove] [--registry <path>]\n'
    + 'Default registry is the source registry in this directory, not the deployed one:\n'
    + 'a deployed registry resealed by hand desynchronises from hooks-runtime/installed.json.\n',
  )
  process.exit(Number('2'))
}
const timeout = Number(timeoutArg || Number('10'))
if (!Number.isInteger(timeout) || timeout < Number('1') || timeout > Number('3600')) {
  process.stderr.write('timeout must be an integer from 1 through 3600 seconds\n')
  process.exit(Number('2'))
}

const registryFlag = process.argv.indexOf('--registry')
if (registryFlag !== Number('0') - Number('1')) {
  const value = process.argv[registryFlag + Number('1')]
  if (!value || value.startsWith('--')) {
    process.stderr.write('--registry requires a path\n')
    process.exit(Number('2'))
  }
}
const registryPath = registryFlag === Number('0') - Number('1')
  ? join(here, 'registry.json')
  : process.argv[registryFlag + Number('1')]
const registryStat = await stat(registryPath)
const registry = JSON.parse(await readFile(registryPath, 'utf8'))
const metadata = JSON.parse(await readFile(join(here, 'catalog-metadata.json'), 'utf8'))
const removing = process.argv.includes('--remove')
const meta = metadata[id] || {}
if (!metadata[id] && !removing) {
  process.stderr.write(`catalog-metadata.json has no entry for ${id}\n`)
  process.exit(Number('2'))
}

const entry = registry.events?.[event]
if (!entry) {
  process.stderr.write(`registry has no event ${event}\n`)
  process.exit(Number('2'))
}


// The source registry keeps its catalog in catalog.agentHooks with repository
// paths; the deployed registry keeps a flat hooks array with release paths.
// Preserve whichever shape the target already uses.
const sourceShape = Array.isArray(registry.catalog?.agentHooks)
const catalog = sourceShape ? registry.catalog.agentHooks : (registry.hooks || [])

const eventIndex = (entry.hooks || []).findIndex(hook => hook.id === id)
const catalogIndex = catalog.findIndex(hook => hook.id === id)
const existingCatalogEntry = catalogIndex < Number('0') ? null : catalog[catalogIndex]
const registeredCommands = Object.values(registry.events || {})
  .flatMap(config => config.hooks || [])
  .filter(hook => hook.id === id)
  .map(hook => hook.command)
  .filter(Boolean)
if (!removing && registeredCommands.some(registered => registered !== command)) {
  process.stderr.write(`hook ${id} is already registered with a different command\n`)
  process.exit(Number('2'))
}

if (removing) {
  entry.hooks = (entry.hooks || []).filter(hook => hook.id !== id)
} else if (eventIndex < Number('0')) {
  entry.hooks.push({ command, id, timeout, type: 'command' })
}

const registeredOccurrences = Object.entries(registry.events || {}).flatMap(([eventName, config]) =>
  (config.hooks || [])
    .filter(hook => hook.id === id)
    .map(hook => ({
      blocking: Boolean(config.blocking),
      event: eventName,
      statusMessage: hook.statusMessage ?? meta.statusMessage ?? null,
      timeout: hook.timeout ?? null,
      hook,
    })),
)
const kept = catalog.filter(hook => hook.id !== id)
if (registeredOccurrences.length) {
  const primary = registeredOccurrences.at(Number('0')).hook
  const commandSource = primary.command.split(' ').at(Number('0') - Number('1'))
  const executable = commandSource.split('/').at(Number('0') - Number('1'))
  const sourceStem = executable.startsWith('tama-')
    ? executable.slice('tama-'.length).replaceAll('-', '_')
    : executable.replace(/\.(?:c?js|mjs|py|sh)$/, '')
  const sourceCandidates = [
    ...registeredOccurrences.map(occurrence => occurrence.hook.source).filter(Boolean),
    ...['py', 'sh', 'mjs', 'js'].map(extension => join(here, `${sourceStem}.${extension}`)),
    join(
      here,
      '..',
      'rust',
      'crates',
      'tama-hook-tools',
      'src',
      'bin',
      `${sourceStem}.rs`,
    ),
    commandSource,
  ]
  let catalogSource = sourceCandidates.at(Number('0') - Number('1'))
  for (const candidate of sourceCandidates) {
    if (await stat(candidate).then(() => true, () => false)) {
      catalogSource = candidate
      break
    }
  }
  const catalogEntry = {
    ...(existingCatalogEntry || {}),
    id,
    aliases: existingCatalogEntry?.aliases ?? [],
    category: meta.category ?? existingCatalogEntry?.category,
    command: primary.command,
    description: meta.description ?? existingCatalogEntry?.description,
    occurrences: registeredOccurrences.map(occurrence => ({
      blocking: occurrence.blocking,
      event: occurrence.event,
      statusMessage: occurrence.statusMessage,
      timeout: occurrence.timeout,
    })),
    sideEffects: meta.sideEffects ?? existingCatalogEntry?.sideEffects,
    source: existingCatalogEntry?.source ?? catalogSource,
    status: meta.status ?? existingCatalogEntry?.status,
    why: meta.why ?? existingCatalogEntry?.why,
  }
  if (catalogIndex < Number('0')) kept.push(catalogEntry)
  else kept.splice(catalogIndex, Number('0'), catalogEntry)
}

if (sourceShape) registry.catalog.agentHooks = kept
else registry.hooks = kept

registry.catalogChecksum = registryChecksum(registry)
const temporaryPath = `${registryPath}.tama-${process.pid}`
try {
  await writeFile(
    temporaryPath,
    `${JSON.stringify(registry, null, Number('2'))}\n`,
    { encoding: 'utf8', mode: registryStat.mode },
  )
  await chmod(temporaryPath, registryStat.mode)
  await rename(temporaryPath, registryPath)
} catch (error) {
  await rm(temporaryPath, { force: true }).catch(() => {})
  throw error
}
process.stdout.write(`${removing ? 'removed' : 'registered'} ${id} on ${event}\n  seal ${registry.catalogChecksum}\n`)
} catch (error) {
  const message = error instanceof Error ? error.message : String(error)
  const limit = Number('2048')
  const boundedMessage = message.length > limit ? `${message.slice(Number('0'), limit)}…` : message
  process.stderr.write(`hook registry mutation failed: ${boundedMessage}\n`)
  process.exitCode = Number('1')
}
