import { createHash, randomUUID } from 'node:crypto'
import {
  chmodSync,
  mkdirSync,
  readFileSync,
  renameSync,
  rmSync,
  writeFileSync,
} from 'node:fs'
import { homedir } from 'node:os'
import { basename, join } from 'node:path'
import { normalizedCapability } from './session-capability.mjs'
import { loadHookEnforcement, shouldEnforceHook } from './enforcement-selection.mjs'

export const SESSION_CONTROL_SCHEMA = 'ai.wisent.tama.session-control.v2'
const EMERGENCY_STATE_SCHEMA = 'ai.wisent.tama.hook-emergency-state.v1'
const DEFAULT_HEARTBEAT_TTL_SECONDS = 900

function tamaStateRoot() {
  if (process.platform === 'darwin') {
    return join(homedir(), 'Library', 'Application Support', 'Tama')
  }
  if (process.platform === 'win32') {
    return join(process.env.LOCALAPPDATA || join(homedir(), 'AppData', 'Local'), 'Tama')
  }
  return join(process.env.XDG_STATE_HOME || join(homedir(), '.local', 'state'), 'tama')
}

export const sessionControlRoot = process.env.TAMA_SESSION_CONTROL_ROOT
  || join(tamaStateRoot(), 'session-control')

const emergencyStatePath = process.env.TAMA_EMERGENCY_STATE
  || join(tamaStateRoot(), 'hook-emergency-state.json')

function loadJson(path, fallback = null) {
  try {
    return JSON.parse(readFileSync(path, 'utf8'))
  } catch {
    return fallback
  }
}

function atomicWriteJson(path, value) {
  mkdirSync(sessionControlRoot, { recursive: true, mode: 0o700 })
  chmodSync(sessionControlRoot, 0o700)
  const temporary = `${path}.${process.pid}.${randomUUID()}.tmp`
  try {
    writeFileSync(temporary, `${JSON.stringify(value)}\n`, { mode: 0o600, flag: 'wx' })
    renameSync(temporary, path)
  } finally {
    rmSync(temporary, { force: true })
  }
}

function normalizedAgentId(value) {
  const agentId = String(value || '').trim().toLowerCase()
  return /^[a-z][a-z0-9-]{0,31}$/.test(agentId) ? agentId : null
}

function nestedValues(payload) {
  return [payload, payload?.raw_event, payload?.session].filter(
    value => value && typeof value === 'object' && !Array.isArray(value),
  )
}

function normalizedResumeArgv(value) {
  if (typeof value === 'string') {
    try {
      return normalizedResumeArgv(JSON.parse(value))
    } catch {
      return null
    }
  }
  if (!Array.isArray(value) || value.length === 0) return null
  if (!value.every(item => typeof item === 'string' && item.length > 0)) return null
  return [...value]
}

export function sessionResumeArgv(payload = null) {
  for (const value of nestedValues(payload)) {
    const candidate = value.resume_argv
      || value.resumeArgv
      || value.restart_argv
      || value.restartArgv
    const normalized = normalizedResumeArgv(candidate)
    if (normalized) return normalized
  }
  return normalizedResumeArgv(process.env.TAMA_SESSION_RESUME_ARGV_JSON)
}

function sessionIdFromPayload(payload) {
  for (const value of nestedValues(payload)) {
    const explicit = value.session_id
      || value.sessionId
      || value.conversation_id
      || value.conversationId
      || value.thread_id
      || value.threadId
      || value.id
    if (explicit) return String(explicit).trim()
  }
  for (const value of nestedValues(payload)) {
    const transcript = value.transcript_path || value.transcriptPath
    if (!transcript) continue
    const name = basename(String(transcript)).replace(/\.jsonl$/, '')
    const match = name.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i)
    if (match) return match[0]
  }
  return null
}

function cwdFromPayload(payload) {
  for (const value of nestedValues(payload)) {
    const cwd = value.cwd || value.project_dir || value.projectDir
    if (cwd) return String(cwd)
  }
  return process.cwd()
}

function numericEnvironment(name) {
  const value = Number(process.env[name] || '')
  return Number.isSafeInteger(value) && value > 0 ? value : null
}

function processIsAlive(pid) {
  try {
    process.kill(pid, 0)
    return true
  } catch (error) {
    return error?.code === 'EPERM'
  }
}

export function hooksGloballyDisabled() {
  const state = loadJson(emergencyStatePath)
  return state?.schema === EMERGENCY_STATE_SCHEMA && state.disabled === true
}

export function sessionContext(agentIdValue, payload) {
  const agentId = normalizedAgentId(agentIdValue)
  const sessionId = sessionIdFromPayload(payload)
  if (!agentId || !sessionId) return null
  return {
    agentId,
    sessionId,
    controlKey: createHash('sha256').update(`${agentId}\0${sessionId}`).digest('hex'),
    cwd: cwdFromPayload(payload),
  }
}

function cleanHookIds(value, knownHookIds) {
  if (!Array.isArray(value)) return []
  return [...new Set(value.map(id => String(id).trim()).filter(id => (
    id && (!knownHookIds || knownHookIds.has(id))
  )))].sort()
}

// A new emergency disable invalidates preceding session grants. Only exact
// enables bound to its changedAt generation may run while it remains active.
export function readSessionOverride(context, knownHookIds = null) {
  const empty = { enabledHookIds: [], capability: null, emergencyChangedAt: null }
  if (!context) return empty
  const value = loadJson(join(sessionControlRoot, `${context.controlKey}.override.json`))
  if (
    value?.schema !== SESSION_CONTROL_SCHEMA
    || value.agentId !== context.agentId
    || value.sessionId !== context.sessionId
    || value.controlKey !== context.controlKey
  ) {
    return empty
  }
  const emergency = loadJson(emergencyStatePath)
  if (emergency?.schema === EMERGENCY_STATE_SCHEMA && emergency.disabled === true) {
    if (
      typeof emergency.changedAt !== 'string'
      || !emergency.changedAt.trim()
      || value.emergencyChangedAt !== emergency.changedAt
    ) return empty
  }
  return {
    enabledHookIds: cleanHookIds(value.enabledHookIds, knownHookIds),
    capability: normalizedCapability(value.capability, context.sessionId),
    emergencyChangedAt: value.emergencyChangedAt || null,
  }
}

export function isSessionHookEnabled(
  context,
  hookId,
  knownHookIds = null,
  selection = loadHookEnforcement(),
  overrides = readSessionOverride(context, knownHookIds),
) {
  return shouldEnforceHook(hookId, selection, {
    globallyDisabled: hooksGloballyDisabled(),
    sessionEnabledHookIds: overrides.enabledHookIds,
  })
}

export function publishSession(
  context,
  knownHookIds = null,
  payload = null,
  selection = loadHookEnforcement(),
) {
  if (!context) return null
  const overrides = readSessionOverride(context, knownHookIds)
  const ownerPid = numericEnvironment('TAMA_SESSION_OWNER_PID')
  const hasLiveOwner = ownerPid !== null && processIsAlive(ownerPid)
  const heartbeatTTLSeconds = numericEnvironment('TAMA_SESSION_HEARTBEAT_TTL_SECONDS')
    || DEFAULT_HEARTBEAT_TTL_SECONDS
  const resumeArgv = sessionResumeArgv(payload)
  const state = {
    schema: SESSION_CONTROL_SCHEMA,
    agentId: context.agentId,
    sessionId: context.sessionId,
    controlKey: context.controlKey,
    pid: hasLiveOwner ? ownerPid : 0,
    cwd: context.cwd,
    livenessMode: hasLiveOwner ? 'process' : 'heartbeat',
    heartbeatTTLSeconds,
    globallyDisabled: hooksGloballyDisabled(),
    enforcementMode: selection.mode,
    machineEnabledHookIds: selection.enabledHookIds,
    disabledHookIds: [],
    enabledHookIds: overrides.enabledHookIds,
    emergencyChangedAt: overrides.emergencyChangedAt,
    capability: overrides.capability,
    ...(payload?.semantic_runtime ? { semanticRuntime: payload.semantic_runtime } : {}),
    ...(payload?.system_policy && typeof payload.system_policy === 'object' && !Array.isArray(payload.system_policy)
      ? { systemPolicy: payload.system_policy }
      : {}),
    ...(resumeArgv ? { resumeArgv } : {}),
    updatedAt: new Date().toISOString(),
  }
  atomicWriteJson(join(sessionControlRoot, `${context.controlKey}.session.json`), state)
  return state
}
