//! Streamed job endpoints: violation scan and clean, each mirroring the
//! corresponding CLI command as NDJSON log events plus one final result
//! event whose status mirrors the command's exit code.

use std::net::TcpStream;
use std::path::Path;

use serde_json::Value;
use tama_violations::clean::{clean_repo, clean_summary_lines, CleanJsonOutput, CleanParams};
use tama_violations::scan_repos::{parse_scan_args, run_scan, scan_json_document};

use super::http::{json_body, send_error, stream_job, Request};

/// `tama find-violations --repo <path> --json` as a streamed job. The usage
/// rejections the command exits 2 on are 400 envelopes here, sent before the
/// stream starts.
pub(super) fn scan_job(request: Request, root: &Path, writer: &mut TcpStream) {
    let body = match json_body(&request) {
        Ok(body) => body,
        Err((status, message)) => return send_error(writer, status, &message),
    };
    let repo = body
        .get("repo")
        .and_then(Value::as_str)
        .unwrap_or("")
        .to_string();
    let argv = vec!["--repo".to_string(), repo.clone(), "--json".to_string()];
    let Some(args) = parse_scan_args(&argv, root) else {
        return send_error(writer, 400, "scan requires a repo path");
    };
    if !Path::new(&args.hook_path).exists() {
        return send_error(writer, 400, &format!("hook not found: {}", args.hook_path));
    }
    if !Path::new(&repo).exists() {
        return send_error(writer, 400, &format!("repo not found: {repo}"));
    }
    stream_job(writer, |emit| {
        let (reports, problems) = run_scan(&args, |line| emit("stderr", &format!("{line}\n")));
        let total: usize = reports.iter().map(|report| report.violations.len()).sum();
        let document = scan_json_document(&reports, &problems);
        let status = if total > 0 || !problems.is_empty() {
            1
        } else {
            0
        };
        (status, serde_json::to_value(&document).unwrap_or_default())
    });
}

/// `tama clean --repo <path>` with the command's defaults (Codex, three
/// rounds, no skip list, no note) as a streamed job: the repair screen is
/// deliberately one shape, so the endpoint takes no knobs.
pub(super) fn clean_job(request: Request, root: &Path, writer: &mut TcpStream) {
    if std::env::var("TAMA_CLEAN_DISABLED").as_deref() == Ok("1") {
        return send_error(
            writer,
            403,
            "tama clean is disabled (TAMA_CLEAN_DISABLED=1)",
        );
    }
    let body = match json_body(&request) {
        Ok(body) => body,
        Err((status, message)) => return send_error(writer, status, &message),
    };
    let repo = body
        .get("repo")
        .and_then(Value::as_str)
        .unwrap_or("")
        .to_string();
    if repo.is_empty() {
        return send_error(writer, 400, "clean requires a repo path");
    }
    let hook = root.join("shared-hooks").join("pre_write_edit.sh");
    if !hook.exists() {
        return send_error(writer, 400, &format!("hook not found: {}", hook.display()));
    }
    if !Path::new(&repo).exists() {
        return send_error(writer, 400, &format!("repo not found: {repo}"));
    }
    let hook_path = hook.to_string_lossy().into_owned();
    stream_job(writer, |emit| {
        emit(
            "stderr",
            &format!("[clean] {repo}: starting repair rounds\n"),
        );
        let result = clean_repo(&CleanParams {
            repo: &repo,
            hook_path: &hook_path,
            model: tama_violations::clean::DEFAULT_ROUTE,
            // f64::from(3) is the exact 3.0 default spelled without a bare
            // numeric literal.
            max_rounds: f64::from(3),
            dry_run: false,
            skip: &[],
            note: None,
            root,
        });
        for line in clean_summary_lines(&result) {
            emit("stdout", &format!("{line}\n"));
        }
        let unresolved = result.clean == Some(false) || result.locked == Some(true);
        let document = CleanJsonOutput {
            results: std::slice::from_ref(&result),
            problems: &[],
        };
        let status = if unresolved { 1 } else { 0 };
        (status, serde_json::to_value(&document).unwrap_or_default())
    });
}
