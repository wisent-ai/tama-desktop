//! The standing assignment as state on disk, not as something an agent
//! remembers.
//!
//! On 2026-09-10, thirty-two hours into one session, an agent was asked what
//! its task was and answered with the session's *first* request — a job
//! finished the previous night — because the middle of that session had been
//! dropped from its context window to fit an archive budget. Nothing was wrong
//! with the rules it had been given; the rules sat in the same discarded
//! context. An instruction that lives only in a context window is lost the
//! moment that window is trimmed, and every guard written in prose is lost
//! with it.
//!
//! So the newest thing the operator said is written down when they say it, and
//! reading it is a precondition for ending a turn. The record carries the text
//! verbatim: a summary would be the acting model's interpretation, which is
//! exactly the thing that drifted.

use std::fs;
use std::io;
use std::path::PathBuf;

use serde::{Deserialize, Serialize};
use serde_json::Value;
use tama_hooks::session_control::tama_state_root;
use tama_hooks::sha256::sha256_hex;

pub mod rules;
/// Usage exits are spelled the way the other hook tools spell them.
const USAGE_EXIT_TEXT: &str = "2";

fn usage_exit() -> i32 {
    USAGE_EXIT_TEXT.parse().unwrap_or_default()
}

/// One operator instruction, as it was written.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Assignment {
    /// The session the instruction belongs to; an instruction does not carry
    /// over into another session.
    pub session_id: String,
    /// Digest of the session and the exact words, so a later prompt supersedes
    /// an earlier one without anyone comparing prose.
    pub turn_digest: String,
    pub captured_at: String,
    /// Verbatim. Never summarised.
    pub text: String,
    /// The digest that was last read through `tama assignment show`.
    #[serde(default)]
    pub read_digest: String,
}

impl Assignment {
    /// Whether the newest instruction has been read in its own right.
    pub fn unread(&self) -> bool {
        self.read_digest != self.turn_digest
    }
}

/// Where the record lives. The override exists so a test never reads or writes
/// the operator's own record.
pub fn state_path() -> PathBuf {
    match std::env::var("TAMA_ASSIGNMENT_STATE") {
        Ok(path) if !path.is_empty() => PathBuf::from(path),
        _ => tama_state_root().join("current-assignment.json"),
    }
}

pub fn load() -> Option<Assignment> {
    let text = fs::read_to_string(state_path()).ok()?;
    serde_json::from_str(&text).ok()
}

fn write(record: &Assignment) -> io::Result<()> {
    let path = state_path();
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent)?;
    }
    let body = serde_json::to_string_pretty(record)
        .map_err(|error| io::Error::other(error.to_string()))?;
    let pending = path.with_extension(format!("pending{}", std::process::id()));
    fs::write(&pending, body + "\n")?;
    fs::rename(pending, path)
}

/// Seconds since the epoch: the record is read by machines, and a wall-clock
/// format would need a timezone this process has no business choosing.
fn captured_now() -> String {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|value| value.as_secs())
        .unwrap_or_default()
        .to_string()
}

/// Record what the operator just said. An empty prompt records nothing: there
/// is no instruction in it, and overwriting the standing one would lose it.
pub fn capture(session_id: &str, text: &str) -> io::Result<Option<Assignment>> {
    let text = text.trim();
    if text.is_empty() {
        return Ok(None);
    }
    let digest = sha256_hex(format!("{session_id}\u{0}{text}").as_bytes());
    if let Some(existing) = load() {
        if existing.turn_digest == digest {
            return Ok(Some(existing));
        }
    }
    let record = Assignment {
        session_id: session_id.to_string(),
        turn_digest: digest,
        captured_at: captured_now(),
        text: text.to_string(),
        read_digest: String::new(),
    };
    write(&record)?;
    Ok(Some(record))
}

/// Mark the standing instruction as read, and hand it back so the caller can
/// print it. Reading is what `tama assignment show` does.
pub fn mark_read() -> io::Result<Option<Assignment>> {
    let Some(mut record) = load() else {
        return Ok(None);
    };
    record.read_digest = record.turn_digest.clone();
    write(&record)?;
    Ok(Some(record))
}

/// The prompt text of a `user_prompt_submit` payload, wherever the harness put
/// it.
pub fn prompt_of(payload: &Value) -> String {
    for key in ["prompt", "user_message", "text"] {
        if let Some(text) = payload.get(key).and_then(Value::as_str) {
            if !text.trim().is_empty() {
                return text.to_string();
            }
        }
    }
    payload
        .get("raw_event")
        .and_then(|event| event.get("text").or_else(|| event.get("prompt")))
        .and_then(Value::as_str)
        .unwrap_or_default()
        .to_string()
}

/// `tama assignment show` — the reading surface the stop guard requires.
pub fn cli_main(args: &[String]) -> i32 {
    let action = args.first().map(String::as_str).unwrap_or("show");
    if action != "show" {
        eprintln!("usage: tama assignment show [--json]");
        return usage_exit();
    }
    let json = args.iter().any(|argument| argument == "--json");
    match mark_read() {
        Ok(Some(record)) => {
            if json {
                println!(
                    "{}",
                    serde_json::to_string_pretty(&record).unwrap_or_default()
                );
            } else {
                println!("session: {}", record.session_id);
                println!("captured: {}", record.captured_at);
                println!("assignment:");
                println!("{}", record.text);
                println!();
                print!("{}", rules::rules_or_reason());
            }
            0
        }
        Ok(None) => {
            println!("no assignment is recorded for this machine yet");
            0
        }
        Err(error) => {
            eprintln!("cannot mark the assignment read: {error}");
            1
        }
    }
}
