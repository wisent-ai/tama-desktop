//! Deleting the copies a pass judged removable, and deciding whether it may.
//!
//! Split from [`super::discovery`] when one file carrying both halves crossed
//! the three-hundred-line limit `block-oversized-files` enforces. The seam is
//! meaningful rather than arithmetic: everything here mutates the filesystem
//! or decides whether it may be mutated, and nothing here walks a tree or
//! asks git about a candidate.

use std::collections::BTreeSet;
use std::fs;
use std::path::Path;

use super::discovery::{list_document, refusals, Copy, ListDocument, RemoveDocument};
use super::CommandError;
use crate::gitcmd::canonical;

/// Drops every `--except` copy from the pass before anything judges it: an
/// excepted copy that is dirty must not be able to refuse a pass it is not
/// part of. A value matching nothing is a usage error rather than a no-op,
/// because a pass the operator believed narrowed would otherwise remove
/// everything.
fn withhold(listed: &mut ListDocument, except: &[String]) -> Result<Vec<String>, CommandError> {
    if except.is_empty() {
        return Ok(Vec::new());
    }
    let mut excepted: BTreeSet<String> = BTreeSet::new();
    for wanted in except {
        let real = canonical(Path::new(wanted));
        let matched = listed
            .copies
            .iter()
            .any(|copy| canonical(Path::new(&copy.path)) == real);
        if !matched {
            return Err(CommandError::UnknownExcept(wanted.clone()));
        }
        excepted.insert(real.to_string_lossy().into_owned());
    }
    listed.copies.retain(|copy| {
        !excepted.contains(canonical(Path::new(&copy.path)).to_string_lossy().as_ref())
    });
    listed.copy_count = listed.copies.len();
    listed.bytes = listed.copies.iter().map(|copy| copy.bytes).sum();
    Ok(excepted.into_iter().collect())
}

/// Narrows the pass to exactly the paths `--only` names, and marks them as
/// named. A directory that is the sole checkout of its repository here is
/// refused by default because the pass cannot tell whether losing it loses
/// anything; an operator naming it answers exactly that question, and
/// nothing else — dirty, unpushed, origin-less and worktree-owning copies
/// are refused whether they were named or not.
fn narrow(listed: &mut ListDocument, only: &[String]) -> Result<(), CommandError> {
    if only.is_empty() {
        return Ok(());
    }
    let mut named: BTreeSet<String> = BTreeSet::new();
    for wanted in only {
        let real = canonical(Path::new(wanted));
        let matched = listed
            .copies
            .iter()
            .any(|copy| canonical(Path::new(&copy.path)) == real);
        if !matched {
            return Err(CommandError::UnknownOnly(wanted.clone()));
        }
        named.insert(real.to_string_lossy().into_owned());
    }
    listed.copies.retain_mut(|copy| {
        let hit = named.contains(canonical(Path::new(&copy.path)).to_string_lossy().as_ref());
        copy.named = hit;
        hit
    });
    listed.copy_count = listed.copies.len();
    listed.bytes = listed.copies.iter().map(|copy| copy.bytes).sum();
    Ok(())
}

/// The last checks before a directory is deleted, made against the
/// filesystem rather than the document: the reads behind that document are
/// minutes old by the time an operator types `--apply`.
fn remove_one(copy: &Copy, roots: &[String]) -> Result<(), CommandError> {
    let path = Path::new(&copy.path);
    let metadata = fs::symlink_metadata(path)
        .map_err(|error| CommandError::Operational(format!("{}: {error}", copy.path)))?;
    if metadata.file_type().is_symlink() {
        return Err(CommandError::Operational(format!(
            "{} is a symlink; this pass deletes directories, never links",
            copy.path
        )));
    }
    let real = canonical(path);
    if !roots
        .iter()
        .any(|root| real.starts_with(canonical(Path::new(root))))
    {
        return Err(CommandError::Operational(format!(
            "{} left the roots this pass was given",
            copy.path
        )));
    }
    fs::remove_dir_all(path)
        .map_err(|error| CommandError::Operational(format!("{}: {error}", copy.path)))
}

/// Nothing is deleted unless `apply` is set and the whole pass is free of
/// refusals — the same all-or-nothing rule the worktrees pass uses, so a
/// half-applied pass never has to be reasoned about afterwards.
pub(crate) fn remove_document(
    roots: &[String],
    except: &[String],
    only: &[String],
    apply: bool,
    force: bool,
) -> Result<RemoveDocument, CommandError> {
    let mut listed = list_document(roots)?;
    let excepted = withhold(&mut listed, except)?;
    narrow(&mut listed, only)?;
    let refused = refusals(&listed, force);
    let applied = apply && refused.is_empty();
    let mut removed: Vec<String> = Vec::new();
    if applied {
        for copy in &listed.copies {
            remove_one(copy, &listed.roots)?;
            removed.push(copy.path.clone());
        }
    }
    Ok(RemoveDocument {
        schema_version: listed.schema_version,
        roots: listed.roots,
        copies: listed.copies,
        copy_count: listed.copy_count,
        bytes: listed.bytes,
        linked_worktrees: listed.linked_worktrees,
        twins: listed.twins,
        unreadable: listed.unreadable,
        excepted,
        applied,
        removed,
        refused,
    })
}
