//! Port of `src/tests/live-runtime/runtimes/git-codex-support.mjs`.

use std::path::{Path, PathBuf};

use crate::json::{self, Json};
use crate::scenarios::{GitScenario, Pattern};
use crate::support::{self, RunOpts};

/// JS `setupGitConfig(repo)`.
pub fn setup_git_config(repo: &Path) -> Result<Json, String> {
    Ok(Json::obj(vec![(
        "targetPath".to_string(),
        Json::str(
            repo.join(".git")
                .join("config")
                .to_string_lossy()
                .into_owned(),
        ),
    )]))
}

/// JS `setupMissingHuskyPreCommit(repo)`.
pub fn setup_missing_husky_pre_commit(repo: &Path) -> Result<Json, String> {
    std::fs::create_dir_all(repo.join(".husky"))
        .map_err(|e| support::io_error_message("mkdir", &repo.join(".husky"), &e))?;
    Ok(Json::obj(vec![(
        "targetPath".to_string(),
        Json::str(
            repo.join(".husky")
                .join("pre-commit")
                .to_string_lossy()
                .into_owned(),
        ),
    )]))
}

/// JS `setupExistingHuskyPreCommit(repo)`.
#[allow(dead_code)]
pub fn setup_existing_husky_pre_commit(repo: &Path) -> Result<Json, String> {
    std::fs::create_dir_all(repo.join(".husky"))
        .map_err(|e| support::io_error_message("mkdir", &repo.join(".husky"), &e))?;
    let target_path = repo.join(".husky").join("pre-commit");
    support::write_file(&target_path, "#!/bin/sh\nexit 0\n")?;
    Ok(Json::obj(vec![(
        "targetPath".to_string(),
        Json::str(target_path.to_string_lossy().into_owned()),
    )]))
}

/// JS `initGitRepo(repo)`.
pub fn init_git_repo(repo: &Path) -> Result<(), String> {
    let result = support::run_in("git", &["init", "--quiet"], repo);
    if result.status != Some(0) {
        return Err(format!(
            "failed to initialize temp git repo: {}",
            result.stderr
        ));
    }
    let result = support::run_in(
        "git",
        &["config", "user.email", "live-hook@example.invalid"],
        repo,
    );
    if result.status != Some(0) {
        return Err(format!("failed to configure git email: {}", result.stderr));
    }
    let result = support::run_in("git", &["config", "user.name", "Live Hook Smoke"], repo);
    if result.status != Some(0) {
        return Err(format!("failed to configure git user: {}", result.stderr));
    }
    Ok(())
}

/// JS `assertGitHookPath(repo, hook)`.
pub fn assert_git_hook_path(repo: &Path, hook: &Json) -> Result<String, String> {
    let hooks_path = match hook.get("hooksPath").and_then(Json::as_str) {
        Some(path) if path.starts_with('/') => path.to_string(),
        _ => support::dirname(&json::js_string_opt(hook.get("source"))),
    };
    let result = support::run_in("git", &["config", "core.hooksPath", &hooks_path], repo);
    if result.status != Some(0) {
        return Err(format!(
            "failed to configure hooksPath {hooks_path}: {}",
            result.stderr
        ));
    }
    Ok(hooks_path)
}

fn opt_str(value: Option<&Json>) -> Option<String> {
    value.and_then(Json::as_str).map(str::to_string)
}

fn git_result_json(
    hook: &Json,
    coverage_key: &str,
    command: Vec<String>,
    hooks_path: &str,
    final_entries: Vec<(String, Json)>,
) -> Json {
    let mut entries = vec![
        ("ok".to_string(), Json::Bool(true)),
        ("runtime".to_string(), Json::str("git")),
    ];
    // `event: hook.event` — dropped by JSON.stringify when undefined.
    if let Some(event) = hook.get("event") {
        entries.push(("event".to_string(), event.clone()));
    }
    // `hook: hook.id` — dropped by JSON.stringify when undefined.
    if let Some(id) = hook.get("id") {
        entries.push(("hook".to_string(), id.clone()));
    }
    entries.push(("coverageKey".to_string(), Json::str(coverage_key)));
    entries.push((
        "coveredKeys".to_string(),
        Json::arr(vec![Json::str(coverage_key)]),
    ));
    entries.push((
        "command".to_string(),
        Json::arr(command.into_iter().map(Json::Str).collect()),
    ));
    if let Some(source) = hook.get("source") {
        entries.push(("hookSource".to_string(), source.clone()));
    }
    entries.push(("hooksPath".to_string(), Json::str(hooks_path)));
    entries.extend(final_entries);
    Json::obj(entries)
}

fn run_git_pre_commit_scenario(hook: &Json, keep_artifacts: bool) -> Result<Json, String> {
    let tmp = support::mkdtemp(&support::tmpdir().join("tama-live-git-pre-commit-"))?;
    let outcome = run_git_pre_commit_inner(&tmp, hook);
    if !keep_artifacts {
        support::rm_force(&tmp);
    }
    outcome
}

fn run_git_pre_commit_inner(tmp: &Path, hook: &Json) -> Result<Json, String> {
    init_git_repo(tmp)?;
    let hooks_path = assert_git_hook_path(tmp, hook)?;
    support::write_file(&tmp.join("staged.txt"), "staged\n")?;
    let result = support::run_in("git", &["add", "staged.txt"], tmp);
    if result.status != Some(0) {
        return Err(format!(
            "failed to stage pre-commit fixture: {}",
            result.stderr
        ));
    }
    support::write_file(&tmp.join("untracked.txt"), "untracked\n")?;
    let result = support::run(
        "git",
        &[
            "commit".to_string(),
            "-m".to_string(),
            "live pre-commit hook smoke".to_string(),
        ],
        &RunOpts {
            cwd: Some(tmp.to_path_buf()),
            timeout_ms: Some(30_000),
            ..RunOpts::default()
        },
    );
    let output = format!("{}\n{}", result.stdout, result.stderr);
    if result.status == Some(0) {
        return Err("real git pre-commit did not block dirty worktree".to_string());
    }
    if !output.contains("pre-commit blocked: worktree has unstaged or untracked files") {
        return Err(format!(
            "real git pre-commit did not report expected dirty-worktree block: {}",
            support::tail_n(&output, 1000)
        ));
    }
    let head = support::run_in("git", &["rev-parse", "--verify", "HEAD"], tmp);
    if head.status == Some(0) {
        return Err("blocked pre-commit still created a commit".to_string());
    }
    let event = opt_str(hook.get("event"));
    let hook_id = json::js_string_opt(hook.get("id"));
    let event_or_id = event.clone().unwrap_or_else(|| hook_id.clone());
    let coverage_key = support::coverage_key_opt("git", &event_or_id, &hook_id, &event_or_id);
    Ok(git_result_json(
        hook,
        &coverage_key,
        vec![
            "git".to_string(),
            "commit".to_string(),
            "-m".to_string(),
            "live pre-commit hook smoke".to_string(),
        ],
        &hooks_path,
        vec![
            ("blocked".to_string(), Json::Bool(true)),
            ("commitCreated".to_string(), Json::Bool(false)),
        ],
    ))
}

fn run_git_pre_push_scenario(hook: &Json, keep_artifacts: bool) -> Result<Json, String> {
    let tmp = support::mkdtemp(&support::tmpdir().join("tama-live-git-pre-push-"))?;
    let remote = support::mkdtemp(&support::tmpdir().join("tama-live-git-remote-"))?;
    let outcome = run_git_pre_push_inner(&tmp, &remote, hook);
    if !keep_artifacts {
        support::rm_force(&tmp);
        support::rm_force(&remote);
    }
    outcome
}

fn run_git_pre_push_inner(tmp: &Path, remote: &Path, hook: &Json) -> Result<Json, String> {
    init_git_repo(tmp)?;
    let result = support::run_in("git", &["init", "--bare", "--quiet"], remote);
    if result.status != Some(0) {
        return Err(format!(
            "failed to initialize temp remote: {}",
            result.stderr
        ));
    }
    support::write_file(&tmp.join("tracked.txt"), "tracked\n")?;
    let result = support::run_in("git", &["add", "tracked.txt"], tmp);
    if result.status != Some(0) {
        return Err(format!("failed to stage initial file: {}", result.stderr));
    }
    let result = support::run_in("git", &["commit", "-m", "initial"], tmp);
    if result.status != Some(0) {
        return Err(format!(
            "failed to create initial commit: {}",
            result.stderr
        ));
    }
    let remote_str = remote.to_string_lossy().into_owned();
    let result = support::run_in("git", &["remote", "add", "origin", &remote_str], tmp);
    if result.status != Some(0) {
        return Err(format!("failed to add temp remote: {}", result.stderr));
    }
    let hooks_path = assert_git_hook_path(tmp, hook)?;
    support::write_file(&tmp.join("dirty.txt"), "dirty\n")?;
    let result = support::run(
        "git",
        &[
            "push".to_string(),
            "origin".to_string(),
            "HEAD:refs/heads/main".to_string(),
        ],
        &RunOpts {
            cwd: Some(tmp.to_path_buf()),
            timeout_ms: Some(30_000),
            ..RunOpts::default()
        },
    );
    let output = format!("{}\n{}", result.stdout, result.stderr);
    if result.status == Some(0) {
        return Err("real git pre-push did not block dirty worktree".to_string());
    }
    if !output.contains("pre-push blocked: worktree has uncommitted or untracked files") {
        return Err(format!(
            "real git pre-push did not report expected dirty-worktree block: {}",
            support::tail_n(&output, 1000)
        ));
    }
    let pushed = support::run(
        "git",
        &[
            "--git-dir".to_string(),
            remote_str.clone(),
            "show-ref".to_string(),
            "--verify".to_string(),
            "refs/heads/main".to_string(),
        ],
        &RunOpts::default(),
    );
    if pushed.status == Some(0) {
        return Err("blocked pre-push still updated remote main".to_string());
    }
    let event = opt_str(hook.get("event"));
    let hook_id = json::js_string_opt(hook.get("id"));
    let event_or_id = event.clone().unwrap_or_else(|| hook_id.clone());
    let coverage_key = support::coverage_key_opt("git", &event_or_id, &hook_id, &event_or_id);
    Ok(git_result_json(
        hook,
        &coverage_key,
        vec![
            "git".to_string(),
            "push".to_string(),
            "origin".to_string(),
            "HEAD:refs/heads/main".to_string(),
        ],
        &hooks_path,
        vec![
            ("blocked".to_string(), Json::Bool(true)),
            ("remoteUpdated".to_string(), Json::Bool(false)),
        ],
    ))
}

/// JS `runGitHookScenario(scenario)`.
pub fn run_git_hook_scenario(scenario: &GitScenario, keep_artifacts: bool) -> Result<Json, String> {
    match scenario.hook.get("event").and_then(Json::as_str) {
        Some("pre-commit") => run_git_pre_commit_scenario(&scenario.hook, keep_artifacts),
        Some("pre-push") => run_git_pre_push_scenario(&scenario.hook, keep_artifacts),
        other => Err(format!(
            "no live git scenario for event {}",
            match other {
                Some(event) => event.to_string(),
                None => json::js_string_opt(scenario.hook.get("event")),
            }
        )),
    }
}

/// JS `unavailableRuntime(runtime, blocker, probes, affectedKeys)`.
pub fn unavailable_runtime(
    runtime: &str,
    blocker: &str,
    probes: Vec<Json>,
    affected_keys: Vec<String>,
) -> Json {
    Json::obj(vec![
        ("ok".to_string(), Json::Bool(false)),
        ("unavailableRuntime".to_string(), Json::Bool(true)),
        ("runtime".to_string(), Json::str(runtime)),
        ("blocker".to_string(), Json::str(blocker)),
        ("probes".to_string(), Json::arr(probes)),
        (
            "affectedKeys".to_string(),
            Json::arr(affected_keys.into_iter().map(Json::Str).collect()),
        ),
        (
            "error".to_string(),
            Json::str(format!(
                "{runtime} runtime unavailable before hook dispatch: {blocker}"
            )),
        ),
    ])
}

/// JS probe object from `codexProbe` / `codexRouterProbe`.
#[derive(Debug, Clone)]
pub struct Probe {
    pub command: Vec<String>,
    pub exit_status: Option<i32>,
    pub signal: Option<String>,
    pub timed_out: bool,
    pub stdout_tail: String,
    pub stderr_tail: String,
    pub output_tail: String,
    pub target_changed: bool,
    pub output: String,
    pub via_model_router: bool,
}

impl Probe {
    /// `{...probe, output: undefined}` — the probe object without `output`
    /// (which JSON.stringify would drop).
    pub fn to_json_without_output(&self) -> Json {
        let mut entries = vec![
            (
                "command".to_string(),
                Json::arr(self.command.iter().cloned().map(Json::Str).collect()),
            ),
            (
                "exitStatus".to_string(),
                match self.exit_status {
                    Some(code) => Json::num_i64(code as i64),
                    None => Json::Null,
                },
            ),
            (
                "signal".to_string(),
                match &self.signal {
                    Some(signal) => Json::str(signal.clone()),
                    None => Json::Null,
                },
            ),
            ("timedOut".to_string(), Json::Bool(self.timed_out)),
            (
                "stdoutTail".to_string(),
                Json::str(self.stdout_tail.clone()),
            ),
            (
                "stderrTail".to_string(),
                Json::str(self.stderr_tail.clone()),
            ),
            (
                "outputTail".to_string(),
                Json::str(self.output_tail.clone()),
            ),
            ("targetChanged".to_string(), Json::Bool(self.target_changed)),
        ];
        if self.via_model_router {
            entries.push(("viaModelRouter".to_string(), Json::Bool(true)));
        }
        Json::obj(entries)
    }
}

fn build_probe(
    command: Vec<String>,
    result: &support::RunResult,
    before: &str,
    after: &str,
    via_model_router: bool,
) -> Probe {
    let output = format!("{}\n{}", result.stdout, result.stderr);
    let timed_out = result.signal.as_deref() == Some("SIGTERM")
        || result.error_code.as_deref() == Some("ETIMEDOUT");
    Probe {
        command,
        exit_status: result.status,
        signal: result.signal.clone(),
        timed_out,
        stdout_tail: support::tail(&result.stdout),
        stderr_tail: support::tail(&result.stderr),
        output_tail: support::tail(&output),
        target_changed: before != after,
        output,
        via_model_router,
    }
}

/// JS `codexProbe(tmp, args, timeoutMs)`.
pub fn codex_probe(tmp: &Path, args: &[String], timeout_ms: u64) -> Result<Probe, String> {
    let target_path = tmp.join(".git").join("config");
    let before = support::read(&target_path)?;
    let result = support::run(
        "codex",
        args,
        &RunOpts {
            cwd: Some(tmp.to_path_buf()),
            timeout_ms: Some(timeout_ms),
            max_buffer: Some(10_485_760),
            ..RunOpts::default()
        },
    );
    let after = support::read(&target_path)?;
    let mut command = vec!["codex".to_string()];
    command.extend(args.iter().cloned());
    Ok(build_probe(command, &result, &before, &after, false))
}

/// JS `codexRouterProbe(tmp, prompt, timeoutMs)`.
pub fn codex_router_probe(tmp: &Path, prompt: &str, timeout_ms: u64) -> Result<Probe, String> {
    let target_path = tmp.join(".git").join("config");
    let before = support::read(&target_path)?;
    let model_router_root = support::model_router_root();
    let script = std::env::var("CODEX_MODEL_ROUTER_SIGNED_CHAT_SCRIPT")
        .ok()
        .filter(|v| !v.is_empty())
        .unwrap_or_else(|| {
            model_router_root
                .join("scripts")
                .join("signed-chat-from-weles-config.mjs")
                .to_string_lossy()
                .into_owned()
        });
    let model = std::env::var("CODEX_MODEL_ROUTER_MODEL")
        .ok()
        .filter(|v| !v.is_empty())
        .unwrap_or_else(|| "codex-subscription".to_string());
    let args = vec![
        script.clone(),
        "--model".to_string(),
        model.clone(),
        "--prompt".to_string(),
        prompt.to_string(),
        "--raw".to_string(),
    ];
    let result = support::run(
        &support::node_exec_path(),
        &args,
        &RunOpts {
            cwd: Some(model_router_root),
            timeout_ms: Some(timeout_ms),
            max_buffer: Some(10_485_760),
            ..RunOpts::default()
        },
    );
    let after = support::read(&target_path)?;
    let mut command = vec![support::node_exec_path()];
    command.extend(args.iter().cloned());
    Ok(build_probe(command, &result, &before, &after, true))
}

/// `/refresh token was already used|refresh_token_reused|401 Unauthorized|token_expired|wss:\/\/chatgpt\.com\/backend-api\/codex\/responses/`.
pub fn codex_auth_unavailable(output: &str) -> bool {
    [
        "refresh token was already used",
        "refresh_token_reused",
        "401 Unauthorized",
        "token_expired",
        "wss://chatgpt.com/backend-api/codex/responses",
    ]
    .iter()
    .any(|needle| output.contains(needle))
}

/// JS `codexProbeUnavailableReason(probe)`.
pub fn codex_probe_unavailable_reason(probe: &Probe) -> String {
    if probe.timed_out {
        return "runtime timed out before completing a tool call".to_string();
    }
    if codex_auth_unavailable(&probe.output) {
        return "cloud auth unavailable (refresh token reused / 401); re-auth via model-router/Weles required".to_string();
    }
    format!(
        "no hook block observed (exit={})",
        match probe.exit_status {
            Some(code) => code.to_string(),
            None => "null".to_string(),
        }
    )
}

/// JS `codexBlockedHookConfig(probe)`.
pub fn codex_blocked_hook_config(probe: &Probe) -> bool {
    if probe
        .output
        .contains("BLOCKED: hook source/config changes are device-level protected")
    {
        return true;
    }
    // /blocked by (a|the) local PreToolUse hook protecting hook configuration changes/i
    let lowered = probe.output.to_lowercase();
    if lowered.contains("blocked by a local pretooluse hook protecting hook configuration changes")
        || lowered
            .contains("blocked by the local pretooluse hook protecting hook configuration changes")
    {
        return true;
    }
    // /DEVICE_HOOK_EDIT_APPROVED=1.*outside the agent session/i
    Pattern {
        segments: vec!["device_hook_edit_approved=1", "outside the agent session"],
        case_insensitive: true,
        dotall: false,
    }
    .test(&probe.output)
}

/// JS `basenameFromHookCommand(command)` from git-codex-support.mjs (unlike
/// `basenameFromCommand` in core, it does not strip quotes).
pub fn basename_from_hook_command(command: &str) -> String {
    let parts: Vec<&str> = command.trim().split_whitespace().collect();
    let first = parts.first().copied().unwrap_or("");
    let script = parts
        .iter()
        .copied()
        .find(|part| {
            part.ends_with(".py")
                || part.ends_with(".sh")
                || part.ends_with(".mjs")
                || part.ends_with(".js")
        })
        .unwrap_or(first);
    script.rsplit('/').next().unwrap_or("").to_string()
}

/// JS `hookCommandsMatch(adapterCommand, registryCommand)`.
pub fn hook_commands_match(adapter_command: &str, registry_command: &str) -> bool {
    if adapter_command == registry_command {
        return true;
    }
    let adapter_base = basename_from_hook_command(adapter_command);
    let registry_base = basename_from_hook_command(registry_command);
    !adapter_base.is_empty() && !registry_base.is_empty() && adapter_base == registry_base
}

/// JS `codexCoverageKeysFromCommand(event, command)`.
pub fn codex_coverage_keys_from_command(
    root: &Path,
    event: &str,
    command: &str,
) -> Result<Vec<String>, String> {
    let registry = tama_core::runtime::load_registry(PathBuf::from(root).as_path())
        .map_err(|e| e.to_string())?;
    let empty = Vec::new();
    let hooks = registry
        .events
        .get(event)
        .map(|config| &config.hooks)
        .unwrap_or(&empty);
    Ok(hooks
        .iter()
        .filter(|hook| hook_commands_match(command, hook.command.as_deref().unwrap_or("")))
        .map(|hook| support::coverage_key_opt("codex", event, &hook.id, event))
        .collect())
}

/// JS `codexRouterCoverageTexts(output)`.
pub fn codex_router_coverage_texts(output: &str) -> Vec<String> {
    let mut texts = vec![output.to_string()];
    // `try { const parsed = JSON.parse(output); ... } catch {}` — raw Codex
    // output is not guaranteed to be JSON.
    if let Ok(parsed) = json::parse(output) {
        let choices = json::js_or2(
            parsed.get("data").and_then(|d| d.get("choices")),
            parsed.get("choices"),
        )
        .and_then(Json::as_array);
        if let Some(choices) = choices {
            for choice in choices {
                if let Some(content) = choice
                    .get("message")
                    .and_then(|m| m.get("content"))
                    .and_then(Json::as_str)
                {
                    texts.push(content.to_string());
                }
            }
        }
    }
    texts
}

/// JS `codexRouterCoverageEntries(output)`.
pub fn codex_router_coverage_entries(output: &str) -> Vec<Json> {
    const MARKER: &str = "[model-router-codex-hook-coverage]";
    let mut entries = Vec::new();
    for text in codex_router_coverage_texts(output) {
        let index = match text.rfind(MARKER) {
            Some(index) => index,
            None => continue,
        };
        for line in text[index + MARKER.len()..].split('\n') {
            let trimmed = line.trim_end_matches('\r').trim();
            if trimmed.is_empty() {
                continue;
            }
            if let Ok(entry) = json::parse(trimmed) {
                entries.push(entry);
            }
        }
    }
    entries
}

/// JS `coveredKeysFromCodexRouterCoverage(output)`.
pub fn covered_keys_from_codex_router_coverage(
    root: &Path,
    output: &str,
) -> Result<Vec<String>, String> {
    let mut keys = Vec::new();
    for entry in codex_router_coverage_entries(output) {
        let event = entry
            .get("event")
            .and_then(Json::as_str)
            .filter(|s| !s.is_empty());
        let hook_id = entry
            .get("hook_id")
            .and_then(Json::as_str)
            .filter(|s| !s.is_empty());
        let command = entry
            .get("command")
            .and_then(Json::as_str)
            .filter(|s| !s.is_empty());
        match (event, hook_id, command) {
            (Some(event), Some(hook_id), _) => {
                keys.push(support::coverage_key_opt("codex", event, hook_id, event));
            }
            (Some(event), None, Some(command)) => {
                keys.extend(codex_coverage_keys_from_command(root, event, command)?);
            }
            _ => {}
        }
    }
    Ok(support::unique(keys))
}
