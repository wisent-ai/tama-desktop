//! The operator's standing rules, read from Oko's ledger.
//!
//! A rule the operator gives lives in the transcript of the session it was
//! given in. The next session starts without it, and the operator says it
//! again, less patiently. Oko's ledger tells standing rules apart from turn
//! orders; this asks it for the rules of the last week, in the operator's
//! own words, with the session and message each came from.
//!
//! Turn orders such as "nie koduj" are deliberately not here: a "do not code"
//! that followed an agent into every session would freeze every agent.

use std::process::Command;

use serde_json::Value;

/// A week: long enough to cover the sessions an operator still has open.
const RULE_WINDOW_HOURS: &str = "168";
/// Claude Code caps SessionStart context at ten thousand characters and
/// replaces anything longer with a file, silently. Stay well under it.
const CONTEXT_CHARS: usize = 8000;

pub struct Rule {
    pub session: String,
    pub ordinal: i64,
    pub at: String,
    pub text: String,
}

fn oko_cli() -> String {
    std::env::var("TAMA_OKO_CLI")
        .ok()
        .filter(|value| !value.is_empty())
        .unwrap_or_else(|| "oko-cli".to_string())
}

/// The rules, newest first. The error names why they could not be read,
/// because a session that starts without them has to know it did.
pub fn standing_rules() -> Result<Vec<Rule>, String> {
    let output = Command::new(oko_cli())
        .args([
            "transcripts",
            "rules",
            "--open",
            "--hours",
            RULE_WINDOW_HOURS,
            "--json",
        ])
        .output()
        .map_err(|error| format!("cannot run oko-cli: {error}"))?;
    if !output.status.success() {
        let stderr = String::from_utf8_lossy(&output.stderr);
        return Err(stderr
            .lines()
            .next()
            .unwrap_or("oko-cli refused")
            .trim()
            .to_string());
    }
    let rules: Value = serde_json::from_slice(&output.stdout)
        .map_err(|error| format!("oko-cli answered something that is not JSON: {error}"))?;
    let mut out: Vec<Rule> = rules
        .as_array()
        .map(|rules| {
            rules
                .iter()
                .map(|rule| Rule {
                    session: rule
                        .get("sessionId")
                        .and_then(Value::as_str)
                        .unwrap_or("?")
                        .to_string(),
                    ordinal: rule
                        .get("ordinal")
                        .and_then(Value::as_i64)
                        .unwrap_or_default(),
                    at: rule
                        .get("at")
                        .and_then(Value::as_str)
                        .unwrap_or("")
                        .to_string(),
                    text: rule
                        .get("text")
                        .and_then(Value::as_str)
                        .unwrap_or("")
                        .to_string(),
                })
                .collect()
        })
        .unwrap_or_default();
    out.reverse();
    Ok(out)
}

/// The rules as one block of text an agent reads, bounded for a hook's
/// context and honest about what it left out.
pub fn rules_text(rules: &[Rule]) -> String {
    let mut out = String::from(
        "# Operator's standing rules (Oko ledger, last 7 days). These bind this session.\n",
    );
    for rule in rules {
        let line = format!(
            "- {} ({} #{}): {}\n",
            rule.at,
            short(&rule.session),
            rule.ordinal,
            rule.text.replace('\n', " ")
        );
        if out.len() + line.len() > CONTEXT_CHARS {
            out.push_str(
                "- (older rules omitted: run `oko-cli transcripts rules --open --hours 168`)\n",
            );
            break;
        }
        out.push_str(&line);
    }
    out
}

/// What `assignment show` and the hook print when the rules cannot be read.
pub fn rules_or_reason() -> String {
    match standing_rules() {
        Ok(rules) if rules.is_empty() => {
            "# Operator's standing rules: none recorded in the last 7 days.\n".to_string()
        }
        Ok(rules) => rules_text(&rules),
        Err(reason) => {
            format!("# Operator's standing rules are unavailable in this session: {reason}\n")
        }
    }
}

fn short(session: &str) -> &str {
    let key = session.rsplit('_').next().unwrap_or(session);
    let end = key
        .char_indices()
        .nth("01a0870f".len())
        .map(|(index, _)| index)
        .unwrap_or(key.len());
    &key[..end]
}
