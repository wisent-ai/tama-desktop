//! `tama-reconcile-registry-sources` driven as the real binary against real
//! git checkouts.
//!
//! The tool keeps a hook registry's `source` fields pointing at the file that
//! actually holds the hook. Two shapes are stale and repairable — a
//! repository-relative path whose file moved, and a source naming the hook's
//! own installed binary, which is what the registry writer records when it
//! cannot find the source at all. Everything else outside the checkout is
//! left alone. Each case below asserts the registry file on disk, not only
//! what the run printed.

use std::fs;
use std::path::PathBuf;
use std::process::Command;
use std::time::{SystemTime, UNIX_EPOCH};

const TOOL: &str = env!("CARGO_BIN_EXE_tama-reconcile-registry-sources");

fn fixture(label: &str) -> PathBuf {
    let nonce = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .expect("clock after epoch")
        .as_nanos();
    // The crate's own `CARGO_TARGET_TMPDIR` inside `target/`: not `/tmp`,
    // swept on sight here, and not `~/.stado/work`, which belongs to Stado.
    let root = PathBuf::from(env!("CARGO_TARGET_TMPDIR"))
        .join(format!("tama-registry-sources-{label}-{nonce}"));
    fs::create_dir_all(&root).expect("create scratch root");
    root
}

fn init_repo(root: &PathBuf, files: &[&str]) {
    Command::new("git")
        .arg("init")
        .current_dir(root)
        .output()
        .expect("git init");
    for file in files {
        let path = root.join(file);
        fs::create_dir_all(path.parent().unwrap()).expect("create parent dirs");
        fs::write(&path, "").expect("write file");
        Command::new("git")
            .args(&["add", file])
            .current_dir(root)
            .output()
            .expect("git add");
    }
    Command::new("git")
        .args(&["config", "user.email", "test@example.com"])
        .current_dir(root)
        .output()
        .expect("git config");
    Command::new("git")
        .args(&["config", "user.name", "Test"])
        .current_dir(root)
        .output()
        .expect("git config");
    Command::new("git")
        .args(&["commit", "-m", "init"])
        .current_dir(root)
        .output()
        .expect("git commit");
}

fn write_registry(path: &PathBuf, entries: &[(&str, &str)]) {
    let mut json = String::from("{\n");
    for (i, (name, source)) in entries.iter().enumerate() {
        if i > 0 {
            json.push_str(",\n");
        }
        json.push_str(&format!(
            "  \"{name}\": {{\n    \"source\": \"{source}\"\n  }}"
        ));
    }
    json.push_str("\n}\n");
    fs::write(path, json).expect("write registry");
}

fn read_registry(path: &PathBuf) -> String {
    fs::read_to_string(path).expect("read registry")
}

fn run(args: &[&str]) -> (i32, String, String) {
    let output = Command::new(TOOL)
        .args(args)
        .output()
        .expect("run reconciler");
    let code = output.status.code().unwrap_or(-1);
    let stdout = String::from_utf8_lossy(&output.stdout).to_string();
    let stderr = String::from_utf8_lossy(&output.stderr).to_string();
    (code, stdout, stderr)
}

#[test]
fn stale_source_is_repaired_when_exactly_one_file_matches_name() {
    let root = fixture("repair");
    init_repo(
        &root,
        &["rust/crates/tama-hook-tools/src/bin/block/repo/block_repository_copies.rs"],
    );
    let registry = root.join("shared-hooks/registry.json");
    fs::create_dir_all(registry.parent().unwrap()).expect("create shared-hooks");
    write_registry(
        &registry,
        &[("block-repo", "rust/crates/old/block_repository_copies.rs")],
    );

    let (code, _, stderr) = run(&["--check", registry.to_str().unwrap()]);
    assert_ne!(code, 0, "check should exit non-zero for stale source");
    assert!(stderr.contains("old/block_repository_copies.rs"));
    assert!(stderr.contains("block_repository_copies.rs"));

    let (code, _, _) = run(&[registry.to_str().unwrap()]);
    assert_eq!(code, 0, "rewrite should exit zero");
    let content = read_registry(&registry);
    assert!(content.contains("block/repo/block_repository_copies.rs"));
    assert!(!content.contains("old/block_repository_copies.rs"));

    let (code, _, _) = run(&["--check", registry.to_str().unwrap()]);
    assert_eq!(code, 0, "second check should exit zero");

    fs::remove_dir_all(&root).expect("cleanup");
}

#[test]
fn resolving_source_is_untouched() {
    let root = fixture("resolves");
    init_repo(
        &root,
        &["rust/crates/tama-hook-tools/src/bin/block/repo/block_repository_copies.rs"],
    );
    let registry = root.join("shared-hooks/registry.json");
    fs::create_dir_all(registry.parent().unwrap()).expect("create shared-hooks");
    write_registry(
        &registry,
        &[(
            "block-repo",
            "rust/crates/tama-hook-tools/src/bin/block/repo/block_repository_copies.rs",
        )],
    );

    let before = read_registry(&registry);
    let (code, _, _) = run(&[registry.to_str().unwrap()]);
    assert_eq!(code, 0, "rewrite should exit zero for resolving source");
    let after = read_registry(&registry);
    assert_eq!(before, after, "resolving source should not be modified");

    fs::remove_dir_all(&root).expect("cleanup");
}

#[test]
fn foreign_absolute_source_is_left_alone() {
    let root = fixture("foreign");
    init_repo(
        &root,
        &["rust/crates/tama-hook-tools/src/bin/block/repo/block_repository_copies.rs"],
    );
    let registry = root.join("shared-hooks/registry.json");
    fs::create_dir_all(registry.parent().unwrap()).expect("create shared-hooks");
    write_registry(&registry, &[("foreign", "/opt/somewhere/else.sh")]);

    let before = read_registry(&registry);
    let (code, _, _) = run(&[registry.to_str().unwrap()]);
    assert_eq!(code, 0, "rewrite should exit zero for foreign source");
    let after = read_registry(&registry);
    assert_eq!(before, after, "foreign source should not be modified");

    fs::remove_dir_all(&root).expect("cleanup");
}

/// A `$HOME` source that is NOT an installed hook binary belongs to another
/// tree and stays. The distinction matters: the sibling case below is also a
/// `$HOME` path and must be repaired, so "leave `$HOME` alone" is not the
/// rule and must not be read as one.
#[test]
fn home_source_that_is_not_a_hook_binary_is_left_alone() {
    let root = fixture("home-var");
    init_repo(
        &root,
        &["rust/crates/tama-hook-tools/src/bin/block/repo/block_repository_copies.rs"],
    );
    let registry = root.join("shared-hooks/registry.json");
    fs::create_dir_all(registry.parent().unwrap()).expect("create shared-hooks");
    write_registry(
        &registry,
        &[("home-script", "$HOME/.local/bin/some-script")],
    );

    let before = read_registry(&registry);
    let (code, _, _) = run(&[registry.to_str().unwrap()]);
    assert_eq!(
        code, 0,
        "rewrite should exit zero for a foreign home source"
    );
    let after = read_registry(&registry);
    assert_eq!(
        before, after,
        "a foreign home source should not be modified"
    );

    fs::remove_dir_all(&root).expect("cleanup");
}

/// The defect that stopped every hook release, in one test.
///
/// `register-hook.mjs` looks for a hook's source only as a flat
/// `src/bin/<stem>.rs`, so a guard living in `src/bin/block/repo/` matched
/// nothing and the writer recorded the hook's own command as its source.
/// `seal_hook_release.py` then refused the release with "External hook source
/// is missing", and no hook release could be sealed at all until this was
/// repaired. The stem comes from the binary name the same way the writer
/// derives it: drop `tama-`, hyphens become underscores.
#[test]
fn installed_hook_binary_source_is_repaired_to_its_nested_file() {
    let root = fixture("hook-binary");
    let tracked = "rust/crates/tama-hook-tools/src/bin/block/repo/block_repository_copies.rs";
    init_repo(&root, &[tracked]);
    let registry = root.join("shared-hooks/registry.json");
    fs::create_dir_all(registry.parent().unwrap()).expect("create shared-hooks");
    let stale = "$HOME/.local/bin/tama-block-repository-copies";
    write_registry(&registry, &[("block-repository-copies", stale)]);

    let (code, _, stderr) = run(&["--check", registry.to_str().unwrap()]);
    assert_ne!(code, 0, "check should exit non-zero: {stderr}");
    assert!(
        stderr.contains(stale),
        "the stale source is named: {stderr}"
    );
    assert!(
        stderr.contains(tracked),
        "the repaired path is named: {stderr}"
    );

    let (code, _, _) = run(&[registry.to_str().unwrap()]);
    assert_eq!(code, 0, "rewrite should exit zero");
    let content = read_registry(&registry);
    assert!(content.contains(tracked), "the nested file is recorded");
    assert!(
        !content.contains(stale),
        "the command is no longer the source"
    );

    let (code, _, _) = run(&["--check", registry.to_str().unwrap()]);
    assert_eq!(code, 0, "the repaired registry checks clean");

    fs::remove_dir_all(&root).expect("cleanup");
}

/// An installed hook binary whose Rust file is not tracked is undecidable,
/// never silently rewritten to something that merely looks close.
#[test]
fn installed_hook_binary_without_a_tracked_file_is_undecidable() {
    let root = fixture("hook-binary-missing");
    init_repo(
        &root,
        &["rust/crates/tama-hook-tools/src/bin/block/repo/block_repository_copies.rs"],
    );
    let registry = root.join("shared-hooks/registry.json");
    fs::create_dir_all(registry.parent().unwrap()).expect("create shared-hooks");
    write_registry(
        &registry,
        &[(
            "block-nothing-here",
            "$HOME/.local/bin/tama-block-nothing-here",
        )],
    );

    let before = read_registry(&registry);
    let (code, _, stderr) = run(&[registry.to_str().unwrap()]);
    assert_ne!(code, 0, "an undecidable source must not pass");
    assert!(
        stderr.contains("no tracked file is named block_nothing_here.rs"),
        "the missing file is named: {stderr}"
    );
    assert_eq!(before, read_registry(&registry), "nothing is rewritten");

    fs::remove_dir_all(&root).expect("cleanup");
}

#[test]
fn undecidable_source_leaves_file_unchanged_and_exits_nonzero() {
    let root = fixture("undecidable");
    init_repo(
        &root,
        &["rust/crates/tama-hook-tools/src/bin/block/repo/block_repository_copies.rs"],
    );
    let registry = root.join("shared-hooks/registry.json");
    fs::create_dir_all(registry.parent().unwrap()).expect("create shared-hooks");
    write_registry(&registry, &[("nonexistent", "rust/crates/nonexistent.rs")]);

    let before = read_registry(&registry);
    let (code, _, stderr) = run(&[registry.to_str().unwrap()]);
    assert_ne!(
        code, 0,
        "rewrite should exit non-zero for undecidable source"
    );
    assert!(stderr.contains("no tracked file is named nonexistent.rs"));
    let after = read_registry(&registry);
    assert_eq!(before, after, "file should not be modified");

    fs::remove_dir_all(&root).expect("cleanup");
}

#[test]
fn multiple_tracked_files_with_same_name_is_undecidable() {
    let root = fixture("duplicates");
    init_repo(
        &root,
        &[
            "rust/crates/tama-hook-tools/src/bin/block/repo/block_repository_copies.rs",
            "rust/other/block_repository_copies.rs",
        ],
    );
    let registry = root.join("shared-hooks/registry.json");
    fs::create_dir_all(registry.parent().unwrap()).expect("create shared-hooks");
    write_registry(
        &registry,
        &[("dupes", "rust/old/block_repository_copies.rs")],
    );

    let before = read_registry(&registry);
    let (code, _, stderr) = run(&[registry.to_str().unwrap()]);
    assert_ne!(code, 0, "rewrite should exit non-zero for multiple matches");
    assert!(stderr.contains("2 tracked files are named block_repository_copies.rs"));
    let after = read_registry(&registry);
    assert_eq!(before, after, "file should not be modified when ambiguous");

    fs::remove_dir_all(&root).expect("cleanup");
}

#[test]
fn out_flag_writes_to_separate_file_leaving_input_untouched() {
    let root = fixture("out-flag");
    init_repo(
        &root,
        &["rust/crates/tama-hook-tools/src/bin/block/repo/block_repository_copies.rs"],
    );
    let registry = root.join("shared-hooks/registry.json");
    fs::create_dir_all(registry.parent().unwrap()).expect("create shared-hooks");
    write_registry(
        &registry,
        &[("block-repo", "rust/crates/old/block_repository_copies.rs")],
    );
    let output = root.join("shared-hooks/registry-new.json");

    let before = read_registry(&registry);
    let (code, _, _) = run(&[
        "--out",
        output.to_str().unwrap(),
        registry.to_str().unwrap(),
    ]);
    assert_eq!(code, 0, "rewrite with --out should exit zero");

    let after_input = read_registry(&registry);
    assert_eq!(
        before, after_input,
        "input file should not be modified with --out"
    );

    let output_content = read_registry(&output);
    assert!(output_content.contains("block/repo/block_repository_copies.rs"));
    assert!(!output_content.contains("crates/old"));

    fs::remove_dir_all(&root).expect("cleanup");
}
