//! Command handlers extracted from the `main()` dispatch chain: onboarding,
//! policy, list, show, validate, install-plan, install, and verify. Each
//! function reproduces the original inline branch — same argument validation,
//! same messages, same exit codes — but takes `argv`/`root` as parameters.

use std::path::Path;
use std::process::Command;

use tama_core::catalog::{build_catalog, find_hook, validate_catalog};
use tama_core::install::{install_global_git, level_plan, InstallOptions};
use tama_core::policy_bundle::{
    import_policy_bundle, list_policy_bundles, ImportPolicyBundleOptions,
};

use super::args::{arg_after, has, option_value};
use super::output::{
    print_catalog_json, print_json, print_policy_import, truthy, unwrap_or_exit, usage,
};
use crate::EXIT_USAGE;

pub fn onboarding(argv: &[String], root: &Path) -> i32 {
    let source = arg_after(argv, "--policy-bundle").filter(|value| !value.starts_with("--"));
    if has(argv, "--policy-bundle") && source.is_none() {
        eprintln!("--policy-bundle requires a directory");
        return EXIT_USAGE;
    }
    if has(argv, "--replace") && source.is_none() {
        eprintln!("--replace requires --policy-bundle <dir>");
        return EXIT_USAGE;
    }
    let home = option_value(argv, "--home").filter(|value| !value.starts_with("--"));
    if has(argv, "--home") && home.is_none() {
        eprintln!("--home requires a directory");
        return EXIT_USAGE;
    }
    let allowed = [
        "onboarding",
        "--reset",
        "--policy-bundle",
        "--replace",
        "--home",
    ];
    for (index, argument) in argv.iter().enumerate().skip(1) {
        if (argv[index - 1] == "--policy-bundle" || argv[index - 1] == "--home")
            && !argument.starts_with("--")
        {
            continue;
        }
        if !allowed.contains(&argument.as_str()) {
            eprintln!("unknown onboarding option: {argument}");
            return EXIT_USAGE;
        }
    }
    let imported = source.as_ref().map(|source| {
        unwrap_or_exit(import_policy_bundle(ImportPolicyBundleOptions {
            source: Path::new(source),
            home: home.as_deref().map(Path::new),
            replace: has(argv, "--replace"),
        }))
    });
    if let Some(result) = &imported {
        print_policy_import(result, false);
        if result.status == "conflict" || result.status == "rejected" {
            return 1;
        }
    }
    if let Err(error) = crate::onboarding::run(root, has(argv, "--reset"), imported.as_ref()) {
        eprintln!("{error}");
        return 1;
    }
    0
}

pub fn policy(argv: &[String]) -> i32 {
    let operation = argv.get(1).map(String::as_str).unwrap_or("");
    if operation == "import" {
        let source = arg_after(argv, "--source")
            .filter(|value| !value.starts_with("--"))
            .unwrap_or_else(|| {
                eprintln!("policy import requires --source <dir>");
                std::process::exit(EXIT_USAGE);
            });
        let home = option_value(argv, "--home").filter(|value| !value.starts_with("--"));
        if has(argv, "--home") && home.is_none() {
            eprintln!("--home requires a directory");
            return EXIT_USAGE;
        }
        let allowed = [
            "policy",
            "import",
            "--source",
            "--replace",
            "--json",
            "--home",
        ];
        for (index, argument) in argv.iter().enumerate().skip(2) {
            if (argv[index - 1] == "--source" || argv[index - 1] == "--home")
                && !argument.starts_with("--")
            {
                continue;
            }
            if !allowed.contains(&argument.as_str()) {
                eprintln!("unknown policy import option: {argument}");
                return EXIT_USAGE;
            }
        }
        let result = unwrap_or_exit(import_policy_bundle(ImportPolicyBundleOptions {
            source: Path::new(&source),
            home: home.as_deref().map(Path::new),
            replace: has(argv, "--replace"),
        }));
        print_policy_import(&result, has(argv, "--json"));
        return if result.status == "conflict" || result.status == "rejected" {
            1
        } else {
            0
        };
    }
    if operation == "list" {
        let home = option_value(argv, "--home").filter(|value| !value.starts_with("--"));
        if has(argv, "--home") && home.is_none() {
            eprintln!("--home requires a directory");
            return EXIT_USAGE;
        }
        let allowed = ["policy", "list", "--json", "--home"];
        for (index, argument) in argv.iter().enumerate().skip(2) {
            if argv[index - 1] == "--home" && !argument.starts_with("--") {
                continue;
            }
            if !allowed.contains(&argument.as_str()) {
                eprintln!("unknown policy list option: {argument}");
                return EXIT_USAGE;
            }
        }
        let bundles = unwrap_or_exit(list_policy_bundles(home.as_deref().map(Path::new)));
        if has(argv, "--json") {
            print_json(&bundles);
        } else if bundles.bundles.is_empty() {
            println!("No inactive policy bundles imported.");
        } else {
            for bundle in bundles.bundles {
                println!(
                    "{}\t{}\t{} hooks\t{} files\tinactive",
                    bundle.source_path, bundle.source_digest, bundle.hook_count, bundle.file_count
                );
            }
        }
        return 0;
    }
    eprintln!("usage: tama policy import --source <dir> [--replace] [--json] [--home <path>] | tama policy list [--json] [--home <path>]");
    EXIT_USAGE
}

pub fn list_hooks(root: &Path, json: bool) -> tama_core::Result<usize> {
    let catalog = build_catalog(root)?;
    let hook_count = catalog.hooks.len();
    if json {
        print_catalog_json(&catalog);
    } else {
        for hook in &catalog.hooks {
            let events: Vec<&str> = hook
                .events
                .iter()
                .map(|event| event.event.as_str())
                .collect();
            println!(
                "{}\t{}\t{}",
                hook.id,
                hook.source_path.as_deref().unwrap_or("-"),
                events.join(", ")
            );
        }
    }
    Ok(hook_count)
}

pub fn list(argv: &[String], root: &Path) -> i32 {
    unwrap_or_exit(list_hooks(root, has(argv, "--json")));
    0
}

pub fn show(argv: &[String], root: &Path) -> i32 {
    let id = argv.get(1);
    let Some(id) = id else {
        usage();
        return EXIT_USAGE;
    };
    let hook = unwrap_or_exit(find_hook(id, root));
    let Some(hook) = hook else {
        eprintln!("not found: {id}");
        return 1;
    };
    if has(argv, "--json") {
        print_catalog_json(&hook);
    } else {
        println!("{}", hook.id);
        println!("source: {}", hook.source_path.as_deref().unwrap_or("-"));
        println!("command: {}", hook.command);
        if let Some(description) = truthy(&hook.description) {
            println!("does: {description}");
        }
        if let Some(why) = truthy(&hook.why) {
            println!("why: {why}");
        }
        println!("events:");
        for ev in &hook.events {
            println!("  - {} blocking={}", ev.event, ev.blocking);
        }
    }
    0
}

pub fn validate(argv: &[String], root: &Path) -> i32 {
    let mut result = unwrap_or_exit(validate_catalog(root));
    result.errors.extend(unwrap_or_exit(
        crate::catalog_integrity::wired_without_catalog_errors(root),
    ));
    result.ok = result.errors.is_empty();
    if has(argv, "--json") {
        print_json(&result);
    } else {
        println!("hooks: {}", result.hook_count);
        println!("orphan sources: {}", result.orphan_source_count);
        for warning in &result.warnings {
            println!("WARN {warning}");
        }
        for error in &result.errors {
            eprintln!("ERROR {error}");
        }
    }
    if result.ok {
        0
    } else {
        1
    }
}

pub fn install_plan(argv: &[String], root: &Path) -> i32 {
    // JS: `levelPlan(root, optionValue('--git-hooks-path'),
    // optionValue('--home', process.env.HOME ?? ''))`; the library consults
    // `HOME` itself when `home` is None.
    let plan = level_plan(
        root,
        option_value(argv, "--git-hooks-path").as_deref(),
        option_value(argv, "--home").as_deref(),
    );
    if has(argv, "--json") {
        print_json(&plan);
    } else {
        println!("archive: {}", plan.archive_root);
        println!("agent/app hooks: configured by Claude/Codex/OMP runtimes, not by archive alone");
        println!("kimi hooks: no known native hook adapter; indirect coverage only via editor/Git surfaces");
        println!(
            "editor adapters: {} (not installed by archive alone)",
            plan.levels.editor.runtime_targets.editor_watch
        );
        println!("mcp server: {}", plan.levels.mcp.runtime_targets.server);
        println!(
            "user-global Git hooks: {}",
            plan.levels
                .user_global_git
                .current_hooks_path
                .as_deref()
                .unwrap_or("not configured")
        );
        println!("repo/project Git hooks: git config core.hooksPath .githooks");
        println!("OS-level policy: outside Tama");
    }
    0
}

pub fn install(argv: &[String], root: &Path) -> i32 {
    let result = unwrap_or_exit(install_global_git(
        root,
        &InstallOptions {
            hooks_path: option_value(argv, "--git-hooks-path"),
            set_global_config: has(argv, "--set-git-config") && !has(argv, "--no-git-config"),
            home: option_value(argv, "--home"),
        },
    ));
    if has(argv, "--json") {
        print_json(&result);
    } else {
        println!("hooksPath: {}", result.hooks_path);
        println!("pre-commit: {}", result.pre_commit.target);
        println!("pre-push: {}", result.pre_push.target);
        println!("git global config updated: {}", result.set_global_config);
    }
    0
}

pub fn verify(root: &Path) -> i32 {
    // The native Rust harness (`tama-require-live-runtime`) must sit next
    // to this binary; the Node CLI is gone, so there is nothing else to run.
    let native = std::env::current_exe()
        .ok()
        .and_then(|exe| {
            exe.parent()
                .map(|dir| dir.join("tama-require-live-runtime"))
        })
        .filter(|path| path.is_file());
    let Some(bin) = native else {
        eprintln!("tama-require-live-runtime not found next to this binary");
        return 1;
    };
    let status = Command::new(bin).current_dir(root).status();
    match status {
        Ok(status) => status.code().unwrap_or(1),
        Err(_) => 1,
    }
}
