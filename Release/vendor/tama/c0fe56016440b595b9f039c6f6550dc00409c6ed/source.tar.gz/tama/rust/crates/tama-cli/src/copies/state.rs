//! Git's answers about one candidate checkout. This file reads; the
//! classification in [`super::discovery`] decides.

use std::fs;
use std::path::Path;

use crate::gitcmd::{git, is_dirty};

/// A checkout whose `.git` is a file is a linked worktree: the file holds a
/// `gitdir:` line pointing into the owner's `.git/worktrees/`. That noun
/// belongs to `tama worktrees`, which removes it through git itself, so this
/// command reports it and steps over it.
pub(super) fn is_linked_worktree(dir: &Path) -> bool {
    dir.join(".git").is_file()
}

/// Linked worktrees hanging off a checkout, from git's own records in
/// `.git/worktrees/<name>/gitdir`, each of which holds the `<worktree>/.git`
/// path. The shared walk cannot answer this: it returns early on a checkout
/// whose `.git` is a file, so a linked worktree never reaches the caller as
/// a candidate. A copies pass still has to name them — a clean pass over
/// copies alone would otherwise read as one checkout per repository when it
/// is not — and a copy that owns them is refused rather than deleted,
/// because deleting it orphans these records.
pub(super) fn linked_worktrees(dir: &Path) -> Vec<String> {
    let Ok(entries) = fs::read_dir(dir.join(".git").join("worktrees")) else {
        return Vec::new();
    };
    let mut paths = Vec::new();
    for entry in entries.flatten() {
        let Ok(text) = fs::read_to_string(entry.path().join("gitdir")) else {
            continue;
        };
        let recorded = text.trim();
        let path = recorded.strip_suffix("/.git").unwrap_or(recorded);
        if !path.is_empty() {
            paths.push(path.to_string());
        }
    }
    paths
}

pub(super) fn owns_worktrees(dir: &Path) -> bool {
    !linked_worktrees(dir).is_empty()
}

pub(super) fn dirty(dir: &Path) -> bool {
    is_dirty(dir)
}

/// Where this checkout came from. Two directories are the same repository
/// when they were cloned from the same place, so the origin URL is the
/// comparison, and a checkout with no `origin` cannot be compared at all.
pub(super) fn origin(dir: &Path) -> Option<String> {
    let url = git(dir, &["remote", "get-url", "origin"]).ok()?;
    let trimmed = url.trim();
    if trimmed.is_empty() {
        return None;
    }
    Some(trimmed.to_string())
}

/// `git@github.com:wisent-ai/lem.git`, `https://github.com/wisent-ai/lem.git`
/// and `https://github.com/wisent-ai/lem` name one repository to a reader and
/// three different strings to `==`. What is kept is the host and the path;
/// what is dropped is only spelling: the scheme, any user prefix, a `.git`
/// suffix and a trailing slash.
pub(super) fn normalize_origin(url: &str) -> String {
    let without_scheme = url.split_once("://").map_or(url, |(_, rest)| rest);
    let after_user = without_scheme
        .rsplit_once('@')
        .map_or(without_scheme, |(_, rest)| rest);
    let unified = after_user.replacen(':', "/", 1);
    let trimmed = unified.trim_end_matches('/');
    trimmed
        .strip_suffix(".git")
        .unwrap_or(trimmed)
        .to_lowercase()
}

/// An origin that names a directory on this filesystem rather than a server:
/// what `git clone /path/to/repo` and `git clone file:///path` write. The
/// answer is the path itself, so the caller can ask whether that path is one
/// of the canonical checkouts it already found.
pub(super) fn local_origin_path(url: &str) -> Option<String> {
    let path = match url.split_once("://") {
        Some(("file", rest)) => rest,
        Some(_) => return None,
        None => url,
    };
    // An scp-style `user@host:path` has a colon before any slash; a Windows
    // drive letter cannot occur on this machine.
    if let Some(colon) = path.find(':') {
        if path[..colon].find('/').is_none() {
            return None;
        }
    }
    let trimmed = path.trim_end_matches('/');
    let without_git = trimmed.strip_suffix("/.git").unwrap_or(trimmed);
    Some(without_git.to_string())
}

/// Whether any commit on a local branch is absent from every remote-tracking
/// ref. This is the question "would deleting this directory lose history",
/// and it is asked of the checkout on disk, never of a server over the
/// network. An error means git does not answer for this directory as a
/// repository, which the caller reports rather than treats as safe.
pub(super) fn unpublished(dir: &Path) -> Result<bool, String> {
    let text = git(
        dir,
        &["log", "--branches", "--not", "--remotes", "--oneline"],
    )?;
    Ok(!text.trim().is_empty())
}

/// Apparent size of the candidate, so the operator sees what a pass returns.
/// Symlinks are counted as links and never followed: a copy that links to
/// something outside itself must not have that thing's size attributed to it,
/// and must never have it walked.
pub(super) fn bytes(dir: &Path) -> u64 {
    let Ok(entries) = fs::read_dir(dir) else {
        return 0;
    };
    let mut total = 0u64;
    for entry in entries.flatten() {
        let Ok(kind) = entry.file_type() else {
            continue;
        };
        if kind.is_symlink() {
            continue;
        }
        if kind.is_dir() {
            total += bytes(&entry.path());
        } else if let Ok(metadata) = entry.metadata() {
            total += metadata.len();
        }
    }
    total
}
