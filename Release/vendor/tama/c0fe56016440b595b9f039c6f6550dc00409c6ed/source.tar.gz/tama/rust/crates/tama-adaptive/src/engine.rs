//! Port of `src/adaptive/engine.mjs`: threshold-free adaptive engine.
//! Projections persist independently from telemetry.

use sha2::{Digest, Sha256};
use std::fs::{self, OpenOptions};
use std::io::Write;
use std::path::{Path, PathBuf};

use tama_core::registry::Registry;

use crate::state::projections::{
    project_contested_block, project_outcome, IdentityFacts, Projection,
};
use crate::state::{
    open_state_store, EpisodeBlockInput, EpisodeWriteResult, HookState, StateStore,
    TransitionResult, Warn,
};
use crate::util::{home_dir, iso8601, now_ms, repo_root, shell_words};

const INTERPRETERS: [&str; 12] = [
    "bash", "bun", "deno", "env", "node", "perl", "php", "python", "python3", "ruby", "sh", "zsh",
];

/// `SAFE_TIER` / a resolved policy tier.
#[derive(Debug, Clone)]
pub struct Tier {
    pub name: String,
    pub enforce_verdict: bool,
    pub on_infra_failure: String,
    pub demotable: bool,
}

impl Tier {
    fn safe() -> Self {
        Tier {
            name: "integrity".to_string(),
            enforce_verdict: true,
            on_infra_failure: "warn".to_string(),
            demotable: false,
        }
    }
}

/// `SourceIdentity` from `engine.mjs`.
#[derive(Debug, Clone)]
pub struct SourceIdentity {
    pub hook_id: String,
    pub command: Option<String>,
    pub source_path: Option<String>,
    pub digest: Option<String>,
    pub verifiable: bool,
}

impl SourceIdentity {
    pub fn to_value(&self) -> serde_json::Value {
        serde_json::json!({
            "hookId": self.hook_id,
            "command": self.command,
            "sourcePath": self.source_path,
            "digest": self.digest,
            "verifiable": self.verifiable,
        })
    }

    fn facts(&self) -> IdentityFacts {
        IdentityFacts {
            verifiable: self.verifiable,
            digest: self.digest.clone(),
        }
    }
}

/// `OutcomeObservation` — fields may be missing like a partial JS object.
#[derive(Debug, Clone, Default)]
pub struct OutcomeObservation {
    pub hook_id: Option<String>,
    pub outcome: Option<String>,
}

pub struct Engine {
    pub state_dir: PathBuf,
    pub registry_path: PathBuf,
    pub policy: serde_json::Value,
    pub registry: Registry,
    /// Raw registry JSON, kept for insertion-order-faithful iteration where
    /// JS uses `Object.values(registry.events)`.
    registry_value: serde_json::Value,
    store: StateStore,
}

/// `loadObject(path, alternate)` — lenient JSON object load.
fn load_object(path: &Path, alternate: serde_json::Value) -> serde_json::Value {
    if let Ok(text) = fs::read_to_string(path) {
        if let Ok(value) = serde_json::from_str::<serde_json::Value>(&text) {
            if value.is_object() {
                return value;
            }
        }
    }
    alternate
}

fn load_registry(path: &Path) -> serde_json::Value {
    let value = load_object(path, serde_json::json!({ "events": {} }));
    if value.get("events").map(|v| v.is_object()).unwrap_or(false) {
        return value;
    }
    serde_json::json!({ "events": {} })
}

/// `policyEntry(id, hooks)`: exact key first, then the longest key that is a
/// prefix of the hook id. (Two distinct equal-length keys can never both be
/// prefixes of one string, so key order never matters.)
fn policy_entry<'a>(
    id: &str,
    hooks: &'a serde_json::Map<String, serde_json::Value>,
) -> Option<&'a serde_json::Value> {
    if let Some(entry) = hooks.get(id) {
        return Some(entry);
    }
    let mut best = "";
    for key in hooks.keys() {
        if id.starts_with(key.as_str()) && key.len() > best.len() {
            best = key;
        }
    }
    if !best.is_empty() {
        return hooks.get(best);
    }
    None
}

/// `resolveFile(word, registryPath)`.
fn resolve_file(word: &str, registry_path: &Path) -> Option<PathBuf> {
    let word_path = Path::new(word);
    let candidates: Vec<PathBuf> = if word_path.is_absolute() {
        vec![word_path.to_path_buf()]
    } else {
        let parent = registry_path.parent().unwrap_or_else(|| Path::new("."));
        vec![
            parent.join(word_path),
            std::env::current_dir().unwrap_or_default().join(word_path),
        ]
    };
    for path in candidates {
        if let Ok(meta) = fs::metadata(&path) {
            if meta.is_file() {
                return Some(path);
            }
        }
    }
    None
}

/// `basename` for the interpreter check (trailing slashes trimmed first).
fn basename_of(word: &str) -> &str {
    let trimmed = word.trim_end_matches('/');
    match trimmed.rfind('/') {
        Some(index) => &trimmed[index + 1..],
        None => trimmed,
    }
}

/// `commandFor(registry, hookId)` over the raw registry value.
fn command_for(registry: &serde_json::Value, hook_id: &str) -> Option<String> {
    let events = registry.get("events")?.as_object()?;
    for event in events.values() {
        let Some(hooks) = event.get("hooks").and_then(|h| h.as_array()) else {
            continue;
        };
        for hook in hooks {
            let id_matches = hook
                .get("id")
                .map(|id| crate::util::js_string(id) == hook_id)
                .unwrap_or(false);
            if id_matches {
                if let Some(command) = hook.get("command").and_then(|c| c.as_str()) {
                    return Some(command.to_string());
                }
            }
        }
    }
    None
}

/// `sourceFor(command, registryPath)`.
fn source_for(command: &str, registry_path: &Path) -> Option<PathBuf> {
    let mut words = shell_words(command);
    if !words.is_empty() && INTERPRETERS.contains(&basename_of(&words[0])) {
        words.remove(0);
    }
    for word in &words {
        if word.starts_with('-') {
            continue;
        }
        if let Some(path) = resolve_file(word, registry_path) {
            return Some(path);
        }
    }
    None
}

impl Engine {
    /// `tierOf(hookId)`.
    pub fn tier_of(&self, hook_id: &str) -> Tier {
        let empty = serde_json::Map::new();
        let hooks = self
            .policy
            .get("hooks")
            .and_then(|v| v.as_object())
            .unwrap_or(&empty);
        let tiers = self
            .policy
            .get("tiers")
            .and_then(|v| v.as_object())
            .unwrap_or(&empty);
        let entry = policy_entry(hook_id, hooks);
        let mut name = self
            .policy
            .get("defaults")
            .and_then(|d| d.get("tier"))
            .and_then(|t| t.as_str())
            .map(str::to_string);
        if let Some(entry) = entry {
            if let Some(tier) = entry.get("tier").and_then(|t| t.as_str()) {
                if !tier.is_empty() {
                    name = Some(tier.to_string());
                }
            }
        }
        let name = name
            .filter(|n| !n.is_empty())
            .unwrap_or_else(|| "integrity".to_string());
        if name == "integrity" {
            return Tier::safe();
        }
        let definition = tiers.get(&name);
        let Some(definition) = definition.and_then(|d| d.as_object()) else {
            return Tier::safe();
        };
        let demotable = name == "etiquette";
        Tier {
            name,
            enforce_verdict: definition
                .get("enforceVerdict")
                .map(|v| v.as_bool().unwrap_or(true))
                .unwrap_or(true),
            on_infra_failure: definition
                .get("onInfraFailure")
                .and_then(|v| v.as_str())
                .filter(|s| !s.is_empty())
                .unwrap_or("warn")
                .to_string(),
            demotable,
        }
    }

    /// `sourceIdentity(hookId)`.
    pub fn source_identity(&self, hook_id: &str) -> SourceIdentity {
        let id = hook_id.to_string();
        let command = command_for(&self.registry_value, &id);
        let Some(command) = command else {
            return SourceIdentity {
                hook_id: id,
                command: None,
                source_path: None,
                digest: None,
                verifiable: false,
            };
        };
        let source_path = source_for(&command, &self.registry_path);
        // try { hash... } catch { unverifiable }
        let hashed = (|| -> Option<SourceIdentity> {
            let mut hasher = Sha256::new();
            hasher.update(command.as_bytes());
            if let Some(path) = &source_path {
                if path.exists() {
                    let bytes = fs::read(path).ok()?;
                    hasher.update(b"\0");
                    hasher.update(bytes);
                    return Some(SourceIdentity {
                        hook_id: id.clone(),
                        command: Some(command.clone()),
                        source_path: Some(path.to_string_lossy().to_string()),
                        digest: Some(format!("{:x}", hasher.finalize())),
                        verifiable: true,
                    });
                }
            }
            let missing_script = shell_words(&command).iter().any(|word| {
                word.ends_with(".py") || word.ends_with(".sh") || word.ends_with(".mjs")
            });
            if missing_script {
                return Some(SourceIdentity {
                    hook_id: id.clone(),
                    command: Some(command.clone()),
                    source_path: None,
                    digest: None,
                    verifiable: false,
                });
            }
            Some(SourceIdentity {
                hook_id: id.clone(),
                command: Some(command.clone()),
                source_path: None,
                digest: Some(format!("{:x}", hasher.finalize())),
                verifiable: true,
            })
        })();
        hashed.unwrap_or(SourceIdentity {
            hook_id: id,
            command: Some(command),
            source_path: None,
            digest: None,
            verifiable: false,
        })
    }

    /// `effectiveMode(hookId)`.
    pub fn effective_mode(&self, hook_id: &str) -> &'static str {
        let tier = self.tier_of(hook_id);
        if tier.name == "advisory" {
            return "warn";
        }
        if tier.name != "etiquette" {
            return "enforce";
        }
        let phase = self
            .store
            .snapshot(Some(hook_id))
            .get("phase")
            .and_then(|v| v.as_str())
            .unwrap_or("")
            .to_string();
        if phase == "warning" {
            "warn"
        } else {
            "enforce"
        }
    }

    /// `finish(hookId, result)` — computes the mode on persisted results.
    fn finish(&self, hook_id: &str, mut result: TransitionResult) -> TransitionResult {
        result.mode = if result.persisted {
            self.effective_mode(hook_id).to_string()
        } else {
            "enforce".to_string()
        };
        result
    }

    /// `recordOutcome(observation)`. Lock-acquisition I/O errors propagate
    /// like the JS throw outside `update`'s `try` block.
    pub fn record_outcome(
        &self,
        observation: Option<&OutcomeObservation>,
    ) -> std::io::Result<TransitionResult> {
        let Some(observation) = observation else {
            let state = snapshot_hook(&self.store, "");
            return Ok(self.finish("", invalid_observation(state)));
        };
        let hook_id = observation.hook_id.clone().unwrap_or_default();
        let outcome = observation.outcome.clone().unwrap_or_default();
        if hook_id.is_empty() || !matches!(outcome.as_str(), "pass" | "infra_failure" | "block") {
            let state = snapshot_hook(&self.store, &hook_id);
            return Ok(self.finish(&hook_id, invalid_observation(state)));
        }
        let tier = self.tier_of(&hook_id);
        let identity = self.source_identity(&hook_id);
        let facts = identity.facts();
        let outcome_for_projection = outcome.clone();
        let tier_name = tier.name.clone();
        let result = self.store.update(
            &hook_id,
            move |prior: &HookState, fact: &serde_json::Value| -> Projection {
                let event_id = fact.get("id").and_then(|v| v.as_str()).unwrap_or("");
                project_outcome(prior, &outcome_for_projection, &tier_name, &facts, event_id)
            },
            Some(serde_json::json!({
                "kind": "outcome",
                "outcome": outcome,
                "tier": tier.name,
                "identity": identity.to_value(),
            })),
        )?;
        Ok(self.finish(&hook_id, result))
    }

    /// `recordContestedBlock(observation)` — `hook_id` empty models the JS
    /// missing-observation case.
    pub fn record_contested_block(&self, hook_id: &str) -> std::io::Result<TransitionResult> {
        if hook_id.is_empty() {
            let state = snapshot_hook(&self.store, "");
            return Ok(self.finish("", invalid_observation(state)));
        }
        let tier = self.tier_of(hook_id);
        let identity = self.source_identity(hook_id);
        let facts = identity.facts();
        let tier_name = tier.name.clone();
        let result = self.store.update(
            hook_id,
            move |prior: &HookState, fact: &serde_json::Value| -> Projection {
                let event_id = fact.get("id").and_then(|v| v.as_str()).unwrap_or("");
                project_contested_block(prior, &tier_name, &facts, event_id)
            },
            Some(serde_json::json!({
                "kind": "contested-block",
                "tier": tier.name,
                "identity": identity.to_value(),
            })),
        )?;
        Ok(self.finish(hook_id, result))
    }

    /// `recordEpisodeBlock(observation)`.
    pub fn record_episode_block(&self, input: &EpisodeBlockInput) -> EpisodeWriteResult {
        self.store.record_episode_block(input)
    }

    /// `consumeLatestEpisodeBlocks(sessionId)`.
    pub fn consume_latest_episode_blocks(
        &self,
        session_id: Option<&str>,
    ) -> Vec<serde_json::Value> {
        self.store.consume_latest_episode_blocks(session_id)
    }

    /// `engine.registry?.events?.[event]` — raw entry JSON (falsy entries
    /// behave like missing ones, as in the runner checks).
    pub fn registry_event(&self, event: &str) -> Option<serde_json::Value> {
        let entry = self.registry_value.get("events")?.get(event)?.clone();
        if crate::util::js_truthy(&entry) {
            Some(entry)
        } else {
            None
        }
    }

    /// `stateSnapshot(hookId?)`.
    pub fn state_snapshot(&self, hook_id: Option<&str>) -> serde_json::Value {
        if let Some(hook_id) = hook_id {
            return self.store.snapshot(Some(hook_id));
        }
        let mut states = self.store.snapshot(None);
        if let (Some(states_map), Some(events)) = (
            states.as_object_mut(),
            self.registry_value
                .get("events")
                .and_then(|e| e.as_object()),
        ) {
            for config in events.values() {
                let hooks = config.get("hooks").and_then(|h| h.as_array());
                let Some(hooks) = hooks else { continue };
                for hook in hooks {
                    if let Some(id) = hook.get("id").and_then(|v| v.as_str()) {
                        if !id.is_empty() {
                            states_map.insert(id.to_string(), self.store.snapshot(Some(id)));
                        }
                    }
                }
            }
        }
        states
    }
}

fn invalid_observation(state: HookState) -> TransitionResult {
    TransitionResult {
        ok: false,
        persisted: false,
        mode: String::new(),
        transition: None,
        reason: Some("invalid-observation".to_string()),
        state,
    }
}

fn snapshot_hook(store: &StateStore, hook_id: &str) -> HookState {
    let value = store.snapshot(Some(hook_id));
    serde_json::from_value::<HookState>(value).unwrap_or_else(|_| HookState::initial(hook_id))
}

/// `loadEngine(env = process.env)`.
pub fn load_engine() -> Engine {
    load_engine_with(|key| std::env::var(key).ok())
}

/// `loadEngine(env)` with an explicit environment lookup.
pub fn load_engine_with(env: impl Fn(&str) -> Option<String>) -> Engine {
    let state_dir = env("HOOKS_ADAPTIVE_STATE")
        .filter(|v| !v.is_empty())
        .map(PathBuf::from)
        .unwrap_or_else(|| home_dir().join(".hooks-adaptive"));
    let registry_path = env("AGENT_HOOK_REGISTRY")
        .filter(|v| !v.is_empty())
        .map(PathBuf::from)
        .unwrap_or_else(|| home_dir().join(".shared-hooks").join("registry.json"));
    let policy_path = repo_root().join("adaptive").join("policy.json");
    let policy = load_object(
        &policy_path,
        serde_json::json!({ "defaults": { "tier": "integrity" }, "tiers": {}, "hooks": {} }),
    );
    let registry_value = load_registry(&registry_path);
    let registry: Registry = serde_json::from_value(registry_value.clone()).unwrap_or_default();

    let warn: Warn = {
        let state_dir = state_dir.clone();
        std::sync::Arc::new(move |text: &str| {
            let attempt = (|| -> std::io::Result<()> {
                fs::create_dir_all(&state_dir)?;
                let mut file = OpenOptions::new()
                    .append(true)
                    .create(true)
                    .open(state_dir.join("warnings.log"))?;
                file.write_all(format!("{} {}\n", iso8601(now_ms()), text).as_bytes())?;
                Ok(())
            })();
            let _ = attempt;
        })
    };

    let store = open_state_store(&state_dir, warn);
    store.quarantine_legacy();
    Engine {
        state_dir,
        registry_path,
        policy,
        registry,
        registry_value,
        store,
    }
}
