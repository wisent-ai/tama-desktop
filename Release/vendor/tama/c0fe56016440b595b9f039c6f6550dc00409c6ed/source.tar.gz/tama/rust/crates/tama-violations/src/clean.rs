//! Violation cleaner ("gate"): scans target repositories with the real hook
//! replay, hands the violation report to Brama for one patch per repository
//! per round, applies it, then re-scans. Repeats until clean or out of
//! rounds. Kill switch: the disable variable named in `cli`. Test seam:
//! TAMA_CLEAN_AGENT_CMD replaces the model step. Audit journal:
//! state/clean-journal.jsonl; per-repo mkdir locks in state/clean-locks/.
//!
//! The parts live in four modules because the whole loop shared one file and
//! the file could not be edited under the three-hundred-line rule.

pub mod agent;
pub mod brief;
pub mod cli;
pub mod journal;
pub mod runner;

pub use brief::{build_brief, is_actionable, BriefParams, GENERATED_PATHS};
pub use cli::{
    clean_summary_lines, main, parse_clean_args, print_clean_usage, CleanArgs, CleanJsonOutput,
    DEFAULT_ROUTE,
};
pub use runner::{clean_repo, CleanParams, CleanResult, Round};
