//! Port of `src/adaptive/segments/runner-command.mjs`: payload parsing,
//! budget computation, and the `/bin/sh -lc` command runner with
//! process-group kill on budget overrun.

use std::io::{Read, Write};
use std::os::unix::process::CommandExt;
use std::path::Path;
use std::process::{Command, Stdio};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

use crate::util::home_dir;

const DEFAULT_BUDGET_SECONDS: f64 = 10.0;
const MS_PER_SECOND: f64 = 1000.0;

extern "C" {
    fn kill(pid: i32, sig: i32) -> i32;
    fn setsid() -> i32;
}

const SIGTERM: i32 = 15;
const SIGKILL: i32 = 9;

/// A registry hook as the runner helpers see it (`hook.id/.command/.timeout`).
#[derive(Debug, Clone)]
pub struct HookSpec {
    /// Raw `id` JSON value (kept verbatim for result frames); `Null` when the
    /// key is absent, matching `undefined` in JS result objects.
    pub id: serde_json::Value,
    pub command: String,
    pub timeout: Option<serde_json::Value>,
}

impl HookSpec {
    /// Template-literal rendering of `hook.id` (`${hook.id}`).
    pub fn id_text(&self) -> String {
        if self.id.is_null() {
            "undefined".to_string()
        } else {
            crate::util::js_string(&self.id)
        }
    }
}

/// `expandHome(command)`: `~` before `/` or end, plus every `$HOME`.
pub fn expand_home(command: &str) -> String {
    let home = home_dir().to_string_lossy().to_string();
    let mut out = String::with_capacity(command.len());
    let chars: Vec<char> = command.chars().collect();
    let mut index = 0;
    while index < chars.len() {
        let c = chars[index];
        if c == '~' && (index + 1 == chars.len() || chars[index + 1] == '/') {
            out.push_str(&home);
            index += 1;
        } else if c == '$' && chars[index..].starts_with(&['$', 'H', 'O', 'M', 'E']) {
            out.push_str(&home);
            index += 5;
        } else {
            out.push(c);
            index += 1;
        }
    }
    out
}

/// `stdinText()` — all of stdin as utf8.
pub fn stdin_text() -> String {
    let mut buffer = Vec::new();
    let _ = std::io::stdin().read_to_end(&mut buffer);
    String::from_utf8_lossy(&buffer).to_string()
}

/// `parsePayload(text)`.
pub fn parse_payload(text: &str) -> serde_json::Value {
    if text.trim().is_empty() {
        return serde_json::json!({});
    }
    match serde_json::from_str::<serde_json::Value>(text) {
        Ok(value) => value,
        Err(_) => serde_json::json!({ "raw": text }),
    }
}

/// JS `Number(value)` for the timeout field.
fn js_number(value: &serde_json::Value) -> f64 {
    match value {
        serde_json::Value::Number(n) => n.as_f64().unwrap_or(f64::NAN),
        serde_json::Value::String(s) => {
            let trimmed = s.trim();
            if trimmed.is_empty() {
                0.0
            } else {
                trimmed.parse::<f64>().unwrap_or(f64::NAN)
            }
        }
        serde_json::Value::Bool(b) => {
            if *b {
                1.0
            } else {
                0.0
            }
        }
        _ => f64::NAN,
    }
}

/// `budgetMsFor(hook)` — `Math.max(1, Number(hook.timeout || 10)) * 1000`;
/// a `NaN` budget (unparseable timeout) behaves like an immediate timeout.
pub fn budget_ms_for(hook: &HookSpec) -> f64 {
    let raw = match &hook.timeout {
        Some(value) if crate::util::js_truthy(value) => js_number(value),
        _ => DEFAULT_BUDGET_SECONDS,
    };
    let seconds = if raw.is_nan() { f64::NAN } else { raw.max(1.0) };
    seconds * MS_PER_SECOND
}

/// Result of `runCommand`.
#[derive(Debug, Clone)]
pub struct CommandResult {
    pub ms: u64,
    pub code: Option<i32>,
    pub signal: Option<String>,
    pub timed_out: bool,
    pub stdout: String,
    pub stderr: String,
    pub spawn_error: Option<String>,
}

fn signal_group(pid: u32, signal: i32) {
    unsafe {
        if kill(-(pid as i32), signal) != 0 {
            kill(pid as i32, signal);
        }
    }
}

/// `runCommand(command, input, budgetMs)` — sequential Rust equivalent of
/// the JS promise runner; on overrun the detached process group gets
/// SIGTERM, a short grace, then SIGKILL, and the call settles without
/// waiting for `close`, exactly like the JS `setImmediate` chain.
pub fn run_command(command: &str, input: &str, budget_ms: f64) -> CommandResult {
    let started = Instant::now();
    let elapsed_ms = move || started.elapsed().as_millis() as u64;
    let expanded = expand_home(command);
    let spawned = unsafe {
        Command::new("/bin/sh")
            .args(["-lc", &expanded])
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .pre_exec(|| {
                // `detached: true` — own process group for group kills.
                setsid();
                Ok(())
            })
            .spawn()
    };
    let mut child = match spawned {
        Ok(child) => child,
        Err(error) => {
            return CommandResult {
                ms: elapsed_ms(),
                code: None,
                signal: None,
                timed_out: false,
                stdout: String::new(),
                stderr: String::new(),
                spawn_error: Some(format!("Error: {}", error)),
            }
        }
    };
    let pid = child.id();
    if let Some(mut stdin) = child.stdin.take() {
        let input = input.to_string();
        std::thread::spawn(move || {
            let _ = stdin.write_all(input.as_bytes());
        });
    }
    let stdout_buf = Arc::new(Mutex::new(String::new()));
    let stderr_buf = Arc::new(Mutex::new(String::new()));
    fn spawn_reader(
        mut pipe: impl Read + Send + 'static,
        buf: Arc<Mutex<String>>,
    ) -> std::thread::JoinHandle<()> {
        std::thread::spawn(move || {
            let mut chunk = [0u8; 8192];
            loop {
                match pipe.read(&mut chunk) {
                    Ok(0) | Err(_) => break,
                    Ok(n) => {
                        buf.lock()
                            .unwrap()
                            .push_str(&String::from_utf8_lossy(&chunk[..n]));
                    }
                }
            }
        })
    }
    let mut readers = Vec::new();
    if let Some(pipe) = child.stdout.take() {
        readers.push(spawn_reader(pipe, Arc::clone(&stdout_buf)));
    }
    if let Some(pipe) = child.stderr.take() {
        readers.push(spawn_reader(pipe, Arc::clone(&stderr_buf)));
    }
    let budget = if budget_ms.is_nan() || budget_ms < 0.0 {
        Duration::from_millis(0)
    } else {
        Duration::from_millis(budget_ms as u64)
    };
    let deadline = Instant::now() + budget;
    let mut status = None;
    loop {
        match child.try_wait() {
            Ok(Some(exit)) => {
                status = Some(exit);
                break;
            }
            Ok(None) => {
                if Instant::now() >= deadline {
                    break;
                }
                std::thread::sleep(Duration::from_millis(2));
            }
            Err(_) => break,
        }
    }
    let snapshot = |buf: &Arc<Mutex<String>>| buf.lock().unwrap().clone();
    match status {
        Some(exit) => {
            for reader in readers {
                let _ = reader.join();
            }
            let (code, signal) = decode_exit(exit);
            CommandResult {
                ms: elapsed_ms(),
                code,
                signal,
                timed_out: false,
                stdout: snapshot(&stdout_buf),
                stderr: snapshot(&stderr_buf),
                spawn_error: None,
            }
        }
        None => {
            // Budget exhausted: SIGTERM the group, grace, SIGKILL, settle.
            signal_group(pid, SIGTERM);
            std::thread::sleep(Duration::from_millis(10));
            signal_group(pid, SIGKILL);
            std::thread::sleep(Duration::from_millis(10));
            let _ = child.try_wait();
            CommandResult {
                ms: elapsed_ms(),
                code: None,
                signal: Some("SIGKILL".to_string()),
                timed_out: true,
                stdout: snapshot(&stdout_buf),
                stderr: snapshot(&stderr_buf),
                spawn_error: None,
            }
        }
    }
}

/// Decode an exit status into (code, signal-name) like Node's `close`.
fn decode_exit(exit: std::process::ExitStatus) -> (Option<i32>, Option<String>) {
    use std::os::unix::process::ExitStatusExt;
    if let Some(code) = exit.code() {
        return (Some(code), None);
    }
    let name = exit.signal().map(|sig| match sig {
        1 => "SIGHUP".to_string(),
        2 => "SIGINT".to_string(),
        3 => "SIGQUIT".to_string(),
        6 => "SIGABRT".to_string(),
        9 => "SIGKILL".to_string(),
        13 => "SIGPIPE".to_string(),
        14 => "SIGALRM".to_string(),
        15 => "SIGTERM".to_string(),
        other => format!("SIG{}", other),
    });
    (None, name)
}

/// `decisionFromOutput(text)`.
pub fn decision_from_output(text: &str) -> Option<String> {
    let trimmed = text.trim();
    if trimmed.is_empty() {
        return None;
    }
    let mut candidates = vec![trimmed];
    candidates.extend(trimmed.split('\n'));
    for candidate in candidates {
        let line = candidate.trim();
        if line.is_empty() {
            continue;
        }
        if let Ok(parsed) = serde_json::from_str::<serde_json::Value>(line) {
            if parsed.is_object()
                && parsed.get("decision").and_then(|v| v.as_str()) == Some("block")
            {
                let reason = parsed.get("reason").filter(|r| crate::util::js_truthy(r));
                return Some(match reason {
                    Some(value) => crate::util::js_string(value),
                    None => "hook returned block decision".to_string(),
                });
            }
        }
        if line.starts_with("BLOCKED:") {
            return Some(line.to_string());
        }
    }
    None
}

/// Node-style number rendering inside templates (`${hook.timeout}`).
pub fn js_number_string(value: &serde_json::Value) -> String {
    match value {
        serde_json::Value::Number(n) => {
            if let Some(i) = n.as_i64() {
                i.to_string()
            } else if let Some(u) = n.as_u64() {
                u.to_string()
            } else {
                let f = n.as_f64().unwrap_or(f64::NAN);
                if f.fract() == 0.0 && f.is_finite() && f.abs() < 1e15 {
                    format!("{}", f as i64)
                } else {
                    format!("{}", f)
                }
            }
        }
        other => crate::util::js_string(other),
    }
}

/// `overrunReason(hook)`.
pub fn overrun_reason(hook: &HookSpec) -> String {
    let timeout = match &hook.timeout {
        Some(value) if crate::util::js_truthy(value) => js_number_string(value),
        _ => "10".to_string(),
    };
    format!("{} timed out after {}s", hook.id_text(), timeout)
}

/// `crashReason(hook, result)`.
pub fn crash_reason(hook: &HookSpec, result: &CommandResult) -> String {
    let reason_text = if !result.stderr.is_empty() {
        result.stderr.trim().to_string()
    } else if !result.stdout.is_empty() {
        result.stdout.trim().to_string()
    } else {
        let code = result
            .code
            .map(|c| c.to_string())
            .unwrap_or_else(|| "null".to_string());
        format!("exit {}", code)
    };
    format!("{}: {}", hook.id_text(), reason_text)
}

/// Node `path.extname`: suffix from the last dot of the basename, `''` for
/// dotfiles and names without a dot.
pub fn extname(path: &str) -> String {
    let base = Path::new(path)
        .file_name()
        .map(|n| n.to_string_lossy().to_string())
        .unwrap_or_default();
    match base.rfind('.') {
        Some(index) if index > 0 => base[index..].to_string(),
        _ => String::new(),
    }
}
