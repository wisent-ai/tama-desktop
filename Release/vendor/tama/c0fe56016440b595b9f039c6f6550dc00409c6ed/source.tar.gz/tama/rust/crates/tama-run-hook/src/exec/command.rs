//! Port of `runCommand`: spawn one hook command and capture its result.

use std::io::{Read, Write};
use std::process::{Command, Stdio};

use serde_json::Value;

use tama_hooks::hook_exec::tokenize_command;
use tama_hooks::session_capability::capability_environment;

use super::{expand_home, spawn_error_message, RunResult};

/// Port of `runCommand`: argv spawn (no shell) with the capability
/// environment, the normalized payload on stdin, and SIGTERM after
/// `timeout_ms` (JS timer semantics: NaN fires immediately, values
/// above the 32-bit signed range — including Infinity — fire after 1 ms).
pub(crate) fn run_command(
    command: &str,
    input: &str,
    timeout_ms: f64,
    capability: Option<&Value>,
) -> RunResult {
    let tokens = tokenize_command(&expand_home(command));
    let (program, args) = match tokens.split_first() {
        Some((program, args)) if !program.is_empty() => (program.clone(), args.to_vec()),
        _ => {
            return RunResult {
                stderr: "empty hook command".to_string(),
                spawn_error: true,
                ..Default::default()
            }
        }
    };
    let mut cmd = Command::new(&program);
    cmd.args(&args)
        // `spawn(program, args, { env })` replaces the whole environment.
        .env_clear()
        .envs(capability_environment(capability, &[]))
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped());
    let mut child = match cmd.spawn() {
        Ok(child) => child,
        Err(error) => {
            return RunResult {
                stderr: spawn_error_message(&program, &error),
                spawn_error: true,
                ..Default::default()
            }
        }
    };
    let mut stdout_handle = child.stdout.take();
    let mut stderr_handle = child.stderr.take();
    let stdout_thread = std::thread::spawn(move || -> Vec<u8> {
        let mut buf = Vec::new();
        if let Some(mut out) = stdout_handle.take() {
            let _ = out.read_to_end(&mut buf);
        }
        buf
    });
    let stderr_thread = std::thread::spawn(move || -> Vec<u8> {
        let mut buf = Vec::new();
        if let Some(mut err) = stderr_handle.take() {
            let _ = err.read_to_end(&mut buf);
        }
        buf
    });
    let mut stdin_error = None;
    if let Some(mut stdin) = child.stdin.take() {
        if let Err(error) = stdin.write_all(input.as_bytes()) {
            // `child.stdin.on('error', ...)` appends the message to stderr.
            stdin_error = Some(if error.kind() == std::io::ErrorKind::BrokenPipe {
                "write EPIPE".to_string()
            } else {
                error.to_string()
            });
        }
        // Dropping stdin closes it, like `child.stdin.end(input)`.
    }
    let timeout = if timeout_ms.is_nan() {
        std::time::Duration::from_millis(0)
    } else if !timeout_ms.is_finite() || timeout_ms > 2_147_483_647.0 {
        std::time::Duration::from_millis(1)
    } else {
        std::time::Duration::from_millis(timeout_ms as u64)
    };
    let start = std::time::Instant::now();
    let mut timed_out = false;
    let status = loop {
        match child.try_wait() {
            Ok(Some(status)) => break Some(status),
            Ok(None) => {
                if start.elapsed() >= timeout {
                    timed_out = true;
                    // `child.kill('SIGTERM')`; afterwards JS waits for 'close'
                    // indefinitely, so we simply block on wait().
                    let _ = Command::new("kill")
                        .args(["-TERM", &child.id().to_string()])
                        .status();
                    break child.wait().ok();
                }
                std::thread::sleep(std::time::Duration::from_millis(5));
            }
            Err(_) => break None,
        }
    };
    let stdout_bytes = stdout_thread.join().unwrap_or_default();
    let stderr_bytes = stderr_thread.join().unwrap_or_default();
    let mut stderr = String::from_utf8_lossy(&stderr_bytes).into_owned();
    if let Some(message) = stdin_error {
        stderr.push_str(&message);
    }
    RunResult {
        code: status.and_then(|s| s.code()),
        timed_out,
        stdout: String::from_utf8_lossy(&stdout_bytes).into_owned(),
        stderr,
        spawn_error: false,
    }
}
