//! `tama copies` — find and remove second full checkouts of repositories this
//! machine already has.
//!
//! `block-repository-copies` refuses two nouns, and until now only one of
//! them could be reclaimed. A *linked worktree* is tracked by git itself and
//! `tama worktrees remove` takes it. A *repository copy* is a second checkout
//! with its own `.git`, which a clone of a local path or a recursive copy
//! produces, and the original knows nothing about it — so no command could
//! reach it. On 2026-09-09 this machine held an 8.4 GiB clone of the content
//! platform's upstream in `backends/.work/content-platform-upstream-https`,
//! a 9.9 GiB `backends/wisent-open-source`, and 45 nested checkouts totalling
//! 24 GiB, under an operator order of one checkout per repository. A guard
//! that blocks the next copy while leaving every existing one unreachable is
//! half a policy.
//!
//! A copy goes by deleting its directory, which git cannot undo, so the pass
//! proves first that nothing lives only there: uncommitted changes, commits
//! absent from every remote, a missing `origin` to compare against, no
//! canonical checkout of the same repository under the root, or linked
//! worktrees hanging off the copy itself are each a refusal that keeps it.
//!
//! `discovery` holds what exists, `remove` what deleting it does, `state` the
//! git reads both need, `render` the printed shapes; this module is the
//! argument surface: the leaves, the usage refusals and the exit codes.

use std::fmt;

mod discovery;
mod remove;
mod render;
mod state;

pub(crate) use discovery::list_document;
use discovery::Refusal;
pub(crate) use remove::remove_document;
use render::{print_json, print_list, print_remove, refusal_sentence};

const EXIT_USAGE: i32 = 2;
const USAGE: &str = "tama copies <command>

Commands:
  list   [--root <PATH>]... [--json]                     Every second full checkout under the roots
  remove [--root <PATH>]... [--except <PATH>]... [--only <PATH>]... [--apply] [--force] [--json]  Remove them; previews unless --apply

  --except <PATH>  Leave that one copy alone: it is neither removed nor able
                   to refuse the pass. Repeatable, remove only.
  --only <PATH>    Narrow the pass to that copy, and accept it as removable
                   even when it is the sole checkout of its repository here.
                   Every refusal that protects history still applies.
                   Repeatable, remove only, not with --except.";

/// Emitted on both leaves when no `--root` was given. There is deliberately
/// no default root: the tree holding the copies on this machine
/// (`~/Documents/CodingProjects/Wisent`) sits beside trees Tama does not own,
/// so the operator names the tree.
pub(crate) const MISSING_ROOT: &str =
    "tama copies needs at least one --root; a machine-wide default would walk directories Tama does not own.";

/// An `--except` value naming nothing the pass would otherwise consider. The
/// operator asked to spare a specific copy; sparing nothing instead would let
/// a pass they believed narrowed remove everything.
pub(crate) fn unknown_except_sentence(path: &str) -> String {
    format!(
        "tama copies does not know the copy {path}; --except takes the path of a copy this pass would otherwise remove."
    )
}

/// An `--only` value naming nothing the pass would otherwise consider. The
/// operator asked to remove one specific copy; narrowing to nothing instead
/// would print a clean pass over an empty list and read as success.
pub(crate) fn unknown_only_sentence(path: &str) -> String {
    format!(
        "tama copies does not know the copy {path}; --only takes the path of a copy this pass found."
    )
}

#[derive(Debug)]
pub(crate) enum CommandError {
    MissingRoot,
    /// The `--except` value, exactly as the operator spelled it.
    UnknownExcept(String),
    /// The `--only` value, exactly as the operator spelled it.
    UnknownOnly(String),
    /// Every copy the pass had to refuse, so the operator sees all of them at
    /// once instead of one per re-run.
    Refused(Vec<Refusal>),
    Operational(String),
}

impl fmt::Display for CommandError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::MissingRoot => formatter.write_str(MISSING_ROOT),
            Self::UnknownExcept(path) => formatter.write_str(&unknown_except_sentence(path)),
            Self::UnknownOnly(path) => formatter.write_str(&unknown_only_sentence(path)),
            Self::Refused(refusals) => {
                let sentences: Vec<String> = refusals.iter().map(refusal_sentence).collect();
                formatter.write_str(&sentences.join("\n"))
            }
            Self::Operational(error) => formatter.write_str(error),
        }
    }
}

struct Options {
    roots: Vec<String>,
    except: Vec<String>,
    only: Vec<String>,
    apply: bool,
    force: bool,
    json: bool,
}

/// `--root`, `--except` and `--only` are repeatable and take a value;
/// `--apply` and `--force` are flags. Anything else is a usage error, an
/// empty value included.
fn parse(args: &[String]) -> Option<Options> {
    let mut options = Options {
        roots: Vec::new(),
        except: Vec::new(),
        only: Vec::new(),
        apply: false,
        force: false,
        json: false,
    };
    let mut index = 0;
    while index < args.len() {
        match args[index].as_str() {
            "--json" => options.json = true,
            "--apply" => options.apply = true,
            "--force" => options.force = true,
            name @ ("--root" | "--except" | "--only") => {
                let value = args.get(index + 1)?;
                if value.is_empty() {
                    return None;
                }
                match name {
                    "--root" => options.roots.push(value.clone()),
                    "--except" => options.except.push(value.clone()),
                    _ => options.only.push(value.clone()),
                }
                index += 2;
                continue;
            }
            _ => return None,
        }
        index += 1;
    }
    Some(options)
}

fn usage(code: i32) -> i32 {
    eprintln!("{USAGE}");
    code
}

fn list(rest: &[String]) -> Result<i32, CommandError> {
    let Some(options) = parse(rest) else {
        return Ok(usage(EXIT_USAGE));
    };
    // `list` mutates nothing, so the removal flags — `--except` and `--only`
    // among them, since there is nothing to be spared from or narrowed to —
    // are not its vocabulary.
    if options.apply || options.force || !options.except.is_empty() || !options.only.is_empty() {
        return Ok(usage(EXIT_USAGE));
    }
    let document = list_document(&options.roots)?;
    if options.json {
        print_json(&document);
    } else {
        print_list(&document);
    }
    Ok(0)
}

fn remove(rest: &[String]) -> Result<i32, CommandError> {
    let Some(options) = parse(rest) else {
        return Ok(usage(EXIT_USAGE));
    };
    // Sparing paths and narrowing to paths are two answers to the same
    // question, and a pass carrying both leaves which one won unreadable.
    if !options.except.is_empty() && !options.only.is_empty() {
        return Ok(usage(EXIT_USAGE));
    }
    let document = remove_document(
        &options.roots,
        &options.except,
        &options.only,
        options.apply,
        options.force,
    )?;
    if options.json {
        print_json(&document);
    } else {
        print_remove(&document, options.apply);
    }
    // A preview mutates nothing and is never a failure; only an --apply pass
    // that had to be refused is.
    if document.refused.is_empty() || !options.apply {
        return Ok(0);
    }
    if options.json {
        return Ok(1);
    }
    Err(CommandError::Refused(document.refused))
}

fn run(args: &[String]) -> Result<i32, CommandError> {
    let rest = args.get(1..).unwrap_or_default();
    match args.first().map(String::as_str) {
        Some("help" | "--help" | "-h") | None => Ok(usage(0)),
        Some("list") => list(rest),
        Some("remove") => remove(rest),
        _ => Ok(usage(EXIT_USAGE)),
    }
}

pub(crate) fn main(args: &[String]) -> i32 {
    match run(args) {
        Ok(code) => code,
        Err(CommandError::MissingRoot) => {
            eprintln!("{MISSING_ROOT}");
            usage(EXIT_USAGE)
        }
        // One sentence and no usage block: the flag was spelled correctly and
        // the operator needs the path they got wrong, not the whole grammar.
        Err(error @ (CommandError::UnknownExcept(_) | CommandError::UnknownOnly(_))) => {
            eprintln!("{error}");
            EXIT_USAGE
        }
        Err(error @ CommandError::Refused(_)) => {
            eprintln!("{error}");
            1
        }
        Err(CommandError::Operational(error)) => {
            eprintln!("copies: {error}");
            1
        }
    }
}
