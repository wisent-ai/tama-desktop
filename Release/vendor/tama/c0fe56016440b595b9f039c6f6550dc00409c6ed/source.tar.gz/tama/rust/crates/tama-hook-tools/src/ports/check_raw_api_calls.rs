//! Ports `shared-hooks/check_raw_api_calls.py` (hook `check-raw-api-calls`).
//!
//! A `PreToolUse` gate against raw HTTP into the REST surface of the
//! bot-classified sites. The bypass it closes is the one its Python docstring
//! names: a `fetch()` that never drives the browser carries none of the SPA
//! headers those sites fingerprint, so the call reads as a bot and the account
//! is disabled. Hosts, patterns, allowlist, per-line opt-out and banner are the
//! Python's, unchanged.

use regex::Regex;
use serde_json::Value;
use tama_hooks::session_record::{deny_tool_use, read_payload};

use crate::ports::{pystr, pyvalue};

/// `BOT_HOST_RE` — hosts that fingerprint the full SPA header set.
const BOT_HOST: &str = "(?:discord|discordapp|linkedin|tiktok|twitter|x|instagram|facebook|\
reddit|youtube|producthunt|threads)\\.com";

/// `CDN_HOST_RE` — public asset hosts: auth-less GET, no bot signal.
const CDN_HOST: &str = "cdn\\.(?:discordapp|linkedin|tiktok|twitter|x|instagram|facebook|\
reddit|youtube)\\.com";

/// `_API_PATH_RE`.
const API_PATH: &str = "/(?:api|voyager|graphql|gateway|i)\\b";

const CDN_PLACEHOLDER: &str = "_CDN_HOST_";

/// `ALLOWLISTED_PATH_FRAGMENTS` — substring match, order preserved because the
/// banner lists them.
const ALLOWLISTED_PATH_FRAGMENTS: &[&str] = &[
    "/weles/src/session/",
    "/weles/dist/session/",
    "/weles/src/proxy/",
    "/weles/dist/proxy/",
    "/weles/src/utils/sms.",
    "/weles/dist/utils/sms.",
    "/weles/src/utils/burned.",
    "/weles/dist/utils/burned.",
    "/.weles/runs/dbg/",
];

const SCANNED_EXTS: &[&str] = &[".mjs", ".ts", ".tsx", ".js", ".jsx", ".py", ".ipynb"];

const BYPASS_MARKERS: &[&str] = &["allow-raw-api:"];

/// `enumerate(content.splitlines(), start=1)`.
const FIRST_LINE_TEXT: &str = "1";
/// `violations[:10]` in `report`.
const MAX_REPORTED_TEXT: &str = "10";
/// `line[:160]` in `report`.
const REPORT_LINE_CHARS_TEXT: &str = "160";
/// `m.group(0)[:80]` in the string-concat reason.
const CONCAT_SAMPLE_CHARS_TEXT: &str = "80";
/// `cmd[:200]` for the single synthetic line of a Bash payload.
const BASH_LINE_CHARS_TEXT: &str = "200";
/// Python reports an uncaught `AttributeError`/`TypeError` as exit 1.
const CRASH_STATUS_TEXT: &str = "1";

fn first_line() -> usize {
    FIRST_LINE_TEXT.parse().unwrap_or_default()
}

fn max_reported() -> usize {
    MAX_REPORTED_TEXT.parse().unwrap_or_default()
}

fn report_line_chars() -> usize {
    REPORT_LINE_CHARS_TEXT.parse().unwrap_or_default()
}

fn concat_sample_chars() -> usize {
    CONCAT_SAMPLE_CHARS_TEXT.parse().unwrap_or_default()
}

fn bash_line_chars() -> usize {
    BASH_LINE_CHARS_TEXT.parse().unwrap_or_default()
}

/// The Python raises on a payload shape it cannot `.get`, which the hook runner
/// sees as a non-blocking error rather than a decision.
fn crash() -> ! {
    eprintln!("check_raw_api_calls: payload is not a mapping");
    std::process::exit(CRASH_STATUS_TEXT.parse().unwrap_or_default())
}

struct Violation {
    line_no: usize,
    line: String,
    reason: String,
}

struct Patterns {
    cdn: Regex,
    url: Vec<Regex>,
    concat: Regex,
}

impl Patterns {
    fn new() -> Patterns {
        let cdn = Regex::new(&format!("(?i){CDN_HOST}")).unwrap();
        let url = vec![
            Regex::new(&format!(
                "(?i)https?://(?:[a-z0-9-]+\\.)?{BOT_HOST}/(?:api|voyager|graphql|gateway|i)\\b"
            ))
            .unwrap(),
            Regex::new(&format!("(?i)https?://api\\.{BOT_HOST}\\b")).unwrap(),
        ];
        let concat = Regex::new(&format!(
            "(?i)['\"]https?://(?:[a-z0-9-]+\\.)?{BOT_HOST}{API_PATH}[^'\"]*['\"][ \\t]*\\+\
|\\+[ \\t]*['\"]https?://(?:[a-z0-9-]+\\.)?{BOT_HOST}"
        ))
        .unwrap();
        Patterns { cdn, url, concat }
    }

    /// The URL-literal patterns win; concat is only consulted when none fired,
    /// so a line is never flagged twice.
    fn reason_for(&self, raw_line: &str) -> Option<String> {
        if line_has_bypass(raw_line) {
            return None;
        }
        let line = self.cdn.replace_all(raw_line, CDN_PLACEHOLDER);
        for pattern in &self.url {
            if let Some(hit) = pattern.find(&line) {
                return Some(format!("raw URL literal: {}", hit.as_str()));
            }
        }
        let hit = self.concat.find(&line)?;
        Some(format!(
            "string-concat URL: {}",
            pystr::head_chars(hit.as_str(), concat_sample_chars())
        ))
    }

    fn scan_text(&self, content: &str) -> Vec<Violation> {
        let start = first_line();
        let mut violations = Vec::new();
        for (index, raw_line) in pystr::splitlines(content).into_iter().enumerate() {
            let Some(reason) = self.reason_for(raw_line) else {
                continue;
            };
            violations.push(Violation {
                line_no: start + index,
                line: pystr::rstrip(raw_line).to_string(),
                reason,
            });
        }
        violations
    }
}

fn is_allowlisted(file_path: &str) -> bool {
    ALLOWLISTED_PATH_FRAGMENTS
        .iter()
        .any(|fragment| file_path.contains(fragment))
}

fn line_has_bypass(line: &str) -> bool {
    BYPASS_MARKERS.iter().any(|marker| line.contains(marker))
}

fn is_falsy(value: &Value) -> bool {
    !pyvalue::truthy(value)
}

/// `payload.get("tool_input", {}) or {}`.
fn tool_input(payload: &Value) -> Value {
    let raw = payload.get("tool_input").cloned().unwrap_or_default();
    if is_falsy(&raw) {
        return Value::Object(Default::default());
    }
    if !raw.is_object() {
        crash();
    }
    raw
}

/// `input.get(a) or input.get(b) or ""`, where a truthy non-string would reach
/// a `str`-only operation and raise.
fn first_truthy_text(input: &Value, keys: &[&str]) -> String {
    for key in keys {
        let Some(value) = input.get(key) else {
            continue;
        };
        if is_falsy(value) {
            continue;
        }
        match value.as_str() {
            Some(text) => return text.to_string(),
            None => crash(),
        }
    }
    String::new()
}

fn report(target: &str, violations: &[Violation]) -> ! {
    let target = if target.is_empty() {
        "<bash command>"
    } else {
        target
    };
    let mut banner =
        format!("BLOCKED: raw HTTP call to bot-classified site detected\n  in: {target}\n\n");
    let chars = report_line_chars();
    for hit in violations.iter().take(max_reported()) {
        banner.push_str(&format!("  line {}: {}\n", hit.line_no, hit.reason));
        banner.push_str(&format!("    > {}\n", pystr::head_chars(&hit.line, chars)));
    }
    banner.push_str(RULE_HEAD);
    for fragment in ALLOWLISTED_PATH_FRAGMENTS {
        banner.push_str(&format!("  - {fragment}\n"));
    }
    banner.truncate(banner.len() - "\n".len());
    banner.push_str(RULE_TAIL);
    deny_tool_use(&banner)
}

const RULE_HEAD: &str = concat!(
    "\nRule (CLAUDE.md auto-added 2026-05-09): 'Never use raw Playwright ",
    "APIs in any scrape/harvest/visit script targeting a bot-classified ",
    "site — always use the humanized atoms.' Raw fetch() against ",
    "/api/voyager/graphql endpoints is the same anti-pattern — the ",
    "missing SPA headers (X-Super-Properties, X-Discord-Locale, ",
    "Sec-CH-UA-*) are an immediate bot signal.\n",
    "\nLegitimate paths:\n",
    "  - drive the SPA via WSession + humanized atoms (humanClick/Fill/Type)\n",
    "  - or use s.page.context().request.get/post (routes through the\n",
    "    authenticated browser context's cookie jar + fingerprint)\n",
    "\nAllowlisted directories (these may make raw bot-host calls):\n",
);

/// `deny_tool_use` supplies the newline `print` would have added.
const RULE_TAIL: &str = concat!(
    "\n\nPer-line bypass: append `// allow-raw-api: <reason>` on the same\n",
    "line as the call. No env-var blanket bypass — closed loophole.\n",
);

fn check_write_edit(payload: &Value, patterns: &Patterns) {
    let input = tool_input(payload);
    let file_path = first_truthy_text(&input, &["file_path", "notebook_path"]);
    if file_path.is_empty() {
        return;
    }
    if !SCANNED_EXTS.iter().any(|ext| file_path.ends_with(ext)) {
        return;
    }
    if is_allowlisted(&file_path) {
        return;
    }
    let content = match payload
        .get("tool_name")
        .and_then(Value::as_str)
        .unwrap_or_default()
    {
        "Write" | "NotebookEdit" => first_truthy_text(&input, &["content", "new_source"]),
        "Edit" => first_truthy_text(&input, &["new_string"]),
        _ => return,
    };
    if content.is_empty() {
        return;
    }
    let violations = patterns.scan_text(&content);
    if !violations.is_empty() {
        report(&file_path, &violations);
    }
}

/// The whole command counts as one logical line, bypass marker included.
fn check_bash(payload: &Value, patterns: &Patterns) {
    let command = first_truthy_text(&tool_input(payload), &["command"]);
    if command.is_empty() {
        return;
    }
    let Some(reason) = patterns.reason_for(&command) else {
        return;
    };
    let violations = vec![Violation {
        line_no: first_line(),
        line: pystr::head_chars(&command, bash_line_chars()).to_string(),
        reason,
    }];
    report("", &violations);
}

pub fn run() {
    let payload = read_payload();
    if is_falsy(&payload) {
        return;
    }
    if !payload.is_object() {
        crash();
    }
    let patterns = Patterns::new();
    match payload
        .get("tool_name")
        .and_then(Value::as_str)
        .unwrap_or_default()
    {
        "Write" | "Edit" | "NotebookEdit" => check_write_edit(&payload, &patterns),
        "Bash" => check_bash(&payload, &patterns),
        _ => (),
    }
}
