//! The catalog integrity verdict `tama validate` appends to
//! `validate_catalog`. The implementation moved to `tama_core::registry` so
//! the release verification harness can refuse the same catalog; this module
//! keeps the name the CLI calls.

pub use tama_core::registry::wired_without_catalog_errors;
