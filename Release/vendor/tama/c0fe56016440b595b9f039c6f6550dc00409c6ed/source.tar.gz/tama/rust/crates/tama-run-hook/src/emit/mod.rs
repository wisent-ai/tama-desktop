//! JSON emission (manual, to preserve the JS key order:
//! decision, reason, blockedHookId, results; id, code, timedOut, failed).

use std::io::Write;

use serde_json::Value;

pub(crate) mod decision;

pub(crate) use decision::decision_from_output;

/// One entry of the `results` array.
pub(crate) enum Record {
    /// `{ id: hook.id, skipped: true }`
    Skipped(Option<Value>),
    /// `{ id, code, timedOut }` plus `failed: true` after a malfunction.
    Exec {
        id: Option<Value>,
        code: Option<i32>,
        timed_out: bool,
        failed: bool,
    },
}

pub(crate) fn json_str(s: &str) -> String {
    serde_json::to_string(s).unwrap_or_else(|_| "\"\"".to_string())
}

pub(crate) fn json_value(v: &Value) -> String {
    serde_json::to_string(v).unwrap_or_else(|_| "null".to_string())
}

fn serialize_results(results: &[Record]) -> String {
    let mut out = String::from("[");
    for (i, record) in results.iter().enumerate() {
        if i > 0 {
            out.push(',');
        }
        match record {
            Record::Skipped(id) => {
                out.push('{');
                if let Some(id) = id {
                    out.push_str("\"id\":");
                    out.push_str(&json_value(id));
                    out.push(',');
                }
                out.push_str("\"skipped\":true}");
            }
            Record::Exec {
                id,
                code,
                timed_out,
                failed,
            } => {
                out.push('{');
                if let Some(id) = id {
                    out.push_str("\"id\":");
                    out.push_str(&json_value(id));
                    out.push(',');
                }
                out.push_str("\"code\":");
                match code {
                    Some(c) => out.push_str(&c.to_string()),
                    None => out.push_str("null"),
                }
                out.push_str(",\"timedOut\":");
                out.push_str(if *timed_out { "true" } else { "false" });
                if *failed {
                    out.push_str(",\"failed\":true");
                }
                out.push('}');
            }
        }
    }
    out.push(']');
    out
}

pub(crate) fn pass_with_reason_json(reason: &str) -> String {
    format!("{{\"decision\":\"pass\",\"reason\":{}}}", json_str(reason))
}

pub(crate) fn pass_with_results_json(results: &[Record]) -> String {
    format!(
        "{{\"decision\":\"pass\",\"results\":{}}}",
        serialize_results(results)
    )
}

pub(crate) fn block_json(reason: &str, blocked_id: Option<&Value>, results: &[Record]) -> String {
    let mut out = String::from("{\"decision\":\"block\",\"reason\":");
    out.push_str(&json_str(reason));
    if let Some(id) = blocked_id {
        out.push_str(",\"blockedHookId\":");
        out.push_str(&json_value(id));
    }
    out.push_str(",\"results\":");
    out.push_str(&serialize_results(results));
    out.push('}');
    out
}

/// Port of `emitDecision`. Returns the process exit code contribution
/// (2 for a block with a non-codex provider).
pub(crate) fn emit_decision(provider: &str, decision: &str, json: &str) -> i32 {
    if provider == "codex" {
        if decision != "pass" {
            let value: Value = serde_json::from_str(json).unwrap_or(Value::Null);
            let reason = value
                .get("reason")
                .and_then(Value::as_str)
                .unwrap_or("hook returned block decision");
            let codex = serde_json::json!({
                "decision": "block",
                "reason": reason,
            });
            let mut out = std::io::stdout().lock();
            let _ = out.write_all(codex.to_string().as_bytes());
            let _ = out.flush();
        }
        return 0;
    }
    let mut out = std::io::stdout().lock();
    let _ = out.write_all(json.as_bytes());
    let _ = out.flush();
    if decision == "block" {
        2
    } else {
        0
    }
}

pub(crate) fn write_stderr(text: &str) {
    let mut err = std::io::stderr().lock();
    let _ = err.write_all(text.as_bytes());
    let _ = err.flush();
}
