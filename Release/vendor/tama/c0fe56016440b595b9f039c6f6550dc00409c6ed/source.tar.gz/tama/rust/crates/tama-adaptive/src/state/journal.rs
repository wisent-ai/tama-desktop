//! Port of `src/adaptive/state/journal.mjs`: immutable per-hook fact journal.

use sha2::{Digest, Sha256};
use std::fs::{self, OpenOptions};
use std::io::Write;
use std::path::{Path, PathBuf};

use super::Warn;

/// `keyOf(hookId)` — sha256 hex of the hook id string.
pub fn key_of(hook_id: &str) -> String {
    format!("{:x}", Sha256::digest(hook_id.as_bytes()))
}

pub struct FactJournal {
    root: PathBuf,
    warn: Warn,
}

impl FactJournal {
    /// `openFactJournal(stateDir, warn)` — creates the facts root eagerly.
    pub fn open(state_dir: &Path, warn: Warn) -> Self {
        let root = state_dir.join("facts");
        let _ = fs::create_dir_all(&root);
        FactJournal { root, warn }
    }

    fn path_for(&self, hook_id: &str) -> PathBuf {
        self.root.join(format!("{}.jsonl", key_of(hook_id)))
    }

    /// `read(hookId)`: `Some(facts)` when the journal is healthy (a missing
    /// file is an empty journal), `None` when unreadable, torn, or corrupt.
    pub fn read(&self, hook_id: &str) -> Option<Vec<serde_json::Value>> {
        let path = self.path_for(hook_id);
        if !path.exists() {
            return Some(Vec::new());
        }
        let source = match fs::read_to_string(&path) {
            Ok(source) => source,
            Err(error) => {
                (self.warn)(&format!(
                    "adaptive fact journal unreadable: {}: {}",
                    path.display(),
                    error
                ));
                return None;
            }
        };
        if !source.is_empty() && !source.ends_with('\n') {
            (self.warn)(&format!(
                "adaptive fact journal has an incomplete tail: {}",
                path.display()
            ));
            return None;
        }
        let mut facts = Vec::new();
        for line in source.split('\n') {
            if line.is_empty() {
                continue;
            }
            match parse_fact(line) {
                Ok(fact) => facts.push(fact),
                Err(error) => {
                    (self.warn)(&format!(
                        "adaptive fact journal is corrupt: {}: {}",
                        path.display(),
                        error
                    ));
                    return None;
                }
            }
        }
        Some(facts)
    }

    /// `append(hookId, fact)` — refuses to append after a torn/corrupt tail.
    pub fn append(&self, hook_id: &str, fact: &serde_json::Value) -> std::io::Result<()> {
        if self.read(hook_id).is_none() {
            return Err(std::io::Error::new(
                std::io::ErrorKind::InvalidData,
                format!("adaptive fact journal is not appendable for {}", hook_id),
            ));
        }
        let path = self.path_for(hook_id);
        let existed = path.exists();
        let mut file = OpenOptions::new().append(true).create(true).open(&path)?;
        file.write_all(serde_json::to_string(fact).unwrap_or_default().as_bytes())?;
        file.write_all(b"\n")?;
        file.sync_all()?;
        drop(file);
        if !existed {
            sync_directory(&self.root);
        }
        Ok(())
    }
}

fn parse_fact(line: &str) -> Result<serde_json::Value, String> {
    let fact: serde_json::Value = serde_json::from_str(line).map_err(|e| e.to_string())?;
    let object = fact
        .as_object()
        .ok_or_else(|| "row is not an object".to_string())?;
    let kind = object.get("kind").and_then(|v| v.as_str()).unwrap_or("");
    if kind != "outcome" && kind != "contested-block" {
        return Err("unknown fact kind".to_string());
    }
    let identity_ok = object.get("id").map(|v| v.is_string()).unwrap_or(false)
        && object.get("hookId").map(|v| v.is_string()).unwrap_or(false);
    if !identity_ok {
        return Err("fact identity is invalid".to_string());
    }
    Ok(fact)
}

/// fsync a directory (`openSync(path, 'r')` + `fsyncSync`).
pub fn sync_directory(path: &Path) {
    if let Ok(dir) = fs::File::open(path) {
        let _ = dir.sync_all();
    }
}
