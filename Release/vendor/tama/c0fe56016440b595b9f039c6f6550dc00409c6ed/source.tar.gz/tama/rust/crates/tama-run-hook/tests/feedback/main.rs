#![cfg(unix)]

//! The owner-feedback loop, driven through the real runtime binary.
//!
//! What the product promises: a block puts its real payload in that hook's
//! replay corpus, a direct correction of that block labels the case and queues
//! a repair, and `adaptive repair` then has the labeled cases it validates a
//! candidate against. What happened instead, measured 2026-09-10 on a machine
//! driven only through this runtime: the corpus had not changed since
//! 2026-07-09 although hooks blocked many times a day, every hook reported
//! `contested=false`, the repair queue was empty, and the documented repair
//! route could not be walked at all — twice in one day the fix had to go
//! through the owner's own shell instead.
//!
//! Three things were missing and all three are asserted here: this runtime
//! never recorded a block for the adaptive layer, never handed a prompt to the
//! feedback bridge, and the bridge itself only opened its door to frustration
//! vocabulary, so a calm correction naming the hook was thrown away.

use std::fs;
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

use serde_json::{json, Value};
use tama_hooks::sha256::sha256_hex;

/// This suite's own state, inside the build directory, so no case can read or
/// write the operator's adaptive state.
fn root(label: &str) -> PathBuf {
    let nonce = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .expect("clock before epoch")
        .as_nanos();
    let root = PathBuf::from(env!("CARGO_TARGET_TMPDIR"))
        .join(format!("feedback-{label}-{}-{nonce}", std::process::id()));
    fs::create_dir_all(root.join("state")).expect("create the state root");
    root
}

/// Durable evidence lives in the Transcript Lake, which is machine-wide: the
/// product's reader walks it on every call and re-hashes every committed
/// segment. Pointing it at a directory that does not exist keeps this suite off
/// the operator's own lake — and keeps it quick, because reading that lake for
/// real takes tens of seconds on a working machine.
fn isolate_lake() -> PathBuf {
    let lake = PathBuf::from(env!("CARGO_TARGET_TMPDIR")).join("feedback-absent-lake");
    std::env::set_var("LAKE_DATA", &lake);
    lake
}

/// A hook that refuses everything, so the block under test is the fixture's own
/// and not some rule of this machine.
fn refusing_hook(root: &Path) -> PathBuf {
    let path = root.join("refuse.sh");
    fs::write(
        &path,
        "#!/bin/sh\nprintf '%s' '{\"decision\":\"block\",\"reason\":\"fixture refuses\"}'\n",
    )
    .expect("write the fixture hook");
    let mut permissions = fs::metadata(&path)
        .expect("stat the fixture hook")
        .permissions();
    std::os::unix::fs::PermissionsExt::set_mode(&mut permissions, 0o755);
    fs::set_permissions(&path, permissions).expect("make the fixture hook executable");
    path
}

/// The fixture registry, in the shape the runtime parses: one refusing hook on
/// a tool event, and the prompt event the feedback hand-off rides on.
fn publish_registry(root: &Path, hook_id: &str) {
    let hook = refusing_hook(root);
    let mut document = json!({
        "releaseId": "feedback-fixture",
        "events": {
            "pre_tool_use:bash": {
                "blocking": true,
                "hooks": [{
                    "id": hook_id,
                    "command": hook.to_string_lossy(),
                    "timeout": 10,
                }],
            },
            "user_prompt_submit": { "blocking": false, "hooks": [] },
        },
    });
    document["catalogChecksum"] = json!(sha256_hex(
        &serde_json::to_vec(&document).expect("serialize the fixture registry")
    ));
    fs::write(
        root.join("registry.json"),
        serde_json::to_vec(&document).expect("serialize the fixture registry"),
    )
    .expect("publish the fixture registry");
}

fn dispatch(root: &Path, event: &str, payload: &Value) -> String {
    let output = Command::new(env!("CARGO_BIN_EXE_tama-run-hook"))
        .args([event, "omp"])
        .env("AGENT_HOOK_REGISTRY", root.join("registry.json"))
        .env("HOOKS_ADAPTIVE_STATE", root.join("state"))
        .env("TAMA_PROVIDER", "omp")
        // Neither file exists, which is how the product reads "every hook
        // enforces, nothing is emergency-disabled". Without this the machine's
        // own `enforcement only` selection reaches in and the fixture hook is
        // skipped, so the suite would measure this laptop instead of the code.
        .env("TAMA_HOOK_ENFORCEMENT", root.join("enforcement.json"))
        .env("TAMA_EMERGENCY_STATE", root.join("emergency.json"))
        // The bridge reads the owner's own correction vocabulary out of Oko's
        // transcript index under their home. This suite gets a home of its
        // own: it must neither read the operator's transcripts nor wait on
        // that database, and the static vocabulary is what it exercises.
        .env("HOME", root)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .and_then(|mut child| {
            use std::io::Write;
            child
                .stdin
                .as_mut()
                .expect("the runtime takes stdin")
                .write_all(payload.to_string().as_bytes())?;
            child.wait_with_output()
        })
        .expect("run the runtime");
    String::from_utf8_lossy(&output.stdout).to_string()
}

fn closed_events(root: &Path, kind: &str) -> Vec<Value> {
    tama_adaptive::doctor::repair::read_closed_telemetry_events(&root.join("state"))
        .unwrap_or_default()
        .into_iter()
        .filter(|row| row.get("type").and_then(Value::as_str) == Some(kind))
        .collect()
}

/// The bridge is a detached child, so its result arrives shortly after the
/// prompt returns. Read it through the product's own reader.
fn awaited_events(root: &Path, kind: &str, window: Duration) -> Vec<Value> {
    let deadline = Instant::now() + window;
    loop {
        let rows = closed_events(root, kind);
        if !rows.is_empty() || Instant::now() >= deadline {
            return rows;
        }
        std::thread::sleep(Duration::from_millis(100));
    }
}

fn attribution_window() -> Duration {
    Duration::from_secs(20)
}

/// A repair candidate is validated against the payloads the product derives
/// from closed telemetry, not from any file on disk, so this is where a
/// refused payload has to show up.
fn corpus_payloads(root: &Path, hook_id: &str) -> Vec<Value> {
    closed_events(root, "corpus_add")
        .into_iter()
        .filter(|row| row.get("id").and_then(Value::as_str) == Some(hook_id))
        .collect()
}

fn hook_id() -> &'static str {
    "fixture-refuses-everything"
}

fn block_once(root: &Path, session: &str) -> String {
    publish_registry(root, hook_id());
    dispatch(
        root,
        "pre_tool_use:bash",
        &json!({
            "session_id": session,
            "tool_name": "bash",
            "tool_input": { "command": "git -C weles-chromium status" },
        }),
    )
}

#[test]
fn a_block_puts_its_own_payload_in_the_replay_corpus() {
    let root = root("corpus");
    isolate_lake();
    let decision = block_once(&root, "feedback-corpus");

    assert!(
        decision.contains("\"decision\":\"block\""),
        "the fixture hook has to block: {decision}"
    );
    let cases = awaited_events(&root, "corpus_add", Duration::from_secs(5));
    assert!(
        !cases.is_empty(),
        "a block has to add its case to the replay corpus"
    );
    let cases = corpus_payloads(&root, hook_id());
    assert!(
        cases
            .iter()
            .any(|row| serde_json::to_string(row).unwrap_or_default().contains("weles-chromium")),
        "a repair candidate is validated against the refused payload, and the payload is not there: {cases:?}"
    );
}

#[test]
fn a_calm_correction_naming_the_hook_labels_the_case_and_queues_the_repair() {
    let root = root("named");
    isolate_lake();
    block_once(&root, "feedback-named");

    // No swearing and no complaint: the hook is named and a repair is asked
    // for, which is the shape the contract calls a direct correction and
    // exactly what used to be discarded.
    dispatch(
        &root,
        "user_prompt_submit",
        &json!({
            "session_id": "feedback-named",
            "prompt": format!("okej to naprawmy {}", hook_id()),
        }),
    );

    let queued = awaited_events(&root, "repair_proposal", attribution_window());

    assert!(
        queued
            .iter()
            .any(|row| row.get("id").and_then(Value::as_str) == Some(hook_id())),
        "the correction has to queue a repair for the hook it named: {queued:?}"
    );
    let labels = awaited_events(&root, "corpus_label", attribution_window());
    assert!(
        labels.iter().any(|row| {
            row.get("id").and_then(Value::as_str) == Some(hook_id())
                && row.get("label").and_then(Value::as_str) == Some("fp-suspect")
        }),
        "repair validates against labeled cases, and the case is unlabeled: {labels:?}"
    );
}

#[test]
fn a_prompt_that_corrects_nothing_queues_nothing() {
    let root = root("unrelated");
    isolate_lake();
    block_once(&root, "feedback-unrelated");

    dispatch(
        &root,
        "user_prompt_submit",
        &json!({
            "session_id": "feedback-unrelated",
            "prompt": "carry on with the release notes",
        }),
    );

    // The same window the positive case waits for, so an empty queue here is a
    // real absence and not an assertion that won a race.
    let queued = awaited_events(&root, "repair_proposal", Duration::from_secs(3));
    assert!(
        queued.is_empty(),
        "a prompt that neither names a hook nor corrects one stays recommendation evidence: {queued:?}"
    );
}
