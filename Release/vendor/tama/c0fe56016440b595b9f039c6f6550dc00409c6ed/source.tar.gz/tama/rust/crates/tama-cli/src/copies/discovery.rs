//! What a repository copy is under a given tree.
//!
//! Two structural facts shape this module, and the first is borrowed from
//! `crate::worktrees::discovery` for the same reason:
//!
//! - `tama_violations::repo_discovery::discover_every_checkout` answers
//!   "which checkouts exist under this tree", and the emphasis is on EVERY.
//!   Its filtered siblings drop a checkout its owning repository ignores, and
//!   the copies this command exists for live exactly there: below a `.work/`
//!   or `.worktrees/` directory the owning repository ignores.
//! - A copy is removed by deleting a directory, which git cannot undo and no
//!   remote can restore. So the pass proves per candidate that nothing lives
//!   only there, and a candidate git will not answer for is reported instead
//!   of removed. Deleting is [`super::remove`]'s half.

use std::collections::{BTreeMap, BTreeSet};
use std::path::{Path, PathBuf};

use serde::Serialize;
use tama_violations::repo_discovery::discover_every_checkout_deep;
use tama_violations::resolve_path;

use super::state;
use super::CommandError;
use crate::gitcmd::canonical;

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub(crate) struct Copy {
    pub path: String,
    /// The canonical checkout of the same repository under one of the roots,
    /// when the pass found one. `null` is a refusal: without it, this
    /// directory is the only checkout of that repository here.
    pub owner: Option<String>,
    pub origin: Option<String>,
    pub bytes: u64,
    pub dirty: bool,
    pub unpublished: bool,
    pub owns_worktrees: bool,
    /// The operator named this path with `--only`. That answers the one
    /// question the pass cannot answer for itself — whether losing a
    /// directory that is the sole checkout of its repository here loses
    /// anything they want — and nothing else: every refusal that protects
    /// history still applies to it.
    #[serde(default)]
    pub named: bool,
}

/// Two checkouts of one repository, both directly under a root. This pass
/// reports them and never removes one: which of the two an operator keeps is
/// their call, not a sort order's. `stado` and `wisent-compute` here share
/// the origin `wisent-ai/stado.git` while `wisent-compute` is the tree the
/// product is actually built from, so a rule that kept the first name would
/// delete 69 GB of the working tree and call it tidying.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub(crate) struct Twin {
    pub path: String,
    pub twin: String,
    pub origin: String,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub(crate) struct ListDocument {
    pub schema_version: u32,
    pub roots: Vec<String>,
    pub copies: Vec<Copy>,
    pub copy_count: usize,
    pub bytes: u64,
    /// Linked worktrees the walk crossed. Those are second checkouts too, but
    /// git tracks them and `tama worktrees` removes them; naming them here
    /// keeps a clean copies pass from reading as "one checkout per
    /// repository" when it is not.
    pub linked_worktrees: Vec<String>,
    /// Checkouts of one repository that both sit directly under a root.
    pub twins: Vec<Twin>,
    /// Candidates the walk found a `.git` for and git then refused to answer
    /// for. Reported rather than dropped: silence would be the pass claiming
    /// it read a checkout it never read.
    pub unreadable: Vec<String>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub(crate) struct Refusal {
    pub path: String,
    pub reason: &'static str,
}

/// The list document plus the outcome, spelled out rather than flattened so
/// the document is one plain struct in declaration order.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub(crate) struct RemoveDocument {
    pub schema_version: u32,
    pub roots: Vec<String>,
    pub copies: Vec<Copy>,
    pub copy_count: usize,
    pub bytes: u64,
    pub linked_worktrees: Vec<String>,
    pub twins: Vec<Twin>,
    pub unreadable: Vec<String>,
    pub excepted: Vec<String>,
    pub applied: bool,
    pub removed: Vec<String>,
    pub refused: Vec<Refusal>,
}

/// The named root itself, or a checkout directly under it, is a canonical
/// checkout. That is the layout the operator keeps — one directory per
/// repository under `~/Documents/CodingProjects/Wisent` — so depth separates
/// the original from a copy, and no origin comparison can promote a copy over
/// it.
///
/// The root itself has to be here, and the loopback route is what proved it:
/// `POST /v1/copies/list` with `roots: ["…/Wisent/tama"]` reported
/// `…/Wisent/tama` as a copy of nothing, because its parent is `Wisent` and
/// not the root. An operator naming one repository as the root would have
/// been offered their own checkout for deletion.
fn is_canonical(path: &Path, root: &Path) -> bool {
    let real = canonical(path);
    let root = canonical(root);
    real == root || real.parent() == Some(root.as_path())
}

/// The canonical checkout this candidate is a copy of: same origin, or an
/// origin naming that checkout's own path, which is what a clone of a local
/// directory records.
fn owner_of(candidate_origin: &str, canonicals: &[(String, String)]) -> Option<String> {
    let normalized = state::normalize_origin(candidate_origin);
    if let Some((_, path)) = canonicals
        .iter()
        .find(|(origin, _)| state::normalize_origin(origin) == normalized)
    {
        return Some(path.clone());
    }
    let local = state::local_origin_path(candidate_origin)?;
    let real = canonical(Path::new(&local));
    canonicals
        .iter()
        .find(|(_, path)| canonical(Path::new(path)) == real)
        .map(|(_, path)| path.clone())
}

pub(crate) fn list_document(roots: &[String]) -> Result<ListDocument, CommandError> {
    if roots.is_empty() {
        return Err(CommandError::MissingRoot);
    }
    let mut resolved_roots: Vec<String> = Vec::new();
    let mut copies: Vec<Copy> = Vec::new();
    let mut linked_worktrees: Vec<String> = Vec::new();
    let mut twins: Vec<Twin> = Vec::new();
    let mut unreadable: Vec<String> = Vec::new();
    let mut seen: BTreeSet<String> = BTreeSet::new();
    for root in roots {
        let resolved: PathBuf = resolve_path(&[Path::new(root)]);
        resolved_roots.push(resolved.to_string_lossy().into_owned());
        let mut canonicals: Vec<(String, String)> = Vec::new();
        let mut candidates: Vec<String> = Vec::new();
        for checkout in discover_every_checkout_deep(&resolved) {
            if !seen.insert(checkout.clone()) {
                continue;
            }
            let path = Path::new(&checkout);
            if state::is_linked_worktree(path) {
                linked_worktrees.push(checkout);
                continue;
            }
            linked_worktrees.extend(state::linked_worktrees(path));
            if is_canonical(path, &resolved) {
                if let Some(origin) = state::origin(path) {
                    canonicals.push((origin, checkout));
                }
                continue;
            }
            candidates.push(checkout);
        }
        for candidate in candidates {
            let path = Path::new(&candidate);
            let Ok(unpublished) = state::unpublished(path) else {
                unreadable.push(candidate);
                continue;
            };
            let origin = state::origin(path);
            let owner = origin.as_deref().and_then(|url| owner_of(url, &canonicals));
            copies.push(Copy {
                owner,
                origin,
                bytes: state::bytes(path),
                dirty: state::dirty(path),
                unpublished,
                owns_worktrees: state::owns_worktrees(path),
                named: false,
                path: candidate,
            });
        }
        let mut by_origin: BTreeMap<String, Vec<String>> = BTreeMap::new();
        for (origin, path) in &canonicals {
            by_origin
                .entry(state::normalize_origin(origin))
                .or_default()
                .push(path.clone());
        }
        for (origin, mut paths) in by_origin {
            if paths.len() < 2 {
                continue;
            }
            paths.sort();
            let first = paths[0].clone();
            for path in paths.into_iter().skip(1) {
                twins.push(Twin {
                    path,
                    twin: first.clone(),
                    origin: origin.clone(),
                });
            }
        }
    }
    copies.sort_by(|left, right| left.path.cmp(&right.path));
    linked_worktrees.sort();
    twins.sort_by(|left, right| left.path.cmp(&right.path));
    unreadable.sort();
    Ok(ListDocument {
        schema_version: 1,
        roots: resolved_roots,
        copy_count: copies.len(),
        bytes: copies.iter().map(|copy| copy.bytes).sum(),
        copies,
        linked_worktrees,
        twins,
        unreadable,
    })
}

/// Every copy the pass would have to refuse, one sentence each. `--force`
/// refuses nothing, exactly as it does for worktrees.
pub(crate) fn refusals(document: &ListDocument, force: bool) -> Vec<Refusal> {
    if force {
        return Vec::new();
    }
    let mut refusals = Vec::new();
    for copy in &document.copies {
        // Ordered by what the operator has to act on first: work that exists
        // nowhere else, then an identity the pass could not establish, then
        // git records that deleting would orphan.
        let reason = if copy.dirty {
            "uncommitted-changes"
        } else if copy.unpublished {
            "commits-not-on-remote"
        } else if copy.origin.is_none() {
            "no-origin-remote"
        } else if copy.owner.is_none() && !copy.named {
            "no-canonical-checkout"
        } else if copy.owns_worktrees {
            "owns-linked-worktrees"
        } else {
            continue;
        };
        refusals.push(Refusal {
            path: copy.path.clone(),
            reason,
        });
    }
    refusals
}
