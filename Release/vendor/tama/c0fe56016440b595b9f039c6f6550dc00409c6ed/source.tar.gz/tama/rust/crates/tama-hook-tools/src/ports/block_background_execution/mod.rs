//! Refuse work that leaves the operator's sight by going into the background.
//!
//! On 2026-09-09 two `find` passes over the operator's whole home directory
//! ran in the background for minutes. He was never told. He found out by
//! asking me directly what I was doing, and his answer was to stop them and
//! forbid the shape: "ok prosze zatrzymaj je. zablokuj joby w backgroudzie".
//!
//! The harness half is a configuration: `bash.autoBackground.enabled` is off,
//! so a slow foreground command is no longer deferred on its own. This module
//! is the other half, which no configuration covers — a call that ASKS for the
//! background, and a command that backgrounds itself inside the shell.
//!
//! Detecting the second one cannot be done on tokens. `shlex` renders both
//! `grep '&' file` and `sleep 5 &` with a bare `&` token, so a token scan
//! cannot tell an operator from quoted data, and a guard that refused the
//! first would be worse than none. The scan below walks characters and
//! tracks quoting, which is the only place the difference survives.
//!
//! `bash -c '… &'` hides the operator one level down, inside a quoted string
//! the outer scan deliberately skips, so the inner text is scanned as its own
//! command.

use serde_json::Value;
use std::path::Path;

use crate::ports::python_stdlib::{one, shell_tokens};
use crate::ports::pyvalue::{first_truthy_py_str, py_str, truthy};

const TOOL_INPUT_KEY: &str = "tool_input";
const COMMAND_KEYS: &[&str] = &["command", "cmd"];
/// Both spellings a payload may carry for the deferral request.
const ASYNC_KEYS: &[&str] = &["async", "Async"];

/// Programs whose whole purpose is detaching the command from this session.
const DETACHING_PROGRAMS: &[&str] = &["nohup", "disown", "setsid"];
/// Multiplexers that detach only with a flag, so `tmux ls` and `screen -ls`
/// stay ordinary foreground commands.
const MULTIPLEXERS: &[&str] = &["screen", "tmux"];
/// `-d` alone, and the bundles that carry it.
const DETACH_FLAGS: &[&str] = &["-d", "-dm", "-dmS", "-D"];
/// Shells that run a command given as one argument.
const INNER_SHELLS: &[&str] = &["bash", "sh", "zsh", "dash"];
const INNER_FLAG: &str = "-c";

const ASYNC_REASON: &str = "BLOCKED: background execution is forbidden. Run it in the foreground \
                            so its output is seen. Detected: the call asked for the background.";

fn token_reason(token: &str) -> String {
    format!(
        "BLOCKED: background execution is forbidden. Run it in the foreground so its output is \
         seen. Detected: '{token}' puts the command in the background."
    )
}

/// The shell command a payload carries: the named field, else the whole input
/// rendered as Python would render it — the shape the neighbouring shell
/// guards already use.
fn command_from(payload: &Value) -> String {
    let Some(raw) = payload.get(TOOL_INPUT_KEY).filter(|value| truthy(value)) else {
        return String::new();
    };
    if raw.is_object() {
        let named = first_truthy_py_str(raw, COMMAND_KEYS);
        if !named.is_empty() {
            return named;
        }
    }
    py_str(raw)
}

/// Did the call itself ask to be deferred? Only a JSON `true` counts: the
/// string "false" is truthy in Python's sense and must not refuse anything.
fn asked_for_background(payload: &Value) -> bool {
    let Some(raw) = payload.get(TOOL_INPUT_KEY) else {
        return false;
    };
    ASYNC_KEYS
        .iter()
        .any(|key| raw.get(*key) == Some(&Value::Bool(true)))
}

/// `Path(token).name`, so `/usr/bin/nohup` counts as `nohup`.
fn program_is(token: &str, program: &str) -> bool {
    Path::new(token).file_name().and_then(|name| name.to_str()) == Some(program)
}

/// Is there a bare `&` operator outside quotes? `&&` is a separator, not a
/// backgrounding request, so a doubled ampersand is stepped over whole.
fn has_background_operator(command: &str) -> bool {
    let characters: Vec<char> = command.chars().collect();
    let mut index = usize::MIN;
    let mut single = false;
    let mut double = false;
    while index < characters.len() {
        let character = characters[index];
        if character == '\\' && !single {
            index += one() + one();
            continue;
        }
        if character == '\'' && !double {
            single = !single;
        } else if character == '"' && !single {
            double = !double;
        } else if character == '&' && !single && !double {
            // `&&` is a list operator, and `>&`, `<&` and `&>` are
            // redirections: in `2>&1` the ampersand duplicates a file
            // descriptor and starts nothing at all. Only a bare `&`
            // backgrounds, which is the whole subject of this ban. Missing
            // that cost a false refusal of `stado host disk-cleanup ... 2>&1
            // | sed` on 2026-09-09, and the operator asked for a guard
            // against hidden work, not against redirecting stderr.
            let next = characters.get(index + one());
            if next == Some(&'&') || next == Some(&'>') {
                index += one() + one();
                continue;
            }
            if index > usize::MIN {
                let previous = characters[index - one()];
                if previous == '>' || previous == '<' {
                    index += one();
                    continue;
                }
            }
            return true;
        }
        index += one();
    }
    false
}

/// The text of an inner `-c` command, when the segment runs one.
fn inner_command(tokens: &[String]) -> Option<&str> {
    let (program, arguments) = tokens.split_first()?;
    if !INNER_SHELLS
        .iter()
        .any(|candidate| program_is(program, candidate))
    {
        return None;
    }
    let position = arguments.iter().position(|token| token == INNER_FLAG)?;
    arguments.get(position + one()).map(String::as_str)
}

/// A detaching program, or a multiplexer asked to detach.
fn detaching_program(tokens: &[String]) -> Option<String> {
    let (program, arguments) = tokens.split_first()?;
    if let Some(name) = DETACHING_PROGRAMS
        .iter()
        .find(|candidate| program_is(program, candidate))
    {
        return Some((*name).to_string());
    }
    if !MULTIPLEXERS
        .iter()
        .any(|candidate| program_is(program, candidate))
    {
        return None;
    }
    arguments
        .iter()
        .find(|token| DETACH_FLAGS.contains(&token.as_str()))
        .map(|flag| flag.clone())
}

/// The refusal this command earns, looking one shell level down.
fn command_refusal(command: &str) -> Option<String> {
    if has_background_operator(command) {
        return Some(token_reason("&"));
    }
    let tokens = shell_tokens(command);
    if let Some(flag) = detaching_program(&tokens) {
        return Some(token_reason(&flag));
    }
    if let Some(inner) = inner_command(&tokens) {
        return command_refusal(inner);
    }
    None
}

/// The refusal this call earns, or `None` when it passes. The caller writes
/// the banner to stderr and exits 2.
pub fn evaluate(payload: &Value) -> Option<String> {
    if asked_for_background(payload) {
        return Some(ASYNC_REASON.to_string());
    }
    let command = command_from(payload);
    if command.is_empty() {
        return None;
    }
    if let Some(reason) = command_refusal(&command) {
        return Some(reason);
    }
    // A compound command backgrounds only in one of its parts, and the
    // character scan above already reads the whole text, so what is left is
    // to judge each part's own program. Splitting on the separators that are
    // not `&` keeps the operator scan the single authority on ampersands.
    command
        .split([';', '|', '\n'])
        .filter_map(|segment| {
            let tokens = shell_tokens(segment);
            detaching_program(&tokens).map(|flag| token_reason(&flag))
        })
        .next()
}
