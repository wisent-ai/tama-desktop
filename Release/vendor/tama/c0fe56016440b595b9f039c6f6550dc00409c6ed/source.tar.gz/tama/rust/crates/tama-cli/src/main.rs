//! Port of `src/cli.mjs` — the main `tama` binary.
//!
//! Fidelity notes:
//! - `argv` here corresponds to JS `process.argv.slice(2)`: the node and
//!   script path entries never equal a flag, so `has`/`argAfter` over the
//!   remaining arguments behave identically.
//! - `N(x)` = `Number(x)`; exit codes are plain integers (`EXIT_USAGE` = 2).
//! - JS library errors propagate as thrown exceptions (exit 1 with the error
//!   text on stderr); here `Result` errors print the message and exit 1.
//!
//! The crate root stays slim: argument helpers, output helpers, and the
//! per-command handlers live under `cli/`; `main()` only resolves the root
//! and dispatches.

use std::path::PathBuf;

use serde::Serialize;

use tama_core::catalog::repo_root;

mod brama;
mod catalog_integrity;
mod cli;
mod copies;
mod enforcement;
mod gitcmd;
mod justify;
mod onboarding;
mod provider_config;
mod serve;
mod worktrees;

/// `EXIT_USAGE` from `src/adaptive/engine.mjs` (`N('2')`).
const EXIT_USAGE: i32 = 2;

#[derive(Serialize)]
struct McpConfig {
    #[serde(rename = "mcpServers")]
    mcp_servers: McpServers,
}

#[derive(Serialize)]
struct McpServers {
    tama: McpServerEntry,
}

#[derive(Serialize)]
struct McpServerEntry {
    command: String,
    args: Vec<String>,
}

/// The `mcp-config` document, shared with the serve backend: the native Rust
/// MCP server installed next to this binary, or its bare name when no such
/// sibling binary exists.
fn mcp_config() -> McpConfig {
    McpConfig {
        mcp_servers: McpServers {
            tama: McpServerEntry {
                command: std::env::current_exe()
                    .ok()
                    .and_then(|exe| exe.parent().map(|dir| dir.join("tama-mcp-server")))
                    .filter(|path| path.is_file())
                    .map(|path| path.display().to_string())
                    .unwrap_or_else(|| "tama-mcp-server".to_string()),
                args: vec![],
            },
        },
    }
}

/// Rust starts every program with `SIGPIPE` ignored, so a command whose reader
/// closes early - `tama enforcement status | head -2` - fails its next write
/// and panics inside `println!`, printing a Rust panic and a backtrace note
/// over the operator's terminal. Restoring the default disposition makes this
/// end the way every other Unix tool ends a closed pipe: quietly.
fn end_quietly_when_the_reader_closes() {
    const SIGPIPE: i32 = 13;
    const SIG_DFL: usize = 0;
    extern "C" {
        fn signal(signum: i32, handler: usize) -> usize;
    }
    unsafe { signal(SIGPIPE, SIG_DFL) };
}

fn main() {
    end_quietly_when_the_reader_closes();
    // JS `process.argv.slice(2)`.
    let argv: Vec<String> = std::env::args().skip(1).collect();

    // JS `selectedRoot()` = `optionValue('--root', repoRoot())`.
    let root: PathBuf = cli::args::option_value(&argv, "--root")
        .map(PathBuf::from)
        .unwrap_or_else(repo_root);

    let cmd: &str = argv.first().map(String::as_str).unwrap_or("help");

    match cmd {
        "help" | "--help" | "-h" => {
            cli::output::usage();
            std::process::exit(0);
        }
        "onboarding" => std::process::exit(cli::commands::onboarding(&argv, &root)),
        "policy" => std::process::exit(cli::commands::policy(&argv)),
        "list" => std::process::exit(cli::commands::list(&argv, &root)),
        "show" => std::process::exit(cli::commands::show(&argv, &root)),
        "validate" => std::process::exit(cli::commands::validate(&argv, &root)),
        "install-plan" => std::process::exit(cli::commands::install_plan(&argv, &root)),
        "install" => std::process::exit(cli::commands::install(&argv, &root)),
        "verify" => std::process::exit(cli::commands::verify(&root)),
        "justify" => std::process::exit(justify::main(&argv[1..])),
        "find-violations" => {
            std::process::exit(tama_violations::scan_repos::main(&argv[1..], &root))
        }
        "clean" => std::process::exit(tama_violations::clean::main(&argv[1..])),
        "brama-check" => std::process::exit(brama::check::main(&argv[1..])),
        "mcp-config" => {
            cli::output::print_json(&mcp_config());
            std::process::exit(0);
        }
        "enforcement" => std::process::exit(enforcement::main(&argv[1..], &root)),
        "provider-config" => {
            let rest = argv.split_first().map(|(_, rest)| rest).unwrap_or_default();
            std::process::exit(provider_config::main(rest));
        }
        "serve" => std::process::exit(serve::main(&argv[1..], &root)),
        "adaptive" => std::process::exit(tama_adaptive::doctor::cli::main(&argv[1..])),
        "sessions" => std::process::exit(cli::sessions::main(&argv, &root)),
        "worktrees" => std::process::exit(worktrees::main(&argv[1..])),
        "copies" => std::process::exit(copies::main(&argv[1..])),
        "assignment" => std::process::exit(tama_hook_tools::assignment::cli_main(&argv[1..])),
        // Hidden entrypoint used by the installed adaptive runner shim.
        "adaptive-runner" => std::process::exit(tama_adaptive::runner::main(&argv)),
        // Hidden subcommand: spawned by `tama_adaptive::runner::dispatch_bridge`
        // as `<current exe> adaptive-bridge`; intentionally absent from usage.
        "adaptive-bridge" => std::process::exit(tama_adaptive::bridge::main()),
        _ => {
            cli::output::usage();
            std::process::exit(EXIT_USAGE);
        }
    }
}
