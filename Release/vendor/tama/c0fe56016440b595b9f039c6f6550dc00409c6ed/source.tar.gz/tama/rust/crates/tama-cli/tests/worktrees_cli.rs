//! `tama worktrees` against real git and the real binary.
//!
//! Every assertion reads state — the output of `git worktree list
//! --porcelain` and the filesystem — not only what the command printed. The
//! throwaway repository they drive lives in `worktrees_fixture`.

mod worktrees_fixture;

use std::fs;

use serde_json::{json, Value};

use worktrees_fixture::{stderr, stdout, text, Fixture, SCHEMA_VERSION};

#[test]
fn list_reports_both_worktrees_with_their_repository() {
    let fixture = Fixture::new("list");
    let output = fixture.tama(&["worktrees", "list", "--root", &fixture.root()]);
    assert_eq!(output.status.code(), Some(0), "stderr: {}", stderr(&output));
    let printed = stdout(&output);
    for expected in [
        text(fixture.repo()),
        text(fixture.worktree("wt-a")),
        text(fixture.worktree("wt-b")),
        "2 linked worktree(s) in 1 repository(ies).".to_string(),
    ] {
        assert!(printed.contains(&expected), "{expected} missing: {printed}");
    }
}

#[test]
fn list_json_emits_the_contract_document_without_the_main_worktree() {
    let fixture = Fixture::new("json");
    let output = fixture.tama(&["worktrees", "list", "--root", &fixture.root(), "--json"]);
    assert_eq!(output.status.code(), Some(0), "stderr: {}", stderr(&output));
    let document: Value = serde_json::from_str(&stdout(&output)).expect("list document is JSON");
    let head = fixture.head();
    let worktree = |name: &str| {
        json!({
            "path": text(fixture.worktree(name)),
            "branch": format!("refs/heads/{name}"),
            "head": head,
            "dirty": false,
            "locked": false,
            "prunable": false,
        })
    };
    let worktrees = vec![worktree("wt-a"), worktree("wt-b")];
    let count = worktrees.len();
    assert_eq!(
        document,
        json!({
            "schemaVersion": SCHEMA_VERSION,
            "roots": [fixture.root()],
            "repositories": [{
                "repository": text(fixture.repo()),
                "worktrees": worktrees,
            }],
            "worktreeCount": count,
            "unreadable": [],
        }),
        "the main worktree is never one of the reported entries"
    );
}

#[test]
fn remove_without_apply_deletes_nothing() {
    let fixture = Fixture::new("preview");
    assert_eq!(fixture.git_worktrees(), fixture.all_three());
    let output = fixture.tama(&["worktrees", "remove", "--root", &fixture.root()]);
    assert_eq!(output.status.code(), Some(0), "stderr: {}", stderr(&output));
    assert!(stdout(&output).contains("Would remove 2 linked worktree(s); nothing was changed."));
    assert_eq!(fixture.git_worktrees(), fixture.all_three());
    assert!(fixture.worktree("wt-a").is_dir());
    assert!(fixture.worktree("wt-b").is_dir());
}

#[test]
fn remove_apply_removes_every_linked_worktree() {
    let fixture = Fixture::new("apply");
    let output = fixture.tama(&["worktrees", "remove", "--root", &fixture.root(), "--apply"]);
    assert_eq!(output.status.code(), Some(0), "stderr: {}", stderr(&output));
    assert!(stdout(&output).contains("Removed 2 linked worktree(s)."));
    assert_eq!(
        fixture.git_worktrees(),
        vec![text(fixture.repo())],
        "git must report only the main worktree afterwards"
    );
    assert!(!fixture.worktree("wt-a").exists());
    assert!(!fixture.worktree("wt-b").exists());
}

#[test]
fn remove_apply_refuses_the_whole_pass_for_an_uncommitted_change() {
    let fixture = Fixture::new("dirty");
    fs::write(fixture.worktree("wt-a").join("file.txt"), "edited\n").expect("dirty a worktree");
    let output = fixture.tama(&["worktrees", "remove", "--root", &fixture.root(), "--apply"]);
    assert_eq!(output.status.code(), Some(1));
    assert_eq!(
        stderr(&output),
        format!(
            "Refusing to remove {}: it carries uncommitted changes. Commit them in that worktree, or pass --force to discard them.\n",
            text(fixture.worktree("wt-a"))
        )
    );
    assert_eq!(
        fixture.git_worktrees(),
        fixture.all_three(),
        "a refused pass removes nothing at all, not even the clean worktree"
    );
    assert!(fixture.worktree("wt-a").is_dir());
    assert!(fixture.worktree("wt-b").is_dir());
}

#[test]
fn remove_apply_force_discards_an_uncommitted_change() {
    let fixture = Fixture::new("force");
    fs::write(fixture.worktree("wt-a").join("file.txt"), "edited\n").expect("dirty a worktree");
    let output = fixture.tama(&[
        "worktrees",
        "remove",
        "--root",
        &fixture.root(),
        "--apply",
        "--force",
    ]);
    assert_eq!(output.status.code(), Some(0), "stderr: {}", stderr(&output));
    assert_eq!(fixture.git_worktrees(), vec![text(fixture.repo())]);
    assert!(!fixture.worktree("wt-a").exists());
    assert!(!fixture.worktree("wt-b").exists());
}

#[test]
fn both_leaves_require_at_least_one_root() {
    let fixture = Fixture::new("root");
    for leaf in ["list", "remove"] {
        let output = fixture.tama(&["worktrees", leaf]);
        assert_eq!(
            output.status.code(),
            Some(2),
            "{leaf} must be a usage error"
        );
        assert!(
            stderr(&output).starts_with(
                "tama worktrees needs at least one --root; a machine-wide default would walk directories Tama does not own.\n"
            ),
            "{leaf} stderr: {}",
            stderr(&output)
        );
        assert_eq!(stdout(&output), "");
    }
    assert_eq!(
        fixture.git_worktrees(),
        fixture.all_three(),
        "a usage error changes nothing"
    );
}

#[test]
fn remove_apply_keeps_an_excepted_worktree() {
    let fixture = Fixture::new("except");
    let output = fixture.tama(&[
        "worktrees",
        "remove",
        "--root",
        &fixture.root(),
        "--except",
        &text(fixture.worktree("wt-a")),
        "--apply",
    ]);
    assert_eq!(output.status.code(), Some(0), "stderr: {}", stderr(&output));
    assert!(
        stdout(&output).contains(&format!(
            "Kept 1 linked worktree(s) by --except:\n  {}",
            text(fixture.worktree("wt-a"))
        )),
        "stdout: {}",
        stdout(&output)
    );
    assert_eq!(
        fixture.git_worktrees(),
        vec![text(fixture.repo()), text(fixture.worktree("wt-a"))],
        "git must still report the excepted worktree and nothing else"
    );
    assert!(fixture.worktree("wt-a").is_dir());
    assert!(!fixture.worktree("wt-b").exists());
}

/// The reason the flag exists: one worktree is being written by a live
/// session, and the contract refuses the whole pass for a dirty worktree. An
/// excepted worktree is not part of the pass, so it cannot refuse it.
#[test]
fn remove_apply_proceeds_when_the_only_dirty_worktree_is_excepted() {
    let fixture = Fixture::new("except-dirty");
    let dirty = fixture.worktree("wt-a").join("file.txt");
    fs::write(&dirty, "edited\n").expect("dirty a worktree");
    let output = fixture.tama(&[
        "worktrees",
        "remove",
        "--root",
        &fixture.root(),
        "--except",
        &text(fixture.worktree("wt-a")),
        "--apply",
    ]);
    assert_eq!(output.status.code(), Some(0), "stderr: {}", stderr(&output));
    assert_eq!(
        fixture.git_worktrees(),
        vec![text(fixture.repo()), text(fixture.worktree("wt-a"))]
    );
    assert!(!fixture.worktree("wt-b").exists());
    assert_eq!(
        fs::read_to_string(&dirty).expect("the excepted worktree is untouched"),
        "edited\n"
    );
}

#[test]
fn remove_refuses_an_except_path_it_does_not_know() {
    let fixture = Fixture::new("except-unknown");
    let stranger = text(fixture.base.join("tree/not-a-worktree"));
    let output = fixture.tama(&[
        "worktrees",
        "remove",
        "--root",
        &fixture.root(),
        "--except",
        &stranger,
        "--apply",
    ]);
    assert_eq!(output.status.code(), Some(2));
    assert_eq!(
        stderr(&output),
        format!("tama worktrees does not know the worktree {stranger}; --except takes the path of a worktree this pass would otherwise remove.\n")
    );
    assert_eq!(fixture.git_worktrees(), fixture.all_three());
    assert!(fixture.worktree("wt-a").is_dir());
    assert!(fixture.worktree("wt-b").is_dir());
}

#[test]
fn remove_json_carries_the_excepted_paths() {
    let fixture = Fixture::new("except-json");
    let kept = text(fixture.worktree("wt-a"));
    let output = fixture.tama(&[
        "worktrees",
        "remove",
        "--root",
        &fixture.root(),
        "--except",
        &kept,
        "--apply",
        "--json",
    ]);
    assert_eq!(output.status.code(), Some(0), "stderr: {}", stderr(&output));
    let document: Value = serde_json::from_str(&stdout(&output)).expect("a JSON document");
    assert_eq!(document["schemaVersion"], json!(SCHEMA_VERSION));
    assert_eq!(document["excepted"], json!([kept]));
    assert_eq!(
        document["removed"],
        json!([text(fixture.worktree("wt-b"))]),
        "the excepted worktree is not among the removed"
    );
    assert_eq!(
        fixture.git_worktrees(),
        vec![text(fixture.repo()), kept.clone()]
    );
    assert!(fixture.worktree("wt-a").is_dir());
}
