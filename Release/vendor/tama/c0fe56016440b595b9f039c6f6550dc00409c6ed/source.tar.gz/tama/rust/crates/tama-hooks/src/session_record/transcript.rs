//! Transcript internals backing `Turn::for_path`: transcript discovery under
//! the sessions root, tracker-state retention across user messages, tool-call
//! collection, and path-token extraction from argument trees.

use std::path::PathBuf;

use serde_json::Value;

use super::types::{ToolCall, ToolResult};

const SHORTEST_PATH: &str = "a/b";

fn sessions_root() -> PathBuf {
    if let Ok(custom) = std::env::var("TAMA_OMP_SESSION_ROOT") {
        if !custom.is_empty() {
            return PathBuf::from(custom);
        }
    }
    home_dir().join(".omp").join("agent").join("sessions")
}

fn home_dir() -> PathBuf {
    std::env::var("HOME").map(PathBuf::from).unwrap_or_default()
}

pub(super) fn transcript_path(session: &str) -> Option<PathBuf> {
    if session.is_empty() {
        return None;
    }
    let mut newest: Option<(std::time::SystemTime, PathBuf)> = None;
    let mut stack = vec![sessions_root()];
    while let Some(directory) = stack.pop() {
        let entries = match std::fs::read_dir(&directory) {
            Ok(entries) => entries,
            Err(_) => continue,
        };
        for entry in entries.flatten() {
            let path = entry.path();
            if path.is_dir() {
                stack.push(path);
                continue;
            }
            let name = match path.file_name().and_then(|n| n.to_str()) {
                Some(name) => name,
                None => continue,
            };
            if !name.contains(session) || !name.ends_with(".jsonl") {
                continue;
            }
            let modified = entry
                .metadata()
                .and_then(|meta| meta.modified())
                .unwrap_or(std::time::UNIX_EPOCH);
            if newest
                .as_ref()
                .map(|(seen, _)| modified > *seen)
                .unwrap_or(true)
            {
                newest = Some((modified, path));
            }
        }
    }
    newest.map(|(_, path)| path)
}

pub(super) fn retain_tracker_state(
    calls: &mut Vec<(usize, ToolCall)>,
    results: &mut Vec<ToolResult>,
) {
    let snapshot_position = results.iter().rev().find_map(|result| {
        (result.tool_name == "todo"
            && !result.is_error
            && result
                .details
                .get("phases")
                .and_then(Value::as_array)
                .is_some())
        .then_some(result.position)
    });
    calls.retain(|(position, call)| {
        is_tracker_tool(&call.name)
            && snapshot_position
                .map(|snapshot| *position > snapshot)
                .unwrap_or(true)
            && results
                .iter()
                .any(|result| result.call_id == call.id && !result.is_error)
    });
    results.retain(|result| {
        !result.is_error
            && is_tracker_tool(&result.tool_name)
            && snapshot_position
                .map(|snapshot| result.position >= snapshot)
                .unwrap_or(true)
    });
}

pub(super) fn is_tracker_tool(name: &str) -> bool {
    name == "todo" || name == "update_plan" || name.ends_with("__update_plan")
}

pub(super) fn collect_tool_calls(
    position: usize,
    message: &Value,
    calls: &mut Vec<(usize, ToolCall)>,
) {
    if message.get("type").and_then(Value::as_str) == Some("function_call") {
        calls.push((
            position,
            ToolCall {
                id: string_at(message, "id"),
                name: string_at(message, "name").to_lowercase(),
                arguments: arguments_of(message),
            },
        ));
        return;
    }
    if message.get("role").and_then(Value::as_str) != Some("assistant") {
        return;
    }
    for item in content_items(message) {
        if item.get("type").and_then(Value::as_str) != Some("toolCall") {
            continue;
        }
        calls.push((
            position,
            ToolCall {
                id: string_at(item, "id"),
                name: string_at(item, "name").to_lowercase(),
                arguments: arguments_of(item),
            },
        ));
    }
}

fn content_items(message: &Value) -> Vec<&Value> {
    message
        .get("content")
        .and_then(Value::as_array)
        .map(|items| items.iter().filter(|item| item.is_object()).collect())
        .unwrap_or_default()
}

pub(super) fn is_error_result(message: &Value) -> bool {
    message.get("role").and_then(Value::as_str) == Some("toolResult")
        && message.get("isError").and_then(Value::as_bool) == Some(true)
}

pub(super) fn result_text(message: &Value) -> String {
    content_items(message)
        .into_iter()
        .filter(|item| item.get("type").and_then(Value::as_str) == Some("text"))
        .filter_map(|item| item.get("text").and_then(Value::as_str))
        .collect::<Vec<_>>()
        .join("\n")
}

pub(super) fn string_at(value: &Value, key: &str) -> String {
    value
        .get(key)
        .and_then(Value::as_str)
        .unwrap_or_default()
        .to_string()
}

fn arguments_of(call: &Value) -> Value {
    match call.get("arguments") {
        Some(Value::String(text)) => serde_json::from_str(text).unwrap_or(Value::Null),
        Some(value) => value.clone(),
        None => Value::Null,
    }
}

/// Path-looking tokens inside an argument tree: anything containing a slash.
pub fn path_tokens(value: &Value) -> Vec<String> {
    let mut found = Vec::new();
    collect_paths(value, &mut found);
    found
}

fn collect_paths(value: &Value, found: &mut Vec<String>) {
    match value {
        Value::String(text) => {
            for token in text.split(|c: char| c.is_whitespace() || c == '"' || c == '\'') {
                let trimmed =
                    token.trim_matches(|c: char| c == ',' || c == ';' || c == ')' || c == '(');
                if trimmed.contains('/') && trimmed.len() > SHORTEST_PATH.len() {
                    found.push(trimmed.to_string());
                }
            }
        }
        Value::Array(items) => items.iter().for_each(|item| collect_paths(item, found)),
        Value::Object(map) => map.values().for_each(|item| collect_paths(item, found)),
        _ => {}
    }
}
