//! Port of `src/adaptive/state.mjs`: durable per-hook projection store with
//! fact-journal replay, episode block persistence, and legacy quarantine.

pub mod journal;
pub mod lock;
pub mod projections;

use std::collections::BTreeMap;
use std::fs::{self, OpenOptions};
use std::io::Write;
use std::path::{Path, PathBuf};

use journal::{key_of, FactJournal};
use lock::{LockOwnership, LockStore};
pub use projections::{
    project_contested_block, project_outcome, HookState, IdentityFacts, Projection,
};

use crate::util::{pretty_json_line, uuid_v4};

const LEGACY_NAMES: [&str; 3] = [
    "overrides.json",
    "provenance-pending.json",
    "numeric-provenance.json",
];
const PHASES: [&str; 3] = ["observing", "enforcing", "warning"];

/// Shared warn sink (`warn(text)`); failures inside it are swallowed by callers.
pub type Warn = std::sync::Arc<dyn Fn(&str) + Send + Sync>;

/// `validState(value, hookId)` — lenient JSON validation like the JS code.
/// Returns `None` for invalid shapes; unknown keys are preserved via `extra`.
pub fn valid_state(value: &serde_json::Value, hook_id: &str) -> Option<HookState> {
    let object = value.as_object()?;
    if object.get("schema").and_then(|v| v.as_str()) != Some(projections::SCHEMA) {
        return None;
    }
    if object.get("hookId").and_then(|v| v.as_str()) != Some(hook_id) {
        return None;
    }
    let phase = object.get("phase").and_then(|v| v.as_str())?;
    if !PHASES.contains(&phase) {
        return None;
    }
    let active_run_value = object.get("activeRun")?.as_array()?;
    match object.get("activeRunSourceDigest") {
        Some(v) if !v.is_null() && !v.is_string() => return None,
        None => return None,
        _ => {}
    }
    match object.get("recoveredRecord") {
        Some(v) if !v.is_null() && !v.is_array() => return None,
        None => return None,
        _ => {}
    }
    if phase == "warning"
        && !object
            .get("warningSourceDigest")
            .map(|v| v.is_string())
            .unwrap_or(false)
    {
        return None;
    }
    match object.get("journalCount") {
        Some(serde_json::Value::Number(n)) => {
            // Number.isInteger: integral doubles like 2.0 count as integers.
            let count = match n.as_i64() {
                Some(count) => count,
                None => match n.as_f64() {
                    Some(f) if f.is_finite() && f.fract() == 0.0 => f as i64,
                    _ => return None,
                },
            };
            if count < 0 {
                return None;
            }
        }
        _ => return None,
    }
    let recovered_record = match object.get("recoveredRecord") {
        Some(serde_json::Value::Array(items)) => Some(
            items
                .iter()
                .filter_map(|v| v.as_str().map(str::to_string))
                .collect(),
        ),
        _ => None,
    };
    let active_run: Vec<String> = active_run_value
        .iter()
        .filter_map(|v| v.as_str().map(str::to_string))
        .collect();
    // `{ ...initialState(hookId), ...value, activeRun, recoveredRecord }`:
    // start from defaults, overlay every key of the source value, then fix
    // the two filtered arrays.
    let mut state = HookState::initial(hook_id);
    if let Ok(mut parsed) = serde_json::from_value::<HookStateLenient>(value.clone()) {
        state.schema = std::mem::take(&mut parsed.schema).unwrap_or_else(|| state.schema.clone());
        state.hook_id =
            std::mem::take(&mut parsed.hook_id).unwrap_or_else(|| state.hook_id.clone());
        state.phase = std::mem::take(&mut parsed.phase).unwrap_or_else(|| state.phase.clone());
        state.recovered_record = recovered_record;
        state.active_run = active_run;
        state.active_run_source_digest = parsed.active_run_source_digest.take();
        state.warning_source_digest = parsed.warning_source_digest.take();
        state.contested_block_observed = parsed.contested_block_observed.unwrap_or(false);
        state.last_outcome = parsed.last_outcome.take();
        state.journal_count = parsed.journal_count.unwrap_or(0);
        state.extra = std::mem::take(&mut parsed.extra);
    }
    Some(state)
}

/// Lenient mirror of `HookState` where every field is optional so a partial
/// JSON object still overlays defaults, like the JS spread.
#[derive(Default, serde::Deserialize)]
#[serde(rename_all = "camelCase", default)]
struct HookStateLenient {
    schema: Option<String>,
    hook_id: Option<String>,
    phase: Option<String>,
    active_run_source_digest: Option<String>,
    warning_source_digest: Option<String>,
    contested_block_observed: Option<bool>,
    last_outcome: Option<String>,
    journal_count: Option<i64>,
    #[serde(flatten)]
    extra: BTreeMap<String, serde_json::Value>,
}

/// Result of `store.update` / engine `finish` (`TransitionResult` in JS).
#[derive(Debug, Clone)]
pub struct TransitionResult {
    pub ok: bool,
    pub persisted: bool,
    pub mode: String,
    pub transition: Option<String>,
    pub reason: Option<String>,
    pub state: HookState,
}

impl TransitionResult {
    pub fn to_value(&self) -> serde_json::Value {
        let mut map = serde_json::Map::new();
        map.insert("ok".into(), self.ok.into());
        map.insert("persisted".into(), self.persisted.into());
        map.insert("mode".into(), self.mode.clone().into());
        if let Some(transition) = &self.transition {
            map.insert("transition".into(), transition.clone().into());
        }
        if let Some(reason) = &self.reason {
            map.insert("reason".into(), reason.clone().into());
        }
        map.insert("state".into(), self.state.to_value());
        serde_json::Value::Object(map)
    }
}

pub struct StateStore {
    state_dir: PathBuf,
    projection_dir: PathBuf,
    tmp_dir: PathBuf,
    quarantine_dir: PathBuf,
    episode_dir: PathBuf,
    journal: FactJournal,
    locks: LockStore,
    warn: Warn,
}

impl StateStore {
    fn path_for(&self, hook_id: &str) -> PathBuf {
        self.projection_dir
            .join(format!("{}.json", key_of(hook_id)))
    }

    /// `readState(hookId, requireHealthy)`.
    fn read_state(&self, hook_id: &str, require_healthy: bool) -> Result<HookState, String> {
        let facts = match self.journal.read(hook_id) {
            Some(facts) => facts,
            None => {
                if require_healthy {
                    return Err("adaptive fact journal requires repair".to_string());
                }
                let mut enforced = HookState::initial(hook_id);
                enforced.phase = "enforcing".to_string();
                return Ok(enforced);
            }
        };
        let checked = fs::read_to_string(self.path_for(hook_id))
            .ok()
            .and_then(|text| serde_json::from_str::<serde_json::Value>(&text).ok())
            .and_then(|parsed| valid_state(&parsed, hook_id));
        if let Some(checked) = &checked {
            if checked.journal_count == facts.len() as i64 {
                return Ok(checked.clone());
            }
        }
        let mut rebuilt = HookState::initial(hook_id);
        for fact in &facts {
            let kind = fact.get("kind").and_then(|v| v.as_str()).unwrap_or("");
            let identity = identity_facts_from(fact.get("identity"));
            let event_id = fact.get("id").and_then(|v| v.as_str()).unwrap_or("");
            let tier = fact.get("tier").and_then(|v| v.as_str()).unwrap_or("");
            let result = match kind {
                "outcome" => {
                    let outcome = fact.get("outcome").and_then(|v| v.as_str()).unwrap_or("");
                    Some(project_outcome(
                        &rebuilt, outcome, tier, &identity, event_id,
                    ))
                }
                "contested-block" => {
                    Some(project_contested_block(&rebuilt, tier, &identity, event_id))
                }
                _ => None,
            };
            match result {
                Some(projection) => {
                    if projection.changed {
                        rebuilt = projection.state;
                    }
                }
                None => {
                    (self.warn)(&format!(
                        "adaptive fact journal contains an unknown fact for {}",
                        hook_id
                    ));
                    return Ok(HookState::initial(hook_id));
                }
            }
        }
        rebuilt.journal_count = facts.len() as i64;
        Ok(
            valid_state(&rebuilt.to_value(), hook_id)
                .unwrap_or_else(|| HookState::initial(hook_id)),
        )
    }

    /// `persist(hookId, state)` — write tmp with `wx`, fsync-free rename.
    fn persist(&self, hook_id: &str, state: &HookState) -> std::io::Result<()> {
        fs::create_dir_all(&self.projection_dir)?;
        fs::create_dir_all(&self.tmp_dir)?;
        let temporary = self.tmp_dir.join(format!("projection-{}.json", uuid_v4()));
        {
            let mut file = OpenOptions::new()
                .write(true)
                .create_new(true)
                .open(&temporary)?;
            file.write_all(pretty_json_line(&state.to_value()).as_bytes())?;
        }
        fs::rename(&temporary, self.path_for(hook_id))?;
        Ok(())
    }

    /// `update(hookId, transition, fact)`. A lock-acquisition I/O error
    /// propagates like the JS throw outside the `try` block.
    pub fn update<F>(
        &self,
        hook_id: &str,
        transition: F,
        fact: Option<serde_json::Value>,
    ) -> std::io::Result<TransitionResult>
    where
        F: FnOnce(&HookState, &serde_json::Value) -> Projection,
    {
        let id = hook_id.to_string();
        if id.is_empty() {
            return Ok(TransitionResult {
                ok: false,
                persisted: false,
                mode: String::new(),
                transition: None,
                reason: Some("missing-hook-id".to_string()),
                state: HookState::initial(&id),
            });
        }
        let ownership: LockOwnership = match self.locks.acquire(&key_of(&id)) {
            Ok(ownership) => ownership,
            Err(error) => return Err(error),
        };
        let result = self.update_locked(&id, transition, fact);
        self.locks.release(Some(ownership));
        Ok(result)
    }

    fn update_locked<F>(
        &self,
        id: &str,
        transition: F,
        fact: Option<serde_json::Value>,
    ) -> TransitionResult
    where
        F: FnOnce(&HookState, &serde_json::Value) -> Projection,
    {
        match self.try_update(id, transition, fact) {
            Ok(result) => result,
            Err(error) => {
                (self.warn)(&format!(
                    "adaptive state persistence failed for {}: {}",
                    id, error
                ));
                TransitionResult {
                    ok: false,
                    persisted: false,
                    mode: String::new(),
                    transition: None,
                    reason: Some("persistence-failed".to_string()),
                    state: HookState::initial(id),
                }
            }
        }
    }

    fn try_update<F>(
        &self,
        id: &str,
        transition: F,
        fact: Option<serde_json::Value>,
    ) -> Result<TransitionResult, String>
    where
        F: FnOnce(&HookState, &serde_json::Value) -> Projection,
    {
        let prior = self.read_state(id, true)?;
        let fact = fact
            .filter(|f| f.is_object())
            .ok_or("missing adaptive transition fact")?;
        let mut durable_fact = serde_json::Map::new();
        durable_fact.insert("id".into(), uuid_v4().into());
        durable_fact.insert("hookId".into(), id.into());
        if let serde_json::Value::Object(extra) = fact {
            durable_fact.extend(extra);
        }
        let durable_fact = serde_json::Value::Object(durable_fact);
        let result = transition(&prior, &durable_fact);
        if !result.changed {
            let transition_name = result.transition;
            // JS: `transition` key only added when truthy; all projection
            // transition names are non-empty strings, so it is always set.
            return Ok(TransitionResult {
                ok: true,
                persisted: true,
                mode: String::new(),
                transition: Some(transition_name.to_string()),
                reason: None,
                state: prior,
            });
        }
        let mut next = result.state;
        next.journal_count = prior.journal_count + 1;
        let checked = valid_state(&next.to_value(), id).ok_or("invalid adaptive projection")?;
        self.journal
            .append(id, &durable_fact)
            .map_err(|e| format!("Error: {}", e))?;
        self.persist(id, &checked)
            .map_err(|e| format!("Error: {}", e))?;
        Ok(TransitionResult {
            ok: true,
            persisted: true,
            mode: String::new(),
            transition: Some(result.transition.to_string()),
            reason: None,
            state: checked,
        })
    }

    /// `snapshot(hookId?)` — a single hook state or a map of all states.
    pub fn snapshot(&self, hook_id: Option<&str>) -> serde_json::Value {
        if let Some(hook_id) = hook_id {
            let state = self
                .read_state(hook_id, false)
                .unwrap_or_else(|_| HookState::initial(hook_id));
            return state.to_value();
        }
        let mut states = serde_json::Map::new();
        if let Ok(entries) = fs::read_dir(&self.projection_dir) {
            for entry in entries.flatten() {
                let name = entry.file_name().to_string_lossy().to_string();
                if !name.ends_with(".json") {
                    continue;
                }
                let Ok(text) = fs::read_to_string(entry.path()) else {
                    continue;
                };
                let Ok(parsed) = serde_json::from_str::<serde_json::Value>(&text) else {
                    continue;
                };
                let Some(id) = parsed.get("hookId").and_then(|v| v.as_str()) else {
                    continue;
                };
                let replayed = self
                    .read_state(id, false)
                    .unwrap_or_else(|_| HookState::initial(id));
                states.insert(replayed.hook_id.clone(), replayed.to_value());
            }
        }
        serde_json::Value::Object(states)
    }

    fn episode_path(&self, session_id: &str) -> PathBuf {
        self.episode_dir
            .join(format!("{}.json", key_of(session_id)))
    }

    fn with_episode_lock<T>(
        &self,
        session_id: &str,
        action: impl FnOnce() -> Result<T, String>,
        unavailable: T,
    ) -> T {
        let ownership = match self
            .locks
            .acquire(&format!("episode-{}", key_of(session_id)))
        {
            Ok(ownership) => Some(ownership),
            // JS `acquire` throws only past the caller's `try`; treating an
            // acquisition failure as "unavailable" matches the unavailable
            // result contract without crashing the hook path.
            Err(_) => None,
        };
        let Some(ownership) = ownership else {
            return unavailable;
        };
        let result = match action() {
            Ok(value) => value,
            Err(error) => {
                (self.warn)(&format!("adaptive episode persistence failed: {}", error));
                unavailable
            }
        };
        self.locks.release(Some(ownership));
        result
    }

    /// `recordEpisodeBlock(value)` — appends a causal block record.
    pub fn record_episode_block(&self, value: &EpisodeBlockInput) -> EpisodeWriteResult {
        let session_id = value.session_id.clone().unwrap_or_default();
        let hook_id = value.hook_id.clone().unwrap_or_default();
        if session_id.is_empty() || hook_id.is_empty() {
            return EpisodeWriteResult {
                persisted: false,
                reason: Some("missing-causal-identity".to_string()),
            };
        }
        self.with_episode_lock(
            &session_id,
            || {
                fs::create_dir_all(&self.episode_dir).map_err(|e| e.to_string())?;
                let mut blocks: Vec<serde_json::Value> =
                    fs::read_to_string(self.episode_path(&session_id))
                        .ok()
                        .and_then(|text| serde_json::from_str::<serde_json::Value>(&text).ok())
                        .and_then(|v| v.as_array().cloned())
                        .unwrap_or_default();
                blocks.push(serde_json::json!({
                    "id": uuid_v4(),
                    "hookId": hook_id,
                    "episodeId": value.episode_id,
                    "reason": value.reason.clone().unwrap_or_default(),
                }));
                fs::create_dir_all(&self.tmp_dir).map_err(|e| e.to_string())?;
                let temporary = self.tmp_dir.join(format!("episode-{}.json", uuid_v4()));
                {
                    let mut file = OpenOptions::new()
                        .write(true)
                        .create_new(true)
                        .open(&temporary)
                        .map_err(|e| e.to_string())?;
                    file.write_all(pretty_json_line(&serde_json::Value::Array(blocks)).as_bytes())
                        .map_err(|e| e.to_string())?;
                }
                fs::rename(&temporary, self.episode_path(&session_id))
                    .map_err(|e| e.to_string())?;
                Ok(EpisodeWriteResult {
                    persisted: true,
                    reason: None,
                })
            },
            EpisodeWriteResult {
                persisted: false,
                reason: Some("concurrent-episode-update".to_string()),
            },
        )
    }

    /// `consumeLatestEpisodeBlocks(sessionId)` — reads and removes the
    /// episode file, returning only blocks of the latest episode.
    pub fn consume_latest_episode_blocks(
        &self,
        session_id: Option<&str>,
    ) -> Vec<serde_json::Value> {
        let id = session_id.unwrap_or("").to_string();
        if id.is_empty() {
            return Vec::new();
        }
        self.with_episode_lock(
            &id,
            || {
                let blocks: Vec<serde_json::Value> = fs::read_to_string(self.episode_path(&id))
                    .ok()
                    .and_then(|text| serde_json::from_str::<serde_json::Value>(&text).ok())
                    .and_then(|v| v.as_array().cloned())
                    .unwrap_or_default();
                let _ = fs::remove_file(self.episode_path(&id));
                if blocks.is_empty() {
                    return Ok(Vec::new());
                }
                // JS: `blocks[blocks.length - 1].episodeId` is `undefined`
                // (not null) when the key is missing or the entry is not an
                // object; `None` models `undefined` here.
                let latest_episode_id: Option<serde_json::Value> =
                    blocks.last().and_then(|b| b.get("episodeId")).cloned();
                Ok(blocks
                    .into_iter()
                    .filter(|block| {
                        js_truthy(block) && block.get("episodeId").cloned() == latest_episode_id
                    })
                    .collect())
            },
            Vec::new(),
        )
    }

    /// `quarantineLegacy()` — move legacy artifacts aside, silently.
    pub fn quarantine_legacy(&self) {
        for name in LEGACY_NAMES {
            let source = self.state_dir.join(name);
            let attempt = (|| -> std::io::Result<()> {
                fs::create_dir_all(&self.quarantine_dir)?;
                fs::rename(
                    &source,
                    self.quarantine_dir.join(format!("{}-{}", name, uuid_v4())),
                )?;
                Ok(())
            })();
            if attempt.is_ok() {
                (self.warn)(&format!("quarantined legacy adaptive artifact {}", name));
            }
        }
    }
}

/// Input to `record_episode_block` (JS observation object).
#[derive(Debug, Clone, Default)]
pub struct EpisodeBlockInput {
    pub session_id: Option<String>,
    pub episode_id: Option<String>,
    pub hook_id: Option<String>,
    pub reason: Option<String>,
}

#[derive(Debug, Clone)]
pub struct EpisodeWriteResult {
    pub persisted: bool,
    pub reason: Option<String>,
}

/// `openStateStore(stateDir, warn)`.
pub fn open_state_store(state_dir: &Path, warn: Warn) -> StateStore {
    StateStore {
        state_dir: state_dir.to_path_buf(),
        projection_dir: state_dir.join("projections"),
        tmp_dir: state_dir.join("tmp"),
        quarantine_dir: state_dir.join("quarantine"),
        episode_dir: state_dir.join("episodes"),
        journal: FactJournal::open(state_dir, warn.clone()),
        locks: LockStore::open(state_dir, warn.clone()),
        warn,
    }
}

/// Extract `IdentityFacts` from a fact's `identity` JSON (lenient).
fn identity_facts_from(value: Option<&serde_json::Value>) -> IdentityFacts {
    let Some(value) = value else {
        return IdentityFacts::default();
    };
    IdentityFacts {
        verifiable: value
            .get("verifiable")
            .and_then(|v| v.as_bool())
            .unwrap_or(false),
        digest: value
            .get("digest")
            .and_then(|v| v.as_str())
            .map(str::to_string),
    }
}

use crate::util::js_truthy;
