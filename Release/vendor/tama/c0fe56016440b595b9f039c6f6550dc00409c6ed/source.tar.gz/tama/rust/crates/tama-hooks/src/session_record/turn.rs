//! The `Turn` view of a session transcript: current activity plus the
//! successful tracker history the `Stop` guards reconstruct state from.

use std::collections::HashSet;
use std::io::{BufRead, BufReader};
use std::path::Path;

use serde_json::Value;

use super::payload::session_id_of;
use super::transcript::{
    collect_tool_calls, is_error_result, is_tracker_tool, result_text, retain_tracker_state,
    string_at, transcript_path,
};
use super::types::{Denial, ToolCall, ToolResult};

/// Current activity plus successful tracker history from one session transcript.
pub struct Turn {
    calls: Vec<(usize, ToolCall)>,
    results: Vec<ToolResult>,
}

impl Turn {
    /// Current turn from a hook payload. Codex supplies the exact transcript
    /// path; older runtimes only supplied a session id, so retain that lookup
    /// as the legacy path.
    pub fn for_payload(payload: &Value) -> Option<Turn> {
        if let Some(path) = payload.get("transcript_path").and_then(Value::as_str) {
            if !path.is_empty() {
                return Self::for_path(Path::new(path));
            }
        }
        Self::for_session(&session_id_of(payload))
    }

    /// Current tool activity plus successful tracker history. `None` means no
    /// transcript is readable, so a guard must not deny.
    pub fn for_session(session: &str) -> Option<Turn> {
        let path = transcript_path(session)?;
        Self::for_path(&path)
    }

    fn for_path(path: &Path) -> Option<Turn> {
        let file = std::fs::File::open(path).ok()?;
        let mut calls = Vec::new();
        let mut results = Vec::new();
        for (position, line) in BufReader::new(file).lines().enumerate() {
            let line = match line {
                Ok(value) => value,
                Err(_) => continue,
            };
            let record: Value = match serde_json::from_str(&line) {
                Ok(value) => value,
                Err(_) => continue,
            };
            let message =
                if let Some(value) = record.get("message").filter(|value| value.is_object()) {
                    value
                } else if record.get("type").and_then(Value::as_str) == Some("response_item") {
                    match record.get("payload").filter(|value| value.is_object()) {
                        Some(value) => value,
                        None => continue,
                    }
                } else {
                    continue;
                };
            if message.get("role").and_then(Value::as_str) == Some("user")
                || message.get("type").and_then(Value::as_str) == Some("user_message")
            {
                retain_tracker_state(&mut calls, &mut results);
                continue;
            }
            collect_tool_calls(position, message, &mut calls);
            if message.get("role").and_then(Value::as_str) == Some("toolResult") {
                let tool_name = string_at(message, "toolName").to_lowercase();
                let is_error = is_error_result(message);
                results.push(ToolResult {
                    position,
                    call_id: string_at(message, "toolCallId"),
                    details: if is_tracker_tool(&tool_name) {
                        message.get("details").cloned().unwrap_or(Value::Null)
                    } else {
                        Value::Null
                    },
                    tool_name,
                    is_error,
                    text: if is_error {
                        result_text(message)
                    } else {
                        String::new()
                    },
                });
            }
        }
        Some(Turn { calls, results })
    }

    /// Tool calls in record order, paired with the transcript position that
    /// carried them.
    pub fn tool_calls(&self) -> Vec<(usize, ToolCall)> {
        self.calls.clone()
    }

    /// Tool results in record order.
    pub fn tool_results(&self) -> &[ToolResult] {
        &self.results
    }

    /// Ids of calls whose result completed without an error.
    pub fn successful_call_ids(&self) -> HashSet<String> {
        self.results
            .iter()
            .filter(|result| !result.is_error && !result.call_id.is_empty())
            .map(|result| result.call_id.clone())
            .collect()
    }

    /// Errored results, oldest first. The caller decides which ones are hook
    /// denials by matching the banner id against the registry.
    pub fn denials(&self) -> Vec<Denial> {
        self.results
            .iter()
            .filter(|result| result.is_error)
            .map(|result| Denial {
                position: result.position,
                call_id: result.call_id.clone(),
                tool_name: result.tool_name.clone(),
                text: result.text.clone(),
            })
            .collect()
    }
}
