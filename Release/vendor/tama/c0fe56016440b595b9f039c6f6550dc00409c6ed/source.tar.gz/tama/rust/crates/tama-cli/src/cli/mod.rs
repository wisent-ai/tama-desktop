//! Command layer extracted from the crate root: argument helpers, output
//! helpers, and the per-command handlers `main()` dispatches to.

pub mod args;
pub mod commands;
pub mod output;
pub mod sessions;
