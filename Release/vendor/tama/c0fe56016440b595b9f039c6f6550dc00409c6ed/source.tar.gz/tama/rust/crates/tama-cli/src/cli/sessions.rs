//! The `tama sessions` command, extracted from the crate root: lists every
//! live agent session and its hook state, merged with the machine-wide
//! enforcement status.

use std::path::{Path, PathBuf};

use super::args::{has, option_value};
use super::output::print_json;
use crate::enforcement;

pub fn main(argv: &[String], root: &Path) -> i32 {
    let home = option_value(argv, "--home")
        .or_else(|| std::env::var("HOME").ok())
        .unwrap_or_default();
    let control_dir =
        std::path::Path::new(&home).join("Library/Application Support/Tama/session-control");

    let mut entries: Vec<PathBuf> = match std::fs::read_dir(&control_dir) {
        Ok(rd) => rd
            .filter_map(|e| e.ok())
            .map(|e| e.path())
            .filter(|p| {
                p.extension().is_some_and(|ext| ext == "json")
                    && p.to_string_lossy().ends_with(".session.json")
            })
            .collect(),
        Err(_) => Vec::new(),
    };
    entries.sort();

    let mut sessions: Vec<serde_json::Value> = Vec::new();
    for path in &entries {
        match std::fs::read_to_string(path) {
            Ok(text) => match serde_json::from_str::<serde_json::Value>(&text) {
                Ok(raw) => {
                    let runtime = raw.get("runtime");
                    let session = serde_json::json!({
                        "sessionId": raw.get("sessionId").cloned().unwrap_or(serde_json::Value::Null),
                        "agentId": raw.get("agentId").cloned().unwrap_or(serde_json::Value::Null),
                        "cwd": raw.get("cwd").cloned().unwrap_or(serde_json::Value::Null),
                        "status": raw.get("status").cloned().unwrap_or(serde_json::Value::Null),
                        "globallyDisabled": runtime.and_then(|r| r.get("globallyDisabled")).cloned().unwrap_or(serde_json::Value::Null),
                        "loadedHookCount": runtime.and_then(|r| r.get("loadedHookCount")).cloned().unwrap_or(serde_json::Value::Null),
                        "registeredHookCount": runtime.and_then(|r| r.get("registeredHookCount")).cloned().unwrap_or(serde_json::Value::Null),
                        "enabledHookIds": runtime.and_then(|r| r.get("enabledHookIds")).cloned().unwrap_or(serde_json::json!([])),
                        "disabledHookIds": runtime.and_then(|r| r.get("disabledHookIds")).cloned().unwrap_or(serde_json::json!([])),
                        "updatedAt": raw.get("updatedAt").cloned().unwrap_or(serde_json::Value::Null),
                    });
                    sessions.push(session);
                }
                Err(_) => {
                    sessions.push(serde_json::json!({ "sessionId": path.display().to_string(), "parseError": true }));
                }
            },
            Err(_) => {
                sessions.push(serde_json::json!({ "sessionId": path.display().to_string(), "readError": true }));
            }
        }
    }
    let machine_enforcement = match enforcement::status_for_home(root, std::path::Path::new(&home))
    {
        Ok(status) => status,
        Err(error) => {
            eprintln!("{error}");
            return 1;
        }
    };
    enforcement::report_read_error(&machine_enforcement);
    let exit_code = if machine_enforcement.read_error.is_some() {
        1
    } else {
        0
    };

    if has(argv, "--json") {
        print_json(&serde_json::json!({
            "machineEnforcement": &machine_enforcement,
            "sessions": sessions,
        }));
    } else {
        println!("{}", enforcement::session_summary(&machine_enforcement));
        for s in &sessions {
            let agent = s.get("agentId").and_then(|v| v.as_str()).unwrap_or("?");
            let session_id = s.get("sessionId").and_then(|v| v.as_str()).unwrap_or("?");
            let short_id: String = session_id.chars().take(12).collect();
            let globally_disabled = s
                .get("globallyDisabled")
                .and_then(|v| v.as_bool())
                .unwrap_or(false);
            let hooks = if globally_disabled {
                let enabled: Vec<&str> = s
                    .get("enabledHookIds")
                    .and_then(|v| v.as_array())
                    .map(|a| a.iter().filter_map(|x| x.as_str()).collect())
                    .unwrap_or_default();
                if enabled.is_empty() {
                    "allowlist: empty".to_string()
                } else {
                    format!("allowlist: {}", enabled.join(", "))
                }
            } else {
                let loaded = s
                    .get("loadedHookCount")
                    .and_then(|v| v.as_i64())
                    .map(|v| v.to_string())
                    .unwrap_or("?".into());
                let registered = s
                    .get("registeredHookCount")
                    .and_then(|v| v.as_i64())
                    .map(|v| v.to_string())
                    .unwrap_or("?".into());
                format!("{loaded}/{registered}")
            };
            println!("{agent}\t{short_id}\t{hooks}");
        }
    }
    exit_code
}
