//! One repository's repair: the lock, the rounds, and the verdict.

use std::path::Path;

use serde::Serialize;

use super::agent::{revert_patch, spawn_agent};
use super::brief::{build_brief, is_actionable, BriefParams};
use super::journal::{journal, lock_path_for, state_dir, JournalDone, JournalRound};
use crate::find_violations::{detect_gaming, read_ignore_file, scan_repo, Violation};
use crate::js_num;

/// A dry run prints the brief the first round would receive.
const FIRST_ROUND: i64 = true as i64;

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Round {
    pub round: i64,
    /// Kept as an explicit JSON null on timeout/signal, like the JS
    /// `{ agentExit: run.status }` with `status === null`.
    pub agent_exit: Option<i32>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub rejected: Option<String>,
    pub remaining: usize,
}

/// Result of one `clean_repo` call: the dry-run, locked and full-run shapes.
#[derive(Debug, Clone, Default, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CleanResult {
    pub repo: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub dry_run: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub locked: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub clean: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub violations: Option<usize>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub actionable: Option<usize>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub before: Option<usize>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub after: Option<usize>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub remaining: Option<Vec<Violation>>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub rounds: Option<Vec<Round>>,
}

pub struct CleanParams<'a> {
    pub repo: &'a str,
    pub hook_path: &'a str,
    pub model: &'a str,
    pub max_rounds: f64,
    pub dry_run: bool,
    pub skip: &'a [String],
    pub note: Option<&'a str>,
    pub root: &'a Path,
}

/// The mkdir lock keeps two runs off one repository; it is removed on every
/// exit path.
pub fn clean_repo(params: &CleanParams) -> CleanResult {
    let mut report = scan_repo(Path::new(params.repo), Path::new(params.hook_path));
    let ignore_entries = read_ignore_file(params.repo);
    let before_count = report.violations.len();
    let mut actionable: Vec<Violation> = report
        .violations
        .iter()
        .filter(|v| is_actionable(v, params.skip, &ignore_entries))
        .cloned()
        .collect();
    if params.dry_run {
        println!(
            "{}",
            build_brief(&BriefParams {
                repo: params.repo,
                violations: &actionable,
                round: FIRST_ROUND,
                max_rounds: params.max_rounds,
                skip: params.skip,
                note: params.note,
                feedback: &[],
            })
        );
        return CleanResult {
            repo: params.repo.to_string(),
            dry_run: Some(true),
            violations: Some(before_count),
            actionable: Some(actionable.len()),
            ..Default::default()
        };
    }
    let _ = std::fs::create_dir_all(state_dir(params.root).join("clean-locks"));
    let lock_path = lock_path_for(params.root, params.repo);
    let locked = std::fs::create_dir(&lock_path).is_err();
    if locked {
        return CleanResult {
            repo: params.repo.to_string(),
            locked: Some(true),
            violations: Some(before_count),
            actionable: Some(actionable.len()),
            ..Default::default()
        };
    }
    let result = run_rounds(
        params,
        &ignore_entries,
        &mut report,
        &mut actionable,
        before_count,
    );
    let _ = std::fs::remove_dir(&lock_path);
    result
}

fn run_rounds(
    params: &CleanParams,
    ignore_entries: &[String],
    report: &mut crate::find_violations::ScanReport,
    actionable: &mut Vec<Violation>,
    before_count: usize,
) -> CleanResult {
    let mut rounds: Vec<Round> = Vec::new();
    let mut feedback: Vec<String> = Vec::new();
    let mut round = FIRST_ROUND - FIRST_ROUND;
    let note_fires = params.note.map(|note| !note.is_empty()).unwrap_or(false);
    while (!actionable.is_empty()
        || (note_fires && round == FIRST_ROUND - FIRST_ROUND)
        || !feedback.is_empty())
        && (round as f64) < params.max_rounds
    {
        round += FIRST_ROUND;
        let before_round = actionable.len();
        let brief = build_brief(&BriefParams {
            repo: params.repo,
            violations: actionable,
            round,
            max_rounds: params.max_rounds,
            skip: params.skip,
            note: params.note,
            feedback: &feedback,
        });
        eprintln!(
            "[clean] {} round {}/{}: {} violation(s), route={}",
            params.repo,
            round,
            js_num(params.max_rounds),
            actionable.len(),
            params.model
        );
        let run = spawn_agent(params.model, &brief, params.repo);
        if let Some(error) = &run.error {
            eprintln!(
                "[clean] {} round {round} repaired nothing: {error}",
                params.repo
            );
        }
        let gaming = detect_gaming(Path::new(params.repo));
        journal(
            params.root,
            &JournalRound {
                at: crate::iso_now(),
                repo: params.repo,
                round,
                model: params.model,
                agent_exit: run.status,
                agent_signal: run.signal.clone(),
                violations: actionable.len(),
                gaming: &gaming.findings,
            },
        );
        *report = scan_repo(Path::new(params.repo), Path::new(params.hook_path));
        *actionable = report
            .violations
            .iter()
            .filter(|v| is_actionable(v, params.skip, ignore_entries))
            .cloned()
            .collect();
        // A round that could not act ends the run: repeating it spends the
        // same minutes on the same failure.
        if let Some(error) = run.error {
            rounds.push(Round {
                round,
                agent_exit: run.status,
                rejected: Some(error),
                remaining: actionable.len(),
            });
            break;
        }
        // A round that left more to fix than it found is not progress. On
        // 2026-09-07 one such round wrote ten modules no crate declared, so
        // the compiler never saw them, the build stayed green, and the count
        // went from 54 to 62 while the run reported success. Its own patch is
        // undone exactly, and the next brief is told what happened.
        if actionable.len() > before_round {
            let raised = format!(
                "the round raised the violation count from {before_round} to {}",
                actionable.len()
            );
            let undone = match run.patch.as_deref() {
                Some(patch) => match revert_patch(params.repo, patch) {
                    Ok(()) => {
                        *report = scan_repo(Path::new(params.repo), Path::new(params.hook_path));
                        *actionable = report
                            .violations
                            .iter()
                            .filter(|v| is_actionable(v, params.skip, ignore_entries))
                            .cloned()
                            .collect();
                        "; its patch was undone"
                    }
                    Err(_) => "; its patch could not be undone",
                },
                None => "",
            };
            eprintln!(
                "[clean] {} round {round} rejected: {raised}{undone}",
                params.repo
            );
            feedback = vec![format!(
                "- {raised}{undone}. Fix the rules named above without adding files that break them, \
                 and keep every new module reachable from its parent."
            )];
            rounds.push(Round {
                round,
                agent_exit: run.status,
                rejected: Some(format!("{raised}{undone}")),
                remaining: actionable.len(),
            });
            continue;
        }
        if !gaming.findings.is_empty() {
            feedback = gaming
                .findings
                .iter()
                .map(|finding| format!("- {}: {}", finding.kind, finding.path))
                .collect();
            rounds.push(Round {
                round,
                agent_exit: run.status,
                rejected: Some("rule-gaming".to_string()),
                remaining: actionable.len(),
            });
            continue;
        }
        feedback = Vec::new();
        rounds.push(Round {
            round,
            agent_exit: run.status,
            rejected: None,
            remaining: actionable.len(),
        });
    }
    let last_round = rounds.last();
    let clean = actionable.is_empty() && !matches!(last_round, Some(r) if r.rejected.is_some());
    journal(
        params.root,
        &JournalDone {
            at: crate::iso_now(),
            repo: params.repo,
            done: true,
            clean,
            before: before_count,
            after: report.violations.len(),
        },
    );
    CleanResult {
        repo: params.repo.to_string(),
        clean: Some(clean),
        before: Some(before_count),
        after: Some(report.violations.len()),
        remaining: Some(actionable.clone()),
        rounds: Some(rounds),
        ..Default::default()
    }
}
