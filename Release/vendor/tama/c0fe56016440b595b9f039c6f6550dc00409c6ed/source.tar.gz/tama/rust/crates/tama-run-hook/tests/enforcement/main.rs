use std::fs;
use std::path::{Path, PathBuf};
use std::process::{Command, Output, Stdio};
use std::time::{SystemTime, UNIX_EPOCH};

use serde_json::{json, Value};
use tama_hooks::enforcement::{write_enforcement_selection_at, EnforcementMode};
use tama_hooks::session_control::{session_context, SESSION_CONTROL_SCHEMA};

fn scratch() -> PathBuf {
    let nonce = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .expect("clock after epoch")
        .as_nanos();
    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("../../target/enforcement-evidence")
        .join(format!("{}-{nonce}", std::process::id()))
}

fn run(
    registry: &Path,
    enforcement: &Path,
    emergency: &Path,
    control_root: &Path,
    payload: &Value,
    enabled_filter: Option<&str>,
    disabled_filter: Option<&str>,
) -> Output {
    let root = registry.parent().unwrap();
    for name in ["alpha", "beta"] {
        if let Err(error) = fs::remove_file(root.join(format!("{name}.out"))) {
            assert_eq!(error.kind(), std::io::ErrorKind::NotFound);
        }
    }
    let mut command = Command::new(env!("CARGO_BIN_EXE_tama-run-hook"));
    command
        .args(["pre_tool_use:read", "claude"])
        .env("AGENT_HOOK_REGISTRY", registry)
        .env("TAMA_HOOK_ENFORCEMENT", enforcement)
        .env("TAMA_EMERGENCY_STATE", emergency)
        .env("TAMA_SESSION_CONTROL_ROOT", control_root)
        // A refused dispatch is now recorded for the adaptive layer, so the
        // fixture needs an adaptive state and a lake of its own; without these
        // the suite would append its fixture hooks to the operator's.
        .env("HOOKS_ADAPTIVE_STATE", root.join("adaptive-state"))
        .env("LAKE_DATA", root.join("absent-lake"))
        .env_remove("TAMA_PROVIDER")
        .env_remove("TAMA_ONLY_HOOK_ID")
        .env_remove("TAMA_ENABLED_HOOKS")
        .env_remove("TAMA_DISABLED_HOOKS")
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped());
    if let Some(value) = enabled_filter {
        command.env("TAMA_ENABLED_HOOKS", value);
    }
    if let Some(value) = disabled_filter {
        command.env("TAMA_DISABLED_HOOKS", value);
    }
    let mut child = command.spawn().expect("spawn tama-run-hook");
    {
        use std::io::Write;
        child
            .stdin
            .take()
            .expect("child stdin")
            .write_all(serde_json::to_string(payload).unwrap().as_bytes())
            .expect("write payload");
    }
    let output = child.wait_with_output().expect("wait for tama-run-hook");
    let nonce = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap()
        .as_nanos();
    fs::write(
        root.join(format!("invocation-{nonce}.json")),
        json!({
            "arguments": ["pre_tool_use:read", "claude"],
            "payload": payload, "enabledFilter": enabled_filter, "disabledFilter": disabled_filter,
            "exitCode": output.status.code(),
            "stdout": String::from_utf8_lossy(&output.stdout),
            "stderr": String::from_utf8_lossy(&output.stderr),
        })
        .to_string(),
    )
    .unwrap();
    output
}

fn result_flags(output: &Output, root: &Path) -> Vec<(String, bool)> {
    assert!(
        output.status.success(),
        "stderr: {}",
        String::from_utf8_lossy(&output.stderr)
    );
    let value: Value = serde_json::from_slice(&output.stdout).expect("decision JSON");
    value["results"]
        .as_array()
        .expect("results array")
        .iter()
        .map(|record| {
            let id = record["id"].as_str().expect("hook id");
            let skipped = record.get("skipped") == Some(&Value::Bool(true));
            let observation = root.join(format!("{id}.out"));
            if skipped {
                assert!(
                    !observation.exists(),
                    "skipped hook must not write {id}.out"
                );
            } else {
                assert_eq!(fs::read_to_string(observation).unwrap(), "hook ran");
            }
            (id.to_string(), skipped)
        })
        .collect()
}

#[test]
fn durable_selection_is_applied_before_invocation_filters() {
    let root = scratch();
    fs::create_dir_all(&root).expect("create scratch root");
    fs::write(root.join("input"), "hook ran").unwrap();
    let revision = Command::new("git")
        .args(["rev-parse", "HEAD"])
        .current_dir(env!("CARGO_MANIFEST_DIR"))
        .output()
        .unwrap();
    assert!(revision.status.success());
    let binary = env!("CARGO_BIN_EXE_tama-run-hook");
    fs::write(root.join("run.json"), json!({
        "sourceRevision": String::from_utf8_lossy(&revision.stdout).trim(),
        "binary": binary, "binarySha256": tama_hooks::sha256::sha256_hex(&fs::read(binary).unwrap()),
    }).to_string()).unwrap();
    let registry = root.join("registry.json");
    let enforcement = root.join("hook-enforcement.json");
    let emergency = root.join("emergency.json");
    let control_root = root.join("session-control");
    fs::write(
        &registry,
        serde_json::to_string(&json!({
            "events": {
                "pre_tool_use:read": {
                    "blocking": true,
                    "hooks": [
                        {"id": "alpha", "command": format!("/bin/cp {:?} {:?}", root.join("input"), root.join("alpha.out")), "timeout": 5},
                        {"id": "beta", "command": format!("/bin/cp {:?} {:?}", root.join("input"), root.join("beta.out")), "timeout": 5}
                    ]
                }
            }
        }))
        .unwrap(),
    )
    .expect("write registry");
    let payload = json!({"session_id": "session-1", "cwd": root});

    let missing = run(
        &registry,
        &enforcement,
        &emergency,
        &control_root,
        &payload,
        None,
        None,
    );
    assert_eq!(
        result_flags(&missing, &root),
        vec![("alpha".into(), false), ("beta".into(), false)]
    );

    fs::write(&enforcement, "{bad json\n").expect("write malformed enforcement state");
    let malformed = run(
        &registry,
        &enforcement,
        &emergency,
        &control_root,
        &payload,
        None,
        None,
    );
    assert_eq!(
        result_flags(&malformed, &root),
        vec![("alpha".into(), false), ("beta".into(), false)]
    );
    assert!(String::from_utf8_lossy(&malformed.stderr)
        .contains("hook enforcement state warning: invalid"));

    write_enforcement_selection_at(&enforcement, EnforcementMode::Only, &["alpha".to_string()])
        .expect("write only selection");
    let selected = run(
        &registry,
        &enforcement,
        &emergency,
        &control_root,
        &payload,
        None,
        None,
    );
    assert_eq!(
        result_flags(&selected, &root),
        vec![("alpha".into(), false), ("beta".into(), true)]
    );

    let context = session_context("claude", Some(&payload)).expect("session context");
    fs::create_dir_all(&control_root).expect("create control root");
    fs::write(
        control_root.join(format!("{}.override.json", context.control_key)),
        serde_json::to_string(&json!({
            "schema": SESSION_CONTROL_SCHEMA,
            "agentId": context.agent_id,
            "sessionId": context.session_id,
            "controlKey": context.control_key,
            "enabledHookIds": ["beta"],
            "disabledHookIds": ["alpha"]
        }))
        .unwrap(),
    )
    .expect("write session override");
    let additive = run(
        &registry,
        &enforcement,
        &emergency,
        &control_root,
        &payload,
        None,
        None,
    );
    assert_eq!(
        result_flags(&additive, &root),
        vec![("alpha".into(), false), ("beta".into(), false)]
    );

    let disabled_filter = run(
        &registry,
        &enforcement,
        &emergency,
        &control_root,
        &payload,
        None,
        Some("alpha"),
    );
    assert_eq!(
        result_flags(&disabled_filter, &root),
        vec![("alpha".into(), true), ("beta".into(), false)]
    );
    let enabled_filter = run(
        &registry,
        &enforcement,
        &emergency,
        &control_root,
        &payload,
        Some("alpha"),
        None,
    );
    assert_eq!(
        result_flags(&enabled_filter, &root),
        vec![("alpha".into(), false), ("beta".into(), true)]
    );

    fs::write(
        &emergency,
        r#"{"schema":"ai.wisent.tama.hook-emergency-state.v1","disabled":true}"#,
    )
    .expect("write emergency state");
    let emergency_result = run(
        &registry,
        &enforcement,
        &emergency,
        &control_root,
        &payload,
        None,
        None,
    );
    assert_eq!(
        result_flags(&emergency_result, &root),
        vec![("alpha".into(), true), ("beta".into(), true)]
    );

    println!("retained enforcement evidence: {}", root.display());
}
