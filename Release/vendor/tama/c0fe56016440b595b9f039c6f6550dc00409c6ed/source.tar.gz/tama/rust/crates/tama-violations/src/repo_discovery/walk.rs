//! Which Git checkouts under a tree are ours to scan.
//!
//! A name list cannot answer that. It was tried three times: `.build`,
//! `Pods` and `SourcePackages` were added when one tree scan turned into six
//! hundred and fifty-five targets, and the same shape came back as
//! `.lake/packages/mathlib`, `codex-home/.tmp/plugins`, vendored
//! `espeak-ng-spm`, and a linked worktree of a repository already in the
//! list — 61 965 file-length violations, most of them somebody else's code
//! counted as ours.
//!
//! So provenance decides, and it needs exactly two structural facts:
//!
//! - a checkout whose `.git` is a **file** is a linked worktree or a
//!   submodule, so its content belongs to the repository that owns it;
//! - a checkout inside a path its owning repository **ignores** was written
//!   by a package manager, a cache or a scratch run, never by us.
//!
//! Both hold for any tool, including ones that do not exist yet. The name
//! list below stays only to keep the walk cheap.

use std::collections::BTreeMap;
use std::path::Path;
use std::process::{Command, Stdio};

/// Directories that never hold interesting checkouts and are expensive to
/// walk. Correctness comes from the two rules above; this is speed.
pub const PRUNE_DIR_NAMES: [&str; 19] = [
    ".git",
    "node_modules",
    "Library",
    ".Trash",
    ".cache",
    ".next",
    "__pycache__",
    "chromium-build",
    "dist",
    "build",
    ".build",
    "Pods",
    "SourcePackages",
    "vendor",
    "target",
    ".venv",
    "venv",
    "coverage",
    ".live-runtime-tmp",
];

/// Does `owner` ignore `path`? A dependency checkout always lands in an
/// ignored directory, because the repository that pulled it in refuses to
/// track it.
fn ignored_by_owner(owner: &Path, path: &Path) -> bool {
    Command::new("git")
        .arg("-C")
        .arg(owner)
        .args(["check-ignore", "--quiet", "--"])
        .arg(path)
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .status()
        .map(|status| status.success())
        .unwrap_or(false)
}

/// Every Git checkout under `root_dir` that belongs to this workspace, with
/// no per-origin deduplication.
///
/// Content scanning wants one checkout per repository; ownership questions
/// want them all. `wisent-compute` and `stado` in this workspace share the
/// origin `https://github.com/wisent-ai/stado.git`, so [`discover_repos`]
/// keeps only `stado` — and `wisent-compute` was holding twenty linked
/// worktrees that no reader of the deduplicated list could see. A worktree
/// registration lives in the checkout that created it, so a caller asking
/// what a tree owns has to see every checkout.
pub fn discover_checkouts(root_dir: &Path) -> Vec<String> {
    let mut repos = Vec::new();
    visit(root_dir, &mut repos, None);
    repos
}

/// Every Git checkout under `root_dir`, including the ones their owning
/// repository ignores.
///
/// The provenance rule in this module's header is right for content and
/// wrong for ownership, and the difference cost a false answer twice.
/// `paper-repos` is itself a repository that ignores the twenty-odd
/// checkouts nested inside it, so [`discover_checkouts`] returns only
/// `paper-repos`, and `wisent-general-theory` — which was holding a linked
/// worktree — was invisible to every reader of that list.
///
/// A checkout being ignored says who wrote its content. It says nothing
/// about what worktrees it registered, and a caller asking what this machine
/// owns has to see it. Content scanning keeps the filtered lists above.
pub fn discover_every_checkout(root_dir: &Path) -> Vec<String> {
    let mut repos = Vec::new();
    visit_with(root_dir, &mut repos, None, false);
    repos
}

/// What a copies pass prunes: package-manager and cache directories only.
///
/// [`PRUNE_DIR_NAMES`] also skips `vendor`, `target`, `build`, `.build` and
/// `dist` to keep a content scan cheap, and those are exactly the
/// directories a scratch clone is left in: on this machine the first pass
/// with that list missed the vendored clones under `growth-tactics/` and
/// `wisent-experiments/` entirely, and a clone one level under `target/`
/// would have been invisible too. A pass whose whole purpose is finding
/// second checkouts cannot inherit a speed list that hides them, so it pays
/// the walk.
/// `Pods`, `SourcePackages`, `checkouts` and `node_modules` stay pruned: the
/// checkouts there are a package manager's working state, which it
/// re-resolves on the next build, and reporting hundreds of them would bury
/// the answer. SwiftPM writes its dependency clones into
/// `.build/checkouts` and `.build/index-build/checkouts`, which is why the
/// bare name is on the list while `.build` itself is walked.
pub const COPY_PRUNE_DIR_NAMES: [&str; 14] = [
    ".git",
    "node_modules",
    "Pods",
    "checkouts",
    "SourcePackages",
    "Library",
    ".Trash",
    ".cache",
    "__pycache__",
    ".next",
    "coverage",
    ".venv",
    "venv",
    ".live-runtime-tmp",
];

/// Every Git checkout under `root_dir`, walking the build and vendor
/// directories [`discover_every_checkout`] prunes for speed.
pub fn discover_every_checkout_deep(root_dir: &Path) -> Vec<String> {
    let mut repos = Vec::new();
    visit_pruning(root_dir, &mut repos, None, false, &COPY_PRUNE_DIR_NAMES);
    repos
}

/// Finds the Git checkouts under `root_dir` that belong to this workspace.
///
/// Two checkouts of one repository are one repository: a scratch clone
/// reports the same file twice and fixing the source fixes both, so the
/// shortest path per origin remote is kept. A checkout with no origin is
/// nobody's copy and is always kept.
pub fn discover_repos(root_dir: &Path) -> Vec<String> {
    dedupe_by_origin(discover_checkouts(root_dir))
}

fn origin_remote(repo: &str) -> Option<String> {
    let output = Command::new("git")
        .arg("-C")
        .arg(repo)
        .args(["remote", "get-url", "origin"])
        .stdin(Stdio::null())
        .stderr(Stdio::null())
        .output()
        .ok()?;
    if !output.status.success() {
        return None;
    }
    let url = String::from_utf8_lossy(&output.stdout).trim().to_string();
    // A trailing `.git` or slash is the same repository spelled twice.
    let url = url
        .trim_end_matches('/')
        .trim_end_matches(".git")
        .to_string();
    (!url.is_empty()).then_some(url)
}

/// The copy an operator would edit: fewest path components, then the
/// lexicographically first, so the answer never depends on walk order.
fn preferred(current: &str, candidate: &str) -> bool {
    let depth = |path: &str| path.split('/').count();
    match depth(candidate).cmp(&depth(current)) {
        std::cmp::Ordering::Less => true,
        std::cmp::Ordering::Greater => false,
        std::cmp::Ordering::Equal => candidate < current,
    }
}

fn dedupe_by_origin(repos: Vec<String>) -> Vec<String> {
    let mut kept: BTreeMap<String, String> = BTreeMap::new();
    let mut anonymous: Vec<String> = Vec::new();
    for repo in repos {
        match origin_remote(&repo) {
            Some(origin) => match kept.get(&origin) {
                Some(current) if !preferred(current, &repo) => {}
                _ => {
                    kept.insert(origin, repo);
                }
            },
            None => anonymous.push(repo),
        }
    }
    let mut out: Vec<String> = kept.into_values().chain(anonymous).collect();
    out.sort();
    out
}

fn visit(dir: &Path, repos: &mut Vec<String>, owner: Option<&Path>) {
    visit_pruning(dir, repos, owner, true, &PRUNE_DIR_NAMES)
}

fn visit_with(dir: &Path, repos: &mut Vec<String>, owner: Option<&Path>, respect_ignore: bool) {
    visit_pruning(dir, repos, owner, respect_ignore, &PRUNE_DIR_NAMES)
}

/// `respect_ignore` false keeps a checkout its owner ignores, and keeps
/// descending past it. See [`discover_every_checkout`] for why ownership
/// questions need that and content questions do not. `prune` is the caller's
/// speed list, because a copies pass and a content scan disagree about which
/// directories are worth walking.
fn visit_pruning(
    dir: &Path,
    repos: &mut Vec<String>,
    owner: Option<&Path>,
    respect_ignore: bool,
    prune: &[&str],
) {
    let entries = match std::fs::read_dir(dir) {
        Ok(entries) => entries,
        Err(_) => return,
    };
    let mut names: Vec<(String, bool)> = Vec::new();
    let mut git_is_file = false;
    let mut is_checkout = false;
    for entry in entries.flatten() {
        let is_dir = entry.file_type().map(|kind| kind.is_dir()).unwrap_or(false);
        let name = entry.file_name().to_string_lossy().into_owned();
        if name == ".git" {
            is_checkout = true;
            git_is_file = !is_dir;
        }
        names.push((name, is_dir));
    }
    // Node `readdirSync` returns entries sorted by name.
    names.sort_by(|left, right| left.0.cmp(&right.0));
    if is_checkout {
        // A worktree or submodule: whoever owns it is already being scanned,
        // and its files are theirs, not a second repository's.
        if git_is_file {
            return;
        }
        if respect_ignore && owner.is_some_and(|owner| ignored_by_owner(owner, dir)) {
            return;
        }
        repos.push(dir.to_string_lossy().into_owned());
    }
    let descend_owner = if is_checkout { Some(dir) } else { owner };
    for (name, is_dir) in names {
        if !is_dir || prune.contains(&name.as_str()) {
            continue;
        }
        visit_pruning(
            &dir.join(&name),
            repos,
            descend_owner,
            respect_ignore,
            prune,
        );
    }
}
