//! Port of `src/adaptive/doctor/repair.mjs`: corpus-driven candidate
//! validation and consent-gated application of validated hook patches.
//! Also carries the minimal `src/core/catalog.mjs` surface the doctor
//! needs (`commandSourcePath`, catalog hook listing, `findHook`).

use std::collections::HashMap;
use std::fs;
use std::io::Write;
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};

pub use super::evidence::{live_script_path, read_closed_telemetry_events};
use crate::engine::load_engine;
use crate::segments::runner_command::extname;
use crate::telemetry::open_telemetry;
use crate::util::{js_string, now_ms, repo_root};

const RUN_BUDGET_MS: u64 = 10 * 1000;
const DRAFT_BUDGET_MS: u64 = 120 * 1000;
const SAMPLE_LIMIT: usize = 5;
const SAMPLE_CHARS: usize = 2000;

// ---------------------------------------------------------------- catalog --

/// `commandSourcePath(command)` from `src/core/catalog.mjs`.
pub fn command_source_path(command: &str) -> Option<String> {
    if command.is_empty() {
        return None;
    }
    let root = repo_root();
    let prefixes: [(String, &str); 6] = [
        (
            "/Users/lukaszbartoszcze/.shared-hooks/".to_string(),
            "shared-hooks/",
        ),
        (
            "/Users/lukaszbartoszcze/.codex/hooks/".to_string(),
            "codex-hooks/",
        ),
        (
            "/Users/lukaszbartoszcze/.claude/hooks/".to_string(),
            "claude-hooks/",
        ),
        (
            format!("{}/", root.join("shared-hooks").display()),
            "shared-hooks/",
        ),
        (
            format!("{}/", root.join("codex-hooks").display()),
            "codex-hooks/",
        ),
        (
            format!("{}/", root.join("claude-hooks").display()),
            "claude-hooks/",
        ),
    ];
    for (prefix, repo_dir) in &prefixes {
        if let Some(index) = command.find(prefix.as_str()) {
            let rest = &command[index + prefix.len()..];
            let first = rest.split(char::is_whitespace).next().unwrap_or("");
            return Some(format!("{}{}", repo_dir, first));
        }
    }
    None
}

/// The catalog view the doctor needs (`buildCatalog().hooks`).
#[derive(Debug, Clone)]
pub struct CatalogHook {
    pub id: String,
    pub command: String,
    pub source_path: Option<String>,
}

fn load_repo_registry(root: &Path) -> serde_json::Value {
    let path = root.join("shared-hooks").join("registry.json");
    match fs::read_to_string(path) {
        Ok(text) => {
            serde_json::from_str(&text).unwrap_or_else(|_| serde_json::json!({ "events": {} }))
        }
        Err(_) => serde_json::json!({ "events": {} }),
    }
}

/// `buildCatalog(root).hooks` reduced to id/command/sourcePath, sorted by id.
pub fn build_catalog_hooks(root: &Path) -> Vec<CatalogHook> {
    let registry = load_repo_registry(root);
    let mut by_id: HashMap<String, CatalogHook> = HashMap::new();
    if let Some(events) = registry.get("events").and_then(|e| e.as_object()) {
        for config in events.values() {
            let hooks = config.get("hooks").and_then(|h| h.as_array());
            let Some(hooks) = hooks else { continue };
            for hook in hooks {
                let source = hook
                    .get("source")
                    .filter(|s| crate::util::js_truthy(s))
                    .and_then(|s| s.as_str())
                    .and_then(command_source_path)
                    .or_else(|| {
                        hook.get("command")
                            .and_then(|c| c.as_str())
                            .and_then(command_source_path)
                    });
                let id = hook
                    .get("id")
                    .and_then(|v| v.as_str())
                    .unwrap_or("")
                    .to_string();
                let entry = by_id.entry(id.clone()).or_insert_with(|| CatalogHook {
                    id,
                    command: hook
                        .get("command")
                        .and_then(|c| c.as_str())
                        .unwrap_or("")
                        .to_string(),
                    source_path: None,
                });
                if entry.source_path.is_none() && source.is_some() {
                    entry.source_path = source;
                }
            }
        }
    }
    let mut catalog: Vec<CatalogHook> = by_id.into_values().collect();
    catalog.sort_by(|a, b| a.id.cmp(&b.id));
    catalog
}

/// `findHook(id, root)`.
pub fn find_hook(id: &str, root: &Path) -> Option<CatalogHook> {
    build_catalog_hooks(root)
        .into_iter()
        .find(|hook| hook.id == id)
}

// ----------------------------------------------------------------- paths --

struct HookPaths {
    command: Option<String>,
    live: Option<String>,
    archive: Option<PathBuf>,
}

fn registry_command(hook_id: &str, core: &crate::engine::Engine) -> Option<String> {
    for event in core.registry.events.values() {
        for entry in &event.hooks {
            if entry.id == hook_id {
                if let Some(command) = &entry.command {
                    if !command.is_empty() {
                        return Some(command.clone());
                    }
                }
            }
        }
    }
    None
}

fn hook_paths(hook_id: &str, core: &crate::engine::Engine) -> HookPaths {
    let root = repo_root();
    let catalog_hook = find_hook(hook_id, &root);
    // `registryCommand(...) ?? catalogHook?.command ?? null` — nullish
    // coalescing keeps an empty-string command.
    let command = registry_command(hook_id, core)
        .or_else(|| catalog_hook.as_ref().map(|h| h.command.clone()));
    let live = command
        .as_deref()
        .filter(|c| !c.is_empty())
        .and_then(live_script_path);
    let archive_rel = catalog_hook
        .and_then(|h| h.source_path)
        .or_else(|| command.as_deref().and_then(command_source_path));
    let archive = archive_rel.map(|rel| root.join(rel));
    HookPaths {
        command,
        live,
        archive,
    }
}

// ----------------------------------------------------------------- corpus --

struct Corpus {
    must_pass: Vec<serde_json::Value>,
    must_block: Vec<serde_json::Value>,
    labeled_count: usize,
}

/// `splitCorpus(stateDir, hookId)` — the latest label targeting a payload
/// wins; without `payloadTs` a label applies to the newest payload.
fn split_corpus(state_dir: &Path, hook_id: &str) -> Result<Corpus, String> {
    let rows = read_closed_telemetry_events(state_dir)?;
    let mut payloads: Vec<serde_json::Value> = Vec::new();
    let mut labels: HashMap<usize, serde_json::Value> = HashMap::new();
    for row in &rows {
        if row.get("id") != Some(&serde_json::Value::String(hook_id.to_string())) {
            continue;
        }
        let row_type = row.get("type").and_then(|v| v.as_str()).unwrap_or("");
        if row_type == "corpus_add" {
            payloads.push(row.clone());
            let index = payloads.len() - 1;
            if let Some(label) = row.get("label") {
                if crate::util::js_truthy(label) && label.as_str() != Some("unlabeled") {
                    labels.insert(index, label.clone());
                }
            }
            continue;
        }
        if row_type != "corpus_label" {
            continue;
        }
        let mut target: Option<usize> = None;
        if let Some(payload_ts) = row.get("payloadTs") {
            for index in (0..payloads.len()).rev() {
                if payloads[index].get("ts") == Some(payload_ts) {
                    target = Some(index);
                    break;
                }
            }
        } else if !payloads.is_empty() {
            target = Some(payloads.len() - 1);
        }
        if let Some(index) = target {
            let label = row.get("label").cloned().unwrap_or(serde_json::Value::Null);
            let label = if label.is_null() {
                serde_json::Value::String("unlabeled".to_string())
            } else {
                label
            };
            labels.insert(index, label);
        }
    }
    let mut must_pass = Vec::new();
    let mut must_block = Vec::new();
    for (index, row) in payloads.into_iter().enumerate() {
        let label = labels
            .get(&index)
            .cloned()
            .unwrap_or(serde_json::Value::String("unlabeled".to_string()));
        if label.as_str() == Some("unlabeled") {
            continue;
        }
        if label.as_str() == Some("fp") || label.as_str() == Some("fp-suspect") {
            must_pass.push(row);
        } else {
            must_block.push(row);
        }
    }
    let labeled_count = must_pass.len() + must_block.len();
    Ok(Corpus {
        must_pass,
        must_block,
        labeled_count,
    })
}

// ------------------------------------------------------------------ spawn --

/// `spawnSync(cmd, args, { input, encoding, timeout })` outcome.
pub struct SpawnOutcome {
    pub status: Option<i32>,
    pub signal: Option<String>,
    pub error: Option<String>,
    pub stdout: String,
    pub stderr: String,
}

/// Synchronous spawn with stdin input and a kill-on-timeout budget.
pub fn spawn_sync_capture(
    program: &str,
    args: &[String],
    input: &str,
    timeout_ms: u64,
) -> SpawnOutcome {
    let spawned = Command::new(program)
        .args(args)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn();
    let mut child = match spawned {
        Ok(child) => child,
        Err(error) => {
            let code = match error.kind() {
                std::io::ErrorKind::NotFound => "ENOENT",
                std::io::ErrorKind::PermissionDenied => "EACCES",
                _ => "EIO",
            };
            return SpawnOutcome {
                status: None,
                signal: None,
                error: Some(format!("Error: spawnSync {} {}", program, code)),
                stdout: String::new(),
                stderr: String::new(),
            };
        }
    };
    if let Some(mut stdin) = child.stdin.take() {
        let input = input.to_string();
        std::thread::spawn(move || {
            let _ = stdin.write_all(input.as_bytes());
        });
    }
    let deadline = std::time::Instant::now() + std::time::Duration::from_millis(timeout_ms);
    loop {
        match child.try_wait() {
            Ok(Some(_)) => break,
            Ok(None) => {
                if std::time::Instant::now() >= deadline {
                    let _ = child.kill();
                    let _ = child.wait();
                    let output = collect_output(&mut child);
                    return SpawnOutcome {
                        status: None,
                        signal: Some("SIGTERM".to_string()),
                        error: Some(format!("Error: spawnSync {} ETIMEDOUT", program)),
                        stdout: output.0,
                        stderr: output.1,
                    };
                }
                std::thread::sleep(std::time::Duration::from_millis(2));
            }
            Err(error) => {
                return SpawnOutcome {
                    status: None,
                    signal: None,
                    error: Some(format!("Error: {}", error)),
                    stdout: String::new(),
                    stderr: String::new(),
                };
            }
        }
    }
    let output = collect_output(&mut child);
    let status = child.try_wait().ok().flatten();
    let (code, signal) = match status {
        Some(exit) => decode_exit(exit),
        None => (None, None),
    };
    SpawnOutcome {
        status: code,
        signal,
        error: None,
        stdout: output.0,
        stderr: output.1,
    }
}

fn collect_output(child: &mut std::process::Child) -> (String, String) {
    use std::io::Read;
    let mut stdout = String::new();
    let mut stderr = String::new();
    if let Some(mut out) = child.stdout.take() {
        let _ = out.read_to_string(&mut stdout);
    }
    if let Some(mut err) = child.stderr.take() {
        let _ = err.read_to_string(&mut stderr);
    }
    (stdout, stderr)
}

fn decode_exit(exit: std::process::ExitStatus) -> (Option<i32>, Option<String>) {
    use std::os::unix::process::ExitStatusExt;
    if let Some(code) = exit.code() {
        return (Some(code), None);
    }
    (None, exit.signal().map(|sig| format!("SIG{}", sig)))
}

/// `blockVerdict(result)`.
fn block_verdict(result: &SpawnOutcome) -> bool {
    for stream in [&result.stdout, &result.stderr] {
        let text = stream.trim();
        if text.is_empty() {
            continue;
        }
        let mut pieces = vec![text];
        pieces.extend(text.split('\n'));
        for piece in pieces {
            let line = piece.trim();
            if line.starts_with("BLOCKED:") {
                return true;
            }
            if !line.starts_with('{') {
                continue;
            }
            if let Ok(parsed) = serde_json::from_str::<serde_json::Value>(line) {
                if parsed.get("decision").and_then(|v| v.as_str()) == Some("block") {
                    return true;
                }
            }
        }
    }
    false
}

// ------------------------------------------------------------------ brief --

pub struct Brief {
    pub hook_id: String,
    pub command: Option<String>,
    pub live: Option<String>,
    pub archive: Option<PathBuf>,
    pub must_pass_count: usize,
    pub must_block_count: usize,
    pub text: String,
}

/// `buildBrief(hookId)`.
pub fn build_brief(hook_id: &str) -> Result<Brief, String> {
    let core = load_engine();
    let paths = hook_paths(hook_id, &core);
    let corpus = split_corpus(&core.state_dir, hook_id)?;
    let source_path = paths
        .live
        .clone()
        .filter(|live| Path::new(live).exists())
        .or_else(|| {
            paths
                .archive
                .as_ref()
                .map(|a| a.to_string_lossy().to_string())
        });
    let source = source_path
        .as_deref()
        .filter(|p| Path::new(p).exists())
        .and_then(|p| fs::read_to_string(p).ok())
        .unwrap_or_default();
    let sample = |rows: &[serde_json::Value]| -> Vec<String> {
        rows.iter()
            .rev()
            .take(SAMPLE_LIMIT)
            .collect::<Vec<_>>()
            .into_iter()
            .rev()
            .map(|row| {
                let payload = row
                    .get("payload")
                    .cloned()
                    .unwrap_or_else(|| serde_json::json!({}));
                let text = serde_json::to_string(&payload).unwrap_or_default();
                text.chars().take(SAMPLE_CHARS).collect()
            })
            .collect()
    };
    let mut lines: Vec<String> = vec![
        format!("Hook under repair: {}", hook_id),
        format!(
            "Live script: {}",
            paths
                .live
                .clone()
                .unwrap_or_else(|| "unknown path".to_string())
        ),
        format!(
            "Registry command: {}",
            paths
                .command
                .clone()
                .unwrap_or_else(|| "not registered".to_string())
        ),
        "Goal: produce a minimal patch of the script so that every MUST-BLOCK payload".to_string(),
        "still blocks (nonzero exit or {\"decision\":\"block\"} JSON) and every MUST-PASS"
            .to_string(),
        "payload passes cleanly (zero exit, no block JSON). It must not crash on {}.".to_string(),
        format!(
            "--- MUST BLOCK payload samples ({} total) ---",
            corpus.must_block.len()
        ),
    ];
    lines.extend(sample(&corpus.must_block));
    lines.push(format!(
        "--- MUST PASS payload samples ({} total) ---",
        corpus.must_pass.len()
    ));
    lines.extend(sample(&corpus.must_pass));
    lines.push("--- CURRENT SOURCE ---".to_string());
    lines.push(source);
    lines.push(
        "Reply with the complete corrected file content only. No commentary, no markdown fences."
            .to_string(),
    );
    Ok(Brief {
        hook_id: hook_id.to_string(),
        command: paths.command,
        live: paths.live,
        archive: paths.archive,
        must_pass_count: corpus.must_pass.len(),
        must_block_count: corpus.must_block.len(),
        text: lines.join("\n"),
    })
}

// --------------------------------------------------------------- validate --

fn interpreter_for(ext: &str) -> Option<&'static str> {
    match ext {
        ".py" => Some("python3"),
        ".sh" => Some("bash"),
        ".mjs" => Some("node"),
        _ => None,
    }
}

/// `validateCandidate(hookId, candidateFilePath)` — returns the JS report
/// object shape (`{ ok, checked, failures, staged? }`).
pub fn validate_candidate(
    hook_id: &str,
    candidate_file_path: &str,
) -> Result<serde_json::Value, String> {
    let core = load_engine();
    let paths = hook_paths(hook_id, &core);
    let mut ext = extname(candidate_file_path);
    if ext.is_empty() {
        if let Some(live) = &paths.live {
            ext = extname(live);
        }
    }
    let Some(interpreter) = interpreter_for(&ext) else {
        return Ok(serde_json::json!({
            "ok": false,
            "checked": 0,
            "failures": [{ "kind": "setup", "detail": format!("no interpreter for extension \"{}\"", ext) }],
        }));
    };
    let corpus = split_corpus(&core.state_dir, hook_id)?;
    if corpus.labeled_count == 0 {
        return Ok(serde_json::json!({
            "ok": false,
            "checked": 0,
            "failures": [{ "kind": "insufficient-evidence", "detail": "no labeled corpus cases in validated closed telemetry segments" }],
        }));
    }
    let tmp_dir = core.state_dir.join("tmp");
    fs::create_dir_all(&tmp_dir).map_err(|e| format!("Error: {}", e))?;
    let staged = tmp_dir.join(format!("{}-under-test{}", hook_id, ext));
    fs::copy(candidate_file_path, &staged).map_err(|e| format!("Error: {}", e))?;
    let staged_text = staged.to_string_lossy().to_string();
    let run = |payload: &serde_json::Value| -> SpawnOutcome {
        let input = serde_json::to_string(payload).unwrap_or_else(|_| "{}".to_string());
        spawn_sync_capture(interpreter, &[staged_text.clone()], &input, RUN_BUDGET_MS)
    };
    let mut failures: Vec<serde_json::Value> = Vec::new();
    let mut checked = 0u64;
    for row in &corpus.must_block {
        checked += 1;
        let result = run(row.get("payload").unwrap_or(&serde_json::Value::Null));
        let blocked = block_verdict(&result) || result.status != Some(0);
        if !blocked {
            failures.push(serde_json::json!({
                "kind": "must-block",
                "ts": row.get("ts").cloned().unwrap_or(serde_json::Value::Null),
                "detail": "payload that must block passed",
            }));
        }
    }
    for row in &corpus.must_pass {
        checked += 1;
        let result = run(row.get("payload").unwrap_or(&serde_json::Value::Null));
        let clean = result.status == Some(0)
            && result.error.is_none()
            && result.signal.is_none()
            && !block_verdict(&result);
        if !clean {
            let detail = if let Some(error) = &result.error {
                error.clone()
            } else if block_verdict(&result) {
                "explicit block verdict".to_string()
            } else {
                let what = result
                    .status
                    .map(|s| s.to_string())
                    .or_else(|| result.signal.clone())
                    .unwrap_or_else(|| "null".to_string());
                format!("exit {}", what)
            };
            failures.push(serde_json::json!({
                "kind": "must-pass",
                "ts": row.get("ts").cloned().unwrap_or(serde_json::Value::Null),
                "detail": detail,
            }));
        }
    }
    checked += 1; // smoke run: an empty object payload must not crash the script
    let smoke = run(&serde_json::json!({}));
    if smoke.error.is_some() || smoke.signal.is_some() {
        let what = smoke
            .error
            .clone()
            .or(smoke.signal.clone())
            .unwrap_or_default();
        failures.push(serde_json::json!({
            "kind": "smoke",
            "detail": format!("crashed on empty payload: {}", what),
        }));
    }
    Ok(serde_json::json!({
        "ok": failures.is_empty(),
        "checked": checked,
        "failures": failures,
        "staged": staged_text,
    }))
}

// --------------------------------------------------------------- propose --

/// `unfence(text)`.
fn unfence(text: &str) -> String {
    let mut lines: Vec<&str> = text.split('\n').collect();
    if lines.first().map(|l| l.starts_with("```")).unwrap_or(false) {
        lines.remove(0);
    }
    if lines.last().map(|l| l.starts_with("```")).unwrap_or(false) {
        lines.pop();
    }
    lines.join("\n")
}

fn draft_with_claude(prompt: &str, out_path: &Path) -> Result<PathBuf, String> {
    if std::env::var("HOOKS_ADAPTIVE_NO_LLM").ok().as_deref() == Some("1") {
        return Err("LLM drafting disabled (HOOKS_ADAPTIVE_NO_LLM); pass --patch-file".to_string());
    }
    let probe = spawn_sync_capture("claude", &["--version".to_string()], "", DRAFT_BUDGET_MS);
    if probe.error.is_some() {
        return Err("local claude CLI unavailable; pass --patch-file".to_string());
    }
    let result = spawn_sync_capture(
        "claude",
        &["-p".to_string(), prompt.to_string()],
        "",
        DRAFT_BUDGET_MS,
    );
    let body = unfence(result.stdout.trim());
    if result.error.is_some() || result.status != Some(0) || body.is_empty() {
        return Err("claude draft did not produce content".to_string());
    }
    fs::write(out_path, format!("{}\n", body)).map_err(|e| format!("Error: {}", e))?;
    Ok(out_path.to_path_buf())
}

/// `propose(hookId, { patchFile })`.
pub fn propose(hook_id: &str, patch_file: Option<&str>) -> Result<serde_json::Value, String> {
    let core = load_engine();
    let paths = hook_paths(hook_id, &core);
    if paths.live.is_none() && paths.archive.is_none() {
        return Ok(serde_json::json!({
            "ok": false,
            "hookId": hook_id,
            "reason": format!("unknown hook or no script path: {}", hook_id),
        }));
    }
    let ext = match &paths.live {
        Some(live) => extname(live),
        None => extname(
            &paths
                .archive
                .as_ref()
                .map(|a| a.to_string_lossy().to_string())
                .unwrap_or_default(),
        ),
    };
    let tmp_dir = core.state_dir.join("tmp");
    fs::create_dir_all(&tmp_dir).map_err(|e| format!("Error: {}", e))?;
    let source_file = match patch_file {
        Some(file) => file.to_string(),
        None => {
            let brief = build_brief(hook_id)?;
            let draft_path = tmp_dir.join(format!("{}-draft{}", hook_id, ext));
            match draft_with_claude(&brief.text, &draft_path) {
                Ok(path) => path.to_string_lossy().to_string(),
                Err(reason) => {
                    return Ok(
                        serde_json::json!({ "ok": false, "hookId": hook_id, "reason": reason }),
                    );
                }
            }
        }
    };
    if !Path::new(&source_file).exists() {
        return Ok(serde_json::json!({
            "ok": false,
            "hookId": hook_id,
            "reason": format!("patch file not found: {}", source_file),
        }));
    }
    let report = validate_candidate(hook_id, &source_file)?;
    if report.get("ok").and_then(|v| v.as_bool()) != Some(true) {
        let mut merged = report.as_object().cloned().unwrap_or_default();
        merged.insert("hookId".into(), hook_id.into());
        merged.insert("patchFile".into(), source_file.into());
        merged.insert(
            "reason".into(),
            format!(
                "validation did not pass; artifacts left in {}",
                tmp_dir.display()
            )
            .into(),
        );
        return Ok(serde_json::Value::Object(merged));
    }
    let dir = core
        .state_dir
        .join("proposals")
        .join(format!("{}-{}", hook_id, now_ms()));
    fs::create_dir_all(&dir).map_err(|e| format!("Error: {}", e))?;
    let proposed = dir.join(format!("proposed{}", ext));
    fs::copy(&source_file, &proposed).map_err(|e| format!("Error: {}", e))?;
    let diff_stdout = paths.live.as_deref().map(|live| {
        spawn_sync_capture(
            "diff",
            &[
                "-u".to_string(),
                live.to_string(),
                proposed.to_string_lossy().to_string(),
            ],
            "",
            RUN_BUDGET_MS,
        )
        .stdout
    });
    fs::write(dir.join("proposed.diff"), diff_stdout.unwrap_or_default())
        .map_err(|e| format!("Error: {}", e))?;
    let mut full = report.as_object().cloned().unwrap_or_default();
    full.insert("hookId".into(), hook_id.into());
    full.insert(
        "proposalDir".into(),
        dir.to_string_lossy().to_string().into(),
    );
    full.insert(
        "proposed".into(),
        proposed.to_string_lossy().to_string().into(),
    );
    full.insert(
        "livePath".into(),
        paths
            .live
            .clone()
            .map(Into::into)
            .unwrap_or(serde_json::Value::Null),
    );
    full.insert(
        "archivePath".into(),
        paths
            .archive
            .as_ref()
            .map(|a| a.to_string_lossy().to_string().into())
            .unwrap_or(serde_json::Value::Null),
    );
    let full = serde_json::Value::Object(full);
    fs::write(
        dir.join("report.json"),
        format!(
            "{}\n",
            serde_json::to_string_pretty(&full).unwrap_or_default()
        ),
    )
    .map_err(|e| format!("Error: {}", e))?;
    fs::write(dir.join("summary.md"), summary_text(&full)).map_err(|e| format!("Error: {}", e))?;
    Ok(full)
}

/// `summaryText(report)`.
fn summary_text(report: &serde_json::Value) -> String {
    let failures = report.get("failures").and_then(|v| v.as_array());
    let fail_lines: Vec<String> = match failures {
        Some(list) if !list.is_empty() => list
            .iter()
            .map(|failure| {
                format!(
                    "- {}: {}",
                    failure.get("kind").map(js_string).unwrap_or_default(),
                    failure.get("detail").map(js_string).unwrap_or_default()
                )
            })
            .collect(),
        _ => vec!["- none".to_string()],
    };
    let render = |key: &str, fallback: &str| {
        report
            .get(key)
            .filter(|v| !v.is_null())
            .map(js_string)
            .unwrap_or_else(|| fallback.to_string())
    };
    let mut lines = vec![
        format!("# Repair proposal: {}", render("hookId", "undefined")),
        String::new(),
        format!("Live path: {}", render("livePath", "unknown")),
        format!("Archive path: {}", render("archivePath", "not archived")),
        format!("Corpus runs: {}", render("checked", "undefined")),
        String::new(),
        "## Validation failures".to_string(),
    ];
    lines.extend(fail_lines);
    lines.push(String::new());
    lines.push(format!(
        "Apply with: doctor apply {}",
        render("proposalDir", "undefined")
    ));
    lines.push(
        "Requires DEVICE_HOOK_EDIT_APPROVED set by the owner outside the session.".to_string(),
    );
    lines.push(String::new());
    lines.join("\n")
}

// ----------------------------------------------------------------- apply --

/// `applyProposal(proposalDir)` — fs/JSON errors propagate like the JS
/// throws, which `doctor/cli` turns into `doctor: <error>` and exit 1.
pub fn apply_proposal(proposal_dir: &str) -> Result<i32, String> {
    use std::io::Write as _;
    if std::env::var("DEVICE_HOOK_EDIT_APPROVED").ok().as_deref() != Some("1") {
        let _ = writeln!(
            std::io::stderr(),
            "refusing to modify live hooks: DEVICE_HOOK_EDIT_APPROVED is not set."
        );
        let _ = writeln!(
            std::io::stderr(),
            "Owner consent flow: see https://tama.wisent.com/docs/hook-management"
        );
        return Ok(1);
    }
    let report_path = Path::new(proposal_dir).join("report.json");
    if !report_path.exists() {
        let _ = writeln!(std::io::stderr(), "no report.json in {}", proposal_dir);
        return Ok(1);
    }
    let report: serde_json::Value = match fs::read_to_string(&report_path)
        .ok()
        .and_then(|text| serde_json::from_str(&text).ok())
    {
        Some(report) => report,
        None => {
            let _ = writeln!(
                std::io::stderr(),
                "unreadable report.json: SyntaxError: Unexpected token in JSON"
            );
            return Ok(1);
        }
    };
    let core = load_engine();
    let hook_id = report.get("hookId").and_then(|v| v.as_str()).unwrap_or("");
    let paths = hook_paths(hook_id, &core);
    let proposed = report
        .get("proposed")
        .and_then(|v| v.as_str())
        .map(str::to_string)
        .unwrap_or_else(|| {
            let ext = extname(paths.live.as_deref().unwrap_or(""));
            Path::new(proposal_dir)
                .join(format!("proposed{}", ext))
                .to_string_lossy()
                .to_string()
        });
    let live = match &paths.live {
        Some(live) if Path::new(&proposed).exists() => live.clone(),
        _ => {
            let rendered = report
                .get("hookId")
                .map(js_string)
                .unwrap_or_else(|| "undefined".to_string());
            let _ = writeln!(
                std::io::stderr(),
                "missing live path or proposed file for {}",
                rendered
            );
            return Ok(1);
        }
    };
    let backup_dir = core.state_dir.join("backup");
    fs::create_dir_all(&backup_dir).map_err(|e| format!("Error: {}", e))?;
    let backup_name = Path::new(&live)
        .file_name()
        .map(|n| n.to_string_lossy().to_string())
        .unwrap_or_default();
    let backup_path = backup_dir.join(format!("{}.{}", backup_name, now_ms()));
    if Path::new(&live).exists() {
        fs::copy(&live, &backup_path).map_err(|e| format!("Error: {}", e))?;
    }
    fs::copy(&proposed, &live).map_err(|e| format!("Error: {}", e))?;
    if let Some(archive) = &paths.archive {
        fs::copy(&proposed, archive).map_err(|e| format!("Error: {}", e))?;
    }
    let telemetry = open_telemetry(&core.state_dir);
    let archive_note = paths
        .archive
        .as_ref()
        .map(|a| format!(", archive {}", a.display()))
        .unwrap_or_default();
    telemetry.warn(&format!(
        "doctor apply: {} <- {} (backup {}{})",
        js_string(report.get("hookId").unwrap_or(&serde_json::Value::Null)),
        proposed,
        backup_path.display(),
        archive_note
    ));
    telemetry.close();
    println!(
        "applied {}; backup at {}",
        js_string(report.get("hookId").unwrap_or(&serde_json::Value::Null)),
        backup_path.display()
    );
    Ok(0)
}
