//! Which checkouts a tree scan claims as ours.
//!
//! Driven through the real `tama find-violations --tree`, whose JSON names
//! every repository it scanned. The tree below has one of each shape that
//! inflated the machine-wide inventory: a dependency checkout in an ignored
//! path, a linked worktree, and an ordinary nested checkout that nobody
//! ignores and that must still be found.

use std::fs;
use std::path::{Path, PathBuf};
use std::process::Command;
use std::time::{SystemTime, UNIX_EPOCH};

use serde_json::Value;

fn scratch(label: &str) -> PathBuf {
    let unique = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .expect("clock before epoch")
        .as_nanos();
    let path = std::env::temp_dir().join(format!(
        "tama-discovery-{label}-{}-{unique}",
        std::process::id()
    ));
    fs::create_dir_all(&path).expect("create scratch root");
    path
}

fn git(repo: &Path, args: &[&str]) {
    let status = Command::new("git")
        .args(args)
        .current_dir(repo)
        .status()
        .expect("run git");
    assert!(status.success(), "git {args:?} failed in {repo:?}");
}

fn init_repo(path: &Path) {
    fs::create_dir_all(path).expect("create repo");
    git(path, &["init", "--quiet"]);
    git(path, &["config", "user.email", "probe@wisent.com"]);
    git(path, &["config", "user.name", "probe"]);
    fs::write(path.join("kept.js"), "export const ok = true;\n").expect("write file");
    git(path, &["add", "-A"]);
    git(path, &["commit", "--quiet", "-m", "probe"]);
}

fn tama_root() -> PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR"))
        .ancestors()
        .nth("3".parse().expect("valid ancestor count"))
        .expect("tama root above rust/crates/tama-cli")
        .to_path_buf()
}

/// Every repository the scan claims, as absolute paths.
fn scanned_repos(tree: &Path) -> Vec<String> {
    let root = tama_root();
    let hook = root.join("shared-hooks/block_oversized_files.sh");
    let output = Command::new(env!("CARGO_BIN_EXE_tama-cli"))
        .args(["find-violations", "--tree"])
        .arg(tree)
        .arg("--hook")
        .arg(&hook)
        .arg("--json")
        .env("TAMA_ROOT", &root)
        .output()
        .expect("run tama find-violations");
    let document: Value = serde_json::from_slice(&output.stdout)
        .unwrap_or_else(|error| panic!("no JSON from find-violations ({error}): {output:?}"));
    document
        .get("repos")
        .and_then(Value::as_array)
        .unwrap_or_else(|| panic!("scan emitted no repos: {document}"))
        .iter()
        .filter_map(|repo| repo.get("repo").and_then(Value::as_str))
        .map(str::to_string)
        .collect()
}

#[test]
fn a_dependency_checkout_in_an_ignored_path_is_not_a_target() {
    let root = scratch("ignored");
    let owner = root.join("owner");
    init_repo(&owner);
    fs::write(owner.join(".gitignore"), "deps/\n").expect("write ignore file");
    git(&owner, &["add", "-A"]);
    git(&owner, &["commit", "--quiet", "-m", "ignore deps"]);
    let dependency = owner.join("deps").join("upstream");
    init_repo(&dependency);

    let scanned = scanned_repos(&root);
    assert!(
        scanned.iter().any(|repo| repo == &owner.to_string_lossy()),
        "the owning repository is ours: {scanned:?}"
    );
    assert!(
        !scanned.iter().any(|repo| repo.contains("deps/upstream")),
        "a checkout its owner ignores was written by a package manager: {scanned:?}"
    );
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn a_linked_worktree_is_not_a_second_repository() {
    let root = scratch("worktree");
    let owner = root.join("owner");
    init_repo(&owner);
    git(
        &owner,
        &["worktree", "add", "--quiet", "-b", "probe", "../checkout"],
    );

    let scanned = scanned_repos(&root);
    assert!(
        scanned.iter().any(|repo| repo == &owner.to_string_lossy()),
        "the owning repository is still scanned: {scanned:?}"
    );
    assert!(
        !scanned.iter().any(|repo| repo.ends_with("checkout")),
        "a worktree duplicates the files of the repository that owns it: {scanned:?}"
    );
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn an_ordinary_nested_checkout_is_still_found() {
    let root = scratch("nested");
    let outer = root.join("outer");
    init_repo(&outer);
    let inner = outer.join("packages").join("inner");
    init_repo(&inner);

    let scanned = scanned_repos(&root);
    assert!(
        scanned.iter().any(|repo| repo == &outer.to_string_lossy()),
        "the outer repository is ours: {scanned:?}"
    );
    assert!(
        scanned.iter().any(|repo| repo == &inner.to_string_lossy()),
        "nobody ignores the inner checkout, so it is ours too: {scanned:?}"
    );
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn two_clones_of_one_repository_are_one_target() {
    let root = scratch("clones");
    let origin = root.join("origin.git");
    fs::create_dir_all(&origin).expect("create origin");
    git(&origin, &["init", "--quiet", "--bare"]);
    let source = root.join("source");
    init_repo(&source);
    git(
        &source,
        &["remote", "add", "origin", &origin.to_string_lossy()],
    );
    git(&source, &["push", "--quiet", "origin", "HEAD"]);
    let scratch_clone = root.join("scratch").join("deep").join("copy");
    fs::create_dir_all(scratch_clone.parent().expect("clone parent")).expect("create clone parent");
    git(
        &root,
        &[
            "clone",
            "--quiet",
            &origin.to_string_lossy(),
            &scratch_clone.to_string_lossy(),
        ],
    );

    let scanned = scanned_repos(&root);
    let copies: Vec<&String> = scanned
        .iter()
        .filter(|repo| repo.contains("source") || repo.contains("copy"))
        .collect();
    assert_eq!(
        copies.len(),
        "1".parse::<usize>().expect("valid count"),
        "one repository is one target, whichever paths hold it: {scanned:?}"
    );
    assert!(
        copies[false as usize].ends_with("source"),
        "the shallowest copy is the one an operator would edit: {copies:?}"
    );
    let _ = fs::remove_dir_all(&root);
}
