//! Rust port of the helpers from `shared-hooks/run-one-session-hook.js`:
//! provider catalog validation, launch-plan construction (including the
//! isolated CODEX_HOME / OMP agent transports) and the OMP-facing payload
//! builders used by the extension entry point.

use crate::hook_exec::{looks_like_malfunction, output_block_reason, run_hook_command, HookOutput};
use crate::registry::{matching_hooks, provider_hooks};
use crate::util::{home_dir, js_string_or_empty, random_uuid, shared_hooks_root};
use serde_json::{json, Map, Value};
use std::path::{Path, PathBuf};

pub const PROVIDER_CATALOG_SCHEMA: &str = "ai.wisent.tama.providers.v1";

/// `registryPath` / `providerCatalogPath` / `workRoot` resolution.
pub fn registry_path() -> PathBuf {
    std::env::var_os("AGENT_HOOK_REGISTRY")
        .map(PathBuf::from)
        .unwrap_or_else(|| shared_hooks_root().join("registry.json"))
}

pub fn provider_catalog_path() -> PathBuf {
    std::env::var_os("TAMA_PROVIDER_CATALOG")
        .map(PathBuf::from)
        .unwrap_or_else(|| shared_hooks_root().join("providers.json"))
}

pub fn work_root() -> PathBuf {
    std::env::var_os("TAMA_SESSION_HOOK_WORK_ROOT")
        .map(PathBuf::from)
        .unwrap_or_else(|| {
            shared_hooks_root()
                .parent()
                .unwrap_or_else(|| Path::new("/"))
                .join(".tama")
                .join("one-session-hook")
        })
}

/// `extensionPath` in JS is the run-one-session-hook script itself; OMP can
/// only load JS extensions, so the port keeps pointing at the JS file.
pub fn extension_path() -> PathBuf {
    shared_hooks_root().join("run-one-session-hook.js")
}

pub fn run_hook_path() -> PathBuf {
    shared_hooks_root().join("run-hook.mjs")
}

/// Port of the top-level provider catalog validation.
pub fn load_provider_catalog(path: &Path) -> Result<Map<String, Value>, String> {
    let text = std::fs::read_to_string(path).map_err(|e| {
        if e.kind() == std::io::ErrorKind::NotFound {
            format!(
                "ENOENT: no such file or directory, open '{}'",
                path.display()
            )
        } else {
            e.to_string()
        }
    })?;
    let catalog: Value = serde_json::from_str(&text).map_err(|e| format!("{}", e))?;
    let valid = catalog.get("schema").and_then(Value::as_str) == Some(PROVIDER_CATALOG_SCHEMA)
        && catalog
            .get("providers")
            .map(Value::is_object)
            .unwrap_or(false);
    if !valid {
        return Err(format!("Invalid Tama provider catalog: {}", path.display()));
    }
    Ok(catalog
        .get("providers")
        .and_then(Value::as_object)
        .cloned()
        .unwrap_or_default())
}

/// Port of `expandArguments`.
pub fn expand_arguments(
    template: &[Value],
    values: &Map<String, Value>,
) -> Result<Vec<String>, String> {
    let mut out = Vec::new();
    for argument in template {
        let Some(argument) = argument.as_str() else {
            continue;
        };
        if argument == "{session}" && values.get("session").is_none() {
            continue;
        }
        if !(argument.starts_with('{') && argument.ends_with('}')) {
            out.push(argument.to_string());
            continue;
        }
        let key = &argument[1..argument.len() - 1];
        match values.get(key) {
            Some(value) => out.push(js_string_or_empty(Some(value))),
            None => {
                return Err(format!(
                    "Unknown provider argument placeholder: {}",
                    argument
                ))
            }
        }
    }
    Ok(out)
}

/// A prepared provider launch (`launchForProvider` result).
pub struct LaunchPlan {
    pub executable: String,
    pub args: Vec<String>,
    pub env: Vec<(String, String)>,
    /// Temp directory to remove after the child exits (`cleanup()`).
    pub cleanup: Option<PathBuf>,
}

fn validate_provider(provider: &Value) -> Result<(), String> {
    let ok = provider
        .get("executable")
        .map(Value::is_string)
        .unwrap_or(false)
        && provider
            .get("executableEnv")
            .map(Value::is_string)
            .unwrap_or(false)
        && provider
            .get("hookTransport")
            .map(Value::is_string)
            .unwrap_or(false)
        && provider
            .get("newArguments")
            .map(Value::is_array)
            .unwrap_or(false)
        && provider
            .get("resumeArguments")
            .map(Value::is_array)
            .unwrap_or(false);
    if !ok {
        return Err("Invalid provider entry in Tama provider catalog.".to_string());
    }
    Ok(())
}

/// Port of `isolatedCodexHome`.
pub fn isolated_codex_home(
    registry: &Value,
    hook_id: &str,
    cwd: &str,
    provider: &str,
) -> Result<PathBuf, String> {
    use std::os::unix::fs::PermissionsExt;
    let source = std::env::var_os("CODEX_HOME")
        .map(PathBuf::from)
        .unwrap_or_else(|| home_dir().join(".codex"));
    let path = work_root().join(format!("codex-{}", random_uuid()));
    std::fs::create_dir_all(&path).map_err(|e| e.to_string())?;
    std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o700))
        .map_err(|e| e.to_string())?;
    let excluded = [
        "config.toml",
        "hooks.json",
        "plugins",
        "requirements.toml",
        "tmp",
        ".tmp",
    ];
    let entries = std::fs::read_dir(&source).map_err(|e| {
        if e.kind() == std::io::ErrorKind::NotFound {
            format!(
                "ENOENT: no such file or directory, scandir '{}'",
                source.display()
            )
        } else {
            e.to_string()
        }
    })?;
    for entry in entries {
        let entry = entry.map_err(|e| e.to_string())?;
        let name = entry.file_name().to_string_lossy().into_owned();
        if excluded.contains(&name.as_str()) {
            continue;
        }
        let from = source.join(&name);
        let to = path.join(&name);
        std::os::unix::fs::symlink(&from, &to).map_err(|e| e.to_string())?;
    }
    let hooks = provider_hooks(registry, hook_id, provider, &run_hook_path())?;
    let hooks_path = path.join("hooks.json");
    std::fs::write(
        &hooks_path,
        format!(
            "{}\n",
            serde_json::to_string_pretty(&json!({ "hooks": hooks })).unwrap_or_default()
        ),
    )
    .map_err(|e| e.to_string())?;
    std::fs::set_permissions(&hooks_path, std::fs::Permissions::from_mode(0o600))
        .map_err(|e| e.to_string())?;
    let config_path = path.join("config.toml");
    let cwd_json = serde_json::to_string(&json!(cwd)).unwrap_or_default();
    std::fs::write(
        &config_path,
        format!(
            "[features]\nhooks = true\n\n[projects.{}]\ntrust_level = \"untrusted\"\n",
            cwd_json
        ),
    )
    .map_err(|e| e.to_string())?;
    std::fs::set_permissions(&config_path, std::fs::Permissions::from_mode(0o600))
        .map_err(|e| e.to_string())?;
    Ok(path)
}

/// The python3 one-liner from `isolatedOmpAgent`.
const SQLITE_SNAPSHOT_SCRIPT: &str = "import sqlite3, sys
from pathlib import Path
source, target = map(Path, sys.argv[1:3])
for name in (\"agent.db\", \"models.db\", \"history.db\"):
    if not (source / name).exists(): continue
    source_db = sqlite3.connect(f\"file:{source / name}?mode=ro\", uri=True)
    target_db = sqlite3.connect(target / name)
    source_db.backup(target_db)
    target_db.close()
    source_db.close()";

/// Port of `isolatedOmpAgent`.
pub fn isolated_omp_agent() -> Result<PathBuf, String> {
    use std::os::unix::fs::PermissionsExt;
    let source = std::env::var_os("PI_CODING_AGENT_DIR")
        .map(PathBuf::from)
        .unwrap_or_else(|| home_dir().join(".omp").join("agent"));
    let path = work_root().join(format!("omp-agent-{}", random_uuid()));
    std::fs::create_dir_all(&path).map_err(|e| e.to_string())?;
    std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o700))
        .map_err(|e| e.to_string())?;
    let source_config = source.join("config.yml");
    if source_config.exists() {
        let excluded_keys = ["disabledExtensions", "extensions", "hooks"];
        let text = std::fs::read_to_string(&source_config).map_err(|e| e.to_string())?;
        let lines: Vec<&str> = text.split('\n').collect();
        let mut kept: Vec<&str> = Vec::new();
        for (index, line) in lines.iter().enumerate() {
            let mut owner = index as isize;
            while owner >= 0 && lines[owner as usize].starts_with(|c: char| c.is_whitespace()) {
                owner -= 1;
            }
            let key = if owner >= 0 {
                parse_yaml_key(lines[owner as usize])
            } else {
                None
            };
            let exclude = key.map(|k| excluded_keys.contains(&k)).unwrap_or(false);
            if !exclude {
                kept.push(line);
            }
        }
        let config_path = path.join("config.yml");
        std::fs::write(&config_path, kept.join("\n")).map_err(|e| e.to_string())?;
        std::fs::set_permissions(&config_path, std::fs::Permissions::from_mode(0o600))
            .map_err(|e| e.to_string())?;
    }
    let snapshot = std::process::Command::new("python3")
        .arg("-c")
        .arg(SQLITE_SNAPSHOT_SCRIPT)
        .arg(&source)
        .arg(&path)
        .output();
    let failed = match &snapshot {
        Ok(output) => !output.status.success(),
        Err(_) => true,
    };
    if failed {
        let _ = std::fs::remove_dir_all(&path);
        let detail = match &snapshot {
            Ok(output) => String::from_utf8_lossy(&output.stderr).trim().to_string(),
            Err(e) => {
                if e.kind() == std::io::ErrorKind::NotFound {
                    "spawnSync python3 ENOENT".to_string()
                } else {
                    e.to_string()
                }
            }
        };
        return Err(format!("Could not snapshot isolated OMP state: {}", detail));
    }
    let changelog = source.join("last-changelog-version");
    if changelog.exists() {
        let bytes = std::fs::read(&changelog).map_err(|e| e.to_string())?;
        std::fs::write(path.join("last-changelog-version"), bytes).map_err(|e| e.to_string())?;
    }
    Ok(path)
}

/// `lines[owner]?.match(/^([^#\s][^:]*):/)?.[1]`
fn parse_yaml_key(line: &str) -> Option<&str> {
    let first = line.chars().next()?;
    if first == '#' || first.is_whitespace() {
        return None;
    }
    let colon = line.find(':')?;
    if colon == 0 {
        return None;
    }
    Some(&line[..colon])
}

/// Port of `launchForProvider`.
pub fn launch_for_provider(
    registry: &Value,
    provider_name: &str,
    provider: &Value,
    hook_id: &str,
    mode: &str,
    session: Option<&str>,
    cwd: &str,
) -> Result<LaunchPlan, String> {
    validate_provider(provider)?;
    let mut env = vec![
        ("TAMA_ONE_SESSION_HOOK_ID".to_string(), hook_id.to_string()),
        (
            "TAMA_SESSION_OWNER_PID".to_string(),
            std::process::id().to_string(),
        ),
    ];
    let mut values = Map::new();
    values.insert("cwd".into(), json!(cwd));
    values.insert(
        "extensionPath".into(),
        json!(extension_path().display().to_string()),
    );
    if let Some(session) = session {
        values.insert("session".into(), json!(session));
    }
    let session_dir = std::env::var_os("PI_CODING_AGENT_DIR")
        .map(PathBuf::from)
        .unwrap_or_else(|| home_dir().join(".omp").join("agent"))
        .join("sessions");
    values.insert(
        "sessionDir".into(),
        json!(session_dir.display().to_string()),
    );
    let mut cleanup = None;

    let transport = provider
        .get("hookTransport")
        .and_then(Value::as_str)
        .unwrap_or_default();
    match transport {
        "inline-settings" => {
            let hooks = provider_hooks(registry, hook_id, provider_name, &run_hook_path())?;
            values.insert(
                "hooksJson".into(),
                json!(serde_json::to_string(&json!({ "hooks": hooks })).unwrap_or_default()),
            );
        }
        "isolated-codex-home" => {
            let isolated = isolated_codex_home(registry, hook_id, cwd, provider_name)?;
            env.push(("CODEX_HOME".to_string(), isolated.display().to_string()));
            cleanup = Some(isolated);
        }
        "omp-extension" => {
            let isolated = isolated_omp_agent()?;
            env.push((
                "PI_CODING_AGENT_DIR".to_string(),
                isolated.display().to_string(),
            ));
            cleanup = Some(isolated);
        }
        other => return Err(format!("Unsupported provider hook transport: {}", other)),
    }

    let template = if mode == "new" {
        provider
            .get("newArguments")
            .and_then(Value::as_array)
            .cloned()
            .unwrap_or_default()
    } else {
        provider
            .get("resumeArguments")
            .and_then(Value::as_array)
            .cloned()
            .unwrap_or_default()
    };
    let executable_env = provider
        .get("executableEnv")
        .and_then(Value::as_str)
        .unwrap_or_default();
    let executable = std::env::var(executable_env)
        .ok()
        .filter(|v| !v.is_empty())
        .unwrap_or_else(|| {
            provider
                .get("executable")
                .and_then(Value::as_str)
                .unwrap_or_default()
                .to_string()
        });
    Ok(LaunchPlan {
        executable,
        args: expand_arguments(&template, &values)?,
        env,
        cleanup,
    })
}

// ---------------------------------------------------------------------------
// OMP extension entry (the default export in JS): payload builders and the
// command runner used by `runOneSessionHook(pi)`.
// ---------------------------------------------------------------------------

/// Port of `ompEvent` (run-one-session-hook variant — no `lookup` mapping).
pub fn omp_event(name: &str) -> String {
    let normalized = name.to_lowercase();
    let event = match normalized.as_str() {
        "read" => "pre_tool_use:read",
        "notebookedit" | "notebook" => "pre_tool_use:notebook",
        "multiedit" => "pre_tool_use:multiedit",
        "write" | "edit" | "apply_patch" => "pre_tool_use:edit",
        "bash" => "pre_tool_use:bash",
        "monitor" | "schedulewakeup" => "pre_tool_use:wait",
        "task" | "agent" => "pre_tool_use:task",
        "todo" => "pre_tool_use:todo",
        "goal" => "pre_tool_use:goal",
        n if n == "ask" || n.ends_with(".ask") || n.ends_with("/ask") || n.ends_with("_ask") => {
            "pre_tool_use:ask"
        }
        "ssh" => "pre_tool_use:ssh",
        _ => "pre_tool_use:eval",
    };
    event.to_string()
}

/// Port of `ompPayload`.
pub fn omp_payload(event: &Value) -> Value {
    let name = js_string_or_empty(event.get("toolName").or_else(|| event.get("name")));
    let input = match event.get("input").or_else(|| event.get("params")) {
        Some(v) if v.is_object() => v.clone(),
        _ => json!({}),
    };
    json!({
        "agent_hook_event": "tool_call",
        "runtime": "omp",
        "session_id": event
            .get("sessionId")
            .or_else(|| event.get("session_id"))
            .or_else(|| event.get("session").and_then(|s| s.get("id")))
            .cloned()
            .unwrap_or(Value::Null),
        "project_dir": event.get("cwd").filter(|v| crate::util::js_truthy(v)).cloned().unwrap_or_else(|| {
            json!(std::env::current_dir().map(|p| p.display().to_string()).unwrap_or_default())
        }),
        "tool_name": name,
        "tool_input": input,
        "tool": { "name": name, "input": input },
    })
}

/// Result of the run-one-session-hook `runCommand`.
pub struct CommandVerdict {
    pub blocked: bool,
    pub reason: Option<String>,
}

/// Port of `runCommand` from run-one-session-hook.js. `selected_hook_id` is
/// `TAMA_ONE_SESSION_HOOK_ID`, used in malfunction/timeout messages.
pub fn run_command(
    command: &str,
    payload: &Value,
    timeout_ms: u64,
    selected_hook_id: &str,
) -> CommandVerdict {
    let tokens = crate::hook_exec::tokenize_command(command);
    if tokens.first().map(|s| s.is_empty()).unwrap_or(true) {
        return CommandVerdict {
            blocked: false,
            reason: None,
        };
    }
    let output: HookOutput = run_hook_command(command, payload, timeout_ms, &[], &[]);
    if output.spawn_error {
        eprintln!("{} malfunctioned: {}", selected_hook_id, output.stderr);
        return CommandVerdict {
            blocked: false,
            reason: None,
        };
    }
    if output.timed_out {
        return CommandVerdict {
            blocked: true,
            reason: Some(format!("{} timed out", selected_hook_id)),
        };
    }
    let reason =
        output_block_reason(&output.stdout).or_else(|| output_block_reason(&output.stderr));
    if let Some(reason) = reason {
        return CommandVerdict {
            blocked: true,
            reason: Some(reason),
        };
    }
    let code = output.code.unwrap_or(0);
    if code == 0 {
        return CommandVerdict {
            blocked: false,
            reason: None,
        };
    }
    if looks_like_malfunction(&output) {
        // A crashing hook is not a policy decision.
        let detail = if !output.stderr.is_empty() {
            output.stderr.trim()
        } else {
            output.stdout.trim()
        };
        eprintln!("{} malfunctioned: {}", selected_hook_id, detail);
        return CommandVerdict {
            blocked: false,
            reason: None,
        };
    }
    let detail = if !output.stderr.trim().is_empty() {
        output.stderr.trim().to_string()
    } else if !output.stdout.trim().is_empty() {
        output.stdout.trim().to_string()
    } else {
        format!("{} exited {}", selected_hook_id, code)
    };
    CommandVerdict {
        blocked: true,
        reason: Some(detail),
    }
}

/// Commands for one OMP tool event, deduplicated by `hook.command` — like the
/// `Map` in the JS `tool_call` handler: the LAST hook with a given command
/// wins, but keeps the position of its first insertion. Returns full matches
/// so callers keep access to the event entry (`entry.blocking`).
pub fn commands_for_event<'a>(
    registry: &'a Value,
    hook_id: &str,
    event_name: &str,
) -> Vec<crate::registry::HookMatch<'a>> {
    let mut order: Vec<String> = Vec::new();
    let mut by_command: std::collections::HashMap<String, usize> = std::collections::HashMap::new();
    let mut matches: Vec<Option<crate::registry::HookMatch<'a>>> = Vec::new();
    for m in matching_hooks(registry, hook_id) {
        if m.event != event_name {
            continue;
        }
        let command = js_string_or_empty(m.hook.get("command"));
        match by_command.get(&command) {
            Some(&index) => matches[index] = Some(m),
            None => {
                by_command.insert(command.clone(), matches.len());
                order.push(command);
                matches.push(Some(m));
            }
        }
    }
    let mut out = Vec::new();
    for command in &order {
        if let Some(&index) = by_command.get(command) {
            if let Some(m) = matches[index].take() {
                out.push(m);
            }
        }
    }
    out
}
