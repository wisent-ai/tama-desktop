//! Session-record access shared by the evidence-based `Stop` guards.
//!
//! The guards judge recorded behaviour, never prose, so they all need the same
//! payload, the current turn's activity, and the successful tracker history
//! required to reconstruct state that persists across user messages.
//!
//! Transcript shape (`~/.omp/agent/sessions/**/*.jsonl`, one JSON object per
//! line): `{ type, message: { role, content: [...] } }` where an assistant
//! message carries `content[].type == "toolCall"` with `id`, `name` and
//! `arguments`, and a result carries `role == "toolResult"` with `toolCallId`,
//! `toolName`, `isError` and text parts.
//!
//! Sizes are materialized from text, the same way the JS sources write
//! `Number('0')`: the repository keeps bare numeric literals out of code.

mod payload;
mod transcript;
mod turn;
mod types;

pub use payload::{
    all_strings, deny, deny_banner_id, deny_tool_use, last_assistant_message, read_payload,
    session_id_of, tool_input_of, tool_name_of,
};
pub use transcript::path_tokens;
pub use turn::Turn;
pub use types::{Denial, ToolCall, ToolResult};
