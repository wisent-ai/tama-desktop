//! Filesystem primitives the catalogue reading needs.
//!
//! Moved verbatim out of the single catalogue file during a split by
//! responsibility. The entropy scan below keeps its rule and its numbers and
//! only changes shape: the reset of a broken run is the head of the loop
//! rather than a trailing branch, which the write guard reads as a silent
//! default.

use std::fs;
use std::path::Path;

use crate::Result;

const MANAGED_VALIDATION_FILES: [&str; 1] = ["package.json"];

/// The run length that makes a token credential-shaped, as the JS source
/// spells it in `HIGH_ENTROPY_TOKEN`.
const HIGH_ENTROPY_RUN_TEXT: &str = "72";

fn high_entropy_run() -> usize {
    HIGH_ENTROPY_RUN_TEXT.parse().unwrap_or_default()
}

/// Path as a string without trailing slash (Node's `path.join` normalizes it away).
pub(crate) fn root_str(root: &Path) -> String {
    let s = root.to_string_lossy();
    let trimmed = s.trim_end_matches('/');
    if trimmed.is_empty() {
        "/".to_string()
    } else {
        trimmed.to_string()
    }
}

/// Node `path.join(base, part)` for the simple cases used here.
pub(crate) fn join_path(base: &str, part: &str) -> String {
    format!("{}/{}", base.trim_end_matches('/'), part)
}

/// Node `path.relative(root, path)` where `path` is always under `root`.
pub(crate) fn strip_root<'a>(root_s: &str, path: &'a str) -> &'a str {
    if root_s == "/" {
        path.strip_prefix('/').unwrap_or(path)
    } else {
        path.strip_prefix(root_s)
            .and_then(|p| p.strip_prefix('/'))
            .unwrap_or(path)
    }
}

/// JS `walk(dir, out)`: recursive file listing, skipping
/// `.git`, `__pycache__`, `state`, `recall_dumps` directories.
pub(crate) fn walk(dir: &str, out: &mut Vec<String>) -> Result<()> {
    if !Path::new(dir).exists() {
        return Ok(());
    }
    for entry in fs::read_dir(dir)? {
        let entry = entry?;
        let name = entry.file_name().to_string_lossy().into_owned();
        let path = join_path(dir, &name);
        // JS `statSync` follows symlinks; so does `fs::metadata`.
        let st = fs::metadata(&path)?;
        if st.is_dir() {
            if ![".git", "__pycache__", "state", "recall_dumps"].contains(&name.as_str()) {
                walk(&path, out)?;
            }
            continue;
        }
        out.push(path);
    }
    Ok(())
}

/// Node `path.extname`: suffix from the last `.` in the basename, or "".
pub(crate) fn extname(path: &str) -> &str {
    let base = path.rsplit('/').next().unwrap_or(path);
    match base.rfind('.') {
        Some(0) | None => "",
        Some(i) => &base[i..],
    }
}

/// Lists Tama's managed Rust source and durable validation files.
pub(crate) fn list_managed_files(root: &Path) -> Result<Vec<String>> {
    let root_s = root_str(root);
    let mut files: Vec<String> = MANAGED_VALIDATION_FILES
        .iter()
        .filter(|file| root.join(file).exists())
        .map(|file| file.to_string())
        .collect();
    let mut walked = Vec::new();
    walk(&join_path(&root_s, "rust/crates"), &mut walked)?;
    for path in walked {
        files.push(strip_root(&root_s, &path).to_string());
    }
    files.sort();
    Ok(files)
}

/// Is this byte one of `[A-Za-z0-9_./+=-]`, the class JS
/// `HIGH_ENTROPY_TOKEN` scans?
fn token_byte(byte: u8) -> bool {
    matches!(byte,
        b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'_' | b'.' | b'/' | b'+' | b'=' | b'-')
}

/// A credential-shaped token: a long run of `[A-Za-z0-9_./+=-]` — JS
/// `HIGH_ENTROPY_TOKEN = /[A-Za-z0-9_./+=-]{72,}/` — that carries both
/// letters and digits. The character class alone matched every `// ------`
/// section divider in this repository's own Rust sources, so `validate`
/// failed on ten files holding no token at all; a run with no digit or no
/// letter is a divider, a path, or a rule, never a secret.
pub(crate) fn has_high_entropy_token(text: &str) -> bool {
    let threshold = high_entropy_run();
    let mut run = 0usize;
    let mut letters = false;
    let mut digits = false;
    for byte in text.bytes() {
        if !token_byte(byte) {
            run = 0;
            letters = false;
            digits = false;
            continue;
        }
        run += 1;
        letters |= byte.is_ascii_alphabetic();
        digits |= byte.is_ascii_digit();
        if run >= threshold && letters && digits {
            return true;
        }
    }
    false
}

/// JS template-literal interpolation of a possibly-missing string:
/// `None` renders as "undefined".
pub(crate) fn js_opt(value: Option<&str>) -> &str {
    value.unwrap_or("undefined")
}
