//! Rendering a violation scan: the usage text, one repository's detail, and
//! the aggregate summary.
//!
//! Split out of `scan_repos.rs` on the seam between driving the scan and
//! printing it, because the operator's rule keeps every source file at three
//! hundred lines or fewer and that file had grown past it — which the write
//! guard then answers by refusing every edit to it, in both directions, so
//! the file could not be brought back under the limit by editing at all.

use crate::find_violations::ScanReport;
use crate::repo_discovery::Problem;

pub fn print_scan_usage() {
    eprintln!(
        "tama find-violations (--repo <path> | --tree <dir> | --owner <gh-user-or-org>) [...] [--json] [--summary] [--size-only] [--hook <path>] [--clone-dir <dir>]

Scan repositories for existing violations of the rules the shared write guards
enforce: the forbidden content patterns, time-limit and retry bans,
provider/key bans and unsubstantiated constants of the pre-write hook, the
max 5 files per folder rule, and the max 300 lines per file rule, which lives
in its own hook and is replayed in a second pass over the same files. That
line rule does not apply to structured data (.json, .jsonl, .ndjson, .lock,
.csv, .tsv) or to manuscript sources (.tex, .bib, .sty, .bst, .cls): a registry
is read whole by its loader and a chapter is not a module, so neither pass
reports one over the limit. The scan
replays the real hooks against every enumerated file and never modifies
scanned repositories. It reports the first violation per file per pass;
re-scan after fixes to surface the rest.

Targets (repeatable, combinable):
  --repo <path>    one repository or directory
  --tree <dir>     discover every Git checkout under a directory tree
                   (named --tree because cli.mjs reserves --root already)
  --owner <login>  every GitHub repo of a user or org (gh CLI); missing
                   checkouts are shallow-cloned into --clone-dir
  --me             the gh-authenticated user plus every org they belong to

Modes:
  --size-only      skip the hook replay and apply the two size rules in
                   process: max 300 lines per file, max 5 files per folder.
                   Same enumeration, same skips and the same sentences as the
                   replay, but no shell per file, so a whole tree finishes in
                   minutes instead of hours. Use it to pick what to fix, then
                   re-scan that repository without the flag for the content
                   rules the hooks own.
  --summary        one row per repository — files over the line limit, folders
                   over the file limit, path — worst first, instead of every
                   hit in every repository.

Command-gating hooks (browser, CUA, keychain, Git bypass bans) gate shell
commands, not file content, so they stay out of scope."
    );
}

pub fn print_scan_report(report: &ScanReport) {
    println!("find-violations: {}", report.repo);
    println!(
        "enumeration: {}; scanned: {}; skipped: {}; errors: {}",
        report.mode,
        report.scanned_files,
        report.skipped_files.len(),
        report.errors.len()
    );
    for item in &report.skipped_files {
        println!("  skip {} ({})", item.path, item.reason);
    }
    if report.violations.is_empty() {
        println!("no violations found");
    } else {
        // Group by rule, preserving first-occurrence order like a JS Map.
        let mut groups: Vec<(&str, Vec<&crate::find_violations::Violation>)> = Vec::new();
        for violation in &report.violations {
            match groups.iter_mut().find(|(rule, _)| *rule == violation.rule) {
                Some((_, list)) => list.push(violation),
                None => groups.push((violation.rule.as_str(), vec![violation])),
            }
        }
        for (rule, list) in &groups {
            println!("\n{} — {} hit(s)", rule, list.len());
            for violation in list {
                println!("  {}\n    {}", violation.path, violation.message);
            }
        }
        println!("\nviolations: {}", report.violations.len());
    }
    for error in &report.errors {
        eprintln!("ERROR {}: {}", error.path, error.message);
    }
}

pub fn problem_label(problem: &Problem) -> String {
    match &problem.repo {
        Some(repo) if !repo.is_empty() => format!("{} {}", problem.owner, repo),
        _ => problem.owner.clone(),
    }
}

pub fn print_aggregate(reports: &[ScanReport], problems: &[Problem]) {
    for report in reports {
        print_scan_report(report);
        println!();
    }
    let mut total = 0usize;
    for report in reports {
        total += report.violations.len();
    }
    println!("== summary ==");
    for report in reports {
        println!(
            "{} — violations: {}, errors: {}",
            report.repo,
            report.violations.len(),
            report.errors.len()
        );
    }
    for problem in problems {
        println!("PROBLEM {}: {}", problem_label(problem), problem.error);
    }
    println!(
        "repositories: {}, violations: {}, problems: {}",
        reports.len(),
        total,
        problems.len()
    );
}

/// One row per repository that still breaks a rule, worst first: how many
/// files are over the line limit, how many folders are over the file limit,
/// and where it is. `print_aggregate` answers "what is wrong in this
/// repository"; this answers "which repositories do I have to fix", which is
/// unreadable when 229 checkouts each print every hit first.
pub fn print_summary(reports: &[ScanReport], problems: &[Problem]) {
    let mut rows: Vec<(usize, usize, &str)> = Vec::new();
    for report in reports {
        let folders = report
            .violations
            .iter()
            .filter(|violation| violation.rule.starts_with("Folder has"))
            .count();
        let files = report.violations.len() - folders;
        if files + folders == 0 {
            continue;
        }
        rows.push((files, folders, report.repo.as_str()));
    }
    rows.sort_by(|left, right| {
        (right.0 + right.1)
            .cmp(&(left.0 + left.1))
            .then_with(|| crate::locale_compare(left.2, right.2))
    });
    println!("files\tfolders\trepository");
    for (files, folders, repo) in &rows {
        println!("{files}\t{folders}\t{repo}");
    }
    for problem in problems {
        println!("PROBLEM {}: {}", problem_label(problem), problem.error);
    }
    println!(
        "repositories: {} scanned, {} with violations; files over limit: {}; crowded folders: {}",
        reports.len(),
        rows.len(),
        rows.iter().map(|row| row.0).sum::<usize>(),
        rows.iter().map(|row| row.1).sum::<usize>()
    );
}
