//! Path helpers and the shared result type for hook command execution.

use std::path::PathBuf;
use std::process::Command;

pub(crate) mod command;

pub(crate) use command::run_command;

/// `os.homedir()`: `$HOME` on POSIX, with a passwd-database lookup through
/// the shell when `$HOME` is unset; `USERPROFILE` / `HOMEDRIVE`+`HOMEPATH`
/// on Windows.
pub(crate) fn home_dir() -> PathBuf {
    #[cfg(unix)]
    {
        if let Some(h) = std::env::var_os("HOME").filter(|v| !v.is_empty()) {
            return PathBuf::from(h);
        }
        if let Ok(out) = Command::new("sh").args(["-c", "printf %s ~"]).output() {
            if out.status.success() && !out.stdout.is_empty() {
                use std::os::unix::ffi::OsStringExt;
                return PathBuf::from(std::ffi::OsString::from_vec(out.stdout));
            }
        }
        PathBuf::from("/")
    }
    #[cfg(windows)]
    {
        if let Some(p) = std::env::var_os("USERPROFILE").filter(|v| !v.is_empty()) {
            return PathBuf::from(p);
        }
        let drive = std::env::var_os("HOMEDRIVE").unwrap_or_default();
        let path = std::env::var_os("HOMEPATH").unwrap_or_default();
        if !drive.is_empty() || !path.is_empty() {
            let mut p = drive;
            p.push(&path);
            return p;
        }
        PathBuf::from(".")
    }
}

/// Port of `expandHome`: `~` before `/` or end-of-string becomes the home
/// directory, and every `$HOME` is replaced.
pub(crate) fn expand_home(command: &str) -> String {
    let home = home_dir().to_string_lossy().into_owned();
    let mut out = String::with_capacity(command.len());
    let mut chars = command.chars().peekable();
    while let Some(c) = chars.next() {
        if c == '~' && matches!(chars.peek(), None | Some('/')) {
            out.push_str(&home);
        } else {
            out.push(c);
        }
    }
    out.replace("$HOME", &home)
}

/// Result of one hook command execution, mirroring the JS `runCommand`
/// resolution value.
#[derive(Debug, Default)]
pub(crate) struct RunResult {
    pub(crate) code: Option<i32>,
    pub(crate) timed_out: bool,
    pub(crate) stdout: String,
    pub(crate) stderr: String,
    pub(crate) spawn_error: bool,
}

/// Node-style spawn error message (`spawn <program> ENOENT`).
pub(crate) fn spawn_error_message(program: &str, error: &std::io::Error) -> String {
    if error.kind() == std::io::ErrorKind::NotFound {
        format!("spawn {} ENOENT", program)
    } else {
        format!("spawn {} {}", program, error)
    }
}
