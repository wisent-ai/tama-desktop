//! Port of `src/tests/live-runtime/support/runtime-test-support.mjs`
//! (plus the process-spawning primitives it re-exports from Node).

use std::io::Read;
use std::io::Write;
use std::path::{Component, Path, PathBuf};
use std::process::{Child, Command, Stdio};
use std::time::{Duration, Instant};

use crate::json::{self, Json};

/// JS `realRunner` — absolute device path, verbatim from the JS source.
pub const REAL_RUNNER: &str = "/Users/lukaszbartoszcze/.shared-hooks/run-hook.mjs";

/// JS `root` = repo root. The Rust port resolves `TAMA_ROOT` first (repo
/// convention shared with the other crates), then falls back to the crate
/// location (`rust/crates/tama-testkit` -> three levels up).
pub fn root() -> PathBuf {
    if let Some(root) = std::env::var_os("TAMA_ROOT") {
        return PathBuf::from(root);
    }
    normalize_path(
        Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../..")
            .as_path(),
    )
}

/// JS `modelRouterRoot = join(dirname(root), 'model-router')`.
pub fn model_router_root() -> PathBuf {
    root()
        .parent()
        .unwrap_or(Path::new("/"))
        .join("model-router")
}

/// Lexical normalization of `.` / `..` (like Node `path.resolve` on an
/// already-absolute path).
pub fn normalize_path(path: &Path) -> PathBuf {
    let mut out = PathBuf::new();
    for component in path.components() {
        match component {
            Component::CurDir => {}
            Component::ParentDir => {
                out.pop();
            }
            other => out.push(other.as_os_str()),
        }
    }
    out
}

/// JS `keepArtifacts`.
pub fn keep_artifacts() -> bool {
    std::env::var("KEEP_LIVE_TEST_ARTIFACTS").as_deref() == Ok("1")
}

/// JS `codexRouterCoverage`.
pub fn codex_router_coverage() -> bool {
    std::env::var("CODEX_LIVE_RUNTIME_VIA_MODEL_ROUTER").as_deref() == Ok("1")
}

/// JS `codexFullLocalCoverage`.
pub fn codex_full_local_coverage() -> bool {
    std::env::var("MODEL_ROUTER_CODEX_COVERAGE_HOOKS").as_deref() == Ok("full-local")
}

/// JS `claudeLiveModel` (`process.env.CLAUDE_LIVE_MODEL || 'claude-opus-4-8'`).
pub fn claude_live_model() -> String {
    std::env::var("CLAUDE_LIVE_MODEL")
        .ok()
        .filter(|v| !v.is_empty())
        .unwrap_or_else(|| "claude-opus-4-8".to_string())
}

/// JS `scenarioFilter` (`process.env.LIVE_SCENARIO_FILTER || ''`).
pub fn scenario_filter() -> String {
    std::env::var("LIVE_SCENARIO_FILTER").unwrap_or_default()
}

/// JS `liveRuntimeTmpRoot`.
pub fn live_runtime_tmp_root() -> PathBuf {
    root().join(".live-runtime-tmp")
}

/// Node `os.tmpdir()`.
pub fn tmpdir() -> PathBuf {
    std::env::temp_dir()
}

/// Node `path.dirname` (POSIX).
pub fn dirname(path: &str) -> String {
    let trimmed = path.trim_end_matches('/');
    if trimmed.is_empty() {
        return "/".to_string();
    }
    match trimmed.rfind('/') {
        None => ".".to_string(),
        Some(0) => "/".to_string(),
        Some(index) => trimmed[..index].to_string(),
    }
}

/// JS `makeLiveRuntimeTemp(prefix)`.
pub fn make_live_runtime_temp(prefix: &str) -> Result<PathBuf, String> {
    let root_dir = live_runtime_tmp_root();
    std::fs::create_dir_all(&root_dir).map_err(|e| io_error_message("mkdir", &root_dir, &e))?;
    mkdtemp(&root_dir.join(prefix))
}

/// Node `mkdtempSync(prefix)`: appends 6 random characters.
pub fn mkdtemp(prefix: &Path) -> Result<PathBuf, String> {
    const CHARSET: &[u8] = b"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    for _ in 0..100 {
        let random = random_bytes(6);
        let suffix: String = random
            .iter()
            .map(|b| CHARSET[(*b as usize) % 62] as char)
            .collect();
        let candidate = PathBuf::from(format!("{}{suffix}", prefix.display()));
        match std::fs::create_dir(&candidate) {
            Ok(()) => return Ok(candidate),
            Err(e) if e.kind() == std::io::ErrorKind::AlreadyExists => continue,
            Err(e) => return Err(io_error_message("mkdtemp", &candidate, &e)),
        }
    }
    Err(format!(
        "mkdtemp: could not create a unique directory for {}",
        prefix.display()
    ))
}

fn random_bytes(n: usize) -> Vec<u8> {
    let mut buf = vec![0u8; n];
    if std::fs::File::open("/dev/urandom")
        .and_then(|mut f| f.read_exact(&mut buf))
        .is_err()
    {
        let nanos = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_nanos())
            .unwrap_or(0);
        for (i, b) in buf.iter_mut().enumerate() {
            *b = (nanos >> ((i % 16) * 8)) as u8 ^ (std::process::id() as u8);
        }
    }
    buf
}

/// Node-style I/O error message for `readFileSync`/`writeFileSync` failures.
pub fn io_error_message(op: &str, path: &Path, error: &std::io::Error) -> String {
    if error.kind() == std::io::ErrorKind::NotFound {
        let verb = if op == "mkdir" || op == "mkdtemp" {
            op
        } else {
            "open"
        };
        format!(
            "ENOENT: no such file or directory, {verb} '{}'",
            path.display()
        )
    } else {
        format!("{error}")
    }
}

/// JS `read(path)` = `readFileSync(path, 'utf8')` (throws on error).
pub fn read(path: &Path) -> Result<String, String> {
    std::fs::read_to_string(path).map_err(|e| io_error_message("open", path, &e))
}

/// JS `writeFileSync(path, content)` (throws on error).
pub fn write_file(path: &Path, content: &str) -> Result<(), String> {
    std::fs::write(path, content).map_err(|e| io_error_message("open", path, &e))
}

pub fn exists(path: &Path) -> bool {
    path.exists()
}

/// JS `rmSync(path, { recursive: true, force: true })` — errors ignored.
pub fn rm_force(path: &Path) {
    if path.is_dir() {
        let _ = std::fs::remove_dir_all(path);
    } else {
        let _ = std::fs::remove_file(path);
    }
}

// ---------------------------------------------------------------------------
// spawnSync equivalent
// ---------------------------------------------------------------------------

/// Result of a JS `spawnSync(..., { encoding: 'utf8' })` call.
#[derive(Debug, Clone)]
pub struct RunResult {
    /// Exit code (`null` when the child was signaled or failed to spawn).
    pub status: Option<i32>,
    /// Signal name such as `SIGTERM` (`null` on a normal exit).
    pub signal: Option<String>,
    pub stdout: String,
    pub stderr: String,
    /// `result.error?.code` (`ENOENT`, `ETIMEDOUT`, ...).
    pub error_code: Option<String>,
}

/// Options for [`run`]. `env_overrides` reproduces `{...process.env, ...}`
/// (Command inherits the parent environment; overrides replace single keys).
#[derive(Default)]
pub struct RunOpts {
    pub cwd: Option<PathBuf>,
    pub env_overrides: Vec<(String, String)>,
    pub timeout_ms: Option<u64>,
    pub max_buffer: Option<usize>,
    pub input: Option<String>,
}

extern "C" {
    fn kill(pid: i32, sig: i32) -> i32;
}

const SIGTERM: i32 = 15;
const SIGKILL: i32 = 9;

fn send_signal(pid: u32, sig: i32) {
    unsafe {
        kill(pid as i32, sig);
    }
}

fn signal_name(number: i32) -> String {
    // macOS signal numbers (the platform this harness runs on).
    match number {
        1 => "SIGHUP",
        2 => "SIGINT",
        3 => "SIGQUIT",
        4 => "SIGILL",
        5 => "SIGTRAP",
        6 => "SIGABRT",
        7 => "SIGEMT",
        8 => "SIGFPE",
        9 => "SIGKILL",
        10 => "SIGBUS",
        11 => "SIGSEGV",
        12 => "SIGSYS",
        13 => "SIGPIPE",
        14 => "SIGALRM",
        15 => "SIGTERM",
        16 => "SIGURG",
        30 => "SIGUSR1",
        31 => "SIGUSR2",
        other => return format!("SIG{other}"),
    }
    .to_string()
}

/// JS `run(command, args, options)` = `spawnSync` with `encoding: 'utf8'`,
/// `timeout`, `maxBuffer`, `cwd`, `env` and `input` support.
pub fn run(command: &str, args: &[String], opts: &RunOpts) -> RunResult {
    let mut cmd = Command::new(command);
    cmd.args(args);
    if let Some(cwd) = &opts.cwd {
        cmd.current_dir(cwd);
    }
    for (key, value) in &opts.env_overrides {
        cmd.env(key, value);
    }
    cmd.stdin(if opts.input.is_some() {
        Stdio::piped()
    } else {
        Stdio::null()
    });
    cmd.stdout(Stdio::piped());
    cmd.stderr(Stdio::piped());

    let mut child = match cmd.spawn() {
        Ok(child) => child,
        Err(error) => {
            let code = match error.kind() {
                std::io::ErrorKind::NotFound => "ENOENT",
                std::io::ErrorKind::PermissionDenied => "EACCES",
                _ => "UNKNOWN",
            };
            return RunResult {
                status: None,
                signal: None,
                stdout: String::new(),
                stderr: String::new(),
                error_code: Some(code.to_string()),
            };
        }
    };

    let mut stdin = child.stdin.take();
    let input = opts.input.clone();
    let stdin_thread = std::thread::spawn(move || {
        if let (Some(mut stdin), Some(input)) = (stdin.take(), input) {
            let _ = stdin.write_all(input.as_bytes());
        }
    });

    let mut stdout_pipe = child.stdout.take();
    let stdout_thread = std::thread::spawn(move || {
        let mut buf = Vec::new();
        if let Some(mut pipe) = stdout_pipe.take() {
            let _ = pipe.read_to_end(&mut buf);
        }
        buf
    });
    let mut stderr_pipe = child.stderr.take();
    let stderr_thread = std::thread::spawn(move || {
        let mut buf = Vec::new();
        if let Some(mut pipe) = stderr_pipe.take() {
            let _ = pipe.read_to_end(&mut buf);
        }
        buf
    });

    let deadline = opts
        .timeout_ms
        .map(|ms| Instant::now() + Duration::from_millis(ms));
    let mut timed_out = false;
    let status = loop {
        match child.try_wait() {
            Ok(Some(status)) => break Some(status),
            Ok(None) => {
                if let Some(deadline) = deadline {
                    if Instant::now() >= deadline {
                        // Node kills the child with SIGTERM on timeout.
                        timed_out = true;
                        send_signal(child.id(), SIGTERM);
                        break child.wait().ok();
                    }
                }
                std::thread::sleep(Duration::from_millis(10));
            }
            Err(_) => break None,
        }
    };
    let _ = stdin_thread.join();
    let stdout_bytes = stdout_thread.join().unwrap_or_default();
    let stderr_bytes = stderr_thread.join().unwrap_or_default();

    // maxBuffer: Node kills the child once the buffer exceeds the limit; the
    // port reads fully and truncates (observably identical for outputs that
    // stay under the limit, which is the expected case here).
    let truncate = |mut buf: Vec<u8>| -> String {
        if let Some(max) = opts.max_buffer {
            if buf.len() > max {
                buf.truncate(max);
            }
        }
        String::from_utf8_lossy(&buf).into_owned()
    };

    use std::os::unix::process::ExitStatusExt;
    let (status_code, signal) = match status {
        Some(exit) => (exit.code(), exit.signal().map(signal_name)),
        None => (None, None),
    };
    RunResult {
        status: status_code,
        signal,
        stdout: truncate(stdout_bytes),
        stderr: truncate(stderr_bytes),
        error_code: if timed_out {
            Some("ETIMEDOUT".to_string())
        } else {
            None
        },
    }
}

/// Convenience wrapper matching `run(cmd, args, { cwd })` call sites.
pub fn run_in(cmd: &str, args: &[&str], cwd: &Path) -> RunResult {
    let owned: Vec<String> = args.iter().map(|a| a.to_string()).collect();
    run(
        cmd,
        &owned,
        &RunOpts {
            cwd: Some(cwd.to_path_buf()),
            ..RunOpts::default()
        },
    )
}

/// `spawn(command, args, { stdio: 'ignore', cwd, env })` — detached child for
/// the editor watcher. I/O is ignored like `stdio: 'ignore'`.
pub fn spawn_ignored(
    command: &str,
    args: &[String],
    cwd: &Path,
    env_overrides: &[(String, String)],
) -> Result<Child, String> {
    let mut cmd = Command::new(command);
    cmd.args(args)
        .current_dir(cwd)
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null());
    for (key, value) in env_overrides {
        cmd.env(key, value);
    }
    cmd.spawn()
        .map_err(|e| format!("failed to spawn {command}: {e}"))
}

/// `child.kill('SIGTERM')` followed by reaping (JS does not reap explicitly;
/// the port waits briefly so no zombie is left behind).
pub fn kill_sigterm(child: &mut Child) {
    send_signal(child.id(), SIGTERM);
    let deadline = Instant::now() + Duration::from_millis(2_000);
    loop {
        match child.try_wait() {
            Ok(Some(_)) => return,
            Ok(None) => {
                if Instant::now() >= deadline {
                    send_signal(child.id(), SIGKILL);
                    let _ = child.wait();
                    return;
                }
                std::thread::sleep(Duration::from_millis(20));
            }
            Err(_) => return,
        }
    }
}

/// `process.execPath` in the JS harness is the Node binary; resolve `node`
/// from `PATH` so spawned commands log an absolute path like the JS version.
pub fn node_exec_path() -> String {
    if let Some(path_var) = std::env::var_os("PATH") {
        for dir in std::env::split_paths(&path_var) {
            let candidate = dir.join("node");
            if candidate.is_file() {
                return candidate.to_string_lossy().into_owned();
            }
        }
    }
    "node".to_string()
}

// ---------------------------------------------------------------------------
// recorder / payload helpers
// ---------------------------------------------------------------------------

/// JS `makeRecorder(tmp)`: writes `record-run-hook.mjs` (verbatim content,
/// mode 0755) and returns `{ payloadLog, recorder }`.
pub fn make_recorder(tmp: &Path) -> Result<(PathBuf, PathBuf), String> {
    let payload_log = tmp.join("runtime-payloads.jsonl");
    let recorder = tmp.join("record-run-hook.mjs");
    let content = format!(
        "#!/usr/bin/env node\n\
         import {{ spawnSync }} from 'node:child_process';\n\
         import {{ appendFileSync, readFileSync }} from 'node:fs';\n\
         const input = readFileSync(0, 'utf8');\n\
         const parsedInput = JSON.parse(input || '{{}}');\n\
         const child = spawnSync(process.execPath, [{real_runner}, ...process.argv.slice(2)], {{ input, encoding: 'utf8', stdio: ['pipe', 'pipe', 'pipe'], env: process.env }});\n\
         let parsedStdout = null;\n\
         try {{ parsedStdout = JSON.parse(child.stdout || '{{}}'); }} catch {{}}\n\
         appendFileSync({payload_log}, JSON.stringify({{ argv: process.argv.slice(2), input: parsedInput, runner: {{ status: child.status, signal: child.signal, stdout: child.stdout, stderr: child.stderr, json: parsedStdout }} }}) + '\\n');\n\
         if (child.stdout) process.stdout.write(child.stdout);\n\
         if (child.stderr) process.stderr.write(child.stderr);\n\
         process.exit(child.status ?? 1);\n",
        real_runner = Json::str(REAL_RUNNER).to_compact(),
        payload_log = Json::str(payload_log.to_string_lossy().into_owned()).to_compact(),
    );
    write_file(&recorder, &content)?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        std::fs::set_permissions(&recorder, std::fs::Permissions::from_mode(0o755))
            .map_err(|e| io_error_message("chmod", &recorder, &e))?;
    }
    Ok((payload_log, recorder))
}

/// JS `readPayloads(payloadLog)`: one bad line (or a read failure) discards
/// everything (the whole body sits inside a single `try`).
pub fn read_payloads(payload_log: &Path) -> Vec<Json> {
    let parse_all = || -> Result<Vec<Json>, String> {
        let text = read(payload_log)?;
        text.trim()
            .split('\n')
            .filter(|line| !line.is_empty())
            .map(json::parse)
            .collect()
    };
    parse_all().unwrap_or_default()
}

/// JS `parseJsonLines(path)`: per-line tolerant parse (bad lines dropped).
pub fn parse_json_lines(path: &Path) -> Vec<Json> {
    if !path.exists() {
        return Vec::new();
    }
    let text = match std::fs::read_to_string(path) {
        Ok(text) => text,
        Err(_) => return Vec::new(),
    };
    text.split('\n')
        .filter(|line| !line.is_empty())
        .filter_map(|line| json::parse(line).ok())
        .collect()
}

/// JS `parseJsonLinesFromText(text)` from `codex-replay.mjs`.
pub fn parse_json_lines_from_text(text: &str) -> Vec<Json> {
    text.split('\n')
        .filter(|line| !line.is_empty())
        .filter_map(|line| json::parse(line).ok())
        .collect()
}

/// JS `unique(values)`: dedup preserving first-seen order, falsy dropped.
pub fn unique(values: Vec<String>) -> Vec<String> {
    let mut seen: Vec<String> = Vec::new();
    for value in values {
        if !value.is_empty() && !seen.contains(&value) {
            seen.push(value);
        }
    }
    seen
}

/// JS `tail(text, length = 1000)` = `String(text || '').slice(-length)`.
pub fn tail(text: &str) -> String {
    tail_n(text, 1000)
}

pub fn tail_n(text: &str, length: usize) -> String {
    let chars: Vec<char> = text.chars().collect();
    chars
        .iter()
        .skip(chars.len().saturating_sub(length))
        .collect()
}

/// JS `ompClaimedEvent(entry)`.
pub fn omp_claimed_event(entry: &Json) -> String {
    let runtime_event = json::js_string_opt(entry.get("argv").and_then(|argv| argv.at(0)));
    if runtime_event == "pre_tool_use:edit"
        && entry
            .get("input")
            .and_then(|input| input.get("tool_name"))
            .and_then(Json::as_str)
            == Some("Write")
    {
        return "pre_tool_use:write".to_string();
    }
    runtime_event
}

/// JS `coverageKey(runtime, event, hookId, runtimeEvent = event)` where any
/// argument may be JS `undefined` (interpolated as "undefined").
pub fn coverage_key_opt(runtime: &str, event: &str, hook_id: &str, runtime_event: &str) -> String {
    if runtime_event == event {
        format!("{runtime}:{event}:{hook_id}")
    } else {
        format!("{runtime}:{event}:via:{runtime_event}:{hook_id}")
    }
}

/// JS `coveredKeysFromOmpPayloads(payloads)`.
pub fn covered_keys_from_omp_payloads(payloads: &[Json]) -> Vec<String> {
    let mut keys = Vec::new();
    for entry in payloads {
        let runtime_event = json::js_string_opt(entry.get("argv").and_then(|argv| argv.at(0)));
        let event = omp_claimed_event(entry);
        let results = entry
            .get("runner")
            .and_then(|r| r.get("json"))
            .and_then(|j| j.get("results"))
            .and_then(Json::as_array)
            .unwrap_or(&[]);
        for result in results {
            if let Some(id) = result
                .get("id")
                .and_then(Json::as_str)
                .filter(|s| !s.is_empty())
            {
                keys.push(coverage_key_opt("omp", &event, id, &runtime_event));
            } else {
                // `result.id ? ... : null` — null is dropped by `unique`.
                keys.push(String::new());
            }
        }
    }
    unique(keys)
}

/// JS `coveredKeysFromEditorOutcomes(parsed, runtime)`.
pub fn covered_keys_from_editor_outcomes(parsed: Option<&Json>, runtime: &str) -> Vec<String> {
    let mut keys = Vec::new();
    let outcomes = parsed
        .and_then(|p| p.get("outcomes"))
        .and_then(Json::as_array)
        .unwrap_or(&[]);
    for outcome in outcomes {
        let results = outcome
            .get("results")
            .and_then(Json::as_array)
            .unwrap_or(&[]);
        for result in results {
            let hook_results = result
                .get("parsed")
                .and_then(|p| p.get("results"))
                .and_then(Json::as_array)
                .unwrap_or(&[]);
            for hook_result in hook_results {
                match hook_result
                    .get("id")
                    .and_then(Json::as_str)
                    .filter(|s| !s.is_empty())
                {
                    Some(id) => {
                        let event = json::js_string_opt(result.get("event"));
                        keys.push(coverage_key_opt(runtime, &event, id, &event));
                    }
                    None => keys.push(String::new()),
                }
            }
        }
    }
    unique(keys)
}

/// JS `coveredKeysFromEditorWatchLog(logPath, runtime)`.
pub fn covered_keys_from_editor_watch_log(log_path: &Path, runtime: &str) -> Vec<String> {
    let mut keys = Vec::new();
    for line in parse_json_lines(log_path) {
        if line.get("message").and_then(Json::as_str) != Some("guard-result") {
            continue;
        }
        let stdout = line
            .get("data")
            .and_then(|d| d.get("stdout"))
            .and_then(Json::as_str)
            .unwrap_or("{}");
        // `try { parsed = JSON.parse(...) } catch {}` — stays null on error.
        let parsed = json::parse(stdout).ok();
        keys.extend(covered_keys_from_editor_outcomes(parsed.as_ref(), runtime));
    }
    unique(keys)
}

/// JS `attempt(name, fn)`: errors become `{ ok: false, name, error }`.
pub fn attempt(name: &str, run_scenario: impl FnOnce() -> Result<Json, String>) -> Json {
    match run_scenario() {
        Ok(result) => result,
        Err(error) => Json::obj(vec![
            ("ok".to_string(), Json::Bool(false)),
            ("name".to_string(), Json::str(name)),
            ("error".to_string(), Json::str(error)),
        ]),
    }
}
