//! Replay all file rules once per file; count each crowded folder once.
use super::*;
pub fn folder_violations(
    repo: &str,
    files: &[String],
    ignore_entries: &[String],
) -> Vec<Violation> {
    let mut counts: std::collections::HashMap<String, u64> = std::collections::HashMap::new();
    for path in files {
        if is_system_path(path) {
            continue;
        }
        if is_vendor_path(path) {
            continue;
        }
        if is_ignored(
            &relative_path(Path::new(repo), Path::new(path)),
            ignore_entries,
        ) {
            continue;
        }
        let info = match std::fs::metadata(path) {
            Ok(info) => info,
            Err(_) => continue,
        };
        if !info.is_file() {
            continue;
        }
        let dir = Path::new(path)
            .parent()
            .map(|parent| parent.to_string_lossy().into_owned())
            .unwrap_or_default();
        *counts.entry(dir).or_insert(0) += 1;
    }
    let mut violations = Vec::new();
    for (dir, count) in counts {
        if count <= FOLDER_FILE_LIMIT {
            continue;
        }
        if FOLDER_EXEMPT_FRAGMENTS
            .iter()
            .any(|fragment| dir.contains(fragment))
        {
            continue;
        }
        let rel = relative_path(Path::new(repo), Path::new(&dir));
        // A declaration names a path, and a crowded folder's path is a
        // directory: `assets/` or `.` in the ignore file has to exclude the
        // folder itself, not only the files counted inside it.
        let declared = if rel.is_empty() { "." } else { rel.as_str() };
        let as_directory = format!("{declared}/");
        if is_ignored(declared, ignore_entries)
            || ignore_entries.iter().any(|entry| *entry == as_directory)
        {
            continue;
        }
        violations.push(Violation {
            hook: HOOK_ID.to_string(),
            rule: format!("Folder has N files (max {})", FOLDER_FILE_LIMIT),
            path: if rel.is_empty() { ".".to_string() } else { rel },
            message: format!(
                "Folder has {} files (max {}). Move files into sub-folders or consolidate.",
                count, FOLDER_FILE_LIMIT
            ),
        });
    }
    violations
}

/// Everything both passes need before they differ: which files the repository
/// owns, which of them were skipped and why, and the readable content of the
/// rest. Splitting this out is what lets `--size-only` skip the hook process
/// without inventing its own idea of what a repository file is.
struct Prelude {
    abs_repo: String,
    mode: &'static str,
    files: Vec<String>,
    ignore_entries: Vec<String>,
    skipped_files: Vec<SkippedFile>,
    pending: Vec<(String, String)>,
}

fn collect_prelude(repo: &Path) -> Prelude {
    let abs_repo = resolve_path(&[repo]).to_string_lossy().into_owned();
    let enumeration = enumerate_files(&abs_repo);
    let ignore_entries = read_ignore_file(&abs_repo);
    let mut skipped_files = Vec::new();
    let mut pending: Vec<(String, String)> = Vec::new();
    for path in &enumeration.files {
        if is_system_path(path) {
            continue;
        }
        let rel = relative_path(Path::new(&abs_repo), Path::new(path));
        if is_ignored(&rel, &ignore_entries) {
            skipped_files.push(SkippedFile {
                path: rel,
                reason: "ignored by the repository's violations-ignore".to_string(),
            });
            continue;
        }
        if is_vendor_path(path) {
            skipped_files.push(SkippedFile {
                path: rel,
                reason: "vendored or build-output dir".to_string(),
            });
            continue;
        }
        match probe_file(path) {
            Probe::Skip(reason) => skipped_files.push(SkippedFile {
                path: rel,
                reason: reason.to_string(),
            }),
            Probe::SkipOwned(reason) => skipped_files.push(SkippedFile { path: rel, reason }),
            Probe::Content(buffer) => {
                pending.push((path.clone(), String::from_utf8_lossy(&buffer).into_owned()))
            }
        }
    }
    Prelude {
        abs_repo,
        mode: enumeration.mode,
        files: enumeration.files,
        ignore_entries,
        skipped_files,
        pending,
    }
}

/// The line count `block_oversized_files.sh` reads. Command substitution in
/// the hook strips every trailing newline from the payload and `echo` puts one
/// back, so a file is worth one line plus one per newline that survives.
fn hook_line_count(content: &str) -> u64 {
    let body = content.trim_end_matches('\n');
    1 + body.matches('\n').count() as u64
}

/// The two size rules without the hook process: a file over the line limit and
/// a folder over the file limit. Same enumeration, same skips and same
/// sentences as the replay, which is what makes it usable as a pre-filter over
/// a whole machine — the replay spawns two shells per file and takes hours.
pub fn scan_repo_sizes(repo: &Path) -> ScanReport {
    let prelude = collect_prelude(repo);
    let mut violations = Vec::new();
    for (path, content) in &prelude.pending {
        if exempt_from_line_limit(path) {
            continue;
        }
        let lines = hook_line_count(content);
        if lines <= FILE_LINE_LIMIT {
            continue;
        }
        violations.push(Violation {
            hook: "block-oversized-files".to_string(),
            rule: "File would be N lines (max N). Split into smaller modules.".to_string(),
            path: relative_path(Path::new(&prelude.abs_repo), Path::new(path)),
            message: format!(
                "BLOCKED: File would be {} lines (max {}). Split into smaller modules.",
                lines, FILE_LINE_LIMIT
            ),
        });
    }
    violations.extend(folder_violations(
        &prelude.abs_repo,
        &prelude.files,
        &prelude.ignore_entries,
    ));
    violations.sort_by(|a, b| locale_compare(&a.path, &b.path));
    ScanReport {
        repo: prelude.abs_repo,
        hook: "size-rules".to_string(),
        mode: prelude.mode.to_string(),
        scanned_files: prelude.pending.len(),
        skipped_files: prelude.skipped_files,
        violations,
        errors: Vec::new(),
        via: None,
    }
}

/// Port of `scanRepo`. The JS original replays hooks through an 8-lane async
/// pool; this port runs them sequentially. Output is identical because the
/// violation list is sorted before returning (only wall-clock time differs).
pub fn scan_repo(repo: &Path, hook_path: &Path) -> ScanReport {
    let prelude = collect_prelude(repo);
    let abs_repo = prelude.abs_repo;
    let hook = hook_path.to_string_lossy().into_owned();
    let size_path = hook_path.with_file_name("block_oversized_files.sh");
    let size_hook = size_path.to_string_lossy();
    let skipped_files = prelude.skipped_files;
    let pending = prelude.pending;
    let mut violations = Vec::new();
    let mut errors = Vec::new();
    for (path, content) in &pending {
        let payload = serde_json::to_string(&HookPayload {
            tool_name: "Write",
            tool_input: ToolInput {
                file_path: path,
                content,
            },
        })
        .unwrap_or_default();
        let rel = relative_path(Path::new(&abs_repo), Path::new(path));
        for (script, id) in [
            (hook.as_str(), HOOK_ID),
            (size_hook.as_ref(), "block-oversized-files"),
        ] {
            if id == "block-oversized-files" && script == hook {
                continue;
            }
            let run = run_hook(script, &payload);
            if run.status == 2 {
                violations.push(Violation {
                    hook: id.to_string(),
                    rule: rule_key(&run.stderr),
                    path: rel.clone(),
                    message: first_line(&run.stderr),
                });
                break;
            } else if run.status != 0 {
                errors.push(ScanError {
                    path: rel.clone(),
                    message: format!(
                        "{} exited {}: {}",
                        script,
                        run.status,
                        first_line(&run.stderr)
                    ),
                });
            }
        }
    }
    violations.extend(folder_violations(
        &abs_repo,
        &prelude.files,
        &prelude.ignore_entries,
    ));
    violations.sort_by(|a, b| locale_compare(&a.path, &b.path));
    ScanReport {
        repo: abs_repo,
        hook,
        mode: prelude.mode.to_string(),
        scanned_files: pending.len(),
        skipped_files,
        violations,
        errors,
        via: None,
    }
}
