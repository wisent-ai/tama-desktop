//! Journey definition loading and validation: the onboarding walkthrough
//! definition is embedded at compile time and checked for identity and
//! structural integrity before any screen is shown.

use serde_json::Value;
use std::collections::HashSet;

use super::{FIRST_SUCCESS_FACT, JOURNEY_ID, JOURNEY_VERSION, PRODUCT_ID};

const DEFINITION: &str = include_str!("../onboarding_first_use.json");

pub(super) fn canonical_definition() -> Result<Value, String> {
    let definition: Value = serde_json::from_str(DEFINITION)
        .map_err(|error| format!("could not parse Tama onboarding definition: {error}"))?;
    if definition.get("schema_version").and_then(Value::as_u64) != Some(1)
        || definition.get("product_id").and_then(Value::as_str) != Some(PRODUCT_ID)
        || definition.get("journey_id").and_then(Value::as_str) != Some(JOURNEY_ID)
        || definition.get("journey_version").and_then(Value::as_str) != Some(JOURNEY_VERSION)
        || definition.get("first_success_fact").and_then(Value::as_str) != Some(FIRST_SUCCESS_FACT)
        || definition
            .pointer("/analytics_contract/surface")
            .and_then(Value::as_str)
            != Some("cli_first_use")
    {
        return Err("Tama onboarding definition identity is invalid".to_string());
    }

    let screens = definition
        .get("screens")
        .and_then(Value::as_array)
        .ok_or_else(|| "Tama onboarding definition has no screens".to_string())?;
    if !(3..=5).contains(&screens.len()) {
        return Err("Tama onboarding definition must contain three to five screens".to_string());
    }

    let mut screen_ids = HashSet::new();
    for screen in screens {
        let screen_id = screen
            .get("screen_id")
            .and_then(Value::as_str)
            .ok_or_else(|| "Tama onboarding screen has no id".to_string())?;
        if !screen_ids.insert(screen_id) {
            return Err(format!("duplicate Tama onboarding screen id: {screen_id}"));
        }
        for field in ["title", "body"] {
            if screen
                .pointer(&format!("/presentation/{field}"))
                .and_then(Value::as_str)
                .is_none_or(str::is_empty)
            {
                return Err(format!(
                    "Tama onboarding screen {screen_id} has no presentation {field}"
                ));
            }
        }
    }

    let entry_screen_id = definition
        .get("entry_screen_id")
        .and_then(Value::as_str)
        .ok_or_else(|| "Tama onboarding definition has no entry screen".to_string())?;
    if !screen_ids.contains(entry_screen_id) {
        return Err("Tama onboarding entry screen does not exist".to_string());
    }
    for screen in screens {
        if let Some(transitions) = screen.get("transitions").and_then(Value::as_array) {
            for transition in transitions {
                let target = transition
                    .get("next_screen_id")
                    .and_then(Value::as_str)
                    .ok_or_else(|| "Tama onboarding transition has no target".to_string())?;
                if !screen_ids.contains(target) {
                    return Err(format!(
                        "Tama onboarding transition target does not exist: {target}"
                    ));
                }
            }
        }
    }

    Ok(definition)
}
