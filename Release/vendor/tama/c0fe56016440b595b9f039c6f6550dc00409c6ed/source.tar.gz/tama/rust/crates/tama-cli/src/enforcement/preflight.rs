//! Asking a hook, before it is selected, whether it can work on this machine.
//!
//! The session path already does this: the OMP adapter runs a declared hook
//! once with `tama_activation_preflight` and refuses to activate it when the
//! answer is not an acceptance. The machine-wide selection did not, so on
//! 2026-09-11 `block-objective-substitution` was selected on a machine where
//! Brama refuses its consumer, and from that moment every tool call an agent
//! made was refused with that credential error — including this very command,
//! which was then the only way back.
//!
//! A hook whose binary is absent is not a failure here: it is not installed
//! yet, it will not be dispatched, and refusing the selection for that would
//! stop an operator from selecting a hook before its release lands. Only a
//! hook that runs and answers with an infrastructure failure is refused.

use std::io::Write;
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};

use tama_hooks::hook_exec::{tokenize_command, INFRASTRUCTURE_MARKER};

/// The probe payload the adapter uses, so a hook that already understands the
/// session preflight answers this one the same way.
const PROBE: &[u8] = br#"{"tama_activation_preflight":true}"#;

/// The registry stores a hook command with the home directory left as a
/// literal `$HOME` or `~`, and the runtime expands it before spawning. The
/// probe has to expand it too. It did not, so on 2026-09-11 the probe tried to
/// run a file whose name began with `$HOME`, took the spawn failure for "not
/// installed yet", and let the very hook this check exists for back into the
/// selection — wedging the machine a second time inside one turn.
fn expanded(word: &str) -> String {
    let home = std::env::var("HOME").unwrap_or_default();
    if home.is_empty() {
        return word.to_string();
    }
    for prefix in ["$HOME/", "${HOME}/", "~/"] {
        if let Some(rest) = word.strip_prefix(prefix) {
            return format!("{home}/{rest}");
        }
    }
    match word {
        "$HOME" | "${HOME}" | "~" => home,
        _ => word.to_string(),
    }
}

/// What asking one hook produced, so a refusal and a diagnostic report the
/// same observation instead of each deciding for itself.
pub(crate) struct Probe {
    pub(crate) command: String,
    pub(crate) program: String,
    pub(crate) spawned: Result<(), String>,
    pub(crate) exit: Option<i32>,
    pub(crate) answer: String,
}

impl Probe {
    /// The infrastructure line the hook printed, which is the only answer that
    /// keeps it out of the selection.
    pub(crate) fn failure(&self) -> Option<String> {
        self.answer
            .lines()
            .find(|line| line.trim_start().starts_with(INFRASTRUCTURE_MARKER))
            .map(|line| line.trim().to_string())
    }

    pub(crate) fn verdict(&self) -> &'static str {
        match (&self.spawned, self.failure()) {
            (Err(_), _) => "not installed on this machine",
            (Ok(()), Some(_)) => "unusable: the hook cannot reach the service it needs",
            (Ok(()), None) => "usable",
        }
    }
}

pub(crate) fn probe(command: &str) -> Option<Probe> {
    let tokens = tokenize_command(command);
    let (program, arguments) = tokens.split_first()?;
    let program = expanded(program);
    let arguments: Vec<String> = arguments.iter().map(|word| expanded(word)).collect();
    let mut probe = Probe {
        command: command.to_string(),
        program: program.clone(),
        spawned: Ok(()),
        exit: None,
        answer: String::new(),
    };
    let child = Command::new(&program)
        .args(&arguments)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn();
    let mut child = match child {
        Ok(child) => child,
        Err(error) => {
            probe.spawned = Err(error.to_string());
            return Some(probe);
        }
    };
    if let Some(stdin) = child.stdin.as_mut() {
        let _ = stdin.write_all(PROBE);
    }
    match child.wait_with_output() {
        Ok(output) => {
            probe.exit = output.status.code();
            probe.answer = format!(
                "{}{}",
                String::from_utf8_lossy(&output.stdout),
                String::from_utf8_lossy(&output.stderr)
            );
        }
        Err(error) => probe.spawned = Err(error.to_string()),
    }
    Some(probe)
}

/// The command the machine would actually run for one hook id.
///
/// The installed catalogue is asked first. Its commands are pinned to the
/// installed release under `hooks-runtime/current/bin`, which is what a
/// provider event reaches; a checkout's catalogue still names the unpinned
/// `$HOME/.local/bin` copy. On 2026-09-11 this check probed that copy, found
/// a binary left there in August, and reported its old credential path as the
/// live hook's answer - the opposite of what the check exists for.
pub(crate) fn hook_command(root: &Path, wanted: &str) -> Option<String> {
    let installed = std::env::var("HOME")
        .map(PathBuf::from)
        .map(|home| home.join(".shared-hooks").join("registry.json"))
        .ok();
    if let Some(path) = installed.filter(|path| path.is_file()) {
        if let Some(command) = catalogue_command(&path, wanted) {
            return Some(command);
        }
    }
    catalogue_command(&root.join("shared-hooks").join("registry.json"), wanted)
}

/// One catalogue document, read from the exact path that holds it: the
/// installed catalogue lives under `.shared-hooks`, a checkout's under
/// `shared-hooks`, and only the file itself says which commands are pinned.
fn catalogue_command(path: &Path, wanted: &str) -> Option<String> {
    let text = std::fs::read_to_string(path).ok()?;
    let document: serde_json::Value = serde_json::from_str(&text).ok()?;
    let catalog = document.get("catalog")?.as_object()?;
    for key in ["agentHooks", "gitHooks"] {
        let Some(hooks) = catalog.get(key).and_then(serde_json::Value::as_array) else {
            continue;
        };
        for hook in hooks {
            if hook.get("id").and_then(serde_json::Value::as_str) != Some(wanted) {
                continue;
            }
            // One entry naming the hook without a command is not the end of
            // the walk: the catalogue records the same hook under both keys.
            if let Some(command) = hook.get("command").and_then(serde_json::Value::as_str) {
                return Some(command.to_string());
            }
        }
    }
    None
}

/// The diagnostic behind `tama enforcement preflight`: what the catalogue
/// records, what was actually executed, and what the hook answered. Written
/// because reading the code could not tell an operator why a hook was accepted
/// or refused, and one wrong guess about that costs a machine its agent.
pub(super) fn report(root: &Path, id: &str, installed: &[String]) -> i32 {
    println!("hook: {id}");
    println!(
        "catalogue: {}",
        if installed.binary_search(&id.to_string()).is_ok() {
            "installed"
        } else {
            "unknown to the installed registry"
        }
    );
    let Some(command) = hook_command(root, id) else {
        println!("command: none recorded, so nothing can be asked");
        println!("verdict: unusable: the catalogue records no command for this hook");
        return 1;
    };
    let Some(probe) = probe(&command) else {
        println!("command: {command}");
        println!("verdict: unusable: the recorded command is empty");
        return 1;
    };
    println!("command: {}", probe.command);
    println!("program: {}", probe.program);
    match &probe.spawned {
        Ok(()) => println!("exit: {}", probe.exit.unwrap_or(-1)),
        Err(error) => println!("spawn: {error}"),
    }
    println!(
        "answer: {}",
        probe.answer.lines().next().unwrap_or("").trim()
    );
    println!("verdict: {}", probe.verdict());
    i32::from(probe.failure().is_some())
}
