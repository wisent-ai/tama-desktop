//! Which files the line limit is about.
//!
//! Mirrors the registry case at the top of `block_oversized_files.sh`, which
//! leaves structured data untouched by the line count on the operator's
//! instruction ("wylacz limit dla plikow rejestrow", 2026-09-10): a registry
//! is read whole by the code that loads it, so "split into smaller modules" is
//! not an instruction anybody can follow there. The hook compares with
//! `nocasematch`, so the comparison here lowercases the extension first.
//!
//! Only the line rule is relaxed. The folder-file limit, the new-file
//! justification and the content gates still apply to a registry, and the
//! default scan keeps replaying the real hook — this list exists so the
//! in-process `--size-only` pass answers the same way over a whole machine.
//!
//! It lives beside the scan rather than inside `find_violations.rs` because
//! adding it there pushed that file past the three-hundred-line limit this
//! very hook enforces.

use std::path::Path;

/// Every extension the hook's `case` leaves out of the line count: structured
/// data first, then the manuscript sources a thesis is written in. The list is
/// duplicated here on purpose — the fast pass must not spawn a shell — and
/// `the_mirror_matches_the_hook` fails the moment the two disagree.
const EXEMPT_EXTENSIONS: [&str; 11] = [
    "json", "jsonl", "ndjson", "lock", "csv", "tsv", "tex", "bib", "sty", "bst", "cls",
];

/// True when the line limit does not apply to this path, as the hook decides.
pub fn exempt_from_line_limit(path: &str) -> bool {
    Path::new(path)
        .extension()
        .map(|extension| extension.to_string_lossy().to_lowercase())
        .is_some_and(|extension| EXEMPT_EXTENSIONS.contains(&extension.as_str()))
}

#[cfg(test)]
mod tests {
    use super::EXEMPT_EXTENSIONS;
    use std::collections::BTreeSet;
    use std::path::PathBuf;

    /// The shipped hook this crate mirrors, read from the repository it lives
    /// in rather than from the installed copy, so the check is about the
    /// revision under test.
    fn hook() -> PathBuf {
        PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .join("..")
            .join("..")
            .join("..")
            .join("shared-hooks")
            .join("block_oversized_files.sh")
    }

    /// Every `*.ext` spelling inside the hook's exemption `case`, which is the
    /// only place the rule is decided for a real write.
    fn hook_extensions(source: &str) -> BTreeSet<String> {
        source
            .lines()
            .filter(|line| line.contains("exit 0 ;;"))
            .flat_map(|line| {
                line.split(')')
                    .next()
                    .unwrap_or_default()
                    .split('|')
                    .filter_map(|part| part.trim().strip_prefix("*."))
                    .map(|extension| extension.to_lowercase())
                    .collect::<Vec<String>>()
            })
            .collect()
    }

    #[test]
    fn the_mirror_matches_the_hook() {
        let source = std::fs::read_to_string(hook()).expect("read the shipped line-limit hook");
        let wanted = hook_extensions(&source);
        assert!(
            !wanted.is_empty(),
            "the hook must still carry an exemption case: {source}"
        );
        let mirrored: BTreeSet<String> = EXEMPT_EXTENSIONS
            .iter()
            .map(|extension| extension.to_string())
            .collect();
        assert_eq!(
            mirrored, wanted,
            "the fast size pass must exempt exactly what the hook exempts"
        );
    }
}
