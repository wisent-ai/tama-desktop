#![cfg(unix)]

//! A hook that could not reach its service has not decided anything.
//!
//! The catalogue has promised for months that credential, transport, timeout
//! and HTTP failures are reported as infrastructure failures rather than policy
//! decisions. Nothing implemented that promise. A hook that printed
//! `TAMA_HOOK_INFRASTRUCTURE:` and exited non-zero fell through to the last
//! branch - non-zero exit on a blocking event - and its stderr became the
//! refusal. On 2026-09-11 `block-objective-substitution` could not authenticate
//! to Brama on this machine and every tool call an agent made was refused with
//! that credential error, down to `true`.
//!
//! A crash and an unreachable service are the same thing to a policy engine:
//! no verdict. A real block decision is still a block, and that is the second
//! case here, because a fix that let everything through would be worse than the
//! defect it repairs.

use std::fs;
use std::io::Write;
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::time::{SystemTime, UNIX_EPOCH};

use serde_json::json;
use tama_hooks::sha256::sha256_hex;

fn root(label: &str) -> PathBuf {
    let nonce = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .expect("clock before epoch")
        .as_nanos();
    let root = PathBuf::from(env!("CARGO_TARGET_TMPDIR")).join(format!(
        "infrastructure-{label}-{}-{nonce}",
        std::process::id()
    ));
    fs::create_dir_all(&root).expect("create the fixture root");
    root
}

fn script(root: &Path, name: &str, body: &str) -> PathBuf {
    let path = root.join(name);
    fs::write(&path, body).expect("write the fixture hook");
    let mut permissions = fs::metadata(&path)
        .expect("stat the fixture hook")
        .permissions();
    std::os::unix::fs::PermissionsExt::set_mode(&mut permissions, 0o755);
    fs::set_permissions(&path, permissions).expect("make the fixture hook executable");
    path
}

/// The fixture registry, in the shape the runtime parses: one hook on a
/// blocking tool event, with the timeout the record carries.
fn publish(root: &Path, hook: &Path) {
    let mut document = json!({
        "releaseId": "infrastructure-fixture",
        "events": {
            "pre_tool_use:bash": {
                "blocking": true,
                "hooks": [{
                    "id": "fixture-hook",
                    "command": hook.to_string_lossy(),
                    "timeout": 10,
                }],
            },
        },
    });
    document["catalogChecksum"] = json!(sha256_hex(
        &serde_json::to_vec(&document).expect("serialize the fixture registry")
    ));
    fs::write(
        root.join("registry.json"),
        serde_json::to_vec(&document).expect("serialize the fixture registry"),
    )
    .expect("publish the fixture registry");
}

fn dispatch(root: &Path) -> String {
    let mut child = Command::new(env!("CARGO_BIN_EXE_tama-run-hook"))
        .args(["pre_tool_use:bash", "omp"])
        .env("AGENT_HOOK_REGISTRY", root.join("registry.json"))
        .env("HOOKS_ADAPTIVE_STATE", root.join("state"))
        .env("LAKE_DATA", root.join("absent-lake"))
        .env("HOME", root)
        .env("TAMA_HOOK_ENFORCEMENT", root.join("enforcement.json"))
        .env("TAMA_EMERGENCY_STATE", root.join("emergency.json"))
        .env("TAMA_PROVIDER", "omp")
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .expect("start the runtime");
    child
        .stdin
        .as_mut()
        .expect("the runtime takes stdin")
        .write_all(
            br#"{"session_id":"infrastructure","tool_name":"bash","tool_input":{"command":"true"}}"#,
        )
        .expect("the payload reaches the runtime");
    let output = child.wait_with_output().expect("the runtime finishes");
    String::from_utf8_lossy(&output.stdout).to_string()
}

#[test]
fn an_unreachable_service_does_not_refuse_the_call() {
    let root = root("unreachable");
    let hook = script(
        &root,
        "unreachable.sh",
        "#!/bin/sh\nprintf '%s\\n' 'TAMA_HOOK_INFRASTRUCTURE: Brama rejected the request from consumer tama with HTTP 401' >&2\nexit 70\n",
    );
    publish(&root, &hook);

    let decision = dispatch(&root);

    assert!(
        decision.contains("\"decision\":\"pass\""),
        "a hook that reached nothing decided nothing, and must not refuse the call: {decision}"
    );
    assert!(
        !decision.contains("HTTP 401"),
        "a credential error is not a policy reason: {decision}"
    );
}

#[test]
fn a_real_block_decision_still_blocks() {
    let root = root("blocking");
    let hook = script(
        &root,
        "refuse.sh",
        "#!/bin/sh\nprintf '%s' '{\"decision\":\"block\",\"reason\":\"fixture refuses\"}'\n",
    );
    publish(&root, &hook);

    let decision = dispatch(&root);

    assert!(
        decision.contains("\"decision\":\"block\"") && decision.contains("fixture refuses"),
        "narrowing the failure path must not weaken a real refusal: {decision}"
    );
}
