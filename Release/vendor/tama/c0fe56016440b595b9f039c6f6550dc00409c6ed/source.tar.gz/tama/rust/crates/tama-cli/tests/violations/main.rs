//! Real CLI and real hook scripts; source files remain byte-identical.
use serde_json::Value;
use std::fs;
use std::path::{Path, PathBuf};
use std::process::{Command, Output};
use std::sync::atomic::{AtomicU64, Ordering};

const LIMIT: usize = 300;
static FIXTURE_SEQUENCE: AtomicU64 = AtomicU64::new(0);
struct Fixture {
    root: PathBuf,
    repo: PathBuf,
    tama: PathBuf,
}
impl Fixture {
    fn new() -> Self {
        let tama = Path::new(env!("CARGO_MANIFEST_DIR"))
            .ancestors()
            .nth(3)
            .unwrap()
            .to_path_buf();
        let evidence = tama.join(".wisent-output/violations");
        fs::create_dir_all(&evidence).unwrap();
        let root = evidence.join(format!(
            "{}-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos(),
            FIXTURE_SEQUENCE.fetch_add(1, Ordering::Relaxed)
        ));
        fs::create_dir(&root).unwrap();
        let repo = root.join("repo");
        fs::create_dir_all(&repo).unwrap();
        assert!(Command::new("git")
            .args(["init", "--quiet"])
            .arg(&repo)
            .status()
            .unwrap()
            .success());
        let revision = Command::new("git")
            .args(["rev-parse", "HEAD"])
            .current_dir(&tama)
            .output()
            .unwrap();
        fs::write(root.join("revision.txt"), revision.stdout).unwrap();
        Self { root, repo, tama }
    }
    fn run(&self, step: &str, command: &str, extra: &[&str]) -> Output {
        let out = Command::new(env!("CARGO_BIN_EXE_tama-cli"))
            .args([command, "--repo"])
            .arg(&self.repo)
            .args(extra)
            .env("TAMA_ROOT", &self.tama)
            .env("TAMA_CLEAN_STATE_DIR", self.root.join("state"))
            .output()
            .unwrap();
        fs::write(self.root.join(format!("{step}.stdout")), &out.stdout).unwrap();
        fs::write(self.root.join(format!("{step}.stderr")), &out.stderr).unwrap();
        fs::write(
            self.root.join(format!("{step}.exit")),
            format!("{:?}", out.status.code()),
        )
        .unwrap();
        out
    }
}
impl Drop for Fixture {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.repo);
    }
}

#[test]
fn scan_counts_file_limit_and_crowded_folder_once_without_mutation() {
    let f = Fixture::new();
    let long = "// source row\n".repeat(LIMIT + 1);
    fs::write(f.repo.join("long.js"), &long).unwrap();
    fs::write(f.repo.join("edge.js"), "// source row\n".repeat(LIMIT)).unwrap();
    fs::create_dir(f.repo.join("dense")).unwrap();
    for name in ["a", "b", "c", "d", "e", "f"] {
        fs::write(
            f.repo.join("dense").join(format!("{name}.js")),
            "// source\n",
        )
        .unwrap();
    }
    let out = f.run("scan", "find-violations", &["--json"]);
    assert_eq!(
        out.status.code(),
        Some(1),
        "{}",
        String::from_utf8_lossy(&out.stderr)
    );
    let report: Value = serde_json::from_slice(&out.stdout).unwrap();
    let hits = report["repos"][0]["violations"].as_array().unwrap();
    assert_eq!(
        hits.iter().filter(|hit| hit["path"] == "long.js").count(),
        1,
        "{report}"
    );
    assert_eq!(
        hits.iter().filter(|hit| hit["path"] == "dense").count(),
        1,
        "{report}"
    );
    assert!(!hits.iter().any(|hit| hit["path"] == "edge.js"), "{report}");
    assert_eq!(fs::read_to_string(f.repo.join("long.js")).unwrap(), long);
    assert_eq!(report["repos"][0]["errors"], serde_json::json!([]));
}

#[test]
fn ignore_paths_and_clean_preview_use_the_same_size_rule() {
    let f = Fixture::new();
    let long = "// source row\n".repeat(LIMIT + 1);
    fs::create_dir(f.repo.join("ignored")).unwrap();
    fs::write(f.repo.join("ignored/old.js"), &long).unwrap();
    fs::write(f.repo.join(".tama-violations-ignore"), "ignored/\n").unwrap();
    fs::write(f.repo.join("long.js"), &long).unwrap();
    let out = f.run("scan", "find-violations", &["--json"]);
    let report: Value = serde_json::from_slice(&out.stdout).unwrap();
    let hits = report["repos"][0]["violations"].as_array().unwrap();
    assert_eq!(
        hits.iter().filter(|hit| hit["path"] == "long.js").count(),
        1
    );
    assert!(!hits.iter().any(|hit| hit["path"] == "ignored/old.js"));
    let preview = f.run("clean-preview", "clean", &["--dry-run"]);
    assert!(
        String::from_utf8_lossy(&preview.stdout).contains("long.js"),
        "{}",
        String::from_utf8_lossy(&preview.stderr)
    );
    assert_eq!(fs::read_to_string(f.repo.join("long.js")).unwrap(), long);
    fs::write(f.repo.join("long.js"), "// source\n").unwrap();
    let fixed = f.run("rescanned", "find-violations", &["--json"]);
    assert_eq!(
        fixed.status.code(),
        Some(0),
        "{}",
        String::from_utf8_lossy(&fixed.stderr)
    );
}

/// `--size-only` exists because the replay spawns two shells per file and a
/// whole-machine scan never finishes. It is only usable if it answers the two
/// size rules exactly as the hooks do, so this drives both modes over one
/// repository and compares what they report, sentence for sentence.
#[test]
fn size_only_matches_hook_replay() {
    let f = Fixture::new();
    fs::write(f.repo.join("long.js"), "// source row\n".repeat(LIMIT + 1)).unwrap();
    fs::write(f.repo.join("edge.js"), "// source row\n".repeat(LIMIT)).unwrap();
    // A registry is data its reader loads whole: the hook leaves it out of the
    // line count, so the fast pass must leave it out too, or a whole-machine
    // scan would order splits the real guard never asks for. The entries carry
    // text, because the content rules the replay also runs are not the subject
    // here and a bare number in a registry trips one of them.
    fs::write(
        f.repo.join("registry.json"),
        "{\n".to_string() + &"  \"entry\": \"recorded\",\n".repeat(LIMIT) + "}\n",
    )
    .unwrap();
    fs::create_dir(f.repo.join("ignored")).unwrap();
    fs::write(
        f.repo.join("ignored/old.js"),
        "// source row\n".repeat(LIMIT + 1),
    )
    .unwrap();
    fs::write(f.repo.join(".tama-violations-ignore"), "ignored/\n").unwrap();
    fs::create_dir(f.repo.join("dense")).unwrap();
    for name in ["a", "b", "c", "d", "e", "f"] {
        fs::write(
            f.repo.join("dense").join(format!("{name}.js")),
            "// source\n",
        )
        .unwrap();
    }

    let replayed: Value =
        serde_json::from_slice(&f.run("scan", "find-violations", &["--json"]).stdout).unwrap();
    let fast = f.run(
        "scan-size-only",
        "find-violations",
        &["--json", "--size-only"],
    );
    assert_eq!(
        fast.status.code(),
        Some(1),
        "{}",
        String::from_utf8_lossy(&fast.stderr)
    );
    let measured: Value = serde_json::from_slice(&fast.stdout).unwrap();

    let sentences = |report: &Value| -> Vec<String> {
        report["repos"][0]["violations"]
            .as_array()
            .unwrap()
            .iter()
            .map(|hit| format!("{} :: {}", hit["path"], hit["message"]))
            .collect()
    };
    assert_eq!(sentences(&measured), sentences(&replayed), "{measured}");
    assert_eq!(
        measured["repos"][0]["scannedFiles"],
        replayed["repos"][0]["scannedFiles"]
    );
    assert!(
        !sentences(&measured)
            .iter()
            .chain(sentences(&replayed).iter())
            .any(|sentence| sentence.contains("registry.json")),
        "a registry over the limit is exempt from the line count in both passes: {measured}"
    );
    assert_eq!(measured["repos"][0]["errors"], serde_json::json!([]));
}

/// A repository declares its generated files to this audit in a file at its
/// own root — and the write guard refuses a sixth file in any folder, which a
/// repository root almost always already has. `.tama/violations-ignore` is the
/// form that can actually be created; both must be honoured.
#[test]
fn folded_ignore_file_excludes_the_same_paths_as_the_root_form() {
    let f = Fixture::new();
    let long = "// source row\n".repeat(LIMIT + 1);
    fs::create_dir(f.repo.join("generated")).unwrap();
    fs::write(f.repo.join("generated/art.svg"), &long).unwrap();
    for name in ["a", "b", "c", "d", "e", "f"] {
        fs::write(
            f.repo.join("generated").join(format!("{name}.svg")),
            "<svg/>\n",
        )
        .unwrap();
    }
    fs::write(f.repo.join("kept.js"), &long).unwrap();
    fs::create_dir(f.repo.join("dense")).unwrap();
    for name in ["a", "b", "c", "d", "e", "f"] {
        fs::write(
            f.repo.join("dense").join(format!("{name}.js")),
            "// source\n",
        )
        .unwrap();
    }
    fs::create_dir(f.repo.join(".tama")).unwrap();
    fs::write(
        f.repo.join(".tama/violations-ignore"),
        "# rendered by the product\ngenerated/\n",
    )
    .unwrap();

    let out = f.run("scan", "find-violations", &["--json", "--size-only"]);
    let report: Value = serde_json::from_slice(&out.stdout).unwrap();
    let hits = report["repos"][0]["violations"].as_array().unwrap();
    let paths: Vec<&str> = hits
        .iter()
        .map(|hit| hit["path"].as_str().unwrap_or_default())
        .collect();
    assert!(paths.contains(&"kept.js"), "{report}");
    assert!(paths.contains(&"dense"), "{report}");
    assert!(!paths.contains(&"generated/art.svg"), "{report}");
    assert!(!paths.contains(&"generated"), "{report}");
    assert!(
        report["repos"][0]["skippedFiles"]
            .as_array()
            .unwrap()
            .iter()
            .any(|skip| skip["path"] == "generated/art.svg"),
        "{report}"
    );
}
