//! Reading git's own answer about a repository's worktrees.
//!
//! Split out of `discovery.rs` when that file crossed the three-hundred-line
//! limit `block-oversized-files` enforces. The seam is meaningful rather than
//! arithmetic: everything here turns `git worktree list --porcelain` into
//! values, and nothing here decides what to do with them.

use std::path::Path;

use crate::gitcmd::is_dirty;
pub(super) use crate::gitcmd::{canonical, git, same_path};

use serde::Serialize;

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub(crate) struct Worktree {
    pub path: String,
    /// `null` on a detached HEAD: the porcelain output then carries a
    /// `detached` record instead of a `branch` one.
    pub branch: Option<String>,
    pub head: String,
    pub dirty: bool,
    pub locked: bool,
    pub prunable: bool,
}

#[derive(Default)]
struct Record {
    path: String,
    head: String,
    branch: Option<String>,
    bare: bool,
    locked: bool,
    prunable: bool,
}

/// `git worktree list --porcelain`: blank-line separated stanzas, each opened
/// by `worktree <path>` and carrying `HEAD <sha>` plus one of `branch <ref>`
/// or `detached`, and optionally `bare`, `locked [reason]` and
/// `prunable [reason]`.
fn parse_porcelain(text: &str) -> Vec<Record> {
    let mut records: Vec<Record> = Vec::new();
    for line in text.lines() {
        if let Some(path) = line.strip_prefix("worktree ") {
            records.push(Record {
                path: path.to_string(),
                ..Record::default()
            });
            continue;
        }
        let Some(current) = records.last_mut() else {
            continue;
        };
        if let Some(head) = line.strip_prefix("HEAD ") {
            current.head = head.to_string();
        } else if let Some(branch) = line.strip_prefix("branch ") {
            current.branch = Some(branch.to_string());
        } else if line == "bare" {
            current.bare = true;
        } else if line == "locked" || line.starts_with("locked ") {
            current.locked = true;
        } else if line == "prunable" || line.starts_with("prunable ") {
            current.prunable = true;
        }
    }
    records
}

/// Every linked worktree of `repo`. The main worktree is dropped twice over:
/// git documents it as the first entry, and its path is the repository path
/// discovery handed us. A bare entry has no checkout to remove.
pub(super) fn linked_worktrees(repo: &Path) -> Result<Vec<Worktree>, String> {
    let records = parse_porcelain(&git(repo, &["worktree", "list", "--porcelain"])?);
    let mut worktrees = Vec::new();
    for (index, record) in records.iter().enumerate() {
        if index == 0 || record.bare || same_path(&record.path, repo) {
            continue;
        }
        worktrees.push(Worktree {
            dirty: is_dirty(Path::new(&record.path)),
            path: record.path.clone(),
            branch: record.branch.clone(),
            head: record.head.clone(),
            locked: record.locked,
            prunable: record.prunable,
        });
    }
    Ok(worktrees)
}
