//! Detecting repair changes that evade rather than satisfy the rules.
use super::*;
/// Rule-gaming detector: flags working-tree changes that comply with the
/// letter of the hook rules while dodging their spirit. Git repositories
/// only; other trees report `{ skipped: true, findings: [] }`.
pub fn detect_gaming(repo: &Path) -> GamingResult {
    let out = Command::new("git")
        .args(["status", "--porcelain"])
        .current_dir(repo)
        .output();
    let out = match out {
        Ok(out) => out,
        Err(_) => {
            return GamingResult {
                skipped: true,
                findings: Vec::new(),
            }
        }
    };
    if out.status.code() != Some(0) {
        return GamingResult {
            skipped: true,
            findings: Vec::new(),
        };
    }
    let stdout = String::from_utf8_lossy(&out.stdout);
    let mut findings = Vec::new();
    let mut changed_paths: Vec<String> = Vec::new();
    for line in stdout.split('\n') {
        if line.trim().is_empty() {
            continue;
        }
        let entry = line.chars().skip(3).collect::<String>().trim().to_string();
        let renamed = entry.contains(" -> ");
        let parts: Vec<&str> = entry.split(" -> ").collect();
        let old_path: Option<String> = if renamed {
            Some(parts[0].to_string())
        } else {
            None
        };
        let new_path: String = if renamed {
            parts[1].to_string()
        } else {
            entry.clone()
        };
        if let Some(old_path) = &old_path {
            let old_has_test = basename(old_path).to_lowercase().contains("test");
            let new_has_test = basename(&new_path).to_lowercase().contains("test");
            if old_has_test && !new_has_test {
                findings.push(Finding {
                    kind: "test-gate-rename-dodge".to_string(),
                    path: format!("{} -> {}", old_path, new_path),
                });
            }
        }
        changed_paths.push(new_path);
    }
    for path in &changed_paths {
        let ext = extname(path);
        if !ext.is_empty() && !MODULE_EXTENSIONS.contains(&ext.as_str()) {
            findings.push(Finding {
                kind: "non-module-extension".to_string(),
                path: path.clone(),
            });
            continue;
        }
        let full = repo.join(path);
        let info = match std::fs::metadata(&full) {
            Ok(info) => info,
            Err(_) => continue,
        };
        if !info.is_file() || info.len() > MAX_BYTES {
            continue;
        }
        let content = match std::fs::read(&full) {
            Ok(bytes) => String::from_utf8_lossy(&bytes).into_owned(),
            Err(_) => continue,
        };
        for pattern in GAMING_CONTENT {
            if content.contains(pattern) {
                findings.push(Finding {
                    kind: "smuggled-runtime-blob".to_string(),
                    path: path.clone(),
                });
                break;
            }
        }
    }
    GamingResult {
        skipped: false,
        findings,
    }
}
