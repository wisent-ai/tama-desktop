//! JS `buildCatalog(root)` and `findHook(id, root)`: the catalogue a reader
//! sees, one record per hook.
//!
//! Moved verbatim out of the single catalogue file during a split by
//! responsibility.

use serde::Serialize;
use std::collections::{HashMap, HashSet};
use std::path::Path;

use crate::registry::{HookDocs, JustificationRequirement, OrderedMap};
use crate::Result;

use super::fs_scan::extname;
use super::key_order::top_level_object_key_order;
use super::{
    command_source_path, list_repo_git_hooks, list_source_files, load_catalog_metadata,
    load_registry_raw, RepoGitHook,
};

/// Per-event entry of a catalog hook: `{ event, blocking, timeout, statusMessage }`.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CatalogHookEvent {
    pub event: String,
    pub blocking: bool,
    #[serde(serialize_with = "serialize_js_number")]
    pub timeout: Option<f64>,
    pub status_message: Option<String>,
}

/// Serialize an `Option<f64>` the way `JSON.stringify` prints JS numbers:
/// integral values without a fractional part (`10`, not `10.0`).
fn serialize_js_number<S: serde::Serializer>(
    value: &Option<f64>,
    serializer: S,
) -> std::result::Result<S::Ok, S::Error> {
    match value {
        None => serializer.serialize_none(),
        Some(v) if v.fract() == 0.0 && v.abs() < 1e15 => serializer.serialize_i64(*v as i64),
        Some(v) => serializer.serialize_f64(*v),
    }
}

/// One hook entry of the built catalog (JS object shape preserved).
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CatalogHook {
    pub id: String,
    #[serde(rename = "type")]
    pub hook_type: String,
    pub command: String,
    pub source_path: Option<String>,
    pub category: Option<String>,
    pub status: Option<String>,
    pub description: Option<String>,
    pub why: Option<String>,
    pub side_effects: Option<String>,
    pub events: Vec<CatalogHookEvent>,
    pub justification_requirements: Vec<JustificationRequirement>,
}

/// Result of JS `buildCatalog(root)`.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Catalog {
    pub version: u64,
    pub generated_at: Option<String>,
    pub hooks: Vec<CatalogHook>,
    pub orphan_sources: Vec<String>,
    /// Adapters in `registry.json` insertion order (not alphabetical).
    pub adapters: OrderedMap<crate::registry::Adapter>,
    pub repo_git_hooks: Vec<RepoGitHook>,
}

/// JS `buildCatalog(root)`. Field-level merge priorities:
/// `type`: docs.type ?? hook.type ?? 'command';
/// `category`/`status`/`why`/`sideEffects`: hook.* ?? docs.*;
/// `description`: hook.description ?? hook.does ?? docs.description;
/// `justificationRequirements`: docs.* ?? hook.* ?? [].
pub fn build_catalog(root: &Path) -> Result<Catalog> {
    let (registry, raw) = load_registry_raw(root)?;
    let mut event_order: Vec<String> = raw
        .as_deref()
        .map(|text| top_level_object_key_order(text, "events"))
        .unwrap_or_default();
    // Defensive: include any events the raw-text scan might have missed.
    for key in registry.events.keys() {
        if !event_order.iter().any(|e| e == key) {
            event_order.push(key.clone());
        }
    }
    let mut adapter_order: Vec<String> = raw
        .as_deref()
        .map(|text| top_level_object_key_order(text, "adapters"))
        .unwrap_or_default();
    for key in registry.adapters.keys() {
        if !adapter_order.iter().any(|a| a == key) {
            adapter_order.push(key.clone());
        }
    }
    let metadata = load_catalog_metadata(root)?;
    let empty_docs = HookDocs::default();

    let mut by_id: HashMap<String, CatalogHook> = HashMap::new();
    for event in &event_order {
        let config = &registry.events[event];
        for hook in &config.hooks {
            // JS: `hook.source ? commandSourcePath(hook.source) : commandSourcePath(hook.command)`
            let source_path = match hook.source.as_deref() {
                Some(source) if !source.is_empty() => command_source_path(Some(source), root),
                _ => command_source_path(hook.command.as_deref(), root),
            };
            let docs = metadata.get(&hook.id).unwrap_or(&empty_docs);
            let entry = by_id.entry(hook.id.clone()).or_insert_with(|| CatalogHook {
                id: hook.id.clone(),
                hook_type: docs
                    .hook_type
                    .clone()
                    .or_else(|| hook.hook_type.clone())
                    .unwrap_or_else(|| "command".to_string()),
                command: hook.command.clone().unwrap_or_default(),
                source_path: source_path.clone(),
                category: hook.category.clone().or_else(|| docs.category.clone()),
                status: hook.status.clone().or_else(|| docs.status.clone()),
                description: hook
                    .description
                    .clone()
                    .or_else(|| hook.does.clone())
                    .or_else(|| docs.description.clone()),
                why: hook.why.clone().or_else(|| docs.why.clone()),
                side_effects: hook
                    .side_effects
                    .clone()
                    .or_else(|| docs.side_effects.clone()),
                events: Vec::new(),
                justification_requirements: docs
                    .justification_requirements
                    .clone()
                    .unwrap_or_else(|| hook.justification_requirements.clone()),
            });
            entry.events.push(CatalogHookEvent {
                event: event.clone(),
                blocking: config.blocking.unwrap_or(false),
                timeout: hook.timeout,
                status_message: hook.status_message.clone(),
            });
            if entry.source_path.is_none() && source_path.is_some() {
                entry.source_path = source_path;
            }
        }
    }
    // `catalog.agentHooks` is the human-authored list, and the only place a
    // ported hook names its source: every native hook's event entry carries
    // `source: null` and a `~/.local/bin/tama-*` command that maps to no
    // file, which left 36 hooks sourceless and their still-shipped policy
    // files counted as orphans.
    let agent_hooks = registry
        .extra
        .get("catalog")
        .and_then(|catalog| catalog.get("agentHooks"))
        .and_then(serde_json::Value::as_array)
        .map(Vec::as_slice)
        .unwrap_or_default();
    for hook in agent_hooks {
        let Some(id) = hook.get("id").and_then(serde_json::Value::as_str) else {
            continue;
        };
        let Some(entry) = by_id.get_mut(id) else {
            continue;
        };
        if entry.source_path.is_some() {
            continue;
        }
        let declared = hook.get("source").and_then(serde_json::Value::as_str);
        entry.source_path = command_source_path(declared, root).or_else(|| {
            command_source_path(
                hook.get("command").and_then(serde_json::Value::as_str),
                root,
            )
        });
    }
    let mut hooks: Vec<CatalogHook> = by_id.into_values().collect();
    hooks.sort_by(|a, b| a.id.cmp(&b.id));
    let registered_sources: HashSet<&str> = hooks
        .iter()
        .filter_map(|h| h.source_path.as_deref())
        .filter(|s| !s.is_empty())
        .collect();
    let orphan_sources: Vec<String> = list_source_files(root)?
        .into_iter()
        .filter(|p| [".py", ".sh", ".mjs", ".js"].contains(&extname(p)))
        .filter(|p| !registered_sources.contains(p.as_str()))
        .collect();
    let mut adapters = OrderedMap::new();
    for name in &adapter_order {
        if let Some(adapter) = registry.adapters.get(name) {
            adapters.push(name.clone(), adapter.clone());
        }
    }
    Ok(Catalog {
        version: registry.version.unwrap_or(1),
        generated_at: registry.generated_at.clone(),
        hooks,
        orphan_sources,
        adapters,
        repo_git_hooks: list_repo_git_hooks(root)?,
    })
}

/// JS `findHook(id, root)`.
pub fn find_hook(id: &str, root: &Path) -> Result<Option<CatalogHook>> {
    Ok(build_catalog(root)?
        .hooks
        .into_iter()
        .find(|hook| hook.id == id))
}
