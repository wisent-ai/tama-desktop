//! Port of `src/tests/live-runtime/orchestration.mjs` (loaded by
//! `src/tests/require-live-runtime.mjs`).

use std::io::Write;
use std::path::PathBuf;

use tama_core::runtime::{CoverageSummary, RequiredCoverage};

use crate::json::Json;
use crate::scenarios::{self, LiveScenario};
use crate::support;
use crate::{claude, codex, editor, git_codex, omp};

/// Shared scenario context (root + env flags), read once like the JS module
/// does at load time.
pub struct Ctx {
    pub root: PathBuf,
    pub keep_artifacts: bool,
    pub claude_live_model: String,
    pub codex_router_coverage: bool,
    pub codex_full_local_coverage: bool,
}

/// `console.error(text)` — one write + flush so `process::exit` cannot
/// truncate it.
fn write_stderr(text: &str) {
    let stderr = std::io::stderr();
    let mut out = stderr.lock();
    let _ = out.write_all(text.as_bytes());
    let _ = out.write_all(b"\n");
    let _ = out.flush();
}

/// Entry point equivalent to running `require-live-runtime.mjs`.
/// Returns the process exit code.
pub fn run_require_live_runtime() -> i32 {
    match run_inner() {
        Ok(code) => code,
        Err(error) => {
            // JS: a throw during module evaluation is an uncaught exception —
            // Node prints it to stderr and exits 1.
            write_stderr(&error);
            1
        }
    }
}

fn dispatch(scenario: &LiveScenario, ctx: &Ctx) -> Result<Json, String> {
    match scenario {
        LiveScenario::Git(s) => git_codex::run_git_hook_scenario(s, ctx.keep_artifacts),
        LiveScenario::Codex(s) if s.full_local_hook_replay => {
            codex::run_codex_full_local_hook_replay_scenario(s, ctx)
        }
        LiveScenario::Codex(s) if s.full_local_lifecycle => {
            codex::run_codex_full_local_lifecycle_scenario(s, ctx)
        }
        LiveScenario::Codex(s) => codex::run_codex_hook_config_scenario(s, ctx),
        LiveScenario::Claude(s) if s.claude_neutral => {
            claude::run_claude_neutral_bash_scenario(s, ctx)
        }
        LiveScenario::Claude(s) if s.claude_captured => {
            claude::run_claude_captured_tool_scenario(s, ctx)
        }
        LiveScenario::Claude(s) => claude::run_claude_hook_config_scenario(s, ctx),
        LiveScenario::Editor(s) if s.runtime == "editor-save-guard" => {
            editor::run_editor_save_guard_scenario(s, ctx)
        }
        LiveScenario::Editor(s) => editor::run_editor_watch_scenario(s, ctx),
        LiveScenario::Omp(s) if s.neutral => omp::run_omp_neutral_bash_scenario(s, ctx),
        LiveScenario::Omp(s) if s.captured => omp::run_omp_captured_tool_scenario(s, ctx),
        LiveScenario::Omp(s) => omp::run_omp_hook_config_scenario(s, ctx),
    }
}

fn run_inner() -> Result<i32, String> {
    let root = support::root();
    let ctx = Ctx {
        root: root.clone(),
        keep_artifacts: support::keep_artifacts(),
        claude_live_model: support::claude_live_model(),
        codex_router_coverage: support::codex_router_coverage(),
        codex_full_local_coverage: support::codex_full_local_coverage(),
    };

    // `const requiredCoverage = buildRequiredCoverage(root)`
    let required_coverage =
        tama_core::runtime::build_required_coverage(&root).map_err(|e| e.to_string())?;
    let required_keys: Vec<&str> = required_coverage
        .iter()
        .map(|item| item.coverage_key())
        .collect();
    let scenario_filter = support::scenario_filter();

    // `const liveScenarios = [...]`
    let mut live_scenarios: Vec<LiveScenario> = Vec::new();
    live_scenarios.extend(
        scenarios::omp_scenarios()
            .into_iter()
            .map(LiveScenario::Omp),
    );
    live_scenarios.extend(
        scenarios::git_scenarios(&root)?
            .into_iter()
            .map(LiveScenario::Git),
    );
    for scenario in scenarios::codex_scenarios() {
        let exact_scenario_filter = scenario_filter == scenario.coverage_key
            || scenario_filter == format!("={}", scenario.coverage_key);
        if exact_scenario_filter {
            live_scenarios.push(LiveScenario::Codex(scenario));
            continue;
        }
        if scenario.full_local_lifecycle && !ctx.codex_full_local_coverage {
            continue;
        }
        if scenario.full_local_hook_replay {
            if ctx.codex_full_local_coverage {
                live_scenarios.push(LiveScenario::Codex(scenario));
            }
            continue;
        }
        if ctx.codex_router_coverage || required_keys.contains(&scenario.coverage_key) {
            live_scenarios.push(LiveScenario::Codex(scenario));
        }
    }
    live_scenarios.extend(
        scenarios::claude_scenarios()
            .into_iter()
            .map(LiveScenario::Claude),
    );
    live_scenarios.extend(
        scenarios::editor_scenarios()
            .into_iter()
            .map(LiveScenario::Editor),
    );

    // `const selectedScenarios = scenarioFilter ? liveScenarios.filter(...) : liveScenarios`
    let selected: Vec<&LiveScenario> = if scenario_filter.is_empty() {
        live_scenarios.iter().collect()
    } else if let Some(exact) = scenario_filter.strip_prefix('=') {
        live_scenarios
            .iter()
            .filter(|scenario| scenario.coverage_key() == exact)
            .collect()
    } else {
        live_scenarios
            .iter()
            .filter(|scenario| scenario.coverage_key().contains(&scenario_filter))
            .collect()
    };

    let mut scenario_results: Vec<Json> = Vec::new();
    for scenario in &selected {
        let result = support::attempt(scenario.coverage_key(), || dispatch(scenario, &ctx));
        scenario_results.push(result.clone());
        write_stderr(&Json::obj(vec![("liveScenarioResult".to_string(), result)]).to_pretty2());
    }

    let is_ok = |result: &Json| result.get("ok").map(Json::truthy).unwrap_or(false);
    let passed_live_smokes: Vec<&Json> = scenario_results.iter().filter(|r| is_ok(r)).collect();
    let failed_live_scenarios: Vec<&Json> = scenario_results.iter().filter(|r| !is_ok(r)).collect();
    let unavailable_runtimes: Vec<&Json> = scenario_results
        .iter()
        .filter(|r| {
            r.get("unavailableRuntime")
                .map(Json::truthy)
                .unwrap_or(false)
        })
        .collect();

    // `passedLiveSmokes.flatMap((result) => result.coveredKeys ?? [result.coverageKey])`
    let mut passed_keys: Vec<String> = Vec::new();
    for result in &passed_live_smokes {
        match result.get("coveredKeys") {
            Some(Json::Arr(items)) => {
                passed_keys.extend(items.iter().map(|item| item.js_string()));
            }
            Some(Json::Null) | None => {
                passed_keys.push(json_string_or_empty(result.get("coverageKey")));
            }
            Some(other) => passed_keys.push(other.js_string()),
        }
    }
    let coverage_summary = tama_core::runtime::summarize_coverage(&required_coverage, &passed_keys);

    let filtered_run_ok =
        !scenario_filter.is_empty() && !selected.is_empty() && failed_live_scenarios.is_empty();
    let unfiltered_run_ok = scenario_filter.is_empty()
        && coverage_summary.missing_count == 0
        && failed_live_scenarios.is_empty();
    let ok = filtered_run_ok || unfiltered_run_ok;

    let message = if ok {
        if scenario_filter.is_empty() {
            "REAL RUNTIME COVERAGE COMPLETE"
        } else {
            "SELECTED REAL RUNTIME SMOKES PASSED"
        }
    } else {
        "INCOMPLETE REAL RUNTIME COVERAGE: every hook occurrence in every claimed runtime/editor path requires a live scenario with real CLI/editor execution and captured runtime payload."
    };

    let summary_json = coverage_summary_json(&coverage_summary, true);
    let compact_summary_json = coverage_summary_json(&coverage_summary, false);

    let report = Json::obj(vec![
        ("ok".to_string(), Json::Bool(ok)),
        ("message".to_string(), Json::str(message)),
        (
            "passedLiveSmokeCount".to_string(),
            Json::num_usize(passed_live_smokes.len()),
        ),
        (
            "failedLiveScenarioCount".to_string(),
            Json::num_usize(failed_live_scenarios.len()),
        ),
        (
            "unavailableRuntimeCount".to_string(),
            Json::num_usize(unavailable_runtimes.len()),
        ),
        ("compactCoverageSummary".to_string(), compact_summary_json),
        (
            "failedLiveScenarios".to_string(),
            Json::arr(failed_live_scenarios.iter().map(|r| (*r).clone()).collect()),
        ),
        (
            "unavailableRuntimes".to_string(),
            Json::arr(unavailable_runtimes.iter().map(|r| (*r).clone()).collect()),
        ),
        ("coverageSummary".to_string(), summary_json),
        (
            "passedLiveSmokes".to_string(),
            Json::arr(passed_live_smokes.iter().map(|r| (*r).clone()).collect()),
        ),
    ]);
    write_stderr(&report.to_pretty2());
    Ok(if ok { 0 } else { 1 })
}

fn json_string_or_empty(value: Option<&Json>) -> String {
    crate::json::js_string_opt(value)
}

/// `missing` entries keep the JS object key order from
/// `buildRequiredCoverage`.
fn required_coverage_json(item: &RequiredCoverage) -> Json {
    match item {
        RequiredCoverage::Runtime(entry) => {
            let mut entries = vec![
                ("runtime".to_string(), Json::str(entry.runtime.clone())),
                ("event".to_string(), Json::str(entry.event.clone())),
                (
                    "runtimeEvent".to_string(),
                    Json::str(entry.runtime_event.clone()),
                ),
                ("hookId".to_string(), Json::str(entry.hook_id.clone())),
            ];
            if let Some(command) = &entry.command {
                entries.push(("command".to_string(), Json::str(command.clone())));
            }
            entries.push((
                "coverageKey".to_string(),
                Json::str(entry.coverage_key.clone()),
            ));
            Json::obj(entries)
        }
        RequiredCoverage::Git(entry) => {
            let mut entries = vec![
                ("runtime".to_string(), Json::str(entry.runtime.clone())),
                ("event".to_string(), Json::str(entry.event.clone())),
                ("hookId".to_string(), Json::str(entry.hook_id.clone())),
            ];
            if let Some(source) = &entry.source {
                entries.push(("source".to_string(), crate::json::from_serde(source)));
            }
            if let Some(repo) = &entry.repo {
                entries.push(("repo".to_string(), crate::json::from_serde(repo)));
            }
            if let Some(hooks_path) = &entry.hooks_path {
                entries.push(("hooksPath".to_string(), crate::json::from_serde(hooks_path)));
            }
            if let Some(scope) = &entry.scope {
                entries.push(("scope".to_string(), crate::json::from_serde(scope)));
            }
            entries.push((
                "coverageKey".to_string(),
                Json::str(entry.coverage_key.clone()),
            ));
            Json::obj(entries)
        }
    }
}

fn ordered_counts_json(map: &tama_core::registry::OrderedMap<usize>) -> Json {
    Json::obj(
        map.iter()
            .map(|(key, count)| (key.clone(), Json::num_usize(*count)))
            .collect(),
    )
}

/// `coverageSummary` (full) or `compactCoverageSummary` (without `missing`).
fn coverage_summary_json(summary: &CoverageSummary, full: bool) -> Json {
    let mut entries = vec![
        (
            "requiredCount".to_string(),
            Json::num_usize(summary.required_count),
        ),
        (
            "passedCount".to_string(),
            Json::num_usize(summary.passed_count),
        ),
        (
            "missingCount".to_string(),
            Json::num_usize(summary.missing_count),
        ),
        (
            "missingByRuntime".to_string(),
            ordered_counts_json(&summary.missing_by_runtime),
        ),
        (
            "missingByEvent".to_string(),
            ordered_counts_json(&summary.missing_by_event),
        ),
    ];
    if full {
        entries.push((
            "missing".to_string(),
            Json::arr(summary.missing.iter().map(required_coverage_json).collect()),
        ));
    }
    Json::obj(entries)
}
