//! Minimal backtracking regex engine (std-only) supporting the subset used
//! by `bridge.mjs` frustration patterns: literals, `.`, character classes,
//! `\b \w \W \s \S \d \D` escapes, groups `(…)`/`(?:…)`, alternation,
//! greedy quantifiers `? * + {n,m}` (lazy suffix accepted, treated greedy),
//! anchors `^ $`, and a case-insensitive flag. Leftmost-first match
//! semantics like JavaScript's `RegExp`.

#[derive(Debug, Clone)]
enum Ast {
    Alt(Vec<Ast>),
    Seq(Vec<Ast>),
    Repeat(Box<Ast>, u32, u32),
    Atom(Atom),
}

#[derive(Debug, Clone)]
enum Atom {
    Char(char),
    Any,
    Class {
        negated: bool,
        items: Vec<ClassItem>,
    },
    Set(Set),
    WordBoundary,
    NonWordBoundary,
    Start,
    End,
}

#[derive(Debug, Clone)]
enum ClassItem {
    Range(char, char),
    Set(Set),
}

#[derive(Debug, Clone, Copy)]
enum Set {
    Word,
    NonWord,
    Digit,
    NonDigit,
    Space,
    NonSpace,
}

const UNLIMITED: u32 = u32::MAX;

pub struct Regex {
    ast: Ast,
    ignore_case: bool,
}

impl Regex {
    /// `new RegExp(source, 'i')` — `Err` for unparseable sources.
    pub fn new(source: &str, ignore_case: bool) -> Result<Regex, String> {
        let chars: Vec<char> = source.chars().collect();
        let mut parser = Parser {
            chars: &chars,
            pos: 0,
        };
        let ast = parser.parse_alt()?;
        if parser.pos != chars.len() {
            return Err(format!("unexpected character at {}", parser.pos));
        }
        Ok(Regex { ast, ignore_case })
    }

    /// `regex.test(text)`.
    pub fn is_match(&self, text: &str) -> bool {
        self.find(text).is_some()
    }

    /// `text.match(regex)` — the first match's text, if any.
    pub fn find(&self, text: &str) -> Option<String> {
        let chars: Vec<char> = text.chars().collect();
        for start in 0..=chars.len() {
            let mut end = None;
            let found = self.matches(&self.ast, &chars, start, &mut |p| {
                end = Some(p);
                true
            });
            if found {
                let end = end.unwrap_or(start);
                return Some(chars[start..end].iter().collect());
            }
        }
        None
    }

    fn atom_matches(&self, atom: &Atom, chars: &[char], p: usize) -> Option<usize> {
        match atom {
            Atom::Start => {
                if p == 0 {
                    Some(p)
                } else {
                    None
                }
            }
            Atom::End => {
                if p == chars.len() {
                    Some(p)
                } else {
                    None
                }
            }
            Atom::WordBoundary => {
                if is_boundary(chars, p) {
                    Some(p)
                } else {
                    None
                }
            }
            Atom::NonWordBoundary => {
                if !is_boundary(chars, p) {
                    Some(p)
                } else {
                    None
                }
            }
            Atom::Char(expected) => {
                let c = *chars.get(p)?;
                if self.char_eq(c, *expected) {
                    Some(p + 1)
                } else {
                    None
                }
            }
            Atom::Any => {
                let c = *chars.get(p)?;
                if c != '\n' {
                    Some(p + 1)
                } else {
                    None
                }
            }
            Atom::Set(set) => {
                let c = *chars.get(p)?;
                if self.set_matches(*set, c) {
                    Some(p + 1)
                } else {
                    None
                }
            }
            Atom::Class { negated, items } => {
                let c = *chars.get(p)?;
                let inside = items.iter().any(|item| match item {
                    ClassItem::Range(lo, hi) => self.in_range(c, *lo, *hi),
                    ClassItem::Set(set) => self.set_matches(*set, c),
                });
                if inside != *negated {
                    Some(p + 1)
                } else {
                    None
                }
            }
        }
    }

    fn char_eq(&self, a: char, b: char) -> bool {
        if a == b {
            return true;
        }
        if !self.ignore_case {
            return false;
        }
        fold(a) == fold(b)
    }

    fn in_range(&self, c: char, lo: char, hi: char) -> bool {
        if lo <= c && c <= hi {
            return true;
        }
        if !self.ignore_case {
            return false;
        }
        let folded = fold(c);
        (lo <= folded && folded <= hi) || (lo <= fold_upper(c) && fold_upper(c) <= hi)
    }

    fn set_matches(&self, set: Set, c: char) -> bool {
        match set {
            Set::Word => is_word_char(c),
            Set::NonWord => !is_word_char(c),
            Set::Digit => c.is_ascii_digit(),
            Set::NonDigit => !c.is_ascii_digit(),
            Set::Space => is_js_space(c),
            Set::NonSpace => !is_js_space(c),
        }
    }

    fn matches(
        &self,
        ast: &Ast,
        chars: &[char],
        p: usize,
        k: &mut dyn FnMut(usize) -> bool,
    ) -> bool {
        match ast {
            Ast::Atom(atom) => match self.atom_matches(atom, chars, p) {
                Some(next) => k(next),
                None => false,
            },
            Ast::Seq(nodes) => self.matches_seq(nodes, 0, chars, p, k),
            Ast::Alt(alts) => alts.iter().any(|alt| self.matches(alt, chars, p, k)),
            Ast::Repeat(node, min, max) => self.matches_repeat(node, *min, *max, 0, chars, p, k),
        }
    }

    fn matches_seq(
        &self,
        nodes: &[Ast],
        index: usize,
        chars: &[char],
        p: usize,
        k: &mut dyn FnMut(usize) -> bool,
    ) -> bool {
        if index == nodes.len() {
            return k(p);
        }
        self.matches(&nodes[index], chars, p, &mut |next| {
            self.matches_seq(nodes, index + 1, chars, next, k)
        })
    }

    #[allow(clippy::too_many_arguments)]
    fn matches_repeat(
        &self,
        node: &Ast,
        min: u32,
        max: u32,
        count: u32,
        chars: &[char],
        p: usize,
        k: &mut dyn FnMut(usize) -> bool,
    ) -> bool {
        if count < min {
            return self.matches(node, chars, p, &mut |next| {
                self.matches_repeat(node, min, max, count + 1, chars, next, k)
            });
        }
        if count < max {
            let grown = self.matches(node, chars, p, &mut |next| {
                next != p && self.matches_repeat(node, min, max, count + 1, chars, next, k)
            });
            if grown {
                return true;
            }
        }
        k(p)
    }
}

fn fold(c: char) -> char {
    c.to_lowercase().next().unwrap_or(c)
}

fn fold_upper(c: char) -> char {
    c.to_uppercase().next().unwrap_or(c)
}

fn is_word_char(c: char) -> bool {
    c.is_ascii_alphanumeric() || c == '_'
}

fn is_js_space(c: char) -> bool {
    c.is_whitespace() || c == '\u{feff}'
}

fn is_boundary(chars: &[char], p: usize) -> bool {
    let before = p > 0 && is_word_char(chars[p - 1]);
    let after = p < chars.len() && is_word_char(chars[p]);
    before != after
}

struct Parser<'a> {
    chars: &'a [char],
    pos: usize,
}

impl<'a> Parser<'a> {
    fn peek(&self) -> Option<char> {
        self.chars.get(self.pos).copied()
    }

    fn next(&mut self) -> Option<char> {
        let c = self.peek();
        if c.is_some() {
            self.pos += 1;
        }
        c
    }

    fn expect(&mut self, c: char) -> Result<(), String> {
        if self.next() == Some(c) {
            Ok(())
        } else {
            Err(format!("expected '{}'", c))
        }
    }

    fn parse_alt(&mut self) -> Result<Ast, String> {
        let mut alts = vec![self.parse_seq()?];
        while self.peek() == Some('|') {
            self.pos += 1;
            alts.push(self.parse_seq()?);
        }
        if alts.len() == 1 {
            Ok(alts.pop().unwrap())
        } else {
            Ok(Ast::Alt(alts))
        }
    }

    fn parse_seq(&mut self) -> Result<Ast, String> {
        let mut nodes = Vec::new();
        while let Some(c) = self.peek() {
            if c == '|' || c == ')' {
                break;
            }
            nodes.push(self.parse_piece()?);
        }
        Ok(Ast::Seq(nodes))
    }

    fn parse_piece(&mut self) -> Result<Ast, String> {
        let atom = self.parse_atom()?;
        let (min, max) = match self.peek() {
            Some('?') => {
                self.pos += 1;
                (0, 1)
            }
            Some('*') => {
                self.pos += 1;
                (0, UNLIMITED)
            }
            Some('+') => {
                self.pos += 1;
                (1, UNLIMITED)
            }
            Some('{') => match self.parse_braces()? {
                Some(bounds) => bounds,
                None => return Ok(atom),
            },
            _ => return Ok(atom),
        };
        // Lazy suffix accepted and treated as greedy (unused by our sources).
        if self.peek() == Some('?') {
            self.pos += 1;
        }
        Ok(Ast::Repeat(Box::new(atom), min, max))
    }

    fn parse_braces(&mut self) -> Result<Option<(u32, u32)>, String> {
        let saved = self.pos;
        self.pos += 1; // '{'
        let mut min = String::new();
        while let Some(c) = self.peek() {
            if c.is_ascii_digit() {
                min.push(c);
                self.pos += 1;
            } else {
                break;
            }
        }
        if min.is_empty() {
            self.pos = saved;
            return Ok(None);
        }
        let min: u32 = min.parse().map_err(|_| "bad repeat".to_string())?;
        let max = match self.peek() {
            Some('}') => {
                self.pos += 1;
                min
            }
            Some(',') => {
                self.pos += 1;
                let mut max = String::new();
                while let Some(c) = self.peek() {
                    if c.is_ascii_digit() {
                        max.push(c);
                        self.pos += 1;
                    } else {
                        break;
                    }
                }
                self.expect('}')?;
                if max.is_empty() {
                    UNLIMITED
                } else {
                    max.parse().map_err(|_| "bad repeat".to_string())?
                }
            }
            _ => {
                self.pos = saved;
                return Ok(None);
            }
        };
        Ok(Some((min, max)))
    }

    fn parse_atom(&mut self) -> Result<Ast, String> {
        let c = self.next().ok_or("unexpected end of pattern")?;
        match c {
            '(' => {
                // Non-capturing groups parse like plain groups here.
                if self.peek() == Some('?') {
                    self.pos += 1;
                    self.expect(':')?;
                }
                let inner = self.parse_alt()?;
                self.expect(')')?;
                Ok(inner)
            }
            '[' => self.parse_class(),
            '.' => Ok(Ast::Atom(Atom::Any)),
            '^' => Ok(Ast::Atom(Atom::Start)),
            '$' => Ok(Ast::Atom(Atom::End)),
            '\\' => {
                let escaped = self.parse_escape()?;
                Ok(match escaped {
                    Escaped::Atom(atom) => Ast::Atom(atom),
                    Escaped::Char(ch) => Ast::Atom(Atom::Char(ch)),
                })
            }
            other => Ok(Ast::Atom(Atom::Char(other))),
        }
    }

    fn parse_class(&mut self) -> Result<Ast, String> {
        let negated = if self.peek() == Some('^') {
            self.pos += 1;
            true
        } else {
            false
        };
        let mut items = Vec::new();
        let mut first = true;
        loop {
            let c = self.next().ok_or("unterminated character class")?;
            if c == ']' && !first {
                break;
            }
            first = false;
            let lo = match c {
                '\\' => match self.parse_escape()? {
                    Escaped::Atom(Atom::Set(set)) => {
                        items.push(ClassItem::Set(set));
                        continue;
                    }
                    Escaped::Atom(_) => return Err("unsupported escape in class".to_string()),
                    Escaped::Char(ch) => ch,
                },
                other => other,
            };
            if self.peek() == Some('-')
                && self
                    .chars
                    .get(self.pos + 1)
                    .copied()
                    .map(|c| c != ']')
                    .unwrap_or(false)
            {
                self.pos += 1;
                let hi = self.next().ok_or("unterminated range")?;
                let hi = if hi == '\\' {
                    match self.parse_escape()? {
                        Escaped::Char(ch) => ch,
                        Escaped::Atom(_) => return Err("bad range end".to_string()),
                    }
                } else {
                    hi
                };
                items.push(ClassItem::Range(lo, hi));
            } else {
                items.push(ClassItem::Range(lo, lo));
            }
        }
        Ok(Ast::Atom(Atom::Class { negated, items }))
    }

    fn parse_escape(&mut self) -> Result<Escaped, String> {
        let c = self.next().ok_or("trailing backslash")?;
        Ok(match c {
            'b' => Escaped::Atom(Atom::WordBoundary),
            'B' => Escaped::Atom(Atom::NonWordBoundary),
            'w' => Escaped::Atom(Atom::Set(Set::Word)),
            'W' => Escaped::Atom(Atom::Set(Set::NonWord)),
            'd' => Escaped::Atom(Atom::Set(Set::Digit)),
            'D' => Escaped::Atom(Atom::Set(Set::NonDigit)),
            's' => Escaped::Atom(Atom::Set(Set::Space)),
            'S' => Escaped::Atom(Atom::Set(Set::NonSpace)),
            'n' => Escaped::Char('\n'),
            'r' => Escaped::Char('\r'),
            't' => Escaped::Char('\t'),
            'f' => Escaped::Char('\u{0c}'),
            'v' => Escaped::Char('\u{0b}'),
            '0' => Escaped::Char('\0'),
            'u' => {
                let mut code = 0u32;
                for _ in 0..4 {
                    let d = self.next().ok_or("bad \\u escape")?;
                    code = code * 16 + d.to_digit(16).ok_or("bad \\u escape")?;
                }
                Escaped::Char(char::from_u32(code).ok_or("bad \\u escape")?)
            }
            other => Escaped::Char(other),
        })
    }
}

enum Escaped {
    Atom(Atom),
    Char(char),
}
