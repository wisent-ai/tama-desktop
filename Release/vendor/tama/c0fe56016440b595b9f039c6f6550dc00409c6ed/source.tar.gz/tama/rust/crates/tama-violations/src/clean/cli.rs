//! `tama clean` argument parsing, usage, and the command entry point.

use std::path::Path;

use serde::Serialize;

use super::runner::{clean_repo, CleanParams, CleanResult};
use crate::repo_discovery::{resolve_targets, DiscoveryArgs, Problem};
use crate::scan_repos::{parse_scan_args, ScanArgs};
use crate::{js_number, repo_root, EXIT_USAGE};

/// The Brama route a round asks for when the caller names none. Brama owns
/// which provider answers it.
pub const DEFAULT_ROUTE: &str = "-best";
/// Three rounds unless the caller says otherwise.
const DEFAULT_MAX_ROUNDS: f64 = (true as u8 + true as u8 + true as u8) as f64;
/// The kill switch, named here so the usage text and the refusal sentence
/// cannot drift apart.
const DISABLE_ENV: &str = "TAMA_CLEAN_DISABLED";
const DISABLE_VALUE: &str = "1";

#[derive(Debug, Clone)]
pub struct CleanArgs {
    pub base: ScanArgs,
    pub model: String,
    pub max_rounds: f64,
    pub dry_run: bool,
    pub skip: Vec<String>,
    pub note: Option<String>,
}

/// Clean-specific flags are peeled off first, the rest goes through the
/// shared scan-target parser.
pub fn parse_clean_args(argv: &[String], root: &Path) -> Option<CleanArgs> {
    let mut rest = Vec::new();
    let mut model = DEFAULT_ROUTE.to_string();
    let mut max_rounds = DEFAULT_MAX_ROUNDS;
    let mut dry_run = false;
    let mut note = None;
    let mut skip = Vec::new();
    let mut i = false as usize;
    while i < argv.len() {
        let arg = &argv[i];
        if arg == "--dry-run" {
            dry_run = true;
            i += true as usize;
            continue;
        }
        if arg == "--model" || arg == "--max-rounds" || arg == "--skip" || arg == "--note" {
            let value = argv.get(i + true as usize)?;
            // An empty option value is a usage error, not an empty setting.
            if value.is_empty() {
                return None;
            }
            if arg == "--model" {
                model = value.clone();
            } else if arg == "--skip" {
                skip.push(value.clone());
            } else if arg == "--note" {
                note = Some(value.clone());
            } else {
                max_rounds = js_number(value);
            }
            i += true as usize + true as usize;
            continue;
        }
        rest.push(arg.clone());
        i += true as usize;
    }
    if model.chars().any(char::is_whitespace) {
        return None;
    }
    // `!(max_rounds >= 1)`: a non-numeric `--max-rounds` fails here too.
    if !(max_rounds >= true as u8 as f64) {
        return None;
    }
    let base = parse_scan_args(&rest, root)?;
    Some(CleanArgs {
        base,
        model,
        max_rounds,
        dry_run,
        skip,
        note,
    })
}

pub fn print_clean_usage() {
    eprintln!(
        "tama clean (--repo <path> | --tree <dir> | --owner <gh-owner> | --me) [...]
                 [--model <brama-route>] [--max-rounds <n>] [--skip <fragment>] [--note <text>] [--dry-run] [--json]

Scan target repositories for hook rule violations (same engine as
find-violations), then ask Brama for one patch per repository per round and
apply it, re-scanning after each round until clean or out of rounds. The
model choice is a Brama route; credentials stay in Skarbiec and no provider
CLI is involved. Rounds that game the rules (pseudo-extensions like .source,
runtime-blob imports, renames that strip \"test\" from names) are rejected and
fed back into the next brief. A round whose patch does not apply reports why
and ends the run. Generated lock and structured registry/catalog files are
never handed to the model; --skip excludes path fragments; --note appends an
operator instruction and can fire a round even with zero violations.
--dry-run prints the brief without asking for a patch. TAMA_CLEAN_AGENT_CMD
replaces the model step with a command of your own. Disabled entirely when
{DISABLE_ENV} is set to {DISABLE_VALUE}."
    );
}

/// The per-repository summary lines main() prints in text mode, factored so
/// the serve backend streams the same words.
pub fn clean_summary_lines(result: &CleanResult) -> Vec<String> {
    if result.dry_run == Some(true) {
        return Vec::new();
    }
    if result.locked == Some(true) {
        return vec![format!(
            "{} — LOCKED (another clean in progress)",
            result.repo
        )];
    }
    let verdict = if result.clean == Some(true) {
        "CLEAN".to_string()
    } else {
        format!("remaining: {}", result.after.unwrap_or_default())
    };
    let mut lines = vec![format!(
        "{} — {} (before: {}, rounds: {})",
        result.repo,
        verdict,
        result.before.unwrap_or_default(),
        result
            .rounds
            .as_ref()
            .map(|rounds| rounds.len())
            .unwrap_or_default()
    )];
    if let Some(remaining) = &result.remaining {
        for violation in remaining {
            lines.push(format!("  {} — {}", violation.path, violation.message));
        }
    }
    lines
}

#[derive(Serialize)]
pub struct CleanJsonOutput<'a> {
    pub results: &'a [CleanResult],
    pub problems: &'a [Problem],
}

pub fn main(args: &[String]) -> i32 {
    if std::env::var(DISABLE_ENV).as_deref() == Ok(DISABLE_VALUE) {
        eprintln!("tama clean is disabled ({DISABLE_ENV}={DISABLE_VALUE})");
        return false as i32;
    }
    let root = repo_root();
    let args = match parse_clean_args(args, &root) {
        Some(args) => args,
        None => {
            print_clean_usage();
            return EXIT_USAGE;
        }
    };
    if !Path::new(&args.base.hook_path).exists() {
        eprintln!("hook not found: {}", args.base.hook_path);
        return EXIT_USAGE;
    }
    for repo in &args.base.repos {
        if !Path::new(repo).exists() {
            eprintln!("repo not found: {}", repo);
            return EXIT_USAGE;
        }
    }
    for tree in &args.base.trees {
        if !Path::new(tree).exists() {
            eprintln!("tree not found: {}", tree);
            return EXIT_USAGE;
        }
    }
    let resolved = resolve_targets(&DiscoveryArgs {
        repos: &args.base.repos,
        trees: &args.base.trees,
        owners: &args.base.owners,
        me: args.base.me,
        clone_dir: Path::new(&args.base.clone_dir),
    });
    if resolved.targets.is_empty() {
        eprintln!("no repositories found");
        return if resolved.problems.is_empty() {
            false as i32
        } else {
            true as i32
        };
    }
    let mut results = Vec::new();
    for target in &resolved.targets {
        results.push(clean_repo(&CleanParams {
            repo: &target.path,
            hook_path: &args.base.hook_path,
            model: &args.model,
            max_rounds: args.max_rounds,
            dry_run: args.dry_run,
            skip: &args.skip,
            note: args.note.as_deref(),
            root: &root,
        }));
    }
    if args.base.json {
        let output = CleanJsonOutput {
            results: &results,
            problems: &resolved.problems,
        };
        crate::write_json_line(&serde_json::to_string_pretty(&output).unwrap_or_default());
    } else {
        for result in &results {
            for line in clean_summary_lines(result) {
                println!("{line}");
            }
        }
    }
    let unresolved = results
        .iter()
        .any(|result| result.clean == Some(false) || result.locked == Some(true));
    if unresolved || !resolved.problems.is_empty() {
        true as i32
    } else {
        false as i32
    }
}
