#!/usr/bin/env bash
# Acceptance check for the folder-file limit, driven through the real guard.
#
# Usage: tests/crowded_folders/verify.sh <path to block_crowded_folders.sh>
#
# The guard path is required and never guessed: the installed copy is what
# enforces policy, the copy in shared-hooks/ is what the repository ships, and
# a candidate is what a repair proposal holds. All three must answer these
# payloads the same way, and naming one is how you say which you are accepting.
#
# The limit keeps modules grouped in sub-folders instead of piling up in one
# directory. A manuscript's folder holds the document, its bibliography and the
# venue's style files side by side, and the venue template decides that layout;
# on 2026-09-14 the owner asked that the limit not apply to `.tex`. New source
# in a full folder is refused; new LaTeX-family files are not; a test folder
# was already exempt; and this check keeps all three true after the next repair.
#
# Fixtures are built here rather than committed: a folder holding five files
# cannot be written into this repository while the guard it tests is installed.

set -uo pipefail

guard="${1:-}"
if [[ -z "$guard" ]]; then
  printf '%s\n' 'verify.sh needs the guard script path; there is deliberately no default.' >&2
  exit 2
fi
if [[ ! -x "$guard" ]]; then
  printf 'verify.sh cannot run the guard at %s\n' "$guard" >&2
  exit 2
fi

here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
scratch="$(cd "$here/../.." && pwd)/.live-runtime-tmp/crowded-folders"
rm -rf "$scratch"
mkdir -p "$scratch/full" "$scratch/full/tests"
trap 'rm -rf "$scratch"' EXIT

for n in 1 2 3 4 5; do
  printf 'fn existing_%s() {}\n' "$n" > "$scratch/full/existing_$n.rs"
done

payload_write() {
  printf '{"tool_name":"Write","tool_input":{"file_path":"%s","content":"one line\\n"}}' "$1"
}

failures=0
total=0

check() {
  local payload="$1" expected="$2" label="$3" output status
  total=$((total + 1))
  output="$(printf '%s' "$payload" | "$guard" 2>&1)"
  status=$?
  if [[ "$expected" == 'allow' && "$status" -ne 0 ]]; then
    printf 'FAIL %s: refused, and nothing here crowds what the limit protects\n%s\n' "$label" "$output"
    failures=$((failures + 1))
    return
  fi
  if [[ "$expected" == 'refuse' ]]; then
    if [[ "$status" -eq 0 ]]; then
      printf 'FAIL %s: allowed, and the limit no longer holds for source\n' "$label"
      failures=$((failures + 1))
      return
    fi
    if ! printf '%s' "$output" | grep -q 'max 5'; then
      printf 'FAIL %s: refused without naming the limit\n%s\n' "$label" "$output"
      failures=$((failures + 1))
      return
    fi
  fi
  printf 'ok   %s (%s)\n' "$label" "$expected"
}

check "$(payload_write "$scratch/full/module.rs")" refuse 'a new source module in a folder holding five files'
check "$(payload_write "$scratch/full/existing_1.rs")" allow 'a rewrite of a file the full folder already holds'
check "$(payload_write "$scratch/full/paper.tex")" allow 'a new manuscript in a folder holding five files'
check "$(payload_write "$scratch/full/bibliography.bib")" allow 'a new bibliography in a folder holding five files'
check "$(payload_write "$scratch/full/venue.sty")" allow 'a new style file in a folder holding five files'
check "$(payload_write "$scratch/full/tests/case.rs")" allow 'a new file in a test folder'

if [[ "$failures" -ne 0 ]]; then
  printf '%d of %d cases failed against %s\n' "$failures" "$total" "$guard" >&2
  exit 1
fi
printf '%d of %d cases passed against %s\n' "$total" "$total" "$guard"
