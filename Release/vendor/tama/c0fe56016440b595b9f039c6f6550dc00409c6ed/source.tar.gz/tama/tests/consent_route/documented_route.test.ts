// The consent route, checked from the guard outwards.
//
// `block-hook-config-edits-without-consent` refuses a hook change made from
// inside an agent session and points at two things: a variable that lifts the
// refusal, and a documentation page. On 2026-09-10 the page documented neither,
// so the refusal was a dead end for whoever read it — the route existed in
// scattered CLI leaves and in the source, and nowhere as a route.
//
// These cases read the pointer and the variable out of the live guard rather
// than repeating them, so renaming either in the guard moves the assertion with
// it instead of leaving a stale copy behind.

import { test } from "bun:test";
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const repo = resolve(import.meta.dirname, "../..");
const guardPath = resolve(repo, "shared-hooks/block_hook_config_edits_without_consent.py");
const guard = readFileSync(guardPath, "utf8");

/** The variable the guard actually checks, as the guard spells it. */
function approvalVariable(): string {
  const match = guard.match(/^APPROVAL_ENV\s*=\s*"([^"]+)"/m);
  assert.ok(match, `${guardPath} no longer declares APPROVAL_ENV`);
  return match[1];
}

/** Every page the refusal sends a reader to. */
function documentationUrls(): string[] {
  const block = guard.match(/^DOCS\s*=\s*\(([\s\S]*?)\)/m);
  assert.ok(block, `${guardPath} no longer declares DOCS`);
  const urls = [...block[1].matchAll(/"([^"]+)"/g)].map((match) => match[1]);
  assert.ok(urls.length > 0, "the refusal has to name at least one page");
  return urls;
}

/**
 * Published pages are read where they are published. `TAMA_DOCS_ORIGIN` points
 * the same assertions at a local build, which is how a page is checked before
 * it is live.
 */
function published(url: string): string {
  const origin = process.env.TAMA_DOCS_ORIGIN;
  if (!origin) return url;
  return `${origin.replace(/\/$/, "")}${new URL(url).pathname}`;
}

test("the page the refusal names documents the consent route", async () => {
  const variable = approvalVariable();
  for (const declared of documentationUrls()) {
    const url = published(declared);
    const response = await fetch(url, { redirect: "follow" });
    assert.equal(response.status, 200, `${url} returned ${response.status}`);
    const text = await response.text();
    for (const required of [variable, "tama adaptive repair", "tama adaptive apply"]) {
      assert.ok(
        text.includes(required),
        `${url} is named by the refusal but does not mention ${required}`,
      );
    }
  }
});

test("the refusal itself carries the variable and the page", () => {
  const variable = approvalVariable();
  const payload = JSON.stringify({
    tool_name: "write",
    tool_input: { path: "~/.shared-hooks/some_hook.sh", content: "#!/usr/bin/env bash\n" },
  });
  const environment = { ...process.env };
  delete environment[variable];

  const run = spawnSync("python3", [guardPath], {
    input: payload,
    env: environment,
    encoding: "utf8",
  });

  const said = `${run.stdout ?? ""}${run.stderr ?? ""}`;
  assert.notEqual(run.status, 0, `editing a hook without consent must be refused: ${said}`);
  assert.ok(said.includes(variable), `the refusal has to name the variable: ${said}`);
  for (const url of documentationUrls()) {
    assert.ok(said.includes(url), `the refusal has to name where the route is written: ${said}`);
  }
});

test("consent lets the same edit through", () => {
  const variable = approvalVariable();
  const payload = JSON.stringify({
    tool_name: "write",
    tool_input: { path: "~/.shared-hooks/some_hook.sh", content: "#!/usr/bin/env bash\n" },
  });

  const run = spawnSync("python3", [guardPath], {
    input: payload,
    env: { ...process.env, [variable]: "1" },
    encoding: "utf8",
  });

  assert.equal(
    run.status,
    0,
    `with ${variable}=1 the owner's own edit must pass: ${run.stdout ?? ""}${run.stderr ?? ""}`,
  );
});
