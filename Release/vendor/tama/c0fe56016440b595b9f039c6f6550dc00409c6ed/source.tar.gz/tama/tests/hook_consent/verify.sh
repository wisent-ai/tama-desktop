#!/usr/bin/env bash
# Acceptance check for the hook-consent boundary, driven through the real guard.
#
# Usage: tests/hook_consent/verify.sh <path to block_hook_config_edits_without_consent.py>
#
# The guard path is required and never guessed: the installed copy is what
# enforces policy, the copy in shared-hooks/ is what the repository ships, and a
# candidate is what a repair proposal holds. All three must answer these
# payloads the same way, and naming one is how you say which you are accepting.
#
# The guard refuses a hook change made without the owner's consent, and it
# decides by reading the command text: a protected path plus something that
# looks like a write. Both halves are text, so on 2026-09-10 a recursive search
# over the live hook root was refused for sending its errors to the null device,
# and a search whose quoted pattern listed mutation words was refused for
# quoting them. Neither command can change a byte.
#
# Three payloads here must be allowed: those two searches and a line count over
# the same root. Four must be refused: a copy onto a live hook, an in-place
# stream edit of one, a redirection into one, and the same copy hidden inside a
# quoted interpreter argument. The last one is the reason the fix cannot simply
# ignore quoted text.
#
# The guard is run with the consent variable removed, because with it set every
# payload is allowed by design and the suite would prove nothing.

set -uo pipefail

guard="${1:-}"
if [[ -z "$guard" ]]; then
  printf '%s\n' 'verify.sh needs the guard script path; there is deliberately no default.' >&2
  exit 2
fi
if [[ ! -r "$guard" ]]; then
  printf 'verify.sh cannot read the guard at %s\n' "$guard" >&2
  exit 2
fi

here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
payloads="$here/payloads"
failures=0
total=0

check() {
  local payload="$1" expected="$2" label="$3" output status
  total=$((total + 1))
  output="$(env -u DEVICE_HOOK_EDIT_APPROVED python3 "$guard" < "$payloads/$payload" 2>&1)"
  status=$?
  if [[ "$expected" == 'allow' && "$status" -ne 0 ]]; then
    printf 'FAIL %s: refused, and it changes nothing\n%s\n' "$label" "$output"
    failures=$((failures + 1))
    return
  fi
  if [[ "$expected" == 'refuse' ]]; then
    if [[ "$status" -eq 0 ]]; then
      printf 'FAIL %s: allowed, and it can change a hook\n' "$label"
      failures=$((failures + 1))
      return
    fi
    if ! printf '%s' "$output" | grep -q 'BLOCKED: hook source/config changes are device-level protected.'; then
      printf 'FAIL %s: refused without the consent sentence\n%s\n' "$label" "$output"
      failures=$((failures + 1))
      return
    fi
  fi
  printf 'ok   %s (%s)\n' "$label" "$expected"
}

check allow/search-with-discarded-stderr.json allow 'a search that discards its error stream'
check allow/search-for-write-verbs.json allow 'a search whose pattern lists mutation words'
check allow/line-count-over-the-live-root.json allow 'a line count over the live hook root'
check refuse/copy-into-the-live-root.json refuse 'a copy onto a live hook'
check refuse/in-place-edit.json refuse 'an in-place edit of a live hook'
check refuse/redirect-into-the-live-root.json refuse 'a redirection into a live hook'
check refuse/interpreter-smuggled-copy.json refuse 'the same copy quoted inside an interpreter argument'

if [[ "$failures" -ne 0 ]]; then
  printf '%d of %d cases failed against %s\n' "$failures" "$total" "$guard" >&2
  exit 1
fi
printf '%d of %d cases passed against %s\n' "$total" "$total" "$guard"
