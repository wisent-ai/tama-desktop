#!/usr/bin/env bash
# Acceptance check for the browser boundary, driven through the real guard.
#
# Usage: tests/browser_guard/verify.sh <path to block_browser_usage.sh>
#
# The guard path is required and never guessed: the installed copy under
# ~/.shared-hooks is what enforces policy, the copy in shared-hooks/ is what
# the repository ships, and a candidate under .wisent-output/ is what a repair
# proposal holds. All three must answer the four payloads beside this script
# the same way, and pointing the check at one of them is how you say which one
# you are accepting.
#
# Each payload is the real tool payload a hook receives on stdin. Three must be
# allowed — naming the patched-browser source repositories, editing inside one
# of them, and a commit whose message happens to end a sentence with one of the
# words a driver API also uses — and three must be refused: the engine built
# under such a checkout, a plain engine launch, and a script calling a driver
# handle. The pairing is the point: an allowance only holds if the refusals
# still hold with it.

set -uo pipefail

guard="${1:-}"
if [[ -z "$guard" ]]; then
  printf '%s\n' 'verify.sh needs the guard script path; there is deliberately no default.' >&2
  exit 2
fi
if [[ ! -r "$guard" ]]; then
  printf 'verify.sh cannot read the guard at %s\n' "$guard" >&2
  exit 2
fi

here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
payloads="$here/payloads"
failures=0
total=0

check() {
  local payload="$1" expected="$2" label="$3" output status
  total=$((total + 1))
  output="$(bash "$guard" < "$payloads/$payload" 2>&1)"
  status=$?
  if [[ "$expected" == 'allow' && "$status" -ne 0 ]]; then
    printf 'FAIL %s: refused, and it must be allowed\n%s\n' "$label" "$output"
    failures=$((failures + 1))
    return
  fi
  if [[ "$expected" == 'refuse' ]]; then
    if [[ "$status" -eq 0 ]]; then
      printf 'FAIL %s: allowed, and it must be refused\n' "$label"
      failures=$((failures + 1))
      return
    fi
    if ! printf '%s' "$output" | grep -q 'BLOCKED: direct browser use is forbidden.'; then
      printf 'FAIL %s: refused without the boundary sentence\n%s\n' "$label" "$output"
      failures=$((failures + 1))
      return
    fi
  fi
  printf 'ok   %s (%s)\n' "$label" "$expected"
}

check case-repository-names.json allow 'a compound git command naming both source repositories'
check case-edit-in-repository.json allow 'an edit inside one of those repositories'
check case-commit-message-prose.json allow 'a commit message ending a sentence with a driver word'
check case-built-browser-launch.json refuse 'the engine built under one of those checkouts'
check case-bare-engine-launch.json refuse 'a plain engine launch'
check case-driver-api-call.json refuse 'a script calling a driver handle'

if [[ "$failures" -ne 0 ]]; then
  printf '%d of %d cases failed against %s\n' "$failures" "$total" "$guard" >&2
  exit 1
fi
printf '%d of %d cases passed against %s\n' "$total" "$total" "$guard"
