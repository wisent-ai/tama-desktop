-- A scratch copy of the tables the claimed-work guard reads from the Oko
-- index: one task given in session feed-session, claimed by the session the
-- suite's stop payload names, with nothing recorded for it yet.
CREATE TABLE IF NOT EXISTS operator_messages (
    sessionId TEXT NOT NULL,
    ordinal   INTEGER NOT NULL,
    uuid      TEXT,
    at        INTEGER,
    text      TEXT NOT NULL,
    PRIMARY KEY (sessionId, ordinal)
);
CREATE TABLE IF NOT EXISTS task_claims (
    sessionKey TEXT NOT NULL,
    ordinal    INTEGER NOT NULL,
    claimed_by TEXT NOT NULL,
    claimed_at INTEGER NOT NULL,
    PRIMARY KEY (sessionKey, ordinal)
);
CREATE TABLE IF NOT EXISTS task_evidence (
    sessionKey  TEXT NOT NULL,
    ordinal     INTEGER NOT NULL,
    commit_ref  TEXT,
    report      TEXT,
    recorded_by TEXT NOT NULL,
    recorded_at INTEGER NOT NULL,
    PRIMARY KEY (sessionKey, ordinal)
);
INSERT INTO operator_messages(sessionId, ordinal, uuid, at, text)
VALUES ('2026-09-10T00-00-00-000Z_feed-session', 3, 'm3', 1789150000, 'usun wszystkie katalogi robocze');
INSERT INTO task_claims(sessionKey, ordinal, claimed_by, claimed_at)
VALUES ('feed-session', 3, 'assignment-suite', 1789150100);
