-- The leading session records what it did. The guard releases; the task
-- itself stays open until the operator's word.
INSERT INTO task_evidence(sessionKey, ordinal, commit_ref, report, recorded_by, recorded_at)
VALUES ('feed-session', 3, 'abc1234', NULL, 'assignment-suite', 1789150200);
