#!/usr/bin/env bash
# Acceptance check for the standing-assignment loop, driven through the real
# hook binaries.
#
# Usage: tests/assignment/verify.sh <directory holding the built binaries>
#
# The directory is required and never guessed: the copy under
# rust/target/{debug,release} is what a developer just built, the copy in a
# staged hook release is what an install would put on the machine, and both
# have to answer these payloads the same way. Naming one is how you say which
# you are accepting.
#
# The incident this defends: thirty-two hours into a session, asked what its
# task was, an agent answered with the session's first request - finished the
# night before - because the middle of the session had been trimmed out of its
# context window. Every existing stop guard passed that turn: the task list
# held no open work, the answer was grounded in the session, and it gave the
# user no homework. It was still an answer to the wrong instruction.
#
# So the loop is: the operator speaks and the instruction is written down
# verbatim; ending a turn without reading the newest one is refused; reading it
# through `tama assignment show` clears the refusal; a newer instruction
# supersedes the previous one and the refusal returns. This suite drives that
# loop against its own state file and never touches the operator's.

set -uo pipefail

bins="${1:-}"
if [[ -z "$bins" ]]; then
  printf '%s\n' 'verify.sh needs the directory holding the built binaries; there is deliberately no default.' >&2
  exit 2
fi
for binary in tama-record-current-assignment tama-block-stale-assignment tama-block-stop-with-claimed-work tama-cli; do
  if [[ ! -x "$bins/$binary" ]]; then
    printf 'verify.sh cannot run %s/%s\n' "$bins" "$binary" >&2
    exit 2
  fi
done

here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
payloads="$here/payloads"
state="$(mktemp -d "${here%/tests/assignment}/.wisent-output/assignment-suite.XXXXXX")"
export TAMA_ASSIGNMENT_STATE="$state/current-assignment.json"
trap 'rm -rf "$state"' EXIT

failures=0
total=0

record() {
  "$bins/tama-record-current-assignment" < "$payloads/$1" >/dev/null 2>&1
}

stop_decision() {
  "$bins/tama-block-stale-assignment" < "$payloads/turn-ending.json" 2>&1
}

check() {
  local label="$1" expected="$2" output="$3"
  total=$((total + 1))
  case "$expected" in
    refuse)
      if ! printf '%s' "$output" | grep -q '"decision":"block"'; then
        printf 'FAIL %s: the turn was allowed to end on a stale instruction\n%s\n' "$label" "$output"
        failures=$((failures + 1))
        return
      fi
      ;;
    allow)
      if printf '%s' "$output" | grep -q '"decision":"block"'; then
        printf 'FAIL %s: refused, and there is nothing unread\n%s\n' "$label" "$output"
        failures=$((failures + 1))
        return
      fi
      ;;
  esac
  printf 'ok   %s (%s)\n' "$label" "$expected"
}

# Nothing recorded: no evidence, no denial.
check 'a machine with no recorded instruction' allow "$(stop_decision)"

record first-instruction.json
first="$(stop_decision)"
check 'a turn ending without reading the instruction' refuse "$first"
total=$((total + 1))
if printf '%s' "$first" | grep -q 'dopisane do naszej bazy'; then
  printf 'ok   the refusal quotes the instruction verbatim (refuse)\n'
else
  printf 'FAIL the refusal has to quote the instruction, or it restores nothing\n%s\n' "$first"
  failures=$((failures + 1))
fi

"$bins/tama-cli" assignment show >/dev/null 2>&1
check 'a turn ending after reading it' allow "$(stop_decision)"

record newer-instruction.json
newer="$(stop_decision)"
check 'a newer instruction superseding the read one' refuse "$newer"
total=$((total + 1))
if printf '%s' "$newer" | grep -q 'petle sprzezenia zwrotnego'; then
  printf 'ok   the refusal quotes the newest instruction, not the old one (refuse)\n'
else
  printf 'FAIL the refusal quotes the wrong instruction\n%s\n' "$newer"
  failures=$((failures + 1))
fi

"$bins/tama-cli" assignment show >/dev/null 2>&1
check 'a turn ending after reading the newer one' allow "$(stop_decision)"

# One session leads a task given in another. Until it has shown something
# for it, the turn may not end; evidence releases the guard, and the task
# stays open for the operator's word.
export OKO_TRANSCRIPT_INDEX_PATH="$state/transcript-index.sqlite"
claimed_decision() {
  "$bins/tama-block-stop-with-claimed-work" < "$payloads/turn-ending.json" 2>&1
}
check 'a session that leads no task' allow "$(claimed_decision)"
sqlite3 "$OKO_TRANSCRIPT_INDEX_PATH" < "$here/fixtures/claimed-ledger.sql"
claimed="$(claimed_decision)"
check 'a led task with no evidence' refuse "$claimed"
total=$((total + 1))
if printf '%s' "$claimed" | grep -q 'feed-session #3: usun wszystkie katalogi robocze'; then
  printf 'ok   the refusal names the task in the operator'"'"'s words (refuse)\n'
else
  printf 'FAIL the refusal has to name the task it is holding the turn for\n%s\n' "$claimed"
  failures=$((failures + 1))
fi
sqlite3 "$OKO_TRANSCRIPT_INDEX_PATH" < "$here/fixtures/claimed-ledger-evidence.sql"
check 'a led task with evidence recorded' allow "$(claimed_decision)"

if [[ "$failures" -ne 0 ]]; then
  printf '%d of %d cases failed against %s\n' "$failures" "$total" "$bins" >&2
  exit 1
fi
printf '%d of %d cases passed against %s\n' "$total" "$total" "$bins"
