import { test } from "bun:test";
import assert from "node:assert/strict";
import { createHash, randomUUID } from "node:crypto";
import { appendFileSync, existsSync, mkdirSync, readFileSync, renameSync, symlinkSync, writeFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { spawnSync } from "node:child_process";
import type { AgentSession, AuthStorage } from "@oh-my-pi/pi-coding-agent";
import { z } from "zod";

const repo = resolve(import.meta.dir, "../..");
const sha256 = (value: string | Buffer) => createHash("sha256").update(value).digest("hex");
const quote = (value: string) => `'${value.replaceAll("'", "'\\''")}'`;
type Json = string | number | boolean | null | Json[] | { [key: string]: Json };
const coreSchema = z.object({ processId: z.number().int() });
const statusSchema = z.object({
  sessionId: z.string(), loadedReleaseId: z.string(), reloadRequired: z.boolean(),
  core: coreSchema.nullish(),
});
const replySchema = z.object({ isError: z.boolean().optional(), details: z.unknown() });
const recordSchema = z.object({ pid: z.number().int(), runtime: z.object({ loadedReleaseId: z.string() }) });
type Outcome = { passed: boolean; error?: string; sessionId?: string; processId?: number; coreProcessId?: number };

function stable(value: Json): Json {
  if (Array.isArray(value)) return value.map(stable);
  if (!value || typeof value !== "object") return value;
  return Object.fromEntries(Object.keys(value).sort().map(key => [key, stable(value[key])]));
}

function publish(root: string, releaseId: string, program: string, input: string, extraEvents: Record<string, Json> = {}) {
  const catalog = {
    releaseId,
    events: {
      ...extraEvents,
      "pre_tool_use:read": {
        blocking: true,
        hooks: [{
          id: "persist-observation",
          command: `${program} ${quote(join(root, input))} ${quote(join(root, "observation.txt"))}`,
        }],
      },
    },
  };
  const registry = { ...catalog, catalogChecksum: sha256(JSON.stringify(stable(catalog))) };
  writeFileSync(join(root, "registry.pending"), JSON.stringify(registry));
  renameSync(join(root, "registry.pending"), join(root, "registry.json"));
  writeFileSync(join(root, "runtime/installed.json"), JSON.stringify({
    releaseId, catalogChecksum: registry.catalogChecksum,
  }));
}

test("OMP reload executes replacement hooks without replacing the session or inserting a prompt", async () => {
  const root = join(repo, "rust/target/omp-runtime-evidence", randomUUID());
  const native = resolve(process.env.TAMA_TEST_NATIVE_BINARY || join(repo, "rust/target/debug/tama-run-hook"));
  const adapter = resolve(process.env.TAMA_TEST_OMP_ADAPTER || join(repo, "shared-hooks/omp-shared-hooks.js"));
  const releaseManifest = join(dirname(dirname(native)), "release.json");
  mkdirSync(join(root, "runtime/current/bin"), { recursive: true });
  mkdirSync(join(root, "reports"));
  mkdirSync(join(root, "agent"));
  symlinkSync(native, join(root, "runtime/current/bin/tama-run-hook"));
  writeFileSync(join(root, "first.txt"), "first hook execution");
  writeFileSync(join(root, "replacement.txt"), "replacement hook execution");
  writeFileSync(join(root, "recovered.txt"), "recovered hook execution");
  writeFileSync(join(root, "read-target.txt"), "real OMP read target");
  publish(root, "release-a", "/bin/cp", "first.txt");
  const revision = spawnSync("git", ["rev-parse", "HEAD"], { cwd: repo, encoding: "utf8" });
  assert.equal(revision.status, 0, revision.stderr);
  writeFileSync(join(root, "reports/run.json"), JSON.stringify({
    sourceRevision: revision.stdout.trim(), adapter, adapterSha256: sha256(readFileSync(adapter)),
    native, nativeSha256: sha256(readFileSync(native)), processId: process.pid,
    nativeRelease: existsSync(releaseManifest) ? JSON.parse(readFileSync(releaseManifest, "utf8")) : null,
    command: "npm run test:omp-runtime", bunVersion: Bun.version,
  }, null, 2));

  // This process owns one isolated SDK session. No operator settings or
  // credentials are read, and the test never replaces a provider or harness.
  const originalEnv = { ...process.env };
  const isolatedEnv = {
    PATH: process.env.PATH!, HOME: root, PI_CODING_AGENT_DIR: join(root, "agent"),
    AGENT_HOOK_REGISTRY: join(root, "registry.json"),
    TAMA_INSTALLED_HOOK_RELEASE: join(root, "runtime/installed.json"),
    TAMA_SESSION_CONTROL_ROOT: join(root, "control"),
    TAMA_EMERGENCY_STATE: join(root, "emergency.json"),
    TAMA_HOOK_ENFORCEMENT: join(root, "enforcement.json"),
    OMP_TAMA_EVIDENCE_LOG: join(root, "reports/hooks.jsonl"),
  };
  for (const key of Object.keys(process.env)) delete process.env[key];
  Object.assign(process.env, isolatedEnv);
  let session: AgentSession | undefined;
  let authStorage: AuthStorage | undefined;
  let outcome: Outcome = { passed: false };
  const runtimeErrors: unknown[] = [];
  const recordRuntimeError = (error: unknown) => {
    runtimeErrors.push(error);
    appendFileSync(join(root, "reports/runtime-errors.jsonl"), JSON.stringify(error) + "\n");
  };
  try {
    const sdk = await import("@oh-my-pi/pi-coding-agent");
    const settings = sdk.Settings.isolated({
      "memory.backend": "off", "advisor.enabled": false, "autolearn.enabled": false,
      "tools.xdev": false, "ttsr.enabled": false,
    });
    authStorage = await sdk.discoverAuthStorage(join(root, "agent"));
    const modelRegistry = new sdk.ModelRegistry(authStorage, join(root, "agent/models.yml"), { settings });
    const sessionManager = sdk.SessionManager.create(root, join(root, "sessions"));
    const created = await sdk.createAgentSession({
      cwd: root, agentDir: join(root, "agent"), sessionManager, settings,
      authStorage, modelRegistry, agentRegistry: new sdk.AgentRegistry(),
      additionalExtensionPaths: [adapter], disableExtensionDiscovery: true,
      toolNames: ["read", "bash"], enableMCP: false, enableLsp: false, enableIrc: false,
      skills: [], rules: [], contextFiles: [], promptTemplates: [], slashCommands: [],
      preloadedCustomToolPaths: [], skipPythonPreflight: true,
    });
    session = created.session;
    const activeSession = session;
    const { initializeExtensions } = await import("@oh-my-pi/pi-coding-agent/modes/runtime-init");
    await initializeExtensions(activeSession, {
      mode: "print",
      reportSendError: (action, error) => recordRuntimeError({ action, error: error.message }),
      reportRuntimeError: recordRuntimeError,
    });
    assert.deepEqual(created.extensionsResult.errors, [], "the real adapter must load");
    const sessionId = activeSession.sessionId;
    const pid = process.pid;
    const call = async (name: string, input: object = {}) => {
      const tool = activeSession.getToolByName(name);
      assert.ok(tool, `real OMP tool is missing: ${name}`);
      const id = randomUUID();
      appendFileSync(join(root, "reports/tools.jsonl"), JSON.stringify({ id, name, input }) + "\n");
      try {
        const result = await tool.execute(id, input);
        appendFileSync(join(root, "reports/tools.jsonl"), JSON.stringify({ id, result }) + "\n");
        return replySchema.parse(result);
      } catch (error) {
        appendFileSync(join(root, "reports/tools.jsonl"), JSON.stringify({ id, error: String(error) }) + "\n");
        throw error;
      }
    };
    const readTarget = () => call("read", { path: join(root, "read-target.txt") });
    const before = statusSchema.parse((await call("tama_hook_runtime_status")).details);
    await readTarget();
    assert.equal(readFileSync(join(root, "observation.txt"), "utf8"), "first hook execution");

    publish(root, "release-b", "/bin/mv", "replacement.txt");
    const reloaded = await call("tama_reload_hook_runtime");
    await readTarget();
    assert.equal(readFileSync(join(root, "observation.txt"), "utf8"), "replacement hook execution");
    assert.equal(existsSync(join(root, "replacement.txt")), false, "the replacement move command must execute");
    assert.equal(reloaded.isError, false);
    assert.equal(activeSession.sessionId, sessionId);
    assert.equal(process.pid, pid);
    assert.ok(before.core, "status must identify the actual shared core");
    const reloadDetails = z.object({ core: coreSchema }).parse(reloaded.details);
    assert.equal(reloadDetails.core.processId, before.core.processId);
    const insertedPrompt = sessionManager.getBranch().some(entry =>
      entry.type === "message" && entry.message.role === "user"
      && JSON.stringify(entry.message.content).includes("/tama_reload_hook_runtime"));
    assert.equal(insertedPrompt, false, "reload must not insert a user prompt");

    writeFileSync(join(root, "registry.json"), "{\"events\":\n");
    await assert.rejects(readTarget, /registry/i);
    assert.equal(readFileSync(join(root, "observation.txt"), "utf8"), "replacement hook execution");
    publish(root, "release-c", "/bin/cp", "recovered.txt");
    await readTarget();
    assert.equal(readFileSync(join(root, "observation.txt"), "utf8"), "recovered hook execution");
    const after = statusSchema.parse((await call("tama_hook_runtime_status")).details);
    assert.equal(after.core?.processId, before.core.processId);
    assert.equal(after.loadedReleaseId, "release-c");
    assert.equal(after.reloadRequired, false);
    assert.equal(activeSession.sessionId, sessionId);
    const key = sha256(`omp\0${sessionId}`);
    const published = recordSchema.parse(JSON.parse(readFileSync(join(root, "control", `${key}.session.json`), "utf8")));
    assert.equal(published.pid, pid, "the core must not take ownership of the OMP session record");
    assert.equal(published.runtime.loadedReleaseId, "release-c");

    // A hook may enforce only its own rule. The shared engine must identify
    // the actual refusing hook, rather than hiding it inside another gate.
    const sourceRepo = join(root, "source-repository");
    const copiedRepo = join(root, "forbidden-repository-copy");
    const initialized = spawnSync("git", ["init", "--quiet", sourceRepo], { cwd: root, encoding: "utf8" });
    assert.equal(initialized.status, 0, initialized.stderr);
    writeFileSync(join(sourceRepo, "content.txt"), "isolated repository input");
    const hookIds = ["block-background-execution", "block-repository-copies"];
    publish(root, "release-d", "/bin/cp", "recovered.txt", {
      "pre_tool_use:bash": {
        blocking: true,
        hooks: hookIds.map(id => ({ id, command: quote(join(dirname(native), `tama-${id}`)) })),
      },
    });
    await assert.rejects(
      () => call("bash", { command: `cp -R ${quote(sourceRepo)} ${quote(copiedRepo)}` }),
      (error: unknown) => {
        assert.ok(error instanceof Error);
        assert.match(error.message, /^block-repository-copies:/);
        return true;
      },
    );
    assert.equal(existsSync(copiedRepo), false, "the rejected tool must not copy the repository");
    assert.deepEqual(runtimeErrors, [], "the real OMP extension runtime must report no hidden failures");
    outcome = { passed: true, sessionId, processId: pid, coreProcessId: after.core?.processId };
  } catch (error) {
    outcome.error = error instanceof Error ? error.stack : String(error);
    throw error;
  } finally {
    try { await session?.dispose(); } finally {
      await authStorage?.close();
      for (const key of Object.keys(process.env)) delete process.env[key];
      Object.assign(process.env, originalEnv);
      writeFileSync(join(root, "reports/result.json"), JSON.stringify(outcome, null, 2));
      console.log(`OMP runtime evidence: ${join(root, "reports")}`);
    }
  }
}, 120_000);
