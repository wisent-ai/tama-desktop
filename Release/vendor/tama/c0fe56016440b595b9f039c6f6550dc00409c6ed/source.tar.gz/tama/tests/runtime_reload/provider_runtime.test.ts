import { test } from "bun:test";
import assert from "node:assert/strict";
import { createHash, randomUUID } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, rmSync, symlinkSync, writeFileSync } from "node:fs";
import { join, resolve } from "node:path";
import { spawnSync } from "node:child_process";

const repo = resolve(import.meta.dir, "../..");
const sha256 = (value: string | Buffer) => createHash("sha256").update(value).digest("hex");

test("provider entrypoints enforce the shared catalog and refuse an unavailable native engine", () => {
  const root = join(repo, "rust/target/provider-runtime-evidence", randomUUID());
  const native = resolve(process.env.TAMA_TEST_NATIVE_BINARY || join(repo, "rust/target/debug/tama-run-hook"));
  const adapter = resolve(process.env.TAMA_TEST_PROVIDER_ADAPTER || join(repo, "shared-hooks/run-hook.mjs"));
  const link = join(root, "runtime/current/bin/tama-run-hook");
  mkdirSync(join(root, "runtime/current/bin"), { recursive: true });
  mkdirSync(join(root, "reports"));
  symlinkSync(native, link);
  writeFileSync(join(root, "input.txt"), "real provider hook execution");
  const catalog = {
    events: {
      "pre_tool_use:read": {
        blocking: true,
        hooks: [{
          command: `/bin/cp ${JSON.stringify(join(root, "input.txt"))} ${JSON.stringify(join(root, "observation.txt"))}`,
          id: "persist-observation",
        }],
      },
    },
    releaseId: "provider-test",
  };
  const registry = { ...catalog, catalogChecksum: sha256(JSON.stringify(catalog)) };
  const registryPath = join(root, "registry.json");
  const revision = spawnSync("git", ["rev-parse", "HEAD"], { cwd: repo, encoding: "utf8" });
  assert.equal(revision.status, 0, revision.stderr);
  writeFileSync(join(root, "reports/run.json"), JSON.stringify({
    sourceRevision: revision.stdout.trim(), adapter, adapterSha256: sha256(readFileSync(adapter)),
    native, nativeSha256: sha256(readFileSync(native)), command: "npm run test:provider-runtime",
  }, null, 2));
  const invoke = (provider: string, name: string) => {
    const args = [adapter, "pre_tool_use:read", provider];
    const input = JSON.stringify({ session_id: "provider-session", tool_name: "read", cwd: root });
    const output = spawnSync("node", args, {
      cwd: root, input, encoding: "utf8",
      env: {
        PATH: process.env.PATH, HOME: root, AGENT_HOOK_REGISTRY: registryPath,
        TAMA_INSTALLED_HOOK_RELEASE: join(root, "runtime/installed.json"),
        TAMA_SESSION_CONTROL_ROOT: join(root, "control"),
        TAMA_EMERGENCY_STATE: join(root, "emergency.json"),
        TAMA_HOOK_ENFORCEMENT: join(root, "enforcement.json"),
      },
    });
    writeFileSync(join(root, "reports", `${provider}-${name}.json`), JSON.stringify({
      args, input, status: output.status, signal: output.signal,
      stdout: output.stdout, stderr: output.stderr, error: output.error?.message,
    }, null, 2));
    assert.equal(output.error, undefined, "the real Node process must complete");
    return output;
  };
  try {
    for (const provider of ["claude", "codex"]) {
      writeFileSync(registryPath, JSON.stringify(registry));
      const valid = invoke(provider, "valid");
      assert.equal(valid.status, 0, valid.stderr);
      assert.equal(readFileSync(join(root, "observation.txt"), "utf8"), "real provider hook execution");
      rmSync(join(root, "observation.txt"));
      writeFileSync(registryPath, JSON.stringify({ ...registry, catalogChecksum: "invalid" }));
      const rejected = invoke(provider, "invalid-checksum");
      assert.equal(existsSync(join(root, "observation.txt")), false, "a rejected catalog must execute no hook");
      assert.notEqual(rejected.status, 0);
      assert.match(rejected.stderr, /checksum mismatch/);
    }
    writeFileSync(registryPath, JSON.stringify(registry));
    rmSync(link);
    const missing = invoke("claude", "missing-engine");
    assert.notEqual(missing.status, 0);
    assert.match(missing.stderr, /tama-run-hook.*ENOENT/);
    assert.equal(existsSync(join(root, "observation.txt")), false);
    writeFileSync(join(root, "reports/result.json"), JSON.stringify({ passed: true }));
  } catch (error) {
    writeFileSync(join(root, "reports/result.json"), JSON.stringify({ passed: false, error: String(error) }));
    throw error;
  } finally {
    console.log(`Provider runtime evidence: ${join(root, "reports")}`);
  }
}, 120_000);
