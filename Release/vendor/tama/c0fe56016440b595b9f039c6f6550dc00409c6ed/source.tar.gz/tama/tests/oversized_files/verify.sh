#!/usr/bin/env bash
# Acceptance check for the file-line limit, driven through the real guard.
#
# Usage: tests/oversized_files/verify.sh <path to block_oversized_files.sh>
#
# The guard path is required and never guessed: the installed copy is what
# enforces policy, the copy in shared-hooks/ is what the repository ships, and
# a candidate is what a repair proposal holds. All three must answer these
# payloads the same way, and naming one is how you say which you are accepting.
#
# The limit exists for source a person edits and navigates. A registry is a
# list, not a module: `test_justifications.json` and `file_justifications.json`
# grow one entry per decision and the hooks themselves read them, so "split
# into smaller modules" was an instruction nobody could follow, and on
# 2026-09-10 it left the owner unable to record the justification his own gates
# demanded. A manuscript is one document, not a module tree: its length is set
# by the venue, and on 2026-09-14 the owner asked that the limit not apply to
# `.tex`. Structured data files and the LaTeX family are exempt; source is not,
# and this check is what keeps all three halves true after the next repair.
#
# Fixtures are built here rather than committed: a three-hundred-line source
# fixture cannot be written into this repository while the guard it tests is
# installed.

set -uo pipefail

guard="${1:-}"
if [[ -z "$guard" ]]; then
  printf '%s\n' 'verify.sh needs the guard script path; there is deliberately no default.' >&2
  exit 2
fi
if [[ ! -x "$guard" ]]; then
  printf 'verify.sh cannot run the guard at %s\n' "$guard" >&2
  exit 2
fi

here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
scratch="$(cd "$here/../.." && pwd)/.live-runtime-tmp/oversized-files"
rm -rf "$scratch"
mkdir -p "$scratch"
trap 'rm -rf "$scratch"' EXIT

long_lines=400
registry="$scratch/registry.json"
module="$scratch/module.rs"
manuscript="$scratch/paper.tex"
printf '{\n' > "$registry"
printf '  "entry-%s": "value",\n' $(seq "$long_lines") >> "$registry"
printf '  "last": "value"\n}\n' >> "$registry"
printf 'fn line_%s() {}\n' $(seq "$long_lines") > "$module"
printf 'Paragraph %s of the manuscript.\n' $(seq "$long_lines") > "$manuscript"

body=""
for _ in $(seq "$long_lines"); do
  body+='line\n'
done

payload_write() {
  printf '{"tool_name":"Write","tool_input":{"file_path":"%s","content":"%s"}}' "$1" "$body"
}
payload_edit() {
  printf '{"tool_name":"Edit","tool_input":{"file_path":"%s","old_string":"a","new_string":"b"}}' "$1"
}

failures=0
total=0

check() {
  local payload="$1" expected="$2" label="$3" output status
  total=$((total + 1))
  output="$(printf '%s' "$payload" | "$guard" 2>&1)"
  status=$?
  if [[ "$expected" == 'allow' && "$status" -ne 0 ]]; then
    printf 'FAIL %s: refused, and nothing here exceeds what the limit protects\n%s\n' "$label" "$output"
    failures=$((failures + 1))
    return
  fi
  if [[ "$expected" == 'refuse' ]]; then
    if [[ "$status" -eq 0 ]]; then
      printf 'FAIL %s: allowed, and the limit no longer holds for source\n' "$label"
      failures=$((failures + 1))
      return
    fi
    if ! printf '%s' "$output" | grep -q 'max 300'; then
      printf 'FAIL %s: refused without naming the limit\n%s\n' "$label" "$output"
      failures=$((failures + 1))
      return
    fi
  fi
  printf 'ok   %s (%s)\n' "$label" "$expected"
}

check "$(payload_edit "$registry")" allow 'an edit of a registry longer than the limit'
check "$(payload_write "$registry")" allow 'a registry written longer than the limit'
check "$(payload_write "$scratch/notes.jsonl")" allow 'a line-delimited data file over the limit'
check "$(payload_edit "$manuscript")" allow 'an edit of a manuscript longer than the limit'
check "$(payload_write "$manuscript")" allow 'a manuscript written longer than the limit'
check "$(payload_write "$scratch/bibliography.bib")" allow 'a bibliography written longer than the limit'
check "$(payload_edit "$module")" refuse 'an edit of a source module over the limit'
check "$(payload_write "$module")" refuse 'a source module written over the limit'

if [[ "$failures" -ne 0 ]]; then
  printf '%d of %d cases failed against %s\n' "$failures" "$total" "$guard" >&2
  exit 1
fi
printf '%d of %d cases passed against %s\n' "$total" "$total" "$guard"
