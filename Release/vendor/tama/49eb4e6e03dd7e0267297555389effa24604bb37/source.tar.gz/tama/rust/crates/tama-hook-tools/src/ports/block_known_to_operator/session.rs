//! What this session has already said: the operator's own words and every
//! earlier answer the agent gave him, read out of the live transcript.
//!
//! Split out of `mod.rs`, which keeps the judgement. Finding the file and
//! reducing its records to the two voices is here.
//!
//! Transcript shape (`~/.omp/agent/sessions/**/*.jsonl`, one JSON object per
//! line): `{ type, message: { role, content: [...] } }`. A user-role record
//! the harness injected — a todo reminder, a hook continuation — carries
//! `attribution: "agent"` and is not the operator speaking.

use std::path::PathBuf;

use serde_json::Value;
use tama_hooks::session_record::{session_id_of, transcript_path};

const TRANSCRIPT_PATH_KEY: &str = "transcript_path";
const MESSAGE_KEY: &str = "message";
const ROLE_KEY: &str = "role";
const CONTENT_KEY: &str = "content";
const TYPE_KEY: &str = "type";
const TEXT_KEY: &str = "text";
const ATTRIBUTION_KEY: &str = "attribution";
const AGENT_ATTRIBUTION: &str = "agent";
const USER_ROLE: &str = "user";
const ASSISTANT_ROLE: &str = "assistant";

/// The two voices of the session before the answer under judgement.
#[derive(Debug, Default, PartialEq, Eq)]
pub(crate) struct Said {
    /// The operator's messages, oldest first.
    pub operator: Vec<String>,
    /// The agent's earlier prose answers, oldest first, the final one
    /// excluded.
    pub told: Vec<String>,
    /// How many transcript records were read; for the log.
    pub records: usize,
}

impl Said {
    /// Nothing to compare an answer against: no words of the operator and
    /// nothing told before. Such a session cannot know anything yet.
    pub fn is_empty(&self) -> bool {
        self.operator.is_empty() && self.told.is_empty()
    }
}

/// The transcript the payload names, or the newest one of its session.
pub(crate) fn locate(payload: &Value) -> Option<PathBuf> {
    if let Some(path) = payload.get(TRANSCRIPT_PATH_KEY).and_then(Value::as_str) {
        if !path.is_empty() {
            return Some(PathBuf::from(path));
        }
    }
    transcript_path(&session_id_of(payload))
}

/// The prose of one record: its text parts, or its string content.
fn prose(message: &Value) -> String {
    match message.get(CONTENT_KEY) {
        Some(Value::String(text)) => text.clone(),
        Some(Value::Array(items)) => items
            .iter()
            .filter(|item| item.get(TYPE_KEY).and_then(Value::as_str) == Some(TEXT_KEY))
            .filter_map(|item| item.get(TEXT_KEY).and_then(Value::as_str))
            .collect::<Vec<_>>()
            .join("\n"),
        _ => String::new(),
    }
}

/// The two voices, read out of a transcript's text. `final_message` is the
/// answer under judgement: the last assistant record that says it is not
/// something told before, so it is left out of `told`.
pub(crate) fn read(raw: &str, final_message: &str) -> Said {
    let mut said = Said::default();
    let mut assistant: Vec<String> = Vec::new();
    for line in raw.lines() {
        let Ok(record) = serde_json::from_str::<Value>(line) else {
            continue;
        };
        said.records += usize::from(true);
        let message = record.get(MESSAGE_KEY).unwrap_or(&record);
        let role = message
            .get(ROLE_KEY)
            .and_then(Value::as_str)
            .unwrap_or_default();
        let text = prose(message);
        if text.trim().is_empty() {
            continue;
        }
        if role == USER_ROLE {
            if message.get(ATTRIBUTION_KEY).and_then(Value::as_str) != Some(AGENT_ATTRIBUTION) {
                said.operator.push(text);
            }
        } else if role == ASSISTANT_ROLE {
            assistant.push(text);
        }
    }
    if assistant
        .last()
        .is_some_and(|last| last.trim() == final_message.trim())
    {
        assistant.pop();
    }
    said.told = assistant;
    said
}

#[cfg(test)]
mod tests {
    use super::read;
    use serde_json::json;

    fn record(role: &str, text: &str) -> String {
        json!({"type": "message", "message": {"role": role, "content": [{"type": "text", "text": text}]}})
            .to_string()
    }

    #[test]
    fn the_operator_and_the_earlier_answers_are_kept_apart_and_the_final_one_left_out() {
        let raw = [
            record("user", "napraw build"),
            record("assistant", "build naprawiony, ale hook odmowil cargo test"),
            json!({"type": "message", "message": {"role": "user", "attribution": "agent",
                "content": [{"type": "text", "text": "todo reminder"}]}})
            .to_string(),
            record("toolResult", "exit 0"),
            record("assistant", "final answer"),
        ]
        .join("\n");
        let said = read(&raw, "final answer");
        assert_eq!(said.operator, vec!["napraw build".to_string()]);
        assert_eq!(
            said.told,
            vec!["build naprawiony, ale hook odmowil cargo test".to_string()]
        );
    }

    #[test]
    fn a_session_with_no_words_yet_is_empty() {
        let raw = [
            record("toolResult", "exit 0"),
            record("assistant", "the answer"),
        ]
        .join("\n");
        let said = read(&raw, "the answer");
        assert!(said.is_empty(), "{said:?}");
    }
}
