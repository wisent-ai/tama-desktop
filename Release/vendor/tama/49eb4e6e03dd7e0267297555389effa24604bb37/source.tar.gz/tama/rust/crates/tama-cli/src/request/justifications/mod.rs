use std::path::PathBuf;

use serde_json::Value;

use super::reply::{json_body, send_error, send_json, Reply, Request};
use crate::justify::{api, cua};

pub(in crate::request) fn handle(request: Request, writer: &mut Reply) {
    let home = match std::env::var_os("HOME") {
        Some(home) => PathBuf::from(home),
        None => return send_error(writer, 500, "HOME is not set"),
    };
    if request.operation == "justifications/cua" {
        return respond(writer, cua::list_document(&home));
    }
    let body = match json_body(&request) {
        Ok(body) => body,
        Err((status, message)) => return send_error(writer, status, &message),
    };
    let result = match request.operation.as_str() {
        "justifications/cua/record" => serde_json::from_value::<cua::RecordRequest>(body)
            .map_err(|error| format!("invalid CUA record request: {error}"))
            .and_then(|input| cua::record_request(input, &home)),
        "justifications/cua/remove" => body
            .get("quote")
            .and_then(Value::as_str)
            .ok_or_else(|| "quote is required".to_string())
            .and_then(|quote| cua::remove_document(&home, quote)),
        "justifications/record" => serde_json::from_value::<api::RecordRequest>(body)
            .map_err(|error| format!("invalid justification request: {error}"))
            .and_then(api::record),
        _ => Err("unknown justification operation".into()),
    };
    respond(writer, result);
}

fn respond(writer: &mut Reply, result: Result<Value, String>) {
    match result {
        Ok(document) => send_json(writer, 200, &document),
        Err(error) => send_error(writer, 400, &error),
    }
}
