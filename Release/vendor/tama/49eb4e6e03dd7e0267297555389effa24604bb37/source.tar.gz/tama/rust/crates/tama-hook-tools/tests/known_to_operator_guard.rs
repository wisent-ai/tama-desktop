//! `tama-block-known-to-operator`, driven as the real binary over real
//! session transcripts, judged by the real gateway.
//!
//! The operator's words on 2026-09-22, after a session ended its answer by
//! reporting his own hooks' refusals and his build ration as blockers: "the
//! user does not need this information. this is intential. a model should
//! not be able to provide irrelevant information to the user. especially
//! information that a. was already communicated before b. the user has
//! decidedly asked for".
//!
//! What this defends: the answer that incident ended on is refused in a
//! session where the operator installed those gates and had already been
//! told about the ration; an answer made of the work's results passes; a
//! session that has said nothing yet is never asked and passes; a machine
//! with no Oko CLI refuses nothing and says why. The judgement is Brama's,
//! reached through `oko-cli proxy-call`: a gateway that cannot answer fails
//! the two cases that need a verdict, by name, rather than passing them.

use std::fs;
use std::io::Write as _;
use std::path::PathBuf;
use std::process::{Command, Output, Stdio};
use std::time::{SystemTime, UNIX_EPOCH};

use serde_json::json;

const GUARD: &str = env!("CARGO_BIN_EXE_tama-block-known-to-operator");
const BLOCK_DECISION: &str = "\"decision\":\"block\"";
const SESSION: &str = "known-to-operator-guard-session";

/// What the operator said in the fixture session: he asked for the work,
/// and he installed the gates the answer later complains about.
const ASKED: &str = "rozdziel build od release w stado: stado build submit buduje i zapisuje \
    wynik, stado release submit --build publikuje tylko build ktory przeszedl";
const DECIDED: &str = "hooki zostaja: cargo build i cargo test w sesji agenta sa zablokowane \
    celowo, buduje sie raz dziennie w batchu, trzy buildy na dobe to moja decyzja";

/// What the agent already told him, earlier in the same session.
const TOLD: &str = "## What was done\n\nThe build ration for today is spent: tama build record \
    answered that three builds were used (skarbiec, wisent-compute, brama, brama) and the next \
    is authorized in 250 minutes, so the batched build runs then.";

/// The answer the incident ended on, in substance.
const INCIDENT_ANSWER: &str = "## What was done\n\nstado build submit, build status, build list \
    and build newest are in stado@3d181dcc; stado release submit --build releases a passed \
    build and refuses a waiting one.\n\n## Blockers\n\n- The real journeys did not run in this \
    session. cargo build, cargo check, cargo test and npm test are refused by the machine's hooks \
    (\"one-off repair by hand\"), and tama build record --kind build --target stado answered: \
    \"the policy allows 3 builds in any 24 hours and this machine has spent all 3 (skarbiec, \
    wisent-compute, brama, brama). The next one is authorized in 250 min.\" So ci-cd/builds.rs \
    and BuildOperationsTests.swift are written and pushed, not passed.\n\n## Next steps\n\n- none";

/// The same work, reported without telling him what he decided or already
/// heard.
const GROUNDED_ANSWER: &str = "## What was done\n\nstado build submit, build status, build list \
    and build newest are in stado@3d181dcc; stado release submit --build releases a passed \
    build and refuses a waiting one with `build <id> is waiting, not passed`. The journey \
    tests are in ci-cd/builds.rs and BuildOperationsTests.swift.\n\n## Blockers\n\nnone\n\n\
    ## Next steps\n\nnone";

fn scratch(label: &str) -> PathBuf {
    let nonce = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .expect("clock after epoch")
        .as_nanos();
    let path = PathBuf::from(env!("CARGO_TARGET_TMPDIR"))
        .join(format!("known-to-operator-{label}-{nonce}"))
        .join("project");
    fs::create_dir_all(&path).expect("create the session root");
    path
}

fn record(role: &str, text: &str) -> String {
    json!({"type": "message", "message": {"role": role, "content": [{"type": "text", "text": text}]}})
        .to_string()
}

/// Write one session transcript and answer with the root it sits under.
fn session(label: &str, lines: &[String]) -> PathBuf {
    let project = scratch(label);
    let file = project.join(format!("2026-09-22T00-00-00-000Z_{SESSION}.jsonl"));
    fs::write(&file, format!("{}\n", lines.join("\n"))).expect("write the transcript");
    project
        .parent()
        .expect("the session root above the project")
        .to_path_buf()
}

/// The session the incident happened in: the request, the decision, an
/// earlier answer about the ration, and the answer under judgement.
fn incident_session(label: &str, answer: &str) -> PathBuf {
    session(
        label,
        &[
            record("user", ASKED),
            record("user", DECIDED),
            record("assistant", TOLD),
            record("user", "kontynuuj"),
            record("assistant", answer),
        ],
    )
}

/// The judge-health record the guard reads, or none: a case that needs a
/// live judgement points the guard at an absent file, so the operator's own
/// record of an outage cannot turn a judged case into a skipped one.
fn run(root: &PathBuf, message: &str, path: Option<&str>) -> Output {
    run_with_health(root, message, path, None)
}

fn run_with_health(
    root: &PathBuf,
    message: &str,
    path: Option<&str>,
    health: Option<&str>,
) -> Output {
    let payload = json!({"session_id": SESSION, "last_assistant_message": message});
    let health_file = root.join("judge-health.json");
    if let Some(state) = health {
        fs::write(&health_file, state).expect("write the judge-health record");
    }
    let mut command = Command::new(GUARD);
    command
        .env("TAMA_OMP_SESSION_ROOT", root)
        .env("OKO_JUDGE_HEALTH_PATH", &health_file);
    if let Some(path) = path {
        command.env("PATH", path).env("HOME", root);
    }
    let mut child = command
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .unwrap_or_else(|error| panic!("spawn the guard: {error}"));
    child
        .stdin
        .as_mut()
        .expect("guard stdin")
        .write_all(payload.to_string().as_bytes())
        .expect("write payload");
    child.wait_with_output().expect("guard output")
}

fn spoken(output: &Output) -> String {
    format!(
        "stdout:\n{}\nstderr:\n{}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    )
}

fn refused(output: &Output) -> bool {
    String::from_utf8_lossy(&output.stdout).contains(BLOCK_DECISION)
}

/// A verdict that was never obtained is a blocked case, not a passed one.
fn require_a_judgement(output: &Output) {
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        !stderr.contains("no judgement"),
        "the gateway gave no judgement, so this case proves nothing: {}",
        spoken(output)
    );
}

#[test]
fn the_answer_the_incident_ended_on_is_refused_with_his_rule() {
    let root = incident_session("incident", INCIDENT_ANSWER);
    let output = run(&root, INCIDENT_ANSWER, None);
    require_a_judgement(&output);
    assert!(
        refused(&output),
        "the incident answer passed: {}",
        spoken(&output)
    );
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(
        stdout.contains("was already communicated before"),
        "the refusal quotes his rule: {stdout}"
    );
    assert!(
        stdout.contains("block-known-to-operator"),
        "the refusal names the gate: {stdout}"
    );
}

#[test]
fn an_answer_made_of_the_work_passes() {
    let root = incident_session("grounded", GROUNDED_ANSWER);
    let output = run(&root, GROUNDED_ANSWER, None);
    require_a_judgement(&output);
    assert!(
        !refused(&output),
        "the grounded answer was refused: {}",
        spoken(&output)
    );
}

/// Nothing said yet, nothing known: the model is not even asked.
#[test]
fn a_session_that_has_said_nothing_is_never_asked() {
    let root = session("silent", &[record("assistant", INCIDENT_ANSWER)]);
    let output = run(&root, INCIDENT_ANSWER, None);
    assert!(!refused(&output), "{}", spoken(&output));
    assert!(
        String::from_utf8_lossy(&output.stderr).trim().is_empty(),
        "a session with nothing to compare against costs no call: {}",
        spoken(&output)
    );
}

/// No Oko CLI, no judgement, no denial — and the reason on stderr.
#[test]
fn a_machine_without_the_oko_cli_refuses_nothing_and_says_why() {
    let root = incident_session("no-oko", INCIDENT_ANSWER);
    let empty = root.join("empty-path");
    fs::create_dir_all(&empty).expect("an empty PATH directory");
    let output = run(
        &root,
        INCIDENT_ANSWER,
        Some(empty.to_str().expect("utf-8 path")),
    );
    assert!(!refused(&output), "{}", spoken(&output));
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        stderr.contains("no judgement") && stderr.contains("oko-cli"),
        "the reason nothing was judged is on stderr: {}",
        spoken(&output)
    );
}

/// A judge Oko has recorded as not answering is not asked: the turn passes
/// at once, and the reason names the probe that lifts it. On 2026-09-22 one
/// refused gateway call took 27 seconds and the gate timed out at ten.
#[test]
fn a_judge_oko_recorded_as_down_is_not_asked() {
    let root = incident_session("judge-down", INCIDENT_ANSWER);
    let started = std::time::Instant::now();
    let output = run_with_health(
        &root,
        INCIDENT_ANSWER,
        None,
        Some(
            r#"{"answering":false,"checkedAt":"2026-09-22T16:31:30Z","detail":"Brama answered HTTP 429","observedBy":"transcripts tasks verify"}"#,
        ),
    );
    let elapsed = started.elapsed();
    assert!(!refused(&output), "{}", spoken(&output));
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        stderr.contains("no judgement")
            && stderr.contains("Oko last saw the judge refuse")
            && stderr.contains("transcripts tasks judge --probe"),
        "the recorded outage is the reason, and the probe is named: {}",
        spoken(&output)
    );
    // The gateway was never asked, so no retry wait was spent: well inside
    // the ten seconds a hook is given by default.
    assert!(
        elapsed < std::time::Duration::from_secs("10".parse().unwrap_or_default()),
        "a recorded outage still cost a call: {elapsed:?}"
    );
}
