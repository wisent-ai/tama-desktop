//! The throwaway layout the `tama copies` tests drive.
//!
//! A command that deletes directories cannot be proven against anything but
//! real repositories, so this fixture makes them: a bare `origin.git`, one
//! canonical checkout at `tree/repo` cloned from it, a second clone of that
//! same origin nested at `tree/repo/vendor/copy`, and `tree/repo/vendor/lone`
//! cloned from a second origin that has no canonical checkout under the root.
//!
//! Everything lives under the crate's own `CARGO_TARGET_TMPDIR` inside
//! `target/` — the one place this workshop allows throwaway state: not
//! `/tmp`, which is swept on sight here, and not `~/.stado/work`, which
//! belongs to Stado. The whole base is removed on drop, so a failing
//! assertion cleans up exactly like a passing one.
//!
//! A `mod.rs` in a subdirectory of `tests/` is not compiled as its own test
//! binary, so the crate's `[[test]]` entry keeps working unchanged.

use std::fs;
use std::io::Write;
use std::path::{Path, PathBuf};
use std::process::{Command, Output, Stdio};
use std::time::{SystemTime, UNIX_EPOCH};

pub struct Fixture {
    pub base: PathBuf,
}

impl Fixture {
    pub fn new(label: &str) -> Self {
        let unique = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock before epoch")
            .as_nanos();
        let base = PathBuf::from(env!("CARGO_TARGET_TMPDIR")).join(format!(
            "tama-copies-cli-{label}-{}-{unique}",
            std::process::id()
        ));
        fs::create_dir_all(base.join("home")).expect("create scratch home");
        fs::create_dir_all(base.join("tree")).expect("create scratch tree");
        let fixture = Self {
            base: fs::canonicalize(&base).expect("canonicalise scratch base"),
        };
        fixture.seed("origin", "tree/repo");
        fixture.seed("other", "seed-other");
        fixture.clone_into("origin", "tree/repo/vendor/copy");
        fixture.clone_into("other", "tree/repo/vendor/lone");
        fixture
    }

    /// A bare origin with one commit pushed into it, and a working checkout
    /// of it at `at`. Published history is what makes a copy removable, so
    /// the fixture starts from a remote rather than from `git init`.
    fn seed(&self, origin: &str, at: &str) {
        let bare = self.base.join(format!("{origin}.git"));
        fs::create_dir_all(&bare).expect("create bare origin");
        self.git(&bare, &["init", "-q", "--bare"]);
        let checkout = self.base.join(at);
        fs::create_dir_all(&checkout).expect("create checkout");
        self.git(&checkout, &["init", "-q"]);
        fs::write(checkout.join("file.txt"), "one\n").expect("write tracked file");
        self.git(&checkout, &["add", "file.txt"]);
        self.git(&checkout, &["commit", "-q", "-m", "init"]);
        self.git(&checkout, &["remote", "add", "origin", &text(bare.clone())]);
        self.git(&checkout, &["push", "-q", "-u", "origin", "HEAD"]);
    }

    fn clone_into(&self, origin: &str, at: &str) {
        let bare = self.base.join(format!("{origin}.git"));
        let target = self.base.join(at);
        fs::create_dir_all(target.parent().expect("copy has a parent"))
            .expect("create copy parent");
        let mut command = Command::new("git");
        command
            .arg("clone")
            .arg("-q")
            .arg(text(bare))
            .arg(text(target));
        let output = self.env(&mut command).output().expect("run git clone");
        assert!(
            output.status.success(),
            "git clone failed: {}",
            stderr(&output)
        );
    }

    pub fn root(&self) -> String {
        text(self.base.join("tree"))
    }

    pub fn checkout(&self) -> PathBuf {
        self.base.join("tree/repo")
    }

    pub fn copy(&self) -> PathBuf {
        self.base.join("tree/repo/vendor/copy")
    }

    /// The clone whose repository has no canonical checkout under the root.
    pub fn lone(&self) -> PathBuf {
        self.base.join("tree/repo/vendor/lone")
    }

    /// The scratch home, an empty global config and no system config, so this
    /// machine's git configuration — a `core.hooksPath` included — can
    /// neither change the fixture nor be changed by it.
    pub fn env<'a>(&self, command: &'a mut Command) -> &'a mut Command {
        command
            .env("HOME", self.base.join("home"))
            .env("GIT_CONFIG_GLOBAL", self.base.join("home/.gitconfig"))
            .env("GIT_CONFIG_NOSYSTEM", "1")
            // These real remotes belong to this isolated fixture, never the network.
            .env("GIT_ALLOW_PROTOCOL", "file")
            .env("GIT_AUTHOR_NAME", "Tama Test")
            .env("GIT_AUTHOR_EMAIL", "test@example.invalid")
            .env("GIT_COMMITTER_NAME", "Tama Test")
            .env("GIT_COMMITTER_EMAIL", "test@example.invalid")
    }

    pub fn git(&self, dir: &Path, args: &[&str]) -> Output {
        let mut command = Command::new("git");
        command.arg("-C").arg(dir).args(args);
        let output = self.env(&mut command).output().expect("run git");
        assert!(
            output.status.success(),
            "git {args:?} failed: {}",
            stderr(&output)
        );
        output
    }

    pub fn tama(&self, args: &[&str]) -> Output {
        let mut command = Command::new(env!("CARGO_BIN_EXE_tama-cli"));
        command
            .args(args)
            .env_remove("TAMA_ROOT")
            .env_remove("TAMA_HOOK_ENFORCEMENT")
            .env_remove("TAMA_EMERGENCY_STATE");
        let output = self.env(&mut command).output().expect("run tama-cli");
        eprintln!(
            "command: tama-cli {args:?}\nexit: {:?}\nstdout:\n{}\nstderr:\n{}",
            output.status.code(),
            stdout(&output),
            stderr(&output)
        );
        output
    }

    /// One commit that exists in this checkout and on no remote.
    pub fn commit_locally(&self, dir: &Path) {
        fs::write(dir.join("local.txt"), "local\n").expect("write local file");
        self.git(dir, &["add", "local.txt"]);
        self.git(dir, &["commit", "-q", "-m", "local only"]);
    }

    pub fn dirty(&self, dir: &Path) {
        fs::write(dir.join("file.txt"), "changed\n").expect("dirty the checkout");
    }

    /// `tama-cli request <operation>` with `body` on stdin, the way Tama
    /// Desktop runs one: the status and document of its single response
    /// event, after checking the exit status that status promises.
    pub fn request(&self, operation: &str, body: serde_json::Value) -> (u16, serde_json::Value) {
        let mut command = Command::new(env!("CARGO_BIN_EXE_tama-cli"));
        command
            .args(["request", operation])
            .env_remove("TAMA_ROOT")
            .env_remove("TAMA_HOOK_ENFORCEMENT")
            .env_remove("TAMA_EMERGENCY_STATE")
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped());
        let mut child = self
            .env(&mut command)
            .spawn()
            .expect("start tama-cli request");
        let input = serde_json::to_vec(&body).unwrap();
        child
            .stdin
            .take()
            .expect("request stdin")
            .write_all(&input)
            .expect("write request body");
        let output = child.wait_with_output().expect("run tama-cli request");
        eprintln!(
            "command: tama-cli request {operation}\n{}\nexit: {:?}\nstdout:\n{}\nstderr:\n{}",
            String::from_utf8_lossy(&input),
            output.status.code(),
            stdout(&output),
            stderr(&output)
        );
        let text = stdout(&output);
        let event: serde_json::Value =
            serde_json::from_str(text.lines().last().expect("one response event"))
                .expect("response event JSON");
        assert_eq!(event["type"], "response", "{event}");
        let status: u16 = event["status"].as_u64().unwrap().try_into().unwrap();
        let exit = if status == 200 { 0 } else { 1 };
        assert_eq!(output.status.code(), Some(exit), "{event}");
        (status, event["json"].clone())
    }
}

impl Drop for Fixture {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.base);
    }
}

pub fn text(path: PathBuf) -> String {
    path.to_string_lossy().into_owned()
}

pub fn stdout(output: &Output) -> String {
    String::from_utf8(output.stdout.clone()).expect("stdout is UTF-8")
}

pub fn stderr(output: &Output) -> String {
    String::from_utf8(output.stderr.clone()).expect("stderr is UTF-8")
}
