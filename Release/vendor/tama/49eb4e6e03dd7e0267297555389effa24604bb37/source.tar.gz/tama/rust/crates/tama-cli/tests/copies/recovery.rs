use std::fs;

use serde_json::Value;

use crate::copies_fixture::{stderr, stdout, text, Fixture};

#[test]
fn a_missing_object_store_is_reported_and_requires_explicit_force() {
    let fixture = Fixture::new("missing-object-store");
    let cache = fixture.base.join("cache.git");
    let dependency = fixture.checkout().join(".build/checkouts/sdk");
    fs::create_dir_all(dependency.parent().unwrap()).unwrap();
    fixture.git(
        &fixture.checkout(),
        &[
            "clone",
            "--quiet",
            "--bare",
            &text(fixture.base.join("origin.git")),
            &text(cache.clone()),
        ],
    );
    fixture.git(
        &fixture.checkout(),
        &[
            "clone",
            "--quiet",
            "--shared",
            &text(cache.clone()),
            &text(dependency.clone()),
        ],
    );
    fs::remove_dir_all(&cache).unwrap();
    let refused = fixture.tama(&[
        "copies",
        "remove",
        "--root",
        &fixture.root(),
        "--only",
        &text(dependency.clone()),
        "--apply",
        "--json",
    ]);
    assert_eq!(refused.status.code(), Some(1), "{}", stderr(&refused));
    let document: Value = serde_json::from_str(&stdout(&refused)).unwrap();
    assert_eq!(document["refused"][0]["reason"], "unreadable-git-state");
    assert!(document["copies"][0]["inspectionError"]
        .as_str()
        .unwrap()
        .contains("git status"));
    assert!(document["copies"][0]["dirty"].is_null());
    assert!(dependency.is_dir());
    let (status, removed) = fixture.request(
        "copies/remove",
        serde_json::json!({
            "roots": [fixture.root()], "only": [dependency], "apply": true, "force": true,
        }),
    );
    assert_eq!(status, 200, "{removed}");
    assert_eq!(removed["applied"], true);
    assert!(!dependency.exists());
    assert_eq!(
        fs::read(fixture.checkout().join("file.txt")).unwrap(),
        b"one\n"
    );
    fixture.git(&fixture.checkout(), &["fsck", "--full"]);
}
