//! The stdout side of one request: the single `response` event of a bounded
//! operation, or the log events and the single `result` event of a streamed
//! job. No operation logic lives here — see `routes` and `jobs`.

use std::io::Write;

use serde_json::{json, Value};

pub(super) struct Request {
    pub operation: String,
    pub body: Vec<u8>,
}

/// What the process exits with, decided by the last event it printed.
#[derive(Default)]
pub(super) struct Reply {
    exit_status: i32,
}

impl Reply {
    pub(super) fn exit_status(&self) -> i32 {
        self.exit_status
    }
}

/// The answer of a bounded operation: 200 with the document the command
/// prints, or a refusal status with the product's own sentence.
pub(super) fn send_json(writer: &mut Reply, status: u16, document: &Value) {
    write_event(&json!({ "type": "response", "status": status, "json": document }));
    writer.exit_status = if (200..300).contains(&status) { 0 } else { 1 };
}

pub(super) fn send_error(writer: &mut Reply, status: u16, message: &str) {
    send_json(writer, status, &json!({ "error": message }));
}

/// The parsed JSON body, or the (status, sentence) of the refusal. An empty
/// body is `{}`, so an operation that takes no fields needs no input at all.
pub(super) fn json_body(request: &Request) -> Result<Value, (u16, String)> {
    let text = String::from_utf8_lossy(&request.body);
    let trimmed = text.trim();
    if trimmed.is_empty() {
        return Ok(json!({}));
    }
    serde_json::from_str(trimmed).map_err(|_| (400, "request body is not valid JSON".to_string()))
}

/// One event per line, flushed when it is written, so the desktop shows a
/// job's output while the job runs. A reader that has gone away ends the
/// process at this write: `main` restores the default SIGPIPE disposition.
fn write_event(event: &Value) {
    let mut line = serde_json::to_vec(event).unwrap_or_default();
    line.push(b'\n');
    let mut out = std::io::stdout().lock();
    let _ = out.write_all(&line);
    let _ = out.flush();
}

/// Streams one job, mirroring the command: log events in the job's own
/// order, then exactly one result event whose status is the exit code and
/// whose json is the command's document.
pub(super) fn stream_job(
    writer: &mut Reply,
    job: impl FnOnce(&mut dyn FnMut(&str, &str)) -> (i32, Value),
) {
    let mut emit = |stream: &str, chunk: &str| {
        write_event(&json!({ "type": "log", "stream": stream, "chunk": chunk }));
    };
    let (status, document) = job(&mut emit);
    write_event(&json!({ "type": "result", "status": status, "json": document }));
    writer.exit_status = status;
}
