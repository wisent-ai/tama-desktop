//! Which files belong at a repository root because a tool reads them
//! there, and which ones do not belong at any root at all.
//!
//! Split out of `declare_root/mod.rs`, which had grown past the
//! three-hundred-line limit as the table learned more toolchains.

/// Files whose place at a repository root is decided by a tool, with the
/// tool that decides it. Anything not named here is a file a person put
/// there and a person can move.
pub(super) const FIXED_AT_ROOT: &[(&str, &str)] = &[
    ("README.md", "GitHub shows it on the repository page"),
    ("README", "GitHub shows it on the repository page"),
    ("LICENSE", "GitHub reads the licence from the root"),
    ("LICENSE.md", "GitHub reads the licence from the root"),
    ("NOTICE", "the licence terms are published beside it"),
    (
        "CHANGELOG.md",
        "release tooling and GitHub read it from the root",
    ),
    ("CODEOWNERS", "GitHub reads reviewers from the root"),
    (
        ".git-blame-ignore-revs",
        "GitHub's blame view reads the revisions to skip from the root",
    ),
    (
        "onboarding_first_use.json",
        "Echo's journey publisher discovers the product's first-use definition at this path on origin/main",
    ),
    ("package.json", "npm"),
    ("package-lock.json", "npm"),
    ("pnpm-lock.yaml", "pnpm"),
    ("pnpm-workspace.yaml", "pnpm"),
    ("yarn.lock", "yarn"),
    ("bun.lockb", "bun"),
    (".npmignore", "npm"),
    (".npmrc", "npm"),
    (".nvmrc", "node"),
    ("tsconfig.json", "TypeScript"),
    ("Cargo.toml", "cargo"),
    ("Cargo.lock", "cargo"),
    ("rust-toolchain.toml", "rustup"),
    ("pyproject.toml", "pip and the Python build backends"),
    ("setup.py", "pip"),
    ("setup.cfg", "pip"),
    ("requirements.txt", "pip"),
    ("MANIFEST.in", "the Python sdist build"),
    ("poetry.lock", "poetry"),
    ("uv.lock", "uv"),
    (".python-version", "pyenv"),
    ("Package.swift", "SwiftPM"),
    ("Package.resolved", "SwiftPM"),
    ("go.mod", "go"),
    ("go.sum", "go"),
    ("Gemfile", "bundler"),
    ("Gemfile.lock", "bundler"),
    ("Dockerfile", "docker"),
    (
        ".dockerignore",
        "docker reads it from the build context root, whatever the Dockerfile's own path",
    ),
    ("docker-compose.yml", "docker compose"),
    ("docker-compose.yaml", "docker compose"),
    ("Makefile", "make"),
    ("vercel.json", "Vercel"),
    ("netlify.toml", "Netlify"),
    ("next.config.ts", "Next.js"),
    ("next.config.js", "Next.js"),
    ("next.config.mjs", "Next.js"),
    ("next-env.d.ts", "Next.js writes it and TypeScript reads it"),
    ("postcss.config.mjs", "PostCSS"),
    ("postcss.config.js", "PostCSS"),
    ("tailwind.config.ts", "Tailwind"),
    ("tailwind.config.js", "Tailwind"),
    ("svelte.config.js", "SvelteKit"),
    ("vite.config.ts", "Vite"),
    ("vite.config.js", "Vite"),
    ("astro.config.mjs", "Astro"),
    ("nuxt.config.ts", "Nuxt"),
    ("eslint.config.mjs", "ESLint"),
    ("eslint.config.js", "ESLint"),
    (".eslintrc.json", "ESLint"),
    ("components.json", "shadcn/ui"),
    (".gitignore", "git"),
    (".gitattributes", "git"),
    (".gitmodules", "git"),
    (".editorconfig", "editors"),
    (".wisent-release.json", "the Wisent release tooling"),
    (".env.example", "dotenv, and whoever copies it to .env"),
    (".claudeignore", "Claude Code"),
    (
        "released-surface.json",
        "the Wisent release tooling reads it from the root",
    ),
    (
        ".wisent-desktop-release.json",
        "the Wisent desktop release tooling",
    ),
    (
        "platform-entitlements.json",
        "the pack's release tooling reads it by that exact path",
    ),
    ("landing.brief.json", "the landing tooling"),
    ("landing.config.json", "the landing tooling"),
    ("landing.plan.json", "the landing tooling"),
    ("landing.components.json", "the landing tooling"),
    (".swiftlint.yml", "SwiftLint"),
    (".swiftformat", "SwiftFormat"),
    (".swift-version", "swiftenv"),
    (
        "project.yml",
        "XcodeGen reads the project spec from the root it is run in",
    ),
    (
        "commercial-status.json",
        "the fleet reads a product's commercial posture from this exact path",
    ),
    (
        "project.yaml",
        "XcodeGen reads the project spec from the root it is run in",
    ),
    (
        "index.html",
        "Vite reads the entry page from the project root and rewrites its script tags",
    ),
    (
        "VERSION",
        "the release scripts read the version from this exact path",
    ),
];

/// Files a root should not carry, with what to do about each. Finder and
/// Explorer metadata is deleted; a build's own cache belongs to the build
/// directory and to `.gitignore`, never to a commit. Either way the file is
/// not moved into a folder, and saying which it is saves a reader the
/// puzzle of where it should have gone.
pub(super) const JUNK_AT_ROOT: &[(&str, &str)] = &[
    (".DS_Store", "delete this, nothing reads it"),
    ("Thumbs.db", "delete this, nothing reads it"),
    ("desktop.ini", "delete this, nothing reads it"),
    (
        "tsconfig.tsbuildinfo",
        "TypeScript writes this cache; gitignore it and remove the committed copy",
    ),
];

/// Suffixes of files a compiler writes beside the code it read, which end
/// up at a root when a build is started there. `oko` had four of them
/// committed — `EmbeddedOnboardingDefinition.generated-2.swiftmodule` and
/// its dependency, diagnostic and swiftdeps siblings — and no name list
/// can keep up, because the stem is whatever was being compiled.
pub(super) const BUILD_OUTPUT_SUFFIXES: &[&str] = &[
    ".swiftmodule",
    ".swiftdeps",
    ".swiftdoc",
    ".swiftsourceinfo",
    ".dia",
    ".o",
];

pub(super) fn is_junk(name: &str) -> bool {
    JUNK_AT_ROOT.iter().any(|(known, _)| *known == name) || is_build_output(name)
}

/// Whether a compiler wrote this file. The `.d` dependency file is judged
/// by its stem too: a root file named `<something>.generated-2.d` is the
/// sibling of a `.swiftmodule`, while a lone `main.d` could be D source.
fn is_build_output(name: &str) -> bool {
    let lowered = name.to_lowercase();
    BUILD_OUTPUT_SUFFIXES
        .iter()
        .any(|suffix| lowered.ends_with(suffix))
        || (lowered.ends_with(".d") && lowered.contains(".generated"))
}

pub(super) fn junk_reason(name: &str) -> &'static str {
    if is_build_output(name) {
        return "a compiler wrote this beside the code it read; gitignore it and remove the \
                committed copy";
    }
    JUNK_AT_ROOT
        .iter()
        .find(|(known, _)| *known == name)
        .map(|(_, reason)| *reason)
        .unwrap_or("delete this, nothing reads it")
}
