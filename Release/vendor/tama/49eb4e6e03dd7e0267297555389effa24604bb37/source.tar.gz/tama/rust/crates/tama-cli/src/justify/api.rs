use serde::Deserialize;
use serde_json::{json, Value};

use super::{absolute, entry, registry, request};

#[derive(Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub(crate) struct RecordRequest {
    kind: String,
    file: String,
    justification: String,
    quote: Option<String>,
    expires_at: Option<String>,
}

pub(crate) fn record(input: RecordRequest) -> Result<Value, String> {
    if input.kind != "file" && input.kind != "test" {
        return Err(
            "kind must be file or test; CUA uses the justifications/cua/record request".into(),
        );
    }
    let mut argv = vec![
        "--kind".into(),
        input.kind,
        "--file".into(),
        input.file.clone(),
        "--justification".into(),
        input.justification,
    ];
    if let Some(quote) = input.quote {
        argv.extend(["--quote".into(), quote]);
    }
    if let Some(expires) = input.expires_at {
        argv.extend(["--expires-at".into(), expires]);
    }
    let request = request(&argv)?;
    let key = absolute(&input.file)?;
    let document = entry(&argv, &request, &key)?;
    let path = registry::registry_path(&request.home, request.kind);
    registry::record(&path, &key, document)?;
    Ok(json!({"recorded": key, "kind": request.kind.label(), "registry": path}))
}
