//! `tama request <operation>` — one desktop request, answered by this process.
//!
//! Tama Desktop starts one of these per operation (`tama request coverage
//! --root <release>`, `tama request violations/scan --root <release>`),
//! writes the request body to stdin as one JSON document, and reads the
//! events this prints on stdout. The process ends when the operation ends, so
//! no Tama process stays resident behind the window and no port is opened.
//! Every operation reuses the exact functions the CLI commands use (runtime,
//! install, scan_repos, clean) — no parallel implementation.
//!
//! stdout carries only NDJSON events. A bounded operation prints exactly one:
//!
//!   {"type":"response","status":<status>,"json":{...}}
//!
//! `status` is 200 for an answer and otherwise names the refusal in HTTP's
//! vocabulary: 400 a request the operation refuses, 403 an operation disabled
//! on this machine, 404 an unknown operation, 500 a failure while it ran. A
//! refusal's `json` is {"error": "<one sentence>"} — the product's own
//! refusal sentence, verbatim from the underlying failure.
//!
//! A streamed job (violation scan and clean) prints instead:
//!
//!   {"type":"log","stream":"stdout"|"stderr","chunk":"..."}  (zero or more)
//!   {"type":"result","status":<exit-code>,"json":{...}}      (exactly one, last)
//!
//! where `json` is the same document the command prints and `status` is its
//! exit code. A job refused before it starts prints one `response` instead.
//!
//! The process exits 0 after a 200 response, 1 after any other response, and
//! with the job's own status after a result.

mod builds;
mod copies;
mod jobs;
mod justifications;
mod reply;
mod routes;

use std::io::Read;
use std::path::Path;

use crate::EXIT_USAGE;

pub fn main(args: &[String], root: &Path) -> i32 {
    let mut operation: Option<&str> = None;
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            // `--root` is already resolved by the caller; it stays in argv.
            "--root" => {
                if args.get(i + 1).is_none() {
                    eprintln!("missing value for --root");
                    return EXIT_USAGE;
                }
                i += 2;
            }
            option if option.starts_with("--") => {
                eprintln!("unknown request option: {option}");
                return EXIT_USAGE;
            }
            name if operation.is_none() => {
                operation = Some(name);
                i += 1;
            }
            extra => {
                eprintln!("unexpected request argument: {extra}");
                return EXIT_USAGE;
            }
        }
    }
    let Some(operation) = operation else {
        eprintln!("request requires an operation");
        return EXIT_USAGE;
    };
    let mut body = Vec::new();
    if let Err(error) = std::io::stdin().read_to_end(&mut body) {
        eprintln!("failed to read the request body from stdin: {error}");
        return 1;
    }
    let mut reply = reply::Reply::default();
    routes::dispatch(
        reply::Request {
            operation: operation.to_string(),
            body,
        },
        root,
        &mut reply,
    );
    reply.exit_status()
}
