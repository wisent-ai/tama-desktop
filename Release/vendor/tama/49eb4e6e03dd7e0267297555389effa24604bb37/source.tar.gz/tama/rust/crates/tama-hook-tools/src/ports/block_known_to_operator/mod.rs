//! Logic for `tama-block-known-to-operator`, registry hook id
//! `block-known-to-operator`.
//!
//! A Stop gate. It refuses a final message that tells the operator what he
//! already knows: what this session already told him, or what he himself
//! decided — a refusal from his own hooks, a limit he set, a rule he stated
//! — handed back to him as a blocker, a limitation or news.
//!
//! Why: on 2026-09-22 a session ended its answer with a blocker section
//! that reported `cargo build`, `cargo check`, `cargo test` and `npm test`
//! refused by the machine's own gates, and the build ration answering that
//! the day's three builds were spent. Every one of those refusals is the
//! operator's own policy, installed on his instruction, and the ration had
//! been explained to him in the same session. His words: "the user does not
//! need this information. this is intential. a model should not be able to
//! provide irrelevant information to the user. especially information that
//! a. was already communicated before b. the user has decidedly asked for".
//!
//! Shape cannot decide this — whether a sentence restates an earlier answer,
//! or reports the operator's own decision back to him, is a reading of two
//! texts against a third — so the decider is a model, asked through Brama by
//! `ports::model_judgement`. The session is the memory: the operator's own
//! messages and the agent's earlier answers are read out of the live
//! transcript and put in front of the model beside the answer. A judgement
//! nobody could obtain is never a denial, and a session that has said
//! nothing yet is never asked about.

mod session;

use serde_json::Value;
use tama_hooks::session_record::{deny, read_payload};

use crate::ports::block_unsearched_blocker_claim::final_message;
use crate::ports::{model_judgement, pystr};

const TAG: &str = "block-known-to-operator";
const STOP_HOOK_ACTIVE: &str = "stop_hook_active";
const BLOCK: &str = "BLOCK";

/// How much of each voice the model is shown: the tail, because the newest
/// words are the ones an answer is most likely to repeat. The operator's
/// words are the smallest voice and the one that matters most, so they get
/// the widest window; the answer itself the one every other stop gate uses.
const OPERATOR_CHARS_TEXT: &str = "12000";
const TOLD_CHARS_TEXT: &str = "12000";
const ANSWER_CHARS_TEXT: &str = "6000";

const PROMPT: &str = "You are a strict gate over the final message an AI coding agent is about to hand its operator. \
The operator's rule, in his words: \"the user does not need this information. this is intentional. \
a model should not be able to provide irrelevant information to the user. especially information that \
a. was already communicated before b. the user has decidedly asked for\".

Three texts follow. <operator> holds every message the operator wrote in this session, oldest first: \
his requests, his decisions, the rules and limits he stated. <told> holds every earlier answer the \
agent gave him in this session, oldest first. <answer> is the message about to be sent.

Refuse a sentence of <answer> that:
1. tells the operator something <told> already told him in substance — the same fact, the same \
failure, the same refusal, the same explanation, reworded or repeated; or
2. reports back to the operator something he himself decided, asked for or installed — a refusal \
by his own hooks, gates, guards or policy; a limit, quota, ration or rule he set; a choice he made in \
<operator> — presented as a blocker, a limitation, a reason the work stopped, or as news. What the \
operator decided is his intention, not an obstacle, and never needs telling.

Do not refuse: the results of the work he asked for; a direct answer to a question he asked; a \
defect identifier named in one clause; a failure outside his own decisions that <told> never mentioned; \
a sentence that only names what he must do or decide next without explaining his own policy to him.

Reply with EXACTLY one of these two formats and nothing else:
PASS
or
BLOCK: <each offending sentence quoted verbatim, followed by one clause saying whether it was told before or is his own decision>

<operator>
{operator}
</operator>

<told>
{told}
</told>

<answer>
{answer}
</answer>";

const OPERATOR_PLACEHOLDER: &str = "{operator}";
const TOLD_PLACEHOLDER: &str = "{told}";
const ANSWER_PLACEHOLDER: &str = "{answer}";
const VOICE_SEPARATOR: &str = "\n\n---\n\n";

fn chars(text: &str) -> usize {
    text.parse().unwrap_or_default()
}

fn log(text: &str) {
    eprintln!("{TAG}: {text}");
}

/// The prompt for one answer, the voices cut to their tails.
pub(crate) fn prompt(said: &session::Said, answer: &str) -> String {
    let operator = said.operator.join(VOICE_SEPARATOR);
    let told = said.told.join(VOICE_SEPARATOR);
    PROMPT
        .replace(
            OPERATOR_PLACEHOLDER,
            pystr::tail_chars(&operator, chars(OPERATOR_CHARS_TEXT)),
        )
        .replace(
            TOLD_PLACEHOLDER,
            pystr::tail_chars(&told, chars(TOLD_CHARS_TEXT)),
        )
        .replace(
            ANSWER_PLACEHOLDER,
            pystr::tail_chars(answer, chars(ANSWER_CHARS_TEXT)),
        )
}

/// The refusal a `BLOCK` verdict becomes, or nothing for any other answer.
pub(crate) fn refusal(verdict: &str) -> Option<String> {
    let rest = verdict.trim().strip_prefix(BLOCK)?;
    let said = rest.trim_start_matches([':', ' ']).trim();
    let said = if said.is_empty() {
        "the model named no sentence"
    } else {
        said
    };
    Some(format!(
        "{TAG}: this answer tells the operator what he already knows: {said}. His rule: \"the user \
         does not need this information. this is intentional. a model should not be able to provide \
         irrelevant information to the user. especially information that a. was already communicated \
         before b. the user has decidedly asked for\". A gate of his that refused you is his decision, \
         not your blocker; what this session already told him is not news. Delete those sentences \
         and answer with the work."
    ))
}

/// The refusal, or nothing: no answer to judge, nothing said yet in the
/// session, no judgement obtainable, or a `PASS`.
pub fn check(payload: &Value) -> Option<String> {
    if payload.get(STOP_HOOK_ACTIVE) == Some(&Value::Bool(true)) {
        return None;
    }
    let answer = final_message(payload);
    if answer.trim().is_empty() {
        return None;
    }
    let Some(path) = session::locate(payload) else {
        log("no transcript for this session; nothing is known yet");
        return None;
    };
    let raw = match std::fs::read_to_string(&path) {
        Ok(raw) => raw,
        Err(error) => {
            log(&format!("cannot read {}: {error}", path.display()));
            return None;
        }
    };
    let said = session::read(&raw, &answer);
    if said.is_empty() {
        return None;
    }
    match model_judgement::ask(&prompt(&said, &answer)) {
        model_judgement::Judgement::Answered(verdict) => refusal(&verdict),
        model_judgement::Judgement::Unavailable(reason) => {
            log(&format!("no judgement: {reason}"));
            None
        }
    }
}

pub fn run() {
    let payload = read_payload();
    if let Some(problem) = check(&payload) {
        deny(problem);
    }
}

#[cfg(test)]
mod tests {
    use super::{prompt, refusal, session::Said};

    #[test]
    fn a_pass_refuses_nothing_and_a_block_quotes_the_model() {
        assert_eq!(refusal("PASS"), None);
        let said = refusal("BLOCK: \"cargo test is refused by the hooks\" — his own decision")
            .expect("a block is a refusal");
        assert!(
            said.contains("cargo test is refused by the hooks"),
            "{said}"
        );
        assert!(said.contains("was already communicated before"), "{said}");
    }

    #[test]
    fn the_prompt_carries_the_three_voices() {
        let said = Said {
            operator: vec!["napraw build".into(), "to jest release. a nie build".into()],
            told: vec!["the ration is spent".into()],
            records: usize::from(true),
        };
        let text = prompt(&said, "the ration is still spent");
        assert!(
            text.contains(
                "<operator>\nnapraw build\n\n---\n\nto jest release. a nie build\n</operator>"
            ),
            "{text}"
        );
        assert!(
            text.contains("<told>\nthe ration is spent\n</told>"),
            "{text}"
        );
        assert!(
            text.contains("<answer>\nthe ration is still spent\n</answer>"),
            "{text}"
        );
    }
}
