//! Rust ports of the registered Python hooks under `shared-hooks/`.
//!
//! One module per hook, named after the Python stem. A hook whose logic does
//! not fit the repository's 300-line file limit is split into
//! `<hook>_<aspect>.rs` siblings, with `<hook>.rs` keeping the orchestration.
//! One module here has no Python original — `block_repository_copies`, a
//! native guard — and it keeps the same naming and the same `evaluate` shape
//! so the tree stays one convention.

pub mod auto_rules;
pub mod block_background_execution;
pub mod block_broken_judge;
pub mod block_browser_usage;
pub mod block_crowded_folders;
pub mod block_direct_lsi_api;
pub mod block_external_source_edits;
pub mod block_git_authorship;
pub mod block_hook_config_edits_without_consent;
pub mod block_hook_config_edits_without_consent_gate;
pub mod block_hook_config_edits_without_consent_patterns;
pub mod block_identity_literals;
pub mod block_inline_execution;
pub mod block_keychain_prompt_commands;
pub mod block_keyword_literals;
pub mod block_known_to_operator;
pub mod block_local_model_training;
pub mod block_off_task_work;
pub mod block_oko_trajectory_edits;
pub mod block_one_off_repairs;
pub mod block_openai_api_key;
pub mod block_overleaf_api;
pub mod block_oversized_files;
pub mod block_repeated_blocker;
pub mod block_repository_copies;
pub mod block_stop_on_own_work;
pub mod block_subagent_spawn;
pub mod block_supabase_cli;
pub mod block_temporary_path_operations;
pub mod block_unapproved_audits;
pub mod block_unapproved_audits_state;
pub mod block_unauthorized_cua;
pub mod block_unauthorized_cua_detect;
pub mod block_unauthorized_ssh;
pub mod block_unauthorized_ssh_detect;
pub mod block_unauthorized_ssh_targets;
pub mod block_unregistered_build_or_restart;
pub mod block_unsearched_blocker_claim;
pub mod block_wait_polling;
pub mod check_artifact_inspection;
pub mod check_email_infra;
pub mod check_failure_inspection;
pub mod check_failure_inspection_claim;
pub mod check_failure_inspection_labels;
pub mod check_failure_inspection_recording;
pub mod check_failure_inspection_transcript;
pub mod check_failure_inspection_wsession;
pub mod check_git_hooks_path;
pub mod check_humanized_actions;
pub mod check_legacy_activation_bypass;
pub mod check_legacy_activation_bypass_markers;
pub mod check_legacy_activation_bypass_tree;
pub mod check_merge_deletion_loss;
pub mod check_numeric_literals;
pub mod check_numeric_literals_laundered;
pub mod check_numeric_literals_payload;
pub mod check_numeric_literals_provenance;
pub mod check_numeric_literals_scan;
pub mod check_raw_api_calls;
pub mod check_unsubstantiated_constants;
pub mod clean_violations_gate;
pub mod codex_api_guard;
pub mod detect_frustration;
pub mod failure_artefacts;
pub mod inspect_required_check;
pub mod model_judgement;
pub mod patch_envelope;
pub mod post_trajectory_capture;
pub mod pre_bash;
pub mod pre_edit_trajectory_evidence;
pub mod pre_wait_tools;
pub mod pre_write_edit;
pub mod pystr;
pub mod python_stdlib;
pub mod python_stdlib_path;
pub mod pyvalue;
pub mod recall_after_compaction;
pub mod require_new_file_justification;
pub mod shell_text;
pub mod time_words;
pub mod tool_vocabulary;
pub mod transport_common;
pub mod violations_declarations;
pub mod write_payload;
pub mod write_verbs;
