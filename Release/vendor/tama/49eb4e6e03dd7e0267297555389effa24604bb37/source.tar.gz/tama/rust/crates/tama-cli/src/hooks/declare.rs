//! `tama hooks declare --file <declaration.json>`: put one hook into the
//! catalogue, the registry and the seal, in the documented order, with one
//! command.
//!
//! Adding a hook took four writers in a fixed order — `tama-record-hook-metadata`,
//! `shared-hooks/register-hook.mjs`, `tama-reconcile-registry-sources`,
//! `shared-hooks/seal-registry.mjs` — each with its own arguments, and the
//! order is not a preference: the registry writer refuses a hook the
//! catalogue does not describe, and the seal refuses a release whose source
//! entry does not resolve. Nothing in the product ran the four, so every new
//! hook arrived as a shell file an operator was asked to run, written into a
//! build directory that the next clean wipes. On 2026-09-19 the operator
//! asked the only question that block deserved: "i jak niby mam go
//! uruchomic".
//!
//! This is that command. The hook is described once, as data in the
//! repository (`shared-hooks/declarations/<id>.json`), and this runs the
//! product's own writers over it. It is idempotent: a catalogue entry that
//! already matches is left alone, an event already registered is reported and
//! skipped, and the reseal runs only when something changed.
//!
//! Hook source and configuration are device-level protected, so without
//! `DEVICE_HOOK_EDIT_APPROVED=1` this refuses before writing anything and
//! prints the exact command block the owner runs in their own shell.

use std::path::{Path, PathBuf};
use std::process::Command;

use serde::Deserialize;
use serde_json::Value;

pub const USAGE: &str =
    "usage: tama hooks declare --file <declaration.json> [--dry-run] [--json]\n\
     \n\
     The declaration carries the hook's id, its catalogue entry and the events it binds:\n\
     {\"id\":\"…\",\"category\":\"…\",\"description\":\"…\",\"why\":\"…\",\"sideEffects\":\"…\",\n\
      \"command\":\"$HOME/.local/bin/tama-…\",\"events\":[{\"event\":\"pre_tool_use:bash\"}]}\n\
     A binding may carry \"timeout\": the seconds the runtime waits for the hook, for a hook\n\
     that asks a model; the registry's default is ten.";

pub const CONSENT_ENV: &str = "DEVICE_HOOK_EDIT_APPROVED";
pub const CONSENT_VALUE: &str = "1";
const REFUSED: i32 = 2;

#[derive(Deserialize)]
pub struct Declaration {
    pub id: String,
    pub category: String,
    pub description: String,
    pub why: String,
    #[serde(rename = "sideEffects")]
    pub side_effects: String,
    pub command: String,
    pub events: Vec<Binding>,
}

#[derive(Deserialize)]
pub struct Binding {
    pub event: String,
    /// Seconds the runtime waits for this hook on this event; the registry
    /// writer's default when absent.
    #[serde(default)]
    pub timeout: Option<u32>,
}

pub fn refuse(message: &str) -> i32 {
    eprintln!("{message}");
    REFUSED
}

/// The owner's consent, read from the one variable the whole product reads.
pub fn consented() -> bool {
    std::env::var(CONSENT_ENV).ok().as_deref() == Some(CONSENT_VALUE)
}

/// Where the writers are: beside this executable first, then the repository's
/// release build, so a checkout that has just built them works and an
/// installed CLI uses what was installed with it.
fn writer(root: &Path, name: &str) -> Option<PathBuf> {
    let beside = std::env::current_exe()
        .ok()
        .and_then(|exe| exe.parent().map(|dir| dir.join(name)));
    let built = root.join("rust/target/release").join(name);
    [beside, Some(built)]
        .into_iter()
        .flatten()
        .find(|path| path.is_file())
}

pub fn run(program: &Path, args: &[String], cwd: &Path) -> Result<String, String> {
    let output = Command::new(program)
        .args(args)
        .current_dir(cwd)
        .output()
        .map_err(|error| format!("cannot run {}: {error}", program.display()))?;
    let text = format!(
        "{}{}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    match output.status.success() {
        true => Ok(text.trim().to_string()),
        false => Err(format!(
            "{} exited {}: {}",
            program.display(),
            output.status.code().unwrap_or_default(),
            text.trim()
        )),
    }
}

/// The timeout this event's binding to this hook carries in the registry,
/// or `None` when the event is not bound to it.
fn registered_timeout(registry: &Path, id: &str, event: &str) -> Option<Option<u64>> {
    let text = std::fs::read_to_string(registry).ok()?;
    let document = serde_json::from_str::<Value>(&text).ok()?;
    document["events"][event]["hooks"]
        .as_array()
        .into_iter()
        .flatten()
        .find(|hook| hook["id"].as_str() == Some(id))
        .map(|hook| hook["timeout"].as_u64())
}

/// Whether the registry already binds this event to the hook as declared:
/// bound, and with the declared timeout when the declaration names one. A
/// binding whose timeout the declaration changed is re-registered, because
/// a hook that turned out to need longer than the default is corrected by
/// declaring the number, not by editing the registry.
fn already_registered(registry: &Path, id: &str, binding: &Binding) -> bool {
    match registered_timeout(registry, id, &binding.event) {
        None => false,
        Some(registered) => binding
            .timeout
            .is_none_or(|declared| registered == Some(u64::from(declared))),
    }
}

pub fn main(argv: &[String], root: &Path) -> i32 {
    if argv.iter().any(|arg| arg == "--help" || arg == "-h") {
        println!("{USAGE}");
        return 0;
    }
    let Some(file) = argv
        .iter()
        .position(|arg| arg == "--file")
        .and_then(|at| argv.get(at + 1))
    else {
        return refuse(USAGE);
    };
    let dry_run = argv.iter().any(|arg| arg == "--dry-run");
    let text = match std::fs::read_to_string(file) {
        Ok(text) => text,
        Err(error) => return refuse(&format!("cannot read {file}: {error}")),
    };
    let declaration: Declaration = match serde_json::from_str(&text) {
        Ok(declaration) => declaration,
        Err(error) => return refuse(&format!("{file} is not a hook declaration: {error}")),
    };
    if declaration.events.is_empty() {
        return refuse(&format!(
            "{file} binds no event; a hook that runs nowhere is not a hook"
        ));
    }
    if !dry_run && !consented() {
        return refuse(&format!(
            "BLOCKED: hook source and configuration are device-level protected. Run this in your \
             own shell, outside any agent session:\n\n  cd {}\n  {CONSENT_ENV}={CONSENT_VALUE} \
             tama hooks declare --file {file}\n\nRead why: \
             https://tama.wisent.com/docs/hook-management/#owner-consent-for-a-hook-change",
            root.display()
        ));
    }
    plan(&declaration, root, file, dry_run)
}

fn plan(declaration: &Declaration, root: &Path, file: &str, dry_run: bool) -> i32 {
    let catalogue = root.join("shared-hooks/catalog-metadata.json");
    let registry = root.join("shared-hooks/registry.json");
    let pending: Vec<&Binding> = declaration
        .events
        .iter()
        .filter(|binding| !already_registered(&registry, &declaration.id, binding))
        .collect();
    if dry_run {
        println!("would record the catalogue entry for {}", declaration.id);
        for binding in &declaration.events {
            let state = match pending.iter().any(|item| item.event == binding.event) {
                true => "would register",
                false => "already registered",
            };
            println!("{state}: {} on {}", declaration.id, binding.event);
        }
        println!("would reconcile sources and reseal {}", registry.display());
        return 0;
    }
    let Some(recorder) = writer(root, "tama-record-hook-metadata") else {
        return refuse(
            "no tama-record-hook-metadata beside this CLI or in rust/target/release; build it with: \
             cargo build --release -p tama-hook-tools --bin tama-record-hook-metadata",
        );
    };
    let record = vec![
        "--category".to_string(),
        declaration.category.clone(),
        "--description".to_string(),
        declaration.description.clone(),
        "--why".to_string(),
        declaration.why.clone(),
        "--side-effects".to_string(),
        declaration.side_effects.clone(),
        catalogue.display().to_string(),
        declaration.id.clone(),
    ];
    match run(&recorder, &record, root) {
        Ok(said) => println!("catalogue: {said}"),
        Err(error) => return refuse(&error),
    }
    for binding in &pending {
        // Bound with another timeout: the writer refuses a second entry for
        // the same event, so the old binding is removed before the declared
        // one is registered.
        if registered_timeout(&registry, &declaration.id, &binding.event).is_none() {
            continue;
        }
        let args = vec![
            "node".to_string(),
            "shared-hooks/register-hook.mjs".to_string(),
            declaration.id.clone(),
            binding.event.clone(),
            declaration.command.clone(),
            "--remove".to_string(),
        ];
        match run(Path::new("/usr/bin/env"), &args, root) {
            Ok(said) => println!("registry: unbound the old timeout: {said}"),
            Err(error) => return refuse(&error),
        }
    }
    for binding in &pending {
        let mut args = vec![
            "shared-hooks/register-hook.mjs".to_string(),
            declaration.id.clone(),
            binding.event.clone(),
            declaration.command.clone(),
        ];
        if let Some(timeout) = binding.timeout {
            args.push(timeout.to_string());
        }
        match run(
            Path::new("/usr/bin/env"),
            &[vec!["node".to_string()], args].concat(),
            root,
        ) {
            Ok(said) => println!("registry: {said}"),
            Err(error) => return refuse(&error),
        }
    }
    for binding in &declaration.events {
        if !pending.iter().any(|item| item.event == binding.event) {
            println!(
                "registry: {} already bound to {}",
                declaration.id, binding.event
            );
        }
    }
    if let Some(reconciler) = writer(root, "tama-reconcile-registry-sources") {
        match run(&reconciler, &[registry.display().to_string()], root) {
            Ok(said) => println!("sources: {said}"),
            Err(error) => return refuse(&error),
        }
    }
    match run(
        Path::new("/usr/bin/env"),
        &[
            "node".to_string(),
            "shared-hooks/seal-registry.mjs".to_string(),
        ],
        root,
    ) {
        Ok(said) => println!("seal: {said}"),
        Err(error) => return refuse(&error),
    }
    println!(
        "{} is declared. It runs where the registry says once the release is installed; \
         `tama enforcement only …` decides what this machine runs, and `tama show {} --json` \
         reads it back. Declaration: {file}",
        declaration.id, declaration.id
    );
    0
}
