//! tama-violations: hook-rule violation scanning and cleaning.
//! Rust port of `src/violations/`.

pub mod clean;
pub mod find_violations;
pub mod find_violations_tests;
pub mod repo_discovery;
pub mod scan_repos;

use std::path::{Component, Path, PathBuf};

/// Mirrors `EXIT_USAGE` from `src/adaptive/engine.mjs`.
pub const EXIT_USAGE: i32 = 2;

/// Rust counterpart of `repoRoot()` from `src/core/catalog.mjs`: the
/// tama repository root. Resolved from `TAMA_ROOT` when set,
/// otherwise relative to this crate's manifest dir (rust/crates/tama-violations
/// is three levels below the repo root).
pub fn repo_root() -> PathBuf {
    if let Ok(root) = std::env::var("TAMA_ROOT") {
        if !root.is_empty() {
            return normalize(&PathBuf::from(root));
        }
    }
    normalize(
        &Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("..")
            .join("..")
            .join(".."),
    )
}

/// Mirrors `firstLine` from the JS sources: first line of the text, trimmed.
pub fn first_line(text: &str) -> String {
    text.split('\n').next().unwrap_or("").trim().to_string()
}

/// Mirrors Node's `os.homedir()` (honors `HOME`).
pub fn homedir() -> PathBuf {
    if let Ok(home) = std::env::var("HOME") {
        if !home.is_empty() {
            return PathBuf::from(home);
        }
    }
    PathBuf::from("/")
}

/// Lexical normalization mirroring Node's `path.resolve` for one already
/// joined path: collapses `.`/`..`/duplicate separators without touching the
/// filesystem (no symlink resolution, like Node).
fn normalize(path: &Path) -> PathBuf {
    let mut out: Vec<std::ffi::OsString> = Vec::new();
    let mut rooted = false;
    for component in path.components() {
        match component {
            Component::RootDir => rooted = true,
            Component::CurDir => {}
            Component::ParentDir => {
                if !out.is_empty() {
                    out.pop();
                }
                // At the root Node drops extra `..` as well.
            }
            Component::Normal(part) => out.push(part.to_os_string()),
            Component::Prefix(_) => {}
        }
    }
    let mut result = if rooted { PathBuf::from("/") } else { PathBuf::new() };
    for part in out {
        result.push(part);
    }
    if result.as_os_str().is_empty() && rooted {
        PathBuf::from("/")
    } else {
        result
    }
}

/// Mirrors Node's `path.resolve(...)`: joins the segments, then makes the
/// result absolute against the process cwd and normalizes lexically.
pub fn resolve_path(segments: &[&Path]) -> PathBuf {
    let mut joined = PathBuf::new();
    for segment in segments {
        if segment.is_absolute() {
            joined = segment.to_path_buf();
        } else {
            joined.push(segment);
        }
    }
    if joined.is_absolute() {
        normalize(&joined)
    } else {
        let cwd = std::env::current_dir().unwrap_or_else(|_| PathBuf::from("/"));
        normalize(&cwd.join(&joined))
    }
}

/// Mirrors Node's `path.relative(from, to)` for absolute paths (both sides
/// are always absolute in this port): common prefix plus `..` segments.
pub fn relative_path(from: &Path, to: &Path) -> String {
    let from_norm = normalize(from);
    let to_norm = normalize(to);
    let from_parts: Vec<_> = from_norm
        .components()
        .filter_map(|c| match c {
            Component::Normal(part) => Some(part.to_string_lossy().into_owned()),
            _ => None,
        })
        .collect();
    let to_parts: Vec<_> = to_norm
        .components()
        .filter_map(|c| match c {
            Component::Normal(part) => Some(part.to_string_lossy().into_owned()),
            _ => None,
        })
        .collect();
    let mut common = 0;
    while common < from_parts.len()
        && common < to_parts.len()
        && from_parts[common] == to_parts[common]
    {
        common += 1;
    }
    let mut out: Vec<String> = Vec::new();
    for _ in common..from_parts.len() {
        out.push("..".to_string());
    }
    out.extend(to_parts[common..].iter().cloned());
    out.join("/")
}

/// Mirrors Node's `path.basename` for the inputs used here.
pub fn basename(path: &str) -> String {
    let trimmed = path.trim_end_matches('/');
    match trimmed.rfind('/') {
        Some(index) => trimmed[index + 1..].to_string(),
        None => trimmed.to_string(),
    }
}

/// Mirrors Node's `path.extname`: from the last dot of the basename, unless
/// that dot is the basename's first character.
pub fn extname(path: &str) -> String {
    let base = basename(path);
    match base.rfind('.') {
        Some(0) | None => String::new(),
        Some(index) => base[index..].to_string(),
    }
}

/// Emits a JSON document plus a trailing newline synchronously through a
/// single locked `write_all` + `flush`, so a following `process::exit` cannot
/// truncate it (mirrors the JS `writeSync(1, ...)` from the commit "emit
/// large scan JSON synchronously so process.exit cannot truncate it").
pub(crate) fn write_json_line(text: &str) {
    use std::io::Write;
    let stdout = std::io::stdout();
    let mut out = stdout.lock();
    let _ = out.write_all(text.as_bytes());
    let _ = out.write_all(b"\n");
    let _ = out.flush();
}

/// Formats a number the way JS template interpolation renders the values
/// used here (`3` -> "3", `2.5` -> "2.5", NaN -> "NaN").
pub fn js_num(value: f64) -> String {
    if value.is_nan() {
        return "NaN".to_string();
    }
    if value.is_infinite() {
        return if value > 0.0 { "Infinity" } else { "-Infinity" }.to_string();
    }
    if value.fract() == 0.0 && value.abs() < 9.0e15 {
        format!("{}", value as i64)
    } else {
        format!("{}", value)
    }
}

/// Parses a string with (the used subset of) JS `Number()` semantics:
/// empty/whitespace -> 0, otherwise an f64 parse, NaN on garbage.
pub fn js_number(text: &str) -> f64 {
    let trimmed = text.trim();
    if trimmed.is_empty() {
        return 0.0;
    }
    trimmed.parse::<f64>().unwrap_or(f64::NAN)
}

/// Current UTC time in the shape of JS `new Date().toISOString()`
/// (`2026-07-25T01:46:13.617Z`), computed with std only.
pub fn iso_now() -> String {
    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default();
    let millis = now.subsec_millis();
    let total_secs = now.as_secs() as i64;
    let days = total_secs.div_euclid(86_400);
    let secs_of_day = total_secs.rem_euclid(86_400);
    let hour = secs_of_day / 3600;
    let minute = (secs_of_day % 3600) / 60;
    let second = secs_of_day % 60;
    // Howard Hinnant's civil-from-days algorithm.
    let z = days + 719_468;
    let era = z.div_euclid(146_097);
    let doe = z.rem_euclid(146_097);
    let yoe = (doe - doe / 1460 + doe / 36_524 - doe / 146_096) / 365;
    let y = yoe + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let day = doy - (153 * mp + 2) / 5 + 1;
    let month = if mp < 10 { mp + 3 } else { mp - 9 };
    let year = if month <= 2 { y + 1 } else { y };
    format!(
        "{:04}-{:02}-{:02}T{:02}:{:02}:{:02}.{:03}Z",
        year, month, day, hour, minute, second, millis
    )
}

/// Mirrors JS `a.path.localeCompare(b.path)` closely enough for repo paths:
/// base letters first (case-insensitive), lowercase before uppercase on ties.
pub fn locale_compare(a: &str, b: &str) -> std::cmp::Ordering {
    let folded_a: Vec<char> = a.chars().flat_map(|c| c.to_lowercase()).collect();
    let folded_b: Vec<char> = b.chars().flat_map(|c| c.to_lowercase()).collect();
    match folded_a.cmp(&folded_b) {
        std::cmp::Ordering::Equal => {
            // Tertiary: lowercase sorts before uppercase for the same letter.
            let rank = |s: &str| -> Vec<u8> {
                s.chars()
                    .map(|c| if c.is_uppercase() { 1 } else { 0 })
                    .collect()
            };
            rank(a).cmp(&rank(b))
        }
        other => other,
    }
}
