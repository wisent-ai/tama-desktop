//! Rust port of `shared-hooks/session-capability.mjs`.

use crate::util::{iso_from_millis, js_string, js_string_or_empty, parse_iso_millis};
use serde_json::{json, Map, Value};
use std::collections::{BTreeMap, BTreeSet};

pub const CAPABILITY_SCHEMA_VERSION: u64 = 2;
pub const CAPABILITY_ENV: &str = "AGENT_STRUCTURED_CAPABILITY";
pub const CAPABILITY_LIFETIMES: [&str; 3] = ["single-use", "expires-at", "current-session"];

/// Identity used to bind a capability to a release/catalog.
#[derive(Debug, Clone, Default)]
pub struct CapabilityIdentity {
    pub control_key: Option<String>,
    pub release_id: Option<String>,
    pub catalog_checksum: Option<String>,
}

fn valid_name(value: &str) -> bool {
    // /^[a-z][a-z0-9:_-]{0,127}$/
    let bytes = value.as_bytes();
    if bytes.is_empty() || bytes.len() > 128 {
        return false;
    }
    if !bytes[0].is_ascii_lowercase() {
        return false;
    }
    bytes[1..].iter().all(|b| {
        b.is_ascii_lowercase() || b.is_ascii_digit() || *b == b':' || *b == b'_' || *b == b'-'
    })
}

fn js_lower_string(value: &Value) -> String {
    // String(value || '').trim().toLowerCase()
    let raw = if value.is_null() || !crate::util::js_truthy(value) {
        String::new()
    } else {
        js_string(value)
    };
    raw.trim().to_lowercase()
}

/// Port of `normalizeCapabilityGrants`.
pub fn normalize_capability_grants(value: &Value) -> Option<Vec<Value>> {
    let grants = value.as_array()?;
    if grants.is_empty() {
        return None;
    }
    let mut merged: BTreeMap<String, Option<BTreeSet<String>>> = BTreeMap::new();
    for grant in grants {
        let obj = grant.as_object()?;
        let tool = js_lower_string(obj.get("tool").unwrap_or(&Value::Null));
        if !valid_name(&tool) {
            return None;
        }
        let actions: Option<Vec<String>> = match obj.get("actions") {
            None | Some(Value::Null) => None,
            Some(value) => {
                let items = value.as_array()?;
                if items.is_empty() {
                    return None;
                }
                let mut seen = Vec::new();
                for item in items {
                    let action = js_lower_string(item);
                    if !seen.contains(&action) {
                        seen.push(action);
                    }
                }
                if seen.iter().any(|a| !valid_name(a)) {
                    return None;
                }
                Some(seen)
            }
        };
        let existing = merged.get(&tool);
        match (existing, actions) {
            (Some(None), _) | (_, None) => {
                merged.insert(tool, None);
            }
            (Some(Some(existing)), Some(actions)) => {
                let mut union = existing.clone();
                union.extend(actions);
                merged.insert(tool, Some(union));
            }
            (None, Some(actions)) => {
                merged.insert(tool, Some(actions.into_iter().collect()));
            }
        }
    }
    Some(
        merged
            .into_iter()
            .map(|(tool, actions)| match actions {
                None => json!({ "tool": tool }),
                Some(actions) => json!({ "tool": tool, "actions": actions.into_iter().collect::<Vec<_>>() }),
            })
            .collect(),
    )
}

fn normalized_expiry(value: Option<&Value>, now_ms: f64) -> Option<String> {
    let raw = js_string_or_empty(value);
    let expires_at = parse_iso_millis(&raw);
    if !expires_at.is_finite() || expires_at <= now_ms {
        return None;
    }
    Some(iso_from_millis(expires_at))
}

/// Port of `normalizedCapability`.
pub fn normalized_capability(
    value: &Value,
    active_session_id: Option<&str>,
    now_ms: f64,
    identity: &CapabilityIdentity,
) -> Option<Value> {
    let obj = value.as_object()?;
    let grants = normalize_capability_grants(obj.get("grants").unwrap_or(&Value::Null))?;
    let lifetime = js_lower_string(obj.get("lifetime").unwrap_or(&Value::Null));
    let control_key = js_string_or_empty(obj.get("controlKey")).trim().to_string();
    let release_id = js_string_or_empty(obj.get("releaseId")).trim().to_string();
    let catalog_checksum = js_string_or_empty(obj.get("catalogChecksum")).trim().to_string();
    let session_id = js_string_or_empty(obj.get("sessionId"));
    let expected_session = active_session_id.unwrap_or("");

    let schema_ok = obj.get("schemaVersion").and_then(Value::as_u64) == Some(CAPABILITY_SCHEMA_VERSION);
    let issued_by = js_string_or_empty(obj.get("issuedBy"));
    let nonce = js_string_or_empty(obj.get("nonce"));
    if !schema_ok
        || issued_by.trim().is_empty()
        || nonce.trim().is_empty()
        || session_id != expected_session
        || control_key.is_empty()
        || release_id.is_empty()
        || catalog_checksum.is_empty()
        || identity
            .control_key
            .as_ref()
            .map(|k| !k.is_empty() && *k != control_key)
            .unwrap_or(false)
        || identity
            .release_id
            .as_ref()
            .map(|r| !r.is_empty() && *r != release_id)
            .unwrap_or(false)
        || identity
            .catalog_checksum
            .as_ref()
            .map(|c| !c.is_empty() && *c != catalog_checksum)
            .unwrap_or(false)
        || !CAPABILITY_LIFETIMES.contains(&lifetime.as_str())
    {
        return None;
    }

    let mut normalized = Map::new();
    normalized.insert("schemaVersion".into(), json!(CAPABILITY_SCHEMA_VERSION));
    normalized.insert("issuedBy".into(), json!(issued_by));
    normalized.insert("nonce".into(), json!(nonce));
    normalized.insert("sessionId".into(), json!(session_id));
    normalized.insert("controlKey".into(), json!(control_key));
    normalized.insert("releaseId".into(), json!(release_id));
    normalized.insert("catalogChecksum".into(), json!(catalog_checksum));
    normalized.insert("lifetime".into(), json!(lifetime));
    normalized.insert("grants".into(), Value::Array(grants));
    match lifetime.as_str() {
        "expires-at" => {
            let expires_at = normalized_expiry(obj.get("expiresAt"), now_ms)?;
            normalized.insert("expiresAt".into(), json!(expires_at));
        }
        "single-use" => {
            if obj.get("remainingUses").and_then(Value::as_i64) != Some(1) {
                return None;
            }
            normalized.insert("remainingUses".into(), json!(1));
        }
        _ => {}
    }
    Some(Value::Object(normalized))
}

/// Port of `capabilityEnvironment`: returns env additions/removals relative
/// to the inherited process environment.
pub fn capability_environment(
    capability: Option<&Value>,
    extra: &[(String, String)],
) -> (Vec<(String, String)>, Vec<String>) {
    let mut set: Vec<(String, String)> = extra.to_vec();
    let mut remove = Vec::new();
    match capability {
        Some(cap) => set.push((
            CAPABILITY_ENV.to_string(),
            serde_json::to_string(cap).unwrap_or_default(),
        )),
        None => remove.push(CAPABILITY_ENV.to_string()),
    }
    (set, remove)
}
