//! Shared helpers for the tama-testkit harness binaries: ports of the JS
//! semantics used by `src/tests/session-overrides.mjs`,
//! `src/tests/session-overrides/*.mjs` and
//! `src/tests/generate-configs-integrity.mjs`.
//!
//! The harnesses exercise the JavaScript hook runtime (the OMP adapter,
//! `run-hook.mjs`, `generate-configs.mjs`, `block_unauthorized_cua.py`), so —
//! exactly like the JS tests — the ported binaries spawn `node` / `python3`
//! for those parts. This module provides the fixture builders (fixture
//! registry with a valid catalog checksum, the recorder script, the OMP
//! adapter driver script) plus the small pieces of JS semantics the harness
//! itself relies on: SHA-256 hex digests, `Date.now()` /
//! `Date#toISOString()`, `fs.mkdtemp`, `spawnSync`, and insertion-ordered
//! JSON key extraction (`serde_json::Map` sorts keys, `JSON.parse` does not).
//!
//! The module is included by several binaries via `#[path]`; not every
//! binary uses every helper.
#![allow(dead_code)]

use std::env;
use std::ffi::{OsStr, OsString};
use std::fs;
use std::io::{BufRead, BufReader, Read, Write};
use std::path::{Path, PathBuf};
use std::process::{Child, ChildStdin, ChildStdout, Command, Stdio};
use std::time::{SystemTime, UNIX_EPOCH};

use serde_json::{json, Map, Value};

/// Harness assertion (`node:assert/strict` failures exit the process with
/// code 1; `Err` here does the same in the ported binaries).
pub fn check(condition: bool, message: impl Into<String>) -> Result<(), String> {
    if condition {
        Ok(())
    } else {
        Err(message.into())
    }
}

// ---------------------------------------------------------------------------
// SHA-256 (FIPS 180-4), hex-encoded — like Node's
// `createHash('sha256').update(data).digest('hex')`. Implemented locally
// because this crate must not take on new dependencies.
// ---------------------------------------------------------------------------

const SHA256_K: [u32; 64] = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
];

const SHA256_H0: [u32; 8] = [
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
];

pub fn sha256_hex(data: &[u8]) -> String {
    let mut h = SHA256_H0;

    let mut msg = data.to_vec();
    let bit_len = (data.len() as u64).wrapping_mul(8);
    msg.push(0x80);
    while msg.len() % 64 != 56 {
        msg.push(0);
    }
    msg.extend_from_slice(&bit_len.to_be_bytes());

    for chunk in msg.chunks_exact(64) {
        let mut w = [0u32; 64];
        for (i, word) in w.iter_mut().take(16).enumerate() {
            *word = u32::from_be_bytes([
                chunk[4 * i],
                chunk[4 * i + 1],
                chunk[4 * i + 2],
                chunk[4 * i + 3],
            ]);
        }
        for i in 16..64 {
            let s0 = w[i - 15].rotate_right(7) ^ w[i - 15].rotate_right(18) ^ (w[i - 15] >> 3);
            let s1 = w[i - 2].rotate_right(17) ^ w[i - 2].rotate_right(19) ^ (w[i - 2] >> 10);
            w[i] = w[i - 16]
                .wrapping_add(s0)
                .wrapping_add(w[i - 7])
                .wrapping_add(s1);
        }

        let (mut a, mut b, mut c, mut d, mut e, mut f, mut g, mut hh) =
            (h[0], h[1], h[2], h[3], h[4], h[5], h[6], h[7]);
        for i in 0..64 {
            let s1 = e.rotate_right(6) ^ e.rotate_right(11) ^ e.rotate_right(25);
            let ch = (e & f) ^ ((!e) & g);
            let t1 = hh
                .wrapping_add(s1)
                .wrapping_add(ch)
                .wrapping_add(SHA256_K[i])
                .wrapping_add(w[i]);
            let s0 = a.rotate_right(2) ^ a.rotate_right(13) ^ a.rotate_right(22);
            let maj = (a & b) ^ (a & c) ^ (b & c);
            let t2 = s0.wrapping_add(maj);
            hh = g;
            g = f;
            f = e;
            e = d.wrapping_add(t1);
            d = c;
            c = b;
            b = a;
            a = t1.wrapping_add(t2);
        }
        h[0] = h[0].wrapping_add(a);
        h[1] = h[1].wrapping_add(b);
        h[2] = h[2].wrapping_add(c);
        h[3] = h[3].wrapping_add(d);
        h[4] = h[4].wrapping_add(e);
        h[5] = h[5].wrapping_add(f);
        h[6] = h[6].wrapping_add(g);
        h[7] = h[7].wrapping_add(hh);
    }

    let mut out = String::with_capacity(64);
    for word in h {
        out.push_str(&format!("{word:08x}"));
    }
    out
}

/// `controlKey(provider, sessionId)` from `src/tests/session-overrides.mjs`:
/// `sha256(`${provider}\0${sessionId}`)`.
pub fn control_key(provider: &str, session_id: &str) -> String {
    sha256_hex(format!("{provider}\0{session_id}").as_bytes())
}

// ---------------------------------------------------------------------------
// JS Date semantics: `Date.now()` and `new Date(ms).toISOString()`.
// ---------------------------------------------------------------------------

/// Milliseconds since the Unix epoch, like `Date.now()`.
pub fn now_millis() -> f64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as f64)
        .unwrap_or(0.0)
}

fn civil_from_days(z: i64) -> (i64, i64, i64) {
    let z = z + 719468;
    let era = if z >= 0 { z } else { z - 146096 } / 146097;
    let doe = z - era * 146097; // [0, 146096]
    let yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    let y = yoe + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = doy - (153 * mp + 2) / 5 + 1;
    let m = if mp < 10 { mp + 3 } else { mp - 9 };
    (if m <= 2 { y + 1 } else { y }, m, d)
}

/// `new Date(ms).toISOString()` — always UTC, `YYYY-MM-DDTHH:mm:ss.sssZ`.
pub fn to_iso_string(ms: f64) -> String {
    let ms = ms.trunc() as i64;
    let days = ms.div_euclid(86_400_000);
    let rem = ms.rem_euclid(86_400_000);
    let (y, mo, d) = civil_from_days(days);
    let (hh, mi, ss, mss) = (
        rem / 3_600_000,
        (rem / 60_000) % 60,
        (rem / 1_000) % 60,
        rem % 1_000,
    );
    let year = if (0..=9999).contains(&y) {
        format!("{y:04}")
    } else if y > 9999 {
        format!("+{y:06}")
    } else {
        format!("-{:06}", -y)
    };
    format!("{year}-{mo:02}-{d:02}T{hh:02}:{mi:02}:{ss:02}.{mss:03}Z")
}

// ---------------------------------------------------------------------------
// `fs.mkdtemp(prefix)`: append six random [A-Za-z0-9] characters, create dir.
// ---------------------------------------------------------------------------

fn random_bytes<const N: usize>() -> [u8; N] {
    let mut buf = [0u8; N];
    if let Ok(mut f) = fs::File::open("/dev/urandom") {
        if f.read_exact(&mut buf).is_ok() {
            return buf;
        }
    }
    let nanos = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_nanos())
        .unwrap_or(0);
    for (i, b) in buf.iter_mut().enumerate() {
        *b = (nanos >> ((i % 16) * 8)) as u8;
    }
    buf
}

/// `await mkdtemp(prefix)` — `prefix` already ends with the `-` separator,
/// exactly like `mkdtemp(join(tmpdir(), 'tama-...-'))` in the JS tests.
pub fn mkdtemp(prefix: &Path) -> Result<PathBuf, String> {
    const ALNUM: &[u8] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    for _ in 0..100 {
        let bytes = random_bytes::<6>();
        let suffix: String = bytes
            .iter()
            .map(|b| ALNUM[(*b as usize) % ALNUM.len()] as char)
            .collect();
        let mut candidate = prefix.as_os_str().to_owned();
        candidate.push(&suffix);
        let candidate = PathBuf::from(candidate);
        match fs::create_dir(&candidate) {
            Ok(()) => return Ok(candidate),
            Err(e) if e.kind() == std::io::ErrorKind::AlreadyExists => continue,
            Err(e) => return Err(format!("mkdtemp {}: {e}", candidate.display())),
        }
    }
    Err(format!("mkdtemp {}: no unique suffix", prefix.display()))
}

// ---------------------------------------------------------------------------
// `spawnSync`: capture status/stdout/stderr with optional stdin input and
// environment overrides on top of the inherited environment. Undefined env
/// values in a Node `env` object are dropped from the child environment;
/// callers express that via `env_remove`.
// ---------------------------------------------------------------------------

pub struct SpawnOutput {
    /// `null` when the child was terminated by a signal (`result.status`).
    pub status: Option<i32>,
    pub stdout: String,
    pub stderr: String,
}

pub fn spawn_sync(
    program: &str,
    args: &[&str],
    input: Option<&str>,
    env_set: &[(String, String)],
    env_remove: &[&str],
) -> Result<SpawnOutput, String> {
    let mut command = Command::new(program);
    command.args(args);
    command.stdin(if input.is_some() {
        Stdio::piped()
    } else {
        Stdio::null()
    });
    command.stdout(Stdio::piped());
    command.stderr(Stdio::piped());
    for (key, value) in env_set {
        command.env(key, value);
    }
    for key in env_remove {
        command.env_remove(key);
    }
    let mut child = command
        .spawn()
        .map_err(|e| format!("spawn {program}: {e}"))?;
    if let Some(text) = input {
        let mut stdin = child.stdin.take().unwrap_or_else(|| unreachable!());
        stdin
            .write_all(text.as_bytes())
            .map_err(|e| format!("spawn {program} stdin: {e}"))?;
        drop(stdin);
    }
    let output = child
        .wait_with_output()
        .map_err(|e| format!("spawn {program}: {e}"))?;
    Ok(SpawnOutput {
        status: output.status.code(),
        stdout: String::from_utf8_lossy(&output.stdout).into_owned(),
        stderr: String::from_utf8_lossy(&output.stderr).into_owned(),
    })
}

// ---------------------------------------------------------------------------
// Environment snapshot/restore — `originalEnv` / `restoreEnv()` from
// `src/tests/session-overrides.mjs`.
// ---------------------------------------------------------------------------

pub struct EnvGuard {
    saved: Vec<(String, Option<OsString>)>,
}

impl EnvGuard {
    pub fn capture(keys: &[&str]) -> Self {
        Self {
            saved: keys
                .iter()
                .map(|key| (key.to_string(), env::var_os(key)))
                .collect(),
        }
    }

    pub fn get(&self, key: &str) -> Option<&OsStr> {
        self.saved
            .iter()
            .find(|(k, _)| k == key)
            .and_then(|(_, v)| v.as_deref())
    }

    pub fn restore(&self) {
        for (key, value) in &self.saved {
            match value {
                Some(value) => env::set_var(key, value),
                None => env::remove_var(key),
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Insertion-ordered JSON key extraction. `Object.keys(policy.tiers)`
/// preserves the document order; `serde_json::Value` does not, so the order
/// is recovered by scanning the raw JSON text.
// ---------------------------------------------------------------------------

fn skip_ws(bytes: &[u8], pos: &mut usize) {
    while *pos < bytes.len() && matches!(bytes[*pos], b' ' | b'\t' | b'\n' | b'\r') {
        *pos += 1;
    }
}

fn parse_json_string(bytes: &[u8], pos: &mut usize) -> Option<String> {
    if bytes.get(*pos) != Some(&b'"') {
        return None;
    }
    *pos += 1;
    let mut out = String::new();
    while *pos < bytes.len() {
        let b = bytes[*pos];
        *pos += 1;
        match b {
            b'"' => return Some(out),
            b'\\' => {
                let esc = *bytes.get(*pos)?;
                *pos += 1;
                match esc {
                    b'"' => out.push('"'),
                    b'\\' => out.push('\\'),
                    b'/' => out.push('/'),
                    b'b' => out.push('\u{0008}'),
                    b'f' => out.push('\u{000c}'),
                    b'n' => out.push('\n'),
                    b'r' => out.push('\r'),
                    b't' => out.push('\t'),
                    b'u' => {
                        let hex = bytes.get(*pos..*pos + 4)?;
                        *pos += 4;
                        let code = u16::from_str_radix(std::str::from_utf8(hex).ok()?, 16).ok()?;
                        out.push(char::from_u32(code as u32).unwrap_or('\u{fffd}'));
                    }
                    _ => return None,
                }
            }
            _ => {
                // Re-decode multi-byte UTF-8 sequences verbatim.
                if b < 0x80 {
                    out.push(b as char);
                } else {
                    let start = *pos - 1;
                    let len = if b >= 0xf0 {
                        4
                    } else if b >= 0xe0 {
                        3
                    } else {
                        2
                    };
                    *pos = start + len;
                    out.push_str(std::str::from_utf8(bytes.get(start..*pos)?).ok()?);
                }
            }
        }
    }
    None
}

fn skip_json_value(bytes: &[u8], pos: &mut usize) -> Option<()> {
    skip_ws(bytes, pos);
    match *bytes.get(*pos)? {
        b'"' => {
            parse_json_string(bytes, pos)?;
        }
        b'{' | b'[' => {
            let mut depth = 0i64;
            while *pos < bytes.len() {
                let b = bytes[*pos];
                if b == b'"' {
                    parse_json_string(bytes, pos)?;
                    continue;
                }
                *pos += 1;
                match b {
                    b'{' | b'[' => depth += 1,
                    b'}' | b']' => {
                        depth -= 1;
                        if depth == 0 {
                            return Some(());
                        }
                    }
                    _ => {}
                }
            }
            return None;
        }
        _ => {
            while *pos < bytes.len() && !matches!(bytes[*pos], b',' | b'}' | b']') {
                *pos += 1;
            }
        }
    }
    Some(())
}

/// Key order of the object stored under top-level `key` in a JSON document,
/// like `Object.keys(JSON.parse(text)[key])`.
pub fn nested_object_key_order(text: &str, key: &str) -> Option<Vec<String>> {
    let bytes = text.as_bytes();
    let mut pos = 0;
    skip_ws(bytes, &mut pos);
    if bytes.get(pos) != Some(&b'{') {
        return None;
    }
    pos += 1;
    loop {
        skip_ws(bytes, &mut pos);
        if bytes.get(pos) == Some(&b'}') {
            return None;
        }
        let name = parse_json_string(bytes, &mut pos)?;
        skip_ws(bytes, &mut pos);
        if bytes.get(pos) != Some(&b':') {
            return None;
        }
        pos += 1;
        skip_ws(bytes, &mut pos);
        if name == key && bytes.get(pos) == Some(&b'{') {
            pos += 1;
            let mut keys = Vec::new();
            loop {
                skip_ws(bytes, &mut pos);
                if bytes.get(pos) == Some(&b'}') {
                    return Some(keys);
                }
                keys.push(parse_json_string(bytes, &mut pos)?);
                skip_ws(bytes, &mut pos);
                if bytes.get(pos) != Some(&b':') {
                    return None;
                }
                pos += 1;
                skip_json_value(bytes, &mut pos)?;
                skip_ws(bytes, &mut pos);
                match bytes.get(pos) {
                    Some(b',') => pos += 1,
                    Some(b'}') => return Some(keys),
                    _ => return None,
                }
            }
        }
        skip_json_value(bytes, &mut pos)?;
        skip_ws(bytes, &mut pos);
        match bytes.get(pos) {
            Some(b',') => pos += 1,
            Some(b'}') => return None,
            _ => return None,
        }
    }
}

// ---------------------------------------------------------------------------
// Fixture registry — port of `src/tests/session-overrides/fixture-registry.mjs`.
// `stableValue` sorts object keys recursively; `serde_json::Map` is a sorted
// map, so its compact serialization is exactly `JSON.stringify(stableValue(...))`
// for the ASCII-only content used here.
// ---------------------------------------------------------------------------

pub const LOG_LIFECYCLE_COMMAND: &str = r##"node -e "let d='';process.stdin.on('data',(c)=>{d+=c}).on('end',()=>{const e=JSON.parse(d||'{}');require('node:fs').appendFileSync(process.env.TAMA_TEST_RECORDER_LOG,String(e.agent_hook_event||'unknown')+'\n');process.stdout.write(JSON.stringify({decision:'pass',results:[]}))})""##;

fn lifecycle_hook() -> Value {
    json!({ "id": "fixture-lifecycle-hook", "command": LOG_LIFECYCLE_COMMAND, "timeout": 5 })
}

/// `buildFixtureRegistry()`: the events object plus a valid catalog checksum
/// (sha256 of the stable serialization of the registry without the checksum).
pub fn build_fixture_registry() -> Value {
    let mut events = Map::new();
    let mut event = |name: &str, blocking: bool, hooks: Value| {
        events.insert(name.to_string(), json!({ "blocking": blocking, "hooks": hooks }));
    };
    event(
        "test:integrity",
        true,
        json!([{ "id": "block-numeric-literals", "command": "exit 2", "timeout": 1 }]),
    );
    event(
        "test:former-protected",
        true,
        json!([{ "id": "block-device-level-tests-without-consent", "command": "exit 2", "timeout": 1 }]),
    );
    event(
        "test:adapter",
        true,
        json!([{ "id": "fixture-registry-hook", "command": "exit 2", "timeout": 1 }]),
    );
    event("user_prompt_submit", false, json!([lifecycle_hook()]));
    event("stop", false, json!([lifecycle_hook()]));
    event("session_start:compact", false, json!([lifecycle_hook()]));
    event("post_tool_use:bash", true, json!([lifecycle_hook()]));
    event(
        "pre_tool_use:eval",
        true,
        json!([{ "id": "fixture-registry-hook", "command": "exit 2", "timeout": 1 }]),
    );

    let mut registry = Map::new();
    registry.insert("events".to_string(), Value::Object(events));
    let stable = serde_json::to_string(&Value::Object(registry.clone()))
        .unwrap_or_else(|_| unreachable!());
    registry.insert(
        "catalogChecksum".to_string(),
        json!(sha256_hex(stable.as_bytes())),
    );
    Value::Object(registry)
}

// ---------------------------------------------------------------------------
// `recorder.mjs` — the fixture hook runner written by the JS test
// (verbatim file content, including the leading newline).
// ---------------------------------------------------------------------------

pub const RECORDER_MJS: &str = "
import { appendFileSync } from 'node:fs'
const id = 'fixture-registry-hook'
const event = process.argv.at(-1)
appendFileSync(process.env.TAMA_TEST_RECORDER_LOG, event + '\\n')
const disabled = new Set(String(process.env.TAMA_DISABLED_HOOKS || '').split(',').filter(Boolean))
const enabledFilter = Object.hasOwn(process.env, 'TAMA_ENABLED_HOOKS')
const enabled = new Set(String(process.env.TAMA_ENABLED_HOOKS || '').split(',').filter(Boolean))
const skipped = disabled.has(id) || (enabledFilter && !enabled.has(id))
const blocked = !skipped && event.startsWith('pre_tool_use:')
process.stdout.write(JSON.stringify(blocked
  ? { decision: 'block', reason: id + ': fixture block', blockedHookId: id, results: [{ id, code: Number('2') }] }
  : { decision: 'pass', results: [{ id, skipped }] }))
";

// ---------------------------------------------------------------------------
// OMP adapter driver. The JS harness imports `omp-shared-hooks.js` directly
// and drives the registered tools/handlers in-process; the port spawns a
// `node` process running this script (written into the fixture directory)
// and steers it with newline-delimited JSON requests/responses on stdio.
// The mock `pi` object is a verbatim copy of the one in the JS test.
// ---------------------------------------------------------------------------

pub const DRIVER_MJS: &str = r##"import { createInterface } from 'node:readline'

const adapterPath = process.argv[2]
const adapter = await import(adapterPath + '?test=' + Date.now())
const tools = []
const commands = new Map()
const handlers = new Map()
const entries = []
const pi = {
  zod: {
    z: {
      object: (value) => value,
      string: () => ({ type: 'string', optional() { return this } }),
      boolean: () => ({ type: 'boolean', optional() { return this } }),
      literal: (value) => ({ value, optional() { return this } }),
      enum: (values) => ({ values, optional() { return this } }),
      array: () => ({
        optional() { return this },
        nonempty() { return this },
      }),
    },
  },
  registerTool: (tool) => tools.push(tool),
  registerCommand: (name, command) => commands.set(name, command),
  on: (event, handler) => handlers.set(event, handler),
  appendEntry: (customType, data) => entries.push({ customType, data }),
}
adapter.default(pi)

const context = { hasUI: true, ui: {} }

function handlerContext(spec) {
  if (!spec) return undefined
  if (spec.strictUi) {
    return {
      ui: { notify: () => { throw new Error('passing prompt must not notify') } },
      abort: () => { throw new Error('passing prompt must not abort') },
    }
  }
  const ctx = {}
  if (spec.cwd !== undefined) ctx.cwd = spec.cwd
  const sessionManager = {}
  if (spec.branch !== undefined) sessionManager.getBranch = () => spec.branch
  if (spec.sessionFile !== undefined) sessionManager.getSessionFile = () => spec.sessionFile
  ctx.sessionManager = sessionManager
  return ctx
}

function reply(value) {
  process.stdout.write(JSON.stringify(value) + '\n')
}

async function handle(request) {
  if (request.op === 'register') {
    return {
      tools: tools.map((tool) => ({ name: tool.name, approval: tool.approval ?? null })),
      commands: [...commands.keys()],
      handlers: [...handlers.keys()],
    }
  }
  if (request.op === 'execute') {
    const tool = tools.find((candidate) => candidate.name === request.tool)
    if (!tool) return { error: 'tool not registered: ' + request.tool }
    const result = await tool.execute(request.id, request.params, null, null, context)
    return { hasResult: result !== undefined, result: result ?? null }
  }
  if (request.op === 'handle') {
    const handler = handlers.get(request.event)
    if (!handler) return { error: 'handler not registered: ' + request.event }
    const result = await handler(request.payload, handlerContext(request.ctx))
    return { hasResult: result !== undefined, result: result ?? null }
  }
  if (request.op === 'command') {
    const command = commands.get(request.name)
    if (!command) return { error: 'command not registered: ' + request.name }
    const result = await command.handler(request.args ?? {}, {
      ...context,
      reload: async () => {},
      ui: { notify: () => {} },
    })
    return { hasResult: result !== undefined, result: result ?? null }
  }
  if (request.op === 'entries') {
    return { count: entries.length }
  }
  return { error: 'unknown op: ' + request.op }
}

const rl = createInterface({ input: process.stdin })
for await (const line of rl) {
  if (!line.trim()) continue
  let response
  try {
    response = await handle(JSON.parse(line))
  } catch (error) {
    response = { error: error instanceof Error ? error.message : String(error) }
  }
  reply(response)
}
"##;

/// A running `node` driver process hosting the OMP adapter.
pub struct Driver {
    child: Child,
    stdin: ChildStdin,
    stdout: BufReader<ChildStdout>,
}

impl Driver {
    pub fn spawn(driver_path: &Path, adapter_path: &Path) -> Result<Self, String> {
        let mut child = Command::new("node")
            .arg(driver_path)
            .arg(adapter_path)
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            // The adapter writes malfunction diagnostics to stderr; like the
            // JS harness, let them flow through to our own stderr.
            .stderr(Stdio::inherit())
            .spawn()
            .map_err(|e| format!("spawn node {}: {e}", driver_path.display()))?;
        let stdin = child.stdin.take().unwrap_or_else(|| unreachable!());
        let stdout = BufReader::new(child.stdout.take().unwrap_or_else(|| unreachable!()));
        Ok(Self {
            child,
            stdin,
            stdout,
        })
    }

    /// Send one request, read one response. A driver-level `error` field is
    /// the equivalent of the awaited call throwing in the JS test.
    pub fn request(&mut self, payload: &Value) -> Result<Value, String> {
        let mut line = serde_json::to_string(payload).map_err(|e| e.to_string())?;
        line.push('\n');
        self.stdin
            .write_all(line.as_bytes())
            .and_then(|()| self.stdin.flush())
            .map_err(|e| format!("driver request: {e}"))?;
        let mut response = String::new();
        let read = self
            .stdout
            .read_line(&mut response)
            .map_err(|e| format!("driver response: {e}"))?;
        if read == 0 {
            return Err("driver exited without a response".to_string());
        }
        let value: Value = serde_json::from_str(&response)
            .map_err(|e| format!("driver response is not JSON: {e}: {response}"))?;
        if let Some(error) = value.get("error") {
            let message = error.as_str().map(str::to_string).unwrap_or_else(|| error.to_string());
            return Err(message);
        }
        Ok(value)
    }

    pub fn shutdown(mut self) {
        drop(self.stdin);
        let _ = self.child.wait();
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn sha256_known_vectors() {
        assert_eq!(
            sha256_hex(b""),
            "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        );
        assert_eq!(
            sha256_hex(b"abc"),
            "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
        );
    }

    #[test]
    fn fixture_registry_checksum_matches_node() {
        // Reference value computed by `node` from
        // `src/tests/session-overrides/fixture-registry.mjs`.
        let registry = build_fixture_registry();
        assert_eq!(
            registry["catalogChecksum"].as_str(),
            Some("d5173a339ea73bebda80163d8a86cff40fe4d36a7832a37cca2852e1b8597b8b")
        );
    }

    #[test]
    fn control_key_matches_node() {
        // Reference value computed by `node` for sha256("omp\0session-c").
        assert_eq!(
            control_key("omp", "session-c"),
            "7653bff7edf7a3022917cb28b269f9a7ab8def5e1b7967bb85d2df44ec574c78"
        );
    }

    #[test]
    fn iso_string() {
        assert_eq!(to_iso_string(0.0), "1970-01-01T00:00:00.000Z");
        assert_eq!(
            to_iso_string(1_735_689_600_123.0),
            "2025-01-01T00:00:00.123Z"
        );
    }

    #[test]
    fn key_order() {
        let text = r#"{"a": 1, "tiers": {"integrity": {}, "etiquette": {"x": [1, {"}": 2}]}}, "z": 2}"#;
        assert_eq!(
            nested_object_key_order(text, "tiers"),
            Some(vec!["integrity".to_string(), "etiquette".to_string()])
        );
        assert_eq!(nested_object_key_order(text, "missing"), None);
    }
}
