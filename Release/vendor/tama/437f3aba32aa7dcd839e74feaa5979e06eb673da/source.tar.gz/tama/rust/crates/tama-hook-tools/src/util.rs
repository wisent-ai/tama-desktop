//! Shared std-only helpers for the `tama-hook-tools` binaries:
//! path resolution, JS-compatible primitives (`Number`, `String`, truthiness),
//! ISO-8601 timestamps, SHA-256, UUIDv4, atomic JSON writes and a minimal
//! unix signal FFI (declared directly, no external crates).

use serde_json::Value;
use std::path::{Component, Path, PathBuf};

/// Node `os.homedir()` equivalent: `$HOME` on unix.
pub fn home_dir() -> PathBuf {
    std::env::var_os("HOME")
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from("/"))
}

/// Repo root: `TAMA_ROOT` when set, otherwise resolved relative to the crate
/// manifest (`rust/crates/tama-hook-tools` -> three levels up).
pub fn repo_root() -> PathBuf {
    if let Some(root) = std::env::var_os("TAMA_ROOT") {
        return PathBuf::from(root);
    }
    normalize_path(Path::new(env!("CARGO_MANIFEST_DIR")).join("../../..").as_path())
}

/// Directory that mirrors the JS `shared-hooks/` folder inside the repo.
pub fn shared_hooks_root() -> PathBuf {
    repo_root().join("shared-hooks")
}

/// Lexical normalization (`.`, `..`), without touching the filesystem —
/// the same semantics as Node `path.resolve` on an already-absolute path.
pub fn normalize_path(path: &Path) -> PathBuf {
    let mut out = PathBuf::new();
    for component in path.components() {
        match component {
            Component::CurDir => {}
            Component::ParentDir => {
                out.pop();
            }
            other => out.push(other.as_os_str()),
        }
    }
    out
}

/// Node `path.resolve(value)`.
pub fn resolve_path(value: &str) -> PathBuf {
    let path = Path::new(value);
    if path.is_absolute() {
        normalize_path(path)
    } else {
        let cwd = std::env::current_dir().unwrap_or_else(|_| PathBuf::from("/"));
        normalize_path(&cwd.join(path))
    }
}

/// Node `path.extname`.
pub fn extname(path: &str) -> String {
    let base = path.rsplit('/').next().unwrap_or(path);
    match base.rfind('.') {
        None | Some(0) => String::new(),
        Some(index) => base[index..].to_string(),
    }
}

/// JS `String(value)` for JSON values.
pub fn js_string(value: &Value) -> String {
    match value {
        Value::Null => "null".to_string(),
        Value::Bool(b) => b.to_string(),
        Value::Number(n) => n.to_string(),
        Value::String(s) => s.clone(),
        Value::Array(items) => items.iter().map(js_string).collect::<Vec<_>>().join(","),
        Value::Object(_) => "[object Object]".to_string(),
    }
}

/// JS `String(value || '')` — empty string for null/missing/false/0/"".
pub fn js_string_or_empty(value: Option<&Value>) -> String {
    match value {
        Some(v) if js_truthy(v) => js_string(v),
        _ => String::new(),
    }
}

/// JS truthiness for JSON values.
pub fn js_truthy(value: &Value) -> bool {
    match value {
        Value::Null => false,
        Value::Bool(b) => *b,
        Value::Number(n) => n.as_f64().map(|f| f != 0.0 && !f.is_nan()).unwrap_or(false),
        Value::String(s) => !s.is_empty(),
        Value::Array(_) | Value::Object(_) => true,
    }
}

/// JS `Number(string)`.
pub fn js_number(text: &str) -> f64 {
    let trimmed = text.trim();
    if trimmed.is_empty() {
        return 0.0;
    }
    match trimmed {
        "Infinity" | "+Infinity" => f64::INFINITY,
        "-Infinity" => f64::NEG_INFINITY,
        _ => trimmed.parse::<f64>().unwrap_or(f64::NAN),
    }
}

/// JS number-to-string interpolation (`${n}`) for JSON numbers.
pub fn js_number_to_string(value: &Value) -> String {
    match value.as_f64() {
        Some(f) => {
            if f.is_finite() && f.fract() == 0.0 && f.abs() < 1e21 {
                format!("{}", f as i64)
            } else {
                format!("{}", f)
            }
        }
        None => js_string(value),
    }
}

/// Milliseconds since the unix epoch (JS `Date.now()`).
pub fn now_millis() -> f64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_millis() as f64)
        .unwrap_or(0.0)
}

fn civil_from_days(z: i64) -> (i64, u32, u32) {
    let z = z + 719468;
    let era = if z >= 0 { z } else { z - 146096 } / 146097;
    let doe = (z - era * 146097) as u64;
    let yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    let y = yoe as i64 + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = (doy - (153 * mp + 2) / 5 + 1) as u32;
    let m = if mp < 10 { mp + 3 } else { mp - 9 } as u32;
    (if m <= 2 { y + 1 } else { y }, m, d)
}

fn days_from_civil(y: i64, m: u32, d: u32) -> i64 {
    let y = if m <= 2 { y - 1 } else { y };
    let era = if y >= 0 { y } else { y - 399 } / 400;
    let yoe = (y - era * 400) as u64;
    let mp = if m > 2 { m - 3 } else { m + 9 } as u64;
    let doy = (153 * mp + 2) / 5 + d as u64 - 1;
    let doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    era * 146097 + doe as i64 - 719468
}

/// JS `new Date(ms).toISOString()` — `YYYY-MM-DDTHH:MM:SS.sssZ`.
pub fn iso_from_millis(ms: f64) -> String {
    let total = ms.trunc() as i64;
    let days = total.div_euclid(86_400_000);
    let day_ms = total.rem_euclid(86_400_000);
    let (year, month, day) = civil_from_days(days);
    let hour = day_ms / 3_600_000;
    let minute = (day_ms % 3_600_000) / 60_000;
    let second = (day_ms % 60_000) / 1000;
    let millis = day_ms % 1000;
    format!(
        "{:04}-{:02}-{:02}T{:02}:{:02}:{:02}.{:03}Z",
        year, month, day, hour, minute, second, millis
    )
}

/// JS `new Date().toISOString()`.
pub fn iso_now() -> String {
    iso_from_millis(now_millis())
}

/// JS `Date.parse` restricted to ISO-8601 input (`YYYY-MM-DD[THH:MM[:SS[.sss]]][Z|±hh:mm]`).
/// Returns NaN when the input does not parse, like `Date.parse`.
/// Note: JS parses timezone-less date-times as *local* time; this port treats
/// them as UTC (no timezone database in std).
pub fn parse_iso_millis(input: &str) -> f64 {
    let text = input.trim();
    let bytes = text.as_bytes();
    let mut pos = 0usize;
    let take = |pos: &mut usize, n: usize| -> Option<i64> {
        if *pos + n > bytes.len() {
            return None;
        }
        let slice = &text[*pos..*pos + n];
        if !slice.bytes().all(|b| b.is_ascii_digit()) {
            return None;
        }
        *pos += n;
        slice.parse::<i64>().ok()
    };
    let year = match take(&mut pos, 4) {
        Some(v) => v,
        None => return f64::NAN,
    };
    let sep = |pos: &mut usize, c: u8| -> bool {
        if pos.checked_add(0).is_some() && *pos < bytes.len() && bytes[*pos] == c {
            *pos += 1;
            true
        } else {
            false
        }
    };
    if !sep(&mut pos, b'-') {
        return f64::NAN;
    }
    let month = match take(&mut pos, 2) {
        Some(v) if (1..=12).contains(&v) => v as u32,
        _ => return f64::NAN,
    };
    if !sep(&mut pos, b'-') {
        return f64::NAN;
    }
    let day = match take(&mut pos, 2) {
        Some(v) if (1..=31).contains(&v) => v as u32,
        _ => return f64::NAN,
    };
    let mut millis = days_from_civil(year, month, day) * 86_400_000;
    if pos >= bytes.len() {
        return millis as f64;
    }
    if !(sep(&mut pos, b'T') || sep(&mut pos, b' ')) {
        return f64::NAN;
    }
    let hour = match take(&mut pos, 2) {
        Some(v) if v <= 24 => v,
        _ => return f64::NAN,
    };
    if !sep(&mut pos, b':') {
        return f64::NAN;
    }
    let minute = match take(&mut pos, 2) {
        Some(v) if v < 60 => v,
        _ => return f64::NAN,
    };
    let mut second = 0i64;
    let mut frac = 0i64;
    if sep(&mut pos, b':') {
        second = match take(&mut pos, 2) {
            Some(v) if v < 62 => v,
            _ => return f64::NAN,
        };
        if sep(&mut pos, b'.') {
            let start = pos;
            while pos < bytes.len() && bytes[pos].is_ascii_digit() {
                pos += 1;
            }
            let digits = &text[start..pos];
            if digits.is_empty() {
                return f64::NAN;
            }
            let mut scaled = digits[..digits.len().min(3)].to_string();
            while scaled.len() < 3 {
                scaled.push('0');
            }
            frac = scaled.parse::<i64>().unwrap_or(0);
        }
    }
    let mut offset = 0i64;
    if pos < bytes.len() {
        if sep(&mut pos, b'Z') {
            // UTC
        } else {
            let sign = if sep(&mut pos, b'+') {
                1
            } else if sep(&mut pos, b'-') {
                -1
            } else {
                return f64::NAN;
            };
            let oh = match take(&mut pos, 2) {
                Some(v) => v,
                None => return f64::NAN,
            };
            let _ = sep(&mut pos, b':');
            let om = match take(&mut pos, 2) {
                Some(v) => v,
                None => return f64::NAN,
            };
            offset = sign * (oh * 60 + om) * 60_000;
        }
    }
    if pos != bytes.len() {
        return f64::NAN;
    }
    millis += (hour * 3_600_000) + (minute * 60_000) + (second * 1000) + frac - offset;
    millis as f64
}

/// SHA-256 hex digest (std-only implementation).
pub fn sha256_hex(data: &[u8]) -> String {
    const K: [u32; 64] = [
        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4,
        0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe,
        0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f,
        0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
        0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b,
        0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116,
        0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
        0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7,
        0xc67178f2,
    ];
    let mut h: [u32; 8] = [
        0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab,
        0x5be0cd19,
    ];
    let mut message = data.to_vec();
    let bit_len = (data.len() as u64).wrapping_mul(8);
    message.push(0x80);
    while message.len() % 64 != 56 {
        message.push(0);
    }
    message.extend_from_slice(&bit_len.to_be_bytes());
    for chunk in message.chunks_exact(64) {
        let mut w = [0u32; 64];
        for (i, word) in w.iter_mut().take(16).enumerate() {
            *word = u32::from_be_bytes([
                chunk[i * 4],
                chunk[i * 4 + 1],
                chunk[i * 4 + 2],
                chunk[i * 4 + 3],
            ]);
        }
        for i in 16..64 {
            let s0 = w[i - 15].rotate_right(7) ^ w[i - 15].rotate_right(18) ^ (w[i - 15] >> 3);
            let s1 = w[i - 2].rotate_right(17) ^ w[i - 2].rotate_right(19) ^ (w[i - 2] >> 10);
            w[i] = w[i - 16]
                .wrapping_add(s0)
                .wrapping_add(w[i - 7])
                .wrapping_add(s1);
        }
        let [mut a, mut b, mut c, mut d, mut e, mut f, mut g, mut hh] = h;
        for i in 0..64 {
            let s1 = e.rotate_right(6) ^ e.rotate_right(11) ^ e.rotate_right(25);
            let ch = (e & f) ^ ((!e) & g);
            let temp1 = hh
                .wrapping_add(s1)
                .wrapping_add(ch)
                .wrapping_add(K[i])
                .wrapping_add(w[i]);
            let s0 = a.rotate_right(2) ^ a.rotate_right(13) ^ a.rotate_right(22);
            let maj = (a & b) ^ (a & c) ^ (b & c);
            let temp2 = s0.wrapping_add(maj);
            hh = g;
            g = f;
            f = e;
            e = d.wrapping_add(temp1);
            d = c;
            c = b;
            b = a;
            a = temp1.wrapping_add(temp2);
        }
        h[0] = h[0].wrapping_add(a);
        h[1] = h[1].wrapping_add(b);
        h[2] = h[2].wrapping_add(c);
        h[3] = h[3].wrapping_add(d);
        h[4] = h[4].wrapping_add(e);
        h[5] = h[5].wrapping_add(f);
        h[6] = h[6].wrapping_add(g);
        h[7] = h[7].wrapping_add(hh);
    }
    let mut out = String::with_capacity(64);
    for word in h {
        out.push_str(&format!("{:08x}", word));
    }
    out
}

/// JS `crypto.randomUUID()` (UUIDv4, lowercase).
pub fn random_uuid() -> String {
    use std::io::Read;
    let mut bytes = [0u8; 16];
    let filled = std::fs::File::open("/dev/urandom")
        .and_then(|mut f| f.read_exact(&mut bytes))
        .is_ok();
    if !filled {
        // Last-resort entropy: time, pid and stack address mixed together.
        let mut seed = now_millis() as u64
            ^ ((std::process::id() as u64) << 32)
            ^ (&bytes as *const _ as usize as u64);
        for b in bytes.iter_mut() {
            seed ^= seed << 13;
            seed ^= seed >> 7;
            seed ^= seed << 17;
            *b = seed as u8;
        }
    }
    bytes[6] = (bytes[6] & 0x0f) | 0x40;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    let hex: String = bytes.iter().map(|b| format!("{:02x}", b)).collect();
    format!(
        "{}-{}-{}-{}-{}",
        &hex[0..8],
        &hex[8..12],
        &hex[12..16],
        &hex[16..20],
        &hex[20..32]
    )
}

/// Port of `atomicWriteJson` from session-control.mjs / omp-shared-hooks.js:
/// creates `root` with mode 0700, writes `${JSON.stringify(value)}\n` to a
/// unique sibling temp file (mode 0600, exclusive create), then renames.
pub fn atomic_write_json(root: &Path, path: &Path, value: &Value) -> std::io::Result<()> {
    use std::os::unix::fs::OpenOptionsExt;
    use std::os::unix::fs::PermissionsExt;
    std::fs::create_dir_all(root)?;
    std::fs::set_permissions(root, std::fs::Permissions::from_mode(0o700))?;
    use std::io::Write;
    let temporary = format!(
        "{}.{}.{}.tmp",
        path.display(),
        std::process::id(),
        random_uuid()
    );
    let result = (|| -> std::io::Result<()> {
        let mut file = std::fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .mode(0o600)
            .open(&temporary)?;
        file.write_all(format!("{}\n", serde_json::to_string(value).unwrap_or_default()).as_bytes())?;
        drop(file);
        std::fs::rename(&temporary, path)?;
        Ok(())
    })();
    let _ = std::fs::remove_file(&temporary);
    result
}

/// JS `JSON.parse(fs.readFileSync(path, 'utf8'))` with a silent fallback.
pub fn load_json(path: &Path, fallback: Value) -> Value {
    std::fs::read_to_string(path)
        .ok()
        .and_then(|text| serde_json::from_str(&text).ok())
        .unwrap_or(fallback)
}

/// Minimal unix signal FFI (libc symbols are always linked on unix; declared
/// here directly so no external crate is needed).
#[cfg(unix)]
pub mod sys {
    pub const SIGHUP: i32 = 1;
    pub const SIGINT: i32 = 2;
    pub const SIGTERM: i32 = 15;

    extern "C" {
        fn signal(signum: i32, handler: extern "C" fn(i32)) -> isize;
        fn kill(pid: i32, sig: i32) -> i32;
    }

    pub fn install_signal_handler(signum: i32, handler: extern "C" fn(i32)) {
        unsafe {
            signal(signum, handler);
        }
    }

    /// Returns false when the process no longer exists (ESRCH).
    pub fn send_signal(pid: u32, sig: i32) -> bool {
        unsafe { kill(pid as i32, sig) == 0 }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn sha256_known_vectors() {
        assert_eq!(
            sha256_hex(b"abc"),
            "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
        );
        assert_eq!(
            sha256_hex(b""),
            "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        );
    }

    /// Values cross-checked against Node `Date.parse` / `Date#toISOString`.
    #[test]
    fn iso_time_matches_node() {
        assert_eq!(parse_iso_millis("2026-07-25T01:46:13.612Z"), 1784943973612.0);
        assert_eq!(parse_iso_millis("2026-07-25"), 1784937600000.0);
        assert_eq!(parse_iso_millis("2026-01-01T00:00:00+02:00"), 1767218400000.0);
        assert_eq!(parse_iso_millis("2026-07-25T01:46:13Z"), 1784943973000.0);
        assert!(parse_iso_millis("not a date").is_nan());
        assert!(parse_iso_millis("2026-13-01").is_nan());
        assert_eq!(iso_from_millis(1784943973612.0), "2026-07-25T01:46:13.612Z");
        assert_eq!(iso_from_millis(1784928373612.0), "2026-07-24T21:26:13.612Z");
    }

    #[test]
    fn extname_matches_node() {
        assert_eq!(extname("foo.tar.gz"), ".gz");
        assert_eq!(extname(".gitignore"), "");
        assert_eq!(extname("/a/b/c.py"), ".py");
        assert_eq!(extname("noext"), "");
        assert_eq!(extname("foo."), ".");
    }
}

// ---------------------------------------------------------------------------
// Insertion-order JSON helpers. serde_json maps are BTreeMaps (sorted), but
// `JSON.stringify` preserves the parse/insertion order; for byte-identical
// output the order has to be recovered from the raw text or given explicitly.
// ---------------------------------------------------------------------------

fn json_skip_ws(bytes: &[u8], mut i: usize) -> usize {
    while i < bytes.len() && bytes[i].is_ascii_whitespace() {
        i += 1;
    }
    i
}

fn json_skip_string(bytes: &[u8], mut i: usize) -> usize {
    // bytes[i] == '"'
    i += 1;
    while i < bytes.len() {
        match bytes[i] {
            b'\\' => i += 2,
            b'"' => return i + 1,
            _ => i += 1,
        }
    }
    i
}

fn json_skip_value(bytes: &[u8], mut i: usize) -> usize {
    i = json_skip_ws(bytes, i);
    if i >= bytes.len() {
        return i;
    }
    match bytes[i] {
        b'"' => json_skip_string(bytes, i),
        b'{' | b'[' => {
            let mut depth = 0usize;
            while i < bytes.len() {
                match bytes[i] {
                    b'"' => i = json_skip_string(bytes, i),
                    b'{' | b'[' => {
                        depth += 1;
                        i += 1;
                    }
                    b'}' | b']' => {
                        depth -= 1;
                        i += 1;
                        if depth == 0 {
                            return i;
                        }
                    }
                    _ => i += 1,
                }
            }
            i
        }
        _ => {
            while i < bytes.len() && !matches!(bytes[i], b',' | b'}' | b']') {
                i += 1;
            }
            i
        }
    }
}

/// Iterate the top-level entries of the JSON object starting at `start`
/// (which must point at `{`), calling `visit(key, value_start)` in file order.
fn json_object_entries(text: &str, start: usize, visit: &mut dyn FnMut(&str, usize)) {
    let bytes = text.as_bytes();
    let mut i = json_skip_ws(bytes, start);
    if i >= bytes.len() || bytes[i] != b'{' {
        return;
    }
    i += 1;
    loop {
        i = json_skip_ws(bytes, i);
        if i >= bytes.len() || bytes[i] == b'}' {
            return;
        }
        if bytes[i] != b'"' {
            return;
        }
        let key_end = json_skip_string(bytes, i);
        let key = &text[i + 1..key_end - 1];
        i = json_skip_ws(bytes, key_end);
        if i >= bytes.len() || bytes[i] != b':' {
            return;
        }
        let value_start = json_skip_ws(bytes, i + 1);
        visit(key, value_start);
        i = json_skip_value(bytes, value_start);
        i = json_skip_ws(bytes, i);
        if i >= bytes.len() {
            return;
        }
        match bytes[i] {
            b',' => i += 1,
            b'}' => return,
            _ => return,
        }
    }
}

/// Top-level key order of the object at `path` (e.g. `["events"]`) in raw
/// JSON text. Keys are returned raw (no unescaping — registry keys are plain
/// ASCII). Empty when the path does not resolve to an object.
pub fn ordered_object_keys(text: &str, path: &[&str]) -> Vec<String> {
    let mut start = 0usize;
    for segment in path {
        let mut found = None;
        json_object_entries(text, start, &mut |key, value_start| {
            if found.is_none() && key == *segment {
                found = Some(value_start);
            }
        });
        match found {
            Some(value_start) => start = value_start,
            None => return Vec::new(),
        }
    }
    let mut keys = Vec::new();
    json_object_entries(text, start, &mut |key, _| keys.push(key.to_string()));
    keys
}

/// `JSON.stringify(object, null, 2)` with an explicit key order — the pairs
/// are emitted in the given sequence, values use the standard 2-space pretty
/// printer (nested content re-indented like `JSON.stringify`).
pub fn stringify_pretty_ordered(pairs: &[(&str, Value)]) -> String {
    if pairs.is_empty() {
        return "{}".to_string();
    }
    let mut out = String::from("{\n");
    for (index, (key, value)) in pairs.iter().enumerate() {
        out.push_str("  ");
        out.push_str(&serde_json::to_string(key).unwrap_or_default());
        out.push_str(": ");
        let rendered = serde_json::to_string_pretty(value).unwrap_or_default();
        out.push_str(&rendered.replace('\n', "\n  "));
        if index + 1 < pairs.len() {
            out.push(',');
        }
        out.push('\n');
    }
    out.push('}');
    out
}
