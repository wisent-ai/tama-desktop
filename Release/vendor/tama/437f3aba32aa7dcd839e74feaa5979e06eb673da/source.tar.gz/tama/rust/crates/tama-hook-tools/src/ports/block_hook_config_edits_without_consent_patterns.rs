//! Regex sources for `shared-hooks/block_hook_config_edits_without_consent.py`
//! (registry hook `block-hook-config-edits-without-consent`).
//!
//! Translation notes, all mechanical:
//!   * `re.IGNORECASE` becomes the inline `(?i)` flag.
//!   * Python's non-multiline `$` matches at the end of the text *or* just
//!     before a single trailing newline. The Rust `regex` crate has no
//!     lookahead and its `$` is end-of-text only, so every `$` is written
//!     `\n?\z`, which accepts the same two positions.
//!   * The character class `['\"]` is written `[\x27\x22]`: the same two
//!     characters, without putting a bare double quote inside the source.
//! No pattern used a backreference or a lookaround, so nothing needed
//! restructuring.

use regex::Regex;

const PROTECTED_PATH: &str = concat!(
    r"(?i)(",
    r"(^|/)\.git/hooks(/|\n?\z)",
    r"|(^|/)\.githooks(/|\n?\z)",
    r"|(^|/)repo-githooks(/|\n?\z)",
    r"|(^|/)\.husky(/|\n?\z)",
    r"|(^|/)lefthook\.ya?ml\n?\z",
    r"|(^|/)\.pre-commit-config\.ya?ml\n?\z",
    r"|(^|/)\.claude/(settings[^/]*\.json|hooks(/|\n?\z))",
    r"|(^|/)\.codex/(hooks\.json|hooks(/|\n?\z))",
    r"|(^|/)\.omp/agent/hooks(/|\n?\z)",
    r"|(^|/)\.kimi-code/(config\.toml\n?\z|hooks(/|\n?\z))",
    r"|(^|/)\.shared-hooks(/|\n?\z)",
    r"|(^|/)tama/(shared-hooks|codex-hooks|claude-hooks|repo-githooks|src)(/|\n?\z)",
    r")",
);

const WRITE_COMMAND: &str = concat!(
    r"(?i)(",
    r">\s*[^\s;|&]+",
    r"|\b(tee|touch|mkdir|rm|rmdir|cp|mv|install|rsync|dd|chmod)\b",
    r"|\bsed\s+[^;&|]*-[^;&|]*i\b",
    r"|\b(Bun\.write|writeFileSync|writeFile|appendFile|copyFile|rename|unlink|rmdir|remove",
    r"|open\s*\([^)]*[\x27\x22][wax]",
    r"|Path\([^)]*\)\.(?:write_text|write_bytes|unlink|rmdir|rename)",
    r"|fs\s*\.\s*(?:writeFile|appendFile|copyFile|rename|unlink|rm|rmdir)",
    r"|shutil\s*\.\s*(?:rmtree|move)",
    r"|os\s*\.\s*(?:remove|unlink|rmdir|rename))\b",
    r")",
);

const OPAQUE_PATCH: &str = r"(?i)\b(git\s+apply|patch\b|ed\b|ex\b)";
const GIT_HOOKSPATH: &str = r"(?i)\bgit\s+config\b[^;&|\n]*\bcore\.hooksPath\b";
const GIT_CONFIG_PATH: &str = r"(?i)(^|/)\.git/config\n?\z";

/// `re.split` sources: command word boundaries, and shell command separators.
const COMMAND_TOKEN_SPLIT: &str = r"[\s;&|<>()]+";
const SEGMENT_SPLIT: &str = r"[;&|]+";

/// `^\[([^#\]\n]+)#`, `^\*\*\* (?:Add|Update|Delete) File: (.+)$` and
/// `^(?:---|\+\+\+) [ab]/(.+)$`, each anchored the way `re.match` anchors.
const PATCH_BRACKET: &str = r"^\[(?P<target>[^#\]\n]+)#";
const PATCH_FILE_HEADER: &str = r"^\*\*\* (?:Add|Update|Delete) File: (?P<target>.+)\n?\z";
const PATCH_DIFF_HEADER: &str = r"^(?:---|\+\+\+) [ab]/(?P<target>.+)\n?\z";

/// Every compiled pattern the guard needs, built once per process.
pub struct Patterns {
    pub protected_path: Regex,
    pub write_command: Regex,
    pub opaque_patch: Regex,
    pub git_hookspath: Regex,
    pub git_config_path: Regex,
    pub command_token_split: Regex,
    pub segment_split: Regex,
    pub patch_bracket: Regex,
    pub patch_file_header: Regex,
    pub patch_diff_header: Regex,
}

impl Patterns {
    /// A pattern that fails to compile is a defect in this file, not a payload
    /// the guard should silently wave through.
    pub fn compile() -> Self {
        let build = |source: &str| Regex::new(source).expect(source);
        Self {
            protected_path: build(PROTECTED_PATH),
            write_command: build(WRITE_COMMAND),
            opaque_patch: build(OPAQUE_PATCH),
            git_hookspath: build(GIT_HOOKSPATH),
            git_config_path: build(GIT_CONFIG_PATH),
            command_token_split: build(COMMAND_TOKEN_SPLIT),
            segment_split: build(SEGMENT_SPLIT),
            patch_bracket: build(PATCH_BRACKET),
            patch_file_header: build(PATCH_FILE_HEADER),
            patch_diff_header: build(PATCH_DIFF_HEADER),
        }
    }
}
