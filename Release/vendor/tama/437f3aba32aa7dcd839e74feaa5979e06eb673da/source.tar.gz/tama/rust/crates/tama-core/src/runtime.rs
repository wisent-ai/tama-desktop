//! Port of `src/core/runtime/live-runtime-coverage.mjs` and
//! `src/core/runtime/coverage-analysis.mjs`.
//!
//! Fidelity notes:
//! - `registry.catalog` (ompAdapters / editorAdapters / gitHooks) and adapter
//!   extras (requiredLiveCoverage, unsupportedLiveCoverageEvents,
//!   acknowledgedUninstalledHooks) are accessed leniently through
//!   `serde_json::Value`, mirroring the JS optional-chaining style.
//! - Sort keys and `localeCompare` calls use byte-lexicographic ordering,
//!   identical for the ASCII strings involved here.
//! - JS template interpolation of missing values (`undefined` / `null`) is
//!   reproduced by [`js_str`] where it is observable.

use serde::Serialize;
use serde_json::Value;
use std::collections::{BTreeMap, HashSet};
use std::fs;
use std::path::Path;

use crate::registry::{OrderedMap, Registry};
use crate::{err, Result};

pub const OMP_EVENTS: &[&str] = &[
    "stop",
    "user_prompt_submit",
    "post_tool_use:bash",
    "session_start:compact",
    "pre_tool_use:bash",
    "pre_tool_use:read",
    "pre_tool_use:edit",
    "pre_tool_use:write",
    "pre_tool_use:eval",
    "pre_tool_use:ssh",
    "pre_tool_use:task",
    "pre_tool_use:todo",
    "pre_tool_use:goal",
    "pre_tool_use:lookup",
];

const OMP_SELECTIVE_EVENTS: &[&str] = &[
    "user_prompt_submit",
    "pre_tool_use:bash",
    "pre_tool_use:edit",
    "pre_tool_use:write",
    "pre_tool_use:read",
    "pre_tool_use:multiedit",
    "pre_tool_use:task",
    "pre_tool_use:eval",
    "pre_tool_use:ssh",
    "pre_tool_use:todo",
    "pre_tool_use:goal",
    "pre_tool_use:lookup",
];

const OMP_SELECTIVE_HOOKS: &[&str] = &[
    "block-device-level-tests-without-consent",
    "block-unapproved-audits",
];

pub const CODEX_EVENTS: &[&str] = &[
    "stop",
    "user_prompt_submit",
    "post_tool_use:bash",
    "session_start:compact",
    "pre_tool_use:bash",
    "pre_tool_use:read",
    "pre_tool_use:edit",
    "pre_tool_use:write",
    "pre_tool_use:task",
    "pre_tool_use:todo",
    "pre_tool_use:goal",
    "pre_tool_use:lookup",
    "pre_tool_use:notebook",
    "pre_tool_use:wait",
    "pre_tool_use:eval",
    "pre_tool_use:ssh",
];

/// `new Set([...CODEX_EVENTS, 'pre_tool_use:multiedit'])`.
pub const CLAUDE_EVENTS: &[&str] = &[
    "stop",
    "user_prompt_submit",
    "post_tool_use:bash",
    "session_start:compact",
    "pre_tool_use:bash",
    "pre_tool_use:read",
    "pre_tool_use:edit",
    "pre_tool_use:write",
    "pre_tool_use:task",
    "pre_tool_use:todo",
    "pre_tool_use:goal",
    "pre_tool_use:lookup",
    "pre_tool_use:notebook",
    "pre_tool_use:wait",
    "pre_tool_use:eval",
    "pre_tool_use:ssh",
    "pre_tool_use:multiedit",
];

pub const EDITOR_EVENTS: &[&str] = &["pre_tool_use:edit", "pre_tool_use:notebook"];

/// JS runtime `loadRegistry(root)`: unlike the catalog variant this throws
/// (here: returns `Err`) when `shared-hooks/registry.json` is missing.
pub fn load_registry(root: &Path) -> Result<Registry> {
    let path = root.join("shared-hooks").join("registry.json");
    Ok(serde_json::from_str(&fs::read_to_string(path)?)?)
}

fn omp_runtime_event(event: &str) -> &str {
    if event == "pre_tool_use:write" {
        "pre_tool_use:edit"
    } else {
        event
    }
}

/// JS `ompAdapterStatus(registry)`: status of the `omp-shared-hooks` adapter,
/// or `None` (JS `null`).
fn omp_adapter_status(registry: Option<&Registry>) -> Option<String> {
    let adapters = registry
        .and_then(|r| r.extra.get("catalog"))
        .and_then(|c| c.get("ompAdapters"))
        .and_then(Value::as_array)?;
    for adapter in adapters {
        if adapter.get("id").and_then(Value::as_str) == Some("omp-shared-hooks") {
            // JS: `adapter?.status || null` — only a non-empty string can
            // equal 'active-selective' downstream, so other truthy values
            // collapse to `None` here.
            return adapter
                .get("status")
                .and_then(Value::as_str)
                .filter(|s| !s.is_empty())
                .map(str::to_string);
        }
    }
    None
}

fn omp_claims_event(registry: Option<&Registry>, event: &str) -> bool {
    if omp_adapter_status(registry).as_deref() == Some("active-selective") {
        OMP_SELECTIVE_EVENTS.contains(&event)
    } else {
        OMP_EVENTS.contains(&event)
    }
}

/// JS `coverageKey(runtime, event, hookId, runtimeEvent = event)`.
pub fn coverage_key(runtime: &str, event: &str, hook_id: &str, runtime_event: &str) -> String {
    if runtime_event == event {
        format!("{runtime}:{event}:{hook_id}")
    } else {
        format!("{runtime}:{event}:via:{runtime_event}:{hook_id}")
    }
}

/// JS `toolEventsFromMatcher(matcher)`, preserving first-insertion order
/// (JS `Set` semantics).
fn tool_events_from_matcher(matcher: &str) -> Vec<String> {
    let mut events: Vec<&str> = Vec::new();
    let mut push = |event: &'static str| {
        if !events.contains(&event) {
            events.push(event);
        }
    };
    for tool in matcher
        .split('|')
        .map(|tool| tool.trim().to_lowercase())
        .filter(|tool| !tool.is_empty())
    {
        match tool.as_str() {
            "bash" | "run_command" | "runcommands" | "runpackagecommand" | "runpackagescript" => {
                push("pre_tool_use:bash")
            }
            "read" | "readfile" => push("pre_tool_use:read"),
            "edit" | "apply_patch" => push("pre_tool_use:edit"),
            "write" | "writefile" => push("pre_tool_use:write"),
            "multiedit" => push("pre_tool_use:multiedit"),
            "task" | "agent" => push("pre_tool_use:task"),
            "todo" => push("pre_tool_use:todo"),
            "goal" => push("pre_tool_use:goal"),
            "grep" | "glob" | "search" | "lsp" | "astgrep" | "ast_grep" => {
                push("pre_tool_use:lookup")
            }
            "eval" | "execute_code" | "mcp__node_repl_js" | "node_repl/js" => {
                push("pre_tool_use:eval")
            }
            "ssh" => push("pre_tool_use:ssh"),
            "notebookedit" | "notebook_edit" => push("pre_tool_use:notebook"),
            "monitor" | "schedulewakeup" | "schedule_wakeup" | "wait" => push("pre_tool_use:wait"),
            _ => {}
        }
    }
    events.into_iter().map(str::to_string).collect()
}

/// JS `adapterEvents(adapterEvent, matcher)`.
fn adapter_events(adapter_event: &str, matcher: &str) -> Vec<String> {
    let key = adapter_event.to_lowercase();
    match key.as_str() {
        "stop" => vec!["stop".to_string()],
        "userpromptsubmit" | "user_prompt_submit" => vec!["user_prompt_submit".to_string()],
        "sessionstart" | "session_start" => vec!["session_start:compact".to_string()],
        "posttooluse" | "post_tool_use" => tool_events_from_matcher(matcher)
            .into_iter()
            .map(|event| event.replacen("pre_tool_use:", "post_tool_use:", 1))
            .collect(),
        "pretooluse" | "pre_tool_use" => tool_events_from_matcher(matcher),
        _ => Vec::new(),
    }
}

/// One `{ event, command }` pair extracted from an adapter config.
#[derive(Debug, Clone)]
pub struct AdapterHookEntry {
    pub event: String,
    pub command: String,
}

/// JS `hookEntriesFromAdapterConfig(config)`.
fn hook_entries_from_adapter_config(config: &Value) -> Vec<AdapterHookEntry> {
    let mut entries = Vec::new();
    let empty: Vec<Value> = Vec::new();
    let hooks_root = config.get("hooks").and_then(Value::as_object);
    if let Some(hooks_root) = hooks_root {
        for (adapter_event, blocks) in hooks_root {
            for block in blocks.as_array().unwrap_or(&empty) {
                let matcher = js_str(block.get("matcher"));
                for event in adapter_events(adapter_event, &matcher) {
                    for hook in block.get("hooks").and_then(Value::as_array).unwrap_or(&empty) {
                        // JS: `if (hook.command)` — truthy (non-empty) string.
                        if let Some(command) = hook
                            .get("command")
                            .and_then(Value::as_str)
                            .filter(|c| !c.is_empty())
                        {
                            entries.push(AdapterHookEntry {
                                event: event.clone(),
                                command: command.to_string(),
                            });
                        }
                    }
                }
            }
        }
    }
    entries
}

/// JS `basenameFromCommand(command)`: last path segment of the first token
/// ending in `.py`/`.sh`/`.mjs`/`.js` (or of the first token), with one
/// leading/trailing quote stripped per token.
fn basename_from_command(command: &str) -> String {
    let parts: Vec<&str> = command
        .trim()
        .split_whitespace()
        .map(|part| {
            let part = part
                .strip_prefix(|c| c == '\'' || c == '"')
                .unwrap_or(part);
            part.strip_suffix(|c| c == '\'' || c == '"').unwrap_or(part)
        })
        .collect();
    let first = parts.first().copied().unwrap_or("");
    let last = parts
        .iter()
        .copied()
        .find(|part| {
            part.ends_with(".py") || part.ends_with(".sh") || part.ends_with(".mjs") || part.ends_with(".js")
        })
        .unwrap_or(first);
    last.rsplit('/').next().unwrap_or("").to_string()
}

/// JS `commandsMatch(adapterCommand, registryCommand, hookId)`.
fn commands_match(adapter_command: &str, registry_command: &str, hook_id: &str) -> bool {
    if adapter_command == registry_command {
        return true;
    }
    if !hook_id.is_empty()
        && (adapter_command.contains(&format!("TAMA_ONLY_HOOK_ID='{hook_id}'"))
            || adapter_command.contains(&format!("TAMA_ONLY_HOOK_ID=\"{hook_id}\"")))
        && matches!(basename_from_command(adapter_command).as_str(), "run-hook.mjs" | "tama-run-hook")
    {
        return true;
    }
    let adapter_base = basename_from_command(adapter_command);
    let registry_base = basename_from_command(registry_command);
    !adapter_base.is_empty() && !registry_base.is_empty() && adapter_base == registry_base
}

/// JS `adapterCommandIndex`: event name -> installed command strings.
pub type AdapterCommandIndex = BTreeMap<String, Vec<String>>;

/// JS `adapterCommandIndex(registry, runtime)`. Errors carry the same
/// messages as the JS `Error`s.
pub fn adapter_command_index(registry: &Registry, runtime: &str) -> Result<AdapterCommandIndex> {
    let adapter_path = registry
        .adapters
        .get(runtime)
        .and_then(|adapter| adapter.path.clone())
        .filter(|path| !path.is_empty());
    let adapter_path = match adapter_path {
        Some(path) => path,
        None => {
            return Err(err(format!(
                "Missing {runtime} adapter path in registry.adapters"
            )))
        }
    };
    let read_config = || -> Result<Value> {
        let text = fs::read_to_string(&adapter_path)?;
        Ok(serde_json::from_str(&text)?)
    };
    let config = read_config().map_err(|error| {
        err(format!(
            "Failed to read {runtime} adapter config at {adapter_path}: {error}"
        ))
    })?;
    let mut by_event: AdapterCommandIndex = BTreeMap::new();
    for entry in hook_entries_from_adapter_config(&config) {
        by_event.entry(entry.event).or_default().push(entry.command);
    }
    Ok(by_event)
}

/// JS `{ runtime, runtimeEvent }` spec.
#[derive(Debug, Clone)]
pub struct RuntimeSpec {
    pub runtime: String,
    pub runtime_event: Option<String>,
}

/// JS `runtimeActuallyInstallsHook(adapterCommands, spec, hook, registry)`.
/// `hook_command` maps to `hook.command` (`None` = JS `undefined`).
pub fn runtime_actually_installs_hook(
    adapter_commands: &BTreeMap<String, AdapterCommandIndex>,
    spec: &RuntimeSpec,
    hook_id: &str,
    hook_command: Option<&str>,
    registry: Option<&Registry>,
) -> bool {
    if spec.runtime == "omp" && omp_adapter_status(registry).as_deref() == Some("active-selective") {
        return OMP_SELECTIVE_HOOKS.contains(&hook_id);
    }
    if spec.runtime != "codex" && spec.runtime != "claude" {
        return true;
    }
    let commands: &[String] = adapter_commands
        .get(&spec.runtime)
        .and_then(|by_event| {
            spec.runtime_event
                .as_ref()
                .and_then(|event| by_event.get(event))
        })
        .map(Vec::as_slice)
        .unwrap_or(&[]);
    let registry_command = hook_command.unwrap_or("");
    commands
        .iter()
        .any(|command| commands_match(command, registry_command, hook_id))
}

/// JS `requiredEditorRuntimeSpecs(registry)`.
fn required_editor_runtime_specs(registry: Option<&Registry>) -> Vec<RuntimeSpec> {
    let adapters = registry
        .and_then(|r| r.extra.get("catalog"))
        .and_then(|c| c.get("editorAdapters"))
        .and_then(Value::as_array);
    match adapters {
        None => ["editor-save-guard", "editor-watch-session", "editor-watch-launchd"]
            .iter()
            .map(|name| RuntimeSpec {
                runtime: name.to_string(),
                runtime_event: None,
            })
            .collect(),
        Some(list) => list
            .iter()
            .filter(|adapter| adapter.get("requiredLiveCoverage") != Some(&Value::Bool(false)))
            .filter(|adapter| js_str(adapter.get("status")).starts_with("active"))
            .map(|adapter| RuntimeSpec {
                runtime: js_str(adapter.get("id")),
                runtime_event: None,
            })
            .collect(),
    }
}

/// JS `runtimeRequiredLiveCoverage(registry, runtime)`.
fn runtime_required_live_coverage(registry: Option<&Registry>, runtime: &str) -> bool {
    registry
        .and_then(|r| r.adapters.get(runtime))
        .and_then(|adapter| adapter.extra.get("requiredLiveCoverage"))
        != Some(&Value::Bool(false))
}

/// JS `runtimeSupportsLiveCoverageEvent(registry, runtime, event)`.
fn runtime_supports_live_coverage_event(
    registry: Option<&Registry>,
    runtime: &str,
    event: &str,
) -> bool {
    let unsupported = registry
        .and_then(|r| r.adapters.get(runtime))
        .and_then(|adapter| adapter.extra.get("unsupportedLiveCoverageEvents"))
        .and_then(Value::as_array);
    match unsupported {
        Some(list) => !list.iter().any(|value| value.as_str() == Some(event)),
        None => true,
    }
}

/// JS `claimedRuntimeSpecsForEvent(event, registry)`.
pub fn claimed_runtime_specs_for_event(
    event: &str,
    registry: Option<&Registry>,
) -> Vec<RuntimeSpec> {
    let mut specs: Vec<RuntimeSpec> = Vec::new();
    if omp_claims_event(registry, event) {
        specs.push(RuntimeSpec {
            runtime: "omp".to_string(),
            runtime_event: Some(omp_runtime_event(event).to_string()),
        });
    }
    if CODEX_EVENTS.contains(&event)
        && runtime_required_live_coverage(registry, "codex")
        && runtime_supports_live_coverage_event(registry, "codex", event)
    {
        specs.push(RuntimeSpec {
            runtime: "codex".to_string(),
            runtime_event: Some(event.to_string()),
        });
    }
    if CLAUDE_EVENTS.contains(&event)
        && runtime_required_live_coverage(registry, "claude")
        && runtime_supports_live_coverage_event(registry, "claude", event)
    {
        specs.push(RuntimeSpec {
            runtime: "claude".to_string(),
            runtime_event: Some(event.to_string()),
        });
    }
    if EDITOR_EVENTS.contains(&event) {
        for spec in required_editor_runtime_specs(registry) {
            specs.push(RuntimeSpec {
                runtime: spec.runtime,
                runtime_event: Some(event.to_string()),
            });
        }
    }
    specs
}

/// Runtime (agent) entry of `buildRequiredCoverage`.
/// One mapping row of JS `declaredProviderCoverage`: a registry event claimed
/// by a runtime, or a catalogued Git hook.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ProviderCoverageMapping {
    pub provider: String,
    pub event: String,
    pub runtime_event: String,
    pub hook_id: String,
}

/// One provider entry of JS `declaredProviderCoverage`, serialized with the
/// exact keys the JS command printed.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ProviderCoverage {
    pub provider: String,
    pub coverage_kind: String,
    pub mapping_count: usize,
    pub hook_count: usize,
    pub event_count: usize,
    pub adapter_path: Option<String>,
    pub required_live_coverage: Option<bool>,
    pub evidence: String,
    pub note: Option<String>,
    pub mappings: Vec<ProviderCoverageMapping>,
}

/// JS `declaredProviderCoverage(root)` with no provider filter: every
/// provider the fixed list or the mappings name, sorted byte-lexicographically
/// (identical to `.sort()` for the ASCII provider ids involved).
pub fn declared_provider_coverage(root: &Path) -> Result<Vec<ProviderCoverage>> {
    let registry = load_registry(root)?;
    let mut mappings: Vec<ProviderCoverageMapping> = Vec::new();
    for (event, config) in &registry.events {
        for hook in &config.hooks {
            for spec in claimed_runtime_specs_for_event(event, Some(&registry)) {
                mappings.push(ProviderCoverageMapping {
                    runtime_event: spec.runtime_event.unwrap_or_else(|| event.clone()),
                    provider: spec.runtime,
                    event: event.clone(),
                    hook_id: hook.id.clone(),
                });
            }
        }
    }
    if let Some(git_hooks) = registry
        .extra
        .get("catalog")
        .and_then(|catalog| catalog.get("gitHooks"))
        .and_then(Value::as_array)
    {
        for hook in git_hooks {
            let Some(id) = hook.get("id").and_then(Value::as_str) else {
                continue;
            };
            let event = hook.get("event").and_then(Value::as_str).unwrap_or(id);
            mappings.push(ProviderCoverageMapping {
                provider: "git".to_string(),
                event: event.to_string(),
                runtime_event: event.to_string(),
                hook_id: id.to_string(),
            });
        }
    }

    let mut providers: Vec<String> = [
        "claude",
        "codex",
        "omp",
        "editor-save-guard",
        "editor-watch-session",
        "git",
        "kimi",
    ]
    .iter()
    .map(|provider| provider.to_string())
    .collect();
    for mapping in &mappings {
        if !providers.contains(&mapping.provider) {
            providers.push(mapping.provider.clone());
        }
    }
    providers.sort();

    Ok(providers
        .into_iter()
        .map(|provider| {
            let covered: Vec<ProviderCoverageMapping> = mappings
                .iter()
                .filter(|mapping| mapping.provider == provider)
                .cloned()
                .collect();
            let adapter = registry.adapters.get(&provider);
            Ok(ProviderCoverage {
                coverage_kind: if provider == "kimi" {
                    "indirect".to_string()
                } else {
                    "declared".to_string()
                },
                mapping_count: covered.len(),
                hook_count: covered
                    .iter()
                    .map(|mapping| mapping.hook_id.as_str())
                    .collect::<HashSet<_>>()
                    .len(),
                event_count: covered
                    .iter()
                    .map(|mapping| mapping.event.as_str())
                    .collect::<HashSet<_>>()
                    .len(),
                adapter_path: adapter.and_then(|adapter| adapter.path.clone()),
                required_live_coverage: adapter
                    .and_then(|adapter| adapter.extra.get("requiredLiveCoverage"))
                    .and_then(Value::as_bool),
                evidence: "Registry-declared mappings; not live execution evidence.".to_string(),
                note: (provider == "kimi").then(|| {
                    "No native hook adapter; coverage is indirect through editor and Git surfaces."
                        .to_string()
                }),
                mappings: covered,
                provider,
            })
        })
        .collect::<Result<Vec<_>>>()?)
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct RuntimeCoverage {
    pub runtime: String,
    pub event: String,
    pub runtime_event: String,
    pub hook_id: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub command: Option<String>,
    pub coverage_key: String,
}

/// Git entry of `buildRequiredCoverage`. Optional fields use
/// `Option<Value>`: a key present with JSON `null` is kept as `null`
/// (as `JSON.stringify` would), only an absent key is dropped.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct GitCoverage {
    pub runtime: String,
    pub event: String,
    pub hook_id: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub source: Option<Value>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub repo: Option<Value>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub hooks_path: Option<Value>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub scope: Option<Value>,
    pub coverage_key: String,
}

/// One entry of JS `buildRequiredCoverage(root)` (untagged: the two variants
/// have different key sets, exactly as in JS).
#[derive(Debug, Clone, Serialize)]
#[serde(untagged)]
pub enum RequiredCoverage {
    Runtime(RuntimeCoverage),
    Git(GitCoverage),
}

impl RequiredCoverage {
    pub fn coverage_key(&self) -> &str {
        match self {
            RequiredCoverage::Runtime(entry) => &entry.coverage_key,
            RequiredCoverage::Git(entry) => &entry.coverage_key,
        }
    }

    pub fn runtime(&self) -> &str {
        match self {
            RequiredCoverage::Runtime(entry) => &entry.runtime,
            RequiredCoverage::Git(entry) => &entry.runtime,
        }
    }

    pub fn event(&self) -> &str {
        match self {
            RequiredCoverage::Runtime(entry) => &entry.event,
            RequiredCoverage::Git(entry) => &entry.event,
        }
    }
}

/// JS `buildRequiredCoverage(root)`, sorted by `coverageKey`.
pub fn build_required_coverage(root: &Path) -> Result<Vec<RequiredCoverage>> {
    let registry = load_registry(root)?;
    let mut adapter_commands: BTreeMap<String, AdapterCommandIndex> = BTreeMap::new();
    adapter_commands.insert("codex".to_string(), adapter_command_index(&registry, "codex")?);
    adapter_commands.insert("claude".to_string(), adapter_command_index(&registry, "claude")?);
    let mut required: Vec<RequiredCoverage> = Vec::new();
    for (event, config) in &registry.events {
        for hook in &config.hooks {
            for spec in claimed_runtime_specs_for_event(event, Some(&registry)) {
                if !runtime_actually_installs_hook(
                    &adapter_commands,
                    &spec,
                    &hook.id,
                    hook.command.as_deref(),
                    Some(&registry),
                ) {
                    continue;
                }
                let runtime_event = spec.runtime_event.clone().unwrap_or_default();
                required.push(RequiredCoverage::Runtime(RuntimeCoverage {
                    runtime: spec.runtime.clone(),
                    event: event.clone(),
                    runtime_event: runtime_event.clone(),
                    hook_id: hook.id.clone(),
                    command: hook.command.clone(),
                    coverage_key: coverage_key(&spec.runtime, event, &hook.id, &runtime_event),
                }));
            }
        }
    }
    let empty: Vec<Value> = Vec::new();
    let git_hooks = registry
        .extra
        .get("catalog")
        .and_then(|c| c.get("gitHooks"))
        .and_then(Value::as_array)
        .unwrap_or(&empty);
    for hook in git_hooks {
        // JS: `hook.event || hook.id`
        let raw_event = hook.get("event");
        let event = if js_truthy(raw_event) {
            js_str(raw_event)
        } else {
            js_str(hook.get("id"))
        };
        let hook_id = js_str(hook.get("id"));
        required.push(RequiredCoverage::Git(GitCoverage {
            runtime: "git".to_string(),
            event: event.clone(),
            hook_id: hook_id.clone(),
            source: hook.get("source").cloned(),
            repo: hook.get("repo").cloned(),
            hooks_path: hook.get("hooksPath").cloned(),
            scope: hook.get("scope").cloned(),
            coverage_key: format!("git:{event}:{hook_id}"),
        }));
    }
    // JS `.sort((a, b) => a.coverageKey.localeCompare(b.coverageKey))` is a
    // stable sort; `sort_by` is stable too.
    required.sort_by(|a, b| a.coverage_key().cmp(b.coverage_key()));
    Ok(required)
}

/// One entry of JS `detectRuntimeInstallDrift(root)`. `acknowledged` is
/// `None` for the "adapter config unreadable" entry, matching the JS object
/// which lacks the key there.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct DriftEntry {
    pub runtime: String,
    pub event: Option<String>,
    pub hook_id: Option<String>,
    pub required_live_coverage: bool,
    pub unsupported_event: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub acknowledged: Option<bool>,
    pub material: bool,
    pub reason: String,
}

const DRIFT_CHECKED_RUNTIMES: [(&str, &[&str]); 2] =
    [("codex", CODEX_EVENTS), ("claude", CLAUDE_EVENTS)];

/// JS `detectRuntimeInstallDrift(root)` from `coverage-analysis.mjs`.
pub fn detect_runtime_install_drift(root: &Path) -> Result<Vec<DriftEntry>> {
    let registry = load_registry(root)?;
    let mut drift: Vec<DriftEntry> = Vec::new();
    for (runtime, events) in DRIFT_CHECKED_RUNTIMES {
        let adapter = registry.adapters.get(runtime);
        let required_live_coverage = adapter
            .and_then(|a| a.extra.get("requiredLiveCoverage"))
            != Some(&Value::Bool(false));
        let unsupported_events: HashSet<&str> = adapter
            .and_then(|a| a.extra.get("unsupportedLiveCoverageEvents"))
            .and_then(Value::as_array)
            .map(|list| list.iter().filter_map(Value::as_str).collect())
            .unwrap_or_default();
        let acknowledged: HashSet<String> = adapter
            .and_then(|a| a.extra.get("acknowledgedUninstalledHooks"))
            .and_then(Value::as_array)
            .map(|list| {
                list.iter()
                    .filter(|entry| {
                        entry
                            .get("reason")
                            .and_then(Value::as_str)
                            .map(|reason| !reason.trim().is_empty())
                            .unwrap_or(false)
                    })
                    .map(|entry| {
                        format!("{}:{}", js_str(entry.get("event")), js_str(entry.get("hookId")))
                    })
                    .collect()
            })
            .unwrap_or_default();
        let index = match adapter_command_index(&registry, runtime) {
            Ok(index) => index,
            // JS: silent `catch` -> push the unreadable entry and continue.
            Err(_) => {
                drift.push(DriftEntry {
                    runtime: runtime.to_string(),
                    event: None,
                    hook_id: None,
                    required_live_coverage,
                    unsupported_event: false,
                    acknowledged: None,
                    material: required_live_coverage,
                    reason: "adapter config unreadable".to_string(),
                });
                continue;
            }
        };
        let mut adapter_commands: BTreeMap<String, AdapterCommandIndex> = BTreeMap::new();
        adapter_commands.insert(runtime.to_string(), index);
        for (event, config) in &registry.events {
            if !events.contains(&event.as_str()) {
                continue;
            }
            for hook in &config.hooks {
                let spec = RuntimeSpec {
                    runtime: runtime.to_string(),
                    runtime_event: Some(event.clone()),
                };
                // JS passes no registry here (defaults to null).
                if runtime_actually_installs_hook(
                    &adapter_commands,
                    &spec,
                    &hook.id,
                    hook.command.as_deref(),
                    None,
                ) {
                    continue;
                }
                let unsupported_event = unsupported_events.contains(event.as_str());
                let is_acknowledged = acknowledged.contains(&format!("{event}:{}", hook.id));
                drift.push(DriftEntry {
                    runtime: runtime.to_string(),
                    event: Some(event.clone()),
                    hook_id: Some(hook.id.clone()),
                    required_live_coverage,
                    unsupported_event,
                    acknowledged: Some(is_acknowledged),
                    material: required_live_coverage && !unsupported_event && !is_acknowledged,
                    reason: "registry catalog declares this hook for the event but the runtime adapter does not install it".to_string(),
                });
            }
        }
    }
    // JS sort key interpolates null event/hookId as "null".
    drift.sort_by(|a, b| {
        drift_sort_key(a).cmp(&drift_sort_key(b))
    });
    Ok(drift)
}

fn drift_sort_key(entry: &DriftEntry) -> String {
    format!(
        "{}:{}:{}",
        entry.runtime,
        entry.event.as_deref().unwrap_or("null"),
        entry.hook_id.as_deref().unwrap_or("null")
    )
}

/// Result of JS `summarizeCoverage(required, passedCoverageKeys)`.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CoverageSummary {
    pub required_count: usize,
    pub passed_count: usize,
    pub missing_count: usize,
    pub missing_by_runtime: OrderedMap<usize>,
    pub missing_by_event: OrderedMap<usize>,
    pub missing: Vec<RequiredCoverage>,
}

/// JS `summarizeCoverage(required, passedCoverageKeys)`. The `countBy` maps
/// preserve first-seen key order like JS objects.
pub fn summarize_coverage(
    required: &[RequiredCoverage],
    passed_coverage_keys: &[String],
) -> CoverageSummary {
    let passed: HashSet<&str> = passed_coverage_keys.iter().map(String::as_str).collect();
    let missing: Vec<RequiredCoverage> = required
        .iter()
        .filter(|item| !passed.contains(item.coverage_key()))
        .cloned()
        .collect();
    let mut missing_by_runtime = OrderedMap::new();
    let mut missing_by_event = OrderedMap::new();
    for item in &missing {
        // JS `countBy`: `item[key] || '<unknown>'`; runtime/event are always
        // non-empty strings in these entries.
        missing_by_runtime.increment(item.runtime());
        missing_by_event.increment(item.event());
    }
    CoverageSummary {
        required_count: required.len(),
        passed_count: required.len() - missing.len(),
        missing_count: missing.len(),
        missing_by_runtime,
        missing_by_event,
        missing,
    }
}

// ---------------------------------------------------------------------------
// helpers
// ---------------------------------------------------------------------------

/// JS template-literal interpolation of a JSON value: missing key ->
/// "undefined", null -> "null", strings verbatim, booleans/numbers via their
/// plain string form. Arrays/objects fall back to their JSON text
/// (JS would produce e.g. "[object Object]"; not expected in this data).
fn js_str(value: Option<&Value>) -> String {
    match value {
        None => "undefined".to_string(),
        Some(Value::Null) => "null".to_string(),
        Some(Value::String(s)) => s.clone(),
        Some(Value::Bool(b)) => b.to_string(),
        Some(Value::Number(n)) => n.to_string(),
        Some(other) => other.to_string(),
    }
}

/// JS truthiness of a JSON value.
fn js_truthy(value: Option<&Value>) -> bool {
    match value {
        None | Some(Value::Null) => false,
        Some(Value::Bool(b)) => *b,
        Some(Value::String(s)) => !s.is_empty(),
        Some(Value::Number(n)) => n.as_f64().map(|f| f != 0.0).unwrap_or(true),
        Some(_) => true,
    }
}
