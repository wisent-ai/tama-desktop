//! Rust ports of the registered Python hooks under `shared-hooks/`.
//!
//! One module per hook, named after the Python stem. A hook whose logic does
//! not fit the repository's 300-line file limit is split into
//! `<hook>_<aspect>.rs` siblings, with `<hook>.rs` keeping the orchestration.

pub mod check_failure_inspection;
pub mod check_failure_inspection_claim;
pub mod check_failure_inspection_labels;
pub mod check_failure_inspection_recording;
pub mod check_failure_inspection_transcript;
pub mod check_failure_inspection_wsession;
pub mod inspect_required_check;
pub mod block_direct_lsi_api;
pub mod block_keychain_prompt_commands;
pub mod block_overleaf_api;
pub mod codex_api_guard;
pub mod block_hook_config_edits_without_consent;
pub mod block_hook_config_edits_without_consent_gate;
pub mod block_hook_config_edits_without_consent_patterns;
pub mod block_temporary_path_operations;
pub mod check_git_hooks_path;
pub mod python_stdlib;
pub mod python_stdlib_path;
pub mod pyvalue;
pub mod block_unapproved_audits;
pub mod block_unapproved_audits_state;
pub mod check_legacy_activation_bypass;
pub mod check_legacy_activation_bypass_markers;
pub mod check_legacy_activation_bypass_tree;
pub mod pystr;
pub mod block_openai_api_key;
pub mod check_raw_api_calls;
pub mod check_numeric_literals;
pub mod check_numeric_literals_payload;
pub mod check_numeric_literals_provenance;
pub mod check_numeric_literals_scan;
pub mod check_numeric_literals_laundered;
pub mod block_unauthorized_cua;
pub mod block_unauthorized_cua_detect;
pub mod block_unauthorized_ssh;
pub mod block_unauthorized_ssh_detect;
pub mod block_unauthorized_ssh_targets;
pub mod transport_common;
