//! Failure-claim detection for the `check-failure-inspection` port of
//! `shared-hooks/check_failure_inspection.py`.
//!
//! Ports `FAIL_TERMS`, `_DISCLAIM_PAT`, `label_tokens()` and the v9
//! `label_in_response()` guards: backtick masking, a disclaim keyword before
//! the mention, and a failure term within reach of it.
//!
//! Both Python patterns carry `re.IGNORECASE`, written here as the inline
//! `(?i)` flag. Neither uses a backreference or a lookaround, so the pattern
//! text is otherwise verbatim; `['\x22]` spells Python's `['\"]`.

use regex::Regex;

const FAIL_TERMS_PATTERN: &str = concat!(
    r"(?i)\b(FAIL[: ]|failed|failure|did\s+not\s+(pass|solve)|exited?\s+(non-?zero|1)|",
    r"crashed|errored|broken|broke|bombed|did\s+not\s+(work|complete)|",
    r"shadow[\- ]?throttl|shadow[\- ]?ban|shadowban|throttl|",
    r"\b0\s+handles\b|\b0\s+entries\b|\b0\s+results?\b|\bno\s+results?\b|",
    r"account[\- ]locked|account[\- ]ban|locked\s+out|restricted|",
    r"empty\s+results?|search\s+(returned|empty)|",
    r"soft[\- ]block|hard[\- ]block|stopped\s+before|cut\s+off|",
    r"truncat(ed|ion)|burst[\- ]ed?|kicked\s+(us\s+)?back)\b",
);

const DISCLAIM_PATTERN: &str = concat!(
    r"(?i)(unrelated|different\s+(session|conversation|run|trajectory|project)|",
    r"false\s+positive|not\s+actionable|spurious|misfir|",
    r"echoe?d|quoted|ignor(e|ed|ing)|n/a|not\s+pertinent|",
    r"hook\s+(is\s+)?firing|hook\s+(fired|fires)|hook\s+(error|feedback)|",
    r"system[\s\-]reminder)",
);

const FENCED_SPAN_PATTERN: &str = r"```[\s\S]*?```";
const INLINE_SPAN_PATTERN: &str = r"`[^`\n]+`";
const LABEL_SPLIT_PATTERN: &str = r"[_/\-\s]+";
const MASK_CHAR: char = '_';

/// `FAIL_PROXIMITY` in `label_in_response`: a failure term must sit this close
/// to the mention, in either direction.
const FAIL_PROXIMITY_TEXT: &str = "250";
/// `DISCLAIM_WINDOW`: how far before the mention a disclaimer disqualifies it.
const DISCLAIM_WINDOW_TEXT: &str = "200";
/// The token-set fallback's `max(combo) - min(combo) <= 200` span.
const TOKEN_SPAN_TEXT: &str = "200";
/// `len(tokens) >= 2 and all(len(t) >= 3 ...)` gate on the fallback.
const MIN_TOKENS_TEXT: &str = "2";
const MIN_TOKEN_LEN_TEXT: &str = "3";

fn fail_proximity() -> usize {
    FAIL_PROXIMITY_TEXT.parse().unwrap_or_default()
}

fn disclaim_window() -> usize {
    DISCLAIM_WINDOW_TEXT.parse().unwrap_or_default()
}

fn token_span() -> usize {
    TOKEN_SPAN_TEXT.parse().unwrap_or_default()
}

fn min_tokens() -> usize {
    MIN_TOKENS_TEXT.parse().unwrap_or_default()
}

fn min_token_len() -> usize {
    MIN_TOKEN_LEN_TEXT.parse().unwrap_or_default()
}

/// `label_tokens()`.
pub fn label_tokens(label: &str) -> Vec<String> {
    let splitter = Regex::new(LABEL_SPLIT_PATTERN).expect("label split pattern");
    splitter
        .split(&label.to_lowercase())
        .filter(|token| !token.is_empty())
        .map(str::to_string)
        .collect()
}

/// The module-level Python patterns, compiled once per run instead of once per
/// `label_in_response` call (Python leans on `re`'s internal pattern cache).
pub struct ClaimMatcher {
    fail: Regex,
    disclaim: Regex,
    fenced: Regex,
    inline: Regex,
}

impl ClaimMatcher {
    pub fn new() -> Self {
        Self {
            fail: Regex::new(FAIL_TERMS_PATTERN).expect("fail terms pattern"),
            disclaim: Regex::new(DISCLAIM_PATTERN).expect("disclaim pattern"),
            fenced: Regex::new(FENCED_SPAN_PATTERN).expect("fenced span pattern"),
            inline: Regex::new(INLINE_SPAN_PATTERN).expect("inline span pattern"),
        }
    }

    /// `FAIL_TERMS.search(response)`.
    pub fn claims_failure(&self, text: &str) -> bool {
        self.fail.is_match(text)
    }

    /// `label_in_response()`: true iff the response makes a failure claim about
    /// `label`.
    pub fn label_in_response(&self, label: &str, text: &str) -> bool {
        let masked = self.mask(text);
        let positions = self.mention_positions(label, &masked);
        positions.iter().any(|&at| {
            let before = masked.window(at.saturating_sub(disclaim_window()), at);
            if self.disclaim.is_match(&before) {
                return false;
            }
            let near = masked.window(
                at.saturating_sub(fail_proximity()),
                at.saturating_add(fail_proximity()),
            );
            self.fail.is_match(&near)
        })
    }

    /// The two `re.sub` masking passes, then `.lower()`.
    fn mask(&self, text: &str) -> Masked {
        let fenced = self.fenced.replace_all(text, underscores);
        let inline = self.inline.replace_all(&fenced, underscores);
        Masked::new(inline.to_lowercase())
    }

    /// Whole-label matches, or — when there are none — the starts the token-set
    /// fallback admits.
    fn mention_positions(&self, label: &str, masked: &Masked) -> Vec<usize> {
        let label_lc = label.to_lowercase();
        let direct = masked.word_positions(&label_lc);
        if !direct.is_empty() {
            return direct;
        }
        let tokens = label_tokens(label);
        if tokens.len() < min_tokens()
            || tokens
                .iter()
                .any(|token| token.chars().count() < min_token_len())
        {
            return Vec::new();
        }
        let hits: Vec<Vec<usize>> = tokens
            .iter()
            .map(|token| masked.word_positions(token))
            .collect();
        if hits.iter().any(Vec::is_empty) {
            return Vec::new();
        }
        // `product(*hits)` filtered by `max(combo) - min(combo) <= 200`, keeping
        // `min(combo)`. A start `s` survives exactly when every token also hits
        // inside `[s, s + 200]`, so the same set falls out without the Python's
        // exponential cartesian product.
        let span = token_span();
        hits.iter()
            .flatten()
            .copied()
            .filter(|&start| {
                hits.iter().all(|token_hits| {
                    token_hits
                        .iter()
                        .any(|&at| at >= start && at.saturating_sub(start) <= span)
                })
            })
            .collect()
    }
}

fn underscores(caps: &regex::Captures) -> String {
    let matched = caps.get(usize::MIN).map(|m| m.as_str()).unwrap_or_default();
    MASK_CHAR.to_string().repeat(matched.chars().count())
}

/// Masked, lowercased response text indexed the way Python indexes `str`: by
/// character, not by byte.
struct Masked {
    text: String,
    chars: Vec<char>,
    offsets: Vec<usize>,
}

impl Masked {
    fn new(text: String) -> Self {
        let chars = text.chars().collect();
        let offsets = text.char_indices().map(|(at, _)| at).collect();
        Self {
            text,
            chars,
            offsets,
        }
    }

    /// Character offsets of `\b<escaped>\b` matches.
    fn word_positions(&self, needle: &str) -> Vec<usize> {
        let pattern = format!(r"\b{}\b", regex::escape(needle));
        let Ok(word) = Regex::new(&pattern) else {
            return Vec::new();
        };
        word.find_iter(&self.text)
            .map(|found| self.offsets.binary_search(&found.start()).unwrap_or_default())
            .collect()
    }

    /// `text[start:end]` with Python's clamping.
    fn window(&self, start: usize, end: usize) -> String {
        let last = self.chars.len();
        self.chars[start.min(last)..end.min(last)].iter().collect()
    }
}
