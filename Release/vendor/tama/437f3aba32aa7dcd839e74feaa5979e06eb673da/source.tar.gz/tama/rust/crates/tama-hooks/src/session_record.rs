//! Session-record access shared by the evidence-based `Stop` guards.
//!
//! The guards judge recorded behaviour, never prose, so they all need the same
//! payload, the current turn's activity, and the successful tracker history
//! required to reconstruct state that persists across user messages.
//!
//! Transcript shape (`~/.omp/agent/sessions/**/*.jsonl`, one JSON object per
//! line): `{ type, message: { role, content: [...] } }` where an assistant
//! message carries `content[].type == "toolCall"` with `id`, `name` and
//! `arguments`, and a result carries `role == "toolResult"` with `toolCallId`,
//! `toolName`, `isError` and text parts.
//!
//! Sizes are materialized from text, the same way the JS sources write
//! `Number('0')`: the repository keeps bare numeric literals out of code.

use std::collections::HashSet;
use std::io::{BufRead, BufReader, Read};
use std::path::{Path, PathBuf};

use serde_json::Value;

/// Registry hook ids are kebab-case and short; this bound rejects a prose
/// sentence that merely happens to contain a colon.
const MAX_HOOK_ID_TEXT: &str = "64";

const SESSION_ID_KEYS: &[&str] = &[
    "session_id",
    "sessionId",
    "conversation_id",
    "conversationId",
];
const PATH_KEYS: &[&str] = &["path", "file", "file_path", "filename", "target"];
const SHORTEST_PATH: &str = "a/b";

fn max_hook_id_len() -> usize {
    MAX_HOOK_ID_TEXT.parse().unwrap_or_default()
}

/// One recorded tool invocation.
#[derive(Clone)]
pub struct ToolCall {
    pub id: String,
    pub name: String,
    pub arguments: Value,
}

impl ToolCall {
    /// The first path-like argument, preserving URI schemes and removing only file selectors.
    pub fn target(&self) -> Option<String> {
        for key in PATH_KEYS {
            if let Some(text) = self.arguments.get(key).and_then(Value::as_str) {
                if !text.is_empty() {
                    return Some(if text.contains("://") {
                        text.to_string()
                    } else {
                        text.split(':').next().unwrap_or(text).to_string()
                    });
                }
            }
        }
        path_tokens(&self.arguments).into_iter().next()
    }

    /// Every path-looking token anywhere in the arguments.
    pub fn paths(&self) -> Vec<String> {
        path_tokens(&self.arguments)
    }
}

/// One recorded tool result.
#[derive(Clone)]
pub struct ToolResult {
    pub position: usize,
    pub call_id: String,
    pub tool_name: String,
    pub details: Value,
    pub is_error: bool,
    pub text: String,
}

/// One errored tool result carrying a hook's deny text.
pub struct Denial {
    pub position: usize,
    pub call_id: String,
    pub tool_name: String,
    pub text: String,
}

/// Current activity plus successful tracker history from one session transcript.
pub struct Turn {
    calls: Vec<(usize, ToolCall)>,
    results: Vec<ToolResult>,
}

impl Turn {
    /// Current turn from a hook payload. Codex supplies the exact transcript
    /// path; older runtimes only supplied a session id, so retain that lookup
    /// as a fallback.
    pub fn for_payload(payload: &Value) -> Option<Turn> {
        if let Some(path) = payload.get("transcript_path").and_then(Value::as_str) {
            if !path.is_empty() {
                return Self::for_path(Path::new(path));
            }
        }
        Self::for_session(&session_id_of(payload))
    }

    /// Current tool activity plus successful tracker history. `None` means no
    /// transcript is readable, so a guard must not deny.
    pub fn for_session(session: &str) -> Option<Turn> {
        let path = transcript_path(session)?;
        Self::for_path(&path)
    }

    fn for_path(path: &Path) -> Option<Turn> {
        let file = std::fs::File::open(path).ok()?;
        let mut calls = Vec::new();
        let mut results = Vec::new();
        for (position, line) in BufReader::new(file).lines().enumerate() {
            let line = match line {
                Ok(value) => value,
                Err(_) => continue,
            };
            let record: Value = match serde_json::from_str(&line) {
                Ok(value) => value,
                Err(_) => continue,
            };
            let message =
                if let Some(value) = record.get("message").filter(|value| value.is_object()) {
                    value
                } else if record.get("type").and_then(Value::as_str) == Some("response_item") {
                    match record.get("payload").filter(|value| value.is_object()) {
                        Some(value) => value,
                        None => continue,
                    }
                } else {
                    continue;
                };
            if message.get("role").and_then(Value::as_str) == Some("user")
                || message.get("type").and_then(Value::as_str) == Some("user_message")
            {
                retain_tracker_state(&mut calls, &mut results);
                continue;
            }
            collect_tool_calls(position, message, &mut calls);
            if message.get("role").and_then(Value::as_str) == Some("toolResult") {
                let tool_name = string_at(message, "toolName").to_lowercase();
                let is_error = is_error_result(message);
                results.push(ToolResult {
                    position,
                    call_id: string_at(message, "toolCallId"),
                    details: if is_tracker_tool(&tool_name) {
                        message.get("details").cloned().unwrap_or(Value::Null)
                    } else {
                        Value::Null
                    },
                    tool_name,
                    is_error,
                    text: if is_error {
                        result_text(message)
                    } else {
                        String::new()
                    },
                });
            }
        }
        Some(Turn { calls, results })
    }

    /// Tool calls in record order, paired with the transcript position that
    /// carried them.
    pub fn tool_calls(&self) -> Vec<(usize, ToolCall)> {
        self.calls.clone()
    }

    /// Tool results in record order.
    pub fn tool_results(&self) -> &[ToolResult] {
        &self.results
    }

    /// Ids of calls whose result completed without an error.
    pub fn successful_call_ids(&self) -> HashSet<String> {
        self.results
            .iter()
            .filter(|result| !result.is_error && !result.call_id.is_empty())
            .map(|result| result.call_id.clone())
            .collect()
    }

    /// Errored results, oldest first. The caller decides which ones are hook
    /// denials by matching the banner id against the registry.
    pub fn denials(&self) -> Vec<Denial> {
        self.results
            .iter()
            .filter(|result| result.is_error)
            .map(|result| Denial {
                position: result.position,
                call_id: result.call_id.clone(),
                tool_name: result.tool_name.clone(),
                text: result.text.clone(),
            })
            .collect()
    }
}

/// The leading `<hook-id>:` token of a deny banner, if the text has one.
pub fn deny_banner_id(text: &str) -> Option<String> {
    let head = text.trim_start();
    let (candidate, _) = head.split_once(':')?;
    let ok = !candidate.is_empty()
        && candidate.len() <= max_hook_id_len()
        && candidate.starts_with(|c: char| c.is_ascii_lowercase())
        && candidate
            .chars()
            .all(|c| c.is_ascii_lowercase() || c.is_ascii_digit() || c == '-');
    ok.then(|| candidate.to_string())
}

/// Payload delivered on stdin; an unreadable payload is an empty object.
pub fn read_payload() -> Value {
    let mut raw = String::new();
    if std::io::stdin().read_to_string(&mut raw).is_err() {
        return Value::Object(Default::default());
    }
    serde_json::from_str(&raw).unwrap_or_else(|_| Value::Object(Default::default()))
}

pub fn session_id_of(payload: &Value) -> String {
    for key in SESSION_ID_KEYS {
        if let Some(text) = payload.get(key).and_then(Value::as_str) {
            if !text.is_empty() {
                return text.to_string();
            }
        }
    }
    String::new()
}

/// Tool name from a `PreToolUse`-shaped payload, lowercased.
pub fn tool_name_of(payload: &Value) -> String {
    let direct = payload
        .get("tool_name")
        .or_else(|| payload.get("name"))
        .or_else(|| payload.get("tool"));
    match direct {
        Some(Value::String(text)) => text.trim().to_lowercase(),
        Some(Value::Object(map)) => map
            .get("name")
            .or_else(|| map.get("tool_name"))
            .and_then(Value::as_str)
            .unwrap_or_default()
            .trim()
            .to_lowercase(),
        _ => String::new(),
    }
}

/// Tool arguments from a `PreToolUse`-shaped payload.
pub fn tool_input_of(payload: &Value) -> Value {
    payload
        .get("tool_input")
        .or_else(|| payload.get("input"))
        .cloned()
        .unwrap_or(Value::Null)
}

/// The final assistant message, when the payload carries one.
pub fn last_assistant_message(payload: &Value) -> Option<&str> {
    payload
        .get("last_assistant_message")
        .and_then(Value::as_str)
}

/// Every string inside a JSON tree, in document order.
pub fn all_strings(value: &Value) -> Vec<String> {
    let mut found = Vec::new();
    collect_strings(value, &mut found);
    found
}

fn collect_strings(value: &Value, found: &mut Vec<String>) {
    match value {
        Value::String(text) => found.push(text.clone()),
        Value::Array(items) => items.iter().for_each(|item| collect_strings(item, found)),
        Value::Object(map) => map.values().for_each(|item| collect_strings(item, found)),
        _ => {}
    }
}

/// A `PreToolUse` denial: banner on stderr, exit code 2.
pub fn deny_tool_use(reason: &str) -> ! {
    eprintln!("{reason}");
    std::process::exit("2".parse().unwrap_or_default())
}

/// A `Stop` decision the runner understands.
pub fn deny(reason: String) {
    let decision = serde_json::json!({ "decision": "block", "reason": reason });
    println!("{decision}");
}

fn sessions_root() -> PathBuf {
    if let Ok(custom) = std::env::var("TAMA_OMP_SESSION_ROOT") {
        if !custom.is_empty() {
            return PathBuf::from(custom);
        }
    }
    home_dir().join(".omp").join("agent").join("sessions")
}

fn home_dir() -> PathBuf {
    std::env::var("HOME").map(PathBuf::from).unwrap_or_default()
}

fn transcript_path(session: &str) -> Option<PathBuf> {
    if session.is_empty() {
        return None;
    }
    let mut newest: Option<(std::time::SystemTime, PathBuf)> = None;
    let mut stack = vec![sessions_root()];
    while let Some(directory) = stack.pop() {
        let entries = match std::fs::read_dir(&directory) {
            Ok(entries) => entries,
            Err(_) => continue,
        };
        for entry in entries.flatten() {
            let path = entry.path();
            if path.is_dir() {
                stack.push(path);
                continue;
            }
            let name = match path.file_name().and_then(|n| n.to_str()) {
                Some(name) => name,
                None => continue,
            };
            if !name.contains(session) || !name.ends_with(".jsonl") {
                continue;
            }
            let modified = entry
                .metadata()
                .and_then(|meta| meta.modified())
                .unwrap_or(std::time::UNIX_EPOCH);
            if newest
                .as_ref()
                .map(|(seen, _)| modified > *seen)
                .unwrap_or(true)
            {
                newest = Some((modified, path));
            }
        }
    }
    newest.map(|(_, path)| path)
}

fn retain_tracker_state(calls: &mut Vec<(usize, ToolCall)>, results: &mut Vec<ToolResult>) {
    let snapshot_position = results.iter().rev().find_map(|result| {
        (result.tool_name == "todo"
            && !result.is_error
            && result
                .details
                .get("phases")
                .and_then(Value::as_array)
                .is_some())
        .then_some(result.position)
    });
    calls.retain(|(position, call)| {
        is_tracker_tool(&call.name)
            && snapshot_position
                .map(|snapshot| *position > snapshot)
                .unwrap_or(true)
            && results
                .iter()
                .any(|result| result.call_id == call.id && !result.is_error)
    });
    results.retain(|result| {
        !result.is_error
            && is_tracker_tool(&result.tool_name)
            && snapshot_position
                .map(|snapshot| result.position >= snapshot)
                .unwrap_or(true)
    });
}

fn is_tracker_tool(name: &str) -> bool {
    name == "todo" || name == "update_plan" || name.ends_with("__update_plan")
}

fn collect_tool_calls(position: usize, message: &Value, calls: &mut Vec<(usize, ToolCall)>) {
    if message.get("type").and_then(Value::as_str) == Some("function_call") {
        calls.push((
            position,
            ToolCall {
                id: string_at(message, "id"),
                name: string_at(message, "name").to_lowercase(),
                arguments: arguments_of(message),
            },
        ));
        return;
    }
    if message.get("role").and_then(Value::as_str) != Some("assistant") {
        return;
    }
    for item in content_items(message) {
        if item.get("type").and_then(Value::as_str) != Some("toolCall") {
            continue;
        }
        calls.push((
            position,
            ToolCall {
                id: string_at(item, "id"),
                name: string_at(item, "name").to_lowercase(),
                arguments: arguments_of(item),
            },
        ));
    }
}

fn content_items(message: &Value) -> Vec<&Value> {
    message
        .get("content")
        .and_then(Value::as_array)
        .map(|items| items.iter().filter(|item| item.is_object()).collect())
        .unwrap_or_default()
}

fn is_error_result(message: &Value) -> bool {
    message.get("role").and_then(Value::as_str) == Some("toolResult")
        && message.get("isError").and_then(Value::as_bool) == Some(true)
}

fn result_text(message: &Value) -> String {
    content_items(message)
        .into_iter()
        .filter(|item| item.get("type").and_then(Value::as_str) == Some("text"))
        .filter_map(|item| item.get("text").and_then(Value::as_str))
        .collect::<Vec<_>>()
        .join("\n")
}

fn string_at(value: &Value, key: &str) -> String {
    value
        .get(key)
        .and_then(Value::as_str)
        .unwrap_or_default()
        .to_string()
}

fn arguments_of(call: &Value) -> Value {
    match call.get("arguments") {
        Some(Value::String(text)) => serde_json::from_str(text).unwrap_or(Value::Null),
        Some(value) => value.clone(),
        None => Value::Null,
    }
}

/// Path-looking tokens inside an argument tree: anything containing a slash.
pub fn path_tokens(value: &Value) -> Vec<String> {
    let mut found = Vec::new();
    collect_paths(value, &mut found);
    found
}

fn collect_paths(value: &Value, found: &mut Vec<String>) {
    match value {
        Value::String(text) => {
            for token in text.split(|c: char| c.is_whitespace() || c == '"' || c == '\'') {
                let trimmed =
                    token.trim_matches(|c: char| c == ',' || c == ';' || c == ')' || c == '(');
                if trimmed.contains('/') && trimmed.len() > SHORTEST_PATH.len() {
                    found.push(trimmed.to_string());
                }
            }
        }
        Value::Array(items) => items.iter().for_each(|item| collect_paths(item, found)),
        Value::Object(map) => map.values().for_each(|item| collect_paths(item, found)),
        _ => {}
    }
}
