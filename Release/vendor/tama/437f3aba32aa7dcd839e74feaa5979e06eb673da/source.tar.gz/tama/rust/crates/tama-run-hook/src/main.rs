//! `tama-run-hook` — Rust port of `shared-hooks/run-hook.mjs`.
//!
//! Reads the hook registry, normalizes the stdin payload, runs the hooks
//! registered for the event sequentially (argv spawn, no shell, SIGTERM after
//! `timeout * 1000` ms) and emits the final decision JSON on stdout:
//! `{"decision":"pass","results":[...]}` or, on block,
//! `{"decision":"block","reason":...,"blockedHookId":...,"results":[...]}`
//! (exit code 2 for non-codex providers). For `TAMA_PROVIDER=codex` a `pass`
//! decision is not printed. Any failure along the way ends in
//! `hook runner failure: <msg>` on stderr plus a `pass` decision — a broken
//! runner never blocks.

use std::collections::HashSet;
use std::io::{Read, Write};
use std::path::PathBuf;
use std::process::{Command, Stdio};

use serde_json::Value;

use tama_hooks::hook_exec::{looks_like_malfunction, tokenize_command, CommandResult};
use tama_hooks::session_capability::capability_environment;
use tama_hooks::session_control::{
    hooks_globally_disabled, is_session_hook_enabled, publish_session, read_session_override,
    session_context,
};

// --- JS semantic helpers (local copies; `tama_hooks::jsutil` is crate-private)

/// JS `\s` / `String#trim` whitespace: Unicode `White_Space` plus U+FEFF.
fn is_js_whitespace(c: char) -> bool {
    c.is_whitespace() || c == '\u{feff}'
}

fn trim_js(s: &str) -> &str {
    s.trim_matches(is_js_whitespace)
}

/// JS truthiness of a JSON value (absent/`undefined` is falsy).
fn js_truthy(v: Option<&Value>) -> bool {
    match v {
        None | Some(Value::Null) => false,
        Some(Value::Bool(b)) => *b,
        Some(Value::Number(n)) => n.as_f64().is_some_and(|f| f != 0.0),
        Some(Value::String(s)) => !s.is_empty(),
        Some(_) => true,
    }
}

/// Approximation of JS `Number#toString` for JSON numbers.
fn js_number_to_string(n: &serde_json::Number) -> String {
    if let Some(i) = n.as_i64() {
        return i.to_string();
    }
    if let Some(u) = n.as_u64() {
        return u.to_string();
    }
    let f = n.as_f64().unwrap_or(f64::NAN);
    if f == 0.0 {
        return "0".to_string(); // also covers -0
    }
    let a = f.abs();
    if f.fract() == 0.0 && a < 1e21 {
        return format!("{f:.0}");
    }
    if a >= 1e21 || a < 1e-6 {
        // Rust prints "1.5e21"; JS prints "1.5e+21".
        let s = format!("{f:e}");
        return match s.split_once('e') {
            Some((m, e)) if !e.starts_with('-') => format!("{m}e+{e}"),
            _ => s,
        };
    }
    format!("{f}")
}

/// JS `String(value)` for a JSON value.
fn js_to_string(v: &Value) -> String {
    match v {
        Value::Null => "null".to_string(),
        Value::Bool(b) => if *b { "true" } else { "false" }.to_string(),
        Value::Number(n) => js_number_to_string(n),
        Value::String(s) => s.clone(),
        // Array#toString joins with commas; null/undefined become empty.
        Value::Array(items) => items
            .iter()
            .map(|i| match i {
                Value::Null => String::new(),
                other => js_to_string(other),
            })
            .collect::<Vec<_>>()
            .join(","),
        Value::Object(_) => "[object Object]".to_string(),
    }
}

/// JS `String(value)` where the value may be absent (`undefined`).
fn js_to_string_opt(v: Option<&Value>) -> String {
    match v {
        None => "undefined".to_string(),
        Some(v) => js_to_string(v),
    }
}

/// JS `Number(string)` coercion for the subset relevant to `hook.timeout`.
fn js_number_str(s: &str) -> f64 {
    let t = trim_js(s);
    if t.is_empty() {
        return 0.0;
    }
    match t {
        "Infinity" | "+Infinity" => return f64::INFINITY,
        "-Infinity" => return f64::NEG_INFINITY,
        _ => {}
    }
    for (prefix, radix) in [("0x", 16u32), ("0X", 16), ("0o", 8), ("0O", 8), ("0b", 2), ("0B", 2)] {
        if let Some(rest) = t.strip_prefix(prefix) {
            if rest.is_empty() {
                return f64::NAN;
            }
            let mut v = 0f64;
            for c in rest.chars() {
                match c.to_digit(radix) {
                    Some(d) => v = v * radix as f64 + d as f64,
                    None => return f64::NAN,
                }
            }
            return v;
        }
    }
    if !is_js_decimal(t) {
        return f64::NAN;
    }
    t.parse::<f64>().unwrap_or(f64::NAN)
}

fn is_js_decimal(t: &str) -> bool {
    let b = t.as_bytes();
    let mut i = 0;
    if i < b.len() && (b[i] == b'+' || b[i] == b'-') {
        i += 1;
    }
    let mut int_digits = 0;
    while i < b.len() && b[i].is_ascii_digit() {
        i += 1;
        int_digits += 1;
    }
    let mut frac_digits = 0;
    if i < b.len() && b[i] == b'.' {
        i += 1;
        while i < b.len() && b[i].is_ascii_digit() {
            i += 1;
            frac_digits += 1;
        }
    }
    if int_digits == 0 && frac_digits == 0 {
        return false;
    }
    if i < b.len() && (b[i] == b'e' || b[i] == b'E') {
        i += 1;
        if i < b.len() && (b[i] == b'+' || b[i] == b'-') {
            i += 1;
        }
        let mut exp_digits = 0;
        while i < b.len() && b[i].is_ascii_digit() {
            i += 1;
            exp_digits += 1;
        }
        if exp_digits == 0 {
            return false;
        }
    }
    i == b.len()
}

/// JS `Number(value)` for a JSON value (`Number([x]) === Number(x)`,
/// `Number([]) === 0`, objects are NaN).
fn js_number_value(v: &Value) -> f64 {
    match v {
        Value::Null => 0.0,
        Value::Bool(b) => {
            if *b {
                1.0
            } else {
                0.0
            }
        }
        Value::Number(n) => n.as_f64().unwrap_or(f64::NAN),
        Value::String(s) => js_number_str(s),
        Value::Array(items) => match items.len() {
            0 => 0.0,
            1 => js_number_value(&items[0]),
            _ => f64::NAN,
        },
        Value::Object(_) => f64::NAN,
    }
}

/// `os.homedir()`: `$HOME` on POSIX, with a passwd-database fallback via the
/// shell; `USERPROFILE` / `HOMEDRIVE`+`HOMEPATH` on Windows.
fn home_dir() -> PathBuf {
    #[cfg(unix)]
    {
        if let Some(h) = std::env::var_os("HOME").filter(|v| !v.is_empty()) {
            return PathBuf::from(h);
        }
        if let Ok(out) = Command::new("sh").args(["-c", "printf %s ~"]).output() {
            if out.status.success() && !out.stdout.is_empty() {
                use std::os::unix::ffi::OsStringExt;
                return PathBuf::from(std::ffi::OsString::from_vec(out.stdout));
            }
        }
        PathBuf::from("/")
    }
    #[cfg(windows)]
    {
        if let Some(p) = std::env::var_os("USERPROFILE").filter(|v| !v.is_empty()) {
            return PathBuf::from(p);
        }
        let drive = std::env::var_os("HOMEDRIVE").unwrap_or_default();
        let path = std::env::var_os("HOMEPATH").unwrap_or_default();
        if !drive.is_empty() || !path.is_empty() {
            let mut p = drive;
            p.push(&path);
            return p;
        }
        PathBuf::from(".")
    }
}

/// Port of `expandHome`: `~` before `/` or end-of-string becomes the home
/// directory, and every `$HOME` is replaced.
fn expand_home(command: &str) -> String {
    let home = home_dir().to_string_lossy().into_owned();
    let mut out = String::with_capacity(command.len());
    let mut chars = command.chars().peekable();
    while let Some(c) = chars.next() {
        if c == '~' && matches!(chars.peek(), None | Some('/')) {
            out.push_str(&home);
        } else {
            out.push(c);
        }
    }
    out.replace("$HOME", &home)
}

// --- runner -----------------------------------------------------------------

fn usage() -> &'static str {
    "Usage: run-hook.mjs <event> <agent-id>\nExample: run-hook.mjs stop agent\n"
}

/// Port of `parsePayload`: empty input is `{}`, unparseable input is
/// `{ raw: text }`.
fn parse_payload(text: &str) -> Value {
    if trim_js(text).is_empty() {
        return Value::Object(serde_json::Map::new());
    }
    serde_json::from_str(text).unwrap_or_else(|_| {
        let mut m = serde_json::Map::new();
        m.insert("raw".to_string(), Value::String(text.to_string()));
        Value::Object(m)
    })
}

/// Result of one hook command execution, mirroring the JS `runCommand`
/// resolution value.
#[derive(Debug, Default)]
struct RunResult {
    code: Option<i32>,
    timed_out: bool,
    stdout: String,
    stderr: String,
    spawn_error: bool,
}

/// Node-style spawn error message (`spawn <program> ENOENT`).
fn spawn_error_message(program: &str, error: &std::io::Error) -> String {
    if error.kind() == std::io::ErrorKind::NotFound {
        format!("spawn {} ENOENT", program)
    } else {
        format!("spawn {} {}", program, error)
    }
}

/// Port of `runCommand`: argv spawn (no shell) with the capability
/// environment, the normalized payload on stdin, and SIGTERM after
/// `timeout_ms` (JS `setTimeout` semantics: NaN fires immediately, values
/// above the 32-bit signed range — including Infinity — fire after 1 ms).
fn run_command(command: &str, input: &str, timeout_ms: f64, capability: Option<&Value>) -> RunResult {
    let tokens = tokenize_command(&expand_home(command));
    let (program, args) = match tokens.split_first() {
        Some((program, args)) if !program.is_empty() => (program.clone(), args.to_vec()),
        _ => {
            return RunResult {
                stderr: "empty hook command".to_string(),
                spawn_error: true,
                ..Default::default()
            }
        }
    };
    let mut cmd = Command::new(&program);
    cmd.args(&args)
        // `spawn(program, args, { env })` replaces the whole environment.
        .env_clear()
        .envs(capability_environment(capability, &[]))
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped());
    let mut child = match cmd.spawn() {
        Ok(child) => child,
        Err(error) => {
            return RunResult {
                stderr: spawn_error_message(&program, &error),
                spawn_error: true,
                ..Default::default()
            }
        }
    };
    let mut stdout_handle = child.stdout.take();
    let mut stderr_handle = child.stderr.take();
    let stdout_thread = std::thread::spawn(move || -> Vec<u8> {
        let mut buf = Vec::new();
        if let Some(mut out) = stdout_handle.take() {
            let _ = out.read_to_end(&mut buf);
        }
        buf
    });
    let stderr_thread = std::thread::spawn(move || -> Vec<u8> {
        let mut buf = Vec::new();
        if let Some(mut err) = stderr_handle.take() {
            let _ = err.read_to_end(&mut buf);
        }
        buf
    });
    let mut stdin_error = None;
    if let Some(mut stdin) = child.stdin.take() {
        if let Err(error) = stdin.write_all(input.as_bytes()) {
            // `child.stdin.on('error', ...)` appends the message to stderr.
            stdin_error = Some(if error.kind() == std::io::ErrorKind::BrokenPipe {
                "write EPIPE".to_string()
            } else {
                error.to_string()
            });
        }
        // Dropping stdin closes it, like `child.stdin.end(input)`.
    }
    let timeout = if timeout_ms.is_nan() {
        std::time::Duration::from_millis(0)
    } else if !timeout_ms.is_finite() || timeout_ms > 2_147_483_647.0 {
        std::time::Duration::from_millis(1)
    } else {
        std::time::Duration::from_millis(timeout_ms as u64)
    };
    let start = std::time::Instant::now();
    let mut timed_out = false;
    let status = loop {
        match child.try_wait() {
            Ok(Some(status)) => break Some(status),
            Ok(None) => {
                if start.elapsed() >= timeout {
                    timed_out = true;
                    // `child.kill('SIGTERM')`; afterwards JS waits for 'close'
                    // indefinitely, so we simply block on wait().
                    let _ = Command::new("kill")
                        .args(["-TERM", &child.id().to_string()])
                        .status();
                    break child.wait().ok();
                }
                std::thread::sleep(std::time::Duration::from_millis(5));
            }
            Err(_) => break None,
        }
    };
    let stdout_bytes = stdout_thread.join().unwrap_or_default();
    let stderr_bytes = stderr_thread.join().unwrap_or_default();
    let mut stderr = String::from_utf8_lossy(&stderr_bytes).into_owned();
    if let Some(message) = stdin_error {
        stderr.push_str(&message);
    }
    RunResult {
        code: status.and_then(|s| s.code()),
        timed_out,
        stdout: String::from_utf8_lossy(&stdout_bytes).into_owned(),
        stderr,
        spawn_error: false,
    }
}

/// Port of `decisionFromOutput`: the whole trimmed output must be a JSON
/// object with `decision === 'block'`; the reason is `parsed.reason ||
/// 'hook returned block decision'` (stringified like a template literal).
fn decision_from_output(text: &str) -> Option<String> {
    let trimmed = trim_js(text);
    if trimmed.is_empty() {
        return None;
    }
    let parsed: Value = serde_json::from_str(trimmed).ok()?;
    if parsed.is_object()
        && parsed.get("decision").and_then(Value::as_str) == Some("block")
    {
        let reason = parsed.get("reason");
        return Some(if js_truthy(reason) {
            js_to_string_opt(reason)
        } else {
            "hook returned block decision".to_string()
        });
    }
    None
}

// --- JSON emission (manual, to preserve the JS key order: -------------------
//     decision, reason, blockedHookId, results; id, code, timedOut, failed) --

/// One entry of the `results` array.
enum Record {
    /// `{ id: hook.id, skipped: true }`
    Skipped(Option<Value>),
    /// `{ id, code, timedOut }` plus `failed: true` after a malfunction.
    Exec {
        id: Option<Value>,
        code: Option<i32>,
        timed_out: bool,
        failed: bool,
    },
}

fn json_str(s: &str) -> String {
    serde_json::to_string(s).unwrap_or_else(|_| "\"\"".to_string())
}

fn json_value(v: &Value) -> String {
    serde_json::to_string(v).unwrap_or_else(|_| "null".to_string())
}

fn serialize_results(results: &[Record]) -> String {
    let mut out = String::from("[");
    for (i, record) in results.iter().enumerate() {
        if i > 0 {
            out.push(',');
        }
        match record {
            Record::Skipped(id) => {
                out.push('{');
                if let Some(id) = id {
                    out.push_str("\"id\":");
                    out.push_str(&json_value(id));
                    out.push(',');
                }
                out.push_str("\"skipped\":true}");
            }
            Record::Exec {
                id,
                code,
                timed_out,
                failed,
            } => {
                out.push('{');
                if let Some(id) = id {
                    out.push_str("\"id\":");
                    out.push_str(&json_value(id));
                    out.push(',');
                }
                out.push_str("\"code\":");
                match code {
                    Some(c) => out.push_str(&c.to_string()),
                    None => out.push_str("null"),
                }
                out.push_str(",\"timedOut\":");
                out.push_str(if *timed_out { "true" } else { "false" });
                if *failed {
                    out.push_str(",\"failed\":true");
                }
                out.push('}');
            }
        }
    }
    out.push(']');
    out
}

fn pass_with_reason_json(reason: &str) -> String {
    format!("{{\"decision\":\"pass\",\"reason\":{}}}", json_str(reason))
}

fn pass_with_results_json(results: &[Record]) -> String {
    format!(
        "{{\"decision\":\"pass\",\"results\":{}}}",
        serialize_results(results)
    )
}

fn block_json(reason: &str, blocked_id: Option<&Value>, results: &[Record]) -> String {
    let mut out = String::from("{\"decision\":\"block\",\"reason\":");
    out.push_str(&json_str(reason));
    if let Some(id) = blocked_id {
        out.push_str(",\"blockedHookId\":");
        out.push_str(&json_value(id));
    }
    out.push_str(",\"results\":");
    out.push_str(&serialize_results(results));
    out.push('}');
    out
}

/// Port of `emitDecision`. Returns the process exit code contribution
/// (2 for a block with a non-codex provider).
fn emit_decision(provider: &str, decision: &str, json: &str) -> i32 {
    if provider == "codex" {
        if decision != "pass" {
            let value: Value = serde_json::from_str(json).unwrap_or(Value::Null);
            let reason = value
                .get("reason")
                .and_then(Value::as_str)
                .unwrap_or("hook returned block decision");
            let codex = serde_json::json!({
                "decision": "block",
                "reason": reason,
            });
            let mut out = std::io::stdout().lock();
            let _ = out.write_all(codex.to_string().as_bytes());
            let _ = out.flush();
        }
        return 0;
    }
    let mut out = std::io::stdout().lock();
    let _ = out.write_all(json.as_bytes());
    let _ = out.flush();
    if decision == "block" {
        2
    } else {
        0
    }
}

fn write_stderr(text: &str) {
    let mut err = std::io::stderr().lock();
    let _ = err.write_all(text.as_bytes());
    let _ = err.flush();
}

// --- payload normalization ----------------------------------------------------

/// Port of the `normalized` payload construction. Returns the JSON string
/// passed to hooks on stdin. Key order follows the JS object spread:
/// payload keys first (see note), then `cwd`, `transcript_path` and
/// `agent_hook_event` appended when absent; `raw_event` is dropped.
///
/// Deviation: `serde_json::Value` does not preserve source key order (the
/// workspace does not enable `preserve_order`), so payload keys are emitted
/// sorted instead of in original document order; this affects nested objects
/// as well. Also, float values re-serialize as `1.0` where JS emits `1`.
fn normalized_payload(payload: &Value, event: &str) -> String {
    // `{ ...payload }` — objects spread their own keys, arrays and strings
    // spread indexed entries, everything else spreads nothing.
    let mut entries: Vec<(String, Value)> = match payload {
        Value::Object(map) => map.iter().map(|(k, v)| (k.clone(), v.clone())).collect(),
        Value::Array(items) => items
            .iter()
            .enumerate()
            .map(|(i, v)| (i.to_string(), v.clone()))
            .collect(),
        Value::String(s) => s
            .chars()
            .enumerate()
            .map(|(i, c)| (i.to_string(), Value::String(c.to_string())))
            .collect(),
        _ => Vec::new(),
    };
    let object = payload.as_object();
    let get = |key: &str| object.and_then(|m| m.get(key));
    let raw_event = match payload.get("raw_event") {
        // `payload.raw_event && typeof payload.raw_event === 'object'` — only
        // plain objects expose the fallback keys (arrays have none of them).
        Some(v @ Value::Object(_)) => Some(v),
        _ => None,
    };
    let raw_get = |key: &str| raw_event.and_then(|m| m.get(key));

    // `payload.cwd || rawEvent.cwd || payload.project_dir` — when nothing is
    // truthy the value is `undefined`, which `JSON.stringify` drops entirely.
    let cwd = ["cwd", "raw_event.cwd", "project_dir"]
        .iter()
        .map(|k| match *k {
            "raw_event.cwd" => raw_get("cwd"),
            k => get(k),
        })
        .find(|v| js_truthy(*v))
        .flatten()
        .cloned();
    // `... || null` — always defined, so the key is always emitted.
    let transcript_path = ["transcript_path", "raw_event.transcript_path", "transcriptPath"]
        .iter()
        .map(|k| match *k {
            "raw_event.transcript_path" => raw_get("transcript_path"),
            "transcriptPath" => raw_get("transcriptPath"),
            k => get(k),
        })
        .find(|v| js_truthy(*v))
        .flatten()
        .cloned()
        .unwrap_or(Value::Null);

    fn upsert(entries: &mut Vec<(String, Value)>, key: &str, value: Value) {
        if let Some(entry) = entries.iter_mut().find(|(k, _)| k == key) {
            entry.1 = value;
        } else {
            entries.push((key.to_string(), value));
        }
    }
    match cwd {
        Some(v) => upsert(&mut entries, "cwd", v),
        None => entries.retain(|(k, _)| k != "cwd"),
    }
    upsert(&mut entries, "transcript_path", transcript_path);
    entries.retain(|(k, _)| k != "raw_event");
    upsert(
        &mut entries,
        "agent_hook_event",
        Value::String(event.to_string()),
    );

    let mut out = String::from("{");
    for (i, (key, value)) in entries.iter().enumerate() {
        if i > 0 {
            out.push(',');
        }
        out.push_str(&json_str(key));
        out.push(':');
        out.push_str(&json_value(value));
    }
    out.push('}');
    out
}

// --- main ----------------------------------------------------------------------

/// Node `readFile` error text for the common cases.
fn read_error_message(path: &std::path::Path, error: &std::io::Error) -> String {
    match error.kind() {
        std::io::ErrorKind::NotFound => {
            format!("ENOENT: no such file or directory, open '{}'", path.display())
        }
        std::io::ErrorKind::PermissionDenied => {
            format!("EACCES: permission denied, open '{}'", path.display())
        }
        _ => error.to_string(),
    }
}

/// The body of `main()` in the JS file. `Err(message)` bubbles up to the
/// `main().catch(...)` equivalent in `run`.
fn inner(
    registry_path: &std::path::Path,
    event: &str,
    agent_id: &str,
    provider: &str,
    only_hook_id: &str,
    disabled_hook_ids: &HashSet<String>,
    has_enabled_hook_filter: bool,
    enabled_hook_ids: &HashSet<String>,
) -> Result<i32, String> {
    if event.is_empty() {
        write_stderr(usage());
        return Ok(2);
    }
    let registry_text =
        std::fs::read(registry_path).map_err(|e| read_error_message(registry_path, &e))?;
    let registry_text = String::from_utf8_lossy(&registry_text);
    let registry: Value = serde_json::from_str(&registry_text).map_err(|e| e.to_string())?;

    let mut stdin_bytes = Vec::new();
    std::io::stdin()
        .lock()
        .read_to_end(&mut stdin_bytes)
        .map_err(|e| e.to_string())?;
    let input = String::from_utf8_lossy(&stdin_bytes).into_owned();
    let payload = parse_payload(&input);

    let mut known_hook_ids: HashSet<String> = HashSet::new();
    if let Some(events) = registry.get("events").and_then(Value::as_object) {
        for entry in events.values() {
            // `entry.hooks` on a null entry throws a TypeError in JS.
            if entry.is_null() {
                return Err("Cannot read properties of null (reading 'hooks')".to_string());
            }
            match entry.get("hooks") {
                Some(hooks_value) if js_truthy(Some(hooks_value)) => {
                    // `(entry.hooks || []).map(...)` — a truthy non-array
                    // throws a TypeError in JS.
                    let Some(hooks) = hooks_value.as_array() else {
                        return Err(
                            "(entry.hooks || []).map is not a function".to_string()
                        );
                    };
                    for hook in hooks {
                        // `hook.id` on a null hook throws a TypeError in JS.
                        if hook.is_null() {
                            return Err(
                                "Cannot read properties of null (reading 'id')".to_string()
                            );
                        }
                        // `String(hook.id || '')` then `.filter(Boolean)` — only
                        // truthy ids land in the set, stringified.
                        if let Some(id) = hook.get("id").filter(|v| js_truthy(Some(v))) {
                            let id = js_to_string(id);
                            if !id.is_empty() {
                                known_hook_ids.insert(id);
                            }
                        }
                    }
                }
                _ => {}
            }
        }
    }

    let context = session_context(agent_id, Some(&payload));
    let session_capability =
        read_session_override(context.as_ref(), Some(&known_hook_ids)).capability;
    publish_session(context.as_ref(), Some(&known_hook_ids), Some(&payload))
        .map_err(|e| e.to_string())?;

    // `registry.events?.[event]` guarded by `if (!entry)` — a falsy entry
    // (null, false, 0, "") takes the same "no hooks" branch as a missing one.
    let entry = registry
        .get("events")
        .and_then(|e| e.get(event))
        .filter(|e| js_truthy(Some(e)));
    let Some(entry) = entry else {
        let json = pass_with_reason_json(&format!("no hooks for {}", event));
        return Ok(emit_decision(provider, "pass", &json));
    };

    // `payload.raw_event` (and later `payload.cwd` etc.) throw a TypeError in
    // JS when the payload is `null`.
    if payload.is_null() {
        return Err("Cannot read properties of null (reading 'raw_event')".to_string());
    }
    let normalized = normalized_payload(&payload, event);
    let mut results: Vec<Record> = Vec::new();

    let empty_hooks = Vec::new();
    let hooks: &Vec<Value> = match entry.get("hooks") {
        Some(v) if js_truthy(Some(v)) => match v.as_array() {
            Some(arr) => arr,
            // `for (const hook of entry.hooks || [])` on a truthy,
            // non-iterable value throws a TypeError in JS (unreachable in
            // practice: the knownHookIds pass above throws first).
            None => {
                let what = match v {
                    Value::Number(_) => format!("number {}", js_to_string(v)),
                    Value::Bool(b) => format!("boolean {}", b),
                    _ => "object".to_string(),
                };
                return Err(format!(
                    "{} is not iterable (cannot read property Symbol(Symbol.iterator))",
                    what
                ));
            }
        },
        _ => &empty_hooks,
    };

    let legacy_codex_dispatcher = provider == "codex"
        && !only_hook_id.is_empty()
        && hooks
            .first()
            .and_then(|hook| hook.get("id"))
            .and_then(Value::as_str)
            == Some(only_hook_id);
    if provider == "codex" && !only_hook_id.is_empty() && !legacy_codex_dispatcher {
        let json = pass_with_reason_json(&format!(
            "legacy wrapper {} delegated to dispatcher",
            only_hook_id
        ));
        return Ok(emit_decision(provider, "pass", &json));
    }

    for hook in hooks {
        let id_value = hook.get("id").cloned();
        let id_str = hook.get("id").and_then(Value::as_str);
        let id_display = js_to_string_opt(hook.get("id"));

        // `isSessionHookEnabled(context, hook.id, ...)` — a non-string id can
        // never be in `enabledHookIds`, so it is enabled exactly when hooks
        // are not globally disabled.
        let session_enabled = match id_str {
            Some(id) => is_session_hook_enabled(context.as_ref(), id, Some(&known_hook_ids)),
            None => !hooks_globally_disabled(),
        };
        if (!only_hook_id.is_empty() && !legacy_codex_dispatcher && id_str != Some(only_hook_id))
            || id_str.is_some_and(|id| disabled_hook_ids.contains(id))
            || (has_enabled_hook_filter && !id_str.is_some_and(|id| enabled_hook_ids.contains(id)))
            || !session_enabled
        {
            results.push(Record::Skipped(id_value));
            continue;
        }

        // `Math.max(1, Number(hook.timeout || 10)) * 1000` — NaN propagates.
        let timeout_raw = hook.get("timeout").filter(|v| js_truthy(Some(v)));
        let timeout_num = timeout_raw.map_or(10.0, js_number_value);
        let timeout_ms = if timeout_num.is_nan() {
            f64::NAN
        } else {
            timeout_num.max(1.0) * 1000.0
        };
        let timeout_display = timeout_raw.map_or_else(|| "10".to_string(), js_to_string);

        // `tokenizeCommand(expandHome(command))` — `String(command)` first.
        let command = js_to_string_opt(hook.get("command"));
        let result = run_command(&command, &normalized, timeout_ms, session_capability.as_ref());
        results.push(Record::Exec {
            id: id_value.clone(),
            code: result.code,
            timed_out: result.timed_out,
            failed: false,
        });

        if result.timed_out {
            let reason = format!("{} timed out after {}s", id_display, timeout_display);
            if entry.get("blocking") != Some(&Value::Bool(false)) {
                let json = block_json(&reason, id_value.as_ref(), &results);
                return Ok(emit_decision(provider, "block", &json));
            }
            continue;
        }

        let block_reason = decision_from_output(&result.stdout)
            .or_else(|| decision_from_output(&result.stderr));
        if let Some(block_reason) = block_reason {
            let reason = format!("{}: {}", id_display, block_reason);
            let json = block_json(&reason, id_value.as_ref(), &results);
            return Ok(emit_decision(provider, "block", &json));
        }

        let malfunction_check = CommandResult {
            spawn_error: result.spawn_error,
            stdout: Some(result.stdout.clone()),
            stderr: Some(result.stderr.clone()),
        };
        if result.spawn_error
            || (result.code.is_some_and(|c| c != 0) && looks_like_malfunction(&malfunction_check))
        {
            // The hook crashed. A broken policy engine is not a policy
            // decision; denying on it is indistinguishable from a deliberate
            // block.
            let detail = if js_truthy(Some(&Value::String(result.stderr.clone()))) {
                result.stderr.clone()
            } else if js_truthy(Some(&Value::String(result.stdout.clone()))) {
                result.stdout.clone()
            } else {
                String::new()
            };
            write_stderr(&format!(
                "hook {} malfunctioned: {}\n",
                id_display,
                trim_js(&detail)
            ));
            if let Some(Record::Exec { failed, .. }) = results.last_mut() {
                *failed = true;
            }
            continue;
        }

        if result.code.is_some_and(|c| c != 0) && entry.get("blocking") != Some(&Value::Bool(false))
        {
            let fallback = format!("exit {}", result.code.unwrap_or(0));
            let reason_source = if !result.stderr.is_empty() {
                &result.stderr
            } else if !result.stdout.is_empty() {
                &result.stdout
            } else {
                &fallback
            };
            let reason = format!("{}: {}", id_display, trim_js(reason_source));
            let json = block_json(&reason, id_value.as_ref(), &results);
            return Ok(emit_decision(provider, "block", &json));
        }
    }

    let json = pass_with_results_json(&results);
    Ok(emit_decision(provider, "pass", &json))
}

fn run() -> i32 {
    let registry_path = std::env::var_os("AGENT_HOOK_REGISTRY")
        .filter(|v| !v.is_empty())
        .map(PathBuf::from)
        .unwrap_or_else(|| home_dir().join(".shared-hooks").join("registry.json"));
    let args: Vec<String> = std::env::args_os()
        .map(|a| a.to_string_lossy().into_owned())
        .collect();
    let event = args.get(1).cloned().unwrap_or_default();
    let agent_id = trim_js(&match args.get(2).filter(|s| !s.is_empty()) {
        Some(a) => a.clone(),
        None => std::env::var("TAMA_AGENT_ID").unwrap_or_default(),
    })
    .to_lowercase();
    let provider = match std::env::var("TAMA_PROVIDER") {
        Ok(p) if !p.is_empty() => trim_js(&p).to_lowercase(),
        _ => agent_id.clone(),
    };
    let only_hook_id = trim_js(&std::env::var("TAMA_ONLY_HOOK_ID").unwrap_or_default()).to_string();
    let split_ids = |name: &str| -> HashSet<String> {
        std::env::var(name)
            .unwrap_or_default()
            .split(',')
            .map(trim_js)
            .filter(|id| !id.is_empty())
            .map(str::to_string)
            .collect()
    };
    let disabled_hook_ids = split_ids("TAMA_DISABLED_HOOKS");
    let has_enabled_hook_filter = std::env::var_os("TAMA_ENABLED_HOOKS").is_some();
    let enabled_hook_ids = split_ids("TAMA_ENABLED_HOOKS");

    match inner(
        &registry_path,
        &event,
        &agent_id,
        &provider,
        &only_hook_id,
        &disabled_hook_ids,
        has_enabled_hook_filter,
        &enabled_hook_ids,
    ) {
        Ok(code) => code,
        // `main().catch(...)` — a broken runner never blocks.
        Err(message) => {
            write_stderr(&format!("hook runner failure: {}\n", message));
            let json = pass_with_reason_json("hook runner failure");
            emit_decision(&provider, "pass", &json)
        }
    }
}

fn main() {
    std::process::exit(run());
}
