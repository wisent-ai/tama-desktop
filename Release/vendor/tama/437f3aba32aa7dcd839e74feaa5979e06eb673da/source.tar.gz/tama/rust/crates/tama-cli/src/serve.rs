//! `tama serve` — loopback HTTP/JSON backend for the desktop app.
//!
//! The desktop spawns this once (`tama serve --port 0 --root <release>`) and
//! talks to it over 127.0.0.1 HTTP — it never builds argv for the other
//! commands. On bind, exactly one line lands on stdout:
//!
//!   {"ready":true,"port":<number>}
//!
//! After that, stdout carries no protocol traffic; every failure is an HTTP
//! response. All endpoints live under /v1 and reuse the exact functions the
//! CLI commands use (runtime, install, scan_repos, clean) — no parallel
//! implementation.
//!
//! Errors are non-2xx with body {"error": "<one sentence>"} — the product's
//! own refusal sentence, verbatim from the underlying failure.
//!
//! Long-running jobs (violation scan / clean) stream NDJSON:
//!   {"type":"log","stream":"stdout"|"stderr","chunk":"..."}  (zero or more)
//!   {"type":"result","status":0,"json":{...}}                (exactly one, last)
//! where `json` is the same document the command prints and `status` mirrors
//! its exit code.

use std::io::{BufRead, BufReader, Read, Write};
use std::net::{Ipv4Addr, Shutdown, TcpListener, TcpStream};
use std::path::{Path, PathBuf};
use std::sync::Mutex;

use serde_json::{json, Value};
use tama_core::install::level_plan;
use tama_core::policy_bundle::{
    import_policy_bundle, list_policy_bundles, ImportPolicyBundleOptions,
};
use tama_core::runtime::declared_provider_coverage;
use tama_violations::clean::{clean_repo, clean_summary_lines, CleanJsonOutput, CleanParams};
use tama_violations::scan_repos::{parse_scan_args, run_scan, scan_json_document};

use crate::{mcp_config, EXIT_USAGE};

const MAX_BODY_BYTES: usize = 1024 * 1024;

/// Streamed jobs patch no shared state, but one cleanup mutates one working
/// tree at a time and each job's log events belong on their own response, so
/// jobs run one at a time.
static JOB_LOCK: Mutex<()> = Mutex::new(());

pub fn main(args: &[String], root: &Path) -> i32 {
    let mut port: u16 = 0;
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "--port" => {
                let Some(value) = args.get(i + 1) else {
                    eprintln!("missing value for --port");
                    return EXIT_USAGE;
                };
                match value.parse() {
                    Ok(parsed) => port = parsed,
                    Err(_) => {
                        eprintln!("invalid --port: {value}");
                        return EXIT_USAGE;
                    }
                }
                i += 2;
            }
            // `--root` is already resolved by the caller; it stays in argv.
            "--root" => {
                if args.get(i + 1).is_none() {
                    eprintln!("missing value for --root");
                    return EXIT_USAGE;
                }
                i += 2;
            }
            other => {
                eprintln!("unknown serve option: {other}");
                return EXIT_USAGE;
            }
        }
    }
    let listener = match TcpListener::bind((Ipv4Addr::LOCALHOST, port)) {
        Ok(listener) => listener,
        Err(error) => {
            eprintln!("{error}");
            return 1;
        }
    };
    let bound = listener.local_addr().map(|address| address.port()).unwrap_or(port);
    // The ready line is the only stdout write: after it, stdout is
    // protocol-clean and every failure is an HTTP response or a stderr log.
    println!("{}", json!({ "ready": true, "port": bound }));
    let _ = std::io::stdout().flush();

    for stream in listener.incoming() {
        if let Ok(stream) = stream {
            let root = root.to_path_buf();
            std::thread::spawn(move || handle(stream, root));
        }
    }
    0
}

struct Request {
    method: String,
    path: String,
    body: Vec<u8>,
}

/// Reads one request: request line, headers, then exactly Content-Length
/// body bytes. Returns None on a closed or unreadable connection — there is
/// no one to report to.
fn read_request(reader: &mut BufReader<TcpStream>) -> std::io::Result<Option<Request>> {
    let mut request_line = String::new();
    if reader.read_line(&mut request_line)? == 0 {
        return Ok(None);
    }
    let mut parts = request_line.split_whitespace();
    let (Some(method), Some(target), _) = (parts.next(), parts.next(), parts.next()) else {
        return Ok(None);
    };
    let mut content_length = 0usize;
    loop {
        let mut line = String::new();
        if reader.read_line(&mut line)? == 0 {
            return Ok(None);
        }
        let trimmed = line.trim();
        if trimmed.is_empty() {
            break;
        }
        if let Some((name, value)) = trimmed.split_once(':') {
            if name.eq_ignore_ascii_case("content-length") {
                content_length = value.trim().parse().unwrap_or(0);
            }
        }
    }
    if content_length > MAX_BODY_BYTES {
        return Ok(Some(Request {
            method: method.to_string(),
            path: "/__body-too-large__".to_string(),
            body: Vec::new(),
        }));
    }
    let mut body = vec![0u8; content_length];
    reader.read_exact(&mut body)?;
    Ok(Some(Request {
        method: method.to_string(),
        path: target.to_string(),
        body,
    }))
}

fn handle(stream: TcpStream, root: PathBuf) {
    let Ok(mut writer) = stream.try_clone() else {
        return;
    };
    let mut reader = BufReader::new(stream);
    match read_request(&mut reader) {
        Ok(Some(request)) => dispatch(request, &root, &mut writer),
        Ok(None) | Err(_) => {}
    }
}

fn reason(status: u16) -> &'static str {
    match status {
        200 => "OK",
        400 => "Bad Request",
        403 => "Forbidden",
        404 => "Not Found",
        500 => "Internal Server Error",
        _ => "Error",
    }
}

fn send_json(writer: &mut TcpStream, status: u16, document: &Value) {
    let body = serde_json::to_vec(document).unwrap_or_default();
    let _ = write!(
        writer,
        "HTTP/1.1 {status} {}\r\ncontent-type: application/json\r\ncontent-length: {}\r\nconnection: close\r\n\r\n",
        reason(status),
        body.len()
    );
    let _ = writer.write_all(&body);
    let _ = writer.shutdown(Shutdown::Both);
}

fn send_error(writer: &mut TcpStream, status: u16, message: &str) {
    send_json(writer, status, &json!({ "error": message }));
}

/// The parsed JSON body, or the (status, sentence) of the refusal.
fn json_body(request: &Request) -> Result<Value, (u16, String)> {
    let text = String::from_utf8_lossy(&request.body);
    let trimmed = text.trim();
    if trimmed.is_empty() {
        return Ok(json!({}));
    }
    serde_json::from_str(trimmed)
        .map_err(|_| (400, "request body is not valid JSON".to_string()))
}

fn write_event(writer: &mut TcpStream, event: &Value) {
    let mut line = serde_json::to_vec(event).unwrap_or_default();
    line.push(b'\n');
    let _ = writer.write_all(&line);
    let _ = writer.flush();
}

/// Streams one job as NDJSON after a 200 header, mirroring the command:
/// log events in the job's own order, then exactly one result event whose
/// status mirrors the exit code and whose json is the command's document.
fn stream_job(
    writer: &mut TcpStream,
    job: impl FnOnce(&mut dyn FnMut(&str, &str)) -> (i32, Value),
) {
    let _ = write!(
        writer,
        "HTTP/1.1 200 OK\r\ncontent-type: application/x-ndjson\r\ncache-control: no-cache\r\nconnection: close\r\n\r\n"
    );
    let _ = writer.flush();
    let _guard = JOB_LOCK.lock();
    {
        let mut emit = |stream: &str, chunk: &str| {
            write_event(writer, &json!({ "type": "log", "stream": stream, "chunk": chunk }));
        };
        let (status, document) = job(&mut emit);
        write_event(writer, &json!({ "type": "result", "status": status, "json": document }));
    }
    let _ = writer.shutdown(Shutdown::Both);
}

fn dispatch(request: Request, root: &Path, writer: &mut TcpStream) {
    let path = request.path.split('?').next().unwrap_or("");
    match (request.method.as_str(), path) {
        ("GET", "/v1/health") => send_json(writer, 200, &json!({ "status": "ok" })),
        ("GET", "/v1/coverage") => match declared_provider_coverage(root) {
            Ok(coverage) => send_json(writer, 200, &serde_json::to_value(coverage).unwrap_or_default()),
            Err(error) => send_error(writer, 500, &error.to_string()),
        },
        ("GET", "/v1/install-plan") => {
            send_json(writer, 200, &serde_json::to_value(level_plan(root, None, None)).unwrap_or_default())
        }
        ("GET", "/v1/mcp-config") => {
            send_json(writer, 200, &serde_json::to_value(mcp_config()).unwrap_or_default())
        }
        ("GET", "/v1/policy-bundles") => match list_policy_bundles(None) {
            Ok(bundles) => send_json(
                writer,
                200,
                &serde_json::to_value(bundles).unwrap_or_default(),
            ),
            Err(error) => send_error(writer, 500, &error.to_string()),
        },
        ("POST", "/v1/policy-bundles/import") => policy_import(request, writer),
        ("POST", "/v1/violations/scan") => scan_job(request, root, writer),
        ("POST", "/v1/violations/clean") => clean_job(request, root, writer),
        (_, "/__body-too-large__") => send_error(writer, 400, "request body too large"),
        _ => send_error(
            writer,
            404,
            &format!("unknown endpoint: {} {path}", request.method),
        ),
    }
}

fn policy_import(request: Request, writer: &mut TcpStream) {
    let body = match json_body(&request) {
        Ok(body) => body,
        Err((status, message)) => {
            send_error(writer, status, &message);
            return;
        }
    };
    let Some(source) = body.get("sourcePath").and_then(Value::as_str) else {
        send_error(writer, 400, "sourcePath is required");
        return;
    };
    if source.trim().is_empty() {
        send_error(writer, 400, "sourcePath is required");
        return;
    }
    let replace = body.get("replace").and_then(Value::as_bool).unwrap_or(false);
    match import_policy_bundle(ImportPolicyBundleOptions {
        source: Path::new(source),
        home: None,
        replace,
    }) {
        Ok(result) => send_json(
            writer,
            200,
            &serde_json::to_value(result).unwrap_or_default(),
        ),
        Err(error) => send_error(writer, 400, &error.to_string()),
    }
}

/// `tama find-violations --repo <path> --json` as a streamed job. The usage
/// rejections the command exits 2 on are 400 envelopes here, sent before the
/// stream starts.
fn scan_job(request: Request, root: &Path, writer: &mut TcpStream) {
    let body = match json_body(&request) {
        Ok(body) => body,
        Err((status, message)) => return send_error(writer, status, &message),
    };
    let repo = body.get("repo").and_then(Value::as_str).unwrap_or("").to_string();
    let argv = vec!["--repo".to_string(), repo.clone(), "--json".to_string()];
    let Some(args) = parse_scan_args(&argv, root) else {
        return send_error(writer, 400, "scan requires a repo path");
    };
    if !Path::new(&args.hook_path).exists() {
        return send_error(writer, 400, &format!("hook not found: {}", args.hook_path));
    }
    if !Path::new(&repo).exists() {
        return send_error(writer, 400, &format!("repo not found: {repo}"));
    }
    stream_job(writer, |emit| {
        let (reports, problems) = run_scan(&args, |line| emit("stderr", &format!("{line}\n")));
        let total: usize = reports.iter().map(|report| report.violations.len()).sum();
        let document = scan_json_document(&reports, &problems);
        let status = if total > 0 || !problems.is_empty() { 1 } else { 0 };
        (status, serde_json::to_value(&document).unwrap_or_default())
    });
}

/// `tama clean --repo <path>` with the command's defaults (Codex, three
/// rounds, no skip list, no note) as a streamed job: the repair screen is
/// deliberately one shape, so the endpoint takes no knobs.
fn clean_job(request: Request, root: &Path, writer: &mut TcpStream) {
    if std::env::var("TAMA_CLEAN_DISABLED").as_deref() == Ok("1") {
        return send_error(writer, 403, "tama clean is disabled (TAMA_CLEAN_DISABLED=1)");
    }
    let body = match json_body(&request) {
        Ok(body) => body,
        Err((status, message)) => return send_error(writer, status, &message),
    };
    let repo = body.get("repo").and_then(Value::as_str).unwrap_or("").to_string();
    if repo.is_empty() {
        return send_error(writer, 400, "clean requires a repo path");
    }
    let hook = root.join("shared-hooks").join("pre_write_edit.sh");
    if !hook.exists() {
        return send_error(writer, 400, &format!("hook not found: {}", hook.display()));
    }
    if !Path::new(&repo).exists() {
        return send_error(writer, 400, &format!("repo not found: {repo}"));
    }
    let hook_path = hook.to_string_lossy().into_owned();
    stream_job(writer, |emit| {
        emit("stderr", &format!("[clean] {repo}: starting repair rounds\n"));
        let result = clean_repo(&CleanParams {
            repo: &repo,
            hook_path: &hook_path,
            model: "codex",
            max_rounds: 3.0,
            dry_run: false,
            skip: &[],
            note: None,
            root,
        });
        for line in clean_summary_lines(&result) {
            emit("stdout", &format!("{line}\n"));
        }
        let unresolved = result.clean == Some(false) || result.locked == Some(true);
        let document = CleanJsonOutput {
            results: std::slice::from_ref(&result),
            problems: &[],
        };
        let status = if unresolved { 1 } else { 0 };
        (status, serde_json::to_value(&document).unwrap_or_default())
    });
}
