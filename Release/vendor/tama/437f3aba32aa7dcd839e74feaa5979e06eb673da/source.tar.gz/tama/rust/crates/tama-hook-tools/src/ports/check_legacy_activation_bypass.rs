//! `check-legacy-activation-bypass` — port of
//! `codex-hooks/check_legacy_activation_bypass.py`.
//!
//! Device-level guard against legacy activation queue bypasses. Two modes,
//! chosen by stdin: a truthy payload is a `PreToolUse` check of the tool's own
//! text, an empty one is a full scan of the Wisent tree.
//!
//! Consent state: none. The hook reads no approval file, writes no state, and
//! consults no transcript; in tree mode it reads source files under the Wisent
//! root, and in payload mode only the tool call in front of it.

use super::check_legacy_activation_bypass_markers as markers;
use super::check_legacy_activation_bypass_tree as tree;
use super::pystr;
use super::pyvalue::{py_str, truthy};
use serde_json::Value;
use tama_hooks::session_record::read_payload;

const EXIT_PASS_TEXT: &str = "0";
const EXIT_BLOCK_TEXT: &str = "2";
/// Python reaches `payload.get` on a truthy non-mapping and dies with an
/// `AttributeError`; the interpreter exits 1. The port keeps that exit code.
const EXIT_CRASH_TEXT: &str = "1";

const TOOL_NAME_KEY: &str = "tool_name";
const TOOL_INPUT_KEY: &str = "tool_input";
const COMMAND_KEYS: &[&str] = &["command", "cmd"];
const LABEL_KEYS: &[&str] = &["file_path", "notebook_path"];
const EDIT_TEXT_KEYS: &[&str] = &["content", "new_string", "patch", "new_source"];
const SHELL_LABEL: &str = "bash command";

fn exit_pass() -> i32 {
    EXIT_PASS_TEXT.parse().unwrap_or_default()
}

fn exit_block() -> i32 {
    EXIT_BLOCK_TEXT.parse().unwrap_or_default()
}

fn exit_crash() -> i32 {
    EXIT_CRASH_TEXT.parse().unwrap_or_default()
}

fn empty_object() -> Value {
    Value::Object(Default::default())
}

/// `command.strip().split(maxsplit=1)[0]` against the read-only allowlist.
fn is_read_only_shell(command: &str) -> bool {
    let first = pystr::strip(command)
        .split_whitespace()
        .next()
        .unwrap_or_default();
    markers::READ_ONLY_SHELL_PROGRAMS.contains(&first)
}

fn shell_command(tool_input: &Value, raw_tool_input: &Value) -> String {
    for key in COMMAND_KEYS {
        if let Some(value) = tool_input.get(*key) {
            if truthy(value) {
                return py_str(value);
            }
        }
    }
    if truthy(raw_tool_input) {
        py_str(raw_tool_input)
    } else {
        String::new()
    }
}

fn edit_label(tool_input: &Value, tool: &str) -> String {
    for key in LABEL_KEYS {
        if let Some(value) = tool_input.get(*key) {
            if truthy(value) {
                return py_str(value);
            }
        }
    }
    tool.to_string()
}

fn edit_text(tool_input: &Value, raw_tool_input: &Value) -> String {
    let parts: Vec<String> = EDIT_TEXT_KEYS
        .iter()
        .map(|key| match tool_input.get(*key) {
            Some(value) if truthy(value) => py_str(value),
            _ => String::new(),
        })
        .collect();
    let text = parts.join("\n");
    // Ported bug: joining four parts always leaves at least three newlines, so
    // `if not text and raw_tool_input` in the Python can never fire.
    if text.is_empty() && truthy(raw_tool_input) {
        return py_str(raw_tool_input);
    }
    text
}

/// `true` when the tool call is denied; the banner is already on stderr.
fn check_pretool(payload: &Value) -> bool {
    let tool = payload
        .get(TOOL_NAME_KEY)
        .and_then(Value::as_str)
        .unwrap_or_default();
    let raw_tool_input = match payload.get(TOOL_INPUT_KEY) {
        Some(value) if truthy(value) => value.clone(),
        _ => empty_object(),
    };
    let tool_input = if raw_tool_input.is_object() {
        raw_tool_input.clone()
    } else {
        empty_object()
    };

    let (text, label) = if markers::SHELL_TOOLS.contains(&tool) {
        let command = shell_command(&tool_input, &raw_tool_input);
        if is_read_only_shell(&command) {
            return false;
        }
        (command, SHELL_LABEL.to_string())
    } else if markers::EDIT_TOOLS.contains(&tool) {
        let label = edit_label(&tool_input, tool);
        (edit_text(&tool_input, &raw_tool_input), label)
    } else {
        return false;
    };

    let hits = markers::blocks_in_text(&text);
    let direct_hf_hits = markers::direct_hf_upload_blocks_in_text(&text, &label);
    let queue_hits = markers::queue_blocks_in_text(&text, &label);
    if hits.is_empty() {
        if queue_hits.is_empty() && direct_hf_hits.is_empty() {
            return false;
        }
        if !direct_hf_hits.is_empty() {
            let found = direct_hf_hits.join(", ");
            eprintln!(
                "BLOCKED: foreground HF upload path detected in {label}: {found}\n\
Activation upload must go through wisent.scripts.activations.raw.upload_worker \
after the GPU slot is released."
            );
            return true;
        }
        let found = queue_hits.join(", ");
        eprintln!(
            "BLOCKED: direct queue mutation detected in {label}: {found}\n\
Use wisent_compute.queue.submit or the queue storage layer; do not write queue \
blobs directly from ad-hoc scripts."
        );
        return true;
    }
    let found = hits.join(", ");
    eprintln!(
        "BLOCKED: legacy activation bypass detected in {label}: {found}\n\
Remove it. Use the raw activation extractor plus detached upload worker path; \
do not recreate foreground HF upload jobs."
    );
    true
}

pub fn run() -> i32 {
    let payload = read_payload();
    if !truthy(&payload) {
        return if tree::check_tree() {
            exit_block()
        } else {
            exit_pass()
        };
    }
    if !payload.is_object() {
        eprintln!("check_legacy_activation_bypass: payload is not a JSON object");
        return exit_crash();
    }
    if check_pretool(&payload) {
        exit_block()
    } else {
        exit_pass()
    }
}
