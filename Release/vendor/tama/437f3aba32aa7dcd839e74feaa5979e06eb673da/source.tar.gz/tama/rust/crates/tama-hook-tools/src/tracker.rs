//! Replay the task-tracker protocol from recorded tool calls.
//!
//! Guards share this state machine so failed calls and terminal task states have
//! identical meaning at every stop boundary.

use std::collections::BTreeMap;

use serde_json::Value;

const OPEN_STATES: &[&str] = &["pending", "in_progress"];
const BLOCKABLE_STATES: &[&str] = &["pending", "in_progress", "blocked"];
const TERMINAL_STATES: &[&str] = &["done", "dropped", "removed", "completed", "abandoned"];
const DEFAULT_INIT_PHASE: &str = "Tasks";

#[derive(Clone)]
struct Item {
    phase: String,
    status: String,
}

#[derive(Default)]
pub struct Tracker {
    items: BTreeMap<String, Item>,
}

fn text_at(value: &Value, key: &str) -> String {
    value
        .get(key)
        .and_then(Value::as_str)
        .unwrap_or_default()
        .to_string()
}

fn declared_items(args: &Value) -> Vec<(String, String)> {
    let mut declared = Vec::new();
    if let Some(phases) = args.get("list").and_then(Value::as_array) {
        for entry in phases {
            let phase = text_at(entry, "phase");
            if let Some(items) = entry.get("items").and_then(Value::as_array) {
                for task in items.iter().filter_map(Value::as_str) {
                    declared.push((phase.clone(), task.to_string()));
                }
            }
        }
    }
    if let Some(items) = args.get("items").and_then(Value::as_array) {
        let phase = match text_at(args, "phase") {
            phase if !phase.is_empty() => phase,
            _ if text_at(args, "op").eq_ignore_ascii_case("init") => DEFAULT_INIT_PHASE.to_string(),
            _ => String::new(),
        };
        for task in items.iter().filter_map(Value::as_str) {
            declared.push((phase.clone(), task.to_string()));
        }
    }
    declared
}

impl Tracker {
    fn set_status(&mut self, args: &Value, status: &str) {
        let task = args.get("task").and_then(Value::as_str).unwrap_or_default();
        let phase = args
            .get("phase")
            .and_then(Value::as_str)
            .unwrap_or_default();
        let can_transition =
            |item: &Item| status == "removed" || !TERMINAL_STATES.contains(&item.status.as_str());
        if !task.is_empty() {
            if let Some(item) = self.items.get_mut(task) {
                if can_transition(item) {
                    item.status = status.to_string();
                }
            }
            return;
        }
        if !phase.is_empty() {
            for item in self.items.values_mut() {
                if item.phase == phase && can_transition(item) {
                    item.status = status.to_string();
                }
            }
        }
    }

    fn apply_todo(&mut self, args: &Value) {
        let op = text_at(args, "op").to_lowercase();
        match op.as_str() {
            "init" | "append" => {
                if op == "init" {
                    self.items.clear();
                }
                for (phase, task) in declared_items(args) {
                    self.items.insert(
                        task,
                        Item {
                            phase,
                            status: "pending".to_string(),
                        },
                    );
                }
            }
            "start" => self.set_status(args, "in_progress"),
            "done" => self.set_status(args, "done"),
            "drop" => self.set_status(args, "dropped"),
            "block" => self.set_status(args, "blocked"),
            "unblock" => self.set_status(args, "pending"),
            "rm" => {
                let named = args.get("task").and_then(Value::as_str).is_some()
                    || args.get("phase").and_then(Value::as_str).is_some();
                if named {
                    self.set_status(args, "removed");
                } else {
                    self.items.clear();
                }
            }
            _ => {}
        }
    }

    fn apply_update_plan(&mut self, args: &Value) {
        let Some(plan) = args.get("plan").and_then(Value::as_array) else {
            return;
        };
        self.items.clear();
        for entry in plan {
            let task = text_at(entry, "step");
            if task.is_empty() {
                continue;
            }
            self.items.insert(
                task,
                Item {
                    phase: String::new(),
                    status: text_at(entry, "status").to_lowercase(),
                },
            );
        }
    }

    /// Replace replayed state with the authoritative phase snapshot returned
    /// by a successful `todo` call.
    pub fn apply_todo_snapshot(&mut self, phases: &Value) -> bool {
        let Some(phases) = phases.as_array() else {
            return false;
        };
        self.items.clear();
        for phase in phases {
            let phase_name = text_at(phase, "name");
            let Some(tasks) = phase.get("tasks").and_then(Value::as_array) else {
                continue;
            };
            for task in tasks {
                let content = text_at(task, "content");
                if content.is_empty() {
                    continue;
                }
                self.items.insert(
                    content,
                    Item {
                        phase: phase_name.clone(),
                        status: text_at(task, "status").to_lowercase(),
                    },
                );
            }
        }
        true
    }

    pub fn apply_call(&mut self, name: &str, args: &Value) {
        if name == "todo" {
            self.apply_todo(args);
        } else if name == "update_plan" || name.ends_with("__update_plan") {
            self.apply_update_plan(args);
        }
    }

    fn target_has_state(&self, args: &Value, states: &[&str]) -> bool {
        let task = args.get("task").and_then(Value::as_str).unwrap_or_default();
        if !task.is_empty() {
            return self
                .items
                .get(task)
                .is_some_and(|item| states.contains(&item.status.as_str()));
        }
        let phase = args
            .get("phase")
            .and_then(Value::as_str)
            .unwrap_or_default();
        !phase.is_empty()
            && self
                .items
                .values()
                .any(|item| item.phase == phase && states.contains(&item.status.as_str()))
    }

    pub fn block_targets_live_item(&self, args: &Value) -> bool {
        self.target_has_state(args, BLOCKABLE_STATES)
    }

    pub fn block_target_is_blocked(&self, args: &Value) -> bool {
        self.target_has_state(args, &["blocked"])
    }

    pub fn open_items(self) -> Vec<String> {
        self.items
            .into_iter()
            .filter(|(_, item)| OPEN_STATES.contains(&item.status.as_str()))
            .map(|(task, _)| task)
            .collect()
    }
}
