//! Rust port of `shared-hooks/hook-exec.mjs` plus the child-process runner
//! shared by `omp-shared-hooks.js` and `run-one-session-hook.js`.
//!
//! Two invariants mirror the JS original:
//!   1. Hook commands are argv, never a shell string.
//!   2. A crashing hook is a malfunction, not a policy decision.

use serde_json::Value;
use std::io::Read;
use std::io::Write;
use std::process::{Command, Stdio};

/// Result of one hook command execution, mirroring the JS result objects.
#[derive(Debug, Clone, Default)]
pub struct HookOutput {
    pub code: Option<i32>,
    pub signal: Option<i32>,
    pub timed_out: bool,
    pub stdout: String,
    pub stderr: String,
    pub spawn_error: bool,
}

/// Shell word semantics: quoted and unquoted runs that are not separated by
/// whitespace belong to the SAME argument.
pub fn tokenize_command(command: &str) -> Vec<String> {
    let mut tokens = Vec::new();
    let mut current = String::new();
    let mut started = false;
    let mut quote: Option<char> = None;
    let mut escaped = false;
    for ch in command.chars() {
        if escaped {
            current.push(ch);
            escaped = false;
            continue;
        }
        if quote != Some('\'') && ch == '\\' {
            escaped = true;
            started = true;
            continue;
        }
        if quote.is_none() && (ch == '"' || ch == '\'') {
            quote = Some(ch);
            started = true;
            continue;
        }
        if quote.is_some() && Some(ch) == quote {
            quote = None;
            continue;
        }
        if quote.is_none() && ch.is_whitespace() {
            if started {
                tokens.push(std::mem::take(&mut current));
                started = false;
            }
            continue;
        }
        current.push(ch);
        started = true;
    }
    if started {
        tokens.push(current);
    }
    tokens
}

fn line_matches_malfunction(s: &str) -> bool {
    if s.starts_with("Traceback (most recent call last):") {
        return true;
    }
    if s.starts_with("File \"") && s[6..].contains("\", line ") {
        return true;
    }
    if let Some(rest) = s.strip_prefix("at ") {
        let token_len = rest.find(char::is_whitespace).unwrap_or(rest.len());
        if token_len > 0 && rest[token_len..].starts_with(" (") && s.ends_with(')') {
            return true;
        }
    }
    for prefix in ["ModuleNotFound", "Import", "Syntax", "Indentation", "Tab"] {
        if s.starts_with(prefix) && s[prefix.len()..].starts_with("Error:") {
            return true;
        }
    }
    if s.starts_with("node:internal/") {
        return true;
    }
    for suffix in ["command not found", "No such file or directory"] {
        if let Some(head) = s.strip_suffix(suffix) {
            if let Some(head) = head.strip_suffix(": ") {
                if !head.chars().any(|c| c.is_whitespace() || c == ':') {
                    return true;
                }
            }
        }
    }
    false
}

/// Port of `MALFUNCTION_RE.test(...)`. The JS regex is multiline-anchored
/// (`^...$` with the `m` flag); `\s*` after `^` may itself consume newlines,
/// so every line-start position is probed.
pub fn malfunction_re_test(text: &str) -> bool {
    let mut rest = text;
    loop {
        let trimmed = rest.trim_start_matches(char::is_whitespace);
        let line_end = trimmed.find('\n').unwrap_or(trimmed.len());
        if line_matches_malfunction(&trimmed[..line_end]) {
            return true;
        }
        match rest.find('\n') {
            Some(index) => rest = &rest[index + 1..],
            None => return false,
        }
    }
}

/// Port of `looksLikeMalfunction`.
pub fn looks_like_malfunction(output: &HookOutput) -> bool {
    if output.spawn_error {
        return true;
    }
    malfunction_re_test(&output.stderr) || malfunction_re_test(&output.stdout)
}

/// Port of `decisionFromOutput` from omp-shared-hooks.js: the whole trimmed
/// output must be a JSON object with `decision === 'block'`.
pub fn decision_from_output(text: &str) -> Option<String> {
    let trimmed = text.trim();
    if trimmed.is_empty() {
        return None;
    }
    let parsed: Value = serde_json::from_str(trimmed).ok()?;
    if parsed.is_object() && parsed.get("decision").and_then(Value::as_str) == Some("block") {
        let reason = parsed.get("reason").and_then(Value::as_str);
        return Some(match reason {
            Some(r) if !r.is_empty() => r.to_string(),
            _ => "hook returned block decision".to_string(),
        });
    }
    None
}

/// Port of `outputBlockReason` from run-one-session-hook.js: only the last
/// non-empty line is considered.
pub fn output_block_reason(text: &str) -> Option<String> {
    let line = text
        .trim()
        .split('\n')
        .filter(|l| !l.is_empty())
        .next_back()?;
    let parsed: Value = serde_json::from_str(line).ok()?;
    if parsed.get("decision").and_then(Value::as_str) == Some("block") {
        let reason = parsed.get("reason").and_then(Value::as_str);
        return Some(match reason {
            Some(r) if !r.is_empty() => r.to_string(),
            _ => "Hook blocked the tool call.".to_string(),
        });
    }
    None
}

/// Node-style spawn error message (`spawn <program> ENOENT`).
fn spawn_error_message(program: &str, error: &std::io::Error) -> String {
    if error.kind() == std::io::ErrorKind::NotFound {
        format!("spawn {} ENOENT", program)
    } else {
        format!("spawn {} {}", program, error)
    }
}

/// Run one hook command: argv spawn (no shell), JSON payload on stdin,
/// stdout/stderr captured, SIGTERM after `timeout_ms`. Mirrors
/// `runHookCommand` in omp-shared-hooks.js. `env_set` overrides and
/// `env_remove` deletes variables on top of the inherited environment.
pub fn run_hook_command(
    command: &str,
    payload: &Value,
    timeout_ms: u64,
    env_set: &[(String, String)],
    env_remove: &[String],
) -> HookOutput {
    let tokens = tokenize_command(command);
    let (program, args) = match tokens.split_first() {
        Some((program, args)) if !program.is_empty() => (program.clone(), args.to_vec()),
        _ => {
            return HookOutput {
                code: None,
                signal: None,
                timed_out: false,
                stdout: String::new(),
                stderr: "empty hook command".to_string(),
                spawn_error: true,
            }
        }
    };
    let mut cmd = Command::new(&program);
    cmd.args(&args)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped());
    for (key, value) in env_set {
        cmd.env(key, value);
    }
    for key in env_remove {
        cmd.env_remove(key);
    }
    let mut child = match cmd.spawn() {
        Ok(child) => child,
        Err(error) => {
            return HookOutput {
                code: None,
                signal: None,
                timed_out: false,
                stdout: String::new(),
                stderr: spawn_error_message(&program, &error),
                spawn_error: true,
            }
        }
    };
    let body = serde_json::to_string(payload).unwrap_or_default();
    let mut stdin_error = None;
    if let Some(mut stdin) = child.stdin.take() {
        if let Err(error) = stdin.write_all(body.as_bytes()) {
            stdin_error = Some(error.to_string());
        }
        // Dropping stdin closes it, like `child.stdin.end(...)`.
    }
    let mut stdout_handle = child.stdout.take();
    let mut stderr_handle = child.stderr.take();
    let stdout_thread = std::thread::spawn(move || -> Vec<u8> {
        let mut buf = Vec::new();
        if let Some(mut out) = stdout_handle.take() {
            let _ = out.read_to_end(&mut buf);
        }
        buf
    });
    let stderr_thread = std::thread::spawn(move || -> Vec<u8> {
        let mut buf = Vec::new();
        if let Some(mut err) = stderr_handle.take() {
            let _ = err.read_to_end(&mut buf);
        }
        buf
    });
    let timeout = std::time::Duration::from_millis(timeout_ms.max(1));
    let start = std::time::Instant::now();
    let mut timed_out = false;
    let status = loop {
        match child.try_wait() {
            Ok(Some(status)) => break Some(status),
            Ok(None) => {
                if start.elapsed() >= timeout {
                    timed_out = true;
                    crate::util::sys::send_signal(child.id(), crate::util::sys::SIGTERM);
                    // Keep waiting for the exit status after SIGTERM, like the
                    // JS 'close' handler does; as a safety net the JS runtime
                    // never needed, force-kill a child that ignores SIGTERM.
                    let grace = std::time::Instant::now();
                    let final_status = loop {
                        match child.try_wait() {
                            Ok(Some(status)) => break Some(status),
                            Ok(None) => {
                                if grace.elapsed() >= std::time::Duration::from_secs(5) {
                                    let _ = child.kill();
                                    break child.wait().ok();
                                }
                                std::thread::sleep(std::time::Duration::from_millis(5));
                            }
                            Err(_) => break None,
                        }
                    };
                    break final_status;
                }
                std::thread::sleep(std::time::Duration::from_millis(5));
            }
            Err(_) => break None,
        }
    };
    let stdout_bytes = stdout_thread.join().unwrap_or_default();
    let stderr_bytes = stderr_thread.join().unwrap_or_default();
    let mut stderr = String::from_utf8_lossy(&stderr_bytes).into_owned();
    if let Some(message) = stdin_error {
        stderr.push_str(&message);
    }
    let (code, signal) = match status {
        Some(status) => {
            use std::os::unix::process::ExitStatusExt;
            (status.code(), status.signal())
        }
        None => (None, None),
    };
    HookOutput {
        code,
        signal,
        timed_out,
        stdout: String::from_utf8_lossy(&stdout_bytes).into_owned(),
        stderr,
        spawn_error: false,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Vectors generated with Node `tokenizeCommand` from hook-exec.mjs.
    #[test]
    fn tokenize_matches_node() {
        let cases: Vec<(&str, Vec<&str>)> = vec![
            ("python3 /x/y.py", vec!["python3", "/x/y.py"]),
            ("node '/path with spaces'/hooks/entry.mjs", vec!["node", "/path with spaces/hooks/entry.mjs"]),
            ("env FOO=bar 'a'\"b\"c d", vec!["env", "FOO=bar", "abc", "d"]),
            ("a\\ b c", vec!["a b", "c"]),
            ("echo \"it\\'s\"", vec!["echo", "it's"]),
            ("", vec![]),
            ("   ", vec![]),
            ("'\\x27", vec!["\\x27"]),
            ("cmd \"unclosed", vec!["cmd", "unclosed"]),
            ("trailing\\", vec!["trailing"]),
        ];
        for (input, expected) in cases {
            assert_eq!(tokenize_command(input), expected, "input: {:?}", input);
        }
    }

    /// Vectors generated with Node `looksLikeMalfunction` from hook-exec.mjs.
    #[test]
    fn malfunction_matches_node() {
        let cases: Vec<(&str, &str, bool)> = vec![
            ("", "Traceback (most recent call last):\n  File \"x\", line 1", true),
            ("", "  File \"/a/b.py\", line 12, in <module>", true),
            ("", "    at Object.<anonymous> (/x/y.js:1:1)", true),
            ("", "at foo (bar)", true),
            ("", "at foo(bar)", false),
            ("", "ModuleNotFoundError: No module named 'x'", true),
            ("", "ImportError: x", true),
            ("", "SyntaxError: x", true),
            ("", "node:internal/modules/cjs/loader:123", true),
            ("", "bash: foo: command not found", false),
            ("", "zsh: command not found: foo", false),
            ("", "python3: can't open file '/x/y.py': [Errno 2] No such file or directory", false),
            ("some normal output", "", false),
            ("", "IndentationError: unexpected indent", true),
            ("", "TabError: inconsistent use of tabs", true),
            ("x\n\nat foo (bar)", "", true),
        ];
        for (stdout, stderr, expected) in cases {
            let output = HookOutput {
                stdout: stdout.to_string(),
                stderr: stderr.to_string(),
                ..Default::default()
            };
            assert_eq!(looks_like_malfunction(&output), expected, "stderr: {:?}", stderr);
        }
    }
}
