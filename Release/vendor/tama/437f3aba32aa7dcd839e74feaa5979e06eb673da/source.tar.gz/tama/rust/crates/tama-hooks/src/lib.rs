//! tama-hooks: shared hook execution helpers.
//! Rust port of `shared-hooks/hook-exec.mjs`, `session-capability.mjs`,
//! `session-control.mjs`.

pub mod hook_exec;
pub mod session_capability;
pub mod session_control;
pub mod session_record;

mod jsutil;
pub mod sha256;
