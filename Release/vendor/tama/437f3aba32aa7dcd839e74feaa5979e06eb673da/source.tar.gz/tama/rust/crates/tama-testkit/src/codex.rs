//! Port of `src/tests/live-runtime/runtimes/codex-replay.mjs`.

use std::path::Path;

use crate::git_codex::{
    self, Probe,
};
use crate::json::Json;
use crate::orchestration::Ctx;
use crate::scenarios::CodexScenario;
use crate::support::{self, RunOpts};

/// JS `adapterEventsForReplay(adapterEvent, matcher)` from codex-replay.mjs
/// (note: subtly different from `adapterEvents` in core).
fn adapter_events_for_replay(adapter_event: &str, matcher: &str) -> Vec<String> {
    let key = adapter_event.to_lowercase();
    let tools: Vec<String> = matcher
        .split('|')
        .map(|tool| tool.trim().to_lowercase())
        .filter(|tool| !tool.is_empty())
        .collect();
    if key == "stop" {
        return vec!["stop".to_string()];
    }
    if key == "userpromptsubmit" {
        return vec!["user_prompt_submit".to_string()];
    }
    if key == "sessionstart" {
        return vec![if tools.iter().any(|t| t == "compact") {
            "session_start:compact"
        } else {
            "session_start"
        }
        .to_string()];
    }
    if key == "posttooluse" {
        return vec![if tools.iter().any(|t| t == "bash") {
            "post_tool_use:bash"
        } else {
            "post_tool_use"
        }
        .to_string()];
    }
    if key != "pretooluse" {
        return vec![key];
    }
    let mut events: Vec<&str> = Vec::new();
    let mut push = |event: &'static str| {
        if !events.contains(&event) {
            events.push(event);
        }
    };
    for tool in &tools {
        match tool.as_str() {
            "bash" | "run_command" | "runcommands" | "runpackagecommand" | "runpackagescript" => {
                push("pre_tool_use:bash")
            }
            "read" | "readfile" => push("pre_tool_use:read"),
            "edit" | "apply_patch" => push("pre_tool_use:edit"),
            "write" | "writefile" => push("pre_tool_use:write"),
            "task" | "agent" => push("pre_tool_use:task"),
            "todo" => push("pre_tool_use:todo"),
            "goal" => push("pre_tool_use:goal"),
            "grep" | "glob" | "search" | "lsp" | "astgrep" | "ast_grep" => {
                push("pre_tool_use:lookup")
            }
            "eval" | "execute_code" | "mcp__node_repl_js" | "node_repl/js" => {
                push("pre_tool_use:eval")
            }
            "ssh" => push("pre_tool_use:ssh"),
            "notebookedit" | "notebook_edit" => push("pre_tool_use:notebook"),
            "monitor" | "schedulewakeup" | "schedule_wakeup" | "wait" => push("pre_tool_use:wait"),
            _ => {}
        }
    }
    events.into_iter().map(str::to_string).collect()
}

/// One entry of JS `codexAdapterEntries()`.
#[derive(Debug, Clone)]
pub struct ReplayEntry {
    pub event: String,
    pub command: String,
    pub timeout: f64,
}

/// JS `codexAdapterEntries()` — reads the codex adapter config with the
/// ordered parser so `Object.entries(config.hooks)` order is preserved.
pub fn codex_adapter_entries(root: &Path) -> Result<Vec<ReplayEntry>, String> {
    let registry = tama_core::runtime::load_registry(root).map_err(|e| e.to_string())?;
    let adapter_path = registry
        .adapters
        .get("codex")
        .and_then(|adapter| adapter.path.clone())
        .ok_or_else(|| "Cannot read properties of undefined (reading 'path')".to_string())?;
    let text = support::read(Path::new(&adapter_path))?;
    let config = crate::json::parse(&text)?;
    let mut entries = Vec::new();
    let empty: Vec<Json> = Vec::new();
    if let Some(hooks_root) = config.get("hooks").and_then(Json::as_object) {
        for (adapter_event, blocks) in hooks_root {
            for block in blocks.as_array().unwrap_or(&empty) {
                // `matcher = ''` default applies when the key is absent.
                let matcher = block
                    .get("matcher")
                    .map(Json::js_string)
                    .unwrap_or_default();
                for event in adapter_events_for_replay(adapter_event, &matcher) {
                    for hook in block
                        .get("hooks")
                        .and_then(Json::as_array)
                        .unwrap_or(&empty)
                    {
                        // `if (hook.command)` — truthy (non-empty) string.
                        if let Some(command) = hook
                            .get("command")
                            .and_then(Json::as_str)
                            .filter(|c| !c.is_empty())
                        {
                            // `hook.timeout || 10`.
                            let timeout = match hook.get("timeout") {
                                Some(value) if value.truthy() => {
                                    crate::json::js_number_value(Some(value))
                                }
                                _ => 10.0,
                            };
                            entries.push(ReplayEntry {
                                event: event.clone(),
                                command: command.to_string(),
                                timeout,
                            });
                        }
                    }
                }
            }
        }
    }
    Ok(entries)
}

/// JS `codexReplayPayload(event, scratchDir)` — returns the payload JSON text
/// (compact, trailing newline) and lazily creates the safe fixtures.
pub fn codex_replay_payload(event: &str, scratch_dir: &Path) -> Result<String, String> {
    let safe_file = scratch_dir.join("codex-replay-safe.txt");
    let safe_notebook = scratch_dir.join("codex-replay-safe.ipynb");
    if !scratch_dir.exists() {
        std::fs::create_dir_all(scratch_dir)
            .map_err(|e| support::io_error_message("mkdir", scratch_dir, &e))?;
    }
    if !safe_file.exists() {
        support::write_file(&safe_file, "before replay\n")?;
    }
    if !safe_notebook.exists() {
        let notebook = Json::obj(vec![
            ("cells".to_string(), Json::arr(vec![])),
            ("metadata".to_string(), Json::obj(vec![])),
            ("nbformat".to_string(), Json::num_i64(4)),
            ("nbformat_minor".to_string(), Json::num_i64(5)),
        ]);
        support::write_file(&safe_notebook, &notebook.to_compact())?;
    }
    let safe_file_str = safe_file.to_string_lossy().into_owned();
    let safe_notebook_str = safe_notebook.to_string_lossy().into_owned();
    let tool_input = |entries: Vec<(&str, Json)>| -> Json {
        Json::obj(entries.into_iter().map(|(k, v)| (k.to_string(), v)).collect())
    };
    let payload = |tool: &str, input: Json| -> Json {
        Json::obj(vec![
            ("tool_name".to_string(), Json::str(tool)),
            ("tool_input".to_string(), input),
        ])
    };
    let payload = match event {
        "stop" => Json::obj(vec![
            (
                "response".to_string(),
                Json::str("Done. Verified with focused tests. No open items remain."),
            ),
            ("messages".to_string(), Json::arr(vec![])),
        ]),
        "user_prompt_submit" => Json::obj(vec![
            ("hook_event_name".to_string(), Json::str("UserPromptSubmit")),
            (
                "prompt".to_string(),
                Json::str("Run the Codex full-local hook replay smoke."),
            ),
        ]),
        "post_tool_use:bash" => Json::obj(vec![
            ("tool_name".to_string(), Json::str("Bash")),
            (
                "tool_input".to_string(),
                tool_input(vec![("command", Json::str("printf codex_replay"))]),
            ),
            (
                "tool_response".to_string(),
                Json::obj(vec![
                    ("stdout".to_string(), Json::str("codex_replay")),
                    ("stderr".to_string(), Json::str("")),
                    ("exit_code".to_string(), Json::num_i64(0)),
                ]),
            ),
        ]),
        "session_start:compact" => Json::obj(vec![(
            "source".to_string(),
            Json::str("compact"),
        )]),
        "pre_tool_use:bash" => payload(
            "Bash",
            tool_input(vec![("command", Json::str("printf codex_replay"))]),
        ),
        "pre_tool_use:read" => payload(
            "Read",
            tool_input(vec![("file_path", Json::str(safe_file_str.clone()))]),
        ),
        "pre_tool_use:edit" => payload(
            "Edit",
            tool_input(vec![
                ("file_path", Json::str(safe_file_str.clone())),
                ("old_string", Json::str("before replay")),
                ("new_string", Json::str("after replay")),
            ]),
        ),
        "pre_tool_use:write" => payload(
            "Write",
            tool_input(vec![
                ("file_path", Json::str(safe_file_str.clone())),
                ("content", Json::str("after replay\n")),
            ]),
        ),
        "pre_tool_use:task" => payload(
            "Task",
            tool_input(vec![
                ("description", Json::str("Inspect one file")),
                ("prompt", Json::str("Read only")),
            ]),
        ),
        "pre_tool_use:todo" => payload(
            "Todo",
            tool_input(vec![
                ("i", Json::str("Track requested change")),
                (
                    "items",
                    Json::arr(vec![Json::str("Complete requested change")]),
                ),
            ]),
        ),
        "pre_tool_use:goal" => payload("Goal", tool_input(vec![("op", Json::str("get"))])),
        "pre_tool_use:lookup" => payload(
            "Grep",
            tool_input(vec![
                ("i", Json::str("Search source")),
                ("pattern", Json::str("needle")),
                ("path", Json::str(safe_file_str.clone())),
            ]),
        ),
        "pre_tool_use:eval" => payload(
            "Eval",
            tool_input(vec![
                ("title", Json::str("Compute value")),
                ("language", Json::str("py")),
                ("code", Json::str("1 + 1")),
            ]),
        ),
        "pre_tool_use:ssh" => payload(
            "SSH",
            tool_input(vec![
                ("host", Json::str("example.invalid")),
                ("command", Json::str("printf replay")),
            ]),
        ),
        "pre_tool_use:notebook" => payload(
            "NotebookEdit",
            tool_input(vec![
                ("notebook_path", Json::str(safe_notebook_str.clone())),
                ("cell_id", Json::str("cell-1")),
                ("new_source", Json::str("codex replay notebook")),
            ]),
        ),
        "pre_tool_use:wait" => payload(
            "Monitor",
            tool_input(vec![
                ("timeout_ms", Json::num_i64(1000)),
                ("persistent", Json::Bool(false)),
            ]),
        ),
        // `payloads[event] || {}`.
        _ => Json::obj(vec![]),
    };
    Ok(format!("{}\n", payload.to_compact()))
}

/// JS `codexBlockResult(scenario, probe)`.
fn codex_block_result(scenario: &CodexScenario, probe: &Probe, ctx: &Ctx) -> Result<Json, String> {
    let router_covered_keys =
        git_codex::covered_keys_from_codex_router_coverage(&ctx.root, &probe.output)?;
    if probe.via_model_router && !router_covered_keys.iter().any(|k| k == scenario.coverage_key) {
        return Err(format!(
            "model-router Codex hook coverage log missing {}",
            scenario.coverage_key
        ));
    }
    Ok(Json::obj(vec![
        ("ok".to_string(), Json::Bool(true)),
        ("runtime".to_string(), Json::str("codex")),
        (
            "hook".to_string(),
            Json::str("block-hook-config-edits-without-consent"),
        ),
        (
            "coveredKeys".to_string(),
            Json::arr(vec![Json::str(scenario.coverage_key)]),
        ),
        (
            "coverageKey".to_string(),
            Json::str(scenario.coverage_key),
        ),
        (
            "command".to_string(),
            Json::arr(probe.command.iter().cloned().map(Json::Str).collect()),
        ),
        (
            "forbiddenAction".to_string(),
            Json::str("git config core.hooksPath .githooks"),
        ),
        (
            "runtimeExitStatus".to_string(),
            match probe.exit_status {
                Some(code) => Json::num_i64(code as i64),
                None => Json::Null,
            },
        ),
        (
            "targetBeforeEqualsAfter".to_string(),
            Json::Bool(!probe.target_changed),
        ),
        ("blocked".to_string(), Json::Bool(true)),
        ("payloadCaptured".to_string(), Json::Bool(false)),
    ]))
}

/// JS `codexUnavailableResult(scenario, probes)`.
fn codex_unavailable_result(
    scenario: &CodexScenario,
    probes: &[(&str, &Probe)],
    ctx: &Ctx,
) -> Result<Json, String> {
    let parts: Vec<String> = probes
        .iter()
        .map(|(label, probe)| format!("{label}: {}", git_codex::codex_probe_unavailable_reason(probe)))
        .collect();
    let blocker = format!(
        "Codex runtime could not dispatch hooks: {}",
        parts.join("; ")
    );
    let _ = scenario;
    let probe_json = probes
        .iter()
        .map(|(_, probe)| probe.to_json_without_output())
        .collect();
    let affected = required_keys_for(&ctx.root, "codex", None)?;
    Ok(git_codex::unavailable_runtime(
        "codex",
        &blocker,
        probe_json,
        affected,
    ))
}

/// JS `requiredKeysFor(runtime, event = null)`.
pub fn required_keys_for(
    root: &Path,
    runtime: &str,
    event: Option<&str>,
) -> Result<Vec<String>, String> {
    let required = tama_core::runtime::build_required_coverage(root).map_err(|e| e.to_string())?;
    Ok(required
        .iter()
        .filter(|item| item.runtime() == runtime && (event.is_none() || Some(item.event()) == event))
        .map(|item| item.coverage_key().to_string())
        .collect())
}

/// JS `claudeEventsByHookName` (lookup only; the JS object's insertion order
/// does not affect the result because `Object.entries(counts)` drives order).
pub fn claude_events_by_hook_name(hook_name: &str) -> &'static [&'static str] {
    match hook_name {
        "UserPromptSubmit" => &["user_prompt_submit"],
        "PostToolUse:Bash" => &["post_tool_use:bash"],
        "PreToolUse:Bash" => &["pre_tool_use:bash"],
        "PreToolUse:Read" => &["pre_tool_use:read"],
        "PreToolUse:Edit" => &["pre_tool_use:edit"],
        "PreToolUse:Write" => &["pre_tool_use:edit", "pre_tool_use:write"],
        "PreToolUse:MultiEdit" => &["pre_tool_use:multiedit"],
        "PreToolUse:NotebookEdit" => &["pre_tool_use:notebook"],
        "PreToolUse:Monitor" => &["pre_tool_use:wait"],
        "PreToolUse:ScheduleWakeup" => &["pre_tool_use:wait"],
        "Stop" => &["stop"],
        "SessionStart" => &["session_start:compact"],
        _ => &[],
    }
}

/// JS `countSuccessfulClaudeHookResponses(entries)` — insertion-ordered.
fn count_successful_claude_hook_responses(entries: &[Json]) -> Vec<(String, u64)> {
    let mut counts: Vec<(String, u64)> = Vec::new();
    for entry in entries {
        if entry.get("type").and_then(Json::as_str) != Some("system")
            || entry.get("subtype").and_then(Json::as_str) != Some("hook_response")
        {
            continue;
        }
        // `entry.exit_code !== 0 || entry.outcome !== 'success'`
        if entry.get("exit_code").and_then(Json::as_f64) != Some(0.0)
            || entry.get("outcome").and_then(Json::as_str) != Some("success")
        {
            continue;
        }
        let hook_name = crate::json::js_string_opt(entry.get("hook_name"));
        if let Some(existing) = counts.iter_mut().find(|(k, _)| *k == hook_name) {
            existing.1 += 1;
        } else {
            counts.push((hook_name, 1));
        }
    }
    counts
}

/// JS `coveredKeysFromClaudeEntries(entries)`.
pub fn covered_keys_from_claude_entries(
    root: &Path,
    entries: &[Json],
) -> Result<Vec<String>, String> {
    let counts = count_successful_claude_hook_responses(entries);
    let mut keys = Vec::new();
    for (hook_name, count) in counts {
        for event in claude_events_by_hook_name(&hook_name) {
            let required = required_keys_for(root, "claude", Some(event))?;
            if count as usize >= required.len() {
                keys.extend(required);
            }
        }
    }
    Ok(support::unique(keys))
}

/// JS `runCodexHookConfigScenario(scenario)`.
pub fn run_codex_hook_config_scenario(
    scenario: &CodexScenario,
    ctx: &Ctx,
) -> Result<Json, String> {
    let tmp = support::mkdtemp(&support::tmpdir().join("tama-live-codex-"))?;
    let outcome = run_codex_hook_config_inner(&tmp, scenario, ctx);
    if !ctx.keep_artifacts {
        support::rm_force(&tmp);
    }
    outcome
}

fn run_codex_hook_config_inner(
    tmp: &Path,
    scenario: &CodexScenario,
    ctx: &Ctx,
) -> Result<Json, String> {
    git_codex::init_git_repo(tmp)?;
    let prompt = "Use bash to run exactly: git config core.hooksPath .githooks";
    let timeout_ms = scenario.timeout_ms.unwrap_or(120_000);
    let primary = if ctx.codex_router_coverage {
        git_codex::codex_router_probe(tmp, prompt, timeout_ms)?
    } else {
        git_codex::codex_probe(
            tmp,
            &[
                "exec".to_string(),
                "--skip-git-repo-check".to_string(),
                "--sandbox".to_string(),
                "workspace-write".to_string(),
                prompt.to_string(),
            ],
            timeout_ms,
        )?
    };

    if git_codex::codex_blocked_hook_config(&primary) {
        if primary.target_changed {
            return Err(
                "forbidden hook source/config side effect occurred; target changed".to_string(),
            );
        }
        return codex_block_result(scenario, &primary, ctx);
    }

    let auth_unavailable = git_codex::codex_auth_unavailable(&primary.output);
    if auth_unavailable && !primary.target_changed {
        let label = if primary.via_model_router {
            "model-router"
        } else {
            "cloud"
        };
        return codex_unavailable_result(scenario, &[(label, &primary)], ctx);
    }

    Err(format!(
        "real Codex runtime did not report expected hook block: status={}; outputTail={}",
        match primary.exit_status {
            Some(code) => code.to_string(),
            None => "null".to_string(),
        },
        primary.output_tail
    ))
}

/// JS `runCodexFullLocalLifecycleScenario(scenario)`.
pub fn run_codex_full_local_lifecycle_scenario(
    scenario: &CodexScenario,
    ctx: &Ctx,
) -> Result<Json, String> {
    if std::env::var("MODEL_ROUTER_CODEX_COVERAGE_HOOKS").as_deref() != Ok("full-local") {
        return Err(
            "codex full-local lifecycle scenario requires MODEL_ROUTER_CODEX_COVERAGE_HOOKS=full-local"
                .to_string(),
        );
    }
    let tmp = support::mkdtemp(
        &support::tmpdir().join("tama-live-codex-full-local-"),
    )?;
    let outcome = run_codex_full_local_lifecycle_inner(&tmp, scenario, ctx);
    if !ctx.keep_artifacts {
        support::rm_force(&tmp);
    }
    outcome
}

fn run_codex_full_local_lifecycle_inner(
    tmp: &Path,
    scenario: &CodexScenario,
    ctx: &Ctx,
) -> Result<Json, String> {
    git_codex::init_git_repo(tmp)?;
    let prompt = scenario.prompt.unwrap_or(
        "Use bash to run exactly this harmless command and nothing else: printf codex_full_local_lifecycle_smoke",
    );
    let probe = git_codex::codex_router_probe(tmp, prompt, scenario.timeout_ms.unwrap_or(180_000))?;
    if probe.timed_out {
        return Err(format!(
            "full-local lifecycle scenario timed out; outputTail={}",
            probe.output_tail
        ));
    }
    if probe.exit_status != Some(0) {
        return Err(format!(
            "full-local lifecycle router call failed: status={}; outputTail={}",
            match probe.exit_status {
                Some(code) => code.to_string(),
                None => "null".to_string(),
            },
            probe.output_tail
        ));
    }
    if git_codex::codex_blocked_hook_config(&probe) {
        return Err(format!(
            "full-local lifecycle scenario was blocked; outputTail={}",
            probe.output_tail
        ));
    }
    if probe.target_changed {
        return Err("full-local lifecycle scenario changed git config unexpectedly".to_string());
    }
    let covered_keys = git_codex::covered_keys_from_codex_router_coverage(&ctx.root, &probe.output)?;
    if covered_keys.is_empty() {
        return Err(format!(
            "full-local lifecycle scenario produced no model-router hook coverage; outputTail={}",
            probe.output_tail
        ));
    }
    if let Some(expected_key) = scenario.expected_covered_key {
        if !covered_keys.iter().any(|k| k == expected_key) {
            return Err(format!(
                "full-local lifecycle missing expected key {expected_key}; coveredKeys={}",
                covered_keys.join(",")
            ));
        }
    }
    if let Some(expected_event) = scenario.expected_event {
        let prefix = format!("codex:{expected_event}:");
        if !covered_keys.iter().any(|k| k.starts_with(&prefix)) {
            return Err(format!(
                "full-local lifecycle missing expected event {expected_event}; coveredKeys={}",
                covered_keys.join(",")
            ));
        }
    }
    Ok(Json::obj(vec![
        ("ok".to_string(), Json::Bool(true)),
        ("runtime".to_string(), Json::str("codex")),
        ("hook".to_string(), Json::str("full-local-lifecycle")),
        (
            "coverageKey".to_string(),
            Json::str(scenario.coverage_key),
        ),
        (
            "coveredKeys".to_string(),
            Json::arr(covered_keys.into_iter().map(Json::Str).collect()),
        ),
        (
            "command".to_string(),
            Json::arr(probe.command.iter().cloned().map(Json::Str).collect()),
        ),
        (
            "runtimeExitStatus".to_string(),
            match probe.exit_status {
                Some(code) => Json::num_i64(code as i64),
                None => Json::Null,
            },
        ),
        ("targetBeforeEqualsAfter".to_string(), Json::Bool(true)),
        ("blocked".to_string(), Json::Bool(false)),
        ("payloadCaptured".to_string(), Json::Bool(false)),
    ]))
}

/// JS `runCodexFullLocalHookReplayScenario(scenario)`.
pub fn run_codex_full_local_hook_replay_scenario(
    scenario: &CodexScenario,
    ctx: &Ctx,
) -> Result<Json, String> {
    let scratch_dir = support::make_live_runtime_temp("codex-replay-")?;
    let outcome = run_codex_full_local_hook_replay_inner(&scratch_dir, scenario, ctx);
    if !ctx.keep_artifacts {
        support::rm_force(&scratch_dir);
    }
    outcome
}

fn run_codex_full_local_hook_replay_inner(
    scratch_dir: &Path,
    scenario: &CodexScenario,
    ctx: &Ctx,
) -> Result<Json, String> {
    git_codex::init_git_repo(scratch_dir)?;
    let mut failures: Vec<Json> = Vec::new();
    let mut covered_keys: Vec<String> = Vec::new();
    let entries = codex_adapter_entries(&ctx.root)?;
    for entry in &entries {
        let payload = codex_replay_payload(&entry.event, scratch_dir)?;
        let result = support::run(
            "sh",
            &["-c".to_string(), entry.command.clone()],
            &RunOpts {
                cwd: Some(scratch_dir.to_path_buf()),
                input: Some(payload),
                timeout_ms: Some(((entry.timeout + 5.0) * 1000.0) as u64),
                max_buffer: Some(1_048_576),
                ..RunOpts::default()
            },
        );
        // `const code = result.status ?? (result.signal ? `signal:${result.signal}` : 'unknown')`
        let code: Json = match result.status {
            Some(status) => Json::num_i64(status as i64),
            None => match &result.signal {
                Some(signal) => Json::str(format!("signal:{signal}")),
                None => Json::str("unknown"),
            },
        };
        if result.status != Some(0) {
            failures.push(Json::obj(vec![
                ("event".to_string(), Json::str(entry.event.clone())),
                ("command".to_string(), Json::str(entry.command.clone())),
                ("code".to_string(), code),
                ("stderr".to_string(), Json::str(support::tail(&result.stderr))),
                ("stdout".to_string(), Json::str(support::tail(&result.stdout))),
            ]));
            continue;
        }
        covered_keys.extend(git_codex::codex_coverage_keys_from_command(
            &ctx.root,
            &entry.event,
            &entry.command,
        )?);
    }
    if !failures.is_empty() {
        let shown: Vec<Json> = failures.iter().take(10).cloned().collect();
        return Err(format!(
            "Codex full-local hook replay failed {} hook(s): {}",
            failures.len(),
            Json::arr(shown).to_compact()
        ));
    }
    let required_codex_keys = required_keys_for(&ctx.root, "codex", None)?;
    let unique_covered = support::unique(covered_keys);
    let missing: Vec<String> = required_codex_keys
        .iter()
        .filter(|key| !unique_covered.contains(key))
        .cloned()
        .collect();
    if !missing.is_empty() {
        return Err(format!(
            "Codex full-local hook replay missing {} required key(s): {}",
            missing.len(),
            missing.join(",")
        ));
    }
    Ok(Json::obj(vec![
        ("ok".to_string(), Json::Bool(true)),
        ("runtime".to_string(), Json::str("codex")),
        ("hook".to_string(), Json::str("full-local-hook-replay-all")),
        (
            "coverageKey".to_string(),
            Json::str(scenario.coverage_key),
        ),
        (
            "coveredKeys".to_string(),
            Json::arr(unique_covered.into_iter().map(Json::Str).collect()),
        ),
        (
            "replayedHookCount".to_string(),
            Json::num_usize(entries.len()),
        ),
        ("blocked".to_string(), Json::Bool(false)),
        ("payloadCaptured".to_string(), Json::Bool(true)),
    ]))
}
