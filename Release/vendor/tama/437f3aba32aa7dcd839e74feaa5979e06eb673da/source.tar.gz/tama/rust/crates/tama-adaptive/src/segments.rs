//! Port of `src/adaptive/segments/`: telemetry segment writer and the
//! runner command helpers.

pub mod index;
pub mod runner_command;
