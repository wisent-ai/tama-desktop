//! Port of `src/core/install.mjs`.

use serde::Serialize;
use std::fs;
use std::path::Path;
use std::process::Command;

use crate::{err, Result};

const MANAGED_HEADER: &str = "# tama managed global Git dispatcher";

/// `process.env.HOME ?? ''` unless overridden.
fn home_or_env(home: Option<&str>) -> String {
    home.map(str::to_string)
        .or_else(|| std::env::var("HOME").ok())
        .unwrap_or_default()
}

/// JS `currentGlobalHooksPath(home)`: `git config --global --get core.hooksPath`
/// with `HOME` overridden; `None` on nonzero exit, spawn failure, or empty output.
pub fn current_global_hooks_path(home: Option<&str>) -> Option<String> {
    let home = home_or_env(home);
    let output = Command::new("git")
        .args(["config", "--global", "--get", "core.hooksPath"])
        .env("HOME", &home)
        .output()
        .ok()?;
    if !output.status.success() {
        return None;
    }
    let value = String::from_utf8_lossy(&output.stdout).trim().to_string();
    if value.is_empty() {
        None
    } else {
        Some(value)
    }
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AgentAppTargets {
    pub shared_hooks: String,
    pub codex_hooks: String,
    pub codex_settings: String,
    pub claude_hooks: String,
    pub claude_settings: String,
    pub omp_pre_tool_adapter: String,
    pub kimi_config: String,
}

#[derive(Debug, Clone, Serialize)]
pub struct UnsupportedTargets {
    pub kimi: String,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AgentAppLevel {
    pub level: String,
    pub active_by_archive_alone: bool,
    pub source_root: String,
    pub runtime_targets: AgentAppTargets,
    pub unsupported_targets: UnsupportedTargets,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct EditorTargets {
    pub editor_save_guard: String,
    pub editor_watch: String,
    pub editor_watch_pid: String,
    pub editor_watch_log: String,
    pub launch_agent: String,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct EditorLevel {
    pub level: String,
    pub active_by_archive_alone: bool,
    pub source_root: String,
    pub runtime_targets: EditorTargets,
    pub note: String,
}

#[derive(Debug, Clone, Serialize)]
pub struct McpTargets {
    pub server: String,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct McpLevel {
    pub level: String,
    pub active_by_archive_alone: bool,
    pub runtime_targets: McpTargets,
    pub config_command: String,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct UserGlobalGitLevel {
    pub level: String,
    pub active_by_archive_alone: bool,
    pub current_hooks_path: Option<String>,
    pub config_command: String,
    pub dispatchers: Vec<String>,
    pub install_command: String,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct RepoProjectLevel {
    pub level: String,
    pub active_by_archive_alone: bool,
    pub source_root: String,
    pub managed_projects: Vec<String>,
    pub install_command: String,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct OsLevel {
    pub level: String,
    pub active_by_archive_alone: bool,
    pub note: String,
}

/// The `levels` object; struct field order reproduces JS key insertion order.
#[derive(Debug, Clone, Serialize)]
pub struct Levels {
    #[serde(rename = "agent-app")]
    pub agent_app: AgentAppLevel,
    pub editor: EditorLevel,
    pub mcp: McpLevel,
    #[serde(rename = "user-global-git")]
    pub user_global_git: UserGlobalGitLevel,
    #[serde(rename = "repo-project")]
    pub repo_project: RepoProjectLevel,
    #[serde(rename = "os-level")]
    pub os_level: OsLevel,
}

/// Result of JS `levelPlan(root, hooksPath, home)`.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct LevelPlan {
    pub archive_root: String,
    pub levels: Levels,
}

/// JS `levelPlan(root, hooksPath = null, home = process.env.HOME ?? '')`.
pub fn level_plan(root: &Path, hooks_path: Option<&str>, home: Option<&str>) -> LevelPlan {
    let root_s = root.to_string_lossy().trim_end_matches('/').to_string();
    let home = home_or_env(home);
    let shared_hooks = join_path(&home, ".shared-hooks");
    LevelPlan {
        archive_root: root_s.clone(),
        levels: Levels {
            agent_app: AgentAppLevel {
                level: "agent-app".to_string(),
                active_by_archive_alone: false,
                source_root: root_s.clone(),
                runtime_targets: AgentAppTargets {
                    shared_hooks: shared_hooks.clone(),
                    codex_hooks: join_path(&home, ".codex/hooks"),
                    codex_settings: join_path(&home, ".codex/hooks.json"),
                    claude_hooks: join_path(&home, ".claude/hooks"),
                    claude_settings: join_path(&home, ".claude/settings.json"),
                    omp_pre_tool_adapter: join_path(&home, ".omp/agent/hooks/pre/shared-hooks.js"),
                    kimi_config: join_path(&home, ".kimi-code/config.toml"),
                },
                unsupported_targets: UnsupportedTargets {
                    kimi: "No hook adapter is known in ~/.kimi-code/config.toml; Kimi is only covered indirectly by editor/Git surfaces.".to_string(),
                },
            },
            editor: EditorLevel {
                level: "editor".to_string(),
                active_by_archive_alone: false,
                source_root: join_path(&root_s, "shared-hooks"),
                runtime_targets: EditorTargets {
                    editor_save_guard: join_path(&shared_hooks, "editor-save-guard.mjs"),
                    editor_watch: join_path(&shared_hooks, "editor-watch.mjs"),
                    editor_watch_pid: join_path(&shared_hooks, "editor-hooks.pid"),
                    editor_watch_log: join_path(&shared_hooks, "editor-hooks.log"),
                    launch_agent: join_path(&home, "Library/LaunchAgents/com.wisent.editor-hooks.plist"),
                },
                note: "Editor watch is an adapter surface, not installed by the archive alone; the current catalog marks launchd installed-not-active and session watch report-only.".to_string(),
            },
            mcp: McpLevel {
                level: "mcp".to_string(),
                active_by_archive_alone: false,
                runtime_targets: McpTargets {
                    server: "tama-mcp-server".to_string(),
                },
                config_command: "tama-cli mcp-config".to_string(),
            },
            user_global_git: UserGlobalGitLevel {
                level: "user-global-git".to_string(),
                active_by_archive_alone: false,
                current_hooks_path: hooks_path
                    .map(str::to_string)
                    .or_else(|| current_global_hooks_path(Some(&home))),
                config_command: "git config --global core.hooksPath <hooksPath>".to_string(),
                dispatchers: vec!["pre-commit".to_string(), "pre-push".to_string()],
                install_command: "tama install --git-hooks-path <path>".to_string(),
            },
            repo_project: RepoProjectLevel {
                level: "repo-project-git".to_string(),
                active_by_archive_alone: false,
                source_root: join_path(&root_s, "repo-githooks"),
                managed_projects: vec![
                    "wisent-enterprise".to_string(),
                    "weles".to_string(),
                    "weles-pr-ci-fix".to_string(),
                ],
                install_command: "git config core.hooksPath .githooks".to_string(),
            },
            os_level: OsLevel {
                level: "os-level".to_string(),
                active_by_archive_alone: false,
                note: "Not installed by this tool. Use macOS policy controls for whole-machine enforcement.".to_string(),
            },
        },
    }
}

/// JS `dispatcherBody(root, hookName, backupPath)` — reproduced byte-for-byte.
fn dispatcher_body(root: &str, hook_name: &str, backup_path: &str) -> String {
    let json = |value: &str| serde_json::to_string(value).unwrap_or_else(|_| "\"\"".to_string());
    let repo_hook = format!("${{repo_root}}/.githooks/{hook_name}");
    let mut out = String::new();
    out.push_str("#!/bin/sh\n");
    out.push_str(MANAGED_HEADER);
    out.push('\n');
    out.push_str("set -eu\n");
    out.push_str("ROOT=");
    out.push_str(&json(root));
    out.push('\n');
    out.push_str("HOOK_NAME=");
    out.push_str(&json(hook_name));
    out.push('\n');
    out.push_str("BACKUP=");
    out.push_str(&json(backup_path));
    out.push('\n');
    out.push_str("INPUT_FILE=\"${TMPDIR:-/tmp}/tama-$HOOK_NAME-$$.stdin\"\n");
    out.push_str("cat > \"$INPUT_FILE\"\n");
    out.push_str("trap 'rm -f \"$INPUT_FILE\"' EXIT\n");
    out.push_str("repo_root=\"$(git rev-parse --show-toplevel 2>/dev/null || true)\"\n");
    out.push_str("archive_hook=''\n");
    out.push_str("if [ -n \"$repo_root\" ]; then\n");
    out.push_str("  repo_base=\"$(basename \"$repo_root\")\"\n");
    out.push_str("  archive_hook=\"$ROOT/repo-githooks/$repo_base/$HOOK_NAME\"\n");
    out.push_str("fi\n");
    out.push_str(&format!(
        "if [ -n \"$repo_root\" ] && [ -x \"{repo_hook}\" ]; then\n"
    ));
    out.push_str(&format!("  \"{repo_hook}\" \"$@\" < \"$INPUT_FILE\"\n"));
    out.push_str("elif [ -n \"$archive_hook\" ] && [ -x \"$archive_hook\" ]; then\n");
    out.push_str("  \"$archive_hook\" \"$@\" < \"$INPUT_FILE\"\n");
    out.push_str("fi\n");
    out.push_str("if [ -x \"$BACKUP\" ]; then\n");
    out.push_str("  \"$BACKUP\" \"$@\" < \"$INPUT_FILE\"\n");
    out.push_str("fi\n");
    out.push_str("exit 0\n");
    out
}

/// JS `expandHome(value, home)`.
fn expand_home(value: &str, home: &str) -> String {
    if value.is_empty() {
        return value.to_string();
    }
    if value == "~" {
        return home.to_string();
    }
    if let Some(rest) = value.strip_prefix("~/") {
        return join_path(home, rest);
    }
    value.to_string()
}

/// Node `path.join(base, part)` for the simple cases used here.
fn join_path(base: &str, part: &str) -> String {
    format!("{}/{}", base.trim_end_matches('/'), part)
}

/// Node `path.resolve(value)`: make absolute against the CWD and normalize
/// `.`/`..`/duplicate slashes, without resolving symlinks.
fn resolve_path(value: &str) -> Result<String> {
    let absolute = if value.starts_with('/') {
        value.to_string()
    } else {
        let cwd = std::env::current_dir()?;
        format!("{}/{}", cwd.to_string_lossy().trim_end_matches('/'), value)
    };
    let mut parts: Vec<&str> = Vec::new();
    for segment in absolute.split('/') {
        match segment {
            "" | "." => {}
            ".." => {
                parts.pop();
            }
            segment => parts.push(segment),
        }
    }
    Ok(format!("/{}", parts.join("/")))
}

#[cfg(unix)]
fn chmod_755(path: &str) -> std::io::Result<()> {
    use std::os::unix::fs::PermissionsExt;
    fs::set_permissions(path, fs::Permissions::from_mode(0o755))
}

#[cfg(not(unix))]
fn chmod_755(_path: &str) -> std::io::Result<()> {
    Ok(())
}

/// One installed dispatcher: `{ target, backup }`.
#[derive(Debug, Clone, Serialize)]
pub struct InstalledHook {
    pub target: String,
    pub backup: Option<String>,
}

/// JS `installOne(root, hooksPath, hookName)`: back up a pre-existing
/// non-managed hook, then write the managed dispatcher (mode 0755).
fn install_one(root: &str, hooks_path: &str, hook_name: &str) -> Result<InstalledHook> {
    let target = join_path(hooks_path, hook_name);
    let backup = join_path(hooks_path, &format!("{hook_name}.before-tama"));
    if Path::new(&target).exists() {
        let bytes = fs::read(&target)?;
        let text = String::from_utf8_lossy(&bytes);
        let mut lines = text.split('\n');
        let first = lines.next().unwrap_or("");
        let second = lines.next().unwrap_or("");
        let is_managed = first == "#!/bin/sh" && second == MANAGED_HEADER;
        if !is_managed && !Path::new(&backup).exists() {
            fs::copy(&target, &backup)?;
            chmod_755(&backup)?;
        }
    }
    fs::write(&target, dispatcher_body(root, hook_name, &backup))?;
    chmod_755(&target)?;
    Ok(InstalledHook {
        target,
        backup: if Path::new(&backup).exists() {
            Some(backup)
        } else {
            None
        },
    })
}

/// Options for [`install_global_git`] (JS `options` object).
#[derive(Debug, Clone, Default)]
pub struct InstallOptions {
    pub home: Option<String>,
    pub hooks_path: Option<String>,
    pub set_global_config: bool,
}

/// Result of JS `installGlobalGit(root, options)`.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct InstallResult {
    pub hooks_path: String,
    pub pre_commit: InstalledHook,
    pub pre_push: InstalledHook,
    pub set_global_config: bool,
}

/// JS `installGlobalGit(root, options = {})`.
pub fn install_global_git(root: &Path, options: &InstallOptions) -> Result<InstallResult> {
    let home = options
        .home
        .clone()
        .or_else(|| std::env::var("HOME").ok())
        .unwrap_or_default();
    let target_path = options
        .hooks_path
        .clone()
        .or_else(|| current_global_hooks_path(Some(&home)))
        .unwrap_or_else(|| join_path(&home, ".config/git/hooks"));
    let hooks_path = resolve_path(&expand_home(&target_path, &home))?;
    fs::create_dir_all(&hooks_path)?;
    let root_s = root.to_string_lossy().trim_end_matches('/').to_string();
    let pre_commit = install_one(&root_s, &hooks_path, "pre-commit")?;
    let pre_push = install_one(&root_s, &hooks_path, "pre-push")?;
    if options.set_global_config {
        let output = Command::new("git")
            .args(["config", "--global", "core.hooksPath", &hooks_path])
            .env("HOME", &home)
            .output()?;
        if !output.status.success() {
            let stderr = String::from_utf8_lossy(&output.stderr).trim().to_string();
            return Err(err(if stderr.is_empty() {
                "git config failed".to_string()
            } else {
                stderr
            }));
        }
    }
    Ok(InstallResult {
        hooks_path,
        pre_commit,
        pre_push,
        set_global_config: options.set_global_config,
    })
}
