//! Shared registry helpers ported from `generate-configs.mjs`,
//! `run-one-session-hook.js` and `omp-shared-hooks.js`.

use crate::util::{js_number_to_string, js_string_or_empty, js_truthy, sha256_hex};
use serde_json::{json, Map, Value};
use std::path::Path;

/// One Codex/Claude target for a registry event.
#[derive(Debug, Clone, Copy)]
pub struct EventTarget {
    pub key: &'static str,
    pub matcher: Option<&'static str>,
}

/// `EVENT_TO_CODEX` from generate-configs.mjs.
pub fn event_to_codex(event: &str) -> Option<EventTarget> {
    let (key, matcher) = match event {
        "stop" => ("Stop", None),
        "user_prompt_submit" => ("UserPromptSubmit", None),
        "post_tool_use:bash" => ("PostToolUse", Some("Bash")),
        "session_start:compact" => ("SessionStart", Some("compact")),
        "pre_tool_use:bash" => ("PreToolUse", Some("Bash")),
        "pre_tool_use:read" => ("PreToolUse", Some("Read")),
        "pre_tool_use:edit" => ("PreToolUse", Some("apply_patch|Edit|Write")),
        "pre_tool_use:task" => ("PreToolUse", Some("Task|Agent")),
        "pre_tool_use:todo" => ("PreToolUse", Some("Todo|todo")),
        "pre_tool_use:goal" => ("PreToolUse", Some("Goal|goal")),
        "pre_tool_use:lookup" => {
            ("PreToolUse", Some("Grep|grep|Glob|glob|Search|LSP|lsp|AstGrep|ast_grep"))
        }
        "pre_tool_use:notebook" => ("PreToolUse", Some("NotebookEdit")),
        "pre_tool_use:wait" => ("PreToolUse", Some("Monitor|ScheduleWakeup")),
        "pre_tool_use:eval" => (
            "PreToolUse",
            Some("Eval|eval|execute_code|mcp__node_repl_js|node_repl/js"),
        ),
        "pre_tool_use:ssh" => ("PreToolUse", Some("SSH|ssh")),
        _ => return None,
    };
    Some(EventTarget { key, matcher })
}

/// `EVENT_MAP` from run-one-session-hook.js (adds write/multiedit).
pub fn event_map_one_session(event: &str) -> Option<EventTarget> {
    match event {
        "pre_tool_use:write" => Some(EventTarget {
            key: "PreToolUse",
            matcher: Some("apply_patch|Edit|Write"),
        }),
        "pre_tool_use:multiedit" => Some(EventTarget {
            key: "PreToolUse",
            matcher: Some("MultiEdit"),
        }),
        _ => event_to_codex(event),
    }
}

/// `stableValue` + `registryChecksum`: sha256 over the compact JSON of the
/// registry with `catalogChecksum` removed and object keys sorted.
/// (serde_json maps are BTreeMaps, so keys are already sorted.)
pub fn registry_checksum(registry: &Value) -> String {
    let mut value = registry.clone();
    if let Some(obj) = value.as_object_mut() {
        obj.remove("catalogChecksum");
    }
    sha256_hex(serde_json::to_string(&value).unwrap_or_default().as_bytes())
}

/// `assertRegistryIntegrity` from generate-configs.mjs.
pub fn assert_registry_integrity(registry: &Value) -> Result<(), String> {
    let expected = js_string_or_empty(registry.get("catalogChecksum"));
    let actual = registry_checksum(registry);
    if expected.is_empty() || expected != actual {
        return Err(format!(
            "Tama hook registry checksum mismatch: expected {}, actual {}. \
             Refusing to generate configs from an unsealed registry; reinstall a sealed Tama release.",
            if expected.is_empty() { "missing" } else { &expected },
            actual,
        ));
    }
    Ok(())
}

/// `shellQuote` — wraps in single quotes, `'` → `'\''`.
pub fn shell_quote(value: &str) -> String {
    format!("'{}'", value.replace('\'', "'\\''"))
}

/// `hookConfig` from generate-configs.mjs.
pub fn hook_config_generate(event: &str, hook: &Value, provider: &str) -> Value {
    let mut out = Map::new();
    out.insert(
        "type".to_string(),
        hook.get("type").cloned().unwrap_or_else(|| json!("command")),
    );
    let command = [
        "env".to_string(),
        format!("TAMA_PROVIDER={}", shell_quote(provider)),
        format!(
            "TAMA_ONLY_HOOK_ID={}",
            shell_quote(&js_string_or_empty(hook.get("id")))
        ),
        // Deployment: generated configs invoke the native Rust dispatcher
        // instead of `node "$HOME/.shared-hooks/run-hook.mjs"`.
        "\"$HOME/.local/bin/tama-run-hook\"".to_string(),
        shell_quote(event),
        shell_quote(provider),
    ]
    .join(" ");
    out.insert("command".to_string(), json!(command));
    if js_truthy(hook.get("timeout").unwrap_or(&Value::Null)) {
        out.insert("timeout".to_string(), hook.get("timeout").cloned().unwrap_or(Value::Null));
    }
    if js_truthy(hook.get("statusMessage").unwrap_or(&Value::Null)) {
        out.insert(
            "statusMessage".to_string(),
            hook.get("statusMessage").cloned().unwrap_or(Value::Null),
        );
    }
    Value::Object(out)
}

/// `hookConfig` from run-one-session-hook.js (separate `node` argv token and
/// a quoted absolute run-hook path).
pub fn hook_config_one_session(event: &str, hook: &Value, provider: &str, run_hook_path: &Path) -> Value {
    let mut out = Map::new();
    out.insert(
        "type".to_string(),
        hook.get("type").cloned().unwrap_or_else(|| json!("command")),
    );
    let command = [
        "env".to_string(),
        format!("TAMA_PROVIDER={}", shell_quote(provider)),
        format!(
            "TAMA_ONLY_HOOK_ID={}",
            shell_quote(&js_string_or_empty(hook.get("id")))
        ),
        "node".to_string(),
        shell_quote(&run_hook_path.display().to_string()),
        shell_quote(event),
        shell_quote(provider),
    ]
    .join(" ");
    out.insert("command".to_string(), json!(command));
    if js_truthy(hook.get("timeout").unwrap_or(&Value::Null)) {
        out.insert("timeout".to_string(), hook.get("timeout").cloned().unwrap_or(Value::Null));
    }
    if js_truthy(hook.get("statusMessage").unwrap_or(&Value::Null)) {
        out.insert(
            "statusMessage".to_string(),
            hook.get("statusMessage").cloned().unwrap_or(Value::Null),
        );
    }
    Value::Object(out)
}

/// `buildHooks` from generate-configs.mjs.
pub fn build_hooks(registry: &Value, provider: &str) -> Map<String, Value> {
    let mut out: Map<String, Value> = Map::new();
    let empty = Map::new();
    let events = registry.get("events").and_then(Value::as_object).unwrap_or(&empty);
    for (event, entry) in events {
        let Some(target) = event_to_codex(event) else { continue };
        let hooks = entry
            .get("hooks")
            .and_then(Value::as_array)
            .cloned()
            .unwrap_or_default();
        let group_hooks: Vec<Value> = hooks
            .iter()
            .map(|hook| hook_config_generate(event, hook, provider))
            .collect();
        let mut group = Map::new();
        group.insert("hooks".to_string(), Value::Array(group_hooks));
        if let Some(matcher) = target.matcher {
            group.insert("matcher".to_string(), json!(matcher));
        }
        out.entry(target.key.to_string())
            .or_insert_with(|| Value::Array(Vec::new()))
            .as_array_mut()
            .expect("hook groups are arrays")
            .push(Value::Object(group));
    }
    out
}

/// One registry hook matched by id, with its event and event entry.
pub struct HookMatch<'a> {
    pub event: &'a str,
    pub entry: &'a Value,
    pub hook: &'a Value,
}

/// `matchingHooks` from run-one-session-hook.js / omp-shared-hooks.js.
pub fn matching_hooks<'a>(registry: &'a Value, hook_id: &str) -> Vec<HookMatch<'a>> {
    let mut matches = Vec::new();
    let Some(events) = registry.get("events").and_then(Value::as_object) else {
        return matches;
    };
    for (event, entry) in events {
        if let Some(hooks) = entry.get("hooks").and_then(Value::as_array) {
            for hook in hooks {
                if js_string_or_empty(hook.get("id")) == hook_id {
                    matches.push(HookMatch { event, entry, hook });
                }
            }
        }
    }
    matches
}

/// `providerHooks` from run-one-session-hook.js.
pub fn provider_hooks(
    registry: &Value,
    hook_id: &str,
    provider: &str,
    run_hook_path: &Path,
) -> Result<Map<String, Value>, String> {
    let mut hooks: Map<String, Value> = Map::new();
    let mut seen: Vec<String> = Vec::new();
    for m in matching_hooks(registry, hook_id) {
        let Some(target) = event_map_one_session(m.event) else { continue };
        let signature = serde_json::to_string(&json!([
            target.key,
            target.matcher.unwrap_or(""),
            m.hook.get("command").cloned().unwrap_or(Value::Null),
        ]))
        .unwrap_or_default();
        if seen.contains(&signature) {
            continue;
        }
        seen.push(signature);
        let mut group = Map::new();
        group.insert(
            "hooks".to_string(),
            Value::Array(vec![hook_config_one_session(m.event, m.hook, provider, run_hook_path)]),
        );
        if let Some(matcher) = target.matcher {
            group.insert("matcher".to_string(), json!(matcher));
        }
        hooks
            .entry(target.key.to_string())
            .or_insert_with(|| Value::Array(Vec::new()))
            .as_array_mut()
            .expect("hook groups are arrays")
            .push(Value::Object(group));
    }
    if hooks.is_empty() {
        return Err(format!("Hook {} has no supported Claude/Codex events.", hook_id));
    }
    Ok(hooks)
}

