//! Payload, quote and transcript primitives shared by the two transport
//! gates: `shared-hooks/block_unauthorized_ssh.py` (hook id
//! `block-unauthorized-ssh`) and `shared-hooks/block_unauthorized_cua.py`
//! (hook id `block-unauthorized-cua`).
//!
//! The two Python sources carry byte-identical copies of `load_payload`,
//! `tool_input`, `strings`, `user_content_contains`,
//! `quote_is_in_current_session` and `DIRECT_CONSENT_RE`. One copy lives here
//! so the ports cannot drift from each other the way the sources could.
//!
//! Python value semantics come from [`crate::ports::pyvalue`]; what is left
//! here is the shape of these two payloads and the transcript scan. The
//! accessors reproduce Python truthiness rather than Rust `Option` presence:
//! `payload.get("tool_input") or payload.get("input")` yields `{}` — a dict,
//! which the caller accepts — when `input` is an empty dict.

use std::path::{Path, PathBuf};
use std::sync::LazyLock;

use regex::Regex;
use serde_json::Value;

use crate::ports::pystr;
use crate::ports::pyvalue;

/// Both hooks read the live transcript root from the same variable, and both
/// treat an empty value as a real (unusable) path, exactly as
/// `os.environ.get(key, default)` does.
const SESSION_ROOT_ENV: &str = "TAMA_OMP_SESSION_ROOT";
const HOME_ENV: &str = "HOME";
const SESSION_ID_KEYS: &[&str] = &["session_id", "sessionId"];
const NAME_KEYS: &[&str] = &["name", "tool_name"];
const INPUT_KEYS: &[&str] = &["tool_input", "input"];
const NESTED_INPUT_KEYS: &[&str] = &["input", "tool_input"];
const TRANSCRIPT_SUFFIX: &str = ".jsonl";
const USER_ROLE: &str = "user";
const CONTENT_KEY: &str = "content";
const ROLE_KEY: &str = "role";
const NESTED_TOOL_KEY: &str = "tool";
const LINE_JOIN: &str = "\n";

/// An uncaught Python exception leaves the interpreter with status 1, which
/// the hook runner reads as a failed — not a blocking — hook.
const EXIT_CRASH_TEXT: &str = "1";

/// `DIRECT_CONSENT_RE`, identical in both Python sources: an explicit Polish
/// or English grant. `re.I` becomes the inline `(?i)` flag.
const DIRECT_CONSENT: &str = concat!(
    "(?i)\\b(?:zgadzam\\s+si[eę]|wyra[zż]am\\s+zgod[eę]|pozwalam(?:\\s+ci)?|",
    "zezwalam(?:\\s+ci)?|autoryzuj[eę]|upowa[zż]niam|masz\\s+moj[aą]\\s+zgod[eę]|",
    "mo[zż]esz\\s+u[zż]y[cć]|i\\s+consent|i\\s+authorize|i\\s+allow|",
    "you\\s+have\\s+my\\s+permission|you\\s+may\\s+use)\\b",
);

pub static DIRECT_CONSENT_RE: LazyLock<Regex> = LazyLock::new(|| compile(DIRECT_CONSENT));

/// `re.compile`. A ported pattern is a constant, so a compile failure is a
/// porting defect and not a runtime condition.
pub fn compile(pattern: &str) -> Regex {
    Regex::new(pattern).expect("ported hook pattern must compile")
}

/// Mirror of an uncaught Python exception: a line on stderr and status 1.
pub fn python_crash(message: &str) -> ! {
    eprintln!("{message}");
    std::process::exit(EXIT_CRASH_TEXT.parse().unwrap_or_default())
}

/// `load_payload`: stdin as JSON, with anything that is not an object
/// replaced by an empty object.
pub fn payload() -> Value {
    let value = tama_hooks::session_record::read_payload();
    match value {
        Value::Object(_) => value,
        _ => Value::Object(Default::default()),
    }
}

/// `value.get(a) or value.get(b) or ...`: the first truthy operand, else the
/// last operand evaluated (`None` when every key is absent).
///
/// [`pyvalue::first_truthy_py_str`] covers the `str(a or b or "")` chains;
/// this one keeps the value, which `tool_input` needs because Python accepts
/// the empty dict that ends a falsy chain.
pub fn or_chain(value: &Value, keys: &[&str]) -> Value {
    let mut last = Value::Null;
    for key in keys {
        last = value.get(key).cloned().unwrap_or(Value::Null);
        if pyvalue::truthy(&last) {
            break;
        }
    }
    last
}

/// `tool_name`: the key order differs between the two hooks, so the caller
/// supplies it. A dict value is unwrapped through `name` then `tool_name`.
pub fn tool_name(payload: &Value, keys: &[&str]) -> String {
    let picked = or_chain(payload, keys);
    let value = match &picked {
        Value::Object(_) => or_chain(&picked, NAME_KEYS),
        _ => picked,
    };
    match pyvalue::truthy(&value) {
        true => pyvalue::py_str(&value),
        false => String::new(),
    }
}

/// `tool_input`: the payload's own input object, else the one nested under
/// `tool`, else `{}`.
pub fn tool_input(payload: &Value) -> Value {
    let value = or_chain(payload, INPUT_KEYS);
    if value.is_object() {
        return value;
    }
    if let Some(nested) = payload.get(NESTED_TOOL_KEY) {
        if nested.is_object() {
            let inner = or_chain(nested, NESTED_INPUT_KEYS);
            if inner.is_object() {
                return inner;
            }
        }
    }
    Value::Object(Default::default())
}

/// `strings`: every string in a JSON tree, in document order.
///
/// Deviation: `serde_json` without `preserve_order` sorts object keys, so
/// strings drawn from sibling keys arrive in key order rather than in the
/// payload's own order. Only the joined text handed to a search regex is
/// affected, and only when two keys would each yield a match.
pub fn strings(value: &Value) -> Vec<String> {
    let mut found = Vec::new();
    collect_strings(value, &mut found);
    found
}

fn collect_strings(value: &Value, found: &mut Vec<String>) {
    match value {
        Value::String(text) => found.push(text.clone()),
        Value::Object(map) => map.values().for_each(|item| collect_strings(item, found)),
        Value::Array(items) => items.iter().for_each(|item| collect_strings(item, found)),
        _ => {}
    }
}

/// `user_content_contains`: the quote appears in the joined content of a
/// `role == "user"` object anywhere in the tree.
pub fn user_content_contains(value: &Value, quote: &str) -> bool {
    match value {
        Value::Object(map) => {
            if map.get(ROLE_KEY).and_then(Value::as_str) == Some(USER_ROLE) {
                let content = map.get(CONTENT_KEY).cloned().unwrap_or(Value::Null);
                if strings(&content).join(LINE_JOIN).contains(quote) {
                    return true;
                }
            }
            map.values().any(|item| user_content_contains(item, quote))
        }
        Value::Array(items) => items.iter().any(|item| user_content_contains(item, quote)),
        _ => false,
    }
}

/// `quote_is_in_current_session`: the verbatim quote was really said by the
/// user in this session. Every transcript whose file name carries the session
/// id is scanned in full, one JSON object per line.
pub fn quote_is_in_current_session(session_id: &str, quote: &str) -> bool {
    let root = session_root();
    if session_id.is_empty() || quote.is_empty() || !root.is_dir() {
        return false;
    }
    for path in transcripts(&root, session_id) {
        let raw = match std::fs::read(&path) {
            Ok(bytes) => bytes,
            Err(_) => continue,
        };
        let text = String::from_utf8_lossy(&raw);
        for line in pystr::splitlines(&text) {
            let value: Value = match serde_json::from_str(line) {
                Ok(value) => value,
                Err(_) => continue,
            };
            if user_content_contains(&value, quote) {
                return true;
            }
        }
    }
    false
}

/// `SESSION_ROOT.rglob(f"*{session_id}*.jsonl")`. `Path.rglob` descends into
/// real directories only, never into a symlinked one.
fn transcripts(root: &Path, session_id: &str) -> Vec<PathBuf> {
    let mut found = Vec::new();
    let mut pending = vec![root.to_path_buf()];
    while let Some(directory) = pending.pop() {
        let entries = match std::fs::read_dir(&directory) {
            Ok(entries) => entries,
            Err(_) => continue,
        };
        for entry in entries.flatten() {
            let path = entry.path();
            if entry.file_type().map(|kind| kind.is_dir()).unwrap_or(false) {
                pending.push(path);
                continue;
            }
            let name = path.file_name().and_then(|item| item.to_str()).unwrap_or_default();
            if name.contains(session_id) && name.ends_with(TRANSCRIPT_SUFFIX) {
                found.push(path);
            }
        }
    }
    found
}

pub fn session_root() -> PathBuf {
    env_path(SESSION_ROOT_ENV, home().join(".omp").join("agent").join("sessions"))
}

/// `os.environ.get(key, default)`: an empty value is a value, not a fallback.
pub fn env_path(key: &str, default: PathBuf) -> PathBuf {
    match std::env::var(key) {
        Ok(text) => PathBuf::from(text),
        Err(_) => default,
    }
}

pub fn home() -> PathBuf {
    std::env::var(HOME_ENV).map(PathBuf::from).unwrap_or_default()
}

/// `str(payload.get("session_id") or payload.get("sessionId") or "")`.
pub fn session_id_of(payload: &Value) -> String {
    pyvalue::first_truthy_py_str(payload, SESSION_ID_KEYS)
}

/// `json.loads(path.read_text())` with `OSError` and `JSONDecodeError` folded
/// into `None`. A file that is not valid UTF-8 raises `UnicodeDecodeError`,
/// which neither hook catches, so it crashes the process instead.
pub fn read_registry(path: &Path) -> Option<Value> {
    let raw = std::fs::read(path).ok()?;
    let text = match String::from_utf8(raw) {
        Ok(text) => text,
        Err(_) => python_crash("UnicodeDecodeError: registry is not valid UTF-8"),
    };
    serde_json::from_str(&text).ok()
}
