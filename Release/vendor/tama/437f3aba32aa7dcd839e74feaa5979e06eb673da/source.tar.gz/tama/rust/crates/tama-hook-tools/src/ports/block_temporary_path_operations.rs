//! Port of `shared-hooks/block_temporary_path_operations.py` (registry hook
//! `block-temporary-path-operations`).
//!
//! Refuses a read, edit, write, notebook change or save whose target lands in a
//! temporary directory. A path is judged three ways — as written, resolved
//! against the process directory, and with symlinks resolved — because `/tmp`
//! is a symlink into `/private/tmp` on this platform and either spelling has to
//! be caught.
//!
//! Translation notes: `re.IGNORECASE` is not used here, but Python's
//! non-multiline `$` accepts a single trailing newline, so each `$` is written
//! `\n?\z`. `str.casefold` has no std equivalent; `to_lowercase` stands in, and
//! the two differ only for characters that the `[^a-z]` filter drops anyway.

use std::collections::BTreeSet;

use regex::Regex;
use serde_json::Value;
use tama_hooks::session_record::{deny_tool_use, read_payload};

use super::pystr;
use super::pyvalue::truthy;
use super::python_stdlib::{
    abspath, commonpath, expanduser, expandvars, normpath, realpath, unquote, urlsplit_parts,
};

const PATH_KEYS: &[&str] = &[
    "path",
    "filepath",
    "notebookpath",
    "savepath",
    "outputpath",
    "targetpath",
    "destination",
    "filename",
];
const PATCH_KEYS: &[&str] = &["input", "patch"];
const COLLECTION_KEYS: &[&str] = &["edits", "files", "targets", "operations"];
const PATCH_PATTERNS: &[&str] = &[
    r"^\[(?P<target>[^#\]\n]+)#[0-9A-Fa-f]+\]\n?\z",
    r"^\*\*\* (?:Add|Update|Delete) File: (?P<target>.+)\n?\z",
    r"^(?:---|\+\+\+) [ab]/(?P<target>.+)\n?\z",
];
const FIXED_TEMP_ROOTS: &[&str] = &[
    "/tmp",
    "/private/tmp",
    "/var/tmp",
    "/private/var/tmp",
    "/var/folders",
    "/private/var/folders",
];
const TOOL_INPUT_KEYS: &[&str] = &["tool_input", "input"];
const TARGET_GROUP: &str = "target";
const TMPDIR_ENV: &str = "TMPDIR";
const FILE_SCHEME: &str = "file";
const LOCALHOST: &str = "localhost";
/// Any path component spelled `tmp` marks the path temporary, wherever it sits.
const TMP_PART: &str = "tmp";
/// An embedded NUL cannot reach the filesystem, so such a path is not judged.
const NUL: char = '\0';

/// `re.sub(r"[^a-z]", "", str(key).casefold())`.
fn normalized_key(key: &str) -> String {
    key.to_lowercase()
        .chars()
        .filter(char::is_ascii_lowercase)
        .collect()
}

fn patch_paths(patterns: &[Regex], text: &str, found: &mut Vec<String>) {
    for raw_line in pystr::splitlines(text) {
        let line = pystr::strip(raw_line);
        for pattern in patterns {
            let Some(caps) = pattern.captures(line) else {
                continue;
            };
            if let Some(target) = caps.name(TARGET_GROUP) {
                found.push(pystr::strip(target.as_str()).to_string());
            }
            break;
        }
    }
}

/// The `if / elif / elif` chain of the Python, kept in that order: a key that
/// names a path wins over one that names a patch, and anything else is only
/// descended into when the key names a collection or the value is one.
fn candidate_paths(patterns: &[Regex], value: &Value, found: &mut Vec<String>) {
    match value {
        Value::Object(map) => {
            for (key, item) in map {
                let name = normalized_key(key);
                let name = name.as_str();
                match item.as_str() {
                    Some(text) if PATH_KEYS.contains(&name) => found.push(text.to_string()),
                    Some(text) if PATCH_KEYS.contains(&name) => {
                        patch_paths(patterns, text, found)
                    }
                    _ if COLLECTION_KEYS.contains(&name) || item.is_object() || item.is_array() => {
                        candidate_paths(patterns, item, found)
                    }
                    _ => {}
                }
            }
        }
        Value::Array(items) => {
            for item in items {
                candidate_paths(patterns, item, found);
            }
        }
        _ => {}
    }
}

/// A local path, or `None` for a URL that does not name one.
fn filesystem_path(path: &str) -> Option<String> {
    let (scheme, netloc, parsed) = urlsplit_parts(path);
    if scheme.is_empty() {
        return Some(path.to_string());
    }
    if scheme != FILE_SCHEME || !(netloc.is_empty() || netloc == LOCALHOST) {
        return None;
    }
    Some(unquote(&parsed))
}

/// The three spellings of one path the guard checks: as written, made absolute,
/// and with symlinks resolved.
fn normalized_paths(path: &str) -> Vec<String> {
    let Some(local) = filesystem_path(path) else {
        return Vec::new();
    };
    if local.is_empty() || local.contains(NUL) {
        return Vec::new();
    }
    let expanded = expandvars(&expanduser(&local));
    let absolute = abspath(&expanded);
    vec![
        expanded.replace('\\', "/"),
        normpath(&absolute),
        realpath(&absolute),
    ]
}

fn roots() -> Vec<String> {
    let mut values: Vec<String> = FIXED_TEMP_ROOTS.iter().map(|root| root.to_string()).collect();
    if let Ok(configured) = std::env::var(TMPDIR_ENV) {
        if !configured.is_empty() {
            values.extend(normalized_paths(&configured));
        }
    }
    let mut out: Vec<String> = Vec::new();
    for value in values {
        if value.is_empty() {
            continue;
        }
        let normalized = normpath(&value);
        if !out.contains(&normalized) {
            out.push(normalized);
        }
    }
    out
}

/// `os.path.commonpath((path, root)) == root`, with the `ValueError` raised on
/// a mixed absolute/relative pair meaning "not under".
fn under(path: &str, root: &str) -> bool {
    commonpath(path, root).is_some_and(|common| common == root)
}

fn temporary(path: &str, temp_roots: &[String]) -> bool {
    for candidate in normalized_paths(path) {
        let posix = candidate.replace('\\', "/");
        let named_tmp = posix
            .split('/')
            .filter(|part| !part.is_empty() && *part != ".")
            .any(|part| part.to_lowercase() == TMP_PART);
        if named_tmp {
            return true;
        }
        let normalized = normpath(&candidate);
        if temp_roots.iter().any(|root| under(&normalized, root)) {
            return true;
        }
    }
    false
}

pub fn run() {
    let payload = read_payload();
    let tool_input = TOOL_INPUT_KEYS
        .iter()
        .filter_map(|key| payload.get(key))
        .find(|value| truthy(value))
        .cloned()
        .unwrap_or_else(|| Value::Object(Default::default()));

    let patterns: Vec<Regex> = PATCH_PATTERNS
        .iter()
        .map(|source| Regex::new(source).expect(source))
        .collect();
    let mut candidates: Vec<String> = Vec::new();
    candidate_paths(&patterns, &tool_input, &mut candidates);

    let temp_roots = roots();
    let blocked: BTreeSet<String> = candidates
        .into_iter()
        .filter(|path| temporary(path, &temp_roots))
        .collect();
    if blocked.is_empty() {
        return;
    }
    let listed = blocked.into_iter().collect::<Vec<_>>().join(" | ");
    deny_tool_use(&format!(
        "BLOCKED: Temporary-path Read/Edit/Write/Save operations are not allowed: {listed}"
    ));
}
