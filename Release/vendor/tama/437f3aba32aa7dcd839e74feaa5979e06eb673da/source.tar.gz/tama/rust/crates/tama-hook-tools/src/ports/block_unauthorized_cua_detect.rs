//! Detection half of the `shared-hooks/block_unauthorized_cua.py` port (hook
//! id `block-unauthorized-cua`): the patterns, `cua_action` and
//! `is_cua_operation`. Split from
//! [`crate::ports::block_unauthorized_cua`] to stay inside the 300-line limit.
//!
//! Python `re.I` becomes the inline `(?i)` flag. No pattern here needs
//! lookaround, so every pattern text is the Python text.

use std::sync::LazyLock;

use regex::Regex;
use serde_json::Value;

use crate::ports::pyvalue;
use crate::ports::transport_common as common;

/// `tool_name` reads these keys in this order here; the SSH hook uses a
/// different order, which is why the order is a parameter.
const TOOL_KEYS: &[&str] = &["tool_name", "tool", "name"];
const OP_KEYS: &[&str] = &["op"];
const EXECUTABLE_TOOLS: &[&str] =
    &["bash", "functions.bash", "eval", "functions.eval", "mcp__node_repl_js"];
const HUB_TOOLS: &[&str] = &["hub", "functions.hub"];
const WRITE_TOOLS: &[&str] = &["write", "functions.write"];
const NODE_REPL_DEVICE: &str = "xd://mcp__node_repl_js";
const START_OP: &str = "start";
pub const PATH_KEY: &str = "path";

/// Every pattern here carries exactly one capture group: the action name.
const ACTION_GROUP_TEXT: &str = "1";

pub fn action_group() -> usize {
    ACTION_GROUP_TEXT.parse().unwrap_or_default()
}

/// `CUA_TOOL_RE`. Python's `$` also matches before one trailing newline and
/// the sibling branch `[._-]` cannot, so the alternative is spelled `\n?\z`.
static CUA_TOOL_RE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile("(?i)(?:^|[._-])(?:cua|computer[ _-]?use)(?:[._-]|\\n?\\z)")
});
static CUA_CLI_RE: LazyLock<Regex> =
    LazyLock::new(|| common::compile("(?i)(?:^|[/\\s;&|])cua-driver\\s+([a-z][a-z0-9_-]*)"));
/// `CUA_DIRECT_TOOL_ACTION_RE`, with the same trailing-newline spelling. The
/// capture is unaffected: `[a-z0-9_-]*` is greedy and cannot match `\n`, so
/// the newline always falls to `\n?`.
static CUA_DIRECT_TOOL_ACTION_RE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile("(?i)(?:cua|computer[ _-]?use).*?__([a-z][a-z0-9_-]*)\\n?\\z")
});
pub static CUA_QUOTE_RE: LazyLock<Regex> =
    LazyLock::new(|| common::compile("(?i)\\b(?:cua(?:-driver)?|computer[ _-]?use)\\b"));
pub static PID_RE: LazyLock<Regex> =
    LazyLock::new(|| common::compile("(?:\"pid\"\\s*:\\s*|--pid(?:=|\\s+))(\\d+)"));

/// `DIRECT_IMPERATIVE_RE`: the CUA verb list, which differs from the SSH one.
pub static DIRECT_IMPERATIVE_RE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(?i)^\\s*(?:(?:prosz[eę]|please)\\s+)?",
        "(?:u[zż]yj|uruchom|otw[oó]rz|steruj|sprawd[zź]|kliknij|wpisz|",
        "use|enable|open|drive|inspect|click|type)\\b",
    ))
});

/// `re.match(r"^xd://(?:mcp__)?(?:cua|computer[ _-]?use)", path, re.I)`:
/// `re.match` anchors at the start only, which `\A` states explicitly.
static XD_CUA_PATH_RE: LazyLock<Regex> =
    LazyLock::new(|| common::compile("(?i)\\Axd://(?:mcp__)?(?:cua|computer[ _-]?use)"));

pub fn tool_name(payload: &Value) -> String {
    common::tool_name(payload, TOOL_KEYS)
}

/// `match.group(1).replace("-", "_").lower()`.
fn captured_action(pattern: &Regex, text: &str) -> Option<String> {
    let captured = pattern.captures(text)?.get(action_group())?;
    Some(captured.as_str().replace('-', "_").to_lowercase())
}

/// `cua_action`: the action this call would drive — from the tool name, from
/// a device path, or from a `cua-driver <action>` command line.
pub fn cua_action(payload: &Value) -> Option<String> {
    let name = tool_name(payload);
    if let Some(action) = captured_action(&CUA_DIRECT_TOOL_ACTION_RE, &name) {
        return Some(action);
    }
    let input = common::tool_input(payload);
    if let Some(Value::String(path)) = input.get(PATH_KEY) {
        if let Some(action) = captured_action(&CUA_DIRECT_TOOL_ACTION_RE, path) {
            return Some(action);
        }
    }
    let text = common::strings(&input).join("\n");
    captured_action(&CUA_CLI_RE, &format!(" {text}"))
}

/// `is_cua_operation`: a direct CUA tool, a CUA device path, or an execution
/// payload carrying a `cua-driver` command line.
pub fn is_cua_operation(payload: &Value) -> bool {
    let name = tool_name(payload);
    if CUA_TOOL_RE.is_match(&name) {
        return true;
    }
    let input = common::tool_input(payload);
    let path = input.get(PATH_KEY).and_then(Value::as_str);
    if let Some(text) = path {
        if XD_CUA_PATH_RE.is_match(text) {
            return true;
        }
    }
    let lowered = name.to_lowercase();
    let named = lowered.as_str();
    let executable_payload = EXECUTABLE_TOOLS.contains(&named)
        || (HUB_TOOLS.contains(&named)
            && pyvalue::first_truthy_py_str(&input, OP_KEYS).to_lowercase() == START_OP)
        || (WRITE_TOOLS.contains(&named)
            && path.map(|text| text.to_lowercase().starts_with(NODE_REPL_DEVICE)).unwrap_or(false));
    executable_payload && CUA_CLI_RE.is_match(&format!(" {}", common::strings(&input).join(" ")))
}
