//! tama-mcp-server: MCP server over stdio (newline-delimited JSON-RPC).
//! Rust port of `src/core/server/mcp-server.mjs`.
//!
//! The JS original uses `@modelcontextprotocol/sdk` (v1.29.0 installed); this
//! port reimplements the observable protocol with std only:
//! - Framing: one JSON-RPC message per line (`JSON.stringify(message) + '\n'`),
//!   a single trailing `\r` is stripped from each inbound line.
//! - Envelope: a message is dispatched as a request only when it matches the
//!   SDK's strict `JSONRPCRequestSchema` ({jsonrpc:"2.0", id: string|int,
//!   method: string, params?: object with object `_meta`}). Everything else —
//!   invalid JSON, invalid envelopes, notifications, responses — is silently
//!   ignored (the SDK routes those to `onerror`, which the JS server never
//!   sets, and notifications produce no output).
//! - Known methods: `initialize`, `ping`, `tools/list`, `tools/call`.
//!   Unknown methods get `-32601 "Method not found"`. There is no
//!   initialization gating (SDK 1.29 answers `tools/list` before `initialize`).
//! - Schema-validation failures inside a known method get `-32603` with the
//!   zod v4 issue list (`JSON.stringify(issues, null, 2)`), reproduced for the
//!   fields these schemas actually require.
//! - Tool handler errors get `-32603` with the thrown message.
//!
//! Response key order mirrors the SDK: success `{result, jsonrpc, id}`,
//! error `{jsonrpc, id, error:{code, message}}`.
//!
//! Documented deviations (all outside the happy path):
//! - When many pipelined requests arrive in one stdin chunk, the JS event loop
//!   can answer cheap error responses before slower successful ones; this port
//!   answers strictly in order (identical to JS when requests arrive
//!   interactively or all succeed).
//! - Nested zod validation inside `capabilities`, `clientInfo.icons` and
//!   `params.task` is not reproduced (object-level checks only).
//! - Error texts originating from the OS/JSON parser (corrupt registry.json,
//!   unreadable catalog files) come from Rust/serde and differ from Node's
//!   `SyntaxError`/`ENOENT` wording, except `read_hook_source`'s ENOENT which
//!   is reproduced literally.
//! - The JS scan replays hooks through an 8-lane async pool; this port runs
//!   them sequentially. `violations` is sorted before returning, so only the
//!   (already nondeterministic in JS) `errors` ordering can differ.

use serde::Serialize;
use serde_json::Value;
use std::collections::{HashMap, HashSet};
use std::io::{Read, Write};
use std::path::{Component, Path, PathBuf};
use std::process::{Command, Stdio};

use tama_core::catalog::{build_catalog, find_hook, repo_root, validate_catalog};

const LATEST_PROTOCOL_VERSION: &str = "2025-11-25";
const SUPPORTED_PROTOCOL_VERSIONS: [&str; 5] = [
    "2025-11-25",
    "2025-06-18",
    "2025-03-26",
    "2024-11-05",
    "2024-10-07",
];

const ERR_METHOD_NOT_FOUND: i32 = -32601;
const ERR_INTERNAL: i32 = -32603;

/// Exact `tools/list` result payload (key order from `mcp-server.mjs`).
const TOOLS_LIST_JSON: &str = concat!(
    r#"{"tools":["#,
    r#"{"name":"list_hooks","description":"List archived hook catalog entries.","inputSchema":{"type":"object","properties":{"blockingOnly":{"type":"boolean"}}}},"#,
    r#"{"name":"show_hook","description":"Show one hook by id, including command, source path, and events.","inputSchema":{"type":"object","properties":{"id":{"type":"string"}},"required":["id"]}},"#,
    r#"{"name":"read_hook_source","description":"Read an archived hook source file by hook id.","inputSchema":{"type":"object","properties":{"id":{"type":"string"}},"required":["id"]}},"#,
    r#"{"name":"validate_hooks","description":"Validate hook catalog consistency and secret-scan archived sources.","inputSchema":{"type":"object","properties":{}}},"#,
    r#"{"name":"find_violations","description":"Scan a repository for existing violations of the hook content rules (max 300 lines per file, max 5 files per folder, forbidden content patterns, unsubstantiated constants) by replaying the real pre-write hook against every enumerated file. Read-only; honors .tama-violations-ignore and vendored/build-output exclusions.","inputSchema":{"type":"object","properties":{"repo":{"type":"string","description":"Absolute path to the repository to scan"},"hookPath":{"type":"string","description":"Optional pre-write hook script path override"}},"required":["repo"]}}"#,
    r#"]}"#,
);

fn main() {
    let root = repo_root();
    let stdin = std::io::stdin();
    let mut input = stdin.lock();
    let mut buffer: Vec<u8> = Vec::new();
    let mut chunk = [0u8; 8192];
    loop {
        match input.read(&mut chunk) {
            Ok(0) => break, // EOF: a trailing partial line is dropped, like the JS ReadBuffer
            Ok(n) => {
                buffer.extend_from_slice(&chunk[..n]);
                while let Some(pos) = buffer.iter().position(|byte| *byte == b'\n') {
                    let line: Vec<u8> = buffer.drain(..=pos).collect();
                    let mut text = String::from_utf8_lossy(&line[..line.len() - 1]).into_owned();
                    if text.ends_with('\r') {
                        text.pop();
                    }
                    process_line(&root, &text);
                }
            }
            Err(_) => break,
        }
    }
}

// ---------------------------------------------------------------------------
// JSON-RPC / MCP protocol
// ---------------------------------------------------------------------------

enum Outcome {
    /// Pre-serialized `result` payload.
    Result(String),
    /// `(code, message)` error pair.
    Error(i32, String),
}

fn process_line(root: &Path, line: &str) {
    let value: Value = match serde_json::from_str(line) {
        Ok(value) => value,
        Err(_) => return, // JS: JSON.parse failure -> onerror -> silent
    };
    let (id, method, params) = match as_request(&value) {
        Some(request) => request,
        None => return, // notifications, responses, invalid envelopes: silent
    };
    match dispatch(root, &method, params.as_ref()) {
        Outcome::Result(result) => emit(&format!(
            "{{\"result\":{},\"jsonrpc\":\"2.0\",\"id\":{}}}",
            result,
            render_id(&id)
        )),
        Outcome::Error(code, message) => emit(&format!(
            "{{\"jsonrpc\":\"2.0\",\"id\":{},\"error\":{{\"code\":{},\"message\":{}}}}}",
            render_id(&id),
            code,
            serde_json::to_string(&message).unwrap_or_else(|_| "\"Internal error\"".to_string())
        )),
    }
}

/// SDK `JSONRPCRequestSchema` (strict): exactly the keys
/// {jsonrpc, id, method, params}, `jsonrpc` literally "2.0", `id` a string or
/// integer number, `method` a string, and optional `params` a non-array object
/// whose optional `_meta` is a non-array object.
fn as_request(value: &Value) -> Option<(Value, String, Option<Value>)> {
    let object = value.as_object()?;
    for key in object.keys() {
        if !["jsonrpc", "id", "method", "params"].contains(&key.as_str()) {
            return None;
        }
    }
    if object.get("jsonrpc")?.as_str()? != "2.0" {
        return None;
    }
    let id = object.get("id")?;
    match id {
        Value::String(_) => {}
        Value::Number(number) => {
            // z.number().int(): integral values only (1e21 is an integer in JS).
            let integral = number.as_i64().is_some()
                || number.as_u64().is_some()
                || number.as_f64().map(|f| f.fract() == 0.0).unwrap_or(false);
            if !integral {
                return None;
            }
        }
        _ => return None,
    }
    let method = object.get("method")?.as_str()?.to_string();
    if let Some(params) = object.get("params") {
        let params_obj = params.as_object()?;
        if let Some(meta) = params_obj.get("_meta") {
            meta.as_object()?;
        }
    }
    let params = object.get("params").cloned();
    Some((id.clone(), method, params))
}

fn dispatch(root: &Path, method: &str, params: Option<&Value>) -> Outcome {
    match method {
        "initialize" => {
            let issues = validate_initialize(params);
            if !issues.is_empty() {
                return Outcome::Error(ERR_INTERNAL, issues_json(&issues));
            }
            let requested = params
                .and_then(|p| p.get("protocolVersion"))
                .and_then(|v| v.as_str())
                .unwrap_or("");
            let version = if SUPPORTED_PROTOCOL_VERSIONS.contains(&requested) {
                requested
            } else {
                LATEST_PROTOCOL_VERSION
            };
            Outcome::Result(format!(
                "{{\"protocolVersion\":{},\"capabilities\":{{\"tools\":{{}}}},\"serverInfo\":{{\"name\":\"tama\",\"version\":\"0.1.0\"}}}}",
                serde_json::to_string(version).unwrap_or_else(|_| "\"\"".to_string())
            ))
        }
        // PingRequestSchema imposes nothing beyond the envelope; result is {}.
        "ping" => Outcome::Result("{}".to_string()),
        "tools/list" => {
            let issues = validate_tools_list(params);
            if !issues.is_empty() {
                return Outcome::Error(ERR_INTERNAL, issues_json(&issues));
            }
            Outcome::Result(TOOLS_LIST_JSON.to_string())
        }
        "tools/call" => {
            let issues = validate_call_tool(params);
            if !issues.is_empty() {
                return Outcome::Error(ERR_INTERNAL, issues_json(&issues));
            }
            let params = match params {
                Some(value) => value,
                None => return Outcome::Error(ERR_INTERNAL, "unreachable: params validated".to_string()),
            };
            match call_tool(root, params) {
                Ok(text) => Outcome::Result(format!(
                    "{{\"content\":[{{\"type\":\"text\",\"text\":{}}}]}}",
                    serde_json::to_string(&text).unwrap_or_else(|_| "\"\"".to_string())
                )),
                Err(message) => Outcome::Error(ERR_INTERNAL, message),
            }
        }
        _ => Outcome::Error(ERR_METHOD_NOT_FOUND, "Method not found".to_string()),
    }
}

/// One locked `write_all` + `flush` per message (mirrors the SDK's
/// `process.stdout.write(JSON.stringify(message) + '\n')`).
fn emit(text: &str) {
    let stdout = std::io::stdout();
    let mut out = stdout.lock();
    let _ = out.write_all(text.as_bytes());
    let _ = out.write_all(b"\n");
    let _ = out.flush();
}

/// Echo a request id the way `JSON.stringify` prints it: integral numbers
/// without a fractional part (`5.0` parses to `5` in JS and echoes as `5`).
fn render_id(id: &Value) -> String {
    match id {
        Value::String(text) => serde_json::to_string(text).unwrap_or_else(|_| "\"\"".to_string()),
        Value::Number(number) => {
            if let Some(int) = number.as_i64() {
                return int.to_string();
            }
            if let Some(uint) = number.as_u64() {
                return uint.to_string();
            }
            let float = number.as_f64().unwrap_or(0.0);
            if float.fract() == 0.0 && float.abs() < 1e21 {
                format!("{}", float as i128)
            } else {
                serde_json::to_string(&float).unwrap_or_else(|_| "0".to_string())
            }
        }
        _ => "null".to_string(),
    }
}

// ---------------------------------------------------------------------------
// zod v4 issue emulation (invalid_type only; shapes the schemas require)
// ---------------------------------------------------------------------------

struct Issue {
    expected: &'static str,
    path: Vec<String>,
    received: &'static str,
}

#[derive(Serialize)]
struct IssueJson<'a> {
    expected: &'a str,
    code: &'a str,
    path: &'a [String],
    message: String,
}

/// zod v4's parsed-type names for JSON values (`undefined` when absent).
fn js_type(value: Option<&Value>) -> &'static str {
    match value {
        None => "undefined",
        Some(Value::Null) => "null",
        Some(Value::Bool(_)) => "boolean",
        Some(Value::Number(_)) => "number",
        Some(Value::String(_)) => "string",
        Some(Value::Array(_)) => "array",
        Some(Value::Object(_)) => "object",
    }
}

fn invalid_type(expected: &'static str, path: &[&str], value: Option<&Value>) -> Issue {
    Issue {
        expected,
        path: path.iter().map(|p| p.to_string()).collect(),
        received: js_type(value),
    }
}

/// `JSON.stringify(issues, null, 2)` of zod v4 `invalid_type` issues.
fn issues_json(issues: &[Issue]) -> String {
    let rendered: Vec<IssueJson> = issues
        .iter()
        .map(|issue| IssueJson {
            expected: issue.expected,
            code: "invalid_type",
            path: &issue.path,
            message: format!(
                "Invalid input: expected {}, received {}",
                issue.expected, issue.received
            ),
        })
        .collect();
    serde_json::to_string_pretty(&rendered).unwrap_or_else(|_| "[]".to_string())
}

/// `InitializeRequestParamsSchema`: required `protocolVersion` (string),
/// `capabilities` (object), `clientInfo` (object with string `name`/`version`;
/// optional `title`/`websiteUrl`/`description` strings). Issues in zod's
/// shape-key order.
fn validate_initialize(params: Option<&Value>) -> Vec<Issue> {
    let mut issues = Vec::new();
    let object = match params {
        Some(Value::Object(object)) => object,
        other => {
            issues.push(invalid_type("object", &["params"], other));
            return issues;
        }
    };
    if !matches!(object.get("protocolVersion"), Some(Value::String(_))) {
        issues.push(invalid_type(
            "string",
            &["params", "protocolVersion"],
            object.get("protocolVersion"),
        ));
    }
    if !matches!(object.get("capabilities"), Some(Value::Object(_))) {
        issues.push(invalid_type(
            "object",
            &["params", "capabilities"],
            object.get("capabilities"),
        ));
    }
    match object.get("clientInfo") {
        Some(Value::Object(info)) => {
            if !matches!(info.get("name"), Some(Value::String(_))) {
                issues.push(invalid_type(
                    "string",
                    &["params", "clientInfo", "name"],
                    info.get("name"),
                ));
            }
            if let Some(title) = info.get("title") {
                if !title.is_string() {
                    issues.push(invalid_type(
                        "string",
                        &["params", "clientInfo", "title"],
                        Some(title),
                    ));
                }
            }
            if !matches!(info.get("version"), Some(Value::String(_))) {
                issues.push(invalid_type(
                    "string",
                    &["params", "clientInfo", "version"],
                    info.get("version"),
                ));
            }
            for key in ["websiteUrl", "description"] {
                if let Some(value) = info.get(key) {
                    if !value.is_string() {
                        issues.push(invalid_type(
                            "string",
                            &["params", "clientInfo", key],
                            Some(value),
                        ));
                    }
                }
            }
        }
        other => issues.push(invalid_type("object", &["params", "clientInfo"], other)),
    }
    issues
}

/// `ListToolsRequestSchema` (paginated): optional params, optional string
/// `cursor`. Params is guaranteed an object by the envelope check.
fn validate_tools_list(params: Option<&Value>) -> Vec<Issue> {
    let mut issues = Vec::new();
    if let Some(Value::Object(object)) = params {
        if let Some(cursor) = object.get("cursor") {
            if !cursor.is_string() {
                issues.push(invalid_type("string", &["params", "cursor"], Some(cursor)));
            }
        }
    }
    issues
}

/// `CallToolRequestParamsSchema`: required object params with `name` (string),
/// optional `arguments` (record = non-array object), optional `task` (object).
/// Issues in zod's shape-key order (`task`, `name`, `arguments`).
fn validate_call_tool(params: Option<&Value>) -> Vec<Issue> {
    let mut issues = Vec::new();
    let object = match params {
        Some(Value::Object(object)) => object,
        other => {
            issues.push(invalid_type("object", &["params"], other));
            return issues;
        }
    };
    if let Some(task) = object.get("task") {
        if !task.is_object() {
            issues.push(invalid_type("object", &["params", "task"], Some(task)));
        }
    }
    if !matches!(object.get("name"), Some(Value::String(_))) {
        issues.push(invalid_type("string", &["params", "name"], object.get("name")));
    }
    if let Some(arguments) = object.get("arguments") {
        if !arguments.is_object() {
            issues.push(invalid_type("record", &["params", "arguments"], Some(arguments)));
        }
    }
    issues
}

// ---------------------------------------------------------------------------
// JS value semantics used by the tool handlers
// ---------------------------------------------------------------------------

/// JS truthiness.
fn js_truthy(value: Option<&Value>) -> bool {
    match value {
        None | Some(Value::Null) => false,
        Some(Value::Bool(flag)) => *flag,
        Some(Value::Number(number)) => number
            .as_f64()
            .map(|f| f != 0.0 && !f.is_nan())
            .unwrap_or(false),
        Some(Value::String(text)) => !text.is_empty(),
        Some(Value::Array(_)) | Some(Value::Object(_)) => true,
    }
}

/// JS template-literal interpolation (`${value}`).
fn js_template(value: Option<&Value>) -> String {
    match value {
        None => "undefined".to_string(),
        Some(Value::Null) => "null".to_string(),
        Some(Value::Bool(flag)) => flag.to_string(),
        Some(Value::Number(number)) => js_number_to_string(number),
        Some(Value::String(text)) => text.clone(),
        // Array.prototype.toString: join(','), null/undefined elements empty.
        Some(Value::Array(items)) => items
            .iter()
            .map(|item| match item {
                Value::Null => String::new(),
                other => js_template(Some(other)),
            })
            .collect::<Vec<_>>()
            .join(","),
        Some(Value::Object(_)) => "[object Object]".to_string(),
    }
}

/// `String(number)` for the magnitudes that can appear in arguments.
fn js_number_to_string(number: &serde_json::Number) -> String {
    if let Some(int) = number.as_i64() {
        return int.to_string();
    }
    if let Some(uint) = number.as_u64() {
        return uint.to_string();
    }
    let float = number.as_f64().unwrap_or(f64::NAN);
    if float.is_nan() {
        return "NaN".to_string();
    }
    if float.is_infinite() {
        return if float > 0.0 { "Infinity" } else { "-Infinity" }.to_string();
    }
    if float.fract() == 0.0 && float.abs() < 1e21 {
        return format!("{}", float as i128);
    }
    // Exponential range: Rust `{:e}` matches JS digits; JS adds '+' for
    // positive exponents.
    let rendered = format!("{:e}", float);
    match rendered.split_once('e') {
        Some((mantissa, exponent)) if !exponent.starts_with('-') => {
            format!("{}e+{}", mantissa, exponent)
        }
        _ => rendered,
    }
}

// ---------------------------------------------------------------------------
// tools/call handlers (mcp-server.mjs)
// ---------------------------------------------------------------------------

fn call_tool(root: &Path, params: &Value) -> Result<String, String> {
    let object = params.as_object().ok_or("params is not an object")?;
    let name = object
        .get("name")
        .and_then(|v| v.as_str())
        .ok_or("params.name is not a string")?;
    let args = object.get("arguments").and_then(|v| v.as_object());
    let arg = |key: &str| args.and_then(|a| a.get(key));
    match name {
        "list_hooks" => {
            let catalog = build_catalog(root).map_err(|e| e.to_string())?;
            let hooks = if js_truthy(arg("blockingOnly")) {
                catalog
                    .hooks
                    .into_iter()
                    .filter(|hook| hook.events.iter().any(|ev| ev.blocking))
                    .collect::<Vec<_>>()
            } else {
                catalog.hooks
            };
            let raw_reqs = load_raw_requirements(root);
            let out: Vec<HookOut> = hooks
                .iter()
                .map(|hook| HookOut {
                    hook,
                    raw_reqs: raw_reqs.get(&hook.id).map(Vec::as_slice),
                })
                .collect();
            serde_json::to_string_pretty(&out).map_err(|e| e.to_string())
        }
        "show_hook" => {
            let id = arg("id");
            let hook = match id {
                Some(Value::String(id)) => find_hook(id, root).map_err(|e| e.to_string())?,
                _ => None,
            };
            let hook = hook.ok_or_else(|| format!("hook not found: {}", js_template(id)))?;
            let raw_reqs = load_raw_requirements(root);
            let out = HookOut {
                hook: &hook,
                raw_reqs: raw_reqs.get(&hook.id).map(Vec::as_slice),
            };
            serde_json::to_string_pretty(&out).map_err(|e| e.to_string())
        }
        "read_hook_source" => {
            let id = arg("id");
            let hook = match id {
                Some(Value::String(id)) => find_hook(id, root).map_err(|e| e.to_string())?,
                _ => None,
            };
            let source_path = hook
                .and_then(|h| h.source_path)
                .filter(|p| !p.is_empty())
                .ok_or_else(|| format!("hook source not found: {}", js_template(id)))?;
            let path = root.join(&source_path);
            let bytes = std::fs::read(&path).map_err(|e| {
                if e.kind() == std::io::ErrorKind::NotFound {
                    // Node readFileSync error message, reproduced literally.
                    format!(
                        "ENOENT: no such file or directory, open '{}'",
                        path.to_string_lossy()
                    )
                } else {
                    e.to_string()
                }
            })?;
            Ok(String::from_utf8_lossy(&bytes).into_owned())
        }
        "validate_hooks" => {
            let result = validate_catalog(root).map_err(|e| e.to_string())?;
            serde_json::to_string_pretty(&result).map_err(|e| e.to_string())
        }
        "find_violations" => {
            let repo = arg("repo");
            // JS: `if (!args.repo || !existsSync(args.repo))` — a truthy
            // non-string makes existsSync return false (no throw).
            let exists = match repo {
                Some(Value::String(path)) => !path.is_empty() && Path::new(path).exists(),
                _ => false,
            };
            if !js_truthy(repo) || !exists {
                let shown = match repo {
                    None | Some(Value::Null) => "(missing)".to_string(),
                    other => js_template(other),
                };
                return Err(format!("repo not found: {}", shown));
            }
            let repo = match repo {
                Some(Value::String(path)) => path.clone(),
                _ => unreachable!("repo checked above"),
            };
            let hook_path = match arg("hookPath") {
                Some(Value::String(path)) if !path.is_empty() => path.clone(),
                other if js_truthy(other) => js_template(other),
                _ => root
                    .join("shared-hooks")
                    .join("pre_write_edit.sh")
                    .to_string_lossy()
                    .into_owned(),
            };
            let report = scan_repo(&repo, &hook_path);
            serde_json::to_string_pretty(&report).map_err(|e| e.to_string())
        }
        other => Err(format!("unknown tool: {}", other)),
    }
}

// ---------------------------------------------------------------------------
// Raw justificationRequirements passthrough
//
// JS passes requirement objects from `catalog-metadata.json`/`registry.json`
// through verbatim (source key order, all fields — e.g. `title`). tama-core's
// typed `JustificationRequirement` flattens unknown fields into a BTreeMap,
// which reorders them, so `list_hooks`/`show_hook` re-serialize the
// requirements from the raw source JSON with order preserved. Merge priority
// mirrors buildCatalog: `docs.justificationRequirements ?? hook.justificationRequirements ?? []`
// (evaluated at the hook's first registry occurrence).
// ---------------------------------------------------------------------------

use serde::ser::{SerializeMap, SerializeSeq, SerializeStruct, Serializer};
use tama_core::catalog::CatalogHook;

/// Order-preserving JSON value (the subset needed for registry/metadata
/// files). Numbers are stored as f64 and re-printed the JS way.
#[derive(Debug, Clone)]
enum JVal {
    Null,
    Bool(bool),
    Num(f64),
    Str(String),
    Arr(Vec<JVal>),
    Obj(Vec<(String, JVal)>),
}

impl JVal {
    fn get<'a>(&'a self, key: &str) -> Option<&'a JVal> {
        match self {
            JVal::Obj(entries) => entries.iter().find(|(k, _)| k == key).map(|(_, v)| v),
            _ => None,
        }
    }

    fn as_array(&self) -> Option<&[JVal]> {
        match self {
            JVal::Arr(items) => Some(items),
            _ => None,
        }
    }

    fn as_str(&self) -> Option<&str> {
        match self {
            JVal::Str(text) => Some(text),
            _ => None,
        }
    }
}

impl Serialize for JVal {
    fn serialize<S: Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        match self {
            JVal::Null => serializer.serialize_none(),
            JVal::Bool(flag) => serializer.serialize_bool(*flag),
            JVal::Num(float) => {
                // JS number printing for the magnitudes used in these files.
                if float.fract() == 0.0 && float.abs() < 1e15 {
                    serializer.serialize_i64(*float as i64)
                } else {
                    serializer.serialize_f64(*float)
                }
            }
            JVal::Str(text) => serializer.serialize_str(text),
            JVal::Arr(items) => {
                let mut seq = serializer.serialize_seq(Some(items.len()))?;
                for item in items {
                    seq.serialize_element(item)?;
                }
                seq.end()
            }
            JVal::Obj(entries) => {
                let mut map = serializer.serialize_map(Some(entries.len()))?;
                for (key, value) in entries {
                    map.serialize_entry(key, value)?;
                }
                map.end()
            }
        }
    }
}

/// Minimal JSON parser producing [`JVal`] with object key order preserved.
struct JParser<'a> {
    bytes: &'a [u8],
    pos: usize,
}

impl<'a> JParser<'a> {
    fn new(text: &'a str) -> Self {
        Self {
            bytes: text.as_bytes(),
            pos: 0,
        }
    }

    fn peek(&self) -> Option<u8> {
        self.bytes.get(self.pos).copied()
    }

    fn skip_ws(&mut self) {
        while matches!(self.peek(), Some(b' ' | b'\t' | b'\n' | b'\r')) {
            self.pos += 1;
        }
    }

    fn expect(&mut self, byte: u8) -> Option<()> {
        if self.peek() == Some(byte) {
            self.pos += 1;
            Some(())
        } else {
            None
        }
    }

    fn value(&mut self) -> Option<JVal> {
        self.skip_ws();
        match self.peek()? {
            b'{' => self.object(),
            b'[' => self.array(),
            b'"' => self.string().map(JVal::Str),
            b't' => {
                self.literal(b"true")?;
                Some(JVal::Bool(true))
            }
            b'f' => {
                self.literal(b"false")?;
                Some(JVal::Bool(false))
            }
            b'n' => {
                self.literal(b"null")?;
                Some(JVal::Null)
            }
            _ => self.number(),
        }
    }

    fn literal(&mut self, text: &[u8]) -> Option<()> {
        if self.bytes.get(self.pos..self.pos + text.len())? == text {
            self.pos += text.len();
            Some(())
        } else {
            None
        }
    }

    fn number(&mut self) -> Option<JVal> {
        let start = self.pos;
        while matches!(self.peek(), Some(b'-' | b'+' | b'.' | b'e' | b'E' | b'0'..=b'9')) {
            self.pos += 1;
        }
        let text = std::str::from_utf8(self.bytes.get(start..self.pos)?).ok()?;
        text.parse::<f64>().ok().map(JVal::Num)
    }

    fn string(&mut self) -> Option<String> {
        self.expect(b'"')?;
        let mut out = String::new();
        loop {
            match self.peek()? {
                b'"' => {
                    self.pos += 1;
                    return Some(out);
                }
                b'\\' => {
                    self.pos += 1;
                    match self.peek()? {
                        b'"' => out.push('"'),
                        b'\\' => out.push('\\'),
                        b'/' => out.push('/'),
                        b'b' => out.push('\u{8}'),
                        b'f' => out.push('\u{c}'),
                        b'n' => out.push('\n'),
                        b'r' => out.push('\r'),
                        b't' => out.push('\t'),
                        b'u' => {
                            self.pos += 1;
                            let first = self.hex4()?;
                            let code = if (0xD800..0xDC00).contains(&first) {
                                // surrogate pair
                                if self.bytes.get(self.pos..self.pos + 2) == Some(b"\\u") {
                                    self.pos += 2;
                                    let second = self.hex4()?;
                                    0x10000 + ((first - 0xD800) << 10) + second.wrapping_sub(0xDC00)
                                } else {
                                    0xFFFD
                                }
                            } else {
                                first
                            };
                            out.push(char::from_u32(code).unwrap_or('\u{FFFD}'));
                            continue;
                        }
                        other => out.push(other as char),
                    }
                    self.pos += 1;
                }
                _ => {
                    // copy one UTF-8 encoded char verbatim
                    let start = self.pos;
                    self.pos += 1;
                    while self.pos < self.bytes.len() && (self.bytes[self.pos] & 0xC0) == 0x80 {
                        self.pos += 1;
                    }
                    out.push_str(std::str::from_utf8(self.bytes.get(start..self.pos)?).ok()?);
                }
            }
        }
    }

    fn hex4(&mut self) -> Option<u32> {
        let hex = self.bytes.get(self.pos..self.pos + 4)?;
        self.pos += 4;
        u32::from_str_radix(std::str::from_utf8(hex).ok()?, 16).ok()
    }

    fn object(&mut self) -> Option<JVal> {
        self.expect(b'{')?;
        let mut entries = Vec::new();
        self.skip_ws();
        if self.peek() == Some(b'}') {
            self.pos += 1;
            return Some(JVal::Obj(entries));
        }
        loop {
            self.skip_ws();
            let key = self.string()?;
            self.skip_ws();
            self.expect(b':')?;
            let value = self.value()?;
            entries.push((key, value));
            self.skip_ws();
            match self.peek()? {
                b',' => self.pos += 1,
                b'}' => {
                    self.pos += 1;
                    return Some(JVal::Obj(entries));
                }
                _ => return None,
            }
        }
    }

    fn array(&mut self) -> Option<JVal> {
        self.expect(b'[')?;
        let mut items = Vec::new();
        self.skip_ws();
        if self.peek() == Some(b']') {
            self.pos += 1;
            return Some(JVal::Arr(items));
        }
        loop {
            let value = self.value()?;
            items.push(value);
            self.skip_ws();
            match self.peek()? {
                b',' => self.pos += 1,
                b']' => {
                    self.pos += 1;
                    return Some(JVal::Arr(items));
                }
                _ => return None,
            }
        }
    }
}

/// Per-hook-id raw `justificationRequirements` arrays, recovered from
/// `shared-hooks/catalog-metadata.json` and `shared-hooks/registry.json` with
/// buildCatalog's merge priority. Missing/unparseable files degrade to an
/// empty map (callers then fall back to the typed requirements).
fn load_raw_requirements(root: &Path) -> HashMap<String, Vec<JVal>> {
    let mut map: HashMap<String, Vec<JVal>> = HashMap::new();
    // docs.justificationRequirements (metadata wins, even when empty).
    if let Ok(text) = std::fs::read_to_string(root.join("shared-hooks").join("catalog-metadata.json")) {
        if let Some(JVal::Obj(entries)) = JParser::new(&text).value() {
            for (id, docs) in entries {
                if let Some(JVal::Arr(items)) = docs.get("justificationRequirements") {
                    map.insert(id, items.clone());
                }
            }
        }
    }
    // hook.justificationRequirements from the hook's first registry
    // occurrence (events in source order); absent/null means [].
    if let Ok(text) = std::fs::read_to_string(root.join("shared-hooks").join("registry.json")) {
        if let Some(registry) = JParser::new(&text).value() {
            if let Some(JVal::Obj(events)) = registry.get("events").cloned() {
                for (_, config) in events {
                    if let Some(hooks) = config.get("hooks").and_then(JVal::as_array) {
                        for hook in hooks {
                            let id = match hook.get("id").and_then(JVal::as_str) {
                                Some(id) => id.to_string(),
                                None => continue,
                            };
                            if map.contains_key(&id) {
                                continue;
                            }
                            let reqs = match hook.get("justificationRequirements") {
                                Some(JVal::Arr(items)) => items.clone(),
                                _ => Vec::new(),
                            };
                            map.insert(id, reqs);
                        }
                    }
                }
            }
        }
    }
    map
}

/// Serializes a [`CatalogHook`] in the JS object key order, with
/// `justificationRequirements` taken from the raw source JSON when available
/// (falling back to the typed struct otherwise).
struct HookOut<'a> {
    hook: &'a CatalogHook,
    raw_reqs: Option<&'a [JVal]>,
}

impl Serialize for HookOut<'_> {
    fn serialize<S: Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        let hook = self.hook;
        let mut st = serializer.serialize_struct("CatalogHook", 11)?;
        st.serialize_field("id", &hook.id)?;
        st.serialize_field("type", &hook.hook_type)?;
        st.serialize_field("command", &hook.command)?;
        st.serialize_field("sourcePath", &hook.source_path)?;
        st.serialize_field("category", &hook.category)?;
        st.serialize_field("status", &hook.status)?;
        st.serialize_field("description", &hook.description)?;
        st.serialize_field("why", &hook.why)?;
        st.serialize_field("sideEffects", &hook.side_effects)?;
        st.serialize_field("events", &hook.events)?;
        match self.raw_reqs {
            Some(reqs) => st.serialize_field("justificationRequirements", &RawReqs(reqs))?,
            None => st.serialize_field("justificationRequirements", &hook.justification_requirements)?,
        }
        st.end()
    }
}

struct RawReqs<'a>(&'a [JVal]);

impl Serialize for RawReqs<'_> {
    fn serialize<S: Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        let mut seq = serializer.serialize_seq(Some(self.0.len()))?;
        for item in self.0 {
            seq.serialize_element(item)?;
        }
        seq.end()
    }
}

// ---------------------------------------------------------------------------
// scan_repo: port of the scanRepo subset of src/violations/find-violations.mjs
// (duplicated from the tama-violations crate because this binary may only
// depend on tama-core; see crate rule "no new dependencies")
// ---------------------------------------------------------------------------

const HOOK_ID: &str = "pre-write-edit";
const MAX_BYTES: u64 = 524_288;
const BINARY_SNIFF_BYTES: usize = 8_192;
const FOLDER_FILE_LIMIT: u64 = 5;

// Mirrors the IS_SYSTEM gate in pre_write_edit.sh; every regex alternative in
// the JS original is a literal substring, so `contains` checks are exact.
const SYSTEM_PATH_FRAGMENTS: [&str; 11] = [
    "node_modules",
    ".git/",
    ".github/workflows/",
    "/scripts/worker/deploy/",
    ".next",
    "__pycache__",
    "/.claude/",
    "/.factory/",
    "/.codex/",
    "/.shared-hooks/",
    "/chromium-build/",
];
const SYSTEM_DIR_NAMES: [&str; 5] = ["node_modules", ".git", ".next", "__pycache__", "chromium-build"];
const VENDOR_DIR_NAMES: [&str; 7] = ["dist", "build", "vendor", "target", ".venv", "venv", "coverage"];
// Mirrors the folder-density case exemptions in pre_write_edit.sh.
const FOLDER_EXEMPT_FRAGMENTS: [&str; 6] = [
    "/supabase/migrations",
    "/node_modules",
    "/.git",
    "/__pycache__",
    "/tests",
    "/migrations",
];

#[derive(Debug, Serialize)]
struct Violation {
    hook: String,
    rule: String,
    path: String,
    message: String,
}

#[derive(Debug, Serialize)]
struct SkippedFile {
    path: String,
    reason: String,
}

#[derive(Debug, Serialize)]
struct ScanError {
    path: String,
    message: String,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct ScanReport {
    repo: String,
    hook: String,
    mode: String,
    scanned_files: usize,
    skipped_files: Vec<SkippedFile>,
    violations: Vec<Violation>,
    errors: Vec<ScanError>,
}

#[derive(Serialize)]
struct HookPayload<'a> {
    tool_name: &'a str,
    tool_input: ToolInput<'a>,
}

#[derive(Serialize)]
struct ToolInput<'a> {
    file_path: &'a str,
    content: &'a str,
}

fn is_system_path(path: &str) -> bool {
    SYSTEM_PATH_FRAGMENTS.iter().any(|fragment| path.contains(fragment))
}

/// Mirrors `ruleKey`: first stderr line minus the BLOCKED: prefix, every
/// number (optionally signed) replaced by `N`, cut to 72 characters.
fn rule_key(stderr: &str) -> String {
    let line = first_line(stderr);
    let clean = match line.strip_prefix("BLOCKED:") {
        Some(rest) => rest.trim_start().to_string(),
        None => line,
    };
    let mut keyed = String::new();
    let chars: Vec<char> = clean.chars().collect();
    let mut i = 0;
    while i < chars.len() {
        let c = chars[i];
        if c.is_ascii_digit() || (c == '-' && i + 1 < chars.len() && chars[i + 1].is_ascii_digit()) {
            keyed.push('N');
            if c == '-' {
                i += 1;
            }
            while i < chars.len() && chars[i].is_ascii_digit() {
                i += 1;
            }
        } else {
            keyed.push(c);
            i += 1;
        }
    }
    let keyed: String = keyed.chars().take(72).collect();
    if keyed.is_empty() {
        "unknown-rule".to_string()
    } else {
        keyed
    }
}

enum Probe {
    Skip(String),
    Content(Vec<u8>),
}

fn probe_file(path: &str) -> Probe {
    let info = match std::fs::metadata(path) {
        Ok(info) => info,
        Err(_) => return Probe::Skip("unreadable".to_string()),
    };
    if !info.is_file() {
        return Probe::Skip("not a regular file".to_string());
    }
    if info.len() > MAX_BYTES {
        return Probe::Skip(format!("larger than {} bytes", MAX_BYTES));
    }
    let buffer = match std::fs::read(path) {
        Ok(buffer) => buffer,
        Err(_) => return Probe::Skip("unreadable".to_string()),
    };
    if buffer.iter().take(BINARY_SNIFF_BYTES).any(|byte| *byte == 0) {
        return Probe::Skip("binary content".to_string());
    }
    Probe::Content(buffer)
}

fn git_files(repo: &str) -> Option<Vec<String>> {
    let out = Command::new("git")
        .args(["ls-files", "-z", "--cached", "--others", "--exclude-standard"])
        .current_dir(repo)
        .output()
        .ok()?;
    if out.status.code() != Some(0) {
        return None;
    }
    let stdout = String::from_utf8_lossy(&out.stdout);
    let mut seen: HashSet<String> = HashSet::new();
    let mut files = Vec::new();
    for entry in stdout.split('\0') {
        if entry.is_empty() {
            continue;
        }
        let full = resolve_path(&[Path::new(repo), Path::new(entry)]);
        let full = full.to_string_lossy().into_owned();
        if !seen.insert(full.clone()) {
            continue;
        }
        files.push(full);
    }
    Some(files)
}

fn walk_files(root_dir: &str) -> Vec<String> {
    fn visit(dir: &str, files: &mut Vec<String>) {
        let entries = match std::fs::read_dir(dir) {
            Ok(entries) => entries,
            Err(_) => return, // JS: `catch { return; }`
        };
        // Node's readdirSync returns directory entries sorted (observed on
        // macOS); raw readdir does not. Sort by name bytes to match.
        let mut entries: Vec<_> = entries.flatten().collect();
        entries.sort_by(|a, b| a.file_name().as_encoded_bytes().cmp(b.file_name().as_encoded_bytes()));
        for entry in entries {
            let name = entry.file_name().to_string_lossy().into_owned();
            let full = Path::new(dir).join(&name).to_string_lossy().into_owned();
            let file_type = match entry.file_type() {
                Ok(file_type) => file_type,
                Err(_) => continue,
            };
            if file_type.is_dir() {
                if !SYSTEM_DIR_NAMES.contains(&name.as_str()) && !VENDOR_DIR_NAMES.contains(&name.as_str()) {
                    visit(&full, files);
                }
            } else if file_type.is_file() {
                files.push(full);
            }
        }
    }
    let mut files = Vec::new();
    visit(root_dir, &mut files);
    files
}

fn is_vendor_path(path: &str) -> bool {
    path.split('/').any(|segment| VENDOR_DIR_NAMES.contains(&segment))
}

/// `.tama-violations-ignore` at the repo root: one exact relative path per
/// line, directories with a trailing slash, `#` comments. Missing/unreadable
/// yields no entries (the JS `catch { /* missing stays null */ }`).
fn read_ignore_file(repo: &str) -> Vec<String> {
    let text = match std::fs::read_to_string(Path::new(repo).join(".tama-violations-ignore")) {
        Ok(text) => text,
        Err(_) => return Vec::new(),
    };
    text.split('\n')
        .map(|raw| raw.trim())
        .filter(|line| !line.is_empty() && !line.starts_with('#'))
        .map(|line| line.to_string())
        .collect()
}

fn is_ignored(rel_path: &str, entries: &[String]) -> bool {
    for entry in entries {
        if entry.ends_with('/') {
            if rel_path.starts_with(entry.as_str()) {
                return true;
            }
        } else if rel_path == entry {
            return true;
        }
    }
    false
}

struct HookRun {
    status: i32,
    stderr: String,
}

/// Runs `bash <hookPath>` with the JSON payload on stdin. Stdout is drained
/// and discarded, stderr captured; a spawn failure mirrors the JS `error`
/// handler as status -1 with the error text in stderr.
fn run_hook(hook_path: &str, payload: &str) -> HookRun {
    let child = Command::new("bash")
        .arg(hook_path)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn();
    let mut child = match child {
        Ok(child) => child,
        Err(error) => {
            return HookRun {
                status: -1,
                stderr: format!("{}", error),
            }
        }
    };
    if let Some(mut stdin) = child.stdin.take() {
        // A hook that exits early closes stdin; ignore the broken pipe,
        // like the JS `child.stdin.on('error', () => {})`.
        let _ = stdin.write_all(payload.as_bytes());
    }
    match child.wait_with_output() {
        Ok(output) => HookRun {
            status: output.status.code().unwrap_or(-1),
            stderr: String::from_utf8_lossy(&output.stderr).into_owned(),
        },
        Err(error) => HookRun {
            status: -1,
            stderr: format!("{}", error),
        },
    }
}

fn folder_violations(repo: &str, files: &[String], ignore_entries: &[String]) -> Vec<Violation> {
    let mut counts: HashMap<String, u64> = HashMap::new();
    for path in files {
        if is_system_path(path) {
            continue;
        }
        if is_vendor_path(path) {
            continue;
        }
        if is_ignored(&relative_path(Path::new(repo), Path::new(path)), ignore_entries) {
            continue;
        }
        let info = match std::fs::metadata(path) {
            Ok(info) => info,
            Err(_) => continue, // JS: `catch { continue; }`
        };
        if !info.is_file() {
            continue;
        }
        let dir = Path::new(path)
            .parent()
            .map(|parent| parent.to_string_lossy().into_owned())
            .unwrap_or_default();
        *counts.entry(dir).or_insert(0) += 1;
    }
    let mut violations = Vec::new();
    for (dir, count) in counts {
        if count <= FOLDER_FILE_LIMIT {
            continue;
        }
        if FOLDER_EXEMPT_FRAGMENTS.iter().any(|fragment| dir.contains(fragment)) {
            continue;
        }
        let rel = relative_path(Path::new(repo), Path::new(&dir));
        violations.push(Violation {
            hook: HOOK_ID.to_string(),
            rule: format!("Folder has N files (max {})", FOLDER_FILE_LIMIT),
            path: if rel.is_empty() { ".".to_string() } else { rel },
            message: format!(
                "Folder has {} files (max {}). Move files into sub-folders or consolidate.",
                count, FOLDER_FILE_LIMIT
            ),
        });
    }
    violations
}

/// Port of `scanRepo`. The JS original replays hooks through an 8-lane async
/// pool; this port runs them sequentially (see the header note).
fn scan_repo(repo: &str, hook_path: &str) -> ScanReport {
    let abs_repo = resolve_path(&[Path::new(repo)]).to_string_lossy().into_owned();
    let hook = hook_path.to_string();
    let (files, mode) = match git_files(&abs_repo) {
        Some(tracked) => (tracked, "git"),
        None => (walk_files(&abs_repo), "walk"),
    };
    let ignore_entries = read_ignore_file(&abs_repo);
    let mut skipped_files = Vec::new();
    let mut pending: Vec<(String, String)> = Vec::new();
    for path in &files {
        if is_system_path(path) {
            continue;
        }
        let rel = relative_path(Path::new(&abs_repo), Path::new(path));
        if is_ignored(&rel, &ignore_entries) {
            skipped_files.push(SkippedFile {
                path: rel,
                reason: "ignored by .tama-violations-ignore".to_string(),
            });
            continue;
        }
        if is_vendor_path(path) {
            skipped_files.push(SkippedFile {
                path: rel,
                reason: "vendored or build-output dir".to_string(),
            });
            continue;
        }
        match probe_file(path) {
            Probe::Skip(reason) => skipped_files.push(SkippedFile { path: rel, reason }),
            Probe::Content(buffer) => {
                pending.push((path.clone(), String::from_utf8_lossy(&buffer).into_owned()))
            }
        }
    }
    let mut violations = Vec::new();
    let mut errors = Vec::new();
    for (path, content) in &pending {
        let payload = serde_json::to_string(&HookPayload {
            tool_name: "Write",
            tool_input: ToolInput {
                file_path: path,
                content,
            },
        })
        .unwrap_or_default();
        let run = run_hook(&hook, &payload);
        let rel = relative_path(Path::new(&abs_repo), Path::new(path));
        if run.status == 2 {
            violations.push(Violation {
                hook: HOOK_ID.to_string(),
                rule: rule_key(&run.stderr),
                path: rel,
                message: first_line(&run.stderr),
            });
        } else if run.status != 0 {
            errors.push(ScanError {
                path: rel,
                message: format!("hook exited {}: {}", run.status, first_line(&run.stderr)),
            });
        }
    }
    violations.extend(folder_violations(&abs_repo, &files, &ignore_entries));
    violations.sort_by(|a, b| locale_compare(&a.path, &b.path));
    ScanReport {
        repo: abs_repo,
        hook,
        mode: mode.to_string(),
        scanned_files: pending.len(),
        skipped_files,
        violations,
        errors,
    }
}

// ---------------------------------------------------------------------------
// path / string helpers (Node semantics)
// ---------------------------------------------------------------------------

/// `firstLine` from the JS sources: first line of the text, trimmed.
fn first_line(text: &str) -> String {
    text.split('\n').next().unwrap_or("").trim().to_string()
}

/// Lexical normalization mirroring Node's `path.resolve` output (collapses
/// `.`/`..`/duplicate separators without touching the filesystem).
fn normalize(path: &Path) -> PathBuf {
    let mut out: Vec<std::ffi::OsString> = Vec::new();
    let mut rooted = false;
    for component in path.components() {
        match component {
            Component::RootDir => rooted = true,
            Component::CurDir => {}
            Component::ParentDir => {
                if !out.is_empty() {
                    out.pop();
                }
            }
            Component::Normal(part) => out.push(part.to_os_string()),
            Component::Prefix(_) => {}
        }
    }
    let mut result = if rooted { PathBuf::from("/") } else { PathBuf::new() };
    for part in out {
        result.push(part);
    }
    if result.as_os_str().is_empty() && rooted {
        PathBuf::from("/")
    } else {
        result
    }
}

/// Mirrors Node's `path.resolve(...)`: joins the segments (later absolute
/// segments reset the join), then makes the result absolute against the
/// process cwd and normalizes lexically.
fn resolve_path(segments: &[&Path]) -> PathBuf {
    let mut joined = PathBuf::new();
    for segment in segments {
        if segment.is_absolute() {
            joined = segment.to_path_buf();
        } else {
            joined.push(segment);
        }
    }
    if joined.is_absolute() {
        normalize(&joined)
    } else {
        let cwd = std::env::current_dir().unwrap_or_else(|_| PathBuf::from("/"));
        normalize(&cwd.join(&joined))
    }
}

/// Mirrors Node's `path.relative(from, to)` for absolute paths (both sides
/// are always absolute here): common prefix plus `..` segments.
fn relative_path(from: &Path, to: &Path) -> String {
    let parts = |path: &Path| -> Vec<String> {
        normalize(path)
            .components()
            .filter_map(|c| match c {
                Component::Normal(part) => Some(part.to_string_lossy().into_owned()),
                _ => None,
            })
            .collect()
    };
    let from_parts = parts(from);
    let to_parts = parts(to);
    let mut common = 0;
    while common < from_parts.len() && common < to_parts.len() && from_parts[common] == to_parts[common] {
        common += 1;
    }
    let mut out: Vec<String> = Vec::new();
    for _ in common..from_parts.len() {
        out.push("..".to_string());
    }
    out.extend(to_parts[common..].iter().cloned());
    out.join("/")
}

/// Mirrors JS `a.path.localeCompare(b.path)` closely enough for repo paths:
/// base letters first (case-insensitive), lowercase before uppercase on ties.
fn locale_compare(a: &str, b: &str) -> std::cmp::Ordering {
    let folded_a: Vec<char> = a.chars().flat_map(|c| c.to_lowercase()).collect();
    let folded_b: Vec<char> = b.chars().flat_map(|c| c.to_lowercase()).collect();
    match folded_a.cmp(&folded_b) {
        std::cmp::Ordering::Equal => {
            let rank = |s: &str| -> Vec<u8> {
                s.chars().map(|c| if c.is_uppercase() { 1 } else { 0 }).collect()
            };
            rank(a).cmp(&rank(b))
        }
        other => other,
    }
}
