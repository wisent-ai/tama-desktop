//! Port of `src/cli.mjs` — the main `tama` binary.
//!
//! Fidelity notes:
//! - `argv` here corresponds to JS `process.argv.slice(2)`: the node and
//!   script path entries never equal a flag, so `has`/`argAfter` over the
//!   remaining arguments behave identically.
//! - `N(x)` = `Number(x)`; exit codes are plain integers (`EXIT_USAGE` = 2).
//! - JS library errors propagate as thrown exceptions (exit 1 with the error
//!   text on stderr); here `Result` errors print the message and exit 1.

use std::io::Write;
use std::path::{Path, PathBuf};
use std::process::Command;

use serde::Serialize;

use tama_core::catalog::{build_catalog, find_hook, repo_root, validate_catalog};
use tama_core::install::{install_global_git, level_plan, InstallOptions};
use tama_core::policy_bundle::{
    import_policy_bundle, list_policy_bundles, ImportPolicyBundleOptions,
    PolicyBundleImportResult,
};
mod serve;
mod onboarding;

/// `EXIT_USAGE` from `src/adaptive/engine.mjs` (`N('2')`).
const EXIT_USAGE: i32 = 2;

/// The usage text from `usage()` in `src/cli.mjs`, byte-for-byte (the JS
/// template literal ends with a newline; `console.error` adds one more).
const USAGE: &str = "tama <command>

Commands:
  list [--json]              List hooks from the catalog
  show <hook-id> [--json]    Show one hook
  validate [--json]          Validate catalog/source archive
  install-plan [--json]      Show runtime scopes and target paths
  install                    Install user-global Git dispatchers; use --set-git-config to write Git config
  onboarding [--reset] [--policy-bundle <dir>] [--replace] [--home <path>]
                             Show first use and optionally import an inactive policy bundle
  policy import --source <dir> [--replace] [--json] [--home <path>]
                             Validate and persist an inactive policy bundle
  policy list [--json] [--home <path>]
                             List imported policy bundles and source identities
  verify                     Run catalog validation and hook block fixtures
  mcp-config                 Print MCP server config snippet
  find-violations (--repo <path> | --tree <dir> | --owner <gh-owner> | --me) [...] [--json]
                             Report existing hook rule violations in repositories (first hit per file)
  clean (same targets) [--model codex|kimi] [--max-rounds N] [--skip <fragment>] [--dry-run]
                             Spawn one headless model agent per repo to fix violations, then re-scan
  sessions [--json] [--home <path>]  Show every live agent session and its hook state
  serve [--port N]             Run the loopback desktop backend; prints one ready line, then serves /v1 endpoints
  adaptive <command> [...]   Adaptive layer doctor: status|drift|queue|repair|apply|install|uninstall|claude-config
";

/// JS `usage()`: the text goes to stderr.
fn usage() {
    eprintln!("{USAGE}");
}

/// `console.log(JSON.stringify(value, null, 2))` — one synchronous
/// `write_all` + `flush` so a following `process::exit` cannot truncate it.
fn print_json<T: Serialize>(value: &T) {
    let text = serde_json::to_string_pretty(value).unwrap_or_else(|_| "null".to_string());
    let stdout = std::io::stdout();
    let mut out = stdout.lock();
    let _ = out.write_all(text.as_bytes());
    let _ = out.write_all(b"\n");
    let _ = out.flush();
}

fn print_policy_import(result: &PolicyBundleImportResult, json: bool) {
    if json {
        print_json(result);
        return;
    }
    println!(
        "{}: {} imported, {} unchanged, {} removed, {} conflicting, {} rejected",
        result.status,
        result.imported,
        result.unchanged,
        result.removed,
        result.conflicting,
        result.rejected
    );
    println!("source: {}", result.source_path);
    println!("store: {}", result.store_path);
    println!("activation: inactive (0 installed, 0 enabled)");
    for conflict in &result.conflicts {
        println!("CONFLICT {}: {}", conflict.path, conflict.reason);
    }
    for rejection in &result.rejections {
        println!("REJECTED {rejection}");
    }
    for ignored in &result.ignored_paths {
        println!("IGNORED {ignored}");
    }
}

/// JS library calls throw on I/O errors; Node exits 1 with the error on
/// stderr. Reproduce the exit code and message (not the stack trace).
fn unwrap_or_exit<T>(result: tama_core::Result<T>) -> T {
    match result {
        Ok(value) => value,
        Err(error) => {
            eprintln!("{error}");
            std::process::exit(1);
        }
    }
}

/// JS truthiness for an optional string (`if (hook.description)`).
fn truthy(value: &Option<String>) -> Option<&str> {
    value.as_deref().filter(|s| !s.is_empty())
}

/// Prints catalog/hook JSON. Works around a tama-core fidelity gap:
/// `JustificationRequirement` flattens unknown keys (`title`) after the named
/// fields, while JS `JSON.parse` preserves the source order
/// (`kind, title, registryPath, field, ..., minimumWords`). Each `"title"`
/// line inside a `justificationRequirements` object is moved right after
/// `"kind"` in the pretty-printed text.
fn print_catalog_json<T: Serialize>(value: &T) {
    let text = serde_json::to_string_pretty(value).unwrap_or_else(|_| "null".to_string());
    let text = restore_requirement_key_order(&text);
    let stdout = std::io::stdout();
    let mut out = stdout.lock();
    let _ = out.write_all(text.as_bytes());
    let _ = out.write_all(b"\n");
    let _ = out.flush();
}

fn restore_requirement_key_order(text: &str) -> String {
    let lines: Vec<&str> = text.split('\n').collect();
    let mut out: Vec<String> = Vec::with_capacity(lines.len());
    let mut i = 0;
    while i < lines.len() {
        let line = lines[i];
        let trimmed = line.trim_start();
        if trimmed != "\"justificationRequirements\": [" {
            out.push(line.to_string());
            i += 1;
            continue;
        }
        let base_indent = line.len() - trimmed.len();
        out.push(line.to_string());
        i += 1;
        while i < lines.len() {
            let l = lines[i];
            let t = l.trim_start();
            let indent = l.len() - t.len();
            if indent <= base_indent && t.starts_with(']') {
                out.push(l.to_string());
                i += 1;
                break;
            }
            if t == "{" {
                let mut object: Vec<String> = vec![l.to_string()];
                i += 1;
                while i < lines.len() {
                    let l2 = lines[i];
                    let t2 = l2.trim_start();
                    let indent2 = l2.len() - t2.len();
                    object.push(l2.to_string());
                    i += 1;
                    if indent2 == indent && (t2 == "}" || t2 == "},") {
                        break;
                    }
                }
                reorder_title(&mut object);
                out.extend(object);
            } else {
                out.push(l.to_string());
                i += 1;
            }
        }
    }
    out.join("\n")
}

fn list_hooks(root: &Path, json: bool) -> tama_core::Result<usize> {
    let catalog = build_catalog(root)?;
    let hook_count = catalog.hooks.len();
    if json {
        print_catalog_json(&catalog);
    } else {
        for hook in &catalog.hooks {
            let events: Vec<&str> = hook.events.iter().map(|event| event.event.as_str()).collect();
            println!(
                "{}\t{}\t{}",
                hook.id,
                hook.source_path.as_deref().unwrap_or("-"),
                events.join(", ")
            );
        }
    }
    Ok(hook_count)
}

/// Moves the `"title"` property line of one justification-requirement object
/// (including its braces) to directly after `"kind"`, preserving commas.
fn reorder_title(object: &mut Vec<String>) {
    let Some(title_pos) = object
        .iter()
        .position(|l| l.trim_start().starts_with("\"title\":"))
    else {
        return;
    };
    let mut title = object.remove(title_pos);
    // `object` still holds the braces; property lines sit between them.
    let property_count = object.len().saturating_sub(2);
    if property_count == 0 {
        object.insert(1, title);
        return;
    }
    if !title.trim_end().ends_with(',') {
        // `title` was the last property: transfer its missing comma.
        title.push(',');
        let last = object.len() - 2;
        if object[last].ends_with(',') {
            object[last].pop();
        }
    }
    let insert_at = object
        .iter()
        .position(|l| l.trim_start().starts_with("\"kind\":"))
        .map(|pos| pos + 1)
        .unwrap_or(1);
    object.insert(insert_at, title);
}

#[derive(Serialize)]
struct McpConfig {
    #[serde(rename = "mcpServers")]
    mcp_servers: McpServers,
}

#[derive(Serialize)]
struct McpServers {
    tama: McpServerEntry,
}

#[derive(Serialize)]
struct McpServerEntry {
    command: String,
    args: Vec<String>,
}

/// The `mcp-config` document, shared with the serve backend: the native Rust
/// MCP server installed next to this binary, or its bare name as a fallback.
fn mcp_config() -> McpConfig {
    McpConfig {
        mcp_servers: McpServers {
            tama: McpServerEntry {
                command: std::env::current_exe()
                    .ok()
                    .and_then(|exe| exe.parent().map(|dir| dir.join("tama-mcp-server")))
                    .filter(|path| path.is_file())
                    .map(|path| path.display().to_string())
                    .unwrap_or_else(|| "tama-mcp-server".to_string()),
                args: vec![],
            },
        },
    }
}

fn main() {
    // JS `process.argv.slice(2)`.
    let argv: Vec<String> = std::env::args().skip(1).collect();

    // JS `has(flag)` = `process.argv.includes(flag)`; the leading node/script
    // entries never equal a flag.
    let has = |flag: &str| argv.iter().any(|arg| arg == flag);
    // JS `argAfter(flag)`: value right after the first occurrence, or None.
    let arg_after = |flag: &str| -> Option<String> {
        argv.iter()
            .position(|arg| arg == flag)
            .and_then(|i| argv.get(i + 1))
            .cloned()
    };
    // JS `optionValue(flag, alt)`.
    let option_value = |flag: &str| -> Option<String> { arg_after(flag) };

    // JS `selectedRoot()` = `optionValue('--root', repoRoot())`.
    let root: PathBuf = option_value("--root")
        .map(PathBuf::from)
        .unwrap_or_else(repo_root);

    let cmd: &str = argv.first().map(String::as_str).unwrap_or("help");

    if cmd == "help" || cmd == "--help" || cmd == "-h" {
        usage();
        std::process::exit(0);
    }

    if cmd == "onboarding" {
        let source = arg_after("--policy-bundle").filter(|value| !value.starts_with("--"));
        if argv.iter().any(|argument| argument == "--policy-bundle") && source.is_none() {
            eprintln!("--policy-bundle requires a directory");
            std::process::exit(EXIT_USAGE);
        }
        if has("--replace") && source.is_none() {
            eprintln!("--replace requires --policy-bundle <dir>");
            std::process::exit(EXIT_USAGE);
        }
        let home = option_value("--home").filter(|value| !value.starts_with("--"));
        if has("--home") && home.is_none() {
            eprintln!("--home requires a directory");
            std::process::exit(EXIT_USAGE);
        }
        let allowed = ["onboarding", "--reset", "--policy-bundle", "--replace", "--home"];
        for (index, argument) in argv.iter().enumerate().skip(1) {
            if (argv[index - 1] == "--policy-bundle" || argv[index - 1] == "--home") && !argument.starts_with("--") {
                continue;
            }
            if !allowed.contains(&argument.as_str()) {
                eprintln!("unknown onboarding option: {argument}");
                std::process::exit(EXIT_USAGE);
            }
        }
        let imported = source.as_ref().map(|source| {
            unwrap_or_exit(import_policy_bundle(ImportPolicyBundleOptions {
                source: Path::new(source),
                home: home.as_deref().map(Path::new),
                replace: has("--replace"),
            }))
        });
        if let Some(result) = &imported {
            print_policy_import(result, false);
            if result.status == "conflict" || result.status == "rejected" {
                std::process::exit(1);
            }
        }
        if let Err(error) = onboarding::run(&root, has("--reset"), imported.as_ref()) {
            eprintln!("{error}");
            std::process::exit(1);
        }
        std::process::exit(0);
    }

    if cmd == "policy" {
        let operation = argv.get(1).map(String::as_str).unwrap_or("");
        if operation == "import" {
            let source = arg_after("--source")
                .filter(|value| !value.starts_with("--"))
                .unwrap_or_else(|| {
                    eprintln!("policy import requires --source <dir>");
                    std::process::exit(EXIT_USAGE);
                });
            let home = option_value("--home").filter(|value| !value.starts_with("--"));
            if has("--home") && home.is_none() {
                eprintln!("--home requires a directory");
                std::process::exit(EXIT_USAGE);
            }
            let allowed = ["policy", "import", "--source", "--replace", "--json", "--home"];
            for (index, argument) in argv.iter().enumerate().skip(2) {
                if (argv[index - 1] == "--source" || argv[index - 1] == "--home") && !argument.starts_with("--") {
                    continue;
                }
                if !allowed.contains(&argument.as_str()) {
                    eprintln!("unknown policy import option: {argument}");
                    std::process::exit(EXIT_USAGE);
                }
            }
            let result = unwrap_or_exit(import_policy_bundle(ImportPolicyBundleOptions {
                source: Path::new(&source),
                home: home.as_deref().map(Path::new),
                replace: has("--replace"),
            }));
            print_policy_import(&result, has("--json"));
            std::process::exit(if result.status == "conflict" || result.status == "rejected" { 1 } else { 0 });
        }
        if operation == "list" {
            let home = option_value("--home").filter(|value| !value.starts_with("--"));
            if has("--home") && home.is_none() {
                eprintln!("--home requires a directory");
                std::process::exit(EXIT_USAGE);
            }
            let allowed = ["policy", "list", "--json", "--home"];
            for (index, argument) in argv.iter().enumerate().skip(2) {
                if argv[index - 1] == "--home" && !argument.starts_with("--") {
                    continue;
                }
                if !allowed.contains(&argument.as_str()) {
                    eprintln!("unknown policy list option: {argument}");
                    std::process::exit(EXIT_USAGE);
                }
            }
            let bundles = unwrap_or_exit(list_policy_bundles(
                home.as_deref().map(Path::new),
            ));
            if has("--json") {
                print_json(&bundles);
            } else if bundles.bundles.is_empty() {
                println!("No inactive policy bundles imported.");
            } else {
                for bundle in bundles.bundles {
                    println!(
                        "{}\t{}\t{} hooks\t{} files\tinactive",
                        bundle.source_path, bundle.source_digest, bundle.hook_count, bundle.file_count
                    );
                }
            }
            std::process::exit(0);
        }
        eprintln!("usage: tama policy import --source <dir> [--replace] [--json] [--home <path>] | tama policy list [--json] [--home <path>]");
        std::process::exit(EXIT_USAGE);
    }

    if cmd == "list" {
        unwrap_or_exit(list_hooks(&root, has("--json")));
        std::process::exit(0);
    }

    if cmd == "show" {
        let id = argv.get(1);
        let Some(id) = id else {
            usage();
            std::process::exit(EXIT_USAGE);
        };
        let hook = unwrap_or_exit(find_hook(id, &root));
        let Some(hook) = hook else {
            eprintln!("not found: {id}");
            std::process::exit(1);
        };
        if has("--json") {
            print_catalog_json(&hook);
        } else {
            println!("{}", hook.id);
            println!("source: {}", hook.source_path.as_deref().unwrap_or("-"));
            println!("command: {}", hook.command);
            if let Some(description) = truthy(&hook.description) {
                println!("does: {description}");
            }
            if let Some(why) = truthy(&hook.why) {
                println!("why: {why}");
            }
            println!("events:");
            for ev in &hook.events {
                println!("  - {} blocking={}", ev.event, ev.blocking);
            }
        }
        std::process::exit(0);
    }

    if cmd == "validate" {
        let result = unwrap_or_exit(validate_catalog(&root));
        if has("--json") {
            print_json(&result);
        } else {
            println!("hooks: {}", result.hook_count);
            println!("orphan sources: {}", result.orphan_source_count);
            for warning in &result.warnings {
                println!("WARN {warning}");
            }
            for error in &result.errors {
                eprintln!("ERROR {error}");
            }
        }
        std::process::exit(if result.ok { 0 } else { 1 });
    }


    if cmd == "install-plan" {
        // JS: `levelPlan(root, optionValue('--git-hooks-path'),
        // optionValue('--home', process.env.HOME ?? ''))`; the library falls
        // back to `HOME` itself when `home` is None.
        let plan = level_plan(
            &root,
            option_value("--git-hooks-path").as_deref(),
            option_value("--home").as_deref(),
        );
        if has("--json") {
            print_json(&plan);
        } else {
            println!("archive: {}", plan.archive_root);
            println!("agent/app hooks: configured by Claude/Codex/OMP runtimes, not by archive alone");
            println!("kimi hooks: no known native hook adapter; indirect coverage only via editor/Git surfaces");
            println!(
                "editor adapters: {} (not installed by archive alone)",
                plan.levels.editor.runtime_targets.editor_watch
            );
            println!("mcp server: {}", plan.levels.mcp.runtime_targets.server);
            println!(
                "user-global Git hooks: {}",
                plan.levels
                    .user_global_git
                    .current_hooks_path
                    .as_deref()
                    .unwrap_or("not configured")
            );
            println!("repo/project Git hooks: git config core.hooksPath .githooks");
            println!("OS-level policy: outside Tama");
        }
        std::process::exit(0);
    }

    if cmd == "install" {
        let result = unwrap_or_exit(install_global_git(
            &root,
            &InstallOptions {
                hooks_path: option_value("--git-hooks-path"),
                set_global_config: has("--set-git-config") && !has("--no-git-config"),
                home: option_value("--home"),
            },
        ));
        if has("--json") {
            print_json(&result);
        } else {
            println!("hooksPath: {}", result.hooks_path);
            println!("pre-commit: {}", result.pre_commit.target);
            println!("pre-push: {}", result.pre_push.target);
            println!("git global config updated: {}", result.set_global_config);
        }
        std::process::exit(0);
    }

    if cmd == "verify" {
        // The native Rust harness (`tama-require-live-runtime`) must sit next
        // to this binary; there is no JS fallback — the Node CLI is gone.
        let native = std::env::current_exe()
            .ok()
            .and_then(|exe| exe.parent().map(|dir| dir.join("tama-require-live-runtime")))
            .filter(|path| path.is_file());
        let Some(bin) = native else {
            eprintln!("tama-require-live-runtime not found next to this binary");
            std::process::exit(1);
        };
        let status = Command::new(bin).current_dir(&root).status();
        let code = match status {
            Ok(status) => status.code().unwrap_or(1),
            Err(_) => 1,
        };
        std::process::exit(code);
    }

    if cmd == "find-violations" {
        std::process::exit(tama_violations::scan_repos::main(&argv[1..], &root));
    }

    if cmd == "clean" {
        std::process::exit(tama_violations::clean::main(&argv[1..]));
    }

    if cmd == "mcp-config" {
        print_json(&mcp_config());
        std::process::exit(0);
    }
    if cmd == "serve" {
        std::process::exit(serve::main(&argv[1..], &root));
    }

    if cmd == "adaptive" {
        std::process::exit(tama_adaptive::doctor::cli::main(&argv[1..]));
    }

    if cmd == "sessions" {
        let home = option_value("--home")
            .or_else(|| std::env::var("HOME").ok())
            .unwrap_or_default();
        let control_dir = std::path::Path::new(&home)
            .join("Library/Application Support/Tama/session-control");

        let mut entries: Vec<PathBuf> = match std::fs::read_dir(&control_dir) {
            Ok(rd) => rd
                .filter_map(|e| e.ok())
                .map(|e| e.path())
                .filter(|p| p.extension().is_some_and(|ext| ext == "json") && p.to_string_lossy().ends_with(".session.json"))
                .collect(),
            Err(_) => Vec::new(),
        };
        entries.sort();

        let mut sessions: Vec<serde_json::Value> = Vec::new();
        for path in &entries {
            match std::fs::read_to_string(path) {
                Ok(text) => match serde_json::from_str::<serde_json::Value>(&text) {
                    Ok(raw) => {
                        let runtime = raw.get("runtime");
                        let session = serde_json::json!({
                            "sessionId": raw.get("sessionId").cloned().unwrap_or(serde_json::Value::Null),
                            "agentId": raw.get("agentId").cloned().unwrap_or(serde_json::Value::Null),
                            "cwd": raw.get("cwd").cloned().unwrap_or(serde_json::Value::Null),
                            "status": raw.get("status").cloned().unwrap_or(serde_json::Value::Null),
                            "globallyDisabled": runtime.and_then(|r| r.get("globallyDisabled")).cloned().unwrap_or(serde_json::Value::Null),
                            "loadedHookCount": runtime.and_then(|r| r.get("loadedHookCount")).cloned().unwrap_or(serde_json::Value::Null),
                            "registeredHookCount": runtime.and_then(|r| r.get("registeredHookCount")).cloned().unwrap_or(serde_json::Value::Null),
                            "enabledHookIds": runtime.and_then(|r| r.get("enabledHookIds")).cloned().unwrap_or(serde_json::json!([])),
                            "disabledHookIds": runtime.and_then(|r| r.get("disabledHookIds")).cloned().unwrap_or(serde_json::json!([])),
                            "updatedAt": raw.get("updatedAt").cloned().unwrap_or(serde_json::Value::Null),
                        });
                        sessions.push(session);
                    }
                    Err(_) => {
                        sessions.push(serde_json::json!({ "sessionId": path.display().to_string(), "parseError": true }));
                    }
                },
                Err(_) => {
                    sessions.push(serde_json::json!({ "sessionId": path.display().to_string(), "readError": true }));
                }
            }
        }

        if has("--json") {
            print_json(&sessions);
        } else {
            for s in &sessions {
                let agent = s.get("agentId").and_then(|v| v.as_str()).unwrap_or("?");
                let session_id = s.get("sessionId").and_then(|v| v.as_str()).unwrap_or("?");
                let short_id: String = session_id.chars().take(12).collect();
                let globally_disabled = s.get("globallyDisabled").and_then(|v| v.as_bool()).unwrap_or(false);
                let hooks = if globally_disabled {
                    let enabled: Vec<&str> = s.get("enabledHookIds").and_then(|v| v.as_array()).map(|a| a.iter().filter_map(|x| x.as_str()).collect()).unwrap_or_default();
                    if enabled.is_empty() {
                        "allowlist: empty".to_string()
                    } else {
                        format!("allowlist: {}", enabled.join(", "))
                    }
                } else {
                    let loaded = s.get("loadedHookCount").and_then(|v| v.as_i64()).map(|v| v.to_string()).unwrap_or("?".into());
                    let registered = s.get("registeredHookCount").and_then(|v| v.as_i64()).map(|v| v.to_string()).unwrap_or("?".into());
                    format!("{loaded}/{registered}")
                };
                println!("{agent}\t{short_id}\t{hooks}");
            }
        }
        std::process::exit(0);
    }

    // Hidden entrypoint used by the installed adaptive runner shim.
    if cmd == "adaptive-runner" {
        std::process::exit(tama_adaptive::runner::main(&argv));
    }

    // Hidden subcommand: spawned by `tama_adaptive::runner::dispatch_bridge`
    // as `<current exe> adaptive-bridge`; intentionally absent from usage.
    if cmd == "adaptive-bridge" {
        std::process::exit(tama_adaptive::bridge::main());
    }

    usage();
    std::process::exit(EXIT_USAGE);
}
