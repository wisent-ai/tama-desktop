//! Rust port of `shared-hooks/block_unauthorized_cua.py` (hook id
//! `block-unauthorized-cua`): block CUA unless a current-session direct user
//! quote authorizes its scope.
//!
//! The gate is two-sided. `authorized_entry` finds a registry entry whose
//! verbatim `userRequestQuote` names CUA, names the target app, carries a
//! direct consent or imperative, and really appears in this session's
//! transcript; `operation_matches_entry` then checks the action and the
//! process this call would actually drive against that entry.
//!
//! The patterns, `cua_action` and `is_cua_operation` live in
//! [`crate::ports::block_unauthorized_cua_detect`] and are re-exported here,
//! so this module is the whole port's surface.

use std::process::Command;

use serde_json::Value;

use crate::ports::block_unauthorized_cua_detect as detect;
use crate::ports::pystr;
use crate::ports::pyvalue;
use crate::ports::transport_common as common;

pub use crate::ports::block_unauthorized_cua_detect::{cua_action, is_cua_operation};

const TAMA_BUNDLE_ID: &str = "ai.wisent.tama.desktop";
const TAMA_EXECUTABLE: &str = "/Tama.app/Contents/MacOS/Tama";
const TAMA_APP_NAME: &str = "Tama";
const STRICT_SCHEMA: &str = "ai.wisent.tama.cua-justifications.vTwo";
const CUA_TOOL: &str = "cua-driver";
const SESSION_LIFETIME: &str = "current OMP session";
const LAUNCH_ACTION: &str = "launch_app";
const LEGACY_ACTIONS: &[&str] = &["status", "check_permissions", "serve"];
const PS_BINARY: &str = "/bin/ps";
const JUSTIFICATIONS_ENV: &str = "TAMA_CUA_JUSTIFICATIONS";
const HOOK_HOME: &str = ".shared-hooks";
const JUSTIFICATIONS_FILE: &str = "cua_justifications.json";
const BANNER: &str = "BLOCKED: unauthorized CUA: ";

fn justifications_path() -> std::path::PathBuf {
    common::env_path(JUSTIFICATIONS_ENV, common::home().join(HOOK_HOME).join(JUSTIFICATIONS_FILE))
}

/// `str(value).replace("-", "_").lower()` — the registry side, which does not
/// strip the way the quote side does.
fn normalized(value: &Value) -> String {
    pyvalue::py_str(value).replace('-', "_").to_lowercase()
}

/// `quote_directly_authorizes`: the quote itself must name CUA, carry a
/// direct grant, name the app, and — under the strict schema — name every
/// allowed action.
pub fn quote_directly_authorizes(entry: &Value, quote: &str, strict_actions: bool) -> bool {
    if !detect::CUA_QUOTE_RE.is_match(quote)
        || !(common::DIRECT_CONSENT_RE.is_match(quote)
            || detect::DIRECT_IMPERATIVE_RE.is_match(quote))
    {
        return false;
    }
    let bundle_id = entry.get("allowedBundleId").and_then(Value::as_str);
    let named = entry.get("allowedAppName").and_then(Value::as_str).unwrap_or_default();
    let app_name = if pystr::strip(named).is_empty() {
        if bundle_id == Some(TAMA_BUNDLE_ID) {
            TAMA_APP_NAME
        } else {
            ""
        }
    } else {
        named
    };
    let lowered = quote.to_lowercase();
    let target_named = (!app_name.is_empty() && lowered.contains(&app_name.to_lowercase()))
        || bundle_id.map(|id| lowered.contains(&id.to_lowercase())).unwrap_or(false);
    if !target_named {
        return false;
    }
    if !strict_actions {
        return true;
    }
    let actions = match entry.get("allowedActions") {
        Some(Value::Array(items)) if !items.is_empty() => items,
        _ => return false,
    };
    actions.iter().all(|raw| quote_names_action(&lowered, raw))
}

/// Every spelling the Python builds for one allowed action: `open_app`,
/// `open-app`, `open app`.
fn quote_names_action(lowered: &str, raw: &Value) -> bool {
    let action = pystr::strip(&pyvalue::py_str(raw)).to_lowercase().replace('-', "_");
    if action.is_empty() {
        return false;
    }
    lowered.contains(&action)
        || lowered.contains(&action.replace('_', "-"))
        || lowered.contains(&action.replace('_', " "))
}

/// `registry.get("authorizations", [])`.
///
/// Ported quirk: Python iterates a string's characters and a dict's keys —
/// neither yields a dict, so no entry can match — while a number, bool or
/// explicit `null` raises `TypeError` and the hook exits 1 without deciding.
fn authorizations(registry: &Value) -> Vec<Value> {
    match registry.get("authorizations") {
        None => Vec::new(),
        Some(Value::Array(items)) => items.clone(),
        Some(Value::String(_)) | Some(Value::Object(_)) => Vec::new(),
        Some(_) => common::python_crash("TypeError: 'authorizations' object is not iterable"),
    }
}

/// `authorized_entry`: the first registry entry the current session's
/// transcript actually backs.
pub fn authorized_entry(payload: &Value) -> Option<Value> {
    let registry = common::read_registry(&justifications_path())?;
    if !registry.is_object() {
        return None;
    }
    let session_id = common::session_id_of(payload);
    let strict_actions = registry.get("schema").and_then(Value::as_str) == Some(STRICT_SCHEMA);
    for entry in authorizations(&registry) {
        if !entry.is_object() {
            continue;
        }
        let quote = match entry.get("userRequestQuote") {
            Some(Value::String(quote)) => quote.clone(),
            _ => continue,
        };
        if entry.get("allowedTool").and_then(Value::as_str) == Some(CUA_TOOL)
            && entry.get("allowedBundleId").map(Value::is_string).unwrap_or(false)
            && entry.get("lifetime").and_then(Value::as_str) == Some(SESSION_LIFETIME)
            && quote_directly_authorizes(&entry, &quote, strict_actions)
            && common::quote_is_in_current_session(&session_id, &quote)
        {
            return Some(entry);
        }
    }
    None
}

/// `pid_targets_entry`: the live process really is the app the grant names.
pub fn pid_targets_entry(pid: &str, entry: &Value) -> bool {
    let configured = entry.get("allowedExecutable").and_then(Value::as_str).unwrap_or_default();
    let allowed = if configured.is_empty() {
        if entry.get("allowedBundleId").and_then(Value::as_str) == Some(TAMA_BUNDLE_ID) {
            TAMA_EXECUTABLE
        } else {
            ""
        }
    } else {
        configured
    };
    if allowed.is_empty() {
        return false;
    }
    let probe = Command::new(PS_BINARY).arg("-p").arg(pid).arg("-o").arg("command=").output();
    match probe {
        Ok(output) => {
            output.status.success() && String::from_utf8_lossy(&output.stdout).contains(allowed)
        }
        Err(_) => false,
    }
}

/// `action in {str(v).replace("-", "_").lower() for v in allowed}`, false
/// when `allowed` is absent or is not a list.
fn lists_action(allowed: Option<&Value>, action: &str) -> bool {
    match allowed {
        Some(Value::Array(items)) => items.iter().any(|item| normalized(item) == action),
        _ => false,
    }
}

/// `operation_matches_entry`: the action and its target are inside the scope
/// recorded with the quote.
pub fn operation_matches_entry(payload: &Value, entry: &Value) -> bool {
    let action = match cua_action(payload) {
        Some(action) => action,
        None => return false,
    };
    let allowed = entry.get("allowedActions").filter(|value| !value.is_null());
    if allowed.is_some() && !lists_action(allowed, &action) {
        return false;
    }
    let probe = pyvalue::py_json_dumps(&common::tool_input(payload));
    let bundle_id = entry.get("allowedBundleId").and_then(Value::as_str);
    if action == LAUNCH_ACTION {
        return bundle_id.map(|id| probe.contains(id)).unwrap_or(false);
    }
    let pids: Vec<String> = detect::PID_RE
        .captures_iter(&probe)
        .filter_map(|found| found.get(detect::action_group()).map(|pid| pid.as_str().to_string()))
        .collect();
    if !pids.is_empty() {
        return pids.iter().all(|pid| pid_targets_entry(pid, entry));
    }
    let legacy_tama_management = bundle_id == Some(TAMA_BUNDLE_ID)
        && allowed.is_none()
        && LEGACY_ACTIONS.contains(&action.as_str());
    legacy_tama_management
        || (matches!(entry.get("allowUntargeted"), Some(Value::Bool(true)))
            && lists_action(allowed, &action))
}

/// `evaluate_payload`: the deny banner when the call is refused, `None` when
/// it passes. The caller writes the banner to stderr and exits 2.
pub fn evaluate(payload: &Value) -> Option<String> {
    if !is_cua_operation(payload) {
        return None;
    }
    let authorization = match authorized_entry(payload) {
        Some(entry) => entry,
        None => {
            return Some(format!(
                "{BANNER}no direct current-session CUA grant in cua_justifications.json; \
                 the verbatim user quote must explicitly name CUA, the target app, \
                 and every allowed cua-driver action"
            ))
        }
    };
    if !operation_matches_entry(payload, &authorization) {
        return Some(format!(
            "{BANNER}the CUA operation is outside the app/action scope recorded with the user quote"
        ));
    }
    None
}
