//! Port of `shared-hooks/session-control.mjs`: session-scoped hook control
//! state under the platform state directory, atomic JSON writes, and the
//! global emergency-disable switch.

use std::collections::HashSet;
use std::env;
use std::fs;
use std::io;
use std::path::{Path, PathBuf};

use serde_json::{json, Value};

use crate::jsutil;
use crate::session_capability::{normalized_capability, CapabilityIdentity};
use crate::sha256::sha256_hex;

pub const SESSION_CONTROL_SCHEMA: &str = "ai.wisent.tama.session-control.v2";
pub const EMERGENCY_STATE_SCHEMA: &str = "ai.wisent.tama.hook-emergency-state.v1";
pub const DEFAULT_HEARTBEAT_TTL_SECONDS: i64 = 900;

/// Platform state root, mirroring `tamaStateRoot()`.
pub fn tama_state_root() -> PathBuf {
    #[cfg(target_os = "macos")]
    {
        jsutil::home_dir()
            .join("Library")
            .join("Application Support")
            .join("Tama")
    }
    #[cfg(target_os = "windows")]
    {
        let base = env::var_os("LOCALAPPDATA")
            .filter(|v| !v.is_empty())
            .map(PathBuf::from)
            .unwrap_or_else(|| jsutil::home_dir().join("AppData").join("Local"));
        base.join("Tama")
    }
    #[cfg(all(unix, not(target_os = "macos")))]
    {
        let base = env::var_os("XDG_STATE_HOME")
            .filter(|v| !v.is_empty())
            .map(PathBuf::from)
            .unwrap_or_else(|| jsutil::home_dir().join(".local").join("state"));
        base.join("tama")
    }
    #[cfg(not(any(unix, windows)))]
    {
        jsutil::home_dir().join(".tama")
    }
}

/// `sessionControlRoot` — `TAMA_SESSION_CONTROL_ROOT` or
/// `<tamaStateRoot>/session-control`.
pub fn session_control_root() -> PathBuf {
    env::var_os("TAMA_SESSION_CONTROL_ROOT")
        .filter(|v| !v.is_empty())
        .map(PathBuf::from)
        .unwrap_or_else(|| tama_state_root().join("session-control"))
}

/// `emergencyStatePath` — `TAMA_EMERGENCY_STATE` or
/// `<tamaStateRoot>/hook-emergency-state.json`.
pub fn emergency_state_path() -> PathBuf {
    env::var_os("TAMA_EMERGENCY_STATE")
        .filter(|v| !v.is_empty())
        .map(PathBuf::from)
        .unwrap_or_else(|| tama_state_root().join("hook-emergency-state.json"))
}

/// `loadJson`: parse the file, fall back to null on any error.
fn load_json(path: &Path) -> Value {
    fs::read_to_string(path)
        .ok()
        .and_then(|s| serde_json::from_str(&s).ok())
        .unwrap_or(Value::Null)
}

/// `atomicWriteJson`: ensure the session-control root (0700), write
/// `JSON.stringify(value) + "\n"` to a unique temp file (0600, `wx`), rename
/// into place, always remove the temp file. Errors propagate like the JS
/// `*Sync` calls do.
fn atomic_write_json(path: &Path, value: &Value) -> io::Result<()> {
    let root = session_control_root();
    fs::create_dir_all(&root)?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        fs::set_permissions(&root, fs::Permissions::from_mode(0o700))?;
    }
    let mut tmp = path.as_os_str().to_owned();
    tmp.push(format!(
        ".{}.{}.tmp",
        std::process::id(),
        jsutil::random_token()
    ));
    let tmp = PathBuf::from(tmp);
    let payload = format!("{}\n", serde_json::to_string(value).map_err(io::Error::other)?);
    let result = (|| -> io::Result<()> {
        let mut opts = fs::OpenOptions::new();
        opts.write(true).create_new(true);
        #[cfg(unix)]
        {
            use std::os::unix::fs::OpenOptionsExt;
            opts.mode(0o600);
        }
        let mut f = opts.open(&tmp)?;
        use std::io::Write;
        f.write_all(payload.as_bytes())?;
        drop(f);
        fs::rename(&tmp, path)?;
        Ok(())
    })();
    let _ = fs::remove_file(&tmp); // rmSync(temporary, { force: true })
    result
}

/// `/^[a-z][a-z0-9-]{0,31}$/` on the trimmed, lowercased input.
fn normalized_agent_id(value: &str) -> Option<String> {
    let id = jsutil::trim_js(value).to_lowercase();
    let b = id.as_bytes();
    if b.is_empty() || b.len() > 32 || !b[0].is_ascii_lowercase() {
        return None;
    }
    if !b[1..]
        .iter()
        .all(|&c| c.is_ascii_lowercase() || c.is_ascii_digit() || c == b'-')
    {
        return None;
    }
    Some(id)
}

/// `[payload, payload?.raw_event, payload?.session]` filtered to plain objects.
fn nested_values(payload: Option<&Value>) -> Vec<&Value> {
    let mut out = Vec::new();
    if let Some(p) = payload {
        if p.is_object() {
            out.push(p);
            for key in ["raw_event", "session"] {
                if let Some(v) = p.get(key) {
                    if v.is_object() {
                        out.push(v);
                    }
                }
            }
        }
    }
    out
}

/// First truthy value among `keys`, implementing the JS `a || b || c` chain
/// (falsy values — null, false, 0, "" — are skipped; empty arrays/objects are
/// truthy).
fn first_truthy<'a>(obj: &'a Value, keys: &[&str]) -> Option<&'a Value> {
    keys.iter()
        .map(|k| obj.get(*k))
        .find(|v| jsutil::js_truthy(*v))
        .flatten()
}

/// `normalizedResumeArgv`: a JSON-string form is parsed first; the result must
/// be a non-empty array of non-empty strings.
fn normalized_resume_argv(value: Option<&Value>) -> Option<Vec<String>> {
    match value {
        Some(Value::String(s)) => {
            normalized_resume_argv(serde_json::from_str::<Value>(s).ok().as_ref())
        }
        Some(Value::Array(items)) => {
            if items.is_empty()
                || !items
                    .iter()
                    .all(|i| i.as_str().is_some_and(|s| !s.is_empty()))
            {
                return None;
            }
            Some(
                items
                    .iter()
                    .map(|i| i.as_str().unwrap_or_default().to_string())
                    .collect(),
            )
        }
        _ => None,
    }
}

/// Port of `sessionResumeArgv`: resume argv from the payload (any nesting
/// level, snake/camel `resume`/`restart` spellings), else from
/// `TAMA_SESSION_RESUME_ARGV_JSON`.
pub fn session_resume_argv(payload: Option<&Value>) -> Option<Vec<String>> {
    for value in nested_values(payload) {
        let candidate = first_truthy(
            value,
            &["resume_argv", "resumeArgv", "restart_argv", "restartArgv"],
        );
        if let Some(normalized) = normalized_resume_argv(candidate) {
            return Some(normalized);
        }
    }
    let env_value = env::var("TAMA_SESSION_RESUME_ARGV_JSON")
        .ok()
        .map(Value::String);
    normalized_resume_argv(env_value.as_ref())
}

/// `[0-9a-f]{8}-…-[0-9a-f]{12}$` (case-insensitive) at the end of `name`.
fn match_trailing_uuid(name: &str) -> Option<String> {
    let tail = name.get(name.len().checked_sub(36)?..)?;
    let b = tail.as_bytes();
    for &dash in &[8usize, 13, 18, 23] {
        if b[dash] != b'-' {
            return None;
        }
    }
    for &(start, len) in &[(0usize, 8usize), (9, 4), (14, 4), (19, 4), (24, 12)] {
        if !b[start..start + len].iter().all(u8::is_ascii_hexdigit) {
            return None;
        }
    }
    Some(tail.to_string())
}

fn session_id_from_payload(payload: Option<&Value>) -> Option<String> {
    for value in nested_values(payload) {
        if let Some(explicit) = first_truthy(
            value,
            &[
                "session_id",
                "sessionId",
                "conversation_id",
                "conversationId",
                "thread_id",
                "threadId",
                "id",
            ],
        ) {
            return Some(jsutil::trim_js(&jsutil::js_to_string(explicit)).to_string());
        }
    }
    for value in nested_values(payload) {
        if let Some(transcript) = first_truthy(value, &["transcript_path", "transcriptPath"]) {
            let name = jsutil::js_basename(&jsutil::js_to_string(transcript));
            let name = name.strip_suffix(".jsonl").unwrap_or(&name);
            if let Some(m) = match_trailing_uuid(name) {
                return Some(m);
            }
        }
    }
    None
}

fn cwd_from_payload(payload: Option<&Value>) -> String {
    for value in nested_values(payload) {
        if let Some(cwd) = first_truthy(value, &["cwd", "project_dir", "projectDir"]) {
            return jsutil::js_to_string(cwd);
        }
    }
    env::current_dir()
        .map(|p| p.to_string_lossy().into_owned())
        .unwrap_or_default()
}

/// `Number(env || '')`, kept only when a positive safe integer.
fn numeric_environment(name: &str) -> Option<i64> {
    let raw = env::var(name).unwrap_or_default();
    jsutil::js_safe_integer_positive(&raw)
}

/// `process.kill(pid, 0)`: alive on success or EPERM.
///
/// Implemented via the shell (`kill -0`) because only std is available; EPERM
/// is recognized from the error message.
fn process_is_alive(pid: i64) -> bool {
    match std::process::Command::new("bash")
        .args(["-c", &format!("kill -0 {pid}")])
        .output()
    {
        Ok(o) if o.status.success() => true,
        Ok(o) => String::from_utf8_lossy(&o.stderr)
            .to_lowercase()
            .contains("operation not permitted"),
        Err(_) => false,
    }
}

/// Port of `hooksGloballyDisabled`.
pub fn hooks_globally_disabled() -> bool {
    let state = load_json(&emergency_state_path());
    state.get("schema").and_then(Value::as_str) == Some(EMERGENCY_STATE_SCHEMA)
        && state.get("disabled") == Some(&Value::Bool(true))
}

/// Result of `sessionContext`.
#[derive(Debug, Clone)]
pub struct SessionContext {
    pub agent_id: String,
    pub session_id: String,
    pub control_key: String,
    pub cwd: String,
}

/// Port of `sessionContext`: both ids required, `controlKey` is
/// `sha256("${agentId}\0${sessionId}")` hex.
pub fn session_context(agent_id_value: &str, payload: Option<&Value>) -> Option<SessionContext> {
    let agent_id = normalized_agent_id(agent_id_value)?;
    let session_id = session_id_from_payload(payload)?;
    if agent_id.is_empty() || session_id.is_empty() {
        return None;
    }
    Some(SessionContext {
        control_key: sha256_hex(format!("{agent_id}\0{session_id}").as_bytes()),
        cwd: cwd_from_payload(payload),
        agent_id,
        session_id,
    })
}

/// `cleanHookIds`: stringify + trim, drop empties and unknown ids, dedupe,
/// sort (byte order, matching JS default sort for ASCII).
fn clean_hook_ids(value: Option<&Value>, known_hook_ids: Option<&HashSet<String>>) -> Vec<String> {
    let mut out: Vec<String> = Vec::new();
    if let Some(Value::Array(items)) = value {
        for id in items {
            let s = jsutil::trim_js(&jsutil::js_to_string(id)).to_string();
            if !s.is_empty()
                && known_hook_ids.is_none_or(|k| k.contains(&s))
                && !out.contains(&s)
            {
                out.push(s);
            }
        }
    }
    out.sort();
    out
}

/// Result of `readSessionOverride`.
#[derive(Debug, Clone, Default)]
pub struct SessionOverride {
    pub enabled_hook_ids: Vec<String>,
    pub capability: Option<Value>,
}

/// Port of `readSessionOverride`: schema/agent/session/key must all match,
/// otherwise the empty override is returned.
pub fn read_session_override(
    context: Option<&SessionContext>,
    known_hook_ids: Option<&HashSet<String>>,
) -> SessionOverride {
    let empty = SessionOverride::default();
    let Some(ctx) = context else {
        return empty;
    };
    let path = session_control_root().join(format!("{}.override.json", ctx.control_key));
    let value = load_json(&path);
    let valid = value.get("schema").and_then(Value::as_str) == Some(SESSION_CONTROL_SCHEMA)
        && value.get("agentId").and_then(Value::as_str) == Some(ctx.agent_id.as_str())
        && value.get("sessionId").and_then(Value::as_str) == Some(ctx.session_id.as_str())
        && value.get("controlKey").and_then(Value::as_str) == Some(ctx.control_key.as_str());
    if !valid {
        return empty;
    }
    SessionOverride {
        enabled_hook_ids: clean_hook_ids(value.get("enabledHookIds"), known_hook_ids),
        capability: normalized_capability(
            value.get("capability").unwrap_or(&Value::Null),
            &ctx.session_id,
            jsutil::now_millis(),
            &CapabilityIdentity::default(),
        ),
    }
}

/// Port of `isSessionHookEnabled`.
pub fn is_session_hook_enabled(
    context: Option<&SessionContext>,
    hook_id: &str,
    known_hook_ids: Option<&HashSet<String>>,
) -> bool {
    if !hooks_globally_disabled() {
        return true;
    }
    read_session_override(context, known_hook_ids)
        .enabled_hook_ids
        .iter()
        .any(|id| id == hook_id)
}

/// Port of `publishSession`: snapshot the session state, atomically write
/// `<sessionControlRoot>/<controlKey>.session.json`, return the state.
/// IO errors propagate (`Err`), as the JS `*Sync` calls throw.
pub fn publish_session(
    context: Option<&SessionContext>,
    known_hook_ids: Option<&HashSet<String>>,
    payload: Option<&Value>,
) -> io::Result<Option<Value>> {
    let Some(ctx) = context else {
        return Ok(None);
    };
    let overrides = read_session_override(Some(ctx), known_hook_ids);
    let owner_pid = numeric_environment("TAMA_SESSION_OWNER_PID");
    let has_live_owner = owner_pid.is_some_and(process_is_alive);
    let heartbeat_ttl_seconds = numeric_environment("TAMA_SESSION_HEARTBEAT_TTL_SECONDS")
        .unwrap_or(DEFAULT_HEARTBEAT_TTL_SECONDS);
    let resume_argv = session_resume_argv(payload);

    let mut state = json!({
        "schema": SESSION_CONTROL_SCHEMA,
        "agentId": ctx.agent_id,
        "sessionId": ctx.session_id,
        "controlKey": ctx.control_key,
        "pid": if has_live_owner { owner_pid.unwrap_or(0) } else { 0 },
        "cwd": ctx.cwd,
        "livenessMode": if has_live_owner { "process" } else { "heartbeat" },
        "heartbeatTTLSeconds": heartbeat_ttl_seconds,
        "globallyDisabled": hooks_globally_disabled(),
        "disabledHookIds": [],
        "enabledHookIds": overrides.enabled_hook_ids,
        "capability": overrides.capability,
        "updatedAt": jsutil::to_iso_string(jsutil::now_millis()),
    });
    if let Some(p) = payload {
        if let Some(sr) = p.get("semantic_runtime") {
            if jsutil::js_truthy(Some(sr)) {
                state["semanticRuntime"] = sr.clone();
            }
        }
        if let Some(sp) = p.get("system_policy") {
            if sp.is_object() {
                state["systemPolicy"] = sp.clone();
            }
        }
    }
    if let Some(r) = resume_argv {
        state["resumeArgv"] = json!(r);
    }

    let path = session_control_root().join(format!("{}.session.json", ctx.control_key));
    atomic_write_json(&path, &state)?;
    Ok(Some(state))
}
