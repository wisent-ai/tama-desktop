//! Target extraction for `shared-hooks/block_unauthorized_ssh.py` (hook id
//! `block-unauthorized-ssh`): the `canonical_target` / `targets_from_urls`
//! half of the port, split out to keep both files inside the 300-line limit.
//!
//! A grant is exact only if the target is exact, so this is where the port
//! has to be literal: the same URL parse, the same `user@host:port` shape,
//! the same rejections.

use std::collections::BTreeSet;
use std::sync::LazyLock;

use regex::Regex;

use crate::ports::pystr;
use crate::ports::python_stdlib;
use crate::ports::transport_common as common;

/// `raw.strip().strip("'\"[](){},;")` — punctuation a target picks up when it
/// is quoted or listed inside a command line.
const STRIP_CHARS: &str = "'\"[](){},;";
const URL_SCHEMES: &[&str] = &["ssh://", "sftp://"];

/// `urllib.parse.SplitResult.port` raises `ValueError` outside this range.
const MAX_PORT_TEXT: &str = "65535";

fn max_port() -> u32 {
    MAX_PORT_TEXT.parse().unwrap_or_default()
}

/// `SSH_URL_RE`, verbatim.
pub static SSH_URL_RE: LazyLock<Regex> =
    LazyLock::new(|| common::compile("(?i)\\b(?:ssh|sftp)://[^\\s'\"<>]+"));

/// `REMOTE_SPEC_RE`, restructured: Rust has no lookbehind, so the negative
/// lookbehind `(?<![A-Za-z0-9._-])` becomes a consumed leading delimiter and
/// the spec is read from capture group 1. Equivalent because the tail
/// `[^\s]+` is greedy with nothing after it, so a match always ends at
/// whitespace or end of text and never eats the delimiter the next match
/// needs.
pub static REMOTE_SPEC_RE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile("(?:\\A|[^A-Za-z0-9._-])((?:[A-Za-z0-9._-]+@)?[A-Za-z0-9.-]+):[^\\s]+")
});

/// `re.fullmatch(r"[A-Za-z0-9.-]+(?::\d+)?", value)`.
static HOSTNAME_RE: LazyLock<Regex> =
    LazyLock::new(|| common::compile("\\A[A-Za-z0-9.-]+(?::\\d+)?\\z"));

/// The single capture group of `REMOTE_SPEC_RE`.
const SPEC_GROUP_TEXT: &str = "1";

pub fn spec_group() -> usize {
    SPEC_GROUP_TEXT.parse().unwrap_or_default()
}

/// `canonical_target`: one target string, or `None` when the text does not
/// name a host at all.
///
/// Ported crash: `urlsplit(...).port` raises `ValueError` on a port that is
/// not an ASCII integer in `0-65535`, and `block_unauthorized_ssh.py` does
/// not catch it — the hook dies with status 1 and decides nothing. The port
/// keeps that behaviour instead of inventing a verdict.
pub fn canonical_target(raw: &str) -> Option<String> {
    let value = pystr::strip(raw).trim_matches(|item| STRIP_CHARS.contains(item));
    if value.is_empty() {
        return None;
    }
    let lowered = value.to_lowercase();
    if URL_SCHEMES.iter().any(|scheme| lowered.starts_with(scheme)) {
        return url_target(value);
    }
    let host_spec = match value.contains(':') && !value.starts_with('[') {
        true => value.split_once(':').map(|(head, _)| head).unwrap_or(value),
        false => value,
    };
    if let Some((user, host)) = host_spec.rsplit_once('@') {
        if user.is_empty() || host.is_empty() {
            return None;
        }
        return Some(format!("{user}@{}", host.to_lowercase()));
    }
    match HOSTNAME_RE.is_match(host_spec) {
        true => Some(host_spec.to_lowercase()),
        false => None,
    }
}

/// The `ssh://` / `sftp://` branch: `user@host:port` rebuilt from
/// `urlsplit`'s `username`, `hostname` and `port`.
fn url_target(value: &str) -> Option<String> {
    let (_, netloc, _) = python_stdlib::urlsplit_parts(value);
    let opened = netloc.contains('[');
    let closed = netloc.contains(']');
    if opened != closed {
        common::python_crash("ValueError: Invalid IPv6 URL");
    }
    let (username, hostname, port_text) = netloc_parts(&netloc);
    let host = hostname.to_lowercase();
    if host.is_empty() {
        return None;
    }
    let user = match username.is_empty() {
        true => String::new(),
        false => format!("{username}@"),
    };
    let port = match parsed_port(&port_text) {
        Some(number) => format!(":{number}"),
        None => String::new(),
    };
    Some(format!("{user}{host}{port}"))
}

/// `SplitResult._userinfo` and `._hostinfo`: userinfo is everything before
/// the last `@`, the username everything before its first `:`, and a
/// bracketed IPv6 host keeps its own colons.
fn netloc_parts(netloc: &str) -> (String, String, String) {
    let (userinfo, hostinfo) = match netloc.rsplit_once('@') {
        Some((left, right)) => (Some(left), right),
        None => (None, netloc),
    };
    let username = userinfo
        .map(|text| text.split_once(':').map(|(head, _)| head).unwrap_or(text))
        .unwrap_or_default();
    let (hostname, port) = match hostinfo.split_once('[') {
        Some((_, bracketed)) => {
            let (host, rest) = bracketed.split_once(']').unwrap_or((bracketed, ""));
            (host, rest.split_once(':').map(|(_, tail)| tail).unwrap_or(""))
        }
        None => hostinfo.split_once(':').unwrap_or((hostinfo, "")),
    };
    (username.to_string(), hostname.to_string(), port.to_string())
}

/// `SplitResult.port`. Absent is `None`; anything else Python rejects is a
/// `ValueError` the hook never catches.
///
/// Deviation: CPython also validates a bracketed host as a real IPv6 or
/// IPvFuture literal and NFKC-checks the netloc, raising `ValueError` for
/// `ssh://[nothex]/`. Reproducing that needs an IPv6 parser and NFKC; this
/// port parses such a URL instead of dying, so it decides where Python would
/// have exited 1 without deciding.
fn parsed_port(port: &str) -> Option<u32> {
    if port.is_empty() {
        return None;
    }
    if !port.chars().all(|item| item.is_ascii_digit()) {
        common::python_crash(&format!(
            "ValueError: Port could not be cast to integer value as '{port}'"
        ));
    }
    match port.parse::<u32>() {
        Ok(number) if number <= max_port() => Some(number),
        _ => common::python_crash("ValueError: Port out of range 0-65535"),
    }
}

/// `targets_from_urls`: the canonical target of every URL that has one.
pub fn targets_from_urls(urls: &[String]) -> BTreeSet<String> {
    let mut targets = BTreeSet::new();
    for url in urls {
        if let Some(target) = canonical_target(url) {
            targets.insert(target);
        }
    }
    targets
}

/// Every `SSH_URL_RE` match in one string, as owned text.
pub fn ssh_urls(text: &str) -> Vec<String> {
    SSH_URL_RE.find_iter(text).map(|found| found.as_str().to_string()).collect()
}
