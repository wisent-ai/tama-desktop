//! Port of `src/adaptive/doctor/evidence.mjs`: validated immutable evidence
//! projection for the doctor queue and repair commands.

use sha2::{Digest, Sha256};
use std::collections::HashSet;
use std::fs;
use std::path::{Path, PathBuf};

use crate::util::{home_dir, shell_words};

const SEGMENT_PROTOCOL: &str = "hooks-telemetry-segment-v1";
const EVIDENCE_TYPES: [&str; 3] = ["repair_proposal", "corpus_add", "corpus_label"];

/// `liveScriptPath(command)` — first shell word ending in `.py`/`.sh`/`.mjs`
/// after `~`/`$HOME` expansion.
pub fn live_script_path(command: &str) -> Option<String> {
    let home = home_dir().to_string_lossy().to_string();
    for word in shell_words(command) {
        let token = expand_home_word(&word, &home);
        if token.ends_with(".py") || token.ends_with(".sh") || token.ends_with(".mjs") {
            return Some(token);
        }
    }
    None
}

fn expand_home_word(word: &str, home: &str) -> String {
    let chars: Vec<char> = word.chars().collect();
    let mut out = String::with_capacity(word.len());
    let mut index = 0;
    while index < chars.len() {
        let c = chars[index];
        if c == '~' && (index + 1 == chars.len() || chars[index + 1] == '/') {
            out.push_str(home);
            index += 1;
        } else if c == '$' && chars[index..].starts_with(&['$', 'H', 'O', 'M', 'E']) {
            out.push_str(home);
            index += 5;
        } else {
            out.push(c);
            index += 1;
        }
    }
    out
}

/// `object(text)` — strict object parse; errors propagate like the JS throw.
fn object(text: &str) -> Result<serde_json::Value, String> {
    let value: serde_json::Value = serde_json::from_str(text).map_err(|e| format!("SyntaxError: {}", e))?;
    if value.is_object() {
        Ok(value)
    } else {
        Ok(serde_json::Value::Null)
    }
}

struct EvidenceSegment {
    segment_id: String,
    created_at: serde_json::Value,
    events: Vec<(serde_json::Value, i64)>,
}

/// `validatedSegment(path, expectedName)` from evidence.mjs.
fn validated_segment(path: &Path, expected_name: &str) -> Option<EvidenceSegment> {
    let source = fs::read_to_string(path).ok()?;
    if !source.ends_with('\n') {
        return None;
    }
    let lines: Vec<&str> = source[..source.len() - 1].split('\n').collect();
    if lines.len() < 2 {
        return None;
    }
    let header = object(lines[0]).ok().filter(|v| v.is_object())?;
    let footer = object(lines[lines.len() - 1]).ok().filter(|v| v.is_object())?;
    let name_match = expected_name
        .strip_prefix("segment-")
        .and_then(|rest| rest.strip_suffix(".jsonl"))
        .filter(|middle| !middle.is_empty())?;
    if header.get("kind").and_then(|v| v.as_str()) != Some("segment_open")
        || header.get("protocol").and_then(|v| v.as_str()) != Some(SEGMENT_PROTOCOL)
    {
        return None;
    }
    if header.get("segmentId").and_then(|v| v.as_str()) != Some(name_match) {
        return None;
    }
    if !header.get("createdAt").map(|v| v.is_number()).unwrap_or(false) {
        return None;
    }
    let producer_ok = header.get("producerId").and_then(|v| v.as_str()).map(|s| !s.is_empty()).unwrap_or(false);
    let invocation_ok = header.get("invocationId").and_then(|v| v.as_str()).map(|s| !s.is_empty()).unwrap_or(false);
    if !producer_ok || !invocation_ok {
        return None;
    }
    let source_field = header.get("source")?;
    if source_field.is_null()
        || source_field.get("producer").and_then(|v| v.as_str()) != Some("tama")
    {
        return None;
    }
    let mut events = Vec::new();
    for (sequence, text) in lines[1..lines.len() - 1].iter().enumerate() {
        let frame = object(text).ok().filter(|v| v.is_object())?;
        if frame.get("kind").and_then(|v| v.as_str()) != Some("event") {
            return None;
        }
        if frame.get("sequence").and_then(|v| v.as_i64()) != Some(sequence as i64) {
            return None;
        }
        let event = frame.get("event")?.clone();
        if !event.is_object() {
            return None;
        }
        events.push((event, sequence as i64));
    }
    let payload = format!("{}\n", lines[..lines.len() - 1].join("\n"));
    let payload_sha256 = format!("{:x}", Sha256::digest(payload.as_bytes()));
    if footer.get("kind").and_then(|v| v.as_str()) != Some("segment_close")
        || footer.get("protocol").and_then(|v| v.as_str()) != Some(SEGMENT_PROTOCOL)
        || footer.get("segmentId").and_then(|v| v.as_str()) != header.get("segmentId").and_then(|v| v.as_str())
    {
        return None;
    }
    if footer.get("eventCount").and_then(|v| v.as_i64()) != Some(events.len() as i64)
        || footer.get("payloadSha256").and_then(|v| v.as_str()) != Some(payload_sha256.as_str())
        || !footer.get("closedAt").map(|v| v.is_number()).unwrap_or(false)
    {
        return None;
    }
    Some(EvidenceSegment {
        segment_id: name_match.to_string(),
        created_at: header.get("createdAt").cloned().unwrap_or(serde_json::Value::Null),
        events,
    })
}

enum Canon {
    /// `false` in JS — the whole segment is invalid.
    Invalid,
    /// `null` in JS — the row carries no evidence, skip it.
    Skip,
    Row(serde_json::Value),
}

fn is_integer(value: &serde_json::Value) -> bool {
    match value {
        serde_json::Value::Number(n) => {
            n.as_i64().is_some()
                || n.as_f64().map(|f| f.is_finite() && f.fract() == 0.0).unwrap_or(false)
        }
        _ => false,
    }
}

fn is_finite_number(value: &serde_json::Value) -> bool {
    value.as_f64().map(|f| f.is_finite()).unwrap_or(false)
}

/// `canonicalEvidence(row, segmentId)`.
fn canonical_evidence(row: &serde_json::Value, segment_id: &str) -> Canon {
    if row.get("runtime").and_then(|v| v.as_str()) != Some("hooks")
        || row.get("event_type").and_then(|v| v.as_str()) != Some("hook_decision")
    {
        return Canon::Invalid;
    }
    let extra = row.get("extra").filter(|v| v.is_object()).cloned().unwrap_or(serde_json::Value::Null);
    if !extra.is_object() {
        return Canon::Invalid;
    }
    let source_type = extra.get("source_type").and_then(|v| v.as_str()).unwrap_or("");
    if !EVIDENCE_TYPES.contains(&source_type) {
        return Canon::Skip;
    }
    let hook_id = extra.get("hook_id").and_then(|v| v.as_str()).unwrap_or("");
    if hook_id.is_empty() {
        return Canon::Invalid;
    }
    if source_type == "corpus_add" && extra.get("payload").is_none() {
        return Canon::Invalid;
    }
    if source_type == "corpus_label" && !extra.get("label").map(|v| v.is_string()).unwrap_or(false) {
        return Canon::Invalid;
    }
    if extra.get("segment_id").and_then(|v| v.as_str()) != Some(segment_id)
        || !extra.get("sequence").map(is_integer).unwrap_or(false)
    {
        return Canon::Invalid;
    }
    if !extra.get("segment_created_at").map(is_finite_number).unwrap_or(false) {
        return Canon::Invalid;
    }
    let timestamp = row.get("ts").and_then(|v| v.as_str()).and_then(parse_date_ms);
    let Some(timestamp) = timestamp else { return Canon::Invalid };
    let mut out = serde_json::Map::new();
    out.insert("type".into(), source_type.into());
    out.insert("ts".into(), timestamp.into());
    out.insert("id".into(), hook_id.into());
    if let Some(payload) = extra.get("payload") {
        out.insert("payload".into(), payload.clone());
    }
    if let Some(label) = extra.get("label") {
        out.insert("label".into(), label.clone());
    }
    if let Some(payload_ts) = extra.get("payload_ts").filter(|v| is_finite_number(v)) {
        out.insert("payloadTs".into(), payload_ts.clone());
    }
    if let Some(kind) = extra.get("repair_kind") {
        out.insert("kind".into(), kind.clone());
    }
    if let Some(evidence) = extra.get("evidence") {
        out.insert("evidence".into(), evidence.clone());
    }
    out.insert("__segmentCreatedAt".into(), extra.get("segment_created_at").cloned().unwrap_or(serde_json::Value::Null));
    out.insert("__segmentId".into(), segment_id.into());
    out.insert("__segmentSequence".into(), extra.get("sequence").cloned().unwrap_or(serde_json::Value::Null));
    Canon::Row(serde_json::Value::Object(out))
}

fn read_lake_evidence() -> Result<(Vec<serde_json::Value>, HashSet<String>), String> {
    let lake_root = std::env::var("LAKE_DATA")
        .ok()
        .filter(|v| !v.is_empty())
        .map(PathBuf::from)
        .unwrap_or_else(|| home_dir().join(".transcript-lake"));
    let cursor_path = lake_root.join("cursors.json");
    let cursor_store = if cursor_path.exists() {
        let parsed = object(&fs::read_to_string(&cursor_path).map_err(|e| format!("Error: {}", e))?)?;
        if parsed.is_object() {
            Some(parsed)
        } else {
            None
        }
    } else {
        None
    };
    let Some(cursor_store) = cursor_store else {
        return Ok((Vec::new(), HashSet::new()));
    };
    let hooks_dir = lake_root.join("events").join("runtime=hooks");
    let mut rows = Vec::new();
    let mut segment_ids = HashSet::new();
    let entries = cursor_store.as_object().cloned().unwrap_or_default();
    for (key, commit) in entries {
        if !key.starts_with("hooks:") {
            continue;
        }
        if commit.get("kind").and_then(|v| v.as_str()) != Some("closed-segment")
            || commit.get("state").and_then(|v| v.as_str()) != Some("committed")
        {
            continue;
        }
        let segment_id = key["hooks:".len()..].to_string();
        let outputs = commit.get("outputs").and_then(|v| v.as_array()).cloned().unwrap_or_default();
        if segment_id.is_empty()
            || commit.get("segmentId").and_then(|v| v.as_str()) != Some(segment_id.as_str())
            || outputs.is_empty()
        {
            continue;
        }
        let mut segment_rows = Vec::new();
        let mut seen_paths = HashSet::new();
        let mut valid = true;
        for output in &outputs {
            let path_str = output.get("path").and_then(|v| v.as_str());
            let sha = output.get("sha256").and_then(|v| v.as_str());
            let (Some(path_str), Some(sha)) = (path_str, sha) else {
                valid = false;
                break;
            };
            let file_path = resolve_path(path_str);
            let relative = file_path.strip_prefix(&hooks_dir).unwrap_or(&file_path);
            let parts: Vec<String> =
                relative.components().map(|c| c.as_os_str().to_string_lossy().to_string()).collect();
            let expected_name = format!("segment-{}.ndjson", segment_id);
            let date_ok = parts.first().map(|p| is_lake_date(p)).unwrap_or(false);
            if parts.len() != 2
                || !date_ok
                || parts.get(1).map(|p| p.as_str()) != Some(expected_name.as_str())
                || file_path.file_name().map(|n| n.to_string_lossy().to_string()).as_deref() != Some(expected_name.as_str())
                || seen_paths.contains(&file_path)
            {
                valid = false;
                break;
            }
            seen_paths.insert(file_path.clone());
            let source = fs::read_to_string(&file_path).map_err(|e| format!("Error: {}", e))?;
            if !source.ends_with('\n')
                || format!("{:x}", Sha256::digest(source.as_bytes())) != sha
            {
                valid = false;
                break;
            }
            for text in source[..source.len() - 1].split('\n') {
                let row = object(text)?;
                match canonical_evidence(&row, &segment_id) {
                    Canon::Invalid => {
                        valid = false;
                        break;
                    }
                    Canon::Skip => {}
                    Canon::Row(evidence) => segment_rows.push(evidence),
                }
            }
            if !valid {
                break;
            }
        }
        if !valid {
            continue;
        }
        segment_ids.insert(segment_id);
        rows.extend(segment_rows);
    }
    Ok((rows, segment_ids))
}

fn resolve_path(path: &str) -> PathBuf {
    let p = PathBuf::from(path);
    if p.is_absolute() {
        p
    } else {
        std::env::current_dir().unwrap_or_default().join(p)
    }
}

/// `^date=[0-9]{4}-[0-9]{2}-[0-9]{2}$`
fn is_lake_date(part: &str) -> bool {
    let Some(date) = part.strip_prefix("date=") else { return false };
    let segs: Vec<&str> = date.split('-').collect();
    segs.len() == 3
        && segs[0].len() == 4
        && segs[1].len() == 2
        && segs[2].len() == 2
        && segs.iter().all(|s| s.bytes().all(|b| b.is_ascii_digit()) && !s.is_empty())
}

/// `readClosedTelemetryEvents(stateDir)`.
pub fn read_closed_telemetry_events(state_dir: &Path) -> Result<Vec<serde_json::Value>, String> {
    let (durable_rows, segment_ids) = read_lake_evidence()?;
    let mut rows = durable_rows;
    let ready_dir = state_dir.join("telemetry-segments").join("ready");
    let mut names: Vec<String> = if ready_dir.exists() {
        fs::read_dir(&ready_dir)
            .map_err(|e| format!("Error: {}", e))?
            .flatten()
            .map(|entry| entry.file_name().to_string_lossy().to_string())
            .collect()
    } else {
        Vec::new()
    };
    names.sort();
    for name in names {
        let Some(middle) = name.strip_prefix("segment-").and_then(|r| r.strip_suffix(".jsonl")) else {
            continue;
        };
        if middle.is_empty() || name.contains('/') || name.contains('\\') {
            continue;
        }
        if segment_ids.contains(middle) {
            continue;
        }
        let Some(segment) = validated_segment(&ready_dir.join(&name), &name) else { continue };
        for (event, sequence) in segment.events {
            let event_type = event.get("type").and_then(|v| v.as_str()).unwrap_or("");
            if !EVIDENCE_TYPES.contains(&event_type) {
                continue;
            }
            let mut row = event.as_object().cloned().unwrap_or_default();
            row.insert("__segmentCreatedAt".into(), segment.created_at.clone());
            row.insert("__segmentId".into(), segment.segment_id.clone().into());
            row.insert("__segmentSequence".into(), sequence.into());
            rows.push(serde_json::Value::Object(row));
        }
    }
    rows.sort_by(|left, right| {
        let key = |row: &serde_json::Value| {
            let created = row.get("__segmentCreatedAt").and_then(|v| v.as_f64()).unwrap_or(0.0);
            let ts = row.get("ts").and_then(|v| v.as_f64()).unwrap_or(created);
            (
                ordered_float(ts),
                ordered_float(created),
                row.get("__segmentId").and_then(|v| v.as_str()).unwrap_or("").to_string(),
                row.get("__segmentSequence").and_then(|v| v.as_i64()).unwrap_or(0),
            )
        };
        key(left).cmp(&key(right))
    });
    Ok(rows)
}

fn ordered_float(value: f64) -> i64 {
    // Timestamps here are integral milliseconds; comparing as i64 keeps the
    // total order simple and matches the JS numeric subtraction comparator.
    value as i64
}

/// `Date.parse` for the ISO-8601 shapes the lake writes
/// (`YYYY-MM-DD[T ]HH:MM:SS[.sss][Z|±HH:MM]` or date-only).
pub fn parse_date_ms(text: &str) -> Option<u64> {
    let (date_part, time_part) = match text.find(['T', ' ']) {
        Some(index) => (&text[..index], &text[index + 1..]),
        None => (text, ""),
    };
    let date_segs: Vec<&str> = date_part.split('-').collect();
    if date_segs.len() != 3 {
        return None;
    }
    let year: i64 = date_segs[0].parse().ok()?;
    let month: i64 = date_segs[1].parse().ok()?;
    let day: i64 = date_segs[2].parse().ok()?;
    if !(1..=12).contains(&month) || !(1..=31).contains(&day) {
        return None;
    }
    let days = days_from_civil(year, month as u32, day as u32);
    let mut seconds = 0i64;
    let mut millis = 0i64;
    let mut offset_seconds = 0i64;
    if !time_part.is_empty() {
        let (time_main, offset) = split_offset(time_part);
        offset_seconds = offset?;
        let time_segs: Vec<&str> = time_main.split(':').collect();
        if time_segs.len() < 2 {
            return None;
        }
        let hour: i64 = time_segs[0].parse().ok()?;
        let minute: i64 = time_segs[1].parse().ok()?;
        let (sec_str, frac) = match time_segs.get(2).map(|s| s.split_once('.')) {
            Some(Some((sec, frac))) => (sec, frac),
            Some(None) => (time_segs[2], ""),
            None => ("0", ""),
        };
        let second: i64 = sec_str.parse().ok()?;
        if !frac.is_empty() {
            let padded = format!("{:0<3}", &frac[..frac.len().min(3)]);
            millis = padded.parse().ok()?;
        }
        seconds = hour * 3600 + minute * 60 + second;
    }
    let total = (days * 86_400 + seconds - offset_seconds) * 1000 + millis;
    if total < 0 {
        return None;
    }
    Some(total as u64)
}

fn split_offset(time: &str) -> (&str, Option<i64>) {
    if let Some(stripped) = time.strip_suffix('Z') {
        return (stripped, Some(0));
    }
    let bytes = time.as_bytes();
    for index in (0..bytes.len()).rev() {
        let c = bytes[index] as char;
        if (c == '+' || c == '-') && index > 0 {
            let offset = &time[index..];
            let sign = if c == '+' { 1 } else { -1 };
            let body = &offset[1..];
            let (h, m) = body.split_once(':').unwrap_or((body, "0"));
            if let (Ok(h), Ok(m)) = (h.parse::<i64>(), m.parse::<i64>()) {
                return (&time[..index], Some(sign * (h * 3600 + m * 60)));
            }
            return (time, None);
        }
    }
    (time, Some(0))
}

fn days_from_civil(y: i64, m: u32, d: u32) -> i64 {
    let y = if m <= 2 { y - 1 } else { y };
    let era = if y >= 0 { y } else { y - 399 } / 400;
    let yoe = (y - era * 400) as u64;
    let mp = if m > 2 { m - 3 } else { m + 9 } as u64;
    let doy = (153 * mp + 2) / 5 + d as u64 - 1;
    let doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    era * 146_097 + doe as i64 - 719_468
}
