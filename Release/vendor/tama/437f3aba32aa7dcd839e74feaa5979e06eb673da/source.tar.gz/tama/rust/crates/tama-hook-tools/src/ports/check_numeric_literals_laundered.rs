//! The evasion `check_numeric_literals` did not see: a number spelled as a
//! string and converted back.
//!
//! `strip_sc` blanks quoted text before the scan, which is what makes a number
//! inside a message safe. The same blanking makes `const LIMIT: &str = "8"`
//! followed by `LIMIT.parse()` invisible — and that spelling is a magic number
//! with one extra step, not a justified one. This repository's own sources use
//! it (`Number('0')`, `int("0")`, `"4194304".parse()`), which is how the
//! practice spread: the scanner taught the workaround.
//!
//! Detection is contextual, never "a string that looks like a number". A
//! quoted digit run is reported only where it is being used AS a number:
//! declared as the initializer of a binding, or handed to a conversion. A
//! version string, an id, a port in a URL, a regex quantifier are untouched.
//!
//! Justification path is unchanged: report it like any other literal, so the
//! owner can put it in `numeric-provenance.json` with a verbatim quote, or
//! delete it.

use std::sync::LazyLock;

use regex::Regex;

use super::python_stdlib;

/// A quoted digit run, permitting the separators a written number carries.
const NUMBER: &str = "[0-9][0-9_.,]*";

/// `const X: T = "8"`, `static X = '8'`, `let x = \"0.6\"`, `var x = '5'`.
static DECLARED: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(&format!(
        "(?m)(?:const|static|let|var)\\s+[A-Za-z_][A-Za-z0-9_]*\\s*(?::[^=\\n]+)?=\\s*['\\x22]({NUMBER})['\\x22]"
    ))
    .expect("declared-number pattern")
});

/// `"8".parse()`, `'0'.parse::<u64>()`.
static PARSED: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(&format!("['\\x22]({NUMBER})['\\x22]\\s*\\.\\s*parse")).expect("parsed-number pattern")
});

/// `Number('0')`, `int("4194304")`, `float('0.6')`, `parseInt("10")`.
static CONVERTED: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(&format!(
        "(?:Number|int|float|parseInt|parseFloat|BigInt)\\s*\\(\\s*['\\x22]({NUMBER})['\\x22]"
    ))
    .expect("converted-number pattern")
});

/// The capture holding the digits in each pattern above.
const VALUE_GROUP_TEXT: &str = "1";

fn value_group() -> usize {
    VALUE_GROUP_TEXT.parse().unwrap_or_default()
}

pub struct Laundered {
    pub line: usize,
    pub value: String,
    pub form: &'static str,
}

fn collect(text: &str, pattern: &Regex, form: &'static str, out: &mut Vec<Laundered>) {
    let step = python_stdlib::one();
    for found in pattern.captures_iter(text) {
        let Some(value) = found.get(value_group()) else { continue };
        let line = text[..value.start()].matches('\n').count() + step;
        out.push(Laundered {
            line,
            value: value.as_str().to_string(),
            form,
        });
    }
}

/// Numbers laundered through string syntax, in source order by form.
pub fn laundered_numbers(text: &str) -> Vec<Laundered> {
    let mut out = Vec::new();
    collect(text, &DECLARED, "declared as a string constant", &mut out);
    collect(text, &PARSED, "parsed from a string literal", &mut out);
    collect(text, &CONVERTED, "converted from a string literal", &mut out);
    out.sort_by_key(|found| found.line);
    out
}
