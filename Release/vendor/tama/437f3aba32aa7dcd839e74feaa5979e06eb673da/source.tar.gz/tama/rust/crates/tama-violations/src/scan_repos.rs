//! Rust port of `src/violations/scan-repos.mjs`.
//! Multi-target orchestration for the violation scan: resolves
//! --repo / --tree / --owner targets via repo-discovery, scans each
//! repository with the real hook replay, and prints per-repo detail plus a
//! total summary.

use serde::Serialize;
use std::path::Path;

use crate::find_violations::{scan_repo, ScanReport};
use crate::repo_discovery::{resolve_targets, DiscoveryArgs, Problem};
use crate::{homedir, EXIT_USAGE};

#[derive(Debug, Clone)]
pub struct ScanArgs {
    pub repos: Vec<String>,
    pub trees: Vec<String>,
    pub owners: Vec<String>,
    pub me: bool,
    pub hook_path: String,
    pub clone_dir: String,
    pub json: bool,
}

/// Port of `parseScanArgs`. The default hook path is resolved from the real
/// tama root, not a CLI --root value; the default clone dir lives in
/// the user cache so org checkouts never re-enter --tree scans.
pub fn parse_scan_args(argv: &[String], root: &Path) -> Option<ScanArgs> {
    let mut repos = Vec::new();
    let mut trees = Vec::new();
    let mut owners = Vec::new();
    let mut me = false;
    let mut hook_path = root
        .join("shared-hooks")
        .join("pre_write_edit.sh")
        .to_string_lossy()
        .into_owned();
    let mut clone_dir = homedir()
        .join(".cache")
        .join("tama")
        .join("violation-clones")
        .to_string_lossy()
        .into_owned();
    let mut json = false;
    let mut i = 0;
    while i < argv.len() {
        let arg = &argv[i];
        if arg == "--json" {
            json = true;
            i += 1;
            continue;
        }
        if arg == "--me" {
            me = true;
            i += 1;
            continue;
        }
        if arg == "--repo" || arg == "--tree" || arg == "--owner" || arg == "--clone-dir" || arg == "--hook" {
            let value = argv.get(i + 1)?;
            // JS `if (!value) return null` rejects empty-string values too.
            if value.is_empty() {
                return None;
            }
            if arg == "--repo" {
                repos.push(value.clone());
            } else if arg == "--tree" {
                trees.push(value.clone());
            } else if arg == "--owner" {
                owners.push(value.clone());
            } else if arg == "--clone-dir" {
                clone_dir = value.clone();
            } else {
                hook_path = value.clone();
            }
            i += 2;
            continue;
        }
        if !arg.starts_with('-') && repos.is_empty() && trees.is_empty() && owners.is_empty() {
            repos.push(arg.clone());
            i += 1;
            continue;
        }
        return None;
    }
    if repos.is_empty() && trees.is_empty() && owners.is_empty() && !me {
        return None;
    }
    Some(ScanArgs { repos, trees, owners, me, hook_path, clone_dir, json })
}

pub fn print_scan_usage() {
    eprintln!(
        "tama find-violations (--repo <path> | --tree <dir> | --owner <gh-user-or-org>) [...] [--json] [--hook <path>] [--clone-dir <dir>]

Scan repositories for existing violations of the content rules enforced by
the shared pre-write hook (max 300 lines per file, forbidden content patterns,
time-limit and retry bans, provider/key bans, unsubstantiated constants) plus
the max 5 files per folder rule. The scan replays the real hook against every
enumerated file and never modifies scanned repositories. It reports the first
violation per file; re-scan after fixes to surface the rest.

Targets (repeatable, combinable):
  --repo <path>    one repository or directory
  --tree <dir>     discover every Git checkout under a directory tree
                   (named --tree because cli.mjs reserves --root already)
  --owner <login>  every GitHub repo of a user or org (gh CLI); missing
                   checkouts are shallow-cloned into --clone-dir
  --me             the gh-authenticated user plus every org they belong to

Command-gating hooks (browser, CUA, keychain, Git bypass bans) gate shell
commands, not file content, so they stay out of scope."
    );
}

pub fn print_scan_report(report: &ScanReport) {
    println!("find-violations: {}", report.repo);
    println!(
        "enumeration: {}; scanned: {}; skipped: {}; errors: {}",
        report.mode,
        report.scanned_files,
        report.skipped_files.len(),
        report.errors.len()
    );
    for item in &report.skipped_files {
        println!("  skip {} ({})", item.path, item.reason);
    }
    if report.violations.is_empty() {
        println!("no violations found");
    } else {
        // Group by rule, preserving first-occurrence order like a JS Map.
        let mut groups: Vec<(&str, Vec<&crate::find_violations::Violation>)> = Vec::new();
        for violation in &report.violations {
            match groups.iter_mut().find(|(rule, _)| *rule == violation.rule) {
                Some((_, list)) => list.push(violation),
                None => groups.push((violation.rule.as_str(), vec![violation])),
            }
        }
        for (rule, list) in &groups {
            println!("\n{} — {} hit(s)", rule, list.len());
            for violation in list {
                println!("  {}\n    {}", violation.path, violation.message);
            }
        }
        println!("\nviolations: {}", report.violations.len());
    }
    for error in &report.errors {
        eprintln!("ERROR {}: {}", error.path, error.message);
    }
}

pub fn problem_label(problem: &Problem) -> String {
    match &problem.repo {
        Some(repo) if !repo.is_empty() => format!("{} {}", problem.owner, repo),
        _ => problem.owner.clone(),
    }
}

pub fn print_aggregate(reports: &[ScanReport], problems: &[Problem]) {
    for report in reports {
        print_scan_report(report);
        println!();
    }
    let mut total = 0usize;
    for report in reports {
        total += report.violations.len();
    }
    println!("== summary ==");
    for report in reports {
        println!(
            "{} — violations: {}, errors: {}",
            report.repo,
            report.violations.len(),
            report.errors.len()
        );
    }
    for problem in problems {
        println!("PROBLEM {}: {}", problem_label(problem), problem.error);
    }
    println!(
        "repositories: {}, violations: {}, problems: {}",
        reports.len(),
        total,
        problems.len()
    );
}

#[derive(Serialize)]
pub struct ScanJsonOutput<'a> {
    pub repos: &'a [ScanReport],
    pub problems: &'a [Problem],
    pub totals: Totals,
}

#[derive(Serialize)]
pub struct Totals {
    pub repositories: usize,
    pub violations: usize,
    pub problems: usize,
}

/// The document `--json` prints, also served by the backend.
pub fn scan_json_document<'a>(reports: &'a [ScanReport], problems: &'a [Problem]) -> ScanJsonOutput<'a> {
    let total = reports.iter().map(|report| report.violations.len()).sum();
    ScanJsonOutput {
        repos: reports,
        problems,
        totals: Totals {
            repositories: reports.len(),
            violations: total,
            problems: problems.len(),
        },
    }
}

/// The scan half of main(): resolves the targets and scans each repository,
/// reporting progress through `log` (main prints to stderr; the serve
/// backend streams it). Returns the per-repo reports and the discovery
/// problems.
pub fn run_scan(args: &ScanArgs, mut log: impl FnMut(&str)) -> (Vec<ScanReport>, Vec<Problem>) {
    let resolved = resolve_targets(&DiscoveryArgs {
        repos: &args.repos,
        trees: &args.trees,
        owners: &args.owners,
        me: args.me,
        clone_dir: Path::new(&args.clone_dir),
    });
    if resolved.targets.is_empty() {
        return (Vec::new(), resolved.problems);
    }
    log(&format!(
        "scanning {} repositor{}...",
        resolved.targets.len(),
        if resolved.targets.len() == 1 { "y" } else { "ies" }
    ));
    let mut reports = Vec::new();
    for target in &resolved.targets {
        log(&format!("[{}/{}] {}", reports.len() + 1, resolved.targets.len(), target.path));
        let mut report = scan_repo(Path::new(&target.path), Path::new(&args.hook_path));
        report.via = Some(target.via.clone());
        reports.push(report);
    }
    (reports, resolved.problems)
}

pub fn main(args: &[String], root: &Path) -> i32 {
    let args = match parse_scan_args(args, root) {
        Some(args) => args,
        None => {
            print_scan_usage();
            return EXIT_USAGE;
        }
    };
    if !Path::new(&args.hook_path).exists() {
        eprintln!("hook not found: {}", args.hook_path);
        return EXIT_USAGE;
    }
    for repo in &args.repos {
        if !Path::new(repo).exists() {
            eprintln!("repo not found: {}", repo);
            return EXIT_USAGE;
        }
    }
    for tree in &args.trees {
        if !Path::new(tree).exists() {
            eprintln!("tree not found: {}", tree);
            return EXIT_USAGE;
        }
    }
    let (reports, problems) = run_scan(&args, |line| eprintln!("{line}"));
    if reports.is_empty() {
        for problem in &problems {
            eprintln!("PROBLEM {}: {}", problem_label(problem), problem.error);
        }
        eprintln!("no repositories found");
        return if problems.is_empty() { 0 } else { 1 };
    }
    let mut total = 0usize;
    for report in &reports {
        total += report.violations.len();
    }
    if args.json {
        let output = scan_json_document(&reports, &problems);
        crate::write_json_line(&serde_json::to_string_pretty(&output).unwrap_or_default());
    } else {
        print_aggregate(&reports, &problems);
    }
    if total > 0 || !problems.is_empty() {
        1
    } else {
        0
    }
}
