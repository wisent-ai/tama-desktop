//! Ordered JSON value with `JSON.parse` / `JSON.stringify` semantics.
//!
//! `serde_json::Map` (without `preserve_order`) sorts object keys, while JS
//! objects preserve insertion/document order and that order is observable in
//! the harness output (`console.error(JSON.stringify(..., null, 2))`). This
//! module therefore implements its own value type, parser (document order
//! preserved) and serializers (compact and 2-space pretty) that reproduce
//! `JSON.stringify` byte-for-byte for the data handled here.

/// JSON value. Numbers are stored preformatted in JS `Number#toString` form.
#[derive(Debug, Clone, PartialEq)]
pub enum Json {
    Null,
    Bool(bool),
    Num(String),
    Str(String),
    Arr(Vec<Json>),
    Obj(Vec<(String, Json)>),
}

impl Json {
    pub fn num_i64(value: i64) -> Json {
        Json::Num(value.to_string())
    }

    pub fn num_usize(value: usize) -> Json {
        Json::Num(value.to_string())
    }

    /// `JSON.stringify` number semantics: non-finite values become `null`.
    pub fn num_f64(value: f64) -> Json {
        Json::Num(js_number_to_string(value))
    }

    pub fn obj(entries: Vec<(String, Json)>) -> Json {
        Json::Obj(entries)
    }

    pub fn arr(values: Vec<Json>) -> Json {
        Json::Arr(values)
    }

    pub fn str(value: impl Into<String>) -> Json {
        Json::Str(value.into())
    }

    /// `value?.[key]` — `None` models JS `undefined`.
    pub fn get(&self, key: &str) -> Option<&Json> {
        match self {
            Json::Obj(entries) => entries
                .iter()
                .find(|(k, _)| k == key)
                .map(|(_, v)| v),
            _ => None,
        }
    }

    /// `value?.[index]`.
    pub fn at(&self, index: usize) -> Option<&Json> {
        match self {
            Json::Arr(items) => items.get(index),
            _ => None,
        }
    }

    pub fn as_str(&self) -> Option<&str> {
        match self {
            Json::Str(s) => Some(s),
            _ => None,
        }
    }

    pub fn as_array(&self) -> Option<&[Json]> {
        match self {
            Json::Arr(items) => Some(items),
            _ => None,
        }
    }

    pub fn as_object(&self) -> Option<&[(String, Json)]> {
        match self {
            Json::Obj(entries) => Some(entries),
            _ => None,
        }
    }

    /// Number value; strings are NOT coerced (use [`js_number_value`]).
    pub fn as_f64(&self) -> Option<f64> {
        match self {
            Json::Num(text) => text.parse::<f64>().ok(),
            _ => None,
        }
    }

    /// JS truthiness.
    pub fn truthy(&self) -> bool {
        match self {
            Json::Null => false,
            Json::Bool(b) => *b,
            Json::Num(text) => text.parse::<f64>().map(|f| f != 0.0).unwrap_or(true),
            Json::Str(s) => !s.is_empty(),
            Json::Arr(_) | Json::Obj(_) => true,
        }
    }

    /// JS `String(value)` for a present value.
    pub fn js_string(&self) -> String {
        match self {
            Json::Null => "null".to_string(),
            Json::Bool(b) => b.to_string(),
            Json::Num(text) => text.clone(),
            Json::Str(s) => s.clone(),
            Json::Arr(items) => items
                .iter()
                .map(|item| match item {
                    Json::Null => String::new(),
                    other => other.js_string(),
                })
                .collect::<Vec<_>>()
                .join(","),
            Json::Obj(_) => "[object Object]".to_string(),
        }
    }

    /// Object key assignment with JS `{...obj, key: value}` spread semantics:
    /// an existing key keeps its position and gets the new value; a new key is
    /// appended.
    pub fn set(&mut self, key: &str, value: Json) {
        if let Json::Obj(entries) = self {
            if let Some(entry) = entries.iter_mut().find(|(k, _)| k == key) {
                entry.1 = value;
            } else {
                entries.push((key.to_string(), value));
            }
        }
    }

    /// Remove an object key (models a spread assigning `undefined`, which
    /// behaves like an absent key for lookups and `JSON.stringify`).
    pub fn remove(&mut self, key: &str) {
        if let Json::Obj(entries) = self {
            entries.retain(|(k, _)| k != key);
        }
    }

    /// `JSON.stringify(value)` (compact).
    pub fn to_compact(&self) -> String {
        let mut out = String::new();
        write_compact(self, &mut out);
        out
    }

    /// `JSON.stringify(value, null, 2)`.
    pub fn to_pretty2(&self) -> String {
        let mut out = String::new();
        write_pretty(self, 0, &mut out);
        out
    }
}

/// `String(value)` where the value may be absent (`undefined`).
pub fn js_string_opt(value: Option<&Json>) -> String {
    match value {
        None => "undefined".to_string(),
        Some(v) => v.js_string(),
    }
}

/// `String(value || '')` where the value may be absent.
pub fn js_string_or_empty(value: Option<&Json>) -> String {
    match value {
        Some(v) if v.truthy() => v.js_string(),
        _ => String::new(),
    }
}

/// JS `a || b`: first truthy wins, otherwise the last operand.
pub fn js_or2<'a>(a: Option<&'a Json>, b: Option<&'a Json>) -> Option<&'a Json> {
    match a {
        Some(v) if v.truthy() => a,
        _ => b,
    }
}

/// JS `a || b || c`.
pub fn js_or3<'a>(a: Option<&'a Json>, b: Option<&'a Json>, c: Option<&'a Json>) -> Option<&'a Json> {
    js_or2(js_or2(a, b), c)
}

/// JS `Number(value)` for a JSON value (`undefined` -> NaN).
pub fn js_number_value(value: Option<&Json>) -> f64 {
    match value {
        None | Some(Json::Null) => {
            // Number(undefined) = NaN; Number(null) = 0.
            match value {
                None => f64::NAN,
                _ => 0.0,
            }
        }
        Some(Json::Bool(b)) => {
            if *b {
                1.0
            } else {
                0.0
            }
        }
        Some(Json::Num(text)) => text.parse::<f64>().unwrap_or(f64::NAN),
        Some(Json::Str(s)) => js_number_str(s),
        Some(Json::Arr(_)) | Some(Json::Obj(_)) => f64::NAN,
    }
}

/// JS `Number(string)` for the decimal subset relevant here.
fn js_number_str(s: &str) -> f64 {
    let t = s.trim();
    if t.is_empty() {
        return 0.0;
    }
    match t {
        "Infinity" | "+Infinity" => f64::INFINITY,
        "-Infinity" => f64::NEG_INFINITY,
        _ => t.parse::<f64>().unwrap_or(f64::NAN),
    }
}

/// JS `Number#toString` / `JSON.stringify` for an f64. Non-finite values
/// stringify as `null` (matching `JSON.stringify`).
pub fn js_number_to_string(f: f64) -> String {
    if f.is_nan() || f.is_infinite() {
        return "null".to_string();
    }
    if f == 0.0 {
        return "0".to_string(); // also covers -0
    }
    let a = f.abs();
    if f.fract() == 0.0 && a < 1e21 {
        return format!("{f:.0}");
    }
    if a >= 1e21 || a < 1e-6 {
        // Rust prints "1.5e21"; JS prints "1.5e+21".
        let s = format!("{f:e}");
        return match s.split_once('e') {
            Some((m, e)) if !e.starts_with('-') => format!("{m}e+{e}"),
            _ => s,
        };
    }
    format!("{f}")
}

fn write_json_string(s: &str, out: &mut String) {
    out.push('"');
    for c in s.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\u{8}' => out.push_str("\\b"),
            '\u{c}' => out.push_str("\\f"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            c if (c as u32) < 0x20 => {
                out.push_str(&format!("\\u{:04x}", c as u32));
            }
            c => out.push(c),
        }
    }
    out.push('"');
}

fn write_compact(value: &Json, out: &mut String) {
    match value {
        Json::Null => out.push_str("null"),
        Json::Bool(b) => out.push_str(if *b { "true" } else { "false" }),
        Json::Num(text) => out.push_str(text),
        Json::Str(s) => write_json_string(s, out),
        Json::Arr(items) => {
            out.push('[');
            for (i, item) in items.iter().enumerate() {
                if i > 0 {
                    out.push(',');
                }
                write_compact(item, out);
            }
            out.push(']');
        }
        Json::Obj(entries) => {
            out.push('{');
            for (i, (key, val)) in entries.iter().enumerate() {
                if i > 0 {
                    out.push(',');
                }
                write_json_string(key, out);
                out.push(':');
                write_compact(val, out);
            }
            out.push('}');
        }
    }
}

fn push_indent(out: &mut String, indent: usize) {
    for _ in 0..indent {
        out.push(' ');
    }
}

fn write_pretty(value: &Json, indent: usize, out: &mut String) {
    match value {
        Json::Arr(items) if !items.is_empty() => {
            out.push('[');
            for (i, item) in items.iter().enumerate() {
                if i > 0 {
                    out.push(',');
                }
                out.push('\n');
                push_indent(out, indent + 2);
                write_pretty(item, indent + 2, out);
            }
            out.push('\n');
            push_indent(out, indent);
            out.push(']');
        }
        Json::Obj(entries) if !entries.is_empty() => {
            out.push('{');
            for (i, (key, val)) in entries.iter().enumerate() {
                if i > 0 {
                    out.push(',');
                }
                out.push('\n');
                push_indent(out, indent + 2);
                write_json_string(key, out);
                out.push_str(": ");
                write_pretty(val, indent + 2, out);
            }
            out.push('\n');
            push_indent(out, indent);
            out.push('}');
        }
        other => write_compact(other, out),
    }
}

// ---------------------------------------------------------------------------
// parser (document order preserved, like `JSON.parse`)
// ---------------------------------------------------------------------------

pub fn parse(text: &str) -> Result<Json, String> {
    let mut parser = Parser {
        bytes: text.as_bytes(),
        pos: 0,
        text,
    };
    parser.skip_whitespace();
    let value = parser.parse_value()?;
    parser.skip_whitespace();
    if parser.pos != parser.bytes.len() {
        return Err(format!("Unexpected token at position {}", parser.pos));
    }
    Ok(value)
}

struct Parser<'a> {
    bytes: &'a [u8],
    text: &'a str,
    pos: usize,
}

impl<'a> Parser<'a> {
    fn skip_whitespace(&mut self) {
        while self.pos < self.bytes.len()
            && matches!(self.bytes[self.pos], b' ' | b'\t' | b'\n' | b'\r')
        {
            self.pos += 1;
        }
    }

    fn peek(&self) -> Option<u8> {
        self.bytes.get(self.pos).copied()
    }

    fn expect(&mut self, byte: u8) -> Result<(), String> {
        if self.peek() == Some(byte) {
            self.pos += 1;
            Ok(())
        } else {
            Err(format!("Expected '{}' at position {}", byte as char, self.pos))
        }
    }

    fn parse_value(&mut self) -> Result<Json, String> {
        match self.peek() {
            Some(b'{') => self.parse_object(),
            Some(b'[') => self.parse_array(),
            Some(b'"') => Ok(Json::Str(self.parse_string()?)),
            Some(b't') => self.parse_lit("true", Json::Bool(true)),
            Some(b'f') => self.parse_lit("false", Json::Bool(false)),
            Some(b'n') => self.parse_lit("null", Json::Null),
            Some(b'-') | Some(b'0'..=b'9') => self.parse_number(),
            _ => Err(format!("Unexpected token at position {}", self.pos)),
        }
    }

    fn parse_lit(&mut self, lit: &str, value: Json) -> Result<Json, String> {
        if self.text[self.pos..].starts_with(lit) {
            self.pos += lit.len();
            Ok(value)
        } else {
            Err(format!("Unexpected token at position {}", self.pos))
        }
    }

    fn parse_number(&mut self) -> Result<Json, String> {
        let start = self.pos;
        if self.peek() == Some(b'-') {
            self.pos += 1;
        }
        while matches!(self.peek(), Some(b'0'..=b'9')) {
            self.pos += 1;
        }
        if self.peek() == Some(b'.') {
            self.pos += 1;
            while matches!(self.peek(), Some(b'0'..=b'9')) {
                self.pos += 1;
            }
        }
        if matches!(self.peek(), Some(b'e') | Some(b'E')) {
            self.pos += 1;
            if matches!(self.peek(), Some(b'+') | Some(b'-')) {
                self.pos += 1;
            }
            while matches!(self.peek(), Some(b'0'..=b'9')) {
                self.pos += 1;
            }
        }
        let raw = &self.text[start..self.pos];
        let number: f64 = raw
            .parse()
            .map_err(|_| format!("Invalid number at position {start}"))?;
        // `JSON.parse` + `JSON.stringify` normalizes the number text.
        Ok(Json::Num(js_number_to_string(number)))
    }

    fn parse_string(&mut self) -> Result<String, String> {
        self.expect(b'"')?;
        let mut out = String::new();
        loop {
            let byte = match self.peek() {
                Some(b) => b,
                None => return Err("Unterminated string".to_string()),
            };
            match byte {
                b'"' => {
                    self.pos += 1;
                    return Ok(out);
                }
                b'\\' => {
                    self.pos += 1;
                    let esc = self.peek().ok_or("Unterminated escape")?;
                    self.pos += 1;
                    match esc {
                        b'"' => out.push('"'),
                        b'\\' => out.push('\\'),
                        b'/' => out.push('/'),
                        b'b' => out.push('\u{8}'),
                        b'f' => out.push('\u{c}'),
                        b'n' => out.push('\n'),
                        b'r' => out.push('\r'),
                        b't' => out.push('\t'),
                        b'u' => {
                            let first = self.parse_hex4()?;
                            let ch = if (0xD800..0xDC00).contains(&first) {
                                // High surrogate: try to pair with a following
                                // low surrogate like JS does.
                                if self.peek() == Some(b'\\')
                                    && self.bytes.get(self.pos + 1) == Some(&b'u')
                                {
                                    let save = self.pos;
                                    self.pos += 2;
                                    let second = self.parse_hex4()?;
                                    if (0xDC00..0xE000).contains(&second) {
                                        let c = 0x10000
                                            + ((first - 0xD800) << 10)
                                            + (second - 0xDC00);
                                        char::from_u32(c).unwrap_or('\u{FFFD}')
                                    } else {
                                        self.pos = save;
                                        '\u{FFFD}'
                                    }
                                } else {
                                    '\u{FFFD}'
                                }
                            } else if (0xDC00..0xE000).contains(&first) {
                                '\u{FFFD}'
                            } else {
                                char::from_u32(first).unwrap_or('\u{FFFD}')
                            };
                            out.push(ch);
                        }
                        _ => return Err(format!("Bad escape at position {}", self.pos)),
                    }
                }
                0x00..=0x1F => return Err(format!("Bad control character at position {}", self.pos)),
                _ => {
                    // Consume one UTF-8 encoded char.
                    let ch_len = utf8_len(byte);
                    let end = (self.pos + ch_len).min(self.text.len());
                    out.push_str(&self.text[self.pos..end]);
                    self.pos = end;
                }
            }
        }
    }

    fn parse_hex4(&mut self) -> Result<u32, String> {
        if self.pos + 4 > self.bytes.len() {
            return Err("Bad \\u escape".to_string());
        }
        let hex = &self.text[self.pos..self.pos + 4];
        let value = u32::from_str_radix(hex, 16).map_err(|_| "Bad \\u escape".to_string())?;
        self.pos += 4;
        Ok(value)
    }

    fn parse_array(&mut self) -> Result<Json, String> {
        self.expect(b'[')?;
        let mut items = Vec::new();
        self.skip_whitespace();
        if self.peek() == Some(b']') {
            self.pos += 1;
            return Ok(Json::Arr(items));
        }
        loop {
            self.skip_whitespace();
            items.push(self.parse_value()?);
            self.skip_whitespace();
            match self.peek() {
                Some(b',') => self.pos += 1,
                Some(b']') => {
                    self.pos += 1;
                    return Ok(Json::Arr(items));
                }
                _ => return Err(format!("Expected ',' or ']' at position {}", self.pos)),
            }
        }
    }

    fn parse_object(&mut self) -> Result<Json, String> {
        self.expect(b'{')?;
        let mut entries = Vec::new();
        self.skip_whitespace();
        if self.peek() == Some(b'}') {
            self.pos += 1;
            return Ok(Json::Obj(entries));
        }
        loop {
            self.skip_whitespace();
            let key = self.parse_string()?;
            self.skip_whitespace();
            self.expect(b':')?;
            self.skip_whitespace();
            let value = self.parse_value()?;
            // JS object semantics: a duplicate key keeps its first position.
            if let Some(entry) = entries.iter_mut().find(|(k, _)| *k == key) {
                entry.1 = value;
            } else {
                entries.push((key, value));
            }
            self.skip_whitespace();
            match self.peek() {
                Some(b',') => self.pos += 1,
                Some(b'}') => {
                    self.pos += 1;
                    return Ok(Json::Obj(entries));
                }
                _ => return Err(format!("Expected ',' or '}}' at position {}", self.pos)),
            }
        }
    }
}

fn utf8_len(first: u8) -> usize {
    if first < 0x80 {
        1
    } else if first >> 5 == 0b110 {
        2
    } else if first >> 4 == 0b1110 {
        3
    } else {
        4
    }
}

/// Convert a `serde_json::Value` (from the tama-core boundary) into `Json`.
/// Object key order is whatever the `serde_json::Map` holds (sorted without
/// `preserve_order`); only used for values whose order is not observable.
pub fn from_serde(value: &serde_json::Value) -> Json {
    match value {
        serde_json::Value::Null => Json::Null,
        serde_json::Value::Bool(b) => Json::Bool(*b),
        serde_json::Value::Number(n) => Json::Num(js_number_to_string(n.as_f64().unwrap_or(f64::NAN))),
        serde_json::Value::String(s) => Json::Str(s.clone()),
        serde_json::Value::Array(items) => Json::Arr(items.iter().map(from_serde).collect()),
        serde_json::Value::Object(map) => Json::Obj(
            map.iter()
                .map(|(k, v)| (k.clone(), from_serde(v)))
                .collect(),
        ),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn roundtrip_preserves_order() {
        let parsed = parse("{\"b\":1,\"a\":[\"x\",null,true,1.5]}").unwrap();
        assert_eq!(parsed.to_compact(), "{\"b\":1,\"a\":[\"x\",null,true,1.5]}");
    }

    #[test]
    fn pretty_matches_json_stringify() {
        let value = Json::obj(vec![
            ("ok".to_string(), Json::Bool(true)),
            ("empty".to_string(), Json::obj(vec![])),
            ("arr".to_string(), Json::arr(vec![Json::num_i64(1)])),
        ]);
        assert_eq!(
            value.to_pretty2(),
            "{\n  \"ok\": true,\n  \"empty\": {},\n  \"arr\": [\n    1\n  ]\n}"
        );
    }

    #[test]
    fn numbers_match_js() {
        assert_eq!(js_number_to_string(0.0), "0");
        assert_eq!(js_number_to_string(45.0), "45");
        assert_eq!(js_number_to_string(1e21), "1e+21");
        assert_eq!(js_number_to_string(1.5e-7), "1.5e-7");
        assert_eq!(js_number_to_string(0.1), "0.1");
    }
}
