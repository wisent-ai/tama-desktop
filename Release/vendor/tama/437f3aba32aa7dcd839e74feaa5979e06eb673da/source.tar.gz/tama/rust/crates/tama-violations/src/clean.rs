//! Rust port of `src/violations/clean.mjs`.
//! Violation cleaner ("gate"): scans target repositories with the real hook
//! replay, hands the violation report to ONE headless model agent per
//! repository per round, then re-scans. Repeats until clean or out of rounds.
//! Kill switch: TAMA_CLEAN_DISABLED=1. Test seam: TAMA_CLEAN_AGENT_CMD
//! replaces the model spawn. Audit journal: state/clean-journal.jsonl;
//! per-repo mkdir locks in state/clean-locks/.

use serde::Serialize;
use sha2::{Digest, Sha256};
use std::io::Read;
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::time::{Duration, Instant};

use crate::find_violations::{
    detect_gaming, is_ignored, read_ignore_file, scan_repo, Finding, Violation,
};
use crate::repo_discovery::{resolve_targets, DiscoveryArgs, Problem};
use crate::scan_repos::{parse_scan_args, ScanArgs};
use crate::{js_num, js_number, repo_root, EXIT_USAGE};

const MODELS: [&str; 2] = ["codex", "kimi"];
const AGENT_BUDGET_MS: u64 = 3_600_000;
const GENERATED_PATHS: [&str; 3] = [
    "package-lock.json",
    "shared-hooks/registry.json",
    "shared-hooks/catalog-metadata.json",
];

/// JS `stateDir()` = `process.env.TAMA_CLEAN_STATE_DIR || join(repoRoot(),
/// 'state')`: the desktop backend serves from a read-only release directory,
/// so journals and locks must honor the override.
fn state_dir(root: &Path) -> PathBuf {
    if let Ok(dir) = std::env::var("TAMA_CLEAN_STATE_DIR") {
        if !dir.is_empty() {
            return PathBuf::from(dir);
        }
    }
    root.join("state")
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct JournalRound<'a> {
    at: String,
    repo: &'a str,
    round: i64,
    model: &'a str,
    agent_exit: Option<i32>,
    agent_signal: Option<String>,
    violations: usize,
    gaming: &'a [Finding],
}

#[derive(Serialize)]
struct JournalDone<'a> {
    at: String,
    repo: &'a str,
    done: bool,
    clean: bool,
    before: usize,
    after: usize,
}

fn journal(root: &Path, entry: &impl Serialize) {
    let dir = state_dir(root);
    let _ = std::fs::create_dir_all(&dir);
    if let Ok(mut file) = std::fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(dir.join("clean-journal.jsonl"))
    {
        use std::io::Write;
        let _ = writeln!(file, "{}", serde_json::to_string(entry).unwrap_or_default());
    }
}

fn lock_path_for(root: &Path, repo: &str) -> PathBuf {
    let digest = Sha256::digest(repo.as_bytes());
    let hex: String = digest.iter().map(|byte| format!("{:02x}", byte)).collect();
    state_dir(root).join("clean-locks").join(&hex[..16])
}

#[derive(Debug, Clone)]
pub struct CleanArgs {
    pub base: ScanArgs,
    pub model: String,
    pub max_rounds: f64,
    pub dry_run: bool,
    pub skip: Vec<String>,
    pub note: Option<String>,
}

/// Port of `parseCleanArgs`: clean-specific flags are peeled off first, the
/// rest goes through the shared scan-target parser.
pub fn parse_clean_args(argv: &[String], root: &Path) -> Option<CleanArgs> {
    let mut rest = Vec::new();
    let mut model = "codex".to_string();
    let mut max_rounds = 3.0f64;
    let mut dry_run = false;
    let mut note = None;
    let mut skip = Vec::new();
    let mut i = 0;
    while i < argv.len() {
        let arg = &argv[i];
        if arg == "--dry-run" {
            dry_run = true;
            i += 1;
            continue;
        }
        if arg == "--model" || arg == "--max-rounds" || arg == "--skip" || arg == "--note" {
            let value = argv.get(i + 1)?;
            // JS `if (!value) return null` rejects empty-string values too.
            if value.is_empty() {
                return None;
            }
            if arg == "--model" {
                model = value.clone();
            } else if arg == "--skip" {
                skip.push(value.clone());
            } else if arg == "--note" {
                note = Some(value.clone());
            } else {
                max_rounds = js_number(value);
            }
            i += 2;
            continue;
        }
        rest.push(arg.clone());
        i += 1;
    }
    if !MODELS.contains(&model.as_str()) {
        return None;
    }
    // JS `!(maxRounds >= 1)`: NaN (e.g. from `--max-rounds abc`) fails here.
    if !(max_rounds >= 1.0) {
        return None;
    }
    let base = parse_scan_args(&rest, root)?;
    Some(CleanArgs { base, model, max_rounds, dry_run, skip, note })
}

fn is_actionable(violation: &Violation, skip: &[String], ignore_entries: &[String]) -> bool {
    if GENERATED_PATHS.contains(&violation.path.as_str()) {
        return false;
    }
    if is_ignored(&violation.path, ignore_entries) {
        return false;
    }
    for fragment in skip {
        if violation.path.contains(fragment.as_str()) {
            return false;
        }
    }
    true
}

pub struct BriefParams<'a> {
    pub repo: &'a str,
    pub violations: &'a [Violation],
    pub round: i64,
    pub max_rounds: f64,
    pub skip: &'a [String],
    pub note: Option<&'a str>,
    pub feedback: &'a [String],
}

/// Port of `buildBrief`: the exact prompt handed to the cleaning agent.
pub fn build_brief(params: &BriefParams) -> String {
    let list = if params.violations.is_empty() {
        "(no scanner violations; follow the additional instruction below)".to_string()
    } else {
        params
            .violations
            .iter()
            .map(|v| format!("- {} — {}", v.path, v.message))
            .collect::<Vec<_>>()
            .join("\n")
    };
    let data_url_style = "data:text/javascript";
    let mut lines: Vec<String> = vec![
        format!(
            "You are cleaning the repository at {} so it passes the enforced hook content rules.",
            params.repo
        ),
        format!(
            "Round {} of {}. The scanner reports {} violation(s):",
            params.round,
            js_num(params.max_rounds),
            params.violations.len()
        ),
        String::new(),
        list,
        String::new(),
        "Rules being enforced (checked by replaying the real pre-write hook):".to_string(),
        "- max 300 lines per file: split longer files into smaller modules.".to_string(),
        "- max 5 files per folder: move files into sub-folders or consolidate (folders matching"
            .to_string(),
        "  supabase/migrations, node_modules, .git, __pycache__, tests, migrations are exempt)."
            .to_string(),
        "- forbidden content patterns, time-limit and retry bans, provider/key bans, and"
            .to_string(),
        "  unsubstantiated numeric constants (each violation message names its rule).".to_string(),
        String::new(),
        "Do not game the rules:".to_string(),
        "- Splits must produce REAL modules with ordinary imports/exports between them. Never"
            .to_string(),
        format!(
            "  glue sources into a runtime blob: no {} imports, no eval, no globalThis",
            data_url_style
        ),
        "  smuggling of shared symbols, no invented pseudo-extensions like .source/.part/.inc."
            .to_string(),
        "- Do not rename files to dodge hook gates (for example dropping \"test\" from a test"
            .to_string(),
        "  file name). Comply with the gates instead (file/test justifications).".to_string(),
        "- Put new files in semantically matching folders — read what a folder holds first;"
            .to_string(),
        "  create a new well-named subfolder when nothing matches.".to_string(),
        "- Module names must say what is inside; no near-duplicate names in one folder."
            .to_string(),
        String::new(),
        "How to fix:".to_string(),
        "- Fix in place: split long files into focused modules, move files into sub-folders,"
            .to_string(),
        "  rewrite flagged constructs. Preserve behavior; do not delete features.".to_string(),
        "- Creating a file may require a 50+ word justification entry under its absolute path in"
            .to_string(),
        "  ~/.shared-hooks/file_justifications.json — add it first when the tooling asks for it."
            .to_string(),
        "- Do NOT commit, push, or create branches. Leave all changes in the working tree."
            .to_string(),
        "- Do NOT touch .git/, generated files (package-lock.json, shared-hooks/registry.json,"
            .to_string(),
        "  shared-hooks/catalog-metadata.json), or anything outside this repo.".to_string(),
    ];
    if !params.skip.is_empty() {
        lines.push(format!(
            "Explicitly out of scope, do not touch: {}.",
            params.skip.join(", ")
        ));
    }
    if !params.feedback.is_empty() {
        lines.push(String::new());
        lines.push("Your previous attempt was rejected for rule-gaming:".to_string());
        lines.extend(params.feedback.iter().cloned());
        lines.push("Redo it properly: real modules, honest names, correct folders.".to_string());
    }
    if let Some(note) = params.note {
        lines.push(String::new());
        lines.push("Additional instruction from the operator:".to_string());
        lines.push(note.to_string());
    }
    lines.push("- When done, print one summary line per file you changed.".to_string());
    lines.join("\n")
}

struct AgentRun {
    status: Option<i32>,
    signal: Option<String>,
}

/// Maps a Unix signal number to the name Node reports in `result.signal`.
fn signal_name(signal: i32) -> String {
    match signal {
        1 => "SIGHUP",
        2 => "SIGINT",
        3 => "SIGQUIT",
        4 => "SIGILL",
        5 => "SIGTRAP",
        6 => "SIGABRT",
        7 => "SIGEMT",
        8 => "SIGFPE",
        9 => "SIGKILL",
        10 => "SIGBUS",
        11 => "SIGSEGV",
        12 => "SIGSYS",
        13 => "SIGPIPE",
        14 => "SIGALRM",
        15 => "SIGTERM",
        16 => "SIGURG",
        17 => "SIGSTOP",
        18 => "SIGTSTP",
        19 => "SIGCONT",
        20 => "SIGCHLD",
        21 => "SIGTTIN",
        22 => "SIGTTOU",
        24 => "SIGXCPU",
        25 => "SIGXFSZ",
        26 => "SIGVTALRM",
        27 => "SIGPROF",
        28 => "SIGWINCH",
        29 => "SIGIO",
        30 => "SIGUSR1",
        31 => "SIGUSR2",
        other => return format!("SIG{}", other),
    }
    .to_string()
}

/// spawnSync with the 1h agent budget. Stdout/stderr are drained on threads
/// (Node buffers them up to maxBuffer; nothing consumes them here either).
/// On timeout Node kills with SIGTERM and reports `{ status: null, signal:
/// 'SIGTERM' }`; std can only send SIGKILL, so the kill is harder but the
/// journal-facing result is kept identical to the JS one.
fn run_with_budget(cmd: &mut Command) -> AgentRun {
    cmd.stdin(Stdio::null()).stdout(Stdio::piped()).stderr(Stdio::piped());
    let mut child = match cmd.spawn() {
        Ok(child) => child,
        // Node's spawnSync surfaces a spawn error as status null / signal null.
        Err(_) => return AgentRun { status: None, signal: None },
    };
    fn drain_pipe<R: Read + Send + 'static>(
        pipe: Option<R>,
    ) -> Option<std::thread::JoinHandle<Vec<u8>>> {
        pipe.map(|mut reader| {
            std::thread::spawn(move || {
                let mut buffer = Vec::new();
                let _ = reader.read_to_end(&mut buffer);
                buffer
            })
        })
    }
    let stdout_handle = drain_pipe(child.stdout.take());
    let stderr_handle = drain_pipe(child.stderr.take());
    let budget = Duration::from_millis(AGENT_BUDGET_MS);
    let start = Instant::now();
    let mut timed_out = false;
    let status = loop {
        match child.try_wait() {
            Ok(Some(status)) => break Some(status),
            Ok(None) => {
                if start.elapsed() >= budget {
                    timed_out = true;
                    let _ = child.kill();
                    break child.wait().ok();
                }
                std::thread::sleep(Duration::from_millis(50));
            }
            Err(_) => break None,
        }
    };
    if let Some(handle) = stdout_handle {
        let _ = handle.join();
    }
    if let Some(handle) = stderr_handle {
        let _ = handle.join();
    }
    if timed_out {
        return AgentRun { status: None, signal: Some("SIGTERM".to_string()) };
    }
    match status {
        Some(status) => match status.code() {
            Some(code) => AgentRun { status: Some(code), signal: None },
            None => {
                #[cfg(unix)]
                {
                    use std::os::unix::process::ExitStatusExt;
                    AgentRun {
                        status: None,
                        signal: status.signal().map(signal_name),
                    }
                }
                #[cfg(not(unix))]
                {
                    AgentRun { status: None, signal: None }
                }
            }
        },
        None => AgentRun { status: None, signal: None },
    }
}

/// Port of `spawnAgent`: the TAMA_CLEAN_AGENT_CMD seam replaces the model
/// spawn; otherwise `kimi -p <brief> --yolo` or `codex exec
/// --skip-git-repo-check --sandbox workspace-write <brief>`.
fn spawn_agent(model: &str, brief: &str, repo: &str) -> AgentRun {
    if let Ok(seam) = std::env::var("TAMA_CLEAN_AGENT_CMD") {
        if !seam.is_empty() {
            let mut cmd = Command::new("/bin/sh");
            cmd.args(["-c", seam.as_str()])
                .current_dir(repo)
                .env("TAMA_CLEAN_BRIEF", brief);
            return run_with_budget(&mut cmd);
        }
    }
    if model == "kimi" {
        let mut cmd = Command::new("kimi");
        cmd.args(["-p", brief, "--yolo"]).current_dir(repo);
        run_with_budget(&mut cmd)
    } else {
        let mut cmd = Command::new("codex");
        cmd.args(["exec", "--skip-git-repo-check", "--sandbox", "workspace-write", brief])
            .current_dir(repo);
        run_with_budget(&mut cmd)
    }
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Round {
    pub round: i64,
    /// Kept as an explicit JSON null on timeout/signal, like the JS
    /// `{ agentExit: run.status }` with `status === null`.
    pub agent_exit: Option<i32>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub rejected: Option<String>,
    pub remaining: usize,
}

/// Result of one `cleanRepo` call. The JSON shape mirrors the three JS
/// object literals: dry-run `{repo, dryRun, violations, actionable}`, locked
/// `{repo, locked, violations, actionable}`, and a full run `{repo, clean,
/// before, after, remaining, rounds}`.
#[derive(Debug, Clone, Default, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CleanResult {
    pub repo: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub dry_run: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub locked: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub clean: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub violations: Option<usize>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub actionable: Option<usize>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub before: Option<usize>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub after: Option<usize>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub remaining: Option<Vec<Violation>>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub rounds: Option<Vec<Round>>,
}

pub struct CleanParams<'a> {
    pub repo: &'a str,
    pub hook_path: &'a str,
    pub model: &'a str,
    pub max_rounds: f64,
    pub dry_run: bool,
    pub skip: &'a [String],
    pub note: Option<&'a str>,
    pub root: &'a Path,
}

/// Port of `cleanRepo`. The mkdir lock mirrors the JS `mkdirSync(lockPath)`
/// in try/catch; the lock dir is removed on every exit path (JS `finally`).
pub fn clean_repo(params: &CleanParams) -> CleanResult {
    let mut report = scan_repo(Path::new(params.repo), Path::new(params.hook_path));
    let ignore_entries = read_ignore_file(params.repo);
    let before_count = report.violations.len();
    let mut actionable: Vec<Violation> = report
        .violations
        .iter()
        .filter(|v| is_actionable(v, params.skip, &ignore_entries))
        .cloned()
        .collect();
    if params.dry_run {
        println!(
            "{}",
            build_brief(&BriefParams {
                repo: params.repo,
                violations: &actionable,
                round: 1,
                max_rounds: params.max_rounds,
                skip: params.skip,
                note: params.note,
                feedback: &[],
            })
        );
        return CleanResult {
            repo: params.repo.to_string(),
            dry_run: Some(true),
            violations: Some(before_count),
            actionable: Some(actionable.len()),
            ..Default::default()
        };
    }
    let _ = std::fs::create_dir_all(state_dir(params.root).join("clean-locks"));
    let lock_path = lock_path_for(params.root, params.repo);
    let locked = std::fs::create_dir(&lock_path).is_err();
    if locked {
        return CleanResult {
            repo: params.repo.to_string(),
            locked: Some(true),
            violations: Some(before_count),
            actionable: Some(actionable.len()),
            ..Default::default()
        };
    }
    let result = run_rounds(params, &ignore_entries, &mut report, &mut actionable, before_count);
    let _ = std::fs::remove_dir(&lock_path);
    result
}

fn run_rounds(
    params: &CleanParams,
    ignore_entries: &[String],
    report: &mut crate::find_violations::ScanReport,
    actionable: &mut Vec<Violation>,
    before_count: usize,
) -> CleanResult {
    let mut rounds: Vec<Round> = Vec::new();
    let mut feedback: Vec<String> = Vec::new();
    let mut round = 0i64;
    let note_fires = params.note.map(|note| !note.is_empty()).unwrap_or(false);
    while (!actionable.is_empty() || (note_fires && round == 0) || !feedback.is_empty())
        && (round as f64) < params.max_rounds
    {
        round += 1;
        let brief = build_brief(&BriefParams {
            repo: params.repo,
            violations: actionable,
            round,
            max_rounds: params.max_rounds,
            skip: params.skip,
            note: params.note,
            feedback: &feedback,
        });
        eprintln!(
            "[clean] {} round {}/{}: {} violation(s), agent={}",
            params.repo,
            round,
            js_num(params.max_rounds),
            actionable.len(),
            params.model
        );
        let run = spawn_agent(params.model, &brief, params.repo);
        let gaming = detect_gaming(Path::new(params.repo));
        journal(
            params.root,
            &JournalRound {
                at: crate::iso_now(),
                repo: params.repo,
                round,
                model: params.model,
                agent_exit: run.status,
                agent_signal: run.signal.clone(),
                violations: actionable.len(),
                gaming: &gaming.findings,
            },
        );
        *report = scan_repo(Path::new(params.repo), Path::new(params.hook_path));
        *actionable = report
            .violations
            .iter()
            .filter(|v| is_actionable(v, params.skip, ignore_entries))
            .cloned()
            .collect();
        if !gaming.findings.is_empty() {
            feedback = gaming
                .findings
                .iter()
                .map(|finding| format!("- {}: {}", finding.kind, finding.path))
                .collect();
            rounds.push(Round {
                round,
                agent_exit: run.status,
                rejected: Some("rule-gaming".to_string()),
                remaining: actionable.len(),
            });
            continue;
        }
        feedback = Vec::new();
        rounds.push(Round { round, agent_exit: run.status, rejected: None, remaining: actionable.len() });
    }
    let last_round = rounds.last();
    let clean = actionable.is_empty() && !matches!(last_round, Some(r) if r.rejected.is_some());
    journal(
        params.root,
        &JournalDone {
            at: crate::iso_now(),
            repo: params.repo,
            done: true,
            clean,
            before: before_count,
            after: report.violations.len(),
        },
    );
    CleanResult {
        repo: params.repo.to_string(),
        clean: Some(clean),
        before: Some(before_count),
        after: Some(report.violations.len()),
        remaining: Some(actionable.clone()),
        rounds: Some(rounds),
        ..Default::default()
    }
}

pub fn print_clean_usage() {
    eprintln!(
        "tama clean (--repo <path> | --tree <dir> | --owner <gh-owner> | --me) [...]
                 [--model codex|kimi] [--max-rounds <n>] [--skip <fragment>] [--note <text>] [--dry-run] [--json]

Scan target repositories for hook rule violations (same engine as
find-violations), then spawn ONE headless model agent per repository per
round to fix them, re-scanning after each round until clean or out of rounds.
The agent edits the repo with hooks active, so the pre-write hook itself
enforces fix quality. Rounds that game the rules (pseudo-extensions like
.source, runtime-blob imports, renames that strip \"test\" from names) are
rejected and fed back into the next brief. Generated lock and structured
registry/catalog files are never handed to the agent; --skip
excludes path fragments; --note appends an operator instruction and can fire
a round even with zero violations. --dry-run prints the brief without
spawning anything. Disabled entirely when TAMA_CLEAN_DISABLED=1."
    );
}

/// The per-repository summary lines main() prints in text mode, factored so
/// the serve backend streams the same words.
pub fn clean_summary_lines(result: &CleanResult) -> Vec<String> {
    if result.dry_run == Some(true) {
        return Vec::new();
    }
    if result.locked == Some(true) {
        return vec![format!("{} — LOCKED (another clean in progress)", result.repo)];
    }
    let verdict = if result.clean == Some(true) {
        "CLEAN".to_string()
    } else {
        format!("remaining: {}", result.after.unwrap_or(0))
    };
    let mut lines = vec![format!(
        "{} — {} (before: {}, rounds: {})",
        result.repo,
        verdict,
        result.before.unwrap_or(0),
        result.rounds.as_ref().map(|rounds| rounds.len()).unwrap_or(0)
    )];
    if let Some(remaining) = &result.remaining {
        for violation in remaining {
            lines.push(format!("  {} — {}", violation.path, violation.message));
        }
    }
    lines
}

#[derive(Serialize)]
pub struct CleanJsonOutput<'a> {
    pub results: &'a [CleanResult],
    pub problems: &'a [Problem],
}

pub fn main(args: &[String]) -> i32 {
    if std::env::var("TAMA_CLEAN_DISABLED").as_deref() == Ok("1") {
        eprintln!("tama clean is disabled (TAMA_CLEAN_DISABLED=1)");
        return 0;
    }
    let root = repo_root();
    let args = match parse_clean_args(args, &root) {
        Some(args) => args,
        None => {
            print_clean_usage();
            return EXIT_USAGE;
        }
    };
    if !Path::new(&args.base.hook_path).exists() {
        eprintln!("hook not found: {}", args.base.hook_path);
        return EXIT_USAGE;
    }
    for repo in &args.base.repos {
        if !Path::new(repo).exists() {
            eprintln!("repo not found: {}", repo);
            return EXIT_USAGE;
        }
    }
    for tree in &args.base.trees {
        if !Path::new(tree).exists() {
            eprintln!("tree not found: {}", tree);
            return EXIT_USAGE;
        }
    }
    let resolved = resolve_targets(&DiscoveryArgs {
        repos: &args.base.repos,
        trees: &args.base.trees,
        owners: &args.base.owners,
        me: args.base.me,
        clone_dir: Path::new(&args.base.clone_dir),
    });
    if resolved.targets.is_empty() {
        eprintln!("no repositories found");
        return if resolved.problems.is_empty() { 0 } else { 1 };
    }
    let mut results = Vec::new();
    for target in &resolved.targets {
        results.push(clean_repo(&CleanParams {
            repo: &target.path,
            hook_path: &args.base.hook_path,
            model: &args.model,
            max_rounds: args.max_rounds,
            dry_run: args.dry_run,
            skip: &args.skip,
            note: args.note.as_deref(),
            root: &root,
        }));
    }
    if args.base.json {
        let output = CleanJsonOutput { results: &results, problems: &resolved.problems };
        crate::write_json_line(&serde_json::to_string_pretty(&output).unwrap_or_default());
    } else {
        for result in &results {
            for line in clean_summary_lines(result) {
                println!("{line}");
            }
        }
    }
    let unresolved = results
        .iter()
        .any(|result| result.clean == Some(false) || result.locked == Some(true));
    if unresolved || !resolved.problems.is_empty() {
        1
    } else {
        0
    }
}
