use serde_json::{json, Value};
use std::collections::HashSet;
use std::fs;
use std::io::ErrorKind;
use std::path::{Path, PathBuf};
use tama_core::policy_bundle::PolicyBundleImportResult;

const PRODUCT_ID: &str = "tama-cli";
const JOURNEY_ID: &str = "first-use";
const JOURNEY_VERSION: &str = "2026-09-03.2";
const FIRST_SUCCESS_FACT: &str = "hook_catalog_listed";
const STATE_SCHEMA: &str = "tama-cli.onboarding-state.v1";
const DEFINITION: &str = include_str!("onboarding_first_use.json");

pub fn run(root: &Path, reset: bool, imported: Option<&PolicyBundleImportResult>) -> Result<(), String> {
    let definition = canonical_definition()?;
    let path = state_path();

    if reset {
        match fs::remove_file(&path) {
            Ok(()) => {}
            Err(error) if error.kind() == ErrorKind::NotFound => {}
            Err(error) => {
                return Err(format!(
                    "could not reset Tama onboarding state {}: {error}",
                    path.display()
                ));
            }
        }
        println!(
            "Tama first-use journey reset: recorded progress and evidence discarded; showing it again now."
        );
        println!();
    }

    let mut state = load_or_start_state(&definition, &path)?;
    if let Some(imported) = imported {
        let object = state
            .as_object_mut()
            .ok_or_else(|| "Tama onboarding state is not an object".to_string())?;
        let evidence = object
            .entry("evidence")
            .or_insert_with(|| json!({}))
            .as_object_mut()
            .ok_or_else(|| "Tama onboarding evidence is not an object".to_string())?;
        evidence.insert("policy_bundle_imported".to_string(), Value::Bool(true));
        object.insert(
            "policy_bundle".to_string(),
            json!({
                "sourcePath": imported.source_path,
                "sourceDigest": imported.source_digest,
                "bundlePath": imported.bundle_path,
                "activation": "inactive"
            }),
        );
        save_state(&path, &state)?;
    }
    if state.get("status").and_then(Value::as_str) == Some("completed") {
        println!(
            "Tama first-use journey is already complete: a hook catalog was read successfully."
        );
        println!("Run `tama onboarding --reset` to show the walkthrough again.");
        return Ok(());
    }

    loop {
        let screen_id = state
            .get("current_screen_id")
            .and_then(Value::as_str)
            .ok_or_else(|| "Tama onboarding state has no current screen; use --reset".to_string())?
            .to_string();
        let screen = screen_by_id(&definition, &screen_id)?.clone();
        render(&screen)?;

        let Some(next) = next_screen_id(&screen)? else {
            println!();
            let hook_count = super::list_hooks(root, false)
                .map_err(|error| format!("Tama could not read its hook catalog: {error}"))?;
            if hook_count == 0 {
                return Err(
                    "Tama read the catalog but found no hooks; onboarding remains in progress"
                        .to_string(),
                );
            }

            if !evidence_satisfied(&screen, FIRST_SUCCESS_FACT)? {
                return Err("Tama onboarding first-success evidence is invalid".to_string());
            }
            let object = state
                .as_object_mut()
                .ok_or_else(|| "Tama onboarding state is not an object".to_string())?;
            object.insert("status".to_string(), Value::String("completed".to_string()));
            let evidence = object
                .entry("evidence")
                .or_insert_with(|| json!({}))
                .as_object_mut()
                .ok_or_else(|| "Tama onboarding evidence is not an object".to_string())?;
            evidence.insert(FIRST_SUCCESS_FACT.to_string(), Value::Bool(true));
            object.insert("hook_count".to_string(), json!(hook_count));
            save_state(&path, &state)?;

            println!();
            println!(
                "First-use complete: Tama observed {FIRST_SUCCESS_FACT} from the {hook_count} hooks listed above."
            );
            return Ok(());
        };

        screen_by_id(&definition, &next)?;
        let object = state
            .as_object_mut()
            .ok_or_else(|| "Tama onboarding state is not an object".to_string())?;
        object.insert("current_screen_id".to_string(), Value::String(next));
        save_state(&path, &state)?;
        println!();
    }
}

fn canonical_definition() -> Result<Value, String> {
    let definition: Value = serde_json::from_str(DEFINITION)
        .map_err(|error| format!("could not parse Tama onboarding definition: {error}"))?;
    if definition.get("schema_version").and_then(Value::as_u64) != Some(1)
        || definition.get("product_id").and_then(Value::as_str) != Some(PRODUCT_ID)
        || definition.get("journey_id").and_then(Value::as_str) != Some(JOURNEY_ID)
        || definition.get("journey_version").and_then(Value::as_str) != Some(JOURNEY_VERSION)
        || definition.get("first_success_fact").and_then(Value::as_str)
            != Some(FIRST_SUCCESS_FACT)
        || definition
            .pointer("/analytics_contract/surface")
            .and_then(Value::as_str)
            != Some("cli_first_use")
    {
        return Err("Tama onboarding definition identity is invalid".to_string());
    }

    let screens = definition
        .get("screens")
        .and_then(Value::as_array)
        .ok_or_else(|| "Tama onboarding definition has no screens".to_string())?;
    if !(3..=5).contains(&screens.len()) {
        return Err("Tama onboarding definition must contain three to five screens".to_string());
    }

    let mut screen_ids = HashSet::new();
    for screen in screens {
        let screen_id = screen
            .get("screen_id")
            .and_then(Value::as_str)
            .ok_or_else(|| "Tama onboarding screen has no id".to_string())?;
        if !screen_ids.insert(screen_id) {
            return Err(format!("duplicate Tama onboarding screen id: {screen_id}"));
        }
        for field in ["title", "body"] {
            if screen
                .pointer(&format!("/presentation/{field}"))
                .and_then(Value::as_str)
                .is_none_or(str::is_empty)
            {
                return Err(format!(
                    "Tama onboarding screen {screen_id} has no presentation {field}"
                ));
            }
        }
    }

    let entry_screen_id = definition
        .get("entry_screen_id")
        .and_then(Value::as_str)
        .ok_or_else(|| "Tama onboarding definition has no entry screen".to_string())?;
    if !screen_ids.contains(entry_screen_id) {
        return Err("Tama onboarding entry screen does not exist".to_string());
    }
    for screen in screens {
        if let Some(transitions) = screen.get("transitions").and_then(Value::as_array) {
            for transition in transitions {
                let target = transition
                    .get("next_screen_id")
                    .and_then(Value::as_str)
                    .ok_or_else(|| "Tama onboarding transition has no target".to_string())?;
                if !screen_ids.contains(target) {
                    return Err(format!(
                        "Tama onboarding transition target does not exist: {target}"
                    ));
                }
            }
        }
    }

    Ok(definition)
}

fn screen_by_id<'a>(definition: &'a Value, screen_id: &str) -> Result<&'a Value, String> {
    definition
        .get("screens")
        .and_then(Value::as_array)
        .and_then(|screens| {
            screens
                .iter()
                .find(|screen| screen.get("screen_id").and_then(Value::as_str) == Some(screen_id))
        })
        .ok_or_else(|| format!("Tama onboarding screen is unavailable: {screen_id}"))
}

fn next_screen_id(screen: &Value) -> Result<Option<String>, String> {
    let Some(transitions) = screen.get("transitions").and_then(Value::as_array) else {
        return Ok(None);
    };
    transitions
        .iter()
        .max_by_key(|transition| {
            transition
                .get("priority")
                .and_then(Value::as_i64)
                .unwrap_or_default()
        })
        .map(|transition| {
            transition
                .get("next_screen_id")
                .and_then(Value::as_str)
                .map(str::to_string)
                .ok_or_else(|| "Tama onboarding transition has no target".to_string())
        })
        .transpose()
}

fn evidence_satisfied(screen: &Value, fact: &str) -> Result<bool, String> {
    let rule = screen
        .get("completion_evidence")
        .filter(|value| !value.is_null())
        .ok_or_else(|| "Tama onboarding final screen has no completion evidence".to_string())?;
    Ok(rule.get("kind").and_then(Value::as_str) == Some("fact")
        && rule.get("operator").and_then(Value::as_str) == Some("eq")
        && rule.get("fact").and_then(Value::as_str) == Some(fact)
        && rule.get("value").and_then(Value::as_bool) == Some(true))
}

fn render(screen: &Value) -> Result<(), String> {
    let title = screen
        .pointer("/presentation/title")
        .and_then(Value::as_str)
        .ok_or_else(|| "Tama onboarding screen has no presentation title".to_string())?;
    let body = screen
        .pointer("/presentation/body")
        .and_then(Value::as_str)
        .ok_or_else(|| "Tama onboarding screen has no presentation body".to_string())?;
    println!("== {title} ==");
    println!("{body}");
    Ok(())
}

fn load_or_start_state(definition: &Value, path: &Path) -> Result<Value, String> {
    if path.exists() {
        let state: Value = serde_json::from_str(
            &fs::read_to_string(path)
                .map_err(|error| format!("could not read {}: {error}", path.display()))?,
        )
        .map_err(|error| format!("could not parse {}: {error}", path.display()))?;
        if state.get("schema").and_then(Value::as_str) != Some(STATE_SCHEMA)
            || state.get("product_id").and_then(Value::as_str) != Some(PRODUCT_ID)
            || state.get("journey_id").and_then(Value::as_str) != Some(JOURNEY_ID)
            || state.get("journey_version").and_then(Value::as_str) != Some(JOURNEY_VERSION)
        {
            return Err("stored Tama onboarding state is incompatible; use --reset".to_string());
        }
        let current_screen_id = state
            .get("current_screen_id")
            .and_then(Value::as_str)
            .ok_or_else(|| "stored Tama onboarding state has no current screen".to_string())?;
        screen_by_id(definition, current_screen_id)?;
        return Ok(state);
    }

    let entry_screen_id = definition
        .get("entry_screen_id")
        .and_then(Value::as_str)
        .ok_or_else(|| "Tama onboarding definition has no entry screen".to_string())?;
    let state = json!({
        "schema": STATE_SCHEMA,
        "product_id": PRODUCT_ID,
        "journey_id": JOURNEY_ID,
        "journey_version": JOURNEY_VERSION,
        "source_revision": definition.get("source_revision").cloned().unwrap_or(Value::Null),
        "current_screen_id": entry_screen_id,
        "status": "in_progress",
        "evidence": {}
    });
    save_state(path, &state)?;
    Ok(state)
}

fn save_state(path: &Path, state: &Value) -> Result<(), String> {
    let parent = path
        .parent()
        .ok_or_else(|| "Tama onboarding state path has no parent".to_string())?;
    fs::create_dir_all(parent)
        .map_err(|error| format!("could not create {}: {error}", parent.display()))?;
    let temporary = path.with_extension(format!("json.tmp-{}", std::process::id()));
    let body = serde_json::to_string_pretty(state)
        .map_err(|error| format!("could not encode Tama onboarding state: {error}"))?;
    fs::write(&temporary, format!("{body}\n"))
        .map_err(|error| format!("could not write {}: {error}", temporary.display()))?;
    fs::rename(&temporary, path)
        .map_err(|error| format!("could not replace {}: {error}", path.display()))?;
    Ok(())
}

fn state_path() -> PathBuf {
    if let Some(path) = std::env::var_os("XDG_STATE_HOME") {
        return PathBuf::from(path).join("tama/onboarding.json");
    }
    if let Some(home) = std::env::var_os("HOME") {
        return PathBuf::from(home).join(".local/state/tama/onboarding.json");
    }
    std::env::temp_dir().join("tama/onboarding.json")
}
