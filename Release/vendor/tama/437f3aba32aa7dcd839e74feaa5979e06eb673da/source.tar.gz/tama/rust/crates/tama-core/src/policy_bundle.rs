//! Durable, inactive policy-bundle adoption for Tama CLI and Desktop.
//!
//! A bundle is an existing self-contained Tama policy directory or sealed
//! release. Import copies the established policy roots into Tama's editable
//! data store, records source identity, and never changes the active runtime or
//! installs a hook.

use crate::catalog::build_catalog;
use crate::registry::Registry;
use crate::{err, Result};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::collections::{BTreeMap, BTreeSet, HashSet};
use std::fs::{self, OpenOptions};
use std::io::Write;
use std::path::{Path, PathBuf};
use std::time::{SystemTime, UNIX_EPOCH};

const INDEX_SCHEMA: &str = "ai.wisent.tama.policy-bundles.v1";
const RESULT_SCHEMA: &str = "ai.wisent.tama.policy-bundle-import-result.v1";
const POLICY_ROOTS: &[&str] = &[
    "shared-hooks",
    "claude-hooks",
    "codex-hooks",
    "repo-githooks",
    "adaptive",
    "external-hooks",
    "bin",
];
const RUNTIME_POLICY_ROOTS: &[(&str, &str)] = &[
    (".shared-hooks", "shared-hooks"),
    (".claude/hooks", "claude-hooks"),
    (".codex/hooks", "codex-hooks"),
];
const ROOT_METADATA: &[&str] = &[
    "package.json",
    "release.json",
    "external-sources.json",
    ".wisent-release.json",
    "README.md",
    "LICENSE",
];

#[derive(Debug, Clone)]
struct SelectedFile {
    relative: String,
    bytes: Vec<u8>,
    sha256: String,
    mode: u32,
}

#[derive(Debug)]
struct Selection {
    files: Vec<SelectedFile>,
    digest: String,
    hook_count: usize,
    ignored_paths: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct BundleFileRecord {
    pub path: String,
    pub sha256: String,
    pub mode: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PolicyBundleRecord {
    pub source_key: String,
    pub source_path: String,
    pub source_digest: String,
    pub bundle_path: String,
    pub imported_at_unix: u64,
    pub hook_count: usize,
    pub activation: String,
    pub files: Vec<BundleFileRecord>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
struct PolicyBundleIndex {
    schema: String,
    bundles: Vec<PolicyBundleRecord>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct PolicyBundleSummary {
    pub source_key: String,
    pub source_path: String,
    pub source_digest: String,
    pub bundle_path: String,
    pub imported_at_unix: u64,
    pub hook_count: usize,
    pub file_count: usize,
    pub activation: String,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct PolicyBundleList {
    pub schema: String,
    pub store_path: String,
    pub bundles: Vec<PolicyBundleSummary>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct PolicyBundleConflict {
    pub path: String,
    pub reason: String,
    pub existing_sha256: Option<String>,
    pub incoming_sha256: Option<String>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct PolicyBundleImportResult {
    pub schema: String,
    pub status: String,
    pub source_path: String,
    pub source_digest: Option<String>,
    pub store_path: String,
    pub bundle_path: Option<String>,
    pub hook_count: usize,
    pub imported: usize,
    pub unchanged: usize,
    pub removed: usize,
    pub conflicting: usize,
    pub rejected: usize,
    pub conflicts: Vec<PolicyBundleConflict>,
    pub rejections: Vec<String>,
    pub ignored_paths: Vec<String>,
    pub activation: String,
    pub installed_hooks: usize,
    pub enabled_hooks: usize,
}

impl PolicyBundleImportResult {
    fn rejected(source: &Path, store: &Path, reasons: Vec<String>, ignored_paths: Vec<String>) -> Self {
        Self {
            schema: RESULT_SCHEMA.to_string(),
            status: "rejected".to_string(),
            source_path: source.display().to_string(),
            source_digest: None,
            store_path: store.display().to_string(),
            bundle_path: None,
            hook_count: 0,
            imported: 0,
            unchanged: 0,
            removed: 0,
            conflicting: 0,
            rejected: reasons.len(),
            conflicts: Vec::new(),
            rejections: reasons,
            ignored_paths,
            activation: "inactive".to_string(),
            installed_hooks: 0,
            enabled_hooks: 0,
        }
    }
}

pub struct ImportPolicyBundleOptions<'a> {
    pub source: &'a Path,
    pub home: Option<&'a Path>,
    pub replace: bool,
}

fn hex(bytes: &[u8]) -> String {
    let mut output = String::with_capacity(bytes.len() * 2);
    for byte in bytes {
        use std::fmt::Write as _;
        let _ = write!(&mut output, "{byte:02x}");
    }
    output
}

fn sha256(bytes: &[u8]) -> String {
    hex(&Sha256::digest(bytes))
}

fn path_string(path: &Path) -> String {
    path.components()
        .map(|component| component.as_os_str().to_string_lossy())
        .collect::<Vec<_>>()
        .join("/")
}

fn safe_join(root: &Path, relative: &str) -> Result<PathBuf> {
    let relative = Path::new(relative);
    if relative.is_absolute()
        || relative.components().any(|component| {
            matches!(
                component,
                std::path::Component::ParentDir
                    | std::path::Component::RootDir
                    | std::path::Component::Prefix(_)
            )
        })
    {
        return Err(err("policy bundle index contains an unsafe file path"));
    }
    Ok(root.join(relative))
}

#[cfg(unix)]
fn file_mode(metadata: &fs::Metadata) -> u32 {
    use std::os::unix::fs::PermissionsExt;
    metadata.permissions().mode() & 0o777
}

#[cfg(not(unix))]
fn file_mode(_metadata: &fs::Metadata) -> u32 {
    0o600
}

#[cfg(unix)]
fn set_mode(path: &Path, mode: u32) -> Result<()> {
    use std::os::unix::fs::PermissionsExt;
    fs::set_permissions(path, fs::Permissions::from_mode(mode))?;
    Ok(())
}

#[cfg(not(unix))]
fn set_mode(_path: &Path, _mode: u32) -> Result<()> {
    Ok(())
}

pub fn policy_bundle_store(home: Option<&Path>) -> Result<PathBuf> {
    if let Some(home) = home {
        if !home.is_dir() {
            return Err(err(format!("Tama home is not a directory: {}", home.display())));
        }
        #[cfg(target_os = "macos")]
        return Ok(home.join("Library/Application Support/Tama/policy-bundles"));
        #[cfg(target_os = "windows")]
        return Ok(home.join("AppData/Local/Tama/policy-bundles"));
        #[cfg(not(any(target_os = "macos", target_os = "windows")))]
        return Ok(home.join(".local/share/tama/policy-bundles"));
    }

    #[cfg(target_os = "windows")]
    if let Ok(root) = std::env::var("LOCALAPPDATA") {
        if !root.trim().is_empty() {
            return Ok(PathBuf::from(root).join("Tama/policy-bundles"));
        }
    }
    #[cfg(not(target_os = "windows"))]
    if let Ok(root) = std::env::var("XDG_DATA_HOME") {
        if !root.trim().is_empty() {
            return Ok(PathBuf::from(root).join("tama/policy-bundles"));
        }
    }
    let home = std::env::var("HOME").map_err(|_| err("HOME is required to locate Tama's policy-bundle store"))?;
    policy_bundle_store(Some(Path::new(&home)))
}

fn index_path(store: &Path) -> PathBuf {
    store.join("index.json")
}

fn empty_index() -> PolicyBundleIndex {
    PolicyBundleIndex {
        schema: INDEX_SCHEMA.to_string(),
        bundles: Vec::new(),
    }
}

fn read_index(store: &Path) -> Result<PolicyBundleIndex> {
    let path = index_path(store);
    if !path.exists() {
        return Ok(empty_index());
    }
    let metadata = fs::symlink_metadata(&path)?;
    if metadata.file_type().is_symlink() || !metadata.is_file() {
        return Err(err(format!("Tama policy-bundle index is not a regular file: {}", path.display())));
    }
    let index: PolicyBundleIndex = serde_json::from_slice(&fs::read(&path)?)?;
    if index.schema != INDEX_SCHEMA {
        return Err(err(format!("unsupported Tama policy-bundle index: {}", path.display())));
    }
    Ok(index)
}

fn walk_files(root: &Path, relative_root: &Path, output: &mut Vec<SelectedFile>) -> Result<()> {
    let start = root.join(relative_root);
    let metadata = fs::symlink_metadata(&start)?;
    if metadata.file_type().is_symlink() || !metadata.is_dir() {
        return Err(err(format!("policy root is not a regular directory: {}", start.display())));
    }
    let mut entries = fs::read_dir(&start)?.collect::<std::io::Result<Vec<_>>>()?;
    entries.sort_by_key(|entry| entry.file_name());
    for entry in entries {
        let relative = relative_root.join(entry.file_name());
        let path = entry.path();
        let metadata = fs::symlink_metadata(&path)?;
        if metadata.file_type().is_symlink() {
            return Err(err(format!("policy bundle must not contain symlinks: {}", path.display())));
        }
        if metadata.is_dir() {
            walk_files(root, &relative, output)?;
        } else if metadata.is_file() {
            let bytes = fs::read(&path)?;
            output.push(SelectedFile {
                relative: path_string(&relative),
                sha256: sha256(&bytes),
                mode: file_mode(&metadata),
                bytes,
            });
        } else {
            return Err(err(format!("policy bundle contains an unsupported filesystem entry: {}", path.display())));
        }
    }
    Ok(())
}

fn ignored_top_level(source: &Path) -> Result<Vec<String>> {
    let accepted: HashSet<&str> = POLICY_ROOTS.iter().chain(ROOT_METADATA.iter()).copied().collect();
    let mut ignored = Vec::new();
    let mut entries = fs::read_dir(source)?.collect::<std::io::Result<Vec<_>>>()?;
    entries.sort_by_key(|entry| entry.file_name());
    for entry in entries {
        let name = entry.file_name().to_string_lossy().to_string();
        if name == ".git" || accepted.contains(name.as_str()) {
            continue;
        }
        let suffix = if entry.file_type()?.is_dir() { "/" } else { "" };
        ignored.push(format!("{name}{suffix}"));
    }
    Ok(ignored)
}
#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct ExternalSourceManifest {
    schema: String,
    mappings: Vec<ExternalSourceMapping>,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct ExternalSourceMapping {
    source_prefix: String,
    release_path: String,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct HookReleaseManifest {
    schema: String,
    release_id: String,
}

fn policy_source_relative(
    value: &str,
    source: &Path,
    external_mappings: &[ExternalSourceMapping],
) -> Option<String> {
    let normalized = value.replace('\\', "/");
    let source_prefix = format!("{}/", source.to_string_lossy().replace('\\', "/"));
    if let Some(index) = normalized.find(&source_prefix) {
        return Some(
            normalized[index + source_prefix.len()..]
                .split(|character: char| character.is_whitespace() || character == '"')
                .next()
                .unwrap_or_default()
                .to_string(),
        );
    }
    for mapping in external_mappings {
        let prefix = mapping.source_prefix.replace('\\', "/");
        if let Some(index) = normalized.find(&prefix) {
            let suffix = normalized[index + prefix.len()..].trim_start_matches('/');
            let suffix = suffix
                .split(|character: char| character.is_whitespace() || character == '"')
                .next()
                .unwrap_or_default();
            return Some(if suffix.is_empty() {
                mapping.release_path.trim_end_matches('/').to_string()
            } else {
                format!("{}/{}", mapping.release_path.trim_end_matches('/'), suffix)
            });
        }
    }
    for (runtime_root, bundle_root) in RUNTIME_POLICY_ROOTS {
        let direct = format!("{runtime_root}/");
        let marker = format!("/{runtime_root}/");
        let suffix = if normalized.starts_with(&direct) {
            Some(&normalized[direct.len()..])
        } else {
            normalized
                .rfind(&marker)
                .map(|index| &normalized[index + marker.len()..])
        };
        if let Some(suffix) = suffix {
            let suffix = suffix
                .split(|character: char| character.is_whitespace() || character == '"')
                .next()
                .unwrap_or_default();
            return Some(format!("{bundle_root}/{suffix}"));
        }
    }
    for root in POLICY_ROOTS {
        let direct = format!("{root}/");
        if normalized.starts_with(&direct) {
            return Some(
                normalized
                    .split(|character: char| character.is_whitespace() || character == '"')
                    .next()
                    .unwrap_or_default()
                    .to_string(),
            );
        }
        let marker = format!("/{root}/");
        if let Some(index) = normalized.rfind(&marker) {
            let relative = &normalized[index + 1..];
            return Some(
                relative
                    .split(|character: char| character.is_whitespace() || character == '"')
                    .next()
                    .unwrap_or_default()
                    .to_string(),
            );
        }
    }
    None
}

fn inspect(source: &Path) -> Result<Selection> {
    let registry_path = source.join("shared-hooks/registry.json");
    let registry_metadata = fs::symlink_metadata(&registry_path).map_err(|_| {
        err(format!("policy bundle has no shared-hooks/registry.json: {}", source.display()))
    })?;
    if registry_metadata.file_type().is_symlink() || !registry_metadata.is_file() {
        return Err(err(format!("policy registry is not a regular file: {}", registry_path.display())));
    }

    let registry: Registry = serde_json::from_slice(&fs::read(&registry_path)?)?;
    let mut rejections = Vec::new();
    let mut identifiers = HashSet::new();
    for (event, configuration) in &registry.events {
        for hook in &configuration.hooks {
            if hook.id.trim().is_empty() {
                rejections.push(format!("{event}: hook id is empty"));
            } else {
                identifiers.insert(hook.id.clone());
            }
        }
    }
    if identifiers.is_empty() {
        rejections.push("policy registry contains no hooks".to_string());
    }

    let mut files = Vec::new();
    for root in POLICY_ROOTS {
        let relative = Path::new(root);
        if source.join(relative).exists() {
            walk_files(source, relative, &mut files)?;
        }
    }
    for metadata in ROOT_METADATA {
        let path = source.join(metadata);
        if !path.exists() {
            continue;
        }
        let stat = fs::symlink_metadata(&path)?;
        if stat.file_type().is_symlink() || !stat.is_file() {
            return Err(err(format!("bundle metadata is not a regular file: {}", path.display())));
        }
        let bytes = fs::read(&path)?;
        files.push(SelectedFile {
            relative: metadata.to_string(),
            sha256: sha256(&bytes),
            mode: file_mode(&stat),
            bytes,
        });
    }
    files.sort_by(|left, right| left.relative.cmp(&right.relative));
    let external_mappings = if source.join("external-sources.json").exists() {
        let manifest: ExternalSourceManifest =
            serde_json::from_slice(&fs::read(source.join("external-sources.json"))?)?;
        if manifest.schema != "ai.wisent.tama.external-hook-sources.v1" {
            rejections.push("unsupported external-sources.json schema".to_string());
        }
        manifest.mappings
    } else {
        Vec::new()
    };
    if source.join("release.json").exists() {
        let release: HookReleaseManifest =
            serde_json::from_slice(&fs::read(source.join("release.json"))?)?;
        if release.schema != "ai.wisent.tama.hook-release.v1" {
            rejections.push("unsupported release.json schema".to_string());
        } else {
            let mut digest = Sha256::new();
            for file in files.iter().filter(|file| file.relative != "release.json") {
                digest.update((file.relative.len() as u64).to_be_bytes());
                digest.update(file.relative.as_bytes());
                digest.update(file.mode.to_be_bytes());
                digest.update((file.bytes.len() as u64).to_be_bytes());
                digest.update(&file.bytes);
            }
            let actual = hex(&digest.finalize());
            if actual != release.release_id {
                rejections.push(format!(
                    "release.json identity mismatch: expected {}, got {actual}",
                    release.release_id
                ));
            }
        }
    }
    let selected: HashSet<&str> = files.iter().map(|file| file.relative.as_str()).collect();

    match build_catalog(source) {
        Ok(catalog) => {
            for hook in &catalog.hooks {
                if hook.events.is_empty() {
                    rejections.push(format!("{}: no events", hook.id));
                }
            }
        }
        Err(error) => rejections.push(error.to_string()),
    }
    for (event, configuration) in &registry.events {
        for hook in &configuration.hooks {
            let declared = hook
                .source
                .as_deref()
                .filter(|value| !value.is_empty())
                .or(hook.command.as_deref());
            match declared.and_then(|value| {
                policy_source_relative(value, source, &external_mappings)
            }) {
                Some(relative) if selected.contains(relative.as_str()) => {}
                Some(relative) => rejections.push(format!(
                    "{} ({event}): source file is outside the supported bundle roots or missing: {relative}",
                    hook.id
                )),
                None => rejections.push(format!(
                    "{} ({event}): source path could not be mapped into the policy bundle",
                    hook.id
                )),
            }
        }
    }
    if let Some(agent_hooks) = registry
        .extra
        .get("catalog")
        .and_then(|catalog| catalog.get("agentHooks"))
        .and_then(serde_json::Value::as_array)
    {
        for hook in agent_hooks {
            let id = hook
                .get("id")
                .and_then(serde_json::Value::as_str)
                .unwrap_or("<catalog hook>");
            let declared = hook.get("source").and_then(serde_json::Value::as_str);
            match declared.and_then(|value| {
                policy_source_relative(value, source, &external_mappings)
            }) {
                Some(relative) if selected.contains(relative.as_str()) => {}
                Some(relative) => rejections.push(format!(
                    "{id} (catalog): source file is outside the supported bundle roots or missing: {relative}"
                )),
                None => rejections.push(format!(
                    "{id} (catalog): source path could not be mapped into the policy bundle"
                )),
            }
        }
    }
    if !rejections.is_empty() {
        return Err(err(rejections.join("; ")));
    }

    let mut digest = Sha256::new();
    for file in &files {
        digest.update(file.relative.as_bytes());
        digest.update([0]);
        digest.update(file.sha256.as_bytes());
        digest.update([0]);
        digest.update(file.mode.to_string().as_bytes());
        digest.update([0]);
    }
    Ok(Selection {
        files,
        digest: hex(&digest.finalize()),
        hook_count: identifiers.len(),
        ignored_paths: ignored_top_level(source)?,
    })
}

fn file_state(path: &Path) -> Result<Option<(String, u32)>> {
    if !path.exists() {
        return Ok(None);
    }
    let metadata = fs::symlink_metadata(path)?;
    if metadata.file_type().is_symlink() || !metadata.is_file() {
        return Ok(Some(("unsupported".to_string(), 0)));
    }
    Ok(Some((sha256(&fs::read(path)?), file_mode(&metadata))))
}

fn files_in_existing_bundle(root: &Path) -> Result<Vec<String>> {
    if !root.exists() {
        return Ok(Vec::new());
    }
    let metadata = fs::symlink_metadata(root)?;
    if metadata.file_type().is_symlink() || !metadata.is_dir() {
        return Err(err(format!("stored policy bundle is not a directory: {}", root.display())));
    }
    let mut files = Vec::new();
    fn visit(root: &Path, current: &Path, output: &mut Vec<String>) -> Result<()> {
        let mut entries = fs::read_dir(current)?.collect::<std::io::Result<Vec<_>>>()?;
        entries.sort_by_key(|entry| entry.file_name());
        for entry in entries {
            let path = entry.path();
            let metadata = fs::symlink_metadata(&path)?;
            if metadata.file_type().is_symlink() {
                return Err(err(format!("stored policy bundle contains a symlink: {}", path.display())));
            }
            if metadata.is_dir() {
                visit(root, &path, output)?;
            } else if metadata.is_file() {
                output.push(path_string(path.strip_prefix(root)?));
            } else {
                return Err(err(format!("stored policy bundle contains an unsupported entry: {}", path.display())));
            }
        }
        Ok(())
    }
    visit(root, root, &mut files)?;
    files.sort();
    Ok(files)
}

struct StoreLock(PathBuf);

impl Drop for StoreLock {
    fn drop(&mut self) {
        let _ = fs::remove_file(&self.0);
    }
}

fn lock_store(store: &Path) -> Result<StoreLock> {
    fs::create_dir_all(store)?;
    let path = store.join(".import.lock");
    OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(&path)
        .map_err(|error| err(format!("another Tama policy-bundle import is active ({}): {error}", path.display())))?;
    Ok(StoreLock(path))
}

fn timestamp() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}

fn transaction_id() -> String {
    format!("{}-{}", std::process::id(), timestamp())
}

pub fn list_policy_bundles(home: Option<&Path>) -> Result<PolicyBundleList> {
    let store = policy_bundle_store(home)?;
    let index = read_index(&store)?;
    Ok(PolicyBundleList {
        schema: INDEX_SCHEMA.to_string(),
        store_path: store.display().to_string(),
        bundles: index
            .bundles
            .into_iter()
            .map(|bundle| PolicyBundleSummary {
                source_key: bundle.source_key,
                source_path: bundle.source_path,
                source_digest: bundle.source_digest,
                bundle_path: bundle.bundle_path,
                imported_at_unix: bundle.imported_at_unix,
                hook_count: bundle.hook_count,
                file_count: bundle.files.len(),
                activation: bundle.activation,
            })
            .collect(),
    })
}

pub fn import_policy_bundle(options: ImportPolicyBundleOptions<'_>) -> Result<PolicyBundleImportResult> {
    let source = fs::canonicalize(options.source).map_err(|_| {
        err(format!("policy bundle source is not an existing directory: {}", options.source.display()))
    })?;
    if !source.is_dir() {
        return Err(err(format!("policy bundle source is not a directory: {}", source.display())));
    }
    let store = policy_bundle_store(options.home)?;
    let ignored = ignored_top_level(&source).unwrap_or_default();
    let selection = match inspect(&source) {
        Ok(selection) => selection,
        Err(error) => return Ok(PolicyBundleImportResult::rejected(&source, &store, vec![error.to_string()], ignored)),
    };
    if source.starts_with(&store) || store.starts_with(&source) {
        return Ok(PolicyBundleImportResult::rejected(
            &source,
            &store,
            vec!["policy bundle source and Tama's editable store must be separate".to_string()],
            selection.ignored_paths,
        ));
    }

    let mut index = read_index(&store)?;
    let source_key = sha256(source.to_string_lossy().as_bytes());
    let bundle_root = store.join("bundles").join(&source_key);
    let existing = index.bundles.iter().find(|bundle| bundle.source_key == source_key).cloned();
    let incoming: BTreeMap<&str, &SelectedFile> = selection
        .files
        .iter()
        .map(|file| (file.relative.as_str(), file))
        .collect();
    let previous: BTreeMap<&str, &BundleFileRecord> = existing
        .as_ref()
        .map(|bundle| bundle.files.iter().map(|file| (file.path.as_str(), file)).collect())
        .unwrap_or_default();
    let mut conflicts = Vec::new();
    let mut unchanged = 0;
    let mut imported = 0;
    let mut removed = 0;

    for file in &selection.files {
        let current_state = file_state(&safe_join(&bundle_root, &file.relative)?)?;
        let current_sha256 = current_state.as_ref().map(|(digest, _)| digest.clone());
        if current_state
            .as_ref()
            .is_some_and(|(digest, mode)| digest == &file.sha256 && *mode == file.mode)
        {
            unchanged += 1;
            continue;
        }
        if let Some(previous_file) = previous.get(file.relative.as_str()) {
            if current_state.as_ref().is_some_and(|(digest, mode)| {
                digest != &previous_file.sha256 || *mode != previous_file.mode
            }) {
                conflicts.push(PolicyBundleConflict {
                    path: file.relative.clone(),
                    reason: "stored definition has local content or mode changes".to_string(),
                    existing_sha256: current_sha256,
                    incoming_sha256: Some(file.sha256.clone()),
                });
                continue;
            }
        }
        if current_state.is_some() && !options.replace {
            conflicts.push(PolicyBundleConflict {
                path: file.relative.clone(),
                reason: "stored definition content or mode differs; explicit replacement is required".to_string(),
                existing_sha256: current_sha256,
                incoming_sha256: Some(file.sha256.clone()),
            });
        } else {
            imported += 1;
        }
    }

    for (relative, previous_file) in &previous {
        if incoming.contains_key(relative) {
            continue;
        }
        let current_state = file_state(&safe_join(&bundle_root, relative)?)?;
        let current_sha256 = current_state.as_ref().map(|(digest, _)| digest.clone());
        if current_state.is_none() {
            continue;
        }
        if current_state.as_ref().is_some_and(|(digest, mode)| {
            digest != &previous_file.sha256 || *mode != previous_file.mode
        }) {
            conflicts.push(PolicyBundleConflict {
                path: (*relative).to_string(),
                reason: "stored definition removed upstream has local content or mode changes".to_string(),
                existing_sha256: current_sha256,
                incoming_sha256: None,
            });
        } else if !options.replace {
            conflicts.push(PolicyBundleConflict {
                path: (*relative).to_string(),
                reason: "stored definition is absent from the selected source".to_string(),
                existing_sha256: current_sha256,
                incoming_sha256: None,
            });
        } else {
            removed += 1;
        }
    }

    let tracked: BTreeSet<&str> = previous.keys().copied().collect();
    for relative in files_in_existing_bundle(&bundle_root)? {
        if tracked.contains(relative.as_str()) {
            continue;
        }
        conflicts.push(PolicyBundleConflict {
            path: relative,
            reason: "stored bundle contains an untracked file".to_string(),
            existing_sha256: None,
            incoming_sha256: None,
        });
    }

    if !conflicts.is_empty() {
        return Ok(PolicyBundleImportResult {
            schema: RESULT_SCHEMA.to_string(),
            status: "conflict".to_string(),
            source_path: source.display().to_string(),
            source_digest: Some(selection.digest),
            store_path: store.display().to_string(),
            bundle_path: Some(bundle_root.display().to_string()),
            hook_count: selection.hook_count,
            imported: 0,
            unchanged,
            removed: 0,
            conflicting: conflicts.len(),
            rejected: 0,
            conflicts,
            rejections: Vec::new(),
            ignored_paths: selection.ignored_paths,
            activation: "inactive".to_string(),
            installed_hooks: 0,
            enabled_hooks: 0,
        });
    }

    if existing.as_ref().is_some_and(|record| record.source_digest == selection.digest)
        && imported == 0
        && removed == 0
    {
        return Ok(PolicyBundleImportResult {
            schema: RESULT_SCHEMA.to_string(),
            status: "unchanged".to_string(),
            source_path: source.display().to_string(),
            source_digest: Some(selection.digest),
            store_path: store.display().to_string(),
            bundle_path: Some(bundle_root.display().to_string()),
            hook_count: selection.hook_count,
            imported: 0,
            unchanged,
            removed: 0,
            conflicting: 0,
            rejected: 0,
            conflicts: Vec::new(),
            rejections: Vec::new(),
            ignored_paths: selection.ignored_paths,
            activation: "inactive".to_string(),
            installed_hooks: 0,
            enabled_hooks: 0,
        });
    }

    let _lock = lock_store(&store)?;
    index = read_index(&store)?;
    if index
        .bundles
        .iter()
        .find(|bundle| bundle.source_key == source_key)
        .map(|bundle| bundle.source_digest.as_str())
        != existing.as_ref().map(|bundle| bundle.source_digest.as_str())
    {
        return Err(err("Tama policy-bundle store changed while the import was being prepared; retry"));
    }

    let id = transaction_id();
    let stage_root = store.join(format!(".bundle-stage-{id}"));
    let backup_root = store.join(format!(".bundle-backup-{id}"));
    let stage_bundle = stage_root.join("bundle");
    for file in &selection.files {
        let destination = safe_join(&stage_bundle, &file.relative)?;
        if let Some(parent) = destination.parent() {
            fs::create_dir_all(parent)?;
        }
        let mut output = OpenOptions::new().write(true).create_new(true).open(&destination)?;
        output.write_all(&file.bytes)?;
        output.flush()?;
        set_mode(&destination, file.mode)?;
    }

    let record = PolicyBundleRecord {
        source_key: source_key.clone(),
        source_path: source.display().to_string(),
        source_digest: selection.digest.clone(),
        bundle_path: bundle_root.display().to_string(),
        imported_at_unix: timestamp(),
        hook_count: selection.hook_count,
        activation: "inactive".to_string(),
        files: selection
            .files
            .iter()
            .map(|file| BundleFileRecord {
                path: file.relative.clone(),
                sha256: file.sha256.clone(),
                mode: file.mode,
            })
            .collect(),
    };
    index.bundles.retain(|bundle| bundle.source_key != source_key);
    index.bundles.push(record);
    index.bundles.sort_by(|left, right| left.source_path.cmp(&right.source_path));
    let staged_index = stage_root.join("index.json");
    fs::write(&staged_index, serde_json::to_vec_pretty(&index)?)?;
    set_mode(&staged_index, 0o600)?;

    fs::create_dir_all(store.join("bundles"))?;
    fs::create_dir_all(&backup_root)?;
    let current_index = index_path(&store);
    let backup_bundle = backup_root.join("bundle");
    let backup_index = backup_root.join("index.json");
    let mut backed_bundle = false;
    let mut backed_index = false;
    let mut placed_bundle = false;
    let mut placed_index = false;
    let commit = (|| -> Result<()> {
        if bundle_root.exists() {
            fs::rename(&bundle_root, &backup_bundle)?;
            backed_bundle = true;
        }
        if current_index.exists() {
            fs::rename(&current_index, &backup_index)?;
            backed_index = true;
        }
        fs::rename(&stage_bundle, &bundle_root)?;
        placed_bundle = true;
        fs::rename(&staged_index, &current_index)?;
        placed_index = true;
        Ok(())
    })();
    if let Err(error) = commit {
        if placed_index {
            let _ = fs::remove_file(&current_index);
        }
        if placed_bundle {
            let _ = fs::remove_dir_all(&bundle_root);
        }
        if backed_index {
            let _ = fs::rename(&backup_index, &current_index);
        }
        if backed_bundle {
            let _ = fs::rename(&backup_bundle, &bundle_root);
        }
        let _ = fs::remove_dir_all(&stage_root);
        let _ = fs::remove_dir_all(&backup_root);
        return Err(error);
    }
    fs::remove_dir_all(&stage_root).ok();
    fs::remove_dir_all(&backup_root).ok();

    Ok(PolicyBundleImportResult {
        schema: RESULT_SCHEMA.to_string(),
        status: if existing.is_some() { "replaced" } else { "imported" }.to_string(),
        source_path: source.display().to_string(),
        source_digest: Some(selection.digest),
        store_path: store.display().to_string(),
        bundle_path: Some(bundle_root.display().to_string()),
        hook_count: selection.hook_count,
        imported,
        unchanged,
        removed,
        conflicting: 0,
        rejected: 0,
        conflicts: Vec::new(),
        rejections: Vec::new(),
        ignored_paths: selection.ignored_paths,
        activation: "inactive".to_string(),
        installed_hooks: 0,
        enabled_hooks: 0,
    })
}
