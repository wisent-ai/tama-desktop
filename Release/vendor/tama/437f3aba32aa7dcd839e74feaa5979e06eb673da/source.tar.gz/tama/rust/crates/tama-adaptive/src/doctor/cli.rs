//! Port of `src/adaptive/doctor/cli.mjs`: adaptive doctor CLI —
//! threshold-free state/status, repair, and installation.

use sha2::{Digest, Sha256};
use std::io::Write;
use std::path::Path;

use super::evidence::live_script_path;
use super::install::{claude_config, install, uninstall};
use super::repair::{apply_proposal, build_catalog_hooks, propose, read_closed_telemetry_events};
use crate::engine::{load_engine, Engine};
use crate::telemetry::open_telemetry;
use crate::util::{js_string, repo_root};
use crate::EXIT_USAGE;

fn usage() -> i32 {
    let lines = [
        "adaptive doctor <command>",
        "",
        "Commands:",
        "  status                                    Per-hook tier, mode, projected state, telemetry transport",
        "  drift                                     Live hook scripts vs repo archive content hashes",
        "  queue                                     Queued repair requests",
        "  repair <hook-id> [--patch-file <path>]    Draft and validate a repair proposal",
        "  apply <proposal-dir>                      Apply a validated proposal (owner consent required)",
        "  install | uninstall                       Manage the legacy-runner shim (owner consent required)",
        "  claude-config                             Print the Claude settings routing fragment",
    ];
    let _ = writeln!(std::io::stderr(), "{}", lines.join("\n"));
    EXIT_USAGE
}

fn hook_ids(core: &Engine, rows: &[serde_json::Value]) -> Vec<String> {
    let mut ids: Vec<String> = Vec::new();
    for config in core.registry.events.values() {
        for hook in &config.hooks {
            if !hook.id.is_empty() && !ids.contains(&hook.id) {
                ids.push(hook.id.clone());
            }
        }
    }
    for row in rows {
        if let Some(id) = row.get("id").and_then(|v| v.as_str()) {
            if !id.is_empty() && !ids.contains(&id.to_string()) {
                ids.push(id.to_string());
            }
        }
    }
    ids.sort();
    ids
}

/// `?? 'default'` with `String(...)` rendering for present values.
fn autonomy(policy: &serde_json::Value, key: &str, fallback: &str) -> String {
    policy
        .get("autonomy")
        .and_then(|a| a.get(key))
        .filter(|v| !v.is_null())
        .map(js_string)
        .unwrap_or_else(|| fallback.to_string())
}

fn cmd_status(core: &Engine) -> Result<i32, String> {
    let states = core.state_snapshot(None);
    let mut ids = hook_ids(core, &[]);
    if let Some(map) = states.as_object() {
        for id in map.keys() {
            if !ids.contains(id) {
                ids.push(id.clone());
            }
        }
    }
    ids.sort();
    println!(
        "autonomy={} lexical={} explicitCorrection={} repair={}",
        autonomy(&core.policy, "automaticCeiling", "warn"),
        autonomy(&core.policy, "lexicalFrustrationAndModel", "recommendation-only"),
        autonomy(&core.policy, "explicitCausalCorrection", "qualifying-evidence"),
        autonomy(&core.policy, "repair", "proposal-only"),
    );
    for id in &ids {
        let tier = core.tier_of(id);
        let state = core.state_snapshot(Some(id));
        let identity = core.source_identity(id);
        let phase = state.get("phase").map(js_string).unwrap_or_else(|| "undefined".to_string());
        let baseline = match state.get("recoveredRecord") {
            Some(serde_json::Value::Array(record)) => record.len().to_string(),
            _ => "cold".to_string(),
        };
        let open_run = state
            .get("activeRun")
            .and_then(|v| v.as_array())
            .map(|run| run.len().to_string())
            .unwrap_or_else(|| "undefined".to_string());
        let contested = state.get("contestedBlockObserved").and_then(|v| v.as_bool()) == Some(true);
        println!(
            "{}",
            [
                id.clone(),
                format!("tier={}", tier.name),
                format!("mode={}", core.effective_mode(id)),
                format!("phase={}", phase),
                format!("baseline={}", baseline),
                format!("openRun={}", open_run),
                format!("source={}", if identity.verifiable { "verified" } else { "unverified" }),
                format!("contested={}", contested),
            ]
            .join(" ")
        );
    }
    let transport = open_telemetry(&core.state_dir);
    println!("telemetry={}", ordered_status_json(&transport.status()));
    transport.close();
    Ok(0)
}

/// `JSON.stringify(transport.status())` — JS object literals keep insertion
/// order (`open, ready, acked, validReady, reclaimable, legacy`).
fn ordered_status_json(status: &serde_json::Value) -> String {
    let mut parts = Vec::new();
    for key in ["open", "ready", "acked", "validReady", "reclaimable", "legacy"] {
        if let Some(value) = status.get(key) {
            parts.push(format!(
                "\"{}\":{}",
                key,
                serde_json::to_string(value).unwrap_or_default()
            ));
        }
    }
    format!("{{{}}}", parts.join(","))
}

/// `hashFile(path)` — `Ok(None)` for missing, errors propagate.
fn hash_file(path: Option<&Path>) -> Result<Option<String>, String> {
    let Some(path) = path else { return Ok(None) };
    if !path.exists() {
        return Ok(None);
    }
    let bytes = std::fs::read(path).map_err(|e| format!("Error: {}", e))?;
    Ok(Some(format!("{:x}", Sha256::digest(&bytes))))
}

fn cmd_drift() -> Result<i32, String> {
    let root = repo_root();
    let catalog_hooks = build_catalog_hooks(&root);
    let mut drift_count = 0u64;
    for hook in &catalog_hooks {
        let Some(source_path) = &hook.source_path else { continue };
        let live = live_script_path(&hook.command);
        let archive = root.join(source_path);
        let live_hash = hash_file(live.as_deref().map(Path::new))?;
        let archive_hash = hash_file(Some(&archive))?;
        if live_hash.is_none() || archive_hash.is_none() {
            println!(
                "MISSING {} live={} archive={}",
                hook.id,
                live.clone().unwrap_or_else(|| "-".to_string()),
                archive.display()
            );
            drift_count += 1;
        } else if live_hash == archive_hash {
            println!("OK {}", hook.id);
        } else {
            println!(
                "DRIFT {} live={} archive={}",
                hook.id,
                live.unwrap_or_default(),
                archive.display()
            );
            drift_count += 1;
        }
    }
    Ok(if drift_count > 0 { 1 } else { 0 })
}

fn cmd_queue(core: &Engine) -> Result<i32, String> {
    let rows: Vec<serde_json::Value> = read_closed_telemetry_events(&core.state_dir)?
        .into_iter()
        .filter(|row| row.get("type").and_then(|v| v.as_str()) == Some("repair_proposal"))
        .collect();
    if rows.is_empty() {
        println!("repair queue empty");
        return Ok(0);
    }
    for row in &rows {
        let timestamp = match row.get("ts").and_then(|v| v.as_u64()) {
            Some(ts) => crate::util::iso8601(ts),
            None => "unknown-time".to_string(),
        };
        let render = |key: &str, fallback: &str| {
            row.get(key).filter(|v| !v.is_null()).map(js_string).unwrap_or_else(|| fallback.to_string())
        };
        println!(
            "{}",
            [
                timestamp,
                render("id", "?"),
                format!("kind={}", render("kind", "?")),
                format!("evidence={}", render("evidence", "-")),
            ]
            .join(" ")
        );
    }
    Ok(0)
}

fn run(args: &[String]) -> Result<i32, String> {
    let command = args.first().map(String::as_str);
    let rest = if args.is_empty() { &[][..] } else { &args[1..] };
    match command {
        Some("status") => cmd_status(&load_engine()),
        Some("drift") => cmd_drift(),
        Some("queue") => cmd_queue(&load_engine()),
        Some("repair") => {
            let hook_id = rest.first().map(String::as_str);
            match hook_id {
                None => Ok(usage()),
                Some(id) if id.starts_with("--") => Ok(usage()),
                Some(id) => {
                    let flag_index = rest.iter().position(|arg| arg == "--patch-file");
                    let patch_file = flag_index.and_then(|index| rest.get(index + 1));
                    if flag_index.is_some() && patch_file.is_none() {
                        return Ok(usage());
                    }
                    let report = propose(id, patch_file.map(String::as_str))?;
                    println!("{}", serde_json::to_string_pretty(&report).unwrap_or_default());
                    let ok = report.get("ok").and_then(|v| v.as_bool()) == Some(true);
                    Ok(if ok { 0 } else { 1 })
                }
            }
        }
        Some("apply") => {
            let Some(proposal_dir) = rest.first() else { return Ok(usage()) };
            apply_proposal(proposal_dir)
        }
        Some("install") => Ok(install()),
        Some("uninstall") => Ok(uninstall()),
        Some("claude-config") => Ok(claude_config()),
        _ => Ok(usage()),
    }
}

/// `main(argv)` from `doctor/cli.mjs`: `args` excludes the program name.
pub fn main(args: &[String]) -> i32 {
    match run(args) {
        Ok(code) => code,
        Err(error) => {
            let _ = writeln!(std::io::stderr(), "doctor: {}", error);
            1
        }
    }
}
