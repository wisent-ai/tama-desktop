//! Rust port of `src/violations/find-violations.mjs`.
//! Scans a repository for existing violations of the content rules enforced by
//! the shared pre-write hook by replaying the real hook script against every
//! enumerated file (synthetic Write payloads), plus the max-files-per-folder
//! rule checked directly. Read-only: target files are never written.

use serde::Serialize;
use std::collections::HashSet;
use std::io::Write;
use std::path::Path;
use std::process::{Command, Stdio};

use crate::{basename, extname, first_line, locale_compare, relative_path, resolve_path};

pub const HOOK_ID: &str = "pre-write-edit";
const MAX_BYTES: u64 = 524_288;
const BINARY_SNIFF_BYTES: usize = 8_192;
const FOLDER_FILE_LIMIT: u64 = 5;

// Mirrors the IS_SYSTEM gate in pre_write_edit.sh. The JS original is the
// regex /node_modules|\.git\/|\.github\/workflows\/|\/scripts\/worker\/deploy\/
// |\.next|__pycache__|\/\.claude\/|\/\.factory\/|\/\.codex\/|\/\.shared-hooks\/
// |\/chromium-build\// — every alternative is a literal substring, so plain
// `contains` checks reproduce it exactly (no regex crate available).
const SYSTEM_PATH_FRAGMENTS: [&str; 11] = [
    "node_modules",
    ".git/",
    ".github/workflows/",
    "/scripts/worker/deploy/",
    ".next",
    "__pycache__",
    "/.claude/",
    "/.factory/",
    "/.codex/",
    "/.shared-hooks/",
    "/chromium-build/",
];
const SYSTEM_DIR_NAMES: [&str; 5] = ["node_modules", ".git", ".next", "__pycache__", "chromium-build"];
// Beyond the hook's IS_SYSTEM list: third-party vendored and build-output
// trees. The hook gates new agent writes; a repo audit should not flag
// code the project did not author.
const VENDOR_DIR_NAMES: [&str; 7] = ["dist", "build", "vendor", "target", ".venv", "venv", "coverage"];
// Mirrors the folder-density case exemptions in pre_write_edit.sh:
// /\/(supabase\/migrations|node_modules|\.git|__pycache__|tests|migrations)/
const FOLDER_EXEMPT_FRAGMENTS: [&str; 6] = [
    "/supabase/migrations",
    "/node_modules",
    "/.git",
    "/__pycache__",
    "/tests",
    "/migrations",
];

const MODULE_EXTENSIONS: [&str; 17] = [
    ".js", ".mjs", ".cjs", ".ts", ".tsx", ".py", ".sh", ".json", ".md", ".txt", ".yml", ".yaml",
    ".toml", ".sql", ".swift", ".css", ".html",
];
// Rule-gaming content patterns: /data:text/javascript/ and /globalThis\.__/
// (both literal substrings; the JS original concatenates the first one to
// dodge the hook's own scan).
const GAMING_CONTENT: [&str; 2] = ["data:text/javascript", "globalThis.__"];

#[derive(Debug, Clone, Serialize)]
pub struct Violation {
    pub hook: String,
    pub rule: String,
    pub path: String,
    pub message: String,
}

#[derive(Debug, Clone, Serialize)]
pub struct SkippedFile {
    pub path: String,
    pub reason: String,
}

#[derive(Debug, Clone, Serialize)]
pub struct ScanError {
    pub path: String,
    pub message: String,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ScanReport {
    pub repo: String,
    pub hook: String,
    pub mode: String,
    pub scanned_files: usize,
    pub skipped_files: Vec<SkippedFile>,
    pub violations: Vec<Violation>,
    pub errors: Vec<ScanError>,
    /// Added by the multi-target orchestration (`scan-repos`), absent from a
    /// bare `scanRepo` result — mirrors `{ ...report, via }`.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub via: Option<String>,
}

#[derive(Debug, Clone, Serialize)]
pub struct Finding {
    pub kind: String,
    pub path: String,
}

#[derive(Debug, Clone, Serialize)]
pub struct GamingResult {
    pub skipped: bool,
    pub findings: Vec<Finding>,
}

#[derive(Serialize)]
struct HookPayload<'a> {
    tool_name: &'a str,
    tool_input: ToolInput<'a>,
}

#[derive(Serialize)]
struct ToolInput<'a> {
    file_path: &'a str,
    content: &'a str,
}

fn is_system_path(path: &str) -> bool {
    SYSTEM_PATH_FRAGMENTS.iter().any(|fragment| path.contains(fragment))
}

/// Mirrors `ruleKey`: first stderr line minus the BLOCKED: prefix, every
/// number (optionally signed) replaced by `N`, cut to 72 characters.
fn rule_key(stderr: &str) -> String {
    let line = first_line(stderr);
    let clean = match line.strip_prefix("BLOCKED:") {
        Some(rest) => rest.trim_start().to_string(),
        None => line,
    };
    let mut keyed = String::new();
    let chars: Vec<char> = clean.chars().collect();
    let mut i = 0;
    while i < chars.len() {
        let c = chars[i];
        if c.is_ascii_digit() || (c == '-' && i + 1 < chars.len() && chars[i + 1].is_ascii_digit()) {
            keyed.push('N');
            if c == '-' {
                i += 1;
            }
            while i < chars.len() && chars[i].is_ascii_digit() {
                i += 1;
            }
        } else {
            keyed.push(c);
            i += 1;
        }
    }
    let keyed: String = keyed.chars().take(72).collect();
    if keyed.is_empty() {
        "unknown-rule".to_string()
    } else {
        keyed
    }
}

enum Probe {
    Skip(&'static str),
    SkipOwned(String),
    Content(Vec<u8>),
}

fn probe_file(path: &str) -> Probe {
    let info = match std::fs::metadata(path) {
        Ok(info) => info,
        Err(_) => return Probe::Skip("unreadable"),
    };
    if !info.is_file() {
        return Probe::Skip("not a regular file");
    }
    if info.len() > MAX_BYTES {
        return Probe::SkipOwned(format!("larger than {} bytes", MAX_BYTES));
    }
    let buffer = match std::fs::read(path) {
        Ok(buffer) => buffer,
        Err(_) => return Probe::Skip("unreadable"),
    };
    if buffer
        .iter()
        .take(BINARY_SNIFF_BYTES)
        .any(|byte| *byte == 0)
    {
        return Probe::Skip("binary content");
    }
    Probe::Content(buffer)
}

fn git_files(repo: &str) -> Option<Vec<String>> {
    let out = Command::new("git")
        .args(["ls-files", "-z", "--cached", "--others", "--exclude-standard"])
        .current_dir(repo)
        .output()
        .ok()?;
    if out.status.code() != Some(0) {
        return None;
    }
    let stdout = String::from_utf8_lossy(&out.stdout);
    let mut seen: HashSet<String> = HashSet::new();
    let mut files = Vec::new();
    for entry in stdout.split('\0') {
        if entry.is_empty() {
            continue;
        }
        let full = resolve_path(&[Path::new(repo), Path::new(entry)]);
        let full = full.to_string_lossy().into_owned();
        if !seen.insert(full.clone()) {
            continue;
        }
        files.push(full);
    }
    Some(files)
}

fn walk_files(root_dir: &str) -> Vec<String> {
    let mut files = Vec::new();
    fn visit(dir: &str, files: &mut Vec<String>) {
        let entries = match std::fs::read_dir(dir) {
            Ok(entries) => entries,
            Err(_) => return,
        };
        // Node `readdirSync` returns entries sorted by name.
        let mut entries: Vec<_> = entries.flatten().collect();
        entries.sort_by_key(|e| e.file_name());
        for entry in entries {
            let name = entry.file_name().to_string_lossy().into_owned();
            let full = Path::new(dir).join(&name).to_string_lossy().into_owned();
            let file_type = match entry.file_type() {
                Ok(file_type) => file_type,
                Err(_) => continue,
            };
            if file_type.is_dir() {
                if !SYSTEM_DIR_NAMES.contains(&name.as_str()) && !VENDOR_DIR_NAMES.contains(&name.as_str()) {
                    visit(&full, files);
                }
            } else if file_type.is_file() {
                files.push(full);
            }
        }
    }
    visit(root_dir, &mut files);
    files
}

pub fn is_vendor_path(path: &str) -> bool {
    path.split('/').any(|segment| VENDOR_DIR_NAMES.contains(&segment))
}

pub struct Enumeration {
    pub files: Vec<String>,
    pub mode: &'static str,
}

pub fn enumerate_files(repo: &str) -> Enumeration {
    if let Some(tracked) = git_files(repo) {
        return Enumeration { files: tracked, mode: "git" };
    }
    Enumeration { files: walk_files(repo), mode: "walk" }
}

/// Per-repo audit exclusions from `.tama-violations-ignore` at the repo root:
/// one exact relative path per line, directories with a trailing slash,
/// `#` comments. A missing/unreadable file yields no entries, like the JS
/// `catch { /* missing stays null */ }`.
pub fn read_ignore_file(repo: &str) -> Vec<String> {
    let text = match std::fs::read_to_string(Path::new(repo).join(".tama-violations-ignore")) {
        Ok(text) => text,
        Err(_) => return Vec::new(),
    };
    text.split('\n')
        .map(|raw| raw.trim())
        .filter(|line| !line.is_empty() && !line.starts_with('#'))
        .map(|line| line.to_string())
        .collect()
}

pub fn is_ignored(rel_path: &str, entries: &[String]) -> bool {
    for entry in entries {
        if entry.ends_with('/') {
            if rel_path.starts_with(entry.as_str()) {
                return true;
            }
        } else if rel_path == entry {
            return true;
        }
    }
    false
}

struct HookRun {
    status: i32,
    stderr: String,
}

/// Runs `bash <hookPath>` with the JSON payload on stdin. Stdout is drained
/// and discarded, stderr captured; a spawn failure mirrors the JS `error`
/// handler as status -1 with the error text in stderr.
fn run_hook(hook_path: &str, payload: &str) -> HookRun {
    let child = Command::new("bash")
        .arg(hook_path)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn();
    let mut child = match child {
        Ok(child) => child,
        Err(error) => return HookRun { status: -1, stderr: format!("{}", error) },
    };
    if let Some(mut stdin) = child.stdin.take() {
        // A hook that exits early closes stdin; ignore the broken pipe,
        // like the JS `child.stdin.on('error', () => {})`.
        let _ = stdin.write_all(payload.as_bytes());
    }
    match child.wait_with_output() {
        Ok(output) => HookRun {
            status: output.status.code().unwrap_or(-1),
            stderr: String::from_utf8_lossy(&output.stderr).into_owned(),
        },
        Err(error) => HookRun { status: -1, stderr: format!("{}", error) },
    }
}

pub fn folder_violations(repo: &str, files: &[String], ignore_entries: &[String]) -> Vec<Violation> {
    let mut counts: std::collections::HashMap<String, u64> = std::collections::HashMap::new();
    for path in files {
        if is_system_path(path) {
            continue;
        }
        if is_vendor_path(path) {
            continue;
        }
        if is_ignored(&relative_path(Path::new(repo), Path::new(path)), ignore_entries) {
            continue;
        }
        let info = match std::fs::metadata(path) {
            Ok(info) => info,
            Err(_) => continue,
        };
        if !info.is_file() {
            continue;
        }
        let dir = Path::new(path)
            .parent()
            .map(|parent| parent.to_string_lossy().into_owned())
            .unwrap_or_default();
        *counts.entry(dir).or_insert(0) += 1;
    }
    let mut violations = Vec::new();
    for (dir, count) in counts {
        if count <= FOLDER_FILE_LIMIT {
            continue;
        }
        if FOLDER_EXEMPT_FRAGMENTS.iter().any(|fragment| dir.contains(fragment)) {
            continue;
        }
        let rel = relative_path(Path::new(repo), Path::new(&dir));
        violations.push(Violation {
            hook: HOOK_ID.to_string(),
            rule: format!("Folder has N files (max {})", FOLDER_FILE_LIMIT),
            path: if rel.is_empty() { ".".to_string() } else { rel },
            message: format!(
                "Folder has {} files (max {}). Move files into sub-folders or consolidate.",
                count, FOLDER_FILE_LIMIT
            ),
        });
    }
    violations
}

/// Port of `scanRepo`. The JS original replays hooks through an 8-lane async
/// pool; this port runs them sequentially. Output is identical because the
/// violation list is sorted before returning (only wall-clock time differs).
pub fn scan_repo(repo: &Path, hook_path: &Path) -> ScanReport {
    let abs_repo = resolve_path(&[repo]).to_string_lossy().into_owned();
    let hook = hook_path.to_string_lossy().into_owned();
    let enumeration = enumerate_files(&abs_repo);
    let ignore_entries = read_ignore_file(&abs_repo);
    let mut skipped_files = Vec::new();
    let mut pending: Vec<(String, String)> = Vec::new();
    for path in &enumeration.files {
        if is_system_path(path) {
            continue;
        }
        let rel = relative_path(Path::new(&abs_repo), Path::new(path));
        if is_ignored(&rel, &ignore_entries) {
            skipped_files.push(SkippedFile {
                path: rel,
                reason: "ignored by .tama-violations-ignore".to_string(),
            });
            continue;
        }
        if is_vendor_path(path) {
            skipped_files.push(SkippedFile {
                path: rel,
                reason: "vendored or build-output dir".to_string(),
            });
            continue;
        }
        match probe_file(path) {
            Probe::Skip(reason) => skipped_files.push(SkippedFile {
                path: rel,
                reason: reason.to_string(),
            }),
            Probe::SkipOwned(reason) => skipped_files.push(SkippedFile { path: rel, reason }),
            Probe::Content(buffer) => {
                pending.push((path.clone(), String::from_utf8_lossy(&buffer).into_owned()))
            }
        }
    }
    let mut violations = Vec::new();
    let mut errors = Vec::new();
    for (path, content) in &pending {
        let payload = serde_json::to_string(&HookPayload {
            tool_name: "Write",
            tool_input: ToolInput { file_path: path, content },
        })
        .unwrap_or_default();
        let run = run_hook(&hook, &payload);
        let rel = relative_path(Path::new(&abs_repo), Path::new(path));
        if run.status == 2 {
            violations.push(Violation {
                hook: HOOK_ID.to_string(),
                rule: rule_key(&run.stderr),
                path: rel,
                message: first_line(&run.stderr),
            });
        } else if run.status != 0 {
            errors.push(ScanError {
                path: rel,
                message: format!("hook exited {}: {}", run.status, first_line(&run.stderr)),
            });
        }
    }
    violations.extend(folder_violations(&abs_repo, &enumeration.files, &ignore_entries));
    violations.sort_by(|a, b| locale_compare(&a.path, &b.path));
    ScanReport {
        repo: abs_repo,
        hook,
        mode: enumeration.mode.to_string(),
        scanned_files: pending.len(),
        skipped_files,
        violations,
        errors,
        via: None,
    }
}

/// Rule-gaming detector: flags working-tree changes that comply with the
/// letter of the hook rules while dodging their spirit. Git repositories
/// only; other trees report `{ skipped: true, findings: [] }`.
pub fn detect_gaming(repo: &Path) -> GamingResult {
    let out = Command::new("git")
        .args(["status", "--porcelain"])
        .current_dir(repo)
        .output();
    let out = match out {
        Ok(out) => out,
        Err(_) => return GamingResult { skipped: true, findings: Vec::new() },
    };
    if out.status.code() != Some(0) {
        return GamingResult { skipped: true, findings: Vec::new() };
    }
    let stdout = String::from_utf8_lossy(&out.stdout);
    let mut findings = Vec::new();
    let mut changed_paths: Vec<String> = Vec::new();
    for line in stdout.split('\n') {
        if line.trim().is_empty() {
            continue;
        }
        let entry = line.chars().skip(3).collect::<String>().trim().to_string();
        let renamed = entry.contains(" -> ");
        let parts: Vec<&str> = entry.split(" -> ").collect();
        let old_path: Option<String> = if renamed { Some(parts[0].to_string()) } else { None };
        let new_path: String = if renamed { parts[1].to_string() } else { entry.clone() };
        if let Some(old_path) = &old_path {
            let old_has_test = basename(old_path).to_lowercase().contains("test");
            let new_has_test = basename(&new_path).to_lowercase().contains("test");
            if old_has_test && !new_has_test {
                findings.push(Finding {
                    kind: "test-gate-rename-dodge".to_string(),
                    path: format!("{} -> {}", old_path, new_path),
                });
            }
        }
        changed_paths.push(new_path);
    }
    for path in &changed_paths {
        let ext = extname(path);
        if !ext.is_empty() && !MODULE_EXTENSIONS.contains(&ext.as_str()) {
            findings.push(Finding {
                kind: "non-module-extension".to_string(),
                path: path.clone(),
            });
            continue;
        }
        let full = repo.join(path);
        let info = match std::fs::metadata(&full) {
            Ok(info) => info,
            Err(_) => continue,
        };
        if !info.is_file() || info.len() > MAX_BYTES {
            continue;
        }
        let content = match std::fs::read(&full) {
            Ok(bytes) => String::from_utf8_lossy(&bytes).into_owned(),
            Err(_) => continue,
        };
        for pattern in GAMING_CONTENT {
            if content.contains(pattern) {
                findings.push(Finding {
                    kind: "smuggled-runtime-blob".to_string(),
                    path: path.clone(),
                });
                break;
            }
        }
    }
    GamingResult { skipped: false, findings }
}
