//! Consent state for `block_unapproved_audits`: the approval policy file and
//! the per-scope audit-gate records.
//!
//! Two files matter, and both keep the paths the Python uses verbatim.
//!
//! * Approval, read only:
//!   `$DEVICE_LEVEL_AUDITS_POLICY`, else `~/.config/agent-policy/device_level_audits.json`.
//!   Approved when its JSON object has `device_level_audits_approved` set to
//!   the boolean `true`, or when `DEVICE_LEVEL_AUDITS_APPROVED=1` is exported
//!   outside the session.
//! * Gate record, read, written and deleted:
//!   `${XDG_STATE_HOME:-~/.local/state}/jeden-hooks/audit-consent/<scope>.json`,
//!   where `<scope>` is the sha256 of `session:<session_id>` or, without one,
//!   of `runtime:<runtime>\ncwd:<cwd>`. Written through a `.<name>.<pid>.tmp`
//!   sibling and renamed; deleted on approval and on every user prompt.

use super::pystr;
use super::pyvalue::{first_truthy_py_str, py_json_dumps};
use crate::util::home_dir;
use serde_json::{json, Value};
use std::path::PathBuf;
use tama_hooks::sha256::sha256_hex;

pub const APPROVAL_ENV: &str = "DEVICE_LEVEL_AUDITS_APPROVED";
pub const POLICY_FIELD: &str = "device_level_audits_approved";
const APPROVAL_VALUE: &str = "1";
const POLICY_ENV: &str = "DEVICE_LEVEL_AUDITS_POLICY";
const POLICY_CONFIG_DIR: &str = ".config";
const POLICY_AGENT_DIR: &str = "agent-policy";
const POLICY_FILE: &str = "device_level_audits.json";
const STATE_HOME_ENV: &str = "XDG_STATE_HOME";
const STATE_LOCAL_DIR: &str = ".local";
const STATE_BASE_DIR: &str = "state";
const STATE_NAMESPACE: &str = "jeden-hooks";
const STATE_BUCKET: &str = "audit-consent";
const REASON_KEY: &str = "reason";
const SCHEMA_KEY: &str = "schemaVersion";
/// `{"schemaVersion": 1, "reason": ...}` in the Python writer.
const SCHEMA_VERSION_TEXT: &str = "1";

const SESSION_KEY: &str = "session_id";
const RUNTIME_KEY: &str = "runtime";
const CWD_KEYS: &[&str] = &["cwd", "project_dir"];

fn schema_version() -> u64 {
    SCHEMA_VERSION_TEXT.parse().unwrap_or_default()
}

pub fn policy_path() -> PathBuf {
    match std::env::var(POLICY_ENV) {
        Ok(value) if !value.is_empty() => PathBuf::from(value),
        _ => home_dir()
            .join(POLICY_CONFIG_DIR)
            .join(POLICY_AGENT_DIR)
            .join(POLICY_FILE),
    }
}

/// `POLICY_PATH.name`.
pub fn policy_name() -> String {
    policy_path()
        .file_name()
        .map(|name| name.to_string_lossy().to_string())
        .unwrap_or_default()
}

pub fn approved() -> bool {
    if std::env::var(APPROVAL_ENV).ok().as_deref() == Some(APPROVAL_VALUE) {
        return true;
    }
    let text = match std::fs::read_to_string(policy_path()) {
        Ok(text) => text,
        Err(_) => return false,
    };
    let value: Value = match serde_json::from_str(&text) {
        Ok(value) => value,
        Err(_) => return false,
    };
    value.get(POLICY_FIELD) == Some(&Value::Bool(true))
}

fn state_root() -> PathBuf {
    let base = match std::env::var(STATE_HOME_ENV) {
        Ok(value) if !value.is_empty() => PathBuf::from(value),
        _ => home_dir().join(STATE_LOCAL_DIR).join(STATE_BASE_DIR),
    };
    base.join(STATE_NAMESPACE).join(STATE_BUCKET)
}

pub fn scope_key(payload: &Value) -> String {
    let session_id = pystr::strip(&first_truthy_py_str(payload, &[SESSION_KEY])).to_string();
    let material = if !session_id.is_empty() {
        format!("session:{session_id}")
    } else {
        let runtime = first_truthy_py_str(payload, &[RUNTIME_KEY]);
        let cwd = first_truthy_py_str(payload, CWD_KEYS);
        format!("runtime:{runtime}\ncwd:{cwd}")
    };
    sha256_hex(material.as_bytes())
}

pub fn state_path(payload: &Value) -> PathBuf {
    state_root().join(format!("{}.json", scope_key(payload)))
}

/// `Path.unlink()` swallowing only `FileNotFoundError`; any other `OSError`
/// still ends the Python process.
pub fn clear_state(payload: &Value) -> std::io::Result<()> {
    match std::fs::remove_file(state_path(payload)) {
        Err(error) if error.kind() != std::io::ErrorKind::NotFound => Err(error),
        _ => Ok(()),
    }
}

pub fn read_state(payload: &Value) -> Option<Value> {
    let text = std::fs::read_to_string(state_path(payload)).ok()?;
    let value: Value = serde_json::from_str(&text).ok()?;
    if value.is_object() {
        Some(value)
    } else {
        None
    }
}

pub fn write_state(payload: &Value, reason: &str) -> std::io::Result<()> {
    let path = state_path(payload);
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)?;
    }
    let name = path
        .file_name()
        .map(|name| name.to_string_lossy().to_string())
        .unwrap_or_default();
    let temporary = path.with_file_name(format!(".{name}.{}.tmp", std::process::id()));
    let record = json!({ REASON_KEY: reason, SCHEMA_KEY: schema_version() });
    std::fs::write(&temporary, format!("{}\n", py_json_dumps(&record)))?;
    std::fs::rename(&temporary, &path)
}

pub fn recorded_reason(state: &Value, fallback: &str) -> String {
    let found = first_truthy_py_str(state, &[REASON_KEY]);
    if found.is_empty() {
        fallback.to_string()
    } else {
        found
    }
}
