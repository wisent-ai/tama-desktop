//! Rust port of `shared-hooks/omp-shared-hooks.js`.
//!
//! The JS file is an OMP extension module: its default export receives the
//! OMP host object (`pi`) and registers commands, tools and event handlers.
//! A Rust binary cannot be loaded as an OMP extension, so the runtime state
//! machine lives here behind the [`OmpHost`] trait (which stands in for `pi`)
//! and the `tama-omp-hooks` binary reproduces the standalone behavior of
//! `node omp-shared-hooks.js` (top-level registry snapshot, exit 0).

use crate::capability::{
    capability_environment, normalize_capability_grants, normalized_capability,
    CapabilityIdentity, CAPABILITY_SCHEMA_VERSION,
};
use crate::hook_exec::{
    decision_from_output, looks_like_malfunction, run_hook_command,
};
use crate::registry::registry_checksum;
use crate::util::{
    atomic_write_json, home_dir, iso_now, js_string, js_string_or_empty, js_truthy, load_json,
    now_millis, random_uuid, sha256_hex,
};
use serde_json::{json, Map, Value};
use std::collections::BTreeSet;
use std::path::{Path, PathBuf};

pub const SESSION_OVERRIDE_TOOL: &str = "tama_set_session_hook";
pub const SESSION_ENABLE_ALL_TOOL: &str = "tama_enable_all_session_hooks";
pub const SESSION_CAPABILITY_TOOL: &str = "tama_request_session_capability";
pub const RUNTIME_RELOAD_TOOL: &str = "tama_reload_hook_runtime";
pub const RUNTIME_STATUS_TOOL: &str = "tama_hook_runtime_status";
pub const SESSION_OVERRIDE_ENTRY: &str = "tama:session-hook-overrides";
pub const SESSION_CONTROL_SCHEMA: &str = "ai.wisent.tama.session-control.v2";
pub const EMERGENCY_STATE_SCHEMA: &str = "ai.wisent.tama.hook-emergency-state.v1";
pub const HOOK_TIMEOUT_MS: u64 = 10000;
pub const SESSION_CONTROL_POLL_MS: u64 = 250;

pub fn control_plane_tools() -> [&'static str; 5] {
    [
        SESSION_OVERRIDE_TOOL,
        SESSION_ENABLE_ALL_TOOL,
        SESSION_CAPABILITY_TOOL,
        RUNTIME_RELOAD_TOOL,
        RUNTIME_STATUS_TOOL,
    ]
}

fn tama_state_root() -> PathBuf {
    home_dir().join("Library").join("Application Support").join("Tama")
}

pub fn emergency_state_path() -> PathBuf {
    std::env::var_os("TAMA_EMERGENCY_STATE")
        .map(PathBuf::from)
        .unwrap_or_else(|| tama_state_root().join("hook-emergency-state.json"))
}

pub fn session_control_root() -> PathBuf {
    std::env::var_os("TAMA_SESSION_CONTROL_ROOT")
        .map(PathBuf::from)
        .unwrap_or_else(|| tama_state_root().join("session-control"))
}

pub fn installed_state_path() -> PathBuf {
    std::env::var_os("TAMA_INSTALLED_HOOK_RELEASE")
        .map(PathBuf::from)
        .unwrap_or_else(|| tama_state_root().join("hooks-runtime").join("installed.json"))
}

pub fn registry_path() -> PathBuf {
    std::env::var_os("AGENT_HOOK_REGISTRY")
        .map(PathBuf::from)
        .unwrap_or_else(|| crate::util::shared_hooks_root().join("registry.json"))
}

/// The subset of the OMP host (`pi`) that the runtime logic calls.
pub trait OmpHost {
    /// `pi.appendEntry(customType, data)`.
    fn append_entry(&mut self, custom_type: &str, data: Value);
    /// `ctx.requestReload()` from a tool or event context.
    fn request_reload(&mut self) -> Result<(), String>;
    /// Whether `ctx.reload()` exists (OMP exposes it only to slash-command handlers).
    fn has_reload(&self) -> bool;
    /// `ctx.reload()`.
    fn reload(&mut self) -> Result<(), String>;
    /// `ctx.ui.notify(text, kind)`.
    fn notify(&mut self, text: &str, kind: &str);
    /// `ctx.abort()`.
    fn abort(&mut self);
}

/// Host used when no OMP is attached (standalone runs, tests).
pub struct NullHost;

impl OmpHost for NullHost {
    fn append_entry(&mut self, _custom_type: &str, _data: Value) {}
    fn request_reload(&mut self) -> Result<(), String> {
        Err("OMP is not attached; cannot schedule a deferred runtime reload".to_string())
    }
    fn has_reload(&self) -> bool {
        false
    }
    fn reload(&mut self) -> Result<(), String> {
        Err("OMP exposes reload only to slash-command handlers".to_string())
    }
    fn notify(&mut self, _text: &str, _kind: &str) {}
    fn abort(&mut self) {}
}

/// Result of `registrySnapshot()`.
#[derive(Debug, Clone)]
pub struct RegistrySnapshot {
    pub registry: Value,
    pub hook_ids: BTreeSet<String>,
    pub release_id: String,
    pub catalog_checksum: String,
}

/// Port of `registrySnapshot()`.
pub fn registry_snapshot() -> Result<RegistrySnapshot, String> {
    let path = registry_path();
    let registry = load_json(&path, Value::Null);
    if !registry.is_object() {
        return Err(format!("Invalid Tama hook registry: {}", path.display()));
    }
    let events = registry.get("events").cloned().unwrap_or(Value::Null);
    if !events.is_object() {
        return Err("Tama hook registry has no events object".to_string());
    }
    let expected = js_string_or_empty(registry.get("catalogChecksum"));
    let actual = registry_checksum(&registry);
    if expected.is_empty() || expected != actual {
        return Err(format!(
            "Tama hook registry checksum mismatch: expected {}, actual {}",
            if expected.is_empty() { "missing" } else { &expected },
            actual
        ));
    }
    let mut hook_ids = BTreeSet::new();
    for entry in events.as_object().into_iter().flatten() {
        if let Some(hooks) = entry.1.get("hooks").and_then(Value::as_array) {
            for hook in hooks {
                let id = js_string_or_empty(hook.get("id")).trim().to_string();
                if !id.is_empty() {
                    hook_ids.insert(id);
                }
            }
        }
    }
    let release_id = match registry.get("releaseId") {
        Some(v) if js_truthy(v) => js_string(v),
        _ => "unknown".to_string(),
    };
    Ok(RegistrySnapshot {
        registry,
        hook_ids,
        release_id,
        catalog_checksum: actual,
    })
}

/// Port of the module-level `hooksGloballyDisabled()`.
pub fn hooks_globally_disabled() -> bool {
    let state = load_json(&emergency_state_path(), Value::Null);
    state.get("schema").and_then(Value::as_str) == Some(EMERGENCY_STATE_SCHEMA)
        && state.get("disabled") == Some(&Value::Bool(true))
}

/// Port of `installedReleaseState()`.
pub fn installed_release_state() -> Value {
    let value = load_json(&installed_state_path(), json!({}));
    json!({
        "releaseId": value.get("releaseId").and_then(Value::as_str),
        "catalogChecksum": value.get("catalogChecksum").and_then(Value::as_str),
        "installedAt": value.get("installedAt").and_then(Value::as_str),
    })
}

/// Port of `sessionControlKey`.
pub fn session_control_key(active_session_id: &str) -> String {
    sha256_hex(format!("omp\0{}", active_session_id).as_bytes())
}

/// Port of `normalizedResumeArgv` / `sessionResumeArgv` from
/// session-control.mjs (the only import omp-shared-hooks.js uses).
fn normalized_resume_argv(value: &Value) -> Option<Vec<String>> {
    match value {
        Value::String(s) => normalized_resume_argv(&serde_json::from_str(s).ok()?),
        Value::Array(items) => {
            if items.is_empty() {
                return None;
            }
            let mut out = Vec::new();
            for item in items {
                match item.as_str() {
                    Some(s) if !s.is_empty() => out.push(s.to_string()),
                    _ => return None,
                }
            }
            Some(out)
        }
        _ => None,
    }
}

pub fn session_resume_argv() -> Option<Vec<String>> {
    let raw = std::env::var("TAMA_SESSION_RESUME_ARGV_JSON").ok()?;
    normalized_resume_argv(&Value::String(raw))
}

/// Port of `expandHome`.
pub fn expand_home(command: &str) -> String {
    let home = home_dir().display().to_string();
    let mut out = String::with_capacity(command.len());
    let chars: Vec<char> = command.chars().collect();
    let mut i = 0;
    while i < chars.len() {
        let c = chars[i];
        if c == '~' && (i + 1 == chars.len() || chars[i + 1] == '/') {
            out.push_str(&home);
        } else {
            out.push(c);
        }
        i += 1;
    }
    out.replace("$HOME", &home)
}

/// Port of `registryEvent`.
pub fn registry_event(name: &str) -> String {
    let normalized = name.to_lowercase();
    let event = match normalized.as_str() {
        "read" => "pre_tool_use:read",
        "notebookedit" | "notebook" => "pre_tool_use:notebook",
        "multiedit" => "pre_tool_use:multiedit",
        "write" | "edit" | "apply_patch" => "pre_tool_use:edit",
        "bash" => "pre_tool_use:bash",
        "monitor" | "schedulewakeup" => "pre_tool_use:wait",
        "task" | "agent" => "pre_tool_use:task",
        "todo" => "pre_tool_use:todo",
        "goal" => "pre_tool_use:goal",
        n if n == "ask" || n.ends_with(".ask") || n.ends_with("/ask") || n.ends_with("_ask") => {
            "pre_tool_use:ask"
        }
        "ssh" => "pre_tool_use:ssh",
        "grep" | "glob" | "lsp" | "ast_edit" => "pre_tool_use:lookup",
        _ => "pre_tool_use:eval",
    };
    event.to_string()
}

/// Port of `registryPostEvent`.
pub fn registry_post_event(name: &str) -> String {
    registry_event(name).replacen("pre_tool_use:", "post_tool_use:", 1)
}

/// Port of `toolName`.
pub fn tool_name(event: &Value) -> String {
    js_string_or_empty(event.get("toolName").or_else(|| event.get("name")))
}

/// Port of `toolInput`.
pub fn tool_input(event: &Value) -> Value {
    let value = event.get("input").or_else(|| event.get("params"));
    match value {
        Some(v) if v.is_object() => v.clone(),
        _ => json!({}),
    }
}

/// The mutable OMP runtime state (module-level `let` bindings in JS).
pub struct OmpRuntime {
    pub registry: Value,
    pub known_hook_ids: BTreeSet<String>,
    pub release_id: String,
    pub catalog_checksum: Option<String>,
    pub registry_load_error: Option<String>,
    pub runtime_started_at: String,
    pub reload_count: u64,
    pub last_reload_at: Option<String>,
    pub last_reload_error: Option<String>,
    pub pending_reload_command: Option<String>,
    pub last_decision: Option<Value>,
    pub current_session_id: Option<String>,
    pub current_session_key: Option<String>,
    pub current_session_cwd: Option<String>,
    pub disabled_hook_ids: BTreeSet<String>,
    pub enabled_hook_ids: BTreeSet<String>,
    pub unknown_hook_ids: BTreeSet<String>,
    pub current_capability: Option<Value>,
    pub session_control_state_path: Option<PathBuf>,
    pub session_control_override_path: Option<PathBuf>,
}

impl Default for OmpRuntime {
    fn default() -> Self {
        Self::new()
    }
}

impl OmpRuntime {
    /// Port of the top-level snapshot install (`installRegistrySnapshot` in a
    /// try/catch, errors captured into `registryLoadError`).
    pub fn new() -> Self {
        let mut runtime = OmpRuntime {
            registry: json!({ "events": {} }),
            known_hook_ids: BTreeSet::new(),
            release_id: "unknown".to_string(),
            catalog_checksum: None,
            registry_load_error: None,
            runtime_started_at: iso_now(),
            reload_count: 0,
            last_reload_at: None,
            last_reload_error: None,
            pending_reload_command: None,
            last_decision: None,
            current_session_id: None,
            current_session_key: None,
            current_session_cwd: None,
            disabled_hook_ids: BTreeSet::new(),
            enabled_hook_ids: BTreeSet::new(),
            unknown_hook_ids: BTreeSet::new(),
            current_capability: None,
            session_control_state_path: None,
            session_control_override_path: None,
        };
        match registry_snapshot() {
            Ok(snapshot) => runtime.install_registry_snapshot(snapshot),
            Err(error) => runtime.registry_load_error = Some(error),
        }
        runtime
    }

    pub fn install_registry_snapshot(&mut self, snapshot: RegistrySnapshot) {
        self.registry = snapshot.registry;
        self.known_hook_ids = snapshot.hook_ids;
        self.release_id = snapshot.release_id;
        self.catalog_checksum = Some(snapshot.catalog_checksum);
        self.registry_load_error = None;
    }

    fn capability_identity(&self, control_key: Option<String>) -> CapabilityIdentity {
        CapabilityIdentity {
            control_key,
            release_id: Some(self.release_id.clone()),
            catalog_checksum: self.catalog_checksum.clone(),
        }
    }

    /// Port of `resolvedSessionId`. `session_file` stands in for
    /// `ctx.sessionManager.getSessionFile()`.
    pub fn resolved_session_id(event: Option<&Value>, session_file: Option<&str>) -> Option<String> {
        let explicit = event
            .and_then(|e| {
                e.get("sessionId")
                    .or_else(|| e.get("session_id"))
                    .or_else(|| e.get("session").and_then(|s| s.get("id")))
            })
            .filter(|v| js_truthy(v));
        if let Some(value) = explicit {
            return Some(js_string(value));
        }
        let file = session_file?;
        let name = Path::new(file)
            .file_name()
            .map(|n| n.to_string_lossy().into_owned())?;
        let name = name.strip_suffix(".jsonl").unwrap_or(&name);
        let separator = name.rfind('_');
        Some(match separator {
            Some(index) => name[index + 1..].to_string(),
            None => name.to_string(),
        })
    }

    /// Port of `sanitizedIds` (records unknown ids as a side effect).
    pub fn sanitized_ids(&mut self, values: &Value) -> Vec<String> {
        let mut known = Vec::new();
        if let Some(items) = values.as_array() {
            for value in items {
                let id = js_string_or_empty(Some(value)).trim().to_string();
                if id.is_empty() {
                    continue;
                }
                if self.known_hook_ids.contains(&id) {
                    known.push(id);
                } else {
                    self.unknown_hook_ids.insert(id);
                }
            }
        }
        known.sort();
        known.dedup();
        known
    }

    /// Port of `sanitizedDisabledIds` — session hook disablement is prohibited,
    /// so the disabled list is always dropped.
    pub fn sanitized_disabled_ids(_values: &Value) -> Vec<String> {
        Vec::new()
    }

    /// Port of `restoredHookOverrides`. `branch` stands in for
    /// `ctx.sessionManager.getBranch()`.
    pub fn restored_hook_overrides(
        &mut self,
        branch: Option<&Value>,
        active_session_id: Option<&str>,
    ) -> (Vec<String>, Vec<String>, Option<Value>) {
        let mut restored = json!({
            "disabledHookIds": [],
            "enabledHookIds": [],
            "capability": Value::Null,
        });
        if let Some(session_id) = active_session_id {
            if let Some(entries) = branch.and_then(Value::as_array) {
                for entry in entries {
                    if entry.get("type").and_then(Value::as_str) != Some("custom")
                        || entry.get("customType").and_then(Value::as_str) != Some(SESSION_OVERRIDE_ENTRY)
                    {
                        continue;
                    }
                    let data = entry.get("data").cloned().unwrap_or(Value::Null);
                    if data.get("sessionId").and_then(Value::as_str) != Some(session_id) {
                        continue;
                    }
                    restored = json!({
                        "disabledHookIds": data.get("disabledHookIds").cloned().unwrap_or(Value::Null),
                        "enabledHookIds": data.get("enabledHookIds").cloned().unwrap_or(Value::Null),
                        "capability": data.get("capability").cloned().unwrap_or(Value::Null),
                    });
                }
            }
        }
        let disabled = Self::sanitized_disabled_ids(restored.get("disabledHookIds").unwrap_or(&Value::Null));
        let enabled = self.sanitized_ids(restored.get("enabledHookIds").unwrap_or(&Value::Null));
        let identity = self.capability_identity(
            active_session_id.map(session_control_key),
        );
        let capability = normalized_capability(
            restored.get("capability").unwrap_or(&Value::Null),
            active_session_id,
            now_millis(),
            &identity,
        );
        (disabled, enabled, capability)
    }

    /// Port of `overrideState()` — revalidates the current capability first.
    pub fn override_state(&mut self) -> Value {
        let identity = self.capability_identity(self.current_session_key.clone());
        let current = self.current_capability.clone().unwrap_or(Value::Null);
        let session_id = self.current_session_id.clone();
        self.current_capability =
            normalized_capability(&current, session_id.as_deref(), now_millis(), &identity);
        json!({
            "disabledHookIds": self.disabled_hook_ids.iter().cloned().collect::<Vec<_>>(),
            "enabledHookIds": self.enabled_hook_ids.iter().cloned().collect::<Vec<_>>(),
            "capability": self.current_capability.clone().unwrap_or(Value::Null),
        })
    }

    /// Port of `appendOverrideEntry`.
    pub fn append_override_entry(&mut self, host: &mut dyn OmpHost) -> Value {
        let overrides = self.override_state();
        host.append_entry(
            SESSION_OVERRIDE_ENTRY,
            json!({
                "sessionId": self.current_session_id.clone().unwrap_or_default(),
                "disabledHookIds": overrides.get("disabledHookIds").cloned().unwrap_or(Value::Null),
                "enabledHookIds": overrides.get("enabledHookIds").cloned().unwrap_or(Value::Null),
                "capability": overrides.get("capability").cloned().unwrap_or(Value::Null),
            }),
        );
        overrides
    }

    /// Port of `externalOverrideState`.
    pub fn external_override_state(&mut self) -> Option<Value> {
        let (session_id, session_key, path) = match (
            self.current_session_id.clone(),
            self.current_session_key.clone(),
            self.session_control_override_path.clone(),
        ) {
            (Some(a), Some(b), Some(c)) => (a, b, c),
            _ => return None,
        };
        let value = load_json(&path, Value::Null);
        let expected_checksum = match &self.catalog_checksum {
            Some(c) => json!(c),
            None => Value::Null,
        };
        let matches = value.get("schema").and_then(Value::as_str) == Some(SESSION_CONTROL_SCHEMA)
            && value.get("agentId").and_then(Value::as_str) == Some("omp")
            && value.get("sessionId").and_then(Value::as_str) == Some(session_id.as_str())
            && value.get("controlKey").and_then(Value::as_str) == Some(session_key.as_str())
            && value.get("releaseId").and_then(Value::as_str) == Some(self.release_id.as_str())
            && value.get("catalogChecksum").cloned().unwrap_or(Value::Null) == expected_checksum;
        if !matches {
            return None;
        }
        let disabled = Self::sanitized_disabled_ids(value.get("disabledHookIds").unwrap_or(&Value::Null));
        let enabled = self.sanitized_ids(value.get("enabledHookIds").unwrap_or(&Value::Null));
        let identity = self.capability_identity(self.current_session_key.clone());
        let capability = normalized_capability(
            value.get("capability").unwrap_or(&Value::Null),
            self.current_session_id.as_deref(),
            now_millis(),
            &identity,
        );
        Some(json!({
            "disabledHookIds": disabled,
            "enabledHookIds": enabled,
            "capability": capability.unwrap_or(Value::Null),
        }))
    }

    /// Port of `writeExternalOverride`.
    pub fn write_external_override(&mut self, identity: Option<CapabilityIdentity>) {
        let (session_id, session_key, path) = match (
            self.current_session_id.clone(),
            self.current_session_key.clone(),
            self.session_control_override_path.clone(),
        ) {
            (Some(a), Some(b), Some(c)) => (a, b, c),
            _ => return,
        };
        let identity = identity.unwrap_or_else(|| self.capability_identity(self.current_session_key.clone()));
        let overrides = self.override_state();
        let _ = atomic_write_json(
            &session_control_root(),
            &path,
            &json!({
                "schema": SESSION_CONTROL_SCHEMA,
                "agentId": "omp",
                "sessionId": session_id,
                "controlKey": session_key,
                "releaseId": identity.release_id.clone().unwrap_or_default(),
                "catalogChecksum": identity.catalog_checksum.clone(),
                "disabledHookIds": overrides.get("disabledHookIds").cloned().unwrap_or(Value::Null),
                "enabledHookIds": overrides.get("enabledHookIds").cloned().unwrap_or(Value::Null),
                "capability": overrides.get("capability").cloned().unwrap_or(Value::Null),
                "updatedAt": iso_now(),
            }),
        );
    }

    /// Port of `synchronizeExternalOverrides`.
    pub fn synchronize_external_overrides(&mut self, host: &mut dyn OmpHost) -> bool {
        let Some(external) = self.external_override_state() else { return false };
        let current = self.override_state();
        let same = serde_json::to_string(current.get("disabledHookIds").unwrap_or(&Value::Null)).unwrap_or_default()
            == serde_json::to_string(external.get("disabledHookIds").unwrap_or(&Value::Null)).unwrap_or_default()
            && serde_json::to_string(current.get("enabledHookIds").unwrap_or(&Value::Null)).unwrap_or_default()
                == serde_json::to_string(external.get("enabledHookIds").unwrap_or(&Value::Null)).unwrap_or_default()
            && serde_json::to_string(current.get("capability").unwrap_or(&Value::Null)).unwrap_or_default()
                == serde_json::to_string(external.get("capability").unwrap_or(&Value::Null)).unwrap_or_default();
        if same {
            return false;
        }
        self.disabled_hook_ids = external
            .get("disabledHookIds")
            .and_then(Value::as_array)
            .map(|a| a.iter().filter_map(|v| v.as_str().map(str::to_string)).collect())
            .unwrap_or_default();
        self.enabled_hook_ids = external
            .get("enabledHookIds")
            .and_then(Value::as_array)
            .map(|a| a.iter().filter_map(|v| v.as_str().map(str::to_string)).collect())
            .unwrap_or_default();
        self.current_capability = match external.get("capability") {
            Some(Value::Null) | None => None,
            other => other.cloned(),
        };
        self.append_override_entry(host);
        true
    }

    /// Port of `activeHookCount`.
    pub fn active_hook_count(&self) -> usize {
        if hooks_globally_disabled() {
            return self
                .known_hook_ids
                .iter()
                .filter(|id| self.enabled_hook_ids.contains(*id))
                .count();
        }
        self.known_hook_ids.len()
    }

    /// Port of `runtimeStatus`.
    pub fn runtime_status(&self) -> Value {
        let installed = installed_release_state();
        let globally_disabled = hooks_globally_disabled();
        let installed_release = installed.get("releaseId").cloned().unwrap_or(Value::Null);
        let installed_checksum = installed.get("catalogChecksum").cloned().unwrap_or(Value::Null);
        let reload_required = self.registry_load_error.is_some()
            || installed_release.is_null()
            || installed_release != json!(self.release_id)
            || (js_truthy(&installed_checksum)
                && self
                    .catalog_checksum
                    .as_ref()
                    .map(|c| installed_checksum != json!(c))
                    .unwrap_or(true));
        json!({
            "schemaVersion": 1,
            "sessionId": self.current_session_id.clone(),
            "controlKey": self.current_session_key.clone(),
            "installedReleaseId": installed_release,
            "loadedReleaseId": self.release_id,
            "installedCatalogChecksum": installed_checksum,
            "catalogChecksum": self.catalog_checksum.clone(),
            "registeredHookCount": self.known_hook_ids.len(),
            "loadedHookCount": self.active_hook_count(),
            "globallyDisabled": globally_disabled,
            "disabledHookIds": self.disabled_hook_ids.iter().cloned().collect::<Vec<_>>(),
            "enabledHookIds": self.enabled_hook_ids.iter().cloned().collect::<Vec<_>>(),
            "unknownHookIds": self.unknown_hook_ids.iter().cloned().collect::<Vec<_>>(),
            "capability": self.current_capability.clone().unwrap_or(Value::Null),
            "reloadRequired": reload_required,
            "reloadPending": self.pending_reload_command.is_some(),
            "pendingReloadCommand": self.pending_reload_command.clone(),
            "registryLoadError": self.registry_load_error.clone(),
            "runtimeStartedAt": self.runtime_started_at,
            "reloadCount": self.reload_count,
            "lastReloadAt": self.last_reload_at.clone(),
            "lastReloadError": self.last_reload_error.clone(),
            "lastDecision": self.last_decision.clone().unwrap_or(Value::Null),
            "updatedAt": iso_now(),
        })
    }

    /// Port of `publishedSessionState`.
    pub fn published_session_state(&mut self) -> Value {
        let overrides = self.override_state();
        let mut state = Map::new();
        state.insert("schema".into(), json!(SESSION_CONTROL_SCHEMA));
        state.insert("agentId".into(), json!("omp"));
        state.insert("sessionId".into(), json!(self.current_session_id));
        state.insert("controlKey".into(), json!(self.current_session_key));
        state.insert("pid".into(), json!(std::process::id()));
        state.insert(
            "cwd".into(),
            json!(self.current_session_cwd.clone().unwrap_or_else(|| {
                std::env::current_dir()
                    .map(|p| p.display().to_string())
                    .unwrap_or_default()
            })),
        );
        state.insert("livenessMode".into(), json!("process"));
        state.insert("globallyDisabled".into(), json!(hooks_globally_disabled()));
        state.insert(
            "disabledHookIds".into(),
            overrides.get("disabledHookIds").cloned().unwrap_or(Value::Null),
        );
        state.insert(
            "enabledHookIds".into(),
            overrides.get("enabledHookIds").cloned().unwrap_or(Value::Null),
        );
        state.insert(
            "capability".into(),
            overrides.get("capability").cloned().unwrap_or(Value::Null),
        );
        if let Some(resume_argv) = session_resume_argv() {
            state.insert("resumeArgv".into(), json!(resume_argv));
        }
        state.insert("runtime".into(), self.runtime_status());
        state.insert("updatedAt".into(), json!(iso_now()));
        Value::Object(state)
    }

    /// Port of `publishSessionState`.
    pub fn publish_session_state(&mut self) {
        let path = match (
            self.current_session_id.clone(),
            self.current_session_key.clone(),
            self.session_control_state_path.clone(),
        ) {
            (Some(_), Some(_), Some(p)) => p,
            _ => return,
        };
        let state = self.published_session_state();
        let _ = atomic_write_json(&session_control_root(), &path, &state);
    }

    /// Port of `persistOverrides`.
    pub fn persist_overrides(&mut self, host: &mut dyn OmpHost, identity: Option<CapabilityIdentity>) -> Value {
        let overrides = self.append_override_entry(host);
        self.write_external_override(identity);
        self.publish_session_state();
        overrides
    }

    /// Port of `applySessionHookOverride`.
    pub fn apply_session_hook_override(&mut self, host: &mut dyn OmpHost, hook_id: &str, enabled: bool) -> Value {
        if !enabled {
            let mut out = Map::new();
            out.insert("changed".into(), json!(false));
            out.insert("accepted".into(), json!(false));
            out.insert("reason".into(), json!("session-hook-disablement-prohibited"));
            out.insert("sessionId".into(), json!(self.current_session_id));
            out.insert("hookId".into(), json!(hook_id));
            out.insert("enabled".into(), json!(true));
            out.insert("globallyDisabled".into(), json!(hooks_globally_disabled()));
            for (key, value) in self.override_state().as_object().into_iter().flatten() {
                out.insert(key.clone(), value.clone());
            }
            return Value::Object(out);
        }
        let globally_disabled = hooks_globally_disabled();
        let changed = if globally_disabled {
            !self.enabled_hook_ids.contains(hook_id)
        } else {
            self.disabled_hook_ids.contains(hook_id)
        };
        if globally_disabled {
            self.enabled_hook_ids.insert(hook_id.to_string());
        } else {
            self.disabled_hook_ids.remove(hook_id);
        }
        let overrides = if changed {
            self.persist_overrides(host, None)
        } else {
            self.override_state()
        };
        let mut out = Map::new();
        out.insert("changed".into(), json!(changed));
        out.insert("accepted".into(), json!(true));
        out.insert("sessionId".into(), json!(self.current_session_id));
        out.insert("hookId".into(), json!(hook_id));
        out.insert("enabled".into(), json!(enabled));
        out.insert("globallyDisabled".into(), json!(globally_disabled));
        for (key, value) in overrides.as_object().into_iter().flatten() {
            out.insert(key.clone(), value.clone());
        }
        Value::Object(out)
    }

    /// Port of `applyEnableAllSessionHooks`.
    pub fn apply_enable_all_session_hooks(
        &mut self,
        host: &mut dyn OmpHost,
        hook_ids: Option<&BTreeSet<String>>,
    ) -> Value {
        self.disabled_hook_ids.clear();
        self.enabled_hook_ids = if hooks_globally_disabled() {
            hook_ids.cloned().unwrap_or_else(|| self.known_hook_ids.clone())
        } else {
            BTreeSet::new()
        };
        let overrides = self.persist_overrides(host, None);
        let mut out = Map::new();
        out.insert("changed".into(), json!(true));
        out.insert("sessionId".into(), json!(self.current_session_id));
        out.insert("globallyDisabled".into(), json!(hooks_globally_disabled()));
        for (key, value) in overrides.as_object().into_iter().flatten() {
            out.insert(key.clone(), value.clone());
        }
        Value::Object(out)
    }

    /// Port of `applySessionCapability`.
    pub fn apply_session_capability(
        &mut self,
        host: &mut dyn OmpHost,
        grants: Value,
        lifetime: &str,
        expires_at: Option<&str>,
    ) -> Value {
        let mut capability = Map::new();
        capability.insert("schemaVersion".into(), json!(CAPABILITY_SCHEMA_VERSION));
        capability.insert("issuedBy".into(), json!("tama:omp-interactive-approval"));
        capability.insert("nonce".into(), json!(random_uuid()));
        capability.insert("sessionId".into(), json!(self.current_session_id));
        capability.insert("controlKey".into(), json!(self.current_session_key));
        capability.insert("releaseId".into(), json!(self.release_id));
        capability.insert("catalogChecksum".into(), json!(self.catalog_checksum));
        capability.insert("lifetime".into(), json!(lifetime));
        capability.insert("grants".into(), grants);
        if lifetime == "expires-at" {
            let parsed = expires_at
                .map(crate::util::parse_iso_millis)
                .unwrap_or(f64::NAN);
            capability.insert("expiresAt".into(), json!(crate::util::iso_from_millis(parsed)));
        }
        if lifetime == "single-use" {
            capability.insert("remainingUses".into(), json!(1));
        }
        self.current_capability = Some(Value::Object(capability));
        let overrides = self.persist_overrides(host, None);
        json!({
            "changed": true,
            "sessionId": self.current_session_id,
            "capability": overrides.get("capability").cloned().unwrap_or(Value::Null),
        })
    }

    /// Port of `consumeSingleUseCapability`.
    pub fn consume_single_use_capability(&mut self, host: &mut dyn OmpHost) -> bool {
        let is_single_use = self
            .current_capability
            .as_ref()
            .and_then(|c| c.get("lifetime"))
            .and_then(Value::as_str)
            == Some("single-use");
        if !is_single_use {
            return false;
        }
        self.current_capability = None;
        self.persist_overrides(host, None);
        true
    }

    /// Port of `processSessionControlRequests`.
    pub fn process_session_control_requests(&mut self, host: &mut dyn OmpHost) {
        if self.synchronize_external_overrides(host) {
            self.publish_session_state();
        }
        let (session_id, session_key) = match (
            self.current_session_id.clone(),
            self.current_session_key.clone(),
        ) {
            (Some(a), Some(b)) => (a, b),
            _ => return,
        };
        let root = session_control_root();
        let names: Vec<String> = match std::fs::read_dir(&root) {
            Ok(entries) => entries
                .filter_map(|e| e.ok())
                .map(|e| e.file_name().to_string_lossy().into_owned())
                .collect(),
            Err(_) => return,
        };
        let prefix = format!("{}.", session_key);
        for name in names {
            if !name.starts_with(&prefix) || !name.ends_with(".request.json") {
                continue;
            }
            let request_path = root.join(&name);
            let response_path = root.join(name.replace(".request.json", ".response.json"));
            let request = load_json(&request_path, Value::Null);
            let _ = std::fs::remove_file(&request_path);
            let valid_envelope = request.get("schema").and_then(Value::as_str) == Some(SESSION_CONTROL_SCHEMA)
                && request.get("sessionId").and_then(Value::as_str) == Some(session_id.as_str())
                && request.get("controlKey").and_then(Value::as_str) == Some(session_key.as_str())
                && request.get("requestId").is_some_and(Value::is_string)
                && request.get("confirmed") == Some(&Value::Bool(true));
            let response;
            if !valid_envelope {
                response = json!({
                    "schema": SESSION_CONTROL_SCHEMA,
                    "requestId": request.get("requestId").cloned().unwrap_or(Value::Null),
                    "ok": false,
                    "error": "invalid-session-control-request",
                });
            } else {
                let operation = request.get("operation").and_then(Value::as_str);
                match operation {
                    Some("enable-all") => {
                        let details = self.schedule_native_control_reload(host, SESSION_ENABLE_ALL_TOOL);
                        let accepted = details.get("accepted") == Some(&Value::Bool(true));
                        let state = self.session_control_state_path.as_ref().map(|p| load_json(p, Value::Null)).unwrap_or(Value::Null);
                        let state = if state.is_null() { self.published_session_state() } else { state };
                        response = json!({
                            "schema": SESSION_CONTROL_SCHEMA,
                            "requestId": request.get("requestId").cloned().unwrap_or(Value::Null),
                            "ok": accepted,
                            "changed": details.get("changed").cloned().unwrap_or(Value::Bool(false)),
                            "error": if accepted {
                                Value::Null
                            } else {
                                details.get("error").cloned().unwrap_or_else(|| json!("reload-not-scheduled"))
                            },
                            "command": details.get("command").cloned().unwrap_or(Value::Null),
                            "state": state,
                        });
                    }
                    Some("set-hook") => {
                        let id = request
                            .get("hookId")
                            .and_then(Value::as_str)
                            .map(str::trim)
                            .unwrap_or("")
                            .to_string();
                        let enabled = request.get("enabled").and_then(Value::as_bool);
                        if !self.known_hook_ids.contains(&id) || enabled.is_none() {
                            let error = if self.known_hook_ids.contains(&id) {
                                "invalid-hook-state".to_string()
                            } else {
                                format!("unknown-hook:{}", id)
                            };
                            response = json!({
                                "schema": SESSION_CONTROL_SCHEMA,
                                "requestId": request.get("requestId").cloned().unwrap_or(Value::Null),
                                "ok": false,
                                "error": error,
                            });
                        } else {
                            let details = self.apply_session_hook_override(host, &id, enabled.unwrap_or(false));
                            let accepted = details.get("accepted") == Some(&Value::Bool(true));
                            response = json!({
                                "schema": SESSION_CONTROL_SCHEMA,
                                "requestId": request.get("requestId").cloned().unwrap_or(Value::Null),
                                "ok": accepted,
                                "changed": details.get("changed").cloned().unwrap_or(Value::Bool(false)),
                                "error": if accepted {
                                    Value::Null
                                } else {
                                    details.get("reason").cloned().unwrap_or_else(|| json!("hook-enable-not-applied"))
                                },
                                "state": self.published_session_state(),
                            });
                        }
                    }
                    None => {
                        response = json!({
                            "schema": SESSION_CONTROL_SCHEMA,
                            "requestId": request.get("requestId").cloned().unwrap_or(Value::Null),
                            "ok": false,
                            "error": "unsupported-operation:missing",
                        });
                    }
                    Some(other) => {
                        response = json!({
                            "schema": SESSION_CONTROL_SCHEMA,
                            "requestId": request.get("requestId").cloned().unwrap_or(Value::Null),
                            "ok": false,
                            "error": format!("unsupported-operation:{}", other),
                        });
                    }
                }
            }
            let _ = atomic_write_json(&root, &response_path, &response);
        }
    }

    /// Port of `stopSessionControl`.
    pub fn stop_session_control(&mut self) {
        if let Some(path) = self.session_control_state_path.take() {
            let _ = std::fs::remove_file(path);
        }
        self.session_control_override_path = None;
        self.current_session_key = None;
        self.current_session_cwd = None;
    }

    /// Port of `startSessionControl`. `ctx_cwd` stands in for `ctx.cwd`.
    /// The JS version also starts a 250ms polling interval; driving that loop
    /// is the host's job (call `process_session_control_requests`).
    pub fn start_session_control(
        &mut self,
        host: &mut dyn OmpHost,
        event: Option<&Value>,
        ctx_cwd: Option<&str>,
    ) {
        self.stop_session_control();
        if self.current_session_id.is_none() {
            return;
        }
        let key = session_control_key(self.current_session_id.as_deref().unwrap_or_default());
        self.current_session_key = Some(key.clone());
        self.current_session_cwd = Some(
            event
                .and_then(|e| e.get("cwd"))
                .filter(|v| js_truthy(v))
                .map(js_string)
                .or_else(|| ctx_cwd.map(str::to_string))
                .unwrap_or_else(|| {
                    std::env::current_dir()
                        .map(|p| p.display().to_string())
                        .unwrap_or_default()
                }),
        );
        let root = session_control_root();
        self.session_control_state_path = Some(root.join(format!("{}.session.json", key)));
        self.session_control_override_path = Some(root.join(format!("{}.override.json", key)));
        self.synchronize_external_overrides(host);
        self.publish_session_state();
    }

    /// Port of `activateSession`. `branch` stands in for
    /// `ctx.sessionManager.getBranch()`, `session_file` for
    /// `ctx.sessionManager.getSessionFile()`.
    pub fn activate_session(
        &mut self,
        host: &mut dyn OmpHost,
        event: Option<&Value>,
        ctx_cwd: Option<&str>,
        branch: Option<&Value>,
        session_file: Option<&str>,
    ) {
        self.current_session_id = Self::resolved_session_id(event, session_file);
        self.unknown_hook_ids = BTreeSet::new();
        let session_id = self.current_session_id.clone();
        let (disabled, enabled, capability) =
            self.restored_hook_overrides(branch, session_id.as_deref());
        self.disabled_hook_ids = disabled.into_iter().collect();
        self.enabled_hook_ids = enabled.into_iter().collect();
        self.current_capability = capability;
        self.start_session_control(host, event, ctx_cwd);
    }

    /// Port of `sessionId(event)`.
    pub fn session_id(&self, event: &Value) -> Value {
        let explicit = event
            .get("sessionId")
            .or_else(|| event.get("session_id"))
            .or_else(|| event.get("session").and_then(|s| s.get("id")))
            .filter(|v| js_truthy(v));
        if let Some(value) = explicit {
            return value.clone();
        }
        match &self.current_session_id {
            Some(id) => json!(id),
            None => Value::Null,
        }
    }

    /// Port of `hookPayload`.
    pub fn hook_payload(&self, event: &Value) -> Value {
        let name = tool_name(event);
        let input = tool_input(event);
        json!({
            "agent_hook_event": "tool_call",
            "runtime": "omp",
            "session_id": self.session_id(event),
            "project_dir": event.get("cwd").filter(|v| js_truthy(v)).cloned().unwrap_or_else(|| {
                json!(std::env::current_dir().map(|p| p.display().to_string()).unwrap_or_default())
            }),
            "control_key": self.current_session_key.clone(),
            "release_id": self.release_id,
            "catalog_checksum": self.catalog_checksum.clone(),
            "tool_name": name,
            "tool_input": input,
            "tool": { "name": name, "input": input },
        })
    }

    /// Port of `lifecyclePayload`.
    pub fn lifecycle_payload(&self, event_name: &str, event: &Value, extra: Map<String, Value>) -> Value {
        let mut out = Map::new();
        out.insert("agent_hook_event".into(), json!(event_name));
        out.insert("runtime".into(), json!("omp"));
        out.insert("session_id".into(), self.session_id(event));
        out.insert(
            "project_dir".into(),
            event.get("cwd").filter(|v| js_truthy(v)).cloned().unwrap_or_else(|| {
                json!(std::env::current_dir().map(|p| p.display().to_string()).unwrap_or_default())
            }),
        );
        out.insert("raw_event".into(), event.clone());
        for (key, value) in extra {
            out.insert(key, value);
        }
        Value::Object(out)
    }

    fn is_hook_active(&self, hook_id: &str) -> bool {
        if hooks_globally_disabled() {
            return self.enabled_hook_ids.contains(hook_id);
        }
        true
    }

    fn record_decision(&mut self, event_name: &str, result: &Value) {
        let mut decision = Map::new();
        decision.insert("event".into(), json!(event_name));
        if let Some(obj) = result.as_object() {
            for (key, value) in obj {
                decision.insert(key.clone(), value.clone());
            }
        }
        decision.insert("at".into(), json!(iso_now()));
        self.last_decision = Some(Value::Object(decision));
    }

    /// Port of `runRegistryEvent`.
    pub fn run_registry_event(&mut self, event_name: &str, payload: &Value) -> Value {
        let _ = self.override_state();
        if let Some(error) = self.registry_load_error.clone() {
            let result = json!({
                "decision": "block",
                "reason": error,
                "id": "tama-registry-integrity",
                "results": [],
            });
            self.record_decision(event_name, &result);
            return result;
        }
        let entry = self
            .registry
            .get("events")
            .and_then(|e| e.get(event_name))
            .cloned();
        let Some(entry) = entry else {
            let result = json!({
                "decision": "pass",
                "reason": format!("no hooks for {}", event_name),
                "results": [],
            });
            self.record_decision(event_name, &result);
            return result;
        };
        let raw_event = payload.get("raw_event").filter(|v| v.is_object()).cloned().unwrap_or_else(|| json!({}));
        let mut normalized = payload.as_object().cloned().unwrap_or_default();
        normalized.remove("raw_event");
        let cwd = ["cwd"]
            .iter()
            .filter_map(|k| payload.get(*k))
            .find(|v| js_truthy(v))
            .or_else(|| raw_event.get("cwd").filter(|v| js_truthy(v)))
            .or_else(|| payload.get("project_dir").filter(|v| js_truthy(v)))
            .cloned();
        if let Some(cwd) = cwd {
            normalized.insert("cwd".into(), cwd);
        }
        let transcript = payload
            .get("transcript_path")
            .filter(|v| js_truthy(v))
            .or_else(|| raw_event.get("transcript_path").filter(|v| js_truthy(v)))
            .or_else(|| raw_event.get("transcriptPath").filter(|v| js_truthy(v)))
            .cloned()
            .unwrap_or(Value::Null);
        normalized.insert("transcript_path".into(), transcript);
        normalized.insert("agent_hook_event".into(), json!(event_name));
        let normalized = Value::Object(normalized);

        let blocking = entry.get("blocking").and_then(Value::as_bool) != Some(false);
        let mut results: Vec<Value> = Vec::new();
        let hooks = entry.get("hooks").and_then(Value::as_array).cloned().unwrap_or_default();
        for hook in hooks {
            let id = js_string_or_empty(hook.get("id"));
            if id.is_empty() || !self.is_hook_active(&id) {
                results.push(json!({ "id": id, "skipped": true }));
                continue;
            }
            let command = match hook.get("command") {
                None => "undefined".to_string(),
                Some(v) => js_string(v),
            };
            let timeout_s = match hook.get("timeout") {
                Some(v) if js_truthy(v) => v.as_f64().unwrap_or(10.0),
                _ => 10.0,
            };
            let timeout_ms = (timeout_s.max(1.0) * 1000.0) as u64;
            let (env_set, env_remove) = capability_environment(
                self.current_capability.as_ref(),
                &[("TAMA_PROVIDER".to_string(), "omp".to_string())],
            );
            let execution = run_hook_command(
                &expand_home(&command),
                &normalized,
                timeout_ms,
                &env_set,
                &env_remove,
            );
            let mut record = json!({
                "id": id,
                "code": execution.code,
                "timedOut": execution.timed_out,
            });
            results.push(record.clone());
            let mut reason: Option<String> = if execution.timed_out {
                Some(format!(
                    "{} timed out after {}s",
                    id,
                    crate::util::js_number_to_string(&json!(timeout_s))
                ))
            } else {
                decision_from_output(&execution.stdout)
                    .or_else(|| decision_from_output(&execution.stderr))
            };
            let code_nonzero = execution.code.map(|c| c != 0).unwrap_or(false);
            if reason.is_none() && (execution.spawn_error || (code_nonzero && looks_like_malfunction(&execution))) {
                // A crashing hook is not a policy decision; denying on it makes
                // a broken policy engine indistinguishable from a deliberate block.
                let detail = if !execution.stderr.is_empty() {
                    execution.stderr.trim().to_string()
                } else {
                    execution.stdout.trim().to_string()
                };
                eprintln!("hook {} malfunctioned: {}", id, detail);
                record.as_object_mut().expect("record is an object").insert("failed".into(), json!(true));
                if let Some(last) = results.last_mut() {
                    *last = record.clone();
                }
            } else if reason.is_none() && code_nonzero && blocking {
                let detail = if !execution.stderr.is_empty() {
                    execution.stderr.trim().to_string()
                } else if !execution.stdout.is_empty() {
                    execution.stdout.trim().to_string()
                } else {
                    format!("exit {}", execution.code.unwrap_or(0))
                };
                reason = Some(detail);
            }
            if let Some(reason) = reason {
                if blocking {
                    let result = json!({
                        "decision": "block",
                        "reason": format!("{}: {}", id, reason),
                        "id": id,
                        "results": results,
                    });
                    self.record_decision(event_name, &result);
                    return result;
                }
            }
        }
        let result = json!({ "decision": "pass", "results": results });
        self.record_decision(event_name, &result);
        result
    }

    /// Port of `sessionOverrideHint`.
    pub fn session_override_hint(result: &Value) -> Value {
        let is_block = result.get("decision").and_then(Value::as_str) == Some("block");
        let id = result.get("id").and_then(Value::as_str);
        if !is_block || id.is_none() {
            return result.clone();
        }
        let guidance = match id {
            Some("block-unauthorized-cua") => "Record a verbatim, direct current-session user grant for CUA and the named app in ~/.shared-hooks/cua_justifications.json. This hook cannot be disabled within the session.".to_string(),
            Some("block-unauthorized-ssh") => "Record a verbatim, explicit current-session SSH grant and its exact target, operation, path, or command in ~/.shared-hooks/ssh_justification.json. This hook cannot be disabled within the session.".to_string(),
            _ => "This hook cannot be disabled within an agent session. Satisfy the blocking policy; policy changes must be performed by the operator outside the agent session.".to_string(),
        };
        let mut out = result.clone();
        let reason = result.get("reason").and_then(Value::as_str).unwrap_or_default();
        out.as_object_mut()
            .expect("result is an object")
            .insert("reason".into(), json!(format!("{}\n{}", reason, guidance)));
        out
    }

    /// Port of `checkToolCall`.
    pub fn check_tool_call(&mut self, host: &mut dyn OmpHost, event: &Value) -> Value {
        if control_plane_tools().contains(&tool_name(event).as_str()) {
            return json!({ "decision": "pass", "code": 0, "results": [] });
        }
        let payload = self.hook_payload(event);
        let event_name = registry_event(&tool_name(event));
        let result = self.run_registry_event(&event_name, &payload);
        if result.get("decision").and_then(Value::as_str) == Some("pass") {
            self.consume_single_use_capability(host);
        }
        if result.get("decision").and_then(Value::as_str) == Some("block") {
            Self::session_override_hint(&result)
        } else {
            result
        }
    }

    /// Port of `writeEvidence`.
    pub fn write_evidence(&self, payload: &Value, result: &Value) {
        let Some(path) = std::env::var_os("OMP_TAMA_EVIDENCE_LOG") else { return };
        let tool = payload.get("tool_name").and_then(Value::as_str).unwrap_or_default();
        let line = json!({
            "event": registry_event(tool),
            "input": payload,
            "decision": result.get("decision").cloned().unwrap_or(Value::Null),
            "blockedHookId": result.get("id").cloned().unwrap_or(Value::Null),
            "reason": result.get("reason").cloned().unwrap_or(Value::Null),
            "results": result.get("results").cloned().unwrap_or_else(|| json!([])),
            "loadedReleaseId": self.release_id,
            "catalogChecksum": self.catalog_checksum.clone(),
        });
        if let Ok(mut file) = std::fs::OpenOptions::new().append(true).create(true).open(path) {
            use std::io::Write;
            let _ = writeln!(file, "{}", serde_json::to_string(&line).unwrap_or_default());
        }
    }

    /// Port of the `pi.on('input', ...)` handler. Returns
    /// `Some({action: 'handled'})` when the prompt was blocked.
    pub fn handle_input(&mut self, host: &mut dyn OmpHost, event: &Value) -> Option<Value> {
        self.process_session_control_requests(host);
        self.publish_session_state();
        let prompt = event
            .get("text")
            .or_else(|| event.get("prompt"))
            .filter(|v| js_truthy(v))
            .cloned()
            .unwrap_or_else(|| json!(""));
        let mut extra = Map::new();
        extra.insert("prompt".into(), prompt);
        let payload = self.lifecycle_payload("user_prompt_submit", event, extra);
        let result = self.run_registry_event("user_prompt_submit", &payload);
        if result.get("decision").and_then(Value::as_str) == Some("block") {
            let reason = result
                .get("reason")
                .and_then(Value::as_str)
                .unwrap_or("Tama blocked this prompt.")
                .to_string();
            host.notify(&reason, "error");
            host.abort();
            return Some(json!({ "action": "handled" }));
        }
        None
    }

    /// Port of the `pi.on('tool_result', ...)` handler.
    pub fn handle_tool_result(&mut self, event: &Value) -> Option<Value> {
        let mut payload = self.hook_payload(event);
        {
            let obj = payload.as_object_mut().expect("payload is an object");
            obj.insert("agent_hook_event".into(), json!("tool_result"));
            obj.insert(
                "tool_result".into(),
                json!({
                    "content": event.get("content").cloned().unwrap_or(Value::Null),
                    "details": event.get("details").cloned().unwrap_or(Value::Null),
                    "is_error": event.get("isError").and_then(Value::as_bool) == Some(true),
                }),
            );
        }
        let name = payload.get("tool_name").and_then(Value::as_str).unwrap_or_default().to_string();
        let event_name = registry_post_event(&name);
        let result = self.run_registry_event(&event_name, &payload);
        if result.get("decision").and_then(Value::as_str) == Some("block") {
            let reason = result
                .get("reason")
                .and_then(Value::as_str)
                .unwrap_or("Tama rejected the tool result.")
                .to_string();
            return Some(json!({
                "content": [{ "type": "text", "text": reason }],
                "isError": true,
            }));
        }
        None
    }

    /// Port of the `pi.on('session_stop', ...)` handler.
    pub fn handle_session_stop(&mut self, event: &Value) -> Option<Value> {
        let payload = self.lifecycle_payload("stop", event, Map::new());
        let result = self.run_registry_event("stop", &payload);
        if result.get("decision").and_then(Value::as_str) == Some("block") {
            let reason = result
                .get("reason")
                .and_then(Value::as_str)
                .unwrap_or("Tama blocked session completion.")
                .to_string();
            return Some(json!({ "decision": "block", "reason": reason }));
        }
        None
    }

    /// Port of the `pi.on('session_compact', ...)` handler.
    pub fn handle_session_compact(&mut self, event: &Value) {
        let payload = self.lifecycle_payload("session_start:compact", event, Map::new());
        let _ = self.run_registry_event("session_start:compact", &payload);
    }

    /// Port of the `pi.on('session_shutdown', ...)` handler.
    pub fn handle_session_shutdown(&mut self) {
        self.stop_session_control();
        self.current_session_id = None;
        self.disabled_hook_ids = BTreeSet::new();
        self.enabled_hook_ids = BTreeSet::new();
        self.unknown_hook_ids = BTreeSet::new();
        self.current_capability = None;
    }

    /// Port of the `pi.on('tool_call', ...)` handler.
    pub fn handle_tool_call(&mut self, host: &mut dyn OmpHost, event: &Value) -> Option<Value> {
        self.process_session_control_requests(host);
        self.publish_session_state();
        let result = self.check_tool_call(host, event);
        self.write_evidence(&self.hook_payload(event), &result);
        self.publish_session_state();
        if result.get("decision").and_then(Value::as_str) == Some("block") {
            return Some(json!({
                "block": true,
                "reason": result.get("reason").cloned().unwrap_or(Value::Null),
            }));
        }
        None
    }

    /// Port of `scheduleNativeControlReload`.
    pub fn schedule_native_control_reload(&mut self, host: &mut dyn OmpHost, command: &str) -> Value {
        if let Some(pending_command) = self.pending_reload_command.clone() {
            if command == SESSION_ENABLE_ALL_TOOL && pending_command != SESSION_ENABLE_ALL_TOOL {
                let upgrade = (|| -> Result<Value, String> {
                    let candidate = registry_snapshot()?;
                    let installed = installed_release_state();
                    if let Some(release) = installed.get("releaseId").and_then(Value::as_str) {
                        if release != candidate.release_id {
                            return Err(format!(
                                "Installed release {} does not match registry release {}",
                                release, candidate.release_id
                            ));
                        }
                    }
                    if let Some(checksum) = installed.get("catalogChecksum").and_then(Value::as_str) {
                        if checksum != candidate.catalog_checksum {
                            return Err(format!(
                                "Installed catalog {} does not match registry catalog {}",
                                checksum, candidate.catalog_checksum
                            ));
                        }
                    }
                    self.disabled_hook_ids.clear();
                    self.enabled_hook_ids = if hooks_globally_disabled() {
                        candidate.hook_ids
                    } else {
                        BTreeSet::new()
                    };
                    let overrides = self.persist_overrides(
                        host,
                        Some(CapabilityIdentity {
                            control_key: self.current_session_key.clone(),
                            release_id: Some(candidate.release_id),
                            catalog_checksum: Some(candidate.catalog_checksum),
                        }),
                    );
                    self.pending_reload_command = Some(SESSION_ENABLE_ALL_TOOL.to_string());
                    self.last_reload_error = None;
                    self.publish_session_state();
                    Ok(json!({
                        "changed": true,
                        "accepted": true,
                        "reloadRequested": true,
                        "command": SESSION_ENABLE_ALL_TOOL,
                        "reason": "pending-reload-upgraded",
                        "enabled": {
                            "changed": true,
                            "sessionId": self.current_session_id,
                            "globallyDisabled": hooks_globally_disabled(),
                            "disabledHookIds": overrides.get("disabledHookIds").cloned().unwrap_or(Value::Null),
                            "enabledHookIds": overrides.get("enabledHookIds").cloned().unwrap_or(Value::Null),
                            "capability": overrides.get("capability").cloned().unwrap_or(Value::Null),
                        },
                        "status": self.runtime_status(),
                    }))
                })();
                return upgrade.unwrap_or_else(|error| {
                    self.last_reload_error = Some(error.clone());
                    self.publish_session_state();
                    json!({
                        "changed": false,
                        "accepted": false,
                        "reloadRequested": true,
                        "command": pending_command,
                        "error": error,
                        "reason": "pending-reload-upgrade-failed",
                        "status": self.runtime_status(),
                    })
                });
            }
            return json!({
                "changed": false,
                "accepted": true,
                "reloadRequested": true,
                "command": pending_command,
                "reason": "reload-already-pending",
                "status": self.runtime_status(),
            });
        }
        let result = (|| -> Result<Value, String> {
            let candidate = registry_snapshot()?;
            let installed = installed_release_state();
            if let Some(release) = installed.get("releaseId").and_then(Value::as_str) {
                if release != candidate.release_id {
                    return Err(format!(
                        "Installed release {} does not match registry release {}",
                        release, candidate.release_id
                    ));
                }
            }
            if let Some(checksum) = installed.get("catalogChecksum").and_then(Value::as_str) {
                if checksum != candidate.catalog_checksum {
                    return Err(format!(
                        "Installed catalog {} does not match registry catalog {}",
                        checksum, candidate.catalog_checksum
                    ));
                }
            }
            let previous_registry = self.registry.clone();
            let previous_hook_ids = self.known_hook_ids.clone();
            let previous_release_id = self.release_id.clone();
            let previous_catalog_checksum = self.catalog_checksum.clone();
            let previous_load_error = self.registry_load_error.clone();
            let previous_disabled = self.disabled_hook_ids.clone();
            let previous_enabled = self.enabled_hook_ids.clone();
            let previous_capability = self.current_capability.clone();
            let enable_all = command == SESSION_ENABLE_ALL_TOOL;
            let expected_release_id = candidate.release_id.clone();
            let expected_catalog_checksum = candidate.catalog_checksum.clone();

            self.last_reload_error = None;
            self.pending_reload_command = Some(command.to_string());
            self.disabled_hook_ids.clear();
            self.enabled_hook_ids = if enable_all {
                if hooks_globally_disabled() {
                    candidate.hook_ids.clone()
                } else {
                    BTreeSet::new()
                }
            } else {
                self.enabled_hook_ids
                    .iter()
                    .filter(|id| candidate.hook_ids.contains(*id))
                    .cloned()
                    .collect()
            };
            let overrides = self.persist_overrides(
                host,
                Some(CapabilityIdentity {
                    control_key: self.current_session_key.clone(),
                    release_id: Some(expected_release_id.clone()),
                    catalog_checksum: Some(expected_catalog_checksum.clone()),
                }),
            );
            if let Err(error) = host.request_reload() {
                self.registry = previous_registry;
                self.known_hook_ids = previous_hook_ids;
                self.release_id = previous_release_id;
                self.catalog_checksum = previous_catalog_checksum;
                self.registry_load_error = previous_load_error;
                self.pending_reload_command = None;
                self.disabled_hook_ids = previous_disabled;
                self.enabled_hook_ids = previous_enabled;
                self.current_capability = previous_capability;
                self.persist_overrides(host, None);
                return Err(error);
            }

            let mut response = json!({
                "changed": true,
                "accepted": true,
                "reloadRequested": true,
                "command": command,
                "expectedReleaseId": expected_release_id,
                "expectedCatalogChecksum": expected_catalog_checksum,
                "status": self.runtime_status(),
            });
            if enable_all {
                response["enabled"] = json!({
                    "changed": true,
                    "sessionId": self.current_session_id,
                    "globallyDisabled": hooks_globally_disabled(),
                    "disabledHookIds": overrides.get("disabledHookIds").cloned().unwrap_or(Value::Null),
                    "enabledHookIds": overrides.get("enabledHookIds").cloned().unwrap_or(Value::Null),
                    "capability": overrides.get("capability").cloned().unwrap_or(Value::Null),
                });
            }
            Ok(response)
        })();
        result.unwrap_or_else(|error| {
            self.last_reload_error = Some(error.clone());
            self.publish_session_state();
            json!({
                "changed": false,
                "accepted": false,
                "reloadRequested": false,
                "command": command,
                "error": error,
                "status": self.runtime_status(),
            })
        })
    }

    /// Port of `reloadRuntime`. The caller must supply the candidate snapshot
    /// (in JS `registrySnapshot()` is the default parameter, evaluated before
    /// the function body — its throw is NOT caught by the inner try/catch).
    pub fn reload_runtime(&mut self, host: &mut dyn OmpHost, candidate: RegistrySnapshot) -> Value {
        if !host.has_reload() {
            let error = "OMP exposes reload only to slash-command handlers".to_string();
            self.last_reload_error = Some(error.clone());
            self.publish_session_state();
            return json!({
                "changed": false,
                "reloadRequested": false,
                "error": error,
                "status": self.runtime_status(),
            });
        }
        let installed = installed_release_state();
        if let Some(release) = installed.get("releaseId").and_then(Value::as_str) {
            if release != candidate.release_id {
                let error = format!(
                    "Installed release {} does not match registry release {}",
                    release, candidate.release_id
                );
                self.last_reload_error = Some(error.clone());
                self.publish_session_state();
                return json!({
                    "changed": false,
                    "reloadRequested": false,
                    "error": error,
                    "status": self.runtime_status(),
                });
            }
        }
        if let Some(checksum) = installed.get("catalogChecksum").and_then(Value::as_str) {
            if checksum != candidate.catalog_checksum {
                let error = format!(
                    "Installed catalog {} does not match registry catalog {}",
                    checksum, candidate.catalog_checksum
                );
                self.last_reload_error = Some(error.clone());
                self.publish_session_state();
                return json!({
                    "changed": false,
                    "reloadRequested": false,
                    "error": error,
                    "status": self.runtime_status(),
                });
            }
        }

        let previous_registry = self.registry.clone();
        let previous_hook_ids = self.known_hook_ids.clone();
        let previous_release_id = self.release_id.clone();
        let previous_catalog_checksum = self.catalog_checksum.clone();
        let previous_load_error = self.registry_load_error.clone();
        let previous_disabled = self.disabled_hook_ids.clone();
        let previous_enabled = self.enabled_hook_ids.clone();
        let previous_capability = self.current_capability.clone();
        let expected_release_id = candidate.release_id.clone();
        let expected_catalog_checksum = candidate.catalog_checksum.clone();

        self.disabled_hook_ids.clear();
        self.enabled_hook_ids = self
            .enabled_hook_ids
            .iter()
            .filter(|id| candidate.hook_ids.contains(*id))
            .cloned()
            .collect();
        self.install_registry_snapshot(candidate);
        self.persist_overrides(host, None);

        if let Err(error) = host.reload() {
            self.registry = previous_registry;
            self.known_hook_ids = previous_hook_ids;
            self.release_id = previous_release_id;
            self.catalog_checksum = previous_catalog_checksum;
            self.registry_load_error = previous_load_error;
            self.disabled_hook_ids = previous_disabled;
            self.enabled_hook_ids = previous_enabled;
            self.current_capability = previous_capability;
            self.last_reload_error = Some(error.clone());
            self.persist_overrides(host, None);
            self.publish_session_state();
            return json!({
                "changed": false,
                "reloadRequested": false,
                "error": error,
                "status": self.runtime_status(),
            });
        }

        self.reload_count += u64::from(true);
        self.last_reload_at = Some(iso_now());
        self.last_reload_error = None;
        self.publish_session_state();
        json!({
            "changed": true,
            "reloadRequested": true,
            "expectedReleaseId": expected_release_id,
            "expectedCatalogChecksum": expected_catalog_checksum,
            "status": self.runtime_status(),
        })
    }

    /// Port of `enableAllAndReload`.
    pub fn enable_all_and_reload(&mut self, host: &mut dyn OmpHost) -> Value {
        if !host.has_reload() {
            return json!({
                "enabled": Value::Null,
                "reload": {
                    "changed": false,
                    "reloadRequested": false,
                    "error": format!("OMP exposes reload only to /{}", SESSION_ENABLE_ALL_TOOL),
                    "status": self.runtime_status(),
                },
            });
        }
        let candidate = match registry_snapshot() {
            Ok(c) => c,
            Err(error) => {
                // In JS the throw escapes enableAllAndReload; mirror that by
                // returning a failed reload object carrying the message.
                return json!({
                    "enabled": Value::Null,
                    "reload": {
                        "changed": false,
                        "reloadRequested": false,
                        "error": error,
                        "status": self.runtime_status(),
                    },
                });
            }
        };
        let previous_disabled = self.disabled_hook_ids.clone();
        let previous_enabled = self.enabled_hook_ids.clone();
        let enabled = self.apply_enable_all_session_hooks(host, Some(&candidate.hook_ids));
        let reload = self.reload_runtime(host, candidate);
        if reload.get("changed") != Some(&Value::Bool(true)) {
            self.disabled_hook_ids = previous_disabled;
            self.enabled_hook_ids = previous_enabled;
            self.persist_overrides(host, None);
        }
        json!({ "enabled": enabled, "reload": reload })
    }

    /// Port of `ensureSession`.
    pub fn ensure_session(&mut self, host: &mut dyn OmpHost, ctx_cwd: Option<&str>) -> bool {
        if self.current_session_id.is_none() {
            self.activate_session(host, None, ctx_cwd, None, None);
        }
        self.current_session_id.is_some()
    }

    /// Port of `missingSessionResult`.
    pub fn missing_session_result(noun: &str) -> Value {
        json!({
            "content": [{
                "type": "text",
                "text": format!("OMP has not provided a session id; Tama refused to create an unscoped {}.", noun),
            }],
            "details": { "changed": false, "reason": "missing-session-id" },
            "isError": true,
        })
    }

    /// Port of the `tama_hook_runtime_status` tool body.
    pub fn tool_runtime_status(&mut self, host: &mut dyn OmpHost, ctx_cwd: Option<&str>) -> Value {
        self.ensure_session(host, ctx_cwd);
        let status = self.runtime_status();
        self.publish_session_state();
        json!({
            "content": [{
                "type": "text",
                "text": serde_json::to_string_pretty(&status).unwrap_or_default(),
            }],
            "details": status,
        })
    }

    /// Port of the `tama_set_session_hook` tool body.
    pub fn tool_session_override(
        &mut self,
        host: &mut dyn OmpHost,
        hook_id: &str,
        enabled: bool,
        ctx_cwd: Option<&str>,
    ) -> Value {
        if !self.ensure_session(host, ctx_cwd) {
            return Self::missing_session_result("hook override");
        }
        let id = hook_id.trim();
        if !self.known_hook_ids.contains(id) {
            return json!({
                "content": [{ "type": "text", "text": format!("Unknown Tama hook id: {}", id) }],
                "details": { "changed": false, "reason": "unknown-hook" },
                "isError": true,
            });
        }
        let details = self.apply_session_hook_override(host, id, enabled);
        let changed = details.get("changed") == Some(&Value::Bool(true));
        let accepted = details.get("accepted") == Some(&Value::Bool(true));
        let text = if changed {
            format!("Enabled {} only for this OMP session.", id)
        } else if accepted {
            format!("{} is already enabled in this OMP session.", id)
        } else {
            format!("{} cannot be disabled within an agent session. Satisfy the blocking policy; policy changes must be performed by the operator outside the agent session.", id)
        };
        json!({
            "content": [{ "type": "text", "text": text }],
            "details": details,
            "isError": !accepted,
        })
    }

    /// Port of the `tama_enable_all_session_hooks` tool body.
    pub fn tool_enable_all(&mut self, host: &mut dyn OmpHost, ctx_cwd: Option<&str>) -> Value {
        if !self.ensure_session(host, ctx_cwd) {
            return Self::missing_session_result("enable-all override");
        }
        let details = self.schedule_native_control_reload(host, SESSION_ENABLE_ALL_TOOL);
        let changed = details.get("changed") == Some(&Value::Bool(true));
        let accepted = details.get("accepted") == Some(&Value::Bool(true));
        let text = if changed {
            "Scheduled native enable-all after the active turn settles and reloads the runtime.".to_string()
        } else if accepted {
            "Native enable-all is already scheduled for this session.".to_string()
        } else {
            format!(
                "Tama could not schedule native enable-all: {}",
                details.get("error").and_then(Value::as_str).unwrap_or_default()
            )
        };
        json!({
            "content": [{ "type": "text", "text": text }],
            "details": details,
            "isError": !accepted,
        })
    }

    /// Port of the `tama_request_session_capability` tool body.
    pub fn tool_request_capability(
        &mut self,
        host: &mut dyn OmpHost,
        grants: &Value,
        lifetime: &str,
        expires_at: Option<&str>,
        ctx_cwd: Option<&str>,
    ) -> Value {
        if !self.ensure_session(host, ctx_cwd) {
            return Self::missing_session_result("capability");
        }
        let normalized_grants = normalize_capability_grants(grants);
        let valid_expiration = lifetime != "expires-at"
            || expires_at
                .map(crate::util::parse_iso_millis)
                .map(|ms| ms.is_finite() && ms > now_millis())
                .unwrap_or(false);
        if normalized_grants.is_none() || !valid_expiration {
            return json!({
                "content": [{ "type": "text", "text": "Tama rejected invalid capability grants, lifetime, or expiration." }],
                "details": { "changed": false, "reason": "invalid-capability-request" },
                "isError": true,
            });
        }
        let details = self.apply_session_capability(
            host,
            Value::Array(normalized_grants.unwrap_or_default()),
            lifetime,
            expires_at,
        );
        json!({
            "content": [{
                "type": "text",
                "text": format!(
                    "Authorized the displayed grants. {}",
                    lifetime_summary(lifetime, details.get("capability").and_then(|c| c.get("expiresAt")).and_then(Value::as_str))
                ),
            }],
            "details": details,
        })
    }

    /// Port of the `tama_reload_hook_runtime` tool body.
    pub fn tool_runtime_reload(&mut self, host: &mut dyn OmpHost, ctx_cwd: Option<&str>) -> Value {
        if !self.ensure_session(host, ctx_cwd) {
            return Self::missing_session_result("runtime reload");
        }
        let details = self.schedule_native_control_reload(host, RUNTIME_RELOAD_TOOL);
        let changed = details.get("changed") == Some(&Value::Bool(true));
        let accepted = details.get("accepted") == Some(&Value::Bool(true));
        let text = if changed {
            "Scheduled the native Tama runtime reload after the active turn settles.".to_string()
        } else if accepted {
            "A native Tama runtime reload is already scheduled for this session.".to_string()
        } else {
            format!(
                "Tama could not schedule the native runtime reload: {}",
                details.get("error").and_then(Value::as_str).unwrap_or_default()
            )
        };
        json!({
            "content": [{ "type": "text", "text": text }],
            "details": details,
            "isError": !accepted,
        })
    }

    /// Port of the `/tama_reload_hook_runtime` slash-command handler.
    pub fn command_runtime_reload(&mut self, host: &mut dyn OmpHost, ctx_cwd: Option<&str>) {
        if !self.ensure_session(host, ctx_cwd) {
            host.notify("Tama cannot reload without an active OMP session id.", "error");
            return;
        }
        match registry_snapshot() {
            Ok(candidate) => {
                let details = self.reload_runtime(host, candidate);
                if details.get("changed") != Some(&Value::Bool(true)) {
                    host.notify(
                        &format!(
                            "Tama runtime reload failed: {}",
                            details.get("error").and_then(Value::as_str).unwrap_or_default()
                        ),
                        "error",
                    );
                }
            }
            Err(error) => {
                host.notify(&format!("Tama runtime reload failed: {}", error), "error");
            }
        }
    }

    /// Port of the `/tama_enable_all_session_hooks` slash-command handler.
    pub fn command_enable_all(&mut self, host: &mut dyn OmpHost, ctx_cwd: Option<&str>) {
        if !self.ensure_session(host, ctx_cwd) {
            host.notify("Tama cannot enable hooks without an active OMP session id.", "error");
            return;
        }
        let details = self.enable_all_and_reload(host);
        let reload = details.get("reload").cloned().unwrap_or(Value::Null);
        if reload.get("changed") != Some(&Value::Bool(true)) {
            host.notify(
                &format!(
                    "Tama enable-all failed and was rolled back: {}",
                    reload.get("error").and_then(Value::as_str).unwrap_or_default()
                ),
                "error",
            );
        }
    }
}

/// Port of `capabilitySummary`.
pub fn capability_summary(grants: &[Value]) -> String {
    grants
        .iter()
        .map(|grant| {
            let tool = grant.get("tool").and_then(Value::as_str).unwrap_or_default();
            match grant.get("actions").and_then(Value::as_array) {
                Some(actions) => format!(
                    "{}:{}",
                    tool,
                    actions.iter().map(|a| a.as_str().unwrap_or_default()).collect::<Vec<_>>().join(",")
                ),
                None => tool.to_string(),
            }
        })
        .collect::<Vec<_>>()
        .join("\n")
}

/// Port of `lifetimeSummary`.
pub fn lifetime_summary(lifetime: &str, expires_at: Option<&str>) -> String {
    match lifetime {
        "single-use" => "Lifetime: one tool invocation".to_string(),
        "current-session" => "Lifetime: until this OMP session ends".to_string(),
        _ => format!("Expires: {}", expires_at.unwrap_or("undefined")),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    fn sealed_registry(events: Value) -> Value {
        let mut registry = json!({ "releaseId": "test-release", "events": events });
        let checksum = registry_checksum(&registry);
        registry
            .as_object_mut()
            .expect("registry is an object")
            .insert("catalogChecksum".into(), json!(checksum));
        registry
    }

    /// End-to-end check of `run_registry_event` against a sealed registry:
    /// pass, block-by-JSON-decision, block-by-exit-code, timeout, and the
    /// malfunction-is-not-a-policy-decision rule.
    #[test]
    fn registry_event_decisions() {
        let dir = std::env::temp_dir().join(format!("tama-omp-test-{}", std::process::id()));
        std::fs::create_dir_all(&dir).expect("create temp dir");
        let registry = sealed_registry(json!({
            "pre_tool_use:bash": {
                "blocking": true,
                "hooks": [
                    { "id": "passer", "command": "/bin/cat", "timeout": 5 },
                    { "id": "crasher", "command": "python3 -c 'import definitely_missing_module_xyz'", "timeout": 5 }
                ]
            },
            "pre_tool_use:read": {
                "blocking": true,
                "hooks": [
                    { "id": "blocker", "command": "printf '{\"decision\":\"block\",\"reason\":\"nope\"}'", "timeout": 5 }
                ]
            },
            "pre_tool_use:edit": {
                "blocking": true,
                "hooks": [ { "id": "failing", "command": "/usr/bin/false", "timeout": 5 } ]
            },
            "pre_tool_use:write": {
                "blocking": true,
                "hooks": [ { "id": "sleeper", "command": "sleep 2", "timeout": 0.05 } ]
            }
        }));
        let registry_path = dir.join("registry.json");
        std::fs::write(&registry_path, serde_json::to_string(&registry).unwrap()).expect("write registry");
        std::env::set_var("AGENT_HOOK_REGISTRY", &registry_path);
        std::env::set_var("TAMA_SESSION_CONTROL_ROOT", dir.join("sc"));
        std::env::set_var("TAMA_EMERGENCY_STATE", dir.join("emergency.json"));
        std::env::set_var("TAMA_INSTALLED_HOOK_RELEASE", dir.join("installed.json"));

        let mut runtime = OmpRuntime::new();
        assert_eq!(runtime.registry_load_error, None);
        assert_eq!(runtime.release_id, "test-release");
        assert!(runtime.known_hook_ids.contains("passer"));

        let payload = json!({ "tool_name": "Bash", "project_dir": "/tmp" });
        // pass: /bin/cat echoes, python traceback is a malfunction, not a block.
        let result = runtime.run_registry_event("pre_tool_use:bash", &payload);
        assert_eq!(result.get("decision").and_then(Value::as_str), Some("pass"));
        let results = result.get("results").and_then(Value::as_array).expect("results array");
        assert_eq!(results.len(), 2);
        assert_eq!(results[1].get("failed"), Some(&Value::Bool(true)));

        // block via JSON decision on stdout.
        let result = runtime.run_registry_event("pre_tool_use:read", &payload);
        assert_eq!(result.get("decision").and_then(Value::as_str), Some("block"));
        assert_eq!(result.get("reason").and_then(Value::as_str), Some("blocker: nope"));

        // block via non-zero exit without output.
        let result = runtime.run_registry_event("pre_tool_use:edit", &payload);
        assert_eq!(result.get("decision").and_then(Value::as_str), Some("block"));
        assert_eq!(result.get("reason").and_then(Value::as_str), Some("failing: exit 1"));

        // timeout -> SIGTERM -> block with timeout reason.
        let result = runtime.run_registry_event("pre_tool_use:write", &payload);
        assert_eq!(result.get("decision").and_then(Value::as_str), Some("block"));
        assert_eq!(
            result.get("reason").and_then(Value::as_str),
            Some("sleeper: sleeper timed out after 0.05s")
        );

        // unknown event passes with a reason.
        let result = runtime.run_registry_event("pre_tool_use:ssh", &payload);
        assert_eq!(result.get("decision").and_then(Value::as_str), Some("pass"));
        assert_eq!(
            result.get("reason").and_then(Value::as_str),
            Some("no hooks for pre_tool_use:ssh")
        );

        let _ = std::fs::remove_dir_all(&dir);
    }
}
