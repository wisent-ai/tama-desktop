//! tama-adaptive: threshold-free adaptive engine, state store, doctor.
//! Rust port of `src/adaptive/`.

pub mod bridge;
pub mod doctor;
pub mod engine;
pub mod minregex;
pub mod runner;
pub mod segments;
pub mod state;
pub mod telemetry;

mod util;

/// Port of `N(x)`/`Number('2')` usage: exit code for usage errors.
pub const EXIT_USAGE: i32 = 2;
