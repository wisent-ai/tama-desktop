//! Python value semantics the ported hooks are measured against: truthiness,
//! `str()`, `repr()`, and `json.dumps` separators.
//!
//! `serde_json::to_string` is not `json.dumps`: Python writes `", "` and `": "`
//! by default, so a hook that regex-scans the serialization for whitespace
//! before a flag sees a different string without them. `str()` of a container
//! is `repr()`, which quotes with `'` and leaves an embedded `"` unescaped —
//! the opposite of JSON, and exactly what a marker containing `"` depends on.
//!
//! Key order is the one difference that cannot be recovered: Python preserves
//! insertion order, `serde_json::Map` is a `BTreeMap` and sorts. Only detection
//! that straddles two values could ever notice.

use serde_json::Value;

/// Python truthiness, as used by every `x or y` chain in the ported hooks.
pub fn truthy(value: &Value) -> bool {
    match value {
        Value::Null => false,
        Value::Bool(flag) => *flag,
        Value::Number(number) => number
            .as_f64()
            .map(|found| found != f64::default())
            .unwrap_or(true),
        Value::String(text) => !text.is_empty(),
        Value::Array(items) => !items.is_empty(),
        Value::Object(map) => !map.is_empty(),
    }
}

/// `str(value)`: a string is itself, everything else is its `repr`.
pub fn py_str(value: &Value) -> String {
    match value {
        Value::String(text) => text.clone(),
        other => py_repr(other),
    }
}

/// `repr(value)` for a value that came out of `json.loads`.
pub fn py_repr(value: &Value) -> String {
    match value {
        Value::Null => "None".to_string(),
        Value::Bool(flag) => (if *flag { "True" } else { "False" }).to_string(),
        Value::Number(number) => number.to_string(),
        Value::String(text) => repr_str(text),
        Value::Array(items) => {
            let parts: Vec<String> = items.iter().map(py_repr).collect();
            format!("[{}]", parts.join(", "))
        }
        Value::Object(map) => {
            let parts: Vec<String> = map
                .iter()
                .map(|(key, item)| format!("{}: {}", repr_str(key), py_repr(item)))
                .collect();
            format!("{{{}}}", parts.join(", "))
        }
    }
}

/// `repr(str)`: single quotes unless that would need escaping and double
/// quotes would not.
fn repr_str(text: &str) -> String {
    let quote = if text.contains('\'') && !text.contains('"') {
        '"'
    } else {
        '\''
    };
    let mut out = String::with_capacity(text.len());
    out.push(quote);
    for found in text.chars() {
        match found {
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            other if other == quote => {
                out.push('\\');
                out.push(other);
            }
            other if other.is_control() => {
                out.push_str(&format!("\\x{:02x}", other as u32));
            }
            other => out.push(other),
        }
    }
    out.push(quote);
    out
}

/// `json.dumps(value, ensure_ascii=False)` — default separators included.
pub fn py_json_dumps(value: &Value) -> String {
    match value {
        Value::Array(items) => {
            let parts: Vec<String> = items.iter().map(py_json_dumps).collect();
            format!("[{}]", parts.join(", "))
        }
        Value::Object(map) => {
            let parts: Vec<String> = map
                .iter()
                .map(|(key, item)| format!("{}: {}", json_string(key), py_json_dumps(item)))
                .collect();
            format!("{{{}}}", parts.join(", "))
        }
        other => serde_json::to_string(other).unwrap_or_default(),
    }
}

fn json_string(text: &str) -> String {
    serde_json::to_string(text).unwrap_or_default()
}

/// `str(a or b or "")` over the given keys of a mapping.
pub fn first_truthy_py_str(value: &Value, keys: &[&str]) -> String {
    for key in keys {
        if let Some(found) = value.get(*key) {
            if truthy(found) {
                return py_str(found);
            }
        }
    }
    String::new()
}
