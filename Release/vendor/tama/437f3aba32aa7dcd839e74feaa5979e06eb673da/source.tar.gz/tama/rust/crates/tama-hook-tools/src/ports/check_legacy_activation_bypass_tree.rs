//! Tree-scan half of `check_legacy_activation_bypass`: the mode the hook takes
//! when stdin carries no payload.
//!
//! It walks a fixed set of files and directories under the Wisent root, reports
//! the first banned marker found in each file, and separately audits the
//! disabled compatibility stub that replaced the foreground uploader.

use super::check_legacy_activation_bypass_markers as markers;
use super::pystr;
use std::collections::HashSet;
use std::path::{Path, PathBuf};

/// `len(text.splitlines()) > 60`: the stub is a few lines of refusal, so
/// anything larger means the legacy implementation is back.
const MAX_STUB_LINES_TEXT: &str = "60";

fn max_stub_lines() -> usize {
    MAX_STUB_LINES_TEXT.parse().unwrap_or_default()
}

/// `Path.read_text(errors="ignore")`: undecodable bytes are dropped rather than
/// replaced, so an ASCII marker interrupted by one bad byte still matches.
pub fn read_text_ignore(path: &Path) -> std::io::Result<String> {
    let bytes = std::fs::read(path)?;
    let text = String::from_utf8_lossy(&bytes);
    Ok(if text.contains(char::REPLACEMENT_CHARACTER) {
        text.replace(char::REPLACEMENT_CHARACTER, "")
    } else {
        text.into_owned()
    })
}

fn legacy_stub_violations() -> Vec<String> {
    let stub = markers::legacy_stub_path();
    if !stub.exists() {
        return Vec::new();
    }
    let text = match read_text_ignore(&stub) {
        Ok(text) => text,
        Err(error) => return vec![format!("cannot read disabled stub: {error}")],
    };
    let mut errors = Vec::new();
    let missing: Vec<&str> = markers::LEGACY_STUB_REQUIRED
        .iter()
        .copied()
        .filter(|marker| !text.contains(marker))
        .collect();
    if !missing.is_empty() {
        errors.push(format!(
            "missing disabled-stub marker(s): {}",
            missing.join(", ")
        ));
    }
    let forbidden: Vec<&str> = markers::LEGACY_STUB_FORBIDDEN
        .iter()
        .copied()
        .filter(|marker| text.contains(marker))
        .collect();
    if !forbidden.is_empty() {
        errors.push(format!(
            "contains foreground-upload implementation marker(s): {}",
            forbidden.join(", ")
        ));
    }
    if pystr::splitlines(&text).len() > max_stub_lines() {
        errors.push(
            "disabled stub is too large; legacy implementation appears to be back".to_string(),
        );
    }
    errors
}

/// `Path.rglob("*")`: symlinked directories are not descended into, while a
/// symlink to a file still counts as a file. Entries are visited in sorted
/// order — `rglob` inherits the filesystem's own arbitrary order, which only
/// ever decided the order of the report lines.
fn walk(root: &Path, found: &mut Vec<PathBuf>) {
    let entries = match std::fs::read_dir(root) {
        Ok(entries) => entries,
        Err(_) => return,
    };
    let mut paths: Vec<PathBuf> = entries
        .filter_map(|entry| entry.ok())
        .map(|entry| entry.path())
        .collect();
    paths.sort();
    for path in paths {
        match std::fs::symlink_metadata(&path) {
            Ok(link) if link.is_dir() => walk(&path, found),
            Ok(_) => {
                if std::fs::metadata(&path)
                    .map(|meta| meta.is_file())
                    .unwrap_or_default()
                {
                    found.push(path);
                }
            }
            Err(_) => {}
        }
    }
}

fn suffix_of(path: &Path) -> String {
    match path.extension() {
        Some(extension) => format!(".{}", extension.to_string_lossy()),
        None => String::new(),
    }
}

fn iter_tree_files() -> Vec<PathBuf> {
    let mut yielded: HashSet<PathBuf> = HashSet::new();
    let mut out: Vec<PathBuf> = Vec::new();
    for path in markers::tree_scan_paths() {
        if path.exists() && yielded.insert(path.clone()) {
            out.push(path);
        }
    }
    for root in markers::tree_scan_dirs() {
        if !root.exists() {
            continue;
        }
        let mut found = Vec::new();
        walk(&root, &mut found);
        for path in found {
            if !markers::SCAN_SUFFIXES.contains(&suffix_of(&path).as_str()) {
                continue;
            }
            if yielded.insert(path.clone()) {
                out.push(path);
            }
        }
    }
    out
}

/// `true` when the tree still carries a bypass; the banner is already on
/// stderr by then.
pub fn check_tree() -> bool {
    let stub = markers::legacy_stub_path();
    let mut violations: Vec<(PathBuf, String)> = Vec::new();
    for error in legacy_stub_violations() {
        violations.push((stub.clone(), error));
    }
    for path in iter_tree_files() {
        if path == stub {
            continue;
        }
        let text = match read_text_ignore(&path) {
            Ok(text) => text,
            Err(_) => continue,
        };
        let label = path.to_string_lossy().to_string();
        let mut hits = markers::blocks_in_text(&text);
        hits.extend(markers::direct_hf_upload_blocks_in_text(&text, &label));
        hits.extend(markers::queue_blocks_in_text(&text, &label));
        if let Some(hit) = hits.into_iter().next() {
            violations.push((path, hit));
        }
    }
    if violations.is_empty() {
        return false;
    }
    eprintln!(
        "BLOCKED: legacy activation bypass still exists in the Wisent tree. \
Remove the code instead of leaving a bypassable legacy path."
    );
    for (path, hit) in violations {
        eprintln!("  {}: {}", path.display(), hit);
    }
    true
}
