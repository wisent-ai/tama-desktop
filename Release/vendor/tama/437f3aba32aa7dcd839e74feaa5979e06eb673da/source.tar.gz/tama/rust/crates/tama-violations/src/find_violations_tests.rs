//! Rust port of `src/violations/find-violations-tests.mjs`.
//! Fixture tests for find-violations: builds temp git repos under
//! .live-runtime-tmp/ and asserts the scan report and CLI exit codes.
//! Set KEEP_VIOLATION_TEST_ARTIFACTS=1 to keep the fixture repos on disk.
//!
//! This is a CLI entry point (`find_violations_tests::main`), not a
//! `#[test]` suite, mirroring the JS script. Where the JS spawns
//! `node src/cli.mjs ...`, this port spawns the current executable (the
//! tama CLI binary); override with TAMA_CLI_BIN.

use std::path::{Path, PathBuf};
use std::process::Command;
use std::time::{SystemTime, UNIX_EPOCH};

use crate::clean::parse_clean_args;
use crate::find_violations::scan_repo;
use crate::repo_discovery::discover_repos;
use crate::repo_root;
use crate::scan_repos::parse_scan_args;

const EXPECTED_VIOLATIONS: usize = 3;
const DENSE_FILE_NAMES: [&str; 6] = ["alpha", "bravo", "charlie", "delta", "echo", "foxtrot"];

struct Context {
    root: PathBuf,
    hook: PathBuf,
    tmp_root: PathBuf,
    keep: bool,
    failures: u64,
    made: Vec<PathBuf>,
}

impl Context {
    fn check(&mut self, name: &str, condition: bool) {
        if condition {
            println!("ok - {}", name);
        } else {
            self.failures += 1;
            eprintln!("not ok - {}", name);
        }
    }
}

/// `mkdtempSync(join(TMP_ROOT, prefix))`: unique temp dir with the prefix.
fn mkdtemp(prefix: &Path) -> PathBuf {
    let prefix_string = prefix.to_string_lossy().into_owned();
    for attempt in 0..10_000u32 {
        let nanos = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map(|d| d.subsec_nanos())
            .unwrap_or(0);
        let candidate = PathBuf::from(format!("{}{:08x}{:04x}", prefix_string, nanos, attempt));
        if std::fs::create_dir(&candidate).is_ok() {
            return candidate;
        }
    }
    // Give up the same way Node would (mkdtempSync throws): fail loudly.
    panic!("mkdtemp failed for prefix {}", prefix_string);
}

fn make_repo(ctx: &mut Context, prefix: &str) -> PathBuf {
    let _ = std::fs::create_dir_all(&ctx.tmp_root);
    let dir = mkdtemp(&ctx.tmp_root.join(prefix));
    let _ = Command::new("git").args(["init", "--quiet"]).current_dir(&dir).output();
    ctx.made.push(dir.clone());
    dir
}

fn init_repo(ctx: &mut Context, dir: &Path) -> PathBuf {
    let _ = std::fs::create_dir_all(dir);
    let _ = Command::new("git").args(["init", "--quiet"]).current_dir(dir).output();
    ctx.made.push(dir.to_path_buf());
    dir.to_path_buf()
}

fn long_rows() -> String {
    let mut rows = Vec::new();
    for i in 0..350 {
        rows.push(format!("export const row{} = {};", i, i));
    }
    format!("{}\n", rows.join("\n"))
}

fn build_dirty_repo(ctx: &mut Context) -> PathBuf {
    let repo = make_repo(ctx, "violations-dirty-");
    let rows = long_rows();
    let _ = std::fs::write(repo.join("long.js"), &rows);
    // ['fall', 'back'].join('') — spelled so this test file itself passes.
    let banned = ["fall", "back"].concat();
    let _ = std::fs::write(
        repo.join("banned.js"),
        format!("// uses a {} code path\nexport const mode = 'strict';\n", banned),
    );
    let _ = std::fs::write(repo.join("ok.js"), "export const ok = 'ok';\n");
    let _ = std::fs::write(repo.join("blob.dat"), [65u8, 0, 66]);
    let dense = repo.join("dense");
    let _ = std::fs::create_dir(&dense);
    for name in DENSE_FILE_NAMES {
        let _ = std::fs::write(dense.join(format!("{}.js", name)), format!("export const {} = '{}';\n", name, name));
    }
    let vendored = repo.join("vendor").join("lib");
    let _ = std::fs::create_dir_all(&vendored);
    let _ = std::fs::write(vendored.join("long.js"), &rows);
    let built = repo.join("dist");
    let _ = std::fs::create_dir(&built);
    let _ = std::fs::write(built.join("bundle.js"), format!("// uses a {} code path\n", banned));
    repo
}

fn build_multi_tree(ctx: &mut Context) -> (PathBuf, PathBuf, PathBuf) {
    let _ = std::fs::create_dir_all(&ctx.tmp_root);
    let tree = mkdtemp(&ctx.tmp_root.join("violations-tree-"));
    ctx.made.push(tree.clone());
    let tree_dirty = init_repo(ctx, &tree.join("dirty-repo"));
    let _ = std::fs::write(tree_dirty.join("long.js"), long_rows());
    let tree_clean = init_repo(ctx, &tree.join("clean-repo"));
    let _ = std::fs::write(tree_clean.join("ok.js"), "export const ok = 'ok';\n");
    let plain = tree.join("plain");
    let _ = std::fs::create_dir(&plain);
    let _ = std::fs::write(plain.join("note.txt"), "not a repo\n");
    (tree, tree_dirty, tree_clean)
}

/// The executable the CLI-level checks spawn: TAMA_CLI_BIN when set, else
/// the current executable (tests run through the tama CLI binary).
fn cli_bin() -> PathBuf {
    if let Ok(bin) = std::env::var("TAMA_CLI_BIN") {
        if !bin.is_empty() {
            return PathBuf::from(bin);
        }
    }
    std::env::current_exe().unwrap_or_else(|_| PathBuf::from("tama-cli"))
}

struct CliRun {
    status: Option<i32>,
    stdout: String,
    stderr: String,
}

fn run_cli(args: &[&str], envs: &[(&str, &str)]) -> CliRun {
    let mut cmd = Command::new(cli_bin());
    cmd.args(args);
    for (key, value) in envs {
        cmd.env(key, value);
    }
    match cmd.output() {
        Ok(out) => CliRun {
            status: out.status.code(),
            stdout: String::from_utf8_lossy(&out.stdout).into_owned(),
            stderr: String::from_utf8_lossy(&out.stderr).into_owned(),
        },
        Err(_) => CliRun { status: None, stdout: String::new(), stderr: String::new() },
    }
}

fn json_len(value: &serde_json::Value, key: &str) -> Option<usize> {
    value.get(key).and_then(|v| v.as_array()).map(|a| a.len())
}

fn json_num(value: &serde_json::Value, key: &str) -> Option<i64> {
    value.get(key).and_then(|v| v.as_i64())
}

pub fn main(args: &[String]) -> i32 {
    let _ = args; // The JS script ignores argv; kept for CLI symmetry.
    let root = repo_root();
    let mut ctx = Context {
        hook: root.join("shared-hooks").join("pre_write_edit.sh"),
        tmp_root: root.join(".live-runtime-tmp"),
        keep: std::env::var("KEEP_VIOLATION_TEST_ARTIFACTS").as_deref() == Ok("1"),
        root,
        failures: 0,
        made: Vec::new(),
    };

    let dirty = build_dirty_repo(&mut ctx);
    let report = scan_repo(&dirty, &ctx.hook);
    let paths: Vec<&str> = report.violations.iter().map(|v| v.path.as_str()).collect();
    ctx.check(
        "reports the 350-line file",
        report.violations.iter().any(|v| v.path == "long.js" && v.message.contains("max 300")),
    );
    ctx.check(
        "reports the banned keyword file",
        report
            .violations
            .iter()
            .any(|v| v.path == "banned.js" && v.message.contains("Forbidden pattern")),
    );
    ctx.check(
        "reports the dense folder",
        report.violations.iter().any(|v| v.path == "dense" && v.message.contains("max 5")),
    );
    ctx.check("clean file is not flagged", !paths.contains(&"ok.js"));
    ctx.check(
        "binary file is skipped",
        report.skipped_files.iter().any(|s| s.path == "blob.dat"),
    );
    ctx.check(
        "vendored file is skipped, not flagged",
        report.skipped_files.iter().any(|s| s.path == "vendor/lib/long.js")
            && !paths.contains(&"vendor/lib/long.js"),
    );
    ctx.check(
        "build output is skipped, not flagged",
        report.skipped_files.iter().any(|s| s.path == "dist/bundle.js")
            && !paths.contains(&"dist/bundle.js"),
    );
    ctx.check("exactly three violations", report.violations.len() == EXPECTED_VIOLATIONS);
    ctx.check("no scanner errors", report.errors.is_empty());

    let dirty_string = dirty.to_string_lossy().into_owned();
    let cli = run_cli(&["find-violations", "--repo", &dirty_string, "--json"], &[]);
    ctx.check("CLI exits 1 on violations", cli.status == Some(1));
    let parsed: Option<serde_json::Value> = serde_json::from_str(&cli.stdout).ok();
    ctx.check(
        "CLI JSON parses with violations",
        parsed.as_ref().is_some_and(|p| {
            json_len(p, "repos") == Some(1)
                && p.get("repos")
                    .and_then(|r| r.as_array())
                    .and_then(|r| r.first())
                    .map(|r| json_len(r, "violations") == Some(EXPECTED_VIOLATIONS))
                    == Some(true)
                && p.get("totals").map(|t| json_num(t, "violations") == Some(EXPECTED_VIOLATIONS as i64))
                    == Some(true)
        }),
    );

    let clean = make_repo(&mut ctx, "violations-clean-");
    let _ = std::fs::write(clean.join("ok.js"), "export const ok = 'ok';\n");
    let clean_string = clean.to_string_lossy().into_owned();
    let clean_run = run_cli(&["find-violations", "--repo", &clean_string], &[]);
    ctx.check("CLI exits 0 on clean repo", clean_run.status == Some(0));

    let usage = run_cli(&["find-violations"], &[]);
    ctx.check("CLI exits 2 without --repo", usage.status == Some(2));

    let (tree, tree_dirty, tree_clean) = build_multi_tree(&mut ctx);
    let found = discover_repos(&tree);
    let dirty_str = tree_dirty.to_string_lossy().into_owned();
    let clean_str = tree_clean.to_string_lossy().into_owned();
    ctx.check(
        "discovery finds exactly the two repos",
        found.len() == 2 && found.contains(&dirty_str) && found.contains(&clean_str),
    );

    let tree_string = tree.to_string_lossy().into_owned();
    let multi = run_cli(&["find-violations", "--tree", &tree_string, "--json"], &[]);
    ctx.check("multi-repo CLI exits 1", multi.status == Some(1));
    let multi_parsed: Option<serde_json::Value> = serde_json::from_str(&multi.stdout).ok();
    ctx.check(
        "multi-repo JSON has two repos",
        multi_parsed.as_ref().map(|p| json_len(p, "repos") == Some(2)) == Some(true),
    );
    ctx.check(
        "multi-repo totals count violations",
        multi_parsed
            .as_ref()
            .and_then(|p| p.get("totals"))
            .and_then(|t| json_num(t, "violations"))
            .map(|n| n >= 1)
            == Some(true),
    );

    let pair = run_cli(
        &["find-violations", "--repo", &dirty_str, "--repo", &clean_str, "--json"],
        &[],
    );
    ctx.check("two --repo flags exit 1", pair.status == Some(1));

    let clean_tree = run_cli(&["find-violations", "--repo", &clean_str], &[]);
    ctx.check("clean repo still exits 0", clean_tree.status == Some(0));

    let me_args = parse_scan_args(&["--me".to_string()], &ctx.root);
    ctx.check("--me parses as a target", me_args.as_ref().map(|a| a.me) == Some(true));
    ctx.check(
        "--me combines with --owner",
        parse_scan_args(&["--owner".to_string(), "wisent-ai".to_string(), "--me".to_string()], &ctx.root)
            .is_some(),
    );
    ctx.check("no targets still rejected", parse_scan_args(&[], &ctx.root).is_none());

    let clean_rows = long_rows();
    let clean_repo_dir = make_repo(&mut ctx, "violations-cleanrun-");
    let _ = std::fs::write(clean_repo_dir.join("long.js"), &clean_rows);
    let _ = std::fs::write(clean_repo_dir.join("ok.js"), "export const ok = 'ok';\n");
    let clean_repo_string = clean_repo_dir.to_string_lossy().into_owned();
    let clean_cli = run_cli(
        &["clean", "--repo", &clean_repo_string],
        &[("TAMA_CLEAN_AGENT_CMD", "printf 'export const done = \"done\";\\n' > long.js")],
    );
    ctx.check("clean exits 0 after mock agent fixes the file", clean_cli.status == Some(0));
    let rewritten = std::fs::read_to_string(clean_repo_dir.join("long.js")).unwrap_or_default();
    ctx.check("mock agent rewrote the file", rewritten.contains("done"));
    ctx.check(
        "clean output reports CLEAN",
        format!("{}{}", clean_cli.stdout, clean_cli.stderr).contains("CLEAN"),
    );

    let dry_fixture = make_repo(&mut ctx, "violations-dryrun-");
    let _ = std::fs::write(dry_fixture.join("long.js"), &clean_rows);
    let dry_string = dry_fixture.to_string_lossy().into_owned();
    let dry_cli = run_cli(
        &["clean", "--repo", &dry_string, "--dry-run"],
        &[("TAMA_CLEAN_AGENT_CMD", "touch SPAWNED.txt")],
    );
    ctx.check("dry-run prints the brief", dry_cli.stdout.contains("You are cleaning the repository"));
    ctx.check("dry-run does not spawn the agent", !dry_fixture.join("SPAWNED.txt").exists());

    ctx.check(
        "bogus model rejected",
        parse_clean_args(
            &["--repo".to_string(), "x".to_string(), "--model".to_string(), "bogus".to_string()],
            &ctx.root,
        )
        .is_none(),
    );
    ctx.check(
        "dry-run flag parses",
        parse_clean_args(&["--repo".to_string(), "x".to_string(), "--dry-run".to_string()], &ctx.root)
            .map(|a| a.dry_run)
            == Some(true),
    );
    ctx.check(
        "non-numeric rounds rejected",
        parse_clean_args(
            &[
                "--repo".to_string(),
                "x".to_string(),
                "--max-rounds".to_string(),
                "abc".to_string(),
            ],
            &ctx.root,
        )
        .is_none(),
    );

    let game_repo = make_repo(&mut ctx, "violations-gaming-");
    let _ = std::fs::write(game_repo.join("long.js"), &clean_rows);
    let _ = std::fs::write(game_repo.join("ok.js"), "export const ok = 'ok';\n");
    let game_out = format!("{}/../game-briefs.log", game_repo.to_string_lossy());
    let game_mock = "printf '%s\\n' \"$TAMA_CLEAN_BRIEF\" >> \"$TAMA_GAME_OUT\"; printf 'export const done = \"done\";\\n' > long.js; if [ -f mod.source ]; then rm mod.source; else printf 'x\\n' > mod.source; fi";
    let game_string = game_repo.to_string_lossy().into_owned();
    let game_cli = run_cli(
        &["clean", "--repo", &game_string, "--max-rounds", "3"],
        &[("TAMA_CLEAN_AGENT_CMD", game_mock), ("TAMA_GAME_OUT", game_out.as_str())],
    );
    let game_briefs = std::fs::read_to_string(&game_out).unwrap_or_default();
    ctx.check(
        "gaming round is rejected but run recovers to CLEAN",
        game_cli.status == Some(0)
            && format!("{}{}", game_cli.stdout, game_cli.stderr).contains("CLEAN"),
    );
    ctx.check(
        "rejected round feeds feedback into the next brief",
        game_briefs.contains("rejected for rule-gaming") && game_briefs.contains("non-module-extension"),
    );
    ctx.check(
        "pseudo-extension file removed by the recovery round",
        !game_repo.join("mod.source").exists(),
    );

    let note_repo = make_repo(&mut ctx, "violations-note-");
    let _ = std::fs::write(note_repo.join("ok.js"), "export const ok = 'ok';\n");
    let note_out = format!("{}/../note-brief.txt", note_repo.to_string_lossy());
    let note_mock = "printf '%s' \"$TAMA_CLEAN_BRIEF\" > \"$TAMA_NOTE_OUT\"";
    let note_string = note_repo.to_string_lossy().into_owned();
    let note_cli = run_cli(
        &["clean", "--repo", &note_string, "--note", "replace the concat trick"],
        &[("TAMA_CLEAN_AGENT_CMD", note_mock), ("TAMA_NOTE_OUT", note_out.as_str())],
    );
    ctx.check(
        "--note spawns a round with zero violations",
        note_cli.status == Some(0) && Path::new(&note_out).exists(),
    );
    let note_brief = std::fs::read_to_string(&note_out).unwrap_or_default();
    ctx.check("brief carries the operator note", note_brief.contains("replace the concat trick"));

    let dodge_repo = make_repo(&mut ctx, "violations-dodge-");
    let _ = std::fs::write(dodge_repo.join("long.js"), &clean_rows);
    let _ = std::fs::write(dodge_repo.join("my-test-helper.js"), "export const helper = 'h';\n");
    let _ = Command::new("git").args(["add", "-A"]).current_dir(&dodge_repo).output();
    let _ = Command::new("git")
        .args(["-c", "user.email=test@test.t", "-c", "user.name=test", "commit", "-qm", "init"])
        .current_dir(&dodge_repo)
        .output();
    let dodge_out = format!("{}/../dodge-briefs.log", dodge_repo.to_string_lossy());
    let dodge_mock = "printf '%s\\n' \"$TAMA_CLEAN_BRIEF\" >> \"$TAMA_DODGE_OUT\"; printf 'export const done = \"done\";\\n' > long.js; git mv my-test-helper.js my-helper.js || true";
    let dodge_string = dodge_repo.to_string_lossy().into_owned();
    let dodge_cli = run_cli(
        &["clean", "--repo", &dodge_string, "--max-rounds", "2"],
        &[("TAMA_CLEAN_AGENT_CMD", dodge_mock), ("TAMA_DODGE_OUT", dodge_out.as_str())],
    );
    ctx.check("test-name dodge keeps rounds rejected", dodge_cli.status == Some(1));
    let dodge_briefs = std::fs::read_to_string(&dodge_out).unwrap_or_default();
    ctx.check(
        "rename dodge feedback reaches the brief",
        dodge_briefs.contains("test-gate-rename-dodge"),
    );

    let marker = "data:text/javascript";
    let hook_repo = make_repo(&mut ctx, "violations-hookrule-");
    let _ = std::fs::write(hook_repo.join("blob.js"), format!("await import('{};base64,xx');\n", marker));
    let _ = std::fs::write(hook_repo.join("frag.source"), "export const frag = 1;\n");
    let hook_report = scan_repo(&hook_repo, &ctx.hook);
    ctx.check(
        "hook blocks runtime-blob imports",
        hook_report.violations.iter().any(|v| v.path == "blob.js" && v.message.contains(marker)),
    );
    ctx.check(
        "hook blocks pseudo-extension files",
        hook_report
            .violations
            .iter()
            .any(|v| v.path == "frag.source" && v.message.contains("pseudo-extension")),
    );

    let ignore_repo = make_repo(&mut ctx, "violations-ignore-");
    let _ = std::fs::write(
        ignore_repo.join(".tama-violations-ignore"),
        "# by-design\nlegacy/\npinned/old.js\n",
    );
    let _ = std::fs::create_dir(ignore_repo.join("legacy"));
    let _ = std::fs::create_dir(ignore_repo.join("pinned"));
    let _ = std::fs::write(ignore_repo.join("legacy").join("long.js"), &clean_rows);
    let _ = std::fs::write(ignore_repo.join("pinned").join("old.js"), &clean_rows);
    let _ = std::fs::write(ignore_repo.join("long.js"), &clean_rows);
    let ignore_report = scan_repo(&ignore_repo, &ctx.hook);
    let ignore_paths: Vec<&str> = ignore_report.violations.iter().map(|v| v.path.as_str()).collect();
    ctx.check(
        "ignore-listed dir is skipped",
        ignore_report.skipped_files.iter().any(|s| s.path == "legacy/long.js")
            && !ignore_paths.contains(&"legacy/long.js"),
    );
    ctx.check(
        "ignore-listed file is skipped",
        ignore_report.skipped_files.iter().any(|s| s.path == "pinned/old.js")
            && !ignore_paths.contains(&"pinned/old.js"),
    );
    ctx.check("non-ignored file still flagged", ignore_paths.contains(&"long.js"));

    if !ctx.keep {
        for dir in &ctx.made {
            let _ = std::fs::remove_dir_all(dir);
        }
        for out_file in [&game_out, &note_out, &dodge_out] {
            let _ = std::fs::remove_file(out_file);
        }
    }
    if ctx.failures == 0 {
        println!("all find-violations tests passed");
        0
    } else {
        println!("{} check(s) failed", ctx.failures);
        1
    }
}
