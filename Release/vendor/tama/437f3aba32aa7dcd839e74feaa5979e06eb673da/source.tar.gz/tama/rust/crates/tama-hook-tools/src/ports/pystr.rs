//! Python string primitives the ported hooks are measured against.
//!
//! `str::lines` is not `str.splitlines`: Python breaks on eleven boundaries,
//! and a hook that numbers its findings by line has to agree with the Python it
//! replaces or every reported line drifts. `str.rstrip` likewise strips four
//! ASCII separator controls that Rust's `char::is_whitespace` does not claim,
//! and `s[:n]` counts characters rather than bytes.

/// `str.splitlines()` boundaries: CR LF, LF, CR, VT, FF, FS, GS, RS, NEL,
/// LINE SEPARATOR, PARAGRAPH SEPARATOR.
const BOUNDARIES: &[char] = &[
    '\n', '\r', '\u{0b}', '\u{0c}', '\u{1c}', '\u{1d}', '\u{1e}', '\u{85}', '\u{2028}', '\u{2029}',
];

/// `str.isspace()` is true for the ASCII separator controls; the Unicode
/// White_Space property that `char::is_whitespace` reads is not.
const SEPARATOR_CONTROLS: &[char] = &['\u{1c}', '\u{1d}', '\u{1e}', '\u{1f}'];

fn is_py_space(c: char) -> bool {
    c.is_whitespace() || SEPARATOR_CONTROLS.contains(&c)
}

/// `text.splitlines()`: no trailing empty element for a text ending on a
/// boundary, and `CR LF` counts once.
pub fn splitlines(text: &str) -> Vec<&str> {
    let mut out = Vec::new();
    let mut start = usize::MIN;
    let mut chars = text.char_indices().peekable();
    while let Some((index, c)) = chars.next() {
        if !BOUNDARIES.contains(&c) {
            continue;
        }
        out.push(&text[start..index]);
        let mut end = index + c.len_utf8();
        if c == '\r' {
            if let Some(&(_, '\n')) = chars.peek() {
                chars.next();
                end += '\n'.len_utf8();
            }
        }
        start = end;
    }
    if start < text.len() {
        out.push(&text[start..]);
    }
    out
}

/// `text.rstrip()`.
pub fn rstrip(text: &str) -> &str {
    text.trim_end_matches(is_py_space)
}

/// `text.strip()`.
pub fn strip(text: &str) -> &str {
    text.trim_matches(is_py_space)
}

/// `text[:count]` — Python slices characters, not bytes.
pub fn head_chars(text: &str, count: usize) -> &str {
    match text.char_indices().nth(count) {
        Some((index, _)) => &text[..index],
        None => text,
    }
}

/// `text[-count:]` — a window shorter than `count` is the whole text.
pub fn tail_chars(text: &str, count: usize) -> &str {
    let total = text.chars().count();
    match total.checked_sub(count) {
        Some(skipped) => match text.char_indices().nth(skipped) {
            Some((index, _)) => &text[index..],
            None => text,
        },
        None => text,
    }
}
