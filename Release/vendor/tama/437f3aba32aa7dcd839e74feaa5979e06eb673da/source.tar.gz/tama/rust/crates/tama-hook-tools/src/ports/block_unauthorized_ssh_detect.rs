//! Detection half of the `shared-hooks/block_unauthorized_ssh.py` port (hook
//! id `block-unauthorized-ssh`): the patterns, the tool tables, and the three
//! functions that read a command line's shape. Split from
//! [`crate::ports::block_unauthorized_ssh`] to stay inside the 300-line limit.
//!
//! Python `re.I` becomes `(?i)` and `re.S` becomes `(?s)`. Three of these
//! patterns cannot be transcribed: Rust's regex engine has no lookaround, and
//! its `$` is end-of-text where Python's also matches before one trailing
//! newline. Each rewrite is justified at its definition, and each preserves
//! the accepted language rather than approximating it.

use std::sync::LazyLock;

use regex::Regex;
use serde_json::Value;

use crate::ports::pystr;
use crate::ports::pyvalue;
use crate::ports::transport_common as common;

const COMMAND_KEYS: &[&str] = &["command", "cmd", "code"];
const OP_KEYS: &[&str] = &["op"];
const APPLICATION_KEYS: &[&str] = &["application"];
const ARGS_KEY: &str = "args";
const START_OP: &str = "start";
const HUB_TOOLS: &[&str] = &["hub", "functions.hub"];
pub const EXECUTABLE_TOOLS: &[&str] = &[
    "bash",
    "functions.bash",
    "eval",
    "functions.eval",
    "mcp__node_repl_js",
    "node_repl/js",
    "hub",
    "functions.hub",
];
pub const WRITE_TOOLS: &[&str] = &[
    "write",
    "functions.write",
    "edit",
    "functions.edit",
    "multiedit",
    "notebook",
    "notebookedit",
    "apply_patch",
];
pub const EXEC_OP: &str = "exec";
const TUNNEL_OP: &str = "tunnel";
const GIT_OP: &str = "git";
const TRANSFER_OP: &str = "transfer";

/// `SSH_TOOL_RE`. Python's `$` also matches before one trailing newline, so
/// the alternative is spelled `\n?\z` rather than `$`.
pub static SSH_TOOL_RE: LazyLock<Regex> =
    LazyLock::new(|| common::compile("(?i)(?:^|[._:/-])ssh(?:\\n?\\z|[._:/-])"));

/// `SSH_BINARY_RE`, restructured: the trailing `(?=\s|$)` lookahead becomes a
/// consumed terminator. The result is only ever read as a boolean and a
/// candidate exists at exactly the same offsets either way; the lookahead's
/// `$` needs no `\n?\z` spelling because `\s` already covers the newline that
/// Python's `$` would sit in front of.
static SSH_BINARY_RE: LazyLock<Regex> =
    LazyLock::new(|| common::compile("(?i)(?:^|[/\\s;&|`(])(?:ssh|scp|sftp)(?:\\s|$)"));

/// `RSYNC_REMOTE_RE`, restructured: `rsync(?=\s|$).+?` becomes `rsync\s.*?`.
/// The lookahead's `$` branch can never complete a match — `.+?` needs a
/// character that end-of-text does not have — so consuming the whitespace and
/// dropping the branch accepts exactly the same texts.
static RSYNC_REMOTE_RE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(
        "(?is)(?:^|[/\\s;&|`(])rsync\\s.*?(?:ssh://|(?:[A-Za-z0-9._-]+@)?[A-Za-z0-9.-]+:)",
    )
});

/// `GIT_SSH_RE`, restructured the same way as `RSYNC_REMOTE_RE`.
static GIT_SSH_RE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile("(?is)(?:^|[/\\s;&|`(])git\\s.*?(?:ssh://|git@[A-Za-z0-9.-]+:)")
});

static SSH_LIBRARY_RE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile("(?i)\\b(?:paramiko|asyncssh|fabric\\.Connection|node-ssh|ssh2)\\b")
});

pub static SSH_QUOTE_RE: LazyLock<Regex> = LazyLock::new(|| common::compile("(?i)\\bssh\\b"));

/// `command_operation`'s port-forwarding test, which Python compiles without
/// `re.I`.
static TUNNEL_RE: LazyLock<Regex> =
    LazyLock::new(|| common::compile("(?:^|\\s)-(?:[A-Za-z]*[LRDW]|[LRDW])"));

/// `command_operation`'s transfer test, with the same lookahead restructuring
/// as `SSH_BINARY_RE`.
static TRANSFER_RE: LazyLock<Regex> =
    LazyLock::new(|| common::compile("(?i)(?:^|[/\\s;&|`(])(?:scp|sftp|rsync)(?:\\s|$)"));

/// `DIRECT_IMPERATIVE_RE`: the SSH verb list, which differs from the CUA one.
pub static DIRECT_IMPERATIVE_RE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(?i)^\\s*(?:(?:prosz[eę]|please)\\s+)?",
        "(?:u[zż]yj|uruchom|po[lł][aą]cz|zaloguj|odczytaj|pobierz|wy[sś]lij|skopiuj|",
        "use|run|connect|log\\s+in|read|fetch|send|copy)\\b",
    ))
});

/// `command_text`: the command this call would run, including the one a
/// `hub` start assembles from its application and arguments.
pub fn command_text(name: &str, input: &Value) -> String {
    if let Value::String(text) = common::or_chain(input, COMMAND_KEYS) {
        return pystr::strip(&text).to_string();
    }
    if HUB_TOOLS.contains(&name.to_lowercase().as_str())
        && pyvalue::first_truthy_py_str(input, OP_KEYS).to_lowercase() == START_OP
    {
        let mut parts = vec![pyvalue::first_truthy_py_str(input, APPLICATION_KEYS)];
        if let Some(Value::Array(items)) = input.get(ARGS_KEY) {
            parts.extend(items.iter().map(pyvalue::py_str));
        }
        return pystr::strip(&parts.join(" ")).to_string();
    }
    String::new()
}

/// `contains_ssh_command`.
pub fn contains_ssh_command(command: &str) -> bool {
    SSH_BINARY_RE.is_match(command)
        || RSYNC_REMOTE_RE.is_match(command)
        || GIT_SSH_RE.is_match(command)
        || SSH_LIBRARY_RE.is_match(command)
        || crate::ports::block_unauthorized_ssh_targets::SSH_URL_RE.is_match(command)
}

/// `command_operation`.
pub fn command_operation(command: &str) -> String {
    if TUNNEL_RE.is_match(command) {
        return TUNNEL_OP.to_string();
    }
    if GIT_SSH_RE.is_match(command) {
        return GIT_OP.to_string();
    }
    match TRANSFER_RE.is_match(command) {
        true => TRANSFER_OP.to_string(),
        false => EXEC_OP.to_string(),
    }
}
