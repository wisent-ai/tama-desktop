//! Logic for `tama-block-keychain-prompt-commands` — port of
//! `codex-hooks/block_keychain_prompt_commands.py`, registry hook id
//! `block-keychain-prompt-commands`.
//!
//! Block shell commands that can trigger a macOS Keychain permission prompt.
//! An auth-aware CLI such as `supabase` reads secrets from the login keychain
//! and raises native UI the agent cannot answer, so the agent must use
//! explicit non-interactive credentials from already-approved paths instead.
//!
//! No lifetime annotation or character literal appears below on purpose: the
//! `block-numeric-literals` guard strips strings with a scanner that reads a
//! lifetime tick as an opening quote, which would desync it over the digits
//! inside the patterns.

use regex::Regex;
use serde_json::Value;
use tama_hooks::session_record::{deny_tool_use, read_payload};

use super::codex_api_guard as guard;
use super::pyvalue::{py_str, truthy};

/// The shell-metacharacter-or-space class both edges of most patterns use.
const EDGE: &str = "[;&|()`{}\\s]";

fn compiled(pattern: &str, reason: &str) -> (Regex, String) {
    let expression = Regex::new(pattern).expect("keychain pattern must compile");
    (expression, reason.to_string())
}

/// `BLOCKED_PATTERNS`, in source order — the first match decides the reason.
/// Python's `re.IGNORECASE` becomes the inline `(?i)` flag.
fn blocked_patterns() -> Vec<(Regex, String)> {
    vec![
        compiled(
            &format!("(?i)(^|{EDGE})supabase({EDGE}|$)"),
            "Supabase CLI can read the 'Supabase CLI' macOS Keychain item and trigger a password prompt.",
        ),
        compiled(
            &format!("(?i)(^|{EDGE})security({EDGE}|$)"),
            "macOS `security` directly accesses Keychain services.",
        ),
        compiled(
            "(?i)credential-osxkeychain|git\\s+credential\\s+(fill|approve|reject)",
            "Git credential helpers can access macOS Keychain.",
        ),
        compiled(
            &format!("(?i)(^|{EDGE})gh\\s+auth({EDGE}|$)"),
            "GitHub CLI auth can access local credential storage.",
        ),
        compiled(
            &format!("(?i)(^|{EDGE})vercel\\s+(login|switch)({EDGE}|$)"),
            "Vercel interactive auth can touch local credential storage.",
        ),
        compiled(
            &format!("(?i)(^|{EDGE})(op|1password)\\s+"),
            "1Password CLI can trigger unlock or keychain-backed auth prompts.",
        ),
        compiled(
            &format!("(?i)(^|{EDGE})aws\\s+(sso\\s+login|configure\\s+sso)({EDGE}|$)"),
            "AWS SSO auth is interactive and can open credential prompts.",
        ),
        compiled(
            &format!("(?i)(^|{EDGE})gcloud\\s+auth({EDGE}|$)"),
            "Google Cloud auth is interactive and can access local credential storage.",
        ),
        compiled(
            &format!("(?i)(^|{EDGE})az\\s+(login|account\\s+get-access-token)({EDGE}|$)"),
            "Azure CLI auth can access local credential storage.",
        ),
        compiled(
            &format!("(?i)(^|{EDGE})(firebase|netlify|heroku|stripe)\\s+(login|auth)({EDGE}|$)"),
            "Interactive platform CLI auth can trigger local credential prompts.",
        ),
        compiled(
            &format!("(?i)(^|{EDGE})docker\\s+login({EDGE}|$)"),
            "Docker login can use the macOS credential/keychain helper.",
        ),
        compiled(
            &format!("(?i)(^|{EDGE})ssh-add(\\s+.*)?(--apple-use-keychain|-K)({EDGE}|$)"),
            "ssh-add keychain flags directly interact with macOS Keychain.",
        ),
        compiled(
            "(?i)\\b(keychain|login-keychain|osxkeychain|macos-keychain)\\b",
            "Command references a keychain-backed credential path.",
        ),
    ]
}

/// `command_from`: the first truthy command field, else `str(tool_input)`.
fn command_from(data: &Value) -> String {
    let empty = Value::Object(Default::default());
    let tool_input = data
        .get("tool_input")
        .filter(|value| value.is_object())
        .unwrap_or(&empty);

    if let Some(found) = guard::first_truthy(&[
        (tool_input, "command"),
        (tool_input, "cmd"),
        (data, "command"),
        (data, "cmd"),
    ]) {
        // Python hands this value straight to `re.search`, where a non-string
        // raises and leaves the tool unblocked; it yields no text here, and it
        // does not fall through to the payload rendering below either.
        return found.as_str().unwrap_or_default().to_string();
    }

    match data.get("tool_input").filter(|raw| truthy(raw)) {
        Some(raw) => py_str(raw),
        None => String::new(),
    }
}

pub fn run() {
    let data = read_payload();
    let tool = data
        .get("tool_name")
        .and_then(Value::as_str)
        .unwrap_or_default();
    if !guard::SHELL_TOOLS.contains(&tool) {
        return;
    }

    let command = command_from(&data);
    let matched = blocked_patterns()
        .into_iter()
        .find(|(pattern, _)| pattern.is_match(&command));
    let reason = match matched {
        Some((_, reason)) => reason,
        None => return,
    };

    deny_tool_use(&format!(
        "BLOCKED: command may trigger a native macOS Keychain/auth permission prompt.\n  reason: \
         {reason}\n\nUse a non-interactive path instead: already-approved env vars, an explicit \
         connection string, service-role API calls, or a checked-in migration script that does \
         not invoke a keychain-backed CLI."
    ))
}
