//! Rust port of `src/violations/repo-discovery.mjs`.
//! Repository discovery for multi-repo scans: finds Git checkouts under a
//! root directory, lists GitHub user/org repositories through the gh CLI,
//! and resolves them to local checkouts (reusing clones already present in
//! the clone directory, shallow-cloning the rest).

use serde::Serialize;
use std::collections::HashSet;
use std::path::Path;
use std::process::Command;

use crate::first_line;
use crate::resolve_path;

// Directories that never hold interesting checkouts and are expensive to walk.
const PRUNE_DIR_NAMES: [&str; 16] = [
    ".git",
    "node_modules",
    "Library",
    ".Trash",
    ".cache",
    ".next",
    "__pycache__",
    "chromium-build",
    "dist",
    "build",
    "vendor",
    "target",
    ".venv",
    "venv",
    "coverage",
    ".live-runtime-tmp",
];
const GH_LIST_LIMIT: u32 = 1000;

#[derive(Debug, Clone, Serialize)]
pub struct Target {
    pub path: String,
    pub via: String,
}

#[derive(Debug, Clone, Serialize)]
pub struct Problem {
    pub owner: String,
    /// Always present in the JSON shape, `null` when the failure is not
    /// tied to one repository (mirrors the JS `{ owner, repo: null, error }`).
    pub repo: Option<String>,
    pub error: String,
}

#[derive(Debug, Clone)]
pub struct ResolvedTargets {
    pub targets: Vec<Target>,
    pub problems: Vec<Problem>,
}

/// Finds Git checkouts under `root_dir`. Mirrors the JS original: a directory
/// counts as a repo when any direct child is named `.git` (file or dir,
/// matching the JS name-only check), and the walk still descends into
/// already-found repos.
pub fn discover_repos(root_dir: &Path) -> Vec<String> {
    let mut repos = Vec::new();
    fn visit(dir: &Path, repos: &mut Vec<String>) {
        let entries = match std::fs::read_dir(dir) {
            Ok(entries) => entries,
            Err(_) => return,
        };
        let mut names: Vec<(String, bool)> = Vec::new();
        for entry in entries.flatten() {
            let is_dir = entry.file_type().map(|ft| ft.is_dir()).unwrap_or(false);
            names.push((entry.file_name().to_string_lossy().into_owned(), is_dir));
        }
        // Node `readdirSync` returns entries sorted by name.
        names.sort_by(|a, b| a.0.cmp(&b.0));
        if names.iter().any(|(name, _)| name == ".git") {
            repos.push(dir.to_string_lossy().into_owned());
        }
        for (name, is_dir) in names {
            if !is_dir {
                continue;
            }
            if PRUNE_DIR_NAMES.contains(&name.as_str()) {
                continue;
            }
            visit(&dir.join(&name), repos);
        }
    }
    visit(root_dir, &mut repos);
    repos
}

/// `gh repo list <owner> --limit 1000 --json nameWithOwner`.
/// Returns `(repos, error)` exactly like the JS `{ repos, error }` pair.
pub fn github_repos(owner: &str) -> (Option<Vec<String>>, Option<String>) {
    let out = Command::new("gh")
        .args(["repo", "list", owner, "--limit", &GH_LIST_LIMIT.to_string(), "--json", "nameWithOwner"])
        .output();
    let out = match out {
        Ok(out) => out,
        Err(_) => return (None, Some("gh repo list failed".to_string())),
    };
    if out.status.code() != Some(0) {
        let error = first_line(&String::from_utf8_lossy(&out.stderr));
        return (None, Some(if error.is_empty() { "gh repo list failed".to_string() } else { error }));
    }
    let parsed: Option<serde_json::Value> =
        serde_json::from_str(&String::from_utf8_lossy(&out.stdout)).ok();
    let entries = match parsed.and_then(|value| value.as_array().cloned()) {
        Some(entries) => entries,
        None => return (None, Some("unexpected gh repo list output".to_string())),
    };
    let repos = entries
        .iter()
        .filter_map(|entry| entry.get("nameWithOwner").and_then(|v| v.as_str()))
        .map(|name| name.to_string())
        .collect();
    (Some(repos), None)
}

/// `gh api user --jq .login`.
pub fn github_login() -> (Option<String>, Option<String>) {
    let out = Command::new("gh").args(["api", "user", "--jq", ".login"]).output();
    let out = match out {
        Ok(out) => out,
        Err(_) => return (None, Some("gh api user failed".to_string())),
    };
    if out.status.code() != Some(0) {
        let error = first_line(&String::from_utf8_lossy(&out.stderr));
        return (None, Some(if error.is_empty() { "gh api user failed".to_string() } else { error }));
    }
    (Some(first_line(&String::from_utf8_lossy(&out.stdout))), None)
}

/// `gh api user/orgs --paginate --jq .[].login`.
pub fn github_orgs() -> (Option<Vec<String>>, Option<String>) {
    let out = Command::new("gh")
        .args(["api", "user/orgs", "--paginate", "--jq", ".[].login"])
        .output();
    let out = match out {
        Ok(out) => out,
        Err(_) => return (None, Some("gh api user/orgs failed".to_string())),
    };
    if out.status.code() != Some(0) {
        let error = first_line(&String::from_utf8_lossy(&out.stderr));
        return (None, Some(if error.is_empty() { "gh api user/orgs failed".to_string() } else { error }));
    }
    let orgs = String::from_utf8_lossy(&out.stdout)
        .split('\n')
        .map(|line| line.trim())
        .filter(|line| !line.is_empty())
        .map(|line| line.to_string())
        .collect();
    (Some(orgs), None)
}

pub struct Checkout {
    pub path: String,
    pub cloned: bool,
    pub error: Option<String>,
}

/// Reuses the clone under `<cloneDir>/<owner>__<repo>` when present, else
/// shallow-clones. Mirrors JS `nameWithOwner.replace('/', '__')`, which
/// replaces only the first `/`.
pub fn ensure_checkout(name_with_owner: &str, clone_dir: &Path) -> Checkout {
    let target = clone_dir.join(name_with_owner.replacen('/', "__", 1));
    let target_string = target.to_string_lossy().into_owned();
    if target.join(".git").exists() {
        return Checkout { path: target_string, cloned: false, error: None };
    }
    let _ = std::fs::create_dir_all(clone_dir);
    let out = Command::new("gh")
        .args(["repo", "clone", name_with_owner, &target_string, "--", "--depth", "1"])
        .output();
    let out = match out {
        Ok(out) => out,
        Err(_) => {
            return Checkout { path: target_string, cloned: false, error: Some("gh repo clone failed".to_string()) }
        }
    };
    if out.status.code() != Some(0) {
        let error = first_line(&String::from_utf8_lossy(&out.stderr));
        return Checkout {
            path: target_string,
            cloned: false,
            error: Some(if error.is_empty() { "gh repo clone failed".to_string() } else { error }),
        };
    }
    Checkout { path: target_string, cloned: true, error: None }
}

/// The subset of parsed scan arguments discovery needs (`resolveTargets`).
pub struct DiscoveryArgs<'a> {
    pub repos: &'a [String],
    pub trees: &'a [String],
    pub owners: &'a [String],
    pub me: bool,
    pub clone_dir: &'a Path,
}

pub fn resolve_targets(args: &DiscoveryArgs) -> ResolvedTargets {
    let mut targets: Vec<Target> = Vec::new();
    let mut problems: Vec<Problem> = Vec::new();
    let mut seen: HashSet<String> = HashSet::new();

    fn add(
        path: &str,
        via: &str,
        seen: &mut HashSet<String>,
        targets: &mut Vec<Target>,
    ) {
        let full = resolve_path(&[Path::new(path)]).to_string_lossy().into_owned();
        if !seen.insert(full.clone()) {
            return;
        }
        targets.push(Target { path: full, via: via.to_string() });
    }

    fn add_owner_repos(
        owner: &str,
        clone_dir: &Path,
        seen: &mut HashSet<String>,
        targets: &mut Vec<Target>,
        problems: &mut Vec<Problem>,
    ) {
        let (repos, error) = github_repos(owner);
        let repos = match repos {
            Some(repos) => repos,
            None => {
                problems.push(Problem {
                    owner: owner.to_string(),
                    repo: None,
                    error: error.unwrap_or_else(|| "gh repo list failed".to_string()),
                });
                return;
            }
        };
        for name_with_owner in repos {
            let checkout = ensure_checkout(&name_with_owner, clone_dir);
            if let Some(error) = checkout.error {
                problems.push(Problem {
                    owner: owner.to_string(),
                    repo: Some(name_with_owner.clone()),
                    error,
                });
                continue;
            }
            add(&checkout.path, "github", seen, targets);
        }
    }

    for repo in args.repos {
        add(repo, "repo", &mut seen, &mut targets);
    }
    for tree in args.trees {
        let resolved = resolve_path(&[Path::new(tree)]);
        for found in discover_repos(&resolved) {
            add(&found, "tree", &mut seen, &mut targets);
        }
    }
    if args.me {
        let (login, error) = github_login();
        match login {
            None => problems.push(Problem {
                owner: "me".to_string(),
                repo: None,
                error: error.unwrap_or_else(|| "gh api user failed".to_string()),
            }),
            Some(login) => {
                add_owner_repos(&login, args.clone_dir, &mut seen, &mut targets, &mut problems);
                let (orgs, error) = github_orgs();
                match orgs {
                    None => problems.push(Problem {
                        owner: "me".to_string(),
                        repo: None,
                        error: error.unwrap_or_else(|| "gh api user/orgs failed".to_string()),
                    }),
                    Some(orgs) => {
                        for org in orgs {
                            add_owner_repos(&org, args.clone_dir, &mut seen, &mut targets, &mut problems);
                        }
                    }
                }
            }
        }
    }
    for owner in args.owners {
        add_owner_repos(owner, args.clone_dir, &mut seen, &mut targets, &mut problems);
    }
    ResolvedTargets { targets, problems }
}
