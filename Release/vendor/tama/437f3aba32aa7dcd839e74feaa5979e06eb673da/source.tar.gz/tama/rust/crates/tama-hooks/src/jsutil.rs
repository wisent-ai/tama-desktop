//! Internal helpers reproducing small pieces of JavaScript semantics that the
//! ported modules rely on: whitespace classes, truthiness, `String()`/`Number()`
//! coercion, ISO-8601 timestamps (`Date.parse` / `Date#toISOString`), the home
//! directory and POSIX `path.basename`.

use std::env;
use std::path::PathBuf;
use std::time::{SystemTime, UNIX_EPOCH};

use serde_json::Value;

/// JS `\s` / `String#trim` whitespace: Unicode `White_Space` plus U+FEFF,
/// which Rust's `char::is_whitespace` does not include.
pub fn is_js_whitespace(c: char) -> bool {
    c.is_whitespace() || c == '\u{feff}'
}

pub fn trim_js(s: &str) -> &str {
    s.trim_matches(is_js_whitespace)
}

/// JS truthiness of a JSON value (`undefined`/`None` is falsy).
pub fn js_truthy(v: Option<&Value>) -> bool {
    match v {
        None | Some(Value::Null) => false,
        Some(Value::Bool(b)) => *b,
        Some(Value::Number(n)) => n.as_f64().is_some_and(|f| f != 0.0),
        Some(Value::String(s)) => !s.is_empty(),
        // Arrays (even empty) and objects are always truthy in JS.
        Some(_) => true,
    }
}

/// JS `String(value)` for a JSON value.
pub fn js_to_string(v: &Value) -> String {
    match v {
        Value::Null => "null".to_string(),
        Value::Bool(b) => if *b { "true" } else { "false" }.to_string(),
        Value::Number(n) => js_number_to_string(n),
        Value::String(s) => s.clone(),
        // Array#toString joins with commas; null/undefined become empty.
        Value::Array(items) => items
            .iter()
            .map(|i| match i {
                Value::Null => String::new(),
                other => js_to_string(other),
            })
            .collect::<Vec<_>>()
            .join(","),
        Value::Object(_) => "[object Object]".to_string(),
    }
}

/// JS `String(value)` where the value may be absent (`undefined`).
pub fn js_to_string_opt(v: Option<&Value>) -> String {
    match v {
        None => "undefined".to_string(),
        Some(v) => js_to_string(v),
    }
}

/// JS `String(value || '')`.
pub fn js_string_or_empty(v: Option<&Value>) -> String {
    match v {
        Some(v) if js_truthy(Some(v)) => js_to_string(v),
        _ => String::new(),
    }
}

/// Approximation of JS `Number#toString` for JSON numbers.
pub fn js_number_to_string(n: &serde_json::Number) -> String {
    if let Some(i) = n.as_i64() {
        return i.to_string();
    }
    if let Some(u) = n.as_u64() {
        return u.to_string();
    }
    let f = n.as_f64().unwrap_or(f64::NAN);
    if f == 0.0 {
        return "0".to_string(); // also covers -0
    }
    let a = f.abs();
    if f.fract() == 0.0 && a < 1e21 {
        return format!("{f:.0}");
    }
    if a >= 1e21 || a < 1e-6 {
        // Rust prints "1.5e21"; JS prints "1.5e+21".
        let s = format!("{f:e}");
        return match s.split_once('e') {
            Some((m, e)) if !e.starts_with('-') => format!("{m}e+{e}"),
            _ => s,
        };
    }
    format!("{f}")
}

/// JS `Number(string)` coercion for the subset relevant to numeric env vars.
pub fn js_number(s: &str) -> f64 {
    let t = trim_js(s);
    if t.is_empty() {
        return 0.0;
    }
    match t {
        "Infinity" | "+Infinity" => return f64::INFINITY,
        "-Infinity" => return f64::NEG_INFINITY,
        _ => {}
    }
    // Hex / octal / binary integer literals (unsigned, per the JS grammar).
    for (prefix, radix) in [("0x", 16u32), ("0X", 16), ("0o", 8), ("0O", 8), ("0b", 2), ("0B", 2)] {
        if let Some(rest) = t.strip_prefix(prefix) {
            if rest.is_empty() {
                return f64::NAN;
            }
            let mut v = 0f64;
            for c in rest.chars() {
                match c.to_digit(radix) {
                    Some(d) => v = v * radix as f64 + d as f64,
                    None => return f64::NAN,
                }
            }
            return v;
        }
    }
    if !is_js_decimal(t) {
        return f64::NAN;
    }
    t.parse::<f64>().unwrap_or(f64::NAN)
}

fn is_js_decimal(t: &str) -> bool {
    let b = t.as_bytes();
    let mut i = 0;
    if i < b.len() && (b[i] == b'+' || b[i] == b'-') {
        i += 1;
    }
    let mut int_digits = 0;
    while i < b.len() && b[i].is_ascii_digit() {
        i += 1;
        int_digits += 1;
    }
    let mut frac_digits = 0;
    if i < b.len() && b[i] == b'.' {
        i += 1;
        while i < b.len() && b[i].is_ascii_digit() {
            i += 1;
            frac_digits += 1;
        }
    }
    if int_digits == 0 && frac_digits == 0 {
        return false;
    }
    if i < b.len() && (b[i] == b'e' || b[i] == b'E') {
        i += 1;
        if i < b.len() && (b[i] == b'+' || b[i] == b'-') {
            i += 1;
        }
        let mut exp_digits = 0;
        while i < b.len() && b[i].is_ascii_digit() {
            i += 1;
            exp_digits += 1;
        }
        if exp_digits == 0 {
            return false;
        }
    }
    i == b.len()
}

/// `Number.isSafeInteger(value) && value > 0 ? value : null`.
pub fn js_safe_integer_positive(s: &str) -> Option<i64> {
    let v = js_number(s);
    if v.is_finite() && v > 0.0 && v.fract() == 0.0 && v <= 9_007_199_254_740_991.0 {
        Some(v as i64)
    } else {
        None
    }
}

/// Milliseconds since the Unix epoch, like `Date.now()`.
pub fn now_millis() -> f64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as f64)
        .unwrap_or(0.0)
}

// Civil-date conversions (Howard Hinnant's algorithms), needed because no
// date/time crate may be added.

fn days_from_civil(y: i64, m: i64, d: i64) -> i64 {
    let y = if m <= 2 { y - 1 } else { y };
    let era = if y >= 0 { y } else { y - 399 } / 400;
    let yoe = y - era * 400; // [0, 399]
    let mp = (m + 9) % 12; // [0, 11]
    let doy = (153 * mp + 2) / 5 + d - 1;
    let doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    era * 146097 + doe - 719468
}

fn civil_from_days(z: i64) -> (i64, i64, i64) {
    let z = z + 719468;
    let era = if z >= 0 { z } else { z - 146096 } / 146097;
    let doe = z - era * 146097; // [0, 146096]
    let yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    let y = yoe + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = doy - (153 * mp + 2) / 5 + 1;
    let m = if mp < 10 { mp + 3 } else { mp - 9 };
    (if m <= 2 { y + 1 } else { y }, m, d)
}

fn is_leap_year(y: i64) -> bool {
    y % 4 == 0 && (y % 100 != 0 || y % 400 == 0)
}

fn days_in_month(y: i64, m: i64) -> i64 {
    match m {
        1 | 3 | 5 | 7 | 8 | 10 | 12 => 31,
        4 | 6 | 9 | 11 => 30,
        2 => {
            if is_leap_year(y) {
                29
            } else {
                28
            }
        }
        _ => 0,
    }
}

/// `new Date(ms).toISOString()` — always UTC, `YYYY-MM-DDTHH:mm:ss.sssZ`
/// (expanded signed six-digit year outside 0000..=9999).
pub fn to_iso_string(ms: f64) -> String {
    let ms = ms.trunc() as i64;
    let days = ms.div_euclid(86_400_000);
    let rem = ms.rem_euclid(86_400_000);
    let (y, mo, d) = civil_from_days(days);
    let (hh, mi, ss, mss) = (
        rem / 3_600_000,
        (rem / 60_000) % 60,
        (rem / 1_000) % 60,
        rem % 1_000,
    );
    let year = if (0..=9999).contains(&y) {
        format!("{y:04}")
    } else if y > 9999 {
        format!("+{y:06}")
    } else {
        format!("-{:06}", -y)
    };
    format!("{year}-{mo:02}-{d:02}T{hh:02}:{mi:02}:{ss:02}.{mss:03}Z")
}

fn take_digits(b: &[u8], i: &mut usize, n: usize) -> Option<i64> {
    if *i + n > b.len() {
        return None;
    }
    let mut v: i64 = 0;
    for k in 0..n {
        let c = b[*i + k];
        if !c.is_ascii_digit() {
            return None;
        }
        v = v * 10 + (c - b'0') as i64;
    }
    *i += n;
    Some(v)
}

/// Subset of `Date.parse(string)`: the ISO-8601 forms (`YYYY`, `YYYY-MM`,
/// `YYYY-MM-DD`, optional `THH:mm[:ss[.fff]]`, optional `Z`/`±hh[:mm]` zone).
/// Returns milliseconds since the epoch.
///
/// Deviation: a date-time without a zone is treated as UTC, whereas JS parses
/// it in the local timezone. Values in this codebase are produced by
/// `toISOString()` and always carry `Z`.
pub fn parse_date(s: &str) -> Option<f64> {
    let b = s.as_bytes();
    let mut i = 0usize;
    let (year, sign): (i64, i64) = if b.first() == Some(&b'+') {
        i = 1;
        (take_digits(b, &mut i, 6)?, 1)
    } else if b.first() == Some(&b'-') {
        i = 1;
        (take_digits(b, &mut i, 6)?, -1)
    } else {
        (take_digits(b, &mut i, 4)?, 1)
    };
    let year = year * sign;
    let mut month = 1i64;
    let mut day = 1i64;
    if i < b.len() && b[i] == b'-' {
        i += 1;
        month = take_digits(b, &mut i, 2)?;
        if i < b.len() && b[i] == b'-' {
            i += 1;
            day = take_digits(b, &mut i, 2)?;
        }
    }
    if !(1..=12).contains(&month) || day < 1 || day > days_in_month(year, month) {
        return None;
    }

    let mut hour = 0i64;
    let mut minute = 0i64;
    let mut second = 0i64;
    let mut millis = 0i64;
    let mut has_time = false;
    if i < b.len() && (b[i] == b'T' || b[i] == b' ') {
        has_time = true;
        i += 1;
        hour = take_digits(b, &mut i, 2)?;
        if i >= b.len() || b[i] != b':' {
            return None;
        }
        i += 1;
        minute = take_digits(b, &mut i, 2)?;
        if i < b.len() && b[i] == b':' {
            i += 1;
            second = take_digits(b, &mut i, 2)?;
            if i < b.len() && b[i] == b'.' {
                i += 1;
                let start = i;
                while i < b.len() && b[i].is_ascii_digit() {
                    i += 1;
                }
                if i == start {
                    return None;
                }
                let digits = &b[start..i];
                // First three digits, right-padded with zeros (".5" -> 500ms).
                millis = (0..3).fold(0i64, |a, k| {
                    a * 10 + digits.get(k).map_or(0, |c| (c - b'0') as i64)
                });
            }
        }
    }
    if hour > 23 || minute > 59 || second > 59 {
        return None;
    }

    let mut offset_minutes: i64 = 0;
    if has_time && i < b.len() {
        if b[i] == b'Z' {
            i += 1;
        } else if b[i] == b'+' || b[i] == b'-' {
            let sign: i64 = if b[i] == b'-' { -1 } else { 1 };
            i += 1;
            let oh = take_digits(b, &mut i, 2)?;
            let om = if i < b.len() && b[i] == b':' {
                i += 1;
                take_digits(b, &mut i, 2)?
            } else if i + 2 <= b.len() && b[i].is_ascii_digit() {
                take_digits(b, &mut i, 2)?
            } else {
                0
            };
            if oh > 23 || om > 59 {
                return None;
            }
            offset_minutes = sign * (oh * 60 + om);
        } else {
            return None;
        }
    }
    if i != b.len() {
        return None;
    }

    let days = days_from_civil(year, month, day);
    let ms = days * 86_400_000 + (hour * 3_600_000 + minute * 60_000 + second * 1_000 + millis)
        - offset_minutes * 60_000;
    if ms.unsigned_abs() > 8_640_000_000_000_000 {
        return None; // outside the JS Date range
    }
    Some(ms as f64)
}

/// `os.homedir()`: `$HOME` on POSIX, with a passwd-database fallback via the
/// shell; `USERPROFILE` / `HOMEDRIVE`+`HOMEPATH` on Windows.
pub fn home_dir() -> PathBuf {
    #[cfg(unix)]
    {
        if let Some(h) = env::var_os("HOME").filter(|v| !v.is_empty()) {
            return PathBuf::from(h);
        }
        if let Ok(out) = std::process::Command::new("sh")
            .args(["-c", "printf %s ~"])
            .output()
        {
            if out.status.success() && !out.stdout.is_empty() {
                use std::os::unix::ffi::OsStringExt;
                return PathBuf::from(std::ffi::OsString::from_vec(out.stdout));
            }
        }
        PathBuf::from("/")
    }
    #[cfg(windows)]
    {
        if let Some(p) = env::var_os("USERPROFILE").filter(|v| !v.is_empty()) {
            return PathBuf::from(p);
        }
        let drive = env::var_os("HOMEDRIVE").unwrap_or_default();
        let path = env::var_os("HOMEPATH").unwrap_or_default();
        if !drive.is_empty() || !path.is_empty() {
            let mut p = drive;
            p.push(&path);
            return PathBuf::from(p);
        }
        PathBuf::from(".")
    }
}

/// Node `path.basename` (POSIX semantics on non-Windows).
pub fn js_basename(path: &str) -> String {
    #[cfg(windows)]
    {
        let trimmed = path.trim_end_matches(['/', '\\']);
        if trimmed.is_empty() {
            return String::new();
        }
        trimmed
            .rsplit(['/', '\\'])
            .next()
            .unwrap_or_default()
            .to_string()
    }
    #[cfg(not(windows))]
    {
        let trimmed = path.trim_end_matches('/');
        if trimmed.is_empty() {
            return String::new();
        }
        trimmed.rsplit('/').next().unwrap_or_default().to_string()
    }
}

/// Random hex token for temporary file names (replaces `randomUUID()`; the
/// name only needs uniqueness, it never survives the atomic rename).
pub fn random_token() -> String {
    use std::io::Read;
    let mut buf = [0u8; 16];
    if let Ok(mut f) = std::fs::File::open("/dev/urandom") {
        if f.read_exact(&mut buf).is_ok() {
            return buf.iter().map(|b| format!("{b:02x}")).collect();
        }
    }
    let nanos = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_nanos())
        .unwrap_or(0);
    format!("{nanos:032x}")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn iso_roundtrip() {
        assert_eq!(to_iso_string(0.0), "1970-01-01T00:00:00.000Z");
        assert_eq!(
            to_iso_string(1_735_689_600_123.0),
            "2025-01-01T00:00:00.123Z"
        );
        assert_eq!(parse_date("2025-01-01T00:00:00.123Z"), Some(1_735_689_600_123.0));
        assert_eq!(parse_date("1970-01-01"), Some(0.0));
        assert_eq!(parse_date("2025-01-01T02:00:00+02:00"), Some(1_735_689_600_000.0));
        assert_eq!(parse_date("2025-13-01"), None);
        assert_eq!(parse_date("not a date"), None);
        // Roundtrip through to_iso_string.
        let ms = parse_date("2030-06-15T12:34:56.789Z").unwrap();
        assert_eq!(to_iso_string(ms), "2030-06-15T12:34:56.789Z");
    }

    #[test]
    fn number_coercion() {
        assert_eq!(js_safe_integer_positive("42"), Some(42));
        assert_eq!(js_safe_integer_positive(" 7 "), Some(7));
        assert_eq!(js_safe_integer_positive(""), None); // Number('') === 0
        assert_eq!(js_safe_integer_positive("0"), None);
        assert_eq!(js_safe_integer_positive("-3"), None);
        assert_eq!(js_safe_integer_positive("1.5"), None);
        assert_eq!(js_safe_integer_positive("abc"), None);
        assert_eq!(js_safe_integer_positive("0x10"), Some(16));
        assert_eq!(js_safe_integer_positive("9007199254740992"), None);
    }

    #[test]
    fn basename() {
        assert_eq!(js_basename("/a/b/c.jsonl"), "c.jsonl");
        assert_eq!(js_basename("/a/b/"), "b");
        assert_eq!(js_basename(""), "");
        assert_eq!(js_basename("/"), "");
    }
}
