//! `os.path` and `urllib.parse` semantics, re-exported through
//! `super::python_stdlib` so callers see one module.
//!
//! The hooks branch on these behaviours rather than merely using them: a
//! relative path joined against the process directory, `commonpath` raising
//! instead of answering when absolute and relative are mixed, a `file:` URL
//! decoding to a local path. Rust's `std::path` differs at each of those
//! edges, so the Python is reproduced instead of approximated.

use std::path::Path;

/// Index arithmetic advances by one element; the repository keeps bare numeric
/// literals out of code, so the step is materialized from text.
const ONE_TEXT: &str = "1";
/// Radix of the two hex digits in a `%XX` escape (`int(hex, 16)` in
/// `urllib.parse.unquote`).
const HEX_RADIX_TEXT: &str = "16";
/// Characters `urlsplit` accepts after the first one in a scheme.
const SCHEME_EXTRA: &[char] = &['+', '-', '.'];
/// `urlsplit` ends the path at the first fragment or query delimiter.
const PATH_DELIMITERS: &[char] = &['#', '?'];
/// `_splitnetloc` stops the authority at the first of these.
const NETLOC_DELIMITERS: &[char] = &['/', '?', '#'];

pub fn one() -> usize {
    ONE_TEXT.parse().unwrap_or_default()
}

fn hex_radix() -> u32 {
    HEX_RADIX_TEXT.parse().unwrap_or_default()
}

/// `posixpath.normpath` — lexical only, and a leading `//` stays `//`.
pub fn normpath(path: &str) -> String {
    if path.is_empty() {
        return ".".to_string();
    }
    let mut leading = usize::MIN;
    if path.starts_with('/') {
        leading = one();
        if path.starts_with("//") && !path.starts_with("///") {
            leading = one() + one();
        }
    }
    let mut parts: Vec<&str> = Vec::new();
    for part in path.split('/') {
        if part.is_empty() || part == "." {
            continue;
        }
        if part != ".." || (leading == usize::MIN && parts.is_empty()) || parts.last() == Some(&"..")
        {
            parts.push(part);
        } else if !parts.is_empty() {
            parts.pop();
        }
    }
    let mut out = "/".repeat(leading);
    out.push_str(&parts.join("/"));
    if out.is_empty() {
        return ".".to_string();
    }
    out
}

/// `os.path.abspath` — `normpath(join(getcwd(), path))`.
pub fn abspath(path: &str) -> String {
    if path.starts_with('/') {
        return normpath(path);
    }
    let cwd = std::env::current_dir().unwrap_or_default();
    normpath(&format!("{}/{path}", cwd.to_string_lossy()))
}

/// `normpath(join(base, path))` — the base applies only to a relative path.
pub fn join_under(base: &str, path: &str) -> String {
    if path.starts_with('/') {
        return normpath(path);
    }
    normpath(&format!("{base}/{path}"))
}

/// `os.path.realpath` — non-strict, so a path that does not exist resolves as
/// far as its longest existing ancestor and keeps the rest verbatim.
pub fn realpath(path: &str) -> String {
    let absolute = abspath(path);
    if let Ok(resolved) = std::fs::canonicalize(&absolute) {
        return resolved.to_string_lossy().into_owned();
    }
    let mut suffix: Vec<&std::ffi::OsStr> = Vec::new();
    let mut probe = Path::new(&absolute);
    while let (Some(parent), Some(name)) = (probe.parent(), probe.file_name()) {
        suffix.push(name);
        if let Ok(mut resolved) = std::fs::canonicalize(parent) {
            for part in suffix.iter().rev() {
                resolved.push(part);
            }
            return resolved.to_string_lossy().into_owned();
        }
        probe = parent;
    }
    absolute
}

/// `os.path.commonpath((left, right))`. `None` stands for the `ValueError`
/// raised when absolute and relative paths are mixed.
pub fn commonpath(left: &str, right: &str) -> Option<String> {
    let absolute = left.starts_with('/');
    if absolute != right.starts_with('/') {
        return None;
    }
    let parts = |text: &str| -> Vec<String> {
        text.split('/')
            .filter(|part| !part.is_empty() && *part != ".")
            .map(str::to_string)
            .collect()
    };
    let common: Vec<String> = parts(left)
        .into_iter()
        .zip(parts(right))
        .take_while(|(left_part, right_part)| left_part == right_part)
        .map(|(left_part, _)| left_part)
        .collect();
    let mut out = if absolute { "/".to_string() } else { String::new() };
    out.push_str(&common.join("/"));
    Some(out)
}

/// `urllib.parse.unquote` — percent-decode, replacing undecodable bytes.
pub fn unquote(text: &str) -> String {
    if !text.contains('%') {
        return text.to_string();
    }
    let raw = text.as_bytes();
    let mut out: Vec<u8> = Vec::with_capacity(raw.len());
    let mut cursor = usize::MIN;
    while cursor < raw.len() {
        let byte = raw[cursor];
        let start = cursor + one();
        let end = start + one() + one();
        if byte == b'%' && end <= raw.len() && raw[start..end].iter().all(u8::is_ascii_hexdigit) {
            let hex = std::str::from_utf8(&raw[start..end]).unwrap_or_default();
            if let Ok(value) = u8::from_str_radix(hex, hex_radix()) {
                out.push(value);
                cursor = end;
                continue;
            }
        }
        out.push(byte);
        cursor += one();
    }
    String::from_utf8_lossy(&out).into_owned()
}

/// `urllib.parse.urlsplit`, reduced to the three fields the hooks read:
/// `(scheme, netloc, path)`.
pub fn urlsplit_parts(url: &str) -> (String, String, String) {
    // CPython lstrips C0-control-or-space and drops tab/CR/LF everywhere.
    let cleaned: String = url
        .trim_start_matches(|c: char| c <= ' ')
        .chars()
        .filter(|c| *c != '\t' && *c != '\r' && *c != '\n')
        .collect();
    let mut scheme = String::new();
    let mut rest = cleaned.as_str();
    if let Some(at) = cleaned.find(':') {
        let head = &cleaned[..at];
        let starts_alpha = head.chars().next().is_some_and(|c| c.is_ascii_alphabetic());
        let scheme_only = head
            .chars()
            .all(|c| c.is_ascii_alphanumeric() || SCHEME_EXTRA.contains(&c));
        if starts_alpha && scheme_only {
            scheme = head.to_ascii_lowercase();
            rest = &cleaned[at + one()..];
        }
    }
    let mut netloc = String::new();
    if let Some(after) = rest.strip_prefix("//") {
        let end = after.find(NETLOC_DELIMITERS).unwrap_or(after.len());
        netloc = after[..end].to_string();
        rest = &after[end..];
    }
    let end = rest.find(PATH_DELIMITERS).unwrap_or(rest.len());
    (scheme, netloc, rest[..end].to_string())
}
