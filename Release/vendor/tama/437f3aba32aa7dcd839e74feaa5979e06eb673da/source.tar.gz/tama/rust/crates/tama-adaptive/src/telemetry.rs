//! Port of `src/adaptive/telemetry.mjs`: adaptive telemetry façade over
//! immutable per-invocation segments. Observability failures never alter
//! hook enforcement.

use std::cell::RefCell;
use std::path::Path;

use crate::segments::index::SegmentWriter;
use crate::state::Warn;
use crate::util::now_ms;
use std::sync::Arc;

const CORPUS_PAYLOAD_CAP: usize = 65_536;

/// `reportLoss(text)` — best-effort stderr.
fn report_loss(text: &str) {
    use std::io::Write;
    let _ = writeln!(std::io::stderr(), "{}", text);
}

fn loss_warn() -> Warn {
    Arc::new(|text: &str| report_loss(text))
}

/// `storablePayload(payload)`. JS measures string length in UTF-16 code
/// units; mirrored here for the cap and the slice.
fn storable_payload(payload: &serde_json::Value) -> serde_json::Value {
    let text = serde_json::to_string(payload).unwrap_or_default();
    let units: Vec<u16> = text.encode_utf16().collect();
    if units.len() > CORPUS_PAYLOAD_CAP {
        let truncated = String::from_utf16_lossy(&units[..CORPUS_PAYLOAD_CAP]);
        serde_json::Value::String(truncated)
    } else {
        payload.clone()
    }
}

fn object(value: &serde_json::Value) -> serde_json::Map<String, serde_json::Value> {
    value.as_object().cloned().unwrap_or_default()
}

pub struct Telemetry {
    segment: RefCell<SegmentWriter>,
}

impl Telemetry {
    /// `safely(action)` — telemetry errors report a loss and return false.
    fn safely(&self, action: impl FnOnce(&mut SegmentWriter) -> bool) -> bool {
        let mut segment = self.segment.borrow_mut();
        let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| action(&mut segment)));
        match result {
            Ok(flag) => flag,
            Err(_) => {
                report_loss("adaptive telemetry loss: panic in telemetry action");
                false
            }
        }
    }

    /// `record(entry)`.
    pub fn record(&self, entry: &serde_json::Value) -> bool {
        let mut frame = object(entry);
        frame.insert("ts".to_string(), now_ms().into());
        frame.insert("type".to_string(), "decision".into());
        self.safely(|segment| segment.record(&serde_json::Value::Object(frame)))
    }

    /// `warn(text)`.
    pub fn warn(&self, text: &str) -> bool {
        let frame = serde_json::json!({ "ts": now_ms(), "text": text, "type": "warning" });
        self.safely(|segment| segment.record(&frame))
    }

    /// `corpusAdd(id, payload, meta)` — `id` is rendered with JS `String()`.
    pub fn corpus_add(
        &self,
        id: &serde_json::Value,
        payload: &serde_json::Value,
        meta: &serde_json::Value,
    ) -> bool {
        let mut frame = serde_json::Map::new();
        frame.insert("ts".to_string(), now_ms().into());
        frame.insert("id".to_string(), crate::util::js_string(id).into());
        frame.insert("label".to_string(), "unlabeled".into());
        frame.insert("payload".to_string(), storable_payload(payload));
        for (key, value) in object(meta) {
            frame.insert(key, value);
        }
        frame.insert("type".to_string(), "corpus_add".into());
        self.safely(|segment| segment.record(&serde_json::Value::Object(frame)))
    }

    /// `corpusLabel(id, label)` — a string label becomes `{ label }`, an
    /// object label is spread.
    pub fn corpus_label(&self, id: &serde_json::Value, label: &serde_json::Value) -> bool {
        let mut frame = serde_json::Map::new();
        frame.insert("ts".to_string(), now_ms().into());
        frame.insert("id".to_string(), crate::util::js_string(id).into());
        match label {
            serde_json::Value::String(text) => {
                frame.insert("label".to_string(), text.clone().into());
            }
            other => {
                for (key, value) in object(other) {
                    frame.insert(key, value);
                }
            }
        }
        frame.insert("type".to_string(), "corpus_label".into());
        self.safely(|segment| segment.record(&serde_json::Value::Object(frame)))
    }

    /// `frustration(value)`.
    pub fn frustration(&self, value: &serde_json::Value) -> bool {
        let mut frame = serde_json::Map::new();
        frame.insert("ts".to_string(), now_ms().into());
        for (key, entry) in object(value) {
            frame.insert(key, entry);
        }
        frame.insert("type".to_string(), "frustration".into());
        self.safely(|segment| segment.record(&serde_json::Value::Object(frame)))
    }

    /// `queueRepair(value)`.
    pub fn queue_repair(&self, value: &serde_json::Value) -> bool {
        let mut frame = serde_json::Map::new();
        frame.insert("ts".to_string(), now_ms().into());
        for (key, entry) in object(value) {
            frame.insert(key, entry);
        }
        frame.insert("type".to_string(), "repair_proposal".into());
        self.safely(|segment| segment.record(&serde_json::Value::Object(frame)))
    }

    pub fn close(&self) -> bool {
        self.segment.borrow_mut().close()
    }

    pub fn status(&self) -> serde_json::Value {
        self.segment.borrow().status()
    }

    pub fn reclaim_acked(&self) -> u64 {
        self.segment.borrow().reclaim_acked()
    }
}

/// `openTelemetry(stateDir)`.
pub fn open_telemetry(state_dir: &Path) -> Telemetry {
    Telemetry { segment: RefCell::new(SegmentWriter::create(state_dir, loss_warn())) }
}
