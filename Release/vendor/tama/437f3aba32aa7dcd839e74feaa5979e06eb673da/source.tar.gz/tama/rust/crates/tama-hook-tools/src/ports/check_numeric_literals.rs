//! Ports `shared-hooks/check_numeric_literals.py` (hook `block-numeric-literals`).
//!
//! A numeric literal in a code file is banned; in any other text or config file
//! it is banned too, so there is nowhere to relocate it. Numbers live only in
//! `numeric-provenance.json`, each one carrying a verbatim quote from a real
//! `role=user` transcript message that declares that value. The hook certifies
//! that the owner said the number — not that the number is correct.
//!
//! Tolerances, exactly as the Python draws them: strings and comments are
//! blanked in a code file first, so a number inside a quote or a comment is not
//! a literal; digits glued to an identifier (`Int64`, `sha256`) are not literals
//! either; the `TEXT_EXT` families are exempt outright; and a payload whose text
//! contains a NUL byte is skipped as binary.

use regex::Regex;
use serde_json::Value;
use tama_hooks::session_record::{deny_tool_use, read_payload};

use super::check_numeric_literals_payload as payload_shapes;
use super::check_numeric_literals_laundered as laundered;
use super::check_numeric_literals_provenance::{check_provenance, quote_in_user_msg};
use super::check_numeric_literals_scan as scan;
use super::{pystr, python_stdlib, pyvalue};

/// `PROV_RE` — the one file that holds numbers is validated, never scanned.
/// Python's `$` also matches before a single trailing newline, which Rust's
/// end-of-text `$` does not, so the allowance is spelled out.
const PROV_RE: &str = "(^|/)numeric-provenance\\.json\\n?\\z";

/// `WRITE_TOOLS` — a payload naming any other tool is not an edit.
const WRITE_TOOLS: &[&str] = &[
    "write",
    "create",
    "edit",
    "multiedit",
    "apply_patch",
    "functions.apply_patch",
    "applypatch",
];

const TOOL_KEYS: &[&str] = &["tool_name", "tool", "name"];
const INPUT_KEYS: &[&str] = &["tool_input", "input"];
/// A payload carrying a NUL is binary and is left alone.
const NUL: char = '\0';

const CODE_TAIL: &str = " in code -- numbers only in numeric-provenance.json with a user quote";
const OTHER_TAIL: &str = " -- numbers only in numeric-provenance.json (no relocation)";
const BANNER_HEAD: &str = "BLOCKED: numeric literal without a verbatim user-declared quote:";
const BANNER_JOIN: &str = "\n  ";

const VERIFY_FLAG: &str = "--verify-user-quote";
const VERIFY_FAILURE: &str = "verbatim quote not found in any real role=user transcript message";

/// `payload.get("tool_input") or payload.get("input") or {}`.
fn tool_input(payload: &Value) -> Value {
    for key in INPUT_KEYS {
        let Some(value) = payload.get(key) else { continue };
        if !pyvalue::truthy(value) {
            continue;
        }
        if !value.is_object() {
            payload_shapes::crash();
        }
        return value.clone();
    }
    Value::Object(Default::default())
}

/// `str(p.get("tool_name") or p.get("tool") or p.get("name") or "").lower()`.
fn tool_name(payload: &Value) -> String {
    pyvalue::first_truthy_py_str(payload, TOOL_KEYS).to_lowercase()
}

/// The line number is counted in the BLANKED text, so a literal after a
/// multi-line comment or string reports the line the blanking left it on. That
/// is the Python's arithmetic and its drift.
fn code_findings(text: &str, lang: &str) -> Vec<String> {
    let stripped = scan::strip_sc(text, lang);
    let step = python_stdlib::one();
    let mut findings: Vec<String> = scan::numeric_literals(&stripped)
        .into_iter()
        .map(|literal| {
            let line = stripped[..literal.start].matches('\n').count() + step;
            format!("line {line}: literal `{}`{CODE_TAIL}", literal.text)
        })
        .collect();
    // Blanking quoted text is what lets a number hide inside a string and come
    // back through `.parse()`. That spelling is the same magic number with one
    // extra step, so it is scanned on the UNBLANKED source.
    findings.extend(laundered::laundered_numbers(text).into_iter().map(|found| {
        format!(
            "line {}: number `{}` {}{CODE_TAIL}",
            found.line, found.value, found.form
        )
    }));
    findings
}

/// No stripping outside the code families: a bare config or data file is scanned
/// verbatim, comments and quoted text included.
fn other_findings(text: &str, path: &str) -> Vec<String> {
    scan::numeric_literals(text)
        .into_iter()
        .map(|literal| format!("literal `{}` in {path}{OTHER_TAIL}", literal.text))
        .collect()
}

fn check(payload: &Value) -> Vec<String> {
    let input = tool_input(payload);
    let provenance = Regex::new(PROV_RE).unwrap();
    let mut out = Vec::new();
    for (raw_path, text) in payload_shapes::path_texts(&input) {
        let Some(path) = payload_shapes::local_file_path(&raw_path) else { continue };
        if path.is_empty() || text.is_empty() {
            continue;
        }
        if provenance.is_match(&path) {
            out.extend(check_provenance(&text));
            continue;
        }
        if text.contains(NUL) {
            continue;
        }
        match scan::lang_for(&path) {
            Some(lang) => out.extend(code_findings(&text, &lang)),
            None => {
                if scan::TEXT_EXT.iter().any(|ext| path.ends_with(ext)) {
                    continue;
                }
                out.extend(other_findings(&text, &path));
            }
        }
    }
    out
}

/// `--verify-user-quote`: the transcript check on its own, for anything that
/// wants to confirm a quote before writing it into the provenance file.
fn verify_user_quote() -> ! {
    let mut raw = String::new();
    let read = std::io::Read::read_to_string(&mut std::io::stdin(), &mut raw);
    let quote = if read.is_ok() { pystr::strip(&raw).to_string() } else { String::new() };
    if !quote.is_empty() && quote_in_user_msg(&quote) {
        std::process::exit(i32::default());
    }
    deny_tool_use(VERIFY_FAILURE)
}

pub fn run() {
    let args: Vec<String> = std::env::args().skip(python_stdlib::one()).collect();
    if args == [VERIFY_FLAG] {
        verify_user_quote();
    }
    let payload = read_payload();
    if !payload.is_object() {
        payload_shapes::crash();
    }
    let named = payload.get("tool_name").filter(|value| !value.is_null()).is_some();
    if named && !WRITE_TOOLS.contains(&tool_name(&payload).as_str()) {
        return;
    }
    let violations = check(&payload);
    if violations.is_empty() {
        return;
    }
    let listed = violations.join(BANNER_JOIN);
    deny_tool_use(&format!("{BANNER_HEAD}{BANNER_JOIN}{listed}"));
}
