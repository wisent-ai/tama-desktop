//! Port of `src/adaptive/segments/index.mjs`: durable immutable telemetry
//! segments (open -> ready -> acked) with integrity footers.

use sha2::{Digest, Sha256};
use std::fs::{self, File, OpenOptions};
use std::io::Write;
use std::path::{Path, PathBuf};

use crate::state::journal::sync_directory;
use crate::state::Warn;
use crate::util::{now_ms, uuid_v4};

pub const PROTOCOL: &str = "hooks-telemetry-segment-v1";
pub const ACK_PROTOCOL: &str = "hooks-telemetry-ack-v1";
const LEGACY_NAMES: [&str; 3] = ["telemetry.prev.jsonl", "telemetry.jsonl", "repair-queue.jsonl"];

fn digest_bytes(value: &[u8]) -> String {
    format!("{:x}", Sha256::digest(value))
}

fn line(value: &serde_json::Value) -> String {
    format!("{}\n", serde_json::to_string(value).unwrap_or_default())
}

pub fn segment_name(id: &str) -> String {
    format!("segment-{}.jsonl", id)
}

fn ack_name(id: &str) -> String {
    format!("segment-{}.ack.json", id)
}

fn write_all(descriptor: &mut File, text: &str) -> std::io::Result<()> {
    descriptor.write_all(text.as_bytes())
}

fn safe_names(path: &Path) -> Vec<String> {
    match fs::read_dir(path) {
        Ok(entries) => entries
            .flatten()
            .map(|entry| entry.file_name().to_string_lossy().to_string())
            .collect(),
        Err(_) => Vec::new(),
    }
}

fn parse_object(text: &str) -> Option<serde_json::Value> {
    let value = serde_json::from_str::<serde_json::Value>(text).ok()?;
    if value.is_object() {
        Some(value)
    } else {
        None
    }
}

fn is_hex_64(text: &str) -> bool {
    text.len() == 64 && text.bytes().all(|b| b.is_ascii_hexdigit() && !b.is_ascii_uppercase())
}

/// A validated ready segment (`validateSegment`).
pub struct ValidSegment {
    pub segment_id: String,
    pub event_count: usize,
    pub payload_sha256: String,
    pub source_sha256: String,
    pub source_size: usize,
    pub events: Vec<serde_json::Value>,
}

fn get_str<'a>(value: &'a serde_json::Value, key: &str) -> Option<&'a str> {
    value.get(key).and_then(|v| v.as_str())
}

fn is_number(value: &serde_json::Value) -> bool {
    value.is_number()
}

/// `validateSegment(path)` — header/footer/shape checks, payload sha.
pub fn validate_segment(path: &Path) -> Option<ValidSegment> {
    let source = fs::read_to_string(path).ok()?;
    if !source.ends_with('\n') {
        return None;
    }
    let rows: Vec<&str> = source[..source.len() - 1].split('\n').collect();
    if rows.len() < 2 {
        return None;
    }
    let header = parse_object(rows[0])?;
    let footer = parse_object(rows[rows.len() - 1])?;
    if get_str(&header, "kind") != Some("segment_open")
        || get_str(&header, "protocol") != Some(PROTOCOL)
    {
        return None;
    }
    let segment_id = get_str(&header, "segmentId")?.to_string();
    if segment_id.is_empty() {
        return None;
    }
    let base = path.file_name()?.to_string_lossy();
    if base != segment_name(&segment_id) {
        return None;
    }
    let producer_id = get_str(&header, "producerId")?;
    let invocation_id = get_str(&header, "invocationId")?;
    if producer_id.is_empty() || invocation_id.is_empty() {
        return None;
    }
    if !header.get("createdAt").map(is_number).unwrap_or(false) {
        return None;
    }
    let source_field = header.get("source")?;
    if source_field.is_null() || get_str(source_field, "producer") != Some("tama") {
        return None;
    }
    let mut events = Vec::new();
    for row in &rows[1..rows.len() - 1] {
        let frame = parse_object(row)?;
        if get_str(&frame, "kind") != Some("event") {
            return None;
        }
        if frame.get("sequence").and_then(|v| v.as_i64()) != Some(events.len() as i64) {
            return None;
        }
        let event = frame.get("event")?;
        if !event.is_object() {
            return None;
        }
        events.push(event.clone());
    }
    let payload = format!("{}\n", rows[..rows.len() - 1].join("\n"));
    let payload_sha256 = digest_bytes(payload.as_bytes());
    if get_str(&footer, "kind") != Some("segment_close")
        || get_str(&footer, "protocol") != Some(PROTOCOL)
        || get_str(&footer, "segmentId") != Some(segment_id.as_str())
    {
        return None;
    }
    if footer.get("eventCount").and_then(|v| v.as_i64()) != Some(events.len() as i64) {
        return None;
    }
    if get_str(&footer, "payloadSha256") != Some(payload_sha256.as_str()) {
        return None;
    }
    if !footer.get("closedAt").map(is_number).unwrap_or(false) {
        return None;
    }
    Some(ValidSegment {
        segment_id,
        event_count: events.len(),
        payload_sha256,
        source_sha256: digest_bytes(source.as_bytes()),
        source_size: source.len(),
        events,
    })
}

/// `validateAck(path, segment)`.
fn validate_ack(path: &Path, segment: &ValidSegment) -> Option<serde_json::Value> {
    let ack = parse_object(&fs::read_to_string(path).ok()?)?;
    let base = path.file_name()?.to_string_lossy();
    if base != ack_name(&segment.segment_id) {
        return None;
    }
    if get_str(&ack, "protocol") != Some(ACK_PROTOCOL)
        || get_str(&ack, "segmentId") != Some(segment.segment_id.as_str())
    {
        return None;
    }
    if get_str(&ack, "sourceSha256") != Some(segment.source_sha256.as_str()) {
        return None;
    }
    if ack.get("sourceSize").and_then(|v| v.as_i64()) != Some(segment.source_size as i64) {
        return None;
    }
    if ack.get("eventCount").and_then(|v| v.as_i64()) != Some(segment.event_count as i64)
        || get_str(&ack, "payloadSha256") != Some(segment.payload_sha256.as_str())
    {
        return None;
    }
    let lake_commit_id = get_str(&ack, "lakeCommitId")?;
    if lake_commit_id.is_empty() {
        return None;
    }
    let outputs = ack.get("outputs")?.as_array()?;
    if outputs.is_empty() {
        return None;
    }
    let outputs_valid = outputs.iter().all(|item| {
        let Some(item_path) = get_str(item, "path") else { return false };
        if item_path.is_empty() {
            return false;
        }
        let Some(item_sha) = get_str(item, "sha256") else { return false };
        if !is_hex_64(item_sha) {
            return false;
        }
        let Ok(meta) = fs::symlink_metadata(item_path) else { return false };
        if !meta.is_file() || meta.file_type().is_symlink() {
            return false;
        }
        match fs::read(item_path) {
            Ok(bytes) => digest_bytes(&bytes) == item_sha,
            Err(_) => false,
        }
    });
    if !outputs_valid {
        return None;
    }
    Some(ack)
}

/// `decisionsPersisted(segment)`.
fn decisions_persisted(segment: &ValidSegment) -> bool {
    segment.events.iter().all(|event| {
        get_str(event, "type") != Some("decision")
            || event.get("adaptiveStatePersisted").and_then(|v| v.as_bool()) == Some(true)
    })
}

struct ReadyItem {
    path: PathBuf,
    ack_path: PathBuf,
    reclaimable: bool,
}

/// `createSegmentWriter(stateDir, warn)`.
pub struct SegmentWriter {
    state_dir: PathBuf,
    open_dir: PathBuf,
    ready_dir: PathBuf,
    acked_dir: PathBuf,
    invocation_id: String,
    producer_id: String,
    descriptor: Option<File>,
    open_path: PathBuf,
    ready_path: PathBuf,
    segment_id: String,
    payload_hash: Sha256,
    event_count: u64,
    closed: bool,
    failed: bool,
    warn: Warn,
}

impl SegmentWriter {
    pub fn create(state_dir: &Path, warn: Warn) -> Self {
        let root = state_dir.join("telemetry-segments");
        SegmentWriter {
            state_dir: state_dir.to_path_buf(),
            open_dir: root.join("open"),
            ready_dir: root.join("ready"),
            acked_dir: root.join("acked"),
            invocation_id: uuid_v4(),
            producer_id: format!("tama:{}", std::process::id()),
            descriptor: None,
            open_path: PathBuf::new(),
            ready_path: PathBuf::new(),
            segment_id: String::new(),
            payload_hash: Sha256::new(),
            event_count: 0,
            closed: false,
            failed: false,
            warn,
        }
    }

    fn report(&self, error: &str) {
        (self.warn)(&format!("adaptive telemetry loss: {}", error));
    }

    fn ensure_open(&mut self) -> std::io::Result<()> {
        fs::create_dir_all(&self.open_dir)?;
        fs::create_dir_all(&self.ready_dir)?;
        fs::create_dir_all(&self.acked_dir)?;
        self.segment_id = uuid_v4();
        self.open_path = self.open_dir.join(format!("{}.open", segment_name(&self.segment_id)));
        self.ready_path = self.ready_dir.join(segment_name(&self.segment_id));
        let mut descriptor =
            OpenOptions::new().write(true).create_new(true).open(&self.open_path)?;
        self.payload_hash = Sha256::new();
        let header = line(&serde_json::json!({
            "kind": "segment_open",
            "protocol": PROTOCOL,
            "segmentId": self.segment_id,
            "producerId": self.producer_id,
            "invocationId": self.invocation_id,
            "createdAt": now_ms(),
            "source": { "producer": "tama" },
        }));
        write_all(&mut descriptor, &header)?;
        self.payload_hash.update(header.as_bytes());
        self.descriptor = Some(descriptor);
        Ok(())
    }

    fn abandon(&mut self) {
        if let Some(descriptor) = self.descriptor.take() {
            drop(descriptor);
        }
        self.failed = true;
    }

    fn inspect_ready(&self, name: &str) -> Option<ReadyItem> {
        if !name.ends_with(".jsonl") {
            return None;
        }
        let path = self.ready_dir.join(name);
        let segment = validate_segment(&path)?;
        let ack_path = self.acked_dir.join(ack_name(&segment.segment_id));
        let ack = validate_ack(&ack_path, &segment);
        Some(ReadyItem {
            path,
            ack_path,
            reclaimable: ack.is_some() && decisions_persisted(&segment),
        })
    }

    /// `reclaimAcked()` — first error reports and aborts the sweep, like the
    /// single JS try/catch around the loop.
    pub fn reclaim_acked(&self) -> u64 {
        let mut reclaimed = 0u64;
        let result: std::io::Result<()> = (|| {
            for name in safe_names(&self.ready_dir) {
                let Some(item) = self.inspect_ready(&name) else { continue };
                if !item.reclaimable {
                    continue;
                }
                fs::remove_file(&item.path)?;
                sync_directory(&self.ready_dir);
                fs::remove_file(&item.ack_path)?;
                sync_directory(&self.acked_dir);
                reclaimed += 1;
            }
            Ok(())
        })();
        if let Err(error) = result {
            self.report(&error.to_string());
        }
        reclaimed
    }

    fn append(&mut self, event: &serde_json::Value, retried: bool) -> bool {
        let attempt = |writer: &mut SegmentWriter| -> std::io::Result<()> {
            if writer.descriptor.is_none() {
                writer.ensure_open()?;
            }
            let frame = line(&serde_json::json!({
                "kind": "event",
                "sequence": writer.event_count,
                "event": event,
            }));
            let descriptor = writer.descriptor.as_mut().expect("descriptor opened above");
            write_all(descriptor, &frame)?;
            writer.payload_hash.update(frame.as_bytes());
            writer.event_count += 1;
            Ok(())
        };
        match attempt(self) {
            Ok(()) => true,
            Err(error) => {
                self.abandon();
                // ENOSPC (28) / EDQUOT (69) trigger a one-time reclaim retry.
                if !retried && matches!(error.raw_os_error(), Some(28) | Some(69)) {
                    self.reclaim_acked();
                    self.failed = false;
                    return self.append(event, true);
                }
                self.report(&error.to_string());
                false
            }
        }
    }

    /// `record(event)`.
    pub fn record(&mut self, event: &serde_json::Value) -> bool {
        if self.closed || self.failed || !event.is_object() {
            return false;
        }
        self.append(event, false)
    }

    /// `close()`.
    pub fn close(&mut self) -> bool {
        if self.closed {
            return false;
        }
        self.closed = true;
        if self.descriptor.is_none() || self.failed {
            return false;
        }
        let attempt = |writer: &mut SegmentWriter| -> std::io::Result<()> {
            let digest = writer.payload_hash.clone().finalize();
            let footer = line(&serde_json::json!({
                "kind": "segment_close",
                "protocol": PROTOCOL,
                "segmentId": writer.segment_id,
                "eventCount": writer.event_count,
                "payloadSha256": format!("{:x}", digest),
                "closedAt": now_ms(),
            }));
            let mut descriptor = writer.descriptor.take().expect("checked above");
            write_all(&mut descriptor, &footer)?;
            descriptor.sync_all()?;
            drop(descriptor);
            fs::rename(&writer.open_path, &writer.ready_path)?;
            sync_directory(&writer.ready_dir);
            Ok(())
        };
        match attempt(self) {
            Ok(()) => true,
            Err(error) => {
                self.abandon();
                self.report(&error.to_string());
                false
            }
        }
    }

    /// `status()`.
    pub fn status(&self) -> serde_json::Value {
        let open = safe_names(&self.open_dir)
            .iter()
            .filter(|name| name.ends_with(".jsonl.open"))
            .count();
        let ready_names: Vec<String> = safe_names(&self.ready_dir)
            .into_iter()
            .filter(|name| name.ends_with(".jsonl"))
            .collect();
        let acked = safe_names(&self.acked_dir)
            .iter()
            .filter(|name| name.ends_with(".ack.json"))
            .count();
        let mut valid_ready = 0u64;
        let mut reclaimable = 0u64;
        for name in &ready_names {
            if let Some(item) = self.inspect_ready(name) {
                valid_ready += 1;
                if item.reclaimable {
                    reclaimable += 1;
                }
            }
        }
        let mut legacy = Vec::new();
        for name in LEGACY_NAMES {
            if let Ok(meta) = fs::metadata(self.state_dir.join(name)) {
                legacy.push(serde_json::json!({ "name": name, "size": meta.len() }));
            }
        }
        serde_json::json!({
            "open": open,
            "ready": ready_names.len(),
            "acked": acked,
            "validReady": valid_ready,
            "reclaimable": reclaimable,
            "legacy": legacy,
        })
    }
}
