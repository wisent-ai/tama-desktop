//! Port of `src/adaptive/doctor/`: evidence projection, repair pipeline,
//! install shim management, and the doctor CLI.

pub mod cli;
pub mod evidence;
pub mod install;
pub mod repair;
