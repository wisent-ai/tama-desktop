//! tama-testkit: Rust port of src/tests/ harnesses.
//!
//! This crate ports the live-runtime test harness
//! (`src/tests/require-live-runtime.mjs` and all of
//! `src/tests/live-runtime/`): scenario data, runtime runners (omp / claude /
//! codex / git / editor) and the orchestration/reporting logic. External
//! agent processes (claude, codex, omp, node watchers) are still spawned as
//! child processes, exactly like the JS harness does.
//!
//! Fidelity notes:
//! - All harness output goes to stderr (`console.error`), pretty-printed with
//!   `JSON.stringify(..., null, 2)` semantics ([`json::Json::to_pretty2`]);
//!   object key order follows the JS sources.
//! - Thrown JS errors become `Err(String)`; `attempt` wraps them into
//!   `{ ok: false, name, error }` results, an uncaught throw at module level
//!   becomes exit code 1 with the message on stderr (sans stack trace).
//! - `spawnSync` timeouts kill the child with SIGTERM like Node; `maxBuffer`
//!   overflow is truncated after the fact instead of killing the child early
//!   (observably identical for outputs under the limit).

pub mod claude;
pub mod codex;
pub mod editor;
pub mod git_codex;
pub mod json;
pub mod omp;
pub mod orchestration;
pub mod scenarios;
pub mod support;
