//! Python standard-library semantics the ported hooks are measured against.
//!
//! `shlex.split` and the `os.path`/`urllib.parse` helpers are load-bearing in
//! the hooks under `shared-hooks/` and `codex-hooks/`: the guards branch on
//! their failure modes — an unbalanced quote falling back to a whitespace
//! split, a relative path joined against the process directory, `commonpath`
//! raising instead of answering — so the ports reproduce those behaviours
//! rather than approximating with Rust equivalents that differ at the edges.
//! Python *value* semantics (truthiness, `str`, `json.dumps`) live in the
//! `pyvalue` sibling, and string primitives in `pystr`.
//!
//! The `os.path` and `urllib.parse` half lives in the `_path` sibling to stay
//! inside the repository's file-length limit; it is re-exported here so callers
//! only ever name this module.

pub use super::python_stdlib_path::*;

/// `shlex.whitespace` in POSIX mode.
const SHLEX_WHITESPACE: &[char] = &[' ', '\t', '\r', '\n'];

/// `shlex.split(text)` in POSIX mode. `None` stands for the `ValueError` the
/// Python raises on an unterminated quote or a trailing escape.
pub fn shlex_split(text: &str) -> Option<Vec<String>> {
    let mut tokens: Vec<String> = Vec::new();
    let mut token = String::new();
    // Python emits an empty token for `''`, so "a token exists" is not the same
    // question as "the token has characters".
    let mut started = false;
    let mut quote: Option<char> = None;
    let mut escaped_from: Option<Option<char>> = None;
    for ch in text.chars() {
        if let Some(previous) = escaped_from.take() {
            // Inside double quotes a backslash only escapes itself and the
            // quote; before anything else it stays in the token.
            if let Some(active) = previous {
                if ch != '\\' && ch != active {
                    token.push('\\');
                }
            }
            token.push(ch);
            quote = previous;
            started = true;
            continue;
        }
        match quote {
            Some(active) if ch == active => quote = None,
            Some('"') if ch == '\\' => escaped_from = Some(Some('"')),
            Some(_) => token.push(ch),
            None if ch == '\\' => escaped_from = Some(None),
            None if ch == '\'' || ch == '"' => {
                quote = Some(ch);
                started = true;
            }
            None if SHLEX_WHITESPACE.contains(&ch) => {
                if started {
                    tokens.push(std::mem::take(&mut token));
                    started = false;
                }
            }
            None => {
                token.push(ch);
                started = true;
            }
        }
    }
    if quote.is_some() || escaped_from.is_some() {
        return None;
    }
    if started {
        tokens.push(token);
    }
    Some(tokens)
}

/// The `try: shlex.split(...) except ValueError: ....split()` pair the hooks
/// spell out identically in three places.
pub fn shell_tokens(command: &str) -> Vec<String> {
    match shlex_split(command) {
        Some(tokens) => tokens,
        None => command.split_whitespace().map(str::to_string).collect(),
    }
}

/// `os.path.expandvars` — `$NAME` and `${NAME}`; an unset name is left verbatim.
pub fn expandvars(path: &str) -> String {
    if !path.contains('$') {
        return path.to_string();
    }
    let mut out = String::new();
    let mut rest = path;
    loop {
        let Some(at) = rest.find('$') else {
            out.push_str(rest);
            return out;
        };
        let (head, tail) = rest.split_at(at);
        out.push_str(head);
        let after = &tail[one()..];
        let (name, consumed) = match after.strip_prefix('{') {
            // `${` without a closing brace is not a match at all.
            Some(inner) => match inner.find('}') {
                Some(end) => (&inner[..end], one() + end + one()),
                None => ("", usize::MIN),
            },
            None => {
                let end = after
                    .find(|c: char| !(c.is_alphanumeric() || c == '_'))
                    .unwrap_or(after.len());
                (&after[..end], end)
            }
        };
        if name.is_empty() {
            out.push('$');
            rest = after;
            continue;
        }
        match std::env::var(name) {
            Ok(value) => out.push_str(&value),
            Err(_) => {
                out.push('$');
                out.push_str(&after[..consumed]);
            }
        }
        rest = &after[consumed..];
    }
}

/// `os.path.expanduser`. A `~user` prefix needs the password database, which
/// std cannot read; Python returns the path unchanged when that lookup fails,
/// so that is the branch taken here.
pub fn expanduser(path: &str) -> String {
    let Some(rest) = path.strip_prefix('~') else {
        return path.to_string();
    };
    let split = rest.find('/').unwrap_or(rest.len());
    if split > usize::MIN {
        return path.to_string();
    }
    let home = std::env::var("HOME").unwrap_or_default();
    let joined = format!("{}{rest}", home.trim_end_matches('/'));
    if joined.is_empty() {
        return "/".to_string();
    }
    joined
}
