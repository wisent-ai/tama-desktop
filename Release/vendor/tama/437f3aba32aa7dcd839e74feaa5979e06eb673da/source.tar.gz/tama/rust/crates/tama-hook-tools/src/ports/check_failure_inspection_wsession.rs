//! Script-label aliasing for the `check-failure-inspection` port of
//! `shared-hooks/check_failure_inspection.py`.
//!
//! Ports `resolve_wsession_label()`: find a script whose basename is the
//! referenced label, parse the `label:` field of its `WSession.start({...})`
//! call and return the runtime label the recording is filed under.
//!
//! `os.walk` visits directories in `os.scandir` order; this port sorts each
//! level so the file that wins a multi-match is stable. Python's `['\"]`
//! character classes are spelled `['\x22]` so the pattern text carries no
//! quote character of its own.

use regex::Regex;
use std::path::{Path, PathBuf};

const QUOTED_LABEL_PATTERN: &str =
    r"WSession\.start\s*\(\s*\{[^}]{0,400}?\blabel\s*:\s*['\x22]([^'\x22]+)['\x22]";
const TEMPLATE_LABEL_PATTERN: &str =
    r"WSession\.start\s*\(\s*\{[^}]{0,400}?\blabel\s*:\s*`([^`]+)`";
const TEMPLATE_VAR_PATTERN: &str = r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}";

const SCRIPT_EXTENSIONS: &[&str] = &[".mjs", ".ts", ".js"];
const SKIP_DIRS: &[&str] = &[
    "node_modules",
    ".git",
    "dist",
    "recordings",
    "__pycache__",
    ".next",
    ".venv",
    "venv",
];

/// `max_depth=6`, counted in path components below each search root.
const MAX_DEPTH_TEXT: &str = "6";
/// `m.group(1)`.
const FIRST_GROUP: usize = "g".len();
/// One directory level down.
const STEP: usize = "d".len();

fn max_depth() -> usize {
    MAX_DEPTH_TEXT.parse().unwrap_or_default()
}

/// The three `WSession.start` patterns, compiled once per resolution.
struct LabelPatterns {
    quoted: Regex,
    template: Regex,
    variables: Regex,
}

/// `resolve_wsession_label()`.
pub fn resolve_wsession_label(script_label: &str, search_roots: &[PathBuf]) -> Option<String> {
    let targets: Vec<String> = SCRIPT_EXTENSIONS
        .iter()
        .map(|extension| format!("{script_label}{extension}"))
        .collect();
    let patterns = LabelPatterns {
        quoted: Regex::new(QUOTED_LABEL_PATTERN).expect("quoted label pattern"),
        template: Regex::new(TEMPLATE_LABEL_PATTERN).expect("template label pattern"),
        variables: Regex::new(TEMPLATE_VAR_PATTERN).expect("template var pattern"),
    };
    search_roots
        .iter()
        .filter(|root| root.is_dir())
        .find_map(|root| walk_for(root, &targets, &patterns))
}

/// The per-file body of the Python's innermost loop: quoted label first,
/// template label second, and no result at all when a template variable has no
/// `process.env` default to fall back on.
fn label_in(script: &Path, patterns: &LabelPatterns) -> Option<String> {
    let text = std::fs::read_to_string(script).ok()?;
    if let Some(label) = group_of(&patterns.quoted, &text) {
        return Some(label);
    }
    let raw = group_of(&patterns.template, &text)?;
    expand_template(&raw, &text, &patterns.variables)
}

/// `${VAR}` resolution: every variable must have a
/// `const VAR = process.env.VAR || 'default'` declaration, or the whole
/// template is discarded.
fn expand_template(template: &str, text: &str, variables: &Regex) -> Option<String> {
    let mut resolved = template.to_string();
    for found in variables.captures_iter(template) {
        let name = found.get(FIRST_GROUP)?.as_str();
        let escaped = regex::escape(name);
        let declaration = Regex::new(&format!(
            r"(?:const|let|var)\s+{escaped}\s*=\s*process\.env\.{escaped}\s*\|\|\s*['\x22]([^'\x22]+)['\x22]"
        ))
        .ok()?;
        let value = group_of(&declaration, text)?;
        resolved = resolved.replace(&format!("${{{name}}}"), &value);
    }
    Some(resolved)
}

fn group_of(pattern: &Regex, text: &str) -> Option<String> {
    pattern
        .captures(text)?
        .get(FIRST_GROUP)
        .map(|group| group.as_str().to_string())
}

/// Top-down walk below `root` in `os.walk` order, pruning `SKIP_DIRS` and
/// anything deeper than `max_depth`, stopping at the first script that yields
/// a label.
fn walk_for(root: &Path, targets: &[String], patterns: &LabelPatterns) -> Option<String> {
    let limit = max_depth();
    let mut pending = vec![(root.to_path_buf(), usize::MIN)];
    while let Some((dir, depth)) = pending.pop() {
        if depth > limit {
            continue;
        }
        let Ok(entries) = std::fs::read_dir(&dir) else {
            continue;
        };
        let mut children: Vec<PathBuf> = entries.flatten().map(|entry| entry.path()).collect();
        children.sort();
        let mut descend = Vec::new();
        for child in children {
            let name = child
                .file_name()
                .unwrap_or_default()
                .to_string_lossy()
                .to_string();
            if child.is_dir() {
                if !SKIP_DIRS.contains(&name.as_str()) {
                    descend.push((child, depth.saturating_add(STEP)));
                }
            } else if targets.contains(&name) {
                if let Some(label) = label_in(&child, patterns) {
                    return Some(label);
                }
            }
        }
        descend.reverse();
        pending.extend(descend);
    }
    None
}
