//! Marker tables and text predicates for `check_legacy_activation_bypass`.
//!
//! Every detector string is assembled from fragments with `concat!`, exactly as
//! the Python source splits its own literals: this hook scans the content of
//! the file being written, so a contiguous copy of a banned string here would
//! make the live hook block every edit to its own port.

use std::path::PathBuf;

pub const WISENT_ROOT: &str = "/Users/lukaszbartoszcze/Documents/CodingProjects/Wisent";

pub const BANNED_STRINGS: &[&str] = &[
    concat!("wisent.scripts.activations.", "extract_and_upload"),
    concat!("wisent/scripts/activations/", "extract_and_upload.py"),
    concat!("wisent-tools/wisent/scripts/activations/", "extract_and_upload.py"),
    concat!("unset ", "WISENT_FLEET_STAGING_DIR"),
    concat!("export ", "WISENT_FLEET_STAGING_DIR="),
    concat!("WISENT_FLEET_STAGING_DIR=", "\"\""),
    concat!("WISENT_FLEET_STAGING_DIR=", "''"),
];

pub const DIRECT_HF_UPLOAD_MARKERS: &[&str] = &[
    concat!("from huggingface_hub import ", "upload_file"),
    concat!("from huggingface_hub import ", "upload_folder"),
    concat!("upload_file", "("),
    concat!("upload_folder", "("),
    concat!("huggingface-cli ", "upload"),
    concat!("hf ", "upload"),
    concat!("wisent.scripts.activations.migrate_stable_ids", " import"),
    concat!("_flush_batch", "("),
    concat!("_stage_shard", "("),
];

pub const DETACHED_UPLOAD_ALLOWLIST_PATH_FRAGMENTS: &[&str] =
    &["/wisent-tools/wisent/scripts/activations/raw/upload_worker.py"];

pub const ACTIVATION_PATH_FRAGMENTS: &[&str] = &[
    "/wisent-tools/wisent/scripts/activations/",
    "/backends/.work/raw_activation_scope/",
];

/// The two text gates that arm the foreground-upload detector.
pub const ACTIVATION_TEXT_GATES: &[&str] =
    &[concat!("wisent.scripts.", "activations"), "raw_activations/"];

pub const DIRECT_QUEUE_MARKERS: &[&str] = &[
    concat!("gs://wisent-compute/", "queue/"),
    concat!("bucket.blob(", "\"queue/"),
    concat!("bucket.blob(f", "\"queue/"),
    concat!("bucket.blob(", "'queue/"),
    concat!("bucket.blob(f", "'queue/"),
    concat!("write_job(", "\"queue\""),
    concat!("write_job(", "'queue'"),
];

pub const QUEUE_ALLOWLIST_PATH_FRAGMENTS: &[&str] = &[
    "/wisent-compute/wisent_compute/queue/submit.py",
    "/wisent-compute/wisent_compute/queue/storage.py",
    "/wisent-compute/wisent_compute/queue/listing/",
    "/wisent-compute/wisent_compute/scheduler/",
    "/wisent-compute/wisent_compute/sizing/",
];

const TREE_SCAN_RELATIVE_PATHS: &[&str] = &[
    "wisent-compute/wisent_compute/models.py",
    "wisent-compute/wisent_compute/queue/submit.py",
    "wisent-compute/wisent_compute/providers/local/slots.py",
    concat!("wisent-tools/wisent/scripts/activations/", "extract_and_upload.py"),
    "wisent-tools/wisent/scripts/activations/raw/extract_and_upload.py",
    "wisent-tools/wisent/scripts/activations/raw/upload_worker.py",
    "backends/.work/raw_activation_scope/scripts/submit_desired_activation_jobs.py",
    "backends/.work/raw_activation_scope/scripts/patch_queued_desired_commands_upgrade.py",
    "backends/.work/raw_activation_scope/scripts/diagnostics/submit_single_activation_repair.py",
];

const TREE_SCAN_RELATIVE_DIRS: &[&str] = &[
    "backends/.work/raw_activation_scope/scripts",
    "wisent-compute/wisent_compute",
    "wisent-tools/wisent",
];

/// `Path.suffix` values, dot included.
pub const SCAN_SUFFIXES: &[&str] = &[".py", ".sh", ".json", ".toml", ".yaml", ".yml"];

const LEGACY_STUB_DIR: &str = "wisent-tools/wisent/scripts/activations";
const LEGACY_STUB_FILE: &str = "extract_and_upload.py";

pub const LEGACY_STUB_REQUIRED: &[&str] = &[
    "Disabled compatibility stub",
    "foreground activation uploader has been removed",
    "return 64",
];

pub const LEGACY_STUB_FORBIDDEN: &[&str] = &[
    "huggingface_hub",
    "HfApi",
    "upload_folder",
    "upload_file",
    "generate-pairs",
    "extract-activations",
];

pub const SHELL_TOOLS: &[&str] = &["Bash", "exec_command", "functions.exec_command"];

pub const EDIT_TOOLS: &[&str] = &[
    "Write",
    "Edit",
    "apply_patch",
    "NotebookEdit",
    "functions.apply_patch",
];

pub const READ_ONLY_SHELL_PROGRAMS: &[&str] = &[
    "rg", "grep", "sed", "awk", "cat", "nl", "less", "tail", "head", "find", "git",
];

pub fn legacy_stub_path() -> PathBuf {
    PathBuf::from(WISENT_ROOT)
        .join(LEGACY_STUB_DIR)
        .join(LEGACY_STUB_FILE)
}

pub fn tree_scan_paths() -> Vec<PathBuf> {
    TREE_SCAN_RELATIVE_PATHS
        .iter()
        .map(|relative| PathBuf::from(WISENT_ROOT).join(relative))
        .collect()
}

pub fn tree_scan_dirs() -> Vec<PathBuf> {
    TREE_SCAN_RELATIVE_DIRS
        .iter()
        .map(|relative| PathBuf::from(WISENT_ROOT).join(relative))
        .collect()
}

fn hits(table: &[&str], text: &str) -> Vec<String> {
    table
        .iter()
        .filter(|marker| text.contains(**marker))
        .map(|marker| marker.to_string())
        .collect()
}

pub fn blocks_in_text(text: &str) -> Vec<String> {
    hits(BANNED_STRINGS, text)
}

pub fn direct_hf_upload_blocks_in_text(text: &str, label: &str) -> Vec<String> {
    if DETACHED_UPLOAD_ALLOWLIST_PATH_FRAGMENTS
        .iter()
        .any(|fragment| label.contains(fragment))
    {
        return Vec::new();
    }
    let armed = ACTIVATION_PATH_FRAGMENTS
        .iter()
        .any(|fragment| label.contains(fragment))
        || ACTIVATION_TEXT_GATES.iter().any(|gate| text.contains(gate));
    if !armed {
        return Vec::new();
    }
    hits(DIRECT_HF_UPLOAD_MARKERS, text)
}

pub fn queue_blocks_in_text(text: &str, label: &str) -> Vec<String> {
    if QUEUE_ALLOWLIST_PATH_FRAGMENTS
        .iter()
        .any(|fragment| label.contains(fragment))
    {
        return Vec::new();
    }
    hits(DIRECT_QUEUE_MARKERS, text)
}
