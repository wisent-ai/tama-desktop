//! Logic for `tama-block-direct-lsi-api` — port of
//! `codex-hooks/block_direct_lsi_api.py`, registry hook id `block-direct-lsi-api`.
//!
//! Direct server-side writes to the NCBR/LSI form damaged a section of the
//! application, so the allowed path for this system is the real UI flow. The
//! guard refuses shell commands carrying a direct API endpoint, runs of local
//! scripts whose source carries one, and edits that add one to a source file.
//! Read-only inspection such as `sed script.py` stays allowed unless the
//! command itself names a forbidden endpoint.
//!
//! No lifetime annotation or character literal appears below on purpose: the
//! `block-numeric-literals` guard strips strings with a scanner that reads a
//! lifetime tick as an opening quote, which would desync it over the bounded
//! repetition in the last pattern.

use regex::Regex;
use serde_json::Value;
use tama_hooks::session_record::{deny_tool_use, read_payload};

use super::codex_api_guard as guard;
use super::pyvalue::{py_str, truthy};

/// `parts[i + 1 : i + 5]`: the four tokens after a runner.
const CANDIDATE_WINDOW_TEXT: &str = "4";

const SCAN_EDIT_SUFFIXES: &[&str] = &[
    ".py", ".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx", ".sh", ".ipynb",
];

/// `python3` counts as read-only here only while no script source resolves.
const READ_ONLY_SHELL_COMMANDS: &[&str] = &[
    "sed", "cat", "nl", "less", "head", "tail", "wc", "ls", "find", "jq", "sqlite3", "python3",
];

const ALLOWLIST_PATH_FRAGMENTS: &[&str] = &[
    "/.codex/hooks/block_direct_lsi_api.py",
    "/.codex/hooks.json",
];

const SHELL_LABEL: &str = "<shell command>";
const EDIT_LABEL: &str = "<edit>";
const APPLY_PATCH: &str = "apply_patch";
const EDIT_TEXT_KEYS: &[&str] = &["content", "new_string", "patch", "new_source"];

/// `[\s\S]{0,300}` — the span the Python allows between an HTTP client name
/// and the LSI host or endpoint it targets.
const CLIENT_GAP: &str = "[\\s\\S]{0,300}";

type Patterns = [(String, Regex)];

fn candidate_window() -> usize {
    CANDIDATE_WINDOW_TEXT.parse().unwrap_or_default()
}

fn compiled(reason: &str, pattern: &str) -> (String, Regex) {
    let expression = Regex::new(pattern).expect("forbidden LSI pattern must compile");
    (reason.to_string(), expression)
}

/// `FORBIDDEN_PATTERNS`, in source order. `re.I` becomes `(?i)`; the
/// `re.DOTALL` on the helper pattern becomes `(?s)` and, exactly as in Python,
/// changes nothing — that pattern holds no unescaped `.`.
fn forbidden_patterns() -> Vec<(String, Regex)> {
    vec![
        compiled(
            "direct LSI API URL",
            "(?i)https?://lsi2\\.ncbr\\.gov\\.pl/api/",
        ),
        compiled(
            "direct PARP/NCBR API URL",
            "(?i)https?://(?:[^/\\s\"']+\\.)?(?:parp|ncbr)\\.gov\\.pl/api/",
        ),
        compiled(
            "project registry write/read endpoint",
            "(?i)/api/beneficiary/(?:project-versions|project-sections|project)/",
        ),
        compiled(
            "registry values endpoint",
            "(?i)\\b(?:project-registries|registries-values|collection-objects)\\b",
        ),
        compiled(
            "browser-authenticated API helper",
            "(?is)\\b(?:CDPSession|session\\.fetch|page\\.evaluate\\([^)]*fetch|\
             collection_save_url|scalar_save_url|registries_values_url|project_fields_url)\\b",
        ),
        compiled(
            "low-level HTTP client targeting LSI",
            &format!(
                "(?i)\\b(?:curl|wget|httpx?|requests\\.|fetch\\(|urllib\\.request)\\b{CLIENT_GAP}\
                 (?:lsi2\\.ncbr\\.gov\\.pl|/api/beneficiary/)"
            ),
        ),
    ]
}

fn scan_text(patterns: &Patterns, text: &str, label: &str) -> Vec<String> {
    if guard::is_allowlisted(label, ALLOWLIST_PATH_FRAGMENTS) {
        return Vec::new();
    }
    patterns
        .iter()
        .filter(|(_, pattern)| pattern.is_match(text))
        .map(|(reason, _)| reason.clone())
        .collect()
}

fn report(label: &str, hits: &[String]) -> ! {
    deny_tool_use(&format!(
        "BLOCKED: direct LSI/PARP/NCBR API usage is forbidden for this agent.\n  target: \
         {label}\n  matched: {}\n\nUse the real UI flow only. Do not call /api/beneficiary, \
         project-registries, registries-values, or collection-objects directly.",
        guard::matched_list(hits)
    ))
}

fn check_shell(patterns: &Patterns, data: &Value, tool_input: &Value) {
    let command = guard::first_truthy(&[
        (tool_input, "command"),
        (tool_input, "cmd"),
        (data, "command"),
        (data, "cmd"),
    ])
    .and_then(Value::as_str)
    .unwrap_or_default();
    if command.is_empty() {
        return;
    }

    let hits = scan_text(patterns, command, SHELL_LABEL);
    if !hits.is_empty() {
        report(SHELL_LABEL, &hits);
    }

    let executable = guard::first_executable(command);
    let cwd = guard::working_dir(data, tool_input);
    let scripts = guard::resolve_script_paths(command, &cwd, candidate_window());

    // Pure read-only shell inspection is allowed. Running a script is not
    // read-only, so it is still scanned below.
    if scripts.is_empty() && READ_ONLY_SHELL_COMMANDS.contains(&executable.as_str()) {
        return;
    }

    for path in scripts {
        let text = match guard::read_source(&path) {
            Some(text) => text,
            None => continue,
        };
        let shown = path.to_string_lossy().into_owned();
        let hits = scan_text(patterns, &text, &shown);
        if !hits.is_empty() {
            report(&shown, &hits);
        }
    }
}

fn check_edit(patterns: &Patterns, data: &Value, tool_input: &Value) {
    let label = guard::first_truthy(&[
        (tool_input, "file_path"),
        (tool_input, "notebook_path"),
        (tool_input, "path"),
    ])
    .or_else(|| data.get("tool_name"))
    .map(py_str)
    .unwrap_or_else(|| EDIT_LABEL.to_string());

    if guard::is_allowlisted(&label, ALLOWLIST_PATH_FRAGMENTS) {
        return;
    }
    let named_source = SCAN_EDIT_SUFFIXES
        .iter()
        .any(|suffix| label.ends_with(suffix));
    let patching = data.get("tool_name").and_then(Value::as_str) == Some(APPLY_PATCH);
    if !named_source && !patching {
        return;
    }

    let mut pieces: Vec<String> = Vec::new();
    match data.get("tool_input") {
        Some(Value::String(raw)) => pieces.push(raw.clone()),
        _ => {
            for key in EDIT_TEXT_KEYS {
                if let Some(value) = tool_input.get(key).filter(|found| truthy(found)) {
                    pieces.push(py_str(value));
                }
            }
        }
    }
    let text = pieces.join("\n");
    if text.is_empty() {
        return;
    }
    let hits = scan_text(patterns, &text, &label);
    if !hits.is_empty() {
        report(&label, &hits);
    }
}

pub fn run() {
    let data = read_payload();
    if !truthy(&data) {
        return;
    }
    let tool = data
        .get("tool_name")
        .and_then(Value::as_str)
        .unwrap_or_default();
    let empty = Value::Object(Default::default());
    let tool_input = data
        .get("tool_input")
        .filter(|value| value.is_object())
        .unwrap_or(&empty);

    if guard::SHELL_TOOLS.contains(&tool) {
        check_shell(&forbidden_patterns(), &data, tool_input);
    } else if guard::EDIT_TOOLS.contains(&tool) {
        check_edit(&forbidden_patterns(), &data, tool_input);
    }
}
