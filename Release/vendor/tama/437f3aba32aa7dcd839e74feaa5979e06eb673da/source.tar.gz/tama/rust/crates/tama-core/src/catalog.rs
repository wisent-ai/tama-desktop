//! Port of `src/core/catalog.mjs`.
//!
//! Notable fidelity choices:
//! - JS `JSON.parse` preserves object key insertion order. The typed
//!   [`Registry`] uses `BTreeMap`, so insertion order for observable event and
//!   adapter arrays is recovered from the raw JSON text.
//! - JS `.sort()` on the ASCII strings used here is byte-lexicographic, as is
//!   Rust's `str::cmp`. Non-ASCII locale ordering is outside this catalogue.

use serde::Serialize;
use std::collections::{HashMap, HashSet};
use std::fs;
use std::path::{Component, Path, PathBuf};

use crate::registry::{CatalogMetadata, HookDocs, JustificationRequirement, OrderedMap, Registry};
use crate::runtime::detect_runtime_install_drift;
use crate::Result;

const MANAGED_VALIDATION_FILES: [&str; 1] = ["package.json"];

/// JS `repoRoot()`: the repository root.
///
/// Resolved as `$TAMA_ROOT` when the variable is set (and non-empty),
/// otherwise relative to `env!("CARGO_MANIFEST_DIR")` three levels up
/// (`rust/crates/tama-core/../../..`).
pub fn repo_root() -> PathBuf {
    if let Ok(root) = std::env::var("TAMA_ROOT") {
        if !root.is_empty() {
            return PathBuf::from(root);
        }
    }
    normalize_path(
        &PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .join("..")
            .join("..")
            .join(".."),
    )
}

/// Normalize `.`/`..` components without touching the filesystem
/// (like Node's `path.resolve`, which does not resolve symlinks).
fn normalize_path(path: &Path) -> PathBuf {
    let mut out = PathBuf::new();
    for component in path.components() {
        match component {
            Component::CurDir => {}
            Component::ParentDir => {
                out.pop();
            }
            other => out.push(other.as_os_str()),
        }
    }
    out
}

/// JS `readJson(path)` = `JSON.parse(readFileSync(path, 'utf8'))`.
pub fn read_json(path: &Path) -> Result<serde_json::Value> {
    Ok(serde_json::from_str(&fs::read_to_string(path)?)?)
}

/// JS `commandSourcePath(command)`: map an absolute hook command/source path
/// back to its archived repo-relative path, or `None`.
pub fn command_source_path(command: Option<&str>, _root: &Path) -> Option<String> {
    let command = command?;
    if command.is_empty() {
        return None; // JS: `if (!command || typeof command !== 'string') return null`
    }
    // JS `SOURCE_PREFIXES` are built once from the module-level `ROOT`
    // (the real repo root), never from the `--root` argument.
    let root_s = root_str(&repo_root());
    let prefixes: [(String, &str); 6] = [
        ("/Users/lukaszbartoszcze/.shared-hooks/".to_string(), "shared-hooks/"),
        ("/Users/lukaszbartoszcze/.codex/hooks/".to_string(), "codex-hooks/"),
        ("/Users/lukaszbartoszcze/.claude/hooks/".to_string(), "claude-hooks/"),
        (format!("{}/", join_path(&root_s, "shared-hooks")), "shared-hooks/"),
        (format!("{}/", join_path(&root_s, "codex-hooks")), "codex-hooks/"),
        (format!("{}/", join_path(&root_s, "claude-hooks")), "claude-hooks/"),
    ];
    for (prefix, repo_dir) in &prefixes {
        if let Some(idx) = command.find(prefix.as_str()) {
            let rest = command[idx + prefix.len()..]
                .split_whitespace()
                .next()
                .unwrap_or("");
            // Node `join('shared-hooks/', '')` normalizes to 'shared-hooks'.
            return Some(if rest.is_empty() {
                repo_dir.trim_end_matches('/').to_string()
            } else {
                format!("{repo_dir}{rest}")
            });
        }
    }
    None
}

/// JS catalog `loadRegistry(root)`: parsed `shared-hooks/registry.json`,
/// or `{ events: {} }` when the file does not exist.
pub fn load_registry(root: &Path) -> Result<Registry> {
    Ok(load_registry_raw(root)?.0)
}

/// Registry plus the raw file text (needed to recover JSON key order).
fn load_registry_raw(root: &Path) -> Result<(Registry, Option<String>)> {
    let path = root.join("shared-hooks").join("registry.json");
    if !path.exists() {
        return Ok((Registry::default(), None));
    }
    let raw = fs::read_to_string(path)?;
    Ok((serde_json::from_str(&raw)?, Some(raw)))
}

/// JS `loadCatalogMetadata(root)`: `shared-hooks/catalog-metadata.json` as a
/// map of hook id -> docs, empty when the file does not exist.
pub fn load_catalog_metadata(root: &Path) -> Result<CatalogMetadata> {
    let path = root.join("shared-hooks").join("catalog-metadata.json");
    if !path.exists() {
        return Ok(CatalogMetadata::new());
    }
    Ok(serde_json::from_str(&fs::read_to_string(path)?)?)
}

/// JS `listSourceFiles(root)`: repo-relative paths of every file under
/// `claude-hooks`, `codex-hooks`, `shared-hooks`, `repo-githooks`
/// (skipping `.git`, `__pycache__`, `state`, `recall_dumps`), sorted.
pub fn list_source_files(root: &Path) -> Result<Vec<String>> {
    let root_s = root_str(root);
    let mut files = Vec::new();
    for dir in ["claude-hooks", "codex-hooks", "shared-hooks", "repo-githooks"] {
        walk(&join_path(&root_s, dir), &mut files)?;
    }
    let mut rel: Vec<String> = files.iter().map(|p| strip_root(&root_s, p).to_string()).collect();
    rel.sort();
    Ok(rel)
}

/// One entry of JS `listRepoGitHooks(root)`.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct RepoGitHook {
    pub project: String,
    pub event: String,
    pub source_path: String,
}

/// JS `listRepoGitHooks(root)`, sorted by `project:event`.
pub fn list_repo_git_hooks(root: &Path) -> Result<Vec<RepoGitHook>> {
    let mut hooks: Vec<RepoGitHook> = list_source_files(root)?
        .into_iter()
        .filter(|path| path.starts_with("repo-githooks/"))
        .map(|path| {
            let parts: Vec<&str> = path.split('/').collect();
            // JS `parts[1]`/`parts[2]` may be `undefined`, which stringifies
            // as "undefined"; reproduced literally for pathological layouts.
            let part = |i: usize| parts.get(i).map(|s| s.to_string()).unwrap_or_else(|| "undefined".to_string());
            RepoGitHook {
                project: part(1),
                event: part(2),
                source_path: path,
            }
        })
        .collect();
    hooks.sort_by(|a, b| {
        format!("{}:{}", a.project, a.event).cmp(&format!("{}:{}", b.project, b.event))
    });
    Ok(hooks)
}

/// Per-event entry of a catalog hook: `{ event, blocking, timeout, statusMessage }`.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CatalogHookEvent {
    pub event: String,
    pub blocking: bool,
    #[serde(serialize_with = "serialize_js_number")]
    pub timeout: Option<f64>,
    pub status_message: Option<String>,
}

/// Serialize an `Option<f64>` the way `JSON.stringify` prints JS numbers:
/// integral values without a fractional part (`10`, not `10.0`).
fn serialize_js_number<S: serde::Serializer>(
    value: &Option<f64>,
    serializer: S,
) -> std::result::Result<S::Ok, S::Error> {
    match value {
        None => serializer.serialize_none(),
        Some(v) if v.fract() == 0.0 && v.abs() < 1e15 => serializer.serialize_i64(*v as i64),
        Some(v) => serializer.serialize_f64(*v),
    }
}

/// One hook entry of the built catalog (JS object shape preserved).
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CatalogHook {
    pub id: String,
    #[serde(rename = "type")]
    pub hook_type: String,
    pub command: String,
    pub source_path: Option<String>,
    pub category: Option<String>,
    pub status: Option<String>,
    pub description: Option<String>,
    pub why: Option<String>,
    pub side_effects: Option<String>,
    pub events: Vec<CatalogHookEvent>,
    pub justification_requirements: Vec<JustificationRequirement>,
}

/// Result of JS `buildCatalog(root)`.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Catalog {
    pub version: u64,
    pub generated_at: Option<String>,
    pub hooks: Vec<CatalogHook>,
    pub orphan_sources: Vec<String>,
    /// Adapters in `registry.json` insertion order (not alphabetical).
    pub adapters: OrderedMap<crate::registry::Adapter>,
    pub repo_git_hooks: Vec<RepoGitHook>,
}

/// JS `buildCatalog(root)`. Field-level merge priorities:
/// `type`: docs.type ?? hook.type ?? 'command';
/// `category`/`status`/`why`/`sideEffects`: hook.* ?? docs.*;
/// `description`: hook.description ?? hook.does ?? docs.description;
/// `justificationRequirements`: docs.* ?? hook.* ?? [].
pub fn build_catalog(root: &Path) -> Result<Catalog> {
    let (registry, raw) = load_registry_raw(root)?;
    let mut event_order: Vec<String> = raw
        .as_deref()
        .map(|text| top_level_object_key_order(text, "events"))
        .unwrap_or_default();
    // Defensive: include any events the raw-text scan might have missed.
    for key in registry.events.keys() {
        if !event_order.iter().any(|e| e == key) {
            event_order.push(key.clone());
        }
    }
    let mut adapter_order: Vec<String> = raw
        .as_deref()
        .map(|text| top_level_object_key_order(text, "adapters"))
        .unwrap_or_default();
    for key in registry.adapters.keys() {
        if !adapter_order.iter().any(|a| a == key) {
            adapter_order.push(key.clone());
        }
    }
    let metadata = load_catalog_metadata(root)?;
    let empty_docs = HookDocs::default();

    let mut by_id: HashMap<String, CatalogHook> = HashMap::new();
    for event in &event_order {
        let config = &registry.events[event];
        for hook in &config.hooks {
            // JS: `hook.source ? commandSourcePath(hook.source) : commandSourcePath(hook.command)`
            let source_path = match hook.source.as_deref() {
                Some(source) if !source.is_empty() => command_source_path(Some(source), root),
                _ => command_source_path(hook.command.as_deref(), root),
            };
            let docs = metadata.get(&hook.id).unwrap_or(&empty_docs);
            let entry = by_id.entry(hook.id.clone()).or_insert_with(|| CatalogHook {
                id: hook.id.clone(),
                hook_type: docs
                    .hook_type
                    .clone()
                    .or_else(|| hook.hook_type.clone())
                    .unwrap_or_else(|| "command".to_string()),
                command: hook.command.clone().unwrap_or_default(),
                source_path: source_path.clone(),
                category: hook.category.clone().or_else(|| docs.category.clone()),
                status: hook.status.clone().or_else(|| docs.status.clone()),
                description: hook
                    .description
                    .clone()
                    .or_else(|| hook.does.clone())
                    .or_else(|| docs.description.clone()),
                why: hook.why.clone().or_else(|| docs.why.clone()),
                side_effects: hook.side_effects.clone().or_else(|| docs.side_effects.clone()),
                events: Vec::new(),
                justification_requirements: docs
                    .justification_requirements
                    .clone()
                    .unwrap_or_else(|| hook.justification_requirements.clone()),
            });
            entry.events.push(CatalogHookEvent {
                event: event.clone(),
                blocking: config.blocking.unwrap_or(false),
                timeout: hook.timeout,
                status_message: hook.status_message.clone(),
            });
            if entry.source_path.is_none() && source_path.is_some() {
                entry.source_path = source_path;
            }
        }
    }
    let mut hooks: Vec<CatalogHook> = by_id.into_values().collect();
    hooks.sort_by(|a, b| a.id.cmp(&b.id));
    let registered_sources: HashSet<&str> = hooks
        .iter()
        .filter_map(|h| h.source_path.as_deref())
        .filter(|s| !s.is_empty())
        .collect();
    let orphan_sources: Vec<String> = list_source_files(root)?
        .into_iter()
        .filter(|p| [".py", ".sh", ".mjs", ".js"].contains(&extname(p)))
        .filter(|p| !registered_sources.contains(p.as_str()))
        .collect();
    let mut adapters = OrderedMap::new();
    for name in &adapter_order {
        if let Some(adapter) = registry.adapters.get(name) {
            adapters.push(name.clone(), adapter.clone());
        }
    }
    Ok(Catalog {
        version: registry.version.unwrap_or(1),
        generated_at: registry.generated_at.clone(),
        hooks,
        orphan_sources,
        adapters,
        repo_git_hooks: list_repo_git_hooks(root)?,
    })
}

/// JS `findHook(id, root)`.
pub fn find_hook(id: &str, root: &Path) -> Result<Option<CatalogHook>> {
    Ok(build_catalog(root)?.hooks.into_iter().find(|hook| hook.id == id))
}

/// Result of JS `validateCatalog(root)`.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ValidationResult {
    pub ok: bool,
    pub errors: Vec<String>,
    pub warnings: Vec<String>,
    pub hook_count: usize,
    pub orphan_source_count: usize,
}

/// JS `validateCatalog(root)`.
pub fn validate_catalog(root: &Path) -> Result<ValidationResult> {
    let catalog = build_catalog(root)?;
    let mut errors: Vec<String> = Vec::new();
    let mut warnings: Vec<String> = Vec::new();
    let mut seen: HashSet<&str> = HashSet::new();
    for hook in &catalog.hooks {
        if seen.contains(hook.id.as_str()) {
            errors.push(format!("duplicate hook id: {}", hook.id));
        }
        seen.insert(hook.id.as_str());
        if hook.source_path.is_none() {
            warnings.push(format!("{}: source path could not be mapped from command", hook.id));
        }
        if let Some(source_path) = &hook.source_path {
            if !root.join(source_path).exists() {
                errors.push(format!("{}: missing source file {}", hook.id, source_path));
            }
        }
        if hook.events.is_empty() {
            errors.push(format!("{}: no events", hook.id));
        }
        if hook.hook_type == "requires_justification" {
            if hook.justification_requirements.is_empty() {
                errors.push(format!("{}: requires_justification has no requirements", hook.id));
            }
            let mut kinds: HashSet<Option<&str>> = HashSet::new();
            for requirement in &hook.justification_requirements {
                if requirement.kind.is_none() {
                    errors.push(format!("{}: justification requirement has no kind", hook.id));
                }
                if kinds.contains(&requirement.kind.as_deref()) {
                    errors.push(format!(
                        "{}: duplicate justification kind {}",
                        hook.id,
                        js_opt(requirement.kind.as_deref())
                    ));
                }
                kinds.insert(requirement.kind.as_deref());
                let kind = js_opt(requirement.kind.as_deref());
                if requirement.registry_path.is_none() {
                    errors.push(format!("{}: {} justification has no registryPath", hook.id, kind));
                }
                if requirement.field.is_none() {
                    errors.push(format!("{}: {} justification has no field", hook.id, kind));
                }
                if requirement.kind.as_deref() == Some("test")
                    && requirement.direct_user_quote_field.is_none()
                {
                    errors.push(format!("{}: test justification has no directUserQuoteField", hook.id));
                }
                // JS: `!Number.isInteger(minimumWords) || minimumWords < 1`
                match requirement.minimum_words {
                    Some(words) if words >= 1 => {}
                    _ => errors.push(format!(
                        "{}: {} justification has invalid minimumWords",
                        hook.id, kind
                    )),
                }
            }
        }
    }
    for file in list_managed_files(root)? {
        let bytes = fs::read(root.join(&file))?;
        let text = String::from_utf8_lossy(&bytes);
        if has_high_entropy_token(&text) {
            errors.push(format!("{}: high-entropy token detected", file));
        }
    }
    for entry in detect_runtime_install_drift(root)? {
        let where_ = match &entry.event {
            Some(event) => format!(
                "{} {} {}",
                entry.runtime,
                event,
                js_opt(entry.hook_id.as_deref())
            ),
            None => entry.runtime.clone(),
        };
        let message = format!("install drift: {} — {}", where_, entry.reason);
        if entry.material {
            errors.push(message);
        } else {
            let why = if entry.acknowledged.unwrap_or(false) {
                "acknowledged"
            } else if entry.unsupported_event {
                "unsupported event"
            } else {
                "runtime not required for live coverage"
            };
            warnings.push(format!("{} (non-material: {})", message, why));
        }
    }
    Ok(ValidationResult {
        ok: errors.is_empty(),
        errors,
        warnings,
        hook_count: catalog.hooks.len(),
        orphan_source_count: catalog.orphan_sources.len(),
    })
}


// ---------------------------------------------------------------------------
// helpers
// ---------------------------------------------------------------------------

/// Path as a string without trailing slash (Node's `path.join` normalizes it away).
fn root_str(root: &Path) -> String {
    let s = root.to_string_lossy();
    let trimmed = s.trim_end_matches('/');
    if trimmed.is_empty() {
        "/".to_string()
    } else {
        trimmed.to_string()
    }
}

/// Node `path.join(base, part)` for the simple cases used here.
fn join_path(base: &str, part: &str) -> String {
    format!("{}/{}", base.trim_end_matches('/'), part)
}

/// Node `path.relative(root, path)` where `path` is always under `root`.
fn strip_root<'a>(root_s: &str, path: &'a str) -> &'a str {
    if root_s == "/" {
        path.strip_prefix('/').unwrap_or(path)
    } else {
        path.strip_prefix(root_s)
            .and_then(|p| p.strip_prefix('/'))
            .unwrap_or(path)
    }
}

/// JS `walk(dir, out)`: recursive file listing, skipping
/// `.git`, `__pycache__`, `state`, `recall_dumps` directories.
fn walk(dir: &str, out: &mut Vec<String>) -> Result<()> {
    if !Path::new(dir).exists() {
        return Ok(());
    }
    for entry in fs::read_dir(dir)? {
        let entry = entry?;
        let name = entry.file_name().to_string_lossy().into_owned();
        let path = join_path(dir, &name);
        // JS `statSync` follows symlinks; so does `fs::metadata`.
        let st = fs::metadata(&path)?;
        if st.is_dir() {
            if ![".git", "__pycache__", "state", "recall_dumps"].contains(&name.as_str()) {
                walk(&path, out)?;
            }
        } else {
            out.push(path);
        }
    }
    Ok(())
}

/// Node `path.extname`: suffix from the last `.` in the basename, or "".
fn extname(path: &str) -> &str {
    let base = path.rsplit('/').next().unwrap_or(path);
    match base.rfind('.') {
        Some(0) | None => "",
        Some(i) => &base[i..],
    }
}

/// Lists Tama's managed Rust source and durable validation files.
fn list_managed_files(root: &Path) -> Result<Vec<String>> {
    let root_s = root_str(root);
    let mut files: Vec<String> = MANAGED_VALIDATION_FILES
        .iter()
        .filter(|file| root.join(file).exists())
        .map(|file| file.to_string())
        .collect();
    let mut walked = Vec::new();
    walk(&join_path(&root_s, "rust/crates"), &mut walked)?;
    for path in walked {
        files.push(strip_root(&root_s, &path).to_string());
    }
    files.sort();
    Ok(files)
}

/// JS `HIGH_ENTROPY_TOKEN.test(text)` with
/// `HIGH_ENTROPY_TOKEN = /[A-Za-z0-9_./+=-]{72,}/`, implemented as a manual
/// scan (the character class is pure ASCII, so a byte scan is exact).
fn has_high_entropy_token(text: &str) -> bool {
    let mut run = 0usize;
    for byte in text.bytes() {
        if matches!(byte,
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'_' | b'.' | b'/' | b'+' | b'=' | b'-')
        {
            run += 1;
            if run >= 72 {
                return true;
            }
        } else {
            run = 0;
        }
    }
    false
}

/// JS template-literal interpolation of a possibly-missing string:
/// `None` renders as "undefined".
fn js_opt(value: Option<&str>) -> &str {
    value.unwrap_or("undefined")
}

/// JS truthiness for optional strings: `Some(s)` with `s` non-empty.
fn truthy(value: &Option<String>) -> Option<&str> {
    value.as_deref().filter(|s| !s.is_empty())
}

/// JS `Number` -> string for the magnitudes used here (timeouts). Rust's
/// `f64` `Display` matches JS for plain decimal values (`10.0` -> "10").
fn format_f64(value: f64) -> String {
    format!("{}", value)
}

// ---------------------------------------------------------------------------
// raw JSON key-order scanner
// ---------------------------------------------------------------------------

/// Extract the insertion order of keys of the object stored at top-level
/// `key` in raw JSON text. `serde_json` without `preserve_order` sorts map
/// keys, but JS `JSON.parse` preserves insertion order and the catalog output
/// depends on it. Returns an empty vector when the key or its object value is
/// absent or the text is malformed.
fn top_level_object_key_order(text: &str, key: &str) -> Vec<String> {
    let mut scanner = Scanner::new(text);
    scanner.skip_ws();
    if scanner.peek() != Some(b'{') {
        return Vec::new();
    }
    scanner.advance(1);
    loop {
        scanner.skip_ws();
        match scanner.peek() {
            Some(b'}') | None => return Vec::new(),
            Some(b',') => {
                scanner.advance(1);
                continue;
            }
            _ => {}
        }
        let entry_key = match scanner.read_string() {
            Some(k) => k,
            None => return Vec::new(),
        };
        scanner.skip_ws();
        if scanner.peek() == Some(b':') {
            scanner.advance(1);
        }
        scanner.skip_ws();
        if entry_key == key && scanner.peek() == Some(b'{') {
            scanner.advance(1);
            let mut keys = Vec::new();
            loop {
                scanner.skip_ws();
                match scanner.peek() {
                    Some(b'}') | None => return keys,
                    Some(b',') => {
                        scanner.advance(1);
                        continue;
                    }
                    _ => {}
                }
                match scanner.read_string() {
                    Some(k) => keys.push(k),
                    None => return keys,
                }
                scanner.skip_ws();
                if scanner.peek() == Some(b':') {
                    scanner.advance(1);
                }
                scanner.skip_value();
            }
        }
        scanner.skip_value();
    }
}

struct Scanner<'a> {
    bytes: &'a [u8],
    pos: usize,
}

impl<'a> Scanner<'a> {
    fn new(text: &'a str) -> Self {
        Self {
            bytes: text.as_bytes(),
            pos: 0,
        }
    }

    fn peek(&self) -> Option<u8> {
        self.bytes.get(self.pos).copied()
    }

    fn advance(&mut self, n: usize) {
        self.pos += n;
    }

    fn skip_ws(&mut self) {
        while matches!(self.peek(), Some(b' ' | b'\t' | b'\n' | b'\r')) {
            self.pos += 1;
        }
    }

    fn skip_string(&mut self) {
        // assumes the cursor is on the opening quote
        self.pos += 1;
        while let Some(byte) = self.peek() {
            match byte {
                b'\\' => self.pos += 2,
                b'"' => {
                    self.pos += 1;
                    return;
                }
                _ => self.pos += 1,
            }
        }
    }

    /// Read a JSON string at the cursor, decoding standard escapes.
    fn read_string(&mut self) -> Option<String> {
        if self.peek() != Some(b'"') {
            return None;
        }
        self.pos += 1;
        let mut out = String::new();
        while self.pos < self.bytes.len() {
            match self.bytes[self.pos] {
                b'"' => {
                    self.pos += 1;
                    return Some(out);
                }
                b'\\' => {
                    self.pos += 1;
                    let escaped = *self.bytes.get(self.pos)?;
                    self.pos += 1;
                    match escaped {
                        b'"' => out.push('"'),
                        b'\\' => out.push('\\'),
                        b'/' => out.push('/'),
                        b'b' => out.push('\u{8}'),
                        b'f' => out.push('\u{c}'),
                        b'n' => out.push('\n'),
                        b'r' => out.push('\r'),
                        b't' => out.push('\t'),
                        b'u' => {
                            let hex = self.bytes.get(self.pos..self.pos + 4)?;
                            let code = u32::from_str_radix(std::str::from_utf8(hex).ok()?, 16).ok()?;
                            self.pos += 4;
                            out.push(char::from_u32(code).unwrap_or('\u{fffd}'));
                        }
                        other => out.push(other as char),
                    }
                }
                _ => {
                    // copy one UTF-8 encoded char verbatim
                    let start = self.pos;
                    self.pos += 1;
                    while self.pos < self.bytes.len() && (self.bytes[self.pos] & 0xC0) == 0x80 {
                        self.pos += 1;
                    }
                    out.push_str(std::str::from_utf8(&self.bytes[start..self.pos]).ok()?);
                }
            }
        }
        None
    }

    fn skip_value(&mut self) {
        self.skip_ws();
        match self.peek() {
            Some(b'"') => self.skip_string(),
            Some(b'{' | b'[') => {
                let mut depth = 0i32;
                while let Some(byte) = self.peek() {
                    match byte {
                        b'"' => self.skip_string(),
                        b'{' | b'[' => {
                            depth += 1;
                            self.pos += 1;
                        }
                        b'}' | b']' => {
                            depth -= 1;
                            self.pos += 1;
                            if depth == 0 {
                                return;
                            }
                        }
                        _ => self.pos += 1,
                    }
                }
            }
            _ => {
                while let Some(byte) = self.peek() {
                    if matches!(byte, b',' | b'}' | b']' | b' ' | b'\t' | b'\n' | b'\r') {
                        return;
                    }
                    self.pos += 1;
                }
            }
        }
    }
}
