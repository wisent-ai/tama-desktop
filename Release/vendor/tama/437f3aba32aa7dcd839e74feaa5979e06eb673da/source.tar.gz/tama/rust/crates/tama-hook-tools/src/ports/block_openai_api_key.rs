//! Ports `shared-hooks/block_openai_api_key.py` (hook `block-openai-api-key`).
//!
//! A `PreToolUse` gate over three surfaces, in the Python's order: the command
//! of a shell call, the content of a read target that already exists on disk,
//! and the added text of an edit. A hit on any of them is a refusal, and the
//! first surface that applies is the only one examined.
//!
//! The alternation is assembled from fragments at run time so that this file
//! contains no match for its own pattern. That is not decoration: the live hook
//! scans the text of every edit, so a source file spelling the credential names
//! out in full could not be written at all. The Python pays for the same
//! problem with the two lookaround guards on its first alternative, which exist
//! to exempt its own file name.

use regex::Regex;
use serde_json::Value;
use tama_hooks::session_record::deny_tool_use;

use crate::ports::{pystr, python_stdlib, pyvalue};

/// Fragments of `FORBIDDEN`. Joined they are the Python's alternation; apart
/// they match nothing.
const KEY_ENV_PREFIX: &str = "OPENAI_API_";
const KEY_SUFFIX: &str = "KEY";
const BASE_SUFFIX: &str = "BASE";
const URL_SUFFIX: &str = "URL";
const RANK_KEY_PREFIX: &str = "CHATGPT_RANK_API_";
const ENDPOINT_ALTERNATIVES: &str = "api\\.openai\\.com|openai\\.com/v1|sk-[A-Za-z0-9_-]{20,}";

/// `(?<!block_)` on the first alternative: the hook's own file name.
const IDENTIFIER_GUARD: &str = "block_";
/// `(?!\.py)` on the first alternative, for the same reason.
const SOURCE_GUARD: &str = ".py";

/// The capture group wrapping the one guarded alternative.
const GUARDED_GROUP_TEXT: &str = "1";
/// `sample[:220]` in `block`.
const MATCHED_SAMPLE_CHARS_TEXT: &str = "220";
/// Python reports an uncaught `AttributeError` as exit 1.
const CRASH_STATUS_TEXT: &str = "1";

const BLOCK_HEAD: &str = "BLOCKED: OpenAI API-key usage is forbidden for this agent.";
const COMMAND_REASON: &str = "command references OpenAI API credentials or endpoint";
const READ_REASON: &str = "read target contains forbidden OpenAI API credential reference: ";
const EDIT_REASON: &str = "file edit introduces OpenAI API credential or endpoint usage";

const COMMAND_KEYS: &[&str] = &["command", "cmd"];
const TOOL_KEYS: &[&str] = &["tool_name", "tool"];
const READ_KEYS: &[&str] = &["file_path", "path"];
const EDIT_KEYS: &[&str] = &["content", "new_string", "new_source", "patch"];
const PATCH_TOOL_MARKER: &str = "apply_patch";
const PLUS: &str = "+";
const PATCH_HEADERS: &[&str] = &["+++", "***"];
const SEPARATOR: &str = "/";
const CURRENT_DIR: &str = ".";

fn matched_sample_chars() -> usize {
    MATCHED_SAMPLE_CHARS_TEXT.parse().unwrap_or_default()
}

fn crash() -> ! {
    eprintln!("block_openai_api_key: payload is not a mapping");
    std::process::exit(CRASH_STATUS_TEXT.parse().unwrap_or_default())
}

fn forbidden() -> Regex {
    Regex::new(&format!(
        "(?i)({KEY_ENV_PREFIX}{KEY_SUFFIX})|{RANK_KEY_PREFIX}{KEY_SUFFIX}\
|{KEY_ENV_PREFIX}{BASE_SUFFIX}|{KEY_ENV_PREFIX}{URL_SUFFIX}|{ENDPOINT_ALTERNATIVES}"
    ))
    .unwrap()
}

fn tail_matches(text: &str, needle: &str) -> bool {
    pystr::tail_chars(text, needle.chars().count()).eq_ignore_ascii_case(needle)
}

fn head_matches(text: &str, needle: &str) -> bool {
    pystr::head_chars(text, needle.chars().count()).eq_ignore_ascii_case(needle)
}

/// The two lookaround assertions Rust's engine does not have.
fn guards_pass(text: &str, start: usize, end: usize) -> bool {
    !tail_matches(&text[..start], IDENTIFIER_GUARD) && !head_matches(&text[end..], SOURCE_GUARD)
}

/// `FORBIDDEN.search(text).group(0)`. A guard-rejected hit resumes one
/// character on, which is where the Python's engine would continue: no other
/// alternative can begin where the guarded one did.
fn find_forbidden(pattern: &Regex, text: &str) -> Option<String> {
    let guarded: usize = GUARDED_GROUP_TEXT.parse().unwrap_or_default();
    let mut offset = usize::MIN;
    while offset <= text.len() {
        let caps = pattern.captures_at(text, offset)?;
        let hit = caps.get(usize::MIN)?;
        if caps.get(guarded).is_none() || guards_pass(text, hit.start(), hit.end()) {
            return Some(hit.as_str().to_string());
        }
        offset = hit.start() + text[hit.start()..].chars().next().map(char::len_utf8)?;
    }
    None
}

fn block(reason: &str, sample: &str) -> ! {
    let mut banner = format!("{BLOCK_HEAD}\nReason: {reason}");
    if !sample.is_empty() {
        let shown = pystr::head_chars(sample, matched_sample_chars());
        banner.push_str(&format!("\nMatched: {shown}"));
    }
    deny_tool_use(&banner)
}

fn is_falsy(value: &Value) -> bool {
    !pyvalue::truthy(value)
}

/// `data.get("tool_input") or {}`.
fn tool_input(data: &Value) -> Value {
    let raw = data.get("tool_input").cloned().unwrap_or_default();
    if is_falsy(&raw) {
        return Value::Object(Default::default());
    }
    if !raw.is_object() {
        crash();
    }
    raw
}

/// `sys.stdin.read()` plus the parse, which yields `{}` for blank or
/// unparseable input. Undecodable bytes raise in Python, so they exit 1 here.
fn payload() -> (Value, String) {
    let mut raw = String::new();
    if std::io::Read::read_to_string(&mut std::io::stdin(), &mut raw).is_err() {
        crash();
    }
    let data = if pystr::strip(&raw).is_empty() {
        Value::Object(Default::default())
    } else {
        serde_json::from_str(&raw).unwrap_or_else(|_| Value::Object(Default::default()))
    };
    (data, raw)
}

/// `tool_input.get(key) or data.get(key)` per key, returning the first value
/// that is a string — the empty string included, which ends the search.
fn command_text(data: &Value) -> String {
    let input = tool_input(data);
    for key in COMMAND_KEYS {
        let value = match input.get(key) {
            Some(value) if !is_falsy(value) => Some(value),
            _ => data.get(key),
        };
        if let Some(text) = value.and_then(Value::as_str) {
            return text.to_string();
        }
    }
    String::new()
}

fn added_lines_only(text: &str) -> String {
    let mut lines = Vec::new();
    for line in pystr::splitlines(text) {
        if PATCH_HEADERS.iter().any(|header| line.starts_with(header)) {
            continue;
        }
        if let Some(rest) = line.strip_prefix(PLUS) {
            lines.push(rest);
        }
    }
    lines.join("\n")
}

/// `str(data.get("tool_name") or data.get("tool") or "")`, needed only for the
/// `apply_patch` containment test.
fn tool_label(data: &Value) -> String {
    pyvalue::first_truthy_py_str(data, TOOL_KEYS)
}

/// The `apply_patch` branch serialises the arguments and keeps their added
/// lines. JSON escapes every newline, so that serialisation is a single line
/// starting with a brace and the branch always falls back to the raw payload —
/// a dead first operand, ported as written.
fn edit_text(data: &Value, raw: &str) -> String {
    let input = tool_input(data);
    if tool_label(data).to_lowercase().contains(PATCH_TOOL_MARKER) {
        let serialised = pyvalue::py_json_dumps(&input);
        let added = added_lines_only(&serialised);
        return if added.is_empty() { added_lines_only(raw) } else { added };
    }
    let mut parts = Vec::new();
    for key in EDIT_KEYS {
        if let Some(text) = input.get(key).and_then(Value::as_str) {
            parts.push(text);
        }
    }
    parts.join("\n")
}

/// `str(Path(value))` — repeated separators collapse and `.` components drop,
/// but `..` survives.
fn pure_path_text(path: &str) -> String {
    let absolute = path.starts_with(SEPARATOR);
    let joined = path
        .split(SEPARATOR)
        .filter(|part| !part.is_empty() && *part != CURRENT_DIR)
        .collect::<Vec<&str>>()
        .join(SEPARATOR);
    if absolute {
        return format!("{SEPARATOR}{joined}");
    }
    if joined.is_empty() {
        return CURRENT_DIR.to_string();
    }
    joined
}

fn read_path(data: &Value) -> Option<String> {
    let input = tool_input(data);
    for key in READ_KEYS {
        let Some(value) = input.get(key) else { continue };
        if is_falsy(value) {
            continue;
        }
        let text = value.as_str()?;
        return Some(pure_path_text(&python_stdlib::expanduser(&pure_path_text(text))));
    }
    None
}

/// `read_text(errors="ignore")` drops undecodable bytes; a lossy decode would
/// splice a replacement character into the middle of a candidate key instead.
fn read_ignoring_errors(path: &str) -> String {
    let Ok(bytes) = std::fs::read(path) else { return String::new() };
    let mut out = String::new();
    let mut rest = bytes.as_slice();
    loop {
        match std::str::from_utf8(rest) {
            Ok(text) => {
                out.push_str(text);
                return out;
            }
            Err(error) => {
                let (good, bad) = rest.split_at(error.valid_up_to());
                out.push_str(std::str::from_utf8(good).unwrap_or_default());
                rest = &bad[error.error_len().unwrap_or(bad.len())..];
            }
        }
    }
}

pub fn run() {
    let (data, raw) = payload();
    if !data.is_object() {
        crash();
    }
    let pattern = forbidden();
    let command = command_text(&data);
    if !command.is_empty() {
        if let Some(sample) = find_forbidden(&pattern, &command) {
            block(COMMAND_REASON, &sample);
        }
        return;
    }
    if let Some(path) = read_path(&data) {
        if std::fs::metadata(&path).map(|meta| meta.is_file()).unwrap_or_default() {
            let sample = read_ignoring_errors(&path);
            if let Some(hit) = find_forbidden(&pattern, &sample) {
                block(&format!("{READ_REASON}{path}"), &hit);
            }
            return;
        }
    }
    let text = edit_text(&data, &raw);
    if !text.is_empty() {
        if let Some(hit) = find_forbidden(&pattern, &text) {
            block(EDIT_REASON, &hit);
        }
    }
}
