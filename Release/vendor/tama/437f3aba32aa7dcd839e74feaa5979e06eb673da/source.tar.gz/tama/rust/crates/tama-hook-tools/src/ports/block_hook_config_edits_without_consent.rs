//! Port of `shared-hooks/block_hook_config_edits_without_consent.py`
//! (registry hook `block-hook-config-edits-without-consent`).
//!
//! Device-level guard: adding or editing hook sources and configs is refused
//! unless the user approved hook changes out of band with
//! `DEVICE_HOOK_EDIT_APPROVED=1`.
//!
//! One deliberate behaviour fix, and only this one. The Python matched
//! `PROTECTED_PATH_RE` against the raw path text, so `shared-hooks/x.py` typed
//! from the repository root walked straight through a gate that caught
//! `/…/tama/shared-hooks/x.py`. Here every candidate path — write-tool
//! targets and the tokens of execution-tool command text alike — is also
//! matched against its resolution under the payload's `cwd` (the process
//! directory when the payload carries none), so the relative and the absolute
//! spelling of the same write are refused together. Resolution only ever adds
//! matches, so nothing the Python blocked is let through.
//!
//! Ported unchanged, including what reads like a bug: the justification-registry
//! exemption is still tested against raw text, so a relative
//! `.shared-hooks/file_justifications.json` stays blocked. And
//! `bash_targets_hook_modification` is not ported at all — `main` never called
//! it, so it has no behaviour to preserve.

use serde_json::Value;
use tama_hooks::session_record::{deny_tool_use, read_payload};

use super::block_hook_config_edits_without_consent_gate::Gate;
use super::pyvalue::{first_truthy_py_str, py_json_dumps, truthy};

const APPROVAL_ENV: &str = "DEVICE_HOOK_EDIT_APPROVED";
const APPROVAL_VALUE: &str = "1";
const DOCS: &[&str] = &["https://tama.wisent.com/docs/hook-management"];
const WRITE_TOOLS: &[&str] = &[
    "write",
    "edit",
    "multiedit",
    "apply_patch",
    "functions.apply_patch",
    "applypatch",
];
const PATCH_TOOLS: &[&str] = &["apply_patch", "functions.apply_patch", "applypatch"];
const EXECUTION_TOOLS: &[&str] = &[
    "bash",
    "eval",
    "ssh",
    "debug",
    "browser",
    "node_repl",
    "mcp__node_repl_js",
];
const TOOL_NAME_KEYS: &[&str] = &["tool_name", "tool", "name"];
const TOOL_INPUT_KEYS: &[&str] = &["tool_input", "input"];
const HOOKSPATH_NEEDLE: &str = "hookspath";
const PATCH_TARGET_NOTE: &str = "apply_patch payload can create/edit hook source/config";

/// The deny banner names at most this many targets (`targets[:5]`).
const MAX_TARGETS_TEXT: &str = "5";

fn max_targets() -> usize {
    MAX_TARGETS_TEXT.parse().unwrap_or_default()
}

fn tool_name(payload: &Value) -> String {
    first_truthy_py_str(payload, TOOL_NAME_KEYS).to_lowercase()
}

/// `payload.get("tool_input") or payload.get("input") or {}`, then `{}` again
/// for anything that is not a mapping.
fn tool_input(payload: &Value) -> Value {
    let chosen = TOOL_INPUT_KEYS
        .iter()
        .filter_map(|key| payload.get(key))
        .find(|value| truthy(value));
    match chosen {
        Some(found) if found.is_object() => found.clone(),
        _ => Value::Object(Default::default()),
    }
}

/// `"hookspath" in json.dumps(value, ensure_ascii=False).lower()`.
fn mentions_git_hookspath(value: &Value) -> bool {
    py_json_dumps(value)
        .to_lowercase()
        .contains(HOOKSPATH_NEEDLE)
}

fn block_reason(targets: &[String]) -> String {
    let docs = DOCS.join(" | ");
    let listed = targets
        .iter()
        .take(max_targets())
        .cloned()
        .collect::<Vec<_>>()
        .join(", ");
    format!(
        "BLOCKED: hook source/config changes are device-level protected. Set {APPROVAL_ENV}=1 \
         outside the agent session before editing hooks. Read hook scope docs: {docs}. \
         Target(s): {listed}"
    )
}

fn write_tool_targets(gate: &Gate, input: &Value, tool: &str) -> Vec<String> {
    let mut paths: Vec<String> = Vec::new();
    gate.candidate_paths(input, &mut paths);
    let mut targets: Vec<String> = paths
        .into_iter()
        .filter(|path| !path.is_empty())
        .filter(|path| {
            gate.protected_path(path)
                || (gate.git_config_path(path) && mentions_git_hookspath(input))
        })
        .collect();
    if targets.is_empty()
        && PATCH_TOOLS.contains(&tool)
        && (gate.command_mentions_protected_path(&py_json_dumps(input))
            || mentions_git_hookspath(input))
    {
        targets.push(PATCH_TARGET_NOTE.to_string());
    }
    targets
}

pub fn run() {
    let parsed = read_payload();
    let payload = match parsed {
        Value::Object(_) => parsed,
        _ => Value::Object(Default::default()),
    };
    let tool = tool_name(&payload);

    let targets = if WRITE_TOOLS.contains(&tool.as_str()) {
        let gate = Gate::new(&payload);
        write_tool_targets(&gate, &tool_input(&payload), &tool)
    } else if EXECUTION_TOOLS.contains(&tool.as_str()) {
        let gate = Gate::new(&payload);
        match gate.execution_targets_hook_modification(&payload) {
            true => vec![format!("{tool} payload can create/edit hook source/config")],
            false => Vec::new(),
        }
    } else {
        return;
    };

    if targets.is_empty() {
        return;
    }
    if std::env::var(APPROVAL_ENV).ok().as_deref() == Some(APPROVAL_VALUE) {
        return;
    }
    deny_tool_use(&block_reason(&targets));
}
