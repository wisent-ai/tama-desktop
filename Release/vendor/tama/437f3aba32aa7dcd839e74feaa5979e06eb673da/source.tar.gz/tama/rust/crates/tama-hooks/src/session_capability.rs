//! Port of `shared-hooks/session-capability.mjs`: structured capability grant
//! normalization and the `AGENT_STRUCTURED_CAPABILITY` environment contract.

use serde_json::{json, Value};

use crate::jsutil;

pub const CAPABILITY_SCHEMA_VERSION: u64 = 2;
pub const CAPABILITY_ENV: &str = "AGENT_STRUCTURED_CAPABILITY";
pub const CAPABILITY_LIFETIMES: [&str; 3] = ["single-use", "expires-at", "current-session"];

/// `/^[a-z][a-z0-9:_-]{0,127}$/`
fn is_valid_tool_name(name: &str) -> bool {
    let b = name.as_bytes();
    !b.is_empty()
        && b.len() <= 128
        && b[0].is_ascii_lowercase()
        && b[1..]
            .iter()
            .all(|&c| c.is_ascii_lowercase() || c.is_ascii_digit() || c == b':' || c == b'_' || c == b'-')
}

/// Port of `normalizeCapabilityGrants`. Returns `None` for any invalid input,
/// otherwise a JSON array of `{ tool }` / `{ tool, actions }` objects with
/// grants merged per tool and sorted by tool name.
///
/// Deviation: JS sorts tools with `localeCompare`; we sort by byte order.
/// For plain ASCII tool names without punctuation these agree.
pub fn normalize_capability_grants(value: &Value) -> Option<Value> {
    let arr = value.as_array()?;
    if arr.is_empty() {
        return None;
    }
    // Insertion-ordered stand-in for the JS `Map` keyed by tool.
    let mut merged: Vec<(String, Option<Vec<String>>)> = Vec::new();
    for grant in arr {
        // `as_object` rejects arrays, matching the JS `!Array.isArray` check.
        let obj = grant.as_object()?;
        let tool = jsutil::trim_js(&jsutil::js_string_or_empty(obj.get("tool"))).to_lowercase();
        if !is_valid_tool_name(&tool) {
            return None;
        }
        let actions: Option<Vec<String>> = match obj.get("actions") {
            None | Some(Value::Null) => None,
            Some(v) => {
                let items = v.as_array()?;
                if items.is_empty() {
                    return None;
                }
                let mut dedup: Vec<String> = Vec::new();
                for item in items {
                    let a =
                        jsutil::trim_js(&jsutil::js_string_or_empty(Some(item))).to_lowercase();
                    if !dedup.contains(&a) {
                        dedup.push(a);
                    }
                }
                if dedup.iter().any(|a| !is_valid_tool_name(a)) {
                    return None;
                }
                Some(dedup)
            }
        };
        match merged.iter_mut().find(|(t, _)| *t == tool) {
            Some(entry) => {
                entry.1 = match (entry.1.take(), actions) {
                    (Some(existing), Some(new_actions)) => {
                        let mut union = existing;
                        for a in new_actions {
                            if !union.contains(&a) {
                                union.push(a);
                            }
                        }
                        union.sort();
                        Some(union)
                    }
                    _ => None,
                };
            }
            None => {
                let actions = actions.map(|mut a| {
                    a.sort();
                    a
                });
                merged.push((tool, actions));
            }
        }
    }
    merged.sort_by(|a, b| a.0.cmp(&b.0));
    Some(Value::Array(
        merged
            .into_iter()
            .map(|(tool, actions)| match actions {
                None => json!({ "tool": tool }),
                Some(a) => json!({ "tool": tool, "actions": a }),
            })
            .collect(),
    ))
}

/// Optional identity cross-checks, mirroring the JS `identity` parameter
/// (fields are only enforced when present and non-empty).
#[derive(Debug, Clone, Default)]
pub struct CapabilityIdentity {
    pub control_key: Option<String>,
    pub release_id: Option<String>,
    pub catalog_checksum: Option<String>,
}

/// `normalizedExpiry`: `Date.parse`, must be finite and in the future,
/// re-emitted via `toISOString()`.
fn normalized_expiry(value: Option<&Value>, now_ms: f64) -> Option<String> {
    let ms = jsutil::parse_date(&jsutil::js_to_string_opt(value))?;
    if !ms.is_finite() || ms <= now_ms {
        return None;
    }
    Some(jsutil::to_iso_string(ms))
}

/// Port of `normalizedCapability`. `active_session_id` is the expected session
/// (pass `""` where the JS caller would pass a falsy value); `now_ms` is
/// `Date.now()` in milliseconds.
pub fn normalized_capability(
    value: &Value,
    active_session_id: &str,
    now_ms: f64,
    identity: &CapabilityIdentity,
) -> Option<Value> {
    if !value.is_object() {
        return None;
    }
    let grants = normalize_capability_grants(value.get("grants").unwrap_or(&Value::Null));
    let lifetime = jsutil::trim_js(&jsutil::js_string_or_empty(value.get("lifetime"))).to_lowercase();
    let control_key = jsutil::trim_js(&jsutil::js_string_or_empty(value.get("controlKey"))).to_string();
    let release_id = jsutil::trim_js(&jsutil::js_string_or_empty(value.get("releaseId"))).to_string();
    let catalog_checksum =
        jsutil::trim_js(&jsutil::js_string_or_empty(value.get("catalogChecksum"))).to_string();

    let schema_ok = value.get("schemaVersion").and_then(Value::as_f64) == Some(2.0);
    let issued_by_ok =
        !jsutil::trim_js(&jsutil::js_string_or_empty(value.get("issuedBy"))).is_empty();
    let nonce_ok = !jsutil::trim_js(&jsutil::js_string_or_empty(value.get("nonce"))).is_empty();
    let session_ok = jsutil::js_string_or_empty(value.get("sessionId")) == active_session_id;
    let identity_ok = |expected: &Option<String>, actual: &str| match expected {
        Some(e) if !e.is_empty() => e == actual,
        _ => true,
    };

    if !schema_ok
        || !issued_by_ok
        || !nonce_ok
        || !session_ok
        || control_key.is_empty()
        || release_id.is_empty()
        || catalog_checksum.is_empty()
        || !identity_ok(&identity.control_key, &control_key)
        || !identity_ok(&identity.release_id, &release_id)
        || !identity_ok(&identity.catalog_checksum, &catalog_checksum)
        || grants.is_none()
        || !CAPABILITY_LIFETIMES.contains(&lifetime.as_str())
    {
        return None;
    }

    let mut normalized = json!({
        "schemaVersion": CAPABILITY_SCHEMA_VERSION,
        "issuedBy": jsutil::js_to_string_opt(value.get("issuedBy")),
        "nonce": jsutil::js_to_string_opt(value.get("nonce")),
        "sessionId": jsutil::js_to_string_opt(value.get("sessionId")),
        "controlKey": control_key,
        "releaseId": release_id,
        "catalogChecksum": catalog_checksum,
        "lifetime": lifetime,
        "grants": grants?,
    });
    match lifetime.as_str() {
        "expires-at" => {
            let expires_at = normalized_expiry(value.get("expiresAt"), now_ms)?;
            normalized["expiresAt"] = json!(expires_at);
        }
        "single-use" => {
            if value.get("remainingUses").and_then(Value::as_f64) != Some(1.0) {
                return None;
            }
            normalized["remainingUses"] = json!(1);
        }
        _ => {}
    }
    Some(normalized)
}

fn upsert_env(env: &mut Vec<(String, String)>, key: &str, value: &str) {
    if let Some(entry) = env.iter_mut().find(|(k, _)| k == key) {
        entry.1 = value.to_string();
    } else {
        env.push((key.to_string(), value.to_string()));
    }
}

/// Port of `capabilityEnvironment`: `process.env` overlaid with `extra`, with
/// `AGENT_STRUCTURED_CAPABILITY` set to `JSON.stringify(capability)` or deleted
/// when no capability is given. Returned as an insertion-ordered list of pairs
/// (duplicate keys are overwritten in place, like JS object spread).
pub fn capability_environment(
    capability: Option<&Value>,
    extra: &[(String, String)],
) -> Vec<(String, String)> {
    let mut env: Vec<(String, String)> = std::env::vars_os()
        .map(|(k, v)| {
            (
                k.to_string_lossy().into_owned(),
                v.to_string_lossy().into_owned(),
            )
        })
        .collect();
    for (k, v) in extra {
        upsert_env(&mut env, k, v);
    }
    match capability {
        Some(c) => {
            let serialized = serde_json::to_string(c).unwrap_or_else(|_| "null".to_string());
            upsert_env(&mut env, CAPABILITY_ENV, &serialized);
        }
        None => env.retain(|(k, _)| k != CAPABILITY_ENV),
    }
    env
}

#[cfg(test)]
mod tests {
    use super::*;

    fn base_capability() -> Value {
        json!({
            "schemaVersion": 2,
            "issuedBy": "issuer",
            "nonce": "abc",
            "sessionId": "sess-1",
            "controlKey": "ck",
            "releaseId": "rel",
            "catalogChecksum": "sum",
            "lifetime": "current-session",
            "grants": [{ "tool": "Bash", "actions": ["Read", "read", "exec"] }],
        })
    }

    #[test]
    fn normalizes_grants() {
        let grants = json!([
            { "tool": "Bash", "actions": ["Exec"] },
            { "tool": "bash", "actions": ["read"] },
            { "tool": "read" },
        ]);
        let out = normalize_capability_grants(&grants).unwrap();
        // "bash" grants merge into a sorted action union; sorted by tool name.
        assert_eq!(
            out,
            json!([{ "actions": ["exec", "read"], "tool": "bash" }, { "tool": "read" }])
        );
    }

    #[test]
    fn wildcard_grant_wins() {
        let grants = json!([
            { "tool": "bash", "actions": ["exec"] },
            { "tool": "bash" },
        ]);
        let out = normalize_capability_grants(&grants).unwrap();
        assert_eq!(out, json!([{ "tool": "bash" }]));
    }

    #[test]
    fn rejects_invalid_grants() {
        assert!(normalize_capability_grants(&json!([])).is_none());
        assert!(normalize_capability_grants(&json!({})).is_none());
        assert!(normalize_capability_grants(&json!([{ "tool": "1bad" }])).is_none());
        assert!(
            normalize_capability_grants(&json!([{ "tool": "ok", "actions": [] }])).is_none()
        );
        assert!(
            normalize_capability_grants(&json!([{ "tool": "ok", "actions": ["BAD!"] }]))
                .is_none()
        );
    }

    #[test]
    fn normalizes_capability() {
        let now = jsutil::now_millis();
        let cap = normalized_capability(
            &base_capability(),
            "sess-1",
            now,
            &CapabilityIdentity::default(),
        )
        .unwrap();
        assert_eq!(cap["grants"], json!([{ "actions": ["exec", "read"], "tool": "bash" }]));

        // Wrong session id.
        assert!(normalized_capability(
            &base_capability(),
            "other",
            now,
            &CapabilityIdentity::default()
        )
        .is_none());
        // Identity mismatch.
        assert!(normalized_capability(
            &base_capability(),
            "sess-1",
            now,
            &CapabilityIdentity {
                control_key: Some("different".into()),
                ..Default::default()
            }
        )
        .is_none());
    }

    #[test]
    fn lifetimes() {
        let now = 1_700_000_000_000.0;
        let identity = CapabilityIdentity::default();

        let mut cap = base_capability();
        cap["lifetime"] = json!("expires-at");
        cap["expiresAt"] = json!("2030-01-01T00:00:00Z");
        let out = normalized_capability(&cap, "sess-1", now, &identity).unwrap();
        assert_eq!(out["expiresAt"], json!("2030-01-01T00:00:00.000Z"));

        // Expired.
        cap["expiresAt"] = json!("2020-01-01T00:00:00Z");
        assert!(normalized_capability(&cap, "sess-1", now, &identity).is_none());

        // single-use requires remainingUses === 1.
        let mut cap = base_capability();
        cap["lifetime"] = json!("single-use");
        assert!(normalized_capability(&cap, "sess-1", now, &identity).is_none());
        cap["remainingUses"] = json!(1);
        assert!(normalized_capability(&cap, "sess-1", now, &identity).is_some());
        cap["remainingUses"] = json!("1"); // string is not === 1
        assert!(normalized_capability(&cap, "sess-1", now, &identity).is_none());
    }
}
