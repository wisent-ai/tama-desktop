#!/usr/bin/env python3
"""Block direct LSI/PARP/NCBR API usage by the agent.

This guard exists because direct server-side writes to the NCBR/LSI form
damaged section 6.5. The allowed path for this system is the real UI flow.

The hook blocks:
- shell commands containing direct API endpoint URLs or endpoint paths;
- running local Python/JS/TS shell scripts whose source contains direct LSI API
  helpers/endpoints;
- creating or editing source files that add direct API calls to LSI/PARP/NCBR.

Read-only inspection commands such as `sed script.py` are allowed unless the
command itself contains a forbidden API URL/path.
"""
from __future__ import annotations

import json
import os
import re
import shlex
import sys
from pathlib import Path


SHELL_TOOLS = {"Bash", "exec_command", "functions.exec_command"}
EDIT_TOOLS = {"Write", "Edit", "apply_patch", "functions.apply_patch", "NotebookEdit"}

SCRIPT_SUFFIXES = {".py", ".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx", ".sh"}
SCAN_EDIT_SUFFIXES = SCRIPT_SUFFIXES | {".ipynb"}

SCRIPT_RUNNERS = {
    "python",
    "python3",
    "node",
    "tsx",
    "bun",
    "deno",
    "ts-node",
    "npx",
    "bash",
    "sh",
    "zsh",
    "dash",
}

READ_ONLY_SHELL_COMMANDS = {
    "sed",
    "cat",
    "nl",
    "less",
    "head",
    "tail",
    "wc",
    "ls",
    "find",
    "jq",
    "sqlite3",
    "python3",  # only read-only when no script source is resolved below
}

ALLOWLIST_PATH_FRAGMENTS = (
    "/.codex/hooks/block_direct_lsi_api.py",
    "/.codex/hooks.json",
)


FORBIDDEN_PATTERNS: tuple[tuple[str, re.Pattern[str]], ...] = (
    (
        "direct LSI API URL",
        re.compile(r"https?://lsi2\.ncbr\.gov\.pl/api/", re.IGNORECASE),
    ),
    (
        "direct PARP/NCBR API URL",
        re.compile(r"https?://(?:[^/\s\"']+\.)?(?:parp|ncbr)\.gov\.pl/api/", re.IGNORECASE),
    ),
    (
        "project registry write/read endpoint",
        re.compile(
            r"/api/beneficiary/(?:project-versions|project-sections|project)/", re.IGNORECASE
        ),
    ),
    (
        "registry values endpoint",
        re.compile(r"\b(?:project-registries|registries-values|collection-objects)\b", re.IGNORECASE),
    ),
    (
        "browser-authenticated API helper",
        re.compile(
            r"\b(?:CDPSession|session\.fetch|page\.evaluate\([^)]*fetch|collection_save_url|"
            r"scalar_save_url|registries_values_url|project_fields_url)\b",
            re.IGNORECASE | re.DOTALL,
        ),
    ),
    (
        "low-level HTTP client targeting LSI",
        re.compile(
            r"\b(?:curl|wget|httpx?|requests\.|fetch\(|urllib\.request)\b[\s\S]{0,300}"
            r"(?:lsi2\.ncbr\.gov\.pl|/api/beneficiary/)",
            re.IGNORECASE,
        ),
    ),
)


def payload() -> dict:
    raw = sys.stdin.read()
    try:
        return json.loads(raw) if raw.strip() else {}
    except json.JSONDecodeError:
        return {}


def is_allowlisted_path(path: str) -> bool:
    return any(fragment in path for fragment in ALLOWLIST_PATH_FRAGMENTS)


def first_executable(command: str) -> str:
    try:
        parts = shlex.split(command)
    except ValueError:
        parts = command.split()
    if not parts:
        return ""
    return Path(parts[0]).name


def scan_text(text: str, label: str) -> list[str]:
    if is_allowlisted_path(label):
        return []
    hits: list[str] = []
    for reason, pattern in FORBIDDEN_PATTERNS:
        if pattern.search(text):
            hits.append(reason)
    return hits


def resolve_script_paths(command: str, cwd: str | None) -> list[Path]:
    try:
        parts = shlex.split(command)
    except ValueError:
        parts = command.split()
    if not parts:
        return []

    paths: list[Path] = []
    for i, token in enumerate(parts):
        name = Path(token).name
        if name not in SCRIPT_RUNNERS and not any(name.startswith(runner) for runner in SCRIPT_RUNNERS):
            continue

        for candidate in parts[i + 1 : i + 5]:
            if candidate.startswith("-"):
                continue
            if candidate in {"run", "--"}:
                continue
            candidate_path = Path(os.path.expanduser(candidate))
            if not candidate_path.suffix or candidate_path.suffix not in SCRIPT_SUFFIXES:
                continue
            if not candidate_path.is_absolute() and cwd:
                candidate_path = Path(cwd) / candidate_path
            if candidate_path.exists() and candidate_path.is_file():
                paths.append(candidate_path)
            break
    return paths


def report(label: str, hits: list[str]) -> None:
    print(
        "BLOCKED: direct LSI/PARP/NCBR API usage is forbidden for this agent.\n"
        f"  target: {label}\n"
        f"  matched: {', '.join(sorted(set(hits)))}\n\n"
        "Use the real UI flow only. Do not call /api/beneficiary, "
        "project-registries, registries-values, or collection-objects directly.",
        file=sys.stderr,
    )


def check_shell(data: dict, tool_input: dict) -> int:
    command = (
        tool_input.get("command")
        or tool_input.get("cmd")
        or data.get("command")
        or data.get("cmd")
        or ""
    )
    if not command:
        return 0

    hits = scan_text(command, "<shell command>")
    if hits:
        report("<shell command>", hits)
        return 2

    exe = first_executable(command)
    cwd = tool_input.get("workdir") or tool_input.get("cwd") or data.get("cwd") or os.getcwd()
    scripts = resolve_script_paths(command, cwd)

    # Pure read-only shell inspection is allowed. Running a script is not
    # read-only, so it is still scanned below.
    if not scripts and exe in READ_ONLY_SHELL_COMMANDS:
        return 0

    for path in scripts:
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        hits = scan_text(text, str(path))
        if hits:
            report(str(path), hits)
            return 2
    return 0


def check_edit(data: dict, tool_input: dict) -> int:
    raw_input = data.get("tool_input")
    label = (
        tool_input.get("file_path")
        or tool_input.get("notebook_path")
        or tool_input.get("path")
        or data.get("tool_name", "<edit>")
    )
    if is_allowlisted_path(str(label)):
        return 0
    if str(label).endswith(tuple(SCAN_EDIT_SUFFIXES)) is False and data.get("tool_name") != "apply_patch":
        return 0

    pieces = []
    if isinstance(raw_input, str):
        pieces.append(raw_input)
    else:
        for key in ("content", "new_string", "patch", "new_source"):
            value = tool_input.get(key)
            if value:
                pieces.append(str(value))
    text = "\n".join(pieces)
    if not text:
        return 0
    hits = scan_text(text, str(label))
    if hits:
        report(str(label), hits)
        return 2
    return 0


def main() -> int:
    data = payload()
    if not data:
        return 0
    tool = data.get("tool_name", "")
    raw_tool_input = data.get("tool_input", {}) or {}
    tool_input = raw_tool_input if isinstance(raw_tool_input, dict) else {}
    if tool in SHELL_TOOLS:
        return check_shell(data, tool_input)
    if tool in EDIT_TOOLS:
        return check_edit(data, tool_input)
    return 0


if __name__ == "__main__":
    sys.exit(main())
