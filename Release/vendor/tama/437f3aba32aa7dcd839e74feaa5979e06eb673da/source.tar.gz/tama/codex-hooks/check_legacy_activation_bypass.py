#!/usr/bin/env python3
"""Device-level guard against legacy activation queue bypasses."""
from __future__ import annotations

import json
import sys
from pathlib import Path


WISENT_ROOT = Path("/Users/lukaszbartoszcze/Documents/CodingProjects/Wisent")
BANNED_ENTRYPOINT = "wisent.scripts.activations." + "extract_and_upload"
BANNED_ENTRYPOINT_PATHS = (
    "wisent/scripts/activations/" + "extract_and_upload.py",
    "wisent-tools/wisent/scripts/activations/" + "extract_and_upload.py",
)
BANNED_UNSET = "unset " + "WISENT_FLEET_STAGING_DIR"
BANNED_STAGING_BYPASS = (
    BANNED_UNSET,
    "export WISENT_FLEET_STAGING_DIR=",
    "WISENT_FLEET_STAGING_DIR=\"\"",
    "WISENT_FLEET_STAGING_DIR=''",
)
BANNED_STRINGS = (
    BANNED_ENTRYPOINT,
    *BANNED_ENTRYPOINT_PATHS,
    *BANNED_STAGING_BYPASS,
)
DIRECT_HF_UPLOAD_MARKERS = (
    "from huggingface_hub import upload_file",
    "from huggingface_hub import upload_folder",
    "upload_file(",
    "upload_folder(",
    "huggingface-cli upload",
    "hf upload",
    "wisent.scripts.activations.migrate_stable_ids import",
    "_flush_batch(",
    "_stage_shard(",
)
DETACHED_UPLOAD_ALLOWLIST_PATH_FRAGMENTS = (
    "/wisent-tools/wisent/scripts/activations/raw/upload_worker.py",
)
ACTIVATION_PATH_FRAGMENTS = (
    "/wisent-tools/wisent/scripts/activations/",
    "/backends/.work/raw_activation_scope/",
)
DIRECT_QUEUE_MARKERS = (
    "gs://wisent-compute/queue/",
    "bucket.blob(\"queue/",
    "bucket.blob(f\"queue/",
    "bucket.blob('queue/",
    "bucket.blob(f'queue/",
    "write_job(\"queue\"",
    "write_job('queue'",
)
QUEUE_ALLOWLIST_PATH_FRAGMENTS = (
    "/wisent-compute/wisent_compute/queue/submit.py",
    "/wisent-compute/wisent_compute/queue/storage.py",
    "/wisent-compute/wisent_compute/queue/listing/",
    "/wisent-compute/wisent_compute/scheduler/",
    "/wisent-compute/wisent_compute/sizing/",
)
TREE_SCAN_PATHS = (
    WISENT_ROOT / "wisent-compute/wisent_compute/models.py",
    WISENT_ROOT / "wisent-compute/wisent_compute/queue/submit.py",
    WISENT_ROOT / "wisent-compute/wisent_compute/providers/local/slots.py",
    WISENT_ROOT / "wisent-tools/wisent/scripts/activations/extract_and_upload.py",
    WISENT_ROOT / "wisent-tools/wisent/scripts/activations/raw/extract_and_upload.py",
    WISENT_ROOT / "wisent-tools/wisent/scripts/activations/raw/upload_worker.py",
    WISENT_ROOT / "backends/.work/raw_activation_scope/scripts/submit_desired_activation_jobs.py",
    WISENT_ROOT / "backends/.work/raw_activation_scope/scripts/patch_queued_desired_commands_upgrade.py",
    WISENT_ROOT / "backends/.work/raw_activation_scope/scripts/diagnostics/submit_single_activation_repair.py",
)
TREE_SCAN_DIRS = (
    WISENT_ROOT / "backends/.work/raw_activation_scope/scripts",
    WISENT_ROOT / "wisent-compute/wisent_compute",
    WISENT_ROOT / "wisent-tools/wisent",
)
SCAN_SUFFIXES = {".py", ".sh", ".json", ".toml", ".yaml", ".yml"}
LEGACY_STUB_PATH = (
    WISENT_ROOT
    / "wisent-tools/wisent/scripts/activations"
    / "extract_and_upload.py"
)
LEGACY_STUB_REQUIRED = (
    "Disabled compatibility stub",
    "foreground activation uploader has been removed",
    "return 64",
)
LEGACY_STUB_FORBIDDEN = (
    "huggingface_hub",
    "HfApi",
    "upload_folder",
    "upload_file",
    "generate-pairs",
    "extract-activations",
)
SHELL_TOOLS = {"Bash", "exec_command", "functions.exec_command"}
EDIT_TOOLS = {
    "Write",
    "Edit",
    "apply_patch",
    "NotebookEdit",
    "functions.apply_patch",
}


def _payload() -> dict:
    raw = sys.stdin.read()
    try:
        return json.loads(raw) if raw.strip() else {}
    except json.JSONDecodeError:
        return {}


def _blocks_in_text(text: str) -> list[str]:
    return [s for s in BANNED_STRINGS if s in text]


def _direct_hf_upload_blocks_in_text(text: str, label: str) -> list[str]:
    if any(fragment in label for fragment in DETACHED_UPLOAD_ALLOWLIST_PATH_FRAGMENTS):
        return []
    if not (
        any(fragment in label for fragment in ACTIVATION_PATH_FRAGMENTS)
        or "wisent.scripts.activations" in text
        or "raw_activations/" in text
    ):
        return []
    return [s for s in DIRECT_HF_UPLOAD_MARKERS if s in text]


def _queue_blocks_in_text(text: str, label: str) -> list[str]:
    if any(fragment in label for fragment in QUEUE_ALLOWLIST_PATH_FRAGMENTS):
        return []
    return [s for s in DIRECT_QUEUE_MARKERS if s in text]


def _is_read_only_shell(command: str) -> bool:
    first = command.strip().split(maxsplit=1)[0] if command.strip() else ""
    return first in {
        "rg",
        "grep",
        "sed",
        "awk",
        "cat",
        "nl",
        "less",
        "tail",
        "head",
        "find",
        "git",
    }


def check_pretool(payload: dict) -> int:
    tool = payload.get("tool_name", "")
    raw_tool_input = payload.get("tool_input", {}) or {}
    tool_input = raw_tool_input if isinstance(raw_tool_input, dict) else {}
    text = ""
    label = tool
    if tool in SHELL_TOOLS:
        command = (
            tool_input.get("command", "")
            or tool_input.get("cmd", "")
            or (str(raw_tool_input) if raw_tool_input else "")
        )
        if _is_read_only_shell(command):
            return 0
        text = command
        label = "bash command"
    elif tool in EDIT_TOOLS:
        label = tool_input.get("file_path") or tool_input.get("notebook_path") or tool
        text = "\n".join(
            str(tool_input.get(key, "") or "")
            for key in ("content", "new_string", "patch", "new_source")
        )
        if not text and raw_tool_input:
            text = str(raw_tool_input)
    else:
        return 0
    hits = _blocks_in_text(text)
    direct_hf_hits = _direct_hf_upload_blocks_in_text(text, label)
    queue_hits = _queue_blocks_in_text(text, label)
    if not hits:
        if not queue_hits and not direct_hf_hits:
            return 0
        if direct_hf_hits:
            print(
                "BLOCKED: foreground HF upload path detected in "
                f"{label}: {', '.join(direct_hf_hits)}\n"
                "Activation upload must go through "
                "wisent.scripts.activations.raw.upload_worker after the GPU "
                "slot is released.",
                file=sys.stderr,
            )
            return 2
        print(
            "BLOCKED: direct queue mutation detected in "
            f"{label}: {', '.join(queue_hits)}\n"
            "Use wisent_compute.queue.submit or the queue storage layer; do "
            "not write queue blobs directly from ad-hoc scripts.",
            file=sys.stderr,
        )
        return 2
    print(
        "BLOCKED: legacy activation bypass detected in "
        f"{label}: {', '.join(hits)}\n"
        "Remove it. Use the raw activation extractor plus detached upload "
        "worker path; do not recreate foreground HF upload jobs.",
        file=sys.stderr,
    )
    return 2


def _iter_tree_files():
    yielded: set[Path] = set()
    for path in TREE_SCAN_PATHS:
        if path.exists() and path not in yielded:
            yielded.add(path)
            yield path
    for root in TREE_SCAN_DIRS:
        if not root.exists():
            continue
        for path in root.rglob("*"):
            if path.is_file() and path.suffix in SCAN_SUFFIXES and path not in yielded:
                yielded.add(path)
                yield path


def _legacy_stub_violations() -> list[str]:
    if not LEGACY_STUB_PATH.exists():
        return []
    try:
        text = LEGACY_STUB_PATH.read_text(errors="ignore")
    except OSError as exc:
        return [f"cannot read disabled stub: {exc}"]
    errors: list[str] = []
    missing = [marker for marker in LEGACY_STUB_REQUIRED if marker not in text]
    if missing:
        errors.append("missing disabled-stub marker(s): " + ", ".join(missing))
    forbidden = [marker for marker in LEGACY_STUB_FORBIDDEN if marker in text]
    if forbidden:
        errors.append("contains foreground-upload implementation marker(s): " + ", ".join(forbidden))
    if len(text.splitlines()) > 60:
        errors.append("disabled stub is too large; legacy implementation appears to be back")
    return errors


def check_tree() -> int:
    violations: list[tuple[Path, str]] = []
    for error in _legacy_stub_violations():
        violations.append((LEGACY_STUB_PATH, error))
    for path in _iter_tree_files():
        if path == LEGACY_STUB_PATH:
            continue
        try:
            text = path.read_text(errors="ignore")
        except OSError:
            continue
        hits = _blocks_in_text(text)
        hits.extend(_direct_hf_upload_blocks_in_text(text, str(path)))
        hits.extend(_queue_blocks_in_text(text, str(path)))
        for hit in hits:
            violations.append((path, hit))
            break
    if not violations:
        return 0
    print(
        "BLOCKED: legacy activation bypass still exists in the Wisent tree. "
        "Remove the code instead of leaving a bypassable legacy path.",
        file=sys.stderr,
    )
    for path, hit in violations:
        print(f"  {path}: {hit}", file=sys.stderr)
    return 2


def main() -> int:
    payload = _payload()
    if payload:
        return check_pretool(payload)
    return check_tree()


if __name__ == "__main__":
    raise SystemExit(main())
