#!/usr/bin/env python3
"""Device-level PreToolUse gate: block raw Overleaf API usage.

Allowed path: a dedicated Weles UI trajectory that drives Overleaf like a user.
Forbidden path: direct calls to Overleaf project JSON/history endpoints, whether
from shell commands, inline snippets, or checked-in helper scripts.
"""
from __future__ import annotations

import json
import os
import re
import shlex
import sys
from pathlib import Path
from typing import Any


MESSAGE = "YOU FUCKING RETARD USE THE DEDICATED WELES TRAJECTORY NOT THE OVERLEAF API"

SHELL_TOOLS = {"Bash", "exec_command", "functions.exec_command"}
EDIT_TOOLS = {"Write", "Edit", "apply_patch", "functions.apply_patch", "NotebookEdit"}

SCRIPT_SUFFIXES = {".py", ".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx", ".sh"}
SCAN_EDIT_SUFFIXES = SCRIPT_SUFFIXES | {".ipynb", ".json", ".jsonl"}

SCRIPT_RUNNERS = {
    "python",
    "python3",
    "node",
    "tsx",
    "bun",
    "deno",
    "ts-node",
    "npx",
    "bash",
    "sh",
    "zsh",
    "dash",
}

READ_ONLY_SHELL_COMMANDS = {
    "sed",
    "cat",
    "nl",
    "less",
    "head",
    "tail",
    "wc",
    "ls",
    "find",
    "jq",
    "sqlite3",
}

ALLOWLIST_PATH_FRAGMENTS = (
    "/.codex/hooks/block_overleaf_api.py",
    "/.codex/hooks.json",
)

PROJECT_ID = r"[0-9a-fA-F]{24}"
PROJECT_PREFIX = rf"(?:https?://(?:www\.)?overleaf\.com)?/project/(?:{PROJECT_ID}|\$\{{?[A-Za-z_][A-Za-z0-9_]*\}}?|['\"]?\s*\+\s*[A-Za-z_][A-Za-z0-9_]*\s*\+\s*['\"]?)"

FORBIDDEN_PATTERNS: tuple[tuple[str, re.Pattern[str]], ...] = (
    (
        "Overleaf updates endpoint",
        re.compile(rf"{PROJECT_PREFIX}/updates\b", re.IGNORECASE),
    ),
    (
        "Overleaf diff endpoint",
        re.compile(rf"{PROJECT_PREFIX}/diff\b", re.IGNORECASE),
    ),
    (
        "Overleaf changes/users endpoint",
        re.compile(rf"{PROJECT_PREFIX}/changes/users\b", re.IGNORECASE),
    ),
    (
        "Overleaf latest/history endpoint",
        re.compile(rf"{PROJECT_PREFIX}/latest/history\b", re.IGNORECASE),
    ),
    (
        "Overleaf entities endpoint",
        re.compile(rf"{PROJECT_PREFIX}/entities\b", re.IGNORECASE),
    ),
    (
        "browser fetch of Overleaf project API",
        re.compile(
            rf"\bfetch\s*\([^)]*/project/(?:{PROJECT_ID}|\$\{{?[A-Za-z_][A-Za-z0-9_]*\}}?)[^)]*/(?:updates|diff|changes/users|latest/history|entities)\b",
            re.IGNORECASE | re.DOTALL,
        ),
    ),
    (
        "HTTP client against Overleaf project API",
        re.compile(
            rf"\b(?:curl|wget|httpx?|requests\.|urllib\.request|fetch\()\b[\s\S]{{0,500}}"
            rf"(?:overleaf\.com)?/project/(?:{PROJECT_ID}|\$\{{?[A-Za-z_][A-Za-z0-9_]*\}}?)[^'\"\s)]*/(?:updates|diff|changes/users|latest/history|entities)\b",
            re.IGNORECASE,
        ),
    ),
)


def load_payload() -> dict[str, Any]:
    raw = sys.stdin.read()
    try:
        return json.loads(raw) if raw.strip() else {}
    except json.JSONDecodeError:
        return {}


def is_allowlisted_path(path: str) -> bool:
    return any(fragment in path for fragment in ALLOWLIST_PATH_FRAGMENTS)


def first_executable(command: str) -> str:
    try:
        parts = shlex.split(command)
    except ValueError:
        parts = command.split()
    if not parts:
        return ""
    return Path(parts[0]).name


def scan_text(text: str, label: str) -> list[str]:
    if is_allowlisted_path(label):
        return []
    hits: list[str] = []
    for reason, pattern in FORBIDDEN_PATTERNS:
        if pattern.search(text):
            hits.append(reason)
    return hits


def collect_strings(value: Any) -> list[str]:
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        out: list[str] = []
        for item in value:
            out.extend(collect_strings(item))
        return out
    if isinstance(value, dict):
        out: list[str] = []
        for item in value.values():
            out.extend(collect_strings(item))
        return out
    return []


def resolve_script_paths(command: str, cwd: str | None) -> list[Path]:
    try:
        parts = shlex.split(command)
    except ValueError:
        parts = command.split()
    if not parts:
        return []

    paths: list[Path] = []
    for i, token in enumerate(parts):
        name = Path(token).name
        if name not in SCRIPT_RUNNERS and not any(name.startswith(runner) for runner in SCRIPT_RUNNERS):
            continue
        for candidate in parts[i + 1 : i + 6]:
            if candidate in {"run", "--"} or candidate.startswith("-"):
                continue
            candidate_path = Path(os.path.expanduser(candidate))
            if candidate_path.suffix not in SCRIPT_SUFFIXES:
                continue
            if not candidate_path.is_absolute() and cwd:
                candidate_path = Path(cwd) / candidate_path
            if candidate_path.exists() and candidate_path.is_file():
                paths.append(candidate_path)
            break
    return paths


def report(label: str, hits: list[str]) -> None:
    print(MESSAGE, file=sys.stderr)
    print(f"BLOCKED: raw Overleaf API usage detected in {label}", file=sys.stderr)
    print(f"matched: {', '.join(sorted(set(hits)))}", file=sys.stderr)


def check_shell(data: dict[str, Any], tool_input: dict[str, Any]) -> int:
    command = (
        tool_input.get("command")
        or tool_input.get("cmd")
        or data.get("command")
        or data.get("cmd")
        or ""
    )
    if not command:
        return 0

    hits = scan_text(command, "<shell command>")
    if hits:
        report("<shell command>", hits)
        return 2

    exe = first_executable(command)
    cwd = tool_input.get("workdir") or tool_input.get("cwd") or data.get("cwd") or os.getcwd()
    scripts = resolve_script_paths(command, cwd)

    if not scripts and exe in READ_ONLY_SHELL_COMMANDS:
        return 0

    for path in scripts:
        if is_allowlisted_path(str(path)):
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        hits = scan_text(text, str(path))
        if hits:
            report(str(path), hits)
            return 2
    return 0


def check_edit(data: dict[str, Any], tool_input: dict[str, Any]) -> int:
    label = (
        tool_input.get("file_path")
        or tool_input.get("notebook_path")
        or tool_input.get("path")
        or data.get("file_path")
        or "<edit payload>"
    )
    label = str(label)
    if is_allowlisted_path(label):
        return 0
    if label != "<edit payload>":
        suffix = Path(label).suffix
        if suffix and suffix not in SCAN_EDIT_SUFFIXES:
            return 0

    text = "\n".join(collect_strings(tool_input)) or "\n".join(collect_strings(data))
    hits = scan_text(text, label)
    if hits:
        report(label, hits)
        return 2
    return 0


def main() -> int:
    data = load_payload()
    tool_name = str(data.get("tool_name") or data.get("tool") or "")
    tool_input = data.get("tool_input") or {}
    if not isinstance(tool_input, dict):
        tool_input = {}

    if tool_name in SHELL_TOOLS or not tool_name:
        shell_result = check_shell(data, tool_input)
        if shell_result:
            return shell_result

    if tool_name in EDIT_TOOLS or not tool_name:
        edit_result = check_edit(data, tool_input)
        if edit_result:
            return edit_result

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
