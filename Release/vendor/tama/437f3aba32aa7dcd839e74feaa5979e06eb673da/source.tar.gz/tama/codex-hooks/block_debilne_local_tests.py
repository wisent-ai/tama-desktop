#!/usr/bin/env python3
import json
import re
import sys


BLOCKED_REPO = "wisent-marketing-asset-generator"
BLOCKED_PATTERNS = [
    r"\bnpm\s+test\b",
    r"\bnode\s+--test\b",
    r"\bnpx\s+vitest\b",
    r"\bnpx\s+jest\b",
    r"\bvitest\b",
    r"\bjest\b",
    r"\bplaywright\s+test\b",
    r"\btest/(cli|context|export-verifier|exporter|image-inspection|loop|producer|reference-adapter|svg|utils|verifier|doctor|model-router-provider|vision)\.test\.mjs\b",
]

BLOCKED_TEST_CATEGORIES = (
    "local files/render/export/verify/hash/path safety"
)


def collect_strings(value):
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for nested in value.values():
            yield from collect_strings(nested)
    elif isinstance(value, list):
        for nested in value:
            yield from collect_strings(nested)


def main():
    raw = sys.stdin.read()
    try:
        payload = json.loads(raw) if raw.strip() else {}
    except Exception:
        payload = {"raw": raw}

    text = "\n".join(collect_strings(payload))
    if BLOCKED_REPO not in text and "/test/" not in text and "npm test" not in text and "node --test" not in text:
        return 0

    for pattern in BLOCKED_PATTERNS:
        if re.search(pattern, text):
            print(
                "BLOCKED: debilne local/dry-run tests are banned here "
                f"({BLOCKED_TEST_CATEGORIES}). Use a real end-to-end check instead.",
                file=sys.stderr,
            )
            return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
