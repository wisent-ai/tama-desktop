#!/usr/bin/env python3
"""Block shell commands that can trigger macOS Keychain permission prompts.

This guard exists because running auth-aware CLIs such as `supabase` can
request access to secrets stored in the user's login keychain and show a
native macOS prompt. Agents must use explicit non-interactive credentials
from already-approved environment/config paths instead of causing keychain UI.
"""
from __future__ import annotations

import json
import re
import sys


SHELL_TOOLS = {"Bash", "exec_command", "functions.exec_command"}


BLOCKED_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    (
        re.compile(r"(^|[;&|()`{}\s])supabase([;&|()`{}\s]|$)", re.IGNORECASE),
        "Supabase CLI can read the 'Supabase CLI' macOS Keychain item and trigger a password prompt.",
    ),
    (
        re.compile(r"(^|[;&|()`{}\s])security([;&|()`{}\s]|$)", re.IGNORECASE),
        "macOS `security` directly accesses Keychain services.",
    ),
    (
        re.compile(r"credential-osxkeychain|git\s+credential\s+(fill|approve|reject)", re.IGNORECASE),
        "Git credential helpers can access macOS Keychain.",
    ),
    (
        re.compile(r"(^|[;&|()`{}\s])gh\s+auth([;&|()`{}\s]|$)", re.IGNORECASE),
        "GitHub CLI auth can access local credential storage.",
    ),
    (
        re.compile(r"(^|[;&|()`{}\s])vercel\s+(login|switch)([;&|()`{}\s]|$)", re.IGNORECASE),
        "Vercel interactive auth can touch local credential storage.",
    ),
    (
        re.compile(r"(^|[;&|()`{}\s])(op|1password)\s+", re.IGNORECASE),
        "1Password CLI can trigger unlock or keychain-backed auth prompts.",
    ),
    (
        re.compile(r"(^|[;&|()`{}\s])aws\s+(sso\s+login|configure\s+sso)([;&|()`{}\s]|$)", re.IGNORECASE),
        "AWS SSO auth is interactive and can open credential prompts.",
    ),
    (
        re.compile(r"(^|[;&|()`{}\s])gcloud\s+auth([;&|()`{}\s]|$)", re.IGNORECASE),
        "Google Cloud auth is interactive and can access local credential storage.",
    ),
    (
        re.compile(r"(^|[;&|()`{}\s])az\s+(login|account\s+get-access-token)([;&|()`{}\s]|$)", re.IGNORECASE),
        "Azure CLI auth can access local credential storage.",
    ),
    (
        re.compile(r"(^|[;&|()`{}\s])(firebase|netlify|heroku|stripe)\s+(login|auth)([;&|()`{}\s]|$)", re.IGNORECASE),
        "Interactive platform CLI auth can trigger local credential prompts.",
    ),
    (
        re.compile(r"(^|[;&|()`{}\s])docker\s+login([;&|()`{}\s]|$)", re.IGNORECASE),
        "Docker login can use the macOS credential/keychain helper.",
    ),
    (
        re.compile(r"(^|[;&|()`{}\s])ssh-add(\s+.*)?(--apple-use-keychain|-K)([;&|()`{}\s]|$)", re.IGNORECASE),
        "ssh-add keychain flags directly interact with macOS Keychain.",
    ),
    (
        re.compile(r"\b(keychain|login-keychain|osxkeychain|macos-keychain)\b", re.IGNORECASE),
        "Command references a keychain-backed credential path.",
    ),
]


def payload() -> dict:
    raw = sys.stdin.read()
    try:
        return json.loads(raw) if raw.strip() else {}
    except json.JSONDecodeError:
        return {}


def command_from(data: dict) -> str:
    raw_tool_input = data.get("tool_input", {}) or {}
    tool_input = raw_tool_input if isinstance(raw_tool_input, dict) else {}
    return (
        tool_input.get("command", "")
        or tool_input.get("cmd", "")
        or data.get("command", "")
        or data.get("cmd", "")
        or (str(raw_tool_input) if raw_tool_input else "")
    )


def blocked_reason(command: str) -> str | None:
    for pattern, reason in BLOCKED_PATTERNS:
        if pattern.search(command):
            return reason
    return None


def main() -> int:
    data = payload()
    if data.get("tool_name", "") not in SHELL_TOOLS:
        return 0

    command = command_from(data)
    reason = blocked_reason(command)
    if reason is None:
        return 0

    print(
        "BLOCKED: command may trigger a native macOS Keychain/auth permission prompt.\n"
        f"  reason: {reason}\n\n"
        "Use a non-interactive path instead: already-approved env vars, an explicit "
        "connection string, service-role API calls, or a checked-in migration script "
        "that does not invoke a keychain-backed CLI.",
        file=sys.stderr,
    )
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
