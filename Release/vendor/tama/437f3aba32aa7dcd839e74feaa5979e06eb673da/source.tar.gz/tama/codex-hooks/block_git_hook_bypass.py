#!/usr/bin/env python3
"""Block Git hook bypass flags before shell commands run."""
from __future__ import annotations

import json
import shlex
import sys
from pathlib import Path


SHELL_TOOLS = {"Bash", "exec_command", "functions.exec_command"}


def payload() -> dict:
    raw = sys.stdin.read()
    try:
        return json.loads(raw) if raw.strip() else {}
    except json.JSONDecodeError:
        return {}


def command_from(data: dict) -> str:
    raw_tool_input = data.get("tool_input", {}) or {}
    tool_input = raw_tool_input if isinstance(raw_tool_input, dict) else {}
    return (
        tool_input.get("command", "")
        or tool_input.get("cmd", "")
        or (str(raw_tool_input) if raw_tool_input else "")
    )


def command_tokens(command: str) -> list[str]:
    try:
        return shlex.split(command)
    except ValueError:
        return command.split()


def is_git_token(token: str) -> bool:
    return Path(token).name == "git"


def has_git_subcommand(tokens: list[str], subcommand: str) -> bool:
    for index, token in enumerate(tokens):
        if is_git_token(token) and subcommand in tokens[index + 1 :]:
            return True
    return False


def commit_short_option_bypasses_hooks(token: str) -> bool:
    return token.startswith("-") and not token.startswith("--") and "n" in token[1:]


def bypass_reason(command: str) -> str | None:
    tokens = command_tokens(command)
    if not any(is_git_token(token) for token in tokens):
        return None

    if "--no-verify" in tokens and (
        has_git_subcommand(tokens, "commit") or has_git_subcommand(tokens, "push")
    ):
        return "git commit/push --no-verify bypasses required hooks"

    if has_git_subcommand(tokens, "commit") and any(
        commit_short_option_bypasses_hooks(token) for token in tokens
    ):
        return "git commit -n bypasses required hooks"

    return None


def main() -> int:
    data = payload()
    if data.get("tool_name", "") not in SHELL_TOOLS:
        return 0

    reason = bypass_reason(command_from(data))
    if reason is None:
        return 0

    print(
        "BLOCKED: Git hook bypass is forbidden for this agent.\n"
        f"  reason: {reason}\n\n"
        "Run commit and push normally so device-level and repo-level hooks execute.",
        file=sys.stderr,
    )
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
