#!/bin/bash
# Register the inline-execution guard on every code-bearing agent tool surface.
set -euo pipefail

ROOT=$(cd "$(dirname "$0")/.." && pwd)
REGISTER="$ROOT/shared-hooks/register-hook.mjs"
HOOK_COMMAND="$HOME/.shared-hooks/block_inline_execution.sh"
NODE=${TAMA_NODE:-$(command -v node || true)}
if [[ -z "$NODE" ]]; then
    for CANDIDATE in /opt/homebrew/bin/node /usr/local/bin/node "$HOME/.local/bin/node"; do
        if [[ -x "$CANDIDATE" ]]; then
            NODE=$CANDIDATE
            break
        fi
    done
fi
if [[ -z "$NODE" ]]; then
    printf '%s\n' "Node.js executable not found"
    exit
fi


for EVENT in \
    pre_tool_use:browser \
    pre_tool_use:debug \
    pre_tool_use:eval \
    pre_tool_use:hub \
    pre_tool_use:mcp__node_repl_js \
    pre_tool_use:node_repl \
    pre_tool_use:notebook \
    pre_tool_use:write
do
    "$NODE" "$REGISTER" block-inline-execution "$EVENT" "$HOOK_COMMAND"
done
