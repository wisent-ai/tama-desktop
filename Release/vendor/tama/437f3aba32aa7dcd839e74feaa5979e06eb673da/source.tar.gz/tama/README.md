<!-- wisent-banner:start -->
<p align="center">
  <img src="assets/readme-banner.webp" alt="tama by Wisent" width="100%">
</p>
<!-- wisent-banner:end -->

<!-- wisent-readme-signals:start -->
[![Source](https://img.shields.io/badge/GitHub-Source-181717?logo=github)](https://github.com/wisent-ai/tama) [![Issues](https://img.shields.io/badge/GitHub-Issues-181717?logo=github)](https://github.com/wisent-ai/tama/issues) [![Wisent](https://img.shields.io/badge/Wisent-Website-0B0B0B)](https://wisent.com) [![Discord](https://img.shields.io/badge/Discord-Join-5865F2?logo=discord&logoColor=white)](https://discord.gg/qRjpkthq54) [![LinkedIn](https://img.shields.io/badge/LinkedIn-Follow-0A66C2?logo=linkedin&logoColor=white)](https://www.linkedin.com/company/wisent-ai/) [![X](https://img.shields.io/badge/X-Follow-000000?logo=x&logoColor=white)](https://x.com/wisentai) [![Enterprise](https://img.shields.io/badge/Enterprise-Book%20a%20call-0B0B0B?logo=calendly)](https://calendly.com/lbartoszcze)
<!-- wisent-readme-signals:end -->

# Tama

Runtime and CLI implementation for **Tama**, Wisent's coding-agent policy
product. The user-facing command is `tama`, and Tama Desktop runs this same CLI
rather than a second implementation.

## Tama CLI

Install from the repository through the canonical npm recipe:

```sh
npm install --global github:wisent-ai/tama
```

Core commands:

```text
tama status --json
tama hooks list --json
tama hooks show <hook-id> --json
tama provider coverage --json
tama install-plan --json
tama install
tama onboarding [--reset] [--policy-bundle <dir>] [--replace]
tama policy import --source <dir> [--replace] [--json]
tama policy list [--json]
tama mcp-config
tama find-violations --repo <path> --json
tama clean --repo <path>
```

The CLI owns catalog inspection, provider coverage, installation planning,
session runtime installation, repository scans and confirmed cleanup. Tama
Desktop is the native view over the same command contract.

## Import an existing policy bundle

First setup can adopt policies from an existing self-contained Tama policy
bundle or sealed release directory without installing or enabling them:

```sh
tama onboarding --policy-bundle /absolute/path/to/tama-bundle
# The same operation remains available after onboarding:
tama policy import --source /absolute/path/to/tama-bundle
tama policy list
```

The supported bundle format contains `shared-hooks/registry.json` and regular,
non-symlink policy files under `shared-hooks/`, `claude-hooks/`,
`codex-hooks/`, `repo-githooks/`, `adaptive/`, `external-hooks/`, and `bin/`.
It also retains existing root `package.json`, `release.json`,
`external-sources.json`, `.wisent-release.json`, `README.md`, and `LICENSE`
files. Other top-level paths are returned in `ignoredPaths`; they are never silently
treated as policy definitions.

Before any store mutation, Tama parses the exact registry, validates the
established catalog, maps every registered source to a selected file, and, for
a sealed release, verifies the `release.json` tree identity. Invalid JSON,
missing source files, empty catalogs, seal mismatches, symlinks, and special
filesystem entries return a rejected result and leave the store unchanged.

Accepted bundles are copied to Tama's editable application-data store and
recorded in `index.json` with canonical source path, source digest, hook count,
timestamp, file modes, and per-file SHA-256 digests. Repeating the same source
and content is `unchanged`. A changed source returns all conflicts by default;
`--replace` updates only a bundle with no untracked or locally changed files.
Other imported bundles are always preserved.

Every result reports imported, unchanged, removed, conflicting, and rejected
counts. Imported bundles are explicitly `inactive`: the operation installs and
enables zero hooks and does not modify `~/.shared-hooks`, Git configuration,
agent configuration, the active Tama release, or the selected source. Activation
remains a separate, explicit install/runtime operation. Skipping import leaves
an empty, usable Tama.
