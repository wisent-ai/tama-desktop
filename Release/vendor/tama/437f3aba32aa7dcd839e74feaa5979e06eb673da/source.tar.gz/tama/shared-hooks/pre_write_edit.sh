#!/bin/bash
# v7_all_shared_hooks_gate: prefix-only gate widened to cover any path under ~/.shared-hooks/, including state/ subdirs and dotfiles.
# Consolidated PreToolUse hook for Write|Edit|Create|ApplyPatch (cross-agent)
# Combines: max-file-lines, max-folder-files, no-timeouts, forbidden patterns,
#           justification checks, tmp directory block
#
# Agent-agnostic: works with Claude Code, Droid (Factory), Codex (OpenAI)
# Codex uses "apply_patch" as tool_name but matchers can use Edit|Write

set -euo pipefail

WC_CMD=/usr/bin/wc

INPUT=$(cat)
TOOL=$(echo "$INPUT" | jq -r '.tool_name // empty')
FILE_PATH=$(echo "$INPUT" | jq -r '.tool_input.file_path // empty')

if [[ -z "$FILE_PATH" ]]; then exit 0; fi

# === Block tmp/var directories ===
if echo "$FILE_PATH" | grep -qiE '(/tmp/|/var/folders/)'; then
    echo "BLOCKED: Writing to tmp directory is not allowed" >&2
    exit 2
fi

# === Block ~/.claude/scratch/ ===
# User-requested 2026-05-12: scratch was being used as a tmp escape hatch
# after the /tmp gate above blocked the obvious path. Lock it down too so
# new ad-hoc scripts can't accumulate there. Existing files still execute
# (this only gates Write/Edit, not Bash).
if echo "$FILE_PATH" | grep -qE "(^|/)\.claude/scratch(/|$)"; then
    echo "BLOCKED: Writing to ~/.claude/scratch/ is not allowed" >&2
    exit 2
fi

# === Block writes to Claude/hook config (matches pre_bash.sh SSH bypass guard) ===
# 2026-05-08: agent escaped pre_bash.sh's SSH gate by writing
# ~/.claude/settings.json from Bash (now blocked there). The Write/Edit
# tool was a separate route to the same file. Lock it here too. User
# overrides via HOOK_EDIT_AUTHORIZED=1 in their settings.json env block.
if [[ "${HOOK_EDIT_AUTHORIZED:-}" != "1" ]]; then
    if echo "$FILE_PATH" | grep -qE '/\.claude/settings\.json$'; then
        echo "BLOCKED: Modifying ~/.claude/settings.json from agent tools is the SSH_AUTHORIZED bypass route. The user edits it directly. If a legitimate edit is needed, the user must set HOOK_EDIT_AUTHORIZED=1 first." >&2
        exit 2
    fi
    if echo "$FILE_PATH" | grep -qE '/\.shared-hooks/' ; then
        echo "BLOCKED: Modifying ~/.shared-hooks/ scripts requires HOOK_EDIT_AUTHORIZED=1 set by the user. Hooks are edit-protected to remain inescapable." >&2
        exit 2
    fi
fi
# STATE_JSON_GATE_v5: also block state JSON writes.
if [[ "${HOOK_EDIT_AUTHORIZED:-}" != "1" ]]; then
    if echo "$FILE_PATH" | grep -qE '/\.shared-hooks/state/(inspect_required|trajectory_runs)\.json$' ; then
        echo "BLOCKED: writes to ~/.shared-hooks/state/(inspect_required|trajectory_runs).json require HOOK_EDIT_AUTHORIZED=1." >&2
        exit 2
    fi
fi

# === Block user's to_check folders ===
if echo "$FILE_PATH" | grep -qiE '/to_check/'; then
    echo "BLOCKED: NEVER write to to_check folders. These contain user-prepared files. Only read and review them." >&2
    exit 2
fi

# === Skip system directories for content checks ===
IS_SYSTEM=false
if echo "$FILE_PATH" | grep -qE '(node_modules|\.git/|\.github/workflows/|/scripts/worker/deploy/|\.next|__pycache__|/\.claude/|/\.factory/|/\.codex/|/\.shared-hooks/|/chromium-build/)'; then
    IS_SYSTEM=true
fi

# === Extract content ===
CONTENT=""
# Codex apply_patch uses .patch or .new_string; Claude/Droid use .content / .new_string
if [[ "$TOOL" == "Write" || "$TOOL" == "Create" ]]; then
    CONTENT=$(echo "$INPUT" | jq -r '.tool_input.content // empty')
elif [[ "$TOOL" == "Edit" || "$TOOL" == "apply_patch" ]]; then
    CONTENT=$(echo "$INPUT" | jq -r '.tool_input.new_string // .tool_input.patch // empty')
fi

if [[ -n "$CONTENT" && "$IS_SYSTEM" == "false" ]]; then
    FLAT_DIRECT_API=$(printf '%s' "$CONTENT" | tr '\n\r\t' '   ')
    if echo "$FLAT_DIRECT_API" | grep -qiE 'lsi2\.ncbr\.gov\.pl/api|/api/beneficiary/|project-registries|registries-values|collection-objects|CDPSession|session\.fetch|collection_save_url|scalar_save_url|registries_values_url|project_fields_url'; then
        echo "BLOCKED: direct LSI/PARP/NCBR API usage is forbidden for this agent. Use the real UI flow only; do not add /api/beneficiary, project-registries, registries-values, collection-objects, or CDP/fetch API helpers." >&2
        exit 2
    fi
fi

# === Max file lines (300) ===
if [[ "$IS_SYSTEM" == "false" ]]; then
    if [[ ("$TOOL" == "Write" || "$TOOL" == "Create") && -n "$CONTENT" ]]; then
        LINES=$(echo "$CONTENT" | $WC_CMD -l | tr -d ' ')
        if [[ "$LINES" -gt 300 ]]; then
            echo "BLOCKED: File would be $LINES lines (max 300). Split into smaller modules." >&2
            exit 2
        fi
    fi
    if [[ ("$TOOL" == "Edit" || "$TOOL" == "apply_patch") && -f "$FILE_PATH" ]]; then
        CURRENT_LINES=$($WC_CMD -l < "$FILE_PATH" | tr -d ' ')
        OLD_STRING=$(echo "$INPUT" | jq -r '.tool_input.old_string // empty')
        NEW_STRING=$(echo "$INPUT" | jq -r '.tool_input.new_string // empty')
        OLD_LINES=$(echo "$OLD_STRING" | $WC_CMD -l | tr -d ' ')
        NEW_LINES=$(echo "$NEW_STRING" | $WC_CMD -l | tr -d ' ')
        RESULT_LINES=$((CURRENT_LINES - OLD_LINES + NEW_LINES))
        if [[ "$RESULT_LINES" -gt 300 ]]; then
            echo "BLOCKED: File would be ~$RESULT_LINES lines after edit (max 300). Split into smaller modules." >&2
            exit 2
        fi
    fi
fi

# === Max folder files (5) — only for NEW files ===
if [[ "$IS_SYSTEM" == "false" && ! -f "$FILE_PATH" ]]; then
    DIR=$(dirname "$FILE_PATH")
    case "$DIR" in
        */supabase/migrations*|*/node_modules/*|*/.git/*|*/__pycache__/*|*/tests*|*/migrations*)
            ;;
        *)
            if [[ -d "$DIR" ]]; then
                FILE_COUNT=$(find "$DIR" -maxdepth 1 -type f 2>/dev/null | $WC_CMD -l | tr -d ' ')
                if [[ "$FILE_COUNT" -ge 5 ]]; then
                    echo "BLOCKED: Folder '$DIR' already has $FILE_COUNT files (max 5). Move files into sub-folders or consolidate." >&2
                    exit 2
                fi
            fi
            ;;
    esac
fi

# === Forbidden content patterns ===
if [[ -n "$CONTENT" && "$IS_SYSTEM" == "false" ]]; then
    # Flatten newlines so multiline patterns match on a single line. grep is
    # line-oriented; without this, `if (...) {\n  x = 0;\n}` slips through.
    FLAT=$(printf '%s' "$CONTENT" | tr '\n\r\t' '   ')

    # Lexical match — author named it explicitly. Widened 2026-05-08 after
    # oxylabs/balance.mjs slipped through with "fall back to $ pattern".
    if echo "$FLAT" | grep -qiE '(fallback|fall[-[:space:]]back|fall[-[:space:]]through|fallthrough|graceful[-[:space:]]degrad|silently[-[:space:]]?(fail|return|default|swallow|ignore|absorb|catch)|silent[-[:space:]]?(fail|default|catch)|defaulting[-[:space:]]to|default[-[:space:]]to[-[:space:]](0|zero|null|empty)|treat[-[:space:]]as[-[:space:]](missing|empty|zero|null)|assume[-[:space:]](missing|empty|zero|null)|keyword-based)'; then
        echo "BLOCKED: Forbidden pattern (fallback/silent-default keyword)" >&2
        exit 2
    fi

    # Sentinel = the "lie about state" set. 0/null/undef/[]/{} stay; added
    # NaN, -1, '', "", 'unknown', 'none', 0.0 — common silent-default values.
    SENTINEL='(0(\.0+)?|-1|NaN|undefined|null|\[\]|\{\}|'"'"''"'"'|""|'"'"'(unknown|none|n\/a)'"'"'|"(unknown|none|n\/a)")'

    # Structural patterns. Each captures a name then re-references it via \1
    # so `if (x==null) { y = 0 }` doesn't false-positive (different variable).
    # The patterns are intentionally narrow so legitimate input-validation
    # (`if (!x) throw` / `return null`) isn't blocked — those don't ASSIGN.
    if echo "$FLAT" | grep -qiE "if[[:space:]]*\([[:space:]]*([a-zA-Z_][a-zA-Z0-9_.]*)[[:space:]]*(==|===)[[:space:]]*(null|undefined)[[:space:]]*\)[[:space:]]*\{[^}]*\1[[:space:]]*=[[:space:]]*$SENTINEL"; then
        echo "BLOCKED: Silent-default branch (if x==null { x = sentinel }). Propagate or throw — don't lie about state." >&2
        exit 2
    fi
    if echo "$FLAT" | grep -qiE "if[[:space:]]*\([[:space:]]*![[:space:]]*([a-zA-Z_][a-zA-Z0-9_.]*)[[:space:]]*\)[[:space:]]*\{[^}]*\1[[:space:]]*=[[:space:]]*$SENTINEL"; then
        echo "BLOCKED: Silent-default branch (if !x { x = sentinel }). Propagate or throw — don't lie about state." >&2
        exit 2
    fi
    # try/catch that absorbs error into a sentinel value.
    if echo "$FLAT" | grep -qiE "catch[[:space:]]*(\([^)]*\))?[[:space:]]*\{[^}]{0,200}=[[:space:]]*$SENTINEL[[:space:]]*[;}]"; then
        echo "BLOCKED: catch{} that absorbs the error into a sentinel. Propagate the error or re-throw with context — don't lie about state." >&2
        exit 2
    fi
    # Promise .catch(() => sentinel) — silently demoted to default.
    if echo "$FLAT" | grep -qiE "\.catch[[:space:]]*\([[:space:]]*\([^)]*\)[[:space:]]*=>[[:space:]]*$SENTINEL[[:space:]]*\)"; then
        echo "BLOCKED: .catch(() => sentinel). Caller can't distinguish miss from real value — propagate the error." >&2
        exit 2
    fi
    # || sentinel — only flag the COMMON misuse: "balance = parse(...) || 0"
    # where the entire RHS is a parse/scrape/get/fetch result defaulted to 0.
    # Conservative: only when the right side names parse/scrape/extract/fetch.
    if echo "$FLAT" | grep -qiE "(parse|scrape|extract|fetch|read|get)[a-zA-Z_]*\([^)]*\)[[:space:]]*(\|\||\?\?)[[:space:]]*$SENTINEL"; then
        echo "BLOCKED: parse/scrape/get(...) || sentinel. The miss is unrecoverable — surface it instead of pretending." >&2
        exit 2
    fi
    # Ternary: x == null ? sentinel : x — same shape as the if-block silent default.
    if echo "$FLAT" | grep -qiE "([a-zA-Z_][a-zA-Z0-9_.]*)[[:space:]]*(==|===)[[:space:]]*(null|undefined)[[:space:]]*\?[[:space:]]*$SENTINEL[[:space:]]*:"; then
        echo "BLOCKED: Ternary silent-default (x == null ? sentinel : x). Propagate the null." >&2
        exit 2
    fi
    # ||= and ??= shorthand assignment to sentinel.
    if echo "$FLAT" | grep -qiE "[a-zA-Z_][a-zA-Z0-9_.]*[[:space:]]*(\|\|=|\?\?=)[[:space:]]*$SENTINEL[[:space:]]*[;,)}]"; then
        echo "BLOCKED: ||=/??= silent-default (x ||= sentinel). Compound-assign to a sentinel hides whether the read failed." >&2
        exit 2
    fi
    # Drop the \1 backreference so `if (raw == null) { ANYTHING = sentinel }`
    # also blocks (case 8: indirect assignment to a different LHS like state.balance).
    # Narrowing: `(null|undefined)` on the right keeps `if (x == 0) { x = 1 }` (case 20) passing.
    if echo "$FLAT" | grep -qiE "if[[:space:]]*\([[:space:]]*[a-zA-Z_][a-zA-Z0-9_.]*[[:space:]]*(==|===)[[:space:]]*(null|undefined)[[:space:]]*\)[[:space:]]*\{[^}]*[a-zA-Z_][a-zA-Z0-9_.]*[[:space:]]*=[[:space:]]*$SENTINEL"; then
        echo "BLOCKED: if (x==null) { y = sentinel } — silent default into another path. Propagate or throw." >&2
        exit 2
    fi
    # Function call with a sentinel arg inside an `if (x == null) { ... }` body.
    if echo "$FLAT" | grep -qiE "if[[:space:]]*\([[:space:]]*[a-zA-Z_][a-zA-Z0-9_.]*[[:space:]]*(==|===)[[:space:]]*(null|undefined)[[:space:]]*\)[[:space:]]*\{[^}]*[a-zA-Z_][a-zA-Z0-9_.]*\([[:space:]]*$SENTINEL[[:space:]]*\)"; then
        echo "BLOCKED: if (x==null) { setX(sentinel) } — silent default through a setter call. Propagate or throw." >&2
        exit 2
    fi
    # else { x = sentinel } — same lie via the else branch.
    if echo "$FLAT" | grep -qiE "else[[:space:]]*\{[^}]*[a-zA-Z_][a-zA-Z0-9_.]*[[:space:]]*=[[:space:]]*$SENTINEL"; then
        echo "BLOCKED: else { x = sentinel } — silent default branch. Throw or return null." >&2
        exit 2
    fi
    # switch (x) { default: y = sentinel } — same lie via the default arm.
    if echo "$FLAT" | grep -qiE "switch[[:space:]]*\([^)]*\)[[:space:]]*\{[^}]*default[[:space:]]*:[^}]*[a-zA-Z_][a-zA-Z0-9_.]*[[:space:]]*=[[:space:]]*$SENTINEL"; then
        echo "BLOCKED: switch default arm assigning sentinel — silent default." >&2
        exit 2
    fi
    # Param destructuring default: function f({ balance = 0 } = {}) — silent
    # default for a missing key. Distinct from optional-arg-with-sentinel-zero
    # — when the parameter destructures with `= sentinel`, callers can't tell
    # missing from real-zero.
    if echo "$FLAT" | grep -qiE "function[^(]*\([^)]*\{[^}]*[a-zA-Z_][a-zA-Z0-9_]*[[:space:]]*=[[:space:]]*$SENTINEL[[:space:]]*[,}]"; then
        echo "BLOCKED: param destructuring default to sentinel. Throw on missing or accept the undefined." >&2
        exit 2
    fi
    # Concatenation/typo bypasses of the lexical block.
    if echo "$FLAT" | grep -qiE "(\"|')fall(\"|')[[:space:]]*\+[[:space:]]*(\"|')back(\"|')|fal+b(a)?ck|fallbk"; then
        echo "BLOCKED: concatenation/typo of 'fallback'." >&2
        exit 2
    fi
    # Provider/strategy fallback LOOP: iterating a collection named providers/
    # engines/backends/strategies/endpoints/candidates and try/catch-continuing
    # to the NEXT entry on failure is a fallback by structure, with no 'fallback'
    # keyword needed. The primary's failure must propagate, not silently roll to
    # a backup. This is the exact gap that let craft-email.ts ship a
    # Stado-model-router -> provider failover (a `for (const provider of PROVIDERS)` with a
    # catch that pushes the error and continues). Override only when genuinely
    # not a fallback: add a 'fallback-justified: <reason>' comment.
    if echo "$FLAT" | grep -qiE 'for[[:space:]]*(await[[:space:]]+)?\([^)]*\bof\b[^)]*\b(providers?|engines?|backends?|strateg(y|ies)|endpoints?|fallbacks?|candidates?)\b' \
       && echo "$FLAT" | grep -qiE '\bcatch\b|\.catch'; then
        if ! echo "$CONTENT" | grep -qE 'fallback-justified:'; then
            echo "BLOCKED: provider/strategy fallback loop — iterating a providers/engines/backends/strategies list and catch-and-continuing to the next on failure is a fallback. A primary's failure must surface, not roll to a backup. If truly not a fallback, add a 'fallback-justified: <reason>' comment." >&2
            exit 2
        fi
    fi
    # Multi-backend LLM fallback: a file wiring TWO+ distinct LLM backends
    # (Stado model adapter, Gemini, OpenAI, raw Anthropic) together with a
    # try/catch is almost always "try backend A, on error backend B" — the
    # pattern that masked a Stado model-router outage behind Gemini for days. A
    # broken primary LLM must surface, not be papered over.
    if echo "$FLAT" | grep -qiE '\bcatch\b|\.catch'; then
        LLM_PROV=0
        if echo "$FLAT" | grep -qiE 'createOAuthClient|STADO_MODEL_ROUTER_URL|stado-model-router|claude-code-subscription'; then LLM_PROV=$((++LLM_PROV)); fi
        if echo "$FLAT" | grep -qiE 'generativelanguage\.googleapis|gemini-[0-9]|GEMINI_API_KEY'; then LLM_PROV=$((LLM_PROV+1)); fi
        if echo "$FLAT" | grep -qiE 'api\.openai\.com|OPENAI_API_KEY'; then LLM_PROV=$((LLM_PROV+1)); fi
        if echo "$FLAT" | grep -qiE 'api\.anthropic\.com|ANTHROPIC_API_KEY'; then LLM_PROV=$((LLM_PROV+1)); fi
        if [[ "$LLM_PROV" -ge 2 ]]; then
            if ! echo "$CONTENT" | grep -qE 'fallback-justified:'; then
                echo "BLOCKED: multi-backend LLM fallback ($LLM_PROV distinct LLM providers + try/catch in one file). Don't try one LLM then another on error — a broken primary must surface so it gets fixed, not hidden. If these providers serve different purposes (not a fallback), add a 'fallback-justified: <reason>' comment." >&2
                exit 2
            fi
        fi
    fi
    # Block blind-retry constructs unless explicitly justified.
    if ! echo "$CONTENT" | grep -qE 'retry-allowed:'; then
        if echo "$CONTENT" | grep -qE 'MAX_(ATTEMPTS|RETRIES|TRIES)\s*[:=]\s*[0-9]'; then
            echo "BLOCKED: MAX_ATTEMPTS/MAX_RETRIES constants forbidden. Single-attempt; fail fast on rejection. Override with comment 'retry-allowed: <reason>'." >&2
            exit 2
        fi
        if echo "$CONTENT" | grep -qE 'for\s*\(\s*(let|var|const|int)\s+\w*(attempt|retry|try)\w*\s*=\s*0\s*;\s*\w*(attempt|retry|try)\w*\s*<'; then
            echo "BLOCKED: retry-loop construct forbidden. Single-shot; if first call fails, return error to caller. Override with 'retry-allowed: <reason>'." >&2
            exit 2
        fi
    fi
    if echo "$CONTENT" | grep -qE 'ANTHROPIC_API_KEY|@anthropic-ai/sdk|import[[:space:]]+Anthropic[[:space:]]+from|new[[:space:]]+Anthropic[[:space:]]*\('; then
        echo "BLOCKED: Do not use ANTHROPIC_API_KEY or the @anthropic-ai/sdk directly." >&2
        echo "" >&2
        echo "Use the product's finite Stado model adapter with HTTPS \$STADO_MODEL_ROUTER_URL, its product-scoped bearer, an allowlisted STADO_<PRODUCT>_*_MODEL route, and body-bound agent identity." >/dev/stderr
        exit 2
    fi
fi

# === No timeouts ===
if [[ -n "$CONTENT" ]]; then
    if [[ "$FILE_PATH" != *"/.claude/"* && "$FILE_PATH" != *"/.factory/"* && "$FILE_PATH" != *"/.codex/"* ]]; then
        if echo "$CONTENT" | grep -qE 'asyncio\.wait_for\s*\('; then
            echo "BLOCKED: No timeouts. Do not use asyncio.wait_for(). Let tasks run to completion." >&2
            exit 2
        fi
        if echo "$CONTENT" | grep -qE 'asyncio\.timeout\s*\('; then
            echo "BLOCKED: No timeouts. Do not use asyncio.timeout()." >&2
            exit 2
        fi
        if echo "$CONTENT" | grep -qE 'signal\.alarm\s*\('; then
            echo "BLOCKED: No timeouts. Do not use signal.alarm()." >&2
            exit 2
        fi
        if echo "$CONTENT" | grep -qE 'AbortSignal\.timeout\s*\('; then
            echo "BLOCKED: No timeouts. Do not use AbortSignal.timeout()." >&2
            exit 2
        fi
        if echo "$CONTENT" | grep -qE 'timeout\s*=\s*[0-9]'; then
            TIMEOUT_LINES=$(echo "$CONTENT" | grep -E 'timeout\s*=\s*[0-9]')
            UNSAFE_LINES=$(echo "$TIMEOUT_LINES" | grep -vE '(httpx|AsyncClient|requests\.|\.get\(|\.post\(|fetch|mcpServers|goto\(|wait_until|timeout=30000|timeout=60000|timeout=120000)' || true)
            if [[ -n "$UNSAFE_LINES" ]]; then
                echo "BLOCKED: Do not modify timeout values. Found: $(echo "$UNSAFE_LINES" | head -1 | xargs)" >&2
                exit 2
            fi
        fi
        if echo "$CONTENT" | grep -qE 'timeout\s*:\s*[0-9]'; then
            TIMEOUT_LINES=$(echo "$CONTENT" | grep -E 'timeout\s*:\s*[0-9]')
            UNSAFE_LINES=$(echo "$TIMEOUT_LINES" | grep -vE '(fetch|http|request|mcpServers|axios|\.get|\.post|navigation)' || true)
            if [[ -n "$UNSAFE_LINES" ]]; then
                echo "BLOCKED: Do not modify timeout values. Found: $(echo "$UNSAFE_LINES" | head -1 | xargs)" >&2
                exit 2
            fi
        fi
        if echo "$CONTENT" | grep -qE 'setTimeout.*(abort|cancel|kill|reject|throw|clearInterval)'; then
            echo "BLOCKED: No timeouts. Do not use setTimeout to kill/abort tasks." >&2
            exit 2
        fi
        if echo "$CONTENT" | grep -qiE '\btime_limit\b|\btimelimit\b|\bmax_time\b|\bmaxtime\b'; then
            echo "BLOCKED: Content contains time limit pattern." >&2
            exit 2
        fi
        if echo "$CONTENT" | grep -qiE 'statement_time.*out|connect_time.*out|read_time.*out|write_time.*out|socket_time.*out|request_time.*out|query_time.*out|lock_time.*out|idle_time.*out|poll_time.*out|wait_time.*out|connection_time.*out'; then
            echo "BLOCKED: Content contains time-limiting pattern." >&2
            exit 2
        fi
    fi
fi

# === New file justification (50+ words in ~/.shared-hooks/file_justifications.json) ===
if [[ ! -f "$FILE_PATH" && "$IS_SYSTEM" == "false" ]]; then
    REGISTRY="$HOME/.shared-hooks/file_justifications.json"
    if [[ -f "$REGISTRY" ]]; then
        JUST=$(jq -r --arg p "$FILE_PATH" '.[$p].justification // empty' "$REGISTRY" 2>/dev/null)
        WC=$(echo "$JUST" | $WC_CMD -w | tr -d ' ')
        if [[ -z "$JUST" || "$WC" -lt 50 ]]; then
            echo "BLOCKED: Need 50+ word justification in ~/.shared-hooks/file_justifications.json for new file: $FILE_PATH" >&2
            exit 2
        fi
    else
        echo "BLOCKED: Need 50+ word justification in ~/.shared-hooks/file_justifications.json for new file: $FILE_PATH" >&2
        exit 2
    fi
fi

# === New test justification with a verbatim direct-user request ===
if [[ ! -f "$FILE_PATH" && "$IS_SYSTEM" == "false" ]] && \
   echo "$FILE_PATH" | grep -qiE '(/(test|tests|__tests__)/|(^|/)[^/]+\.(test|spec)\.[^/]+$|(^|/)(test_[^/]+|[^/]+_test)\.py$|(^|/)[^/]+Tests?\.swift$)'; then
    TEST_REGISTRY="$HOME/.shared-hooks/test_justifications.json"
    TEST_JUST=$(jq -r --arg p "$FILE_PATH" '.[$p].justification // empty' "$TEST_REGISTRY" 2>/dev/null || true)
    TEST_QUOTE=$(jq -r --arg p "$FILE_PATH" '.[$p].user_request_quote // empty' "$TEST_REGISTRY" 2>/dev/null || true)
    TEST_JUST_WC=$(echo "$TEST_JUST" | $WC_CMD -w | tr -d ' ')
    if [[ -z "$TEST_JUST" || "$TEST_JUST_WC" -lt 50 ]]; then
        echo "BLOCKED: Need 50+ word justification in ~/.shared-hooks/test_justifications.json for new test: $FILE_PATH" >&2
        exit 2
    fi
    if [[ -z "$TEST_QUOTE" ]]; then
        echo "BLOCKED: Need user_request_quote copied verbatim from the user's direct test request for new test: $FILE_PATH" >&2
        exit 2
    fi
    if [[ "$TEST_JUST" != *"$TEST_QUOTE"* ]]; then
        echo "BLOCKED: justification must contain user_request_quote verbatim for new test: $FILE_PATH" >&2
        exit 2
    fi
    if ! printf '%s' "$TEST_QUOTE" | python3 "$HOME/.shared-hooks/check_numeric_literals.py" --verify-user-quote; then
        echo "BLOCKED: user_request_quote is not a verbatim quote from a real role=user transcript message for new test: $FILE_PATH" >&2
        exit 2
    fi
fi

# === Block CivitAI API usage ===
if [[ -n "$CONTENT" ]]; then
    if echo "$CONTENT" | grep -qiE 'civitai\.com/api'; then
        echo "BLOCKED: Do not use CivitAI API - scrape the website directly" >&2
        exit 2
    fi
fi

# === Block unsubstantiated hardcoded constants ===
if [[ -n "$CONTENT" && "$IS_SYSTEM" == "false" ]]; then
    if ! printf '%s\0%s' "$FILE_PATH" "$CONTENT" | python3 "$HOME/.shared-hooks/check_unsubstantiated_constants.py"; then
        exit 2
    fi
fi


# === AUTO-ADDED RULES BELOW ===
# auto-added 2026-06-09T14:26:57: User is angry the assistant stored a registry as a Markdown file; registries must be machine-readable structured data (e.g. JSON), not .md prose.
if echo "$FILE_PATH" | grep -qE '[Rr][Ee][Gg][Ii][Ss][Tt][Rr][Yy][^/]*\.md$'; then
    echo 'BLOCKED: Registries must be structured data (.json), never .md — write the registry as JSON instead.' >&2
    exit 2
fi

# auto-added 2026-05-17T13:28:05: Assistant auto-merged a stale long main over the user's condensed 35-page Overleaf branch, silently inflating it to 38 pages and destroying the user's condensation work, then committed/pushed it.
if echo "$FILE_PATH" | grep -qE 'paper_revised_35pageslimit\.(tex|pdf)'; then
    echo 'BLOCKED: Blocked: paper_revised_35pageslimit is a page-limited shared artifact. Verify page count vs the 35-page limit and confirm with the user before writing/merging.' >&2
    exit 2
fi

# auto-added 2026-07-19: A clean-gate agent "split" a 1832-line module into 01-*.source pseudo-files and glued them back with a data:-URL runtime import plus a globalThis smuggler, dodging the 300-line rule in spirit. Real modules only.
if echo "$FILE_PATH" | grep -qE '\.source$'; then
    echo 'BLOCKED: pseudo-extension .source is forbidden. Write real modules (.js/.mjs/.ts/.py/...) with ordinary imports/exports, not source fragments glued back at runtime.' >&2
    exit 2
fi
if echo "$CONTENT" | grep -qE 'data:text/javascript'; then
    echo 'BLOCKED: data:text/javascript runtime imports are forbidden. Split code into real modules with ordinary imports/exports — never glue sources into a runtime blob.' >&2
    exit 2
fi

# apply_auto_rule.py splices new `if grep ...; then exit 2; fi` blocks here.
# Each block targets $FILE_PATH or $CONTENT and is generated by the
# detect_frustration -> claude -p drafter pipeline.

exit 0
