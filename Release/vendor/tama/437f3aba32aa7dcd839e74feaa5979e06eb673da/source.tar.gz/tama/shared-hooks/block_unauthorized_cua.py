#!/usr/bin/env python3
"""Block CUA unless a current-session direct user quote authorizes its scope."""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Any

CUA_TOOL_RE = re.compile(r"(?:^|[._-])(?:cua|computer[ _-]?use)(?:[._-]|$)", re.I)
CUA_CLI_RE = re.compile(r"(?:^|[/\s;&|])cua-driver\s+([a-z][a-z0-9_-]*)", re.I)
CUA_DIRECT_TOOL_ACTION_RE = re.compile(r"(?:cua|computer[ _-]?use).*?__([a-z][a-z0-9_-]*)$", re.I)
DIRECT_CONSENT_RE = re.compile(
    r"\b(?:zgadzam\s+si[eę]|wyra[zż]am\s+zgod[eę]|pozwalam(?:\s+ci)?|"
    r"zezwalam(?:\s+ci)?|autoryzuj[eę]|upowa[zż]niam|masz\s+moj[aą]\s+zgod[eę]|"
    r"mo[zż]esz\s+u[zż]y[cć]|i\s+consent|i\s+authorize|i\s+allow|"
    r"you\s+have\s+my\s+permission|you\s+may\s+use)\b",
    re.I,
)
DIRECT_IMPERATIVE_RE = re.compile(
    r"^\s*(?:(?:prosz[eę]|please)\s+)?"
    r"(?:u[zż]yj|uruchom|otw[oó]rz|steruj|sprawd[zź]|kliknij|wpisz|"
    r"use|enable|open|drive|inspect|click|type)\b",
    re.I,
)
CUA_QUOTE_RE = re.compile(r"\b(?:cua(?:-driver)?|computer[ _-]?use)\b", re.I)
PID_RE = re.compile(r'(?:"pid"\s*:\s*|--pid(?:=|\s+))(\d+)')
JUSTIFICATIONS_PATH = Path(os.environ.get(
    "TAMA_CUA_JUSTIFICATIONS",
    str(Path.home() / ".shared-hooks" / "cua_justifications.json"),
))
SESSION_ROOT = Path(os.environ.get(
    "TAMA_OMP_SESSION_ROOT",
    str(Path.home() / ".omp" / "agent" / "sessions"),
))
TAMA_BUNDLE_ID = "ai.wisent.tama.desktop"
TAMA_EXECUTABLE = "/Tama.app/Contents/MacOS/Tama"


def load_payload() -> dict[str, Any]:
    try:
        value = json.loads(sys.stdin.read() or "{}")
    except json.JSONDecodeError:
        return {}
    return value if isinstance(value, dict) else {}

def tool_name(payload: dict[str, Any]) -> str:
    value = payload.get("tool_name") or payload.get("tool") or payload.get("name")
    if isinstance(value, dict):
        value = value.get("name") or value.get("tool_name")
    return str(value or "")


def tool_input(payload: dict[str, Any]) -> dict[str, Any]:
    value = payload.get("tool_input") or payload.get("input")
    if isinstance(value, dict):
        return value
    nested = payload.get("tool")
    if isinstance(nested, dict):
        value = nested.get("input") or nested.get("tool_input")
        if isinstance(value, dict):
            return value
    return {}


def cua_action(payload: dict[str, Any]) -> str | None:
    name = tool_name(payload)
    direct = CUA_DIRECT_TOOL_ACTION_RE.search(name)
    if direct:
        return direct.group(1).replace("-", "_").lower()
    path = tool_input(payload).get("path")
    wrapped = CUA_DIRECT_TOOL_ACTION_RE.search(path) if isinstance(path, str) else None
    if wrapped:
        return wrapped.group(1).replace("-", "_").lower()
    text = "\n".join(strings(tool_input(payload)))
    cli = CUA_CLI_RE.search(f" {text}")
    return cli.group(1).replace("-", "_").lower() if cli else None


def is_cua_operation(payload: dict[str, Any]) -> bool:
    name = tool_name(payload)
    if CUA_TOOL_RE.search(name):
        return True
    inp = tool_input(payload)
    path = inp.get("path")
    if isinstance(path, str) and re.match(r"^xd://(?:mcp__)?(?:cua|computer[ _-]?use)", path, re.I):
        return True
    lowered_name = name.casefold()
    executable_payload = (
        lowered_name in {"bash", "functions.bash", "eval", "functions.eval", "mcp__node_repl_js"}
        or (
            lowered_name in {"hub", "functions.hub"}
            and str(inp.get("op") or "").casefold() == "start"
        )
        or (
            lowered_name in {"write", "functions.write"}
            and isinstance(path, str)
            and path.casefold().startswith("xd://mcp__node_repl_js")
        )
    )
    return executable_payload and CUA_CLI_RE.search(
        f" {' '.join(strings(inp))}"
    ) is not None


def strings(value: Any):
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for item in value.values():
            yield from strings(item)
    elif isinstance(value, list):
        for item in value:
            yield from strings(item)


def user_content_contains(value: Any, quote: str) -> bool:
    if isinstance(value, dict):
        if value.get("role") == "user" and quote in "\n".join(strings(value.get("content"))):
            return True
        return any(user_content_contains(item, quote) for item in value.values())
    if isinstance(value, list):
        return any(user_content_contains(item, quote) for item in value)
    return False


def quote_is_in_current_session(session_id: str, quote: str) -> bool:
    if not session_id or not quote or not SESSION_ROOT.is_dir():
        return False
    for path in SESSION_ROOT.rglob(f"*{session_id}*.jsonl"):
        try:
            for line in path.read_text(errors="replace").splitlines():
                try:
                    value = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if user_content_contains(value, quote):
                    return True
        except OSError:
            continue
    return False


def quote_directly_authorizes(
    entry: dict[str, Any],
    quote: str,
    strict_actions: bool,
) -> bool:
    if not CUA_QUOTE_RE.search(quote) or not (
        DIRECT_CONSENT_RE.search(quote) or DIRECT_IMPERATIVE_RE.search(quote)
    ):
        return False
    bundle_id = entry.get("allowedBundleId")
    app_name = entry.get("allowedAppName")
    if not isinstance(app_name, str) or not app_name.strip():
        app_name = "Tama" if bundle_id == TAMA_BUNDLE_ID else ""
    lowered = quote.casefold()
    target_named = bool(
        (app_name and app_name.casefold() in lowered)
        or (isinstance(bundle_id, str) and bundle_id.casefold() in lowered)
    )
    if not target_named:
        return False
    if not strict_actions:
        return True
    actions = entry.get("allowedActions")
    if not isinstance(actions, list) or not actions:
        return False
    for raw_action in actions:
        action = str(raw_action).strip().casefold().replace("-", "_")
        if not action:
            return False
        variants = {action, action.replace("_", "-"), action.replace("_", " ")}
        if not any(variant in lowered for variant in variants):
            return False
    return True


def authorized_entry(payload: dict[str, Any]) -> dict[str, Any] | None:
    try:
        registry = json.loads(JUSTIFICATIONS_PATH.read_text())
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(registry, dict):
        return None
    session_id = str(payload.get("session_id") or payload.get("sessionId") or "")
    strict_actions = registry.get("schema") == "ai.wisent.tama.cua-justifications.vTwo"
    for entry in registry.get("authorizations", []):
        if not isinstance(entry, dict):
            continue
        quote = entry.get("userRequestQuote")
        if (
            entry.get("allowedTool") == "cua-driver"
            and isinstance(entry.get("allowedBundleId"), str)
            and entry.get("lifetime") == "current OMP session"
            and isinstance(quote, str)
            and quote_directly_authorizes(entry, quote, strict_actions)
            and quote_is_in_current_session(session_id, quote)
        ):
            return entry
    return None


def pid_targets_entry(pid: str, entry: dict[str, Any]) -> bool:
    allowed_executable = entry.get("allowedExecutable")
    if not isinstance(allowed_executable, str) or not allowed_executable:
        allowed_executable = TAMA_EXECUTABLE if entry.get("allowedBundleId") == TAMA_BUNDLE_ID else ""
    if not allowed_executable:
        return False
    try:
        result = subprocess.run(
            ["/bin/ps", "-p", pid, "-o", "command="],
            check=False,
            capture_output=True,
            text=True,
        )
    except OSError:
        return False
    return result.returncode == 0 and allowed_executable in result.stdout


def operation_matches_entry(payload: dict[str, Any], entry: dict[str, Any]) -> bool:
    action = cua_action(payload)
    if action is None:
        return False
    allowed_actions = entry.get("allowedActions")
    if allowed_actions is not None:
        if not isinstance(allowed_actions, list) or action not in {
            str(value).replace("-", "_").lower() for value in allowed_actions
        }:
            return False
    probe = json.dumps(tool_input(payload), ensure_ascii=False)
    bundle_id = entry.get("allowedBundleId")
    if action == "launch_app":
        return isinstance(bundle_id, str) and bundle_id in probe
    pids = PID_RE.findall(probe)
    if pids:
        return all(pid_targets_entry(pid, entry) for pid in pids)
    legacy_tama_management = (
        bundle_id == TAMA_BUNDLE_ID
        and allowed_actions is None
        and action in {"status", "check_permissions", "serve"}
    )
    return legacy_tama_management or (
        entry.get("allowUntargeted") is True
        and isinstance(allowed_actions, list)
        and action in {str(value).replace("-", "_").lower() for value in allowed_actions}
    )


def block(reason: str) -> int:
    sys.stderr.write(f"BLOCKED: unauthorized CUA: {reason}\n")
    return int("2")


def evaluate_payload(payload: dict[str, Any]) -> int:
    if not is_cua_operation(payload):
        return 0
    authorization = authorized_entry(payload)
    if authorization is None:
        return block(
            "no direct current-session CUA grant in cua_justifications.json; "
            "the verbatim user quote must explicitly name CUA, the target app, "
            "and every allowed cua-driver action"
        )
    if not operation_matches_entry(payload, authorization):
        return block("the CUA operation is outside the app/action scope recorded with the user quote")
    return 0


def main() -> int:
    return evaluate_payload(load_payload())


if __name__ == "__main__":
    raise SystemExit(main())
