#!/usr/bin/env python3
# Blocks an identity literal nobody issued. An identity is an email address, a
# UUID, or an identifier that flattens an address (jakub-wisent-ai ==
# jakub@wisent.ai). A literal passes when one of these holds:
#
#   1. an artifact outside any conversation carries it -- a token cache, a
#      cloud profile, a machine registry, a config file;
#   2. the user used it in more than one stored session;
#   3. identity_provenance.json records a verbatim user quote declaring it, and
#      that quote is found in a real role=user message.
#
# Why those three and not "the user said it once": on 2026-08-05 the agent
# invented jakub@wisent.com, wrote it into an enumerated credential contract in
# three repositories, propagated it through its own subagent briefs, and asked
# the user to confirm it three times. The user eventually echoed the invented
# address back once. A rule keyed on "the user said it" reads that echo as
# authority and blesses the invention. The real address, jakub@wisent.ai, sat
# 7763 times in the stored transcripts across many sessions and in stored mail;
# lukasz@wisent.com is bound to its object id by the local MSAL token cache. The
# invention existed in one authoring session and in no artifact at all. That is
# the difference this hook measures.
#
# Two discriminators were tried and rejected against real data, recorded so they
# are not tried again:
#   - stripping strings before scanning, copied from the numeric hook: an
#     identity in code IS a string, so stripping removed the only thing worth
#     finding;
#   - first-mention ordering (user before assistant): across months of history
#     an assistant has eventually said nearly every value, so it blocked both
#     genuine accounts.
#
# Roots are injectable so the tests run against a small fixture instead of the
# real multi-gigabyte store. Walking the real store per literal is what made an
# earlier version take minutes per check.
from __future__ import annotations
import json, os, re, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from check_numeric_literals import (  # noqa: E402
    path_texts,
    quote_in_user_msg,
    tool_name,
)

PROVENANCE = os.path.expanduser(
    os.environ.get('IDENTITY_PROVENANCE_FILE', '~/.shared-hooks/identity_provenance.json')
)
TRANSCRIPT_ROOT = os.path.expanduser(
    os.environ.get('IDENTITY_TRANSCRIPT_ROOT', '~/.omp/agent/sessions')
)
DEFAULT_ARTIFACTS = ':'.join((
    '~/.azure/msal_token_cache.json',
    '~/.azure/azureProfile.json',
    '~/.stado/local-storage/registry.json',
    '~/.stado/forwards',
    '~/NAMES.md',
))
ARTIFACT_ROOTS = [
    os.path.expanduser(part)
    for part in os.environ.get('IDENTITY_ARTIFACT_ROOTS', DEFAULT_ARTIFACTS).split(':')
    if part
]
WRITE_TOOLS = ('edit', 'multiedit', 'write', 'notebook')
# Never open these while searching: a vault is ciphertext, a log is chat output
# under another name, and both would make the artifact test meaningless.
ARTIFACT_SKIP = ('.vault.json', '.jsonl', '.log', '.audit.jsonl')

EMAIL = re.compile(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}')
UUID = re.compile(
    r'\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b'
)
# The tld set is closed deliberately. An open one turns every hyphenated name
# into an address claim.
TLDS = ('com', 'ai', 'io', 'net', 'org', 'dev', 'co', 'app', 'eu', 'pl')
FLAT = re.compile(r'\b([A-Za-z0-9]+)-([A-Za-z0-9]+)-(' + '|'.join(TLDS) + r')\b(?![A-Za-z0-9])')
PLACEHOLDER = re.compile(
    r'(?i)(example|sample|placeholder|dummy|fixture|redacted|your-|<[a-z-]+>|xxx'
    r'|test@|user@|foo|bar|localhost|nowhere)'
)


def sanitize(value: str) -> str:
    return value.strip().strip('.,;:"\'').lower()


def identities(text: str):
    """Every identity the text asserts, as (kind, value, as_written)."""
    found = {}
    for match in EMAIL.finditer(text):
        found.setdefault(sanitize(match.group()), ('email address', match.group()))
    for match in UUID.finditer(text):
        found.setdefault(sanitize(match.group()), ('UUID', match.group()))
    for match in FLAT.finditer(text):
        local, domain, tld = match.group(1), match.group(2), match.group(3)
        address = '{}@{}.{}'.format(local.lower(), domain.lower(), tld.lower())
        found.setdefault(address, ('address encoded in an identifier', match.group()))
    return [(kind, value, shown) for value, (kind, shown) in found.items()]


def file_contains(path: str, needle: str) -> bool:
    try:
        with open(path, 'r', encoding='utf-8', errors='replace') as handle:
            return needle in handle.read().lower()
    except Exception:
        return False


def texts_of(record, message):
    content = (message or record).get('content')
    if isinstance(content, str):
        return [content]
    if isinstance(content, list):
        return [part.get('text', '') for part in content if isinstance(part, dict)]
    return []


def transcript_files():
    for base, _directories, files in os.walk(TRANSCRIPT_ROOT):
        for name in files:
            if name.endswith('.jsonl'):
                yield os.path.join(base, name)


def user_sessions_mentioning(value: str, stop_at: int = 2):
    """How many distinct stored sessions carry this value in a user message.

    Counting stops at stop_at: the question is only ever "more than one", so a
    value the user uses constantly must not cost a full walk of the store.
    """
    needle = value.lower()
    hits = 0
    for path in transcript_files():
        if not file_contains(path, needle):
            continue
        try:
            handle = open(path, 'r', encoding='utf-8', errors='replace')
        except Exception:
            continue
        with handle:
            for line in handle:
                try:
                    record = json.loads(line)
                except Exception:
                    continue
                message = record.get('message') if isinstance(record.get('message'), dict) else None
                role = (message.get('role') if message else None) or record.get('role')
                if role != 'user':
                    continue
                if any(needle in text.lower() for text in texts_of(record, message)):
                    hits += 1
                    break
        if hits >= stop_at:
            return hits
    return hits


def in_an_artifact(value: str) -> bool:
    """True when something outside any conversation knows this identity."""
    needle = value.lower()
    for root in ARTIFACT_ROOTS:
        if os.path.isfile(root):
            if file_contains(root, needle):
                return True
            continue
        for base, _directories, files in os.walk(root):
            for name in files:
                if name.endswith(ARTIFACT_SKIP):
                    continue
                if file_contains(os.path.join(base, name), needle):
                    return True
    return False


def load_provenance():
    try:
        with open(PROVENANCE, 'r', encoding='utf-8') as handle:
            doc = json.load(handle)
    except FileNotFoundError:
        return {}, None
    except Exception as error:
        return {}, 'identity_provenance.json is not valid JSON: {}'.format(error)
    if not isinstance(doc, dict):
        return {}, 'identity_provenance.json must be an object: value -> {user_said}'
    return doc, None


def provenanced(value: str, doc: dict) -> bool:
    for recorded, entry in doc.items():
        if sanitize(str(recorded)) != value:
            continue
        quote = entry.get('user_said') if isinstance(entry, dict) else None
        if not isinstance(quote, str) or value not in quote.lower():
            return False
        return quote_in_user_msg(quote)
    return False


def sourced(value: str, doc: dict):
    """(ok, reason_it_is_not)."""
    if in_an_artifact(value):
        return True, None
    sessions = user_sessions_mentioning(value)
    if sessions > 1:
        return True, None
    if provenanced(value, doc):
        return True, None
    if sessions == 1:
        return False, (
            'no artifact outside the chat carries it and exactly one stored '
            'session has the user saying it, which is what an invented value '
            'echoed back by the user looks like'
        )
    return False, 'no artifact carries it and no stored user message contains it'


def check(payload):
    tool_input = payload.get('tool_input') or payload.get('input') or {}
    doc, doc_error = load_provenance()
    problems = [doc_error] if doc_error else []
    for raw_path, text in path_texts(tool_input):
        # Strings are scanned, unlike the numeric hook: in code an identity is
        # a string literal, so stripping them removes the whole subject.
        for kind, value, shown in identities(text or ''):
            if PLACEHOLDER.search(shown):
                continue
            ok, reason = sourced(value, doc)
            if ok:
                continue
            problems.append(
                '{}: the {} {} has no provenance -- {}. Search the stored '
                'transcripts and the machine for the value that was actually '
                'issued. An identity you cannot source is an invention, and an '
                'invention is not a question to ask the user.'.format(
                    raw_path or '<payload>', kind, shown, reason
                )
            )
    return problems


def main():
    try:
        payload = json.loads(sys.stdin.read())
    except Exception:
        return 0
    if not any(tool_name(payload).endswith(name) for name in WRITE_TOOLS):
        return 0
    problems = check(payload)
    if not problems:
        return 0
    sys.stderr.write('block-identity-literals:' + chr(10))
    for problem in problems:
        sys.stderr.write('  ' + problem + chr(10))
    return 2


if __name__ == '__main__':
    sys.exit(main())
