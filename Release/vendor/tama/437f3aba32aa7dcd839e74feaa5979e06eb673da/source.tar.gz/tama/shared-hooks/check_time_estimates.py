#!/usr/bin/env python3
"""Stop hook: reject assistant turns that contain time estimates.

Cross-agent: works with Claude Code, Droid (Factory), Codex (OpenAI).
All agents send the same Stop-hook JSON on stdin.
"""
from __future__ import annotations

import json
import re
import sys

NUMBER = r"(?:~?\s*)?[0-9]+(?:\s*[-\u2013\u2014~]\s*[0-9]+)?"
UNIT = r"(?:sec(?:ond)?|min(?:ute)?|hour|hr|day|week|month|year)s?"
SAFE_FOLLOW = (
    r"bar|bars|candle|candles|timeframe|period|sma|ema|atr|ma|"
    r"window|lookback|moving|chart|data|horizon|hold|max|rsi|macd|"
    r"ago|old|span"
)

ESTIMATE_PATTERNS = [
    r"\bETA\b",
    r"\bhalf\s+an?\s*(?:day|week|hour|month|year|minute)\b",
    r"\ba\s+(?:couple|few)\s+of\s+(?:hour|day|week|minute|month)s?\b",
    rf"\b(?:takes?|took|will\s+take|should\s+take|it\s+takes)\s+"
    rf"{NUMBER}\s*{UNIT}\b",
    rf"\b{NUMBER}\s*{UNIT}\s+(?:of\s+work|to\s+(?:build|implement|"
    rf"port|deploy|ship|train|finish|complete|get))\b",
    rf"\b(?:approx|approximately|around|roughly|~)\s*{NUMBER}\s*{UNIT}\b",
    rf"\b{NUMBER}\s*{UNIT}\b(?!\s+(?:{SAFE_FOLLOW})\b)",
    # auto-added 2026-05-17T20:37:28: User furious assistant included time estimates after Stop hook already blocked them
    r"""\bstale\s+~?\s*\d+\s*(?:min|minute|minutes|hr|hour|hours|sec|second|seconds|day|days)\b""",
]

COMPILED = [re.compile(p, flags=re.IGNORECASE) for p in ESTIMATE_PATTERNS]

def find_hits(text: str) -> list[str]:
    hits: list[str] = []
    for regex in COMPILED:
        for match in regex.finditer(text):
            hits.append(match.group(0).strip())
    return list(dict.fromkeys(hits))

def main() -> int:
    try:
        payload = json.loads(sys.stdin.read() or "{}")
    except json.JSONDecodeError:
        return 0
    if payload.get("stop_hook_active"):
        return 0
    msg = payload.get("last_assistant_message") or ""
    if not isinstance(msg, str) or not msg.strip():
        return 0
    hits = find_hits(msg)
    if not hits:
        return 0
    reason = (
        "BLOCKED: Your response contains time estimate(s): "
        + "; ".join(hits[:5])
        + ". Remove all durations (minutes, hours, days, ETAs, "
        '"half a day", etc.) and respond again without guessing '
        "how long work will take."
    )
    print(json.dumps({"decision": "block", "reason": reason}))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
