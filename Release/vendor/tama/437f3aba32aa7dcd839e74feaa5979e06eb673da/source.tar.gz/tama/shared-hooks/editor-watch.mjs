#!/usr/bin/env node

import { watch } from 'node:fs'
import { appendFile, rename, stat, writeFile, rm } from 'node:fs/promises'
import { spawn } from 'node:child_process'
import { homedir } from 'node:os'
import { basename, extname, join, resolve, sep } from 'node:path'

const home = homedir()
const guard = `${home}/.shared-hooks/editor-save-guard.mjs`
const logPath = process.env.WISENT_EDITOR_HOOK_LOG || `${home}/.shared-hooks/editor-hooks.log`
const pidPath = process.env.WISENT_EDITOR_HOOK_PID || `${home}/.shared-hooks/editor-hooks.pid`
const debounceMs = Math.max(250, Number(process.env.WISENT_EDITOR_HOOK_DEBOUNCE_MS || 1500))
const reportOnly = process.env.WISENT_EDITOR_HOOK_REPORT_ONLY !== '0'
const configuredMaxLogBytes = Number(process.env.WISENT_EDITOR_HOOK_MAX_LOG_BYTES || 8 * 1024 * 1024)
const maxLogBytes = Number.isFinite(configuredMaxLogBytes) ? Math.max(64 * 1024, configuredMaxLogBytes) : 8 * 1024 * 1024
const roots = process.argv.slice(2).map(value => resolve(value))
if (roots.length === 0) roots.push(`${home}/Documents/CodingProjects/Wisent`)

const excludedDirs = new Set([
  '.git', 'node_modules', '.next', 'dist', 'build', 'coverage', '.work', '.venv', 'venv', '__pycache__',
  'recordings', 'overleaf_browser_profile', '.cache', '.turbo', '.swiftpm', '.build'
])
const allowedExtensions = new Set([
  '.js', '.mjs', '.cjs', '.ts', '.tsx', '.jsx', '.json', '.jsonl', '.yml', '.yaml', '.toml', '.py', '.sh',
  '.swift', '.md', '.mdx', '.sql', '.css', '.scss', '.html', '.ipynb'
])
const pending = new Map()
let flushTimer = null
let logWrite = Promise.resolve()

async function log(message, data = undefined) {
  const entry = `${JSON.stringify({ ts: new Date().toISOString(), message, data })}\n`
  logWrite = logWrite.then(async () => {
    try {
      const info = await stat(logPath)
      if (info.size + Buffer.byteLength(entry) > maxLogBytes) {
        await rm(`${logPath}.1`, { force: true })
        await rename(logPath, `${logPath}.1`)
      }
    } catch {}
    await appendFile(logPath, entry, 'utf8')
  }).catch(() => {})
  await logWrite
}

function hasExcludedSegment(path) {
  return path.split(sep).some(part => excludedDirs.has(part) || part.endsWith('.app'))
}

function shouldCheckFile(path) {
  const name = basename(path)
  if (hasExcludedSegment(path)) return false
  if (name.startsWith('.#') || name.endsWith('~') || name.endsWith('.swp') || name.endsWith('.tmp')) return false
  return allowedExtensions.has(extname(path))
}

function runGuard(files) {
  return new Promise((resolveGuard) => {
    const args = [guard]
    if (reportOnly) args.push('--report-only')
    args.push(...files)
    const child = spawn(process.execPath, args, { env: process.env })
    let stdout = ''
    let stderr = ''
    child.stdout.on('data', chunk => { stdout += chunk.toString('utf8') })
    child.stderr.on('data', chunk => { stderr += chunk.toString('utf8') })
    child.on('close', code => resolveGuard({ code, stdout, stderr }))
  })
}

async function flushPending() {
  flushTimer = null
  const files = Array.from(pending.keys())
  pending.clear()
  const existing = []
  for (const file of files) {
    try {
      const info = await stat(file)
      if (info.isFile()) existing.push(file)
    } catch {}
  }
  if (existing.length === 0) return
  const result = await runGuard(existing)
  await log('guard-result', { files: existing, code: result.code, stdout: result.stdout.slice(0, 4000), stderr: result.stderr.slice(0, 4000) })
}

function schedule(file) {
  pending.set(file, true)
  if (flushTimer) clearTimeout(flushTimer)
  flushTimer = setTimeout(flushPending, debounceMs)
}

const watchers = []
for (const root of roots) {
  try {
    const watcher = watch(root, { recursive: true }, (eventType, filename) => {
      if (!filename) return
      const file = resolve(join(root, filename.toString()))
      if (!shouldCheckFile(file)) return
      schedule(file)
    })
    watcher.on('error', error => { log('watch-error', { root, error: error instanceof Error ? error.message : String(error) }) })
    watchers.push(watcher)
  } catch (error) {
    await log('watch-open-error', { root, error: error instanceof Error ? error.message : String(error) })
  }
}

await writeFile(pidPath, `${process.pid}\n`, 'utf8').catch(() => {})
await log('ready', { roots, watchers: watchers.length, debounceMs, reportOnly, mode: 'fs.watch-recursive' })
if (watchers.length === 0) {
  await rm(pidPath, { force: true }).catch(() => {})
  process.exit(2)
}
async function shutdown() {
  await log('stopping')
  for (const watcher of watchers) watcher.close()
  await rm(pidPath, { force: true }).catch(() => {})
  process.exit(0)
}
process.on('SIGTERM', shutdown)
process.on('SIGINT', shutdown)
