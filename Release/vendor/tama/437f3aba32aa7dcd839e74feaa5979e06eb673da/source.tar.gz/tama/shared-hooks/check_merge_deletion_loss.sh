#!/bin/bash
# PreToolUse(Bash) guard: block `git push` of a merge commit that silently
# reverts a large, deliberate deletion made on one parent.
#
# Origin incident (2026-05-17): merging an Overleaf sync branch (1291 lines,
# the author's deliberate 35-page condensation) into a stale `main` (1990
# lines) produced a 1867-line three-way merge that resurrected ~576 of the
# ~699 deleted lines. It was committed and pushed without comparing the
# merge result's size against the branch being merged. This hook makes that
# class of mistake impossible to push silently.
#
# Failure condition (deterministic): for an unpushed merge commit M with
# parents P1,P2 and merge-base MB, for any tracked text file:
#   shrink_i = lines(MB:f) - lines(Pi:f)              # how much side i cut
#   readd    = lines(M:f)  - lines(Pi:f)              # what the merge kept back
# If shrink_i >= MIN_SHRINK_LINES and readd >= 0.5*shrink_i for either side,
# the merge undid more than half of a deliberate condensation -> BLOCK.
#
# Override: set MERGE_DELETION_LOSS_ACK=1 in ~/.claude/settings.json env
# (NOT inline on the command line — inline is rejected, matching the
# HOOK_EDIT_AUTHORIZED convention in pre_bash.sh).

set -euo pipefail

INPUT=$(cat)
CMD=$(echo "$INPUT" | jq -r '.tool_input.command // empty')
CWD=$(echo "$INPUT" | jq -r '.cwd // empty')
[ -z "$CMD" ] && exit 0

# Only engage on git push (the outbound, auto-deploying, hard-to-reverse step).
echo "$CMD" | grep -qE '(^|[;&|]|\s)git\b([^;&|]*\s)?push\b' || exit 0

# Inline override attempts are rejected (cannot be bypassed per-command).
if echo "$CMD" | grep -qE '(^|[;&|]|\s)MERGE_DELETION_LOSS_ACK=' ; then
    echo "BLOCKED: MERGE_DELETION_LOSS_ACK must be set in settings.json env, not inline." >&2
    exit 2
fi
[ "${MERGE_DELETION_LOSS_ACK:-}" = "1" ] && exit 0

# Resolve repo working dir from the session cwd; bail quietly if not a repo.
WD="${CWD:-$PWD}"
[ -d "$WD" ] || exit 0
cd "$WD" 2>/dev/null || exit 0
git rev-parse --is-inside-work-tree >/dev/null 2>&1 || exit 0

MIN_SHRINK_LINES="${MERGE_DELETION_LOSS_MIN:-80}"
TEXT_RE='\.(tex|bib|bbl|md|markdown|txt|rst|rmd|org)$'

# Commits about to leave this machine = local history not on any remote.
UNPUSHED=$(git rev-list HEAD --not --remotes 2>/dev/null || true)
[ -z "$UNPUSHED" ] && exit 0

lines() { # lines(<rev>:<path>) -> line count, 0 if path absent at rev
    # NOTE: bare `wc` is shadowed by the wisent-compute CLI on this machine;
    # awk is used so the count is correct regardless of PATH.
    git show "$1" 2>/dev/null | awk 'END{print NR+0}'
}

VIOLATIONS=""
for M in $UNPUSHED; do
    # Merge commit iff it has a second parent.
    P2=$(git rev-parse -q --verify "${M}^2" 2>/dev/null || true)
    [ -z "$P2" ] && continue
    P1=$(git rev-parse -q --verify "${M}^1")
    MB=$(git merge-base "$P1" "$P2" 2>/dev/null || true)
    [ -z "$MB" ] && continue

    # Text files touched by the merge relative to either parent.
    FILES=$( { git diff --name-only "$P1" "$M"; git diff --name-only "$P2" "$M"; } \
             2>/dev/null | sort -u | grep -E "$TEXT_RE" || true )
    [ -z "$FILES" ] && continue

    while IFS= read -r f; do
        [ -z "$f" ] && continue
        n_mb=$(lines "$MB:$f"); n_m=$(lines "$M:$f")
        for P in "$P1" "$P2"; do
            n_p=$(lines "$P:$f")
            shrink=$(( n_mb - n_p ))
            [ "$shrink" -lt "$MIN_SHRINK_LINES" ] && continue
            readd=$(( n_m - n_p ))
            half=$(( shrink / 2 ))
            if [ "$readd" -ge "$half" ]; then
                short=$(git rev-parse --short "$M")
                pb=$(git rev-parse --short "$P")
                VIOLATIONS="${VIOLATIONS}\n  merge ${short}  file ${f}\n    merge-base=${n_mb}L  parent ${pb}=${n_p}L  merge result=${n_m}L\n    that parent deliberately cut ${shrink} lines; the merge added ${readd} back (>=50%)."
            fi
        done
    done <<< "$FILES"
done

if [ -n "$VIOLATIONS" ]; then
    {
      echo "BLOCKED: push contains a merge that reverted a large deliberate deletion."
      printf '%b\n' "$VIOLATIONS"
      echo ""
      echo "A three-way merge silently re-added content one branch had intentionally"
      echo "removed (e.g. an Overleaf condensation). Do NOT push this."
      echo "Fix: re-resolve the merge so the file matches the branch that did the"
      echo "deletion (e.g. 'git checkout <that-branch> -- <file>' then recommit), or"
      echo "if the re-addition is genuinely intended, set MERGE_DELETION_LOSS_ACK=1"
      echo "in ~/.claude/settings.json env and retry."
    } >&2
    exit 2
fi
exit 0
