#!/usr/bin/env python3
"""Device-level gate against fake verification and policy-bypass logic.

Blocks across Bash, eval/code-kernel tools, and Write/Edit-style tools:
- smoke checks and dry-runs.
- local/unit test runners unless a separate user-controlled hook policy permits them.
- live Slack/Supabase/Oko side-effect probes from eval/code kernels.
- edits that introduce keyword/token-list classifiers for intent/routing/policy.
- edits that introduce fallback/provider-failure/silent-catch behavior.
- fake/stubbed integration checks.

Policy message: no smoke tests, no dry-runs, no unapproved live tests, no
keyword classifiers, no hidden fallbacks. If the user explicitly approves a real
live action, route it through checked-in product code or an existing CLI path,
not an ad-hoc eval/kernel payload.
"""

import json
import os
import re
import sys
from pathlib import Path
from typing import Any

SMOKE_RE = re.compile(r"\bsmoke\b", re.IGNORECASE)
DRY_RUN_RE = re.compile(
    r"(--dry[-_]?run\b|\b[A-Z0-9_]*DRY_RUN[A-Z0-9_]*\s*=|\bdry[-_ ]run\b)",
    re.IGNORECASE,
)
FAKE_INTEGRATION_RE = re.compile(
    r"\b(fake|mock(?:ed)?|stub(?:bed)?|in[-_ ]memory|test[-_ ]double)\b.{0,80}"
    r"\b(supabase|stripe|slack|oauth|api|database|db|integration|route|endpoint|worker|queue|webhook|browser|gui|cdp)\b"
    r"|\b(supabase|stripe|slack|oauth|api|database|db|integration|route|endpoint|worker|queue|webhook|browser|gui|cdp)\b.{0,80}"
    r"\b(fake|mock(?:ed)?|stub(?:bed)?|in[-_ ]memory|test[-_ ]double)\b",
    re.IGNORECASE,
)
SMOKE_TEST_NAME_RE = re.compile(r"(^|[._-])smoke([._-]|$)|smoke[-_]?test|smoketest", re.IGNORECASE)
SMOKE_TEST_TEXT_RE = re.compile(r"smoke[:._ -]?(test|tests|check|checks)|smoke[-_:][a-z0-9]", re.IGNORECASE)
LOCAL_TEST_RUNNER_RE = re.compile(
    r"(^|[;&|`(]|\s)("
    r"npm\s+(run\s+)?test(:[A-Za-z0-9_.-]+)?"
    r"|pnpm\s+(run\s+)?test(:[A-Za-z0-9_.-]+)?"
    r"|yarn\s+(run\s+)?test(:[A-Za-z0-9_.-]+)?"
    r"|bun\s+test"
    r"|swift\s+test\b"
    r"|xcodebuild\b[^;&|`]*\btest\b"
    r"|cargo\s+test\b"
    r"|go\s+test\b"
    r"|pytest\b"
    r"|python[0-9.]*\s+-m\s+pytest\b"
    r"|rspec\b"
    r"|bundle\s+exec\s+rspec\b"
    r"|npx\s+[^;&|`]*\b(vitest|jest|mocha|ava|tap|cypress)\b"
    r"|npm\s+exec\s+[^;&|`]*\b(vitest|jest|mocha|ava|tap|cypress)\b"
    r"|pnpm\s+exec\s+[^;&|`]*\b(vitest|jest|mocha|ava|tap|cypress)\b"
    r"|yarn\s+dlx\s+[^;&|`]*\b(vitest|jest|mocha|ava|tap|cypress)\b"
    r"|bunx\s+[^;&|`]*\b(vitest|jest|mocha|ava|tap|cypress)\b"
    r"|(?:vitest|jest|mocha|ava|tap|cypress)\b"
    r"|playwright\s+test\b"
    r")(?=\s|$)",
    re.IGNORECASE,
)

# Eval/code-kernel side-effect probes that bypass Bash/Write/Edit policy.
LIVE_EVAL_SIDE_EFFECT_RE = re.compile(
    r"(slack\.com/api/(chat\.(postMessage|delete|update|scheduleMessage)|files\.upload|reactions\.(add|remove))"
    r"|chat\W{0,40}(postMessage|delete|update|scheduleMessage)"
    r"|conversations\W{0,80}replies.{0,240}chat\W{0,40}delete"
    r"|service\W{0,40}Role\W{0,40}Key"
    r"|/rest\W{0,20}v1\W{0,80}"
    r"|auto_goals_snapshot"
    r"|work_telemetry_snapshot"
    r"|urlopen\s*\("
    r"|urllib\.request\.Request"
    r"|subprocess\.(run|Popen|call|check_call|check_output)"
    r"|\.oko/bin/oko-cli\s+(suggestions\s+reply|context\s+refresh-slack)"
    r")",
    re.IGNORECASE | re.DOTALL,
)

# Keyword/token list classifiers for routing/intent/policy are banned. This is
# intentionally structural: either the code names the anti-pattern, or combines
# token normalization/list membership with intent/routing/policy decisions.
KEYWORD_CLASSIFIER_RE = re.compile(
    r"(keyword[-_ ]?based|\bnormalizedTokens\b|\bnormalizedQuestionTokens\b|\bmentionsGoal\b|\basksTo[A-Z][A-Za-z0-9_]*\b"
    r"|\bSet\s*<\s*String\s*>\b.{0,500}\b(intent|route|policy|scenario|classifier|classif|decision)\b"
    r"|\b(intent|route|policy|scenario|classifier|classif|decision)\b.{0,500}\b(isDisjoint|contains\s*\(|normalizedTokens|\[\s*\"[A-Za-z])"
    r"|\b(tokens?|keywords?)\b.{0,240}\b(isDisjoint|contains\s*\(|\[\s*\"[A-Za-z])\b.{0,240}\b(intent|route|policy|scenario|classifier|classif|decision)\b)",
    re.IGNORECASE | re.DOTALL,
)

# Fallbacks are banned both lexically and by common Swift/TS/Python shapes that
# hide a failure behind a safe-sounding response.
FALLBACK_LOGIC_RE = re.compile(
    r"(\bfallback\b|fall[-_ ]?back|fallthrough|graceful[-_ ]?degrad|providerFailure|FailureSlackMessage"
    r"|couldn['’]t complete this request safely|will not guess the result"
    r"|catch\s*\{[^}]{0,400}\breturn\b[^}]{0,220}(Message|nil|None|null|false|true|0|\[\]|\{\})"
    r"|except\s+[^:]*:\s*(?:\n|.){0,240}\breturn\b\s*(None|False|True|0|\[\]|\{\}|['\"])"
    r"|\.catch\s*\([^)]*=>\s*(null|undefined|false|true|0|\[\]|\{\}|['\"])"
    r"|try\?\s+await"
    r"|\?\?\s*(false|true|nil|null|None|0|\[\]|\{\}|\"\"|'')"
    r")",
    re.IGNORECASE | re.DOTALL,
)

SKIP_DIRS = {
    ".git",
    ".hg",
    ".svn",
    "node_modules",
    ".next",
    "dist",
    "build",
    "out",
    "coverage",
    "__pycache__",
    ".venv",
    "venv",
    ".claude",
    ".codex",
    ".factory",
    ".shared-hooks",
    ".tmp",
}
REPO_MARKERS = {".git", "package.json", "pyproject.toml", "Cargo.toml", "go.mod", "Package.swift"}
MAX_FINDINGS = 12
MAX_TEXT = 250_000


def block(message: str) -> None:
    sys.stderr.write(message.rstrip() + "\n")
    raise SystemExit(2)


def load_payload() -> dict:
    raw = sys.stdin.read()
    if not raw.strip():
        return {}
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return {}


def tool_input(payload: dict) -> dict:
    value = payload.get("tool_input")
    return value if isinstance(value, dict) else {}


def strings_from(value: Any) -> list[str]:
    out: list[str] = []
    stack = [value]
    while stack:
        cur = stack.pop()
        if isinstance(cur, str):
            out.append(cur)
        elif isinstance(cur, dict):
            stack.extend(cur.values())
        elif isinstance(cur, list):
            stack.extend(cur)
    return out


def payload_text(payload: dict) -> str:
    text = "\n".join(strings_from(payload))
    return text[:MAX_TEXT]


def resolve_path(raw_path):
    if not raw_path:
        return None
    raw_path = os.path.expanduser(raw_path)
    path = Path(raw_path)
    if not path.is_absolute():
        base = os.environ.get("CLAUDE_PROJECT_DIR") or os.getcwd()
        path = Path(base) / path
    return path.resolve(strict=False)


def nearest_repo(path):
    if path is None:
        project_dir = os.environ.get("CLAUDE_PROJECT_DIR")
        path = Path(project_dir).resolve(strict=False) if project_dir else Path.cwd().resolve(strict=False)
    cursor = path if path.is_dir() else path.parent
    home = Path.home().resolve(strict=False)
    while True:
        if cursor == home or cursor == cursor.parent:
            return None
        if any((cursor / marker).exists() for marker in REPO_MARKERS):
            return cursor
        cursor = cursor.parent


def is_system_path(path: Path) -> bool:
    parts = set(path.parts)
    return bool(parts & {".claude", ".shared-hooks", ".codex", ".factory"})


def smoke_findings(repo):
    findings = []
    for root, dirs, files in os.walk(repo):
        root_path = Path(root)
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for name in dirs + files:
            rel = str((root_path / name).relative_to(repo))
            if SMOKE_TEST_NAME_RE.search(name):
                findings.append(rel)
                if len(findings) >= MAX_FINDINGS:
                    return findings
        for name in files:
            if name not in {"package.json", "package-lock.json", "pnpm-lock.yaml", "yarn.lock", "Makefile"} and not name.endswith((".md", ".yml", ".yaml")):
                continue
            file_path = root_path / name
            try:
                if file_path.stat().st_size > 1_000_000:
                    continue
                text = file_path.read_text(errors="ignore")
            except OSError:
                continue
            if SMOKE_TEST_TEXT_RE.search(text):
                findings.append(str(file_path.relative_to(repo)))
                if len(findings) >= MAX_FINDINGS:
                    return findings
    return findings


def proposed_text(inp: dict) -> str:
    parts = []
    for key in ("content", "new_string", "patch", "command", "cmd", "code"):
        value = inp.get(key)
        if isinstance(value, str):
            parts.append(value)
    return "\n".join(parts)


def tool_kind(tool: str) -> str:
    lower = tool.lower()
    if lower in {"bash", "execute"}:
        return "bash"
    if lower in {"write", "edit", "create", "notebookedit", "apply_patch"}:
        return "edit"
    if lower in {"eval", "mcp__node_repl__js", "node_repl/js", "mcp__ide__executecode"} or "execute_code" in lower or "repl" in lower:
        return "eval"
    return "other"


def block_common_text(text: str, scope: str) -> None:
    if SMOKE_RE.search(text):
        block(f"BLOCKED: smoke checks are forbidden in {scope}. Do real approved actions only; no smoke tests.")
    if DRY_RUN_RE.search(text):
        block(f"BLOCKED: dry-runs are forbidden in {scope}. Do not simulate or preview side effects as a substitute for approval.")
    if LOCAL_TEST_RUNNER_RE.search(text):
        block(f"BLOCKED: local/unit test runner detected in {scope}. Tests require explicit user approval and must not be launched ad hoc.")
    if FAKE_INTEGRATION_RE.search(text):
        block(f"BLOCKED: fake/stubbed integration check detected in {scope}. Use the real approved path, not fake verification.")


def block_eval_bypasses(text: str) -> None:
    block_common_text(text, "eval/code kernel payload")
    if LIVE_EVAL_SIDE_EFFECT_RE.search(text):
        block(
            "BLOCKED: eval/code kernel attempts a live Slack/Supabase/Oko side effect or subprocess probe. "
            "This bypasses approval-aware product code and hook coverage. Use checked-in code/CLI only after explicit user approval."
        )


def block_edit_bypasses(raw_file: str, proposed: str) -> None:
    joined = f"{raw_file}\n{proposed}"
    block_common_text(joined, "edit payload")
    if KEYWORD_CLASSIFIER_RE.search(proposed):
        block(
            "BLOCKED: keyword/token-list intent routing or policy classifier detected. "
            "Do not add deterministic keyword-based logic; use the approved non-keyword decision path."
        )
    if FALLBACK_LOGIC_RE.search(proposed):
        block(
            "BLOCKED: fallback/provider-failure/silent-catch logic detected. "
            "Surface failures; do not add fallbacks or safe-looking default responses."
        )


def main() -> None:
    payload = load_payload()
    tool = str(payload.get("tool_name") or payload.get("tool") or payload.get("name") or "")
    inp = tool_input(payload)
    kind = tool_kind(tool)
    all_text = payload_text(payload)

    if kind == "bash":
        command = str(inp.get("command") or inp.get("cmd") or payload.get("command") or payload.get("cmd") or "")
        block_common_text(command, "Bash command")
        return

    if kind == "eval":
        block_eval_bypasses(all_text)
        return

    if kind != "edit":
        # Unknown tools still get the cross-tool verification/liveness gate. This
        # closes the class of bypass where a new code execution MCP appears under
        # a different name and carries Python/JS code in arbitrary JSON fields.
        block_common_text(all_text, "tool payload")
        if LIVE_EVAL_SIDE_EFFECT_RE.search(all_text):
            block(
                "BLOCKED: tool payload contains live Slack/Supabase/Oko side-effect code. "
                "No ad-hoc live tests or mutations through unregistered tools."
            )
        return

    raw_file = str(inp.get("file_path") or inp.get("path") or "")
    path = resolve_path(raw_file)
    if path and is_system_path(path):
        return

    proposed = proposed_text(inp)
    block_edit_bypasses(raw_file, proposed)

    repo = nearest_repo(path)
    if not repo:
        return
    findings = smoke_findings(repo)
    if findings:
        block(
            "BLOCKED: smoke-test artifacts are forbidden on this device. "
            f"Repo {repo} contains: {', '.join(findings)}. Remove them before further edits."
        )


if __name__ == "__main__":
    main()
