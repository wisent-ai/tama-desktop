#!/usr/bin/env python3
"""Stop hook — block assistant responses that make claims about a
trajectory/run's visible page state without a corresponding Read on a
recent frame.

v6 (2026-05-09): closes gaps that let "linkedin scrape" claims through.
  - Label discovery: trajectory_runs.json keys + recordings/<label>/ +
    .work/<label>/ frame dirs. Old version only used trajectory_runs.
  - Token-set matching: "linkedin scrape" matches scrape_linkedin (tokens
    in any order, within 200 chars). Old \\b<label>\\b required exact form.
  - Log-Read inference: a Read on .work/<label>/ or recordings/<label>/
    or known per-platform log paths counts as a label reference even when
    the response doesn't name the label.
  - Recency window 24h instead of 15min — the agent often analyzes
    yesterday's run.

Bypass: CHECK_VISUAL_CLAIMS_DISABLED=1.
"""
import json
import os
import re
import sys
import time
import hashlib
from pathlib import Path

if os.environ.get("CHECK_VISUAL_CLAIMS_DISABLED") == "1":
    sys.exit(0)

HOME = Path(os.environ.get("HOME", "/tmp"))
CWD = Path(os.getcwd())

VISUAL_TERMS = re.compile(
    r"\b(captcha|recaptcha|stripped[_ ]login[_ ]shell|stripped\s+shell|token\s+expir|"
    r"verification\s+challenge\s+expired|checkpoint|verify\s+(failed|reject)|"
    r"login\s+form|password\s+input|email\s+input|stripped|consensus|"
    r"page\s+(showed|shows|rendered|presented)|the\s+page\s+(was|is)|"
    r"security[\- ](gate|wall|check|page)|bot[\- ]protection|"
    r"sign[\- ]in[\- ]protection|verify[\- ]checkbox|challenge[\- ]page|"
    r"i'?m\s+not\s+a\s+robot|"
    r"protection\s+wall|risk\s+model|takeover\s+suspected|"
    r"(red|orange|yellow)\s+banner|kicked\s+(us\s+)?back|intercepted|"
    # v6 additions: state-of-run claims
    r"shadow[\- ]?throttl|shadow[\- ]?ban|shadowban|throttl|"
    r"\b0\s+handles\b|\b0\s+entries\b|\b0\s+results?\b|\bno\s+results?\b|"
    r"account[\- ]locked|account[\- ]ban|locked\s+out|restricted|"
    r"redirect(?:ed)?\s+to|empty\s+results?|search\s+(returned|empty)|"
    r"soft[\- ]block|hard[\- ]block|rate[\- ]limit)",
    re.IGNORECASE,
)


def find_session_jsonl():
    encoded = str(CWD).replace("/", "-")
    proj = HOME / ".claude" / "projects" / encoded
    if not proj.is_dir():
        return None
    cs = sorted(proj.glob("*.jsonl"), key=lambda p: p.stat().st_mtime, reverse=True)
    return cs[0] if cs else None


def discover_all_labels():
    """Combine: trajectory_runs.json keys + recordings/<label>/ +
    .work/<label>/ where frames or webms exist."""
    labels = set()
    state = HOME / ".shared-hooks" / "state" / "trajectory_runs.json"
    if state.is_file():
        try:
            data = json.loads(state.read_text())
            for k in data.keys():
                slash = k.rfind("/")
                labels.add(k[slash + 1:] if slash >= 0 else k)
        except Exception:
            pass
    for base in [CWD.parent / "weles" / "recordings", CWD / "recordings"]:
        if base.is_dir():
            for d in base.iterdir():
                if d.is_dir() and any(d.glob("*.webm")):
                    labels.add(d.name)
    work = CWD / ".work"
    if work.is_dir():
        for d in work.iterdir():
            if d.is_dir() and (any(d.glob("frame_*.png")) or
                               any(d.glob("failure_state_*.png"))):
                labels.add(d.name)
    return list(labels)


def label_tokens(label):
    return [t for t in re.split(r"[_/\-\s]+", label.lower()) if t]


def label_in_response(label, text):
    """True if all tokens of `label` appear in `text` within a 200-char
    window (case-insensitive). Also matches the exact label form."""
    text_lc = text.lower()
    if re.search(rf"\b{re.escape(label.lower())}\b", text_lc):
        return True
    tokens = label_tokens(label)
    if len(tokens) < 2:
        return False  # single-token labels too prone to FP
    pos = {}
    for tok in tokens:
        if len(tok) < 3:
            return False  # avoid 'sf' / 'us' false positives
        hits = [m.start() for m in re.finditer(rf"\b{re.escape(tok)}\b", text_lc)]
        if not hits:
            return False
        pos[tok] = hits
    from itertools import product
    for combo in product(*[pos[t] for t in tokens]):
        if max(combo) - min(combo) <= 200:
            return True
    return False


def session_log_reads_imply_labels(lookback=120):
    """Walk session jsonl looking for Reads on log/data files in this
    turn. Infer labels from path patterns:
      - .work/<label>/...        → label
      - recordings/<label>/...   → label
      - .work/avatar-survey/data/run_<plat>_*.log → <plat>_avatar_survey
      - .work/avatar-survey/data/<plat>.json     → <plat>_avatar_survey
    """
    jsonl = find_session_jsonl()
    if not jsonl:
        return []
    try:
        lines = jsonl.read_text().splitlines()
    except Exception:
        return []
    labels = set()
    boundary = max(0, len(lines) - lookback)
    for i in range(len(lines) - 1, boundary - 1, -1):
        try:
            entry = json.loads(lines[i])
        except Exception:
            continue
        if entry.get("type") == "user":
            boundary = i + 1
            break
    for raw in lines[boundary:]:
        try:
            entry = json.loads(raw)
        except Exception:
            continue
        msg = entry.get("message") or {}
        content = msg.get("content") or []
        if not isinstance(content, list):
            continue
        for block in content:
            if not isinstance(block, dict) or block.get("type") != "tool_use":
                continue
            if block.get("name") != "Read":
                continue
            fp = str((block.get("input") or {}).get("file_path") or "")
            m = re.search(r"\.work/([^/]+)/", fp)
            if m:
                labels.add(m.group(1))
            m = re.search(r"recordings/([^/]+)/", fp)
            if m:
                labels.add(m.group(1))
            m = re.search(r"avatar-survey/data/run_([a-z]+)_", fp)
            if m:
                plat = {"li": "linkedin", "ig": "instagram", "tt": "tiktok",
                        "tw": "twitter", "rd": "reddit", "yt": "youtube",
                        "li_v3": "linkedin", "li_v4_logan": "linkedin"}.get(m.group(1), m.group(1))
                # try both common WSession label forms
                labels.add(f"{plat}_avatar_survey")
                labels.add(f"{plat}_scrape")
            m = re.search(r"avatar-survey/data/([a-z_]+)\.json$", fp)
            if m and m.group(1) not in ("data", "config"):
                labels.add(f"{m.group(1)}_avatar_survey")
    return list(labels)


def resolve_wsession_label(script_label, search_roots, max_depth=6):
    """Find a script file basename-matching `script_label`, parse its
    WSession.start({label: ...}) call, and return the runtime label.

    Handles:
      label: 'literal'                       -> 'literal'
      label: `${VAR}_suffix`  with `const VAR = process.env.VAR || 'default'`
                                             -> 'default_suffix'

    Returns None if the script can't be found or the label is too dynamic
    to resolve statically.
    """
    targets = {f"{script_label}{ext}" for ext in ('.mjs', '.ts', '.js')}
    skip_dirs = {'node_modules', '.git', 'dist', 'recordings',
                 '__pycache__', '.next', '.venv', 'venv'}
    for root in search_roots:
        if not root.is_dir():
            continue
        for dirpath, dirnames, filenames in os.walk(root):
            try:
                depth = len(Path(dirpath).relative_to(root).parts)
            except ValueError:
                depth = 0
            if depth > max_depth:
                dirnames.clear()
                continue
            dirnames[:] = [d for d in dirnames if d not in skip_dirs]
            for fn in filenames:
                if fn not in targets:
                    continue
                path = Path(dirpath) / fn
                try:
                    text = path.read_text()
                except Exception:
                    continue
                m = re.search(
                    r"WSession\.start\s*\(\s*\{[^}]{0,400}?\blabel\s*:\s*['\"]([^'\"]+)['\"]",
                    text, flags=re.DOTALL)
                if m:
                    return m.group(1)
                m = re.search(
                    r"WSession\.start\s*\(\s*\{[^}]{0,400}?\blabel\s*:\s*`([^`]+)`",
                    text, flags=re.DOTALL)
                if m:
                    template = m.group(1)
                    var_names = re.findall(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}", template)
                    resolved = template
                    for v in var_names:
                        ed = re.search(
                            rf"(?:const|let|var)\s+{re.escape(v)}\s*=\s*process\.env\.{re.escape(v)}\s*\|\|\s*['\"]([^'\"]+)['\"]",
                            text)
                        if not ed:
                            resolved = None
                            break
                        resolved = resolved.replace(f"${{{v}}}", ed.group(1))
                    if resolved:
                        return resolved
    return None


def latest_recording_sha8(label):
    bases = [CWD.parent / "weles" / "recordings" / label,
             CWD / "recordings" / label]
    candidates = []
    for b in bases:
        if b.is_dir():
            candidates.extend(b.glob("*.webm"))
    if not candidates:
        return None, None
    latest = max(candidates, key=lambda p: p.stat().st_mtime)
    h = hashlib.sha256()
    with latest.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()[:8], latest


def session_has_sha8_read(label, sha8, rec_path, lookback=240):
    jsonl = find_session_jsonl()
    if not jsonl:
        return False
    pat = re.compile(
        rf"\.work/{re.escape(label)}/(?:frame|failure_state)_{re.escape(sha8)}_?[^\s'\"]*\.(?:png|jpg)$"
    )
    rec_mt = rec_path.stat().st_mtime
    try:
        lines = jsonl.read_text().splitlines()
    except Exception:
        return False
    for raw in lines[-lookback:]:
        try:
            entry = json.loads(raw)
        except Exception:
            continue
        msg = entry.get("message") or {}
        content = msg.get("content") or []
        if not isinstance(content, list):
            continue
        for block in content:
            if not isinstance(block, dict) or block.get("type") != "tool_use":
                continue
            if block.get("name") != "Read":
                continue
            fp = str((block.get("input") or {}).get("file_path") or "")
            if not pat.search(fp):
                continue
            try:
                if abs(Path(fp).stat().st_mtime - rec_mt) > 2.0:
                    continue
            except Exception:
                continue
            return True
    return False


def recent_trajectory_labels(within_seconds=86400):
    """24h window — covers yesterday's runs. Old 15min was too tight."""
    out = []
    bases = [CWD.parent / "weles" / "recordings", CWD / "recordings"]
    cutoff = time.time() - within_seconds
    for root in bases:
        if not root.is_dir():
            continue
        for d in root.iterdir():
            if not d.is_dir():
                continue
            recs = list(d.glob("*.webm"))
            if not recs:
                continue
            latest = max(recs, key=lambda p: p.stat().st_mtime)
            if latest.stat().st_mtime >= cutoff:
                out.append(d.name)
    return list(set(out))


def main():
    raw = sys.stdin.read()
    try:
        payload = json.loads(raw) if raw.strip() else {}
    except Exception:
        sys.exit(0)
    # Claude Code Stop-hook protocol: payload.last_assistant_message is the
    # assistant's pending response. Older code read payload.message.content,
    # which CC does NOT send to Stop hooks — that path always saw empty
    # text and exited 0, defeating the entire visual-claim guard.
    msg = payload.get("last_assistant_message") or ""
    if not isinstance(msg, str) or not msg.strip():
        sys.exit(0)
    response = msg
    if not VISUAL_TERMS.search(response):
        sys.exit(0)

    labels = discover_all_labels()
    referenced = [l for l in labels if label_in_response(l, response)]
    log_inferred = session_log_reads_imply_labels()
    for l in log_inferred:
        if l not in referenced:
            referenced.append(l)
    if not referenced:
        referenced = recent_trajectory_labels()

    # Sibling expansion: if a referenced label has no recording on disk:
    #   (a) try resolve_wsession_label() — read the script source for
    #       `WSession.start({label: '...'})` (literal OR template with
    #       process.env.X || 'default'). Fully automated, exact mapping.
    #   (b) fallback: most-recent token-overlapping sibling.
    search_roots = [CWD, CWD / ".work",
                    CWD.parent / "weles" / "scripts",
                    CWD.parent / "weles" / "src"]
    expanded = list(referenced)
    for label in referenced:
        sha8, rec = latest_recording_sha8(label)
        if sha8 and rec:
            continue
        aliased = resolve_wsession_label(label, search_roots)
        if aliased and aliased not in expanded:
            ali_sha8, ali_rec = latest_recording_sha8(aliased)
            if ali_sha8 and ali_rec:
                expanded.append(aliased)
                continue
        label_toks = {t for t in label_tokens(label) if len(t) >= 4}
        if not label_toks:
            continue
        best = None
        for other in labels:
            if other == label or other in expanded:
                continue
            other_toks = {t for t in label_tokens(other) if len(t) >= 4}
            if not (label_toks & other_toks):
                continue
            sib_sha8, sib_rec = latest_recording_sha8(other)
            if not sib_sha8 or not sib_rec:
                continue
            mt = sib_rec.stat().st_mtime
            if best is None or mt > best[0]:
                best = (mt, other, sib_sha8, sib_rec)
        if best:
            expanded.append(best[1])
    referenced = expanded

    missing = []
    for label in referenced:
        sha8, rec = latest_recording_sha8(label)
        if not sha8 or not rec:
            continue
        if not session_has_sha8_read(label, sha8, rec):
            missing.append((label, sha8, rec))

    if not missing:
        sys.exit(0)

    print("=" * 60, file=sys.stderr)
    print("  BLOCKED: visual-state claim without inspecting frames", file=sys.stderr)
    print("=" * 60, file=sys.stderr)
    for label, sha8, rec in missing:
        print(f"  trajectory '{label}' — latest {rec.name} (sha8={sha8})", file=sys.stderr)
        print(f"    Read .work/{label}/frame_{sha8}_last.png before claiming page state.", file=sys.stderr)
        print(f"    If frames absent: $HOME/.shared-hooks/inspect_trajectory.sh {label}", file=sys.stderr)
    print("", file=sys.stderr)
    print("Bypass: CHECK_VISUAL_CLAIMS_DISABLED=1.", file=sys.stderr)
    sys.exit(2)


if __name__ == "__main__":
    main()
