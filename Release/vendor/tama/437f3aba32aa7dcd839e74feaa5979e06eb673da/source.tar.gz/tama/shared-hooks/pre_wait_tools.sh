#!/bin/bash
# PreToolUse gate for non-Bash tools that introduce waits.
# Closes the equivalent gap to pre_bash.sh's TIMEOUT_BLOCK section.
#
# Tools covered (matched in settings.json):
#   - Monitor       (timeout_ms; persistent)
#   - ScheduleWakeup (delaySeconds)
#
# Default cap matches pre_bash: 60000 ms / 60 s.
# Bypass: TIMEOUT_BLOCK_AUTHORIZED=1.

set -euo pipefail
INPUT=$(cat)
TOOL=$(echo "$INPUT" | jq -r '.tool_name // empty')

CAP_MS=60000

block() {
    local reason=$1
    # No env-var escape (removed for the same reason TIMEOUT_BLOCK_AUTHORIZED
    # came out of pre_bash.sh).
    echo "BLOCKED: ${reason}. Long-running waits without active diagnosis are forbidden." >&2
    exit 2
}

case "$TOOL" in
    Monitor)
        TIMEOUT_MS=$(echo "$INPUT" | jq -r '.tool_input.timeout_ms // empty')
        PERSISTENT=$(echo "$INPUT" | jq -r '.tool_input.persistent // false')
        if [[ "$PERSISTENT" == "true" ]]; then
            block "Monitor persistent=true (no deadline) is forbidden"
        fi
        if [[ -n "$TIMEOUT_MS" ]] && [[ "$TIMEOUT_MS" != "null" ]]; then
            if [[ "$TIMEOUT_MS" -gt "$CAP_MS" ]]; then
                block "Monitor timeout_ms=${TIMEOUT_MS} exceeds ${CAP_MS}ms cap"
            fi
        fi
        ;;
    ScheduleWakeup)
        DELAY=$(echo "$INPUT" | jq -r '.tool_input.delaySeconds // empty')
        if [[ -n "$DELAY" ]] && [[ "$DELAY" != "null" ]]; then
            DELAY_MS=$((${DELAY%.*} * 1000))
            if [[ "$DELAY_MS" -gt "$CAP_MS" ]]; then
                block "ScheduleWakeup delaySeconds=${DELAY} (${DELAY_MS}ms) exceeds ${CAP_MS}ms cap"
            fi
        fi
        ;;
esac
exit 0
