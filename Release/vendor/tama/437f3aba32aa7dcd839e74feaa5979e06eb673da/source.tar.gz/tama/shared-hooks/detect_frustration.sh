#!/bin/bash
# UserPromptSubmit hook: detect when the user is frustrated or correcting
# behavior and auto-append a generated rule to the appropriate target.
# HARDENED 2026-05-08: drafter prompt now includes pre_bash.sh and
# pre_write_edit.sh as valid PreToolUse targets, and the dispatcher
# forwards `message` (block string) for those.

set -euo pipefail

if [[ -n "${DETECT_FRUSTRATION_ACTIVE:-}" ]]; then
    exit 0
fi

INPUT=$(cat)
PROMPT=$(echo "$INPUT" | jq -r '.prompt // empty')
TRANSCRIPT=$(echo "$INPUT" | jq -r '.transcript_path // empty')
CWD=$(echo "$INPUT" | jq -r '.cwd // empty')

if [[ -z "$PROMPT" ]]; then exit 0; fi

FRUSTRATION='\b(stop\s+(doing|using|saying|writing|asking|making|with)|don.?t\s+(do|ever|use|say|write|ask|tell)|never\s+(do|use|say|write|again)|i\s+(hate|dislike|don.?t\s+want|told\s+you|already\s+told)|ugh|wtf|jesus\s+christ|for\s+the\s+love|come\s+on|cmon|how\s+many\s+times|annoying|frustrat\w*|infuriat\w*|the\s+fuck|fucking\s|bullshit|why\s+(are|did|would|do)\s+you|that.?s\s+not\s+what|i\s+didn.?t\s+ask|not\s+what\s+i\s+(asked|wanted)|stop\s+asking|hate\s+(when|that|it|how))\b'

if ! echo "$PROMPT" | grep -qiE "$FRUSTRATION"; then
    exit 0
fi

LAST_ASSISTANT=""
if [[ -f "$TRANSCRIPT" ]]; then
    LAST_ASSISTANT=$(tail -300 "$TRANSCRIPT" \
        | jq -r 'select((.message.role // .role // .type) == "assistant") | (.message.content // .content // empty)' 2>/dev/null \
        | tr '\n' ' ' \
        | tail -c 1500 || true)
fi

LOG="$HOME/.shared-hooks/auto_rules.log"
mkdir -p "$(dirname "$LOG")"

if ! command -v claude >/dev/null 2>&1; then
    echo "$(date '+%F %T') | NO_CLAUDE_CLI prompt=${PROMPT:0:200}" >> "$LOG"
    exit 0
fi

(
    export DETECT_FRUSTRATION_ACTIVE=1

    CLASSIFY_PROMPT="Decide whether the user message below is expressing frustration with or correction of the assistant's recent behavior. Examples of YES: telling the assistant to stop doing something, complaining about a previous response, profanity directed at the assistant, 'I told you', 'why did you', 'that's not what I asked'. Examples of NO: a normal task request, a calm question, satisfaction, cursing at unrelated infrastructure, casual filler.

USER MESSAGE: $PROMPT

Reply with exactly one of these and nothing else:
YES
or
NO"

    VERDICT=$(claude -p "$CLASSIFY_PROMPT" 2>/dev/null | head -1 | tr -d '[:space:]' || true)

    if [[ "$VERDICT" != "YES" ]]; then
        echo "$(date '+%F %T') | NOT_FRUSTRATED verdict=${VERDICT:-empty}" >> "$LOG"
        exit 0
    fi

    DRAFT_PROMPT="You translate user frustration into a hook rule. Pick the most-specific target.

Targets:
  - check_stop_asking.py  (regex on the assistant final response — block end-of-turn behaviors)
  - check_time_estimates.py (regex on the assistant final response — block time estimate language)
  - pre_bash.sh           (regex on the bash command — block specific shell invocations)
  - pre_write_edit.sh     (regex on the file path — block writes to specific paths)
  - CLAUDE.md             (one-line behavioral rule loaded into every future session)

Respond ONLY with a JSON object on a single line, no prose, no markdown fence:
  {\"summary\":str, \"target\":<one of the above>, \"regex\":str|null, \"rule_text\":str|null, \"message\":str|null, \"confidence\":float}

For Stop-hook targets supply 'regex' (Python regex, no slashes).
For pre_* targets supply 'regex' (POSIX ERE for grep -E) AND 'message' (one-line block message).
For CLAUDE.md supply 'rule_text' (one-line behavioral rule).
Set confidence below 0.5 if the user's frustration is unrelated to assistant behavior.

USER (frustrated): $PROMPT

PRIOR ASSISTANT TURN: $LAST_ASSISTANT"

    DRAFT=$(claude -p "$DRAFT_PROMPT" 2>/dev/null || true)

    if [[ -z "$DRAFT" ]]; then
        echo "$(date '+%F %T') | CLAUDE_NO_OUTPUT" >> "$LOG"
        exit 0
    fi

    DRAFT_CLEAN=$(echo "$DRAFT" | sed -E '/^```/d')

    CONFIDENCE=$(echo "$DRAFT_CLEAN" | jq -r '.confidence // 0' 2>/dev/null || echo "0")
    TARGET=$(echo "$DRAFT_CLEAN" | jq -r '.target // empty' 2>/dev/null || echo "")
    REGEX=$(echo "$DRAFT_CLEAN" | jq -r '.regex // empty' 2>/dev/null || echo "")
    RULE_TEXT=$(echo "$DRAFT_CLEAN" | jq -r '.rule_text // empty' 2>/dev/null || echo "")
    MESSAGE=$(echo "$DRAFT_CLEAN" | jq -r '.message // empty' 2>/dev/null || echo "")
    SUMMARY=$(echo "$DRAFT_CLEAN" | jq -r '.summary // empty' 2>/dev/null || echo "")

    THRESHOLD="${FRUSTRATION_CONF_MIN:-0.6}"
    KEEP=$(awk -v c="$CONFIDENCE" -v t="$THRESHOLD" 'BEGIN { print (c+0 >= t+0) ? "1" : "0" }')
    if [[ "$KEEP" != "1" ]]; then
        echo "$(date '+%F %T') | LOW_CONF conf=$CONFIDENCE thresh=$THRESHOLD target=$TARGET summary=$SUMMARY" >> "$LOG"
        exit 0
    fi

    HELPER="$HOME/.shared-hooks/apply_auto_rule.py"
    if [[ ! -f "$HELPER" ]]; then
        echo "$(date '+%F %T') | NO_HELPER target=$TARGET" >> "$LOG"
        exit 0
    fi

    ARGS=(--target "$TARGET" --summary "$SUMMARY" --cwd "$CWD")
    if [[ -n "$REGEX" && "$REGEX" != "null" ]]; then
        ARGS+=(--regex "$REGEX")
    fi
    if [[ -n "$RULE_TEXT" && "$RULE_TEXT" != "null" ]]; then
        ARGS+=(--rule-text "$RULE_TEXT")
    fi
    if [[ -n "$MESSAGE" && "$MESSAGE" != "null" ]]; then
        ARGS+=(--message "$MESSAGE")
    fi

    HOOK_EDIT_AUTHORIZED=1 python3 "$HELPER" "${ARGS[@]}" >> "$LOG" 2>&1 || true
) >/dev/null 2>&1 &
disown

echo "$(date '+%F %T') | DISPATCHED prompt=${PROMPT:0:120}" >> "$LOG"
exit 0
