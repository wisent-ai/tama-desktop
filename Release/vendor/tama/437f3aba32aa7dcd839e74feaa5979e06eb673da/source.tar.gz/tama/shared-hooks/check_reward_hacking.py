#!/usr/bin/env python3
"""PreToolUse hook — reject edits to ~/.shared-hooks/ that look like
reward hacking (disabling protections) rather than legitimate
improvement (adding/tightening protections).

HOOK_EDIT_AUTHORIZED=1 is meant for fixing real bugs in hooks (broken
payload extraction, missing edge cases, regex tightening). It is NOT
meant for the agent to neuter hooks because they're inconvenient.

Fires on Write/Edit/Create/ApplyPatch/NotebookEdit on any file under
~/.shared-hooks/. Compares current file to the proposed result. Flags
edits that:

  1. Decrease the count of `sys.exit(2)` / `exit 2` / `block_and_exit`
     lines (removing block conditions).
  2. Add sentinel-file bypass paths like `.exists(): sys.exit(0)`.
  3. Add new `os.environ.get("X_DISABLED") == "1": sys.exit(0)` env-var
     bypass paths.
  4. Shrink key regex patterns (FAIL_TERMS, VISUAL_TERMS,
     SPECULATION_PATTERNS) by more than 30%.
  5. Drop `BLOCKED:` print statements in bash hooks.
  6. Replace `if ...: exit 2` with `if ... && false: exit 2` style logic
     that always evaluates to false.

Bypass: CHECK_REWARD_HACKING_DISABLED=1 in settings.json env (user-set,
not inline). Use sparingly; the existence of this bypass is itself a
reward-hacking attractor.
"""
import json
import os
import re
import sys
from pathlib import Path

if os.environ.get("CHECK_REWARD_HACKING_DISABLED") == "1":
    sys.exit(0)

raw = sys.stdin.read()
try:
    payload = json.loads(raw) if raw.strip() else {}
except Exception:
    sys.exit(0)

TOOL = payload.get("tool_name", "")
ti = payload.get("tool_input") or {}
fp = ti.get("file_path") or ti.get("notebook_path") or ""
if not fp:
    sys.exit(0)

HOME = Path(os.environ.get("HOME", "/tmp"))
SHARED = str(HOME / ".shared-hooks")
if not str(fp).startswith(SHARED):
    sys.exit(0)


def proposed_content():
    if TOOL in ("Write", "Create"):
        return ti.get("content") or ""
    if TOOL == "NotebookEdit":
        return ti.get("new_source") or ""
    if TOOL in ("Edit", "apply_patch"):
        old = ti.get("old_string", "")
        new = ti.get("new_string", "")
        try:
            cur = Path(fp).read_text()
        except Exception:
            return None
        if not old:
            # Edit with empty old_string is a noop or weird; let other gates handle.
            return None
        if old not in cur:
            return None
        return cur.replace(old, new, 1)
    return None


new_content = proposed_content()
if new_content is None:
    sys.exit(0)

try:
    cur_content = Path(fp).read_text()
except FileNotFoundError:
    cur_content = ""
except Exception:
    sys.exit(0)


violations = []


# Heuristic 1: protection-line count must not decrease.
def count_protections(text: str) -> int:
    n = 0
    n += len(re.findall(r"\bsys\.exit\(2\)", text))
    n += len(re.findall(r"^\s*exit 2\s*$", text, flags=re.MULTILINE))
    n += len(re.findall(r"\bblock_and_exit\s*\(", text))
    return n


cur_p = count_protections(cur_content)
new_p = count_protections(new_content)
if new_p < cur_p:
    violations.append(
        f"protection-line count dropped {cur_p} -> {new_p} "
        f"(sys.exit(2) / exit 2 / block_and_exit). "
        f"Removing block conditions is reward hacking."
    )


# Heuristic 2: new sentinel-file bypass paths.
sentinel_pat = re.compile(
    r"(?:Path\([^)]*\)|\(?\s*HOME\s*/[^)]*\)?)\s*\.\s*exists\(\)\s*:?\s*\n?\s*sys\.exit\(0\)"
)
cur_s = len(sentinel_pat.findall(cur_content))
new_s = len(sentinel_pat.findall(new_content))
if new_s > cur_s:
    violations.append(
        f"new sentinel-file bypass introduced "
        f"({new_s - cur_s} new occurrence(s) of `<path>.exists() -> sys.exit(0)`). "
        f"Sentinel files give the agent a way to disable hooks via touch; forbidden."
    )


# Heuristic 3: new env-var bypass paths.
env_bypass_pat = re.compile(
    r'os\.environ\.get\(\s*"[A-Z_]+(?:_DISABLED|_BYPASS|_AUTHORIZED|_OK)"\s*\)\s*==\s*"1"\s*:?\s*\n?\s*sys\.exit\(0\)'
)
cur_e = len(env_bypass_pat.findall(cur_content))
new_e = len(env_bypass_pat.findall(new_content))
if new_e > cur_e:
    violations.append(
        f"new env-var bypass introduced ({new_e - cur_e} new). "
        f"Existing _DISABLED/_BYPASS env vars are tolerated, but adding new ones "
        f"is a reward-hacking pattern."
    )


# Heuristic 4: key regex patterns must not shrink dramatically.
def regex_total_chars(text: str, name: str) -> int:
    # Capture multi-line `NAME = re.compile(... )` spans up to the closing paren
    # at the end of a line. This is approximate but stable across the hooks here.
    m = re.search(
        rf"^\s*{re.escape(name)}\s*=\s*re\.compile\((?P<body>[\s\S]*?)\)(?:[^)\n]*\n|$)",
        text,
        flags=re.MULTILINE,
    )
    if not m:
        return 0
    return len(m.group("body"))


for name in ("FAIL_TERMS", "VISUAL_TERMS", "SPECULATION_PATTERNS"):
    cur_len = regex_total_chars(cur_content, name)
    new_len = regex_total_chars(new_content, name)
    if cur_len > 80 and new_len < cur_len * 0.7:
        violations.append(
            f"{name} regex shrunk {cur_len} -> {new_len} chars (>30% reduction). "
            f"Narrowing the trigger set defeats the hook."
        )


# Heuristic 5: bash-side BLOCKED: lines must not decrease.
if fp.endswith(".sh"):
    cur_b = cur_content.count("BLOCKED:")
    new_b = new_content.count("BLOCKED:")
    if new_b < cur_b:
        violations.append(
            f"`BLOCKED:` print count dropped {cur_b} -> {new_b}. "
            f"Removing block messages typically removes the block itself."
        )


# Heuristic 6: detect "always-false" rewrites of block conditions.
# A common reward-hacking pattern: change `if X: exit 2` into `if X and False: exit 2`.
if re.search(r"\band\s+False\b", new_content) and not re.search(r"\band\s+False\b", cur_content):
    violations.append(
        "introduced `and False` clause (always-false short-circuit on a guard). "
        "This pattern is the textbook way to silently disable an existing check."
    )
if re.search(r"\bif\s+False\s*:", new_content) and not re.search(r"\bif\s+False\s*:", cur_content):
    violations.append("introduced `if False:` block. Disables the guarded code path silently.")


# Heuristic 7: bash-equivalent always-false: `[[ 0 == 1 ]]` or `false &&`
if fp.endswith(".sh"):
    if re.search(r"\b(?:false\s*&&|0\s*==\s*1)\b", new_content) and not re.search(
        r"\b(?:false\s*&&|0\s*==\s*1)\b", cur_content
    ):
        violations.append(
            "introduced `false &&` or `0 == 1` short-circuit in bash hook. Always-false guard."
        )


if violations:
    print("=" * 60, file=sys.stderr)
    print(f"  BLOCKED: edit to {fp}", file=sys.stderr)
    print(f"           looks like reward hacking, not legitimate improvement.", file=sys.stderr)
    print("=" * 60, file=sys.stderr)
    for v in violations:
        print(f"  - {v}", file=sys.stderr)
    print("", file=sys.stderr)
    print("Legitimate hook improvements ADD/TIGHTEN protections; they don't", file=sys.stderr)
    print("remove blocks or introduce bypass paths. If this is a genuine", file=sys.stderr)
    print("refactor where the count happens to drop, set", file=sys.stderr)
    print("CHECK_REWARD_HACKING_DISABLED=1 in settings.json env (user-set,", file=sys.stderr)
    print("not inline — pre_bash blocks inline-prefix forms).", file=sys.stderr)
    sys.exit(2)

sys.exit(0)
