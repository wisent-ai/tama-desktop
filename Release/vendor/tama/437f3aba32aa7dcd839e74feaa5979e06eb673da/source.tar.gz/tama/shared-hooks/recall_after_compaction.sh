#!/bin/bash
# SessionStart hook (matcher: source=="compact"): after a compaction, dump the
# text-only transcript of the just-summarized session and inject it back as
# additionalContext so the resuming agent sees the full prior conversation —
# not just the compaction summary. This prevents the "lost background
# process" failure mode where the summary drops launches the agent made.
#
# Input (stdin, JSON):
#   { "session_id": "<uuid>", "cwd": "<path>", "transcript_path": "<jsonl>", "source": "compact" }
#
# Output (stdout, JSON):
#   { "hookSpecificOutput": { "hookEventName": "SessionStart", "additionalContext": "<transcript>" } }

set -euo pipefail

INPUT=$(cat)
SOURCE=$(echo "$INPUT" | jq -r '.source // empty')
SESSION_ID=$(echo "$INPUT" | jq -r '.session_id // empty')
CWD=$(echo "$INPUT" | jq -r '.cwd // empty')
TRANSCRIPT=$(echo "$INPUT" | jq -r '.transcript_path // empty')

# Only fire on compaction. Startup / resume from manual cmd should be no-ops.
if [[ "$SOURCE" != "compact" ]]; then
    exit 0
fi

RECALL="$HOME/.claude/scratch/recall_conversation.sh"
if [[ ! -x "$RECALL" ]]; then
    echo "recall_conversation.sh not found at $RECALL" >&2
    exit 0
fi

# recall_conversation.sh takes either a uuid or a basename, not an absolute
# path. Derive the uuid from transcript_path when present, else let recall
# pick the latest JSONL for the cwd's project dir.
if [[ -f "$TRANSCRIPT" ]]; then
    UUID=$(basename "$TRANSCRIPT" .jsonl)
else
    UUID=""
fi

LOG="$HOME/.shared-hooks/recall_after_compaction.log"

if [[ -n "$UUID" ]]; then
    TRANSCRIPT_TEXT=$(RECALL_CWD="$CWD" "$RECALL" "$UUID" 2>>"$LOG" || true)
else
    TRANSCRIPT_TEXT=$(RECALL_CWD="$CWD" "$RECALL" 2>>"$LOG" || true)
fi

if [[ -z "$TRANSCRIPT_TEXT" ]]; then
    echo "$(date '+%F %T') | EMPTY_RECALL session=$SESSION_ID cwd=$CWD" >>"$LOG"
    exit 0
fi

CHARS=${#TRANSCRIPT_TEXT}

# Claude Code caps SessionStart additionalContext at 10000 chars; oversize
# strings get file-replaced (silently from the agent's perspective). Instead
# of fighting that, write the full transcript to a stable known path and
# inject only a short pointer well under the cap. The resuming agent reads
# the file on demand with the Read tool when it needs pre-compaction context.
RECALL_DIR="$HOME/.shared-hooks/recall_dumps"
mkdir -p "$RECALL_DIR"
DUMP_FILE="$RECALL_DIR/${SESSION_ID}_$(date '+%Y%m%dT%H%M%S').txt"
printf '%s' "$TRANSCRIPT_TEXT" > "$DUMP_FILE"

echo "$(date '+%F %T') | RECALLED chars=$CHARS dump=$DUMP_FILE session=$SESSION_ID" >>"$LOG"

PAYLOAD="# Pre-compaction transcript pointer (recall_after_compaction.sh)
# Source JSONL: ${TRANSCRIPT:-${UUID}}
# Full text-only transcript: ${DUMP_FILE}
# Total chars: ${CHARS}
#
# The compaction summary you just received was auto-generated and may be
# wrong or incomplete. Read ${DUMP_FILE} with the Read tool — in full or
# in offset/limit slices for very large transcripts — when you need
# pre-compaction context the summary lost (background jobs, prior
# decisions, user directives, exact tool outputs). Do not rely on the
# summary alone for any non-trivial recall."

jq -n --arg ctx "$PAYLOAD" '{
  hookSpecificOutput: {
    hookEventName: "SessionStart",
    additionalContext: $ctx
  }
}'
