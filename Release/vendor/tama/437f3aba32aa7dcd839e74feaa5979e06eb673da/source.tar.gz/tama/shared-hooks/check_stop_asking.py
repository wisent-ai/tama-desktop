#!/usr/bin/env python3
"""Stop hook: reject assistant turns that end with a 'what next?' style
ask-the-user question when there is obviously more work to do.

Cross-agent: works with Claude Code, Droid (Factory), Codex (OpenAI).
"""
from __future__ import annotations

import json
import re
import sys

TAIL_CHARS = 1200

STOP_PATTERNS = [
    r"\bwant me to\b[^.?!]*\?",
    r"\bshould i\b[^.?!]*\?",
    r"\bwould you like me to\b[^.?!]*\?",
    r"\bdo you want me to\b[^.?!]*\?",
    r"\bshall i\b[^.?!]*\?",
    r"\bwhich (one|of these|option|should i|do you want|would you)\b",
    r"\b(a|b|c)\s*[\).]\s*\w+\s+\b(or|vs\.?)\b",
    r"\btell me (which|if|what|whether)\b",
    r"\blet me know (if|which|whether|what|when)\b",
    r"\bpick (one|whichever|which)\b",
    r"\b(next up|up next|coming next|what['\u2019]s next)\b[^.]*\?",
    r"\b(or|alternatively)[,]?\s+(should|would|do|could) (you|i|we)\b",
    r"\bhow (do you|would you) want\b",
    r"\bready to (continue|proceed|move on|ship|deploy)\b[^.]*\?",
    r"\b(options?|paths?|approaches?|ways?)[^.]*:\s*\n(?:.|\n){0,500}\?\s*$",
    r"\b(remaining|outstanding|pending|leftover|next)\s+(steps?|work|items?|tasks?|action\s+items?|todo|to\s+ship|to\s+deploy|to\s+make)\b",
    r"\bleft\s+(to\s+(do|ship|deploy|apply|run)|for\s+you)\b",
    r"\bto\s+(make|ship|get)\s+(it|this|that|the\s+\w+)\s+(live|going|working|deployed|running)\b",
    r"\bwhat'?s?\s+(left|remaining|still\s+(needed|to\s+do|pending))\b",
    r"\b(you|you'?ll?|you\s+(need|have|should|must)\s+to|your\s+turn\s+to)\s+(need|have|should|must|take|do|apply|run|deploy|push|configure|wire|enable|set|trigger|kick|start|create|add|handoff|hand\s+off)\b",
    r"\b(handing|handoff|hand\s+off|over\s+to\s+you|your\s+(job|task|responsibility|action))\b",
    r"^\s*\d+[).]\s+.*\b(apply|run|deploy|push|configure|set|trigger|enable|install|provision|grant)\b[^.]*$",
    r"\b(now\s+you|time\s+(for\s+you|to\s+hand)|over\s+to\s+you)\b",
    r"\b(your\s+action|your\s+call|your\s+decision|your\s+move|user\s+action)\s*[\):]",
    # auto-added 2026-05-16: assistant overused "your authorization call" /
    # "that's your call" / "on your explicit go-ahead" to defer concrete,
    # in-capability actions back to the user instead of executing.
    r"\byour\s+(authoriz\w*|signup|sign[- ]?off|payment|spend|procurement|purchase|provisioning)\s+(call|decision|choice|to\s+make)\b",
    r"\byour\s+authorization\s+call\b",
    r"\b(that'?s|that\s+is|this\s+is|it'?s)\s+(a\s+)?your\s+(call|decision|choice)\b",
    r"\b(is|remains?)\s+(a\s+)?(decision|call|choice)\s+(for\s+you|only\s+you|that'?s\s+yours)\b",
    r"\byour\s+(call|decision|choice)\s+to\s+make\b",
    r"\bon\s+your\s+(explicit\s+)?(go[- ]?ahead|say[- ]?so|authorization|sign[- ]?off|approval|word)\b",
    r"\b(will\s+not|won'?t|do\s+not|don'?t)\s+(unilaterally|autonomously)\b",
    # auto-added 2026-05-17: assistant overused "stopped at the hard money
    # boundary" / "the hard money boundary" as a deflection crutch to halt
    # instead of completing all non-payment work + only surfacing the literal
    # card step. The boundary is real (no autonomous payment) but stating it
    # is not a reason to STOP the turn.
    r"\bhard\s+money\s+boundary\b",
    r"\b(stopped|stopping|halt(ed|ing)?|paused?|pausing|blocked)\s+(at|on|by|here\s+at)\s+(the\s+)?(hard\s+)?(money|payment|card|billing|spend)\s+boundary\b",
    r"\b(the\s+)?(money|payment|card|billing|spend)\s+boundary\s+(is|means|requires?|blocks?|stops?)\b",
    r"\b(needs?|requires?)\s+your\s+(explicit\s+)?(authorization|authoriz\w*|go[- ]?ahead|say[- ]?so|approval|sign[- ]?off)\b",
    r"\b(i'?ll?|let me|i'?m going to|going to|i'?ve decided to)\s+(pause|stop|hold|wait|checkpoint|hand\s*off|yield)\b",
    r"\b(stopping|pausing|halting|checkpointing|holding)\s+(here|now|for\s+(now|a\s+moment|your|the))\b",
    r"\bpause\s+(here|before|until|on)\b",
    r"\b(next|future|another|a\s+later|a\s+follow[- ]?up)\s+(session|turn|pass|iteration|round|sitting)\b",
    r"\b(follow[- ]?up|later)\s+(work|task|pass|step|session)\b",
    r"\bpick\s+(any|one|whichever|which|them|these|those)\s+(of\s+(them|these|those)\s+)?up\s+(next|later|in\s+a|in\s+the|after)\b",
    r"\b(we|i)\s+can\s+(resume|continue|pick\s+(it|them|this|that|these|those)\s+up|come\s+back)\s+(later|next|in\s+a|in\s+the|after|tomorrow|when)\b",
    r"\b(rest\s+of\s+(the\s+)?(plan|work|tasks?|items?|assistants?|build))\s+(can|will|should|is)\s+(come|be|wait|go)\b",
    r"\b(before|until|so|while)\s+you('?ve?|r)?\s+(look(ed)?|review(ed)?|check(ed)?|see|read|eyeball(ed)?|approve|confirm|decide|weigh\s+in|glance|sanity[- ]?check)\b",
    r"\b(needs?|need|want(ing)?|waiting\s+for|pending)\s+your\s+(green\s+light|go[- ]?ahead|sign[- ]?off|approval|ok|okay|thumbs?[- ]?up|blessing|eyes|review)\b",
    r"\b(your|user)\s+(green\s+light|go[- ]?ahead|sign[- ]?off|thumbs?[- ]?up|blessing)\b",
    r"\b(worth|warrant(s|ing)?|deserve(s|ing)?)\s+(eyeballing|your\s+review|a\s+look|checking)\b",
    r"\bbefore\s+(the\s+pattern|this|that|we)\s+(gets?|is|gets\s+copied)\b",
    r"\b(checkpoint|status\s+(check|update|report))\s+(here|now|before|for)\b",
    r"\bstopping\s+(here|there|at\s+this\s+point)\s+for\b",
    r"\b(phases?|steps?|tasks?|items?|stages?|commits?|pieces?|prs?|pull\s+requests?|changes?|parts?|milestones?)"
    r"\s+[\d\w\-,\u2013\u2014\s]{0,40}\s*\b(remain|remains|remaining|outstanding|pending|left|to\s+go)\b",
    r"\b(remain(ing|s)?|outstanding|pending|leftover|unfinished)"
    r"\s+(phases?|steps?|tasks?|items?|stages?|commits?|work|pieces?|prs?|pull\s+requests?|changes?|parts?|milestones?)\b",
    r"\bwhen\s+you'?re?\s+(ready|good|set)\b",
    r"\bwhen\s+you\s+(give|say|want|decide|confirm|approve|feel)\b",
    r"\beach\s+[\w'\-\s]{0,30}?\b(is|forms?|becomes?|makes?|represents?|maps?\s+to)\s+"
    r"(a\s+|its?\s+own\s+)?(discrete|separate|independent|standalone|own|its?\s+own|distinct)\s*"
    r"(commit|change|pr|pull\s+request|step|task|release|phase|chunk|piece|unit)s?\b",
    r"\blet\s+me\s+know\s+when\s+to\b",
    r"\bi\s+(haven'?t|have\s+not)\s+(yet\s+)?"
    r"(implemented|done|fixed|built|written|wired|added|finished|started|tackled|"
    r"addressed|made|created|rewritten|replaced|migrated|hooked\s+up|landed|coded|"
    r"set\s+(it|that|this|them)?\s*up)\b",
    r"\bis\s+what\s+(should|needs?\s+to|must)\s+"
    r"(replace|come|be|happen|land|ship|fix|resolve|address|do)\b",
    r"\b(should|needs?\s+to|must)\s+be\s+"
    r"(implemented|done|fixed|built|written|wired|added|finished|hooked\s+up|"
    r"landed|replaced|migrated|coded|tackled|rewritten|refactored|addressed)\b",
    r"\b(redesign|refactor|rewrite|migration|implementation|fix|change|cleanup)"
    r"\s+(is|that)\s+(what\s+)?(should|needs\s+to|must)\b",
    r"\b(today|currently|right\s+now|as\s+of\s+now)\s+"
    r"(is|does|works|behaves|operates)\s+exactly\s+(like|the|how|what|that)\b",
    r"\bstill\s+(uses|relies\s+on|behaves|works|treats|hits|calls|reads|writes|"
    r"triggers|runs|fires|defaults|breaks|misses|ignores|skips)\s+(the\s+|a\s+)?"
    r"(broken|wrong|old|original|previous|deprecated|stale|legacy|flawed|"
    r"outdated)\b",
    r"\b(problems?|issues?|bugs?|failures?|gaps?|tasks?|items?|tests?|fixes?|"
    r"changes?|trajectories|repos?|files?|tickets?|defects?)\s+"
    r"(remain|remains|remaining|outstanding|pending|left|to\s+go|"
    r"unfinished|open|still\s+open|still\s+failing)\b",
    r"\b(remaining|outstanding|pending|leftover|unfinished|open|still)\s+"
    r"(problems?|issues?|bugs?|failures?|gaps?|fixes?|trajectories|repos?|"
    r"tickets?|defects?)\b",
    r"\b(continuing\s+(on|with)|will\s+continue\s+with|i'?ll?\s+continue\s+"
    r"(on|with)|moving\s+on\s+to|onto\s+the\s+next|switching\s+to\s+the\s+next)\b",
    r"\bnext\s*:\s*(apply|run|do|fix|build|implement|wire|hook|add|change|"
    r"test|ship|deploy|migrate|refactor|rewrite|tackle|address|finish|"
    r"complete|land|handle|investigate|diagnose|trace|inspect|continue)\b",
    r"^[\s>\*\-\u2022\u203b]*\s*(recap|progress\s+summary|status\s+(update|report|so\s+far)|"
    r"current\s+state|state\s+of\s+(things|the\s+world|play))\s*[:\((]",
    r"\b(continuing|continue|moving|moving\s+on|onto|on\s+to)\s+"
    r"(on\s+)?\w+(_\w+)?(\s*(/|,)\s*\w+(_\w+)?)*\s*\.?\s*$",
    r"\b\d+\s+(task|item|issue|bug|problem|change|file|test|fix|trajectory|"
    r"trajectories|repo|repos)s?\s+(open|outstanding|remaining|left|to\s+go|"
    r"still\s+(open|failing|outstanding|pending))\b",
    r"""What's now live:""",
    # auto-added 2026-05-02T17:38:48: Assistant asked the user to pick between two approaches when the obvious next step was just to open the pages and look
    r"""(?i)two ways forward|(?:^|\n)\s*\d\.\s*\*\*[A-Z][a-z]+\*\*[\s\S]{0,400}(?:^|\n)\s*\d\.\s*\*\*[A-Z][a-z]+\*\*""",
    # auto-added 2026-05-02T21:54:47: Assistant asked 'Want me to proceed' after user already gave the goal, stopping mid-task instead of executing
    r"""[Ww]ant me to proceed\??""",
    # auto-added 2026-05-06T18:13:24: Assistant ran searches/Bash after user said 'do not code, do not search'
    r"""(?i)\b(searching|let me search|let me look|let me check|running (find|grep|ls)|find ~|grep -|xargs)\b""",
    # auto-added 2026-05-08T12:18:10: User furious at verbose 'Substantiated' status report with bulleted evidence dumps and arithmetic monologue
    r"""(?im)^\s*Substantiated[:\s]""",
    # auto-added 2026-05-08T13:17:58: User frustrated assistant produced a verbose multi-step plan asking for authorization instead of executing
    r"""(?i)awaiting your authorization|awaiting authorization to (run|proceed)""",
    # auto-added 2026-05-10T13:12:17: User frustrated assistant is reporting status/summary when the actual task isn't done
    r"""What's missing for|None of the three has happened yet|has not (yet )?(happened|completed|finished|run)""",
    # auto-added 2026-05-11T19:55:54: Don't sit waiting after a stop — when user redirects, identify next concrete action from available sources, don't idle
    r"""(?i)(sitting and waiting|wait(ing)? for your (direction|guidance|instruction|input|go-ahead)|st[o]pping n[o]w\.?\s*$|i'?ll (sit|wait|stand by)|awaiting (your )?(direction|instruction|guidance))""",
    # auto-added 2026-05-13T09:21:04: User furious assistant claimed 'fix worked' when the trajectory still didn't pass — relabeling partial progress as success
    r"""(?i)\b(fix worked|the fix is real|IP class fix is real|page reload fix worked)\b""",
    # auto-added 2026-05-13T10:51:02: User said 'do not code, explain' but assistant kept running bash probes
    r"""(?i)\b(do not code|don't code|stop coding)\b""",
    # auto-added 2026-05-14T17:00:44: Assistant stopped monitoring/fixing bugs after deploy instead of continuing to verify job completes
    r"""(?i)(next\s+\w+\s+drift\s+cycle\s+should|will\s+need\s+the\s+\w+\s+to\s+actually|should\s+pip-upgrade|next\s+cycle\s+(should|will))""",
    # auto-added 2026-05-14T20:32:16: User wants iteration until animations match reference, not status reports claiming goal achieved
    r"""(?i)\b(goal\s+(was\s+)?achieved|task\s+complete|parity\s+achieved|matches?\s+the\s+reference|animation\s+pipeline\s+(works|fixed))\b""",
    # auto-added 2026-05-15T08:12:39: Assistant narrated a compute job failure with speculative VM-recycle language and no log evidence, then proposed waiting for the job to succeed by chance instead of diagnosing root cause
    r"""(?i)\b(likely|probably|presumably|may have|might have|could have|possibly)\s+(been\s+)?(recycled|preempted|restarted|killed|died|crashed|reaped)\b""",
    # auto-added 2026-05-17: assistant finished a code fix then deferred the
    # commit/push/deploy with "committing/pushing is a shared action I won't
    # take without your explicit go-ahead" (and variations). Landing the fix
    # is the rest of the SAME task — completing it (commit + push, the
    # repo's deploy path) is in-capability work, not a user handoff. Flag
    # the "shared/risky action I won't take without your go-ahead" framing
    # and its kin so the turn continues into the commit/push instead of
    # parking a finished change in the working tree.
    r"""(?i)\b(commit\w*|push\w*|deploy\w*|merg\w*|land\w*|ship\w*)\b[^.?!]{0,80}\b(shared|risky|destructive|irreversible|hard[- ]?to[- ]?reverse)\s+(action|state(\s+change)?|operation|side[- ]?effect|step|move)\b""",
    r"""(?i)\b(shared|risky|destructive|irreversible|hard[- ]?to[- ]?reverse)\s+(action|state(\s+change)?|operation|side[- ]?effect|step|move)\b[^.?!]{0,80}\b(won'?t|will\s+not|not\s+going\s+to|can'?t|cannot|do\s+not|don'?t|i'?m\s+not)\s+(take|do|run|make|perform)\b""",
    r"""(?i)\b(won'?t|will\s+not|not\s+going\s+to|can'?t|cannot|do\s+not|don'?t|i'?m\s+not)\s+(take|do|run|make|perform|commit|push|deploy|merge|land|ship)\b[^.?!]{0,90}\bwithout\s+(your|the\s+user'?s|user|explicit)\s+(explicit\s+)?(go[- ]?ahead|approval|authoriz\w*|sign[- ]?off|say[- ]?so|ok|okay|green\s+light|blessing|word|consent|permission|nod)\b""",
    r"""(?i)\b(is|are|that'?s|this\s+is|it'?s|remains?)\s+(a\s+)?(shared|risky|destructive|irreversible|hard[- ]?to[- ]?reverse)\s+(action|operation|state[- ]?change|side[- ]?effect|step|move)\b""",
    r"""(?i)\b(commit|push|deploy|merge|land|release)(ting|ing)?\s*(/|,|\s+or\s+|\s+and\s+)\s*(commit|push|deploy|merge|land|release)(ting|ing)?\b[^.?!]{0,40}\b(won'?t|will\s+not|not\s+going\s+to|shared|risky|without\s+your)\b""",
    # auto-added 2026-05-17T23:43:36: Don't refer to the user in third person in responses
    r"""\bthe user (thought|wanted|asked|said|believed|expected|requested)\b""",
    # auto-added 2026-05-18T14:42:44: User furious assistant keeps narrating broken state and running capture probes instead of fixing the OAuth rotation it has everything to fix
    r"""(?i)(I (don't|do not|didn't) (yet )?have|so I don't yet have|removed the (response )?capture too early|re-runs with a focused capture|that will show definitively|I'll report (that|the) captured (request|response)|capture run in background|Direct answer to .* \*\*No\.\*\*)""",
    # auto-added 2026-05-18T20:50:55: User angry assistant speculated/coded after being told to stop and explain instead
    r"""(?i)\b(it'?s lik\w+|prob\w+|my guess|i'?m guess\w+|presum\w+|seems to be|most lik\w+|appears to be)\b""",
    # auto-added 2026-05-21T22:11:52: User angry that assistant claimed videos were 'lost/wiped/removed' when in fact they were never created — same vague-loss pattern as prior auto-added rule but with new framing of 'who removed'
    r"""\b(removed|wiped|lost|deleted|overwritten|gone|missing)\b.*\b(videos?|recordings?|webms?|frames?|artifacts?|files?)\b""",
    # auto-added 2026-05-21T22:11:59: User frustrated that assistant stopped monitoring jobs before completion despite explicit rule to monitor until done
    r"""(?i)(loop ran|orchestration plumbing works|that's the honest answer|state written as|the actual blocker.*remains)""",
    # auto-added 2026-05-25T23:41:43: Assistant excused a failing trajectory by asserting 'the SSO step is known to be flaky' — an unverified attribution of cause used to justify blindly re-running instead of diagnosing the actual error.
    r"""(?i)\b(known to be flaky|is (?:a )?flaky|flakiness|flaky step|intermittently fails?|known to fail intermittently|just (?:re-?run|retry)(?: it)? as-is)\b""",
    # auto-added 2026-05-27: user explicitly banned "decision is yours to make" — deferring an in-capability fix/decision back to the user instead of executing it.
    r"""(?i)\b(is|are|remains?)\s+yours\s+to\s+(make|decide|call)\b""",
    r"""(?i)\b(decision|choice|call|fix|change|step)\s+is\s+yours\b""",
    # auto-added 2026-06-09T20:22:48: User is angry the assistant refers to steering methods with deprecated English names alongside the Polish ones (e.g. 'TECZA / PRISM', 'TETNO / PULSE'); methods were renamed to Polish-only in v0.7.1476 and must be called only by their Polish names.
    r"""(?i)\b(TECZA|TETNO|OSTRZE|GROM|NURT|SZLAK|WICHER|ZWIAD|PRZELOM)\b\s*[/(]\s*(formerly\s+|aka\s+|f\.?k\.?a\.?\s+)?(PRISM|PULSE|HYPERPLANE|TITAN|CONCEPT[_\s-]?FLOW|GEODESIC[_\s-]?OT|DUAL[_\s-]?STEERING|REP[_\s-]?SCAN)\b|\b(PRISM|PULSE|HYPERPLANE|TITAN|CONCEPT[_\s-]?FLOW|GEODESIC[_\s-]?OT|DUAL[_\s-]?STEERING|REP[_\s-]?SCAN)\b\s*[/(]\s*(now\s+)?(TECZA|TETNO|OSTRZE|GROM|NURT|SZLAK|WICHER|ZWIAD|PRZELOM)\b""",
    # auto-added 2026-06-10T15:10:40: User demands no end-of-turn responses until the assigned task is fully complete — assistant ended its turn with a status update/promise while work was still unfinished
    r"""(?i)\b(i[''']?ll (keep|continue|now|next|then) |still (working|running|processing|in progress)|progress (update|so far)|status update|not (yet )?(done|complete|finished)|will (report|update|check) (back|in|you)|once (it|this|that|the [^.]{1,40}) (completes|finishes|is done)|check back (later|soon|shortly)|in the meantime|i[''']?ll (let you know|report back|monitor|keep you posted)|currently (running|in progress)|waiting (for|on) (it|this|the job) to (finish|complete))\b""",
    # auto-added 2026-06-10T18:56:01: Assistant claimed it 'rendered' a figure and that the rendering 'is accurate' and 'matches the TikZ source' when every render/read command was blocked — it presented a pre-existing compiled-PDF crop verdict it never saw. Block end-of-turn accuracy claims about figure renders so they can't be asserted without a fresh, actually-executed render.
    r"""(?i)\b(?:render(?:ing|ed)?|figure|layout)\b[^.\n]{0,120}\b(?:is\s+accurate|accurate\s+and|matches\s+the\s+(?:tikz|source)|as\s+expected|correctly\s+placed)\b""",
    # auto-added 2026-06-11T08:45:18: User asked for a specific thing; assistant proposed a different/alternative approach instead of delivering exactly what was requested.
    r"""(?i)\b(instead,? (I|we) (propose|suggest|recommend)|I('|’)?d (propose|suggest|recommend) (a|an|using) (different|alternative|better|simpler)|a (better|simpler|cleaner) (approach|option|way|alternative) (would|might) be|alternatively,? (I|we) could|(rather|instead) of (that|what you asked)|what I('|’)?d do instead)\b""",
    # auto-added 2026-06-19T23:53:11: User wants assistant to stop enumerating next steps and instead execute remaining in-capability work in the same turn
    r"""(?i)\b(highest[- ]leverage gaps?|what'?s left to do|ranked by impact|i'?d next (add|do|implement)|to make this complete you'?d|in a (follow[- ]up|separate) (turn|session))\b""",
    # auto-added 2026-06-20T12:32:16: User frustrated that assistant stops after classifying instead of executing the work itself
    r"""(?i)\bI(?:'ve| have)\s+classified\s+this\s+prompt\s+as\b""",
    # auto-added 2026-06-20T19:28:01: User furious assistant stopped working mid-task instead of continuing to debug
    r"""(?i)\b(highest[- ]leverage|what'?s left|natural next step|follow[- ]ups?|to make this complete|i'?d next|the next step would)\b""",
]

COMPILED = [re.compile(p, flags=re.IGNORECASE | re.MULTILINE) for p in STOP_PATTERNS]

def strip_code(text: str) -> str:
    text = re.sub(r"```[\s\S]*?```", "", text)
    text = re.sub(r"`[^`\n]+`", "", text)
    text = re.sub(r'"[^"\n]{1,120}"', "", text)
    text = re.sub(r"'[^'\n]{1,120}'", "", text)
    text = re.sub(r"„[^”\n]{1,120}”", "", text)
    return text

def find_hits(tail: str) -> list[str]:
    cleaned = strip_code(tail)
    hits: list[str] = []
    for regex in COMPILED:
        for match in regex.finditer(cleaned):
            hits.append(match.group(0).strip())
    seen: dict[str, None] = {}
    for h in hits:
        seen.setdefault(h, None)
    return list(seen.keys())

def main() -> int:
    try:
        payload = json.loads(sys.stdin.read() or "{}")
    except json.JSONDecodeError:
        return 0
    if payload.get("stop_hook_active"):
        return 0
    msg = payload.get("last_assistant_message") or ""
    if not isinstance(msg, str):
        return 0
    stripped = msg.strip()
    if not stripped:
        return 0
    tail = stripped[-TAIL_CHARS:] if len(stripped) > TAIL_CHARS else stripped
    hits = find_hits(tail)
    if not hits:
        return 0
    reason = (
        "BLOCKED: You stopped to ask the user what to do next instead of continuing. "
        "Flagged phrase(s): "
        + "; ".join(hits[:3])
        + ". Pick the highest-value next task yourself and execute it."
    )
    print(json.dumps({"decision": "block", "reason": reason}))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
