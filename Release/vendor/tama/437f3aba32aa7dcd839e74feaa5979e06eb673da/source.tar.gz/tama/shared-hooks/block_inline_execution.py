#!/usr/bin/env python3
"""Reject agent tool payloads that contain throwaway inline programs."""

from __future__ import annotations

import json
import os
import sys
from typing import Any

from inline_execution_policy import inline_execution_reason


def load_payload() -> dict[str, Any]:
    try:
        value = json.loads(sys.stdin.read() or "{}")
    except (json.JSONDecodeError, ValueError):
        return {}
    return value if isinstance(value, dict) else {}


def main() -> int:
    reason = inline_execution_reason(load_payload())
    if reason is None:
        return os.EX_OK
    sys.stderr.write(
        "BLOCKED: inline code execution is forbidden. "
        "Put executable logic in a checked-in reusable file and run that file. "
        f"Detected: {reason}\n"
    )
    return os.EX_NOPERM


if __name__ == "__main__":
    raise SystemExit(main())
