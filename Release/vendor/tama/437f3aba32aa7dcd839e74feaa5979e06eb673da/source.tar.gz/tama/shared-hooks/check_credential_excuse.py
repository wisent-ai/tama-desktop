#!/usr/bin/env python3
"""Stop hook: block responses that frame missing credentials, API keys,
sign-ins, or service access as a blocker. The user has explicitly
classified this as a non-blocker — automate acquisition (weles
trajectory, headless OAuth, programmatic account creation) or pick a
credential-free local path. Forbidden framing: 'cannot proceed because
no Adobe ID / Tripo3D key / Mixamo sign-in is available'."""
import json, os, re, sys

PATTERNS = [
    r"\bblocked on (?:credentials?|api keys?|sign[- ]?ins?|adobe|mixamo|tripo|meshy|rodin|replicate)",
    r"\bblocked (?:until|because|by) [a-z ]*(credential|api key|sign[- ]?in|adobe|account|key)",
    r"\bexternal[- ]service paths? are unreachable",
    r"\b(decision|choice) (?:that|which)? ?(?:only|just) (?:you|the user) own",
    r"\b(?:credentials?|api keys?|sign[- ]?ins?) only (?:you|the user)",
    r"\bonly (?:you|the user) (?:can|own|need to|must) (?:provide|decide|grant|authorize|sign in)",
    r"\bup to (?:you|the user) to (?:provide|sign in|authorize|grant|install)",
    r"\bno (?:adobe|mixamo|tripo|meshy|rodin|replicate)[a-z ]* (?:credentials?|sign[- ]?in|cookies?|api keys?|tokens?)",
    r"\bdon\'?t have (?:adobe|mixamo|tripo|meshy|rodin|replicate)[a-z ]* (?:credentials?|sign[- ]?in|api keys?)",
    r"\bcannot (?:proceed|continue|use [a-z ]+) without (?:credentials?|api keys?|sign[- ]?ins?|adobe|tripo|meshy)",
    r"\b(?:requires?|needs?) (?:an? )?(?:adobe id|adobe account|mixamo (?:sign[- ]?in|account)|tripo3d api key|meshy api key)",
    r"\b(?:requires?|needs?) (?:a )?paid (?:api|service|subscription|plan|tier)",
    r"\bmulti[- ]hour (?:pytorch|cuda|install|setup)",
]
REASON = ("BLOCKED (credential-excuse): missing credentials/keys/sign-ins are "
          "not a blocker. Matched: {p!r}. Automate acquisition (weles browser "
          "sign-up, headless OAuth, programmatic account creation), pick a "
          "credential-free local path (open-source rigger, install deps), or "
          "proceed without that credential. Do not stop with credential "
          "framing. Set CHECK_CREDENTIAL_EXCUSE_DISABLED=1 to bypass.")

def main():
    if os.environ.get("CHECK_CREDENTIAL_EXCUSE_DISABLED") == "1":
        return 0
    try: payload = json.loads(sys.stdin.read())
    except Exception: return 0
    if payload.get("stop_hook_active"):
        return 0
    msg = payload.get("last_assistant_message") or ""
    for p in PATTERNS:
        if re.search(p, msg, re.IGNORECASE):
            sys.stdout.write(json.dumps({
                "decision": "block",
                "reason": REASON.format(p=p),
            }))
            return 0
    return 0

if __name__ == "__main__":
    sys.exit(main())
