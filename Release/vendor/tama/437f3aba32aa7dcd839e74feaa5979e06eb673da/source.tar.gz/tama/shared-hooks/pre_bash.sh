#!/bin/bash
# Consolidated PreToolUse hook for Bash/Execute (cross-agent)
# HARDENED: 2026-05-08 — broaden trajectory detection to any node *.mjs that
# uses WSession.start (catches probe scripts under .work/, /tmp/, etc), and
# add HOOK_EDIT_AUTHORIZED gate on Bash modifications of ~/.shared-hooks/.

set -euo pipefail

INPUT=$(cat)
CMD=$(echo "$INPUT" | jq -r '.tool_input.command // .tool_input.cmd // .command // .cmd // empty')
TOOL_WORKDIR=$(echo "$INPUT" | jq -r '.tool_input.workdir // .tool_input.cwd // .cwd // empty')
# Exact transcript path from the Claude Code hook payload. Passed through
# to check_artifact_inspection.py so it never has to guess which session
# JSONL is the active one (mtime/size heuristics fail under concurrent
# sessions, making the inspection gate permanently unsatisfiable).
TRANSCRIPT=$(echo "$INPUT" | jq -r '.transcript_path // empty')

if [[ -z "$CMD" ]]; then exit 0; fi

SYNTAX_ONLY_NODE_CHECK=0
if echo "$CMD" | grep -qE '^[[:space:]]*node[[:space:]]+--check[[:space:]]+[^[:space:];&|`]+\.(mjs|cjs|js)[[:space:]]*$'; then
    SYNTAX_ONLY_NODE_CHECK=1
fi


# Device-level Weles execution ban for this workstation. Weles browser/trajectory
# work must run through the approved API on the Mac mini, never locally here.
WELES_LOCAL_RE='((^|[[:space:];&|`(])(\.\.?/)?weles/|scripts/trajectories/|scripts/_shared/keeper/|keeper/(keeper|action)\.mjs|WSession\.start|weles-chromium|dist/session/wsession|WELES_ROOT|WELES_SECRET_RESULT_FILE)'
WELES_CWD_RE='(^|/)weles(/|$)'
if [[ "$SYNTAX_ONLY_NODE_CHECK" != "1" ]] && ( echo "$CMD" | grep -qiE "$WELES_LOCAL_RE" \
   || { echo "$TOOL_WORKDIR" | grep -qE "$WELES_CWD_RE" && echo "$CMD" | grep -qiE '(^|[;&|`(]|[[:space:]])(node|npm|npx|tsx|bun|deno|ts-node|bash|sh|zsh|dash)[[:space:]]|scripts/trajectories/|scripts/_shared/keeper/|keeper/(keeper|action)\.mjs|WSession\.start|weles-chromium|dist/session/wsession|WELES_ROOT|WELES_SECRET_RESULT_FILE'; } ); then
    echo "NIE ODPALAJ WELESA NA TYM KOMPUTERZE. TO JEST DOZWOLONE TYLKO PRZEZ API NA MACU MINI." >&2
    exit 2
fi
if echo "$CMD" | grep -qE '(^|[;&|`(])[[:space:]]*([A-Za-z_][A-Za-z0-9_]*=[^[:space:]]+[[:space:]]+)*(command[[:space:]]+)?([A-Za-z0-9_./~$-]*/)?supabase([[:space:]]|$)'; then
    echo "BLOCKED: Supabase CLI is forbidden for this agent. Use the approved app/service path or existing project automation; do not run supabase CLI." >&2
    exit 2
fi

# Direct provider and infrastructure CLIs bypass Tama's approved control planes,
# audit boundaries, and structured authorization. This is unconditional and
# covers read-only commands too: agents must use the dedicated tool/API instead.
DIRECT_CLOUD_CLI_RE='(^|[;&|`(]|then[[:space:]]|do[[:space:]])[[:space:]]*(([A-Za-z_][A-Za-z0-9_]*=[^[:space:];&|`]+|(sudo|command|env|nohup|time|xargs)([[:space:]]+-[^[:space:];&|`]+)*)[[:space:]]+)*([A-Za-z0-9_./~$-]*/)?(gcloud|gsutil|bq|aws|az|azd|oci|doctl|ibmcloud|aliyun|kubectl|helm|terraform|tofu|pulumi|flyctl|heroku|vercel|firebase|netlify|cloudflared)([[:space:];&|`)]|$)'
if echo "$CMD" | grep -qiE "$DIRECT_CLOUD_CLI_RE"; then
    echo "BLOCKED: direct cloud/infrastructure CLI commands are forbidden by Tama. Use the approved control plane or dedicated tool/API; do not invoke provider, cluster, IaC, or hosting CLIs directly." >&2
    exit 2
fi
if echo "$CMD" | grep -qE '(^|[;&|`(]|[[:space:]])git([^;&|`]*[[:space:]])?(commit|push)([[:space:]][^;&|`]*)?[[:space:]]--no-verify([[:space:]]|$|[;&|`])'; then
    echo "BLOCKED: Git hook bypass is forbidden for this agent. Run commit and push normally so device-level and repo-level hooks execute." >&2
    exit 2
fi
if echo "$CMD" | grep -qE '(^|[;&|`(]|[[:space:]])git([^;&|`]*[[:space:]])?commit([[:space:]][^;&|`]*)?[[:space:]]-[A-Za-z]*n[A-Za-z]*([[:space:]]|$|[;&|`])'; then
    echo "BLOCKED: git commit -n bypasses required hooks. Run commit normally so device-level and repo-level hooks execute." >&2
    exit 2
fi
if echo "$CMD" | grep -qiE 'lsi2\.ncbr\.gov\.pl/api|/api/beneficiary/|project-registries|registries-values|collection-objects'; then
    echo "BLOCKED: direct LSI/PARP/NCBR API usage is forbidden for this agent. Use the real UI flow only; do not call /api/beneficiary, project-registries, registries-values, or collection-objects directly." >&2
    exit 2
fi
if echo "$CMD" | grep -qiE 'overleaf\.com/project/[0-9a-f]{24}/(updates|diff|changes/users|latest/history|entities)\b|/project/([0-9a-f]{24}|\$\{?[A-Za-z_][A-Za-z0-9_]*\}?)/(updates|diff|changes/users|latest/history|entities)\b|fetch\([^)]*/project/[^)]*/(updates|diff|changes/users|latest/history|entities)\b'; then
    echo "YOU FUCKING RETARD USE THE DEDICATED WELES TRAJECTORY NOT THE OVERLEAF API" >&2
    exit 2
fi
if echo "$CMD" | grep -qE 'scripts/trajectories/overleaf/(phrase_history|history_scan)\.mjs'; then
    echo "YOU FUCKING RETARD USE THE DEDICATED WELES TRAJECTORY NOT THE OVERLEAF API" >&2
    exit 2
fi
OVERLEAF_SCRIPT=$(echo "$CMD" | grep -oE '([A-Za-z0-9_./~$-]+/)?scripts/trajectories/overleaf/[A-Za-z0-9_./~$-]+\.[mc]?[tj]sx?' | head -1 || true)
OVERLEAF_SCRIPT_PATH="$OVERLEAF_SCRIPT"
if [[ -n "$OVERLEAF_SCRIPT_PATH" ]] && [[ "$OVERLEAF_SCRIPT_PATH" != /* ]] && [[ -n "$TOOL_WORKDIR" ]]; then
    OVERLEAF_SCRIPT_PATH="$TOOL_WORKDIR/$OVERLEAF_SCRIPT_PATH"
fi
if [[ -n "$OVERLEAF_SCRIPT_PATH" ]] && [[ -f "$OVERLEAF_SCRIPT_PATH" ]]; then
    if grep -qiE '/(updates|diff|changes/users|latest/history|entities)\b' "$OVERLEAF_SCRIPT_PATH" 2>/dev/null && grep -qiE 'overleaf|/project/' "$OVERLEAF_SCRIPT_PATH" 2>/dev/null; then
        echo "YOU FUCKING RETARD USE THE DEDICATED WELES TRAJECTORY NOT THE OVERLEAF API" >&2
        exit 2
    fi
fi
if echo "$CMD" | grep -qiE '(^|[;&|`(]|[[:space:]])([A-Za-z0-9_./~$-]*python([0-9]+(\.[0-9]+)*)?|node|tsx|bun|deno|ts-node|bash|sh|zsh|dash)[[:space:]][^;&|`]*DO_NOT_RUN_quarantine_[0-9]+'; then
    echo "BLOCKED: files in DO_NOT_RUN_quarantine are retained only as evidence and must not be executed." >&2
    exit 2
fi
if echo "$CMD" | grep -qiE '(^|[;&|`(]|[[:space:]])([A-Za-z0-9_./~$-]*python([0-9]+(\.[0-9]+)*)?|node|tsx|bun|deno|ts-node|bash|sh|zsh|dash)[[:space:]][^;&|`]*\b(cdp_api|fetch_url|inspect_section|fetch_section_status|fetch_project_data_6_5|repair_6_5|wait_and_repair_6_5|save_6_financials|save_remaining_sections|clear_6_5|probe_6_5_correct_row|get_collection_list|save_[A-Za-z0-9_.-]*_(fetch|collection))\.(py|js|mjs|ts|tsx|sh)\b'; then
    echo "BLOCKED: this command runs a local direct-API helper for LSI/PARP/NCBR. Use the real UI flow only." >&2
    exit 2
fi

if echo "$CMD" | grep -qE 'OPENAI_API_KEY|CHATGPT_RANK_API_KEY|OPENAI_API_BASE|OPENAI_API_URL|api\.openai\.com|openai\.com/v1'; then
    echo "BLOCKED: OpenAI API key or endpoint usage is forbidden for this agent." >&2
    exit 2
fi

# v7_inline_hook_edit_block: HOOK_EDIT_AUTHORIZED= must come from
# ~/.claude/settings.json env block, not from inline command prefix.
if echo "$CMD" | grep -qE '^[[:space:]]*HOOK_EDIT_AUTHORIZED=' ; then
    echo "BLOCKED: HOOK_EDIT_AUTHORIZED must be set in settings.json env, not inline. (v7)" >&2
    exit 2
fi
# v7_broader_writes: any write/redirect/copy under ~/.shared-hooks/ — not just prefix-matched files.
if [[ "${HOOK_EDIT_AUTHORIZED:-}" != "1" ]]; then
    if echo "$CMD" | grep -qE '(>>?|cp |mv |tee |install )[[:space:]]*[^[:space:]]*\.shared-hooks/'; then
        echo "BLOCKED: writes to ~/.shared-hooks/ require HOOK_EDIT_AUTHORIZED=1 in settings.json. (v7)" >&2
        exit 2
    fi
fi
# v7_block_invoking_scripts_under_shared_hooks: bash/sh/zsh/dash invocations of any script under ~/.shared-hooks/.
if [[ "${HOOK_EDIT_AUTHORIZED:-}" != "1" ]]; then
    if echo "$CMD" | grep -qE '(^|[;&|`(]|\s)(bash|sh|zsh|dash)[[:space:]]+[^[:space:]]*\.shared-hooks/'; then
        echo "BLOCKED: invoking scripts under ~/.shared-hooks/ requires HOOK_EDIT_AUTHORIZED=1 in settings.json. (v7)" >&2
        exit 2
    fi
fi

# === Block Bash modifications of ~/.shared-hooks/ without authorization ===
if [[ "${HOOK_EDIT_AUTHORIZED:-}" != "1" ]]; then
    if echo "$CMD" | grep -qE '(>>?|cp |mv |tee |install )\s*[^[:space:]]*\.shared-hooks/(pre_|post_|check_|inspect_|detect_|apply_)'; then
        echo "BLOCKED: Modifying ~/.shared-hooks/ requires HOOK_EDIT_AUTHORIZED=1 (user-set). Hook patches go through the Edit tool, not Bash redirects." >&2
        exit 2
    fi
    if echo "$CMD" | grep -qE 'cat\s*>\s*[^[:space:]]*\.shared-hooks/(pre_|post_|check_|inspect_|detect_|apply_)'; then
        echo "BLOCKED: Modifying ~/.shared-hooks/ requires HOOK_EDIT_AUTHORIZED=1 (user-set)." >&2
        exit 2
    fi
fi

STATE_DIR="$HOME/.shared-hooks/state"
STATE_FILE="$STATE_DIR/trajectory_runs.json"
mkdir -p "$STATE_DIR" 2>/dev/null
[ -f "$STATE_FILE" ] || echo '{}' > "$STATE_FILE"

# Detect trajectory/probe invocation. Two paths:
#   (a) canonical: node ...scripts/trajectories/...mjs
#   (b) any other node ...*.mjs whose SOURCE contains WSession.start —
#       catches probe scripts under .work/, /tmp/, anywhere the agent
#       invents a one-off filename to dodge the canonical regex.
TRAJ_MATCH=$(echo "$CMD" | grep -oE 'scripts/trajectories/[A-Za-z0-9_./-]+\.[mc]?[tj]sx?' | head -1 || true)
if [[ "$TRAJ_MATCH" == *"keeper/action.mjs" ]]; then TRAJ_MATCH=""; fi
# (b) Detection broadened to all common JS/TS runners and source extensions:
#       node | tsx | bun | deno | ts-node | npx
#     Source extension: .mjs | .cjs | .js | .mts | .cts | .ts | .tsx | .jsx
#     Catches `tsx probe.ts`, `bun probe.mjs`, `deno run probe.ts`, etc —
#     all common ways to run a Playwright/weles script.
if [[ -z "$TRAJ_MATCH" ]]; then
    SCRIPT_PATH=$(echo "$CMD" | grep -oE '(node|tsx|bun|deno|ts-node|npx)([[:space:]]+(run|--[A-Za-z0-9_-]+(=[^[:space:]]+)?))*[[:space:]]+[A-Za-z0-9_./~$-]+\.[mc]?[tj]sx?' | grep -oE '[A-Za-z0-9_./~$-]+\.[mc]?[tj]sx?$' | head -1 || true)
    if [[ -n "$SCRIPT_PATH" ]] && [[ -f "$SCRIPT_PATH" ]] && grep -qE 'WSession\.start|wsession\.start' "$SCRIPT_PATH" 2>/dev/null; then
        TRAJ_MATCH="$SCRIPT_PATH"
    fi
fi
if [[ -n "$TRAJ_MATCH" ]]; then
    LABEL=$(basename "$TRAJ_MATCH" | sed -E 's/\.[mc]?[tj]sx?$//')
    DIR=$(dirname "$TRAJ_MATCH" | xargs basename)
    KEY="${DIR}/${LABEL}"
    PRIOR=$(jq -r --arg k "$KEY" '.[$k].runs_since_inspection // 0' "$STATE_FILE")
    NEW=$((PRIOR + 1))

    # Check artifact-inspection BEFORE incrementing the counter so the
    # check_artifact_inspection.py first-run gate (`runs == 0 and not
    # recordings` → require WELES_FIRST_RUN=1 or 200+ char inspection.md)
    # is actually reachable on the first run. Previously the increment
    # happened first, so runs was always >= 1 by the time the python
    # script saw it and the first-run gate was dead code.
    if command -v python3 >/dev/null 2>&1; then
        if ! python3 "$HOME/.shared-hooks/check_artifact_inspection.py" "$LABEL" "$CMD" "$TRANSCRIPT"; then
            exit 2
        fi
    fi

    jq --arg k "$KEY" --arg n "$NEW" '.[$k].runs_since_inspection = ($n | tonumber) | .[$k].last_run_at = (now | strftime("%Y-%m-%dT%H:%M:%SZ"))' "$STATE_FILE" > "$STATE_FILE.tmp" && mv "$STATE_FILE.tmp" "$STATE_FILE"

    if [[ $NEW -ge 3 ]]; then
        echo "BLOCKED: trajectory '$KEY' run #${NEW} without inspection." >&2
        echo "Use \$HOME/.shared-hooks/inspect_trajectory.sh ${LABEL} to unblock." >&2
        exit 2
    fi
fi

INSPECT_TRIGGER=0
if echo "$CMD" | grep -qE 'inspect_trajectory\.sh\b'; then INSPECT_TRIGGER=1; fi
if echo "$CMD" | grep -qE '\.work/\.artifact_inspected/'; then INSPECT_TRIGGER=1; fi
if echo "$CMD" | grep -qE 'keeper/action\.mjs\s+(dump|screenshot|eval|url)\b'; then INSPECT_TRIGGER=1; fi
if [[ "$INSPECT_TRIGGER" == "1" ]]; then
    jq 'to_entries | map(.value.runs_since_inspection = 0 | .value.last_inspection_at = (now | strftime("%Y-%m-%dT%H:%M:%SZ"))) | from_entries' "$STATE_FILE" > "$STATE_FILE.tmp" 2>/dev/null && mv "$STATE_FILE.tmp" "$STATE_FILE" || true
fi

if echo "$CMD" | grep -qiE '(>|cp |mv |tee ).*/to_check/'; then
    echo "BLOCKED: NEVER write to to_check folders." >&2; exit 2
fi
if echo "$CMD" | grep -qE '(>>?|cp |mv |tee )\s*/tmp/[^[:space:];|&]+\.(py|sh|js|ts|mjs|rb|pl|php|lua)'; then
    echo "BLOCKED: Don't write scratch script files to /tmp/." >&2; exit 2
fi
if echo "$CMD" | grep -qE 'cat\s*>\s*/tmp/[^[:space:];|&]+\.(py|sh|js|ts|mjs|rb|pl|php|lua)'; then
    echo "BLOCKED: No 'cat > /tmp/file.py <<EOF'." >&2; exit 2
fi
if echo "$CMD" | grep -qE '(^|[;&|`(]|\s)(python[0-9.]?|node|ruby|perl|bash|sh|zsh|dash|php)\s+/tmp/'; then
    echo "BLOCKED: Don't execute scripts under /tmp/." >&2; exit 2
fi
if echo "$CMD" | grep -qE '(^|\[;&|] *)(sh|bash|zsh|dash) +-c '; then
    echo "BLOCKED: No inline shell scripts." >&2; exit 2
fi
if echo "$CMD" | grep -qE 'python[0-9.]?\s+(-c|--command)'; then
    echo "BLOCKED: No inline python scripts." >&2; exit 2
fi
if echo "$CMD" | grep -qE 'python[0-9.]?\s+<<'; then
    echo "BLOCKED: No inline python heredoc." >&2; exit 2
fi
if echo "$CMD" | grep -qE '(^|\[;&|] *)(node|npx) +(-e|--eval|-p|--print)'; then
    echo "BLOCKED: No inline node scripts." >&2; exit 2
fi
if echo "$CMD" | grep -qE '(^|\[;&|] *)(ruby|perl) +(-e|--execute)'; then
    echo "BLOCKED: No inline ruby/perl scripts." >&2; exit 2
fi
if echo "$CMD" | grep -qE 'ANTHROPIC_API_KEY|@anthropic-ai/sdk|api\.anthropic\.com'; then
    echo "BLOCKED: Use the product's finite Stado model adapter with HTTPS \$STADO_MODEL_ROUTER_URL, its product-scoped bearer, an allowlisted STADO_<PRODUCT>_*_MODEL route, and body-bound agent identity." >/dev/stderr; exit "$((!false+!false))"
fi
if echo "$CMD" | grep -qE '(^|\[;&|] *)git\s+commit\b'; then
    if echo "$CMD" | grep -qiE 'Co-Authored-By:[[:space:]].*(Claude|@anthropic\.com|factory-droid\[bot\])'; then
        echo "BLOCKED: Co-Authored-By Claude trailer." >&2; exit 2
    fi
fi
if echo "$CMD" | grep -qE '(^|\s)gh\s+pr\s+(create|merge)\b'; then
    if echo "$CMD" | grep -qE 'wisent-supabase-(wisent-app|content-platform)'; then
        echo "BLOCKED: No PRs against wisent-supabase-* repos." >&2; exit 2
    fi
fi
if echo "$CMD" | grep -qE '(^|[;&|`(]|\s)ssh\s'; then
    if echo "$CMD" | grep -qE 'ssh[^|<]*\b(rm|rmdir|dd|mkfs|shred|truncate|fdisk|find[^|]*-delete)\b'; then
        echo "BLOCKED: destructive op over SSH." >&2; exit 2
    fi
    if echo "$CMD" | grep -qE 'charless-mac-mini\.tail6443b3\.ts\.net|charless@charless-mac-mini'; then
        :
    elif [[ "${SSH_AUTHORIZED:-}" != "1" ]]; then
        echo "BLOCKED: ssh requires SSH_AUTHORIZED=1." >&2; exit 2
    fi
fi
if echo "$CMD" | grep -qE '(^|\s)wisent\s'; then
    FORBIDDEN_FLAGS="--limit|--max-pairs|--max-samples|--num-samples|--batch-size|--max-iterations|--n-pairs|--sample-size|--subset|--quick"
    if echo "$CMD" | grep -qE "(^|\s)(${FORBIDDEN_FLAGS})(\s|=|$)"; then
        MATCHED=$(echo "$CMD" | grep -oE "(${FORBIDDEN_FLAGS})" | head -1)
        echo "BLOCKED: Override flag '${MATCHED}' is forbidden." >&2; exit 2
    fi
fi

# === Block wc submit pinning a single provider without explicit auth ===
# wisent-compute supports gcp/aws/azure/local. Pinning the job to one
# provider (--pin-provider, or --provider <X> on submit) takes a routing
# decision the user owns. Require WC_PIN_AUTHORIZED=1 to opt in.
if echo "$CMD" | grep -qE '(^|[;&|`(]|\s)wc\s+submit\b'; then
    if [[ "${WC_PIN_AUTHORIZED:-}" != "1" ]]; then
        if echo "$CMD" | grep -qE '(^|\s)--pin-provider(\s|$)'; then
            echo "BLOCKED: 'wc submit --pin-provider' restricts the wisent-compute job to one backend (gcp/aws/azure/local). The user has not authorized that. Set WC_PIN_AUTHORIZED=1 to override." >&2; exit 2
        fi
        if echo "$CMD" | grep -qE '(^|\s)--provider(\s|=)(gcp|aws|azure|local)\b'; then
            echo "BLOCKED: 'wc submit --provider <X>' selects a single wisent-compute backend. Submit without --provider so any provider can claim, or set WC_PIN_AUTHORIZED=1 with explicit user OK." >&2; exit 2
        fi
    fi
fi

# === Block git checkout outright ===
# 2026-05-13: I silently overwrote uncommitted CDP-path code in
# src/human/mouse-native.ts and src/human/keyboard.ts by running
# `git checkout 7978acf -- src/human/mouse-native.ts src/human/keyboard.ts`.
# The user had not authorized the revert. `git checkout <ref> -- <path>`
# and `git checkout -- <path>` both destroy working-tree changes with no
# prompt and no backup. There is no valid use that `git switch` (for
# branches) or `git restore` (for files, requires explicit --staged /
# --worktree / --source) cannot do more safely. Ban it.
if echo "$CMD" | grep -qE '(^|[;&|`(]|\s)git\s+checkout(\s|$)'; then
    echo "BLOCKED: 'git checkout' is forbidden — it silently destroys uncommitted working-tree changes. Use 'git switch <branch>' for branch changes or 'git restore --source=<ref> <path>' for file restoration (which still requires explicit --worktree to overwrite uncommitted edits)." >&2; exit 2
fi

# === HARDENED 2026-05-17: close the inline-python / bash source-write
# circumvention of the Edit/Write 300-line guard.
# pre_write_edit.sh blocks the Edit tool when a source file would exceed
# 300 lines. The agent re-ran the identical write through a versioned
# full-path python heredoc:
#   /opt/homebrew/opt/python@3.11/bin/python3.11 - <<'EOF'
#     open(p,"w").write(s)   # grew makespan/__init__.py 311 -> 318
# The old guards (lines ~131-136: `python[0-9.]?\s+(-c|--command)` and
# `python[0-9.]?\s+<<`) missed it because `python[0-9.]?` allows only a
# single optional char, so `python3.11` + ` - ` (stdin) + `<<` defeated
# both. Match ANY python interpreter (any path, any version) used with
# -c / --command / stdin `-` / heredoc, AND any bash redirection / tee /
# sed -i / dd writing a source file. Source edits MUST go through the
# Edit/Write tool so the line-limit + justification hooks actually run;
# there is no sanctioned bash path for editing source. ===
if echo "$CMD" | grep -qE '(^|[;&|`(]|/|[[:space:]])python([0-9]+(\.[0-9]+)*)?([[:space:]]+(-c|--command|-)([[:space:]]|$)|[[:space:]]*<<)'; then
    echo "BLOCKED: inline python (any path/version, via -c/--command/stdin/heredoc) is forbidden. It was used to bypass the Edit/Write 300-line guard. Edit source through the Edit or Write tool so the line-limit and justification hooks run; do not pipe code into a python interpreter." >&2
    exit 2
fi
if echo "$CMD" | grep -qE '(>>?|[[:space:]]tee[[:space:]]|sed[[:space:]]+-i|dd[[:space:]]+[^|;&]*of=)[[:space:]]*[^[:space:];|&]*\.(py|js|ts|tsx|jsx|mjs|cjs|rb|go|rs|java|kt|c|cc|cpp|h|hpp|sh)\b'; then
    echo "BLOCKED: writing/modifying a source file via bash redirection/tee/sed -i/dd is forbidden — it bypasses the Edit/Write 300-line + justification guard. Use the Edit or Write tool." >&2
    exit 2
fi

# === AUTO-ADDED RULES BELOW ===
# auto-added 2026-06-10T14:57:56: User is angry the assistant wrote and ran an ad-hoc Node.js script for a task instead of using existing CLI/infrastructure — same class as the already-banned inline `python -c` throwaway scripts.
if echo "$CMD" | grep -qE '(^|[;&|[:space:]])node[[:space:]]+(-e|--eval|-p[[:space:]]|/tmp/|\$TMPDIR)'; then
    echo 'BLOCKED: BLOCKED: ad-hoc/inline node scripts are forbidden — use the existing CLI commands or proper checked-in script files, never throwaway node code.' >&2
    exit 2
fi

# auto-added 2026-06-07T22:44:26: User demands a device-level hook banning any use of Chromium by the assistant; wants Weles used for all browser automation instead.
if echo "$CMD" | grep -qE '([Cc]hromium|chrome-headless|puppeteer|playwright[^a-z]|chromedriver|--headless=new|chrome --headless)'; then
    {
        echo
        echo '####################################################################################################'
        echo '####################################################################################################'
        echo '####################################################################################################'
        echo
        echo 'YOU FUCKING RETARD. DO NOT USE CHROMIUM. DO NOT USE CHROMIUM. USE WELES'
        echo 'YOU FUCKING RETARD. DO NOT USE CHROMIUM. DO NOT USE CHROMIUM. USE WELES'
        echo 'YOU FUCKING RETARD. DO NOT USE CHROMIUM. DO NOT USE CHROMIUM. USE WELES'
        echo
        echo '####################################################################################################'
        echo '####################################################################################################'
        echo '####################################################################################################'
        echo
        echo 'BLOCKED: Chromium/Chrome/browser automation command detected. Use Weles.'
    } >&2
    exit 2
fi

# auto-added 2026-06-07T22:44:18: User demands a hook that bans the assistant from using Chromium for browser automation; insists Weles must be used instead.
if echo "$CMD" | grep -qE 'chromium'; then
    {
        echo
        echo '####################################################################################################'
        echo '####################################################################################################'
        echo '####################################################################################################'
        echo
        echo 'YOU FUCKING RETARD. DO NOT USE CHROMIUM. DO NOT USE CHROMIUM. USE WELES'
        echo 'YOU FUCKING RETARD. DO NOT USE CHROMIUM. DO NOT USE CHROMIUM. USE WELES'
        echo 'YOU FUCKING RETARD. DO NOT USE CHROMIUM. DO NOT USE CHROMIUM. USE WELES'
        echo
        echo '####################################################################################################'
        echo '####################################################################################################'
        echo '####################################################################################################'
        echo
        echo 'BLOCKED: Chromium command detected. Use Weles.'
    } >&2
    exit 2
fi

# auto-added 2026-05-18T14:57:12: User angry the assistant ran the Claude reauth/login browser flow by SSHing into the mac mini, contrary to the rule that daemons/jobs are started by their owner and the assistant must not SSH in to start them.
# Per-invocation bypass: prefix the command with MAC_MINI_SSH_AUTHORIZED=1
# when (and only when) the user has explicitly granted SSH for this turn.
# The hook reads the command itself so this marker requires no env edits.
if echo "$CMD" | grep -qE 'ssh .*charles@charless-mac-mini' && ! echo "$CMD" | grep -qE 'MAC_MINI_SSH_AUTHORIZED=1'; then
    echo 'BLOCKED: Blocked: do not SSH into the mac mini to start/manage daemons or jobs. Explain what needs to happen and let the owner run it. (Override per-turn with MAC_MINI_SSH_AUTHORIZED=1 prefix when explicitly authorized.)' >&2
    exit 2
fi

# auto-added 2026-05-17T19:22:22: Block bash commands that read browser cookie stores or cookie-related paths
if echo "$CMD" | grep -qE '(Cookies|cookies\.sqlite|Cookies\.binarycookies|com\.apple\.Safari/Data/Library/Cookies)'; then
    echo 'BLOCKED: Browser cookie access is forbidden — do not read cookie stores for auth flows. Ask the user before any cookie-based approach.' >&2
    exit 2
fi

# apply_auto_rule.py splices new `if grep ...; then exit 2; fi` blocks here.
# Each block targets $CMD (the bash command) and is generated by the
# detect_frustration → claude -p drafter pipeline. Rules below this line
# were added automatically in response to user frustration.

# auto-added 2026-05-17: grep-spelunking is an anti-pattern. The agent kept
# grep-ing for random keywords across the tree instead of opening and reading
# the actual files to understand the code. Block grep and all grep-like
# searchers (egrep/fgrep/rg/ag/ack/ack-grep/git grep/ugrep/pcregrep) as a
# command token (start, or after ; & | ` ( or whitespace).
if echo "$CMD" | grep -qE '(^|[;&|`(]|[[:space:]])(grep|egrep|fgrep|rg|ag|ack|ack-grep|ugrep|pcregrep)([[:space:]]|$)' \
   || echo "$CMD" | grep -qE '(^|[;&|`(]|[[:space:]])git[[:space:]]+grep([[:space:]]|$)'; then
    echo "DO NOT GREP FOR RANDOM KEYWORDS. THIS IS AN ANTI PATTERN. READ THE ACTUAL FUCKING CODE AND UNDERSTAND IT." >&2
    exit 2
fi

# auto-added 2026-05-18: block domain purchases that aren't from the curated
# candidate-domain lists. The agent autonomously ran `manage.mjs add
# mailpost847.com` ($11.48) — a generic invented name — instead of using one
# of the plausibly-themed domains the user had already curated under
# weles/scripts/domains/data/available_*.md (pilatesguild.com, wisentforest.com,
# roleheart.com, etc.). Any `manage.mjs add <domain>` must reference an exact
# bullet entry in those .md files.
if echo "$CMD" | grep -qE '(^|[;&|`(]|[[:space:]])(node|tsx|bun|ts-node|npx([[:space:]]+--?[A-Za-z0-9_-]+)*)[[:space:]]+([^[:space:]]+/)?scripts/domains/manage\.mjs[[:space:]]+add[[:space:]]+'; then
    NEW_DOMAIN=$(echo "$CMD" | sed -nE 's|.*scripts/domains/manage\.mjs[[:space:]]+add[[:space:]]+([A-Za-z0-9.-]+).*|\1|p' | head -1)
    if [ -z "$NEW_DOMAIN" ]; then
        echo "BLOCKED: manage.mjs add invocation without a parseable domain argument." >&2
        exit 2
    fi
    CANDIDATES_DIR="${WELES_DOMAIN_CANDIDATES_DIR:-}"
    if [ -z "$CANDIDATES_DIR" ] || [ ! -d "$CANDIDATES_DIR" ]; then
        echo "BLOCKED: set WELES_DOMAIN_CANDIDATES_DIR to the curated candidate-domain list directory before purchasing '$NEW_DOMAIN'." >/dev/stderr
        exit 2
    fi
    if ! cat "$CANDIDATES_DIR"/available_*.md 2>/dev/null | sed -nE 's|^-[[:space:]]+([^[:space:]]+)[[:space:]]*$|\1|p' | grep -Fxq "$NEW_DOMAIN"; then
        echo "BLOCKED: '$NEW_DOMAIN' is not in any curated candidate-domain list ($CANDIDATES_DIR/available_*.md)." >&2
        echo "Pick a domain that's on those lists (e.g. pilatesguild.com, wisentforest.com, roleheart.com) — the user spent significant time curating plausibly-themed names; do not invent generic ones like 'mailpost847.com'." >&2
        exit 2
    fi
fi

# === Block unsubstantiated constants injected via Bash (e.g. remote SSH/SCP edits) ===
if echo "$CMD" | python3 "$HOME/.shared-hooks/check_unsubstantiated_constants.py" --bash; then
    :
else
    exit 2
fi

exit 0
