#!/usr/bin/env python3
"""Device/runtime guard for hook modifications.

Blocks adding or editing hook sources/configs unless the user has explicitly
approved hook changes through DEVICE_HOOK_EDIT_APPROVED=1. This is intentionally
runtime-level, not project-level: it protects repo hooks, shared hooks, Codex,
OMP, Claude, and Kimi Code hook/config locations.
"""

from __future__ import annotations

import json
import os
import re
import shlex
import sys
from typing import Any, Iterable

APPROVAL_ENV = "DEVICE_HOOK_EDIT_APPROVED"
DOCS = ("https://tama.wisent.com/docs/hook-management",)
WRITE_TOOLS = {"write", "edit", "multiedit", "apply_patch", "functions.apply_patch", "applypatch"}
EXECUTION_TOOLS = {"bash", "eval", "ssh", "debug", "browser", "node_repl", "mcp__node_repl_js"}

PROTECTED_PATH_RE = re.compile(
    r"("
    r"(^|/)\.git/hooks(/|$)"
    r"|(^|/)\.githooks(/|$)"
    r"|(^|/)repo-githooks(/|$)"
    r"|(^|/)\.husky(/|$)"
    r"|(^|/)lefthook\.ya?ml$"
    r"|(^|/)\.pre-commit-config\.ya?ml$"
    r"|(^|/)\.claude/(settings[^/]*\.json|hooks(/|$))"
    r"|(^|/)\.codex/(hooks\.json|hooks(/|$))"
    r"|(^|/)\.omp/agent/hooks(/|$)"
    r"|(^|/)\.kimi-code/(config\.toml$|hooks(/|$))"
    r"|(^|/)\.shared-hooks(/|$)"
    r"|(^|/)tama/(shared-hooks|codex-hooks|claude-hooks|repo-githooks|src)(/|$)"
    r")",
    re.IGNORECASE,
)
WRITE_COMMAND_RE = re.compile(
    r"("
    r">\s*[^\s;|&]+"
    r"|\b(tee|touch|mkdir|rm|rmdir|cp|mv|install|rsync|dd|chmod)\b"
    r"|\bsed\s+[^;&|]*-[^;&|]*i\b"
    r"|\b(Bun\.write|writeFileSync|writeFile|appendFile|copyFile|rename|unlink|rmdir|remove|open\s*\([^)]*['\"][wax]|Path\([^)]*\)\.(?:write_text|write_bytes|unlink|rmdir|rename)|fs\s*\.\s*(?:writeFile|appendFile|copyFile|rename|unlink|rm|rmdir)|shutil\s*\.\s*(?:rmtree|move)|os\s*\.\s*(?:remove|unlink|rmdir|rename))\b"
    r")",
    re.IGNORECASE,
)

OPAQUE_PATCH_RE = re.compile(r"\b(git\s+apply|patch\b|ed\b|ex\b)", re.IGNORECASE)
GIT_HOOKSPATH_RE = re.compile(r"\bgit\s+config\b[^;&|\n]*\bcore\.hooksPath\b", re.IGNORECASE)
OPERATOR_RECOVERY_PATH_RE = re.compile(
    r"("
    r"(^|/)Library/Application Support/Tama/hook-emergency-state\.json(?=$|[\s'\";])"
    r"|(^|/)Library/Application Support/Tama/emergency-backup(/|$|[\s'\";])"
    r"|(^|/)Library/Application Support/Tama/session-control/[^/\s'\";]+\.override\.json(?=$|[\s'\";])"
    r")",
    re.IGNORECASE,
)
OPERATOR_RECOVERY_COMMAND_RE = re.compile(
    r"(^|[/\s])emergency_disable_hooks(?:[\s'\";]|$)|\bTAMA_EMERGENCY_ACTION\b",
    re.IGNORECASE,
)


def load_payload() -> dict[str, Any]:
    raw = sys.stdin.read()
    try:
        data = json.loads(raw or "{}")
    except json.JSONDecodeError:
        data = {}
    return data if isinstance(data, dict) else {}


def tool_name(payload: dict[str, Any]) -> str:
    return str(payload.get("tool_name") or payload.get("tool") or payload.get("name") or "")


def tool_input(payload: dict[str, Any]) -> dict[str, Any]:
    value = payload.get("tool_input") or payload.get("input") or {}
    return value if isinstance(value, dict) else {}


def patch_candidate_paths(text: str) -> Iterable[str]:
    for raw_line in text.splitlines():
        line = raw_line.strip()
        bracket = re.match(r"^\[([^#\]\n]+)#", line)
        if bracket:
            yield bracket.group(1)
            continue
        file_header = re.match(r"^\*\*\* (?:Add|Update|Delete) File: (.+)$", line)
        if file_header:
            yield file_header.group(1).strip()
            continue
        diff_header = re.match(r"^(?:---|\+\+\+) [ab]/(.+)$", line)
        if diff_header:
            yield diff_header.group(1).strip()


def candidate_paths(value: Any) -> Iterable[str]:
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for key in ("file_path", "path", "notebook_path"):
            item = value.get(key)
            if isinstance(item, str):
                yield item
        for key in ("input", "patch"):
            item = value.get(key)
            if isinstance(item, str):
                yield from patch_candidate_paths(item)
        edits = value.get("edits")
        if isinstance(edits, list):
            for edit in edits:
                yield from candidate_paths(edit)
    elif isinstance(value, list):
        for item in value:
            yield from candidate_paths(item)


def protected_path(path: str) -> bool:
    normalized = path.replace("\\", "/")
    # Justification registries are data the authorization gates require agents
    # to write after an explicit user grant. Protecting them creates a deadlock.
    if normalized.endswith((
        "/.shared-hooks/file_justifications.json",
        "/.shared-hooks/ssh_justification.json",
    )):
        return False
    return bool(PROTECTED_PATH_RE.search(normalized))

def mentions_git_hookspath(value: Any) -> bool:
    return "hookspath" in json.dumps(value, ensure_ascii=False).lower()


def git_config_path(path: str) -> bool:
    return bool(re.search(r"(^|/)\.git/config$", path.replace("\\", "/"), re.IGNORECASE))


def command_mentions_protected_path(command: str) -> bool:
    normalized = command.replace("\\", "/")
    if PROTECTED_PATH_RE.search(normalized):
        return True
    for token in re.split(r"[\s;&|<>()]+", normalized):
        stripped = token.strip("\"'[]{}:,")
        if stripped and protected_path(stripped):
            return True
    return False



def approved() -> bool:
    return os.environ.get(APPROVAL_ENV) == "1"


def command_text(payload: dict[str, Any]) -> str:
    inp = tool_input(payload)
    return str(inp.get("command") or inp.get("cmd") or payload.get("command") or "")
def execution_text(payload: dict[str, Any]) -> str:
    strings: list[str] = []
    stack: list[Any] = [payload]
    while stack:
        value = stack.pop()
        if isinstance(value, str):
            strings.append(value)
        elif isinstance(value, dict):
            stack.extend(value.values())
        elif isinstance(value, list):
            stack.extend(value)
    return "\n".join(strings)[:250_000]


def git_configures_hookspath(command: str) -> bool:
    for segment in re.split(r"[;&|]+", command):
        try:
            tokens = shlex.split(segment)
        except ValueError:
            tokens = segment.split()
        for index, token in enumerate(tokens):
            if token != "git":
                continue
            cursor = index + 1
            while cursor < len(tokens) and tokens[cursor].startswith("-"):
                option = tokens[cursor]
                cursor += 1
                if option in {"-C", "--git-dir", "--work-tree", "-c"} and cursor < len(tokens):
                    cursor += 1
            if cursor < len(tokens) and tokens[cursor] == "config":
                if any(item.lower() == "core.hookspath" for item in tokens[cursor + 1:]):
                    return True
    return False


def bash_targets_hook_modification(payload: dict[str, Any]) -> bool:
    command = command_text(payload)
    if not command:
        return False
    normalized = command.replace("\\", "/")
    if OPAQUE_PATCH_RE.search(normalized) or GIT_HOOKSPATH_RE.search(normalized) or git_configures_hookspath(normalized):
        return True
    return bool(command_mentions_protected_path(normalized) and WRITE_COMMAND_RE.search(normalized))
def execution_targets_hook_modification(payload: dict[str, Any]) -> bool:
    text = execution_text(payload).replace("\\", "/")
    if not text:
        return False
    if GIT_HOOKSPATH_RE.search(text) or git_configures_hookspath(text):
        return True
    return bool(
        command_mentions_protected_path(text)
        and (WRITE_COMMAND_RE.search(text) or OPAQUE_PATCH_RE.search(text))
    )


def operator_recovery_target(payload: dict[str, Any], tool: str) -> bool:
    if tool in WRITE_TOOLS:
        return any(
            OPERATOR_RECOVERY_PATH_RE.search(path.replace("\\", "/"))
            for path in candidate_paths(tool_input(payload))
        )
    if tool not in EXECUTION_TOOLS:
        return False
    text = execution_text(payload).replace("\\", "/")
    if OPERATOR_RECOVERY_COMMAND_RE.search(text):
        return True
    return bool(
        OPERATOR_RECOVERY_PATH_RE.search(text)
        and (WRITE_COMMAND_RE.search(text) or OPAQUE_PATCH_RE.search(text))
    )


def operator_recovery_block_reason() -> str:
    return (
        "BLOCKED: global Tama emergency disable/re-enable is an operator-only "
        "break-glass control and cannot be invoked or mutated by an agent."
    )


def block_reason(targets: list[str]) -> str:
    docs = " | ".join(DOCS)
    return (
        "BLOCKED: hook source/config changes are device-level protected. "
        f"Set {APPROVAL_ENV}=1 outside the agent session before editing hooks. "
        f"Read hook scope docs: {docs}. "
        f"Target(s): {', '.join(targets[:5])}"
    )


def main() -> int:
    payload = load_payload()
    tool = tool_name(payload).lower()
    if operator_recovery_target(payload, tool):
        print(operator_recovery_block_reason(), file=sys.stderr)
        return 2


    targets: list[str] = []
    if tool in WRITE_TOOLS:
        inp = tool_input(payload)
        paths = [p for p in candidate_paths(inp) if isinstance(p, str) and p]
        targets = [p for p in paths if protected_path(p) or (git_config_path(p) and mentions_git_hookspath(inp))]
        if not targets and tool in {"apply_patch", "functions.apply_patch", "applypatch"}:
            serialized = json.dumps(inp, ensure_ascii=False)
            if command_mentions_protected_path(serialized) or mentions_git_hookspath(inp):
                targets = ["apply_patch payload can create/edit hook source/config"]
    elif tool in EXECUTION_TOOLS:
        if execution_targets_hook_modification(payload):
            targets = [f"{tool} payload can create/edit hook source/config"]
    else:
        return 0

    if not targets:
        return 0
    if approved():
        return 0

    print(block_reason(targets), file=sys.stderr)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
