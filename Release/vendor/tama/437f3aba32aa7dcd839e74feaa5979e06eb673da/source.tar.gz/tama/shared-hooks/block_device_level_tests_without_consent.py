#!/usr/bin/env python3
"""Block agent creation/edit of test paths unless device-level tests are approved.

Fail-closed by default. Approval must arrive through a user-controlled runtime
signal, not through prompt/transcript text that an agent can misread or quote:
DEVICE_LEVEL_TESTS_APPROVED=1.
"""

from __future__ import annotations

import json
import os
import re
import sys
from typing import Any, Iterable

WRITE_TOOLS = {"write", "edit", "multiedit"}

TEST_PATH_RE = re.compile(
    r"("
    r"(^|[\s'\"=]|/)(tests?|__tests__|e2e|playwright|xctest|device-tests?|ui-tests?)(/|$)"
    r"|[._-](test|spec)\.(js|jsx|ts|tsx|mjs|cjs|py|swift|kt|java)$"
    r"|Tests?\.swift$"
    r")",
    re.IGNORECASE,
)

BASH_WRITE_RE = re.compile(
    r"("
    r">\s*[^\s;|&]+"
    r"|\b(tee|touch|mkdir|cp|mv|install|rsync|dd|printf|cat|sed|perl|ruby|node|python3?|bun|deno)\b"
    r"|\b(writeFileSync|writeFile|open\s*\([^)]*['\"]w|Path\([^)]*\)\.write_text)\b"
    r")",
    re.IGNORECASE,
)

PATCH_APPLY_RE = re.compile(r"\b(git\s+apply|patch\b|ed\b|ex\b)", re.IGNORECASE)


def load_payload() -> dict[str, Any]:
    raw = sys.stdin.read()
    try:
        data = json.loads(raw or "{}")
    except json.JSONDecodeError:
        data = {}
    return data if isinstance(data, dict) else {}


def tool_name(payload: dict[str, Any]) -> str:
    return str(payload.get("tool_name") or payload.get("tool") or payload.get("name") or "")


def tool_input(payload: dict[str, Any]) -> dict[str, Any]:
    value = payload.get("tool_input") or payload.get("input") or {}
    return value if isinstance(value, dict) else {}


def candidate_paths(value: Any) -> Iterable[str]:
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for key in ("file_path", "path", "notebook_path"):
            item = value.get(key)
            if isinstance(item, str):
                yield item
        edits = value.get("edits")
        if isinstance(edits, list):
            for edit in edits:
                yield from candidate_paths(edit)
    elif isinstance(value, list):
        for item in value:
            yield from candidate_paths(item)


def is_test_path(path: str) -> bool:
    return bool(TEST_PATH_RE.search(path.replace("\\", "/")))


def approved() -> bool:
    return os.environ.get("DEVICE_LEVEL_TESTS_APPROVED") == "1"


def command_text(payload: dict[str, Any]) -> str:
    inp = tool_input(payload)
    return str(inp.get("command") or inp.get("cmd") or payload.get("command") or "")


def bash_targets_test_creation(payload: dict[str, Any]) -> bool:
    command = command_text(payload)
    if not command:
        return False
    normalized = command.replace("\\", "/")
    if PATCH_APPLY_RE.search(normalized):
        return True
    return bool(TEST_PATH_RE.search(normalized) and BASH_WRITE_RE.search(normalized))


def main() -> int:
    payload = load_payload()
    tool = tool_name(payload).lower()

    blocked: list[str] = []
    if tool in WRITE_TOOLS:
        paths = [p for p in candidate_paths(tool_input(payload)) if isinstance(p, str) and p]
        blocked = [p for p in paths if is_test_path(p)]
    elif tool == "bash":
        if bash_targets_test_creation(payload):
            blocked = ["Bash command targets a test/device-level path with a write-like operation"]
    else:
        return 0

    if not blocked:
        return 0

    if approved():
        return 0

    print(
        "BLOCKED: creating or editing test/device-level files requires explicit user approval. "
        "Set DEVICE_LEVEL_TESTS_APPROVED=1 outside the agent session before allowing this. "
        f"Targeted path(s): {', '.join(blocked[:5])}",
        file=sys.stderr,
    )
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
