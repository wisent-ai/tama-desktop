#!/usr/bin/env node
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const hooksPath = path.join(os.homedir(), '.codex', 'hooks.json');
const boundaryCommand = path.join(os.homedir(), '.shared-hooks', 'block_oko_trajectory_edits.sh');
const boundaryHook = {
  type: 'command',
  command: boundaryCommand,
  statusMessage: 'Checking Oko/Weles trajectory boundary',
};

const data = JSON.parse(fs.readFileSync(hooksPath, 'utf8'));
const preToolUse = data.hooks?.PreToolUse;
if (!Array.isArray(preToolUse)) {
  throw new Error('hooks.PreToolUse is missing or not an array');
}

function sameHook(hook) {
  return hook?.type === boundaryHook.type && hook?.command === boundaryHook.command;
}

function insertAfterStatus(entry, statusMessage) {
  const hooks = entry.hooks;
  if (!Array.isArray(hooks) || hooks.some(sameHook)) return false;
  const index = hooks.findIndex((hook) => hook.statusMessage === statusMessage);
  if (index === -1) {
    hooks.push(boundaryHook);
  } else {
    hooks.splice(index + 1, 0, boundaryHook);
  }
  return true;
}

let changed = false;
for (const entry of preToolUse) {
  if (entry.matcher === 'Bash') {
    changed = insertAfterStatus(entry, 'Checking CUA authorization') || changed;
  }
  if (entry.matcher === 'apply_patch|Edit|Write') {
    changed = insertAfterStatus(entry, 'Checking file edit') || changed;
  }
}

if (changed) {
  fs.writeFileSync(hooksPath, `${JSON.stringify(data, null, 2)}\n`);
}

console.log(JSON.stringify({ changed }, null, 2));
