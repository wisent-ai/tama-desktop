export const CAPABILITY_SCHEMA_VERSION = 2
export const CAPABILITY_ENV = 'AGENT_STRUCTURED_CAPABILITY'
export const CAPABILITY_LIFETIMES = new Set(['single-use', 'expires-at', 'current-session'])

export function normalizeCapabilityGrants(value) {
  if (!Array.isArray(value) || value.length === 0) return null
  const merged = new Map()
  for (const grant of value) {
    if (!grant || typeof grant !== 'object' || Array.isArray(grant)) return null
    const tool = String(grant.tool || '').trim().toLowerCase()
    if (!/^[a-z][a-z0-9:_-]{0,127}$/.test(tool)) return null
    let actions = null
    if (grant.actions !== undefined && grant.actions !== null) {
      if (!Array.isArray(grant.actions) || grant.actions.length === 0) return null
      actions = [...new Set(grant.actions.map(action => String(action || '').trim().toLowerCase()))]
      if (actions.some(action => !/^[a-z][a-z0-9:_-]{0,127}$/.test(action))) return null
    }
    const existing = merged.get(tool)
    if (existing === null || actions === null) merged.set(tool, null)
    else merged.set(tool, [...new Set([...(existing || []), ...actions])].sort())
  }
  return [...merged.entries()].sort(([a], [b]) => a.localeCompare(b)).map(
    ([tool, actions]) => actions === null ? { tool } : { tool, actions },
  )
}

function normalizedExpiry(value, now) {
  const expiresAt = Date.parse(value)
  if (!Number.isFinite(expiresAt) || expiresAt <= now) return null
  return new Date(expiresAt).toISOString()
}

export function normalizedCapability(value, activeSessionId, now = Date.now(), identity = {}) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null
  const grants = normalizeCapabilityGrants(value.grants)
  const lifetime = String(value.lifetime || '').trim().toLowerCase()
  const controlKey = String(value.controlKey || '').trim()
  const releaseId = String(value.releaseId || '').trim()
  const catalogChecksum = String(value.catalogChecksum || '').trim()
  if (
    value.schemaVersion !== CAPABILITY_SCHEMA_VERSION
    || !String(value.issuedBy || '').trim()
    || !String(value.nonce || '').trim()
    || String(value.sessionId || '') !== String(activeSessionId || '')
    || !controlKey
    || !releaseId
    || !catalogChecksum
    || (identity.controlKey && controlKey !== identity.controlKey)
    || (identity.releaseId && releaseId !== identity.releaseId)
    || (identity.catalogChecksum && catalogChecksum !== identity.catalogChecksum)
    || !grants
    || !CAPABILITY_LIFETIMES.has(lifetime)
  ) return null

  const normalized = {
    schemaVersion: CAPABILITY_SCHEMA_VERSION,
    issuedBy: String(value.issuedBy),
    nonce: String(value.nonce),
    sessionId: String(value.sessionId),
    controlKey,
    releaseId,
    catalogChecksum,
    lifetime,
    grants,
  }
  if (lifetime === 'expires-at') {
    const expiresAt = normalizedExpiry(value.expiresAt, now)
    if (!expiresAt) return null
    normalized.expiresAt = expiresAt
  } else if (lifetime === 'single-use') {
    if (value.remainingUses !== 1) return null
    normalized.remainingUses = 1
  }
  return normalized
}

export function capabilityEnvironment(capability, extra = {}) {
  const env = { ...process.env, ...extra }
  if (capability) env[CAPABILITY_ENV] = JSON.stringify(capability)
  else delete env[CAPABILITY_ENV]
  return env
}
