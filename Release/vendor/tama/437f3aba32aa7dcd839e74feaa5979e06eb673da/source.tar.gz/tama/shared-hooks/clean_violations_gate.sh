#!/bin/bash
# Stop hook (non-blocking, opt-in): fires the violation cleaner gate for the
# session's repository after the session ends. Spawns detached and exits
# immediately, so it never delays the stop event. Enable with TAMA_CLEAN_GATE=1;
# TAMA_CLEAN_DISABLED=1 wins over everything. Fires at most once per repo per
# hour; the throttle marker lives under ~/.shared-hooks/state/.
set -euo pipefail

[[ "${TAMA_CLEAN_GATE:-}" == "1" ]] || exit 0
[[ "${TAMA_CLEAN_DISABLED:-}" == "1" ]] && exit 0

INPUT=$(cat)
CWD=$(echo "$INPUT" | jq -r '.cwd // empty')
[[ -n "$CWD" && -d "$CWD/.git" ]] || exit 0

STATE_DIR="$HOME/.shared-hooks/state"
mkdir -p "$STATE_DIR"
MARK="$STATE_DIR/clean-gate-$(printf '%s' "$CWD" | shasum -a 256 | cut -d' ' -f1)"
NOW=$(date +%s)
if [[ -f "$MARK" ]]; then
    LAST=$(cat "$MARK" 2>/dev/null || printf '0')
    if [[ $((NOW - LAST)) -lt 3600 ]]; then
        exit 0
    fi
fi
printf '%s' "$NOW" > "$MARK"

CLI="${TAMA_CLEAN_CLI:-$HOME/.local/bin/tama-cli}"
[[ -f "$CLI" ]] || exit 0

nohup "$CLI" clean --repo "$CWD" >>"$STATE_DIR/clean-gate.log" 2>&1 &
