#!/usr/bin/env bash
set -euo pipefail

INPUT="$(cat)"

if ! command -v jq >/dev/null; then
  printf '%s\n' 'BLOCKED: the Supabase CLI boundary cannot inspect the tool payload because jq is unavailable.'
  false
fi

TOOL_NAME="$(
  printf '%s' "$INPUT" | jq -r '
    (.tool_name // .tool.name // .tool // .name // "")
    | if type == "string" then . else "" end
  ' || true
)"
TOOL_INPUT="$(
  printf '%s' "$INPUT" | jq -c '
    .tool_input // .input // .tool.input // .tool.tool_input // {}
  ' || printf '{}'
)"
TOOL_PATH="$(printf '%s' "$TOOL_INPUT" | jq -r '.path // ""' || true)"
TOOL_OPERATION="$(printf '%s' "$TOOL_INPUT" | jq -r '.op // .action // ""' || true)"
TOOL_COMMAND="$(printf '%s' "$TOOL_INPUT" | jq -r '.command // .cmd // ""' || true)"
TOOL_CODE="$(printf '%s' "$TOOL_INPUT" | jq -r '.code // ""' || true)"
TOOL_PROCESS="$(
  printf '%s' "$TOOL_INPUT" | jq -r '
    [.application // empty, (.args // [])[]] | join(" ")
  ' || true
)"
PAYLOAD_TEXT="$(
  printf '%s' "$TOOL_INPUT" | jq -r '[.. | strings] | join("\n")' || true
)"

LOWER_TOOL="$(printf '%s' "$TOOL_NAME" | tr '[:upper:]' '[:lower:]')"
LOWER_PATH="$(printf '%s' "$TOOL_PATH" | tr '[:upper:]' '[:lower:]')"
LOWER_OPERATION="$(printf '%s' "$TOOL_OPERATION" | tr '[:upper:]' '[:lower:]')"
LOWER_TEXT="$(printf '%s' "$PAYLOAD_TEXT" | tr '[:upper:]' '[:lower:]')"
LOWER_COMMAND="$(printf '%s' "$TOOL_COMMAND" | tr '[:upper:]' '[:lower:]')"
LOWER_CODE="$(printf '%s' "$TOOL_CODE" | tr '[:upper:]' '[:lower:]')"
LOWER_PROCESS="$(printf '%s' "$TOOL_PROCESS" | tr '[:upper:]' '[:lower:]')"

block() {
  printf '%s\n' \
    'BLOCKED: Supabase CLI use is forbidden in agent sessions.' \
    'Use the owning repository and its reviewed deployment path instead of invoking supabase directly.' \
    'This hook has no command, subcommand, read-only, local, help, version, or session-capability exception.'
  false
}

# Inspect only fields that can execute a process. Documentation and source files
# that merely mention the command remain writable.
EXECUTABLE_TEXT=''
case "$LOWER_TOOL" in
  bash|functions.bash)
    EXECUTABLE_TEXT="$LOWER_COMMAND"
    ;;
  eval|functions.eval|mcp__node_repl_js)
    EXECUTABLE_TEXT="$LOWER_CODE"
    ;;
  hub|functions.hub)
    if [[ "$LOWER_OPERATION" == 'start' ]]; then
      EXECUTABLE_TEXT="$LOWER_PROCESS"
    fi
    ;;
  write|functions.write)
    if printf '%s' "$LOWER_PATH" | grep -Eq '^xd://mcp__node_repl_js($|[/_-])'; then
      EXECUTABLE_TEXT="$LOWER_TEXT"
    fi
    ;;
esac

if [[ -z "$EXECUTABLE_TEXT" ]]; then
  exit
fi

# Ignore quoted prose unless the quote is itself executed by a shell wrapper.
if ! printf '%s' "$EXECUTABLE_TEXT" | grep -Eq '(^|[[:space:]])(ssh|(ba|z|d)?sh[[:space:]]+-[a-z]*c)([[:space:]]|$)'; then
  EXECUTABLE_TEXT="$(
    printf '%s' "$EXECUTABLE_TEXT" \
      | sed -E "s/'[^']*'/ /g; s/\"[^\"]*\"/ /g"
  )"
fi

# Match the binary through a bare or absolute path, environment prefix, package
# runner, pipeline, command list, substitution, or wrapped shell command.
SUPABASE_INVOCATION='(^|[|;&`("'"'"']|&&|\|\||[[:space:]])([a-z_][a-z0-9_]*=[^[:space:]]*[[:space:]]+)*((npx|bunx|pnpm[[:space:]]+dlx|yarn[[:space:]]+dlx)[[:space:]]+(--[a-z-]+[[:space:]]+)*)?([^[:space:]|;&"'"'"']*/)?supabase([[:space:]]|$)'

if printf '%s' "$EXECUTABLE_TEXT" | grep -Eq "$SUPABASE_INVOCATION"; then
  block
fi

exit
