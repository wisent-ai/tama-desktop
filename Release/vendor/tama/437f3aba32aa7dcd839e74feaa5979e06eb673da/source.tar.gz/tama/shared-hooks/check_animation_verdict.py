#!/usr/bin/env python3
"""Stop hook — enforce MEMORY.md:35 / feedback_animation_quality_needs_rendered_comparison.md
programmatically.

The rule: animation/rendering quality requires rendered side-by-side
comparison, NOT structural metrics (channel/bone counts, pixel-L1,
weight %, bone-axis angles). The only diagnostic that catches broken
rigs is viewing the rendered frames.

This hook blocks the assistant's response when:
  - it contains a quality verdict on an animation / rig / skinning / GLB
    (e.g. "animated correctly", "rig passes", "skinning fixed", "the
    animation looks", "X is reference quality", "tear OK", a tear/stride
    /weight/skin metric line followed by OK)
  AND
  - the recent tool history (this turn + the few previous turns) does
    NOT show enough Read calls on rendered frame PNGs under the project's
    known frame directories.

No per-hook bypass env var. Stop-hook discipline is global; if the
class of work genuinely needs to ship without frame reads, fix the
gate at the policy layer.
"""
import json
import os
import re
import sys
from pathlib import Path

HOME = Path(os.environ.get("HOME", "/tmp"))
CWD = Path(os.getcwd())

# ---- pull the transcript ---------------------------------------------------
def find_session_jsonl():
    encoded = str(CWD).replace("/", "-")
    proj = HOME / ".claude" / "projects" / encoded
    if not proj.is_dir():
        return None
    cs = sorted(proj.glob("*.jsonl"), key=lambda p: p.stat().st_mtime, reverse=True)
    return cs[0] if cs else None

raw = sys.stdin.read()
try:
    payload = json.loads(raw) if raw.strip() else {}
except Exception:
    sys.exit(0)
transcript = payload.get("transcript_path") or ""
if not transcript:
    j = find_session_jsonl()
    transcript = str(j) if j else ""
if not transcript or not Path(transcript).is_file():
    sys.exit(0)

# ---- scan the recent transcript --------------------------------------------
lines = Path(transcript).read_text(errors="ignore").splitlines()
recent = lines[-240:]

last_assistant_text = ""
recent_reads = []
for ln in reversed(recent):
    try:
        rec = json.loads(ln)
    except Exception:
        continue
    role = rec.get("message", {}).get("role") or rec.get("role")
    if role == "assistant" and not last_assistant_text:
        content = rec.get("message", {}).get("content") or rec.get("content") or []
        if isinstance(content, list):
            for c in content:
                if isinstance(c, dict) and c.get("type") == "text":
                    last_assistant_text += c.get("text", "") + "\n"
        elif isinstance(content, str):
            last_assistant_text = content
    content = rec.get("message", {}).get("content") or rec.get("content") or []
    if isinstance(content, list):
        for c in content:
            if isinstance(c, dict) and c.get("type") == "tool_use" and c.get("name") == "Read":
                p = (c.get("input") or {}).get("file_path", "")
                if p:
                    recent_reads.append(p)
if not last_assistant_text:
    sys.exit(0)

# ---- verdict-trigger regex on the response ---------------------------------
VERDICT = re.compile(
    r"\b(animated\s+correctly|animates?\s+correctly|"
    r"reference[- ]quality|reference\s+level|"
    r"skinning\s+(works|fixed|correct|reference)|"
    r"rig(ging)?\s+(works|fixed|passes|correct|reference)|"
    r"animation\s+(works|fixed|correct|looks\s+good|is\s+good|is\s+clean)|"
    r"clip(s)?\s+(OK|pass(es)?|clean|cohesive)|"
    r"(walk|run|attack|idle|stride)\s+(OK|pass(es)?|clean|cohesive)|"
    r"(tear|stride|skin|weight)[_\- ]?score\s+(OK|below|under|pass)|"
    r"all\s+(motion\s+)?clips\s+OK|"
    r"below\s+(the\s+)?(0\.\d+|threshold)|"
    r"verdict\s*[:=]?\s*OK|"
    r"the\s+(build|model|knight|character|skinning|animation)\s+(is\s+)?(now\s+)?(cohesive|clean|correct|works|fixed|OK)|"
    r"objective\s+(improvement|3x|2\.4x|better))\b",
    re.IGNORECASE,
)
METRIC_LINE = re.compile(
    r"\b(idle|walk|run|attack)\b[^\n]{0,80}\b(0\.0\d+|0\.1[0-7]\d?)\b[^\n]{0,40}\bOK\b",
    re.IGNORECASE,
)

m = VERDICT.search(last_assistant_text) or METRIC_LINE.search(last_assistant_text)
if not m:
    sys.exit(0)

# ---- require Read on frame PNGs --------------------------------------------
FRAME_RE = re.compile(
    r"(\.work/[^\n]*/(cmp|frames?|assess[\w-]*)/[^\n]*\.png|"
    r"\.work/[^/]*/f\d{2,3}\.png|"
    r"recordings/[^\n]*\.png|"
    r"/frame_[a-f0-9]+_\d+\.png|"
    r"/f\d{2,3}\.png)",
    re.IGNORECASE,
)
frame_reads = [p for p in recent_reads if FRAME_RE.search(p)]
MIN_FRAMES = 4
if len(frame_reads) >= MIN_FRAMES:
    sys.exit(0)

snippet = m.group(0)
print(
    f"BLOCKED (animation verdict needs rendered frames): the response "
    f"contains an animation/rig/skinning quality verdict ('{snippet}') "
    f"but the recent tool history shows only {len(frame_reads)} Read(s) "
    f"on frame PNGs (need >= {MIN_FRAMES}). MEMORY.md:35 / "
    f"feedback_animation_quality_needs_rendered_comparison.md: animation "
    f"quality requires rendered side-by-side frame inspection, NOT a "
    f"structural metric. Read more rendered frames from "
    f".work/credential-hook/cmp/<clip>/f*.png (or the equivalent under "
    f"recordings/) before stating a verdict.",
    file=sys.stderr,
)
sys.exit(2)
