#!/usr/bin/env python3
"""Stop hook — block failure-claims about a trajectory/run until the
agent has Read a frame or failure_state PNG from that run.

v6 (2026-05-09):
  - Broadened FAIL_TERMS to catch shadow-throttle / 0 handles / 0 entries
    / shadowban / locked / restricted / no results.
  - Token-set label matching: "linkedin scrape" matches scrape_linkedin
    or linkedin_avatar_survey. Old \\b<label>\\b only caught exact form.
  - Independent of inspect_required.json — also discovers labels from
    recordings/<label>/ on disk and requires a frame Read for the latest
    recording when the response talks about that label/run.

Bypass: CHECK_FAILURE_INSPECTION_DISABLED=1.
"""
import json
import os
import re
import sys
import time
import hashlib
from pathlib import Path

if os.environ.get("CHECK_FAILURE_INSPECTION_DISABLED") == "1":
    sys.exit(0)

HOME = Path(os.environ.get("HOME", "/tmp"))
CWD = Path(os.getcwd())

FAIL_TERMS = re.compile(
    r"\b(FAIL[: ]|failed|failure|did\s+not\s+(pass|solve)|exited?\s+(non-?zero|1)|"
    r"crashed|errored|broken|broke|bombed|did\s+not\s+(work|complete)|"
    # v6: state-of-run failure claims that don't use literal "fail"
    r"shadow[\- ]?throttl|shadow[\- ]?ban|shadowban|throttl|"
    r"\b0\s+handles\b|\b0\s+entries\b|\b0\s+results?\b|\bno\s+results?\b|"
    r"account[\- ]locked|account[\- ]ban|locked\s+out|restricted|"
    r"empty\s+results?|search\s+(returned|empty)|"
    r"soft[\- ]block|hard[\- ]block|stopped\s+before|cut\s+off|"
    r"truncat(ed|ion)|burst[\- ]ed?|kicked\s+(us\s+)?back)\b",
    re.IGNORECASE,
)


_PAYLOAD_TRANSCRIPT = ""


def find_session_jsonl():
    # The Stop-hook payload carries the EXACT transcript path of THIS
    # session (set in main() from stdin). Use it — mtime/size heuristics
    # cannot identify the active session under concurrent sessions, which
    # made every frame Read in the active session invisible and this gate
    # permanently unsatisfiable. Same root-cause fix as
    # check_artifact_inspection.py's transcript passthrough.
    if _PAYLOAD_TRANSCRIPT:
        p = Path(_PAYLOAD_TRANSCRIPT)
        if p.is_file():
            return p
    encoded = str(CWD).replace("/", "-")
    proj = HOME / ".claude" / "projects" / encoded
    if not proj.is_dir():
        return None
    cs = sorted(proj.glob("*.jsonl"), key=lambda p: p.stat().st_mtime, reverse=True)
    return cs[0] if cs else None


def discover_all_labels():
    labels = set()
    state = HOME / ".shared-hooks" / "state" / "trajectory_runs.json"
    if state.is_file():
        try:
            data = json.loads(state.read_text())
            for k in data.keys():
                slash = k.rfind("/")
                labels.add(k[slash + 1:] if slash >= 0 else k)
        except Exception:
            pass
    for base in [CWD.parent / "weles" / "recordings", CWD / "recordings"]:
        if base.is_dir():
            for d in base.iterdir():
                if d.is_dir() and any(d.glob("*.webm")):
                    labels.add(d.name)
    work = CWD / ".work"
    if work.is_dir():
        for d in work.iterdir():
            if d.is_dir() and (any(d.glob("frame_*.png")) or
                               any(d.glob("failure_state_*.png"))):
                labels.add(d.name)
    return list(labels)


def label_tokens(label):
    return [t for t in re.split(r"[_/\-\s]+", label.lower()) if t]


# v9 (2026-05-31): tightened triggering. The label must be referenced AS A
# FAILURE CLAIM — proximity to FAIL_TERMS, outside backtick-quoted regions,
# not preceded by a disclaim/quote keyword. The old "any token-overlap
# anywhere" fired when the agent merely echoed a hook error or discussed a
# trajectory in an unrelated context (e.g., "the hook fired about list_auto
# from a different session — unrelated to current work" was triggering the
# gate every Stop).
_DISCLAIM_PAT = re.compile(
    r"(unrelated|different\s+(session|conversation|run|trajectory|project)|"
    r"false\s+positive|not\s+actionable|spurious|misfir|"
    r"echoe?d|quoted|ignor(e|ed|ing)|n/a|not\s+pertinent|"
    r"hook\s+(is\s+)?firing|hook\s+(fired|fires)|hook\s+(error|feedback)|"
    r"system[\s\-]reminder)",
    re.IGNORECASE,
)


def label_in_response(label, text):
    """Return True iff the response makes a failure-claim ABOUT `label`.

    Three guards beyond bare token-overlap:
      1. Backtick-quoted spans (`...` and ```...```) are masked — mentions
         inside code/quote regions don't count.
      2. A disclaim/quote keyword within 200 chars BEFORE the mention
         ('unrelated', 'different session', 'hook fired about ...', etc.)
         disqualifies it.
      3. A FAIL_TERMS hit must occur within 250 chars of the mention (in
         either direction). Co-occurrence elsewhere in the response is not
         enough.
    """
    FAIL_PROXIMITY = 250
    DISCLAIM_WINDOW = 200
    masked = re.sub(r"```[\s\S]*?```", lambda m: "_" * len(m.group(0)), text)
    masked = re.sub(r"`[^`\n]+`", lambda m: "_" * len(m.group(0)), masked)
    masked_lc = masked.lower()
    label_lc = label.lower()
    positions = [m.start() for m in
                 re.finditer(rf"\b{re.escape(label_lc)}\b", masked_lc)]
    if not positions:
        tokens = label_tokens(label)
        if len(tokens) >= 2 and all(len(t) >= 3 for t in tokens):
            pos = {}
            ok = True
            for tok in tokens:
                hits = [m.start() for m in
                        re.finditer(rf"\b{re.escape(tok)}\b", masked_lc)]
                if not hits:
                    ok = False
                    break
                pos[tok] = hits
            if ok:
                from itertools import product
                for combo in product(*[pos[t] for t in tokens]):
                    if max(combo) - min(combo) <= 200:
                        positions.append(min(combo))
    if not positions:
        return False
    for p in positions:
        before = masked_lc[max(0, p - DISCLAIM_WINDOW):p]
        if _DISCLAIM_PAT.search(before):
            continue
        window = masked_lc[max(0, p - FAIL_PROXIMITY):p + FAIL_PROXIMITY]
        if FAIL_TERMS.search(window):
            return True
    return False


def session_log_reads_imply_labels(lookback=120):
    jsonl = find_session_jsonl()
    if not jsonl:
        return []
    try:
        lines = jsonl.read_text().splitlines()
    except Exception:
        return []
    labels = set()
    boundary = max(0, len(lines) - lookback)
    for i in range(len(lines) - 1, boundary - 1, -1):
        try:
            entry = json.loads(lines[i])
        except Exception:
            continue
        if entry.get("type") == "user":
            boundary = i + 1
            break
    for raw in lines[boundary:]:
        try:
            entry = json.loads(raw)
        except Exception:
            continue
        msg = entry.get("message") or {}
        content = msg.get("content") or []
        if not isinstance(content, list):
            continue
        for block in content:
            if not isinstance(block, dict) or block.get("type") != "tool_use":
                continue
            if block.get("name") != "Read":
                continue
            fp = str((block.get("input") or {}).get("file_path") or "")
            m = re.search(r"\.work/([^/]+)/", fp)
            if m:
                labels.add(m.group(1))
            m = re.search(r"recordings/([^/]+)/", fp)
            if m:
                labels.add(m.group(1))
            m = re.search(r"avatar-survey/data/run_([a-z]+)_", fp)
            if m:
                plat_map = {"li": "linkedin", "ig": "instagram", "tt": "tiktok",
                            "tw": "twitter", "rd": "reddit", "yt": "youtube"}
                plat = plat_map.get(m.group(1), m.group(1))
                labels.add(f"{plat}_avatar_survey")
                labels.add(f"{plat}_scrape")
            m = re.search(r"avatar-survey/data/([a-z_]+)\.json$", fp)
            if m and m.group(1) not in ("data", "config"):
                labels.add(f"{m.group(1)}_avatar_survey")
    return list(labels)


def resolve_wsession_label(script_label, search_roots, max_depth=6):
    """Find a script with basename `script_label`, parse WSession.start
    label, return runtime label. See check_visual_claims for details."""
    targets = {f"{script_label}{ext}" for ext in ('.mjs', '.ts', '.js')}
    skip_dirs = {'node_modules', '.git', 'dist', 'recordings',
                 '__pycache__', '.next', '.venv', 'venv'}
    for root in search_roots:
        if not root.is_dir():
            continue
        for dirpath, dirnames, filenames in os.walk(root):
            try:
                depth = len(Path(dirpath).relative_to(root).parts)
            except ValueError:
                depth = 0
            if depth > max_depth:
                dirnames.clear()
                continue
            dirnames[:] = [d for d in dirnames if d not in skip_dirs]
            for fn in filenames:
                if fn not in targets:
                    continue
                path = Path(dirpath) / fn
                try:
                    text = path.read_text()
                except Exception:
                    continue
                m = re.search(
                    r"WSession\.start\s*\(\s*\{[^}]{0,400}?\blabel\s*:\s*['\"]([^'\"]+)['\"]",
                    text, flags=re.DOTALL)
                if m:
                    return m.group(1)
                m = re.search(
                    r"WSession\.start\s*\(\s*\{[^}]{0,400}?\blabel\s*:\s*`([^`]+)`",
                    text, flags=re.DOTALL)
                if m:
                    template = m.group(1)
                    var_names = re.findall(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}", template)
                    resolved = template
                    for v in var_names:
                        ed = re.search(
                            rf"(?:const|let|var)\s+{re.escape(v)}\s*=\s*process\.env\.{re.escape(v)}\s*\|\|\s*['\"]([^'\"]+)['\"]",
                            text)
                        if not ed:
                            resolved = None
                            break
                        resolved = resolved.replace(f"${{{v}}}", ed.group(1))
                    if resolved:
                        return resolved
    return None


FFPROBE_TIMEOUT_S = int(os.environ.get("CHECK_FAILURE_FFPROBE_TIMEOUT_S", "10"))


def latest_recording_sha8(label):
    bases = [CWD.parent / "weles" / "recordings" / label,
             CWD / "recordings" / label]
    candidates = []
    for b in bases:
        if b.is_dir():
            candidates.extend(b.glob("*.webm"))
    if not candidates:
        return None, None
    latest = max(candidates, key=lambda p: p.stat().st_mtime)
    h = hashlib.sha256()
    with latest.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()[:8], latest


def recording_duration_seconds(rec_path):
    """Return ceil(duration in seconds) of the recording, via ffprobe.
    Returns None when ffprobe is unavailable or the file is unreadable; the
    caller treats None as "minimum gate: require >= 1 frame Read"."""
    import math
    import subprocess
    try:
        out = subprocess.check_output(
            ["ffprobe", "-v", "error",
             "-show_entries", "format=duration",
             "-of", "default=noprint_wrappers=1:nokey=1",
             str(rec_path)],
            stderr=subprocess.DEVNULL, timeout=FFPROBE_TIMEOUT_S,
        ).decode().strip()
        if not out:
            return None
        return max(1, math.ceil(float(out)))
    except Exception:
        return None


def count_distinct_frame_reads(label, sha8, rec_path, lookback=400):
    """Return (count, set_of_paths) — distinct frame_<sha8>_*.png paths Read
    in this session for the matching recording. failure_state_*.png also
    counts (legacy artifact)."""
    jsonl = find_session_jsonl()
    if not jsonl:
        return 0, set()
    pat = re.compile(
        rf"\.work/{re.escape(label)}/(?:frame|failure_state)_{re.escape(sha8)}_?[^\s'\"]*\.(?:png|jpg|html)$"
    )
    rec_mt = rec_path.stat().st_mtime
    try:
        lines = jsonl.read_text().splitlines()
    except Exception:
        return 0, set()
    seen = set()
    for raw in lines[-lookback:]:
        try:
            entry = json.loads(raw)
        except Exception:
            continue
        msg = entry.get("message") or {}
        content = msg.get("content") or []
        if not isinstance(content, list):
            continue
        for block in content:
            if not isinstance(block, dict) or block.get("type") != "tool_use":
                continue
            if block.get("name") != "Read":
                continue
            fp = str((block.get("input") or {}).get("file_path") or "")
            if not pat.search(fp):
                continue
            # NOTE: the old `abs(frame_mtime - rec_mtime) <= 2.0` coupling
            # was a bug — frames are extracted by inspect_trajectory.sh
            # long after the recording finished, so a real frame Read was
            # always skipped and the gate stayed at 0/N forever. The sha8
            # embedded in the frame filename (matched by `pat`) already
            # ties the Read to this exact recording; mtime coupling
            # dropped.
            seen.add(fp)
    return len(seen), seen


def session_has_frame_or_failure_read(label, sha8, rec_path):
    """v8: require a small FIXED sample of frame Reads, not one-per-second.

    The v7 rule (required = ceil(duration_s)) was unsatisfiable: a 60-180s
    recording demanded 62-186 distinct frame Reads, and because
    discover_all_labels() + session_log_reads_imply_labels() add every
    label the agent Reads a frame for, each compliant Read raised the bar
    for more labels — a ratchet that never clears. A handful of
    representative frames already evidences that the agent inspected the
    run before making a verdict. Override with CHECK_FAILURE_MIN_FRAMES.
    Returns (ok, distinct_reads, required)."""
    required = int(os.environ.get("CHECK_FAILURE_MIN_FRAMES", "3"))
    distinct, _ = count_distinct_frame_reads(label, sha8, rec_path)
    return distinct >= required, distinct, required


def main():
    raw = sys.stdin.read()
    try:
        payload = json.loads(raw) if raw.strip() else {}
    except Exception:
        sys.exit(0)
    # Pin frame/transcript scanning to THIS session's exact transcript
    # (removes concurrent-session misidentification). Must be set before
    # any find_session_jsonl() call below.
    tp = payload.get("transcript_path")
    if isinstance(tp, str) and tp:
        globals()["_PAYLOAD_TRANSCRIPT"] = tp
    # Claude Code Stop-hook protocol: payload.last_assistant_message is the
    # assistant's pending response. Older code read payload.message.content,
    # which CC does NOT send to Stop hooks — that path always saw empty
    # text and exited 0, defeating the entire failure-claim guard.
    msg = payload.get("last_assistant_message") or ""
    if not isinstance(msg, str) or not msg.strip():
        sys.exit(0)
    response = msg
    if not FAIL_TERMS.search(response):
        sys.exit(0)

    # Path A: legacy inspect_required.json registrations
    req = HOME / ".shared-hooks" / "state" / "inspect_required.json"
    legacy_missing = []
    if req.is_file():
        try:
            data = json.loads(req.read_text())
        except Exception:
            data = {}
        for label, info in data.items():
            if not label_in_response(label, response):
                continue
            sha8 = info.get("sha8")
            fp = info.get("failure_state")
            if not sha8 or not fp or not Path(fp).is_file():
                continue
            jsonl = find_session_jsonl()
            found = False
            if jsonl:
                pat = re.compile(rf"\.work/{re.escape(label)}/failure_state_{re.escape(sha8)}\.(?:png|jpg|html)$")
                try:
                    lines = jsonl.read_text().splitlines()
                except Exception:
                    lines = []
                for raw2 in lines[-240:]:
                    try:
                        e = json.loads(raw2)
                    except Exception:
                        continue
                    m = e.get("message") or {}
                    cc = m.get("content") or []
                    if not isinstance(cc, list):
                        continue
                    for blk in cc:
                        if (isinstance(blk, dict) and blk.get("type") == "tool_use"
                                and blk.get("name") == "Read"
                                and pat.search(str((blk.get("input") or {}).get("file_path") or ""))):
                            found = True
                if not found:
                    legacy_missing.append((label, sha8, fp))

    # Path B: filesystem-discovered labels with recordings on disk
    labels = discover_all_labels()
    referenced = [l for l in labels if label_in_response(l, response)]
    log_inferred = session_log_reads_imply_labels()
    for l in log_inferred:
        if l not in referenced:
            referenced.append(l)

    # Sibling expansion: same precedence as check_visual_claims —
    #   (a) source-level resolution via WSession.start({label}) parse.
    #   (b) fallback: most-recent token-overlapping sibling.
    search_roots = [CWD, CWD / ".work",
                    CWD.parent / "weles" / "scripts",
                    CWD.parent / "weles" / "src"]
    expanded = list(referenced)
    for label in referenced:
        sha8, rec = latest_recording_sha8(label)
        if sha8 and rec:
            continue
        aliased = resolve_wsession_label(label, search_roots)
        if aliased and aliased not in expanded:
            ali_sha8, ali_rec = latest_recording_sha8(aliased)
            if ali_sha8 and ali_rec:
                expanded.append(aliased)
                continue
        label_toks = {t for t in label_tokens(label) if len(t) >= 4}
        if not label_toks:
            continue
        best = None
        for other in labels:
            if other == label or other in expanded:
                continue
            other_toks = {t for t in label_tokens(other) if len(t) >= 4}
            if not (label_toks & other_toks):
                continue
            sib_sha8, sib_rec = latest_recording_sha8(other)
            if not sib_sha8 or not sib_rec:
                continue
            mt = sib_rec.stat().st_mtime
            if best is None or mt > best[0]:
                best = (mt, other, sib_sha8, sib_rec)
        if best:
            expanded.append(best[1])
    referenced = expanded

    fs_missing = []
    for label in referenced:
        sha8, rec = latest_recording_sha8(label)
        if not sha8 or not rec:
            continue
        ok, distinct, required = session_has_frame_or_failure_read(label, sha8, rec)
        if not ok:
            fs_missing.append((label, sha8, rec, distinct, required))

    if not legacy_missing and not fs_missing:
        sys.exit(0)

    print("=" * 60, file=sys.stderr)
    print("  BLOCKED: failure claim without enough frame Reads (1 frame / second of recording)", file=sys.stderr)
    print("=" * 60, file=sys.stderr)
    for label, sha8, fp in legacy_missing:
        print(f"  trajectory '{label}' (sha8={sha8})", file=sys.stderr)
        print(f"    Read {fp} before claiming what made the run fail.", file=sys.stderr)
    for label, sha8, rec, distinct, required in fs_missing:
        print(f"  trajectory '{label}' — latest {rec.name} (sha8={sha8})", file=sys.stderr)
        print(f"    Read {distinct}/{required} required frames so far.", file=sys.stderr)
        print(f"    Read .work/{label}/frame_{sha8}_*.png (need {required} distinct paths) OR run", file=sys.stderr)
        print(f"      $HOME/.shared-hooks/inspect_trajectory.sh {label}", file=sys.stderr)
    print("", file=sys.stderr)
    print("Bypass: CHECK_FAILURE_INSPECTION_DISABLED=1.", file=sys.stderr)
    sys.exit(2)


if __name__ == "__main__":
    main()
