#!/usr/bin/env node

import { readFile } from 'node:fs/promises'
import { existsSync } from 'node:fs'
import { spawn } from 'node:child_process'
import { homedir } from 'node:os'
import { join } from 'node:path'
import { looksLikeMalfunction, tokenizeCommand } from './hook-exec.mjs'
import { capabilityEnvironment } from './session-capability.mjs'
import {
  isSessionHookEnabled,
  readSessionOverride,
  publishSession,
  sessionContext,
} from './session-control.mjs'

const registryPath = process.env.AGENT_HOOK_REGISTRY || join(homedir(), '.shared-hooks', 'registry.json')
const event = process.argv[2]
const agentId = String(process.argv[3] || process.env.TAMA_AGENT_ID || '').trim().toLowerCase()
const provider = String(process.env.TAMA_PROVIDER || agentId).trim().toLowerCase()
const onlyHookId = String(process.env.TAMA_ONLY_HOOK_ID || '').trim()
const requestedDisabledHookIds = String(process.env.TAMA_DISABLED_HOOKS || '')
  .split(',')
  .map((id) => id.trim())
  .filter(Boolean)
const disabledHookIds = new Set(requestedDisabledHookIds)
const hasEnabledHookFilter = Object.hasOwn(process.env, 'TAMA_ENABLED_HOOKS')
const enabledHookIds = new Set(
  String(process.env.TAMA_ENABLED_HOOKS || '')
    .split(',')
    .map((id) => id.trim())
    .filter(Boolean),
)
let sessionCapability = null

function usage() {
  return 'Usage: run-hook.mjs <event> <agent-id>\nExample: run-hook.mjs stop agent\n'
}

function expandHome(command) {
  return String(command).replace(/~(?=\/|$)/g, homedir()).replace(/\$HOME/g, homedir())
}

async function stdinText() {
  const chunks = []
  for await (const chunk of process.stdin) chunks.push(Buffer.from(chunk))
  return Buffer.concat(chunks).toString('utf8')
}

function parsePayload(text) {
  if (!text.trim()) return {}
  try {
    return JSON.parse(text)
  } catch {
    return { raw: text }
  }
}

function runCommand(command, input, timeoutMs) {
  return new Promise((resolve) => {
    const [program, ...args] = tokenizeCommand(expandHome(command))
    if (!program) {
      resolve({ code: null, signal: null, timedOut: false, stdout: '', stderr: 'empty hook command', spawnError: true })
      return
    }
    // No shell: registry commands are argv, so a registry write cannot smuggle
    // shell syntax into every tool call.
    const child = spawn(program, args, { env: capabilityEnvironment(sessionCapability) })
    let stdout = ''
    let stderr = ''
    let timedOut = false
    const timer = setTimeout(() => {
      timedOut = true
      child.kill('SIGTERM')
    }, timeoutMs)
    child.stdout.on('data', (chunk) => { stdout += chunk.toString('utf8') })
    child.stderr.on('data', (chunk) => { stderr += chunk.toString('utf8') })
    child.stdin.on('error', (error) => { stderr += error instanceof Error ? error.message : String(error) })
    child.on('error', (error) => {
      clearTimeout(timer)
      resolve({
        code: null,
        signal: null,
        timedOut,
        stdout,
        stderr: error instanceof Error ? error.message : String(error),
        spawnError: true,
      })
    })
    child.on('close', (code, signal) => {
      clearTimeout(timer)
      resolve({ code, signal, timedOut, stdout, stderr })
    })
    child.stdin.end(input)
  })
}

function decisionFromOutput(text) {
  const trimmed = String(text || '').trim()
  if (!trimmed) return null
  try {
    const parsed = JSON.parse(trimmed)
    if (parsed && typeof parsed === 'object' && parsed.decision === 'block') {
      return parsed.reason || 'hook returned block decision'
    }
  } catch {}
  return null
}

// Preflight: a registered hook whose program or script path does not exist is
// reported as unavailable and skipped. A missing file is an infrastructure
// failure, never a policy verdict, so it must not deny the tool call.
function missingCommandPaths(command) {
  const [program, ...args] = tokenizeCommand(expandHome(command))
  const candidates = []
  if (program && program.includes('/')) candidates.push(program)
  const scriptArg = args.find(arg => arg.startsWith('/'))
  if (scriptArg) candidates.push(scriptArg)
  return candidates.filter(candidate => !existsSync(candidate))
}

function emitDecision(value) {
  if (provider === 'codex') {
    if (value.decision !== 'pass') {
      process.stdout.write(JSON.stringify({
        decision: 'block',
        reason: value.reason || 'hook returned block decision',
      }))
    }
    return
  }
  process.stdout.write(JSON.stringify(value))
  if (value.decision === 'block') process.exitCode = 2
}

async function main() {
  if (!event) {
    process.stderr.write(usage())
    process.exit(2)
  }
  const registry = JSON.parse(await readFile(registryPath, 'utf8'))
  const input = await stdinText()
  const payload = parsePayload(input)
  const knownHookIds = new Set(
    Object.values(registry.events || {}).flatMap(
      entry => (entry.hooks || []).map(hook => String(hook.id || '')).filter(Boolean),
    ),
  )
  const context = sessionContext(agentId, payload)
  sessionCapability = readSessionOverride(context, knownHookIds).capability
  publishSession(context, knownHookIds, payload)
  const entry = registry.events?.[event]
  if (!entry) {
    emitDecision({ decision: 'pass', reason: `no hooks for ${event}` })
    return
  }
  // Codex used to load one wrapper per hook and freeze that wrapper list for
  // the lifetime of a session. During migration, the first legacy wrapper for
  // an event becomes the dispatcher and the remaining frozen wrappers no-op.
  // Newly generated Codex config has no TAMA_ONLY_HOOK_ID and always dispatches
  // the current registry entry, so additions/removals hot-reload immediately.
  const legacyCodexDispatcher = provider === 'codex'
    && onlyHookId
    && onlyHookId === String(entry.hooks?.[0]?.id || '')
  if (provider === 'codex' && onlyHookId && !legacyCodexDispatcher) {
    emitDecision({ decision: 'pass', reason: `legacy wrapper ${onlyHookId} delegated to dispatcher` })
    return
  }
  const rawEvent = payload.raw_event && typeof payload.raw_event === 'object' ? payload.raw_event : {}
  const normalized = JSON.stringify({
    ...payload,
    cwd: payload.cwd || rawEvent.cwd || payload.project_dir,
    transcript_path: payload.transcript_path || rawEvent.transcript_path || rawEvent.transcriptPath || null,
    raw_event: undefined,
    agent_hook_event: event,
  })
  const results = []

  for (const hook of entry.hooks || []) {
    if (
      (onlyHookId && !legacyCodexDispatcher && hook.id !== onlyHookId)
      || disabledHookIds.has(hook.id)
      || (hasEnabledHookFilter && !enabledHookIds.has(hook.id))
      || !isSessionHookEnabled(context, hook.id, knownHookIds)
    ) {
      results.push({ id: hook.id, skipped: true })
      continue
    }
    const unavailable = missingCommandPaths(hook.command)
    if (unavailable.length > 0) {
      process.stderr.write(`hook ${hook.id} unavailable: missing ${unavailable.join(', ')}\n`)
      results.push({ id: hook.id, unavailable: true })
      continue
    }
    const timeoutMs = Math.max(1, Number(hook.timeout || 10)) * 1000
    const result = await runCommand(hook.command, normalized, timeoutMs)
    const record = { id: hook.id, code: result.code, timedOut: result.timedOut }
    results.push(record)

    if (result.timedOut) {
      const reason = `${hook.id} timed out after ${hook.timeout || 10}s`
      if (entry.blocking !== false) {
        emitDecision({ decision: 'block', reason, blockedHookId: hook.id, results })
        return
      }
      continue
    }

    const blockReason = decisionFromOutput(result.stdout) || decisionFromOutput(result.stderr)
    if (blockReason) {
      emitDecision({ decision: 'block', reason: `${hook.id}: ${blockReason}`, blockedHookId: hook.id, results })
      return
    }

    if (result.spawnError || (result.code && looksLikeMalfunction(result))) {
      // The hook crashed. A broken policy engine is not a policy decision;
      // denying on it is indistinguishable from a deliberate block.
      process.stderr.write(`hook ${hook.id} malfunctioned: ${(result.stderr || result.stdout || '').trim()}\n`)
      record.failed = true
      continue
    }

    if (result.code && entry.blocking !== false) {
      const reasonText = (result.stderr || result.stdout || `exit ${result.code}`).trim()
      emitDecision({ decision: 'block', reason: `${hook.id}: ${reasonText}`, blockedHookId: hook.id, results })
      return
    }
  }

  emitDecision({ decision: 'pass', results })
}

main().catch((error) => {
  process.stderr.write(`hook runner failure: ${error instanceof Error ? error.message : String(error)}\n`)
  emitDecision({ decision: 'pass', reason: 'hook runner failure' })
})
