#!/usr/bin/env python3
"""Stop hook: ban appeals to common knowledge ("is known to be" & kin).

Phrasing like "is known to be", "well-known", "notoriously", "everyone
knows" asserts a fact by appeal to authority/common knowledge with zero
evidence. It is a reliable tell of fabrication: when the assistant cannot
cite a source it reaches for "is known to be" instead of saying "I do not
know" or producing a file:line / command output / citation.

This hook blocks the assistant turn when such phrasing appears OUTSIDE of
quoted or code-span context, so the banned phrase can still be quoted and
discussed (wrap it in backticks or quotes) without tripping the gate.

Contract matches the other Stop hooks (check_speculation.py etc.): read the
hook payload as JSON on stdin, inspect `last_assistant_message`, and emit
{"decision": "block", "reason": ...} to block. Cross-agent: Claude Code,
Droid, Codex all deliver the same payload shape.
"""
from __future__ import annotations

import json
import re
import sys

# The "appeal to common knowledge" family. All matched case-insensitively.
PATTERNS = [
    # is/are/was/were/be/been/being known to|for|as ...
    r"\b(?:is|are|was|were|be|been|being|it'?s)\s+known\s+(?:to|for|as)\b",
    # bare "known to be"
    r"\bknown\s+to\s+be\b",
    # "is a known <thing>"
    r"\bis\s+a\s+known\b",
    # "known issue|bug|fact|..." — asserting established-ness without proof
    r"\bknown\s+(?:issue|bug|fact|problem|limitation|behaviou?r|quirk|caveat|gotcha)\b",
    # well-known / well known
    r"\bwell[-\s]?known\b",
    # widely|commonly|generally|universally known
    r"\b(?:widely|commonly|generally|universally)\s+known\b",
    # it is / it's / it was known that
    r"\bit\s+(?:is|'?s|was)\s+known\s+that\b",
    # as (is) (well) known
    r"\bas\s+(?:is\s+)?(?:well\s+)?known\b",
    # everyone knows / as we (all) know
    r"\beveryone\s+knows\b",
    r"\bas\s+we(?:\s+all)?\s+know\b",
    # single-word appeals to common knowledge
    r"\bnotoriously\b",
    r"\bfamously\b",
]
COMPILED = [re.compile(p, flags=re.IGNORECASE) for p in PATTERNS]


def strip_quoted(text: str) -> str:
    """Blank out fenced blocks, inline code spans, and quoted spans so the
    banned phrase can be quoted/discussed without tripping the gate."""
    text = re.sub(r"```.*?```", " ", text, flags=re.DOTALL)
    text = re.sub(r"`[^`]*`", " ", text)
    text = re.sub(r"\"[^\"]*\"", " ", text)
    text = re.sub(r"'[^']*'", " ", text)
    text = re.sub(r"“[^”]*”", " ", text)  # smart double quotes
    return text


def find_hits(text: str) -> list[str]:
    scan = strip_quoted(text)
    hits: list[str] = []
    for regex in COMPILED:
        for match in regex.finditer(scan):
            hits.append(match.group(0).strip())
    return list(dict.fromkeys(hits))


def main() -> int:
    try:
        payload = json.loads(sys.stdin.read() or "{}")
    except json.JSONDecodeError:
        return 0
    if payload.get("stop_hook_active"):
        return 0
    msg = payload.get("last_assistant_message") or ""
    if not isinstance(msg, str) or not msg.strip():
        return 0
    hits = find_hits(msg)
    if not hits:
        return 0
    reason = (
        "BLOCKED: fabrication tell. You wrote " + repr(hits[0]) + ". "
        "'is known to be' / 'well-known' / 'notoriously' / 'everyone knows' "
        "assert a fact by appeal to common knowledge with zero evidence. "
        "Cite the specific source instead (a file:line, a command's output, a "
        "URL/citation) or say plainly that you do not know. To quote or discuss "
        "the phrase itself, wrap it in backticks or quotes."
    )
    print(json.dumps({"decision": "block", "reason": reason}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
