#!/bin/bash
# PostToolUse hook on Bash — when a trajectory invocation exits non-zero
# OR prints failure markers OR drops a fresh ban_signal{healthy:false}
# OR returns a string of "0 handles / 0 results" (empty-result run),
# extract a last-frame PNG into .work/<label>/failure_state_<sha8>.png
# and register an inspect_required entry.
#
# v6 (2026-05-09): added FAIL_VIA_EMPTY_RESULT path. Catches scrapes
# that return EXIT=0 but produced 0 useful items.

set -euo pipefail

if [[ -n "${DETECT_POST_TRAJECTORY_ACTIVE:-}" ]]; then exit 0; fi
INPUT=$(cat)
CMD=$(echo "$INPUT" | jq -r '.tool_input.command // empty')
EXIT=$(echo "$INPUT" | jq -r '.tool_response.exitCode // .tool_response.exit_code // 0')
STDOUT=$(echo "$INPUT" | jq -r '.tool_response.stdout // .tool_response.output // .tool_response.content // empty' 2>/dev/null || true)
STDERR=$(echo "$INPUT" | jq -r '.tool_response.stderr // empty' 2>/dev/null || true)
[[ -z "$CMD" ]] && exit 0

FAIL_VIA_EXIT=0
FAIL_VIA_STDOUT=0
FAIL_VIA_BAN=0
FAIL_VIA_EMPTY=0
[[ "$EXIT" != "0" ]] && FAIL_VIA_EXIT=1
if echo "$STDOUT$STDERR" | grep -qE '(^|\\n|[[:space:]])FAIL:[[:space:]]'; then
    FAIL_VIA_STDOUT=1
fi

# Empty-result detection: 3+ matches of common "got nothing" markers in stdout
# means the run produced no useful output even if EXIT=0. Patterns:
#   "0 handles (running total 0)"   — avatar-survey scrape
#   "0 entries"                     — generic
#   "0 results"                     — generic
#   "no results"                    — generic
#   "running total 0)"              — partial of avatar-survey marker
EMPTY_HITS=$(echo "$STDOUT$STDERR" | grep -cE '0 handles \(running total 0\)|\b0 entries\b|\b0 results\b|\bno results\b|running total 0\)' || true)
if [[ -n "$EMPTY_HITS" ]] && [[ "$EMPTY_HITS" -ge 3 ]]; then
    FAIL_VIA_EMPTY=1
fi

# Three detection paths so wrapping a trajectory in `bash run.sh` can't
# hide it from this hook:
#   (1) scripts/trajectories/...mjs path in CMD
#   (2) node|tsx|bun|deno|ts-node|npx ... .mjs|.ts source-greps WSession.start
#   (3) FALLBACK: any *.webm in weles/recordings/<*>/ or ./recordings/<*>/
#       was modified within the last 60s.
TRAJ_MATCH=$(echo "$CMD" | grep -oE 'scripts/trajectories/[A-Za-z0-9_./-]+\.[mc]?[tj]sx?' | head -1 || true)
if [[ -z "$TRAJ_MATCH" ]]; then
    SP=$(echo "$CMD" | grep -oE '(node|tsx|bun|deno|ts-node|npx)([[:space:]]+(run|--[A-Za-z0-9_-]+(=[^[:space:]]+)?))*[[:space:]]+[A-Za-z0-9_./~$-]+\.[mc]?[tj]sx?' | grep -oE '[A-Za-z0-9_./~$-]+\.[mc]?[tj]sx?$' | head -1 || true)
    if [[ -n "$SP" ]] && [[ -f "$SP" ]] && grep -qE 'WSession\.start|wsession\.start' "$SP" 2>/dev/null; then
        TRAJ_MATCH="$SP"
    fi
fi

REPO="$(pwd)"
LABEL=""
if [[ -n "$TRAJ_MATCH" ]]; then
    LABEL=$(basename "$TRAJ_MATCH" | sed -E 's/\.[mc]?[tj]sx?$//')
fi

# Path (3) fallback — fresh .webms even when CMD was wrapped.
RECENT_RECORDINGS=()
for ROOT in "$REPO/../weles/recordings" "$REPO/recordings"; do
    [[ -d "$ROOT" ]] || continue
    while IFS= read -r WEBM; do
        [[ -z "$WEBM" ]] && continue
        RECENT_RECORDINGS+=("$WEBM")
    done < <(/usr/bin/find "$ROOT" -type f -name '*.webm' -mtime -1 -print 2>/dev/null | while read -r f; do
        AGE=$(($(date +%s) - $(stat -f %m "$f" 2>/dev/null || stat -c %Y "$f" 2>/dev/null || echo 0)))
        [[ $AGE -le 60 ]] && echo "$f"
    done)
done

if [[ -z "$LABEL" && ${#RECENT_RECORDINGS[@]} -eq 0 ]]; then exit 0; fi

# Path (c): fresh ban_signal.json with healthy:false.
for ROOT in "$REPO/../weles/recordings" "$REPO/recordings"; do
    [[ -d "$ROOT" ]] || continue
    while IFS= read -r BAN; do
        [[ -z "$BAN" ]] && continue
        AGE=$(($(date +%s) - $(stat -f %m "$BAN" 2>/dev/null || stat -c %Y "$BAN" 2>/dev/null || echo 0)))
        [[ $AGE -le 90 ]] || continue
        if grep -qE '"healthy"[[:space:]]*:[[:space:]]*false' "$BAN" 2>/dev/null; then
            FAIL_VIA_BAN=1
        fi
    done < <(/usr/bin/find "$ROOT" -type f -name 'ban_signal.json' -mtime -1 -print 2>/dev/null)
done

# Decide: only proceed when we have at least one positive failure signal.
if [[ "$FAIL_VIA_EXIT" == "0" && "$FAIL_VIA_STDOUT" == "0" \
      && "$FAIL_VIA_BAN" == "0" && "$FAIL_VIA_EMPTY" == "0" ]]; then
    exit 0
fi

# Find the recording for this run.
REC=""
if [[ -n "$LABEL" ]]; then
    for cand in "$REPO/../weles/recordings/$LABEL" "$REPO/recordings/$LABEL"; do
        if [[ -d "$cand" ]]; then
            REC=$(ls -t "$cand"/*.webm 2>/dev/null | head -1 || true)
            [[ -n "$REC" ]] && break
        fi
    done
fi
if [[ -z "$REC" && ${#RECENT_RECORDINGS[@]} -gt 0 ]]; then
    REC="${RECENT_RECORDINGS[0]}"
    LABEL=$(basename "$(dirname "$REC")")
fi
[[ -z "$REC" || ! -f "$REC" ]] && exit 0

REC=$(cd "$(dirname "$REC")" && pwd)/$(basename "$REC")
SHA=$(shasum -a 256 "$REC" | awk '{print $1}')
SHA8=${SHA:0:8}
WORK="$REPO/.work/$LABEL"
mkdir -p "$WORK"
OUT="$WORK/failure_state_${SHA8}.png"
DUR=$(ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "$REC" 2>/dev/null || echo "")
if [[ -n "$DUR" ]]; then
    LAST=$(awk -v d="$DUR" 'BEGIN { printf "%.2f", (d > 0.5 ? d - 0.5 : 0) }')
    DETECT_POST_TRAJECTORY_ACTIVE=1 ffmpeg -y -loglevel error -ss "$LAST" -i "$REC" -frames:v 1 "$OUT" 2>&1 || true
    touch -r "$REC" "$OUT" 2>/dev/null || true
fi

# Record the inspect-required state for the Stop / PreToolUse hooks.
STATE_DIR="$HOME/.shared-hooks/state"
REQ="$STATE_DIR/inspect_required.json"
mkdir -p "$STATE_DIR"
[ -f "$REQ" ] || echo '{}' > "$REQ"
REASON="exit:${FAIL_VIA_EXIT},stdout:${FAIL_VIA_STDOUT},ban:${FAIL_VIA_BAN},empty:${FAIL_VIA_EMPTY}"
jq --arg lbl "$LABEL" --arg sha "$SHA8" --arg rec "$REC" --arg out "$OUT" --arg why "$REASON" \
   '. + {($lbl): {sha8: $sha, recording: $rec, failure_state: $out, reason: $why, set_at: (now | strftime("%Y-%m-%dT%H:%M:%SZ"))}}' \
   "$REQ" > "$REQ.tmp" && mv "$REQ.tmp" "$REQ"
exit 0
