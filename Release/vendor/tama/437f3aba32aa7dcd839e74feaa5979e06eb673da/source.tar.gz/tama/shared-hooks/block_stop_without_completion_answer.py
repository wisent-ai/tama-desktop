#!/usr/bin/env python3
# Stop hook. Puts one question in front of every ending turn and refuses the stop
# until the answer is yes:
#
#   przeczytaj agents.md. czy ukonczyles swoje zadanie idealnie? tak czy nie.
#   jesli nie, to nie mozesz przerwac swojej odpowiedzi
#
# The user asked for this hook after a session in which the agent ended eleven
# turns in a row with work it had itself identified and not done: a leftovers
# list, an unanswered question, three pushes nobody asked for, and four
# rewrites of one file. Each ending looked reasonable in isolation.
#
# A yes is not a password. Answering yes while the payload still shows pending
# tracker work, or while the message carries the leftovers phrasing ~/AGENTS.md
# bans, or while the message ends on a question, is a false yes -- and a false
# yes is worse than no answer, because it launders an unfinished turn as a
# finished one. Those cases are refused with the contradiction named.
#
# Deliberately unbounded, matching block-stop-with-open-work: there is no attempt
# counter that eventually lets an unfinished turn through. The way out is to
# finish the work, or to state the one external prerequisite that only the user
# can supply, which is the single carve-out ~/AGENTS.md keeps.
from __future__ import annotations
import json, os, re, sys

CHALLENGE = (
    'przeczytaj agents.md. czy ukonczyles swoje zadanie idealnie? tak czy nie. '
    'jesli nie, to nie mozesz przerwac swojej odpowiedzi'
)

# An explicit affirmative about completion. A bare "tak" somewhere in prose is
# not an answer to this question; the sentence has to be about being finished.
AFFIRMATIVE = re.compile(
    r'(?i)('
    r'\btak\b[^.!?\n]{0,80}\b(ukonczon|ukończon|skonczon|skończon|zakonczon|zakończon|kompletn|w calosci|w całości)'
    r'|\b(ukonczone|ukończone|skonczone|skończone|zakonczone|zakończone)\b[^.!?\n]{0,40}\bw (calosci|całości)\b'
    r'|\bzadanie (jest )?(ukonczone|ukończone|skonczone|skończone) w (calosci|całości)\b'
    r'|\byes\b[^.!?\n]{0,80}\b(complete|completed|finished|done in full)'
    r'|\btask (is )?complete(d)? in full\b'
    r')'
)
# The phrasing ~/AGENTS.md bans outright. Its presence contradicts any yes.
LEFTOVERS = re.compile(
    r'(?i)('
    r'czego nie zrobi|co zostaje otwarte|co pozostaje|pozostaje otwarte|do zrobienia pozniej'
    r'|what i did not do|what remains|remains open|outstanding|next steps'
    r'|left for later|follow-?up items|to do later'
    r')'
)
# A question aimed at the user. The carve-out is a single external prerequisite,
# so one question is tolerated; a message that asks several is deferring.
QUESTION = re.compile(r'[^\n]*\?\s*$', re.MULTILINE)
OPEN_STATES = ('pending', 'in_progress', 'in progress', 'blocked')
# `transcript_path` is what the OMP adapter actually supplies on a stop event:
# lifecyclePayload carries only agent_hook_event, runtime, session_id,
# project_dir and raw_event, and runRegistryEvent then lifts a transcript path
# out of the raw event. A stop hook that reads only inline message keys is
# structurally blind in this runtime -- it inspects nothing, finds nothing, and
# passes. That is why a whole family of stop gates never fired.
TRANSCRIPT_KEYS = ('transcript', 'messages', 'session', 'events', 'transcript_path')


def records(payload):
    for key in TRANSCRIPT_KEYS:
        value = payload.get(key)
        if isinstance(value, list):
            for item in value:
                if isinstance(item, dict):
                    yield item
        elif isinstance(value, str) and os.path.isfile(value):
            try:
                with open(value, 'r', encoding='utf-8', errors='replace') as handle:
                    for line in handle:
                        try:
                            yield json.loads(line)
                        except Exception:
                            continue
            except Exception:
                continue


def text_of(record):
    message = record.get('message') if isinstance(record.get('message'), dict) else None
    content = (message or record).get('content')
    parts = []
    if isinstance(content, str):
        parts.append(content)
    elif isinstance(content, list):
        for entry in content:
            if isinstance(entry, dict):
                for key in ('text', 'input', 'command'):
                    value = entry.get(key)
                    if isinstance(value, str):
                        parts.append(value)
                    elif isinstance(value, dict):
                        parts.append(json.dumps(value))
    return chr(10).join(parts)


def final_message(payload):
    for key in ('final_message', 'assistant_message', 'response', 'message'):
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            return value
        if isinstance(value, dict):
            content = value.get('content')
            if isinstance(content, str):
                return content
            if isinstance(content, list):
                return chr(10).join(
                    part.get('text', '') for part in content if isinstance(part, dict)
                )
    last = ''
    for record in records(payload):
        message = record.get('message') if isinstance(record.get('message'), dict) else None
        role = (message.get('role') if message else None) or record.get('role')
        if role != 'assistant':
            continue
        # Only a record that actually carries prose may replace the candidate. An
        # assistant turn is usually a tool call with thinking blocks and no text,
        # and taking the last record unconditionally overwrote the real reply
        # with an empty string -- which made every message look like it claimed
        # nothing and, on the passing side, look like it said nothing wrong.
        spoken = text_of(record)
        if spoken.strip():
            last = spoken
    return last


def open_tracker_items(payload):
    """Task titles the latest tracker snapshot still shows as not finished."""
    latest = None
    for record in records(payload):
        blob = text_of(record)
        # No pre-filter on the wording of the call. An earlier version required
        # the blob to mention "op" or "todo" and therefore missed a bare tracker
        # snapshot entirely -- caught by its own test. A snapshot is recognised
        # by its shape: an object carrying items, or phases carrying items.
        if '"items"' not in blob and '"list"' not in blob:
            continue
        for match in re.finditer(r'\{.*\}', blob, re.DOTALL):
            try:
                candidate = json.loads(match.group())
            except Exception:
                continue
            if isinstance(candidate, dict) and ('items' in candidate or 'list' in candidate):
                latest = candidate
    if not isinstance(latest, dict):
        return []
    open_items = []
    entries = latest.get('items')
    if not isinstance(entries, list):
        entries = []
        for phase in latest.get('list') or []:
            if isinstance(phase, dict) and isinstance(phase.get('items'), list):
                entries.extend(phase['items'])
    for entry in entries:
        if isinstance(entry, dict):
            state = str(entry.get('status') or entry.get('state') or '').lower()
            if state in OPEN_STATES:
                open_items.append(str(entry.get('content') or entry.get('task') or '?'))
    return open_items


def contradictions(message, payload):
    found = []
    leftovers = LEFTOVERS.search(message)
    if leftovers:
        found.append(
            'the message says "{}", which ~/AGENTS.md bans outright: a list of '
            'things you identified and did not do is a list of things you should '
            'have done in this turn'.format(leftovers.group())
        )
    questions = QUESTION.findall(message)
    if len(questions) > 1:
        found.append(
            '{} sentences end in a question mark; the carve-out is one external '
            'prerequisite only you cannot supply, not a set of decisions handed '
            'back'.format(len(questions))
        )
    open_items = open_tracker_items(payload)
    if open_items:
        found.append(
            'the tracker still shows {} unfinished item(s): {}'.format(
                len(open_items), ', '.join(open_items[:5])
            )
        )
    return found


def check(payload):
    message = final_message(payload)
    if not message.strip():
        return CHALLENGE
    answered = AFFIRMATIVE.search(message)
    problems = contradictions(message, payload)
    if answered and not problems:
        return None
    lines = [CHALLENGE, '']
    if not answered:
        lines.append(
            'block-stop-without-completion-answer: this turn ends without saying, '
            'in so many words, that the task is finished in full. Say it and mean '
            'it, or keep working.'
        )
    else:
        lines.append(
            'block-stop-without-completion-answer: the message claims completion '
            'while contradicting itself. A false yes is worse than no answer.'
        )
    for problem in problems:
        lines.append('  - ' + problem)
    return chr(10).join(lines)


def main():
    try:
        payload = json.loads(sys.stdin.read())
    except Exception:
        return 0
    problem = check(payload)
    if not problem:
        return 0
    sys.stderr.write(problem + chr(10))
    return 2


if __name__ == '__main__':
    sys.exit(main())
