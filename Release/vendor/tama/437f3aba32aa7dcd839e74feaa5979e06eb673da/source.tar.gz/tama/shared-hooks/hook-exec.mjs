// Shared execution helpers for the hook runners.
//
// Two invariants live here:
//   1. Hook commands are argv, never a shell string. A registry write must not
//      be able to smuggle shell syntax into every tool call.
//   2. A crashing hook is a malfunction, not a policy decision. Denying on a
//      traceback makes a broken policy engine indistinguishable from a
//      deliberate block, and the agent cannot tell the difference either.

export const MALFUNCTION_RE = /^\s*(?:TAMA_HOOK_INFRASTRUCTURE:|Traceback \(most recent call last\):|File ".*", line |at [^\s]+ \(.*\)$|(?:ModuleNotFound|Import|Syntax|Indentation|Tab)Error:|node:internal\/|[^\s:]*: (?:command not found|No such file or directory)$|.*can't open file '.*': \[Errno 2\] No such file or directory$)/m

// Shell word semantics: quoted and unquoted runs that are not separated by
// whitespace belong to the SAME argument. Registry commands rely on this, e.g.
//   node '/path with spaces'/hooks/entry.mjs
// which is one path argument, not two.
export function tokenizeCommand(command) {
  const tokens = []
  let current = ''
  let started = false
  let quote = null
  let escaped = false
  for (const char of String(command)) {
    if (escaped) {
      current += char
      escaped = false
      continue
    }
    if (quote !== "'" && char === '\\') {
      escaped = true
      started = true
      continue
    }
    if (quote === null && (char === '"' || char === "'")) {
      quote = char
      started = true
      continue
    }
    if (quote !== null && char === quote) {
      quote = null
      continue
    }
    if (quote === null && /\s/.test(char)) {
      if (started) {
        tokens.push(current)
        current = ''
        started = false
      }
      continue
    }
    current += char
    started = true
  }
  if (started) tokens.push(current)
  return tokens
}

export function looksLikeMalfunction(result) {
  if (result?.spawnError) return true
  return MALFUNCTION_RE.test(String(result?.stderr || ''))
    || MALFUNCTION_RE.test(String(result?.stdout || ''))
}
