#!/usr/bin/env python3
"""PreToolUse hook on Read.

Blocks reads of text-log files until the agent has written a
.work/<label>/visual_summary.md describing what was inspected in the
DOM dumps and recording frames, with 50+ words and mtime within the
last 5 minutes.

The intent: force frame-first, log-second discipline. Reading raw
script log output before inspecting the actual rendered page state
leads to log-driven inference that diverges from what LinkedIn (or
any other site) actually showed the user.

Log-like paths the hook gates:
    /tmp/<anything>.log
    /tmp/<anything>.txt
    .work/<label>/run_*.log
    .work/<label>/*.log
    /private/tmp/claude-*/tasks/*.output
    recordings/<label>/<file>.log

For each gated path the hook derives a label, then requires:
    .work/<label>/visual_summary.md exists
    word count >= 50
    mtime within last 5 minutes (so the summary is fresh, not reused)

If satisfied, the read passes silently. Otherwise the hook prints
instructions and exit 2.
"""
import json
import os
import re
import sys
import time
from pathlib import Path

raw = sys.stdin.read()
try:
    payload = json.loads(raw) if raw.strip() else {}
except Exception:
    sys.exit(0)

tool = payload.get("tool_name") or ""
if tool != "Read":
    sys.exit(0)

fp = (payload.get("tool_input") or {}).get("file_path") or ""
if not fp:
    sys.exit(0)

LOG_PATTERNS = [
    r"^/tmp/.*\.(log|txt)$",
    r"^/private/tmp/.*\.(log|output)$",
    r"\.work/[^/]+/.*\.log$",
    r"\.work/[^/]+/run[_0-9]*\.log$",
    r"recordings/[^/]+/.*\.log$",
    r"^/tmp/batch_.*",
    r"^/tmp/li_register.*",
    r"^/tmp/deep_.*",
    r"^/tmp/test_stooges.*",
    r"^/tmp/keeper_.*",
]
COMBINED = re.compile("|".join(LOG_PATTERNS))
if not COMBINED.search(fp):
    sys.exit(0)


def derive_label(path: str) -> str:
    base = os.path.basename(path)
    if base.startswith("batch_deep"):
        return "batch_deep"
    if base.startswith("li_register") or base.startswith("linkedin_register"):
        return "linkedin_register"
    if base.startswith("deep_"):
        return "linkedin_deep_extract"
    if base.startswith("li_login") or base.startswith("linkedin_login"):
        return "linkedin_login"
    if base.startswith("test_stooges"):
        return "test_stooges"
    if base.startswith("keeper_"):
        return "keeper"
    m = re.search(r"\.work/([^/]+)/", path)
    if m:
        return m.group(1)
    if "/tasks/" in path:
        return "session_task"
    return os.path.splitext(base)[0]


label = derive_label(fp)
cwd = Path(os.getcwd())
summary = cwd / ".work" / label / "visual_summary.md"

if not summary.exists():
    print("=" * 60, file=sys.stderr)
    print(f"  BLOCKED: cannot Read log {os.path.basename(fp)}", file=sys.stderr)
    print(f"           write visual_summary.md FIRST", file=sys.stderr)
    print("=" * 60, file=sys.stderr)
    print("", file=sys.stderr)
    print(f"Before reading any text log for trajectory '{label}':", file=sys.stderr)
    print(f"  1. Run $HOME/.shared-hooks/inspect_trajectory.sh {label}", file=sys.stderr)
    print(f"     to extract first/mid/last frames + the recording.", file=sys.stderr)
    print(f"  2. Read each frame .work/{label}/frame_<sha8>_*.png with Read.", file=sys.stderr)
    print(f"  3. Read DOM dumps under .work/{label}/ if any exist.", file=sys.stderr)
    print(f"  4. Write a 50+ word summary to:", file=sys.stderr)
    print(f"     {summary}", file=sys.stderr)
    print(f"     covering frames watched, what each rendered, DOM contents,", file=sys.stderr)
    print(f"     page-state conclusion. Then re-attempt the Read.", file=sys.stderr)
    sys.exit(2)

try:
    text = summary.read_text()
except Exception as e:
    print(f"BLOCKED: cannot read {summary}: {e}", file=sys.stderr)
    sys.exit(2)
words = len([w for w in re.split(r"\s+", text) if w])
if words < 50:
    print("=" * 60, file=sys.stderr)
    print(f"  BLOCKED: visual_summary.md too short ({words}/50 words)", file=sys.stderr)
    print("=" * 60, file=sys.stderr)
    print(f"  Path: {summary}", file=sys.stderr)
    print(f"  Expand to >=50 words covering frames + DOM + page state.", file=sys.stderr)
    sys.exit(2)

age = time.time() - summary.stat().st_mtime
if age > 300:
    print("=" * 60, file=sys.stderr)
    print(f"  BLOCKED: visual_summary.md stale (age {int(age)}s, max 300s)", file=sys.stderr)
    print("=" * 60, file=sys.stderr)
    print(f"  Path: {summary}", file=sys.stderr)
    print(f"  Re-run inspect_trajectory.sh {label}, re-Read latest frames,", file=sys.stderr)
    print(f"  and rewrite the summary so it reflects the CURRENT recording.", file=sys.stderr)
    sys.exit(2)

sys.exit(0)
