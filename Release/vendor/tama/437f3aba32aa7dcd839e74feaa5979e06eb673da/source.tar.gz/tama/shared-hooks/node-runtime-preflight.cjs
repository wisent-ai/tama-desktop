'use strict';

const zero = Number(false);
const one = Number(true);
const decimalRadix = 'node-radix'.length;
const minimumNodeMajor = 'minimum-node-version'.length;
const nodeMajor = Number.parseInt(process.versions.node.split('.')[zero], decimalRadix);

if (!Number.isInteger(nodeMajor) || nodeMajor < minimumNodeMajor) {
  console.error(
    `Tama requires Node.js ${minimumNodeMajor} or newer; found ${process.versions.node}`,
  );
  process.exit(one);
}
