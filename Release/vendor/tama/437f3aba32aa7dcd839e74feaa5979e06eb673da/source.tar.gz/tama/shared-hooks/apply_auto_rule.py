#!/usr/bin/env python3
"""Apply an auto-generated rule from detect_frustration.sh to the right
hook file or to the nearest project CLAUDE.md.

HARDENED 2026-05-08: extends supported targets from {check_stop_asking.py,
check_time_estimates.py, CLAUDE.md} to ALSO include the PreToolUse hooks
pre_bash.sh and pre_write_edit.sh. Auto-rules for those are spliced into
a stable `# === AUTO-ADDED RULES BELOW ===` marker block so the splice is
mechanical (no parsing of branching bash).
"""
from __future__ import annotations

import argparse
import datetime as dt
import os
import re
import sys
from pathlib import Path

HOOKS_DIR = Path.home() / ".shared-hooks"
LOG_FILE = Path.home() / ".shared-hooks" / "auto_rules.log"
AUTO_MARKER = "# === AUTO-ADDED RULES BELOW ==="


def log(msg: str) -> None:
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with LOG_FILE.open("a") as f:
        f.write(f"{dt.datetime.now().isoformat(timespec='seconds')} | {msg}\n")


def append_to_python_list(path: Path, list_name: str, pattern: str, summary: str) -> bool:
    if not path.is_file():
        log(f"FAIL_NO_FILE target={path}")
        return False
    src = path.read_text()
    m = re.search(rf"{re.escape(list_name)}\s*=\s*\[", src)
    if not m:
        log(f"FAIL_NO_LIST target={path.name} list={list_name}")
        return False
    depth = 0
    i = m.end() - 1
    while i < len(src):
        if src[i] == "[":
            depth += 1
        elif src[i] == "]":
            depth -= 1
            if depth == 0:
                break
        i += 1
    if depth != 0:
        log(f"FAIL_UNBALANCED target={path.name}")
        return False
    ts = dt.datetime.now().isoformat(timespec="seconds")
    safe = pattern.replace('"""', '\\"\\"\\"')
    new_entry = f"    # auto-added {ts}: {summary}\n    r\"\"\"{safe}\"\"\",\n"
    new_src = src[:i] + new_entry + src[i:]
    path.write_text(new_src)
    log(f"APPLIED target={path.name} list={list_name} summary={summary}")
    return True


def append_to_bash_hook(path: Path, regex: str, message: str, summary: str, scope: str) -> bool:
    """Splice a new BLOCK rule into a bash hook at the AUTO_MARKER comment.
    `scope` is `bash` (use $CMD) or `write` (use $FILE_PATH or $CONTENT).

    The patch shape:
        # auto-added <ts>: <summary>
        if echo "$<scope-var>" | grep -qE '<regex>'; then
            echo 'BLOCKED: <message>' >&2
            exit 2
        fi
    """
    if not path.is_file():
        log(f"FAIL_NO_FILE target={path}")
        return False
    src = path.read_text()
    if AUTO_MARKER not in src:
        log(f"FAIL_NO_MARKER target={path.name}")
        return False
    var = "$CMD" if scope == "bash" else "$FILE_PATH"
    ts = dt.datetime.now().isoformat(timespec="seconds")
    safe_regex = regex.replace("'", r"'\''")
    safe_msg = message.replace("'", r"'\''")
    block = (
        f"\n# auto-added {ts}: {summary}\n"
        f"if echo \"{var}\" | grep -qE '{safe_regex}'; then\n"
        f"    echo 'BLOCKED: {safe_msg}' >&2\n"
        f"    exit 2\n"
        f"fi\n"
    )
    new_src = src.replace(AUTO_MARKER, AUTO_MARKER + block, 1)
    path.write_text(new_src)
    log(f"APPLIED target={path.name} kind=bash_hook scope={scope} summary={summary}")
    return True


def find_project_claude_md(cwd: str) -> Path:
    p = Path(cwd or os.getcwd()).resolve()
    while True:
        candidate = p / "CLAUDE.md"
        if candidate.is_file():
            return candidate
        if p == p.parent:
            return Path(cwd or os.getcwd()).resolve() / "CLAUDE.md"
        p = p.parent


def append_to_claude_md(cwd: str, rule_text: str, summary: str) -> bool:
    target = find_project_claude_md(cwd)
    src = target.read_text() if target.is_file() else ""
    section = "## Auto-added rules"
    ts = dt.datetime.now().isoformat(timespec="seconds")
    bullet = f"- {rule_text}  <!-- auto-added {ts}: {summary} -->\n"
    if section in src:
        idx = src.index(section)
        eol = src.index("\n", idx)
        new_src = src[: eol + 1] + "\n" + bullet + src[eol + 1 :]
    else:
        sep = "" if src.endswith("\n") or not src else "\n"
        new_src = src + sep + ("\n" if src else "") + section + "\n\n" + bullet
    target.write_text(new_src)
    log(f"APPLIED target=CLAUDE.md path={target} summary={summary}")
    return True


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--target", required=True)
    p.add_argument("--regex", default="")
    p.add_argument("--rule-text", default="")
    p.add_argument("--message", default="")
    p.add_argument("--summary", default="")
    p.add_argument("--cwd", default=os.getcwd())
    args = p.parse_args()
    summary = args.summary or "(no summary)"
    if args.target == "check_stop_asking.py":
        if not args.regex:
            log(f"FAIL_NO_REGEX target={args.target}"); return 1
        ok = append_to_python_list(HOOKS_DIR / "check_stop_asking.py", "STOP_PATTERNS", args.regex, summary)
        return 0 if ok else 1
    if args.target == "check_time_estimates.py":
        if not args.regex:
            log(f"FAIL_NO_REGEX target={args.target}"); return 1
        ok = append_to_python_list(HOOKS_DIR / "check_time_estimates.py", "ESTIMATE_PATTERNS", args.regex, summary)
        return 0 if ok else 1
    if args.target == "pre_bash.sh":
        if not args.regex or not args.message:
            log(f"FAIL_NO_REGEX_OR_MSG target={args.target}"); return 1
        ok = append_to_bash_hook(HOOKS_DIR / "pre_bash.sh", args.regex, args.message, summary, scope="bash")
        return 0 if ok else 1
    if args.target == "pre_write_edit.sh":
        if not args.regex or not args.message:
            log(f"FAIL_NO_REGEX_OR_MSG target={args.target}"); return 1
        ok = append_to_bash_hook(HOOKS_DIR / "pre_write_edit.sh", args.regex, args.message, summary, scope="write")
        return 0 if ok else 1
    if args.target == "CLAUDE.md":
        if not args.rule_text:
            log(f"FAIL_NO_RULE_TEXT target={args.target}"); return 1
        ok = append_to_claude_md(args.cwd, args.rule_text, summary)
        return 0 if ok else 1
    log(f"FAIL_UNSUPPORTED_TARGET target={args.target}")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
