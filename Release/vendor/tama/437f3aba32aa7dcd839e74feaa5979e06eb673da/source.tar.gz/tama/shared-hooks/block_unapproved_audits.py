#!/usr/bin/env python3
"""Block explicitly declared audit workflows without device-level approval."""

from __future__ import annotations

import hashlib
import json
import os
import re
import shlex
import sys
from pathlib import Path
from typing import Any, Iterable

APPROVAL_ENV = "DEVICE_LEVEL_AUDITS_APPROVED"
POLICY_PATH = Path(
    os.environ.get("DEVICE_LEVEL_AUDITS_POLICY")
    or (Path.home() / ".config" / "agent-policy" / "device_level_audits.json")
)
POLICY_FIELD = "device_level_audits_approved"
WRITE_TOOLS = {
    "apply_patch",
    "applypatch",
    "edit",
    "multiedit",
    "write",
    "write_file",
    "writefile",
}
POLICY_MUTATION_RE = re.compile(
    r"(?:>|\b(?:tee|touch|cp|mv|install|rsync|dd|write_text|writefile)\b|\bsed\b[^\n]*\s-i\b)",
    re.IGNORECASE,
)
STATE_ROOT = (
    Path(os.environ.get("XDG_STATE_HOME") or (Path.home() / ".local" / "state"))
    / "jeden-hooks"
    / "audit-consent"
)
AUDIT_PROGRAMS = {
    "bundle-audit",
    "cargo-audit",
    "osv-scanner",
    "pip-audit",
}
PACKAGE_AUDIT_PROGRAMS = {"bun", "npm", "pnpm", "yarn"}


def load_payload() -> dict[str, Any]:
    try:
        value = json.loads(sys.stdin.read() or "{}")
    except (json.JSONDecodeError, ValueError):
        return {}
    return value if isinstance(value, dict) else {}


def tool_name(payload: dict[str, Any]) -> str:
    value = payload.get("tool_name") or payload.get("name") or payload.get("tool") or ""
    if isinstance(value, dict):
        value = value.get("name") or ""
    return str(value).strip().lower()


def tool_input(payload: dict[str, Any]) -> dict[str, Any]:
    value = payload.get("tool_input") or payload.get("input")
    if not isinstance(value, dict):
        tool = payload.get("tool")
        value = tool.get("input") if isinstance(tool, dict) else {}
    return value if isinstance(value, dict) else {}

def candidate_paths(value: Any) -> Iterable[str]:
    if not isinstance(value, dict):
        return
    for key in ("file_path", "path", "notebook_path"):
        item = value.get(key)
        if isinstance(item, str):
            yield item
    for key in ("input", "patch"):
        item = value.get(key)
        if not isinstance(item, str):
            continue
        for match in re.finditer(r"^(?:\[([^#\]\n]+)#|\*\*\* (?:Add|Update|Delete) File: (.+))$", item, re.MULTILINE):
            yield next(group for group in match.groups() if group)
    edits = value.get("edits")
    if isinstance(edits, list):
        for edit in edits:
            yield from candidate_paths(edit)


def approval_bypass_reason(payload: dict[str, Any]) -> str | None:
    name = tool_name(payload).split(".")[-1]
    inp = tool_input(payload)
    if name in WRITE_TOOLS:
        for path in candidate_paths(inp):
            if Path(path).name.lower() == POLICY_PATH.name.lower():
                return f"attempted in-session audit policy write: {path}"
        return None
    serialized = json.dumps(inp, ensure_ascii=False)
    if POLICY_PATH.name.lower() in serialized.lower() and POLICY_MUTATION_RE.search(serialized):
        return f"attempted in-session audit policy mutation: {POLICY_PATH.name}"
    return None


def declared_audit_reason(payload: dict[str, Any]) -> str | None:
    inp = tool_input(payload)
    command = str(inp.get("command") or inp.get("cmd") or "")
    return audit_command_reason(command)


def shell_segments(command: str) -> Iterable[list[str]]:
    for segment in re.split(r"(?:&&|\|\||[;\n])", command):
        try:
            tokens = shlex.split(segment)
        except ValueError:
            tokens = segment.split()
        if tokens:
            yield tokens


def audit_command_reason(command: str) -> str | None:
    for tokens in shell_segments(command):
        cursor = 0
        while cursor < len(tokens) and re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*=.*", tokens[cursor]):
            cursor += 1
        if cursor >= len(tokens):
            continue
        program = Path(tokens[cursor]).name.lower()
        args = [token.lower() for token in tokens[cursor + 1 :]]
        if program in AUDIT_PROGRAMS:
            return f"audit program: {program}"
        if program in PACKAGE_AUDIT_PROGRAMS and args and args[0] == "audit":
            return f"audit program: {program} audit"
        if program == "bundle" and args and args[0] == "audit":
            return "audit program: bundle audit"
    return None


def approved() -> bool:
    if os.environ.get(APPROVAL_ENV) == "1":
        return True
    try:
        value = json.loads(POLICY_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError, ValueError):
        return False
    return isinstance(value, dict) and value.get(POLICY_FIELD) is True


def scope_key(payload: dict[str, Any]) -> str:
    session_id = str(payload.get("session_id") or "").strip()
    if session_id:
        material = f"session:{session_id}"
    else:
        runtime = str(payload.get("runtime") or "")
        cwd = str(payload.get("cwd") or payload.get("project_dir") or "")
        material = f"runtime:{runtime}\ncwd:{cwd}"
    return hashlib.sha256(material.encode("utf-8")).hexdigest()


def state_path(payload: dict[str, Any]) -> Path:
    return STATE_ROOT / f"{scope_key(payload)}.json"


def clear_state(payload: dict[str, Any]) -> None:
    try:
        state_path(payload).unlink()
    except FileNotFoundError:
        pass


def read_state(payload: dict[str, Any]) -> dict[str, Any] | None:
    try:
        value = json.loads(state_path(payload).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError, ValueError):
        return None
    return value if isinstance(value, dict) else None


def write_state(payload: dict[str, Any], reason: str) -> None:
    path = state_path(payload)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps({"schemaVersion": 1, "reason": reason}, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    os.replace(temporary, path)


def block(reason: str) -> int:
    print(
        "BLOCKED: audit workflows require explicit user-controlled device approval. "
        f"Set {APPROVAL_ENV}=1 outside the agent session or enable {POLICY_FIELD} in {POLICY_PATH}. "
        f"Detected: {reason}",
        file=sys.stderr,
    )
    return 2


def main() -> int:
    payload = load_payload()
    event = str(
        payload.get("agent_hook_event")
        or payload.get("hook_event_name")
        or payload.get("hook_event")
        or payload.get("event")
        or ""
    )
    if re.sub(r"[^a-z]", "", event.lower()) == "userpromptsubmit":
        clear_state(payload)
        return 0
    bypass_reason = approval_bypass_reason(payload)
    if bypass_reason is not None:
        return block(bypass_reason)
    if approved():
        clear_state(payload)
        return 0

    reason = declared_audit_reason(payload)
    if reason is not None:
        write_state(payload, reason)
        return block(reason)

    state = read_state(payload)
    if state is not None and declared_audit_reason(payload) is not None:
        previous_reason = str(state.get("reason") or "an audit was declared earlier in this session")
        return block(
            f"{previous_reason}; audit gate remains active until the next user prompt or approval. "
            f"Clear it by deleting {state_path(payload)}"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
