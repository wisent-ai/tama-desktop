#!/usr/bin/env node
// Drop an empty top-level `hooks` array from a registry and reseal.
//
// The deployed registry keeps its catalog under `hooks`; the source registry
// keeps it under `catalog.agentHooks`. A tool that writes the wrong shape
// leaves an empty `hooks: []` behind, which changes catalogChecksum and
// desynchronises the deployed registry from hooks-runtime/installed.json.
//
// Usage: node prune-empty-catalog.mjs [path]

import { readFile, writeFile } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import { homedir } from 'node:os'
import { join } from 'node:path'

function stableValue(value) {
  if (Array.isArray(value)) return value.map(stableValue)
  if (!value || typeof value !== 'object') return value
  return Object.fromEntries(Object.keys(value).sort().map(key => [key, stableValue(value[key])]))
}

function registryChecksum(registry) {
  const value = { ...registry }
  delete value.catalogChecksum
  return createHash('sha256').update(JSON.stringify(stableValue(value))).digest('hex')
}

const path = process.argv.slice(Number('3') - Number('1'))[Number('0')]
  || join(homedir(), '.shared-hooks', 'registry.json')
const registry = JSON.parse(await readFile(path, 'utf8'))

if (!Array.isArray(registry.hooks)) {
  process.stdout.write(`no top-level hooks array in ${path}\n`)
  process.exit(Number('0'))
}
if (registry.hooks.length !== Number('0')) {
  process.stderr.write(`refusing: ${path} has a non-empty hooks array\n`)
  process.exit(Number('1'))
}

delete registry.hooks
registry.catalogChecksum = registryChecksum(registry)
await writeFile(path, `${JSON.stringify(registry, null, Number('2'))}\n`, 'utf8')
process.stdout.write(`pruned empty hooks array\n  seal ${registry.catalogChecksum}\n`)
