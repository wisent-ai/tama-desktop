#!/usr/bin/env python3
"""Block unsubstantiated hardcoded constants in local edits and remote Bash commands.

This hook is intentionally strict: any new numeric literal that looks like a
config/estimate/tuning constant must either live in an allowed config/constants
file or carry a justification in ~/.shared-hooks/file_justifications.json.
"""
from __future__ import annotations

import json
import os
import re
import sys
from pathlib import Path

JUSTIFICATION_REGISTRY = Path.home() / ".shared-hooks" / "file_justifications.json"
MIN_JUSTIFICATION_WORDS = 15

# Files where numeric constants are expected and allowed.
ALLOWED_PATH_PATTERNS = [
    r"[Cc]onstants?\.",
    r"[Cc]onstants?/",
    r"_catalog/",
    r"config\.py$",
    r"config\.toml$",
    r"settings\.py$",
    r"setup\.py$",
    r"setup\.cfg$",
    r"pyproject\.toml$",
    r"\.shared-hooks/file_justifications\.json$",
    r"\.shared-hooks/check_unsubstantiated_constants\.py$",
]

# Patterns that introduce hardcoded numeric constants.
# Each tuple: (regex, description).
CONSTANT_PATTERNS = [
    # Python: UPPER_SNAKE = 123 or UPPER_SNAKE: int = 123
    (r"^\s*[A-Z_][A-Z0-9_]*\s*[:=]\s*-?\d+(\.\d+)?\b", "UPPER_SNAKE constant assignment"),
    # Python: os.environ.get("...", "123") or os.getenv("...", 123)
    (r"os\.(environ\.get|getenv)\s*\(\s*['\"][^'\"]+['\"]\s*,\s*['\"]?-?\d+(\.\d+)?['\"]?\s*\)", "numeric env default"),
    # Python: def foo(..., bar=123):
    (r"\bdef\s+\w+\s*\([^)]*\b\w+\s*=\s*-?\d+(\.\d+)?\b", "numeric function default"),
    # Python: return 24  (only in helper/estimate functions); skip 0/1 status codes
    (r"^\s*return\s+-?(?!0\b|1\b)\d+(\.\d+)?\b", "bare numeric return"),
    # Systemd drop-in: Environment=FOO=123 or Environment=FOO_GB=16
    (r"^\s*Environment\s*=\s*[A-Z_][A-Z0-9_]*\s*=\s*-?\d+(\.\d+)?\b", "systemd numeric env var"),
    # Shell: export FOO=123 or FOO_GB=16
    (r"\bexport\s+[A-Z_][A-Z0-9_]*\s*=\s*-?\d+(\.\d+)?\b", "shell numeric env export"),
    # JSON/TOML: "foo": 123
    (r'["\']?[a-z_][a-z0-9_]*["\']?\s*:\s*-?\d+(\.\d+)?\b', "numeric key-value config"),
]


def _is_allowed_path(file_path: str) -> bool:
    for pat in ALLOWED_PATH_PATTERNS:
        if re.search(pat, file_path):
            return True
    return False


def _has_justification(file_path: str) -> bool:
    if not JUSTIFICATION_REGISTRY.exists():
        return False
    try:
        registry = json.loads(JUSTIFICATION_REGISTRY.read_text())
    except Exception:
        return False
    entry = registry.get(file_path, {})
    justification = entry.get("justification", "")
    # A generic justification that mentions constants is required.
    if len(justification.split()) < MIN_JUSTIFICATION_WORDS:
        return False
    lowered = justification.lower()
    if "constant" not in lowered and "config" not in lowered and "tuning" not in lowered and "parameter" not in lowered:
        return False
    return True


def _check_file_content(file_path: str, content: str) -> list[str]:
    if _is_allowed_path(file_path):
        return []
    if _has_justification(file_path):
        return []

    violations: list[str] = []
    for line_no, line in enumerate(content.splitlines(), start=1):
        for regex, desc in CONSTANT_PATTERNS:
            if re.search(regex, line):
                # Allow obvious non-constants like version strings, years, permissions.
                stripped = line.strip()
                if re.search(r"version\s*[:=]\s*['\"]?\d", stripped, re.IGNORECASE):
                    continue
                if re.search(r"\b20\d\d\b", stripped):
                    continue
                if re.search(r"\b0o\d+|0x[0-9a-fA-F]+", stripped):
                    continue
                violations.append(f"line {line_no}: {desc}: {stripped[:80]}")
                break  # one violation per line is enough
    return violations


def _check_bash_command(cmd: str) -> list[str]:
    """Detect remote edits that inject constants without going through local hooks."""
    violations: list[str] = []

    # Remote write to installed package or systemd config.
    remote_write = re.search(
        r"\bssh\b.*?(>>?|\bcp\s|\bmv\s|\btee\s|\bsed\s+-[a-zA-Z]*i|\binstall\s|\bpython3\s+-.*\bopen\(|\bcat\s*>).*?(\.(py|conf|service|socket|timer)|/site-packages/|/systemd/system/)",
        cmd,
        re.IGNORECASE,
    )
    # scp to a protected remote directory is a write by definition.
    scp_write = re.search(
        r"\bscp\b.*?:~?(/etc/systemd/system|/site-packages|/usr/lib/systemd|/opt)\S*",
        cmd,
        re.IGNORECASE,
    )
    rsync_write = re.search(
        r"\brsync\b.*?:~?(/etc/systemd/system|/site-packages|/usr/lib/systemd|/opt|/home/[^/\s]+/\.local/lib/[^/\s]+/site-packages)\S*",
        cmd,
        re.IGNORECASE,
    )
    if remote_write or scp_write or rsync_write:
        # Allow if the command carries an explicit justification marker.
        if not re.search(r"#\s*justify:\s*\S", cmd):
            violations.append(
                "remote write to installed package/systemd config without '# justify: ...' marker"
            )

    # Remote heredoc/echo/sed that sets numeric env vars or constants.
    if re.search(
        r"\bssh\b.*?(Environment\s*=\s*[A-Z_][A-Z0-9_]*\s*=\s*\d+|export\s+[A-Z_][A-Z0-9_]*\s*=\s*\d+)",
        cmd,
        re.IGNORECASE,
    ):
        if not re.search(r"#\s*justify:\s*\S", cmd):
            violations.append(
                "remote injection of numeric env constant without '# justify: ...' marker"
            )

    return violations


def main() -> int:
    args = sys.argv[1:]
    is_bash = "--bash" in args

    data = sys.stdin.read()

    if is_bash:
        violations = _check_bash_command(data)
        if violations:
            print("BLOCKED: unsubstantiated constant injection detected:", file=sys.stderr)
            for v in violations:
                print(f"  - {v}", file=sys.stderr)
            print(
                "Add a justification marker '# justify: <reason>' to the command, "
                "or move the constant to a tracked config/constants file.",
                file=sys.stderr,
            )
            return 2
        return 0

    # Write/Edit path: payload is file_path\0content.
    if "\0" in data:
        file_path, _, content = data.partition("\0")
    else:
        # Fallback: first line is path, rest is content.
        parts = data.split("\n", 1)
        file_path = parts[0]
        content = parts[1] if len(parts) > 1 else ""

    violations = _check_file_content(file_path, content)
    if violations:
        print(
            f"BLOCKED: unsubstantiated hardcoded constants in {file_path}:",
            file=sys.stderr,
        )
        for v in violations:
            print(f"  - {v}", file=sys.stderr)
        print(
            "Move constants to a config/constants module, or add a "
            f"{MIN_JUSTIFICATION_WORDS}+ word justification mentioning 'constants/config/tuning' "
            f"to {JUSTIFICATION_REGISTRY}.",
            file=sys.stderr,
        )
        return 2

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
