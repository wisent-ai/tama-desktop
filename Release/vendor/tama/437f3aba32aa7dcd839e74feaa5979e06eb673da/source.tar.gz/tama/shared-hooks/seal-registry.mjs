#!/usr/bin/env node
// Recompute the registry seal after a catalog change.
//
// `catalogChecksum` is the sha256 of the registry object with that field
// removed and every object key sorted, which is exactly what
// generate-configs.mjs verifies before it will emit any config. Editing the
// registry without resealing closes every tool in the session, so this script
// exists to make the reseal a single reviewable step instead of a hand edit.
//
// Usage: node seal-registry.mjs [--check] [path]

import { readFile, writeFile } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import { homedir } from 'node:os'
import { join } from 'node:path'

function stableValue(value) {
  if (Array.isArray(value)) return value.map(stableValue)
  if (!value || typeof value !== 'object') return value
  return Object.fromEntries(Object.keys(value).sort().map(key => [key, stableValue(value[key])]))
}

function registryChecksum(registry) {
  const value = { ...registry }
  delete value.catalogChecksum
  return createHash('sha256').update(JSON.stringify(stableValue(value))).digest('hex')
}

const args = process.argv.slice(Number('2'))
const checkOnly = args.includes('--check')
const path = args.find(arg => !arg.startsWith('--')) || join(homedir(), '.shared-hooks', 'registry.json')

const registry = JSON.parse(await readFile(path, 'utf8'))
const field = String(registry.catalogChecksum || '')
const actual = registryChecksum(registry)

if (field === actual) {
  process.stdout.write(`sealed ${path} ${actual}\n`)
  process.exit(Number('0'))
}

if (checkOnly) {
  process.stderr.write(`unsealed ${path}\n  field    ${field || 'missing'}\n  computed ${actual}\n`)
  process.exit(Number('1'))
}

registry.catalogChecksum = actual
await writeFile(path, `${JSON.stringify(registry, null, Number('2'))}\n`, 'utf8')
process.stdout.write(`resealed ${path}\n  was ${field || 'missing'}\n  now ${actual}\n`)
