#!/usr/bin/env python3
from __future__ import annotations

import codecs
import ctypes
import hashlib
import json
import os
import plistlib
import re
import select
import signal
import shutil
import struct
import subprocess
import sys
import threading
import time
from collections import deque
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

if os.name == "posix":
    import fcntl
    import pty
    import termios
    import tty


OBSERVATION_SCHEMA = "ai.wisent.tama.observation.v1"
SEMANTIC_EVENT_SCHEMA = "ai.wisent.tama.semantic-event.v1"
ANSI_ESCAPE = re.compile(r"\x1b(?:\[[0-?]*[ -/]*[@-~]|\][^\x07]*(?:\x07|\x1b\\))")
CONTROL_CHARACTER = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def compact_text(value: str) -> str:
    return CONTROL_CHARACTER.sub("", ANSI_ESCAPE.sub("", value)).strip()


def normalized_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True)


class HookDispatcher:
    def __init__(
        self,
        *,
        runner: Path,
        agent_id: str,
        session_id: str,
        cwd: Path,
        owner_pid: Callable[[], int | None],
        resume_argv: list[str],
        runtime_context: Callable[[], dict[str, Any]] | None = None,
    ) -> None:
        self.runner = runner
        self.agent_id = agent_id
        self.session_id = session_id
        self.cwd = cwd
        self.owner_pid = owner_pid
        self.resume_argv = resume_argv
        self.runtime_context = runtime_context or (lambda: {})
        self.sequence = 0
        self.lock = threading.RLock()
        self.history: deque[dict[str, Any]] = deque(maxlen=64)
        self.last_decision: dict[str, Any] | None = None

    def dispatch(self, event: str, payload: dict[str, Any]) -> dict[str, Any]:
        with self.lock:
            self.sequence += 1
            envelope = {
                "schema": SEMANTIC_EVENT_SCHEMA,
                "event_id": f"{self.session_id}:{self.sequence}",
                "event": event,
                "session_id": self.session_id,
                "agent_id": self.agent_id,
                "cwd": str(self.cwd),
                "timestamp": utc_now(),
                "semantic_runtime": {
                    "observationSchema": OBSERVATION_SCHEMA,
                    "semanticEventSchema": SEMANTIC_EVENT_SCHEMA,
                    "eventSequence": self.sequence,
                    "recentEvents": list(self.history),
                },
                **self.runtime_context(),
                **payload,
            }
            environment = dict(os.environ)
            environment["TAMA_SESSION_ID"] = self.session_id
            environment["TAMA_AGENT_ID"] = self.agent_id
            environment["TAMA_SESSION_RESUME_ARGV_JSON"] = normalized_json(self.resume_argv)
            pid = self.owner_pid()
            if pid is not None:
                environment["TAMA_SESSION_OWNER_PID"] = str(pid)
            node_executable = os.environ.get("TAMA_NODE_EXECUTABLE") or "node"
            node_preflight = os.environ.get("TAMA_NODE_PREFLIGHT")
            node_command = [node_executable]
            if node_preflight:
                node_command.extend(("--require", node_preflight))
            node_command.extend((str(self.runner), event, self.agent_id))
            try:
                completed = subprocess.run(
                    node_command,
                    input=normalized_json(envelope).encode(),
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    cwd=self.cwd,
                    env=environment,
                    timeout=float(os.environ.get("TAMA_HOOK_DISPATCH_TIMEOUT_SECONDS", "120")),
                    check=False,
                )
                raw = completed.stdout.decode(errors="replace").strip()
                decision = json.loads(raw) if raw else {"decision": "pass"}
                if not isinstance(decision, dict):
                    decision = {"decision": "block", "reason": "invalid hook decision"}
                if completed.returncode not in (0, 2) and decision.get("decision") != "block":
                    reason = completed.stderr.decode(errors="replace").strip()
                    decision = {
                        "decision": "block",
                        "reason": reason or f"hook runner exited with {completed.returncode}",
                    }
            except (OSError, subprocess.TimeoutExpired, json.JSONDecodeError) as error:
                decision = {"decision": "block", "reason": str(error)}
            summary = {
                "eventId": envelope["event_id"],
                "event": event,
                "timestamp": envelope["timestamp"],
                "decision": decision.get("decision", "block"),
                "blockedHookId": decision.get("blockedHookId"),
                "reason": decision.get("reason"),
            }
            self.history.append(summary)
            self.last_decision = summary
            return decision

    def state(self) -> dict[str, Any]:
        with self.lock:
            return {
                "observationSchema": OBSERVATION_SCHEMA,
                "semanticEventSchema": SEMANTIC_EVENT_SCHEMA,
                "eventSequence": self.sequence,
                "lastDecision": self.last_decision,
                "recentEvents": list(self.history),
            }


class SemanticClassifier:
    def __init__(
        self,
        *,
        dispatch: Callable[[str, dict[str, Any]], dict[str, Any]],
        on_block: Callable[[str, dict[str, Any]], None],
    ) -> None:
        self.dispatch = dispatch
        self.on_block = on_block
        self.input_decoder = codecs.getincrementaldecoder("utf-8")(errors="replace")
        self.output_decoder = codecs.getincrementaldecoder("utf-8")(errors="replace")
        self.input_buffer = ""
        self.output_buffer = ""
        self.seen_calls: deque[str] = deque(maxlen=512)
        self.seen_call_set: set[str] = set()
        self.seen_results: deque[str] = deque(maxlen=512)
        self.seen_result_set: set[str] = set()
        self.pending_calls: dict[str, dict[str, Any]] = {}
        self.turn_output = ""
        self.turn_active = False
        self.stop_emitted = True
        self.last_output_at = time.monotonic()
        self.idle_seconds = float(os.environ.get("TAMA_SEMANTIC_IDLE_SECONDS", "1.25"))

    def observe_input(self, data: bytes) -> None:
        self.input_buffer += self.input_decoder.decode(data)
        while True:
            boundary = min(
                (index for index in (self.input_buffer.find("\n"), self.input_buffer.find("\r")) if index >= 0),
                default=-1,
            )
            if boundary < 0:
                break
            line = compact_text(self.input_buffer[:boundary])
            self.input_buffer = self.input_buffer[boundary + 1 :]
            if line:
                self.turn_output = ""
                self.turn_active = True
                self.stop_emitted = False
                self.dispatch(
                    "user_prompt_submit",
                    {
                        "prompt": line,
                        "observation": {"source": "terminal_input", "kind": "line"},
                    },
                )

    def observe_output(self, data: bytes) -> None:
        decoded = self.output_decoder.decode(data)
        self.last_output_at = time.monotonic()
        if self.turn_active:
            self.turn_output = (self.turn_output + decoded)[-262144:]
        self.output_buffer += decoded
        while "\n" in self.output_buffer:
            line, self.output_buffer = self.output_buffer.split("\n", 1)
            self._observe_output_line(compact_text(line))

    def flush_output(self) -> None:
        line = compact_text(self.output_buffer + self.output_decoder.decode(b"", final=True))
        self.output_buffer = ""
        if line:
            self._observe_output_line(line)

    def poll_idle(self) -> None:
        if (
            not self.turn_active
            or self.stop_emitted
            or time.monotonic() - self.last_output_at < self.idle_seconds
        ):
            return
        self.stop_emitted = True
        decision = self.dispatch(
            "stop",
            {
                "last_assistant_message": compact_text(self.turn_output),
                "observation": {"source": "terminal_output", "kind": "idle_turn_boundary"},
            },
        )
        if decision.get("decision") == "block":
            self.stop_emitted = False
            self.last_output_at = time.monotonic()
            self.on_block("stop", decision)

    def _observe_output_line(self, line: str) -> None:
        if not line or line[0] not in "[{":
            return
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            return
        for result in self._tool_results(value):
            fingerprint = hashlib.sha256(normalized_json(result).encode()).hexdigest()
            if not self._remember(fingerprint, self.seen_results, self.seen_result_set):
                continue
            call_id = str(result.get("id") or "")
            call = self.pending_calls.pop(call_id, {}) if call_id else {}
            tool_name = str(result.get("name") or call.get("name") or "tool")
            tool_input = call.get("input") or {}
            self.dispatch(
                f"post_tool_use:{self._tool_category(tool_name, tool_input)}",
                {
                    "tool_name": tool_name,
                    "tool_input": tool_input,
                    "tool_response": result.get("output"),
                    "tool_call_id": result.get("id"),
                    "observation": {"source": "terminal_output", "kind": "structured_tool_result"},
                },
            )
        for call in self._tool_calls(value):
            fingerprint = hashlib.sha256(normalized_json(call).encode()).hexdigest()
            if not self._remember(fingerprint, self.seen_calls, self.seen_call_set):
                continue
            tool_name = str(call.get("name") or "tool")
            tool_input = call.get("input")
            if call.get("id"):
                self.pending_calls[str(call["id"])] = call
            event = f"pre_tool_use:{self._tool_category(tool_name, tool_input)}"
            decision = self.dispatch(
                event,
                {
                    "tool_name": tool_name,
                    "tool_input": tool_input,
                    "tool_call_id": call.get("id"),
                    "observation": {"source": "terminal_output", "kind": "structured_tool_call"},
                },
            )
            if decision.get("decision") == "block":
                self.on_block(event, decision)

    @staticmethod
    def _remember(fingerprint: str, order: deque[str], members: set[str]) -> bool:
        if fingerprint in members:
            return False
        if len(order) == order.maxlen:
            members.discard(order.popleft())
        order.append(fingerprint)
        members.add(fingerprint)
        return True

    def _tool_results(self, value: Any) -> list[dict[str, Any]]:
        results: list[dict[str, Any]] = []

        def visit(node: Any) -> None:
            if isinstance(node, list):
                for item in node:
                    visit(item)
                return
            if not isinstance(node, dict):
                return
            node_type = str(node.get("type") or "").lower()
            role = str(node.get("role") or "").lower()
            result_marker = (
                "tool_result" in node_type
                or "function_result" in node_type
                or role == "tool"
                or "tool_call_id" in node
            )
            if result_marker:
                output = next(
                    (node[key] for key in ("output", "result", "content", "response") if key in node),
                    None,
                )
                if output is not None:
                    results.append(
                        {
                            "id": node.get("tool_call_id") or node.get("call_id") or node.get("id"),
                            "name": node.get("tool") or node.get("tool_name") or node.get("name"),
                            "output": output,
                        }
                    )
            for child in node.values():
                if isinstance(child, (dict, list)):
                    visit(child)

        visit(value)
        return results

    def _tool_calls(self, value: Any) -> list[dict[str, Any]]:
        calls: list[dict[str, Any]] = []

        def visit(node: Any) -> None:
            if isinstance(node, list):
                for item in node:
                    visit(item)
                return
            if not isinstance(node, dict):
                return
            function = node.get("function")
            if isinstance(function, dict) and isinstance(function.get("name"), str):
                calls.append(
                    {
                        "id": node.get("id") or node.get("tool_call_id"),
                        "name": function["name"],
                        "input": function.get("arguments") or function.get("input") or {},
                    }
                )
            node_type = str(node.get("type") or "").lower()
            name = node.get("tool") or node.get("tool_name") or node.get("name")
            arguments = node.get("input") or node.get("arguments") or node.get("parameters")
            if (
                isinstance(name, str)
                and arguments is not None
                and ("tool" in node_type or "function" in node_type or "tool" in node)
            ):
                calls.append(
                    {
                        "id": node.get("id") or node.get("tool_call_id"),
                        "name": name,
                        "input": arguments,
                    }
                )
            for child in node.values():
                if isinstance(child, (dict, list)):
                    visit(child)

        visit(value)
        return calls

    @staticmethod
    def _tool_category(name: str, arguments: Any) -> str:
        fields = set(arguments) if isinstance(arguments, dict) else set()
        normalized_name = re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")
        if normalized_name == "ask" or normalized_name.endswith("_ask") or "questions" in fields:
            return "ask"
        if fields & {"command", "cmd", "argv", "shell"}:
            return "bash"
        if fields & {"patch", "content", "new_text", "replacement", "changes"}:
            return "edit"
        if fields & {"code", "expression"}:
            return "eval"
        if fields & {"path", "file", "filename"}:
            return "read"
        if fields & {"task", "prompt", "description"}:
            return "task"
        if fields & {"query", "pattern", "url"}:
            return "lookup"
        return normalized_name or "tool"


SYSTEM_POLICY_SCHEMA = "ai.wisent.tama.system-policy.v1"
REQUIRED_SYSTEM_POLICY_CAPABILITIES = {
    "process_spawn",
    "file_read",
    "file_write",
    "network_connect",
}
SYSTEM_POLICY_SUPPORT_PR_URL = "https://github.com/wisent-ai/tama-desktop/compare"
MACOS_ENDPOINT_SECURITY_ENTITLEMENT = "com.apple.developer.endpoint-security.client"


class SystemPolicyBackend:
    def __init__(
        self,
        *,
        command: list[str],
        session_id: str,
        agent_id: str,
        cwd: Path,
        dispatch: Callable[[str, dict[str, Any]], dict[str, Any]],
        on_failure: Callable[[str], None],
    ) -> None:
        self.command = command
        self.session_id = session_id
        self.agent_id = agent_id
        self.cwd = cwd
        self.dispatch = dispatch
        self.on_failure = on_failure
        self.process: subprocess.Popen[str] | None = None
        self.reader: threading.Thread | None = None
        self.ready = threading.Event()
        self.write_lock = threading.Lock()
        self.stopping = threading.Event()
        self.failure_reported = False
        self.error: str | None = None
        self.backend_name: str | None = None
        self.capabilities: list[str] = []

    @staticmethod
    def platform_configuration() -> tuple[str, str, Path]:
        home = Path.home()
        if sys.platform == "darwin":
            return (
                "macOS",
                "tama-system-policy-macos",
                home / "Library" / "Application Support" / "Tama" / "system-policy",
            )
        if sys.platform.startswith("linux"):
            return (
                "Linux",
                "tama-system-policy-linux",
                Path(os.environ.get("XDG_DATA_HOME", home / ".local" / "share"))
                / "tama"
                / "system-policy",
            )
        if os.name == "nt":
            return (
                "Windows",
                "tama-system-policy-windows.exe",
                Path(os.environ.get("LOCALAPPDATA", home / "AppData" / "Local"))
                / "Tama"
                / "system-policy",
            )
        raise RuntimeError(
            f"Tama does not support operating system {sys.platform!r} and refuses "
            "to start without kernel enforcement. Add real system-policy support "
            f"and submit a pull request at {SYSTEM_POLICY_SUPPORT_PR_URL}"
        )

    @classmethod
    def installed_command(cls) -> list[str] | None:
        _, executable_name, user_root = cls.platform_configuration()
        candidates = (
            Path(__file__).with_name("system-policy") / executable_name,
            user_root / executable_name,
        )
        for candidate in candidates:
            if candidate.is_file() and (
                os.name == "nt" or os.access(candidate, os.X_OK)
            ):
                return [str(candidate)]
        return None

    @staticmethod
    def validated_command(command: list[str]) -> list[str]:
        executable = Path(command[0]).expanduser()
        resolved = (
            str(executable.resolve())
            if executable.is_absolute() and executable.is_file()
            else shutil.which(command[0])
        )
        if resolved is None or (
            os.name != "nt" and not os.access(resolved, os.X_OK)
        ):
            raise RuntimeError(
                f"Tama system policy backend is not executable: {command[0]}"
            )
        validated = [resolved, *command[1:]]
        if sys.platform == "darwin":
            SystemPolicyBackend.validate_macos_signature(Path(resolved))
        return validated

    @staticmethod
    def validate_macos_signature(executable: Path) -> None:
        verification = subprocess.run(
            ["/usr/bin/codesign", "--verify", "--strict", str(executable)],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
        )
        if verification.returncode != 0:
            detail = verification.stderr.decode(errors="replace").strip()
            raise RuntimeError(
                "Tama requires a validly signed macOS Endpoint Security backend: "
                + (detail or str(executable))
            )
        signature = subprocess.run(
            ["/usr/bin/codesign", "--display", "--verbose=4", str(executable)],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
            text=True,
        )
        signature_details = signature.stdout + signature.stderr
        team = re.search(r"^TeamIdentifier=(.+)$", signature_details, re.MULTILINE)
        if signature.returncode != 0 or team is None or team.group(1) == "not set":
            raise RuntimeError(
                "Tama refuses an ad-hoc macOS backend; an Apple team signature is required"
            )
        entitlement_result = subprocess.run(
            ["/usr/bin/codesign", "--display", "--entitlements", ":-", str(executable)],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
        )
        entitlement_bytes = entitlement_result.stdout + entitlement_result.stderr
        start = entitlement_bytes.find(b"<?xml")
        if start < 0:
            start = entitlement_bytes.find(b"<plist")
        end = entitlement_bytes.rfind(b"</plist>")
        if entitlement_result.returncode != 0 or start < 0 or end < start:
            raise RuntimeError(
                "Tama macOS backend has no readable Endpoint Security entitlement"
            )
        try:
            entitlements = plistlib.loads(
                entitlement_bytes[start : end + len(b"</plist>")]
            )
        except plistlib.InvalidFileException as error:
            raise RuntimeError(
                "Tama macOS backend has invalid signed entitlements"
            ) from error
        if entitlements.get(MACOS_ENDPOINT_SECURITY_ENTITLEMENT) is not True:
            raise RuntimeError(
                "Tama macOS backend is missing the signed "
                f"{MACOS_ENDPOINT_SECURITY_ENTITLEMENT} entitlement"
            )

    @classmethod
    def from_environment(
        cls,
        *,
        session_id: str,
        agent_id: str,
        cwd: Path,
        dispatch: Callable[[str, dict[str, Any]], dict[str, Any]],
        on_failure: Callable[[str], None],
    ) -> "SystemPolicyBackend":
        raw = os.environ.get("TAMA_SYSTEM_POLICY_BACKEND_JSON")
        command: list[str] | None = None
        if raw:
            decoded = json.loads(raw)
            if (
                not isinstance(decoded, list)
                or not decoded
                or not all(isinstance(item, str) and item for item in decoded)
            ):
                raise RuntimeError(
                    "TAMA_SYSTEM_POLICY_BACKEND_JSON must be a non-empty JSON string array"
                )
            command = list(decoded)
        platform_name, executable_name, _ = cls.platform_configuration()
        if command is None:
            command = cls.installed_command()
        if command is None:
            raise RuntimeError(
                f"Tama requires {executable_name} on {platform_name} and refuses "
                "to start an agent without kernel enforcement"
            )
        command = cls.validated_command(command)
        return cls(
            command=command,
            session_id=session_id,
            agent_id=agent_id,
            cwd=cwd,
            dispatch=dispatch,
            on_failure=on_failure,
        )

    @property
    def configured(self) -> bool:
        return True

    def start(self, *, root_pid: int, root_command: list[str]) -> None:
        self.ready.clear()
        self.error = None
        self.backend_name = None
        self.capabilities = []
        self.stopping.clear()
        self.failure_reported = False
        environment = dict(os.environ)
        environment["TAMA_SESSION_ID"] = self.session_id
        environment["TAMA_AGENT_ID"] = self.agent_id
        self.process = subprocess.Popen(
            self.command,
            cwd=self.cwd,
            env=environment,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
        )
        self.reader = threading.Thread(
            target=self._read_messages,
            name="tama-system-policy",
            daemon=True,
        )
        self.reader.start()
        self._send(
            {
                "schema": SYSTEM_POLICY_SCHEMA,
                "type": "attach",
                "sessionId": self.session_id,
                "agentId": self.agent_id,
                "rootPid": root_pid,
                "rootCommand": root_command,
                "cwd": str(self.cwd),
            }
        )
        timeout = float(os.environ.get("TAMA_SYSTEM_POLICY_READY_TIMEOUT_SECONDS", "30"))
        if not self.ready.wait(timeout):
            self.stop()
            raise RuntimeError(
                self.error or "Tama system policy backend did not become ready"
            )
        if self.error:
            self.stop()
            raise RuntimeError(self.error)
        missing = REQUIRED_SYSTEM_POLICY_CAPABILITIES.difference(self.capabilities)
        if missing:
            self.stop()
            raise RuntimeError(
                "System policy backend is missing required capabilities: "
                + ", ".join(sorted(missing))
            )

    def stop(self) -> None:
        self.stopping.set()
        process = self.process
        self.process = None
        if process is None:
            return
        if process.poll() is None:
            try:
                self._send(
                    {
                        "schema": SYSTEM_POLICY_SCHEMA,
                        "type": "detach",
                        "sessionId": self.session_id,
                    },
                    process=process,
                )
            except OSError:
                pass
            process.terminate()
        try:
            process.wait(timeout=2)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()

    def state(self) -> dict[str, Any]:
        return {
            "schema": SYSTEM_POLICY_SCHEMA,
            "configured": self.configured,
            "required": True,
            "ready": self.ready.is_set() and self.error is None,
            "backend": self.backend_name,
            "capabilities": list(self.capabilities),
            "error": self.error,
            "mode": "kernel-gated",
            "supportPullRequestURL": SYSTEM_POLICY_SUPPORT_PR_URL,
        }

    def _read_messages(self) -> None:
        process = self.process
        if process is None or process.stdout is None:
            return
        try:
            for line in process.stdout:
                try:
                    message = json.loads(line)
                except json.JSONDecodeError as error:
                    self._fail(f"Invalid system policy message: {error}")
                    return
                if not isinstance(message, dict):
                    self._fail("System policy message must be a JSON object")
                    return
                self._handle_message(message)
        except Exception as error:
            self._fail(f"System policy backend protocol failed: {error}")
        finally:
            if not self.stopping.is_set() and self.error is None:
                stderr = ""
                if process.poll() is not None and process.stderr is not None:
                    stderr = process.stderr.read().strip()
                self._fail(stderr or "System policy backend exited unexpectedly")

    def _fail(self, reason: str) -> None:
        self.error = reason
        self.ready.set()
        if not self.stopping.is_set() and not self.failure_reported:
            self.failure_reported = True
            self.on_failure(reason)

    def _handle_message(self, message: dict[str, Any]) -> None:
        if (
            message.get("schema") != SYSTEM_POLICY_SCHEMA
            or message.get("sessionId") != self.session_id
        ):
            self._fail("System policy backend sent an invalid session envelope")
            return
        message_type = message.get("type")
        if message_type == "ready":
            capabilities = message.get("capabilities")
            if not isinstance(capabilities, list) or not all(
                isinstance(item, str) and item for item in capabilities
            ):
                self._fail("System policy backend omitted its capabilities")
            else:
                self.backend_name = str(message.get("backend") or "system-policy")
                self.capabilities = sorted(set(capabilities))
            self.ready.set()
            return
        if message_type == "pre_operation":
            self._handle_pre_operation(message)
            return
        if message_type == "post_operation":
            self._handle_post_operation(message)
            return
        if message_type == "error":
            self._fail(str(message.get("error") or "system policy backend failed"))
            return
        self._fail(f"Unsupported system policy message type: {message_type}")

    def _handle_pre_operation(self, message: dict[str, Any]) -> None:
        request_id = message.get("requestId")
        operation = str(message.get("operation") or "")
        if not isinstance(request_id, str) or not request_id or not operation:
            self._fail("System policy backend sent an invalid pre-operation request")
            return
        category = self._event_category(operation)
        decision = self.dispatch(
            f"pre_tool_use:{category}",
            {
                "tool_name": category,
                "tool_input": {
                    "operation": operation,
                    "target": message.get("target"),
                    "arguments": message.get("arguments") or {},
                    "pid": message.get("pid"),
                },
                "observation": {
                    "source": "system",
                    "kind": "pre_operation",
                    "backend": self.backend_name,
                },
            },
        )
        self._send(
            {
                "schema": SYSTEM_POLICY_SCHEMA,
                "type": "decision",
                "sessionId": self.session_id,
                "requestId": request_id,
                "decision": decision.get("decision", "block"),
                "reason": decision.get("reason"),
            }
        )

    def _handle_post_operation(self, message: dict[str, Any]) -> None:
        operation = str(message.get("operation") or "")
        if not operation:
            return
        category = self._event_category(operation)
        self.dispatch(
            f"post_tool_use:{category}",
            {
                "tool_name": category,
                "tool_input": {
                    "operation": operation,
                    "target": message.get("target"),
                    "arguments": message.get("arguments") or {},
                    "pid": message.get("pid"),
                },
                "tool_response": message.get("result"),
                "observation": {
                    "source": "system",
                    "kind": "post_operation",
                    "backend": self.backend_name,
                },
            },
        )

    @staticmethod
    def _event_category(operation: str) -> str:
        normalized = operation.lower().replace("-", "_")
        if normalized in {"exec", "process_spawn"}:
            return "bash"
        if normalized in {"file_read", "directory_read"}:
            return "read"
        if normalized in {
            "file_write",
            "file_create",
            "file_delete",
            "file_rename",
            "directory_write",
        }:
            return "edit"
        if normalized in {"network_connect", "network_listen", "dns_query"}:
            return "network"
        return normalized or "system"

    def _send(
        self,
        message: dict[str, Any],
        *,
        process: subprocess.Popen[str] | None = None,
    ) -> None:
        target = process or self.process
        if target is None or target.stdin is None:
            raise OSError("System policy backend input is unavailable")
        encoded = normalized_json(message) + "\n"
        with self.write_lock:
            target.stdin.write(encoded)
            target.stdin.flush()


class NativeProcess:
    def __init__(
        self,
        *,
        pid: int,
        ppid: int,
        command: str,
        executable: str | None,
        cwd: str | None,
    ) -> None:
        self.pid = pid
        self.ppid = ppid
        self.command = command
        self.executable = executable
        self.cwd = cwd

    def suspend(self) -> None:
        self._control("suspend")

    def resume(self) -> None:
        self._control("resume")

    def kill(self) -> None:
        self._control("kill")

    def _control(self, operation: str) -> None:
        if os.name == "posix":
            signum = {
                "suspend": signal.SIGSTOP,
                "resume": signal.SIGCONT,
                "kill": signal.SIGKILL,
            }[operation]
            os.kill(self.pid, signum)
            return
        kernel = ctypes.windll.kernel32
        kernel.OpenProcess.restype = ctypes.c_void_p
        access = 0x0001 if operation == "kill" else 0x0800
        handle = kernel.OpenProcess(access, False, self.pid)
        if not handle:
            raise OSError(ctypes.get_last_error(), f"OpenProcess failed for {self.pid}")
        try:
            if operation == "kill":
                if not kernel.TerminateProcess(handle, 1):
                    raise OSError(ctypes.get_last_error(), f"TerminateProcess failed for {self.pid}")
            else:
                function = (
                    ctypes.windll.ntdll.NtSuspendProcess
                    if operation == "suspend"
                    else ctypes.windll.ntdll.NtResumeProcess
                )
                status = function(handle)
                if status != 0:
                    raise OSError(f"Windows process control failed with NTSTATUS {status:#x}")
        finally:
            kernel.CloseHandle(handle)


class WindowsCoord(ctypes.Structure):
    _fields_ = [("X", ctypes.c_short), ("Y", ctypes.c_short)]


class WindowsConPtyProcess:
    def __init__(
        self,
        *,
        process_handle: Any,
        pseudoconsole_handle: Any,
        pid: int,
        command: list[str],
        stdin: Any,
        stdout: Any,
    ) -> None:
        self.kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        self.process_handle = process_handle
        self.pseudoconsole_handle = pseudoconsole_handle
        self.pid = pid
        self.args = command
        self.stdin = stdin
        self.stdout = stdout

    def poll(self) -> int | None:
        if self.kernel.WaitForSingleObject(self.process_handle, 0) != 0:
            return None
        code = ctypes.c_ulong()
        if not self.kernel.GetExitCodeProcess(self.process_handle, ctypes.byref(code)):
            raise ctypes.WinError(ctypes.get_last_error())
        return int(code.value)

    def wait(self, timeout: float | None = None) -> int:
        milliseconds = 0xFFFFFFFF if timeout is None else max(0, int(timeout * 1000))
        result = self.kernel.WaitForSingleObject(self.process_handle, milliseconds)
        if result == 0x102:
            raise subprocess.TimeoutExpired(self.args, timeout)
        if result != 0:
            raise ctypes.WinError(ctypes.get_last_error())
        code = self.poll()
        if code is None:
            raise RuntimeError("ConPTY process signaled without an exit code")
        return code

    def send_signal(self, signum: int) -> None:
        if signum == signal.SIGINT:
            self.stdin.write(b"\x03")
            self.stdin.flush()
            return
        self.terminate()

    def terminate(self) -> None:
        if self.poll() is None and not self.kernel.TerminateProcess(
            self.process_handle, 1
        ):
            raise ctypes.WinError(ctypes.get_last_error())

    def kill(self) -> None:
        self.terminate()

    def resume(self) -> None:
        NativeProcess(self.pid).resume()

    def resize(self, columns: int, rows: int) -> None:
        self.kernel.ResizePseudoConsole.argtypes = [
            ctypes.c_void_p,
            WindowsCoord,
        ]
        result = self.kernel.ResizePseudoConsole(
            self.pseudoconsole_handle,
            WindowsCoord(columns, rows),
        )
        if result != 0:
            raise OSError(result, "ResizePseudoConsole failed")

    def close(self) -> None:
        for stream in (self.stdin, self.stdout):
            try:
                stream.close()
            except OSError:
                pass
        if self.pseudoconsole_handle:
            self.kernel.ClosePseudoConsole(self.pseudoconsole_handle)
            self.pseudoconsole_handle = None
        if self.process_handle:
            self.kernel.CloseHandle(self.process_handle)
            self.process_handle = None


def start_windows_conpty(
    *,
    command: list[str],
    cwd: Path,
    environment: dict[str, str],
    suspended: bool,
) -> WindowsConPtyProcess:
    from ctypes import wintypes
    import msvcrt


    class STARTUPINFOW(ctypes.Structure):
        _fields_ = [
            ("cb", wintypes.DWORD),
            ("lpReserved", wintypes.LPWSTR),
            ("lpDesktop", wintypes.LPWSTR),
            ("lpTitle", wintypes.LPWSTR),
            ("dwX", wintypes.DWORD),
            ("dwY", wintypes.DWORD),
            ("dwXSize", wintypes.DWORD),
            ("dwYSize", wintypes.DWORD),
            ("dwXCountChars", wintypes.DWORD),
            ("dwYCountChars", wintypes.DWORD),
            ("dwFillAttribute", wintypes.DWORD),
            ("dwFlags", wintypes.DWORD),
            ("wShowWindow", wintypes.WORD),
            ("cbReserved2", wintypes.WORD),
            ("lpReserved2", ctypes.POINTER(wintypes.BYTE)),
            ("hStdInput", wintypes.HANDLE),
            ("hStdOutput", wintypes.HANDLE),
            ("hStdError", wintypes.HANDLE),
        ]

    class STARTUPINFOEXW(ctypes.Structure):
        _fields_ = [
            ("StartupInfo", STARTUPINFOW),
            ("lpAttributeList", wintypes.LPVOID),
        ]

    class PROCESS_INFORMATION(ctypes.Structure):
        _fields_ = [
            ("hProcess", wintypes.HANDLE),
            ("hThread", wintypes.HANDLE),
            ("dwProcessId", wintypes.DWORD),
            ("dwThreadId", wintypes.DWORD),
        ]

    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.CreatePseudoConsole.argtypes = [
        WindowsCoord,
        wintypes.HANDLE,
        wintypes.HANDLE,
        wintypes.DWORD,
        ctypes.POINTER(wintypes.HANDLE),
    ]
    kernel.CreatePseudoConsole.restype = ctypes.c_long
    input_read = wintypes.HANDLE()
    input_write = wintypes.HANDLE()
    output_read = wintypes.HANDLE()
    output_write = wintypes.HANDLE()
    pseudoconsole = wintypes.HANDLE()
    attribute_buffer: Any = None
    process_info = PROCESS_INFORMATION()
    owned_handles: list[Any] = []

    def checked(ok: Any) -> None:
        if not ok:
            raise ctypes.WinError(ctypes.get_last_error())

    try:
        checked(
            kernel.CreatePipe(
                ctypes.byref(input_read),
                ctypes.byref(input_write),
                None,
                0,
            )
        )
        owned_handles.extend((input_read, input_write))
        checked(
            kernel.CreatePipe(
                ctypes.byref(output_read),
                ctypes.byref(output_write),
                None,
                0,
            )
        )
        owned_handles.extend((output_read, output_write))
        result = kernel.CreatePseudoConsole(
            WindowsCoord(120, 40),
            input_read,
            output_write,
            0,
            ctypes.byref(pseudoconsole),
        )
        if result != 0:
            raise OSError(result, "CreatePseudoConsole failed")
        kernel.CloseHandle(input_read)
        kernel.CloseHandle(output_write)
        owned_handles.remove(input_read)
        owned_handles.remove(output_write)

        attribute_size = ctypes.c_size_t()
        kernel.InitializeProcThreadAttributeList(
            None, 1, 0, ctypes.byref(attribute_size)
        )
        attribute_buffer = ctypes.create_string_buffer(attribute_size.value)
        attribute_list = ctypes.cast(attribute_buffer, wintypes.LPVOID)
        checked(
            kernel.InitializeProcThreadAttributeList(
                attribute_list,
                1,
                0,
                ctypes.byref(attribute_size),
            )
        )
        checked(
            kernel.UpdateProcThreadAttribute(
                attribute_list,
                0,
                0x00020016,
                ctypes.byref(pseudoconsole),
                ctypes.sizeof(pseudoconsole),
                None,
                None,
            )
        )
        startup = STARTUPINFOEXW()
        startup.StartupInfo.cb = ctypes.sizeof(startup)
        startup.lpAttributeList = attribute_list
        command_line = ctypes.create_unicode_buffer(subprocess.list2cmdline(command))
        environment_block = ctypes.create_unicode_buffer(
            "\0".join(
                f"{key}={value}"
                for key, value in sorted(environment.items(), key=lambda item: item[0].upper())
            )
            + "\0\0"
        )
        flags = 0x00080000 | 0x00000400 | 0x00000200
        if suspended:
            flags |= 0x00000004
        checked(
            kernel.CreateProcessW(
                None,
                command_line,
                None,
                None,
                False,
                flags,
                environment_block,
                str(cwd),
                ctypes.byref(startup.StartupInfo),
                ctypes.byref(process_info),
            )
        )
        kernel.CloseHandle(process_info.hThread)
        kernel.DeleteProcThreadAttributeList(attribute_list)
        attribute_buffer = None
        input_fd = msvcrt.open_osfhandle(int(input_write.value), os.O_BINARY)
        output_fd = msvcrt.open_osfhandle(int(output_read.value), os.O_BINARY)
        owned_handles.remove(input_write)
        owned_handles.remove(output_read)
        return WindowsConPtyProcess(
            process_handle=process_info.hProcess,
            pseudoconsole_handle=pseudoconsole,
            pid=int(process_info.dwProcessId),
            command=command,
            stdin=os.fdopen(input_fd, "wb"),
            stdout=os.fdopen(output_fd, "rb"),
        )
    except Exception:
        if process_info.hProcess:
            kernel.TerminateProcess(process_info.hProcess, 1)
            kernel.CloseHandle(process_info.hProcess)
        if attribute_buffer is not None:
            kernel.DeleteProcThreadAttributeList(
                ctypes.cast(attribute_buffer, wintypes.LPVOID)
            )
        if pseudoconsole:
            kernel.ClosePseudoConsole(pseudoconsole)
        for handle in owned_handles:
            kernel.CloseHandle(handle)
        raise




class TerminalProcess:
    def __init__(
        self,
        *,
        command: list[str],
        cwd: Path,
        environment: dict[str, str],
        observe_input: Callable[[bytes], None],
        observe_output: Callable[[bytes], None],
    ) -> None:
        self.command = command
        self.cwd = cwd
        self.environment = environment
        self.observe_input = observe_input
        self.observe_output = observe_output
        self.process: Any = None
        self.master_fd: int | None = None
        self.original_terminal: list[Any] | None = None
        self.stop_event = threading.Event()
        self.threads: list[threading.Thread] = []
        self.started_suspended = False

    @property
    def pid(self) -> int:
        if self.process is None:
            raise RuntimeError("terminal process has not started")
        return self.process.pid

    def start(self, *, suspended: bool = False) -> "TerminalProcess":
        self.started_suspended = suspended
        if os.name == "posix":
            self._start_posix()
        elif os.name == "nt":
            self._start_windows()
        else:
            self._start_pipes()
        return self

    def _start_posix(self) -> None:
        master_fd, slave_fd = pty.openpty()
        self.master_fd = master_fd
        self._copy_window_size(slave_fd)
        wrapped = [
            "/bin/sh",
            "-c",
            'export TAMA_SESSION_OWNER_PID=$$; '
            + ('kill -STOP $$; ' if self.started_suspended else '')
            + 'exec "$@"',
            "tama-agent-child",
            *self.command,
        ]
        try:
            self.process = subprocess.Popen(
                wrapped,
                cwd=self.cwd,
                env=self.environment,
                stdin=slave_fd,
                stdout=slave_fd,
                stderr=slave_fd,
                close_fds=True,
                start_new_session=True,
            )
        finally:
            os.close(slave_fd)
        if sys.stdin.isatty():
            self.original_terminal = termios.tcgetattr(sys.stdin.fileno())
            tty.setraw(sys.stdin.fileno())
        self._spawn_thread(self._relay_terminal_input, "tama-terminal-input")
        self._spawn_thread(self._relay_terminal_output, "tama-terminal-output")

    def _start_windows(self) -> None:
        self.process = start_windows_conpty(
            command=self.command,
            cwd=self.cwd,
            environment=self.environment,
            suspended=self.started_suspended,
        )
        self._spawn_thread(self._relay_pipe_input, "tama-terminal-input")
        self._spawn_thread(self._relay_pipe_output, "tama-terminal-output")

    def _start_pipes(self) -> None:
        creationflags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        if self.started_suspended:
            creationflags |= getattr(subprocess, "CREATE_SUSPENDED", 0)
        self.process = subprocess.Popen(
            self.command,
            cwd=self.cwd,
            env=self.environment,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            creationflags=creationflags,
        )
        self._spawn_thread(self._relay_pipe_input, "tama-terminal-input")
        self._spawn_thread(self._relay_pipe_output, "tama-terminal-output")

    def _spawn_thread(self, target: Callable[[], None], name: str) -> None:
        thread = threading.Thread(target=target, name=name, daemon=True)
        self.threads.append(thread)
        thread.start()

    def _relay_terminal_input(self) -> None:
        assert self.master_fd is not None
        while not self.stop_event.is_set():
            try:
                readable, _, _ = select.select([sys.stdin.fileno()], [], [], 0.1)
                if not readable:
                    continue
                data = os.read(sys.stdin.fileno(), 4096)
                if not data:
                    return
                self.observe_input(data)
                os.write(self.master_fd, data)
            except (OSError, ValueError):
                return

    def _relay_terminal_output(self) -> None:
        assert self.master_fd is not None
        while not self.stop_event.is_set():
            try:
                readable, _, _ = select.select([self.master_fd], [], [], 0.1)
                if not readable:
                    continue
                data = os.read(self.master_fd, 65536)
                if not data:
                    return
                self.observe_output(data)
                os.write(sys.stdout.fileno(), data)
            except (OSError, ValueError):
                return

    def _relay_pipe_input(self) -> None:
        assert self.process is not None and self.process.stdin is not None
        while not self.stop_event.is_set():
            data = sys.stdin.buffer.read1(4096)
            if not data:
                return
            self.observe_input(data)
            try:
                self.process.stdin.write(data)
                self.process.stdin.flush()
            except OSError:
                return

    def _relay_pipe_output(self) -> None:
        assert self.process is not None and self.process.stdout is not None
        while not self.stop_event.is_set():
            data = self.process.stdout.read1(65536)
            if not data:
                return
            self.observe_output(data)
            sys.stdout.buffer.write(data)
            sys.stdout.buffer.flush()

    @staticmethod
    def _copy_window_size(target_fd: int) -> None:
        if not sys.stdin.isatty():
            return
        try:
            size = fcntl.ioctl(sys.stdin.fileno(), termios.TIOCGWINSZ, struct.pack("HHHH", 0, 0, 0, 0))
            fcntl.ioctl(target_fd, termios.TIOCSWINSZ, size)
        except OSError:
            return

    def resume(self) -> None:
        if self.process is None or not self.started_suspended:
            return
        NativeProcess(self.process.pid).resume()
        self.started_suspended = False

    def resize(self) -> None:
        if self.master_fd is not None:
            self._copy_window_size(self.master_fd)
        elif os.name == "nt" and isinstance(self.process, WindowsConPtyProcess):
            try:
                size = os.get_terminal_size(sys.stdin.fileno())
            except OSError:
                return
            self.process.resize(size.columns, size.lines)

    def poll(self) -> int | None:
        return None if self.process is None else self.process.poll()

    def send_signal(self, signum: int) -> None:
        if self.process is None:
            return
        if os.name == "posix":
            os.killpg(self.process.pid, signum)
        else:
            self.process.send_signal(signum)

    def terminate(self) -> None:
        if self.process is None:
            return
        if os.name == "posix":
            os.killpg(self.process.pid, signal.SIGTERM)
        else:
            self.process.terminate()

    def kill(self) -> None:
        if self.process is None:
            return
        if os.name == "posix":
            os.killpg(self.process.pid, signal.SIGKILL)
        else:
            self.process.kill()

    def write(self, data: bytes) -> None:
        if self.master_fd is not None:
            os.write(self.master_fd, data)
            return
        if self.process is None or self.process.stdin is None:
            raise RuntimeError("terminal input is unavailable")
        self.process.stdin.write(data)
        self.process.stdin.flush()

    def wait(self, timeout: float | None = None) -> int:
        if self.process is None:
            raise RuntimeError("terminal process has not started")
        return self.process.wait(timeout=timeout)

    def close(self) -> None:
        self.stop_event.set()
        if self.original_terminal is not None:
            termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, self.original_terminal)
            self.original_terminal = None
        if self.master_fd is not None:
            try:
                os.close(self.master_fd)
            except OSError:
                pass
            self.master_fd = None
        if isinstance(self.process, WindowsConPtyProcess):
            self.process.close()
