#!/usr/bin/env python3
"""Stop hook: reject defeatist "I can't determine / no way to find out" claims.

When the assistant declares a question undeterminable — "I don't currently
have a way to determine ...", "no way to know", "can't tell which",
"impossible to determine", "nothing that distinguishes them" — it is almost
always giving up *before* running the experiment that would settle it. This
hook blocks that turn and tells the assistant to run a diff experiment
(capture the two states and compare) instead of asserting the matter is
unknowable.

Quoted / backtick-wrapped spans are exempt so the phrasing can still be
quoted and discussed without self-blocking.

Contract matches the other Stop hooks (check_fabrication_phrases.py,
check_speculation.py): read the hook payload as JSON on stdin, inspect
last_assistant_message, emit {"decision": "block", "reason": ...} to block.
"""
from __future__ import annotations

import json
import re
import sys

PATTERNS = [
    # don't / do not / didn't (currently) have a way to ...
    r"\b(?:do\s*n'?t|do not|did\s*n'?t)\s+(?:currently\s+|really\s+|yet\s+)?have\s+(?:a\s+)?way\s+to\b",
    # no way to determine/know/tell/find out/...
    r"\bno\s+way\s+to\s+(?:determine|know|tell|find\s*out|verify|distinguish|isolate|establish|confirm|figure\s*out)\b",
    # can't / cannot / won't / unable to (currently) determine/tell/know/...
    r"\b(?:ca\s*n'?t|cannot|can\s*not|could\s*n'?t|wo\s*n'?t|unable\s+to)\s+(?:currently\s+|yet\s+)?(?:determine|tell\b|know\b|find\s*out|distinguish|isolate|establish|figure\s*out|work\s*out)\b",
    # impossible / not possible to determine/know/...
    r"\b(?:impossible|not\s+possible)\s+to\s+(?:determine|know|tell|isolate|distinguish|establish|find\s*out)\b",
    # can't be determined / known / isolated / distinguished
    r"\b(?:ca\s*n'?t|cannot)\s+be\s+(?:determined|known|established|isolated|distinguished|recovered)\b",
    # nothing that distinguishes / no signal that would tell ...
    r"\bnothing\s+(?:that\s+)?distinguishes\b",
    r"\bno\s+(?:signal|data|evidence|way)\b[^.\n]{0,40}\b(?:tell|determine|distinguish|expose|reveal|know)\b",
    # not recoverable / not determinable / not knowable / not something I can ...
    r"\bnot\s+(?:recoverable|determinable|knowable|something\s+i\s+can)\b",
]
COMPILED = [re.compile(p, flags=re.IGNORECASE) for p in PATTERNS]


def strip_quoted(text: str) -> str:
    """Blank out fenced/inline code and quoted spans so the banned phrasing
    can be quoted/discussed without tripping the gate."""
    text = re.sub(r"```.*?```", " ", text, flags=re.DOTALL)
    text = re.sub(r"`[^`]*`", " ", text)
    text = re.sub(r"\"[^\"]*\"", " ", text)
    text = re.sub(r"'[^']*'", " ", text)
    text = re.sub(r"“[^”]*”", " ", text)
    return text


def find_hits(text: str) -> list[str]:
    scan = strip_quoted(text)
    hits: list[str] = []
    for regex in COMPILED:
        for match in regex.finditer(scan):
            hits.append(match.group(0).strip())
    return list(dict.fromkeys(hits))


def main() -> int:
    try:
        payload = json.loads(sys.stdin.read() or "{}")
    except json.JSONDecodeError:
        return 0
    if payload.get("stop_hook_active"):
        return 0
    msg = payload.get("last_assistant_message") or ""
    if not isinstance(msg, str) or not msg.strip():
        return 0
    hits = find_hits(msg)
    if not hits:
        return 0
    reason = (
        "BLOCKED: You have a way. Run a diff experiment. You wrote "
        + repr(hits[0]) + " — that is giving up before testing. Capture the two "
        "states (passing vs failing, expected vs actual) and diff them to "
        "determine the answer, instead of declaring it undeterminable. "
        "To quote the phrase itself, wrap it in backticks or quotes."
    )
    print(json.dumps({"decision": "block", "reason": reason}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
