#!/usr/bin/env node

import { spawn, spawnSync } from 'node:child_process'
import { looksLikeMalfunction, tokenizeCommand } from './hook-exec.mjs'
import {
  chmodSync,
  existsSync,
  lstatSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  rmSync,
  symlinkSync,
  writeFileSync,
} from 'node:fs'
import { homedir } from 'node:os'
import { dirname, join, resolve } from 'node:path'
import { randomUUID } from 'node:crypto'
import { fileURLToPath } from 'node:url'

const extensionPath = fileURLToPath(import.meta.url)
const sharedHooksRoot = dirname(extensionPath)
const registryPath = process.env.AGENT_HOOK_REGISTRY || join(sharedHooksRoot, 'registry.json')
const providerCatalogPath = process.env.TAMA_PROVIDER_CATALOG || join(sharedHooksRoot, 'providers.json')
const workRoot = process.env.TAMA_SESSION_HOOK_WORK_ROOT
  || join(dirname(sharedHooksRoot), '.work', 'one-session-hook')
const selectedHookId = String(process.env.TAMA_ONE_SESSION_HOOK_ID || '').trim()
const registry = JSON.parse(readFileSync(registryPath, 'utf8'))
const providerCatalog = JSON.parse(readFileSync(providerCatalogPath, 'utf8'))
if (
  providerCatalog.schema !== 'ai.wisent.tama.providers.v1'
  || !providerCatalog.providers
  || typeof providerCatalog.providers !== 'object'
  || Array.isArray(providerCatalog.providers)
) {
  throw new Error(`Invalid Tama provider catalog: ${providerCatalogPath}`)
}
const providers = Object.freeze(providerCatalog.providers)

const EVENT_MAP = Object.freeze({
  stop: { key: 'Stop' },
  user_prompt_submit: { key: 'UserPromptSubmit' },
  'post_tool_use:bash': { key: 'PostToolUse', matcher: 'Bash' },
  'session_start:compact': { key: 'SessionStart', matcher: 'compact' },
  'pre_tool_use:bash': { key: 'PreToolUse', matcher: 'Bash' },
  'pre_tool_use:read': { key: 'PreToolUse', matcher: 'Read' },
  'pre_tool_use:edit': { key: 'PreToolUse', matcher: 'apply_patch|Edit|Write' },
  'pre_tool_use:write': { key: 'PreToolUse', matcher: 'apply_patch|Edit|Write' },
  'pre_tool_use:multiedit': { key: 'PreToolUse', matcher: 'MultiEdit' },
  'pre_tool_use:notebook': { key: 'PreToolUse', matcher: 'NotebookEdit' },
  'pre_tool_use:task': { key: 'PreToolUse', matcher: 'Task|Agent' },
  'pre_tool_use:todo': { key: 'PreToolUse', matcher: 'Todo|todo' },
  'pre_tool_use:goal': { key: 'PreToolUse', matcher: 'Goal|goal' },
  'pre_tool_use:lookup': { key: 'PreToolUse', matcher: 'Grep|grep|Glob|glob|Search|LSP|lsp|AstGrep|ast_grep' },
  'pre_tool_use:wait': { key: 'PreToolUse', matcher: 'Monitor|ScheduleWakeup' },
  'pre_tool_use:eval': { key: 'PreToolUse', matcher: 'Eval|eval|execute_code|mcp__node_repl_js|node_repl/js' },
  'pre_tool_use:ssh': { key: 'PreToolUse', matcher: 'SSH|ssh' },
})

function expandArguments(argumentsTemplate, values) {
  return argumentsTemplate.flatMap((argument) => {
    if (argument === '{session}' && !values.session) return []
    if (!argument.startsWith('{') || !argument.endsWith('}')) return [argument]
    const key = argument.slice(1, -1)
    if (!Object.hasOwn(values, key)) {
      throw new Error(`Unknown provider argument placeholder: ${argument}`)
    }
    return [String(values[key])]
  })
}

function launchForProvider(providerName, provider, { hookId, mode, session, cwd }) {
  if (
    typeof provider?.executable !== 'string'
    || typeof provider?.executableEnv !== 'string'
    || typeof provider?.hookTransport !== 'string'
    || !Array.isArray(provider?.newArguments)
    || !Array.isArray(provider?.resumeArguments)
  ) {
    throw new Error('Invalid provider entry in Tama provider catalog.')
  }

  const env = {
    ...process.env,
    TAMA_ONE_SESSION_HOOK_ID: hookId,
    TAMA_SESSION_OWNER_PID: String(process.pid),
  }
  const values = {
    cwd,
    extensionPath,
    session,
    sessionDir: join(
      process.env.PI_CODING_AGENT_DIR || join(homedir(), '.omp', 'agent'),
      'sessions',
    ),
  }
  let cleanup = () => {}

  if (provider.hookTransport === 'inline-settings') {
    values.hooksJson = JSON.stringify({ hooks: providerHooks(hookId, providerName) })
  } else if (provider.hookTransport === 'isolated-codex-home') {
    const isolated = isolatedCodexHome(hookId, cwd, providerName)
    env.CODEX_HOME = isolated.path
    cleanup = isolated.cleanup
  } else if (provider.hookTransport === 'omp-extension') {
    const isolated = isolatedOmpAgent()
    env.PI_CODING_AGENT_DIR = isolated.path
    cleanup = isolated.cleanup
  } else {
    throw new Error(`Unsupported provider hook transport: ${provider.hookTransport}`)
  }

  const argumentsTemplate = mode === 'new'
    ? provider.newArguments
    : provider.resumeArguments
  return {
    executable: process.env[provider.executableEnv] || provider.executable,
    args: expandArguments(argumentsTemplate, values),
    env,
    cleanup,
  }
}

function matchingHooks(hookId) {
  const matches = []
  for (const [event, entry] of Object.entries(registry.events || {})) {
    for (const hook of entry.hooks || []) {
      if (String(hook?.id || '') === hookId) matches.push({ event, entry, hook })
    }
  }
  return matches
}

function shellQuote(value) {
  return `'${String(value).replaceAll("'", "'\\''")}'`
}

function hookConfig(event, hook, provider) {
  const value = {
    type: hook.type || 'command',
    command: [
      'env',
      `TAMA_PROVIDER=${shellQuote(provider)}`,
      `TAMA_ONLY_HOOK_ID=${shellQuote(hook.id)}`,
      'node',
      shellQuote(join(sharedHooksRoot, 'run-hook.mjs')),
      shellQuote(event),
      shellQuote(provider),
    ].join(' '),
  }
  if (hook.timeout) value.timeout = hook.timeout
  if (hook.statusMessage) value.statusMessage = hook.statusMessage
  return value
}

function providerHooks(hookId, provider) {
  const hooks = {}
  const seen = new Set()
  for (const { event, hook } of matchingHooks(hookId)) {
    const target = EVENT_MAP[event]
    if (!target) continue
    const signature = JSON.stringify([target.key, target.matcher || '', hook.command])
    if (seen.has(signature)) continue
    seen.add(signature)
    const group = { hooks: [hookConfig(event, hook, provider)] }
    if (target.matcher) group.matcher = target.matcher
    if (!hooks[target.key]) hooks[target.key] = []
    hooks[target.key].push(group)
  }
  if (!Object.keys(hooks).length) {
    throw new Error(`Hook ${hookId} has no supported Claude/Codex events.`)
  }
  return hooks
}

function isolatedOmpAgent() {
  const source = process.env.PI_CODING_AGENT_DIR || join(homedir(), '.omp', 'agent')
  const path = join(workRoot, `omp-agent-${randomUUID()}`)
  mkdirSync(path, { recursive: true, mode: 0o700 })
  const sourceConfig = join(source, 'config.yml')
  if (existsSync(sourceConfig)) {
    const excludedKeys = new Set(['disabledExtensions', 'extensions', 'hooks'])
    const filtered = readFileSync(sourceConfig, 'utf8')
      .split('\n')
      .filter((line, index, lines) => {
        let owner = index
        while (owner >= 0 && /^\s/.test(lines[owner])) owner -= 1
        const key = lines[owner]?.match(/^([^#\s][^:]*):/)?.[1]
        return !excludedKeys.has(key)
      })
      .join('\n')
    const configPath = join(path, 'config.yml')
    writeFileSync(configPath, filtered)
    chmodSync(configPath, 0o600)
  }
  const snapshot = spawnSync(
    'python3',
    [
      '-c',
      [
        'import sqlite3, sys',
        'from pathlib import Path',
        'source, target = map(Path, sys.argv[1:3])',
        'for name in ("agent.db", "models.db", "history.db"):',
        '    if not (source / name).exists(): continue',
        '    source_db = sqlite3.connect(f"file:{source / name}?mode=ro", uri=True)',
        '    target_db = sqlite3.connect(target / name)',
        '    source_db.backup(target_db)',
        '    target_db.close()',
        '    source_db.close()',
      ].join('\n'),
      source,
      path,
    ],
    { encoding: 'utf8' },
  )
  if (snapshot.error || snapshot.status !== 0) {
    rmSync(path, { recursive: true, force: true })
    throw new Error(
      `Could not snapshot isolated OMP state: ${snapshot.error?.message || snapshot.stderr.trim()}`,
    )
  }
  const changelogVersion = join(source, 'last-changelog-version')
  if (existsSync(changelogVersion)) {
    writeFileSync(join(path, 'last-changelog-version'), readFileSync(changelogVersion))
  }
  return {
    path,
    cleanup: () => rmSync(path, { recursive: true, force: true }),
  }
}

function isolatedCodexHome(hookId, cwd, provider) {
  const source = process.env.CODEX_HOME || join(homedir(), '.codex')
  const path = join(workRoot, `codex-${randomUUID()}`)
  mkdirSync(path, { recursive: true, mode: 0o700 })
  const excluded = new Set([
    '.tmp',
    'config.toml',
    'hooks.json',
    'plugins',
    'requirements.toml',
    'tmp',
  ])
  for (const name of readdirSync(source)) {
    if (excluded.has(name)) continue
    const from = join(source, name)
    const to = join(path, name)
    const type = lstatSync(from).isDirectory() ? 'dir' : 'file'
    symlinkSync(from, to, type)
  }
  const hooksPath = join(path, 'hooks.json')
  writeFileSync(hooksPath, JSON.stringify({ hooks: providerHooks(hookId, provider) }, null, 2) + '\n')
  chmodSync(hooksPath, 0o600)
  const configPath = join(path, 'config.toml')
  writeFileSync(
    configPath,
    `[features]\nhooks = true\n\n[projects.${JSON.stringify(cwd)}]\ntrust_level = \"untrusted\"\n`,
  )
  chmodSync(configPath, 0o600)
  return {
    path,
    cleanup: () => rmSync(path, { recursive: true, force: true }),
  }
}

function isMainModule() {
  return process.argv[1] ? resolve(process.argv[1]) === resolve(extensionPath) : false
}

function usage() {
  return [
    'Usage: run-one-session-hook.js <provider> <hook-id> [session|--new]',
    '',
    `Providers: ${Object.keys(providers).join(', ')}`,
    'Use --new for a new isolated session; pass a session id/path to resume it.',
    'Without the third argument, the provider opens its resume picker.',
  ].join('\n') + '\n'
}

function parseArguments() {
  const args = process.argv.slice(2)
  if (args.includes('--help') || args.includes('-h')) return { help: true }
  if (args.length < 2 || args.length > 3) throw new Error(usage().trim())
  const [provider, hookId, sessionArgument] = args
  if (!providers[provider]) throw new Error(`Unknown provider: ${provider}\n${usage().trim()}`)
  if (!matchingHooks(hookId).length) throw new Error(`Unknown hook id: ${hookId}`)
  return {
    provider,
    hookId,
    mode: sessionArgument === '--new' ? 'new' : 'resume',
    session: sessionArgument === '--new' ? null : sessionArgument,
  }
}

async function launchOneSession() {
  const request = parseArguments()
  if (request.help) {
    process.stdout.write(usage())
    return 0
  }

  const provider = providers[request.provider]
  const launch = launchForProvider(request.provider, provider, {
    mode: request.mode,
    session: request.session,
    cwd: process.cwd(),
    hookId: request.hookId,
  })
  const child = spawn(launch.executable, launch.args, {
    env: launch.env,
    stdio: 'inherit',
  })
  const forward = (signal) => {
    if (!child.killed) child.kill(signal)
  }
  const signals = ['SIGINT', 'SIGTERM', 'SIGHUP']
  for (const signal of signals) process.on(signal, forward)
  try {
    return await new Promise((resolveExit) => {
      child.on('error', (error) => {
        process.stderr.write(`Could not start ${request.provider}: ${error.message}\n`)
        resolveExit(1)
      })
      child.on('exit', (code, signal) => {
        resolveExit(signal ? 128 + (process.binding('constants').os.signals[signal] || 0) : (code ?? 1))
      })
    })
  } finally {
    for (const signal of signals) process.off(signal, forward)
    launch.cleanup()
  }
}

function toolName(event) {
  return String(event?.toolName || event?.name || '')
}

function toolInput(event) {
  const input = event?.input || event?.params
  return input && typeof input === 'object' && !Array.isArray(input) ? input : {}
}

function ompEvent(name) {
  const normalized = String(name).toLowerCase()
  if (normalized === 'read') return 'pre_tool_use:read'
  if (normalized === 'notebookedit' || normalized === 'notebook') return 'pre_tool_use:notebook'
  if (normalized === 'multiedit') return 'pre_tool_use:multiedit'
  if (normalized === 'write' || normalized === 'edit' || normalized === 'apply_patch') return 'pre_tool_use:edit'
  if (normalized === 'bash') return 'pre_tool_use:bash'
  if (normalized === 'monitor' || normalized === 'schedulewakeup') return 'pre_tool_use:wait'
  if (normalized === 'task' || normalized === 'agent') return 'pre_tool_use:task'
  if (normalized === 'todo') return 'pre_tool_use:todo'
  if (normalized === 'goal') return 'pre_tool_use:goal'
  if (normalized === 'ask' || normalized.endsWith('.ask') || normalized.endsWith('/ask') || normalized.endsWith('_ask')) return 'pre_tool_use:ask'
  if (normalized === 'ssh') return 'pre_tool_use:ssh'
  return 'pre_tool_use:eval'
}

function ompPayload(event) {
  const name = toolName(event)
  const input = toolInput(event)
  return {
    agent_hook_event: 'tool_call',
    runtime: 'omp',
    session_id: event?.sessionId || event?.session_id || event?.session?.id || null,
    project_dir: event?.cwd || process.cwd(),
    tool_name: name,
    tool_input: input,
    tool: { name, input },
  }
}

function outputBlockReason(text) {
  const line = String(text || '').trim().split('\n').filter(Boolean).at(-1)
  if (!line) return null
  try {
    const value = JSON.parse(line)
    return value?.decision === 'block' ? String(value.reason || 'Hook blocked the tool call.') : null
  } catch {
    return null
  }
}

function runCommand(command, payload, timeoutMs) {
  return new Promise((resolveResult) => {
    const [program, ...args] = tokenizeCommand(command)
    if (!program) {
      resolveResult({ blocked: false })
      return
    }
    const child = spawn(program, args, { env: process.env })
    let stdout = ''
    let stderr = ''
    let settled = false
    const finish = (result) => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      resolveResult(result)
    }
    const timer = setTimeout(() => {
      child.kill('SIGTERM')
      finish({ blocked: true, reason: `${selectedHookId} timed out` })
    }, timeoutMs)
    child.stdout.on('data', (chunk) => { stdout += chunk.toString('utf8') })
    child.stderr.on('data', (chunk) => { stderr += chunk.toString('utf8') })
    child.on('error', (error) => {
      process.stderr.write(`${selectedHookId} malfunctioned: ${error.message}\n`)
      finish({ blocked: false })
    })
    child.on('close', (code) => {
      const reason = outputBlockReason(stdout) || outputBlockReason(stderr)
      if (reason) {
        finish({ blocked: true, reason })
        return
      }
      if (!code) {
        finish({ blocked: false })
        return
      }
      if (looksLikeMalfunction({ stdout, stderr })) {
        // A crashing hook is not a policy decision.
        process.stderr.write(`${selectedHookId} malfunctioned: ${(stderr || stdout).trim()}\n`)
        finish({ blocked: false })
        return
      }
      finish({ blocked: true, reason: stderr.trim() || stdout.trim() || `${selectedHookId} exited ${code}` })
    })
    child.stdin.end(JSON.stringify(payload))
  })
}

export default function runOneSessionHook(pi) {
  if (!selectedHookId || !matchingHooks(selectedHookId).length) {
    throw new Error('TAMA_ONE_SESSION_HOOK_ID must identify one registered hook.')
  }
  pi.on('tool_call', async (event) => {
    const eventName = ompEvent(toolName(event))
    const commands = new Map()
    for (const match of matchingHooks(selectedHookId)) {
      if (match.event === eventName) commands.set(match.hook.command, match)
    }
    for (const { entry, hook } of commands.values()) {
      const result = await runCommand(
        hook.command,
        ompPayload(event),
        Math.max(1, Number(hook.timeout || 10)) * 1000,
      )
      if (result.blocked && entry.blocking !== false) {
        return { block: true, reason: `${selectedHookId}: ${result.reason}` }
      }
    }
  })
}

if (isMainModule()) {
  launchOneSession()
    .then((code) => { process.exitCode = code })
    .catch((error) => {
      process.stderr.write(`${error instanceof Error ? error.message : String(error)}\n`)
      process.exitCode = 2
    })
}
