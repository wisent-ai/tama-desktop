#!/usr/bin/env python3
"""Block agent question tools and question-bearing final responses."""
from __future__ import annotations

import json
import os
import re
import sys
from typing import Any

URL_RE = re.compile(r"https?://\S+", re.IGNORECASE)
FENCED_CODE_RE = re.compile(r"```[\s\S]*?```")
INLINE_CODE_RE = re.compile(r"`[^`\n]*`")


def load_payload() -> dict[str, Any]:
    try:
        value = json.loads(sys.stdin.read() or "{}")
    except json.JSONDecodeError:
        return {}
    return value if isinstance(value, dict) else {}


def visible_prose(text: str) -> str:
    text = FENCED_CODE_RE.sub("", text)
    text = INLINE_CODE_RE.sub("", text)
    return URL_RE.sub("", text)


def hook_event(payload: dict[str, Any]) -> str:
    value = (
        payload.get("agent_hook_event")
        or payload.get("hook_event_name")
        or payload.get("hook_event")
        or payload.get("event")
        or ""
    )
    return re.sub(r"[^a-z_:]", "", str(value).lower())


def targets_question_tool(payload: dict[str, Any]) -> bool:
    name = payload.get("tool_name") or payload.get("tool") or payload.get("name") or ""
    if isinstance(name, dict):
        name = name.get("name") or name.get("tool_name") or ""
    if str(name).strip().lower() in {"ask", "functions.ask"}:
        return True
    return hook_event(payload).endswith(":ask")


def final_message(payload: dict[str, Any]) -> str | None:
    message = payload.get("last_assistant_message")
    return message if isinstance(message, str) else None


def main() -> int:
    payload = load_payload()
    message = None if targets_question_tool(payload) else final_message(payload)
    if isinstance(message, str):
        prose = visible_prose(message)
        if "?" not in prose:
            return 0
        print(json.dumps({
            "decision": "block",
            "reason": (
                "BLOCKED: agent questions are disabled by direct user policy. "
                "Resolve ambiguity from available context, choose the conservative default, "
                "or report a concrete unreachable prerequisite without asking the user."
            ),
        }))
        return 0

    if not targets_question_tool(payload):
        # The final text is not visible in this payload shape. A gate that
        # cannot read the message must not deny it: denying here rejects every
        # response instead of the question-bearing ones.
        return os.EX_OK

    sys.stderr.write(
        "BLOCKED: agent question tools are disabled by direct user policy; "
        "continue with informed action instead.\n"
    )
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
