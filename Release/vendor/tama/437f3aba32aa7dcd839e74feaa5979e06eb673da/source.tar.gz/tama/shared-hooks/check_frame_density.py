#!/usr/bin/env python3
"""Stop hook — for every trajectory the assistant just made a verdict about,
require Read on at least one frame PNG per second of that recording's
duration. Blocks the response until density is met.
"""
import json
import os
import re
import subprocess
import sys
from pathlib import Path

CWD = Path(os.getcwd())

def project_root(start):
    p = start
    while p != p.parent:
        if (p / ".git").exists() or (p / ".work").is_dir():
            return p
        p = p.parent
    return start

ROOT = project_root(CWD)

raw = sys.stdin.read()
try:
    payload = json.loads(raw) if raw.strip() else {}
except Exception:
    sys.exit(0)
transcript = payload.get("transcript_path") or ""
if not transcript or not Path(transcript).is_file():
    sys.exit(0)

VERDICT_RE = re.compile(
    r"\b(fail(?:ed|ure|s)?|pass(?:ed|es)?|success(?:ful)?|ended at|reached|exit(?: code)?|"
    r"DETECTION_TRIGGERED|HTTP ERROR|onboarding|captcha (?:solved|failed)|blocked|"
    r"crashed|stalled|hung|stuck|broken|works|completed|finalized|terminated)\b",
    re.IGNORECASE,
)
LABEL_RE = re.compile(r"(?:\.work|recordings)/([a-z][a-z0-9_]+)/", re.IGNORECASE)
WEBM_RE = re.compile(r"([\w./\-]+\.webm)")
FRAME_RE = re.compile(r"\.work/([a-z][a-z0-9_]+)/.*\.(?:png|jpg|jpeg)$", re.IGNORECASE)

try:
    lines = Path(transcript).read_text().splitlines()
except Exception:
    sys.exit(0)

recent = lines[-100:]
claimed_labels = set()
read_pngs_per_label = {}

for raw_line in recent:
    try:
        entry = json.loads(raw_line)
    except Exception:
        continue
    msg = entry.get("message") or {}
    role = msg.get("role") or entry.get("type")
    content = msg.get("content") or []
    if not isinstance(content, list):
        continue
    for block in content:
        if not isinstance(block, dict):
            continue
        btype = block.get("type")
        if btype == "text" and role == "assistant":
            txt = block.get("text") or ""
            if VERDICT_RE.search(txt):
                for m in LABEL_RE.finditer(txt):
                    claimed_labels.add(m.group(1))
                for m in WEBM_RE.finditer(txt):
                    lm = LABEL_RE.search(m.group(1))
                    if lm:
                        claimed_labels.add(lm.group(1))
        elif btype == "tool_use" and block.get("name") == "Read":
            fp = (block.get("input") or {}).get("file_path") or ""
            m = FRAME_RE.search(fp)
            if m:
                read_pngs_per_label.setdefault(m.group(1), set()).add(fp)

if not claimed_labels:
    sys.exit(0)

def latest_webm(label):
    candidates = []
    for base in (ROOT / ".work" / label / "recordings", ROOT / "recordings" / label):
        if base.is_dir():
            candidates += list(base.rglob("*.webm"))
    if not candidates:
        return None
    return max(candidates, key=lambda p: p.stat().st_mtime)

def duration_seconds(webm):
    try:
        out = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "csv=p=0", str(webm)],
            capture_output=True, text=True,
        )
        if out.returncode != 0:
            return None
        return int(float(out.stdout.strip() or 0))
    except Exception:
        return None

violations = []
for label in sorted(claimed_labels):
    webm = latest_webm(label)
    if not webm:
        continue
    dur = duration_seconds(webm)
    if dur is None:
        continue
    read_count = len(read_pngs_per_label.get(label, set()))
    # v2: a small FIXED sample evidences inspection. The prior rule
    # (read_count < dur, i.e. one frame per second) was unsatisfiable for
    # minute-long recordings and self-perpetuated as old label+verdict
    # lines stayed in the lines[-100:] window. Override via
    # CHECK_FRAME_DENSITY_MIN.
    required = int(os.environ.get("CHECK_FRAME_DENSITY_MIN", "3"))
    if read_count < required:
        violations.append((label, webm, required, read_count))

if not violations:
    sys.exit(0)

print("=" * 70, file=sys.stderr)
print("  BLOCKED: insufficient frame inspection for trajectory verdict", file=sys.stderr)
print("=" * 70, file=sys.stderr)
for label, webm, dur, read in violations:
    print(f"  trajectory '{label}': {webm.name}", file=sys.stderr)
    print(f"    duration = {dur} seconds", file=sys.stderr)
    print(f"    frames you Read in .work/{label}/ = {read}", file=sys.stderr)
    print(f"    required >= {dur} (one frame per second of recording)", file=sys.stderr)
    print(f"    extract:  ffmpeg -i {webm} -vf fps=1 .work/{label}/dense_%04d.png", file=sys.stderr)
    print(f"    then Read each of the {dur} PNGs before claiming anything", file=sys.stderr)
    print("", file=sys.stderr)
sys.exit(2)
