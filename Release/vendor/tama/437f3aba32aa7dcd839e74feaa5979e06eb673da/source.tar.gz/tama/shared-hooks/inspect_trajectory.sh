#!/bin/bash
# inspect_trajectory.sh — sanctioned path to inspect a trajectory's recording
# and DOM artifacts, then write the sha256-validating marker that unblocks
# re-runs.
#
# HARDENED 2026-05-08: marker now contains recording_sha256 so the verifier
# can detect a touched-empty-file bypass.

set -euo pipefail

LABEL="${1:-}"
if [[ -z "$LABEL" ]]; then
    echo "usage: $0 <label> [recording-path]" >&2
    exit 1
fi

REC_PATH="${2:-}"
REPO="$(pwd)"

if [[ -z "$REC_PATH" ]]; then
    for cand in "$REPO/../weles/recordings/$LABEL" "$REPO/recordings/$LABEL"; do
        if [[ -d "$cand" ]]; then
            REC_PATH=$(ls -t "$cand"/*.webm 2>/dev/null | head -1 || true)
            [[ -n "$REC_PATH" ]] && break
        fi
    done
fi

if [[ -z "$REC_PATH" || ! -f "$REC_PATH" ]]; then
    echo "no recording found for label '$LABEL'" >&2
    exit 1
fi

REC_PATH=$(cd "$(dirname "$REC_PATH")" && pwd)/$(basename "$REC_PATH")

echo "[inspect] recording: $REC_PATH"
REC_SHA=$(shasum -a 256 "$REC_PATH" | awk '{print $1}')
echo "[inspect] recording sha256: $REC_SHA"

WORK_DIR="$REPO/.work/$LABEL"
mkdir -p "$WORK_DIR"

# Per-recording lineage: tag every extracted frame with the recording's
# sha8. A Read on `frame_<sha8>_*.png` is the only thing the transcript
# scanner counts as inspection of THIS recording. Frames from prior runs
# (with different sha8) no longer satisfy the gate.
SHA8=${REC_SHA:0:8}
DUR=$(ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "$REC_PATH" 2>/dev/null || echo "")
# Always extract one frame per second of recording, plus a `last` frame
# pinned to the final 0.5s so the cursor on the tail of short clips is
# never missed. This produces frame_<sha8>_001.png … frame_<sha8>_<N>.png
# where <N> = ceil(duration). The check_failure_inspection.py gate counts
# distinct Reads against this set and requires count >= ceil(duration).
rm -f "$WORK_DIR"/frame_${SHA8}_*.png 2>/dev/null || true
ffmpeg -y -loglevel error -i "$REC_PATH" -vf "fps=1" "$WORK_DIR/frame_${SHA8}_%03d.png" 2>&1 || true
if [[ -n "$DUR" ]]; then
    LAST_TS=$(awk -v d="$DUR" 'BEGIN { printf "%.2f", (d > 0.5 ? d - 0.5 : 0) }')
    LAST_FRAME="$WORK_DIR/frame_${SHA8}_last.png"
    ffmpeg -y -loglevel error -ss "$LAST_TS" -i "$REC_PATH" -frames:v 1 "$LAST_FRAME" 2>&1 || true
fi
# Mtime-pin: frame mtime == recording mtime so the transcript scanner can
# compare Read-time vs frame mtime and reject reads of stale frames.
touch -r "$REC_PATH" "$WORK_DIR"/frame_${SHA8}_*.png 2>/dev/null || true
shopt -s nullglob
FRAME_FILES=( "$WORK_DIR"/frame_${SHA8}_*.png )
shopt -u nullglob
FRAME_COUNT=${#FRAME_FILES[@]}
echo "[inspect] frames written (sha8=${SHA8}, ${FRAME_COUNT} frames @ 1 fps):"
printf '  %s\n' "${FRAME_FILES[@]:0:20}"
[[ "$FRAME_COUNT" -gt 20 ]] && echo "  ... and $((FRAME_COUNT - 20)) more"

echo ""
echo "[inspect] existing DOM/diag artifacts under .work/:"
find "$REPO/.work" -type f \( -name "*outerHTML*" -o -name "*.html" -o -name "*dom*.json" -o -name "*inspection*" \) 2>/dev/null \
    | grep -E "/$LABEL/|-diag/" | head -20 | sed 's/^/  /' || echo "  (none)"

MARKER_DIR="$REPO/.work/.artifact_inspected"
mkdir -p "$MARKER_DIR"
MARKER="$MARKER_DIR/$LABEL"
{
    echo "label: $LABEL"
    echo "recording: $REC_PATH"
    echo "recording_sha256: $REC_SHA"
    echo "inspected_at: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
    echo "frames:"
    for f in "$WORK_DIR"/frame_${SHA8}_*.png; do
        [[ -f "$f" ]] && {
            FSHA=$(shasum -a 256 "$f" | awk '{print $1}')
            echo "  - path: $f"
            echo "    sha256: $FSHA"
        }
    done
} > "$MARKER"

echo ""
echo "[inspect] marker written: $MARKER"
echo "[inspect] you may now re-run trajectory '$LABEL'"
echo ""
echo "READ THE FRAMES BEFORE THE NEXT RUN. The transcript scanner watches for"
echo "Read tool calls on .work/$LABEL/ paths; failing to Read at least one"
echo "frame keeps you on counter-rule thin ice."
