#!/usr/bin/env python3
"""Block OMP/agent git commit-push commands when Git hooks are not configured/executable."""
from __future__ import annotations

import json
import os
import shlex
import stat
import subprocess
import sys
from pathlib import Path

SHELL_TOOL_NAMES = {"bash", "Bash", "exec_command", "functions.exec_command", "run_command", "run_package_script"}
REQUIRED_HOOKS = ("pre-commit", "pre-push")


def payload() -> dict:
    raw = sys.stdin.read()
    try:
        return json.loads(raw) if raw.strip() else {}
    except json.JSONDecodeError:
        return {}


def command_from(data: dict) -> str:
    tool_input = data.get("tool_input") or data.get("tool", {}).get("input") or {}
    if isinstance(tool_input, dict):
        return str(tool_input.get("command") or tool_input.get("cmd") or "")
    return str(tool_input or "")


def cwd_from(data: dict) -> Path:
    raw_event = data.get("raw_event") if isinstance(data.get("raw_event"), dict) else {}
    for value in (data.get("cwd"), raw_event.get("cwd"), data.get("project_dir")):
        if value:
            return Path(str(value)).expanduser().resolve()
    return Path.cwd()


def tokens(command: str) -> list[str]:
    try:
        return shlex.split(command)
    except ValueError:
        return command.split()


def is_git(token: str) -> bool:
    return Path(token).name == "git"


def expands(value: str, base: Path) -> Path:
    expanded = os.path.expanduser(os.path.expandvars(value))
    path = Path(expanded)
    if not path.is_absolute():
        path = base / path
    return path.resolve()


def target_cwd(base: Path, command: str) -> Path:
    toks = tokens(command)
    for i in range(0, max(0, len(toks) - 3)):
        if toks[i] == "cd" and toks[i + 2] == "&&" and is_git(toks[i + 3]):
            return expands(toks[i + 1], base)
    for i, token in enumerate(toks):
        if not is_git(token):
            continue
        scan = i + 1
        while scan < len(toks):
            if toks[scan] == "-C" and scan + 1 < len(toks):
                return expands(toks[scan + 1], base)
            if toks[scan] in {"commit", "push"}:
                break
            scan += 1
    return base


def mentions_git_commit_or_push(command: str) -> bool:
    toks = tokens(command)
    for i, token in enumerate(toks):
        if is_git(token) and any(t in {"commit", "push"} for t in toks[i + 1 :]):
            return True
    return False


def git(cwd: Path, *args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(["git", *args], cwd=cwd, text=True, capture_output=True, timeout=5)


def is_executable(path: Path) -> bool:
    try:
        mode = path.stat().st_mode
    except FileNotFoundError:
        return False
    return bool(mode & stat.S_IXUSR)


def verify_hooks(cwd: Path) -> str | None:
    try:
        inside = git(cwd, "rev-parse", "--is-inside-work-tree")
    except Exception as exc:
        return f"cannot inspect git worktree at {cwd}: {exc}"
    if inside.returncode != 0 or inside.stdout.strip() != "true":
        return None
    root = git(cwd, "rev-parse", "--show-toplevel")
    hooks = git(cwd, "config", "--get", "core.hooksPath")
    hooks_path = hooks.stdout.strip()
    if hooks.returncode != 0 or not hooks_path:
        return "git core.hooksPath is not configured for this worktree"
    base = Path(hooks_path)
    if not base.is_absolute():
        base = (Path(root.stdout.strip() or cwd) / base).resolve()
    missing = [name for name in REQUIRED_HOOKS if not (base / name).exists()]
    if missing:
        return f"git hooksPath missing required hook(s): {', '.join(missing)} in {base}"
    not_exec = [name for name in REQUIRED_HOOKS if not is_executable(base / name)]
    if not_exec:
        return f"git hooksPath has non-executable hook(s): {', '.join(not_exec)} in {base}"
    return None


def main() -> int:
    data = payload()
    if data.get("tool_name") not in SHELL_TOOL_NAMES:
        return 0
    command = command_from(data)
    if not mentions_git_commit_or_push(command):
        return 0
    reason = verify_hooks(target_cwd(cwd_from(data), command))
    if reason is None:
        return 0
    print(f"BLOCKED: Git hooksPath is not ready for git commit/push.\n  reason: {reason}", file=sys.stderr)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
