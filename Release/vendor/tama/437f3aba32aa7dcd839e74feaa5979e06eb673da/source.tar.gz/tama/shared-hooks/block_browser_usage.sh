#!/usr/bin/env bash
set -euo pipefail

INPUT="$(cat)"

if ! command -v jq >/dev/null; then
  printf '%s\n' 'BLOCKED: browser boundary cannot inspect the tool payload because jq is unavailable.'
  false
fi

TOOL_NAME="$(
  printf '%s' "$INPUT" | jq -r '
    (.tool_name // .tool.name // .tool // .name // "")
    | if type == "string" then . else "" end
  ' || true
)"
TOOL_INPUT="$(
  printf '%s' "$INPUT" | jq -c '
    .tool_input // .input // .tool.input // .tool.tool_input // {}
  ' || printf '{}'
)"
TOOL_PATH="$(printf '%s' "$TOOL_INPUT" | jq -r '.path // ""' || true)"
TOOL_OPERATION="$(printf '%s' "$TOOL_INPUT" | jq -r '.op // .action // ""' || true)"
TOOL_COMMAND="$(printf '%s' "$TOOL_INPUT" | jq -r '.command // .cmd // ""' || true)"
TOOL_CODE="$(printf '%s' "$TOOL_INPUT" | jq -r '.code // ""' || true)"
TOOL_PROCESS="$(
  printf '%s' "$TOOL_INPUT" | jq -r '
    [.application // empty, (.args // [])[]] | join("\n")
  ' || true
)"
PAYLOAD_TEXT="$(
  printf '%s' "$TOOL_INPUT" | jq -r '[.. | strings] | join("\n")' || true
)"

LOWER_TOOL="$(printf '%s' "$TOOL_NAME" | tr '[:upper:]' '[:lower:]')"
LOWER_PATH="$(printf '%s' "$TOOL_PATH" | tr '[:upper:]' '[:lower:]')"
LOWER_OPERATION="$(printf '%s' "$TOOL_OPERATION" | tr '[:upper:]' '[:lower:]')"
LOWER_TEXT="$(printf '%s' "$PAYLOAD_TEXT" | tr '[:upper:]' '[:lower:]')"
LOWER_COMMAND="$(printf '%s' "$TOOL_COMMAND" | tr '[:upper:]' '[:lower:]')"
LOWER_CODE="$(printf '%s' "$TOOL_CODE" | tr '[:upper:]' '[:lower:]')"
LOWER_PROCESS="$(printf '%s' "$TOOL_PROCESS" | tr '[:upper:]' '[:lower:]')"

block() {
  printf '%s\n' \
    'BLOCKED: direct browser use is forbidden.' \
    'Use the Weles API/trajectory; its browser runtime must execute on a Stado target carrying a Weles placement policy.' \
    'Approved Weles targets are read from ~/.stado/local-storage/registry.json.'
  false
}

# Browser tools bypass Weles by definition, including mounted xd://browser
# calls. Closing or inspecting a direct-browser tab is still direct use.
if printf '%s' "$LOWER_TOOL" | grep -Eq '(^|[._-])browser([._-]|$)' \
  || printf '%s' "$LOWER_PATH" | grep -Eq '^xd://(mcp__)?browser([/_-]|$)'; then
  block
fi

# Browser control hidden inside a general execution tool is also direct use.
# For mounted tools, inspect code only on executable device paths so a normal
# source-file write containing the word "playwright" is not blocked.
EXECUTABLE_TEXT=''
case "$LOWER_TOOL" in
  bash|functions.bash)
    EXECUTABLE_TEXT="$LOWER_COMMAND"
    ;;
  eval|functions.eval|mcp__node_repl_js)
    EXECUTABLE_TEXT="$LOWER_CODE"
    ;;
  hub|functions.hub)
    if [[ "$LOWER_OPERATION" == 'start' ]]; then
      EXECUTABLE_TEXT="$LOWER_PROCESS"
    fi
    ;;
  write|functions.write)
    if printf '%s' "$LOWER_PATH" | grep -Eq '^xd://mcp__node_repl_js($|[/_-])'; then
      EXECUTABLE_TEXT="$LOWER_TEXT"
    fi
    ;;
esac

if [[ -z "$EXECUTABLE_TEXT" ]]; then
  exit
fi

# Repository maintenance is not browser execution. Permit one non-compound,
# built-in Git operation even when a repository path contains "weles" or
# "browser"; browser runtimes remain subject to the checks below.
SAFE_GIT_PATTERN='^[[:space:]]*git([[:space:]]+-C[[:space:]]+[^[:space:]]+)?[[:space:]]+(status|diff|log|show|branch|remote|fetch|pull|rebase|add|rm|restore|commit|push|rev-parse|ls-files)([[:space:]]|$)'
if [[ "$LOWER_TOOL" == 'bash' || "$LOWER_TOOL" == 'functions.bash' ]] \
  && printf '%s' "$LOWER_COMMAND" | grep -Eq "$SAFE_GIT_PATTERN" \
  && ! printf '%s' "$LOWER_COMMAND" | grep -Eq '[;&|`]|[$][(]'; then
  exit
fi

BROWSER_RUNTIME_PATTERN='chromium|google[[:space:]]+chrome|chrome-mac|com\.google\.chrome|org\.chromium|firefox|safari(\.app)?|webkit|playwright|puppeteer|selenium|connectovercdp|remote-debugging-port|browser[[:space:]_-]*plugin|(^|[^[:alnum:]_])(tab|page|browser)\.'
WELES_RUNTIME_PATTERN='(^|[/[:space:]"'\''])weles([/[:space:]"'\'']|$)|scripts/(trajectories|worker|_shared/keeper)|wsession'

if ! printf '%s' "$EXECUTABLE_TEXT" | grep -Eq "$BROWSER_RUNTIME_PATTERN|$WELES_RUNTIME_PATTERN"; then
  exit
fi

# Weles itself may drive its patched browser, but only on a host selected by
# the canonical Stado registry. API clients on other machines remain allowed:
# they do not launch a local browser runtime.
if printf '%s' "$EXECUTABLE_TEXT" | grep -Eq "$WELES_RUNTIME_PATTERN"; then
  REGISTRY="${STADO_BROWSER_POLICY_REGISTRY:-$HOME/.stado/local-storage/registry.json}"
  CURRENT_HOST="$(hostname | tr '[:upper:]' '[:lower:]' || true)"
  CURRENT_SHORT="${CURRENT_HOST%.local}"
  if [[ -r "$REGISTRY" ]] && jq -e \
    --arg host "$CURRENT_HOST" \
    --arg short "$CURRENT_SHORT" '
      any(
        .targets[]?;
        (
          (.weles.enabled? == true)
          or ((.weles.actions? | type) == "array" and (.weles.actions != []))
        )
        and any(
          ([.name] + (.hostnames // []))[];
          (ascii_downcase == $host)
          or ((ascii_downcase | sub("[.]local$"; "")) == $short)
        )
      )
    ' "$REGISTRY" >/dev/null; then
    exit
  fi
fi

block
