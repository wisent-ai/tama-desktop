#!/usr/bin/env python3
"""Block OpenAI API-key usage from Codex tool calls."""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path


FORBIDDEN = re.compile(
    r"(?<!block_)OPENAI_API_KEY(?!\.py)|CHATGPT_RANK_API_KEY|OPENAI_API_BASE|OPENAI_API_URL|"
    r"api\.openai\.com|openai\.com/v1|sk-[A-Za-z0-9_-]{20,}",
    re.IGNORECASE,
)


def payload() -> tuple[dict, str]:
    raw = sys.stdin.read()
    try:
      return json.loads(raw) if raw.strip() else {}, raw
    except json.JSONDecodeError:
      return {}, raw


def block(reason: str, sample: str = "") -> None:
    print("BLOCKED: OpenAI API-key usage is forbidden for this agent.", file=sys.stderr)
    print(f"Reason: {reason}", file=sys.stderr)
    if sample:
        print(f"Matched: {sample[:220]}", file=sys.stderr)
    sys.exit(2)


def command_text(data: dict) -> str:
    tool_input = data.get("tool_input") or {}
    for key in ("command", "cmd"):
        value = tool_input.get(key) or data.get(key)
        if isinstance(value, str):
            return value
    return ""


def added_lines_only(text: str) -> str:
    lines = []
    for line in text.splitlines():
        if line.startswith("+++") or line.startswith("***"):
            continue
        if line.startswith("+"):
            lines.append(line[1:])
    return "\n".join(lines)


def edit_text(data: dict, raw: str) -> str:
    tool_input = data.get("tool_input") or {}
    tool = str(data.get("tool_name") or data.get("tool") or "")
    if "apply_patch" in tool.lower():
        return added_lines_only(json.dumps(tool_input, sort_keys=True)) or added_lines_only(raw)
    parts = []
    for key in ("content", "new_string", "new_source", "patch"):
        value = tool_input.get(key)
        if isinstance(value, str):
            parts.append(value)
    return "\n".join(parts)


def read_path(data: dict) -> Path | None:
    tool_input = data.get("tool_input") or {}
    value = tool_input.get("file_path") or tool_input.get("path")
    if isinstance(value, str) and value:
        return Path(value).expanduser()
    return None


def main() -> int:
    data, raw = payload()
    cmd = command_text(data)
    if cmd:
        match = FORBIDDEN.search(cmd)
        if match:
            block("command references OpenAI API credentials or endpoint", match.group(0))
        return 0

    path = read_path(data)
    if path and path.is_file():
        try:
            sample = path.read_text(errors="ignore")
        except OSError:
            sample = ""
        match = FORBIDDEN.search(sample)
        if match:
            block(f"read target contains forbidden OpenAI API credential reference: {path}", match.group(0))
        return 0

    text = edit_text(data, raw)
    if text:
        match = FORBIDDEN.search(text)
        if match:
            block("file edit introduces OpenAI API credential or endpoint usage", match.group(0))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
