#!/usr/bin/env python3
"""Block every SSH transport without a transcript-backed, exact registry grant."""
from __future__ import annotations

from dataclasses import dataclass
import json
import os
from pathlib import Path
import re
import shlex
import sys
from typing import Any, Iterable
from urllib.parse import urlsplit
from inline_execution_policy import inline_execution_reason



SSH_TOOL_RE = re.compile(r"(?:^|[._:/-])ssh(?:$|[._:/-])", re.I)
SSH_URL_RE = re.compile(r"\b(?:ssh|sftp)://[^\s'\"<>]+", re.I)
SSH_BINARY_RE = re.compile(r"(?:^|[/\s;&|`(])(?:ssh|scp|sftp)(?=\s|$)", re.I)
RSYNC_REMOTE_RE = re.compile(r"(?:^|[/\s;&|`(])rsync(?=\s|$).+?(?:ssh://|(?:[A-Za-z0-9._-]+@)?[A-Za-z0-9.-]+:)", re.I | re.S)
GIT_SSH_RE = re.compile(r"(?:^|[/\s;&|`(])git(?=\s|$).+?(?:ssh://|git@[A-Za-z0-9.-]+:)", re.I | re.S)
SSH_LIBRARY_RE = re.compile(r"\b(?:paramiko|asyncssh|fabric\.Connection|node-ssh|ssh2)\b", re.I)
REMOTE_SPEC_RE = re.compile(r"(?<![A-Za-z0-9._-])((?:[A-Za-z0-9._-]+@)?[A-Za-z0-9.-]+):[^\s]+")
DIRECT_CONSENT_RE = re.compile(
    r"\b(?:zgadzam\s+si[eę]|wyra[zż]am\s+zgod[eę]|pozwalam(?:\s+ci)?|"
    r"zezwalam(?:\s+ci)?|autoryzuj[eę]|upowa[zż]niam|masz\s+moj[aą]\s+zgod[eę]|"
    r"mo[zż]esz\s+u[zż]y[cć]|i\s+consent|i\s+authorize|i\s+allow|"
    r"you\s+have\s+my\s+permission|you\s+may\s+use)\b",
    re.I,
)
DIRECT_IMPERATIVE_RE = re.compile(
    r"^\s*(?:(?:prosz[eę]|please)\s+)?"
    r"(?:u[zż]yj|uruchom|po[lł][aą]cz|zaloguj|odczytaj|pobierz|wy[sś]lij|skopiuj|"
    r"use|run|connect|log\s+in|read|fetch|send|copy)\b",
    re.I,
)
SSH_QUOTE_RE = re.compile(r"\bssh\b", re.I)
JUSTIFICATION_PATH = Path(
    os.environ.get(
        "TAMA_SSH_JUSTIFICATION",
        str(Path.home() / ".shared-hooks" / "ssh_justification.json"),
    )
)
SESSION_ROOT = Path(
    os.environ.get(
        "TAMA_OMP_SESSION_ROOT",
        str(Path.home() / ".omp" / "agent" / "sessions"),
    )
)
EXECUTABLE_TOOLS = {
    "bash",
    "functions.bash",
    "eval",
    "functions.eval",
    "mcp__node_repl_js",
    "node_repl/js",
    "hub",
    "functions.hub",
}
READ_TOOLS = {"read", "functions.read", "grep", "functions.grep", "glob", "functions.glob"}
WRITE_TOOLS = {
    "write",
    "functions.write",
    "edit",
    "functions.edit",
    "multiedit",
    "notebook",
    "notebookedit",
    "apply_patch",
}
SSH_OPTIONS_WITH_VALUE = {
    "-b",
    "-c",
    "-D",
    "-E",
    "-e",
    "-F",
    "-I",
    "-i",
    "-J",
    "-L",
    "-l",
    "-m",
    "-O",
    "-o",
    "-p",
    "-Q",
    "-R",
    "-S",
    "-W",
    "-w",
}


@dataclass(frozen=True)
class SshRequest:
    operation: str
    targets: tuple[str, ...]
    paths: tuple[str, ...]
    command: str | None


def load_payload() -> dict[str, Any]:
    try:
        value = json.loads(sys.stdin.read() or "{}")
    except json.JSONDecodeError:
        return {}
    return value if isinstance(value, dict) else {}


def tool_name(payload: dict[str, Any]) -> str:
    value = payload.get("tool_name") or payload.get("name") or payload.get("tool")
    if isinstance(value, dict):
        value = value.get("name") or value.get("tool_name")
    return str(value or "")


def tool_input(payload: dict[str, Any]) -> dict[str, Any]:
    value = payload.get("tool_input") or payload.get("input")
    if isinstance(value, dict):
        return value
    nested = payload.get("tool")
    if isinstance(nested, dict):
        value = nested.get("input") or nested.get("tool_input")
        if isinstance(value, dict):
            return value
    return {}


def strings(value: Any) -> Iterable[str]:
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for item in value.values():
            yield from strings(item)
    elif isinstance(value, list):
        for item in value:
            yield from strings(item)


def canonical_target(raw: str) -> str | None:
    value = raw.strip().strip("'\"[](){},;")
    if not value:
        return None
    if value.lower().startswith(("ssh://", "sftp://")):
        parsed = urlsplit(value)
        host = (parsed.hostname or "").lower()
        if not host:
            return None
        user = parsed.username or ""
        port = f":{parsed.port}" if parsed.port is not None else ""
        return f"{user + '@' if user else ''}{host}{port}"
    if ":" in value and not value.startswith("["):
        value = value.split(":", 1)[0]
    if "@" in value:
        user, host = value.rsplit("@", 1)
        return f"{user}@{host.lower()}" if user and host else None
    return value.lower() if re.fullmatch(r"[A-Za-z0-9.-]+(?::\d+)?", value) else None


def targets_from_urls(urls: Iterable[str]) -> set[str]:
    targets: set[str] = set()
    for url in urls:
        target = canonical_target(url)
        if target:
            targets.add(target)
    return targets


def command_text(name: str, inp: dict[str, Any]) -> str:
    direct = inp.get("command") or inp.get("cmd") or inp.get("code")
    if isinstance(direct, str):
        return direct.strip()
    if name.casefold() in {"hub", "functions.hub"} and str(inp.get("op") or "").casefold() == "start":
        application = str(inp.get("application") or "")
        args = inp.get("args") if isinstance(inp.get("args"), list) else []
        return " ".join([application, *(str(arg) for arg in args)]).strip()
    return ""


def command_targets(command: str) -> set[str]:
    targets = targets_from_urls(SSH_URL_RE.findall(command))
    for match in REMOTE_SPEC_RE.finditer(command):
        target = canonical_target(match.group(1))
        if target:
            targets.add(target)
    try:
        tokens = shlex.split(command, posix=True)
    except ValueError:
        tokens = command.split()
    for index, token in enumerate(tokens):
        binary = os.path.basename(token).casefold()
        if binary not in {"ssh", "sftp"}:
            continue
        cursor = index + 1
        while cursor < len(tokens):
            candidate = tokens[cursor]
            if candidate in SSH_OPTIONS_WITH_VALUE:
                cursor += 2
                continue
            if candidate.startswith("-"):
                cursor += 1
                continue
            target = canonical_target(candidate)
            if target:
                targets.add(target)
            break
    return targets


def contains_ssh_command(command: str) -> bool:
    return bool(
        SSH_BINARY_RE.search(command)
        or RSYNC_REMOTE_RE.search(command)
        or GIT_SSH_RE.search(command)
        or SSH_LIBRARY_RE.search(command)
        or SSH_URL_RE.search(command)
    )


def command_operation(command: str) -> str:
    if re.search(r"(?:^|\s)-(?:[A-Za-z]*[LRDW]|[LRDW])", command):
        return "tunnel"
    if GIT_SSH_RE.search(command):
        return "git"
    if re.search(r"(?:^|[/\s;&|`(])(?:scp|sftp|rsync)(?=\s|$)", command, re.I):
        return "transfer"
    return "exec"


def ssh_request(payload: dict[str, Any]) -> SshRequest | None:
    name = tool_name(payload).casefold()
    inp = tool_input(payload)
    path_values: list[str] = []
    for key in ("path", "paths", "file", "files"):
        path_values.extend(strings(inp.get(key)))
    urls: list[str] = []
    for value in path_values:
        urls.extend(SSH_URL_RE.findall(value))
    if urls:
        operation = "write" if name in WRITE_TOOLS else "read"
        return SshRequest(
            operation=operation,
            targets=tuple(sorted(targets_from_urls(urls))),
            paths=tuple(sorted(set(urls))),
            command=None,
        )

    command = command_text(name, inp)
    direct_tool = bool(SSH_TOOL_RE.search(name))
    executable = name in EXECUTABLE_TOOLS
    if not direct_tool and not (executable and contains_ssh_command(command)):
        return None
    operation = str(inp.get("action") or inp.get("op") or "").strip().casefold()
    if operation not in {"read", "write", "exec", "transfer", "tunnel", "git"}:
        operation = command_operation(command) if command else "exec"
    return SshRequest(
        operation=operation,
        targets=tuple(sorted(command_targets(command))),
        paths=(),
        command=command or None,
    )


def user_content_contains(value: Any, quote: str) -> bool:
    if isinstance(value, dict):
        if value.get("role") == "user" and quote in "\n".join(strings(value.get("content"))):
            return True
        return any(user_content_contains(item, quote) for item in value.values())
    if isinstance(value, list):
        return any(user_content_contains(item, quote) for item in value)
    return False


def quote_is_in_current_session(session_id: str, quote: str) -> bool:
    if not session_id or not quote or not SESSION_ROOT.is_dir():
        return False
    for path in SESSION_ROOT.rglob(f"*{session_id}*.jsonl"):
        try:
            for line in path.read_text(errors="replace").splitlines():
                try:
                    value = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if user_content_contains(value, quote):
                    return True
        except OSError:
            continue
    return False


def quote_authorizes_targets(quote: str, targets: tuple[str, ...]) -> bool:
    if not SSH_QUOTE_RE.search(quote) or not (
        DIRECT_CONSENT_RE.search(quote) or DIRECT_IMPERATIVE_RE.search(quote)
    ):
        return False
    lowered = quote.casefold()
    for target in targets:
        host = target.rsplit("@", 1)[-1].split(":", 1)[0]
        if target.casefold() not in lowered and host not in lowered:
            return False
    return bool(targets)


def exact_string_list(entry: dict[str, Any], key: str) -> set[str] | None:
    value = entry.get(key)
    if not isinstance(value, list) or not value or not all(isinstance(item, str) and item for item in value):
        return None
    return set(value)


def entry_matches(entry: dict[str, Any], request: SshRequest, session_id: str) -> bool:
    quote = entry.get("userRequestQuote")
    if (
        entry.get("allowedTool") != "ssh"
        or entry.get("lifetime") != "current OMP session"
        or not isinstance(quote, str)
        or not quote_authorizes_targets(quote, request.targets)
        or not quote_is_in_current_session(session_id, quote)
    ):
        return False
    targets = exact_string_list(entry, "allowedTargets")
    operations = exact_string_list(entry, "allowedOperations")
    if targets is None or operations is None:
        return False
    if not {target.casefold() for target in request.targets}.issubset(
        {target.casefold() for target in targets}
    ):
        return False
    if request.operation not in {operation.casefold() for operation in operations}:
        return False
    if request.operation in {"read", "write"}:
        paths = exact_string_list(entry, "allowedPaths")
        return paths is not None and set(request.paths).issubset(paths)
    commands = exact_string_list(entry, "allowedCommands")
    return request.command is not None and commands is not None and request.command in commands


def authorized(payload: dict[str, Any], request: SshRequest) -> bool:
    try:
        registry = json.loads(JUSTIFICATION_PATH.read_text())
    except (OSError, json.JSONDecodeError):
        return False
    if not isinstance(registry, dict) or registry.get("schema") != "ai.wisent.tama.ssh-justification.v1":
        return False
    session_id = str(payload.get("session_id") or payload.get("sessionId") or "")
    entries = registry.get("authorizations")
    if not isinstance(entries, list):
        return False
    return any(
        isinstance(entry, dict) and entry_matches(entry, request, session_id)
        for entry in entries
    )




def block_inline_execution(reason: str) -> int:
    sys.stderr.write(
        "BLOCKED: inline code execution is forbidden. "
        "Put executable logic in a checked-in reusable file and run that file. "
        f"Detected: {reason}\n"
    )
    return os.EX_NOPERM


def block(reason: str) -> int:
    sys.stderr.write(f"BLOCKED: unauthorized SSH: {reason}\n")
    return 2


def evaluate_payload(payload: dict[str, Any]) -> int:
    inline_reason = inline_execution_reason(payload)
    if inline_reason is not None:
        return block_inline_execution(inline_reason)
    request = ssh_request(payload)
    if request is None:
        return 0
    if not request.targets:
        return block("the operation uses SSH but its exact target could not be determined")
    if not authorized(payload, request):
        return block(
            "an exact current-session user authorization and matching "
            "ssh_justification.json entry are both required"
        )
    return 0


def main() -> int:
    return evaluate_payload(load_payload())


if __name__ == "__main__":
    raise SystemExit(main())
