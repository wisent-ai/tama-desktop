#!/usr/bin/env python3
"""Block agent reads, edits, writes, notebook changes, and saves in temporary paths."""

from __future__ import annotations

import json
import os
import re
import sys
from pathlib import PurePosixPath
from typing import Any, Iterable
from urllib.parse import unquote, urlsplit

PATH_KEYS = {
    "path",
    "filepath",
    "notebookpath",
    "savepath",
    "outputpath",
    "targetpath",
    "destination",
    "filename",
}
PATCH_KEYS = {"input", "patch"}
COLLECTION_KEYS = {"edits", "files", "targets", "operations"}
PATCH_PATTERNS = (
    re.compile(r"^\[([^#\]\n]+)#[0-9A-Fa-f]+\]$"),
    re.compile(r"^\*\*\* (?:Add|Update|Delete) File: (.+)$"),
    re.compile(r"^(?:---|\+\+\+) [ab]/(.+)$"),
)
FIXED_TEMP_ROOTS = (
    "/tmp",
    "/private/tmp",
    "/var/tmp",
    "/private/var/tmp",
    "/var/folders",
    "/private/var/folders",
)


def load_payload() -> dict[str, Any]:
    try:
        value = json.loads(sys.stdin.read() or "{}")
    except json.JSONDecodeError:
        return {}
    return value if isinstance(value, dict) else {}


def normalized_key(value: object) -> str:
    return re.sub(r"[^a-z]", "", str(value).casefold())


def patch_paths(text: str) -> Iterable[str]:
    for raw_line in text.splitlines():
        line = raw_line.strip()
        for pattern in PATCH_PATTERNS:
            match = pattern.match(line)
            if match:
                yield match.group(int("1")).strip()
                break


def candidate_paths(value: Any) -> Iterable[str]:
    if isinstance(value, dict):
        for key, item in value.items():
            normalized = normalized_key(key)
            if normalized in PATH_KEYS and isinstance(item, str):
                yield item
            elif normalized in PATCH_KEYS and isinstance(item, str):
                yield from patch_paths(item)
            elif normalized in COLLECTION_KEYS or isinstance(item, (dict, list)):
                yield from candidate_paths(item)
    elif isinstance(value, list):
        for item in value:
            yield from candidate_paths(item)


def filesystem_path(path: str) -> str | None:
    parsed = urlsplit(path)
    if not parsed.scheme:
        return path
    if parsed.scheme.casefold() != "file" or parsed.netloc not in {"", "localhost"}:
        return None
    return unquote(parsed.path)


def normalized_paths(path: str) -> Iterable[str]:
    local_path = filesystem_path(path)
    if not local_path or "\x00" in local_path:
        return
    expanded = os.path.expandvars(os.path.expanduser(local_path))
    slash_normalized = expanded.replace("\\", "/")
    yield slash_normalized
    absolute = os.path.abspath(expanded)
    yield os.path.normpath(absolute)
    yield os.path.realpath(absolute)


def roots() -> tuple[str, ...]:
    configured = os.environ.get("TMPDIR")
    values = list(FIXED_TEMP_ROOTS)
    if configured:
        values.extend(normalized_paths(configured))
    return tuple(dict.fromkeys(os.path.normpath(value) for value in values if value))


def under(path: str, root: str) -> bool:
    try:
        return os.path.commonpath((path, root)) == root
    except ValueError:
        return False


def temporary(path: str, temp_roots: tuple[str, ...]) -> bool:
    for candidate in normalized_paths(path):
        posix = candidate.replace("\\", "/")
        parts = tuple(part.casefold() for part in PurePosixPath(posix).parts)
        if "tmp" in parts:
            return True
        normalized = os.path.normpath(candidate)
        if any(under(normalized, root) for root in temp_roots):
            return True
    return False


def main() -> int:
    payload = load_payload()
    tool_input = payload.get("tool_input") or payload.get("input") or {}
    temp_roots = roots()
    blocked = sorted({path for path in candidate_paths(tool_input) if temporary(path, temp_roots)})
    if not blocked:
        return int("0")
    sys.stderr.write(
        "BLOCKED: Temporary-path Read/Edit/Write/Save operations are not allowed: "
        + " | ".join(blocked)
        + "\n"
    )
    return int("2")


if __name__ == "__main__":
    raise SystemExit(main())
