#!/usr/bin/env python3
"""PreToolUse Bash gate — when inspect_required.json has open entries,
block the next Bash command unless it's one of:
  - $HOME/.shared-hooks/inspect_trajectory.sh ...
  - shasum / ffmpeg / ffprobe / ls on the relevant recording
  - cat / head / tail / grep on .work/<label>/ artifacts (read-only)

Cleared automatically when the agent Reads the failure_state PNG via the
Read tool (the corresponding Stop hook check_failure_inspection.py
handles claim-time enforcement; this hook handles tool-call ordering).

Behaviour:
  - Reads inspect_required.json
  - For each open entry, removes the entry once the failure_state file's
    inode atime is > set_at (i.e. the file has been opened/Read).
  - If any entry remains and the agent's command isn't an inspection
    helper, exit 2.

Bypass: INSPECT_REQUIRED_DISABLED=1.
"""
import json
import os
import re
import sys
from pathlib import Path

if os.environ.get("INSPECT_REQUIRED_DISABLED") == "1":
    sys.exit(0)

HOME = Path(os.environ.get("HOME", "/tmp"))
REQ = HOME / ".shared-hooks" / "state" / "inspect_required.json"
if not REQ.is_file():
    sys.exit(0)

raw = sys.stdin.read()
try:
    payload = json.loads(raw) if raw.strip() else {}
except Exception:
    sys.exit(0)
cmd = (payload.get("tool_input") or {}).get("command") or ""

ALLOWED = re.compile(
    r"(\binspect_trajectory\.sh\b|"
    r"\b(shasum|ffmpeg|ffprobe|ls|cat|head|tail|grep|file|stat|wc)\b\s+[^|;&]*\.work/|"
    r"\b(shasum|ffmpeg|ffprobe)\b\s+[^|;&]*recordings/)"
)
if ALLOWED.search(cmd):
    sys.exit(0)

try:
    data = json.loads(REQ.read_text())
except Exception:
    sys.exit(0)
if not data:
    sys.exit(0)

# Auto-clear: scan the session JSONL for a Read on each entry's
# failure_state. If the latest JSONL Read is after entry.set_at, drop it.
import datetime as dt
# Fix: do NOT prepend an extra "-" — absolute paths already begin with "/"
# so .replace("/", "-") yields a leading "-". The prior "-"+... produced
# "--Users-..." which never matches any real projects dir, so the JSONL
# was never found and the gate never auto-cleared after a Read. The
# sibling check_artifact_inspection.py:74 documents this exact pitfall.
encoded = str(Path(os.getcwd())).replace("/", "-")
proj = HOME / ".claude" / "projects" / encoded
jsonl = None
if proj.is_dir():
    cs = sorted(proj.glob("*.jsonl"), key=lambda p: p.stat().st_mtime, reverse=True)
    jsonl = cs[0] if cs else None


def jsonl_has_read(fp_pat):
    if not jsonl:
        return False
    try:
        lines = jsonl.read_text().splitlines()
    except Exception:
        return False
    for raw in lines[-200:]:
        try:
            entry = json.loads(raw)
        except Exception:
            continue
        msg = entry.get("message") or {}
        content = msg.get("content") or []
        if not isinstance(content, list):
            continue
        for block in content:
            if not isinstance(block, dict) or block.get("type") != "tool_use":
                continue
            if block.get("name") != "Read":
                continue
            fp = str((block.get("input") or {}).get("file_path") or "")
            if fp_pat.search(fp):
                return True
    return False


cwd = os.path.realpath(os.getcwd())

remaining = {}
cleared = []
for label, info in data.items():
    sha8 = info.get("sha8") or ""
    fp = info.get("failure_state") or ""
    # CWD scoping: derive the project root from the failure_state path
    # (the part before /.work/). If the agent's CWD is not inside that
    # project root, the failure belongs to a different project and this
    # session has no business inspecting it. Treat as cleared so cross-
    # project recording failures don't block unrelated work.
    proj_root = ""
    if "/.work/" in fp:
        proj_root = os.path.realpath(fp.split("/.work/")[0])
    if proj_root and not (cwd == proj_root or cwd.startswith(proj_root + "/")):
        cleared.append(label)
        continue
    pat = re.compile(rf"\.work/{re.escape(label)}/failure_state_{re.escape(sha8)}\.(?:png|jpg|html)$")
    if jsonl_has_read(pat):
        cleared.append(label)
        continue
    remaining[label] = info

if cleared:
    try:
        REQ.write_text(json.dumps(remaining, indent=2))
    except Exception:
        pass

if not remaining:
    sys.exit(0)

print("=" * 60, file=sys.stderr)
print("  BLOCKED: inspection required before next Bash command", file=sys.stderr)
print("=" * 60, file=sys.stderr)
for label, info in remaining.items():
    print(f"  trajectory '{label}' failed; failure_state at:", file=sys.stderr)
    print(f"    {info.get('failure_state', '?')}", file=sys.stderr)
print("", file=sys.stderr)
print("Read the failure_state png(s) above with the Read tool, OR run", file=sys.stderr)
print("$HOME/.shared-hooks/inspect_trajectory.sh <label>, then retry.", file=sys.stderr)
print("Bypass: INSPECT_REQUIRED_DISABLED=1.", file=sys.stderr)
sys.exit(2)
