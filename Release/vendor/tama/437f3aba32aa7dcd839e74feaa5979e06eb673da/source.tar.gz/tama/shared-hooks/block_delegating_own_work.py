#!/usr/bin/env python3
"""Block final responses that hand the agent's own work to the user.

The agent may not decide, on the user's behalf, that the user should perform an
action the agent is able to perform itself. Committing is the canonical case:
no instruction in this environment reserves `git commit` for a human, yet the
agent invented that convention, attributed it to the user, and used it to leave
its own work unfinished and uncommitted.

The distinction this gate enforces is capability, not politeness:

  deferrable   - needs operator privilege the agent does not have: exporting an
                 environment variable, restarting an application, pushing to a
                 remote, entering a credential, approving a device policy.
  not deferrable - anything the agent can run itself: committing, staging,
                 editing a file, running a local command, reading a path.

Handing back a not-deferrable action is a decision made for the user, and it is
blocked here.
"""

from __future__ import annotations

import json
import re
import sys
from typing import Any

# House convention: numeric literals stay quoted (see src/adaptive/telemetry.mjs).
EXIT_PASS = int("0")
EXIT_BLOCK = int("2")

FENCED_CODE_RE = re.compile(r"```[\s\S]*?```")
INLINE_CODE_RE = re.compile(r"`[^`\n]*`")

# Actions the agent can always perform itself.
OWN_WORK = (
    r"commit(?:uj|ujesz|owa[cć]|ing|ted)?|zacommit\w*|stage|stag(?:ing|ed)|"
    r"git\s+(?:commit|add)|"
    r"popraw(?:i[cć]|isz)?|zmie[nń](?:i[cć]|isz)?|dopisz|edytuj|uruchom|odpal"
)

# Phrases that hand an action back to the user.
HANDOFF = (
    r"zostawiam\s+to\s+(?:tobie|ci|wam)|"
    r"zostawi[eę]\s+to\s+(?:tobie|ci)|"
    r"to\s+ju[zż]\s+(?:twoja|twoj[aą])\s+decyzj\w*|"
    r"decyzj[aę]\s+zostawiam|"
    r"zr[oó][bp]\s+to\s+sam\w*|musisz\s+sam\w*|"
    r"leave\s+(?:it|that|this|the\s+\w+)\s+to\s+you|"
    r"i(?:'|\s)?ll\s+leave\s+(?:it|that|the\s+\w+)\s+to\s+you|"
    r"up\s+to\s+you|your\s+call|you\s+should\s+(?:commit|run|edit|stage)|"
    r"please\s+(?:commit|run|stage)"
)

# Actions that genuinely require operator privilege; handing these back is fine.
OPERATOR_ONLY = re.compile(
    r"export\s+[A-Z_]+=|=1\s+(?:outside|poza)|restart\w*|zrestartuj|uruchom\s+ponownie|"
    r"otw[oó]rz\s+(?:aplikacj|tam)|git\s+push|wypchn\w*|"
    r"credential|has[lł]o|token|keychain|sudo|approve|zatwierd[zź]",
    re.IGNORECASE,
)

HANDOFF_RE = re.compile(HANDOFF, re.IGNORECASE)
OWN_WORK_RE = re.compile(OWN_WORK, re.IGNORECASE)


def load_payload() -> dict[str, Any]:
    try:
        value = json.loads(sys.stdin.read() or "{}")
    except json.JSONDecodeError:
        return {}
    return value if isinstance(value, dict) else {}


def visible_prose(text: str) -> str:
    text = FENCED_CODE_RE.sub(" ", text)
    return INLINE_CODE_RE.sub(" ", text)


def sentences(text: str) -> list[str]:
    return [part for part in re.split(r"(?<=[.!?\n])\s+", text) if part.strip()]


def offending(text: str) -> str | None:
    for sentence in sentences(visible_prose(text)):
        if not HANDOFF_RE.search(sentence):
            continue
        if OPERATOR_ONLY.search(sentence):
            continue
        if OWN_WORK_RE.search(sentence):
            return sentence.strip()
    return None


def main() -> int:
    payload = load_payload()
    message = payload.get("last_assistant_message")
    if not isinstance(message, str):
        # The gate cannot read the message in this payload shape. A gate that
        # cannot see its input must not deny.
        return EXIT_PASS

    sentence = offending(message)
    if sentence is None:
        return EXIT_PASS

    print(json.dumps({
        "decision": "block",
        "reason": (
            "BLOCKED: this hands the agent's own work back to the user. "
            f"Offending sentence: {sentence[:int('240')]} "
            "Nothing in this environment reserves committing, staging, editing "
            "or running local commands for a human. Perform the action, then "
            "report what was done. Defer only what needs operator privilege: "
            "environment variables, application restarts, pushes, credentials."
        ),
    }))
    return EXIT_PASS


if __name__ == "__main__":
    raise SystemExit(main())
