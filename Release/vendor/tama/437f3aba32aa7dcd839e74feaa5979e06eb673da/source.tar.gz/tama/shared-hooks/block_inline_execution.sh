#!/bin/bash
# Stable registry entrypoint; detection lives in the reusable Python module.
set -euo pipefail
exec python3 "$(dirname "$0")/block_inline_execution.py"
