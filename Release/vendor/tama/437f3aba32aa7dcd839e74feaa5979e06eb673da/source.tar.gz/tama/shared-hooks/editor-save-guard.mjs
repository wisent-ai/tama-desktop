#!/usr/bin/env node

import { open, stat } from 'node:fs/promises'
import { spawn } from 'node:child_process'
import { homedir } from 'node:os'
import { extname, resolve } from 'node:path'

const home = homedir()
const runHook = `${home}/.shared-hooks/run-hook.mjs`
const maxPayloadBytes = Number(process.env.WISENT_EDITOR_HOOK_MAX_BYTES || 1024 * 1024)
const allowedExtensions = new Set([
  '.js', '.mjs', '.cjs', '.ts', '.tsx', '.jsx', '.json', '.jsonl', '.yml', '.yaml', '.toml', '.py', '.sh',
  '.swift', '.md', '.mdx', '.sql', '.css', '.scss', '.html', '.ipynb'
])

async function readPrefix(path, bytes) {
  const handle = await open(path, 'r')
  try {
    const buffer = Buffer.alloc(bytes)
    const { bytesRead } = await handle.read(buffer, 0, bytes, 0)
    return buffer.subarray(0, bytesRead)
  } finally {
    await handle.close()
  }
}

const reportOnly = process.argv.includes('--report-only') || process.env.WISENT_EDITOR_HOOK_REPORT_ONLY === '1'
const files = process.argv.filter((arg, index) => index > 1 && arg !== '--report-only')

function usage() {
  return 'Usage: editor-save-guard.mjs [--report-only] <file> [file...]\n'
}

function run(event, payload) {
  return new Promise((resolveGuard) => {
    const child = spawn(process.execPath, [runHook, event], { env: process.env })
    let stdout = ''
    let stderr = ''
    child.stdout.on('data', chunk => { stdout += chunk.toString('utf8') })
    child.stderr.on('data', chunk => { stderr += chunk.toString('utf8') })
    child.on('close', code => {
      let parsed = null
      try { parsed = JSON.parse(stdout.trim() || '{}') } catch {}
      resolveGuard({ event, code, stdout, stderr, parsed })
    })
    child.stdin.end(JSON.stringify(payload))
  })
}

async function payloadFor(file) {
  const path = resolve(file)
  const info = await stat(path)
  if (!info.isFile()) return null
  if (!allowedExtensions.has(extname(path))) return null
  const raw = await readPrefix(path, Math.min(info.size, maxPayloadBytes))
  const truncated = info.size > maxPayloadBytes
  const content = raw.toString('utf8')
  const isNotebook = extname(path) === '.ipynb'
  const toolName = isNotebook ? 'NotebookEdit' : 'Edit'
  return {
    tool_name: toolName,
    tool_input: {
      file_path: path,
      path,
      notebook_path: isNotebook ? path : undefined,
      content,
      new_string: content,
      editor_save_guard: true,
      content_truncated: truncated,
      file_size_bytes: info.size
    }
  }
}

async function checkFile(file) {
  const payload = await payloadFor(file)
  if (!payload) return { file, decision: 'pass', results: [] }
  const events = extname(resolve(file)) === '.ipynb'
    ? ['pre_tool_use:edit', 'pre_tool_use:notebook']
    : ['pre_tool_use:edit']
  const results = []
  for (const event of events) {
    const result = await run(event, payload)
    results.push(result)
    if (result.parsed?.decision === 'block') {
      return { file: resolve(file), decision: reportOnly ? 'report' : 'block', reason: result.parsed.reason, results }
    }
  }
  return { file: resolve(file), decision: 'pass', results }
}

async function main() {
  if (files.length === 0) {
    process.stderr.write(usage())
    process.exit(2)
  }
  const outcomes = []
  for (const file of files) {
    try {
      outcomes.push(await checkFile(file))
    } catch (error) {
      outcomes.push({ file: resolve(file), decision: reportOnly ? 'report' : 'block', reason: error instanceof Error ? error.message : String(error), results: [] })
    }
  }
  const blocked = outcomes.filter(item => item.decision === 'block')
  process.stdout.write(`${JSON.stringify({ reportOnly, outcomes }, null, 2)}\n`)
  process.exit(blocked.length > 0 ? 2 : 0)
}

main().catch(error => {
  process.stderr.write(`${error instanceof Error ? error.stack || error.message : String(error)}\n`)
  process.exit(reportOnly ? 0 : 2)
})
