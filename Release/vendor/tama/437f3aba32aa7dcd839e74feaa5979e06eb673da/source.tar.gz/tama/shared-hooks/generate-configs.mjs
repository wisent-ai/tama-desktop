#!/usr/bin/env node

import { copyFile, readFile, writeFile, mkdir } from 'node:fs/promises'
import { spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { homedir } from 'node:os'
import { dirname, join } from 'node:path'

const home = homedir()
const registryPath = process.env.AGENT_HOOK_REGISTRY || join(home, '.shared-hooks', 'registry.json')
const ompAdapterSource = new URL('./omp-shared-hooks.js', import.meta.url)
const runHookSource = new URL('./run-hook.mjs', import.meta.url)
const sessionControlSource = new URL('./session-control.mjs', import.meta.url)
const apply = process.argv.indexOf('--apply') !== -1
const backup = process.argv.indexOf('--no-backup') === -1

const EVENT_TO_CODEX = {
  stop: { key: 'Stop' },
  user_prompt_submit: { key: 'UserPromptSubmit' },
  'post_tool_use:bash': { key: 'PostToolUse', matcher: 'Bash' },
  'session_start:compact': { key: 'SessionStart', matcher: 'compact' },
  'pre_tool_use:bash': { key: 'PreToolUse', matcher: 'Bash' },
  'pre_tool_use:read': { key: 'PreToolUse', matcher: 'Read' },
  'pre_tool_use:edit': { key: 'PreToolUse', matcher: 'apply_patch|Edit|Write' },
  'pre_tool_use:task': { key: 'PreToolUse', matcher: 'Task|Agent' },
  'pre_tool_use:todo': { key: 'PreToolUse', matcher: 'Todo|todo' },
  'pre_tool_use:goal': { key: 'PreToolUse', matcher: 'Goal|goal' },
  'pre_tool_use:lookup': { key: 'PreToolUse', matcher: 'Grep|grep|Glob|glob|Search|LSP|lsp|AstGrep|ast_grep' },
  'pre_tool_use:notebook': { key: 'PreToolUse', matcher: 'NotebookEdit' },
  'pre_tool_use:wait': { key: 'PreToolUse', matcher: 'Monitor|ScheduleWakeup' },
  'pre_tool_use:eval': { key: 'PreToolUse', matcher: 'Eval|eval|execute_code|mcp__node_repl_js|node_repl/js' },
  'pre_tool_use:ssh': { key: 'PreToolUse', matcher: 'SSH|ssh' },
}


function stamp() {
  return new Date().toISOString().replace(/[:.]/g, '-')
}

function shellQuote(value) {
  return `'${String(value).replaceAll("'", "'\\''")}'`
}

function hookConfig(event, hook, provider) {
  const out = {
    type: hook.type || 'command',
    command: [
      'env',
      `TAMA_PROVIDER=${shellQuote(provider)}`,
      `TAMA_ONLY_HOOK_ID=${shellQuote(hook.id)}`,
      'node \"$HOME/.shared-hooks/run-hook.mjs\"',
      shellQuote(event),
      shellQuote(provider),
    ].join(' '),
  }
  if (hook.timeout) out.timeout = hook.timeout
  if (hook.statusMessage) out.statusMessage = hook.statusMessage
  return out
}

function dispatcherConfig(event, hooks, provider) {
  const out = {
    type: 'command',
    command: [
      'env',
      `TAMA_PROVIDER=${shellQuote(provider)}`,
      'node "$HOME/.shared-hooks/run-hook.mjs"',
      shellQuote(event),
      shellQuote(provider),
    ].join(' '),
  }
  const timeouts = hooks.map(hook => Number(hook.timeout)).filter(Number.isFinite)
  if (timeouts.length > 0) out.timeout = timeouts.reduce((sum, timeout) => sum + timeout)
  return out
}

function addGroup(out, key, matcher, event, hooks, provider) {
  if (hooks.length === 0 && provider !== 'codex') return
  if (!out[key]) out[key] = []
  const configuredHooks = provider === 'codex'
    ? [dispatcherConfig(event, hooks, provider)]
    : hooks.map(hook => hookConfig(event, hook, provider))
  const group = { hooks: configuredHooks }
  if (matcher) group.matcher = matcher
  out[key].push(group)
}

function buildHooks(registry, provider) {
  const out = {}
  const registeredEvents = registry.events || {}
  const events = provider === 'codex'
    ? Object.keys(EVENT_TO_CODEX)
    : Object.keys(registeredEvents)
  for (const event of events) {
    const entry = registeredEvents[event] || {}
    const target = EVENT_TO_CODEX[event]
    if (!target) continue
    addGroup(out, target.key, target.matcher, event, entry.hooks || [], provider)
  }
  return out
}


async function writeText(path, content) {
  await mkdir(dirname(path), { recursive: true })
  if (backup) {
    try { await copyFile(path, `${path}.bak-${stamp()}`) } catch {}
  }
  await writeFile(path, content, 'utf8')
}


async function writeJson(path, data) {
  await mkdir(dirname(path), { recursive: true })
  if (backup) {
    try { await copyFile(path, `${path}.bak-${stamp()}`) } catch {}
  }
  await writeFile(path, `${JSON.stringify(data, null, 2)}\n`, 'utf8')
}

function stableValue(value) {
  if (Array.isArray(value)) return value.map(stableValue)
  if (!value || typeof value !== 'object') return value
  return Object.fromEntries(Object.keys(value).sort().map(key => [key, stableValue(value[key])]))
}

function registryChecksum(registry) {
  const value = { ...registry }
  delete value.catalogChecksum
  return createHash('sha256').update(JSON.stringify(stableValue(value))).digest('hex')
}

function assertRegistryIntegrity(registry) {
  const expected = String(registry.catalogChecksum || '')
  const actual = registryChecksum(registry)
  if (!expected || expected !== actual) {
    throw new Error(
      `Tama hook registry checksum mismatch: expected ${expected || 'missing'}, actual ${actual}. `
      + 'Refusing to generate configs from an unsealed registry; reinstall a sealed Tama release.',
    )
  }
}

function ensureOmpExtension(path) {
  const current = spawnSync('omp', ['config', 'get', 'extensions', '--json'], { encoding: 'utf8' })
  if (current.error) throw current.error
  if (current.status !== 0) throw new Error(current.stderr.trim() || 'could not read OMP extensions')
  const parsed = JSON.parse(current.stdout || '{}')
  const extensions = Array.isArray(parsed.value) ? parsed.value : []
  if (extensions.includes(path)) return { configured: true, changed: false }
  const next = [...extensions, path]
  const update = spawnSync('omp', ['config', 'set', 'extensions', JSON.stringify(next)], { encoding: 'utf8' })
  if (update.error) throw update.error
  if (update.status !== 0) throw new Error(update.stderr.trim() || 'could not register OMP extension')
  return { configured: true, changed: true }
}

async function main() {
  const registry = JSON.parse(await readFile(registryPath, 'utf8'))
  assertRegistryIntegrity(registry)
  const claudeHooks = buildHooks(registry, 'claude')
  const codexHooks = buildHooks(registry, 'codex')
  const codexPath = registry.adapters?.codex?.path || join(home, '.codex', 'hooks.json')
  const claudePath = registry.adapters?.claude?.path || join(home, '.claude', 'settings.json')
  const ompPath = registry.adapters?.omp?.path || join(home, '.shared-hooks', 'omp-shared-hooks.js')

  const codexConfig = { hooks: codexHooks }
  let claudeConfig = {}
  try { claudeConfig = JSON.parse(await readFile(claudePath, 'utf8')) } catch {}
  claudeConfig.hooks = claudeHooks

  if (!apply) {
    process.stdout.write(JSON.stringify({ apply: false, codexPath, claudePath, ompPath, hookEvents: Object.keys(codexHooks) }, null, 2))
    return
  }

  await writeJson(codexPath, codexConfig)
  await writeJson(claudePath, claudeConfig)
  await writeText(ompPath, await readFile(ompAdapterSource, 'utf8'))
  await writeText(join(dirname(ompPath), 'run-hook.mjs'), await readFile(runHookSource, 'utf8'))
  await writeText(join(dirname(ompPath), 'session-control.mjs'), await readFile(sessionControlSource, 'utf8'))
  const ompRegistration = ensureOmpExtension(ompPath)
  process.stdout.write(JSON.stringify({ applied: true, codexPath, claudePath, ompPath, ompRegistration, hookEvents: Object.keys(codexHooks) }, null, 2))
}

main().catch((error) => {
  process.stderr.write(`${error instanceof Error ? error.stack || error.message : String(error)}\n`)
  process.exit(1)
})
