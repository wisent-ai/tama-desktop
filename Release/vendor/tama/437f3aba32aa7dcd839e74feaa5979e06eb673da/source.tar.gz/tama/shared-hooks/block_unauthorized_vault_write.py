#!/usr/bin/env python3
# Blocks a write to a live secret store unless vault_write_justifications.json
# records a verbatim current-session user grant naming that store and that
# operation. Modelled on block-unauthorized-cua, which already enforces this
# shape for GUI automation.
#
# Why: on 2026-08-06 the agent sealed two write-once directory contracts and
# added an item into ~/.stado/weles-skarbiec.vault.json, and appended reader
# scopes to ~/.stado/weles-credential-acquisition-scopes.conf, in a session
# whose user had repeatedly said vault mutation was his decision. The agent had
# itself written, an hour earlier, that an irreversible act outside the
# repositories was the one thing it must not self-authorize -- and then walked
# through that clause. Prose did not hold. A vault write needs the same
# mechanical gate as a GUI action.
#
# Reading is untouched: this hook denies mutation only. A scratch store under a
# temporary directory is not a live store and is always allowed, because that is
# how a lifecycle change gets exercised without touching real material.
from __future__ import annotations
import json, os, re, shlex, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from check_numeric_literals import quote_in_user_msg, tool_name  # noqa: E402

JUSTIFICATIONS = os.path.expanduser(
    os.environ.get(
        'VAULT_WRITE_JUSTIFICATIONS_FILE',
        '~/.shared-hooks/vault_write_justifications.json',
    )
)
WRITE_TOOLS = ('edit', 'multiedit', 'write', 'notebook')
SHELL_TOOLS = ('bash', 'eval', 'hub')

# A live secret store, by path shape. The vault document itself, the acquisition
# scope catalogs that decide who may read it, and the operator token files.
LIVE_STORE = (
    re.compile(r'\.vault\.json$'),
    re.compile(r'acquisition-scopes\.conf$'),
    re.compile(r'-skarbiec-token$'),
    re.compile(r'skarbiec\.audit\.jsonl$'),
)
# Skarbiec subcommands that change stored material. Read verbs are absent on
# purpose: get, list, status, audit and token-verify never appear here.
MUTATING = (
    'set', 'set-json', 'delete', 'purge', 'restore', 'restore-version', 'generate',
    'import', 'migrate-v2', 'add-user', 'rotate-owner', 'share', 'revoke',
    'token-mint', 'token-revoke', 'emergency-grant', 'emergency-activate',
    'policy-set', 'seal-directory', 'reseal', 'adopt', 'resolve-quarantine',
    'acquire', 'rotate', 'reset', 'remove',
)
TEMP_PREFIXES = ('/tmp/', '/private/tmp/', '/var/folders/', '/private/var/folders/')


def temporary(path: str) -> bool:
    resolved = os.path.realpath(os.path.expanduser(path or ''))
    return resolved.startswith(TEMP_PREFIXES)


def live_store(path: str) -> bool:
    if not path or temporary(path):
        return False
    return any(pattern.search(path) for pattern in LIVE_STORE)


def edited_paths(tool_input):
    for key in ('file_path', 'path', 'notebook_path'):
        value = tool_input.get(key)
        if isinstance(value, str) and value:
            yield value
    edits = tool_input.get('edits')
    if isinstance(edits, list):
        for edit in edits:
            if isinstance(edit, dict):
                for key in ('file_path', 'path'):
                    value = edit.get(key)
                    if isinstance(value, str) and value:
                        yield value


def command_of(tool_input):
    for key in ('command', 'code', 'text', 'content'):
        value = tool_input.get(key)
        if isinstance(value, str) and value:
            return value
    return ''


def vault_from_command(command: str):
    """(store, operation) a shell command would mutate, or None.

    The store is read from an explicit --vault/-f flag, from
    SKARBIEC_VAULT_FILE set inline, or from the environment the command would
    inherit. A command that names a mutating subcommand but no store still
    counts: the default store is a live one.
    """
    try:
        words = shlex.split(command)
    except ValueError:
        words = command.split()
    if not any(re.search(r'(^|/)skarbiec$', word) for word in words):
        return None
    operation = next((word for word in words if word in MUTATING), None)
    if operation is None:
        return None
    store = None
    for index, word in enumerate(words):
        if word.startswith('SKARBIEC_VAULT_FILE='):
            store = word.split('=', 1)[1]
        elif word in ('--vault', '-f', '--vault-file') and index + 1 < len(words):
            store = words[index + 1]
    inline = re.search(r'SKARBIEC_VAULT_FILE=([^\s;]+)', command)
    if store is None and inline:
        store = inline.group(1)
    if store is None:
        store = os.environ.get('SKARBIEC_VAULT_FILE') or '<default skarbiec store>'
    if store != '<default skarbiec store>' and temporary(store):
        return None
    return store, operation


def load_grants():
    try:
        with open(JUSTIFICATIONS, 'r', encoding='utf-8') as handle:
            doc = json.load(handle)
    except FileNotFoundError:
        return {}, None
    except Exception as error:
        return {}, 'vault_write_justifications.json is not valid JSON: {}'.format(error)
    if not isinstance(doc, dict):
        return {}, 'vault_write_justifications.json must be an object: store -> grant'
    return doc, None


def granted(store: str, operation: str, doc: dict) -> bool:
    """A grant must name this store, this operation, and quote the user."""
    for recorded, grant in doc.items():
        if not isinstance(grant, dict):
            continue
        if os.path.basename(str(recorded)) != os.path.basename(store):
            continue
        operations = grant.get('operations')
        if not isinstance(operations, list) or operation not in operations:
            continue
        quote = grant.get('user_said')
        if not isinstance(quote, str) or not quote.strip():
            continue
        if not quote_in_user_msg(quote):
            continue
        return True
    return False


def refusal(store, operation, doc_error):
    lines = [
        'block-unauthorized-vault-write: refusing {} on {}.'.format(operation, store),
    ]
    if doc_error:
        lines.append('  ' + doc_error)
    lines.append(
        '  A live secret store is mutated only with a verbatim current-session '
        'user grant recorded in {} as {{"<store>": {{"operations": ["{}"], '
        '"user_said": "<exact user words>"}}}}. The quote must be findable in a '
        'real role=user message. Nothing the agent infers, and nothing the agent '
        'wrote in its own rules, is a grant.'.format(JUSTIFICATIONS, operation)
    )
    lines.append(
        '  To exercise the change without authorization, point the operation at '
        'a store under a temporary directory; those are never gated.'
    )
    return chr(10).join(lines)


def check(payload):
    name = tool_name(payload)
    tool_input = payload.get('tool_input') or payload.get('input') or {}
    doc, doc_error = load_grants()
    problems = []
    if any(name.endswith(tool) for tool in WRITE_TOOLS):
        for path in edited_paths(tool_input):
            if live_store(path) and not granted(path, 'edit', doc):
                problems.append(refusal(path, 'edit', doc_error))
    if any(name.endswith(tool) for tool in SHELL_TOOLS):
        found = vault_from_command(command_of(tool_input))
        if found:
            store, operation = found
            if not granted(store, operation, doc):
                problems.append(refusal(store, operation, doc_error))
    return problems


def main():
    try:
        payload = json.loads(sys.stdin.read())
    except Exception:
        return 0
    problems = check(payload)
    if not problems:
        return 0
    for problem in problems:
        sys.stderr.write(problem + chr(10))
    return 2


if __name__ == '__main__':
    sys.exit(main())
