#!/usr/bin/env python3
# Stop hook. Blocks a final message that claims not to know a value, or asks the
# user to confirm one, when the session never searched the stored transcripts.
#
# Why: on 2026-08-05 the agent invented an email address, built a write-once
# mechanism around it, then declared itself blocked on that address and asked
# the user to confirm it -- three times, across two hours. The answer was in the
# stored transcripts the whole time: the genuine address appeared 7763 times,
# the invention 119, all of them inside the authoring session. One grep would
# have settled it in eleven seconds. It was never run.
#
# The condition is mechanical and both halves are in the payload: blocker
# language in the final message, and the absence of any transcript search among
# the session's tool calls. It does not judge whether the claim is true; it
# refuses to let "I do not know" stand while the cheapest lookup is untried.
from __future__ import annotations
import json, os, re, sys

CLAIM = re.compile(
    r'(?i)('
    r'nie wiem|nie mam pewno|nie jest potwierdz|niepotwierdzon|potrzebuj\w* potwierdz'
    r'|czy to jest|ktor\w+ z nich|musisz mi powiedzie|powiedz mi czy'
    r'|i do not know|i am not sure|cannot confirm|unconfirmed|needs confirmation'
    r'|please confirm|which of the two|only you can tell'
    r')'
)
# A search of the stored transcripts, however spelled.
SEARCHED = re.compile(
    r'(?i)('
    r'\.omp[/\\]agent[/\\]sessions'
    r'|transcript-index\.sqlite'
    r'|sessions_fts'
    r'|history://'
    r')'
)
# `transcript_path` is what the OMP adapter actually supplies on a stop event:
# lifecyclePayload carries only agent_hook_event, runtime, session_id,
# project_dir and raw_event, and runRegistryEvent then lifts a transcript path
# out of the raw event. A stop hook that reads only inline message keys is
# structurally blind in this runtime -- it inspects nothing, finds nothing, and
# passes. That is why a whole family of stop gates never fired.
TRANSCRIPT_KEYS = ('transcript', 'messages', 'session', 'events', 'transcript_path')


def records(payload):
    """Every message-like record the stop payload carries, in order."""
    for key in TRANSCRIPT_KEYS:
        value = payload.get(key)
        if isinstance(value, list):
            for item in value:
                if isinstance(item, dict):
                    yield item
        elif isinstance(value, str) and os.path.isfile(value):
            try:
                with open(value, 'r', encoding='utf-8', errors='replace') as handle:
                    for line in handle:
                        try:
                            yield json.loads(line)
                        except Exception:
                            continue
            except Exception:
                continue


def text_of(record):
    message = record.get('message') if isinstance(record.get('message'), dict) else None
    content = (message or record).get('content')
    parts = []
    if isinstance(content, str):
        parts.append(content)
    elif isinstance(content, list):
        for entry in content:
            if isinstance(entry, dict):
                for key in ('text', 'command', 'pattern', 'path', 'input', 'code'):
                    value = entry.get(key)
                    if isinstance(value, str):
                        parts.append(value)
                    elif isinstance(value, dict):
                        parts.append(json.dumps(value))
    for key in ('command', 'pattern', 'path', 'code', 'input'):
        value = record.get(key)
        if isinstance(value, str):
            parts.append(value)
        elif isinstance(value, dict):
            parts.append(json.dumps(value))
    return chr(10).join(parts)


def final_message(payload):
    for key in ('final_message', 'message', 'assistant_message', 'response'):
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            return value
        if isinstance(value, dict):
            content = value.get('content')
            if isinstance(content, str):
                return content
            if isinstance(content, list):
                return chr(10).join(
                    part.get('text', '') for part in content if isinstance(part, dict)
                )
    last = ''
    for record in records(payload):
        message = record.get('message') if isinstance(record.get('message'), dict) else None
        role = (message.get('role') if message else None) or record.get('role')
        if role != 'assistant':
            continue
        # Only a record that actually carries prose may replace the candidate. An
        # assistant turn is usually a tool call with thinking blocks and no text,
        # and taking the last record unconditionally overwrote the real reply
        # with an empty string -- which made every message look like it claimed
        # nothing and, on the passing side, look like it said nothing wrong.
        spoken = text_of(record)
        if spoken.strip():
            last = spoken
    return last


def searched(payload) -> bool:
    return any(SEARCHED.search(text_of(record)) for record in records(payload))


def check(payload):
    message = final_message(payload)
    if not message:
        return None
    claim = CLAIM.search(message)
    if not claim:
        return None
    if searched(payload):
        return None
    return (
        'block-unsearched-blocker-claim: this message says "{}" but the session '
        'never searched the stored transcripts. Run a search over '
        '~/.omp/agent/sessions before calling a value unknown -- the answer to '
        'the last identity the agent called unconfirmed was sitting there 7763 '
        'times while it asked the user three times instead. A value you have not '
        'looked for is an unchecked lookup, not a blocker.'.format(claim.group())
    )


def main():
    try:
        payload = json.loads(sys.stdin.read())
    except Exception:
        return 0
    problem = check(payload)
    if not problem:
        return 0
    sys.stderr.write(problem + chr(10))
    return 2


if __name__ == '__main__':
    sys.exit(main())
