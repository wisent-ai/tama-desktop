#!/bin/bash
# PreToolUse gate: block writing raw Playwright actions to browser-driving files.
#
# Hardened 2026-05-09 after red-team. Closes:
#   - bracket access page["click"](
#   - whitespace-padded page  .  click  (
#   - optional chain page?.click(
#   - string concat page["cli"+"ck"]
#   - indirection const c = page.click; c.bind/call/apply
#   - setTimeout-in-Promise wait shim
#   - split-string page.evaluate("window.scroll"+"To...")
#   - out-of-scope src/* paths that drive a browser
#   - NotebookEdit tool
#
# Forbidden in any .mjs/.ts/.js that drives Playwright. Bypass via per-line
# `// allow-raw-playwright: <reason>` or HOOK_RAW_PLAYWRIGHT_AUTHORIZED=1.

set -euo pipefail
INPUT=$(cat)
TOOL=$(echo "$INPUT" | jq -r '.tool_name // empty')
FILE_PATH=$(echo "$INPUT" | jq -r '.tool_input.file_path // .tool_input.notebook_path // empty')

if [[ -z "$FILE_PATH" ]]; then exit 0; fi
if [[ "${HOOK_RAW_PLAYWRIGHT_AUTHORIZED:-}" == "1" ]]; then exit 0; fi

# Scope: any .mjs/.ts/.js OR notebook (.ipynb) under any weles/.work path or
# any path containing 'playwright' / 'puppeteer' / 'wsession' / 'browser' is
# considered browser-driving. We err on inclusive — out-of-scope code can
# add the bypass comment.
case "$FILE_PATH" in
  *.mjs|*.ts|*.js|*.ipynb) ;;
  *) exit 0 ;;
esac

# Watched roots. Widened from the v1 list — any weles/* path now covered,
# and content-platform's .work/ subtree.
INSCOPE=0
case "$FILE_PATH" in
  */weles/*) INSCOPE=1 ;;
  */content-platform/.work/*) INSCOPE=1 ;;
  */content-platform/scripts/*) INSCOPE=1 ;;
esac
[[ "$INSCOPE" == "0" ]] && exit 0

# Get the new content.
case "$TOOL" in
  Write|NotebookEdit)
        CONTENT=$(echo "$INPUT" | jq -r '.tool_input.content // .tool_input.new_source // empty') ;;
  Edit) CONTENT=$(echo "$INPUT" | jq -r '.tool_input.new_string // empty') ;;
  Create|ApplyPatch)
        CONTENT=$(echo "$INPUT" | jq -r '.tool_input.new_string // .tool_input.content // .tool_input.patch // empty') ;;
  *) exit 0 ;;
esac
[[ -z "$CONTENT" ]] && exit 0

# Strip per-line opt-out lines.
NO_OPTOUT=$(echo "$CONTENT" | grep -v 'allow-raw-playwright' || true)
# Collapse whitespace within (but preserve newlines, since some checks are
# multi-line). We replace spaces around operators in a copy used for regex.
SQUASHED=$(echo "$NO_OPTOUT" | tr -s ' \t')

VIOLATIONS=()
flag() { VIOLATIONS+=("$1"); }

# --- Direct page.* methods (with whitespace + optional-chain tolerance) ---
RE_DOT='page[[:space:]]*\??\.[[:space:]]*'
for m in click fill type dblclick tap tap press_enter; do
    if echo "$SQUASHED" | grep -qE "${RE_DOT}${m}[[:space:]]*\("; then
        flag "page.${m}(...) — use humanized atom (humanClick/humanFill/humanType)"
    fi
done

# --- Bracket-access page["click"]( and "cl"+"ick" concat ---
# Match page[ ... ]( where the bracket contents include the method name as a
# string literal possibly split by + concatenation.
for m in click fill type dblclick tap; do
    # plain bracket: page["click"]( or page['click'](
    if echo "$SQUASHED" | grep -qE "page[[:space:]]*\[[[:space:]]*['\"]${m}['\"][[:space:]]*\][[:space:]]*\("; then
        flag "page[\"${m}\"](...) — use humanized atom"
    fi
done
# split-string concat: detect any page[ ... + ... ] where the joined
# letters spell click/fill/type/dblclick. Just flag any page[...+...](.
if echo "$SQUASHED" | grep -qE "page[[:space:]]*\[[^]]*\+[^]]*\][[:space:]]*\("; then
    flag "page[<concatenated string>](...) — string-concat method access; use humanized atom"
fi

# --- locator(...).click() / .fill() / .type() ---
for m in click fill type; do
    if echo "$SQUASHED" | grep -qE "\.locator\([^)]*\)[[:space:]]*\.[[:space:]]*${m}[[:space:]]*\("; then
        flag "locator(...).${m}(...) — use humanized atom"
    fi
done

# --- Indirection: aliasing page.click ---
# const|let|var X = page.click
if echo "$SQUASHED" | grep -qE "(const|let|var)[[:space:]]+[A-Za-z_$][A-Za-z0-9_$]*[[:space:]]*=[[:space:]]*${RE_DOT}(click|fill|type|dblclick|tap)"; then
    flag "Aliasing page.click via const/let/var — bot signal still emitted; use humanized atom"
fi
# .bind / .call / .apply on page.click
if echo "$SQUASHED" | grep -qE "${RE_DOT}(click|fill|type|dblclick|tap)[[:space:]]*\.[[:space:]]*(bind|call|apply)[[:space:]]*\("; then
    flag "page.click.bind/.call/.apply — use humanized atom"
fi

# --- Fixed-cadence sleeps ---
if echo "$SQUASHED" | grep -qE "${RE_DOT}waitForTimeout[[:space:]]*\("; then
    flag "page.waitForTimeout(...) — use humanIdlePause"
fi
# new Promise(r => setTimeout(r, N)) — the wait shim. Allowed only if same
# line carries the opt-out (already stripped above).
if echo "$SQUASHED" | grep -qE "new[[:space:]]+Promise[[:space:]]*\([^)]*setTimeout"; then
    flag 'new Promise(r => setTimeout(r, N)) — fixed-cadence sleep; use humanIdlePause'
fi

# --- page.evaluate that touches click/scroll/dispatchEvent ---
# Conservative: any page.evaluate body containing those tokens.
# Match across multiple lines via tr collapse.
ONELINE=$(echo "$NO_OPTOUT" | tr '\n' ' ')
# page.evaluate that takes a STRING argument (rare, almost always
# string-concat bypass). Allow only function-form evaluate.
# Match: page.evaluate( "..." or page.evaluate( '...' or page.evaluate( `...`
if echo "$ONELINE" | grep -qE "page[[:space:]]*\??\.[[:space:]]*evaluate[[:space:]]*\([[:space:]]*['\"\`]"; then
    flag 'page.evaluate(string) — string-form invites concat-bypass; use evaluate(() => ...) and humanized atoms instead'
fi
# Conservative co-occurrence check: if any page.evaluate( appears AND
# any DOM interaction token (.click(), .dispatchEvent, scrollTo, .submit(),
# .focus(), .blur()) appears anywhere in the file, flag. This is a
# false-positive risk on data-extraction code that incidentally mentions
# ".click(" in a comment, but for a security gate conservative is fine.
if echo "$ONELINE" | grep -qE "page[[:space:]]*\??\.[[:space:]]*evaluate[[:space:]]*\("; then
    if echo "$ONELINE" | grep -qE "(\.click\(\)|\.dispatchEvent|scrollTo|\.submit\(\)|\.focus\(\)|\.blur\(\))"; then
        flag 'page.evaluate(...) co-occurs with .click()/.dispatchEvent/scrollTo/.submit/.focus/.blur — likely a DOM-interaction bypass; use humanClick/humanScroll/humanType'
    fi
fi
if echo "$SQUASHED" | grep -qE "dispatchEvent[[:space:]]*\([[:space:]]*new[[:space:]]+(MouseEvent|PointerEvent|KeyboardEvent)"; then
    flag 'dispatchEvent(new MouseEvent/PointerEvent/KeyboardEvent) — isTrusted=false; use humanized atom'
fi
if echo "$ONELINE" | grep -qE "page[[:space:]]*\.[[:space:]]*evaluate[[:space:]]*\([^)]*dispatchEvent"; then
    flag 'dispatchEvent inside page.evaluate — isTrusted=false; use humanized atom'
fi

# --- Keyboard direct (entropy-less) ---
if echo "$SQUASHED" | grep -qE "${RE_DOT}keyboard[[:space:]]*\.[[:space:]]*type[[:space:]]*\("; then
    flag 'page.keyboard.type(...) — use humanType'
fi

# --- Function/eval string-form bypass ---
if echo "$SQUASHED" | grep -qE "(eval|new[[:space:]]+Function)[[:space:]]*\([^)]*page[[:space:]]*\."; then
    flag "eval/new Function constructing page.* call — forbidden indirection"
fi

# --- osascript / cliclick / screencapture for browser automation ---
if echo "$SQUASHED" | grep -qE "spawn(Sync)?[[:space:]]*\([^)]*['\"]osascript['\"]"; then
    flag 'spawn osascript for browser automation — use weles humanized atoms'
fi
if echo "$SQUASHED" | grep -qE "['\"]cliclick['\"]"; then
    flag "cliclick reference — forbidden"
fi

if [[ ${#VIOLATIONS[@]} -gt 0 ]]; then
    echo "BLOCKED: raw Playwright / non-humanized browser action in $FILE_PATH" >&2
    echo "" >&2
    for v in "${VIOLATIONS[@]}"; do echo "  - $v" >&2; done
    echo "" >&2
    echo "Why: bot classifiers (LinkedIn, TikTok, reCAPTCHA Enterprise, Arkose, hCaptcha)" >&2
    echo "read event.isTrusted, scroll cadence, and click timing. Raw page.* actions emit" >&2
    echo "isTrusted=false or fixed cadence and get classified as bot." >&2
    echo "" >&2
    echo "Use the humanized atoms from weles/src/human/:" >&2
    echo "  humanClick(page, x, y) / humanClickLocator(page, locator)" >&2
    echo "  humanFill(page, locator, text)" >&2
    echo "  humanType(page, text)" >&2
    echo "  humanScroll(page, deltaY, bursts)" >&2
    echo "  humanIdlePause('short' | 'deliberate' | 'long')" >&2
    echo "  humanMove(page, x, y)" >&2
    echo "" >&2
    echo "Per-call bypass: append '// allow-raw-playwright: <reason>' on the same line." >&2
    echo "Whole-call bypass: HOOK_RAW_PLAYWRIGHT_AUTHORIZED=1." >&2
    exit 2
fi

exit 0
