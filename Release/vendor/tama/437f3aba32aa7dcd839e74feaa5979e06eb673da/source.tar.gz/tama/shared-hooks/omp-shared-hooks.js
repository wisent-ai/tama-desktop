import { spawn } from 'node:child_process'
import { looksLikeMalfunction, tokenizeCommand } from './hook-exec.mjs'
import {
  appendFileSync,
  chmodSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  renameSync,
  rmSync,
  writeFileSync,
} from 'node:fs'
import { createHash, randomUUID } from 'node:crypto'
import { homedir } from 'node:os'
import { basename, dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import {
  CAPABILITY_SCHEMA_VERSION,
  capabilityEnvironment,
  normalizeCapabilityGrants,
  normalizedCapability,
} from './session-capability.mjs'
import { sessionResumeArgv } from './session-control.mjs'

const SHARED_HOOKS_ROOT = dirname(fileURLToPath(import.meta.url))
const REGISTRY_PATH = process.env.AGENT_HOOK_REGISTRY || join(SHARED_HOOKS_ROOT, 'registry.json')
const SESSION_OVERRIDE_TOOL = 'tama_set_session_hook'
const SESSION_ENABLE_ALL_TOOL = 'tama_enable_all_session_hooks'
const SESSION_CAPABILITY_TOOL = 'tama_request_session_capability'
const RUNTIME_RELOAD_TOOL = 'tama_reload_hook_runtime'
const RUNTIME_STATUS_TOOL = 'tama_hook_runtime_status'
const CONTROL_PLANE_TOOLS = new Set([
  SESSION_OVERRIDE_TOOL,
  SESSION_ENABLE_ALL_TOOL,
  SESSION_CAPABILITY_TOOL,
  RUNTIME_RELOAD_TOOL,
  RUNTIME_STATUS_TOOL,
])
const SESSION_OVERRIDE_ENTRY = 'tama:session-hook-overrides'
const SESSION_CONTROL_SCHEMA = 'ai.wisent.tama.session-control.v2'
const EMERGENCY_STATE_SCHEMA = 'ai.wisent.tama.hook-emergency-state.v1'
const HOOK_TIMEOUT_MS = 10000
const SESSION_CONTROL_POLL_MS = 250
const ACTIVATION_PREFLIGHT_HOOK_IDS = new Set(['block-objective-substitution'])
const emergencyStatePath = process.env.TAMA_EMERGENCY_STATE || join(
  homedir(),
  'Library',
  'Application Support',
  'Tama',
  'hook-emergency-state.json',
)
const sessionControlRoot = process.env.TAMA_SESSION_CONTROL_ROOT || join(
  homedir(),
  'Library',
  'Application Support',
  'Tama',
  'session-control',
)
const installedStatePath = process.env.TAMA_INSTALLED_HOOK_RELEASE || join(
  homedir(),
  'Library',
  'Application Support',
  'Tama',
  'hooks-runtime',
  'installed.json',
)

function loadJson(path, fallback) {
  try {
    return JSON.parse(readFileSync(path, 'utf8'))
  } catch {
    return fallback
  }
}

function stableValue(value) {
  if (Array.isArray(value)) return value.map(stableValue)
  if (!value || typeof value !== 'object') return value
  return Object.fromEntries(Object.keys(value).sort().map(key => [key, stableValue(value[key])]))
}

function registryChecksum(registry) {
  const value = { ...registry }
  delete value.catalogChecksum
  return createHash('sha256').update(JSON.stringify(stableValue(value))).digest('hex')
}

function registrySnapshot() {
  const registry = loadJson(REGISTRY_PATH, null)
  if (!registry || typeof registry !== 'object' || Array.isArray(registry)) {
    throw new Error(`Invalid Tama hook registry: ${REGISTRY_PATH}`)
  }
  if (!registry.events || typeof registry.events !== 'object' || Array.isArray(registry.events)) {
    throw new Error('Tama hook registry has no events object')
  }
  const expectedChecksum = String(registry.catalogChecksum || '')
  const actualChecksum = registryChecksum(registry)
  if (!expectedChecksum || expectedChecksum !== actualChecksum) {
    throw new Error(`Tama hook registry checksum mismatch: expected ${expectedChecksum || 'missing'}, actual ${actualChecksum}`)
  }
  const hookIds = new Set()
  for (const entry of Object.values(registry.events)) {
    if (!entry || !Array.isArray(entry.hooks)) continue
    for (const hook of entry.hooks) {
      const id = String(hook?.id || '').trim()
      if (id) hookIds.add(id)
    }
  }
  return {
    registry,
    hookIds,
    releaseId: String(registry.releaseId || 'unknown'),
    catalogChecksum: actualChecksum,
  }
}

let loadedRegistry = { events: {} }
let knownHookIds = new Set()
let loadedReleaseId = 'unknown'
let loadedCatalogChecksum = null
let registryLoadError = null
let runtimeStartedAt = new Date().toISOString()
let reloadCount = 0
let lastReloadAt = null
let lastReloadError = null
let pendingRuntimeReload = null
let lastDecision = null

function installRegistrySnapshot(snapshot) {
  loadedRegistry = snapshot.registry
  knownHookIds = snapshot.hookIds
  loadedReleaseId = snapshot.releaseId
  loadedCatalogChecksum = snapshot.catalogChecksum
  registryLoadError = null
}

try {
  installRegistrySnapshot(registrySnapshot())
} catch (error) {
  registryLoadError = error instanceof Error ? error.message : String(error)
}

function hooksGloballyDisabled() {
  const state = loadJson(emergencyStatePath, null)
  return state?.schema === EMERGENCY_STATE_SCHEMA && state.disabled === true
}

function installedReleaseState() {
  const value = loadJson(installedStatePath, {})
  return {
    releaseId: typeof value.releaseId === 'string' ? value.releaseId : null,
    catalogChecksum: typeof value.catalogChecksum === 'string' ? value.catalogChecksum : null,
    installedAt: typeof value.installedAt === 'string' ? value.installedAt : null,
  }
}

let currentSessionId = null
let currentSessionKey = null
let currentSessionCwd = null
let currentSessionContext = null
let disabledHookIds = new Set()
let enabledHookIds = new Set()
let unknownHookIds = new Set()
let currentCapability = null
let sessionControlTimer = null
let sessionControlStatePath = null
let sessionControlOverridePath = null
let exitCleanupRegistered = false

function resolvedSessionId(event, ctx) {
  const explicit = event?.sessionId || event?.session_id || event?.session?.id
  if (explicit) return String(explicit)
  const sessionFile = ctx?.sessionManager?.getSessionFile?.()
  if (!sessionFile) return null
  const name = basename(String(sessionFile), '.jsonl')
  const separator = name.lastIndexOf('_')
  return separator >= 0 ? name.slice(separator + 1) : name
}

function capabilityIdentity(controlKey = currentSessionKey) {
  return { controlKey, releaseId: loadedReleaseId, catalogChecksum: loadedCatalogChecksum }
}

function sanitizedIds(values) {
  const known = []
  for (const value of Array.isArray(values) ? values : []) {
    const id = String(value || '').trim()
    if (!id) continue
    if (knownHookIds.has(id)) known.push(id)
    else unknownHookIds.add(id)
  }
  return [...new Set(known)].sort()
}

function sanitizedDisabledIds(_values) {
  return []
}

function restoredHookOverrides(ctx, activeSessionId) {
  let restored = { disabledHookIds: [], enabledHookIds: [], capability: null }
  if (!activeSessionId || hooksGloballyDisabled()) return restored
  for (const entry of ctx?.sessionManager?.getBranch?.() || []) {
    if (entry?.type !== 'custom' || entry.customType !== SESSION_OVERRIDE_ENTRY) continue
    if (entry.data?.sessionId !== activeSessionId) continue
    restored = {
      disabledHookIds: entry.data.disabledHookIds,
      enabledHookIds: entry.data.enabledHookIds,
      capability: entry.data.capability,
    }
  }
  return {
    disabledHookIds: sanitizedDisabledIds(restored.disabledHookIds),
    enabledHookIds: sanitizedIds(restored.enabledHookIds),
    capability: normalizedCapability(
      restored.capability,
      activeSessionId,
      Date.now(),
      capabilityIdentity(sessionControlKey(activeSessionId)),
    ),
  }
}

function sessionControlKey(activeSessionId) {
  return createHash('sha256').update(`omp\0${String(activeSessionId)}`).digest('hex')
}

function atomicWriteJson(path, value) {
  mkdirSync(sessionControlRoot, { recursive: true, mode: 0o700 })
  chmodSync(sessionControlRoot, 0o700)
  const temporary = `${path}.${process.pid}.${randomUUID()}.tmp`
  try {
    writeFileSync(temporary, `${JSON.stringify(value)}\n`, { mode: 0o600, flag: 'wx' })
    renameSync(temporary, path)
  } finally {
    rmSync(temporary, { force: true })
  }
}

function overrideState() {
  currentCapability = normalizedCapability(
    currentCapability,
    currentSessionId,
    Date.now(),
    capabilityIdentity(),
  )
  return {
    disabledHookIds: [...disabledHookIds].sort(),
    enabledHookIds: [...enabledHookIds].sort(),
    capability: currentCapability,
  }
}

function appendOverrideEntry(pi) {
  const overrides = overrideState()
  pi.appendEntry(SESSION_OVERRIDE_ENTRY, {
    sessionId: currentSessionId,
    disabledHookIds: overrides.disabledHookIds,
    enabledHookIds: overrides.enabledHookIds,
    capability: overrides.capability,
  })
  return overrides
}

function externalOverrideState() {
  if (!currentSessionId || !currentSessionKey || !sessionControlOverridePath) return null
  if (hooksGloballyDisabled()) return null
  const value = loadJson(sessionControlOverridePath, null)
  if (
    value?.schema !== SESSION_CONTROL_SCHEMA
    || value.agentId !== 'omp'
    || value.sessionId !== currentSessionId
    || value.controlKey !== currentSessionKey
    || value.releaseId !== loadedReleaseId
    || value.catalogChecksum !== loadedCatalogChecksum
  ) return null
  return {
    disabledHookIds: sanitizedDisabledIds(value.disabledHookIds),
    enabledHookIds: sanitizedIds(value.enabledHookIds),
    capability: normalizedCapability(
      value.capability,
      currentSessionId,
      Date.now(),
      capabilityIdentity(),
    ),
  }
}

function writeExternalOverride(identity = capabilityIdentity()) {
  if (!currentSessionId || !currentSessionKey || !sessionControlOverridePath) return
  const overrides = overrideState()
  atomicWriteJson(sessionControlOverridePath, {
    schema: SESSION_CONTROL_SCHEMA,
    agentId: 'omp',
    sessionId: currentSessionId,
    controlKey: currentSessionKey,
    releaseId: identity.releaseId,
    catalogChecksum: identity.catalogChecksum,
    disabledHookIds: overrides.disabledHookIds,
    enabledHookIds: overrides.enabledHookIds,
    capability: overrides.capability,
    updatedAt: new Date().toISOString(),
  })
}

function synchronizeExternalOverrides(pi) {
  const external = externalOverrideState()
  if (!external) return false
  const current = overrideState()
  if (
    JSON.stringify(current.disabledHookIds) === JSON.stringify(external.disabledHookIds)
    && JSON.stringify(current.enabledHookIds) === JSON.stringify(external.enabledHookIds)
    && JSON.stringify(current.capability) === JSON.stringify(external.capability)
  ) return false
  disabledHookIds = new Set(external.disabledHookIds)
  enabledHookIds = new Set(external.enabledHookIds)
  currentCapability = external.capability
  appendOverrideEntry(pi)
  return true
}

function activeHookCount() {
  return hooksGloballyDisabled() ? 0 : knownHookIds.size
}

function runtimeStatus() {
  const installed = installedReleaseState()
  const globallyDisabled = hooksGloballyDisabled()
  const disabled = [...disabledHookIds].sort()
  const enabled = [...enabledHookIds].sort()
  const reloadRequired = Boolean(
    registryLoadError
    || !installed.releaseId
    || installed.releaseId !== loadedReleaseId
    || (installed.catalogChecksum && installed.catalogChecksum !== loadedCatalogChecksum),
  )
  return {
    schemaVersion: 1,
    sessionId: currentSessionId,
    controlKey: currentSessionKey,
    installedReleaseId: installed.releaseId,
    loadedReleaseId,
    installedCatalogChecksum: installed.catalogChecksum,
    catalogChecksum: loadedCatalogChecksum,
    registeredHookCount: knownHookIds.size,
    loadedHookCount: activeHookCount(),
    globallyDisabled,
    disabledHookIds: disabled,
    enabledHookIds: enabled,
    unknownHookIds: [...unknownHookIds].sort(),
    capability: currentCapability,
    reloadRequired,
    reloadPending: Boolean(pendingRuntimeReload),
    pendingReloadCommand: pendingRuntimeReload?.command || null,
    registryLoadError,
    runtimeStartedAt,
    reloadCount,
    lastReloadAt,
    lastReloadError,
    lastDecision,
    updatedAt: new Date().toISOString(),
  }
}

function publishedSessionState() {
  const overrides = overrideState()
  const resumeArgv = sessionResumeArgv()
  return {
    schema: SESSION_CONTROL_SCHEMA,
    agentId: 'omp',
    sessionId: currentSessionId,
    controlKey: currentSessionKey,
    pid: process.pid,
    cwd: currentSessionCwd || process.cwd(),
    livenessMode: 'process',
    globallyDisabled: hooksGloballyDisabled(),
    disabledHookIds: overrides.disabledHookIds,
    enabledHookIds: overrides.enabledHookIds,
    capability: overrides.capability,
    ...(resumeArgv ? { resumeArgv } : {}),
    runtime: runtimeStatus(),
    updatedAt: new Date().toISOString(),
  }
}

function publishSessionState() {
  if (!currentSessionId || !currentSessionKey || !sessionControlStatePath) return
  atomicWriteJson(sessionControlStatePath, publishedSessionState())
}

function persistOverrides(pi, identity = capabilityIdentity()) {
  const overrides = appendOverrideEntry(pi)
  writeExternalOverride(identity)
  publishSessionState()
  return overrides
}

function applySessionHookOverride(pi, hookId, enabled) {
  if (!enabled) {
    return {
      changed: false,
      accepted: false,
      reason: 'session-hook-disablement-prohibited',
      sessionId: currentSessionId,
      hookId,
      enabled: true,
      globallyDisabled: hooksGloballyDisabled(),
      ...overrideState(),
    }
  }
  const globallyDisabled = hooksGloballyDisabled()
  const changed = globallyDisabled ? !enabledHookIds.has(hookId) : disabledHookIds.has(hookId)
  if (globallyDisabled) enabledHookIds.add(hookId)
  else disabledHookIds.delete(hookId)
  const overrides = changed ? persistOverrides(pi) : overrideState()
  return {
    changed,
    accepted: true,
    sessionId: currentSessionId,
    hookId,
    enabled,
    globallyDisabled,
    ...overrides,
  }
}

function applyEnableAllSessionHooks(pi, hookIds = knownHookIds) {
  disabledHookIds.clear()
  enabledHookIds = hooksGloballyDisabled() ? new Set(hookIds) : new Set()
  const overrides = persistOverrides(pi)
  return {
    changed: true,
    sessionId: currentSessionId,
    globallyDisabled: hooksGloballyDisabled(),
    ...overrides,
  }
}

function applySessionCapability(pi, grants, lifetime, expiresAt = null) {
  const capability = {
    schemaVersion: CAPABILITY_SCHEMA_VERSION,
    issuedBy: 'tama:omp-interactive-approval',
    nonce: randomUUID(),
    sessionId: currentSessionId,
    controlKey: currentSessionKey,
    releaseId: loadedReleaseId,
    catalogChecksum: loadedCatalogChecksum,
    lifetime,
    grants,
  }
  if (lifetime === 'expires-at') capability.expiresAt = new Date(Date.parse(expiresAt)).toISOString()
  if (lifetime === 'single-use') capability.remainingUses = 1
  currentCapability = capability
  const overrides = persistOverrides(pi)
  return { changed: true, sessionId: currentSessionId, capability: overrides.capability }
}

function consumeSingleUseCapability(pi) {
  if (currentCapability?.lifetime !== 'single-use') return false
  currentCapability = null
  persistOverrides(pi)
  return true
}

async function processSessionControlRequests(pi) {
  if (synchronizeExternalOverrides(pi)) publishSessionState()
  if (!currentSessionId || !currentSessionKey) return
  let names
  try {
    names = readdirSync(sessionControlRoot)
  } catch {
    return
  }
  const prefix = `${currentSessionKey}.`
  for (const name of names) {
    if (!name.startsWith(prefix) || !name.endsWith('.request.json')) continue
    const requestPath = join(sessionControlRoot, name)
    const responsePath = join(sessionControlRoot, name.replace(/\.request\.json$/, '.response.json'))
    const request = loadJson(requestPath, null)
    rmSync(requestPath, { force: true })
    let response
    const validEnvelope = request?.schema === SESSION_CONTROL_SCHEMA
      && request.sessionId === currentSessionId
      && request.controlKey === currentSessionKey
      && typeof request.requestId === 'string'
      && request.confirmed === true
    if (!validEnvelope) {
      response = {
        schema: SESSION_CONTROL_SCHEMA,
        requestId: request?.requestId || null,
        ok: false,
        error: 'invalid-session-control-request',
      }
    } else if (request.operation === 'enable-all') {
      const preflight = await preflightSessionHooks(knownHookIds)
      const details = preflight.accepted
        ? scheduleNativeControlReload(pi, currentSessionContext, SESSION_ENABLE_ALL_TOOL)
        : { accepted: false, changed: false, error: preflight.reason }
      const accepted = details.accepted === true
      response = {
        schema: SESSION_CONTROL_SCHEMA,
        requestId: request.requestId,
        ok: accepted,
        changed: details.changed,
        error: accepted ? null : (details.error || 'reload-not-scheduled'),
        command: details.command,
        state: loadJson(sessionControlStatePath, null) || publishedSessionState(),
      }
    } else if (request.operation === 'set-hook') {
      const id = typeof request.hookId === 'string' ? request.hookId.trim() : ''
      if (!knownHookIds.has(id) || typeof request.enabled !== 'boolean') {
        response = {
          schema: SESSION_CONTROL_SCHEMA,
          requestId: request.requestId,
          ok: false,
          error: knownHookIds.has(id) ? 'invalid-hook-state' : `unknown-hook:${id}`,
        }
      } else {
        const preflight = request.enabled
          ? await preflightSessionHook(id)
          : { accepted: true }
        const details = preflight.accepted
          ? applySessionHookOverride(pi, id, request.enabled)
          : { accepted: false, changed: false, reason: preflight.reason }
        const accepted = details.accepted === true
        response = {
          schema: SESSION_CONTROL_SCHEMA,
          requestId: request.requestId,
          ok: accepted,
          changed: details.changed,
          error: accepted ? null : (details.reason || 'hook-enable-not-applied'),
          state: publishedSessionState(),
        }
      }
    } else {
      response = {
        schema: SESSION_CONTROL_SCHEMA,
        requestId: request.requestId,
        ok: false,
        error: `unsupported-operation:${request.operation}`,
      }
    }
    atomicWriteJson(responsePath, response)
  }
}

function stopSessionControl() {
  clearInterval(sessionControlTimer)
  sessionControlTimer = null
  if (sessionControlStatePath) rmSync(sessionControlStatePath, { force: true })
  sessionControlStatePath = null
  sessionControlOverridePath = null
  currentSessionKey = null
  currentSessionCwd = null
  currentSessionContext = null
}

function startSessionControl(pi, event, ctx) {
  stopSessionControl()
  if (!currentSessionId) return
  currentSessionKey = sessionControlKey(currentSessionId)
  currentSessionCwd = event?.cwd || ctx?.cwd || process.cwd()
  currentSessionContext = ctx
  sessionControlStatePath = join(sessionControlRoot, `${currentSessionKey}.session.json`)
  sessionControlOverridePath = join(sessionControlRoot, `${currentSessionKey}.override.json`)
  synchronizeExternalOverrides(pi)
  publishSessionState()
  sessionControlTimer = setInterval(() => {
    processSessionControlRequests(pi).catch(error => {
      lastReloadError = error instanceof Error ? error.message : String(error)
      publishSessionState()
    })
  }, SESSION_CONTROL_POLL_MS)
  sessionControlTimer.unref()
  if (!exitCleanupRegistered) {
    exitCleanupRegistered = true
    process.once('exit', () => {
      if (sessionControlStatePath) rmSync(sessionControlStatePath, { force: true })
    })
  }
}

function activateSession(pi, event, ctx) {
  currentSessionId = resolvedSessionId(event, ctx)
  unknownHookIds = new Set()
  const restored = restoredHookOverrides(ctx, currentSessionId)
  disabledHookIds = new Set(restored.disabledHookIds)
  enabledHookIds = new Set(restored.enabledHookIds)
  currentCapability = restored.capability
  startSessionControl(pi, event, ctx)
}

function sessionId(event) {
  return event?.sessionId || event?.session_id || event?.session?.id || currentSessionId || null
}

function toolName(event) {
  return String(event?.toolName || event?.name || '')
}

function toolInput(event) {
  const value = event?.input || event?.params || null
  return value && typeof value === 'object' && !Array.isArray(value) ? value : {}
}

function hookPayload(event) {
  const name = toolName(event)
  const input = toolInput(event)
  return {
    agent_hook_event: 'tool_call',
    runtime: 'omp',
    session_id: sessionId(event),
    project_dir: event?.cwd || process.cwd(),
    control_key: currentSessionKey,
    release_id: loadedReleaseId,
    catalog_checksum: loadedCatalogChecksum,
    tool_name: name,
    tool_input: input,
    tool: { name, input },
  }
}

function lifecyclePayload(eventName, event = {}, extra = {}) {
  return {
    agent_hook_event: eventName,
    runtime: 'omp',
    session_id: sessionId(event),
    project_dir: event?.cwd || process.cwd(),
    raw_event: event,
    ...extra,
  }
}

function registryEvent(name) {
  const normalized = String(name).toLowerCase()
  if (normalized === 'read') return 'pre_tool_use:read'
  if (normalized === 'notebookedit' || normalized === 'notebook') return 'pre_tool_use:notebook'
  if (normalized === 'multiedit') return 'pre_tool_use:multiedit'
  if (normalized === 'write' || normalized === 'edit' || normalized === 'apply_patch') return 'pre_tool_use:edit'
  if (normalized === 'bash') return 'pre_tool_use:bash'
  if (normalized === 'monitor' || normalized === 'schedulewakeup') return 'pre_tool_use:wait'
  if (normalized === 'task' || normalized === 'agent') return 'pre_tool_use:task'
  if (normalized === 'todo') return 'pre_tool_use:todo'
  if (normalized === 'goal') return 'pre_tool_use:goal'
  if (normalized === 'ask' || normalized.endsWith('.ask') || normalized.endsWith('/ask') || normalized.endsWith('_ask')) return 'pre_tool_use:ask'
  if (normalized === 'ssh') return 'pre_tool_use:ssh'
  if (normalized === 'grep' || normalized === 'glob' || normalized === 'lsp' || normalized === 'ast_edit') return 'pre_tool_use:lookup'
  return 'pre_tool_use:eval'
}

function registryPostEvent(name) {
  return registryEvent(name).replace('pre_tool_use:', 'post_tool_use:')
}

function expandHome(command) {
  return String(command).replace(/~(?=\/|$)/g, homedir()).replace(/\$HOME/g, homedir())
}

function decisionFromOutput(text) {
  const trimmed = String(text || '').trim()
  if (!trimmed) return null
  try {
    const parsed = JSON.parse(trimmed)
    if (parsed && typeof parsed === 'object' && parsed.decision === 'block') {
      return parsed.reason || 'hook returned block decision'
    }
  } catch {}
  return null
}

function runHookCommand(hook, payload) {
  return new Promise(resolve => {
    const [program, ...args] = tokenizeCommand(expandHome(hook.command))
    if (!program) {
      resolve({ code: null, signal: null, timedOut: false, stdout: '', stderr: 'empty hook command', spawnError: true })
      return
    }
    // No shell: registry commands are argv, so a registry write cannot smuggle
    // shell syntax into every tool call.
    const child = spawn(program, args, {
      env: capabilityEnvironment(currentCapability, { TAMA_PROVIDER: 'omp' }),
    })
    let stdout = ''
    let stderr = ''
    let timedOut = false
    let settled = false
    const finish = result => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      resolve(result)
    }
    const timeoutMs = Math.max(1, Number(hook.timeout || 10)) * 1000
    const timer = setTimeout(() => {
      timedOut = true
      child.kill('SIGTERM')
    }, timeoutMs)
    child.stdout.on('data', chunk => { stdout += chunk.toString('utf8') })
    child.stderr.on('data', chunk => { stderr += chunk.toString('utf8') })
    child.stdin.on('error', error => { stderr += error instanceof Error ? error.message : String(error) })
    child.on('error', error => finish({ code: null, signal: null, timedOut, stdout, stderr: error.message, spawnError: true }))
    child.on('close', (code, signal) => finish({ code, signal, timedOut, stdout, stderr }))
    child.stdin.end(JSON.stringify(payload))
  })
}

function registeredHook(hookId, registry = loadedRegistry) {
  for (const entry of Object.values(registry.events || {})) {
    if (!entry || !Array.isArray(entry.hooks)) continue
    const hook = entry.hooks.find(candidate => String(candidate?.id || '') === hookId)
    if (hook) return hook
  }
  return null
}

async function preflightSessionHook(hookId, registry = loadedRegistry) {
  if (hooksGloballyDisabled()) {
    return { accepted: false, reason: 'global-emergency-disable-active' }
  }
  if (!ACTIVATION_PREFLIGHT_HOOK_IDS.has(hookId)) return { accepted: true }
  const hook = registeredHook(hookId, registry)
  if (!hook) return { accepted: false, reason: `activation-preflight-hook-missing:${hookId}` }
  const execution = await runHookCommand(hook, {
    tama_activation_preflight: true,
    session_id: currentSessionId,
    cwd: currentSessionCwd,
    tool_name: SESSION_OVERRIDE_TOOL,
    tool_input: { hookId, enabled: true },
  })
  if (execution.code === 0 && !execution.timedOut) return { accepted: true }
  const detail = (execution.stderr || execution.stdout || `exit ${execution.code}`).trim()
  return {
    accepted: false,
    reason: `activation-preflight-failed:${hookId}:${detail || 'no diagnostic'}`,
  }
}

async function preflightSessionHooks(hookIds, registry = loadedRegistry) {
  for (const hookId of hookIds) {
    const result = await preflightSessionHook(hookId, registry)
    if (!result.accepted) return result
  }
  return { accepted: true }
}

function isHookActive(hookId) {
  if (hooksGloballyDisabled()) return false
  return true
}

// A stop event does not carry the conversation. lifecyclePayload builds only
// agent_hook_event, runtime, session_id, project_dir and raw_event, so every
// stop hook that inspects the final message -- block-agent-questions,
// block-stop-with-open-work, block-unprompted-topics, check-fabrication-phrases
// -- received a payload with nothing in it, inspected nothing, and passed. On
// 2026-08-06 that let an agent close fifteen consecutive turns with visible
// questions and self-identified unfinished work while four stop gates were
// registered, active, and blind.
//
// The session id is enough to find the transcript: OMP writes one JSONL per
// session under ~/.omp/agent/sessions/<project>/, named <iso>_<sessionId>.jsonl.
// Deriving the path here repairs every stop hook at once rather than teaching
// each one to guess.
function derivedTranscriptPath(sessionId) {
  const id = String(sessionId || '').trim()
  if (!id) return null
  const root = join(homedir(), '.omp', 'agent', 'sessions')
  let projects = []
  try {
    projects = readdirSync(root, { withFileTypes: true })
      .filter(entry => entry.isDirectory())
      .map(entry => join(root, entry.name))
  } catch {
    return null
  }
  const suffix = `_${id}.jsonl`
  for (const project of projects) {
    let names = []
    try {
      names = readdirSync(project)
    } catch {
      continue
    }
    // Exact suffix first: a session id is unique, so a name that ends in it is
    // the transcript and no ranking is needed.
    const exact = names.find(name => name.endsWith(suffix) || name === `${id}.jsonl`)
    if (exact) return join(project, exact)
  }
  return null
}

async function runRegistryEvent(eventName, payload) {
  overrideState()
  if (registryLoadError) {
    const result = { decision: 'block', reason: registryLoadError, id: 'tama-registry-integrity', results: [] }
    lastDecision = { event: eventName, ...result, at: new Date().toISOString() }
    return result
  }
  const entry = loadedRegistry.events?.[eventName]
  if (!entry) {
    const result = { decision: 'pass', reason: `no hooks for ${eventName}`, results: [] }
    lastDecision = { event: eventName, ...result, at: new Date().toISOString() }
    return result
  }
  const rawEvent = payload.raw_event && typeof payload.raw_event === 'object' ? payload.raw_event : {}
  const normalized = {
    ...payload,
    cwd: payload.cwd || rawEvent.cwd || payload.project_dir,
    transcript_path: payload.transcript_path
      || rawEvent.transcript_path
      || rawEvent.transcriptPath
      || derivedTranscriptPath(payload.session_id)
      || null,
    raw_event: undefined,
    agent_hook_event: eventName,
  }
  const results = []
  for (const hook of entry.hooks || []) {
    const id = String(hook?.id || '')
    if (!id || !isHookActive(id)) {
      results.push({ id, skipped: true })
      continue
    }
    const execution = await runHookCommand(hook, normalized)
    const record = { id, code: execution.code, timedOut: execution.timedOut }
    results.push(record)
    const infrastructureFailure = execution.timedOut
      || execution.spawnError
      || (execution.code && looksLikeMalfunction(execution))
    let reason = infrastructureFailure
      ? null
      : decisionFromOutput(execution.stdout) || decisionFromOutput(execution.stderr)
    if (infrastructureFailure) {
      const diagnostic = execution.timedOut
        ? `${id} timed out after ${hook.timeout || 10}s`
        : (execution.stderr || execution.stdout || `exit ${execution.code}`).trim()
      process.stderr.write(`hook ${id} infrastructure failure: ${diagnostic}\n`)
      record.failed = 'infrastructure'
      record.diagnostic = diagnostic
    } else if (!reason && execution.code && entry.blocking !== false) {
      reason = (execution.stderr || execution.stdout || `exit ${execution.code}`).trim()
    }
    if (reason && entry.blocking !== false) {
      const result = { decision: 'block', reason: `${id}: ${reason}`, id, results }
      lastDecision = { event: eventName, ...result, at: new Date().toISOString() }
      return result
    }
  }
  const result = { decision: 'pass', results }
  lastDecision = { event: eventName, ...result, at: new Date().toISOString() }
  return result
}

function sessionOverrideHint(result) {
  if (result.decision !== 'block' || !result.id) return result
  let guidance
  if (result.id === 'block-unauthorized-cua') {
    guidance = 'Record a verbatim, direct current-session user grant for CUA and the named app in ~/.shared-hooks/cua_justifications.json. This hook cannot be disabled within the session.'
  } else if (result.id === 'block-unauthorized-ssh') {
    guidance = 'Record a verbatim, explicit current-session SSH grant and its exact target, operation, path, or command in ~/.shared-hooks/ssh_justification.json. This hook cannot be disabled within the session.'
  } else {
    guidance = 'This hook cannot be disabled within an agent session. Satisfy the blocking policy; policy changes must be performed by the operator outside the agent session.'
  }
  return { ...result, reason: `${result.reason}\n${guidance}` }
}

async function checkToolCall(pi, event) {
  if (CONTROL_PLANE_TOOLS.has(toolName(event))) return { decision: 'pass', code: 0, results: [] }
  const result = await runRegistryEvent(registryEvent(toolName(event)), hookPayload(event))
  if (result.decision === 'pass') consumeSingleUseCapability(pi)
  return result.decision === 'block' ? sessionOverrideHint(result) : result
}

function writeEvidence(payload, result) {
  const path = process.env.OMP_TAMA_EVIDENCE_LOG
  if (!path) return
  appendFileSync(path, `${JSON.stringify({
    event: registryEvent(payload.tool_name),
    input: payload,
    decision: result.decision,
    blockedHookId: result.id || null,
    reason: result.reason || null,
    results: result.results || [],
    loadedReleaseId,
    catalogChecksum: loadedCatalogChecksum,
  })}\n`)
}

function capabilitySummary(grants) {
  return grants.map(grant => grant.actions ? `${grant.tool}:${grant.actions.join(',')}` : grant.tool).join('\n')
}

function lifetimeSummary(lifetime, expiresAt) {
  if (lifetime === 'single-use') return 'Lifetime: one tool invocation'
  if (lifetime === 'current-session') return 'Lifetime: until this OMP session ends'
  return `Expires: ${expiresAt}`
}

function validateReloadCandidate(candidate) {
  const installed = installedReleaseState()
  if (installed.releaseId && candidate.releaseId !== installed.releaseId) {
    throw new Error(`Installed release ${installed.releaseId} does not match registry release ${candidate.releaseId}`)
  }
  if (installed.catalogChecksum && candidate.catalogChecksum !== installed.catalogChecksum) {
    throw new Error(`Installed catalog ${installed.catalogChecksum} does not match registry catalog ${candidate.catalogChecksum}`)
  }
}

function captureReloadState() {
  return {
    registry: loadedRegistry,
    hookIds: knownHookIds,
    releaseId: loadedReleaseId,
    catalogChecksum: loadedCatalogChecksum,
    loadError: registryLoadError,
    disabledHookIds,
    enabledHookIds,
    capability: currentCapability,
  }
}

function restoreReloadState(state) {
  loadedRegistry = state.registry
  knownHookIds = state.hookIds
  loadedReleaseId = state.releaseId
  loadedCatalogChecksum = state.catalogChecksum
  registryLoadError = state.loadError
  disabledHookIds = state.disabledHookIds
  enabledHookIds = state.enabledHookIds
  currentCapability = state.capability
}

function stageRuntimeReload(pi, candidate, enableAll = false) {
  validateReloadCandidate(candidate)
  const previous = captureReloadState()
  try {
    disabledHookIds = new Set([...disabledHookIds].filter(id => candidate.hookIds.has(id)))
    enabledHookIds = enableAll
      ? (hooksGloballyDisabled() ? new Set(candidate.hookIds) : new Set())
      : new Set([...enabledHookIds].filter(id => candidate.hookIds.has(id)))
    installRegistrySnapshot(candidate)
    const overrides = persistOverrides(pi)
    return {
      previous,
      enabled: enableAll ? {
        changed: true,
        sessionId: currentSessionId,
        globallyDisabled: hooksGloballyDisabled(),
        ...overrides,
      } : null,
    }
  } catch (error) {
    const primary = error instanceof Error ? error.message : String(error)
    restoreReloadState(previous)
    try {
      persistOverrides(pi)
    } catch (rollbackError) {
      const rollback = rollbackError instanceof Error ? rollbackError.message : String(rollbackError)
      throw new Error(`${primary}; rollback failed: ${rollback}`)
    }
    throw error
  }
}

function stageDeferredRuntimeReload(pi, candidate, enableAll = false) {
  validateReloadCandidate(candidate)
  const previous = captureReloadState()
  try {
    disabledHookIds = new Set([...disabledHookIds].filter(id => candidate.hookIds.has(id)))
    enabledHookIds = enableAll
      ? (hooksGloballyDisabled() ? new Set(candidate.hookIds) : new Set())
      : new Set([...enabledHookIds].filter(id => candidate.hookIds.has(id)))
    const overrides = persistOverrides(pi, {
      controlKey: currentSessionKey,
      releaseId: candidate.releaseId,
      catalogChecksum: candidate.catalogChecksum,
    })
    return {
      previous,
      enabled: enableAll ? {
        changed: true,
        sessionId: currentSessionId,
        globallyDisabled: hooksGloballyDisabled(),
        ...overrides,
      } : null,
    }
  } catch (error) {
    const primary = error instanceof Error ? error.message : String(error)
    restoreReloadState(previous)
    try {
      persistOverrides(pi)
    } catch (rollbackError) {
      const rollback = rollbackError instanceof Error ? rollbackError.message : String(rollbackError)
      throw new Error(`${primary}; rollback failed: ${rollback}`)
    }
    throw error
  }
}

function finishRuntimeReload() {
  reloadCount++
  lastReloadAt = new Date().toISOString()
  lastReloadError = null
  publishSessionState()
  return runtimeStatus()
}

function rollbackRuntimeReload(pi, stage, error) {
  const primary = error instanceof Error ? error.message : String(error)
  restoreReloadState(stage.previous)
  try {
    persistOverrides(pi)
    lastReloadError = primary
  } catch (rollbackError) {
    const rollback = rollbackError instanceof Error ? rollbackError.message : String(rollbackError)
    lastReloadError = `${primary}; rollback failed: ${rollback}`
  }
  publishSessionState()
  return lastReloadError
}

async function reloadRuntime(pi, ctx, candidate = registrySnapshot(), options = {}) {
  let stage = null
  try {
    if (typeof ctx?.reload !== 'function') throw new Error('OMP exposes reload only to slash-command handlers')
    stage = stageRuntimeReload(pi, candidate, options.enableAll === true)
    await ctx.reload()
    const status = finishRuntimeReload()
    return {
      changed: true,
      reloadRequested: true,
      expectedReleaseId: candidate.releaseId,
      expectedCatalogChecksum: candidate.catalogChecksum,
      enabled: stage.enabled,
      status,
    }
  } catch (error) {
    lastReloadError = stage
      ? rollbackRuntimeReload(pi, stage, error)
      : (error instanceof Error ? error.message : String(error))
    if (!stage) {
      try {
        persistOverrides(pi)
      } catch (persistError) {
        const persist = persistError instanceof Error ? persistError.message : String(persistError)
        lastReloadError = `${lastReloadError}; state persistence failed: ${persist}`
      }
      publishSessionState()
    }
    return { changed: false, reloadRequested: false, error: lastReloadError, status: runtimeStatus() }
  }
}

async function enableAllAndReload(pi, ctx) {
  if (typeof ctx?.reload !== 'function') {
    return {
      enabled: null,
      reload: {
        changed: false,
        reloadRequested: false,
        error: `OMP exposes reload only to /${SESSION_ENABLE_ALL_TOOL}`,
        status: runtimeStatus(),
      },
    }
  }
  const candidate = registrySnapshot()
  const preflight = await preflightSessionHooks(candidate.hookIds, candidate.registry)
  if (!preflight.accepted) {
    return {
      enabled: null,
      reload: {
        changed: false,
        reloadRequested: false,
        error: preflight.reason,
        status: runtimeStatus(),
      },
    }
  }
  const reload = await reloadRuntime(pi, ctx, candidate, { enableAll: true })
  return { enabled: reload.enabled, reload }
}

function ensureSession(pi, ctx) {
  if (!currentSessionId) activateSession(pi, null, ctx)
  return Boolean(currentSessionId)
}

function missingSessionResult(noun) {
  return {
    content: [{ type: 'text', text: `OMP has not provided a session id; Tama refused to create an unscoped ${noun}.` }],
    details: { changed: false, reason: 'missing-session-id' },
    isError: true,
  }
}



function scheduleNativeControlReload(pi, ctx, command) {
  if (pendingRuntimeReload) {
    if (command === SESSION_ENABLE_ALL_TOOL && !pendingRuntimeReload.enableAll) {
      try {
        const upgrade = stageDeferredRuntimeReload(pi, pendingRuntimeReload.candidate, true)
        pendingRuntimeReload.enableAll = true
        pendingRuntimeReload.command = SESSION_ENABLE_ALL_TOOL
        lastReloadError = null
        publishSessionState()
        return {
          changed: true,
          accepted: true,
          reloadRequested: true,
          command: pendingRuntimeReload.command,
          reason: 'pending-reload-upgraded',
          enabled: upgrade.enabled,
          status: runtimeStatus(),
        }
      } catch (error) {
        lastReloadError = error instanceof Error ? error.message : String(error)
        publishSessionState()
        return {
          changed: false,
          accepted: false,
          reloadRequested: true,
          command: pendingRuntimeReload.command,
          error: lastReloadError,
          reason: 'pending-reload-upgrade-failed',
          status: runtimeStatus(),
        }
      }
    }
    return {
      changed: false,
      accepted: true,
      reloadRequested: true,
      command: pendingRuntimeReload.command,
      reason: 'reload-already-pending',
      status: runtimeStatus(),
    }
  }

  let stage = null
  try {
    if (typeof ctx?.requestReload !== 'function') {
      throw new Error('OMP does not expose deferred runtime reload requests')
    }
    const candidate = registrySnapshot()
    validateReloadCandidate(candidate)
    const request = {
      command,
      candidate,
      enableAll: command === SESSION_ENABLE_ALL_TOOL,
      sessionId: currentSessionId,
    }
    pendingRuntimeReload = request
    lastReloadError = null
    stage = stageDeferredRuntimeReload(pi, candidate, request.enableAll)
    const completion = ctx.requestReload()
    if (!completion) throw new Error('OMP could not schedule a deferred runtime reload')

    const complete = result => {
      if (pendingRuntimeReload !== request) return
      pendingRuntimeReload = null
      if (result?.reloaded) return
      rollbackRuntimeReload(
        pi,
        stage,
        new Error(result?.error || 'OMP deferred runtime reload failed'),
      )
    }
    void completion.then(
      complete,
      error => complete({ reloaded: false, error: error instanceof Error ? error.message : String(error) }),
    )

    return {
      changed: true,
      accepted: true,
      reloadRequested: true,
      command,
      expectedReleaseId: candidate.releaseId,
      expectedCatalogChecksum: candidate.catalogChecksum,
      ...(stage.enabled ? { enabled: stage.enabled } : {}),
      status: runtimeStatus(),
    }
  } catch (error) {
    pendingRuntimeReload = null
    if (stage) rollbackRuntimeReload(pi, stage, error)
    else {
      lastReloadError = error instanceof Error ? error.message : String(error)
      publishSessionState()
    }
    return {
      changed: false,
      accepted: false,
      reloadRequested: false,
      command,
      error: lastReloadError,
      status: runtimeStatus(),
    }
  }
}

export default function sharedHooks(pi) {
  const { z } = pi.zod

  pi.registerCommand(RUNTIME_RELOAD_TOOL, {
    description: 'Validate the installed Tama release and reload this OMP session runtime.',
    handler: async (_args, ctx) => {
      if (!ensureSession(pi, ctx)) {
        ctx.ui.notify('Tama cannot reload without an active OMP session id.', 'error')
        return
      }
      const details = await reloadRuntime(pi, ctx)
      if (!details.changed) ctx.ui.notify(`Tama runtime reload failed: ${details.error}`, 'error')
    },
  })

  pi.registerCommand(SESSION_ENABLE_ALL_TOOL, {
    description: 'Enable every registered Tama hook and reload this OMP session once.',
    handler: async (_args, ctx) => {
      if (!ensureSession(pi, ctx)) {
        ctx.ui.notify('Tama cannot enable hooks without an active OMP session id.', 'error')
        return
      }
      const details = await enableAllAndReload(pi, ctx)
      if (!details.reload.changed) {
        ctx.ui.notify(`Tama enable-all failed and was rolled back: ${details.reload.error}`, 'error')
      }
    },
  })

  pi.registerTool({
    name: RUNTIME_STATUS_TOOL,
    label: 'Tama hook runtime status',
    description: 'Read the exact installed and loaded Tama hook release, checksum, counts, overrides, capability, and last blocking decision.',
    parameters: z.object({}),
    async execute(_toolCallId, _params, _signal, _onUpdate, ctx) {
      ensureSession(pi, ctx)
      const status = runtimeStatus()
      publishSessionState()
      return { content: [{ type: 'text', text: JSON.stringify(status, null, 2) }], details: status }
    },
  })

  pi.registerTool({
    name: SESSION_OVERRIDE_TOOL,
    label: 'Tama session hook enablement',
    description: 'Enable one exact registered hook in only the current OMP session. Session hook disablement is prohibited.',
    parameters: z.object({ hookId: z.string(), enabled: z.literal(true) }),
    approval: { tier: 'exec', override: true, reason: 'Enables one hook in the current OMP session.' },
    formatApprovalDetails: ({ hookId }) => [
      `Enable hook: ${hookId}`,
      'Scope: current OMP session only',
    ],
    async execute(_toolCallId, { hookId, enabled }, _signal, _onUpdate, ctx) {
      if (!ensureSession(pi, ctx)) return missingSessionResult('hook override')
      const id = String(hookId || '').trim()
      if (!knownHookIds.has(id)) {
        return {
          content: [{ type: 'text', text: `Unknown Tama hook id: ${id}` }],
          details: { changed: false, reason: 'unknown-hook' },
          isError: true,
        }
      }
      const preflight = await preflightSessionHook(id)
      if (!preflight.accepted) {
        return {
          content: [{ type: 'text', text: `Tama refused to enable ${id}: ${preflight.reason}` }],
          details: { changed: false, ...preflight },
          isError: true,
        }
      }
      const details = applySessionHookOverride(pi, id, enabled)
      const accepted = details.accepted === true
      const text = details.changed
        ? `Enabled ${id} only for this OMP session.`
        : accepted
          ? `${id} is already enabled in this OMP session.`
          : `${id} cannot be disabled within an agent session. Satisfy the blocking policy; policy changes must be performed by the operator outside the agent session.`
      return {
        content: [{ type: 'text', text }],
        details,
        isError: !accepted,
      }
    },
  })

  pi.registerTool({
    name: SESSION_ENABLE_ALL_TOOL,
    label: 'Enable all Tama hooks in this session',
    description: 'Atomically enable every loaded or newly installed hook after a deferred runtime reload.',
    parameters: z.object({}),
    async execute(_toolCallId, _params, _signal, _onUpdate, ctx) {
      if (!ensureSession(pi, ctx)) return missingSessionResult('enable-all override')
      const candidate = registrySnapshot()
      const preflight = await preflightSessionHooks(candidate.hookIds, candidate.registry)
      if (!preflight.accepted) {
        return {
          content: [{ type: 'text', text: `Tama refused enable-all: ${preflight.reason}` }],
          details: { changed: false, ...preflight },
          isError: true,
        }
      }
      const details = scheduleNativeControlReload(pi, ctx, SESSION_ENABLE_ALL_TOOL)
      const accepted = details.accepted === true
      const text = details.changed
        ? 'Scheduled native enable-all after the active turn settles and reloads the runtime.'
        : accepted
          ? 'Native enable-all is already scheduled for this session.'
          : `Tama could not schedule native enable-all: ${details.error}`
      return {
        content: [{ type: 'text', text }],
        details,
        isError: !accepted,
      }
    },
  })

  pi.registerTool({
    name: SESSION_CAPABILITY_TOOL,
    label: 'Authorize a scoped Tama capability',
    description: 'Authorize exact tool/action grants for one invocation, a stated expiration, or the current OMP session.',
    parameters: z.object({
      grants: z.array(z.object({ tool: z.string(), actions: z.array(z.string()).optional() })).min(1),
      lifetime: z.enum(['single-use', 'expires-at', 'current-session']),
      expiresAt: z.string().optional(),
    }),
    approval: { tier: 'exec', override: true, reason: 'Authorizes exact protected tool actions for the displayed lifetime.' },
    formatApprovalDetails: ({ grants, lifetime, expiresAt }) => [
      capabilitySummary(normalizeCapabilityGrants(grants) || []),
      lifetimeSummary(lifetime, expiresAt),
      'Scope: current OMP session only',
    ],
    async execute(_toolCallId, { grants, lifetime, expiresAt }, _signal, _onUpdate, ctx) {
      if (!ensureSession(pi, ctx)) return missingSessionResult('capability')
      const normalizedGrants = normalizeCapabilityGrants(grants)
      const validExpiration = lifetime !== 'expires-at'
        || (Number.isFinite(Date.parse(expiresAt)) && Date.parse(expiresAt) > Date.now())
      if (!normalizedGrants || !validExpiration) {
        return {
          content: [{ type: 'text', text: 'Tama rejected invalid capability grants, lifetime, or expiration.' }],
          details: { changed: false, reason: 'invalid-capability-request' },
          isError: true,
        }
      }
      const details = applySessionCapability(pi, normalizedGrants, lifetime, expiresAt)
      return {
        content: [{ type: 'text', text: `Authorized the displayed grants. ${lifetimeSummary(lifetime, details.capability.expiresAt)}` }],
        details,
      }
    },
  })

  pi.registerTool({
    name: RUNTIME_RELOAD_TOOL,
    label: 'Reload the Tama hook runtime',
    description: 'Schedule a native OMP runtime reload after the active agent turn settles.',
    parameters: z.object({}),
    async execute(_toolCallId, _params, _signal, _onUpdate, ctx) {
      if (!ensureSession(pi, ctx)) return missingSessionResult('runtime reload')
      const details = scheduleNativeControlReload(pi, ctx, RUNTIME_RELOAD_TOOL)
      const accepted = details.accepted === true
      const text = details.changed
        ? 'Scheduled the native Tama runtime reload after the active turn settles.'
        : accepted
          ? 'A native Tama runtime reload is already scheduled for this session.'
          : `Tama could not schedule the native runtime reload: ${details.error}`
      return {
        content: [{ type: 'text', text }],
        details,
        isError: !accepted,
      }
    },
  })

  pi.on('input', async (event, ctx) => {
    await processSessionControlRequests(pi)
    publishSessionState()
    const result = await runRegistryEvent('user_prompt_submit', lifecyclePayload('user_prompt_submit', event, {
      prompt: event?.text || event?.prompt || '',
    }))
    if (result.decision === 'block') {
      ctx.ui.notify(result.reason || 'Tama blocked this prompt.', 'error')
      ctx.abort()
      return { action: 'handled' }
    }
  })

  pi.on('tool_result', async event => {
    const payload = {
      ...hookPayload(event),
      agent_hook_event: 'tool_result',
      tool_result: { content: event?.content, details: event?.details, is_error: event?.isError === true },
    }
    const result = await runRegistryEvent(registryPostEvent(payload.tool_name), payload)
    if (result.decision === 'block') {
      return { content: [{ type: 'text', text: result.reason || 'Tama rejected the tool result.' }], isError: true }
    }
  })

  pi.on('session_stop', async event => {
    const result = await runRegistryEvent('stop', lifecyclePayload('stop', event))
    if (result.decision === 'block') return { decision: 'block', reason: result.reason || 'Tama blocked session completion.' }
  })

  pi.on('session_compact', async event => {
    await runRegistryEvent('session_start:compact', lifecyclePayload('session_start:compact', event))
  })

  const handleSessionActivation = (event, ctx) => activateSession(pi, event, ctx)
  pi.on('session_start', handleSessionActivation)
  pi.on('session_switch', handleSessionActivation)
  pi.on('session_branch', handleSessionActivation)
  pi.on('session_tree', handleSessionActivation)
  pi.on('session_shutdown', () => {
    stopSessionControl()
    currentSessionId = null
    disabledHookIds = new Set()
    enabledHookIds = new Set()
    unknownHookIds = new Set()
    currentCapability = null
  })

  pi.on('tool_call', async event => {
    await processSessionControlRequests(pi)
    publishSessionState()
    const result = await checkToolCall(pi, event)
    writeEvidence(hookPayload(event), result)
    publishSessionState()
    if (result.decision === 'block') return { block: true, reason: result.reason }
  })
}
