#!/usr/bin/env python3
"""HARDENED transcript-aware artifact-inspection enforcement.

Improvements over the prior version:
  1. Drop "first run is free" — block from run #1 if any recording for the
     label already exists on disk. Defeats spam-new-filenames bypass.
  2. Pin transcript scan to the label — artifact path must contain the
     trajectory label. One Read on an unrelated recording no longer
     unblocks all labels.
  3. Sha256 marker self-validation — marker file must contain
     "recording_sha256: <64-hex>" matching the recording it claims to have
     inspected. Hook recomputes and rejects mismatches. Defeats
     `touch <marker>` and empty-file bypass.

Inputs:
  argv[1]: trajectory label
  argv[2]: bash command (used in block message only)

Behavior:
  exit 0  - allow
  exit 2  - block, with message naming candidate artifacts on disk
"""

import glob
import hashlib
import json
import os
import re
import sys
import time
from pathlib import Path

LABEL = sys.argv[1] if len(sys.argv) > 1 else ""
CMD = sys.argv[2] if len(sys.argv) > 2 else ""
# argv[3] (or env) is the EXACT transcript path from the Claude Code hook
# payload, passed through by pre_bash.sh. When present it removes all
# guesswork: under concurrent sessions, mtime/size heuristics cannot
# identify "this" session, so inspection done in the active session was
# invisible and the gate was permanently unsatisfiable. Prefer it.
EXPLICIT_TRANSCRIPT = ""
if len(sys.argv) > 3 and sys.argv[3]:
    EXPLICIT_TRANSCRIPT = sys.argv[3]
elif os.environ.get("CLAUDE_TRANSCRIPT_PATH"):
    EXPLICIT_TRANSCRIPT = os.environ["CLAUDE_TRANSCRIPT_PATH"]
if not LABEL:
    sys.exit(0)

CWD = Path(os.getcwd())
REPO = CWD
HOME = Path(os.environ.get("HOME", "/tmp"))
STATE_FILE = HOME / ".shared-hooks" / "state" / "trajectory_runs.json"


def runs_count(label: str) -> int:
    try:
        data = json.loads(STATE_FILE.read_text())
    except Exception:
        return 0
    for k, v in data.items():
        if k.endswith(f"/{label}"):
            return int(v.get("runs_since_inspection", 0))
    return 0


def find_session_jsonl():
    # Exact transcript from the hook payload wins — no guessing.
    if EXPLICIT_TRANSCRIPT:
        p = Path(EXPLICIT_TRANSCRIPT)
        if p.is_file():
            return p
    # Claude Code encodes the project dir by replacing "/" with "-".
    # Because absolute paths begin with "/", that conversion already yields
    # a leading "-"; do NOT prepend another one.
    encoded = str(REPO).replace("/", "-")
    proj_dir = HOME / ".claude" / "projects" / encoded
    if not proj_dir.is_dir():
        return None
    candidates = sorted(proj_dir.glob("*.jsonl"), key=lambda p: p.stat().st_mtime, reverse=True)
    if not candidates:
        return None
    # Pick the single most-recently-MODIFIED transcript. The active session
    # is the one being appended to right now (this hook fires immediately
    # after a tool call wrote to it), so its jsonl has the freshest mtime
    # at hook time. The prior `max(candidates[:5], key=size)` selected a
    # different *concurrent* session's larger JSONL (e.g. 126MB vs the
    # active 23MB), making every Read/marker in the active session
    # invisible and the gate permanently unsatisfiable. A 2s-tie +
    # last-line-timestamp tiebreak was tried but backfired: the active
    # session's final lines are often tool/hook entries with no top-level
    # "timestamp", so last_line_ts returned "" and lost to a stale
    # session. Plain most-recent-mtime is the most reliable signal.
    return candidates[0]


def list_recordings(label: str) -> list[Path]:
    out: list[Path] = []
    for base in [REPO.parent / "weles" / "recordings" / label, REPO / "recordings" / label]:
        if base.is_dir():
            out.extend(sorted(base.glob("*.webm"), key=lambda p: p.stat().st_mtime, reverse=True))
    return out


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def marker_validates(label: str) -> tuple[bool, str]:
    """Marker must:
      (a) exist + non-empty
      (b) name a recording
      (c) the recording must exist
      (d) the recorded sha256 must match a recompute
      (e) the recording named in the marker must be the LATEST recording on
          disk for this label — newer recordings invalidate the marker so
          re-runs can't ride a single old inspection forever
      (f) the session must show a Read tool call on at least one frame in
          .work/<label>/ — verifies the agent actually opened a frame, not
          just ran inspect_trajectory.sh and walked away."""
    marker = REPO / ".work" / ".artifact_inspected" / label
    if not marker.exists() or marker.stat().st_size == 0:
        return False, "no marker (or empty)"
    try:
        text = marker.read_text()
    except Exception as e:
        return False, f"unreadable marker: {e}"
    rec_match = re.search(r"^recording:\s*(.+)$", text, flags=re.MULTILINE)
    sha_match = re.search(r"^recording_sha256:\s*([0-9a-f]{64})$", text, flags=re.MULTILINE)
    if not rec_match or not sha_match:
        return False, "marker missing recording: or recording_sha256: lines"
    rec_path = Path(rec_match.group(1).strip())
    claimed_sha = sha_match.group(1).strip()
    if not rec_path.exists():
        return False, f"recording referenced by marker does not exist: {rec_path}"
    actual_sha = sha256_file(rec_path)
    if actual_sha != claimed_sha:
        return False, f"sha256 mismatch (marker claimed {claimed_sha[:12]}…, actual {actual_sha[:12]}…)"
    # (e) marker must reference the latest recording for the label.
    all_recs = list_recordings(label)
    if all_recs:
        latest = all_recs[0]
        if latest.resolve() != rec_path.resolve():
            return False, f"marker references {rec_path.name} but latest recording is {latest.name}"
    # (f) session transcript must show a Read on a sha8-tagged frame for
    # the LATEST recording. Re-reading frames from an older recording does
    # not satisfy the gate.
    if not transcript_shows_frame_read(label, claimed_sha[:8], rec_path):
        return False, f"no Read on sha8={claimed_sha[:8]} frame in session — run inspect_trajectory.sh on the latest recording AND Read at least one frame_{claimed_sha[:8]}_*.png"
    return True, "marker verified + sha8 frame Read observed"


def parse_marker_frame_shas(label: str) -> dict:
    """Parse the marker file's per-frame sha entries. Returns {path: sha}.
    Marker shape (v5+):
        frames:
          - path: /abs/path/frame_<sha8>_first.png
            sha256: <hex>
    """
    marker = REPO / ".work" / ".artifact_inspected" / label
    if not marker.exists():
        return {}
    out: dict = {}
    last_path = None
    for line in marker.read_text().splitlines():
        m = re.match(r"^\s*-\s*path:\s*(.+)$", line)
        if m:
            last_path = m.group(1).strip()
            continue
        m = re.match(r"^\s*sha256:\s*([0-9a-f]{64})$", line)
        if m and last_path:
            out[last_path] = m.group(1)
            last_path = None
    return out


def transcript_shows_frame_read(label: str, sha8: str, rec_path: "Path", lookback: int = 1200) -> bool:
    """Return True iff the session JSONL has a Read on a frame whose:
      - path matches .work/<label>/frame_<sha8>_*.png
      - mtime is within 2s of the recording's mtime
      - current content sha256 matches what inspect_trajectory.sh wrote
        into the marker (defeats touch-r-with-fake-content bypass)."""
    jsonl = find_session_jsonl()
    if not jsonl:
        return False
    esc = re.escape(label)
    sha8_esc = re.escape(sha8)
    pat = re.compile(rf"\.work/{esc}/frame_{sha8_esc}_[^\s'\"]*\.(?:png|jpg)$")
    rec_mtime = rec_path.stat().st_mtime if rec_path.exists() else None
    frame_shas = parse_marker_frame_shas(label)
    try:
        with jsonl.open("r") as fh:
            lines = fh.readlines()
    except Exception:
        return False
    for raw in lines[-lookback:]:
        try:
            entry = json.loads(raw)
        except Exception:
            continue
        msg = entry.get("message") or {}
        content = msg.get("content") or []
        if not isinstance(content, list):
            continue
        for block in content:
            if not isinstance(block, dict) or block.get("type") != "tool_use":
                continue
            if block.get("name") != "Read":
                continue
            inp = block.get("input") or {}
            fp = str(inp.get("file_path") or "")
            if not pat.search(fp):
                continue
            # NOTE: the old `abs(frame_mtime - rec_mtime) <= 2.0` coupling
            # was a bug — frames are extracted by inspect_trajectory.sh
            # long after the recording finished, so their file mtime is
            # never within 2s of the .webm mtime, making this path
            # permanently unsatisfiable. The real anti-spoof guard is the
            # content sha256 below (the marker is itself sha-validated
            # against the recording earlier), so mtime coupling is dropped.
            try:
                claimed = frame_shas.get(fp)
                if claimed:
                    actual = sha256_file(Path(fp))
                    if actual != claimed:
                        continue
            except Exception:
                continue
            return True
    return False


# Patterns with {label} placeholder pinned to the label.
def label_artifact_patterns(label: str) -> list[re.Pattern]:
    esc = re.escape(label)
    return [
        re.compile(rf"(?:^|/)recordings/{esc}/[^\s'\"]*\.(?:webm|mp4|png|jpg|gif)$"),
        re.compile(rf"\.work/{esc}/[^\s'\"]*\.(?:png|jpg|html|htm|json|md)$"),
        re.compile(rf"\.work/{esc}/frame[_0-9]*\.(?:png|jpg)$"),
        re.compile(rf"\.work/[^\s'\"]*{esc}[^\s'\"]*outerHTML[^\s'\"]*"),
        re.compile(rf"\.work/[^\s'\"]*{esc}[^\s'\"]*-diag/[^\s'\"]*\.(?:json|html|png)$"),
    ]


def label_bash_patterns(label: str) -> list[re.Pattern]:
    esc = re.escape(label)
    return [
        re.compile(rf"ffmpeg\b[^|;&]*{esc}[^|;&]*\.webm"),
        re.compile(rf"ffprobe\b[^|;&]*{esc}[^|;&]*\.webm"),
        re.compile(rf"jq\b[^|;&]*\.work/{esc}/"),
    ]


def transcript_shows_label_inspection(label: str, lookback: int = 1200) -> tuple[bool, list[str]]:
    jsonl = find_session_jsonl()
    if not jsonl:
        return False, []
    art_pats = label_artifact_patterns(label)
    bash_pats = label_bash_patterns(label)
    evidence: list[str] = []
    try:
        with jsonl.open("r") as fh:
            lines = fh.readlines()
    except Exception:
        return False, []
    for raw in lines[-lookback:]:
        try:
            entry = json.loads(raw)
        except Exception:
            continue
        msg = entry.get("message") or {}
        content = msg.get("content") or []
        if not isinstance(content, list):
            continue
        for block in content:
            if not isinstance(block, dict) or block.get("type") != "tool_use":
                continue
            name = block.get("name", "")
            inp = block.get("input") or {}
            if name == "Read":
                fp = str(inp.get("file_path") or "")
                if any(p.search(fp) for p in art_pats):
                    evidence.append(f"Read {fp}")
            elif name == "Bash":
                bcmd = str(inp.get("command") or "")
                if any(p.search(bcmd) for p in bash_pats):
                    evidence.append(f"Bash {bcmd[:80]}")
    return bool(evidence), evidence


def list_candidate_artifacts(label: str) -> list[str]:
    out: list[str] = []
    for base in [REPO.parent / "weles" / "recordings" / label, REPO / "recordings" / label]:
        if base.is_dir():
            for f in sorted(base.glob("*.webm"), key=lambda p: p.stat().st_mtime, reverse=True)[:3]:
                out.append(f"  recording  {f}")
    work_dir = REPO / ".work" / label
    if work_dir.is_dir():
        for f in sorted(work_dir.rglob("*"), key=lambda p: p.stat().st_mtime, reverse=True)[:5]:
            if f.is_file():
                out.append(f"  workfile   {f}")
    return out[:10]


def block_and_exit(label: str, runs: int, why: str):
    artifacts = list_candidate_artifacts(label)
    print("=" * 60, file=sys.stderr)
    print(f"  BLOCKED: trajectory '{label}' run #{runs+1} without inspection", file=sys.stderr)
    print(f"  reason: {why}", file=sys.stderr)
    print("=" * 60, file=sys.stderr)
    print("", file=sys.stderr)
    if artifacts:
        print("Candidate artifacts on disk for this label:", file=sys.stderr)
        for a in artifacts:
            print(a, file=sys.stderr)
    print("", file=sys.stderr)
    print("Unblock by ONE of:", file=sys.stderr)
    print(f"  (a) $HOME/.shared-hooks/inspect_trajectory.sh {label}", file=sys.stderr)
    print(f"      writes a sha256-validating marker the hook can verify.", file=sys.stderr)
    print(f"  (b) Read tool on .work/{label}/ frames or recordings/{label}/", file=sys.stderr)
    print(f"      paths in this session — transcript scanner is label-pinned.", file=sys.stderr)
    sys.exit(2)


def main():
    runs = runs_count(LABEL)
    recordings = list_recordings(LABEL)

    # First-run gate. Allowed only when:
    #   - no prior runs in the counter, AND
    #   - no recordings on disk for this label, AND
    #   - the user has explicitly authorized via WELES_FIRST_RUN=1 OR a
    #     human-authored .work/<label>/inspection.md exists with at least
    #     200 chars (matches the layer-1 unblock pattern).
    # The env-var gate prevents an agent from spamming new filenames to
    # consume infinite "first-run free" passes.
    if runs == 0 and not recordings:
        env_ok = os.environ.get("WELES_FIRST_RUN") == "1"
        notes = REPO / ".work" / LABEL / "inspection.md"
        notes_ok = notes.exists() and notes.stat().st_size >= 200
        if env_ok or notes_ok:
            sys.exit(0)
        block_and_exit(LABEL, runs, "first-run requires WELES_FIRST_RUN=1 env or 200+ char .work/<label>/inspection.md")

    ok, why = marker_validates(LABEL)
    if ok:
        sys.exit(0)

    found, _ = transcript_shows_label_inspection(LABEL)
    if found:
        sys.exit(0)

    block_and_exit(LABEL, runs, why)


if __name__ == "__main__":
    main()
