#!/bin/bash
set -euo pipefail

INPUT=$(cat)
TOOL=$(echo "$INPUT" | jq -r '.tool_name // .tool // .name // empty')
CMD=$(echo "$INPUT" | jq -r '.tool_input.command // .tool_input.cmd // .command // .cmd // empty')

block() {
    echo "BLOCKED: YOU FUCKING RETARD. DO NOT USE CUA. SLACK HAS A FUCKING API" >&2
    exit 2
}

if echo "$TOOL" | grep -qiE 'cua|computer[ _-]?use|gui[ _-]?driver'; then
    block
fi

if echo "$CMD" | grep -qiE 'cua-driver|CuaDriver\.app|mcp__cua|computer[ _-]?use|gui[ _-]?driver'; then
    block
fi

exit 0
