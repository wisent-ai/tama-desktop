#!/usr/bin/env python3
"""Stop hook: reject assistant turns that contain speculation, weasel words,
or suggestions to wait/cool off instead of diagnosing with evidence.

Cross-agent: works with Claude Code, Droid (Factory), Codex (OpenAI).
This is the inline regex from the original settings.json Stop hook,
extracted into a standalone script so all three agents can share it.
"""
from __future__ import annotations

import json
import re
import sys

SPECULATION_PATTERNS = [
    # Weasel words: likely, probably, might, could, etc.
    (r"\blikely\b|\bknown limitation\b|\bprobably\b|\bmaybe\b|\bmay be\b|"
     r"\bmight be\b|\bcould be\b|\bpossibly\b|\bperhaps\b|\bi think\b|"
     r"\bi suspect\b|\bmy guess\b"),
    # Manual/simplified solutions
    (r"\bmanual(ly)?\b|\bby hand\b|\bsimplif(y|ied|ier)\b|\bsimpler approach\b|"
     r"\blet me try a simpler\b|\bdo it yourself\b|"
     r"\bcreate.*(account|it).*(yourself|by hand)\b|"
     r"\beasier.*(just|to).*manual\b"),
    # Cooling off / waiting / rate limit recovery
    (r"\bcool[- ]?down\b|\bcools? (off|down)\b|\bcooling (off|down)\b|"
     r"\bfresh eyes\b|\brested brain\b|\bneed (a |some )?rest\b|"
     r"\bsleep on (it|this)\b|\btry (again )?(tomorrow|later)\b|"
     r"\bcome back (tomorrow|later|in (a|the) morning)\b|\bwait (it )?out\b|"
     r"\bpool (is|was|gets|got) burn(t|ed)\b|\bburnt (pool|ip)\b|"
     r"\bips? (will |should |might )?(cool|age|decay|reset|clear|unburn)\b|"
     r"\brate[- ]?limit.*\b(will|should|might|may) (reset|clear|expire|decay)\b|"
     r"\btake a break\b|\bcall it a day\b|\bpick (this|it) up tomorrow\b"),
]

COMPILED = [re.compile(p, flags=re.IGNORECASE) for p in SPECULATION_PATTERNS]

def find_hits(text: str) -> list[str]:
    hits: list[str] = []
    for regex in COMPILED:
        for match in regex.finditer(text):
            hits.append(match.group(0).strip())
    return list(dict.fromkeys(hits))

def main() -> int:
    try:
        payload = json.loads(sys.stdin.read() or "{}")
    except json.JSONDecodeError:
        return 0
    if payload.get("stop_hook_active"):
        return 0
    msg = payload.get("last_assistant_message") or ""
    if not isinstance(msg, str) or not msg.strip():
        return 0
    hits = find_hits(msg)
    if not hits:
        return 0
    # Categorize the hit for a targeted message
    hit_text = hits[0].lower()
    if any(w in hit_text for w in ["likely", "probably", "maybe", "might", "could", "possibly", "perhaps", "i think", "i suspect", "my guess"]):
        reason = ("BLOCKED: Do not speculate. You used a weasel word (likely, probably, might, etc). "
                  "Investigate the actual code/data and state what IS happening, not what might be.")
    elif any(w in hit_text for w in ["manual", "by hand", "simplif", "simpler", "do it yourself"]):
        reason = ("BLOCKED: You suggested a manual/simplified solution. Everything must be fully automated. "
                  "No manual steps, no simplifying. Rethink and provide a fully automated solution.")
    else:
        reason = ("BLOCKED: Do not suggest waiting, cooling off, retrying later, taking a break, "
                  "or claim that IPs/pools/rate-limits will reset or cool down. "
                  "If a flow fails, diagnose with evidence or say \"I do not know\". "
                  "Never invent recovery mechanisms without reverse-engineering data.")
    print(json.dumps({"decision": "block", "reason": reason}))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
