#!/usr/bin/env python3
# Block numeric literals lacking verbatim user-declared provenance.
# Rule (owner-mandated): a numeric literal in a CODE file is banned; in any
# other text/config file is banned (no relocation); numbers live ONLY in
# numeric-provenance.json as {"<name>": {"value": <n>, "user_said": "<verbatim user quote>"}}
# where the quote appears verbatim in a real role=user transcript message and
# declares that value (120k == 120_000 == 120000 == 120.0). Strings/comments
# stripped; identifier-glued digits (Int64, sha256) are not literals. Whole
# post-edit content scanned so existing literals cannot be edited around. The
# hook certifies provenance (you declared it), not that a value is correct.
from __future__ import annotations
import json, os, re, sqlite3, sys
from urllib.parse import unquote, urlsplit

CODE_EXT = {'.swift':'swift','.ts':'ts','.tsx':'ts','.js':'js','.mjs':'js','.jsx':'js','.py':'py','.rs':'rust','.go':'go','.c':'c','.h':'c','.cpp':'c','.cc':'c','.hpp':'c','.m':'c','.mm':'c','.cs':'c','.java':'c','.kt':'c','.kts':'c','.scala':'c','.groovy':'c','.gradle':'c','.php':'c','.sh':'sh','.bash':'sh','.zsh':'sh','.rb':'sh','.pl':'sh','.r':'sh','.jl':'sh','.lua':'sql','.sql':'sql'}
PROV_RE = re.compile(r'(^|/)numeric-provenance\.json$')
OTHER_RE = re.compile(r'\.(json|toml|ya?ml|plist|cfg|ini|env|properties)$')
NUM = re.compile(r'(?<![A-Za-z0-9_.$])(0[xXbBoO][0-9a-fA-F_]+|\d[\d_]*(?:,\d{3})*(?:\.\d+)?(?:[eE][+-]?\d+)?)' + r'|(?<![A-Za-z0-9_$).\]])\.\d[\d_]*(?:[eE][+-]?\d+)?')
QNUM = re.compile(r'0[xXbBoO][0-9a-fA-F_]+|\d[\d_,]*(?:\.\d+)?(?:[eE][+-]?\d+)?\s*[kmbgKMBG]?|\.\d[\d_]*(?:[eE][+-]?\d+)?')
LC = {'swift':'//','js':'//','ts':'//','py':'#','rust':'//','go':'//','c':'//','sh':'#','sql':'--'}
BLK = {'swift','js','ts','rust','go','c','sql','css','scss'}  # c covers cpp/java/kt/scala/php/cs/groovy
SUF = {'k':1e3,'m':1e6,'b':1e9,'g':1e9}
TEXT_EXT = {'.md','.mdx','.css','.scss','.html','.htm','.ipynb','.jsonl','.rst','.txt','.xml','.svg','.vue','.svelte'}
WRITE_TOOLS = {'write','create','edit','multiedit','apply_patch','functions.apply_patch','applypatch'}
TQ = chr(34)*3
SQ = chr(39)*3
HASHLINE_HEADER = re.compile(r'^\[(?P<path>[^#\]\n]+)#[0-9A-Fa-f]{4}\]\s*$')

def canon(t):
    t=t.strip().lower().replace(',','').replace('_','').replace(' ','')
    if t[:2] in ('0x','0b','0o'):
        base={'0x':16,'0b':2,'0o':8}[t[:2]]
        try: return float(int(t[2:], base))
        except Exception: return None
    mul=1.0
    if t and t[-1] in SUF: mul=SUF[t[-1]]; t=t[:-1]
    try: return float(t)*mul
    except Exception: return None

def lang_for(p):
    for e,l in CODE_EXT.items():
        if p.endswith(e): return l
    return None

def strip_sc(src, lg):
    out=[]; i=0; n=len(src); lc=LC.get(lg,'//'); blk=lg in BLK; tri=lg=='py'
    while i<n:
        c=src[i]; twoc=src[i:i+2]; three=src[i:i+3]
        if twoc==lc or (len(lc)==1 and c==lc):
            j=src.find(chr(10),i); j=n if j<0 else j; out.append(' '*(j-i)); i=j; continue
        if blk and twoc=='/*':
            j=src.find('*/',i+2); j=n if j<0 else j+2; out.append(' '*(j-i)); i=j; continue
        if tri and three in (TQ,SQ):
            q=three; j=src.find(q,i+3); j=n if j<0 else j+3; out.append(' '*(j-i)); i=j; continue
        if c in (chr(34),chr(39),chr(96)):
            q=c; j=i+1
            while j<n:
                if src[j]=='\\': j+=2; continue
                if src[j]==q: j+=1; break
                j+=1
            out.append(' '*(j-i)); i=j; continue
        out.append(c); i+=1
    return ''.join(out)

def added_from_patch(patch):
    return chr(10).join(l[1:] for l in patch.splitlines() if l.startswith('+') and not l.startswith('+++'))

def quote_in_user_msg(quote, limit_sessions=25):
    db=os.path.expanduser('~/Library/Application Support/Oko/transcript-index.sqlite')
    q=quote.strip()
    if not q: return False
    toks=re.findall(r'[A-Za-z0-9]{3,}', q)[:8]
    try: con=sqlite3.connect('file:'+db+'?mode=ro', uri=True)
    except Exception: return False
    rows=[]
    if toks:
        match=' '.join(chr(34)+t+chr(34) for t in toks)
        try: rows=con.execute('SELECT s.path FROM sessions_fts f JOIN sessions s ON s.sessionId=f.sessionId WHERE sessions_fts MATCH ? LIMIT ?', (match, limit_sessions)).fetchall()
        except Exception: rows=[]
    if not rows:
        try: rows=con.execute('SELECT path FROM sessions ORDER BY COALESCE(last_activity,mtime) DESC LIMIT ?',(limit_sessions,)).fetchall()
        except Exception: return False
    for (p,) in rows:
        try:
            with open(p, errors='replace') as fh:
                for line in fh:
                    if q not in line: continue
                    try: o=json.loads(line)
                    except Exception: continue
                    m=o.get('message') if isinstance(o.get('message'),dict) else None
                    if ((m.get('role') if m else None) or o.get('role'))!='user': continue
                    ct=(m or o).get('content')
                    ts=[ct] if isinstance(ct,str) else [x.get('text','') for x in ct if isinstance(x,dict)] if isinstance(ct,list) else []
                    if any(q in t for t in ts): return True
        except FileNotFoundError: continue
    return False

def declares(quote, lit):
    lv=canon(lit)
    return lv is not None and any(canon(x.group())==lv for x in QNUM.finditer(quote))

def check_provenance(text):
    try: doc=json.loads(text)
    except Exception as e: return ['numeric-provenance.json is not valid JSON: '+str(e)]
    if not isinstance(doc,dict): return ['numeric-provenance.json must be an object: name -> {value,user_said}']
    out=[]
    for name,entry in doc.items():
        if not isinstance(entry,dict) or set(entry.keys())!={'value','user_said'}:
            out.append('"'+str(name)+'": entry must be exactly {value,user_said}'); continue
        val=entry['value']; quote=entry['user_said']
        if isinstance(val,bool) or not isinstance(val,(int,float)):
            out.append('"'+str(name)+'": value must be a number'); continue
        if not isinstance(quote,str) or not quote.strip():
            out.append('"'+str(name)+'": user_said must be a non-empty verbatim quote'); continue
        if not quote_in_user_msg(quote):
            out.append('"'+str(name)+'": quote not found in any real user message: "'+quote+'"'); continue
        if not declares(quote, str(val)):
            out.append('"'+str(name)+'": user quote does not declare value '+str(val)+': "'+quote+'"')
    return out

def hashline_sections(text):
    sections={}
    current=None
    for line in text.splitlines():
        match=HASHLINE_HEADER.match(line.strip())
        if match:
            current=match.group('path').strip()
            sections.setdefault(current,[])
        elif current and line.startswith('+'):
            sections[current].append(line.removeprefix('+'))
    return [(path,chr(10).join(lines)) for path,lines in sections.items()]

def post_edit_text(ti):
    if ti.get('content'): return ti['content']
    path=ti.get('file_path') or ti.get('path') or ''
    old=ti.get('old_string'); new=ti.get('new_string')
    if new is not None and path and os.path.exists(path):
        try:
            cur=open(path, errors='replace').read()
            return cur.replace(old,new,1) if old else cur+chr(10)+new
        except Exception: return new
    if new is not None: return new
    edits=ti.get('edits')
    if isinstance(edits,list) and path and os.path.exists(path):
        try:
            cur=open(path, errors='replace').read()
            for e in edits:
                o=e.get('old_string'); nw=e.get('new_string','')
                cur=cur.replace(o,nw,1) if o else cur+chr(10)+nw
            return cur
        except Exception: pass
    if isinstance(edits,list):
        return chr(10).join(e.get('new_string','') for e in edits)
    if ti.get('patch'): return added_from_patch(ti['patch'])
    return ''

def path_texts(ti):
    dsl=ti.get('input') or ti.get('patch') or ''
    sections=hashline_sections(dsl)
    if sections: return sections
    path=ti.get('file_path') or ti.get('path') or ''
    return [(path,post_edit_text(ti))] if path else []

def local_file_path(path):
    parsed=urlsplit(path)
    if not parsed.scheme: return path
    if parsed.scheme.casefold()!='file' or parsed.netloc not in ('','localhost'): return None
    return unquote(parsed.path)

def check(payload):
    ti=payload.get('tool_input') or payload.get('input') or {}
    out=[]
    for raw_path,text in path_texts(ti):
        path=local_file_path(raw_path)
        if not path or not text: continue
        if PROV_RE.search(path):
            out.extend(check_provenance(text))
            continue
        if '\x00' in text:
            continue
        lg=lang_for(path)
        if lg:
            s=strip_sc(text, lg)
            out.extend('line '+str(s.count(chr(10),0,m.start())+1)+': literal `'+m.group()+'` in code -- numbers only in numeric-provenance.json with a user quote' for m in NUM.finditer(s))
        else:
            if any(path.endswith(ext) for ext in TEXT_EXT):
                continue
            out.extend('literal `'+m.group()+'` in '+path+' -- numbers only in numeric-provenance.json (no relocation)' for m in NUM.finditer(text))
    return out

def tool_name(p):
    return str(p.get('tool_name') or p.get('tool') or p.get('name') or '').lower()

def main():
    if sys.argv[1:] == ['--verify-user-quote']:
        quote=sys.stdin.read().strip()
        if quote and quote_in_user_msg(quote): return 0
        sys.stderr.write('verbatim quote not found in any real role=user transcript message'+chr(10))
        return 2
    try: payload=json.loads(sys.stdin.read())
    except Exception: return 0
    if payload.get('tool_name') is not None and tool_name(payload) not in WRITE_TOOLS: return 0
    v=check(payload)
    if v:
        sys.stderr.write('BLOCKED: numeric literal without a verbatim user-declared quote:'+chr(10)+'  '+(chr(10)+'  ').join(v)+chr(10))
        return 2
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
