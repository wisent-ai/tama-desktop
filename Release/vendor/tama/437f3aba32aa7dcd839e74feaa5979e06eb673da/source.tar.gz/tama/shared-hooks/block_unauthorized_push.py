#!/usr/bin/env python3
# Blocks publishing to a remote unless push_justifications.json records a
# verbatim current-session user grant naming the repository and the branch.
# Same shape as block-unauthorized-cua and block-unauthorized-ssh.
#
# Why: on 2026-08-06 the agent pushed to three repositories and opened three
# pull requests. One push was sanctioned, the rest were not asked for. A push is
# the moment a change becomes someone else's problem: it triggers pipelines,
# it is visible to the organization, and on a create-only release channel it
# cannot be undone. block-git-hook-bypass already guards the flags of a push
# while the push itself was ungated.
#
# Local git work stays free. Commit, branch, worktree, fetch, status and diff are
# not publishing and are never touched here.
from __future__ import annotations
import json, os, re, shlex, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from check_numeric_literals import quote_in_user_msg, tool_name  # noqa: E402

JUSTIFICATIONS = os.path.expanduser(
    os.environ.get('PUSH_JUSTIFICATIONS_FILE', '~/.shared-hooks/push_justifications.json')
)
SHELL_TOOLS = ('bash', 'eval', 'hub')
ANY_BRANCH = '*'


def publishing(command: str):
    """(kind, target) the command would publish, or None."""
    try:
        words = shlex.split(command)
    except ValueError:
        words = command.split()
    lowered = [word.lower() for word in words]
    if 'git' in ' '.join(lowered) and 'push' in lowered:
        index = lowered.index('push')
        # git push [remote] [refspec]; the refspec names the branch published.
        rest = [word for word in words[index + 1:] if not word.startswith('-')]
        target = rest[1] if len(rest) > 1 else (rest[0] if rest else 'HEAD')
        branch = target.split(':')[-1]
        return 'git push', branch or ANY_BRANCH
    if 'gh' in lowered and 'pr' in lowered:
        for verb in ('create', 'merge', 'ready', 'close', 'reopen'):
            if verb in lowered:
                base = ANY_BRANCH
                for flag in ('--base', '-B'):
                    if flag in words:
                        position = words.index(flag)
                        if position + 1 < len(words):
                            base = words[position + 1]
                return 'gh pr ' + verb, base
    if 'gh' in lowered and 'release' in lowered and 'create' in lowered:
        return 'gh release create', ANY_BRANCH
    return None


def load_grants():
    try:
        with open(JUSTIFICATIONS, 'r', encoding='utf-8') as handle:
            doc = json.load(handle)
    except FileNotFoundError:
        return [], None
    except Exception as error:
        return [], 'push_justifications.json is not valid JSON: {}'.format(error)
    if not isinstance(doc, list):
        return [], 'push_justifications.json must be a list of grants'
    return doc, None


def granted(kind: str, branch: str, cwd: str, grants) -> bool:
    repository = os.path.basename(os.path.realpath(cwd or os.getcwd()))
    for grant in grants:
        if not isinstance(grant, dict):
            continue
        if str(grant.get('repository', '')) not in (repository, ANY_BRANCH):
            continue
        allowed = grant.get('operations')
        if not isinstance(allowed, list) or kind not in allowed:
            continue
        target = str(grant.get('branch', ''))
        if target not in (branch, ANY_BRANCH):
            continue
        quote = grant.get('user_said')
        if not isinstance(quote, str) or not quote.strip():
            continue
        if not quote_in_user_msg(quote):
            continue
        return True
    return False


def check(payload):
    name = tool_name(payload)
    if not any(name.endswith(tool) for tool in SHELL_TOOLS):
        return []
    tool_input = payload.get('tool_input') or payload.get('input') or {}
    command = ''
    for key in ('command', 'code', 'text'):
        value = tool_input.get(key)
        if isinstance(value, str) and value:
            command = value
            break
    found = publishing(command)
    if not found:
        return []
    kind, branch = found
    grants, doc_error = load_grants()
    cwd = tool_input.get('cwd') or os.getcwd()
    if granted(kind, branch, cwd, grants):
        return []
    repository = os.path.basename(os.path.realpath(cwd))
    message = [
        'block-unauthorized-push: refusing {} to {} in {}.'.format(kind, branch, repository),
    ]
    if doc_error:
        message.append('  ' + doc_error)
    message.append(
        '  Publishing needs a verbatim current-session user grant in {} as '
        '[{{"repository": "{}", "branch": "{}", "operations": ["{}"], '
        '"user_said": "<exact user words>"}}]. The quote must be findable in a '
        'real role=user message. Commit locally as much as the work needs; the '
        'gate is on publication, not on progress.'.format(
            JUSTIFICATIONS, repository, branch, kind
        )
    )
    return [chr(10).join(message)]


def main():
    try:
        payload = json.loads(sys.stdin.read())
    except Exception:
        return 0
    problems = check(payload)
    if not problems:
        return 0
    for problem in problems:
        sys.stderr.write(problem + chr(10))
    return 2


if __name__ == '__main__':
    sys.exit(main())
