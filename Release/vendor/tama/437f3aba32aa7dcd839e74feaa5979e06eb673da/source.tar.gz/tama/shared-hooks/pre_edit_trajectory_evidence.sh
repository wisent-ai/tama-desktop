#!/bin/bash
# PreToolUse hook: trajectory / keeper / routine edits need evidence-based
# justification before they land.
#
# 2026-05-24 shotgun-patch incident: 8 trajectory patches shipped in one
# session based on keeper-vs-trajectory diff hypotheses with no measured
# evidence. 7 had to be reverted. This gate forces the next edit to cite
# a passing-vs-failing comparison from actual logs / row IDs / commits.
#
# Reads ~/.claude/file_justifications.json for key
#   trajectory_evidence_justification
# scoped to the file_path being edited. Requires:
#   1. >= 50 words
#   2. Contains a PASSING-run marker
#   3. Contains a NON-PASSING-run marker
#   4. Contains a concrete artifact citation (log path / webm / row UUID / commit sha)
#
# Bypass for one invocation: TRAJECTORY_EVIDENCE_DISABLED=1.

set -euo pipefail
WC_CMD=/usr/bin/wc

INPUT=$(cat)
TOOL=$(echo "$INPUT" | jq -r '.tool_name // empty')
FILE_PATH=$(echo "$INPUT" | jq -r '.tool_input.file_path // empty')

if [[ -z "$FILE_PATH" ]]; then exit 0; fi
if [[ "${TRAJECTORY_EVIDENCE_DISABLED:-0}" == "1" ]]; then exit 0; fi
if [[ "$TOOL" != "Write" && "$TOOL" != "Edit" && "$TOOL" != "MultiEdit" ]]; then exit 0; fi

if echo "$FILE_PATH" | grep -qE '(node_modules|\.git/|\.next|__pycache__|/\.claude/|/chromium-build/|/dist/)'; then exit 0; fi

if ! echo "$FILE_PATH" | grep -qE '(weles/scripts/trajectories/|weles/scripts/_shared/keeper/|weles/scripts/worker/|src/lib/platform/_shared/.*routine|/api/cron/[^/]+-routine/)'; then
    exit 0
fi

REGISTRY="$HOME/.claude/file_justifications.json"
TJ=""
if [[ -f "$REGISTRY" ]]; then
    TJ=$(jq -r --arg p "$FILE_PATH" '.[$p].trajectory_evidence_justification // empty' "$REGISTRY" 2>/dev/null)
fi
TJ_WC=$(echo "$TJ" | $WC_CMD -w | tr -d ' ')

if [[ -z "$TJ" || "$TJ_WC" -lt 50 ]]; then
    cat >&2 <<EOF
BLOCKED: trajectory/keeper/routine edit needs evidence-based justification.

Path: $FILE_PATH
Word count: $TJ_WC (need 50+)

Add a 'trajectory_evidence_justification' field for this file in
~/.claude/file_justifications.json with >= 50 words that cites BOTH:
  - A PASSING/REFERENCE source: '.work/inst/chrome_<platform>_*.json'
    (human-driven reference capture), or a passing trajectory inst file,
    or 'keeper_completed' / 'status=completed' / 'li_at=yes', or an
    account_action_logs row UUID closed completed.
  - A NON-PASSING source: '.work/inst/<trajectory>_*.json' with the FAIL,
    'failing run', 'FAIL', 'DETECTION', 'challengeUrl', 'status=failed',
    'rejected', or 'silent kill' marker.
AND at least one concrete artifact path:
  - .work/inst/<file>.json (byte-level network capture — THE GROUND TRUTH)
  - .work/runs/<file>.log (trajectory stdout)
  - recordings/<id>.webm
  - account_action_logs row <uuid8-prefix>
  - commit <sha7>

The byte-level corpus at .work/inst/ (325 files: chrome refs + trajectory
captures + diff outputs) is the canonical evidence. Run the diff harness
first: scripts/debug/diff_trajectory.mjs <trajectory.mjs> writes a
.work/inst/diff_*.json with the explicit pass-vs-fail delta.

Bypass for one invocation: TRAJECTORY_EVIDENCE_DISABLED=1
EOF
    exit 2
fi

if ! echo "$TJ" | grep -qiE '\b(passing|pass|completed|succeed|succeeded|li_at[ =]?yes|keeper_completed|status=completed|chrome[ _]reference|chrome[ _]capture|human[ -]?driven|human reference)\b|\.work/inst/chrome_'; then
    echo "BLOCKED: trajectory_evidence_justification missing PASSING/REFERENCE source (need one of: '.work/inst/chrome_<platform>_*.json' human reference, 'passing run', 'keeper_completed', 'status=completed', 'li_at=yes', 'human reference', or a row UUID with completed status). Bypass: TRAJECTORY_EVIDENCE_DISABLED=1" >&2
    exit 2
fi
if ! echo "$TJ" | grep -qiE '\b(failing|failed|fail|detection|challengeurl|challenge_url|status=failed|rejected|silent[ _]kill)\b'; then
    echo "BLOCKED: trajectory_evidence_justification missing NON-PASSING source (need one of: '.work/inst/<trajectory>_*.json' FAIL capture, 'failing run', 'FAIL', 'DETECTION', 'challengeUrl', 'status=failed', 'rejected', or 'silent kill'). Bypass: TRAJECTORY_EVIDENCE_DISABLED=1" >&2
    exit 2
fi
if ! echo "$TJ" | grep -qE '(\.work/inst/[^ ]+\.json|\.work/runs/[^ ]+\.log|recordings/[^ ]+\.webm|account_action_logs[^a-z][^ ]*[0-9a-f]{8}|\b(commit|row|sha)[: ]*[0-9a-f]{7,40}\b|\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4})'; then
    echo "BLOCKED: trajectory_evidence_justification missing concrete artifact path (need one of: '.work/inst/<file>.json' byte-level capture, '.work/runs/<file>.log' trajectory log, 'recordings/<id>.webm', 'account_action_logs row <uuid8>', or 'commit <sha7>'). Bypass: TRAJECTORY_EVIDENCE_DISABLED=1" >&2
    exit 2
fi

exit 0
