#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import re
import secrets
import shutil
import signal
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from universal_agent_runtime import (
    HookDispatcher,
    SemanticClassifier,
    SystemPolicyBackend,
    TerminalProcess,
)

SCHEMA = "ai.wisent.tama.agent-session-supervisor.v3"
SESSION_CONTROL_SCHEMA = "ai.wisent.tama.session-control.v2"
POLL_SECONDS = 0.1
DEFAULT_TIMEOUT_SECONDS = 30.0


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def load_json(path: Path) -> dict[str, Any] | None:
    try:
        value = json.loads(path.read_text())
    except (OSError, json.JSONDecodeError):
        return None
    return value if isinstance(value, dict) else None


def atomic_json(path: Path, value: dict[str, Any], mode: int = 0o600) -> None:
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    os.chmod(path.parent, 0o700)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    os.chmod(temporary, mode)
    os.replace(temporary, path)


def process_is_alive(pid: int | None) -> bool:
    if not pid or pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def safe_agent_id(value: str) -> bool:
    return (
        0 < len(value) <= 32
        and value[0].isascii()
        and value[0].isalpha()
        and all(
            character.isascii()
            and (character.islower() or character.isdigit() or character == "-")
            for character in value
        )
    )

def inferred_agent_id(executable: str) -> str:
    candidate = re.sub(r"[^a-z0-9]+", "-", Path(executable).stem.lower()).strip("-")
    if not candidate or not candidate[0].isalpha():
        candidate = f"agent-{candidate}"
    return candidate[:32].rstrip("-")



def tama_state_root(home: Path) -> Path:
    if sys.platform == "darwin":
        return home / "Library/Application Support/Tama"
    if os.name == "nt":
        return Path(os.environ.get("LOCALAPPDATA", home / "AppData/Local")) / "Tama"
    return Path(os.environ.get("XDG_STATE_HOME", home / ".local/state")) / "tama"


def control_root(home: Path) -> Path:
    configured = os.environ.get("TAMA_SESSION_SUPERVISOR_ROOT")
    return Path(configured) if configured else tama_state_root(home) / "session-supervisor"


def session_control_root(home: Path) -> Path:
    configured = os.environ.get("TAMA_SESSION_CONTROL_ROOT")
    return Path(configured) if configured else tama_state_root(home) / "session-control"

def quiesced_sessions_path(home: Path) -> Path:
    return control_root(home) / "quiesced-unsupervised.json"


def suspend_unsupervised_sessions(home: Path, pids: list[int]) -> list[int]:
    suspended: list[int] = []
    for pid in pids:
        try:
            os.kill(pid, signal.SIGSTOP)
        except ProcessLookupError:
            continue
        except PermissionError as error:
            raise RuntimeError(f"Cannot pause unsupervised agent PID {pid}: {error}") from error
        suspended.append(pid)
    if suspended:
        atomic_json(
            quiesced_sessions_path(home),
            {
                "schema": SCHEMA,
                "pids": suspended,
                "pausedAt": utc_now(),
            },
        )
    return suspended


def resume_unsupervised_sessions(home: Path) -> list[str]:
    path = quiesced_sessions_path(home)
    state = load_json(path)
    if not state:
        return []
    failures: list[str] = []
    for pid in state.get("pids", []):
        if not isinstance(pid, int) or pid <= 0:
            continue
        try:
            os.kill(pid, signal.SIGCONT)
        except ProcessLookupError:
            continue
        except PermissionError as error:
            failures.append(f"Cannot resume unsupervised agent PID {pid}: {error}")
    if not failures:
        path.unlink(missing_ok=True)
    return failures



def normalized_argv(value: Any) -> list[str] | None:
    if (
        not isinstance(value, list)
        or not value
        or not all(isinstance(item, str) and item for item in value)
    ):
        return None
    return list(value)


def render_command(template: list[str], executable: str, session_id: str | None) -> list[str]:
    replacements = {"{executable}": executable}
    if session_id is not None:
        replacements["{sessionId}"] = session_id
    rendered = []
    for item in template:
        value = item
        for marker, replacement in replacements.items():
            value = value.replace(marker, replacement)
        rendered.append(value)
    return rendered


def parse_resume_template(raw: str | None) -> list[str] | None:
    if raw is None:
        return None
    try:
        value = json.loads(raw)
    except json.JSONDecodeError as error:
        raise ValueError(f"Invalid --resume-argv-json: {error}") from error
    normalized = normalized_argv(value)
    if normalized is None:
        raise ValueError("--resume-argv-json must be a non-empty JSON string array")
    return normalized


class SessionSupervisor:
    def __init__(
        self,
        *,
        agent_id: str | None,
        command: list[str],
        cwd: Path,
        home: Path,
        session_id: str | None,
        resume_template: list[str],
        stop_timeout: float,
    ) -> None:
        self.command = command
        self.cwd = cwd
        self.home = home
        self.session_id = session_id or secrets.token_hex(16)
        self.resume_template = resume_template
        self.stop_timeout = stop_timeout
        self.executable = shutil.which(command[0]) or command[0]
        self.agent_id = agent_id or inferred_agent_id(self.executable)
        self.root = control_root(home)
        self.control_key = secrets.token_hex(32)
        self.state_path = self.root / f"{self.control_key}.session.json"
        self.child: TerminalProcess | None = None
        self.last_child_pid: int | None = None
        self.status = "starting"
        self.shutdown_signal: int | None = None
        self.exit_code = 0
        self.dispatcher = HookDispatcher(
            runner=Path(__file__).with_name("run-hook.mjs"),
            agent_id=self.agent_id,
            session_id=self.session_id,
            cwd=self.cwd,
            owner_pid=self.child_pid,
            resume_argv=self.resume_template,
            runtime_context=lambda: {"system_policy": self.system_policy.state()},
        )
        self.classifier = SemanticClassifier(
            dispatch=self.dispatcher.dispatch,
            on_block=self.handle_semantic_block,
        )
        self.system_policy = SystemPolicyBackend.from_environment(
            session_id=self.session_id,
            agent_id=self.agent_id,
            cwd=self.cwd,
            dispatch=self.dispatcher.dispatch,
            on_failure=lambda reason: self.handle_semantic_block(
                "system_policy",
                {"decision": "block", "reason": reason},
            ),
        )

    def child_pid(self) -> int | None:
        return self.child.pid if self.child and self.child.poll() is None else None

    def handle_semantic_block(self, event: str, decision: dict[str, Any]) -> None:
        child = self.child
        if child is None or child.poll() is not None:
            return
        reason = str(decision.get("reason") or "Tama blocked this operation")
        if event == "stop":
            child.write((reason + "\n").encode())
            return
        self.status = "blocked"
        self.publish()
        child.terminate()

    def state(self) -> dict[str, Any]:
        return {
            "schema": SCHEMA,
            "supervisorId": self.control_key,
            "controlKey": self.control_key,
            "supervisorPid": os.getpid(),
            "childPid": self.child_pid(),
            "lastChildPid": self.last_child_pid,
            "agentId": self.agent_id,
            "sessionId": self.session_id,
            "cwd": str(self.cwd),
            "executable": self.executable,
            "resumeSupported": True,
            "status": self.status,
            "runtime": self.dispatcher.state(),
            "systemPolicy": self.system_policy.state(),
            "updatedAt": utc_now(),
        }

    def publish(self) -> None:
        atomic_json(self.state_path, self.state())

    def start_child(self, command: list[str]) -> None:
        environment = dict(os.environ)
        environment["TAMA_SESSION_SUPERVISOR_ID"] = self.control_key
        environment["TAMA_SESSION_SUPERVISOR_PID"] = str(os.getpid())
        environment["TAMA_SESSION_ID"] = self.session_id
        environment["TAMA_AGENT_ID"] = self.agent_id
        environment["TAMA_SESSION_RESUME_ARGV_JSON"] = json.dumps(self.resume_template)
        self.child = TerminalProcess(
            command=command,
            cwd=self.cwd,
            environment=environment,
            observe_input=self.classifier.observe_input,
            observe_output=self.classifier.observe_output,
        ).start(suspended=True)
        try:
            self.system_policy.start(root_pid=self.child.pid, root_command=command)
        except Exception:
            self.child.kill()
            self.child.close()
            self.child = None
            raise
        self.child.resume()
        self.last_child_pid = self.child.pid
        self.status = "running"
        self.dispatcher.dispatch(
            "session_start",
            {
                "source": "startup",
                "resume": command != self.command,
                "observation": {"source": "process", "kind": "start"},
            },
        )
        self.publish()


    def require_resume_command(self) -> list[str]:
        if any("{sessionId}" in item for item in self.resume_template) and not self.session_id:
            raise RuntimeError("The supervised process has not published its session id")
        return render_command(self.resume_template, self.executable, self.session_id)

    def stop_child(self, reason: str = "shutdown") -> int:
        child = self.child
        if child is None:
            return 0
        code = child.poll()
        if code is None:
            child.terminate()
            deadline = time.monotonic() + self.stop_timeout
            while time.monotonic() < deadline:
                code = child.poll()
                if code is not None:
                    break
                time.sleep(POLL_SECONDS)
        if code is None:
            child.kill()
            code = child.wait()
        self.system_policy.stop()
        self.classifier.flush_output()
        self.dispatcher.dispatch(
            "session_end" if reason != "pause" else "session_pause",
            {
                "exit_code": code,
                "reason": reason,
                "observation": {"source": "process", "kind": "exit"},
            },
        )
        child.close()
        self.child = None
        return code

    def pause(self) -> None:
        self.require_resume_command()
        if self.child is None or self.child.poll() is not None:
            raise RuntimeError("The supervised agent is not running")
        self.status = "pausing"
        self.publish()
        self.stop_child("pause")
        self.status = "paused"
        self.publish()

    def resume(self) -> None:
        if self.child is not None and self.child.poll() is None:
            raise RuntimeError("The supervised agent is already running")
        self.status = "resuming"
        self.publish()
        self.start_child(self.require_resume_command())
        time.sleep(POLL_SECONDS)
        if self.child.poll() is not None:
            code = self.child.poll()
            self.stop_child("resume_failed")
            self.status = "paused"
            self.publish()
            raise RuntimeError(f"The resumed agent exited immediately with status {code}")

    def restart(self) -> None:
        self.pause()
        self.resume()

    def write_response(self, request: dict[str, Any], ok: bool, error: str | None = None) -> None:
        request_id = request.get("requestId")
        if not isinstance(request_id, str) or not request_id:
            return
        response_path = self.root / f"{self.control_key}.{request_id}.response.json"
        atomic_json(
            response_path,
            {
                "schema": SCHEMA,
                "requestId": request_id,
                "ok": ok,
                "error": error,
                "state": self.state(),
            },
        )

    def process_requests(self) -> None:
        for path in sorted(self.root.glob(f"{self.control_key}.*.request.json")):
            request = load_json(path)
            path.unlink(missing_ok=True)
            if not request:
                continue
            valid = (
                request.get("schema") == SCHEMA
                and request.get("controlKey") == self.control_key
                and request.get("supervisorId") == self.control_key
            )
            if not valid:
                self.write_response(request, False, "invalid-request-envelope")
                continue
            operation = request.get("operation")
            try:
                if operation == "pause":
                    self.pause()
                elif operation == "resume":
                    self.resume()
                elif operation == "restart":
                    self.restart()
                elif operation == "status":
                    self.publish()
                elif operation == "shutdown":
                    self.stop_child("shutdown")
                    self.status = "stopped"
                    self.publish()
                    self.shutdown_signal = signal.SIGTERM
                else:
                    raise RuntimeError(f"Unsupported supervisor operation: {operation}")
            except Exception as error:
                self.write_response(request, False, str(error))
            else:
                self.write_response(request, True)

    def handle_signal(self, signum: int, _frame: Any) -> None:
        if hasattr(signal, "SIGWINCH") and signum == signal.SIGWINCH:
            if self.child and self.child.poll() is None:
                self.child.resize()
            return
        if signum == signal.SIGINT:
            if self.child and self.child.poll() is None:
                self.child.send_signal(signum)
            return
        self.shutdown_signal = signum
        if self.child and self.child.poll() is None:
            self.child.send_signal(signum)

    def run(self) -> int:
        self.root.mkdir(parents=True, exist_ok=True, mode=0o700)
        os.chmod(self.root, 0o700)
        signal.signal(signal.SIGINT, self.handle_signal)
        signal.signal(signal.SIGTERM, self.handle_signal)
        if hasattr(signal, "SIGHUP"):
            signal.signal(signal.SIGHUP, self.handle_signal)
        if hasattr(signal, "SIGWINCH"):
            signal.signal(signal.SIGWINCH, self.handle_signal)
        try:
            self.start_child(self.command)
            while self.shutdown_signal is None:
                self.classifier.poll_idle()
                self.process_requests()
                if self.shutdown_signal is not None:
                    break
                if self.child is not None:
                    code = self.child.poll()
                    if code is not None:
                        self.exit_code = code
                        self.stop_child("exit")
                        self.status = "stopped"
                        self.publish()
                        break
                time.sleep(POLL_SECONDS)
            if self.child and self.child.poll() is None:
                self.stop_child("shutdown")
            if self.shutdown_signal is not None:
                return 128 + int(self.shutdown_signal)
            return self.exit_code
        finally:
            self.state_path.unlink(missing_ok=True)
            for path in self.root.glob(f"{self.control_key}.*.request.json"):
                path.unlink(missing_ok=True)


def live_states(root: Path, agent_id: str | None) -> list[dict[str, Any]]:
    if not root.is_dir():
        return []
    states = []
    for path in sorted(root.glob("*.session.json")):
        state = load_json(path)
        valid = (
            state
            and state.get("schema") == SCHEMA
            and state.get("controlKey") == path.name.removesuffix(".session.json")
            and isinstance(state.get("supervisorPid"), int)
            and process_is_alive(state["supervisorPid"])
        )
        if not valid:
            path.unlink(missing_ok=True)
            continue
        if agent_id is None or state.get("agentId") == agent_id:
            states.append(state)
    return states


def live_session_pids(home: Path, agent_id: str | None) -> set[int]:
    root = session_control_root(home)
    if not root.is_dir():
        return set()
    pids = set()
    for path in root.glob("*.session.json"):
        state = load_json(path)
        if (
            not state
            or state.get("schema") != SESSION_CONTROL_SCHEMA
            or state.get("livenessMode") != "process"
            or not isinstance(state.get("pid"), int)
        ):
            continue
        if agent_id is not None and state.get("agentId") != agent_id:
            continue
        if process_is_alive(state["pid"]):
            pids.add(state["pid"])
    return pids


def request_operation(
    root: Path,
    state: dict[str, Any],
    operation: str,
    timeout: float,
) -> dict[str, Any]:
    control_key = state["controlKey"]
    request_id = secrets.token_hex(16)
    request_path = root / f"{control_key}.{request_id}.request.json"
    response_path = root / f"{control_key}.{request_id}.response.json"
    atomic_json(
        request_path,
        {
            "schema": SCHEMA,
            "requestId": request_id,
            "supervisorId": control_key,
            "controlKey": control_key,
            "operation": operation,
            "requestedAt": utc_now(),
        },
    )
    deadline = time.monotonic() + timeout
    try:
        while time.monotonic() < deadline:
            response = load_json(response_path)
            if (
                response
                and response.get("schema") == SCHEMA
                and response.get("requestId") == request_id
            ):
                return response
            if not process_is_alive(state.get("supervisorPid")):
                raise RuntimeError(f"Supervisor {control_key[:12]} exited before responding")
            time.sleep(POLL_SECONDS)
        raise RuntimeError(f"Supervisor {control_key[:12]} timed out during {operation}")
    finally:
        request_path.unlink(missing_ok=True)
        response_path.unlink(missing_ok=True)


def run_control(args: argparse.Namespace) -> int:
    home = Path(args.home).expanduser().resolve()
    root = control_root(home)
    states = live_states(root, args.agent_id)
    if args.session_id is not None:
        states = [state for state in states if state.get("sessionId") == args.session_id]
    excluded_session_ids = set(args.exclude_session_id)
    if excluded_session_ids:
        states = [state for state in states if state.get("sessionId") not in excluded_session_ids]
    missing: list[int] = []
    if args.require_all:
        supervised = {
            state.get("childPid")
            for state in states
            if state.get("status") in {"running", "starting", "pausing", "resuming"}
        }
        missing = sorted(live_session_pids(home, args.agent_id) - supervised)
        if missing and args.operation != "pause":
            raise RuntimeError(
                "--require-all can quiesce unsupervised sessions only during pause"
            )
    target_statuses = {
        "pause": {"running", "starting", "resuming"},
        "resume": {"paused"},
        "restart": {"running"},
        "status": {"running", "starting", "paused", "pausing", "resuming"},
        "shutdown": {"running", "starting", "paused", "pausing", "resuming"},
    }[args.operation]
    targets = [state for state in states if state.get("status") in target_statuses]
    targets.sort(
        key=lambda state: (
            str(state.get("sessionId") or ""),
            str(state.get("controlKey") or ""),
        )
    )
    if args.one:
        targets = targets[:1]
    if args.one and not targets:
        raise RuntimeError("No matching supervised session is available")
    responses = []
    failures = []
    for state in targets:
        try:
            response = request_operation(root, state, args.operation, args.timeout)
        except Exception as error:
            failures.append(str(error))
            continue
        responses.append(response)
        if not response.get("ok"):
            failures.append(
                f"Supervisor {state['controlKey'][:12]} rejected {args.operation}: "
                f"{response.get('error') or 'unknown error'}"
            )
    quiesced_pids: list[int] = []
    if args.operation == "pause" and not failures and missing:
        try:
            quiesced_pids = suspend_unsupervised_sessions(home, missing)
        except Exception as error:
            failures.append(str(error))
    if args.operation == "resume":
        failures.extend(resume_unsupervised_sessions(home))
    print(
        json.dumps(
            {
                "schema": SCHEMA,
                "operation": args.operation,
                "agentId": args.agent_id,
                "targetCount": len(targets),
                "succeededCount": len(responses)
                - sum(not response.get("ok") for response in responses),
                "quiescedUnsupervisedPids": quiesced_pids,
                "failures": failures,
                "states": [response.get("state") for response in responses],
            },
            indent=2,
            sort_keys=True,
        )
    )
    return 1 if failures else 0


def parser() -> argparse.ArgumentParser:
    value = argparse.ArgumentParser(
        description="Editor-neutral process supervisor for resumable agent sessions."
    )
    subparsers = value.add_subparsers(dest="command_name", required=True)

    run = subparsers.add_parser("run", help="Run an agent under the persistent supervisor.")
    run.add_argument("--agent-id")
    run.add_argument("--home", default=str(Path.home()))
    run.add_argument("--cwd", default=os.getcwd())
    run.add_argument("--session-id")
    run.add_argument("--resume-argv-json")
    run.add_argument("--stop-timeout", type=float, default=10.0)
    run.add_argument("agent_command", nargs=argparse.REMAINDER)

    control = subparsers.add_parser("control", help="Control every matching live supervisor.")
    control.add_argument("operation", choices=["pause", "resume", "restart", "status", "shutdown"])
    control.add_argument("--agent-id")
    control.add_argument("--home", default=str(Path.home()))
    control.add_argument("--timeout", type=float, default=DEFAULT_TIMEOUT_SECONDS)
    control.add_argument("--require-all", action="store_true")
    control.add_argument("--session-id")
    control.add_argument("--exclude-session-id", action="append", default=[])
    control.add_argument("--one", action="store_true")
    return value


def main() -> int:
    args = parser().parse_args()
    if args.command_name == "control":
        if args.timeout <= 0:
            raise RuntimeError("--timeout must be greater than zero")
        if args.agent_id is not None and not safe_agent_id(args.agent_id):
            raise RuntimeError(f"Invalid agent ID: {args.agent_id}")
        return run_control(args)
    if args.agent_id is not None and not safe_agent_id(args.agent_id):
        raise RuntimeError(f"Invalid agent ID: {args.agent_id}")
    if args.stop_timeout <= 0:
        raise RuntimeError("--stop-timeout must be greater than zero")
    command = list(args.agent_command)
    if command and command[0] == "--":
        command = command[1:]
    if not command:
        raise RuntimeError("Missing agent command after --")
    resume_template = parse_resume_template(args.resume_argv_json) or list(command)
    return SessionSupervisor(
        agent_id=args.agent_id,
        command=command,
        cwd=Path(args.cwd).expanduser().resolve(),
        home=Path(args.home).expanduser().resolve(),
        session_id=args.session_id,
        resume_template=resume_template,
        stop_timeout=args.stop_timeout,
    ).run()


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(130)
    except Exception as error:
        print(f"Tama session supervisor failed: {error}", file=sys.stderr)
        raise SystemExit(1)
