#!/bin/bash
set -euo pipefail

INPUT=$(cat)
TOOL=$(echo "$INPUT" | jq -r '.tool_name // .tool // .name // empty')
FILE_PATH=$(echo "$INPUT" | jq -r '.tool_input.file_path // .tool_input.path // empty')
CMD=$(echo "$INPUT" | jq -r '.tool_input.command // .tool_input.cmd // .command // .cmd // empty')
PATCH=$(echo "$INPUT" | jq -r '.tool_input.patch // .tool_input.content // .tool_input.new_string // empty')

OKO_ROOT="/Users/lukaszbartoszcze/Documents/CodingProjects/Wisent/oko"

block() {
  cat >&2 <<'EOF'
BLOCKED: Do not put trajectories, Slack app install flows, browser login automation, or Weles-owned automation inside Oko. Put it in /Users/lukaszbartoszcze/Documents/CodingProjects/Wisent/weles/scripts/trajectories/ and call it from there. Oko may consume Slack tokens and APIs; Weles owns trajectories and login/install automation.
EOF
  exit 2
}

is_oko_path() {
  local value="$1"
  [[ "$value" == "$OKO_ROOT"* || "$value" == *"/Documents/CodingProjects/Wisent/oko/"* ]]
}

is_trajectory_or_install_path() {
  local value="$1"
  echo "$value" | grep -qiE '(/scripts/trajector(y|ies)/|trajector(y|ies)|slack[-_].*(upgrade|install|oauth|manifest|permission|app)|slack.*(upgrade|install|oauth|manifest|permission).*\.mjs|browser[-_].*(login|install|oauth)|login[-_].*(automation|trajectory)|install[-_].*(automation|trajectory))'
}

contains_oko_trajectory_write() {
  local value="$1"
  echo "$value" | grep -qiE '(/Users/lukaszbartoszcze/Documents/CodingProjects/Wisent/oko|Documents/CodingProjects/Wisent/oko|/oko/)'
}

contains_trajectory_or_install_content() {
  local value="$1"
  echo "$value" | grep -qiE '(WSession\.start|humanClickLocator|humanIdlePause|googleSso|apps\.manifest\.(create|update|validate)|oauth/v2/authorize|install-on-team|window\.boot_data|xoxc-|recordVideo|recordHar|browser login|Slack app install|Slack app permission|trajectory)'
}

if [[ -n "$FILE_PATH" ]] && is_oko_path "$FILE_PATH" && is_trajectory_or_install_path "$FILE_PATH"; then
  block
fi

if [[ -n "$FILE_PATH" ]] && is_oko_path "$FILE_PATH" && contains_trajectory_or_install_content "$PATCH"; then
  block
fi

if [[ "$TOOL" == "apply_patch" && -n "$PATCH" ]]; then
  if contains_oko_trajectory_write "$PATCH" && contains_trajectory_or_install_content "$PATCH"; then
    block
  fi
  if echo "$PATCH" | grep -qiE '^\*\*\* (Add|Update) File: .*/oko/.*(trajector(y|ies)|slack[-_].*(upgrade|install|oauth|manifest|permission|app)|browser[-_].*(login|install|oauth))'; then
    block
  fi
fi

if [[ "$TOOL" == "Bash" && -n "$CMD" ]]; then
  if contains_oko_trajectory_write "$CMD" && contains_trajectory_or_install_content "$CMD"; then
    block
  fi
  if echo "$CMD" | grep -qiE '(>|tee|cp|mv|install|python|node|perl|ruby|sed -i).*oko/.*(trajector(y|ies)|slack[-_].*(upgrade|install|oauth|manifest|permission|app)|browser[-_].*(login|install|oauth))'; then
    block
  fi
fi

exit 0
