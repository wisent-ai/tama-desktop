#!/usr/bin/env python3
"""Stop hook: flag final-answer phrasing that hands work back instead of continuing."""
from __future__ import annotations

import json
import re
import sys

MESSAGE = "GET TO WORK. CONTINUE WORKING UNTIL YOU ARE DONE."

PATTERNS = [
    r"\bnext\s+real\s+blocker\s+is\b",
    r"\bthe\s+next\s+real\s+blocker\s+is\b",
    r"\bnext\s+blocker\s+is\b",
    r"\bthe\s+blocker\s+is\b",
    r"\breal\s+blocker\s+is\b",
    r"\bnext\s+actual\s+blocker\s+is\b",
    r"\bactual\s+blocker\s+is\b",
    r"\bnext\s+thing\s+blocking\s+(this|us|me)\s+is\b",
    r"\bwhat'?s?\s+blocking\s+(this|us|me)\s+now\s+is\b",
]

COMPILED = [re.compile(pattern, flags=re.IGNORECASE) for pattern in PATTERNS]

SELF_TEST_CASES = [
  ("Next real blocker is configuring the worker.", True),
  ("The next real blocker is auth.", True),
  ("Next blocker is model capacity.", True),
  ("The blocker is missing credentials.", True),
  ("Actual blocker is deployment.", True),
  ("The phrase `Next real blocker is` is banned.", False),
  ("Work completed and deployed.", False),
]


def strip_quoted_context(text: str) -> str:
  text = re.sub(r"```[\s\S]*?```", " ", text)
  text = re.sub(r"`[^`\n]+`", " ", text)
  text = re.sub(r"\"[^\"]*\"", " ", text)
  text = re.sub(r"'[^']*'", " ", text)
  text = re.sub(r"“[^”]*”", " ", text)
  return text


def find_hits(text: str) -> list[str]:
  scan = strip_quoted_context(text)
  hits: list[str] = []
  for regex in COMPILED:
    for match in regex.finditer(scan):
      hits.append(match.group(0).strip())
  return list(dict.fromkeys(hits))


def main() -> int:
  if "--self-test" in sys.argv:
    failures: list[str] = []
    for text, expected in SELF_TEST_CASES:
      actual = bool(find_hits(text))
      if actual != expected:
        failures.append(f"{text!r}: expected {expected}, got {actual}")
    if failures:
      print("\n".join(failures), file=sys.stderr)
      return 1
    print(f"{len(SELF_TEST_CASES)} continue-working hook tests passed")
    return 0

  raw = sys.stdin.read() or "{}"
  try:
    payload = json.loads(raw)
  except json.JSONDecodeError:
    payload = {"last_assistant_message": raw}

  if payload.get("stop_hook_active"):
    return 0

  msg = payload.get("last_assistant_message") or payload.get("message") or ""
  if not isinstance(msg, str) or not msg.strip():
    return 0

  hits = find_hits(msg)
  if not hits:
    return 0

  print(json.dumps({
    "decision": "block",
    "reason": f"{MESSAGE} Flagged phrase: {hits[0]}",
  }))
  return 0


if __name__ == "__main__":
  raise SystemExit(main())
