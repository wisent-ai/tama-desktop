#!/usr/bin/env bash
# Daily sweep: scan ~/.claude/projects/ for transcripts modified since the last
# successful run, mirror them under <user>@<host>/, and push to this repo.
# Runs from launchd (macOS) or cron (Linux). Idempotent and concurrency-safe via mkdir lock.
set -euo pipefail

REPO_DIR="$HOME/.claude/transcripts-repo"
PROJECTS_DIR="$HOME/.claude/projects"
STATE_FILE="$REPO_DIR/.git/last-sweep.timestamp"
LOG_FILE="$HOME/.claude/hooks/push-transcript.log"
LOCK_DIR="$REPO_DIR/.git/transcript-push.lock.d"
MAX_BYTES=$((95 * 1024 * 1024))

mkdir -p "$(dirname "$LOG_FILE")"
exec >> "$LOG_FILE" 2>&1
echo "=== sweep $(date) ==="

acquire_lock() {
    local i
    for i in $(seq 1 60); do
        if mkdir "$LOCK_DIR" 2>/dev/null; then
            trap 'rmdir "$LOCK_DIR" 2>/dev/null || true' EXIT
            return 0
        fi
        sleep 0.5
    done
    return 1
}

acquire_lock || { echo "lock timeout, skipping"; exit 0; }

[ ! -d "$REPO_DIR/.git" ] && { echo "repo missing at $REPO_DIR"; exit 1; }
[ ! -d "$PROJECTS_DIR" ] && { echo "no projects dir"; exit 0; }

if [ -f "$STATE_FILE" ]; then
    SINCE_FILE="$STATE_FILE"
else
    SINCE_FILE="$REPO_DIR/.git/.bootstrap-since"
    touch -t "$(date -v-25H +%Y%m%d%H%M 2>/dev/null || date -d '25 hours ago' +%Y%m%d%H%M)" "$SINCE_FILE" 2>/dev/null \
        || touch "$SINCE_FILE"
fi

hostname=$(hostname -s)
user=$(whoami)
copied=0
skipped_size=0

while IFS= read -r src; do
    [ -f "$src" ] || continue
    size=$(stat -f%z "$src" 2>/dev/null || stat -c%s "$src" 2>/dev/null || echo 0)
    if [ "$size" -gt "$MAX_BYTES" ]; then
        skipped_size=$((skipped_size + 1))
        continue
    fi
    rel="${src#$PROJECTS_DIR/}"
    dest="$REPO_DIR/$user@$hostname/$rel"
    mkdir -p "$(dirname "$dest")"
    cp "$src" "$dest"
    copied=$((copied + 1))
done < <(find "$PROJECTS_DIR" -name "*.jsonl" -type f -newer "$SINCE_FILE" 2>/dev/null)

echo "copied=$copied skipped_oversize=$skipped_size"

cd "$REPO_DIR"
git pull --rebase --autostash --quiet || echo "pull failed (continuing)"
git add -A >/dev/null 2>&1 || true
if git diff --cached --quiet; then
    echo "no changes to commit"
else
    msg="$user@$hostname daily sweep $(date -u +%Y-%m-%dT%H:%M:%SZ): $copied transcripts"
    git -c user.email="${GIT_AUTHOR_EMAIL:-$user@$hostname}" \
        -c user.name="${GIT_AUTHOR_NAME:-$user}" \
        commit --quiet -m "$msg"
    if git push --quiet origin HEAD; then
        echo "pushed $copied files"
        touch "$STATE_FILE"
    else
        echo "push failed — state file NOT advanced, will retry next sweep"
    fi
fi
