#!/bin/bash
# Max file lines (300). Moved verbatim out of pre_write_edit.sh so the limit
# the operator asked for can be enforced on its own, without carrying the
# new-file justification rule that shipped in the same script.
set -euo pipefail

source "$(dirname "$0")/write_payload_env.sh"

# A registry is a list, not a module. `test_justifications.json` and
# `file_justifications.json` grow one entry per decision and the hooks
# themselves read them, so "split into smaller modules" is not an instruction
# anyone can follow here: splitting a registry breaks its reader, and the
# limit exists for source a person edits and navigates. Structured data files
# are therefore exempt from the line count, on the operator's instruction
# ("wylacz limit dla plikow rejestrow", 2026-09-10), while every other rule —
# the folder-file limit, the new-file justification, the content gates —
# still applies to them.
#
# A manuscript is one document, not a module tree. Its length is set by the
# venue, a person navigates it by \section and the editor's outline, and the
# bibliography and style files beside it are data the venue supplies. The
# LaTeX family is therefore exempt from the line count as well, on the
# operator's instruction ("do it in a way where the 300-line and
# 5-files-per-folder hooks do not apply to .tex", 2026-09-14). The content
# gates still apply to it.
shopt -s nocasematch
case "$FILE_PATH" in
    *.json|*.jsonl|*.ndjson|*.lock|*.csv|*.tsv) exit 0 ;;
    *.tex|*.bib|*.sty|*.bst|*.cls) exit 0 ;;
esac
shopt -u nocasematch

if [[ "$IS_SYSTEM" == "false" ]]; then
    if [[ ("$TOOL" == "Write" || "$TOOL" == "Create") && -n "$CONTENT" ]]; then
        LINES=$(echo "$CONTENT" | $WC_CMD -l | tr -d ' ')
        if [[ "$LINES" -gt 300 ]]; then
            echo "BLOCKED: File would be $LINES lines (max 300). Split into smaller modules." >&2
            exit 2
        fi
    fi
    if [[ ("$TOOL" == "Edit" || "$TOOL" == "apply_patch") && -f "$FILE_PATH" ]]; then
        CURRENT_LINES=$($WC_CMD -l < "$FILE_PATH" | tr -d ' ')
        OLD_STRING=$(echo "$INPUT" | jq -r '.tool_input.old_string // empty')
        NEW_STRING=$(echo "$INPUT" | jq -r '.tool_input.new_string // empty')
        OLD_LINES=$(echo "$OLD_STRING" | $WC_CMD -l | tr -d ' ')
        NEW_LINES=$(echo "$NEW_STRING" | $WC_CMD -l | tr -d ' ')
        RESULT_LINES=$((CURRENT_LINES - OLD_LINES + NEW_LINES))
        if [[ "$RESULT_LINES" -gt 300 ]]; then
            echo "BLOCKED: File would be ~$RESULT_LINES lines after edit (max 300). Split into smaller modules." >&2
            exit 2
        fi
    fi
fi

exit 0
