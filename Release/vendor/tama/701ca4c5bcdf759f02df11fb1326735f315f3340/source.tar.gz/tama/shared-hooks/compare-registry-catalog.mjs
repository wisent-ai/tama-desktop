#!/usr/bin/env node
// Compare the runtime event wiring with the human-auditable agent hook catalog.
// Usage: node compare-registry-catalog.mjs [registry-path]

import { readFile } from 'node:fs/promises'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const here = dirname(fileURLToPath(import.meta.url))
const registryPath = process.argv.at(Number('2')) || join(here, 'registry.json')

try {
  const registry = JSON.parse(await readFile(registryPath, 'utf8'))
  const wiredEvents = new Map()
  for (const [event, config] of Object.entries(registry.events || {})) {
    for (const hook of config.hooks || []) {
      if (!hook.id) continue
      const events = wiredEvents.get(hook.id) || []
      if (!events.includes(event)) events.push(event)
      wiredEvents.set(hook.id, events)
    }
  }

  const wiredIds = [...wiredEvents.keys()].sort()
  const catalogIds = [...new Set(
    (registry.catalog?.agentHooks || []).map(hook => hook.id).filter(Boolean),
  )].sort()
  const wiredSet = new Set(wiredIds)
  const catalogSet = new Set(catalogIds)
  const wiredOnly = wiredIds.filter(id => !catalogSet.has(id))
  const catalogOnly = catalogIds.filter(id => !wiredSet.has(id))
  const eventsForWiredOnly = Object.fromEntries(
    wiredOnly.map(id => [id, wiredEvents.get(id).sort()]),
  )

  process.stdout.write(`${JSON.stringify({
    registry: registryPath,
    wiredCount: wiredIds.length,
    catalogCount: catalogIds.length,
    wiredIds,
    catalogIds,
    wiredOnly,
    catalogOnly,
    eventsForWiredOnly,
  }, null, Number('2'))}\n`)
} catch (error) {
  const message = error instanceof Error ? error.message : String(error)
  process.stderr.write(`registry/catalog comparison failed: ${message}\n`)
  process.exitCode = Number('1')
}
