#!/bin/bash
# Max folder files (5), for new files only. Moved verbatim out of
# pre_write_edit.sh so the limit the operator asked for stands on its own.
set -euo pipefail

source "$(dirname "$0")/write_payload_env.sh"

# A manuscript's folder holds the document, its bibliography and the venue's
# style files side by side, and a venue template decides that layout, not
# module discipline. New LaTeX-family files are therefore exempt from the
# folder-file limit, on the operator's instruction ("do it in a way where the
# 300-line and 5-files-per-folder hooks do not apply to .tex", 2026-09-14).
shopt -s nocasematch
case "$FILE_PATH" in
    *.tex|*.bib|*.sty|*.bst|*.cls) exit 0 ;;
esac
shopt -u nocasematch

if [[ "$IS_SYSTEM" == "false" && ! -f "$FILE_PATH" ]]; then
    DIR=$(dirname "$FILE_PATH")
    case "$DIR" in
        */supabase/migrations*|*/node_modules/*|*/.git/*|*/__pycache__/*|*/tests*|*/migrations*)
            ;;
        *)
            if [[ -d "$DIR" ]]; then
                FILE_COUNT=$(find "$DIR" -maxdepth 1 -type f 2>/dev/null | $WC_CMD -l | tr -d ' ')
                if [[ "$FILE_COUNT" -ge 5 ]]; then
                    echo "BLOCKED: Folder '$DIR' already has $FILE_COUNT files (max 5). Move files into sub-folders or consolidate." >&2
                    exit 2
                fi
            fi
            ;;
    esac
fi

exit 0
