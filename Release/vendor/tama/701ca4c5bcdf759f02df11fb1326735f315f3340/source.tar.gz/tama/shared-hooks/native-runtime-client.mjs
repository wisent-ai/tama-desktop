import { spawn } from 'node:child_process'
import { createInterface } from 'node:readline'

// JSON-lines transport only. Registry loading and policy belong to Tama's core.
export class NativeRuntimeClient {
  constructor(executable, environment, timeoutMs) {
    this.executable = executable
    this.environment = environment
    this.timeoutMs = timeoutMs
    this.child = null
    this.pending = null
    this.stderr = ''
  }

  waitFor(id, timeoutMs, send) {
    if (this.pending) return Promise.reject(new Error('Tama core request is already in flight'))
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.fail(new Error(`Tama core ${id || 'startup'} timed out after ${timeoutMs}ms`))
      }, timeoutMs)
      this.pending = { id, resolve, reject, timer }
      try { send() } catch (error) { this.fail(error) }
    })
  }

  fail(error) {
    const child = this.child
    this.child = null
    const pending = this.pending
    this.pending = null
    if (child) {
      // The process group contains only this client and its hook children.
      if (process.platform === 'win32') child.kill('SIGKILL')
      else {
        try { process.kill(-child.pid, 'SIGKILL') } catch (killError) {
          if (killError.code !== 'ESRCH') process.stderr.write(`${killError.message}\n`)
        }
      }
    }
    if (pending) {
      clearTimeout(pending.timer)
      pending.reject(new Error(`${this.executable}: ${error.message || error}${this.stderr ? `\n${this.stderr}` : ''}`))
    }
  }

  async start() {
    this.stderr = ''
    const child = spawn(this.executable, ['--serve', 'omp'], {
      env: this.environment,
      detached: process.platform !== 'win32',
      stdio: ['pipe', 'pipe', 'pipe'],
    })
    this.child = child
    const lines = createInterface({ input: child.stdout, crlfDelay: Infinity })
    lines.on('line', line => {
      if (this.child !== child) return
      try {
        const reply = JSON.parse(line)
        const pending = this.pending
        const matches = pending && (pending.id === null
          ? reply.type === 'ready' && reply.state?.processId === child.pid
          : reply.id === pending.id)
        if (!matches) throw new Error('Unexpected Tama core response')
        clearTimeout(pending.timer)
        this.pending = null
        pending.resolve(reply)
      } catch (error) { this.fail(error) }
    })
    child.stderr.setEncoding('utf8')
    child.stderr.on('data', chunk => {
      if (this.child !== child) return
      this.stderr += chunk
      process.stderr.write(chunk)
    })
    child.on('error', error => { if (this.child === child) this.fail(error) })
    child.stdin.on('error', error => { if (this.child === child) this.fail(error) })
    child.on('close', (code, signal) => {
      lines.close()
      if (this.child === child) this.fail(new Error(`Tama core exited: code=${code}, signal=${signal}`))
    })
    await this.waitFor(null, this.timeoutMs, () => {})
  }

  async request(request, timeoutMs) {
    if (!this.child) await this.start()
    this.stderr = ''
    return this.waitFor(request.id, timeoutMs, () => {
      this.child.stdin.write(`${JSON.stringify(request)}\n`)
    })
  }

  async close() {
    const child = this.child
    if (!child) return
    if (this.pending) {
      this.fail(new Error('Tama core closed during a request'))
      return
    }
    await new Promise(resolve => {
      const timer = setTimeout(() => {
        if (this.child === child) this.fail(new Error('Tama core did not close stdin'))
      }, this.timeoutMs)
      child.once('close', () => { clearTimeout(timer); resolve() })
      child.stdin.end()
    })
  }
}
