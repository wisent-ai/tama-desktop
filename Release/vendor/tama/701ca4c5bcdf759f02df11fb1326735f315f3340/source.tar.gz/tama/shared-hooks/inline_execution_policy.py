#!/usr/bin/env python3
"""Detect throwaway inline programs across agent tool payloads."""

from __future__ import annotations

import json
import re
from typing import Any

ALWAYS_INLINE_TOOLS = {
    "eval",
    "functions.eval",
    "notebook",
    "functions.notebook",
    "node_repl",
    "node_repl/js",
    "mcp__node_repl_js",
}
WRITE_TOOLS = {"write", "functions.write"}
BROWSER_TOOLS = {"browser", "functions.browser"}
DEBUG_TOOLS = {"debug", "functions.debug"}
NODE_REPL_DEVICE = "xd://mcp__node_repl_js"
BROWSER_DEVICE = "xd://browser"
DEBUG_DEVICE = "xd://debug"
COMMAND_PREFIX = r"(?:^|[;&|`(]\s*)(?:(?:sudo|env|command|exec)\s+|[A-Za-z_][A-Za-z0-9_]*=\S+\s+)*(?:[^\s;&|`()]+/)?"

INLINE_COMMAND_PATTERNS = tuple(
    re.compile(COMMAND_PREFIX + pattern, re.IGNORECASE)
    for pattern in (
        r"(?:bash|sh|zsh|dash|fish)(?:\s+(?:-c|--command)(?:\s|=|$)|[^;&|`]*<<|[^;&|`]*<\()",
        r"python(?:[0-9]+(?:\.[0-9]+)*)?(?:\s+(?:-c|--command|-)(?:\s|$)|[^;&|`]*<<|[^;&|`]*<\(|\s+/dev/stdin)",
        r"(?:node|bun|deno|tsx|ts-node)(?:\s+(?:run|exec))?\s+(?:-e|--eval|-p|--print|-)(?:\s|$)",
        r"(?:node|bun|deno|tsx|ts-node)(?:[^;&|`]*<<|[^;&|`]*<\(|\s+/dev/stdin)",
        r"npx\s+[^;&|`]*(?:tsx|ts-node|node)\s+(?:-e|--eval|-p|--print|-)(?:\s|$)",
        r"(?:ruby|perl|php|lua|Rscript)(?:\s+(?:-e|--execute|-r|-)(?:\s|$)|[^;&|`]*<<|[^;&|`]*<\(|\s+/dev/stdin)",
        r"(?:osascript|swift|julia|clojure|elixir|R|pwsh|powershell)(?:\s+--?[A-Za-z][^\s;&|]*)*\s+(?:-e|--eval|-c|-Command|-)(?:\s|$)",
        r"(?:awk|gawk|mawk)(?:\s|$)",
        # `jq` takes its filter program on the command line, which is the same
        # throwaway inline program as `python -c`: nobody can review it, rerun
        # it, or diff it. It stays allowed when the program comes from a
        # checked-in file (`-f` / `--from-file`) and when the invocation only
        # asks jq about itself.
        r"jq(?![^;&|`\n]*(?:\s-f\b|\s--from-file\b|\s--version\b|\s--help\b|\s-h\b))(?:\s|$)",
        r"(?:source|\.)\s+<\(",
        r"eval(?:\s|$)",
    )
)
CONTROL_FLOW_RE = re.compile(
    r"(?:^|[;\n]\s*)(?:for|while|until|if|case|select|function)\b"
    r"|(?:^|[;\n]\s*)[A-Za-z_][A-Za-z0-9_]*\s*\(\)\s*\{",
    re.IGNORECASE,
)


def tool_name(payload: dict[str, Any]) -> str:
    value = payload.get("tool_name") or payload.get("name") or payload.get("tool") or ""
    if isinstance(value, dict):
        value = value.get("name") or value.get("tool_name") or ""
    return str(value).strip().casefold()


def tool_input(payload: dict[str, Any]) -> dict[str, Any]:
    value = payload.get("tool_input") or payload.get("input")
    if isinstance(value, dict):
        return value
    nested = payload.get("tool")
    if isinstance(nested, dict):
        value = nested.get("input") or nested.get("tool_input")
        if isinstance(value, dict):
            return value
    return {}


def parsed_device_content(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return value
    if not isinstance(value, str):
        return {}
    try:
        parsed = json.loads(value)
    except (json.JSONDecodeError, ValueError):
        return {}
    return parsed if isinstance(parsed, dict) else {}


def command_text(name: str, inputs: dict[str, Any]) -> str:
    direct = inputs.get("command") or inputs.get("cmd")
    if isinstance(direct, str):
        return direct
    if name in {"hub", "functions.hub"} and str(inputs.get("op") or "").casefold() == "start":
        application = str(inputs.get("application") or "")
        args = inputs.get("args") if isinstance(inputs.get("args"), list) else []
        return " ".join([application, *(str(argument) for argument in args)]).strip()
    return ""


def inline_execution_reason(payload: dict[str, Any]) -> str | None:
    name = tool_name(payload)
    inputs = tool_input(payload)

    if name in ALWAYS_INLINE_TOOLS:
        return f"inline execution tool: {name}"

    action = str(inputs.get("action") or "").casefold()
    if name in BROWSER_TOOLS and action == "run":
        return "inline JavaScript in browser run"
    if name in DEBUG_TOOLS and action == "evaluate":
        return "inline debugger evaluation"

    if name in WRITE_TOOLS:
        path = str(inputs.get("path") or "")
        if path == NODE_REPL_DEVICE:
            return "inline JavaScript in the Node REPL device"
        device = parsed_device_content(inputs.get("content"))
        device_action = str(device.get("action") or "").casefold()
        if path == BROWSER_DEVICE and device_action == "run":
            return "inline JavaScript in the browser device"
        if path == DEBUG_DEVICE and device_action == "evaluate":
            return "inline debugger evaluation through the debug device"

    command = command_text(name, inputs)
    if CONTROL_FLOW_RE.search(command):
        return "inline shell control flow in a command"
    for pattern in INLINE_COMMAND_PATTERNS:
        if pattern.search(command):
            return "inline interpreter program in a command"
    return None
