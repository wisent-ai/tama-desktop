import { spawn } from 'node:child_process'
import { tokenizeCommand } from './hook-exec.mjs'
import { NativeRuntimeClient } from './native-runtime-client.mjs'
import {
  appendFileSync,
  chmodSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  renameSync,
  rmSync,
  writeFileSync,
} from 'node:fs'
import { createHash, randomUUID } from 'node:crypto'
import { homedir } from 'node:os'
import { basename, dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import {
  CAPABILITY_SCHEMA_VERSION,
  capabilityEnvironment,
  normalizeCapabilityGrants,
  normalizedCapability,
} from './session-capability.mjs'
import { sessionResumeArgv } from './session-control.mjs'
import { loadHookEnforcement, shouldEnforceHook } from './enforcement-selection.mjs'

const SHARED_HOOKS_ROOT = dirname(fileURLToPath(import.meta.url))
const REGISTRY_PATH = process.env.AGENT_HOOK_REGISTRY || join(SHARED_HOOKS_ROOT, 'registry.json')
const SESSION_OVERRIDE_TOOL = 'tama_set_session_hook'
const SESSION_ENABLE_ALL_TOOL = 'tama_enable_all_session_hooks'
const SESSION_CAPABILITY_TOOL = 'tama_request_session_capability'
const RUNTIME_RELOAD_TOOL = 'tama_reload_hook_runtime'
const RUNTIME_STATUS_TOOL = 'tama_hook_runtime_status'
const CONTROL_PLANE_TOOLS = new Set([
  SESSION_OVERRIDE_TOOL,
  SESSION_ENABLE_ALL_TOOL,
  SESSION_CAPABILITY_TOOL,
  RUNTIME_RELOAD_TOOL,
  RUNTIME_STATUS_TOOL,
])
const SESSION_OVERRIDE_ENTRY = 'tama:session-hook-overrides'
const SESSION_CONTROL_SCHEMA = 'ai.wisent.tama.session-control.v2'
const EMERGENCY_STATE_SCHEMA = 'ai.wisent.tama.hook-emergency-state.v1'
const HOOK_TIMEOUT_MS = 10000
const SESSION_CONTROL_POLL_MS = 250
const ACTIVATION_PREFLIGHT_HOOK_IDS = new Set([
  'block-objective-substitution',
  'check-open-items-with-model',
])
const emergencyStatePath = process.env.TAMA_EMERGENCY_STATE || join(
  homedir(),
  'Library',
  'Application Support',
  'Tama',
  'hook-emergency-state.json',
)
const sessionControlRoot = process.env.TAMA_SESSION_CONTROL_ROOT || join(
  homedir(),
  'Library',
  'Application Support',
  'Tama',
  'session-control',
)
const installedStatePath = process.env.TAMA_INSTALLED_HOOK_RELEASE || join(
  homedir(),
  'Library',
  'Application Support',
  'Tama',
  'hooks-runtime',
  'installed.json',
)

function loadJson(path, fallback) {
  try {
    return JSON.parse(readFileSync(path, 'utf8'))
  } catch {
    return fallback
  }
}

function stableValue(value) {
  if (Array.isArray(value)) return value.map(stableValue)
  if (!value || typeof value !== 'object') return value
  return Object.fromEntries(Object.keys(value).sort().map(key => [key, stableValue(value[key])]))
}

function registryChecksum(registry) {
  const value = { ...registry }
  delete value.catalogChecksum
  return createHash('sha256').update(JSON.stringify(stableValue(value))).digest('hex')
}

function registrySnapshot(registry = loadJson(REGISTRY_PATH, null)) {
  if (!registry || typeof registry !== 'object' || Array.isArray(registry)) {
    throw new Error(`Invalid Tama hook registry: ${REGISTRY_PATH}`)
  }
  if (!registry.events || typeof registry.events !== 'object' || Array.isArray(registry.events)) {
    throw new Error('Tama hook registry has no events object')
  }
  const expectedChecksum = String(registry.catalogChecksum || '')
  const actualChecksum = registryChecksum(registry)
  if (!expectedChecksum || expectedChecksum !== actualChecksum) {
    throw new Error(`Tama hook registry checksum mismatch: expected ${expectedChecksum || 'missing'}, actual ${actualChecksum}`)
  }
  const hookIds = new Set()
  for (const entry of Object.values(registry.events)) {
    if (!entry || !Array.isArray(entry.hooks)) continue
    for (const hook of entry.hooks) {
      const id = String(hook?.id || '').trim()
      if (id) hookIds.add(id)
    }
  }
  return {
    registry,
    hookIds,
    releaseId: String(registry.releaseId || 'unknown'),
    catalogChecksum: actualChecksum,
  }
}

export default function sharedHooks(pi) {
// OMP imports this module once but calls the factory for every session.
// Keep session identity, permissions, timers, and decisions in this instance.
let loadedRegistry = { events: {} }
let knownHookIds = new Set()
let loadedReleaseId = 'unknown'
let loadedCatalogChecksum = null
let registryLoadError = null
let runtimeStartedAt = new Date().toISOString()
let reloadCount = 0
let lastReloadAt = null
let lastReloadError = null
let pendingRuntimeReload = null
let sharedRuntimeQueue = Promise.resolve()
const sharedRuntimeClient = new NativeRuntimeClient(
  join(dirname(installedStatePath), 'current', 'bin', 'tama-run-hook'),
  capabilityEnvironment(null, {
    AGENT_HOOK_REGISTRY: REGISTRY_PATH,
    TAMA_PROVIDER: 'omp',
    TAMA_SESSION_CONTROL_ROOT: sessionControlRoot,
    TAMA_SESSION_OWNER_PID: String(process.pid),
    TAMA_ONLY_HOOK_ID: undefined, TAMA_ENABLED_HOOKS: undefined, TAMA_DISABLED_HOOKS: undefined,
  }),
  HOOK_TIMEOUT_MS,
)
let lastDecision = null

function installRegistrySnapshot(snapshot) {
  loadedRegistry = snapshot.registry
  knownHookIds = snapshot.hookIds
  loadedReleaseId = snapshot.releaseId
  loadedCatalogChecksum = snapshot.catalogChecksum
  registryLoadError = null
}

try {
  installRegistrySnapshot(registrySnapshot())
} catch (error) {
  registryLoadError = error instanceof Error ? error.message : String(error)
}

function emergencyState() {
  const state = loadJson(emergencyStatePath, null)
  const disabled = state?.schema === EMERGENCY_STATE_SCHEMA && state.disabled === true
  const changedAt = disabled
    && typeof state.changedAt === 'string'
    && state.changedAt.trim()
    ? state.changedAt
    : null
  return { disabled, changedAt }
}

function hooksGloballyDisabled() {
  return emergencyState().disabled
}

function installedReleaseState() {
  const value = loadJson(installedStatePath, {})
  return {
    releaseId: typeof value.releaseId === 'string' ? value.releaseId : null,
    catalogChecksum: typeof value.catalogChecksum === 'string' ? value.catalogChecksum : null,
    installedAt: typeof value.installedAt === 'string' ? value.installedAt : null,
  }
}

let currentSessionId = null
let currentSessionKey = null
let currentSessionCwd = null
let currentSessionContext = null
let disabledHookIds = new Set()
let enabledHookIds = new Set()
let emergencyChangedAt = null
let unknownHookIds = new Set()
let currentCapability = null
let sessionControlTimer = null
let sessionControlStatePath = null
let sessionControlOverridePath = null
let exitCleanupRegistered = false

function resolvedSessionId(event, ctx) {
  const explicit = event?.sessionId || event?.session_id || event?.session?.id
  if (explicit) return String(explicit)
  const current = ctx?.sessionManager?.getSessionId?.()
  if (current) return String(current)
  const sessionFile = ctx?.sessionManager?.getSessionFile?.()
  if (!sessionFile) return null
  const name = basename(String(sessionFile), '.jsonl')
  const separator = name.lastIndexOf('_')
  return separator >= 0 ? name.slice(separator + 1) : name
}

function capabilityIdentity(controlKey = currentSessionKey) {
  return { controlKey, releaseId: loadedReleaseId, catalogChecksum: loadedCatalogChecksum }
}

function sanitizedIds(values) {
  const known = []
  for (const value of Array.isArray(values) ? values : []) {
    const id = String(value || '').trim()
    if (!id) continue
    if (knownHookIds.has(id)) known.push(id)
    else unknownHookIds.add(id)
  }
  return [...new Set(known)].sort()
}

function sanitizedDisabledIds(_values) {
  return []
}

function restoredHookOverrides(ctx, activeSessionId) {
  let restored = {
    disabledHookIds: [],
    enabledHookIds: [],
    capability: null,
    emergencyChangedAt: null,
  }
  if (!activeSessionId) return restored
  for (const entry of ctx?.sessionManager?.getBranch?.() || []) {
    if (entry?.type !== 'custom' || entry.customType !== SESSION_OVERRIDE_ENTRY) continue
    if (entry.data?.sessionId !== activeSessionId) continue
    restored = {
      disabledHookIds: entry.data.disabledHookIds,
      enabledHookIds: entry.data.enabledHookIds,
      capability: entry.data.capability,
      emergencyChangedAt: entry.data.emergencyChangedAt,
    }
  }
  const emergency = emergencyState()
  const restoredEmergencyChangedAt = typeof restored.emergencyChangedAt === 'string'
    && restored.emergencyChangedAt.trim()
    ? restored.emergencyChangedAt
    : null
  const emergencyBindingMatches = !emergency.disabled
    || Boolean(emergency.changedAt && restoredEmergencyChangedAt === emergency.changedAt)
  return {
    disabledHookIds: sanitizedDisabledIds(restored.disabledHookIds),
    enabledHookIds: emergencyBindingMatches ? sanitizedIds(restored.enabledHookIds) : [],
    capability: emergencyBindingMatches
      ? normalizedCapability(
          restored.capability,
          activeSessionId,
          Date.now(),
          capabilityIdentity(sessionControlKey(activeSessionId)),
        )
      : null,
    emergencyChangedAt: emergency.disabled ? restoredEmergencyChangedAt : null,
  }
}

function sessionControlKey(activeSessionId) {
  return createHash('sha256').update(`omp\0${String(activeSessionId)}`).digest('hex')
}

function atomicWriteJson(path, value) {
  mkdirSync(sessionControlRoot, { recursive: true, mode: 0o700 })
  chmodSync(sessionControlRoot, 0o700)
  const temporary = `${path}.${process.pid}.${randomUUID()}.tmp`
  try {
    writeFileSync(temporary, `${JSON.stringify(value)}\n`, { mode: 0o600, flag: 'wx' })
    renameSync(temporary, path)
  } finally {
    rmSync(temporary, { force: true })
  }
}

function reconcileEmergencyPermissions(state = emergencyState()) {
  if (state.disabled && (!state.changedAt || emergencyChangedAt !== state.changedAt)) {
    enabledHookIds.clear()
    currentCapability = null
  }
  if (!state.disabled) emergencyChangedAt = null
  return state
}

function overrideState(emergency = emergencyState()) {
  reconcileEmergencyPermissions(emergency)
  currentCapability = normalizedCapability(
    currentCapability,
    currentSessionId,
    Date.now(),
    capabilityIdentity(),
  )
  return {
    disabledHookIds: [...disabledHookIds].sort(),
    enabledHookIds: [...enabledHookIds].sort(),
    capability: currentCapability,
    emergencyChangedAt,
  }
}

function appendOverrideEntry(pi) {
  const overrides = overrideState()
  pi.appendEntry(SESSION_OVERRIDE_ENTRY, {
    sessionId: currentSessionId,
    disabledHookIds: overrides.disabledHookIds,
    enabledHookIds: overrides.enabledHookIds,
    capability: overrides.capability,
    emergencyChangedAt: overrides.emergencyChangedAt,
  })
  return overrides
}

function externalOverrideState() {
  if (!currentSessionId || !currentSessionKey || !sessionControlOverridePath) return null
  const value = loadJson(sessionControlOverridePath, null)
  if (
    value?.schema !== SESSION_CONTROL_SCHEMA
    || value.agentId !== 'omp'
    || value.sessionId !== currentSessionId
    || value.controlKey !== currentSessionKey
    || value.releaseId !== loadedReleaseId
    || value.catalogChecksum !== loadedCatalogChecksum
  ) return null
  const emergency = emergencyState()
  const overrideEmergencyChangedAt = typeof value.emergencyChangedAt === 'string'
    && value.emergencyChangedAt.trim()
    ? value.emergencyChangedAt
    : null
  const emergencyBindingMatches = !emergency.disabled
    || Boolean(emergency.changedAt && overrideEmergencyChangedAt === emergency.changedAt)
  return {
    disabledHookIds: sanitizedDisabledIds(value.disabledHookIds),
    enabledHookIds: emergencyBindingMatches ? sanitizedIds(value.enabledHookIds) : [],
    capability: emergencyBindingMatches
      ? normalizedCapability(
          value.capability,
          currentSessionId,
          Date.now(),
          capabilityIdentity(),
        )
      : null,
    emergencyChangedAt: emergency.disabled ? overrideEmergencyChangedAt : null,
  }
}

function writeExternalOverride(identity = capabilityIdentity()) {
  if (!currentSessionId || !currentSessionKey || !sessionControlOverridePath) return
  const overrides = overrideState()
  atomicWriteJson(sessionControlOverridePath, {
    schema: SESSION_CONTROL_SCHEMA,
    agentId: 'omp',
    sessionId: currentSessionId,
    controlKey: currentSessionKey,
    releaseId: identity.releaseId,
    catalogChecksum: identity.catalogChecksum,
    disabledHookIds: overrides.disabledHookIds,
    enabledHookIds: overrides.enabledHookIds,
    capability: overrides.capability,
    emergencyChangedAt: overrides.emergencyChangedAt,
    updatedAt: new Date().toISOString(),
  })
}

function synchronizeExternalOverrides(pi) {
  const external = externalOverrideState()
  if (!external) return false
  const current = overrideState()
  if (
    JSON.stringify(current.disabledHookIds) === JSON.stringify(external.disabledHookIds)
    && JSON.stringify(current.enabledHookIds) === JSON.stringify(external.enabledHookIds)
    && JSON.stringify(current.capability) === JSON.stringify(external.capability)
    && current.emergencyChangedAt === external.emergencyChangedAt
  ) return false
  disabledHookIds = new Set(external.disabledHookIds)
  enabledHookIds = new Set(external.enabledHookIds)
  currentCapability = external.capability
  emergencyChangedAt = external.emergencyChangedAt
  appendOverrideEntry(pi)
  return true
}

function activeHookCount(emergency = emergencyState(), selection = loadHookEnforcement()) {
  reconcileEmergencyPermissions(emergency)
  let count = 0
  for (const hookId of knownHookIds) {
    if (shouldEnforceHook(hookId, selection, {
      globallyDisabled: emergency.disabled,
      sessionEnabledHookIds: enabledHookIds,
    })) count++
  }
  return count
}

function runtimeStatus(emergency = emergencyState(), selection = loadHookEnforcement()) {
  const installed = installedReleaseState()
  const overrides = overrideState(emergency)
  const reloadRequired = Boolean(
    registryLoadError
    || !installed.releaseId
    || installed.releaseId !== loadedReleaseId
    || (installed.catalogChecksum && installed.catalogChecksum !== loadedCatalogChecksum),
  )
  return {
    schemaVersion: 1,
    sessionId: currentSessionId,
    controlKey: currentSessionKey,
    installedReleaseId: installed.releaseId,
    loadedReleaseId,
    installedCatalogChecksum: installed.catalogChecksum,
    catalogChecksum: loadedCatalogChecksum,
    registeredHookCount: knownHookIds.size,
    loadedHookCount: activeHookCount(emergency, selection),
    globallyDisabled: emergency.disabled,
    enforcementMode: selection.mode,
    machineEnabledHookIds: selection.enabledHookIds,
    disabledHookIds: overrides.disabledHookIds,
    enabledHookIds: overrides.enabledHookIds,
    unknownHookIds: [...unknownHookIds].sort(),
    capability: overrides.capability,
    emergencyChangedAt: overrides.emergencyChangedAt,
    reloadRequired,
    reloadPending: Boolean(pendingRuntimeReload),
    pendingReloadCommand: pendingRuntimeReload?.command || null,
    registryLoadError,
    runtimeStartedAt,
    reloadCount,
    lastReloadAt,
    lastReloadError,
    lastDecision,
    updatedAt: new Date().toISOString(),
  }
}

function publishedSessionState() {
  const status = runtimeStatus()
  const resumeArgv = sessionResumeArgv()
  return {
    schema: SESSION_CONTROL_SCHEMA,
    agentId: 'omp',
    sessionId: currentSessionId,
    controlKey: currentSessionKey,
    pid: process.pid,
    cwd: currentSessionCwd || process.cwd(),
    livenessMode: 'process',
    globallyDisabled: status.globallyDisabled,
    enforcementMode: status.enforcementMode,
    machineEnabledHookIds: status.machineEnabledHookIds,
    disabledHookIds: status.disabledHookIds,
    enabledHookIds: status.enabledHookIds,
    capability: status.capability,
    emergencyChangedAt: status.emergencyChangedAt,
    ...(resumeArgv ? { resumeArgv } : {}),
    runtime: status,
    updatedAt: new Date().toISOString(),
  }
}

function publishSessionState() {
  if (!currentSessionId || !currentSessionKey || !sessionControlStatePath) return
  atomicWriteJson(sessionControlStatePath, publishedSessionState())
}

function persistOverrides(pi, identity = capabilityIdentity()) {
  const overrides = appendOverrideEntry(pi)
  writeExternalOverride(identity)
  publishSessionState()
  return overrides
}

function applySessionHookOverride(pi, hookId, enabled, preflightEmergencyChangedAt = null) {
  if (!enabled) {
    return {
      changed: false,
      accepted: false,
      reason: 'session-hook-disablement-prohibited',
      sessionId: currentSessionId,
      hookId,
      enabled: true,
      globallyDisabled: hooksGloballyDisabled(),
      ...overrideState(),
    }
  }
  const emergency = emergencyState()
  reconcileEmergencyPermissions(emergency)
  const currentEmergencyChangedAt = emergency.disabled ? emergency.changedAt : null
  if (preflightEmergencyChangedAt !== currentEmergencyChangedAt) {
    return {
      changed: false,
      accepted: false,
      reason: 'emergency-state-changed-during-activation',
      sessionId: currentSessionId,
      hookId,
      enabled: false,
      globallyDisabled: emergency.disabled,
      ...overrideState(emergency),
    }
  }
  if (emergency.disabled && !emergency.changedAt) {
    return {
      changed: false,
      accepted: false,
      reason: 'global-emergency-state-missing-generation',
      sessionId: currentSessionId,
      hookId,
      enabled: false,
      globallyDisabled: true,
      ...overrideState(emergency),
    }
  }
  // Session controls are monotonic: they can add enforcement to the machine
  // selection, but no session path may remove a machine-selected hook.
  const changed = emergency.disabled
    ? emergencyChangedAt !== emergency.changedAt || !enabledHookIds.has(hookId)
    : !enabledHookIds.has(hookId)
  if (emergency.disabled) emergencyChangedAt = emergency.changedAt
  enabledHookIds.add(hookId)
  const overrides = changed ? persistOverrides(pi) : overrideState(emergency)
  return {
    changed,
    accepted: true,
    sessionId: currentSessionId,
    hookId,
    enabled,
    globallyDisabled: emergency.disabled,
    ...overrides,
  }
}


function applySessionCapability(pi, grants, lifetime, expiresAt = null) {
  const emergency = emergencyState()
  reconcileEmergencyPermissions(emergency)
  if (emergency.disabled && !emergency.changedAt) {
    return {
      changed: false,
      accepted: false,
      reason: 'global-emergency-state-missing-generation',
      sessionId: currentSessionId,
      capability: null,
    }
  }
  if (emergency.disabled) emergencyChangedAt = emergency.changedAt
  const capability = {
    schemaVersion: CAPABILITY_SCHEMA_VERSION,
    issuedBy: 'tama:omp-interactive-approval',
    nonce: randomUUID(),
    sessionId: currentSessionId,
    controlKey: currentSessionKey,
    releaseId: loadedReleaseId,
    catalogChecksum: loadedCatalogChecksum,
    lifetime,
    grants,
  }
  if (lifetime === 'expires-at') capability.expiresAt = new Date(Date.parse(expiresAt)).toISOString()
  if (lifetime === 'single-use') capability.remainingUses = 1
  currentCapability = capability
  const overrides = persistOverrides(pi)
  return {
    changed: true,
    accepted: true,
    sessionId: currentSessionId,
    capability: overrides.capability,
    emergencyChangedAt: overrides.emergencyChangedAt,
  }
}

function consumeSingleUseCapability(pi) {
  overrideState()
  if (currentCapability?.lifetime !== 'single-use') return false
  currentCapability = null
  persistOverrides(pi)
  return true
}

async function processSessionControlRequests(pi) {
  if (synchronizeExternalOverrides(pi)) publishSessionState()
  if (!currentSessionId || !currentSessionKey) return
  let names
  try {
    names = readdirSync(sessionControlRoot)
  } catch {
    return
  }
  const prefix = `${currentSessionKey}.`
  for (const name of names) {
    if (!name.startsWith(prefix) || !name.endsWith('.request.json')) continue
    const requestPath = join(sessionControlRoot, name)
    const responsePath = join(sessionControlRoot, name.replace(/\.request\.json$/, '.response.json'))
    const request = loadJson(requestPath, null)
    rmSync(requestPath, { force: true })
    let response
    const validEnvelope = request?.schema === SESSION_CONTROL_SCHEMA
      && request.sessionId === currentSessionId
      && request.controlKey === currentSessionKey
      && typeof request.requestId === 'string'
      && request.confirmed === true
    if (!validEnvelope) {
      response = {
        schema: SESSION_CONTROL_SCHEMA,
        requestId: request?.requestId || null,
        ok: false,
        error: 'invalid-session-control-request',
      }
    } else if (request.operation === 'enable-all') {
      const details = await reloadSessionRuntime(pi, SESSION_ENABLE_ALL_TOOL)
      const accepted = details.accepted === true
      response = {
        schema: SESSION_CONTROL_SCHEMA,
        requestId: request.requestId,
        ok: accepted,
        changed: details.changed,
        error: accepted ? null : (details.error || 'reload-not-completed'),
        command: details.command,
        state: loadJson(sessionControlStatePath, null) || publishedSessionState(),
      }
    } else if (request.operation === 'set-hook') {
      const id = typeof request.hookId === 'string' ? request.hookId.trim() : ''
      if (!knownHookIds.has(id) || typeof request.enabled !== 'boolean') {
        response = {
          schema: SESSION_CONTROL_SCHEMA,
          requestId: request.requestId,
          ok: false,
          error: knownHookIds.has(id) ? 'invalid-hook-state' : `unknown-hook:${id}`,
        }
      } else {
        const preflight = request.enabled
          ? await preflightSessionHook(id)
          : { accepted: true }
        const details = preflight.accepted
          ? applySessionHookOverride(pi, id, request.enabled, preflight.emergencyChangedAt)
          : { accepted: false, changed: false, reason: preflight.reason }
        const accepted = details.accepted === true
        response = {
          schema: SESSION_CONTROL_SCHEMA,
          requestId: request.requestId,
          ok: accepted,
          changed: details.changed,
          error: accepted ? null : (details.reason || 'hook-enable-not-applied'),
          state: publishedSessionState(),
        }
      }
    } else {
      response = {
        schema: SESSION_CONTROL_SCHEMA,
        requestId: request.requestId,
        ok: false,
        error: `unsupported-operation:${request.operation}`,
      }
    }
    atomicWriteJson(responsePath, response)
  }
}

function stopSessionControl() {
  clearInterval(sessionControlTimer)
  sessionControlTimer = null
  if (sessionControlStatePath) rmSync(sessionControlStatePath, { force: true })
  sessionControlStatePath = null
  sessionControlOverridePath = null
  currentSessionKey = null
  currentSessionCwd = null
}

function startSessionControl(pi, event, ctx) {
  stopSessionControl()
  if (!currentSessionId) return
  currentSessionKey = sessionControlKey(currentSessionId)
  currentSessionCwd = event?.cwd || ctx?.cwd || process.cwd()
  sessionControlStatePath = join(sessionControlRoot, `${currentSessionKey}.session.json`)
  sessionControlOverridePath = join(sessionControlRoot, `${currentSessionKey}.override.json`)
  synchronizeExternalOverrides(pi)
  publishSessionState()
  sessionControlTimer = setInterval(() => {
    processSessionControlRequests(pi).catch(error => {
      lastReloadError = error instanceof Error ? error.message : String(error)
      publishSessionState()
    })
  }, SESSION_CONTROL_POLL_MS)
  sessionControlTimer.unref()
  if (!exitCleanupRegistered) {
    exitCleanupRegistered = true
    process.once('exit', () => {
      if (sessionControlStatePath) rmSync(sessionControlStatePath, { force: true })
    })
  }
}

function activateSession(pi, event, ctx) {
  currentSessionId = resolvedSessionId(event, ctx)
  currentSessionContext = ctx
  unknownHookIds = new Set()
  const restored = restoredHookOverrides(ctx, currentSessionId)
  disabledHookIds = new Set(restored.disabledHookIds)
  enabledHookIds = new Set(restored.enabledHookIds)
  currentCapability = restored.capability
  emergencyChangedAt = restored.emergencyChangedAt
  startSessionControl(pi, event, ctx)
}

function sessionId(event) {
  return event?.sessionId || event?.session_id || event?.session?.id || currentSessionId || null
}

function toolName(event) {
  return String(event?.toolName || event?.name || '')
}

function toolInput(event) {
  const value = event?.input ?? event?.params ?? null
  if (value && typeof value === 'object' && !Array.isArray(value)) return value
  return typeof value === 'string' ? { raw_input: value, patch: value } : {}
}

function documentedToolName(name) {
  const normalized = String(name).toLowerCase()
  if (normalized === 'write') return 'Write'
  if (normalized === 'create') return 'Create'
  if (normalized === 'edit') return 'Edit'
  return name
}

function patchInputs(input) {
  const patch = typeof input.patch === 'string'
    ? input.patch
    : typeof input.content === 'string' && input.content.startsWith('*** Begin Patch')
      ? input.content
      : null
  if (!patch) return []
  const sections = []
  let section = null
  for (const line of patch.split(/\r?\n/)) {
    const header = line.match(/^\[([^#\]]+)#[0-9A-Fa-f]{4}\]$/)
    if (header) {
      section = { path: header[1], added: [] }
      sections.push(section)
    } else if (section && line.startsWith('+')) {
      section.added.push(line.slice(1))
    }
  }
  return sections.map(({ path, added }) => ({
    ...input,
    file_path: path,
    new_string: added.join('\n'),
  }))
}

function normalizedToolInputs(event) {
  const input = toolInput(event)
  const name = String(toolName(event)).toLowerCase()
  if (name === 'edit') {
    const sections = patchInputs(input)
    if (sections.length > 0) return sections
  }
  const filePath = input.file_path || input.path || input.file || input.filePath
  const normalized = {
    ...input,
    ...(filePath ? { file_path: filePath } : {}),
  }
  if ((name === 'write' || name === 'create') && normalized.content === undefined) {
    normalized.content = input.text ?? input.data
  }
  if (name === 'edit' && normalized.new_string === undefined) {
    normalized.new_string = input.newString ?? input.content ?? input.text
  }
  return [normalized]
}

function hookPayload(event, input = normalizedToolInputs(event)[0]) {
  const name = toolName(event)
  return {
    agent_hook_event: 'tool_call',
    runtime: 'omp',
    session_id: sessionId(event),
    project_dir: event?.cwd || process.cwd(),
    control_key: currentSessionKey,
    release_id: loadedReleaseId,
    catalog_checksum: loadedCatalogChecksum,
    tool_name: documentedToolName(name),
    tool_input: input,
    tool: { name, input: toolInput(event) },
  }
}

function hookPayloads(event) {
  return normalizedToolInputs(event).map(input => hookPayload(event, input))
}

function messageRole(record) {
  const message = record?.message && typeof record.message === 'object'
    ? record.message
    : record
  return typeof message?.role === 'string' ? message.role.toLowerCase() : null
}

function assistantText(record) {
  const message = record?.message && typeof record.message === 'object'
    ? record.message
    : record
  if (messageRole(message) !== 'assistant') return null
  if (typeof message.content === 'string') return message.content.trim()
  if (!Array.isArray(message.content)) return ''
  return message.content
    .filter(block => block?.type === 'text' && typeof block.text === 'string' && block.text.trim())
    .map(block => block.text.trim())
    .join('\n')
}

function lastAssistantTextInCurrentTurn(records) {
  if (!Array.isArray(records)) return ''
  for (let index = records.length - 1; index >= 0; index--) {
    const role = messageRole(records[index])
    if (role === 'user') break
    if (role !== 'assistant') continue
    const text = assistantText(records[index])
    if (text) return text
  }
  return ''
}

function stopAssistantMessage(event, ctx = currentSessionContext) {
  const supplied = event?.last_assistant_message ?? event?.lastAssistantMessage
  if (typeof supplied === 'string' && supplied.trim()) return supplied.trim()
  const direct = assistantText(event)
  if (direct) return direct
  const eventText = lastAssistantTextInCurrentTurn(
    event?.messages || event?.conversation?.messages,
  )
  if (eventText) return eventText
  return lastAssistantTextInCurrentTurn(ctx?.sessionManager?.getBranch?.() || [])
}

function lifecyclePayload(eventName, event = {}, extra = {}) {
  return {
    agent_hook_event: eventName,
    runtime: 'omp',
    session_id: sessionId(event),
    project_dir: event?.cwd || process.cwd(),
    raw_event: event,
    ...(eventName === 'stop' ? { last_assistant_message: stopAssistantMessage(event) } : {}),
    ...extra,
  }
}

function registryEvent(name) {
  const normalized = String(name).toLowerCase()
  if (normalized === 'read') return 'pre_tool_use:read'
  if (normalized === 'notebookedit' || normalized === 'notebook') return 'pre_tool_use:notebook'
  if (normalized === 'multiedit') return 'pre_tool_use:multiedit'
  if (normalized === 'write' || normalized === 'edit' || normalized === 'apply_patch') return 'pre_tool_use:edit'
  if (normalized === 'bash') return 'pre_tool_use:bash'
  if (normalized === 'monitor' || normalized === 'schedulewakeup') return 'pre_tool_use:wait'
  if (normalized === 'task' || normalized === 'agent') return 'pre_tool_use:task'
  if (normalized === 'todo') return 'pre_tool_use:todo'
  if (normalized === 'goal') return 'pre_tool_use:goal'
  if (normalized === 'ask' || normalized.endsWith('.ask') || normalized.endsWith('/ask') || normalized.endsWith('_ask')) return 'pre_tool_use:ask'
  if (normalized === 'ssh') return 'pre_tool_use:ssh'
  if (normalized === 'grep' || normalized === 'glob' || normalized === 'lsp' || normalized === 'ast_edit') return 'pre_tool_use:lookup'
  return 'pre_tool_use:eval'
}

function registryPostEvent(name) {
  return registryEvent(name).replace('pre_tool_use:', 'post_tool_use:')
}

function expandHome(command) {
  return String(command).replace(/~(?=\/|$)/g, homedir()).replace(/\$HOME/g, homedir())
}

function runHookCommand(hook, payload) {
  return new Promise(resolve => {
    const [program, ...args] = tokenizeCommand(expandHome(hook.command))
    if (!program) {
      resolve({ code: null, signal: null, timedOut: false, stdout: '', stderr: 'empty hook command', spawnError: true })
      return
    }
    // No shell: registry commands are argv, so a registry write cannot smuggle
    // shell syntax into every tool call.
    const child = spawn(program, args, {
      env: capabilityEnvironment(currentCapability, { TAMA_PROVIDER: 'omp' }),
    })
    let stdout = ''
    let stderr = ''
    let timedOut = false
    let settled = false
    const finish = result => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      resolve(result)
    }
    const timeoutMs = Math.max(1, Number(hook.timeout || 10)) * 1000
    const timer = setTimeout(() => {
      timedOut = true
      child.kill('SIGTERM')
    }, timeoutMs)
    child.stdout.on('data', chunk => { stdout += chunk.toString('utf8') })
    child.stderr.on('data', chunk => { stderr += chunk.toString('utf8') })
    child.stdin.on('error', error => { stderr += error instanceof Error ? error.message : String(error) })
    child.on('error', error => finish({ code: null, signal: null, timedOut, stdout, stderr: error.message, spawnError: true }))
    child.on('close', (code, signal) => finish({ code, signal, timedOut, stdout, stderr }))
    child.stdin.end(JSON.stringify(payload))
  })
}

function withSharedRuntime(action) {
  const operation = sharedRuntimeQueue.then(action)
  // Keep later requests usable after an error; the caller still receives it.
  sharedRuntimeQueue = operation.then(() => undefined, () => undefined)
  return operation
}

async function callSharedRuntime(op, event = null, payload = null) {
  const candidate = event ? registrySnapshot() : null
  const hooks = event ? candidate.registry.events[event]?.hooks : []
  if (hooks != null && !Array.isArray(hooks)) {
    throw new Error(`Invalid hook list for ${event} in ${REGISTRY_PATH}`)
  }
  let seconds = HOOK_TIMEOUT_MS / 1000
  for (const hook of hooks || []) {
    const timeout = Number(hook.timeout || HOOK_TIMEOUT_MS / 1000)
    if (!Number.isFinite(timeout)) throw new Error(`Invalid timeout for hook ${hook.id}`)
    seconds += Math.max(1, timeout)
  }
  const id = randomUUID()
  const request = { id, op, knownCatalogChecksum: loadedCatalogChecksum }
  if (event !== null) request.event = event
  if (payload !== null) request.payload = payload
  const reply = await sharedRuntimeClient.request(request, seconds * 1000)
  if (reply.ok !== true) throw new Error(reply.error || `Tama core rejected ${op}`)
  const snapshot = Object.hasOwn(reply, 'catalog') ? registrySnapshot(reply.catalog) : {
    registry: loadedRegistry, hookIds: knownHookIds,
    releaseId: loadedReleaseId, catalogChecksum: loadedCatalogChecksum,
  }
  if (reply.state?.catalogChecksum !== snapshot.catalogChecksum
    || reply.state?.loadedReleaseId !== snapshot.releaseId
    || !Number.isInteger(reply.state?.processId)) {
    throw new Error('Tama core response does not match its loaded catalog')
  }
  return { ...reply, snapshot }
}

function registeredHook(hookId, registry = loadedRegistry) {
  for (const entry of Object.values(registry.events || {})) {
    if (!entry || !Array.isArray(entry.hooks)) continue
    const hook = entry.hooks.find(candidate => String(candidate?.id || '') === hookId)
    if (hook) return hook
  }
  return null
}

async function runSessionHookActivationPreflight(hookId, registry) {
  if (!ACTIVATION_PREFLIGHT_HOOK_IDS.has(hookId)) return { accepted: true }
  const hook = registeredHook(hookId, registry)
  if (!hook) return { accepted: false, reason: `activation-preflight-hook-missing:${hookId}` }
  const execution = await runHookCommand(hook, {
    tama_activation_preflight: true,
    session_id: currentSessionId,
    cwd: currentSessionCwd,
    tool_name: SESSION_OVERRIDE_TOOL,
    last_assistant_message: stopAssistantMessage({}),
    tool_input: { hookId, enabled: true },
  })
  if (execution.code === 0 && !execution.timedOut) {
    let reviewerVerdict
    try {
      reviewerVerdict = JSON.parse(execution.stdout).reviewerVerdict
    } catch {}
    return {
      accepted: true,
      ...(typeof reviewerVerdict === 'string' ? { reviewerVerdict } : {}),
    }
  }
  const outcome = execution.spawnError
    ? 'could not start command'
    : execution.timedOut
      ? `timed out after ${Math.max(1, Number(hook.timeout || 10)) * 1000}ms`
      : execution.signal
        ? `terminated by ${execution.signal}`
        : `exit ${execution.code}`
  const output = (execution.stderr || execution.stdout || '').trim()
  const detail = output ? `${outcome}: ${output}` : outcome
  return {
    accepted: false,
    reason: `activation-preflight-failed:${hookId}:${detail || 'no diagnostic'}`,
  }
}

async function preflightSessionHook(hookId, registry = loadedRegistry) {
  const emergency = emergencyState()
  reconcileEmergencyPermissions(emergency)
  if (emergency.disabled && !emergency.changedAt) {
    return { accepted: false, reason: 'global-emergency-state-missing-generation' }
  }
  const emergencyChangedAtSnapshot = emergency.disabled ? emergency.changedAt : null
  const activation = await runSessionHookActivationPreflight(hookId, registry)
  const currentEmergency = emergencyState()
  reconcileEmergencyPermissions(currentEmergency)
  const currentEmergencyChangedAt = currentEmergency.disabled ? currentEmergency.changedAt : null
  if (emergencyChangedAtSnapshot !== currentEmergencyChangedAt) {
    return { accepted: false, reason: 'emergency-state-changed-during-activation' }
  }
  if (currentEmergency.disabled && !currentEmergency.changedAt) {
    return { accepted: false, reason: 'global-emergency-state-missing-generation' }
  }
  return activation.accepted
    ? { ...activation, emergencyChangedAt: emergencyChangedAtSnapshot }
    : activation
}

async function preflightSessionHooks(hookIds, registry = loadedRegistry) {
  const emergency = emergencyState()
  reconcileEmergencyPermissions(emergency)
  if (emergency.disabled) {
    return { accepted: false, reason: 'global-emergency-disable-active' }
  }
  for (const hookId of hookIds) {
    const result = await runSessionHookActivationPreflight(hookId, registry)
    if (!result.accepted) return result
  }
  if (emergencyState().disabled) {
    return { accepted: false, reason: 'global-emergency-disable-active' }
  }
  return { accepted: true }
}

// OMP stop events do not consistently carry a transcript location. The session
// id is enough to find it: OMP writes one JSONL per session under
// ~/.omp/agent/sessions/<project>/, named <iso>_<sessionId>.jsonl.
function derivedTranscriptPath(sessionId) {
  const id = String(sessionId || '').trim()
  if (!id) return null
  const root = join(homedir(), '.omp', 'agent', 'sessions')
  let projects = []
  try {
    projects = readdirSync(root, { withFileTypes: true })
      .filter(entry => entry.isDirectory())
      .map(entry => join(root, entry.name))
  } catch {
    return null
  }
  const suffix = `_${id}.jsonl`
  for (const project of projects) {
    let names = []
    try {
      names = readdirSync(project)
    } catch {
      continue
    }
    // Exact suffix first: a session id is unique, so a name that ends in it is
    // the transcript and no ranking is needed.
    const exact = names.find(name => name.endsWith(suffix) || name === `${id}.jsonl`)
    if (exact) return join(project, exact)
  }
  return null
}

async function runRegistryEvent(eventName, payload) {
  return withSharedRuntime(async () => {
    overrideState()
    const raw = payload.raw_event && typeof payload.raw_event === 'object' ? payload.raw_event : {}
    const normalized = {
      ...payload,
      cwd: payload.cwd || raw.cwd || payload.project_dir,
      transcript_path: payload.transcript_path || raw.transcript_path || raw.transcriptPath
        || derivedTranscriptPath(payload.session_id) || null,
      raw_event: undefined,
      agent_hook_event: eventName,
    }
    let result
    try {
      const reply = await callSharedRuntime('dispatch', eventName, normalized)
      if (!reply.result || !['pass', 'block'].includes(reply.result.decision)) {
        throw new Error('Tama core returned an invalid policy decision')
      }
      if (reply.snapshot.catalogChecksum !== loadedCatalogChecksum || registryLoadError) {
        stageRuntimeReload(pi, reply.snapshot)
        finishRuntimeReload()
      }
      lastReloadError = null
      result = { ...reply.result, id: reply.result.blockedHookId }
    } catch (error) {
      lastReloadError = error instanceof Error ? error.message : String(error)
      result = {
        decision: 'block', id: 'tama-shared-runtime', results: [],
        reason: `TAMA_HOOK_INFRASTRUCTURE: ${lastReloadError}`,
      }
    }
    lastDecision = { event: eventName, ...result, at: new Date().toISOString() }
    return result
  })
}

async function checkToolCall(pi, event, payloads = hookPayloads(event)) {
  if (CONTROL_PLANE_TOOLS.has(toolName(event))) return { decision: 'pass', code: 0, results: [] }
  const results = []
  for (const payload of payloads) {
    const result = await runRegistryEvent(registryEvent(toolName(event)), payload)
    results.push(...(result.results || []))
    if (result.decision === 'block') {
      return { ...result, results }
    }
  }
  consumeSingleUseCapability(pi)
  return { decision: 'pass', results }
}

function writeEvidence(payload, result) {
  const path = process.env.OMP_TAMA_EVIDENCE_LOG
  if (!path) return
  appendFileSync(path, `${JSON.stringify({
    event: registryEvent(payload.tool_name),
    input: payload,
    decision: result.decision,
    blockedHookId: result.id || null,
    reason: result.reason || null,
    results: result.results || [],
    loadedReleaseId,
    catalogChecksum: loadedCatalogChecksum,
  })}\n`)
}

function capabilitySummary(grants) {
  return grants.map(grant => grant.actions ? `${grant.tool}:${grant.actions.join(',')}` : grant.tool).join('\n')
}

function lifetimeSummary(lifetime, expiresAt) {
  if (lifetime === 'single-use') return 'Lifetime: one tool invocation'
  if (lifetime === 'current-session') return 'Lifetime: until this OMP session ends'
  return `Expires: ${expiresAt}`
}

function validateReloadCandidate(candidate) {
  const installed = installedReleaseState()
  if (installed.releaseId && candidate.releaseId !== installed.releaseId) {
    throw new Error(`Installed release ${installed.releaseId} does not match registry release ${candidate.releaseId}`)
  }
  if (installed.catalogChecksum && candidate.catalogChecksum !== installed.catalogChecksum) {
    throw new Error(`Installed catalog ${installed.catalogChecksum} does not match registry catalog ${candidate.catalogChecksum}`)
  }
}

function captureReloadState() {
  overrideState()
  return {
    registry: loadedRegistry,
    hookIds: knownHookIds,
    releaseId: loadedReleaseId,
    catalogChecksum: loadedCatalogChecksum,
    loadError: registryLoadError,
    disabledHookIds: new Set(disabledHookIds),
    enabledHookIds: new Set(enabledHookIds),
    capability: currentCapability,
    emergencyChangedAt,
  }
}

function restoreReloadState(state) {
  loadedRegistry = state.registry
  knownHookIds = state.hookIds
  loadedReleaseId = state.releaseId
  loadedCatalogChecksum = state.catalogChecksum
  registryLoadError = state.loadError
  disabledHookIds = state.disabledHookIds
  enabledHookIds = state.enabledHookIds
  currentCapability = state.capability
  emergencyChangedAt = state.emergencyChangedAt
}

function stageRuntimeReload(pi, candidate, enableAll = false) {
  validateReloadCandidate(candidate)
  const previous = captureReloadState()
  try {
    const emergency = emergencyState()
    reconcileEmergencyPermissions(emergency)
    if (enableAll && emergency.disabled) throw new Error('global-emergency-disable-active')
    disabledHookIds = new Set([...disabledHookIds].filter(id => candidate.hookIds.has(id)))
    enabledHookIds = enableAll
      ? new Set(candidate.hookIds)
      : new Set([...enabledHookIds].filter(id => candidate.hookIds.has(id)))
    installRegistrySnapshot(candidate)
    const overrides = persistOverrides(pi)
    return {
      previous,
      enabled: enableAll ? {
        changed: true,
        sessionId: currentSessionId,
        globallyDisabled: false,
        ...overrides,
      } : null,
    }
  } catch (error) {
    const primary = error instanceof Error ? error.message : String(error)
    restoreReloadState(previous)
    try {
      persistOverrides(pi)
    } catch (rollbackError) {
      const rollback = rollbackError instanceof Error ? rollbackError.message : String(rollbackError)
      throw new Error(`${primary}; rollback failed: ${rollback}`)
    }
    throw error
  }
}

function finishRuntimeReload() {
  reloadCount++
  lastReloadAt = new Date().toISOString()
  lastReloadError = null
  publishSessionState()
  return runtimeStatus()
}

function rollbackRuntimeReload(pi, stage, error) {
  const primary = error instanceof Error ? error.message : String(error)
  restoreReloadState(stage.previous)
  try {
    persistOverrides(pi)
    lastReloadError = primary
  } catch (rollbackError) {
    const rollback = rollbackError instanceof Error ? rollbackError.message : String(rollbackError)
    lastReloadError = `${primary}; rollback failed: ${rollback}`
  }
  publishSessionState()
  return lastReloadError
}

async function reloadRuntime(pi, enableAll = false) {
  const sessionId = currentSessionId
  return withSharedRuntime(async () => {
    let stage = null
    try {
      if (currentSessionId !== sessionId) throw new Error('Session changed before Tama reload')
      const candidate = registrySnapshot()
      validateReloadCandidate(candidate)
      if (enableAll) {
        const preflight = await preflightSessionHooks(candidate.hookIds, candidate.registry)
        if (!preflight.accepted) throw new Error(preflight.reason)
        if (currentSessionId !== sessionId) throw new Error('Session changed during activation preflight')
      }
      const reply = await callSharedRuntime('reload')
      if (currentSessionId !== sessionId) throw new Error('Session changed during Tama reload')
      if (reply.result?.reloaded !== true || reply.snapshot.catalogChecksum !== candidate.catalogChecksum) {
        throw new Error('Tama core did not adopt the requested catalog')
      }
      stage = stageRuntimeReload(pi, reply.snapshot, enableAll)
      const status = finishRuntimeReload()
      return {
        changed: true, accepted: true, reloadRequested: true,
        expectedReleaseId: candidate.releaseId,
        expectedCatalogChecksum: candidate.catalogChecksum,
        enabled: stage.enabled, core: reply.state, status,
      }
    } catch (error) {
      lastReloadError = stage
        ? rollbackRuntimeReload(pi, stage, error)
        : (error instanceof Error ? error.message : String(error))
      publishSessionState()
      return {
        changed: false, accepted: false, reloadRequested: false,
        error: lastReloadError, status: runtimeStatus(),
      }
    }
  })
}

function ensureSession(pi, ctx) {
  const session = resolvedSessionId(null, ctx)
  if (!session) return false
  if (currentSessionId !== session) activateSession(pi, null, ctx)
  return currentSessionId === session
}

function missingSessionResult(noun) {
  return {
    content: [{ type: 'text', text: `OMP has not provided a session id; Tama refused to create an unscoped ${noun}.` }],
    details: { changed: false, reason: 'missing-session-id' },
    isError: true,
  }
}

async function reloadSessionRuntime(pi, command) {
  if (pendingRuntimeReload?.command === command
    && pendingRuntimeReload.sessionId === currentSessionId) return pendingRuntimeReload.promise
  const request = { command, sessionId: currentSessionId }
  pendingRuntimeReload = request
  request.promise = (async () => {
    try {
      publishSessionState()
      const details = await reloadRuntime(pi, command === SESSION_ENABLE_ALL_TOOL)
      if (pendingRuntimeReload === request) pendingRuntimeReload = null
      publishSessionState()
      return { ...details, command, status: runtimeStatus() }
    } finally {
      if (pendingRuntimeReload === request) {
        pendingRuntimeReload = null
        publishSessionState()
      }
    }
  })()
  return request.promise
}

  const { z } = pi.zod

  pi.registerCommand(RUNTIME_RELOAD_TOOL, {
    description: 'Validate and reload the shared Tama engine without reloading OMP.',
    handler: async (_args, ctx) => {
      if (!ensureSession(pi, ctx)) {
        ctx.ui.notify('Tama cannot reload without an active OMP session id.', 'error')
        return
      }
      const details = await reloadSessionRuntime(pi, RUNTIME_RELOAD_TOOL)
      if (!details.changed) ctx.ui.notify(`Tama runtime reload failed: ${details.error}`, 'error')
    },
  })

  pi.registerCommand(SESSION_ENABLE_ALL_TOOL, {
    description: 'Enable every registered Tama hook through the shared runtime.',
    handler: async (_args, ctx) => {
      if (!ensureSession(pi, ctx)) {
        ctx.ui.notify('Tama cannot enable hooks without an active OMP session id.', 'error')
        return
      }
      const details = await reloadSessionRuntime(pi, SESSION_ENABLE_ALL_TOOL)
      if (!details.accepted) {
        ctx.ui.notify(`Tama enable-all failed: ${details.error}`, 'error')
      }
    },
  })

  pi.registerTool({
    name: RUNTIME_STATUS_TOOL,
    label: 'Tama hook runtime status',
    description: 'Read the exact installed and loaded Tama hook release, checksum, counts, overrides, capability, and last blocking decision.',
    parameters: z.object({}),
    async execute(_toolCallId, _params, _signal, _onUpdate, ctx) {
      ensureSession(pi, ctx)
      return withSharedRuntime(async () => {
        let core = null
        let isError = false
        try {
          const reply = await callSharedRuntime('status')
          core = reply.state
          if (reply.snapshot.catalogChecksum !== loadedCatalogChecksum || registryLoadError) {
            stageRuntimeReload(pi, reply.snapshot)
            finishRuntimeReload()
          }
        } catch (error) {
          isError = true
          lastReloadError = error instanceof Error ? error.message : String(error)
        }
        const status = { ...runtimeStatus(), core }
        publishSessionState()
        return {
          content: [{ type: 'text', text: JSON.stringify(status, null, 2) }], details: status, isError,
        }
      })
    },
  })

  pi.registerTool({
    name: SESSION_OVERRIDE_TOOL,
    label: 'Tama session hook enablement',
    description: 'Enable one exact registered hook in only the current OMP session. Session hook disablement is prohibited.',
    parameters: z.object({ hookId: z.string(), enabled: z.literal(true) }),
    approval: { tier: 'exec', override: true, reason: 'Enables one hook in the current OMP session.' },
    formatApprovalDetails: ({ hookId }) => [
      `Enable hook: ${hookId}`,
      'Scope: current OMP session only',
    ],
    async execute(_toolCallId, { hookId, enabled }, _signal, _onUpdate, ctx) {
      if (!ensureSession(pi, ctx)) return missingSessionResult('hook override')
      const id = String(hookId || '').trim()
      if (!knownHookIds.has(id)) {
        return {
          content: [{ type: 'text', text: `Unknown Tama hook id: ${id}` }],
          details: { changed: false, reason: 'unknown-hook' },
          isError: true,
        }
      }
      const preflight = await preflightSessionHook(id)
      if (!preflight.accepted) {
        return {
          content: [{ type: 'text', text: `Tama refused to enable ${id}: ${preflight.reason}` }],
          details: { changed: false, ...preflight },
          isError: true,
        }
      }
      const details = applySessionHookOverride(pi, id, enabled, preflight.emergencyChangedAt)
      const accepted = details.accepted === true
      const text = details.changed
        ? `Enabled ${id} only for this OMP session.`
        : accepted
          ? `${id} is already enabled in this OMP session.`
          : `Tama refused to enable ${id}: ${details.reason}`
      return {
        content: [{ type: 'text', text }],
        details: { ...details, activation: preflight },
        isError: !accepted,
      }
    },
  })

  pi.registerTool({
    name: SESSION_ENABLE_ALL_TOOL,
    label: 'Enable all Tama hooks in this session',
    description: 'Enable every installed hook after a verified shared-runtime reload.',
    parameters: z.object({}),
    async execute(_toolCallId, _params, _signal, _onUpdate, ctx) {
      if (!ensureSession(pi, ctx)) return missingSessionResult('enable-all override')
      const details = await reloadSessionRuntime(pi, SESSION_ENABLE_ALL_TOOL)
      const accepted = details.accepted === true
      const text = accepted
        ? 'Enabled every installed hook and reloaded the shared Tama runtime.'
        : `Tama could not complete enable-all: ${details.error}`
      return {
        content: [{ type: 'text', text }],
        details,
        isError: !accepted,
      }
    },
  })

  pi.registerTool({
    name: SESSION_CAPABILITY_TOOL,
    label: 'Authorize a scoped Tama capability',
    description: 'Authorize exact tool/action grants for one invocation, a stated expiration, or the current OMP session.',
    parameters: z.object({
      grants: z.array(z.object({ tool: z.string(), actions: z.array(z.string()).optional() })).min(1),
      lifetime: z.enum(['single-use', 'expires-at', 'current-session']),
      expiresAt: z.string().optional(),
    }),
    approval: { tier: 'exec', override: true, reason: 'Authorizes exact protected tool actions for the displayed lifetime.' },
    formatApprovalDetails: ({ grants, lifetime, expiresAt }) => [
      capabilitySummary(normalizeCapabilityGrants(grants) || []),
      lifetimeSummary(lifetime, expiresAt),
      'Scope: current OMP session only',
    ],
    async execute(_toolCallId, { grants, lifetime, expiresAt }, _signal, _onUpdate, ctx) {
      if (!ensureSession(pi, ctx)) return missingSessionResult('capability')
      const normalizedGrants = normalizeCapabilityGrants(grants)
      const validExpiration = lifetime !== 'expires-at'
        || (Number.isFinite(Date.parse(expiresAt)) && Date.parse(expiresAt) > Date.now())
      if (!normalizedGrants || !validExpiration) {
        return {
          content: [{ type: 'text', text: 'Tama rejected invalid capability grants, lifetime, or expiration.' }],
          details: { changed: false, reason: 'invalid-capability-request' },
          isError: true,
        }
      }
      const details = applySessionCapability(pi, normalizedGrants, lifetime, expiresAt)
      const accepted = details.accepted === true
      const text = accepted
        ? `Authorized the displayed grants. ${lifetimeSummary(lifetime, details.capability.expiresAt)}`
        : `Tama refused the capability: ${details.reason}`
      return {
        content: [{ type: 'text', text }],
        details,
        isError: !accepted,
      }
    },
  })

  pi.registerTool({
    name: RUNTIME_RELOAD_TOOL,
    label: 'Reload the Tama hook runtime',
    description: 'Reload the shared Tama engine now, without restarting OMP or inserting a prompt.',
    parameters: z.object({}),
    async execute(_toolCallId, _params, _signal, _onUpdate, ctx) {
      if (!ensureSession(pi, ctx)) return missingSessionResult('runtime reload')
      const details = await reloadSessionRuntime(pi, RUNTIME_RELOAD_TOOL)
      const accepted = details.accepted === true
      const text = accepted
        ? `Reloaded the shared Tama runtime in core process ${details.core.processId}.`
        : `Tama could not reload the shared runtime: ${details.error}`
      return {
        content: [{ type: 'text', text }],
        details,
        isError: !accepted,
      }
    },
  })

  pi.on('input', async (event, ctx) => {
    await processSessionControlRequests(pi)
    publishSessionState()
    const result = await runRegistryEvent('user_prompt_submit', lifecyclePayload('user_prompt_submit', event, {
      prompt: event?.text || event?.prompt || '',
    }))
    if (result.decision === 'block') {
      ctx.ui.notify(result.reason || 'Tama blocked this prompt.', 'error')
      ctx.abort()
      return { action: 'handled' }
    }
  })

  pi.on('tool_result', async event => {
    for (const basePayload of hookPayloads(event)) {
      const payload = {
        ...basePayload,
        agent_hook_event: 'tool_result',
        tool_result: { content: event?.content, details: event?.details, is_error: event?.isError === true },
      }
      const result = await runRegistryEvent(registryPostEvent(payload.tool_name), payload)
      if (result.decision === 'block') {
        return { content: [{ type: 'text', text: result.reason || 'Tama rejected the tool result.' }], isError: true }
      }
    }
  })

  pi.on('session_stop', async event => {
    const result = await runRegistryEvent('stop', lifecyclePayload('stop', event))
    if (result.decision === 'block') return { decision: 'block', reason: result.reason || 'Tama blocked session completion.' }
  })

  pi.on('session_compact', async event => {
    await runRegistryEvent('session_start:compact', lifecyclePayload('session_start:compact', event))
  })

  const handleSessionActivation = (event, ctx) => activateSession(pi, event, ctx)
  pi.on('session_start', handleSessionActivation)
  pi.on('session_switch', handleSessionActivation)
  pi.on('session_branch', handleSessionActivation)
  pi.on('session_tree', handleSessionActivation)
  pi.on('session_shutdown', async () => {
    await withSharedRuntime(() => sharedRuntimeClient.close())
    stopSessionControl()
    currentSessionId = null
    currentSessionContext = null
    disabledHookIds = new Set()
    enabledHookIds = new Set()
    unknownHookIds = new Set()
    currentCapability = null
    emergencyChangedAt = null
  })

  pi.on('tool_call', async event => {
    await processSessionControlRequests(pi)
    publishSessionState()
    const payloads = hookPayloads(event)
    const result = await checkToolCall(pi, event, payloads)
    for (const payload of payloads) writeEvidence(payload, result)
    publishSessionState()
    if (result.decision === 'block') return { block: true, reason: result.reason }
  })
}
