import { readFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'

export const HOOK_ENFORCEMENT_SCHEMA = 'ai.wisent.tama.hook-enforcement.v1'

function tamaStateRoot() {
  if (process.platform === 'darwin') {
    return join(homedir(), 'Library', 'Application Support', 'Tama')
  }
  if (process.platform === 'win32') {
    return join(process.env.LOCALAPPDATA || join(homedir(), 'AppData', 'Local'), 'Tama')
  }
  return join(process.env.XDG_STATE_HOME || join(homedir(), '.local', 'state'), 'tama')
}

export const hookEnforcementPath = process.env.TAMA_HOOK_ENFORCEMENT
  || join(tamaStateRoot(), 'hook-enforcement.json')

const reportedFailures = new Set()

function reportFailure(message) {
  if (reportedFailures.has(message)) return
  reportedFailures.add(message)
  process.stderr.write(`Tama hook enforcement state invalid at ${hookEnforcementPath}; enforcing all hooks: ${message}\n`)
}

function cleanHookIds(value, field, mode) {
  if (!Array.isArray(value)) throw new Error(`${field} must be an array`)
  const ids = value.map((item) => {
    if (typeof item !== 'string' || !item || item.trim() !== item) {
      throw new Error(`${field} must contain nonempty, trimmed hook ids`)
    }
    return item
  })
  if (new Set(ids).size !== ids.length) throw new Error(`${field} must not contain duplicate hook ids`)
  if (mode === 'all' && ids.length !== 0) throw new Error(`${field} must be empty in all mode`)
  if (mode === 'only' && ids.length === 0) throw new Error(`${field} must not be empty in only mode`)
  return ids.sort()
}

function validateMode(value, field) {
  if (value !== 'all' && value !== 'only') throw new Error(`${field} must be "all" or "only"`)
  return value
}

function isRfc3339Timestamp(value) {
  const match = value.match(
    /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/,
  )
  if (!match || !Number.isFinite(Date.parse(value))) return false
  const [, year, month, day, hour, minute, second] = match.map(Number)
  if (month < 1 || month > 12 || hour > 23 || minute > 59 || second > 59) return false
  return day >= 1 && day <= new Date(Date.UTC(year, month, 0)).getUTCDate()
}

function validatedSelection(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error('document must be an object')
  }
  if (value.schema !== HOOK_ENFORCEMENT_SCHEMA) throw new Error('schema is not supported')
  const mode = validateMode(value.mode, 'mode')
  const enabledHookIds = cleanHookIds(value.enabled, 'enabled', mode)
  if (
    typeof value.changedAt !== 'string'
    || value.changedAt.trim() !== value.changedAt
    || !isRfc3339Timestamp(value.changedAt)
  ) {
    throw new Error('changedAt must be an RFC 3339 timestamp')
  }
  if (!value.previous || typeof value.previous !== 'object' || Array.isArray(value.previous)) {
    throw new Error('previous must be an object')
  }
  const previousMode = validateMode(value.previous.mode, 'previous.mode')
  cleanHookIds(value.previous.enabled, 'previous.enabled', previousMode)
  return { mode, enabledHookIds, error: null }
}

export function loadHookEnforcement() {
  let text
  try {
    text = readFileSync(hookEnforcementPath, 'utf8')
  } catch (error) {
    if (error?.code === 'ENOENT') return { mode: 'all', enabledHookIds: [], error: null }
    const message = error instanceof Error ? error.message : String(error)
    reportFailure(message)
    return { mode: 'all', enabledHookIds: [], error: message }
  }
  try {
    return validatedSelection(JSON.parse(text))
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error)
    reportFailure(message)
    return { mode: 'all', enabledHookIds: [], error: message }
  }
}

export function shouldEnforceHook(hookId, selection, options = {}) {
  const sessionEnabled = options.sessionEnabledHookIds instanceof Set
    ? options.sessionEnabledHookIds
    : new Set(options.sessionEnabledHookIds || [])
  if (options.globallyDisabled) return sessionEnabled.has(hookId)
  return selection.mode === 'all'
    || selection.enabledHookIds.includes(hookId)
    || sessionEnabled.has(hookId)
}
