# Historical Tama reload results

Source: transcript-lake `events`, exact `tool_result` records. This is an investigation report, not an implementation change. Times below preserve the timestamps in that index; no timezone conversion was applied.

## Successful command results found

| Timestamp | Session | Recorded result |
|---|---|---|
| 2026-07-24 20:22:13.032 | 019f958f-e520-7000-ac55-2897a3deaa13 | Invoked the native Tama runtime reload command. |
| 2026-07-26 23:58:43.513 | 019f9d11-c101-7000-a4c1-b970a718e63d | Invoked the native Tama runtime reload command. |
| 2026-07-26 23:59:21.286 | 019f9d11-c101-7000-a4c1-b970a718e63d | Invoked the native Tama runtime reload command. |
| 2026-07-27 00:01:48.975 | 019f9d11-c101-7000-a4c1-b970a718e63d | Invoked the native enable-all command and runtime reload. |
| 2026-09-10 03:16:54.294 | 01a04057-ff47-7236-bdbe-48bc54a95d46 | Reloaded the shared Tama runtime in core process 26370. |
| 2026-09-10 08:18:37.158 | 01a07a87-89d0-7423-aa7f-d1f53a18b50f | Reloaded the shared Tama runtime in core process 78767. |
| 2026-09-11 18:55:35.052 | 01a0870f-0f57-77ad-8885-dba90dd4520a | Reloaded the shared Tama runtime in core process 75413. |
| 2026-09-15 18:04:52.573 | 01a05ddf-4fc3-77f8-8d43-fab902b05cd4 | Reloaded the shared Tama runtime in core process 44105. |
| 2026-09-15 20:51:02.872 | 01a07a87-89d0-7423-aa7f-d1f53a18b50f | Reloaded the shared Tama runtime in core process 23197. |
| 2026-09-15 21:19:53.125 | 01a08878-8727-7610-8632-6af0b025207b | Reloaded the shared Tama runtime in core process 21533. |
| 2026-09-15 21:30:13.355 | 01a04057-ff47-7236-bdbe-48bc54a95d46 | Reloaded the shared Tama runtime in core process 66624. |

The July 24 result is also indexed under session `019f975e-1648-7000-85f1-32b5b02a8abe` at exactly the same timestamp. It is not counted twice. The four July results say the command was invoked; they do not independently prove the later installed/loaded state. The seven September results report the shared runtime process. These result strings alone do not establish whether a historical command was entered through CUA.

## Failed attempts are not successful reloads

The first retained exact-prefix export, `rust/target/reload-history/outcomes.csv`, contains 103 rows. Deduplicating by timestamp and exact result yields 97 events, including eight successful command results then present in the index and 89 failures:

- 52 reload attempts: `OMP did not publish a matching installed and loaded runtime before the control deadline`.
- 19 enable-all attempts: the same installed/loaded deadline failure.
- 16 scheduling attempts: `OMP does not expose deferred runtime reload requests`.
- Two attempts: `REGISTRY_TIMEOUT_MS is not defined`.

A broader independent search found another refusal on 2026-07-18 05:43:41.095 in session `019f6d55-f1a8-7000-bfd7-d9d9d73cde3d`: `Enabled the loaded hooks, but runtime reload failed: OMP runtime does not expose ctx.reload()`.

The later exact-result query added the three September 15 successes at 20:51, 21:19 and 21:30. This difference shows that the index changed between queries; the export is a dated snapshot, not a complete immutable history.

## Current-session corroboration

The live `tama_hook_runtime_status` result read during this investigation reports process 66624, reload count 2, last reload `2026-09-15T21:30:13.323Z`, matching installed and loaded release `bf601fd2286a49ef7cf28406a1757e86060d00184a3c18ffc27d0e1bb0c32163`, and no reload error. This corroborates the last row independently of the historical success sentence.

## Additional reloads visible only in runtime status

These are distinct `lastReloadAt` values with a null `lastReloadError`, not additional reads of a previously listed event. The counter belongs to that runtime instance and is not a lifetime total.

| Runtime timestamp (UTC) | Session | Counter |
|---|---|---|
| 2026-09-09T20:37:20.235Z | 01a04057-ff47-7236-bdbe-48bc54a95d46 | 2 |
| 2026-09-10T04:05:26.077Z | 01a04057-ff47-7236-bdbe-48bc54a95d46 | 2 |
| 2026-09-10T04:16:02.485Z | 01a088cb-cafa-73df-9573-49d32e9f4458 | 1 |
| 2026-09-10T06:15:36.764Z | 01a04057-ff47-7236-bdbe-48bc54a95d46 | 3 |
| 2026-09-10T06:15:42.438Z | 01a0870f-0f57-77ad-8885-dba90dd4520a | 2 |
| 2026-09-10T06:15:49.792Z | 01a05ddf-4fc3-77f8-8d43-fab902b05cd4 | 2 |
| 2026-09-11T04:32:24.698Z | 01a0870f-0f57-77ad-8885-dba90dd4520a | 1 |
| 2026-09-15T18:05:13.449Z | 01a07a87-89d0-7423-aa7f-d1f53a18b50f | 1 |
| 2026-09-15T20:50:12.490Z | 01a0a310-6e22-7203-a068-c65bcbe2f596 | 2 |
| 2026-09-15T20:50:18.998Z | 01a04057-ff47-7236-bdbe-48bc54a95d46 | 1 |
| 2026-09-15T20:51:01.905Z | 01a08878-8727-7610-8632-6af0b025207b | 2 |
| 2026-09-15T20:51:44.252Z | 01a05ddf-4fc3-77f8-8d43-fab902b05cd4 | 3 |
| 2026-09-15T20:51:52.880Z | 01a0a1c1-3d53-72a0-9376-653b5bd5d064 | 2 |

A counter of 1 on July 18 was accompanied by `OMP runtime does not expose ctx.reload()` and is therefore not counted as a successful reload. Status evidence adds thirteen distinct reload times to the eleven command-result rows above: twenty-four dated cases, with the four July invocation acknowledgements distinguished from observed runtime state.

## Slash-command records without a paired success result

The exact user-event search also found `/tama_reload_hook_runtime` on September 9 at 18:44:31.884, 19:18:14.139 and 19:39:37.571 in session `01a04057-ff47-7236-bdbe-48bc54a95d46`, and at 20:28:21.394, 20:29:39.081 and 20:32:31.333 in session `01a08331-7c48-7529-b481-1e0015cf19bc`. A submitted command alone does not prove completion. July slash entries accompany the already counted tool results; they are not counted again as separate reloads.

## Limits

The reconciled list covers the indexed command-result records, parseable runtime-status transitions and exact slash-command submissions found during this investigation. It reports twenty-four dated cases, not a lifetime count: missing transcripts and counter increments without a recorded timestamp cannot be reconstructed honestly. Repeated status reads and copied session events are not additional reloads. The earlier claim of exactly fifteen calls was not supported by this evidence.
