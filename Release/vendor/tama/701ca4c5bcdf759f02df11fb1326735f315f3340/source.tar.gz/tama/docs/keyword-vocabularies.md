# Keyword logic: the whole list, and what each kind of it needs

The operator asked on 2026-09-19 where keyword logic is used and how it
should be repaired. This page is the answer for the whole workshop: the
inventory is generated, never hand-kept, and each category below says what
the repair is and names the ones already done.

## Reading the list

```bash
tama vocabulary-report \
  --repo ~/Documents/CodingProjects/Wisent/tama \
  --repo ~/Documents/CodingProjects/Wisent/oko \
  --repo ~/Documents/CodingProjects/Wisent/wisent-compute \
  --repo ~/Documents/CodingProjects/Wisent/jeden \
  --repo ~/Documents/CodingProjects/Wisent/weles
```

That prints every flagged word set with every site that writes it,
most-copied first. It reads the same declarations `block-keyword-literals`
reads, so a vocabulary already declared under a `keyword-provenance.json`
is absent from it.

The output is not kept in this repository. A copy of it was, until
2026-09-21: 863 lines of paths and line numbers that were wrong the day
after they were written, and long past the three-hundred-line limit every
file here lives under. Ask the command instead; it reads the tree as it is
now.

The five products carried **557 vocabularies across 875 sites** when this
page was written, and **401 across 460** on 2026-09-20: tama 261, weles 72,
wisent-compute 32, jeden 24, oko 12. Those are marks in time — run the
command for today's count.

## What the guard does not judge

`block-keyword-literals` reports a word list only where the program keeps
or consults it, and only in code somebody here wrote:

- Words handed to a call are that call's arguments, and words a function
  hands back are a command line — including a function whose return type is
  itself an array, which is how Swift and TypeScript spell
  `listArguments(host:) -> [String]`.
- An options object inside a call is arguments too.
- A list asked a question where it stands — `[…].contains(x)` — is a
  classifier even inside an argument list, and is reported.
- Vendored trees, `node_modules`, package-manager checkouts,
  `site-packages`, built bundles and `.min.js` files are skipped. Six of
  the findings this report used to carry were inside
  `weles/vendor/axe-core/axe.min.js`, which nobody here can fix.
- Prose files are not judged at all, and a list quoted in a comment is a
  report about a classifier rather than one.

## The five categories, and the repair for each

### 1. One vocabulary, many copies

The head of the report: `["ignore", "pipe", "pipe"]` in 21 places, six
words shared by a Rust port and the shell script it replaced, a provider
list that three modules each spell differently. These are not judgements at
all — they are one vocabulary retyped, and the copies have already drifted:
the resolver knew a proxy provider the capability matrix did not, the
topup orchestrator allowed four services while thirteen carried a flow.

**Repair:** name the vocabulary once, where its owner lives, and have every
site read it. Where the owner is another product, ask that product instead
of copying its words.

Done so far: Tama's shells, interpreters, wrappers and source suffixes
(`ports/shell_text/vocabulary/*.json`, tama 00d6fca); Tama's payload keys
(`ports::tool_vocabulary`, 5d2893a); the adaptive phases (fbf7ee0); the
time-estimate words (7ef3d3a); Stado's queue prefixes (a85f0faa), API
actions (63a2763c) and service name keys (deb4a40a); Weles's proxy
providers (f1726bf1); Jeden's pinnable languages and communication
vocabularies (4db72e6, 7b385ab) and lifecycle events (52a9e39); Oko's
model roles (ce3f8082).

### 2. A vocabulary that belongs to another product

Oko kept five transcript runtimes Transcript Lake owns; Stado's dashboard
kept the same five; Oko decided a Stado job was finished by matching three
Stado state words; Jeden's schema kept a copy of its own parser's languages.

**Repair:** ask the owner. Oko asks the Lake (bd1c7436), Stado validates the
shape of a runtime token instead of a list (6bff8ef7), and Stado now reports
`terminal` with every job so Oko can ask the job (9c48e45b, 931e8e18).

### 3. A guess at a shape

A list standing in for something the text itself says: four provider names
after `--provider`, four Weles keeper actions, three JavaScript suffixes,
five operator logins on a host, and a chart-word list that could never match
the two-letter token it filtered.

**Repair:** match the shape, or derive the set from the thing itself.
`--provider <name>` accepts any provider Stado offers, the keeper entry
point any action Weles adds, `node --check` any JavaScript suffix, the topup
orchestrator any service that carries a `topup.mjs`, and `host user delete`
protects the login the registry reaches that host with (f1726bf1, 47111306,
00d6fca).

### 4. A vocabulary that is really the product's contract

The actions a Skarbiec grant may name, the runtimes a topup exists for, the
proxy providers, the shells a guard refuses. These are declarations, not
guesses — but a declaration inside code is still a list nobody can audit.

**Repair:** declare it as data the product compiles in, with a `why` field
saying what the family is, and read it from there. Every JSON under
`ports/*/vocabulary/`, `stado-rs/src/config/boundaries/api-actions.json`,
`weles/src/proxy/providers.json` and
`stado-rs/src/deploy/host_access/protected-accounts.json` is that shape.

### 5. A classifier of prose

The rest, and the hardest: phrase lists that decide what an operator meant
("ok", "okej", "zrobione"), what an agent claimed ("likely", "probably"),
what a page is showing ("Potwierdzam", "Tak", "Złóż wniosek"). A list of
words cannot decide meaning; it can only decide spelling.

**Repair:** a model judgement through Brama. `ports::model_judgement` is the
route (b2221e7): one prompt, one answer, through `oko-cli proxy-call`, and a
judgement nobody could obtain is never a denial —
`check-substantiation-with-model` uses it and no longer spawns a vendor CLI
past the gateway. Each remaining prose classifier moves onto that port, and
the ones that judge a foreign web page move onto the page's own structure
instead of its wording.

**What blocks this category today:** Brama is `ready` but `degraded` —
`an active subscription credential could not be redeemed` — and answers
`HTTP 503 subscription_reauthorization_required` between working calls. A
guard migrated while the gateway is in that state stops enforcing whenever
it is, so the migration is safe to build and unsafe to finish until the
subscriptions are redeemable.
