//! Logic for `tama-block-repeated-blocker`, registry hook id
//! `block-repeated-blocker`.
//!
//! A Stop gate. It refuses a final message that hands the operator a blocker
//! Oko's defect register already holds open, without naming the defect.
//!
//! Why: on 2026-09-21 the operator asked how many times he had been told that
//! Brama answers `subscription_unavailable` and that the judge therefore
//! cannot verify anything. The transcript index answered: the sentence "no
//! working subscription model" appears in 925 of the 4487 sessions of the
//! last thirty days — one session in five — and 805 of those are from the
//! last twenty-four hours. It was first seen on 2026-08-23. Every one of
//! those sessions stopped, explained the same outage in its own words, and
//! called it a blocker. Nothing in the product noticed that the explanation
//! had been given before.
//!
//! A known open defect is not news. Once it is in the register it has an
//! identifier, a date and a finder, and an answer that repeats its symptoms
//! without that identifier is asking the operator to receive the same report
//! again. So: name it by its id in one clause, or leave it out and answer
//! with the work. The register is the memory; prose is not.
//!
//! The match is deliberately narrow. Only the machine words an open defect's
//! own record carries count — the snake_case codes a service prints, like
//! `subscription_unavailable`, `memory_pressure_active` or
//! `release_scratch_short`. They are read out of whatever the register holds
//! rather than from a list written here, so this gate classifies nothing on
//! its own: the operator's register decides what it knows. Ordinary prose
//! carries no such word and never trips it, and a session that has just
//! recorded a defect passes by quoting the id it was given.

use std::collections::BTreeMap;
use std::path::PathBuf;

use serde_json::Value;
use tama_hooks::session_record::{deny_tool_use, read_payload};

use crate::ports::block_unsearched_blocker_claim::final_message;

/// Where Oko keeps the register, and the variable that moves it.
const REGISTER_ENV: &str = "OKO_DEFECT_REGISTER";
const REGISTER_PATH: &str = "Library/Application Support/Oko/defects.json";
const DEFECTS_KEY: &str = "defects";
const FIXED_KEY: &str = "fixed_in";
const ID_KEY: &str = "id";
const TITLE_KEY: &str = "title";
const FOUND_AT_KEY: &str = "found_at";
const FOUND_IN_KEY: &str = "found_in";
/// How Oko prints a defect identifier: the first eight characters of its
/// UUID, lowercased. That is what a session is given when it records one and
/// what a later reader looks up, so that is what an answer has to carry.
const SHORT_ID_LENGTH: usize = 8;
/// A machine word is long enough that it cannot collide with prose, and
/// carries an underscore or a hyphen — the shape of the things a service
/// prints and a person does not invent while writing a sentence: an error
/// code like `subscription_unavailable`, an item like
/// `brama-sub-wisent-app-codex-primary`, a host like `charless-mac-mini`. A
/// repeat that avoids every one of them has stopped naming what failed, and
/// this gate is not a judge of paraphrase.
const MACHINE_WORD_LENGTH: usize = 12;

fn register_path() -> Option<PathBuf> {
    if let Some(named) = std::env::var_os(REGISTER_ENV) {
        let named = PathBuf::from(named);
        if !named.as_os_str().is_empty() {
            return Some(named);
        }
    }
    let mut path = PathBuf::from(std::env::var_os("HOME")?);
    path.push(REGISTER_PATH);
    Some(path)
}

/// Every word of every string this record holds, whatever it is called. The
/// fields are not enumerated here on purpose: what the register carries is
/// the register's business, and a gate that named its own list of fields
/// would be deciding which part of a defect counts.
fn words_of(record: &Value) -> Vec<String> {
    match record {
        Value::String(text) => text
            .split(|letter: char| {
                !(letter.is_ascii_alphanumeric() || letter == '_' || letter == '-')
            })
            .map(|word| word.trim_matches(['_', '-']).to_ascii_lowercase())
            .collect(),
        Value::Array(items) => items.iter().flat_map(words_of).collect(),
        Value::Object(fields) => fields
            .iter()
            .filter(|(name, _)| name.as_str() != ID_KEY)
            .flat_map(|(_, value)| words_of(value))
            .collect(),
        _ => Vec::new(),
    }
}

/// The machine words one defect carries: a service's own code, not prose.
fn machine_words(defect: &Value) -> Vec<String> {
    let mut found: Vec<String> = Vec::new();
    for word in words_of(defect) {
        let machine = word.contains('_') || word.contains('-');
        if word.len() < MACHINE_WORD_LENGTH || !machine {
            continue;
        }
        if !found.contains(&word) {
            found.push(word);
        }
    }
    found
}

fn short_id(defect: &Value) -> Option<String> {
    let id = defect.get(ID_KEY).and_then(Value::as_str)?;
    if id.len() < SHORT_ID_LENGTH {
        return None;
    }
    Some(id[..SHORT_ID_LENGTH].to_ascii_lowercase())
}

/// Every open defect, as machine word to the sentence a repeat would earn.
fn open_defects(document: &Value) -> BTreeMap<String, String> {
    let mut known: BTreeMap<String, String> = BTreeMap::new();
    let Some(defects) = document.get(DEFECTS_KEY).and_then(Value::as_array) else {
        return known;
    };
    for defect in defects {
        let closed = defect
            .get(FIXED_KEY)
            .and_then(Value::as_str)
            .is_some_and(|revision| !revision.trim().is_empty());
        if closed {
            continue;
        }
        let Some(id) = short_id(defect) else {
            continue;
        };
        let title = defect
            .get(TITLE_KEY)
            .and_then(Value::as_str)
            .unwrap_or("a failure this register already holds");
        let found_at = defect
            .get(FOUND_AT_KEY)
            .and_then(Value::as_str)
            .unwrap_or("earlier");
        let found_in = defect
            .get(FOUND_IN_KEY)
            .and_then(Value::as_str)
            .unwrap_or("an earlier session");
        let said = format!(
            "defect {id} — \"{title}\" — recorded {found_at} by session {found_in}, still open"
        );
        for word in machine_words(defect) {
            known.entry(word).or_insert_with(|| said.clone());
        }
    }
    known
}

fn document() -> Option<Value> {
    let text = std::fs::read_to_string(register_path()?).ok()?;
    serde_json::from_str(&text).ok()
}

/// The heading the workshop's answer contract gives the section where a
/// blocker is told, in the two languages it is written in. These are not a
/// guess at what a blocker sounds like: they are the operator's own declared
/// answer format, and the section under them is the only place an answer is
/// allowed to tell him something is stopping it.
const BLOCKER_HEADING_PL: &str = "blokery";
const BLOCKER_HEADING_EN: &str = "blockers";
/// What the same contract says to write when nothing stopped the work.
const NOTHING_PL: &str = "brak";
const NOTHING_EN: &str = "none";

/// Whether the text carries an identifier as Oko prints one: eight
/// hexadecimal characters.
fn names_a_defect(text: &str) -> bool {
    text.split(|letter: char| !letter.is_ascii_alphanumeric())
        .any(|word| {
            word.len() == SHORT_ID_LENGTH && word.chars().all(|letter| letter.is_ascii_hexdigit())
        })
}

/// What the answer tells the operator is stopping it: the lines under the
/// blocker heading, up to the next heading.
fn blocker_section(spoken: &str) -> Option<String> {
    let mut lines = spoken.lines();
    lines.find(|line| {
        let line = line.trim_start_matches(['#', '*', ' ']).trim();
        line == BLOCKER_HEADING_PL || line == BLOCKER_HEADING_EN
    })?;
    let mut said = String::new();
    for line in lines {
        if line.trim_start().starts_with('#') {
            break;
        }
        said.push_str(line);
        said.push('\n');
    }
    Some(said)
}

/// The refusal, or nothing when the answer reports no failure, or reports
/// one and says which defect it is.
pub fn check(payload: &Value) -> Option<String> {
    let message = final_message(payload);
    if message.trim().is_empty() {
        return None;
    }
    let spoken = message.to_ascii_lowercase();
    for (word, said) in open_defects(&document()?) {
        if !spoken.contains(&word) {
            continue;
        }
        let id = said
            .split_whitespace()
            .nth(1)
            .unwrap_or_default()
            .to_string();
        if spoken.contains(&id) {
            continue;
        }
        return Some(format!(
            "block-repeated-blocker: this answer reports `{word}`, and that is {said}. Handing the \
             operator a failure the register already holds is not a report: the same outage was \
             explained to him in 925 sessions of the last thirty days, 805 of them inside one day, \
             every time as news. The register is where a known failure lives, and prose is not. \
             Name it in one clause as defect {id} and spend the answer on the work you can still \
             do, or leave it out of the answer entirely."
        ));
    }
    // A blocker told in prose and written nowhere is how the register stayed
    // empty while the same outage was explained 925 times: each session told
    // him instead of recording it, so the next session had nothing to read
    // and told him again. A blocker worth his attention is worth an entry.
    let told = blocker_section(&spoken)?;
    let bare = told.trim();
    if bare.is_empty() || bare == NOTHING_PL || bare == NOTHING_EN || names_a_defect(bare) {
        return None;
    }
    Some(String::from(
        "block-repeated-blocker: this answer tells the operator something is stopping it and names \
         no defect. A blocker he is told about and nobody records is one the next session will \
         tell him about again — that is how one outage reached him in 925 sessions of thirty days, \
         805 of them in a single day, while the register held nothing. Record it with `oko-cli \
         defects record --product <P> --surface <S> --title <T> --evidence <E> --impact <I> \
         --found-in <SESSION>`, then name the identifier it gives you in that same sentence.",
    ))
}

pub fn run() {
    let payload = read_payload();
    if let Some(problem) = check(&payload) {
        deny_tool_use(&problem);
    }
}

#[cfg(test)]
mod tests {
    use super::{blocker_section, machine_words, names_a_defect, open_defects};
    use serde_json::json;

    #[test]
    fn only_the_machine_words_of_a_defect_count() {
        let words = machine_words(&json!({
            "evidence": "Brama answered HTTP 429 subscription_unavailable for brama-sub-wisent-app-codex-primary while the host published memory_pressure_active",
            "title": "the judge pool has no live credential"
        }));
        assert!(
            words.contains(&"brama-sub-wisent-app-codex-primary".to_string()),
            "a hyphenated item is a machine word too: {words:?}"
        );
        assert!(
            words.contains(&"subscription_unavailable".to_string()),
            "{words:?}"
        );
        assert!(
            words.contains(&"memory_pressure_active".to_string()),
            "{words:?}"
        );
        // Prose carries no underscore, so an ordinary sentence cannot trip it.
        assert!(!words.iter().any(|word| word == "credential"), "{words:?}");
    }

    #[test]
    fn a_closed_defect_is_forgotten_and_an_open_one_is_not() {
        let known = open_defects(&json!({
            "defects": [
                {
                    "id": "AAAAAAAA-0000-0000-0000-000000000000",
                    "title": "open one",
                    "evidence": "the gateway answered subscription_unavailable",
                    "found_at": "2026-09-21T23:00:00Z",
                    "found_in": "session-one"
                },
                {
                    "id": "BBBBBBBB-0000-0000-0000-000000000000",
                    "title": "closed one",
                    "evidence": "the host published memory_pressure_active",
                    "fixed_in": "stado@abcdef12",
                    "found_at": "2026-09-20T10:00:00Z",
                    "found_in": "session-two"
                }
            ]
        }));
        assert!(known.contains_key("subscription_unavailable"), "{known:?}");
        assert!(!known.contains_key("memory_pressure_active"), "{known:?}");
        assert!(known["subscription_unavailable"].starts_with("defect aaaaaaaa"));
    }

    /// The hole that let one outage reach him 925 times: a session tells him
    /// a blocker in prose and records nothing, so the next session reads an
    /// empty register and tells him again.
    #[test]
    fn a_blocker_told_in_prose_and_recorded_nowhere_is_refused() {
        let told = blocker_section("## blokery\nsedzia nie odpowiada, weryfikacja stoi.\n\n## next\n")
            .expect("the section under the heading");
        assert!(told.contains("sedzia nie odpowiada"), "{told}");
        assert!(!names_a_defect(&told), "{told}");
    }

    #[test]
    fn a_blocker_that_names_its_defect_passes_and_so_does_none() {
        let named = blocker_section("## blockers\nthe judge is down, defect c5443db4.\n")
            .expect("the section under the heading");
        assert!(names_a_defect(&named), "{named}");
        let empty = blocker_section("## blokery\nbrak\n").expect("the section under the heading");
        assert_eq!(empty.trim(), "brak");
    }
}
