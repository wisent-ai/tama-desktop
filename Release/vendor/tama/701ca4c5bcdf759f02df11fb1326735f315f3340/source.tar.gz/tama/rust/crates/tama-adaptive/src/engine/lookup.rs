//! Reading the registry the engine reasons over: the policy entry for a
//! hook id, the command it runs, and the file that command executes.
//!
//! Split out of `engine/mod.rs`, which had grown past the
//! three-hundred-line limit; the engine's own decisions stay there.

use std::fs;
use std::path::{Path, PathBuf};

use super::INTERPRETERS;
use crate::util::shell_words;

/// `loadObject(path, alternate)` — lenient JSON object load.
pub(super) fn load_object(path: &Path, alternate: serde_json::Value) -> serde_json::Value {
    if let Ok(text) = fs::read_to_string(path) {
        if let Ok(value) = serde_json::from_str::<serde_json::Value>(&text) {
            if value.is_object() {
                return value;
            }
        }
    }
    alternate
}

pub(super) fn load_registry(path: &Path) -> serde_json::Value {
    let value = load_object(path, serde_json::json!({ "events": {} }));
    if value.get("events").map(|v| v.is_object()).unwrap_or(false) {
        return value;
    }
    serde_json::json!({ "events": {} })
}

/// `policyEntry(id, hooks)`: exact key first, then the longest key that is a
/// prefix of the hook id. (Two distinct equal-length keys can never both be
/// prefixes of one string, so key order never matters.)
pub(super) fn policy_entry<'a>(
    id: &str,
    hooks: &'a serde_json::Map<String, serde_json::Value>,
) -> Option<&'a serde_json::Value> {
    if let Some(entry) = hooks.get(id) {
        return Some(entry);
    }
    let mut best = "";
    for key in hooks.keys() {
        if id.starts_with(key.as_str()) && key.len() > best.len() {
            best = key;
        }
    }
    if !best.is_empty() {
        return hooks.get(best);
    }
    None
}

/// `resolveFile(word, registryPath)`.
fn resolve_file(word: &str, registry_path: &Path) -> Option<PathBuf> {
    let word_path = Path::new(word);
    let candidates: Vec<PathBuf> = if word_path.is_absolute() {
        vec![word_path.to_path_buf()]
    } else {
        let parent = registry_path.parent().unwrap_or_else(|| Path::new("."));
        vec![
            parent.join(word_path),
            std::env::current_dir().unwrap_or_default().join(word_path),
        ]
    };
    for path in candidates {
        if let Ok(meta) = fs::metadata(&path) {
            if meta.is_file() {
                return Some(path);
            }
        }
    }
    None
}

/// `basename` for the interpreter check (trailing slashes trimmed first).
fn basename_of(word: &str) -> &str {
    let trimmed = word.trim_end_matches('/');
    match trimmed.rfind('/') {
        Some(index) => &trimmed[index + 1..],
        None => trimmed,
    }
}

/// `commandFor(registry, hookId)` over the raw registry value.
pub(super) fn command_for(registry: &serde_json::Value, hook_id: &str) -> Option<String> {
    let events = registry.get("events")?.as_object()?;
    for event in events.values() {
        let Some(hooks) = event.get("hooks").and_then(|h| h.as_array()) else {
            continue;
        };
        for hook in hooks {
            let id_matches = hook
                .get("id")
                .map(|id| crate::util::js_string(id) == hook_id)
                .unwrap_or(false);
            if id_matches {
                if let Some(command) = hook.get("command").and_then(|c| c.as_str()) {
                    return Some(command.to_string());
                }
            }
        }
    }
    None
}

/// `sourceFor(command, registryPath)`.
pub(super) fn source_for(command: &str, registry_path: &Path) -> Option<PathBuf> {
    let mut words = shell_words(command);
    if !words.is_empty() && INTERPRETERS.contains(&basename_of(&words[0])) {
        words.remove(0);
    }
    for word in &words {
        if word.starts_with('-') {
            continue;
        }
        if let Some(path) = resolve_file(word, registry_path) {
            return Some(path);
        }
    }
    None
}
