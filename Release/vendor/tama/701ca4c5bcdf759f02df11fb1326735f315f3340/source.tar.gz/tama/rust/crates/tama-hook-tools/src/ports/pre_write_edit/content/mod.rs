//! What the content of a write may not contain, in the order the shell asked.
//!
//! Three families, three files: the words and rollover shapes in `keywords`,
//! the stand-in substitutions in the parent module's `sentinels`, and the
//! deadlines in `timeouts`. This file only decides which family sees which
//! text.
//!
//! Two texts are used. The flattened one — newlines, carriage returns and
//! tabs turned into spaces — is what the structural patterns read, because a
//! guard and its body live on different lines and a line-oriented match would
//! walk straight past `if (x == null) {` on one line and the assignment on
//! the next. The original text is what the line-oriented rules and the
//! override markers read.

mod keywords;
mod timeouts;

use super::sentinels;

/// `tr '\n\r\t' '   '`.
fn flattened(content: &str) -> String {
    content
        .chars()
        .map(|character| match character {
            '\n' | '\r' | '\t' => ' ',
            other => other,
        })
        .collect()
}

/// The refusal this content earns, if any. `is_system` marks the vendored and
/// generated trees, which only the universal rules judge.
pub(crate) fn refusal(path: &str, content: &str, is_system: bool) -> Option<String> {
    if content.is_empty() {
        return None;
    }
    if let Some(found) = keywords::universal_complaint(content) {
        return Some(found);
    }
    if !is_system {
        let flat = flattened(content);
        if let Some(found) = keywords::complaint(&flat, content) {
            return Some(found);
        }
        if let Some(found) = sentinels::complaint(&flat) {
            return Some(found);
        }
    }
    timeouts::complaint(path, content)
}

#[cfg(test)]
mod tests {
    use super::{flattened, refusal};

    const SOURCE: &str = "/repo/src/worker.ts";
    const VENDORED: &str = "/repo/node_modules/thing/index.js";
    /// Spelled in halves for the reason the sibling modules give.
    const NAMED_ROLLOVER: &str = concat!("fall", " back");

    #[test]
    fn newlines_and_tabs_become_spaces_so_a_shape_can_cross_a_line() {
        assert_eq!(flattened("a\n\tb\r\nc"), "a  b  c");
    }

    /// The rule that reads what the code says about itself.
    #[test]
    fn a_named_rollover_is_refused() {
        let content = format!("// {NAMED_ROLLOVER} to the cached value\nreturn cached;");
        let found = refusal(SOURCE, &content, false).expect("the word is there");
        assert!(found.contains("Forbidden pattern"), "{found}");
    }

    /// A vendored tree is judged by the universal rules only.
    #[test]
    fn a_vendored_file_is_judged_only_by_the_universal_rules() {
        let named = format!("// {NAMED_ROLLOVER} to the cached value");
        assert_eq!(refusal(VENDORED, &named, true), None);
        let blob = format!("import('{}base64,x')", concat!("data:text", "/javascript;"));
        assert!(refusal(VENDORED, &blob, true).is_some());
    }

    #[test]
    fn empty_content_is_not_judged() {
        assert_eq!(refusal(SOURCE, "", false), None);
    }
}
