//! What a hook is, to the engine: the source it runs and the digest that
//! identifies it, and the mode its tier and phase put it in.
//!
//! Split out of `engine/mod.rs`, which had grown past the
//! three-hundred-line limit; the outcome recording stays there.

use std::fs;

use sha2::{Digest, Sha256};

use super::lookup::{command_for, source_for};
use super::{Engine, SourceIdentity};
use crate::util::shell_words;

impl Engine {
    pub fn source_identity(&self, hook_id: &str) -> SourceIdentity {
        let id = hook_id.to_string();
        let command = command_for(&self.registry_value, &id);
        let Some(command) = command else {
            return SourceIdentity {
                hook_id: id,
                command: None,
                source_path: None,
                digest: None,
                verifiable: false,
            };
        };
        let source_path = source_for(&command, &self.registry_path);
        // try { hash... } catch { unverifiable }
        let hashed = (|| -> Option<SourceIdentity> {
            let mut hasher = Sha256::new();
            hasher.update(command.as_bytes());
            if let Some(path) = &source_path {
                if path.exists() {
                    let bytes = fs::read(path).ok()?;
                    hasher.update(b"\0");
                    hasher.update(bytes);
                    return Some(SourceIdentity {
                        hook_id: id.clone(),
                        command: Some(command.clone()),
                        source_path: Some(path.to_string_lossy().to_string()),
                        digest: Some(format!("{:x}", hasher.finalize())),
                        verifiable: true,
                    });
                }
            }
            let missing_script = shell_words(&command).iter().any(|word| {
                word.ends_with(".py") || word.ends_with(".sh") || word.ends_with(".mjs")
            });
            if missing_script {
                return Some(SourceIdentity {
                    hook_id: id.clone(),
                    command: Some(command.clone()),
                    source_path: None,
                    digest: None,
                    verifiable: false,
                });
            }
            Some(SourceIdentity {
                hook_id: id.clone(),
                command: Some(command.clone()),
                source_path: None,
                digest: Some(format!("{:x}", hasher.finalize())),
                verifiable: true,
            })
        })();
        hashed.unwrap_or(SourceIdentity {
            hook_id: id,
            command: Some(command),
            source_path: None,
            digest: None,
            verifiable: false,
        })
    }

    /// `effectiveMode(hookId)`.
    pub fn effective_mode(&self, hook_id: &str) -> &'static str {
        let tier = self.tier_of(hook_id);
        if tier.name == "advisory" {
            return "warn";
        }
        if tier.name != "etiquette" {
            return "enforce";
        }
        let phase = self
            .store
            .snapshot(Some(hook_id))
            .get("phase")
            .and_then(|v| v.as_str())
            .unwrap_or("")
            .to_string();
        if phase == crate::state::phase::WARNING {
            "warn"
        } else {
            "enforce"
        }
    }
}
