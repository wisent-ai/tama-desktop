//! Logic for `tama-block-keyword-literals`, registry hook id
//! `block-keyword-literals`.
//!
//! A hand-written list of words in a code file is a classifier nobody
//! asked for: `["ok", "okej", "zrobione"]` decides what an operator meant,
//! `(likely|probably|might)` decides what an agent claimed, `"cannot be
//! decrypted|spawn gpg"` decides why a release failed. On 2026-09-19 the
//! operator asked whether such lists exist anywhere ("czy sa jakies
//! keywords-based logiki gdziekolwiek w naszym codebasie. harcoded words
//! etc.") — they did, in three products — and then: "to dodaj do tamy hook
//! ktory blokuje jakikolweik uzycie keywordsow albo czegokolwiek
//! hardcodowanego".
//!
//! The same contract as `block-numeric-literals`, for words: a run of three
//! or more quoted words, or a regex alternation of three or more words,
//! written into a code file is refused unless every word is declared in
//! `keyword-provenance.json` under a verbatim quote from a real operator
//! message. The hook certifies that the operator asked for the words, not
//! that the classifier is right. A word here is letters only, possibly
//! several separated by spaces; `tool_name`, `/dev/null` and `--json` are
//! not words and are not judged.

mod finder;
mod provenance;
mod text;

use finder::{word_alternations, word_collections};
pub use provenance::declared_words;
use std::collections::HashSet;
pub use text::judged_text;
use text::{came_from_elsewhere, without_comments};

use regex::Regex;
use serde_json::Value;
use tama_hooks::session_record::{deny_tool_use, read_payload};

use super::check_numeric_literals_payload as payload_shapes;
use super::check_numeric_literals_scan as scan;
use super::pyvalue;

const HOOK: &str = "block-keyword-literals";
/// The one file where words may live; validated, never scanned.
const PROVENANCE_RE: &str = "(^|/)keyword-provenance\\.json\\n?\\z";
const INPUT_KEYS: &[&str] = &["tool_input", "input"];
const NUL: char = '\0';
const BANNER_JOIN: &str = "\n  ";
/// How many words make a list. Text: this file is not allowed a bare number.
const LIST_MIN_TEXT: &str = "3";

fn list_min() -> usize {
    LIST_MIN_TEXT.parse().unwrap_or_default()
}

fn tool_input(payload: &Value) -> Value {
    INPUT_KEYS
        .iter()
        .filter_map(|key| payload.get(*key))
        .find(|value| pyvalue::truthy(value))
        .cloned()
        .unwrap_or_else(|| Value::Object(Default::default()))
}

/// Every flagged run in one text, as `(line, kind, words)`, with the
/// declarations applied. The guard turns these into refusals; `tama
/// vocabulary-report` groups them by their words so one declaration can
/// replace every copy at once.
pub fn vocabularies(
    text: &str,
    declared: &HashSet<String>,
) -> Vec<(usize, &'static str, Vec<String>)> {
    word_collections(text)
        .into_iter()
        .map(|(line, words)| (line, "list", words))
        .chain(
            word_alternations(text)
                .into_iter()
                .map(|(line, words)| (line, "alternation", words)),
        )
        .filter(|(_, _, words)| {
            words
                .iter()
                .any(|word| !declared.contains(&word.to_lowercase()))
        })
        .collect()
}

/// The findings for one written text, against the words `declared`.
pub fn findings(path: &str, text: &str, declared: &HashSet<String>) -> Vec<String> {
    let mut out = Vec::new();
    for (line, kind, words) in vocabularies(text, declared) {
        let undeclared: Vec<&String> = words
            .iter()
            .filter(|word| !declared.contains(&word.to_lowercase()))
            .collect();
        if undeclared.is_empty() {
            continue;
        }
        out.push(format!(
            "{path}:{line}: a {kind} of {} words decides something by keyword ({}); undeclared: {}",
            words.len(),
            words
                .iter()
                .map(|w| format!("\"{w}\""))
                .collect::<Vec<_>>()
                .join(", "),
            undeclared
                .iter()
                .map(|w| format!("\"{w}\""))
                .collect::<Vec<_>>()
                .join(", "),
        ));
    }
    out
}

fn check(payload: &Value) -> Vec<String> {
    let input = tool_input(payload);
    let provenance_path = Regex::new(PROVENANCE_RE).unwrap_or_else(|_| unreachable!());
    let mut out = Vec::new();
    for (raw_path, text) in payload_shapes::path_texts(&input) {
        let Some(path) = payload_shapes::local_file_path(&raw_path) else {
            continue;
        };
        if path.is_empty() || text.is_empty() || text.contains(NUL) {
            continue;
        }
        if provenance_path.is_match(&path) {
            out.extend(provenance::check(&text));
            continue;
        }
        if came_from_elsewhere(&path) {
            continue;
        }
        let Some(lang) = scan::lang_for(&path) else {
            continue;
        };
        let declared = provenance::declared_words(&path);
        out.extend(findings(&path, &without_comments(&text, &lang), &declared));
    }
    out
}

/// A payload without written text — a read, a bash line — yields no
/// (path, text) pair from `path_texts` and is never judged. That is also
/// what keeps this guard free of a list of tool names, which its own rule
/// would refuse.
pub fn run() {
    let payload = read_payload();
    if !payload.is_object() {
        payload_shapes::crash();
    }
    let mut violations = check(&payload);
    if violations.is_empty() {
        return;
    }
    // The first line is what a scanner report and a harness card show, so it
    // carries the first finding; the rule and the way through come next.
    let first = violations.remove(usize::default());
    let rest = if violations.is_empty() {
        String::new()
    } else {
        format!("{BANNER_JOIN}{}", violations.join(BANNER_JOIN))
    };
    deny_tool_use(&format!(
        "{HOOK}: BLOCKED: {first}\n  a keyword list is a classifier nobody asked for. Decide with \
         a model judgement through Brama, or with data the operator declared; a word may live in \
         code only under keyword-provenance.json with the operator's verbatim quote that asked \
         for it.{rest}"
    ));
}

#[cfg(test)]
mod tests {
    use super::{findings, without_comments, word_alternations, word_collections};
    use std::collections::HashSet;

    const FILE: &str = "src/words.rs";

    fn none() -> HashSet<String> {
        HashSet::new()
    }

    #[test]
    fn a_list_of_words_is_refused_and_names_them() {
        let text = "static ACKS: &[&str] = &[\"ok\", \"okej\", \"zrobione\"];\n";
        let found = findings(FILE, text, &none());
        assert_eq!(found.len(), usize::from(true), "{found:?}");
        assert!(
            found[usize::default()].contains("\"zrobione\""),
            "{found:?}"
        );
        assert!(
            found[usize::default()].starts_with("src/words.rs:1:"),
            "{found:?}"
        );
    }

    #[test]
    fn a_multi_line_list_and_a_python_list_are_one_list_each() {
        let rust = "const ORDERS: &[&str] = &[\n    \"nie koduj\",\n    \"do roboty\",\n    \"go ahead\",\n];\n";
        assert_eq!(word_collections(rust).len(), usize::from(true));
        let python = "WEASEL = ['likely', 'probably', 'might', 'perhaps']\n";
        assert_eq!(word_collections(python).len(), usize::from(true));
    }

    #[test]
    fn identifiers_paths_flags_and_short_runs_are_not_lists() {
        let keys = "const KEYS: &[&str] = &[\"tool_name\", \"tool_input\", \"file_path\"];\n";
        let paths = "let roots = [\"/dev/null\", \"rust/target\", \"~/x\"];\n";
        let flags = "let argv = [\"--json\", \"--open\", \"-v\"];\n";
        let two = "let pair = [\"op\", \"action\"];\n";
        for text in [keys, paths, flags, two] {
            assert!(word_collections(text).is_empty(), "{text}");
        }
    }

    #[test]
    fn a_regex_alternation_of_words_is_refused_with_its_syntax_stripped() {
        // Fixtures are assembled from one phrase: a literal alternation of
        // three words in this file would be refused by this very guard.
        let alternatives = "potwierd zatwierd akceptacj"
            .split(' ')
            .map(|word| format!("{word}[źz]\\\\w*"))
            .collect::<Vec<_>>()
            .join("|");
        let text = format!("compile(\"(?i)\\\\b({alternatives})\\\\b\")");
        let found = word_alternations(&text);
        assert_eq!(found.len(), usize::from(true), "{found:?}");
        assert_eq!(
            found[usize::default()].1.join(" "),
            "potwierd zatwierd akceptacj"
        );
        let needles = "cannot be decrypted;spawn gpg;no route".replace(';', "|");
        let bare = format!("const NEEDLES: &str = \"{needles}\";");
        assert_eq!(word_alternations(&bare).len(), usize::from(true));
    }

    #[test]
    fn a_list_quoted_in_a_comment_is_a_report_not_a_classifier() {
        let rust = "//! decides by `[\"ok\", \"okej\", \"zrobione\"]`\nlet x = [\"ok\", \"okej\", \"zrobione\"];\n";
        let blanked = without_comments(rust, "rust");
        assert_eq!(word_collections(&blanked).len(), usize::from(true));
        let second_line = "//!\n".lines().count() + usize::from(true);
        assert_eq!(word_collections(&blanked)[usize::default()].0, second_line);
        let python = "# ['ok', 'okej', 'zrobione'] decides\nACKS = 'ok'\n";
        assert!(word_collections(&without_comments(python, "py")).is_empty());
    }

    #[test]
    fn an_alternation_of_syntax_or_two_words_is_not_a_list() {
        let syntax = "compile(\"(^|/)\\\\.git/hooks(/|\\n?\\\\z)\")";
        assert!(word_alternations(syntax).is_empty());
        let two = "compile(\"(?i)(status|diff)\")";
        assert!(word_alternations(two).is_empty());
    }

    #[test]
    fn declared_words_pass_and_one_undeclared_word_still_refuses() {
        let text = "let acks = [\"ok\", \"okej\", \"zrobione\"];\n";
        let declared: HashSet<String> = "ok okej zrobione".split(' ').map(str::to_owned).collect();
        assert!(findings(FILE, text, &declared).is_empty());
        let partial: HashSet<String> = ["ok", "okej"].iter().map(|w| w.to_string()).collect();
        let found = findings(FILE, text, &partial);
        assert!(
            found[usize::default()].ends_with("undeclared: \"zrobione\""),
            "{found:?}"
        );
    }
}
