//! The `tama sessions` command, extracted from the crate root: lists every
//! agent session record, whether its process is still there, and the hook
//! state it reported, merged with the machine-wide enforcement status.
//!
//! A record whose runtime never reported used to print `?/?`, which reads as
//! a broken session and says nothing about which of the two it is. The row
//! now says `no runtime report` and carries the process state beside it, so
//! the operator can tell a session that ended from one that is running
//! without publishing its hook state.

use std::path::{Path, PathBuf};

use super::args::{has, option_value};
use super::output::print_json;
use crate::enforcement;

/// Is the process that wrote this record still there? `kill(pid, 0)` is the
/// same probe the session supervisor uses for `livenessMode: "process"`.
///
/// `None` when the record carries no usable process id. The range check is
/// not decoration: `kill` reads a negative first argument as "every process
/// this caller may signal", so an out-of-range id cast down to `-1` answers
/// "alive" for a session that never existed.
fn running(pid: u64) -> Option<bool> {
    let candidate = i32::try_from(pid).ok().filter(|id| *id > i32::default())?;
    Some(tama_hook_tools::util::sys::send_signal(
        candidate as u32,
        i32::default(),
    ))
}

pub fn main(argv: &[String], root: &Path) -> i32 {
    let home = option_value(argv, "--home")
        .or_else(|| std::env::var("HOME").ok())
        .unwrap_or_default();
    let control_dir =
        std::path::Path::new(&home).join("Library/Application Support/Tama/session-control");

    let mut entries: Vec<PathBuf> = match std::fs::read_dir(&control_dir) {
        Ok(rd) => rd
            .filter_map(|e| e.ok())
            .map(|e| e.path())
            .filter(|p| {
                p.extension().is_some_and(|ext| ext == "json")
                    && p.to_string_lossy().ends_with(".session.json")
            })
            .collect(),
        Err(_) => Vec::new(),
    };
    entries.sort();

    let mut sessions: Vec<serde_json::Value> = Vec::new();
    for path in &entries {
        match std::fs::read_to_string(path) {
            Ok(text) => match serde_json::from_str::<serde_json::Value>(&text) {
                Ok(raw) => {
                    let runtime = raw.get("runtime");
                    let pid = raw.get("pid").and_then(serde_json::Value::as_u64);
                    let session = serde_json::json!({
                        "sessionId": raw.get("sessionId").cloned().unwrap_or(serde_json::Value::Null),
                        "agentId": raw.get("agentId").cloned().unwrap_or(serde_json::Value::Null),
                        "cwd": raw.get("cwd").cloned().unwrap_or(serde_json::Value::Null),
                        "status": raw.get("status").cloned().unwrap_or(serde_json::Value::Null),
                        "pid": raw.get("pid").cloned().unwrap_or(serde_json::Value::Null),
                        "livenessMode": raw.get("livenessMode").cloned().unwrap_or(serde_json::Value::Null),
                        "processAlive": pid.and_then(running).map(serde_json::Value::Bool).unwrap_or(serde_json::Value::Null),
                        "runtimeReported": serde_json::Value::Bool(runtime.is_some()),
                        "globallyDisabled": runtime.and_then(|r| r.get("globallyDisabled")).cloned().unwrap_or(serde_json::Value::Null),
                        "loadedHookCount": runtime.and_then(|r| r.get("loadedHookCount")).cloned().unwrap_or(serde_json::Value::Null),
                        "registeredHookCount": runtime.and_then(|r| r.get("registeredHookCount")).cloned().unwrap_or(serde_json::Value::Null),
                        "enabledHookIds": runtime.and_then(|r| r.get("enabledHookIds")).cloned().unwrap_or(serde_json::json!([])),
                        "disabledHookIds": runtime.and_then(|r| r.get("disabledHookIds")).cloned().unwrap_or(serde_json::json!([])),
                        "updatedAt": raw.get("updatedAt").cloned().unwrap_or(serde_json::Value::Null),
                    });
                    sessions.push(session);
                }
                Err(_) => {
                    sessions.push(serde_json::json!({ "sessionId": path.display().to_string(), "parseError": true }));
                }
            },
            Err(_) => {
                sessions.push(serde_json::json!({ "sessionId": path.display().to_string(), "readError": true }));
            }
        }
    }
    let machine_enforcement = match enforcement::status_for_home(root, std::path::Path::new(&home))
    {
        Ok(status) => status,
        Err(error) => {
            eprintln!("{error}");
            return 1;
        }
    };
    enforcement::report_read_error(&machine_enforcement);
    let exit_code = if machine_enforcement.read_error.is_some() {
        1
    } else {
        0
    };

    if has(argv, "--json") {
        print_json(&serde_json::json!({
            "machineEnforcement": &machine_enforcement,
            "sessions": sessions,
        }));
    } else {
        println!("{}", enforcement::session_summary(&machine_enforcement));
        let mut live = usize::MIN;
        let mut ended = usize::MIN;
        let mut unusable = usize::MIN;
        let mut silent = usize::MIN;
        for s in &sessions {
            let agent = s.get("agentId").and_then(|v| v.as_str()).unwrap_or("?");
            let session_id = s.get("sessionId").and_then(|v| v.as_str()).unwrap_or("?");
            let short_id: String = session_id.chars().take(12).collect();
            let alive = s.get("processAlive").and_then(|v| v.as_bool());
            let process = match alive {
                Some(true) => {
                    live += 1;
                    "running"
                }
                Some(false) => {
                    ended += 1;
                    "gone"
                }
                None => {
                    unusable += 1;
                    "no usable pid"
                }
            };
            let globally_disabled = s
                .get("globallyDisabled")
                .and_then(|v| v.as_bool())
                .unwrap_or(false);
            let reported = s
                .get("runtimeReported")
                .and_then(|v| v.as_bool())
                .unwrap_or(false);
            let hooks = if !reported {
                silent += 1;
                "no runtime report".to_string()
            } else if globally_disabled {
                let enabled: Vec<&str> = s
                    .get("enabledHookIds")
                    .and_then(|v| v.as_array())
                    .map(|a| a.iter().filter_map(|x| x.as_str()).collect())
                    .unwrap_or_default();
                if enabled.is_empty() {
                    "allowlist: empty".to_string()
                } else {
                    format!("allowlist: {}", enabled.join(", "))
                }
            } else {
                let loaded = s
                    .get("loadedHookCount")
                    .and_then(|v| v.as_i64())
                    .map(|v| v.to_string())
                    .unwrap_or("no count".into());
                let registered = s
                    .get("registeredHookCount")
                    .and_then(|v| v.as_i64())
                    .map(|v| v.to_string())
                    .unwrap_or("no count".into());
                format!("{loaded}/{registered}")
            };
            println!("{agent}\t{short_id}\t{process}\t{hooks}");
        }
        println!(
            "session records\t{}\trunning={live}\tgone={ended}\tno-usable-pid={unusable}\tno-runtime-report={silent}",
            sessions.len()
        );
    }
    exit_code
}
