//! `block-unapproved-audits` — port of
//! `shared-hooks/block_unapproved_audits.py`.
//!
//! Block explicitly declared audit workflows without device-level approval. An
//! audit command arms a per-scope gate that survives until the next user prompt
//! or an approval; a tool call that tries to write the approval policy from
//! inside the session is denied outright.
//!
//! Consent state: see `block_unapproved_audits_state` — the approval file at
//! `~/.config/agent-policy/device_level_audits.json` (or
//! `$DEVICE_LEVEL_AUDITS_POLICY`) and the gate record under
//! `${XDG_STATE_HOME:-~/.local/state}/jeden-hooks/audit-consent/`.

use super::block_unapproved_audits_state as state;
use super::python_stdlib;
use super::pyvalue::{first_truthy_py_str, py_json_dumps, py_str, truthy};
use regex::Regex;
use serde_json::Value;
use std::path::Path;
use tama_hooks::session_record::read_payload;

const EXIT_PASS_TEXT: &str = "0";
const EXIT_BLOCK_TEXT: &str = "2";
/// An `OSError` other than `FileNotFoundError` ends the Python process.
const EXIT_CRASH_TEXT: &str = "1";

const WRITE_TOOLS: &[&str] = &[
    "apply_patch",
    "applypatch",
    "edit",
    "multiedit",
    "write",
    "write_file",
    "writefile",
];
const AUDIT_PROGRAMS: &[&str] = &["bundle-audit", "cargo-audit", "osv-scanner", "pip-audit"];
const PACKAGE_AUDIT_PROGRAMS: &[&str] = &["bun", "npm", "pnpm", "yarn"];
const BUNDLE_PROGRAM: &str = "bundle";
const AUDIT_SUBCOMMAND: &str = "audit";

const TOOL_NAME_KEYS: &[&str] = &["tool_name", "name", "tool"];
const NAME_KEY: &str = "name";
const TOOL_KEY: &str = "tool";
const INPUT_KEY: &str = "input";
use crate::ports::tool_vocabulary::{COMMAND_KEYS, TOOL_INPUT_KEY};

const PATH_KEYS: &[&str] = &["file_path", "path", "notebook_path"];
const PATCH_KEYS: &[&str] = &["input", "patch"];
const EDITS_KEY: &str = "edits";
const EVENT_KEYS: &[&str] = &["agent_hook_event", "hook_event_name", "hook_event", "event"];
const USER_PROMPT_SUBMIT: &str = "userpromptsubmit";
const DEFAULT_PREVIOUS_REASON: &str = "an audit was declared earlier in this session";

const POLICY_MUTATION_PATTERN: &str = concat!(
    "(?i)(?:>|\\b(?:tee|touch|cp|mv|install|rsync|dd|write_text|writefile)\\b",
    "|\\bsed\\b[^\\n]*\\s-i\\b)"
);
/// The two envelopes a patch names its file in, from the one declaration
/// in [`super::patch_envelope`], as one multi-line pattern.
fn patch_path_pattern() -> String {
    format!(
        "(?m)^(?:\\[([^#\\]\\n]+)#|{})$",
        super::patch_envelope::file_header_in_text()
    )
}
const SEGMENT_PATTERN: &str = "(?:&&|\\|\\||[;\\n])";
const ASSIGNMENT_PATTERN: &str = "\\A[A-Za-z_][A-Za-z0-9_]*=.*\\z";

fn exit_pass() -> i32 {
    EXIT_PASS_TEXT.parse().unwrap_or_default()
}

fn exit_block() -> i32 {
    EXIT_BLOCK_TEXT.parse().unwrap_or_default()
}

fn exit_crash() -> i32 {
    EXIT_CRASH_TEXT.parse().unwrap_or_default()
}

fn empty_object() -> Value {
    Value::Object(Default::default())
}

fn compile(pattern: &str) -> Regex {
    Regex::new(pattern).expect("hook pattern must compile")
}

fn base_name(path: &str) -> String {
    Path::new(path)
        .file_name()
        .map(|name| name.to_string_lossy().to_string())
        .unwrap_or_default()
}

fn tool_name(payload: &Value) -> String {
    let mut value = Value::String(String::new());
    for key in TOOL_NAME_KEYS {
        if let Some(found) = payload.get(*key) {
            if truthy(found) {
                value = found.clone();
                break;
            }
        }
    }
    if let Value::Object(map) = &value {
        let nested = map.get(NAME_KEY).cloned().unwrap_or(Value::Null);
        value = if truthy(&nested) {
            nested
        } else {
            Value::String(String::new())
        };
    }
    super::pystr::strip(&py_str(&value)).to_lowercase()
}

fn tool_input(payload: &Value) -> Value {
    let value = match payload.get(TOOL_INPUT_KEY) {
        Some(found) if truthy(found) => found.clone(),
        _ => payload.get(INPUT_KEY).cloned().unwrap_or(Value::Null),
    };
    let value = if value.is_object() {
        value
    } else {
        match payload.get(TOOL_KEY) {
            Some(Value::Object(map)) => map.get(INPUT_KEY).cloned().unwrap_or(Value::Null),
            _ => empty_object(),
        }
    };
    if value.is_object() {
        value
    } else {
        empty_object()
    }
}

fn candidate_paths(value: &Value, patch_paths: &Regex, found: &mut Vec<String>) {
    let map = match value {
        Value::Object(map) => map,
        _ => return,
    };
    for key in PATH_KEYS {
        if let Some(Value::String(text)) = map.get(*key) {
            found.push(text.clone());
        }
    }
    for key in PATCH_KEYS {
        let text = match map.get(*key) {
            Some(Value::String(text)) => text,
            _ => continue,
        };
        for captures in patch_paths.captures_iter(text) {
            if let Some(group) = captures
                .iter()
                .skip(python_stdlib::one())
                .flatten()
                .find(|group| !group.as_str().is_empty())
            {
                found.push(group.as_str().to_string());
            }
        }
    }
    if let Some(Value::Array(edits)) = map.get(EDITS_KEY) {
        for edit in edits {
            candidate_paths(edit, patch_paths, found);
        }
    }
}

fn approval_bypass_reason(payload: &Value, policy_name: &str) -> Option<String> {
    let full = tool_name(payload);
    let name = full.rsplit('.').next().unwrap_or_default();
    let input = tool_input(payload);
    let wanted = policy_name.to_lowercase();
    if WRITE_TOOLS.contains(&name) {
        let mut found = Vec::new();
        candidate_paths(&input, &compile(&patch_path_pattern()), &mut found);
        for path in found {
            if base_name(&path).to_lowercase() == wanted {
                return Some(format!("attempted in-session audit policy write: {path}"));
            }
        }
        return None;
    }
    let serialized = py_json_dumps(&input);
    if serialized.to_lowercase().contains(&wanted)
        && compile(POLICY_MUTATION_PATTERN).is_match(&serialized)
    {
        return Some(format!(
            "attempted in-session audit policy mutation: {policy_name}"
        ));
    }
    None
}

fn audit_command_reason(command: &str) -> Option<String> {
    let assignment = compile(ASSIGNMENT_PATTERN);
    let splitter = compile(SEGMENT_PATTERN);
    for segment in splitter.split(command) {
        let tokens = python_stdlib::shell_tokens(segment);
        if tokens.is_empty() {
            continue;
        }
        let mut cursor = usize::MIN;
        while cursor < tokens.len() && assignment.is_match(&tokens[cursor]) {
            cursor += python_stdlib::one();
        }
        let (token, rest) = match tokens.get(cursor..).and_then(|rest| rest.split_first()) {
            Some(parts) => parts,
            None => continue,
        };
        let program = base_name(token).to_lowercase();
        let first_arg = rest.first().map(|arg| arg.to_lowercase());
        let subcommand = first_arg.as_deref() == Some(AUDIT_SUBCOMMAND);
        if AUDIT_PROGRAMS.contains(&program.as_str()) {
            return Some(format!("audit program: {program}"));
        }
        if PACKAGE_AUDIT_PROGRAMS.contains(&program.as_str()) && subcommand {
            return Some(format!("audit program: {program} audit"));
        }
        if program == BUNDLE_PROGRAM && subcommand {
            return Some(format!("audit program: {BUNDLE_PROGRAM} audit"));
        }
    }
    None
}

fn declared_audit_reason(payload: &Value) -> Option<String> {
    let input = tool_input(payload);
    audit_command_reason(&first_truthy_py_str(&input, COMMAND_KEYS))
}

fn block(reason: &str) -> i32 {
    let approval = state::APPROVAL_ENV;
    let field = state::POLICY_FIELD;
    let policy = state::policy_path();
    eprintln!(
        "BLOCKED: audit workflows require explicit user-controlled device \
approval. Set {approval}=1 outside the agent session or enable {field} in {}. \
Detected: {reason}",
        policy.display()
    );
    exit_block()
}

fn letters_only(text: &str) -> String {
    text.chars().filter(char::is_ascii_lowercase).collect()
}

pub fn run() -> i32 {
    let payload = match read_payload() {
        value if value.is_object() => value,
        _ => empty_object(),
    };
    let event = first_truthy_py_str(&payload, EVENT_KEYS);
    if letters_only(&event.to_lowercase()) == USER_PROMPT_SUBMIT {
        return match state::clear_state(&payload) {
            Ok(()) => exit_pass(),
            Err(_) => exit_crash(),
        };
    }
    if let Some(reason) = approval_bypass_reason(&payload, &state::policy_name()) {
        return block(&reason);
    }
    if state::approved() {
        return match state::clear_state(&payload) {
            Ok(()) => exit_pass(),
            Err(_) => exit_crash(),
        };
    }
    if let Some(reason) = declared_audit_reason(&payload) {
        if state::write_state(&payload, &reason).is_err() {
            return exit_crash();
        }
        return block(&reason);
    }
    // Ported dead branch: `declared_audit_reason` is `None` by construction
    // here, so the recorded gate can never fire. The read still happens.
    let recorded = state::read_state(&payload);
    if let (Some(found), Some(_)) = (recorded, declared_audit_reason(&payload)) {
        let previous = state::recorded_reason(&found, DEFAULT_PREVIOUS_REASON);
        let path = state::state_path(&payload);
        return block(&format!(
            "{previous}; audit gate remains active until the next user prompt \
or approval. Clear it by deleting {}",
            path.display()
        ));
    }
    exit_pass()
}
