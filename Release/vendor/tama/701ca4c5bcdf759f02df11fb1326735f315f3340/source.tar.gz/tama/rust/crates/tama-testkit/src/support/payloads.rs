//! The recorder a live run installs in place of the real runner, and the
//! coverage keys read back out of what it wrote.
//!
//! Split out of `support/mod.rs`, which had grown past the three-hundred-line
//! limit; running a command stays there.

use std::path::{Path, PathBuf};

use super::paths::{io_error_message, read, write_file, REAL_RUNNER};
use crate::json::{self, Json};

/// JS `tail(text, length = 1000)`.
const TAIL_CHARS: usize = 1000;
/// The recorder is written executable, like the runner it stands in for.
#[cfg(unix)]
const RECORDER_MODE: u32 = 0o755;

/// JS `makeRecorder(tmp)`: writes `record-run-hook.mjs` (verbatim content,
/// mode 0755) and returns `{ payloadLog, recorder }`.
pub fn make_recorder(tmp: &Path) -> Result<(PathBuf, PathBuf), String> {
    let payload_log = tmp.join("runtime-payloads.jsonl");
    let recorder = tmp.join("record-run-hook.mjs");
    let content = format!(
        "#!/usr/bin/env node\n\
         import {{ spawnSync }} from 'node:child_process';\n\
         import {{ appendFileSync, readFileSync }} from 'node:fs';\n\
         const input = readFileSync(0, 'utf8');\n\
         const parsedInput = JSON.parse(input || '{{}}');\n\
         const child = spawnSync(process.execPath, [{real_runner}, ...process.argv.slice(2)], {{ input, encoding: 'utf8', stdio: ['pipe', 'pipe', 'pipe'], env: process.env }});\n\
         let parsedStdout = null;\n\
         try {{ parsedStdout = JSON.parse(child.stdout || '{{}}'); }} catch {{}}\n\
         appendFileSync({payload_log}, JSON.stringify({{ argv: process.argv.slice(2), input: parsedInput, runner: {{ status: child.status, signal: child.signal, stdout: child.stdout, stderr: child.stderr, json: parsedStdout }} }}) + '\\n');\n\
         if (child.stdout) process.stdout.write(child.stdout);\n\
         if (child.stderr) process.stderr.write(child.stderr);\n\
         process.exit(child.status ?? 1);\n",
        real_runner = Json::str(REAL_RUNNER).to_compact(),
        payload_log = Json::str(payload_log.to_string_lossy().into_owned()).to_compact(),
    );
    write_file(&recorder, &content)?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        std::fs::set_permissions(&recorder, std::fs::Permissions::from_mode(RECORDER_MODE))
            .map_err(|e| io_error_message("chmod", &recorder, &e))?;
    }
    Ok((payload_log, recorder))
}

/// JS `readPayloads(payloadLog)`: one bad line (or a read failure) discards
/// everything (the whole body sits inside a single `try`).
pub fn read_payloads(payload_log: &Path) -> Vec<Json> {
    let parse_all = || -> Result<Vec<Json>, String> {
        let text = read(payload_log)?;
        text.trim()
            .split('\n')
            .filter(|line| !line.is_empty())
            .map(json::parse)
            .collect()
    };
    parse_all().unwrap_or_default()
}

/// JS `parseJsonLines(path)`: per-line tolerant parse (bad lines dropped).
pub fn parse_json_lines(path: &Path) -> Vec<Json> {
    if !path.exists() {
        return Vec::new();
    }
    let text = match std::fs::read_to_string(path) {
        Ok(text) => text,
        Err(_) => return Vec::new(),
    };
    text.split('\n')
        .filter(|line| !line.is_empty())
        .filter_map(|line| json::parse(line).ok())
        .collect()
}

/// JS `parseJsonLinesFromText(text)` from `codex-replay.mjs`.
pub fn parse_json_lines_from_text(text: &str) -> Vec<Json> {
    text.split('\n')
        .filter(|line| !line.is_empty())
        .filter_map(|line| json::parse(line).ok())
        .collect()
}

/// JS `unique(values)`: dedup preserving first-seen order, falsy dropped.
pub fn unique(values: Vec<String>) -> Vec<String> {
    let mut seen: Vec<String> = Vec::new();
    for value in values {
        if !value.is_empty() && !seen.contains(&value) {
            seen.push(value);
        }
    }
    seen
}

/// JS `tail(text, length = 1000)` = `String(text || '').slice(-length)`.
pub fn tail(text: &str) -> String {
    tail_n(text, TAIL_CHARS)
}

pub fn tail_n(text: &str, length: usize) -> String {
    let chars: Vec<char> = text.chars().collect();
    chars
        .iter()
        .skip(chars.len().saturating_sub(length))
        .collect()
}

/// JS `ompClaimedEvent(entry)`.
pub fn omp_claimed_event(entry: &Json) -> String {
    let runtime_event = json::js_string_opt(entry.get("argv").and_then(|argv| argv.at(0)));
    if runtime_event == "pre_tool_use:edit"
        && entry
            .get("input")
            .and_then(|input| input.get("tool_name"))
            .and_then(Json::as_str)
            == Some("Write")
    {
        return "pre_tool_use:write".to_string();
    }
    runtime_event
}

/// JS `coverageKey(runtime, event, hookId, runtimeEvent = event)` where any
/// argument may be JS `undefined` (interpolated as "undefined").
pub fn coverage_key_opt(runtime: &str, event: &str, hook_id: &str, runtime_event: &str) -> String {
    if runtime_event == event {
        format!("{runtime}:{event}:{hook_id}")
    } else {
        format!("{runtime}:{event}:via:{runtime_event}:{hook_id}")
    }
}

/// JS `coveredKeysFromOmpPayloads(payloads)`.
pub fn covered_keys_from_omp_payloads(payloads: &[Json]) -> Vec<String> {
    let mut keys = Vec::new();
    for entry in payloads {
        let runtime_event = json::js_string_opt(entry.get("argv").and_then(|argv| argv.at(0)));
        let event = omp_claimed_event(entry);
        let results = entry
            .get("runner")
            .and_then(|r| r.get("json"))
            .and_then(|j| j.get("results"))
            .and_then(Json::as_array)
            .unwrap_or(&[]);
        for result in results {
            if let Some(id) = result
                .get("id")
                .and_then(Json::as_str)
                .filter(|s| !s.is_empty())
            {
                keys.push(coverage_key_opt("omp", &event, id, &runtime_event));
            } else {
                // `result.id ? ... : null` — null is dropped by `unique`.
                keys.push(String::new());
            }
        }
    }
    unique(keys)
}

/// JS `coveredKeysFromEditorOutcomes(parsed, runtime)`.
pub fn covered_keys_from_editor_outcomes(parsed: Option<&Json>, runtime: &str) -> Vec<String> {
    let mut keys = Vec::new();
    let outcomes = parsed
        .and_then(|p| p.get("outcomes"))
        .and_then(Json::as_array)
        .unwrap_or(&[]);
    for outcome in outcomes {
        let results = outcome
            .get("results")
            .and_then(Json::as_array)
            .unwrap_or(&[]);
        for result in results {
            let hook_results = result
                .get("parsed")
                .and_then(|p| p.get("results"))
                .and_then(Json::as_array)
                .unwrap_or(&[]);
            for hook_result in hook_results {
                match hook_result
                    .get("id")
                    .and_then(Json::as_str)
                    .filter(|s| !s.is_empty())
                {
                    Some(id) => {
                        let event = json::js_string_opt(result.get("event"));
                        keys.push(coverage_key_opt(runtime, &event, id, &event));
                    }
                    None => keys.push(String::new()),
                }
            }
        }
    }
    unique(keys)
}

/// JS `coveredKeysFromEditorWatchLog(logPath, runtime)`.
pub fn covered_keys_from_editor_watch_log(log_path: &Path, runtime: &str) -> Vec<String> {
    let mut keys = Vec::new();
    for line in parse_json_lines(log_path) {
        if line.get("message").and_then(Json::as_str) != Some("guard-result") {
            continue;
        }
        let stdout = line
            .get("data")
            .and_then(|d| d.get("stdout"))
            .and_then(Json::as_str)
            .unwrap_or("{}");
        // `try { parsed = JSON.parse(...) } catch {}` — stays null on error.
        let parsed = json::parse(stdout).ok();
        keys.extend(covered_keys_from_editor_outcomes(parsed.as_ref(), runtime));
    }
    unique(keys)
}

/// JS `attempt(name, fn)`: errors become `{ ok: false, name, error }`.
pub fn attempt(name: &str, run_scenario: impl FnOnce() -> Result<Json, String>) -> Json {
    match run_scenario() {
        Ok(result) => result,
        Err(error) => Json::obj(vec![
            ("ok".to_string(), Json::Bool(false)),
            ("name".to_string(), Json::str(name)),
            ("error".to_string(), Json::str(error)),
        ]),
    }
}
