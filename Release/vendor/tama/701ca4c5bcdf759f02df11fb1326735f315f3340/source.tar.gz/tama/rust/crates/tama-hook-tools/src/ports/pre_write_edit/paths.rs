//! Where a write may not land, whatever it contains.
//!
//! Four of these were written after an escape. The temporary directories went
//! first; `~/.claude/scratch/` followed on 2026-05-12, when it became the
//! next place ad-hoc scripts accumulated. `~/.claude/settings.json` is the
//! route by which an agent once granted itself the SSH permission its own
//! gate refused, and `~/.shared-hooks/` is the hook tree itself: both need
//! `HOOK_EDIT_AUTHORIZED=1`, which only the operator sets. `to_check/`
//! folders hold files the operator prepared for review, so they are read, not
//! rewritten.

use std::sync::LazyLock;

use regex::Regex;

use crate::ports::transport_common as common;

const AUTHORIZED_ENV: &str = "HOOK_EDIT_AUTHORIZED";
const AUTHORIZED_VALUE: &str = "1";

static TEMPORARY: LazyLock<Regex> = LazyLock::new(|| common::compile("(?i)(/tmp/|/var/folders/)"));
static SCRATCH: LazyLock<Regex> = LazyLock::new(|| common::compile("(^|/)\\.claude/scratch(/|$)"));
static CLAUDE_SETTINGS: LazyLock<Regex> =
    LazyLock::new(|| common::compile("/\\.claude/settings\\.json$"));
static HOOK_TREE: LazyLock<Regex> = LazyLock::new(|| common::compile("/\\.shared-hooks/"));
/// Justification registries are data this very gate demands an agent write
/// (`require-new-file-justification`, the new-test rule below). Refusing them
/// with the hook tree locked the key behind the gate; the consent guard
/// already exempts the same name shape.
static JUSTIFICATION_REGISTRY: LazyLock<Regex> =
    LazyLock::new(|| common::compile("(?i)/\\.shared-hooks/[^/]*justifications?\\.json$"));
static HOOK_STATE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile("/\\.shared-hooks/state/(inspect_required|trajectory_runs)\\.json$")
});
static TO_CHECK: LazyLock<Regex> = LazyLock::new(|| common::compile("(?i)/to_check/"));

const TEMPORARY_REFUSAL: &str = "BLOCKED: Writing to tmp directory is not allowed";
const SCRATCH_REFUSAL: &str = "BLOCKED: Writing to ~/.claude/scratch/ is not allowed";
const SETTINGS_REFUSAL: &str = concat!(
    "BLOCKED: Modifying ~/.claude/settings.json from agent tools is the SSH_AUTHORIZED bypass ",
    "route. The user edits it directly. If a legitimate edit is needed, the user must set ",
    "HOOK_EDIT_AUTHORIZED=1 first.",
);
const HOOK_TREE_REFUSAL: &str = concat!(
    "BLOCKED: Modifying ~/.shared-hooks/ scripts requires HOOK_EDIT_AUTHORIZED=1 set by the ",
    "user. Hooks are edit-protected to remain inescapable.",
);
const HOOK_STATE_REFUSAL: &str = concat!(
    "BLOCKED: writes to ~/.shared-hooks/state/(inspect_required|trajectory_runs).json require ",
    "HOOK_EDIT_AUTHORIZED=1.",
);
const TO_CHECK_REFUSAL: &str = concat!(
    "BLOCKED: NEVER write to to_check folders. These contain user-prepared files. Only read and ",
    "review them.",
);

fn authorized() -> bool {
    std::env::var(AUTHORIZED_ENV).ok().as_deref() == Some(AUTHORIZED_VALUE)
}

/// The refusal this path earns, if any.
pub(crate) fn refusal(path: &str) -> Option<&'static str> {
    if TEMPORARY.is_match(path) {
        return Some(TEMPORARY_REFUSAL);
    }
    if SCRATCH.is_match(path) {
        return Some(SCRATCH_REFUSAL);
    }
    if !authorized() {
        if CLAUDE_SETTINGS.is_match(path) {
            return Some(SETTINGS_REFUSAL);
        }
        if HOOK_STATE.is_match(path) {
            return Some(HOOK_STATE_REFUSAL);
        }
        if HOOK_TREE.is_match(path) && !JUSTIFICATION_REGISTRY.is_match(path) {
            return Some(HOOK_TREE_REFUSAL);
        }
    }
    match TO_CHECK.is_match(path) {
        true => Some(TO_CHECK_REFUSAL),
        false => None,
    }
}

#[cfg(test)]
mod tests {
    use super::refusal;

    /// The pattern is `/tmp/` anywhere in the path, so a repository folder
    /// named `tmp` is refused too. That is the shell's behaviour and it is
    /// kept: a folder called tmp is where throwaway state accumulates
    /// whichever tree it sits in.
    #[test]
    fn a_temporary_directory_is_refused_wherever_it_appears() {
        assert!(refusal("/tmp/scratch.py").is_some());
        assert!(refusal("/var/folders/ab/cd/T/notes.txt").is_some());
        assert!(refusal("/repo/src/tmp/keep.rs").is_some());
        assert!(
            refusal("/repo/src/tmpfile.rs").is_none(),
            "a name is not a folder"
        );
    }

    #[test]
    fn the_scratch_escape_hatch_is_refused() {
        assert!(refusal("/Users/someone/.claude/scratch/run.sh").is_some());
    }

    /// The hook tree and the settings file are the two routes by which an
    /// agent once widened its own permissions.
    #[test]
    fn the_hook_tree_and_the_settings_file_need_the_operator() {
        let settings = refusal("/Users/someone/.claude/settings.json").expect("protected");
        assert!(settings.contains("HOOK_EDIT_AUTHORIZED=1"), "{settings}");
        let hook = refusal("/Users/someone/.shared-hooks/pre_bash.sh").expect("protected");
        assert!(hook.contains("inescapable"), "{hook}");
        let state =
            refusal("/Users/someone/.shared-hooks/state/inspect_required.json").expect("protected");
        assert!(state.contains("inspect_required"), "{state}");
    }

    /// The registries the gates demand an entry in are data, not hook source;
    /// refusing them locked the key behind the gate.
    #[test]
    fn a_justification_registry_is_writable_without_the_operator() {
        assert!(refusal("/Users/someone/.shared-hooks/test_justifications.json").is_none());
        assert!(refusal("/Users/someone/.shared-hooks/cua_justifications.json").is_none());
        assert!(refusal("/Users/someone/.shared-hooks/justifications/pre_bash.sh").is_some());
    }

    #[test]
    fn a_review_folder_is_read_only() {
        assert!(refusal("/Users/someone/Documents/to_check/report.pdf").is_some());
    }

    #[test]
    fn an_ordinary_source_path_passes() {
        assert!(refusal("/repo/src/main.rs").is_none());
        assert!(refusal("/repo/docs/guide.md").is_none());
    }
}
