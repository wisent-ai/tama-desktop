//! tama-mcp-server: MCP server over stdio (newline-delimited JSON-RPC).
//! Rust port of `src/core/server/mcp-server.mjs`.
//!
//! The JS original uses `@modelcontextprotocol/sdk` (v1.29.0 installed); this
//! port reimplements the observable protocol with std only:
//! - Framing: one JSON-RPC message per line (`JSON.stringify(message) + '\n'`),
//!   a single trailing `\r` is stripped from each inbound line.
//! - Envelope: a message is dispatched as a request only when it matches the
//!   SDK's strict `JSONRPCRequestSchema` ({jsonrpc:"2.0", id: string|int,
//!   method: string, params?: object with object `_meta`}). Everything else —
//!   invalid JSON, invalid envelopes, notifications, responses — is dropped
//!   without a reply (the SDK routes those to `onerror`, which the JS server
//!   never sets, and notifications produce no output).
//! - Known methods: `initialize`, `ping`, `tools/list`, `tools/call`.
//!   Unknown methods get `-32601 "Method not found"`. There is no
//!   initialization gating (SDK 1.29 answers `tools/list` before `initialize`).
//! - Schema-validation failures inside a known method get `-32603` with the
//!   zod v4 issue list (`JSON.stringify(issues, null, 2)`), reproduced for the
//!   fields these schemas actually require.
//! - Tool handler errors get `-32603` with the thrown message.
//!
//! Response key order mirrors the SDK: success `{result, jsonrpc, id}`,
//! error `{jsonrpc, id, error:{code, message}}`.
//!
//! Documented deviations (all outside the happy path):
//! - When many pipelined requests arrive in one stdin chunk, the JS event loop
//!   can answer cheap error responses before slower successful ones; this port
//!   answers strictly in order (identical to JS when requests arrive
//!   interactively or all succeed).
//! - Nested zod validation inside `capabilities`, `clientInfo.icons` and
//!   `params.task` is not reproduced (object-level checks only).
//! - Error texts originating from the OS/JSON parser (corrupt registry.json,
//!   unreadable catalog files) come from Rust/serde and differ from Node's
//!   `SyntaxError`/`ENOENT` wording, except `read_hook_source`'s ENOENT which
//!   is reproduced literally.
//! - The JS scan replays hooks through an 8-lane async pool; this port runs
//!   them sequentially. `violations` is sorted before returning, so only the
//!   (already nondeterministic in JS) `errors` ordering can differ.

mod protocol;
mod tools;

use std::io::Read;

use tama_core::catalog::repo_root;

fn main() {
    let root = repo_root();
    let stdin = std::io::stdin();
    let mut input = stdin.lock();
    let mut buffer: Vec<u8> = Vec::new();
    let mut chunk = [0u8; 8192];
    loop {
        match input.read(&mut chunk) {
            Ok(0) => break, // EOF: a trailing partial line is dropped, like the JS ReadBuffer
            Ok(n) => {
                buffer.extend_from_slice(&chunk[..n]);
                while let Some(pos) = buffer.iter().position(|byte| *byte == b'\n') {
                    let line: Vec<u8> = buffer.drain(..=pos).collect();
                    let mut text = String::from_utf8_lossy(&line[..line.len() - 1]).into_owned();
                    if text.ends_with('\r') {
                        text.pop();
                    }
                    protocol::process_line(&root, &text);
                }
            }
            Err(_) => break,
        }
    }
}
