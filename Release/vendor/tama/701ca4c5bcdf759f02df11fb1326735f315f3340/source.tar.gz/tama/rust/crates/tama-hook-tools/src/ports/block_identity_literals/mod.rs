//! Logic for `tama-block-identity-literals`, registry hook id
//! `block-identity-literals`.
//!
//! Blocks an identity literal nobody issued. An identity is an email address,
//! a UUID, or an identifier that flattens an address
//! (`jakub-wisent-ai` == `jakub@wisent.ai`). A literal passes when one of
//! these holds:
//!
//!   1. an artifact outside any conversation carries it — a token cache, a
//!      cloud profile, a machine registry, a config file;
//!   2. the user used it in more than one stored session;
//!   3. `identity_provenance.json` records a verbatim user quote declaring it,
//!      and that quote is found in a real `role=user` message.
//!
//! Why those three and not "the user said it once": on 2026-08-05 the agent
//! invented an address, wrote it into an enumerated credential contract in
//! three repositories, propagated it through its own subagent briefs, and
//! asked the user to confirm it three times. The user eventually echoed the
//! invented address back once. A rule keyed on "the user said it" reads that
//! echo as authority and blesses the invention. The real address sat 7763
//! times in the stored transcripts across many sessions and in stored mail;
//! another genuine account is bound to its object id by the local token cache.
//! The invention existed in one authoring session and in no artifact at all.
//! That is the difference this gate measures.
//!
//! Two discriminators were tried and rejected against real data, recorded so
//! they are not tried again: stripping strings before scanning, copied from
//! the numeric gate — an identity in code IS a string, so stripping removed
//! the only thing worth finding; and first-mention ordering (user before
//! assistant) — across months of history an assistant has eventually said
//! nearly every value, so it blocked both genuine accounts.

pub mod sources;

use std::collections::BTreeMap;
use std::sync::LazyLock;

use regex::Regex;
use serde_json::Value;
use tama_hooks::session_record::{deny_tool_use, read_payload};

use crate::ports::check_numeric_literals_payload::path_texts;
use crate::ports::pyvalue::first_truthy_py_str;
use crate::ports::transport_common as common;

const TOOL_KEYS: &[&str] = &["tool_name", "tool", "name"];
const WRITE_TOOLS: &[&str] = &["edit", "multiedit", "write", "notebook"];
const TOOL_INPUT_KEYS: &[&str] = &["tool_input", "input"];
const EMAIL_KIND: &str = "email address";
const UUID_KIND: &str = "UUID";
const FLAT_KIND: &str = "address encoded in an identifier";
const PAYLOAD_LABEL: &str = "<payload>";
const TRIM: &[char] = &['.', ',', ';', ':', '"', '\'', ' ', '\t', '\n'];

static EMAIL: LazyLock<Regex> = LazyLock::new(|| {
    common::compile("[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(?:\\.[A-Za-z0-9-]+)*\\.[A-Za-z]{2,}")
});

static UUID: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(
        "\\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\\b",
    )
});

/// The top-level domain set is closed deliberately. An open one turns every
/// hyphenated name into an address claim. Python's trailing `(?![A-Za-z0-9])`
/// is not needed: `\b` after the group already refuses a following letter or
/// digit, and the Rust engine has no lookaround.
static FLAT: LazyLock<Regex> = LazyLock::new(|| {
    common::compile("\\b([A-Za-z0-9]+)-([A-Za-z0-9]+)-(com|ai|io|net|org|dev|co|app|eu|pl)\\b")
});

static PLACEHOLDER: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(?i)(example|sample|placeholder|dummy|fixture|redacted|your-|<[a-z-]+>|xxx",
        "|test@|user@|foo|bar|localhost|nowhere)",
    ))
});

fn sanitize(value: &str) -> String {
    value.trim().trim_matches(TRIM).to_lowercase()
}

/// Every identity the text asserts, as (kind, value, as written).
fn identities(text: &str) -> Vec<(&'static str, String, String)> {
    let mut found: BTreeMap<String, (&'static str, String)> = BTreeMap::new();
    for found_match in EMAIL.find_iter(text) {
        found
            .entry(sanitize(found_match.as_str()))
            .or_insert((EMAIL_KIND, found_match.as_str().to_string()));
    }
    for found_match in UUID.find_iter(text) {
        found
            .entry(sanitize(found_match.as_str()))
            .or_insert((UUID_KIND, found_match.as_str().to_string()));
    }
    for caps in FLAT.captures_iter(text) {
        let whole = caps.get(0).map(|item| item.as_str()).unwrap_or_default();
        let address = format!(
            "{}@{}.{}",
            caps[true as usize].to_lowercase(),
            caps[true as usize + true as usize].to_lowercase(),
            caps[true as usize + true as usize + true as usize].to_lowercase(),
        );
        found
            .entry(address)
            .or_insert((FLAT_KIND, whole.to_string()));
    }
    found
        .into_iter()
        .map(|(value, (kind, shown))| (kind, value, shown))
        .collect()
}

/// Whether this identity has a source, and the reason it does not.
fn sourced(value: &str, doc: &Value) -> (bool, Option<&'static str>) {
    if sources::in_an_artifact(value) {
        return (true, None);
    }
    let sessions = sources::user_sessions_mentioning(value);
    if sessions > true as usize {
        return (true, None);
    }
    if sources::provenanced(value, doc, sanitize) {
        return (true, None);
    }
    match sessions == true as usize {
        true => (
            false,
            Some(
                "no artifact outside the chat carries it and exactly one stored session has the \
                 user saying it, which is what an invented value echoed back by the user looks \
                 like",
            ),
        ),
        false => (
            false,
            Some("no artifact carries it and no stored user message contains it"),
        ),
    }
}

/// Every identity this write asserts without a source, one complaint each.
pub fn check(payload: &Value) -> Vec<String> {
    let empty = Value::Object(Default::default());
    let input = TOOL_INPUT_KEYS
        .iter()
        .filter_map(|key| payload.get(*key))
        .find(|value| value.is_object())
        .unwrap_or(&empty);
    let (doc, doc_error) = sources::load_provenance();
    let mut problems: Vec<String> = doc_error.into_iter().collect();
    for (raw_path, text) in path_texts(input) {
        // Strings are scanned, unlike the numeric gate: in code an identity is
        // a string literal, so stripping them removes the whole subject.
        for (kind, value, shown) in identities(&text) {
            if PLACEHOLDER.is_match(&shown) {
                continue;
            }
            let (ok, reason) = sourced(&value, &doc);
            if ok {
                continue;
            }
            let label = match raw_path.is_empty() {
                true => PAYLOAD_LABEL,
                false => raw_path.as_str(),
            };
            problems.push(format!(
                "{label}: the {kind} {shown} has no provenance -- {}. Search the stored \
                 transcripts and the machine for the value that was actually issued. An identity \
                 you cannot source is an invention, and an invention is not a question to ask the \
                 user.",
                reason.unwrap_or_default()
            ));
        }
    }
    problems
}

pub fn run() {
    let payload = read_payload();
    let tool = first_truthy_py_str(&payload, TOOL_KEYS).to_lowercase();
    if !WRITE_TOOLS.iter().any(|name| tool.ends_with(name)) {
        return;
    }
    let problems = check(&payload);
    if problems.is_empty() {
        return;
    }
    let listed = problems
        .iter()
        .map(|problem| format!("  {problem}"))
        .collect::<Vec<_>>()
        .join("\n");
    deny_tool_use(&format!("block-identity-literals:\n{listed}"));
}

#[cfg(test)]
mod tests {
    use super::{identities, sanitize, EMAIL_KIND, FLAT_KIND, UUID_KIND};

    #[test]
    fn an_address_a_uuid_and_a_flattened_address_are_all_identities() {
        let found = identities(
            "mail somebody@wisent.ai, id 123e4567-e89b-42d3-a456-426614174000, tag ada-wisent-ai",
        );
        let kinds: Vec<&str> = found.iter().map(|(kind, _, _)| *kind).collect();
        assert!(kinds.contains(&EMAIL_KIND), "{found:?}");
        assert!(kinds.contains(&UUID_KIND), "{found:?}");
        assert!(kinds.contains(&FLAT_KIND), "{found:?}");
    }

    /// A flattened identifier is the same claim as the address it encodes, so
    /// it is reported under that address.
    #[test]
    fn a_flattened_identifier_reads_as_the_address_it_encodes() {
        let found = identities("see ada-wisent-ai please");
        let (kind, value, shown) = found.first().expect("one identity");
        assert_eq!(*kind, FLAT_KIND);
        assert_eq!(value, "ada@wisent.ai");
        assert_eq!(shown, "ada-wisent-ai");
    }

    /// The top-level domain set is closed on purpose: an open one turns every
    /// hyphenated name into an address claim.
    #[test]
    fn a_hyphenated_name_outside_the_domain_set_is_not_an_identity() {
        assert!(identities("the block-git-authorship hook").is_empty());
        assert!(identities("a pre-write-edit gate").is_empty());
    }

    #[test]
    fn punctuation_and_case_do_not_make_a_second_identity() {
        assert_eq!(sanitize("  Somebody@Wisent.AI,  "), "somebody@wisent.ai");
        assert_eq!(identities("A@b.io and a@B.IO,").len(), true as usize);
    }
}
