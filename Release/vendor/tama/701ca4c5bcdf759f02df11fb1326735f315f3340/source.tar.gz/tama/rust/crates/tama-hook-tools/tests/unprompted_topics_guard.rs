//! `tama-block-unprompted-topics`, driven as the real binary over real
//! session transcripts.
//!
//! What this defends: a paragraph built mostly from terms nobody in the
//! session wrote and no tool result produced — and more ungrounded than
//! anything the agent wrote earlier — is refused; a report made of the
//! operator's own words and the turn's results passes; a session with no
//! earlier prose has no baseline and cannot deny.
//!
//! And the defect that made this test exist: the guard rebuilt the session's
//! whole vocabulary at every assistant message, which is quadratic. On
//! 2026-09-20 this session's transcript reached seventeen megabytes, the
//! guard spent more than the ten seconds a hook is given, and the Stop it was
//! meant to judge went unjudged — a gate that gates nothing. The long-session
//! case here fails if that returns.

use std::fs;
use std::io::Write as _;
use std::path::PathBuf;
use std::process::{Command, Output, Stdio};
use std::time::{Instant, SystemTime, UNIX_EPOCH};

use serde_json::{json, Value};

/// A Stop hook answers on stdout: a denial is one `{"decision":"block"}`
/// document with the reason the engine shows, and a pass is silence. The
/// exit status is zero either way, which is why a case that reads the status
/// alone would call every refusal a pass.
const GUARD: &str = env!("CARGO_BIN_EXE_tama-block-unprompted-topics");
const BLOCK_DECISION: &str = "\"decision\":\"block\"";
const SESSION: &str = "unprompted-topics-guard-session";

/// What the operator asked for in the fixture session, and what the work
/// produced: everything a report may be built from.
const ASKED: &str = "napraw diagnostyke miejsca na dysku w stado i pokaz watermark";
const RESULT: &str =
    "stado space report charless-mac-mini: free 8.2 GB, watermark 8 GB, cleaners declared";

/// A grounded report: the operator's words and the result, nothing else.
const GROUNDED_REPORT: &str = "Stado space report na charless-mac-mini pokazuje free 8.2 GB przy \
    watermark 8 GB; cleaners declared.";

/// A paragraph about a subject nobody raised.
const UNPROMPTED: &str = "Zauwazylem tez, ze polityka licencjonowania kontenerow wymaga \
    negocjacji handlowych z dostawca telemetrii oraz przegladu ubezpieczenia floty przez \
    kancelarie patentowa.";

/// A session root of this test's own, under the crate's build directory.
fn scratch(label: &str) -> PathBuf {
    let nonce = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .expect("clock after epoch")
        .as_nanos();
    let path = PathBuf::from(env!("CARGO_TARGET_TMPDIR"))
        .join(format!("unprompted-topics-{label}-{nonce}"))
        .join("project");
    fs::create_dir_all(&path).expect("create the session root");
    path
}

fn record(role: &str, text: &str) -> String {
    json!({"message": {"role": role, "content": [{"type": "text", "text": text}]}}).to_string()
}

/// Write one session transcript and answer with the root it sits under.
fn session(label: &str, lines: &[String]) -> PathBuf {
    let project = scratch(label);
    let file = project.join(format!("2026-09-20T00-00-00-000Z_{SESSION}.jsonl"));
    fs::write(&file, format!("{}\n", lines.join("\n"))).expect("write the transcript");
    project
        .parent()
        .expect("the session root above the project")
        .to_path_buf()
}

fn run(root: &PathBuf, message: &str) -> (Output, u128) {
    let payload = json!({"session_id": SESSION, "last_assistant_message": message});
    let started = Instant::now();
    let mut child = Command::new(GUARD)
        .env("TAMA_OMP_SESSION_ROOT", root)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .unwrap_or_else(|error| panic!("spawn the guard: {error}"));
    child
        .stdin
        .as_mut()
        .expect("guard stdin")
        .write_all(payload.to_string().as_bytes())
        .expect("write payload");
    let output = child.wait_with_output().expect("guard output");
    (output, started.elapsed().as_millis())
}

/// What the engine reads: the decision document, or nothing.
fn decision(output: &Output) -> String {
    format!(
        "{}{}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    )
}

fn refused(output: &Output) -> bool {
    decision(output).contains(BLOCK_DECISION)
}

/// A session the agent has already written two grounded reports in, so the
/// guard has a baseline to judge against.
fn settled_session(label: &str) -> PathBuf {
    session(
        label,
        &[
            record("user", ASKED),
            record("toolResult", RESULT),
            record("assistant", GROUNDED_REPORT),
            record("assistant", GROUNDED_REPORT),
        ],
    )
}

#[test]
fn a_paragraph_nobody_raised_is_refused_and_its_terms_are_named() {
    let root = settled_session("refused");
    let (output, _) = run(&root, UNPROMPTED);
    let said = decision(&output);
    assert!(refused(&output), "the paragraph was not refused: {said}");
    assert!(said.contains("opens a subject nobody raised"), "{said}");
    assert!(
        said.contains("kancelarie"),
        "the ungrounded terms are not named: {said}"
    );
    assert!(said.contains("Do not request an exemption"), "{said}");
}

#[test]
fn a_report_made_of_the_session_passes() {
    let root = settled_session("grounded");
    let (output, _) = run(&root, GROUNDED_REPORT);
    assert!(
        !refused(&output),
        "a report built from the session was refused: {}",
        decision(&output)
    );
}

#[test]
fn a_session_with_no_earlier_prose_cannot_deny() {
    let root = session(
        "baseless",
        &[record("user", ASKED), record("toolResult", RESULT)],
    );
    let (output, _) = run(&root, UNPROMPTED);
    assert!(
        !refused(&output),
        "a guard with no baseline denied anyway: {}",
        decision(&output)
    );
}

/// The reading of a long session has to fit in the ten seconds a hook gets.
/// Before 2026-09-20 the vocabulary was rebuilt per assistant message, and a
/// session this shape took longer than the whole budget.
#[test]
fn a_long_session_is_judged_well_inside_a_hooks_budget() {
    let turns = 400;
    let mut lines = vec![record("user", ASKED)];
    for turn in 0..turns {
        lines.push(record("toolResult", &format!("{RESULT} pass {turn}")));
        lines.push(record(
            "assistant",
            &format!("{GROUNDED_REPORT} pass {turn}"),
        ));
    }
    let root = session("long", &lines);
    let bytes: usize = lines.iter().map(String::len).sum();
    let (output, elapsed) = run(&root, UNPROMPTED);
    assert!(
        refused(&output),
        "the long session was not judged: {}",
        decision(&output)
    );
    // A hook's budget is ten seconds; half of it over a session of this size
    // leaves room for a machine under load and none for quadratic work.
    assert!(
        elapsed < 5_000,
        "judging {bytes} bytes took {elapsed} ms, and a hook has ten seconds for everything"
    );
}

/// A transcript this guard cannot read is not a denial.
#[test]
fn an_unreadable_session_passes() {
    let root = scratch("absent");
    let (output, _) = run(&root, UNPROMPTED);
    assert!(!refused(&output), "{}", decision(&output));
}

/// `--explain` prints the reading instead of a decision, so a verdict can be
/// understood without writing a throwaway program that reads the transcript
/// a second way — which is what the write gate refused on 2026-09-20, and
/// rightly.
#[test]
fn the_reading_behind_a_verdict_is_printed_and_decides_nothing() {
    let root = settled_session("explain");
    let payload = json!({"session_id": SESSION, "last_assistant_message": UNPROMPTED});
    let mut child = Command::new(GUARD)
        .arg("--explain")
        .env("TAMA_OMP_SESSION_ROOT", &root)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .expect("spawn the guard");
    child
        .stdin
        .as_mut()
        .expect("guard stdin")
        .write_all(payload.to_string().as_bytes())
        .expect("write payload");
    let output = child.wait_with_output().expect("guard output");
    let said = decision(&output);
    assert!(
        !refused(&output),
        "an explanation decided something: {said}"
    );
    assert!(said.contains("records read: 4"), "{said}");
    assert!(said.contains("grounded terms:"), "{said}");
    assert!(
        said.contains("most ungrounded paragraph written earlier:"),
        "the baseline it measures against is not shown: {said}"
    );
    assert!(said.contains("would refuse"), "{said}");
    assert!(said.contains("ungrounded: "), "{said}");
}

/// The payload shape itself: no final message, nothing to judge.
#[test]
fn a_payload_without_a_final_message_passes() {
    let root = settled_session("no-message");
    let payload: Value = json!({"session_id": SESSION});
    let mut child = Command::new(GUARD)
        .env("TAMA_OMP_SESSION_ROOT", &root)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .expect("spawn the guard");
    child
        .stdin
        .as_mut()
        .expect("guard stdin")
        .write_all(payload.to_string().as_bytes())
        .expect("write payload");
    let output = child.wait_with_output().expect("guard output");
    assert!(!refused(&output), "{}", decision(&output));
}
