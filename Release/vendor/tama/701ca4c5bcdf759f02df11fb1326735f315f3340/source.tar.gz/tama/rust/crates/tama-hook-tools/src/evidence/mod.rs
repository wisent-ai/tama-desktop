//! Where a recorded run keeps its evidence; the checks read it from here.

pub mod root;

pub use root::{evidence_dir, evidence_root, EVIDENCE_PATH_SEGMENT, EVIDENCE_SEGMENT};
