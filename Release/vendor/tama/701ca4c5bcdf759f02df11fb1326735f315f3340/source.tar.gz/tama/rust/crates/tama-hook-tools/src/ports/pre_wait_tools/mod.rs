//! Logic for `tama-pre-wait-tools`, registry hook `pre-wait-tools`: the tools
//! that introduce a wait without being a shell command.
//!
//! `pre-bash` caps how long a command may block; `Monitor` and
//! `ScheduleWakeup` reach the same waiting through a tool argument, so they
//! are capped by the same number. A monitor with no deadline at all
//! (`persistent=true`) is refused outright.
//!
//! There is deliberately no environment escape. `TIMEOUT_BLOCK_AUTHORIZED`
//! came out of `pre-bash` because a variable an agent can set is not a
//! permission an operator granted.

use serde_json::Value;
use tama_hooks::session_record::{deny_tool_use, read_payload};

const TOOL_KEY: &str = "tool_name";
const INPUT_KEY: &str = "tool_input";
const TIMEOUT_KEY: &str = "timeout_ms";
const PERSISTENT_KEY: &str = "persistent";
const DELAY_KEY: &str = "delaySeconds";
const MONITOR: &str = "Monitor";
const WAKEUP: &str = "ScheduleWakeup";
/// The same cap `pre-bash` applies to a blocking command.
const CAP_MS_TEXT: &str = "60000";
const MS_PER_SECOND_TEXT: &str = "1000";
const TAIL: &str = ". Long-running waits without active diagnosis are forbidden.";

fn cap_ms() -> i64 {
    CAP_MS_TEXT.parse().unwrap_or_default()
}

fn ms_per_second() -> i64 {
    MS_PER_SECOND_TEXT.parse().unwrap_or_default()
}

/// `jq -r` prints a number without quotes and a string as itself, and the
/// shell then compared the text; either spelling is read here.
fn number(input: &Value, key: &str) -> Option<i64> {
    match input.get(key)? {
        Value::Number(value) => value.as_i64(),
        Value::String(text) => text.parse().ok(),
        _ => None,
    }
}

/// `${DELAY%.*}`: the shell dropped a fractional part before multiplying, so
/// half a second is zero milliseconds here too.
fn whole_seconds(input: &Value, key: &str) -> Option<(String, i64)> {
    let shown = match input.get(key)? {
        Value::Number(value) => value.to_string(),
        Value::String(text) => text.clone(),
        _ => return None,
    };
    let whole = shown.split('.').next().unwrap_or_default();
    whole.parse().ok().map(|seconds| (shown, seconds))
}

/// The refusal this wait earns, if any.
pub fn check(payload: &Value) -> Option<String> {
    let tool = payload.get(TOOL_KEY).and_then(Value::as_str)?;
    let empty = Value::Object(Default::default());
    let input = payload.get(INPUT_KEY).unwrap_or(&empty);
    let reason = match tool {
        MONITOR => match input.get(PERSISTENT_KEY) == Some(&Value::Bool(true)) {
            true => Some("Monitor persistent=true (no deadline) is forbidden".to_string()),
            false => number(input, TIMEOUT_KEY)
                .filter(|value| *value > cap_ms())
                .map(|value| format!("Monitor timeout_ms={value} exceeds {}ms cap", cap_ms())),
        },
        WAKEUP => whole_seconds(input, DELAY_KEY)
            .map(|(shown, seconds)| (shown, seconds * ms_per_second()))
            .filter(|(_, millis)| *millis > cap_ms())
            .map(|(shown, millis)| {
                format!(
                    "ScheduleWakeup delaySeconds={shown} ({millis}ms) exceeds {}ms cap",
                    cap_ms()
                )
            }),
        _ => None,
    }?;
    Some(format!("BLOCKED: {reason}{TAIL}"))
}

pub fn run() {
    if let Some(refusal) = check(&read_payload()) {
        deny_tool_use(&refusal);
    }
}

#[cfg(test)]
mod tests {
    use super::{cap_ms, check, ms_per_second};
    use serde_json::{json, Value};

    fn monitor(key: &str, value: Value) -> Value {
        json!({ "tool_name": "Monitor", "tool_input": { key: value } })
    }

    fn wakeup(value: Value) -> Value {
        json!({ "tool_name": "ScheduleWakeup", "tool_input": { "delaySeconds": value } })
    }

    #[test]
    fn a_monitor_with_no_deadline_is_refused() {
        let refusal = check(&monitor("persistent", json!(true))).expect("no deadline at all");
        assert!(refusal.contains("persistent=true"), "{refusal}");
    }

    #[test]
    fn a_monitor_over_the_cap_is_refused_and_the_cap_is_named() {
        let over = cap_ms() + true as i64;
        let refusal = check(&monitor("timeout_ms", json!(over))).expect("over the cap");
        assert!(refusal.contains(&format!("timeout_ms={over}")), "{refusal}");
        assert!(
            refusal.contains(&format!("{}ms cap", cap_ms())),
            "{refusal}"
        );
    }

    #[test]
    fn the_cap_itself_passes() {
        assert_eq!(check(&monitor("timeout_ms", json!(cap_ms()))), None);
    }

    /// The wait may arrive as a JSON number or as the text `jq -r` printed.
    #[test]
    fn a_wakeup_is_read_in_either_spelling() {
        let seconds = cap_ms() / ms_per_second() + true as i64;
        for delay in [json!(seconds), json!(seconds.to_string())] {
            let refusal = check(&wakeup(delay)).expect("over the cap");
            let millis = seconds * ms_per_second();
            assert!(refusal.contains(&format!("{millis}ms")), "{refusal}");
        }
    }

    #[test]
    fn a_short_wakeup_and_an_unrelated_tool_pass() {
        assert_eq!(check(&wakeup(json!(cap_ms() / ms_per_second()))), None);
        assert_eq!(
            check(&json!({ "tool_name": "Bash", "tool_input": { "command": "sleep 600" } })),
            None
        );
    }

    /// `${DELAY%.*}` truncated, so a fraction of a second never reached the
    /// cap and a fractional value over it still does.
    #[test]
    fn a_fractional_delay_keeps_the_shell_arithmetic() {
        let at_cap = cap_ms() / ms_per_second();
        assert_eq!(check(&wakeup(json!(format!("{at_cap}.9")))), None);
        let over = at_cap + true as i64;
        let refusal = check(&wakeup(json!(format!("{over}.9")))).expect("whole seconds decide");
        assert!(
            refusal.contains(&format!("delaySeconds={over}.9")),
            "{refusal}"
        );
    }
}
