//! `tama-block-untreated-block-stop`, driven as the real binary with a Stop
//! payload on stdin, a transcript file it names by path, and a registry file
//! that owns the denying hook's id.
//!
//! On 2026-09-18 a `--help` on a protected writer was denied under the
//! relative path a `cwd`-scoped bash call recorded, three later calls touched
//! the same file by its absolute path, and the guard refused the turn three
//! times because no later path equalled the relative string — a stop gate
//! whose key was out of reach. The same file named two ways is one file.

use std::fs;
use std::io::Write;
use std::path::{Path, PathBuf};
use std::process::{Command, Output, Stdio};
use std::time::{SystemTime, UNIX_EPOCH};

use serde_json::{json, Value};

const GUARD: &str = env!("CARGO_BIN_EXE_tama-block-untreated-block-stop");
const SESSION: &str = "untreated-block-guard-session";
const DENYING_HOOK: &str = "block-hook-config-edits-without-consent";
const RELATIVE_TARGET: &str = "rust/target/release/tama-record-hook-metadata";
const DENIED_CALL: &str = "call-denied";
const LATER_CALL: &str = "call-later";
const BLOCK_DECISION: &str = "block";

fn scratch() -> PathBuf {
    let nonce = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .expect("clock after epoch")
        .as_nanos();
    let thread = format!("{:?}", std::thread::current().id()).replace(['(', ')'], "-");
    let home =
        PathBuf::from(env!("CARGO_TARGET_TMPDIR")).join(format!("tama-untreated-{thread}{nonce}"));
    let hooks = home.join(".shared-hooks");
    fs::create_dir_all(&hooks).expect("create the scratch hooks directory");
    fs::write(
        hooks.join("registry.json"),
        json!({ "hooks": [{ "id": DENYING_HOOK }] }).to_string(),
    )
    .expect("write the registry");
    home
}

fn user(text: &str) -> Value {
    json!({ "type": "message", "message": { "role": "user",
        "content": [{ "type": "text", "text": text }] } })
}

fn call(id: &str, name: &str, arguments: Value) -> Value {
    json!({ "type": "message", "message": { "role": "assistant", "content": [
        { "type": "toolCall", "id": id, "name": name, "arguments": arguments } ] } })
}

fn denied(id: &str, name: &str) -> Value {
    json!({ "type": "message", "message": { "role": "toolResult", "toolCallId": id,
        "toolName": name, "isError": true, "content": [{ "type": "text",
        "text": format!("{DENYING_HOOK}: BLOCKED: hook source/config changes are device-level protected.") }] } })
}

fn answered(id: &str, name: &str, text: &str) -> Value {
    json!({ "type": "message", "message": { "role": "toolResult", "toolCallId": id,
        "toolName": name, "isError": false, "content": [{ "type": "text", "text": text }] } })
}

fn drive(home: &Path, records: &[Value]) -> Output {
    let transcript = home.join(format!("{SESSION}.jsonl"));
    let lines: Vec<String> = records.iter().map(Value::to_string).collect();
    fs::write(&transcript, lines.join("\n")).expect("write the transcript");
    let payload = json!({ "agent_hook_event": "stop", "session_id": SESSION,
        "transcript_path": transcript, "last_assistant_message": "Raport." });
    let mut child = Command::new(GUARD)
        .env("HOME", home)
        .env("TAMA_OKO_CLI", home.join("no-oko-cli-here"))
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .unwrap_or_else(|error| panic!("spawn the guard: {error}"));
    child
        .stdin
        .as_mut()
        .expect("guard stdin")
        .write_all(payload.to_string().as_bytes())
        .expect("write payload");
    child.wait_with_output().expect("guard output")
}

fn decision(output: &Output) -> Option<String> {
    let stdout = String::from_utf8_lossy(&output.stdout);
    let value: Value = serde_json::from_str(stdout.trim()).ok()?;
    assert_eq!(value["decision"], BLOCK_DECISION, "{stdout}");
    Some(value["reason"].as_str().expect("a reason").to_owned())
}

fn denial_under_a_relative_path(home: &Path) -> Vec<Value> {
    vec![
        user("sprawdź, czy ten program nadpisuje wpis"),
        call(
            DENIED_CALL,
            "bash",
            json!({ "command": format!("{RELATIVE_TARGET} --help"),
                "cwd": home.join("Documents/CodingProjects/Wisent/tama") }),
        ),
        denied(DENIED_CALL, "bash"),
    ]
}

#[test]
fn a_denial_with_nothing_after_it_is_refused_naming_the_target() {
    let home = scratch();
    let output = drive(&home, &denial_under_a_relative_path(&home));
    let reason = decision(&output).expect("refused");
    assert!(reason.contains(DENYING_HOOK), "{reason}");
    assert!(reason.contains(RELATIVE_TARGET), "{reason}");
}

#[test]
fn the_same_file_read_later_by_its_absolute_path_treats_the_denial() {
    let home = scratch();
    let absolute = home
        .join("Documents/CodingProjects/Wisent/tama")
        .join(RELATIVE_TARGET);
    let mut records = denial_under_a_relative_path(&home);
    records.push(call(LATER_CALL, "read", json!({ "path": absolute })));
    records.push(answered(LATER_CALL, "read", "Cannot read binary file"));
    let output = drive(&home, &records);
    assert_eq!(
        decision(&output),
        None,
        "{}",
        String::from_utf8_lossy(&output.stdout)
    );
}

#[test]
fn a_later_call_on_another_file_does_not_treat_the_denial() {
    let home = scratch();
    let elsewhere = home.join("Documents/CodingProjects/Wisent/tama/README.md");
    let mut records = denial_under_a_relative_path(&home);
    records.push(call(LATER_CALL, "read", json!({ "path": elsewhere })));
    records.push(answered(LATER_CALL, "read", "# Tama"));
    let output = drive(&home, &records);
    assert!(
        decision(&output).is_some(),
        "{}",
        String::from_utf8_lossy(&output.stdout)
    );
}

/// The 2026-09-18 shape: an inline `jq` pipeline was denied, its only
/// slash-bearing token was `2>/dev/null`, and the goal was then reached by
/// writing the same report to a file and reading it. The device is not the
/// target; the file the later calls name is.
#[test]
fn a_denied_pipeline_whose_only_device_is_dev_null_is_treated_by_the_file_read_after_it() {
    let home = scratch();
    let report = home.join("Documents/CodingProjects/Wisent/tama/rust/target/pool.json");
    let records = vec![
        user("sprawdź stan subskrypcji"),
        call(
            DENIED_CALL,
            "bash",
            json!({ "command": "timeout 90 brama subscriptions list --json 2>/dev/null | jq -c '.providers[]'" }),
        ),
        json!({ "type": "message", "message": { "role": "toolResult", "toolCallId": DENIED_CALL,
            "toolName": "bash", "isError": true, "content": [{ "type": "text",
            "text": format!("{DENYING_HOOK}: BLOCKED: inline code execution is forbidden.") }] } }),
        call(
            LATER_CALL,
            "bash",
            json!({ "command": format!("timeout 90 brama subscriptions list --json > {}", report.display()) }),
        ),
        answered(LATER_CALL, "bash", ""),
        call("call-read", "read", json!({ "path": report })),
        answered("call-read", "read", "{}"),
    ];
    let output = drive(&home, &records);
    assert_eq!(
        decision(&output),
        None,
        "{}",
        String::from_utf8_lossy(&output.stdout)
    );
}
