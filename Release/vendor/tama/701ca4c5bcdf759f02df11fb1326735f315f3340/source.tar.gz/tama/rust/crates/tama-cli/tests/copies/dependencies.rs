use std::fs;

use serde_json::Value;

use crate::copies_fixture::{stderr, stdout, text, Fixture};

#[test]
fn package_manager_checkouts_are_found_and_dirty_content_is_preserved_until_forced() {
    let fixture = Fixture::new("dependency");
    let dependency = fixture.checkout().join(".build/checkouts/sdk");
    fs::create_dir_all(dependency.parent().unwrap()).unwrap();
    fs::rename(fixture.copy(), &dependency).unwrap();
    let path = text(dependency.clone());
    let listed = fixture.tama(&["copies", "list", "--root", &fixture.root(), "--json"]);
    assert!(listed.status.success(), "{}", stderr(&listed));
    let document: Value = serde_json::from_str(&stdout(&listed)).unwrap();
    let row = document["copies"]
        .as_array()
        .unwrap()
        .iter()
        .find(|row| row["path"] == path)
        .expect("the dependency checkout is part of the inventory");
    assert_eq!(row["owner"], text(fixture.checkout()));

    fixture.dirty(&dependency);
    let refused = fixture.tama(&[
        "copies",
        "remove",
        "--root",
        &fixture.root(),
        "--only",
        &path,
        "--apply",
        "--json",
    ]);
    assert!(!refused.status.success());
    let refusal: Value = serde_json::from_str(&stdout(&refused)).unwrap();
    assert_eq!(refusal["refused"][0]["reason"], "uncommitted-changes");
    assert_eq!(
        fs::read_to_string(dependency.join("file.txt")).unwrap(),
        "changed\n"
    );

    let removed = fixture.tama(&[
        "copies",
        "remove",
        "--root",
        &fixture.root(),
        "--only",
        &path,
        "--apply",
        "--force",
        "--json",
    ]);
    assert!(removed.status.success(), "{}", stderr(&removed));
    assert!(!dependency.exists());
    assert_eq!(
        fs::read_to_string(fixture.checkout().join("file.txt")).unwrap(),
        "one\n"
    );
    assert!(fixture.lone().is_dir());
}

#[test]
fn a_submodule_is_a_dependency_copy_and_detached_unpublished_history_is_protected() {
    let fixture = Fixture::new("submodule");
    let origin = text(fixture.base.join("other.git"));
    fixture.git(
        &fixture.checkout(),
        &[
            "-c",
            "protocol.file.allow=always",
            "submodule",
            "add",
            "--quiet",
            &origin,
            "vendor/dependency",
        ],
    );
    let dependency = fixture.checkout().join("vendor/dependency");
    assert!(dependency.join(".git").is_file());
    fixture.git(&dependency, &["checkout", "--quiet", "--detach"]);
    fixture.commit_locally(&dependency);
    let path = text(dependency.clone());
    let listed = fixture.tama(&["copies", "list", "--root", &fixture.root(), "--json"]);
    assert!(listed.status.success(), "{}", stderr(&listed));
    let document: Value = serde_json::from_str(&stdout(&listed)).unwrap();
    assert!(document["copies"]
        .as_array()
        .unwrap()
        .iter()
        .any(|row| row["path"] == path));
    assert!(document["linkedWorktrees"].as_array().unwrap().is_empty());

    let refused = fixture.tama(&[
        "copies",
        "remove",
        "--root",
        &fixture.root(),
        "--only",
        &path,
        "--apply",
        "--json",
    ]);
    assert!(!refused.status.success());
    let refusal: Value = serde_json::from_str(&stdout(&refused)).unwrap();
    assert_eq!(refusal["refused"][0]["reason"], "commits-not-on-remote");
    assert_eq!(
        fs::read_to_string(dependency.join("local.txt")).unwrap(),
        "local\n"
    );

    let removed = fixture.tama(&[
        "copies",
        "remove",
        "--root",
        &fixture.root(),
        "--only",
        &path,
        "--apply",
        "--force",
        "--json",
    ]);
    assert!(removed.status.success(), "{}", stderr(&removed));
    assert!(!dependency.exists());
    assert!(fixture.checkout().join(".git").is_dir());
    assert_eq!(
        fs::read_to_string(fixture.checkout().join("file.txt")).unwrap(),
        "one\n"
    );
}

#[test]
fn bare_dependency_clones_are_reported_and_removed_without_deleting_the_checkout() {
    let fixture = Fixture::new("bare");
    let cache = fixture.checkout().join(".build/repositories/sdk");
    fs::create_dir_all(cache.parent().unwrap()).unwrap();
    fixture.git(
        &fixture.checkout(),
        &[
            "clone",
            "--quiet",
            "--bare",
            &text(fixture.base.join("origin.git")),
            &text(cache.clone()),
        ],
    );
    let path = text(cache.clone());
    let listed = fixture.tama(&["copies", "list", "--root", &fixture.root(), "--json"]);
    assert!(listed.status.success(), "{}", stderr(&listed));
    let document: Value = serde_json::from_str(&stdout(&listed)).unwrap();
    let row = document["copies"]
        .as_array()
        .unwrap()
        .iter()
        .find(|row| row["path"] == path)
        .expect("the bare dependency clone is part of the inventory");
    assert_eq!(row["owner"], text(fixture.checkout()));
    assert_eq!(row["dirty"], false);

    let removed = fixture.tama(&[
        "copies",
        "remove",
        "--root",
        &fixture.root(),
        "--only",
        &path,
        "--apply",
        "--force",
        "--json",
    ]);
    assert!(removed.status.success(), "{}", stderr(&removed));
    assert!(!cache.exists());
    assert!(fixture.checkout().join(".git").is_dir());
    assert!(fixture.copy().is_dir());
    assert_eq!(
        fs::read_to_string(fixture.checkout().join("file.txt")).unwrap(),
        "one\n"
    );
}

#[test]
fn nested_selected_copies_are_removed_in_one_pass() {
    let fixture = Fixture::new("nested-removal");
    let nested = fixture.copy().join("vendor/dependency");
    fs::create_dir_all(nested.parent().unwrap()).unwrap();
    fixture.git(
        &fixture.checkout(),
        &[
            "clone",
            "--quiet",
            &text(fixture.base.join("origin.git")),
            &text(nested.clone()),
        ],
    );
    let removed = fixture.tama(&[
        "copies",
        "remove",
        "--root",
        &fixture.root(),
        "--only",
        &text(fixture.copy()),
        "--only",
        &text(nested.clone()),
        "--apply",
        "--force",
        "--json",
    ]);
    assert!(removed.status.success(), "{}", stderr(&removed));
    let document: Value = serde_json::from_str(&stdout(&removed)).unwrap();
    let paths = document["removed"].as_array().unwrap();
    assert!(paths.contains(&Value::String(text(nested.clone()))));
    assert!(paths.contains(&Value::String(text(fixture.copy()))));
    assert!(!nested.exists());
    assert!(!fixture.copy().exists());
    assert_eq!(
        fs::read_to_string(fixture.checkout().join("file.txt")).unwrap(),
        "one\n"
    );
    assert!(fixture.lone().is_dir());
}

#[test]
fn shared_checkouts_are_removed_before_their_selected_object_store() {
    let fixture = Fixture::new("shared-removal");
    let cache = fixture.checkout().join(".build/repositories/sdk");
    let dependency = fixture.checkout().join(".build/checkouts/sdk");
    fs::create_dir_all(cache.parent().unwrap()).unwrap();
    fs::create_dir_all(dependency.parent().unwrap()).unwrap();
    fixture.git(
        &fixture.checkout(),
        &[
            "clone",
            "--quiet",
            "--bare",
            &text(fixture.base.join("origin.git")),
            &text(cache.clone()),
        ],
    );
    fixture.git(
        &fixture.checkout(),
        &[
            "clone",
            "--quiet",
            "--shared",
            &text(cache.clone()),
            &text(dependency.clone()),
        ],
    );
    assert!(dependency.join(".git/objects/info/alternates").is_file());
    let removed = fixture.tama(&[
        "copies",
        "remove",
        "--root",
        &fixture.root(),
        "--only",
        &text(cache.clone()),
        "--only",
        &text(dependency.clone()),
        "--apply",
        "--json",
    ]);
    assert!(removed.status.success(), "{}", stderr(&removed));
    assert!(
        !dependency.exists(),
        "the checkout must not be left with a deleted object store"
    );
    assert!(!cache.exists());
    assert_eq!(
        fs::read(fixture.checkout().join("file.txt")).unwrap(),
        b"one\n"
    );
    fixture.git(&fixture.checkout(), &["fsck", "--full"]);
}
