//! What this gate must keep answering: which numbers it catches, which ones
//! it lets through, and what makes a written reason count.

use super::{bash_violations, file_violations_with};
use serde_json::json;

const ABSENT: &str = "/nonexistent/file_justifications.json";
const SOURCE: &str = "/repo/src/worker.py";

fn fixture(name: &str, body: serde_json::Value) -> std::path::PathBuf {
    let dir = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("../../target/tmp")
        .join(format!("tama-constants-{name}"));
    let _ = std::fs::remove_dir_all(&dir);
    std::fs::create_dir_all(&dir).expect("a folder for the fixture");
    let path = dir.join("file_justifications.json");
    std::fs::write(&path, body.to_string()).expect("a fixture registry");
    path
}

#[test]
fn a_tuning_constant_is_reported_with_its_line_and_shape() {
    let found = file_violations_with(ABSENT, SOURCE, "\nMAX_WORKERS = 12\n");
    assert_eq!(found.len(), true as usize, "{found:?}");
    assert!(found[0].starts_with("line 2: UPPER_SNAKE"), "{found:?}");
}

#[test]
fn every_shape_the_gate_knows_is_caught() {
    for line in [
        "TIMEOUT_MS = 500",
        "port = os.environ.get(\"PORT\", \"8081\")",
        "def retry(count=7):",
        "Environment=WORKER_GB=16",
        "export CACHE_MB=512",
        "  \"batch\": 64",
    ] {
        assert!(
            !file_violations_with(ABSENT, SOURCE, line).is_empty(),
            "{line}"
        );
    }
}

/// `return 0` and `return 1` are statuses; anything else is an estimate.
#[test]
fn a_status_return_passes_and_an_estimate_does_not() {
    assert!(file_violations_with(ABSENT, SOURCE, "    return 0").is_empty());
    assert!(file_violations_with(ABSENT, SOURCE, "    return 1").is_empty());
    let found = file_violations_with(ABSENT, SOURCE, "    return 24");
    assert!(
        found
            .iter()
            .any(|item| item.contains("bare numeric return")),
        "{found:?}"
    );
}

/// A version, a year, an octal or a hex literal is not a tuning constant.
#[test]
fn obvious_non_constants_pass() {
    for line in [
        "version = \"3\"",
        "STARTED_IN = 2026",
        "MODE = 0o755",
        "MASK = 0xFF",
    ] {
        assert!(
            file_violations_with(ABSENT, SOURCE, line).is_empty(),
            "{line}"
        );
    }
}

/// A constants module is where these numbers belong.
#[test]
fn a_constants_file_is_exempt() {
    assert!(file_violations_with(ABSENT, "/repo/src/constants.py", "MAX = 12").is_empty());
    assert!(file_violations_with(ABSENT, "/repo/pyproject.toml", "line-length = 100").is_empty());
}

/// A reason counts when it names the kind of number it explains; otherwise
/// every file with any entry would be exempt.
#[test]
fn a_reason_that_names_the_kind_of_number_exempts_the_file() {
    let naming = fixture(
        "naming",
        json!({ SOURCE: { "justification": "These tuning constants come from the measured \
throughput of the worker pool on this machine and are recorded here so a later reader can \
reproduce the measurement instead of guessing at the numbers again." } }),
    );
    assert!(file_violations_with(&naming.to_string_lossy(), SOURCE, "MAX_WORKERS = 12").is_empty());
    let _ = std::fs::remove_dir_all(naming.parent().expect("a folder"));

    let vague = fixture(
        "vague",
        json!({ SOURCE: { "justification": "The operator asked for this file and it is needed \
by the worker pipeline for reasons explained at length in the commit message itself." } }),
    );
    assert!(!file_violations_with(&vague.to_string_lossy(), SOURCE, "MAX_WORKERS = 12").is_empty());
    let _ = std::fs::remove_dir_all(vague.parent().expect("a folder"));
}

/// The registry is keyed by absolute paths — `tama justify record` refuses to
/// write any other key — while a write tool may name the same file as the
/// person typed it. A reason recorded for the absolute path counts for the
/// `~/…` write of that file, or the writer is told to record what is already
/// recorded.
#[test]
fn a_reason_recorded_absolutely_counts_for_a_home_relative_write() {
    let home = std::env::var("HOME").expect("a home directory");
    let absolute = format!("{home}/repo/src/worker.py");
    let registry = fixture(
        "home-relative",
        json!({ absolute.clone(): { "justification": "These tuning constants are the pool \
sizes measured on this machine, written down here so a later reader reproduces the \
measurement instead of guessing at the numbers again." } }),
    );
    assert!(
        file_violations_with(
            &registry.to_string_lossy(),
            "~/repo/src/worker.py",
            "MAX_WORKERS = 12"
        )
        .is_empty(),
        "a reason recorded for {absolute} must count for the same file written as ~/…"
    );
    let _ = std::fs::remove_dir_all(registry.parent().expect("a folder"));
}

/// A remote write to an installed package is how a constant reaches a host
/// without passing any local gate.
#[test]
fn a_remote_write_needs_its_marker() {
    let command = "ssh host \"cp local.py /usr/lib/python3/site-packages/worker.py\"";
    assert!(!bash_violations(command).is_empty());
    let marked = format!("{command} # justify: rolling out the measured pool size");
    assert!(bash_violations(&marked).is_empty());
}

#[test]
fn a_remote_env_constant_needs_its_marker() {
    assert!(!bash_violations("ssh host 'export WORKER_GB=16'").is_empty());
}

#[test]
fn an_ordinary_command_passes() {
    assert!(bash_violations("ssh host 'systemctl status worker'").is_empty());
    assert!(bash_violations("git status --short").is_empty());
}
