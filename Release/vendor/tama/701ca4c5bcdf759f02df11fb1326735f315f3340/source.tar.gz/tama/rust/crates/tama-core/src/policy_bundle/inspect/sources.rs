//! Mapping a hook's declared source path back onto a path inside the
//! bundle, including the external-source manifest that redirects it.
//!
//! Split out of `policy_bundle.rs`, which had grown past the
//! three-hundred-line limit.

use serde::Deserialize;
use std::path::Path;

use super::super::{POLICY_ROOTS, RUNTIME_POLICY_ROOTS};

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub(in crate::policy_bundle) struct ExternalSourceManifest {
    pub schema: String,
    pub mappings: Vec<ExternalSourceMapping>,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub(in crate::policy_bundle) struct ExternalSourceMapping {
    pub source_prefix: String,
    pub release_path: String,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub(in crate::policy_bundle) struct HookReleaseManifest {
    pub schema: String,
    pub release_id: String,
}

pub(in crate::policy_bundle) fn policy_source_relative(
    value: &str,
    source: &Path,
    external_mappings: &[ExternalSourceMapping],
) -> Option<String> {
    let normalized = value.replace('\\', "/");
    let source_prefix = format!("{}/", source.to_string_lossy().replace('\\', "/"));
    if let Some(index) = normalized.find(&source_prefix) {
        return Some(
            normalized[index + source_prefix.len()..]
                .split(|character: char| character.is_whitespace() || character == '"')
                .next()
                .unwrap_or_default()
                .to_string(),
        );
    }
    for mapping in external_mappings {
        let prefix = mapping.source_prefix.replace('\\', "/");
        if let Some(index) = normalized.find(&prefix) {
            let suffix = normalized[index + prefix.len()..].trim_start_matches('/');
            let suffix = suffix
                .split(|character: char| character.is_whitespace() || character == '"')
                .next()
                .unwrap_or_default();
            return Some(if suffix.is_empty() {
                mapping.release_path.trim_end_matches('/').to_string()
            } else {
                format!("{}/{}", mapping.release_path.trim_end_matches('/'), suffix)
            });
        }
    }
    for (runtime_root, bundle_root) in RUNTIME_POLICY_ROOTS {
        let direct = format!("{runtime_root}/");
        let marker = format!("/{runtime_root}/");
        let suffix = if normalized.starts_with(&direct) {
            Some(&normalized[direct.len()..])
        } else {
            normalized
                .rfind(&marker)
                .map(|index| &normalized[index + marker.len()..])
        };
        if let Some(suffix) = suffix {
            let suffix = suffix
                .split(|character: char| character.is_whitespace() || character == '"')
                .next()
                .unwrap_or_default();
            return Some(format!("{bundle_root}/{suffix}"));
        }
    }
    for root in POLICY_ROOTS {
        let direct = format!("{root}/");
        if normalized.starts_with(&direct) {
            return Some(
                normalized
                    .split(|character: char| character.is_whitespace() || character == '"')
                    .next()
                    .unwrap_or_default()
                    .to_string(),
            );
        }
        let marker = format!("/{root}/");
        if let Some(index) = normalized.rfind(&marker) {
            let relative = &normalized[index + 1..];
            return Some(
                relative
                    .split(|character: char| character.is_whitespace() || character == '"')
                    .next()
                    .unwrap_or_default()
                    .to_string(),
            );
        }
    }
    None
}
