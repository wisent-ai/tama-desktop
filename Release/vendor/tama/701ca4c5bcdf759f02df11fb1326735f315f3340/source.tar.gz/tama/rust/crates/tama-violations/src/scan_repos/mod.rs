//! Rust port of `src/violations/scan-repos.mjs`.
//! Multi-target orchestration for the violation scan: resolves
//! --repo / --tree / --owner targets via repo-discovery, scans each
//! repository with the real hook replay, and prints per-repo detail plus a
//! total summary.

use serde::Serialize;
use std::path::Path;

mod hook_path;
mod output;

pub use hook_path::{default_hook_path, hook_candidates, hook_missing_message};
pub use output::{
    failures, print_aggregate, print_scan_report, print_scan_usage, print_summary, problem_label,
};

use crate::find_violations::{scan_repo, scan_repo_sizes, ScanReport};
use crate::repo_discovery::{resolve_targets, DiscoveryArgs, Problem};
use crate::{homedir, EXIT_USAGE};

#[derive(Debug, Clone)]
pub struct ScanArgs {
    pub repos: Vec<String>,
    pub trees: Vec<String>,
    pub owners: Vec<String>,
    pub me: bool,
    pub hook_path: String,
    /// Whether `--hook` named that path. A caller's own path is never
    /// second-guessed; a default one is explained when it is not there.
    pub hook_explicit: bool,
    pub clone_dir: String,
    pub json: bool,
    /// Skip the hook replay and apply only the two size rules in-process.
    /// Same enumeration and same sentences, fast enough for a whole machine.
    pub size_only: bool,
    /// Print one row per repository instead of every hit in every repository.
    pub summary: bool,
}

/// Port of `parseScanArgs`. The default hook path is resolved from the real
/// tama root and then from the installed hook tree, not from a CLI --root
/// value; the default clone dir lives in the user cache so org checkouts
/// never re-enter --tree scans.
pub fn parse_scan_args(argv: &[String], root: &Path) -> Option<ScanArgs> {
    let mut repos = Vec::new();
    let mut trees = Vec::new();
    let mut owners = Vec::new();
    let mut me = false;
    let mut hook_path = default_hook_path(root).to_string_lossy().into_owned();
    let mut hook_explicit = false;
    let mut clone_dir = homedir()
        .join(".cache")
        .join("tama")
        .join("violation-clones")
        .to_string_lossy()
        .into_owned();
    let mut json = false;
    let mut size_only = false;
    let mut summary = false;
    let mut i = 0;
    while i < argv.len() {
        let arg = &argv[i];
        if arg == "--json" {
            json = true;
            i += 1;
            continue;
        }
        if arg == "--size-only" {
            size_only = true;
            i += 1;
            continue;
        }
        if arg == "--summary" {
            summary = true;
            i += 1;
            continue;
        }
        if arg == "--me" {
            me = true;
            i += 1;
            continue;
        }
        if arg == "--repo"
            || arg == "--tree"
            || arg == "--owner"
            || arg == "--clone-dir"
            || arg == "--hook"
        {
            let value = argv.get(i + 1)?;
            // JS `if (!value) return null` rejects empty-string values too.
            if value.is_empty() {
                return None;
            }
            if arg == "--repo" {
                repos.push(value.clone());
            } else if arg == "--tree" {
                trees.push(value.clone());
            } else if arg == "--owner" {
                owners.push(value.clone());
            } else if arg == "--clone-dir" {
                clone_dir = value.clone();
            } else {
                hook_path = value.clone();
                hook_explicit = true;
            }
            i += 2;
            continue;
        }
        if !arg.starts_with('-') && repos.is_empty() && trees.is_empty() && owners.is_empty() {
            repos.push(arg.clone());
            i += 1;
            continue;
        }
        return None;
    }
    if repos.is_empty() && trees.is_empty() && owners.is_empty() && !me {
        return None;
    }
    Some(ScanArgs {
        repos,
        trees,
        owners,
        me,
        hook_path,
        hook_explicit,
        clone_dir,
        json,
        size_only,
        summary,
    })
}

#[derive(Serialize)]
pub struct ScanJsonOutput<'a> {
    pub repos: &'a [ScanReport],
    pub problems: &'a [Problem],
    pub totals: Totals,
}

#[derive(Serialize)]
pub struct Totals {
    pub repositories: usize,
    pub violations: usize,
    pub problems: usize,
}

/// The document `--json` prints, also served by the backend.
pub fn scan_json_document<'a>(
    reports: &'a [ScanReport],
    problems: &'a [Problem],
) -> ScanJsonOutput<'a> {
    let total = reports.iter().map(|report| report.violations.len()).sum();
    ScanJsonOutput {
        repos: reports,
        problems,
        totals: Totals {
            repositories: reports.len(),
            violations: total,
            problems: problems.len(),
        },
    }
}

/// The scan half of main(): resolves the targets and scans each repository,
/// reporting progress through `log` (main prints to stderr; the serve
/// backend streams it). Returns the per-repo reports and the discovery
/// problems.
pub fn run_scan(args: &ScanArgs, mut log: impl FnMut(&str)) -> (Vec<ScanReport>, Vec<Problem>) {
    let resolved = resolve_targets(&DiscoveryArgs {
        repos: &args.repos,
        trees: &args.trees,
        owners: &args.owners,
        me: args.me,
        clone_dir: Path::new(&args.clone_dir),
    });
    if resolved.targets.is_empty() {
        return (Vec::new(), resolved.problems);
    }
    log(&format!(
        "scanning {} repositor{}...",
        resolved.targets.len(),
        if resolved.targets.len() == 1 {
            "y"
        } else {
            "ies"
        }
    ));
    let mut reports = Vec::new();
    for target in &resolved.targets {
        log(&format!(
            "[{}/{}] {}",
            reports.len() + 1,
            resolved.targets.len(),
            target.path
        ));
        let mut report = if args.size_only {
            scan_repo_sizes(Path::new(&target.path))
        } else {
            scan_repo(Path::new(&target.path), Path::new(&args.hook_path))
        };
        report.via = Some(target.via.clone());
        reports.push(report);
    }
    (reports, resolved.problems)
}

pub fn main(args: &[String], root: &Path) -> i32 {
    let args = match parse_scan_args(args, root) {
        Some(args) => args,
        None => {
            print_scan_usage();
            return EXIT_USAGE;
        }
    };
    // `--size-only` answers the two size rules in process and never runs a
    // hook, so a missing hook is no reason to refuse that scan. Demanding
    // one is what stopped the fast pass everywhere the compiled-in checkout
    // path is gone.
    if args.size_only {
        if args.hook_explicit {
            eprintln!(
                "note: --size-only applies the size rules in process; {} is not replayed",
                args.hook_path
            );
        }
    } else if !Path::new(&args.hook_path).exists() {
        eprintln!(
            "{}",
            hook_missing_message(&args.hook_path, root, args.hook_explicit)
        );
        return EXIT_USAGE;
    }
    for repo in &args.repos {
        if !Path::new(repo).exists() {
            eprintln!("repo not found: {}", repo);
            return EXIT_USAGE;
        }
    }
    for tree in &args.trees {
        if !Path::new(tree).exists() {
            eprintln!("tree not found: {}", tree);
            return EXIT_USAGE;
        }
    }
    let (reports, problems) = run_scan(&args, |line| eprintln!("{line}"));
    if reports.is_empty() {
        for problem in &problems {
            eprintln!("PROBLEM {}: {}", problem_label(problem), problem.error);
        }
        eprintln!("no repositories found");
        return if output::failures(&problems) == 0 {
            0
        } else {
            1
        };
    }
    let mut total = 0usize;
    for report in &reports {
        total += report.violations.len();
    }
    if args.json {
        let output = scan_json_document(&reports, &problems);
        crate::write_json_line(&serde_json::to_string_pretty(&output).unwrap_or_default());
    } else if args.summary {
        print_summary(&reports, &problems);
    } else {
        print_aggregate(&reports, &problems);
    }
    if total > 0 || output::failures(&problems) > 0 {
        1
    } else {
        0
    }
}
