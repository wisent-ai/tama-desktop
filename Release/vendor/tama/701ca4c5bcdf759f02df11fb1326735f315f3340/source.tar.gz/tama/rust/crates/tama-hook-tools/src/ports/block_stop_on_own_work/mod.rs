//! Logic for `tama-block-stop-on-own-work`, registry hook id
//! `block-stop-on-own-work`.
//!
//! A Stop gate. It refuses a turn that ends on a report instead of on the
//! work the report itself describes. Four shapes, one cause:
//!
//! 1. The turn cites a capacity, budget or clock nobody set — "given
//!    remaining session capacity", "brak czasu w tej sesji" — as the reason
//!    the identified fix is not built.
//! 2. Under "Blokery" the report names a repository of this workshop, checked
//!    out under `~/Documents/CodingProjects/Wisent`, as the place the fix has
//!    to be made — and "Następne kroki" says none. A blocker whose content is
//!    a change the agent can make is the task.
//! 3. The ending is the report a stop guard already refused, said again with
//!    a sentence moved: the report is the body of the loop, not progress.
//! 4. Under "Następne kroki" the report hands the operator a decision or a
//!    go-ahead about the work ("Decyzja, czy budować te trzy zmiany"), or
//!    announces the agent's own next move ("Zbuduję…"). Both are the work,
//!    not a step for the operator. The first is the ending of 2026-09-18 the
//!    operator called "niedopuszczalne", asking for something that forces
//!    the agent to work instead.
//!
//! Why: on 2026-09-18 a session found the actual defect — publisher grants
//! must be issued on the owner's vault by Stado's release catalog — had the
//! file open (`stado-rs/…/vault/grants.rs`), and then wrote "Given remaining
//! session capacity, I don't think I can build that full fix now", put "to
//! zmiana w wisent-compute/stado-rs" under Blokery, wrote "Następne kroki:
//! Żadnych", was refused by a stop guard, ran one grep, and issued the same
//! report again. Zero of the ~50 open tasks moved. The operator's words:
//! "z jakiegos powodu zamiast wykonywac prace agent kreci sie w kolko albo
//! robi inne zadania" and "napraw nasz system zeby to sie nigdy wiecej nie
//! powtorzylo".
//!
//! The honest-no branch (`~/agents/policy.md`): a report whose Następne kroki
//! names what only the operator can supply passes shapes 2 and 3, a limit
//! the operator set in their own last message passes shape 1, and a step
//! that names a cost passes shape 4 — money is the one boundary that holds.
//! An operator stop order stands every shape down.

mod repeat;
mod sections;
mod titles;
mod transcript;

use std::path::Path;
use std::sync::LazyLock;

use regex::Regex;
use serde_json::Value;
use tama_hooks::session_record::{deny, read_payload, session_id_of};

use crate::assignment::stop_order;
use crate::ports::transport_common as common;
use sections::{NotAStep, Report};
use transcript::Transcript;

const HOOK: &str = "block-stop-on-own-work";

/// A limit on the session itself, and the quoting that means a phrase is
/// being reported rather than offered as a reason. Both are declared in
/// `vocabulary/invented-limits.json` beside this file, with the distinction
/// they encode written down next to them.
fn declared(key: &str) -> Regex {
    let document: serde_json::Value =
        serde_json::from_str(include_str!("vocabulary/invented-limits.json"))
            .expect("invented-limits.json in the vocabulary folder is valid JSON");
    common::compile(
        document[key]
            .as_str()
            .unwrap_or_else(|| panic!("invented-limits.json declares no {key}")),
    )
}

static INVENTED_LIMIT: LazyLock<Regex> = LazyLock::new(|| declared("invented_limit"));

fn stands_down(payload: &Value) -> bool {
    let session = session_id_of(payload);
    match stop_order::standing(payload, &session) {
        Some(order) => {
            eprintln!("{}", stop_order::notice(HOOK, &order));
            true
        }
        None => false,
    }
}

static QUOTED: LazyLock<Regex> = LazyLock::new(|| declared("quoted"));

fn invented_limit(transcript: &Transcript) -> Option<String> {
    let spoken = QUOTED.replace_all(&transcript.ending_turn, " ");
    let found = INVENTED_LIMIT.find(&spoken)?;
    if INVENTED_LIMIT.is_match(&transcript.last_operator_message) {
        return None;
    }
    Some(format!(
        "{HOOK}: BLOCKED: this turn gives \"{}\" as a reason to stop. Nobody set that limit: the \
         instruction has no capacity, no budget and no clock, and a limit you invent is a decision \
         not to work dressed as honesty. The fix you identified is the task; build it. (2026-09-18: \
         with the defect found and the file open, the turn ended on \"remaining session capacity\" \
         and a report.)",
        found.as_str().trim()
    ))
}

fn own_work_as_blocker(report: &Report, home: &Path) -> Option<String> {
    let blockers = report.blockers.as_deref()?;
    if !report.next_steps_are_none() {
        return None;
    }
    let repositories = sections::checked_out_repositories(home);
    let named = sections::repositories_named(blockers, &repositories);
    let first = named.first()?;
    Some(format!(
        "{HOOK}: BLOCKED: under Blokery this report names {} — checked out at {} — as the place \
         the fix has to be made, and Następne kroki says none. A blocker whose content is a change \
         you can make is the task, not a blocker (~/agents/finishing.md: ownership is not a \
         blocker; requires-the-operator is a claim you prove with a captured error). Make the change \
         in {first}, or put under Następne kroki the one thing only the operator can supply, with \
         the error that proves it.",
        named.join(", "),
        sections::checkout_root(home).join(first).display(),
    ))
}

fn repeated_ending(transcript: &Transcript, report: &Report) -> Option<String> {
    if report.next_steps.is_some() && !report.next_steps_are_none() {
        return None;
    }
    let (_, percent) = repeat::repeated(&transcript.final_message, &transcript.refused_endings)?;
    Some(format!(
        "{HOOK}: BLOCKED: this ending is the report a stop guard already refused, said again \
         ({percent}% of its phrasing is the same). A report re-issued after a refusal is the body \
         of a loop, not progress: the work it describes is still undone. Do that work, then write \
         what changed since the refusal."
    ))
}

fn next_step_that_is_own_work(report: &Report) -> Option<String> {
    Some(match report.next_step_that_is_the_agent_s()? {
        NotAStep::HandedBack(line) => format!(
            "{HOOK}: BLOCKED: under Następne kroki this report hands the operator a decision: \
             \"{line}\". That decision is yours: the work was assigned, and a go-ahead, a choice \
             between options you can check, or a confirmation is a permission request \
             (~/agents/finishing.md: never ask for permission; presenting options and stopping is \
             a permission request wearing a report). Do the work, then report it in the past tense. \
             Następne kroki may name only what the operator alone can supply — a cost to approve, \
             a value that exists in their head — with the captured error that proves it."
        ),
        NotAStep::Announced(line) => format!(
            "{HOOK}: BLOCKED: under Następne kroki this report announces your own next move: \
             \"{line}\". A step you can name precisely enough to write down is a step you can \
             take now (~/agents/finishing.md: never end a turn on an intention). Take it, then \
             report it in the past tense."
        ),
    })
}

/// The refusal for this payload, judged against the checkouts under `home`.
pub fn check(payload: &Value, home: &Path) -> Option<String> {
    let transcript = Transcript::from_payload(payload);
    if transcript.final_message.trim().is_empty() {
        return None;
    }
    let report = Report::parse(&transcript.final_message);
    invented_limit(&transcript)
        .or_else(|| own_work_as_blocker(&report, home))
        .or_else(|| next_step_that_is_own_work(&report))
        .or_else(|| repeated_ending(&transcript, &report))
}

pub fn run() {
    let payload = read_payload();
    if stands_down(&payload) {
        return;
    }
    if let Some(problem) = check(&payload, &common::home()) {
        deny(problem);
    }
}

#[cfg(test)]
mod tests {
    use super::check;
    use serde_json::json;
    use std::path::Path;

    /// No checkouts under this home, so only shapes 1 and 3 can fire.
    fn nowhere() -> &'static Path {
        Path::new("/nonexistent-home-for-block-stop-on-own-work")
    }

    #[test]
    fn a_limit_nobody_set_is_refused_even_when_only_thought() {
        let payload = json!({ "messages": [
            { "role": "user", "content": [{ "type": "text", "text": "napraw to" }] },
            { "role": "assistant", "content": [
                { "type": "thinking", "thinking": "Given remaining session capacity, I don't think I can build that full fix now." },
                { "type": "text", "text": "## Co zostało zrobione\nZnalazłem usterkę.\n## Blokery\nŻadnych.\n## Następne kroki\nŻadnych." } ] },
        ] });
        let refusal = check(&payload, nowhere()).expect("refused");
        assert!(refusal.contains("remaining session capacity"), "{refusal}");
    }

    #[test]
    fn a_limit_the_operator_set_passes() {
        let payload = json!({ "messages": [
            { "role": "user", "content": [{ "type": "text", "text": "masz budżet sesji na jedną turę, potem raport" }] },
            { "role": "assistant", "content": [
                { "type": "thinking", "thinking": "Brak czasu, więc raportuję." },
                { "type": "text", "text": "Zrobione w części, reszta wymaga Twojej decyzji o koszcie." } ] },
        ] });
        assert_eq!(check(&payload, nowhere()), None);
    }

    #[test]
    fn a_rate_limit_from_a_service_is_not_the_agent_s_limit() {
        let payload = json!({ "final_message":
            "## Blokery\nBrama HTTP 429 provider_rate_limited; limit 4 GB sterty w VS Code.\n## Następne kroki\nŻadnych." });
        assert_eq!(check(&payload, nowhere()), None);
    }

    /// The guard's own first live turn: a report describing the guard quoted
    /// its trigger phrase as an example and was refused for it.
    #[test]
    fn the_phrase_quoted_in_a_report_about_the_guard_passes() {
        let payload = json!({ "final_message":
            "Hook działa. Każda sesja, która chce skończyć na wymyślonym limicie („remaining session capacity”, \
             `brak czasu`), dostaje odmowę.\n## Blokery\nŻadnych.\n## Następne kroki\nŻadnych." });
        assert_eq!(check(&payload, nowhere()), None);
    }

    /// A sentence in a refused attempt does not refuse every attempt after it.
    #[test]
    fn a_limit_thought_before_the_refusal_does_not_refuse_the_next_attempt() {
        let payload = json!({ "messages": [
            { "role": "user", "content": [{ "type": "text", "text": "napraw to" }] },
            { "role": "assistant", "content": [
                { "type": "thinking", "thinking": "Given remaining session capacity I report." },
                { "type": "text", "text": "Raport." } ] },
            { "type": "custom_message", "customType": "session-stop-continuation", "content": "block-x: BLOCKED" },
            { "role": "assistant", "content": [
                { "type": "thinking", "thinking": "Buduję poprawkę." },
                { "type": "text", "text": "Zbudowane: test przeszedł, commit wypchnięty." } ] },
        ] });
        assert_eq!(check(&payload, nowhere()), None);
    }
}
