//! The steps of a release that are not building or installing: getting
//! published main into the ignored build tree, saying where the sealed
//! runtime on this machine came from, and moving the hook selection
//! afterwards.
//!
//! Split out of `release.rs` because a source file here stays at three
//! hundred lines or fewer, and the warm step the release gained needed the
//! room.

use std::path::{Path, PathBuf};
use std::process::Command;

use super::super::declare::run;
use super::EXPORT_DIR;

/// Where the sealed runtime this machine loads was built from.
///
/// The hook binaries a release installs are built from `origin/main`, but
/// the sealed runtime is staged by a script that compiles the checkout's
/// working tree, and this checkout is shared: on 2026-09-20 the live engine
/// carried `"dirty": true`, meaning the gates enforcing policy included code
/// nobody had committed. The release records that fact; nothing ever showed
/// it, so nobody could act on it.
pub(super) fn installed_provenance(home: &Path) -> Option<String> {
    let manifest: PathBuf = home
        .join("Library/Application Support/Tama/hooks-runtime/current")
        .join("native-hook-binaries.json");
    let text = std::fs::read_to_string(&manifest).ok()?;
    let value: serde_json::Value = serde_json::from_str(&text).ok()?;
    let identity = value.get("sourceIdentity")?;
    let revision = identity
        .get("revision")
        .and_then(serde_json::Value::as_str)?;
    let dirty = identity
        .get("dirty")
        .and_then(serde_json::Value::as_bool)
        .unwrap_or_default();
    Some(match dirty {
        true => format!(
            "installed runtime: built from {revision} with uncommitted changes in the checkout, \
             so the engine enforcing policy is not the code that was pushed",
        ),
        false => format!("installed runtime: built from {revision}, with nothing uncommitted"),
    })
}

/// Published main, exported into the ignored build tree: a shared checkout
/// carries other sessions' edits, and a live gate is code that was pushed.
pub(super) fn export_main(root: &Path, export: &Path) -> Result<(), String> {
    run(
        Path::new("/usr/bin/env"),
        &[
            "git".to_string(),
            "fetch".to_string(),
            "-q".to_string(),
            "origin".to_string(),
            "main".to_string(),
        ],
        root,
    )?;
    let _ = std::fs::remove_dir_all(export);
    std::fs::create_dir_all(export)
        .map_err(|error| format!("cannot create {}: {error}", export.display()))?;
    let archive = Command::new("/usr/bin/env")
        .args(["git", "archive", "origin/main"])
        .current_dir(root)
        .output()
        .map_err(|error| format!("cannot export origin/main: {error}"))?;
    if !archive.status.success() {
        return Err(format!(
            "cannot export origin/main: {}",
            String::from_utf8_lossy(&archive.stderr).trim()
        ));
    }
    let tar = root.join(EXPORT_DIR).with_extension("tar");
    std::fs::write(&tar, &archive.stdout)
        .map_err(|error| format!("cannot write {}: {error}", tar.display()))?;
    let extracted = run(
        Path::new("/usr/bin/env"),
        &[
            "tar".to_string(),
            "-x".to_string(),
            "-f".to_string(),
            tar.display().to_string(),
            "-C".to_string(),
            export.display().to_string(),
        ],
        root,
    );
    let _ = std::fs::remove_file(&tar);
    extracted.map(|_| ())
}

/// The machine's hook selection, through the command that owns it. `--enforce`
/// adds: a release that installed one new gate must not silently drop the
/// gates the operator already chose, which is what passing only the new ids to
/// `enforcement only` would do.
pub(super) fn enforce_selection(root: &Path, enforce: &[String]) -> i32 {
    if enforce.is_empty() {
        println!(
            "this machine's hook selection is unchanged; read it with `tama enforcement status` \
             and change it with `tama enforcement only <hook-id>…`"
        );
        return 0;
    }
    let mut argv = vec!["only".to_string()];
    let current = crate::enforcement::status::status(root)
        .map(|status| status.enabled)
        .unwrap_or_default();
    argv.extend(current);
    for id in enforce {
        if !argv.contains(id) {
            argv.push(id.clone());
        }
    }
    crate::enforcement::main(&argv, root)
}
