//! What a trajectory run left on disk, and how many times it has run.
//!
//! Recordings live under Weles's own `recordings/<label>/` beside the
//! repository or under the repository's own; work files under
//! `.work/<label>/`. The run counter lives in the operator's hook state.

use std::path::{Path, PathBuf};
use std::time::UNIX_EPOCH;

use serde_json::Value;

use crate::ports::python_stdlib::expanduser;

const STATE_PATH: &str = "~/.shared-hooks/state/trajectory_runs.json";
const RUNS_KEY: &str = "runs_since_inspection";
const RECORDING_SUFFIX: &str = ".webm";
const WORK_DIR: &str = ".work";
const NOTES_NAME: &str = "inspection.md";
/// `[:3]` recordings and `[:5]` work files in the report, ten lines at most.
const SHOWN_RECORDINGS_TEXT: &str = "3";
const SHOWN_WORKFILES_TEXT: &str = "5";
const SHOWN_TOTAL_TEXT: &str = "10";
/// `stat().st_size >= 200`: a human-authored note, not a touched file.
const NOTES_MIN_BYTES_TEXT: &str = "200";

fn shown(text: &str) -> usize {
    text.parse().unwrap_or_default()
}

pub(crate) fn notes_min_bytes() -> u64 {
    NOTES_MIN_BYTES_TEXT.parse().unwrap_or_default()
}

fn modified(path: &Path) -> u64 {
    std::fs::metadata(path)
        .and_then(|meta| meta.modified())
        .map(|time| {
            time.duration_since(UNIX_EPOCH)
                .map(|value| value.as_secs())
                .unwrap_or_default()
        })
        .unwrap_or_default()
}

fn newest_first(mut paths: Vec<PathBuf>) -> Vec<PathBuf> {
    paths.sort_by_key(|path| std::cmp::Reverse(modified(path)));
    paths
}

/// How many times this label has run since anybody looked at its output.
pub(crate) fn runs_since_inspection(label: &str) -> i64 {
    let Ok(text) = std::fs::read_to_string(expanduser(STATE_PATH)) else {
        return 0;
    };
    let Ok(doc) = serde_json::from_str::<Value>(&text) else {
        return 0;
    };
    let Some(map) = doc.as_object() else {
        return 0;
    };
    let suffix = format!("/{label}");
    map.iter()
        .filter(|(key, _)| key.ends_with(&suffix))
        .filter_map(|(_, value)| value.get(RUNS_KEY))
        .filter_map(Value::as_i64)
        .next()
        .unwrap_or_default()
}

/// The recording directories for a label, Weles's first.
pub(crate) fn recording_roots(repo: &Path, label: &str) -> Vec<PathBuf> {
    let beside = repo
        .parent()
        .map(|parent| parent.join("weles").join("recordings").join(label));
    let own = repo.join("recordings").join(label);
    beside.into_iter().chain(std::iter::once(own)).collect()
}

/// Recordings for this label, newest first.
pub(crate) fn recordings(repo: &Path, label: &str) -> Vec<PathBuf> {
    let mut found: Vec<PathBuf> = Vec::new();
    for root in recording_roots(repo, label).iter().filter(|p| p.is_dir()) {
        let Ok(entries) = std::fs::read_dir(root) else {
            continue;
        };
        found.extend(
            entries
                .flatten()
                .map(|entry| entry.path())
                .filter(|path| path.to_string_lossy().ends_with(RECORDING_SUFFIX)),
        );
    }
    newest_first(found)
}

pub(crate) fn notes(repo: &Path, label: &str) -> PathBuf {
    repo.join(WORK_DIR).join(label).join(NOTES_NAME)
}

fn walk(root: &Path, found: &mut Vec<PathBuf>) {
    let Ok(entries) = std::fs::read_dir(root) else {
        return;
    };
    for entry in entries.flatten() {
        let path = entry.path();
        match path.is_dir() {
            true => walk(&path, found),
            false => found.push(path),
        }
    }
}

/// The artifacts a reader could open for this label, as report lines.
pub(crate) fn candidates(repo: &Path, label: &str) -> Vec<String> {
    let mut lines: Vec<String> = recordings(repo, label)
        .into_iter()
        .take(shown(SHOWN_RECORDINGS_TEXT))
        .map(|path| format!("  recording  {}", path.display()))
        .collect();
    let work = repo.join(WORK_DIR).join(label);
    if work.is_dir() {
        let mut files: Vec<PathBuf> = Vec::new();
        walk(&work, &mut files);
        lines.extend(
            newest_first(files)
                .into_iter()
                .take(shown(SHOWN_WORKFILES_TEXT))
                .map(|path| format!("  workfile   {}", path.display())),
        );
    }
    lines.truncate(shown(SHOWN_TOTAL_TEXT));
    lines
}

#[cfg(test)]
mod tests {
    use super::{notes, notes_min_bytes, recording_roots, runs_since_inspection};
    use std::path::Path;

    #[test]
    fn the_recording_roots_are_weles_first_then_the_repository() {
        let roots = recording_roots(Path::new("/repo/content"), "linkedin");
        assert_eq!(
            roots[0],
            Path::new("/repo/weles/recordings/linkedin").to_path_buf()
        );
        assert_eq!(
            roots[1],
            Path::new("/repo/content/recordings/linkedin").to_path_buf()
        );
    }

    #[test]
    fn the_notes_path_is_under_the_label_work_directory() {
        assert_eq!(
            notes(Path::new("/repo"), "linkedin"),
            Path::new("/repo/.work/linkedin/inspection.md").to_path_buf()
        );
        assert_eq!(notes_min_bytes(), 200);
    }

    /// A label nobody has run has no count, and a missing state file is not
    /// a count of one.
    #[test]
    fn an_unknown_label_has_no_runs() {
        assert_eq!(runs_since_inspection("no-such-label-anywhere"), 0);
    }
}
