//! Logic for `tama-pre-write-edit`, registry hook `pre-write-edit`: the
//! consolidated gate every write and edit passes.
//!
//! Five questions, in this order: may a write land on this path, does an
//! incident rule refuse it, does the content contain something forbidden, is
//! this a new test that nobody asked for, and does it introduce a number
//! nobody can source. The file-line limit, the folder-file limit and the
//! new-file justification used to be here too; each is its own hook now, so a
//! machine can carry one without the others.
//!
//! Two deliberate differences from the shell this replaces. The rules that
//! apply to every tree — the image API, the runtime blob — are checked before
//! the ones that skip vendored and generated paths, so a file gets the same
//! answer wherever it lives; in the shell they were last, which only changed
//! which of two refusals a doubly-offending file saw. And the incident rules
//! that used to be spliced into the script as shell blocks are data now, in
//! `auto_rules`, because a compiled gate cannot be edited by a drafter and a
//! rule that lives in its own runner has no record of why it exists.

mod content;
mod justification;
mod paths;
mod sentinels;

use serde_json::Value;
use tama_hooks::session_record::{deny_tool_use, read_payload};

use crate::ports::auto_rules;
use crate::ports::check_unsubstantiated_constants;
use crate::ports::write_payload::WritePayload;
use justification::test_refusal;

pub use justification::test_refusal_with;

/// The refusal this write earns, if any.
pub fn check(payload: &Value) -> Option<String> {
    let write = WritePayload::read(payload)?;
    if let Some(found) = paths::refusal(&write.file_path) {
        return Some(found.to_string());
    }
    if let Some(found) = auto_rules::write_refusal(&write.file_path, &write.content) {
        return Some(found);
    }
    if let Some(found) = content::refusal(&write.file_path, &write.content, write.is_system) {
        return Some(found);
    }
    if let Some(found) = test_refusal(payload, &write.file_path, write.is_system) {
        return Some(found);
    }
    if write.is_system || write.content.is_empty() {
        return None;
    }
    check_unsubstantiated_constants::file_refusal(&write.file_path, &write.content)
}

pub fn run() {
    if let Some(refusal) = check(&read_payload()) {
        deny_tool_use(&refusal);
    }
}

#[cfg(test)]
mod tests {
    use super::{check, test_refusal_with};
    use serde_json::json;

    const ABSENT: &str = "/nonexistent/test_justifications.json";
    const NEW_TEST: &str = "/repo/tests/worker/limits.test.ts";
    const FIFTY_WORDS: &str = "The operator asked for this test in so many words, and the quote \
is repeated here inside the reason so that the gate can check the one against the other: prosze \
dodaj test ktory sprawdza limit, which is what he typed, and the test covers exactly that limit \
and nothing else besides it today.";
    const QUOTE: &str = "prosze dodaj test ktory sprawdza limit";

    fn fixture(name: &str, body: serde_json::Value) -> std::path::PathBuf {
        let dir = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../target/tmp")
            .join(format!("tama-test-gate-{name}"));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).expect("a folder for the fixture");
        let path = dir.join("test_justifications.json");
        std::fs::write(&path, body.to_string()).expect("a fixture registry");
        path
    }

    fn accept(_quote: &str) -> bool {
        true
    }

    fn reject(_quote: &str) -> bool {
        false
    }

    #[test]
    fn a_path_rule_refuses_before_anything_else() {
        let payload = json!({
            "tool_name": "Write",
            "tool_input": { "file_path": "/tmp/scratch.py", "content": "print(1)" }
        });
        let found = check(&payload).expect("a temporary path");
        assert!(found.contains("tmp directory"), "{found}");
    }

    /// An incident rule, held as data, still refuses its shape.
    #[test]
    fn an_incident_rule_refuses_its_shape() {
        let payload = json!({
            "tool_name": "Write",
            "tool_input": { "file_path": "/repo/docs/hook-registry.md", "content": "# list" }
        });
        let found = check(&payload).expect("a registry as prose");
        assert!(found.contains("structured data"), "{found}");
    }

    #[test]
    fn a_number_nobody_can_source_is_refused() {
        let payload = json!({
            "tool_name": "Write",
            "tool_input": { "file_path": "/repo/src/pool.py", "content": "MAX_WORKERS = 12\n" }
        });
        let found = check(&payload).expect("an unsourced number");
        assert!(found.contains("unsubstantiated"), "{found}");
    }

    #[test]
    fn an_ordinary_write_passes() {
        let payload = json!({
            "tool_name": "Write",
            "tool_input": {
                "file_path": "/repo/src/greet.rs",
                "content": "pub fn greet(name: &str) -> String { format!(\"hi {name}\") }\n"
            }
        });
        assert_eq!(check(&payload), None);
    }

    /// The four things a new test needs, each refused on its own.
    #[test]
    fn a_new_test_needs_a_reason_a_quote_and_the_quote_inside_the_reason() {
        let none = fixture("none", json!({}));
        let missing = test_refusal_with(&none.to_string_lossy(), NEW_TEST, &accept)
            .expect("no reason at all");
        assert!(missing.contains("50+ word justification"), "{missing}");
        let _ = std::fs::remove_dir_all(none.parent().expect("a folder"));

        let no_quote = fixture(
            "no-quote",
            json!({ NEW_TEST: { "justification": FIFTY_WORDS } }),
        );
        let found =
            test_refusal_with(&no_quote.to_string_lossy(), NEW_TEST, &accept).expect("no quote");
        assert!(
            found.contains("user_request_quote copied verbatim"),
            "{found}"
        );
        let _ = std::fs::remove_dir_all(no_quote.parent().expect("a folder"));

        let elsewhere = fixture(
            "elsewhere",
            json!({ NEW_TEST: {
                "justification": "This reason is long enough to pass the word count but it never \
repeats what the operator said, which is the one thing about a reason that a gate can actually \
check for itself, so the write is refused here for that reason alone and for nothing else at \
all in this particular case, today or on any other day of the week.",
                "user_request_quote": QUOTE
            } }),
        );
        let found = test_refusal_with(&elsewhere.to_string_lossy(), NEW_TEST, &accept)
            .expect("the quote is not in the reason");
        assert!(found.contains("must contain user_request_quote"), "{found}");
        let _ = std::fs::remove_dir_all(elsewhere.parent().expect("a folder"));
    }

    /// A quote nobody typed is the whole point of the last check.
    #[test]
    fn an_invented_quote_is_refused_and_a_real_one_passes() {
        let path = fixture(
            "complete",
            json!({ NEW_TEST: { "justification": FIFTY_WORDS, "user_request_quote": QUOTE } }),
        );
        let found = test_refusal_with(&path.to_string_lossy(), NEW_TEST, &reject)
            .expect("no such user message");
        assert!(found.contains("not a verbatim quote"), "{found}");
        assert_eq!(
            test_refusal_with(&path.to_string_lossy(), NEW_TEST, &accept),
            None
        );
        let _ = std::fs::remove_dir_all(path.parent().expect("a folder"));
    }

    /// An existing test is not a new test, and an ordinary source file is not
    /// a test at all.
    #[test]
    fn only_a_new_test_path_is_judged() {
        assert_eq!(
            test_refusal_with(ABSENT, "/repo/src/main.rs", &reject),
            None
        );
        assert_eq!(
            test_refusal_with(ABSENT, file!(), &reject),
            None,
            "this very file exists, so it is not a new test"
        );
    }
}
