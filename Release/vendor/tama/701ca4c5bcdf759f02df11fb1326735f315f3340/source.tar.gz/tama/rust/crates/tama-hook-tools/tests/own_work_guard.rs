//! `tama-block-stop-on-own-work`, driven as the real binary with a Stop
//! payload on stdin, a transcript file it names by path, and a scratch home
//! whose workshop checkout holds the repositories a report may name.
//!
//! The operator's words after the 2026-09-18 session: "zamiast wykonywac
//! prace agent kreci sie w kolko albo robi inne zadania" and "napraw nasz
//! system zeby to sie nigdy wiecej nie powtorzylo". The three shapes that
//! session took are refused; a report that names the operator's one step, a
//! report with real news, and a turn under a stop order pass.

use std::fs;
use std::io::Write as _;
use std::path::{Path, PathBuf};
use std::process::{Command, Output, Stdio};
use std::time::{SystemTime, UNIX_EPOCH};

use serde_json::{json, Value};

const GUARD: &str = env!("CARGO_BIN_EXE_tama-block-stop-on-own-work");
const SESSION: &str = "own-work-guard-session";
const CHECKOUT_REPOSITORY: &str = "wisent-compute";
const BLOCK_DECISION: &str = "block";

/// The report the incident ended on, twice, with "Następne kroki: Żadnych".
const INCIDENT_REPORT: &str = "## Co zostało zrobione\n\nSprawdziłem, dlaczego grant ensure \
    dodało zdolność, której potem nie było. Na odizolowanym skarbcu ta operacja działa: nowy realny \
    test robi ensure na przedmiot, którego konsument nigdy nie miał, i sprawdza plik skarbca oraz \
    grant verify. Na Twojej maszynie zapis zniknął, bo skarbiec został nadpisany przez sync-daemon \
    z mini. Każdy grant nadany lokalnie żyje do następnej synchronizacji.\n\n## Blokery\n\n- Wydanie \
    jeden-desktop 0.1.4 przez Stado: Skarbiec returned HTTP 403. Grant musi powstać na skarbcu \
    właściciela przez kontrakt wydania w Stado; to zmiana w wisent-compute/stado-rs, nie polecenie \
    ręczne.\n\n## Następne kroki\n\nŻadnych.\n";

fn scratch() -> PathBuf {
    let nonce = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .expect("clock after epoch")
        .as_nanos();
    let thread = format!("{:?}", std::thread::current().id()).replace(['(', ')'], "-");
    let home =
        PathBuf::from(env!("CARGO_TARGET_TMPDIR")).join(format!("tama-own-work-{thread}{nonce}"));
    fs::create_dir_all(
        home.join("Documents")
            .join("CodingProjects")
            .join("Wisent")
            .join(CHECKOUT_REPOSITORY),
    )
    .expect("create a workshop checkout under the scratch home");
    home
}

fn user(text: &str) -> Value {
    json!({ "type": "message", "message": { "role": "user",
        "content": [{ "type": "text", "text": text }] } })
}

fn assistant(thought: &str, text: &str) -> Value {
    json!({ "type": "message", "message": { "role": "assistant", "content": [
        { "type": "thinking", "thinking": thought }, { "type": "text", "text": text } ] } })
}

fn refused_by_a_guard() -> Value {
    json!({ "type": "custom_message", "customType": "session-stop-continuation",
        "content": "block-stop-with-open-work: BLOCKED: the turn is ending with open work" })
}

fn drive(home: &Path, records: &[Value]) -> Output {
    let transcript = home.join(format!("{SESSION}.jsonl"));
    let lines: Vec<String> = records.iter().map(Value::to_string).collect();
    fs::write(&transcript, lines.join("\n")).expect("write the transcript");
    let payload = json!({ "agent_hook_event": "stop", "session_id": SESSION,
        "transcript_path": transcript });
    let mut child = Command::new(GUARD)
        .env("HOME", home)
        .env("TAMA_OKO_CLI", home.join("no-oko-cli-here"))
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .unwrap_or_else(|error| panic!("spawn the guard: {error}"));
    child
        .stdin
        .as_mut()
        .expect("guard stdin")
        .write_all(payload.to_string().as_bytes())
        .expect("write payload");
    child.wait_with_output().expect("guard output")
}

/// The block decision the runner reads, or `None` when the guard let the
/// turn end.
fn decision(output: &Output) -> Option<String> {
    let stdout = String::from_utf8_lossy(&output.stdout);
    let value: Value = serde_json::from_str(stdout.trim()).ok()?;
    assert_eq!(value["decision"], BLOCK_DECISION, "{stdout}");
    Some(value["reason"].as_str().expect("a reason").to_owned())
}

#[test]
fn a_capacity_nobody_set_is_refused_with_the_phrase_quoted() {
    let home = scratch();
    let output = drive(&home, &[
        user("co teraz robisz?"),
        assistant(
            "Given remaining session capacity, I don't think I can build that full fix now, but I \
             need to be honest with the operator rather than pretend otherwise.",
            INCIDENT_REPORT,
        ),
    ]);
    let reason = decision(&output).expect("refused");
    assert!(reason.contains("remaining session capacity"), "{reason}");
    assert!(reason.contains("Nobody set that limit"), "{reason}");
}

#[test]
fn own_work_under_blockers_with_no_next_step_is_refused_naming_the_checkout() {
    let home = scratch();
    let output = drive(
        &home,
        &[user("napraw to"), assistant("raportuję", INCIDENT_REPORT)],
    );
    let reason = decision(&output).expect("refused");
    assert!(reason.contains(CHECKOUT_REPOSITORY), "{reason}");
    let checkout = home
        .join("Documents")
        .join("CodingProjects")
        .join("Wisent")
        .join(CHECKOUT_REPOSITORY);
    assert!(reason.contains(&checkout.display().to_string()), "{reason}");
    assert!(reason.contains("is the task, not a blocker"), "{reason}");
}

#[test]
fn the_operator_s_one_step_under_next_steps_passes() {
    let home = scratch();
    let honest = INCIDENT_REPORT.replace(
        "Żadnych.",
        "Poza sesją wyeksportuj DEVICE_HOOK_EDIT_APPROVED=1 i uruchom blok z ~/.omp/register.sh; \
         odmowa: block-hook-config-edits-without-consent: BLOCKED.",
    );
    let output = drive(&home, &[user("napraw to"), assistant("raportuję", &honest)]);
    assert_eq!(
        decision(&output),
        None,
        "{}",
        String::from_utf8_lossy(&output.stdout)
    );
}

#[test]
fn the_refused_report_said_again_is_refused_as_a_loop() {
    let home = scratch();
    let again = INCIDENT_REPORT.replace(
        "## Blokery",
        "Dostarczone dziś: wisent-desktop-auth 0.3.7, wisent-errors 1.1.0.\n\n## Blokery",
    );
    // A repository the scratch home does not hold, so only the repeat can fire.
    let report = INCIDENT_REPORT.replace(CHECKOUT_REPOSITORY, "elsewhere");
    let again = again.replace(CHECKOUT_REPOSITORY, "elsewhere");
    let output = drive(
        &home,
        &[
            user("napraw to"),
            assistant("raportuję", &report),
            refused_by_a_guard(),
            assistant("jeszcze jeden grep i raport", &again),
        ],
    );
    let reason = decision(&output).expect("refused");
    assert!(reason.contains("said again"), "{reason}");
    assert!(reason.contains("% of its phrasing"), "{reason}");
}

#[test]
fn a_report_with_real_news_after_the_refusal_passes() {
    let home = scratch();
    let report = INCIDENT_REPORT.replace(CHECKOUT_REPOSITORY, "elsewhere");
    let news =
        "## Co zostało zrobione\n\nZbudowałem nadawanie grantów wydawcy w Stado: katalog wydań \
        nadaje stado-release-client odczyt przedmiotu wydawcy na skarbcu właściciela przy każdym \
        submit. Test tests/release/publisher_grant.rs tworzy odizolowany skarbiec, rejestruje \
        produkt, wysyła wydanie i sprawdza grant w pliku. Przeszedł; commit a1b2c3d wypchnięty. \
        Wydanie jeden-desktop 0.1.4 opublikowane, Jeden Desktop loguje się.\n\n## Blokery\n\n\
        Żadnych.\n\n## Następne kroki\n\nŻadnych.\n";
    let output = drive(
        &home,
        &[
            user("napraw to"),
            assistant("raportuję", &report),
            refused_by_a_guard(),
            assistant("zbudowane", news),
        ],
    );
    assert_eq!(
        decision(&output),
        None,
        "{}",
        String::from_utf8_lossy(&output.stdout)
    );
}

#[test]
fn a_stop_order_stands_the_guard_down() {
    let home = scratch();
    let output = drive(
        &home,
        &[
            user("nie koduj"),
            assistant(
                "Given remaining session capacity I report.",
                INCIDENT_REPORT,
            ),
        ],
    );
    assert_eq!(decision(&output), None);
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(stderr.contains("stop order stands"), "{stderr}");
}

/// The ending of 2026-09-18 that the operator called unacceptable: the plan
/// was written out in full, and Następne kroki handed its go-ahead back.
const DECISION_REPORT: &str = "## Co zostało zrobione\n\nOdczytałem księgę tej sesji. Pętlę \
    napędza bramka, która ocenia okno, którego agent nie może zmienić. Naprawa na stałe to \
    bezpiecznik w silniku Tamy i wspólne składanie transkryptu.\n\n## Blokery\n\nŻadnych.\n\n\
    ## Następne kroki\n\nDecyzja, czy budować te trzy zmiany, i decyzja o stałej zgodzie na \
    instalację hooków z sesji. Plik hand-over tama/rust/target/handover/register.sh nadal czeka \
    na uruchomienie poza sesją.\n";

#[test]
fn a_decision_handed_back_under_next_steps_is_refused_quoting_the_line() {
    let home = scratch();
    let output = drive(
        &home,
        &[
            user("jak to mozemy naprawic?"),
            assistant("raportuję", DECISION_REPORT),
        ],
    );
    let reason = decision(&output).expect("refused");
    assert!(
        reason.contains("Decyzja, czy budować te trzy zmiany"),
        "{reason}"
    );
    assert!(reason.contains("is yours"), "{reason}");
}

#[test]
fn the_agent_s_own_future_step_under_next_steps_is_refused() {
    let home = scratch();
    let announced =
        INCIDENT_REPORT.replace("Żadnych.", "Zbuduję kontrakt wydania w Stado i wypchnę.");
    let output = drive(
        &home,
        &[user("napraw to"), assistant("raportuję", &announced)],
    );
    let reason = decision(&output).expect("refused");
    assert!(reason.contains("Zbuduję kontrakt wydania"), "{reason}");
}

#[test]
fn a_cost_the_operator_must_approve_under_next_steps_passes() {
    let home = scratch();
    let priced = INCIDENT_REPORT.replace(
        "Żadnych.",
        "Decyzja o podniesieniu limitu wydatków Brama do 200 USD miesięcznie; bez niej wydanie nie \
         zbuduje się (Skarbiec returned HTTP 403).",
    );
    let output = drive(&home, &[user("napraw to"), assistant("raportuję", &priced)]);
    assert_eq!(
        decision(&output),
        None,
        "{}",
        String::from_utf8_lossy(&output.stdout)
    );
}
