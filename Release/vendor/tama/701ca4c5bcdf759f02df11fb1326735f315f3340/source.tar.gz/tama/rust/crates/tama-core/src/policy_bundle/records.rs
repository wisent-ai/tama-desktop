//! What an imported bundle is on disk: the records the index keeps, the
//! summaries a listing shows, and the result an import reports.
//!
//! Split out of `policy_bundle.rs`, which had grown past the
//! three-hundred-line limit; importing stays in the module root.

use serde::{Deserialize, Serialize};
use std::path::Path;

use super::RESULT_SCHEMA;

/// A rejected import copied nothing, so every count it reports is zero.
const NOTHING: usize = 0;

#[derive(Debug, Clone)]
pub(super) struct SelectedFile {
    pub relative: String,
    pub bytes: Vec<u8>,
    pub sha256: String,
    pub mode: u32,
}

#[derive(Debug)]
pub(super) struct Selection {
    pub files: Vec<SelectedFile>,
    pub digest: String,
    pub hook_count: usize,
    pub ignored_paths: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct BundleFileRecord {
    pub path: String,
    pub sha256: String,
    pub mode: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PolicyBundleRecord {
    pub source_key: String,
    pub source_path: String,
    pub source_digest: String,
    pub bundle_path: String,
    pub imported_at_unix: u64,
    pub hook_count: usize,
    pub activation: String,
    pub files: Vec<BundleFileRecord>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub(super) struct PolicyBundleIndex {
    pub schema: String,
    pub bundles: Vec<PolicyBundleRecord>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct PolicyBundleSummary {
    pub source_key: String,
    pub source_path: String,
    pub source_digest: String,
    pub bundle_path: String,
    pub imported_at_unix: u64,
    pub hook_count: usize,
    pub file_count: usize,
    pub activation: String,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct PolicyBundleList {
    pub schema: String,
    pub store_path: String,
    pub bundles: Vec<PolicyBundleSummary>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct PolicyBundleConflict {
    pub path: String,
    pub reason: String,
    pub existing_sha256: Option<String>,
    pub incoming_sha256: Option<String>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct PolicyBundleImportResult {
    pub schema: String,
    pub status: String,
    pub source_path: String,
    pub source_digest: Option<String>,
    pub store_path: String,
    pub bundle_path: Option<String>,
    pub hook_count: usize,
    pub imported: usize,
    pub unchanged: usize,
    pub removed: usize,
    pub conflicting: usize,
    pub rejected: usize,
    pub conflicts: Vec<PolicyBundleConflict>,
    pub rejections: Vec<String>,
    pub ignored_paths: Vec<String>,
    pub activation: String,
    pub installed_hooks: usize,
    pub enabled_hooks: usize,
}

impl PolicyBundleImportResult {
    pub(super) fn rejected(
        source: &Path,
        store: &Path,
        reasons: Vec<String>,
        ignored_paths: Vec<String>,
    ) -> Self {
        Self {
            schema: RESULT_SCHEMA.to_string(),
            status: "rejected".to_string(),
            source_path: source.display().to_string(),
            source_digest: None,
            store_path: store.display().to_string(),
            bundle_path: None,
            hook_count: NOTHING,
            imported: NOTHING,
            unchanged: NOTHING,
            removed: NOTHING,
            conflicting: NOTHING,
            rejected: reasons.len(),
            conflicts: Vec::new(),
            rejections: reasons,
            ignored_paths,
            activation: "inactive".to_string(),
            installed_hooks: NOTHING,
            enabled_hooks: NOTHING,
        }
    }
}

pub struct ImportPolicyBundleOptions<'a> {
    pub source: &'a Path,
    pub home: Option<&'a Path>,
    pub replace: bool,
}
