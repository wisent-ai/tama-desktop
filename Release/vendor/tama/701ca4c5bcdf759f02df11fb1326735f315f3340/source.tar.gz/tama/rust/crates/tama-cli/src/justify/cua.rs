//! Record an existing user grant without changing the policy that consumes it.

mod command;
mod storage;
mod transcript;

use std::path::{Path, PathBuf};
use std::process::Command;

use serde::Deserialize;
use serde_json::{json, Value};
use tama_hook_tools::ports::{block_unauthorized_cua as policy, transport_common};

pub(super) use command::main;

pub(crate) const SCHEMA: &str = "ai.wisent.tama.cua-justifications.vTwo";
const LIFETIME: &str = "current OMP session";

#[derive(Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub(crate) struct RecordRequest {
    pub session_id: String,
    pub app: String,
    pub actions: Vec<String>,
    pub quote: Option<String>,
    pub quote_match: Option<String>,
}

fn installed_app(app: &str) -> Result<(String, String), String> {
    if app.trim().is_empty() || app.contains(['/', '\\']) || app == "." || app == ".." {
        return Err("app must name an installed application, not a path".into());
    }
    let name = format!("{app}.app");
    let bundle = [
        PathBuf::from("/Applications").join(&name),
        transport_common::home().join("Applications").join(&name),
    ]
    .into_iter()
    .find(|path| path.join("Contents/Info.plist").is_file())
    .ok_or_else(|| {
        format!("application {app} is not installed in /Applications or ~/Applications")
    })?;
    let plist = bundle.join("Contents/Info.plist");
    let read = |key: &str| -> Result<String, String> {
        let output = Command::new("/usr/bin/plutil")
            .args(["-extract", key, "raw", "-o", "-"])
            .arg(&plist)
            .output()
            .map_err(|error| format!("cannot read {}: {error}", plist.display()))?;
        let text = String::from_utf8_lossy(&output.stdout).trim().to_string();
        if !output.status.success() || text.is_empty() {
            return Err(format!(
                "cannot read {key} from {}: {}{}",
                plist.display(),
                text,
                String::from_utf8_lossy(&output.stderr)
            ));
        }
        Ok(text)
    };
    let bundle_id = read("CFBundleIdentifier")?;
    let executable_name = read("CFBundleExecutable")?;
    if executable_name.contains('/') || executable_name == ".." {
        return Err(format!(
            "{} has an invalid CFBundleExecutable",
            plist.display()
        ));
    }
    let executable = bundle.join("Contents/MacOS").join(executable_name);
    if !executable.is_file() {
        return Err(format!(
            "application executable is missing at {}",
            executable.display()
        ));
    }
    Ok((bundle_id, executable.to_string_lossy().into_owned()))
}

pub(crate) fn record_request(request: RecordRequest, home: &Path) -> Result<Value, String> {
    if request.session_id.is_empty()
        || !request
            .session_id
            .chars()
            .all(|c| c.is_ascii_alphanumeric() || c == '-')
    {
        return Err("sessionId must be the exact OMP session identifier".into());
    }
    let quote = match (request.quote, request.quote_match) {
        (Some(quote), None) if !quote.trim().is_empty() => quote,
        (None, Some(needle)) if !needle.trim().is_empty() => {
            transcript::select(&request.session_id, &needle)?
        }
        _ => return Err("supply exactly one nonempty quote or quoteMatch".into()),
    };
    let mut actions = Vec::new();
    for raw in request.actions {
        let action = raw.trim().to_lowercase().replace('-', "_");
        if action.is_empty() || !action.chars().all(|c| c.is_ascii_lowercase() || c == '_') {
            return Err(format!("invalid CUA action {raw:?}"));
        }
        if !actions.contains(&action) {
            actions.push(action);
        }
    }
    if actions.is_empty() {
        return Err("actions must name at least one CUA action".into());
    }
    let (bundle_id, executable) = installed_app(&request.app)?;
    let entry = json!({
        "userRequestQuote": quote,
        "allowedTool": "cua-driver",
        "allowedBundleId": bundle_id,
        "allowedAppName": request.app,
        "allowedExecutable": executable,
        "allowedActions": actions,
        "allowUntargeted": false,
        "lifetime": LIFETIME,
        "sessionId": request.session_id,
    });
    if !policy::quote_directly_authorizes(&entry, &quote, true) {
        return Err(
            "the quote must directly authorize CUA, the application and every requested action"
                .into(),
        );
    }
    if !transport_common::quote_is_in_current_session(&request.session_id, &quote) {
        return Err(format!(
            "the quote is not a verbatim user message in OMP session {} under {}",
            request.session_id,
            transport_common::session_root().display()
        ));
    }
    let registry = super::registry::registry_path(home, super::registry::Kind::Cua);
    storage::record(&registry, entry.clone())?;
    Ok(
        json!({"kind": "cua", "registry": registry, "sessionId": request.session_id,
        "authorization": entry}),
    )
}

pub(crate) fn list_document(home: &Path) -> Result<Value, String> {
    let registry = super::registry::registry_path(home, super::registry::Kind::Cua);
    let document = storage::load(&registry)?;
    Ok(json!({"kind": "cua", "registry": registry, "authorizations": document["authorizations"]}))
}

pub(crate) fn remove_document(home: &Path, quote: &str) -> Result<Value, String> {
    if quote.trim().is_empty() {
        return Err("quote must name the recorded sentence to remove".into());
    }
    let registry = super::registry::registry_path(home, super::registry::Kind::Cua);
    let count = storage::forget(&registry, quote)?;
    Ok(json!({"kind": "cua", "registry": registry, "removed": quote, "count": count}))
}
