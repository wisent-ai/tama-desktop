//! The build and restart registry, as this gate reads it.
//!
//! `~/.shared-hooks/build_restart_registry.json` is a JSON object keyed
//! `<kind>:<target>`, each entry stating what the build or restart is for,
//! the revision a build carries, when the authorization was recorded and when
//! it stops:
//!
//! ```json
//! {
//!   "build:skarbiec": {
//!     "kind": "build",
//!     "target": "skarbiec",
//!     "reason": "0.3.11 carries the identity kind and the duplicate refusal",
//!     "revision": "45a5c678042147f76241adf76fb7cf217e121ca6",
//!     "recorded_at": "2026-09-21T04:10:00Z",
//!     "expires_at": "2026-09-21T05:10:00Z"
//!   }
//! }
//! ```
//!
//! The gate only reads. `tama-cli build record` writes, because every other
//! path into `.shared-hooks` is refused by the consent and write gates, and a
//! registry is data with an interface rather than a file anybody edits by
//! hand.
//!
//! An expiry is part of the entry rather than an afterthought: an
//! authorization that never closed would make the first recorded build a
//! standing permission for every later one, which is the state this gate
//! exists to end.

use std::path::{Path, PathBuf};

use serde_json::Value;

use super::detect::Kind;

const REGISTRY_DIRECTORY: &str = ".shared-hooks";
const REGISTRY_FILE: &str = "build_restart_registry.json";

/// One recorded authorization.
pub struct Entry {
    kind: Kind,
    target: String,
    expires_at_epoch: Option<u64>,
}

impl Entry {
    /// Whether this entry authorizes that kind of work on that target, and has
    /// not expired.
    pub fn covers(&self, kind: Kind, target: &str) -> bool {
        self.kind == kind && self.target == target && !self.expired(now())
    }

    fn expired(&self, at: u64) -> bool {
        match self.expires_at_epoch {
            // An entry with no expiry is not a standing permission: it is a
            // malformed entry, and a gate that honoured it would be honouring
            // the one shape an agent could write to disable itself.
            None => true,
            Some(stamp) => stamp <= at,
        }
    }
}

/// The registry file for this account, or nothing when there is no home to
/// read it from.
pub fn registry_path() -> Option<PathBuf> {
    let home = std::env::var_os("HOME")?;
    Some(
        PathBuf::from(home)
            .join(REGISTRY_DIRECTORY)
            .join(REGISTRY_FILE),
    )
}

/// Every entry the registry holds. A missing, empty or malformed registry
/// holds none: the gate then refuses every build and restart, which is the
/// safe direction, and its refusal names the command that writes an entry.
pub fn open_entries(path: &Path) -> Vec<Entry> {
    let Ok(text) = std::fs::read_to_string(path) else {
        return Vec::new();
    };
    let Ok(Value::Object(document)) = serde_json::from_str::<Value>(&text) else {
        return Vec::new();
    };
    document
        .values()
        .filter_map(|entry| {
            let kind = Kind::parse(entry.get("kind").and_then(Value::as_str)?)?;
            let target = entry.get("target").and_then(Value::as_str)?.to_string();
            Some(Entry {
                kind,
                target,
                expires_at_epoch: entry.get("expires_at_epoch").and_then(Value::as_u64),
            })
        })
        .collect()
}

/// The instant an expiry is compared against: seconds since the epoch, the
/// same clock `tama-cli build record` stamps an entry with.
fn now() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|elapsed| elapsed.as_secs())
        .unwrap_or_default()
}

#[cfg(test)]
mod tests {
    use super::{now, open_entries, Entry, Kind};

    /// An hour is the span a recorded build or restart is authorized for in
    /// these cases; what is under test is open versus closed, not the span.
    const ONE_HOUR_SECONDS: u64 = 3600;

    fn entry(kind: Kind, target: &str, expires_at_epoch: Option<u64>) -> Entry {
        Entry {
            kind,
            target: target.to_string(),
            expires_at_epoch,
        }
    }

    #[test]
    fn an_open_entry_covers_its_own_kind_and_target_only() {
        let open = entry(Kind::Build, "skarbiec", Some(now() + ONE_HOUR_SECONDS));
        assert!(open.covers(Kind::Build, "skarbiec"));
        assert!(!open.covers(Kind::Restart, "skarbiec"));
        assert!(!open.covers(Kind::Build, "brama"));
    }

    /// The failure this gate exists to prevent is a first authorization that
    /// never closes.
    #[test]
    fn an_expired_or_undated_entry_covers_nothing() {
        assert!(
            !entry(Kind::Build, "skarbiec", Some(now() - ONE_HOUR_SECONDS))
                .covers(Kind::Build, "skarbiec")
        );
        assert!(!entry(Kind::Build, "skarbiec", None).covers(Kind::Build, "skarbiec"));
    }

    #[test]
    fn a_missing_or_malformed_registry_holds_no_entries() {
        let missing = std::path::Path::new("/nonexistent/build_restart_registry.json");
        assert!(open_entries(missing).is_empty());
        let directory = std::env::temp_dir().join("tama-build-registry-malformed");
        std::fs::create_dir_all(&directory).expect("fixture directory");
        let path = directory.join("build_restart_registry.json");
        std::fs::write(&path, "not json").expect("write fixture");
        assert!(open_entries(&path).is_empty());
        std::fs::remove_file(&path).ok();
    }

    #[test]
    fn entries_are_read_from_the_document() {
        let directory = std::env::temp_dir().join("tama-build-registry-read");
        std::fs::create_dir_all(&directory).expect("fixture directory");
        let path = directory.join("build_restart_registry.json");
        std::fs::write(
            &path,
            serde_json::json!({
                "build:skarbiec": {
                    "kind": "build",
                    "target": "skarbiec",
                    "reason": "the identity kind and the duplicate refusal",
                    "expires_at_epoch": now() + ONE_HOUR_SECONDS
                },
                "restart:web": {
                    "kind": "restart",
                    "target": "web",
                    "reason": "picked up a new image",
                    "expires_at_epoch": now() - ONE_HOUR_SECONDS
                }
            })
            .to_string(),
        )
        .expect("write fixture");
        let entries = open_entries(&path);
        assert_eq!(entries.len(), 2);
        assert!(entries
            .iter()
            .any(|entry| entry.covers(Kind::Build, "skarbiec")));
        assert!(!entries
            .iter()
            .any(|entry| entry.covers(Kind::Restart, "web")));
        std::fs::remove_file(&path).ok();
    }
}
