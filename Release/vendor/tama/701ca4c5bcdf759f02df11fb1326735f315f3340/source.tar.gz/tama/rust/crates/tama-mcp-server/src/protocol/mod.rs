//! JSON-RPC / MCP protocol handling, split out of `main.rs`.

pub mod jsvalues;
mod validate;

use serde_json::Value;
use std::io::Write;
use std::path::Path;

use crate::tools::call_tool;
use validate::{issues_json, validate_call_tool, validate_initialize, validate_tools_list};

const LATEST_PROTOCOL_VERSION: &str = "2025-11-25";
const SUPPORTED_PROTOCOL_VERSIONS: [&str; 5] = [
    "2025-11-25",
    "2025-06-18",
    "2025-03-26",
    "2024-11-05",
    "2024-10-07",
];

const ERR_METHOD_NOT_FOUND: i32 = -32601;
const ERR_INTERNAL: i32 = -32603;

/// Exact `tools/list` result payload (key order from `mcp-server.mjs`).
const TOOLS_LIST_JSON: &str = concat!(
    r#"{"tools":["#,
    r#"{"name":"list_hooks","description":"List archived hook catalog entries.","inputSchema":{"type":"object","properties":{"blockingOnly":{"type":"boolean"}}}},"#,
    r#"{"name":"show_hook","description":"Show one hook by id, including command, source path, and events.","inputSchema":{"type":"object","properties":{"id":{"type":"string"}},"required":["id"]}},"#,
    r#"{"name":"read_hook_source","description":"Read an archived hook source file by hook id.","inputSchema":{"type":"object","properties":{"id":{"type":"string"}},"required":["id"]}},"#,
    r#"{"name":"validate_hooks","description":"Validate hook catalog consistency and secret-scan archived sources.","inputSchema":{"type":"object","properties":{}}},"#,
    r#"{"name":"find_violations","description":"Scan a repository for existing violations of the hook content rules (max 300 lines per file, max 5 files per folder, forbidden content patterns, unsubstantiated constants) by replaying the real pre-write hook against every enumerated file. Read-only; honors .tama/violations-ignore (or the root .tama-violations-ignore) and vendored/build-output exclusions.","inputSchema":{"type":"object","properties":{"repo":{"type":"string","description":"Absolute path to the repository to scan"},"hookPath":{"type":"string","description":"Optional pre-write hook script path override"}},"required":["repo"]}}"#,
    r#"]}"#,
);

pub enum Outcome {
    /// Pre-serialized `result` payload.
    Result(String),
    /// `(code, message)` error pair.
    Error(i32, String),
}

pub fn process_line(root: &Path, line: &str) {
    let value: Value = match serde_json::from_str(line) {
        Ok(value) => value,
        Err(_) => return, // JS: JSON.parse failure -> onerror -> silent
    };
    let (id, method, params) = match as_request(&value) {
        Some(request) => request,
        None => return, // notifications, responses, invalid envelopes: silent
    };
    match dispatch(root, &method, params.as_ref()) {
        Outcome::Result(result) => emit(&format!(
            "{{\"result\":{},\"jsonrpc\":\"2.0\",\"id\":{}}}",
            result,
            render_id(&id)
        )),
        Outcome::Error(code, message) => emit(&format!(
            "{{\"jsonrpc\":\"2.0\",\"id\":{},\"error\":{{\"code\":{},\"message\":{}}}}}",
            render_id(&id),
            code,
            serde_json::to_string(&message).unwrap_or_else(|_| "\"Internal error\"".to_string())
        )),
    }
}

/// SDK `JSONRPCRequestSchema` (strict): exactly the keys
/// {jsonrpc, id, method, params}, `jsonrpc` literally "2.0", `id` a string or
/// integer number, `method` a string, and optional `params` a non-array object
/// whose optional `_meta` is a non-array object.
fn as_request(value: &Value) -> Option<(Value, String, Option<Value>)> {
    let object = value.as_object()?;
    for key in object.keys() {
        if !["jsonrpc", "id", "method", "params"].contains(&key.as_str()) {
            return None;
        }
    }
    if object.get("jsonrpc")?.as_str()? != "2.0" {
        return None;
    }
    let id = object.get("id")?;
    match id {
        Value::String(_) => {}
        Value::Number(number) => {
            // z.number().int(): integral values only (1e21 is an integer in JS).
            let integral = number.as_i64().is_some()
                || number.as_u64().is_some()
                || number.as_f64().map(|f| f.fract() == 0.0).unwrap_or(false);
            if !integral {
                return None;
            }
        }
        _ => return None,
    }
    let method = object.get("method")?.as_str()?.to_string();
    if let Some(params) = object.get("params") {
        let params_obj = params.as_object()?;
        if let Some(meta) = params_obj.get("_meta") {
            meta.as_object()?;
        }
    }
    let params = object.get("params").cloned();
    Some((id.clone(), method, params))
}

fn dispatch(root: &Path, method: &str, params: Option<&Value>) -> Outcome {
    match method {
        "initialize" => {
            let issues = validate_initialize(params);
            if !issues.is_empty() {
                return Outcome::Error(ERR_INTERNAL, issues_json(&issues));
            }
            let requested = params
                .and_then(|p| p.get("protocolVersion"))
                .and_then(|v| v.as_str())
                .unwrap_or("");
            let version = if SUPPORTED_PROTOCOL_VERSIONS.contains(&requested) {
                requested
            } else {
                LATEST_PROTOCOL_VERSION
            };
            Outcome::Result(format!(
                "{{\"protocolVersion\":{},\"capabilities\":{{\"tools\":{{}}}},\"serverInfo\":{{\"name\":\"tama\",\"version\":\"0.1.0\"}}}}",
                serde_json::to_string(version).unwrap_or_else(|_| "\"\"".to_string())
            ))
        }
        // PingRequestSchema imposes nothing beyond the envelope; result is {}.
        "ping" => Outcome::Result("{}".to_string()),
        "tools/list" => {
            let issues = validate_tools_list(params);
            if !issues.is_empty() {
                return Outcome::Error(ERR_INTERNAL, issues_json(&issues));
            }
            Outcome::Result(TOOLS_LIST_JSON.to_string())
        }
        "tools/call" => {
            let issues = validate_call_tool(params);
            if !issues.is_empty() {
                return Outcome::Error(ERR_INTERNAL, issues_json(&issues));
            }
            let params = match params {
                Some(value) => value,
                None => {
                    return Outcome::Error(
                        ERR_INTERNAL,
                        "unreachable: params validated".to_string(),
                    )
                }
            };
            match call_tool(root, params) {
                Ok(text) => Outcome::Result(format!(
                    "{{\"content\":[{{\"type\":\"text\",\"text\":{}}}]}}",
                    serde_json::to_string(&text).unwrap_or_else(|_| "\"\"".to_string())
                )),
                Err(message) => Outcome::Error(ERR_INTERNAL, message),
            }
        }
        _ => Outcome::Error(ERR_METHOD_NOT_FOUND, "Method not found".to_string()),
    }
}

/// One locked `write_all` + `flush` per message (mirrors the SDK's
/// `process.stdout.write(JSON.stringify(message) + '\n')`).
fn emit(text: &str) {
    let stdout = std::io::stdout();
    let mut out = stdout.lock();
    let _ = out.write_all(text.as_bytes());
    let _ = out.write_all(b"\n");
    let _ = out.flush();
}

/// Echo a request id the way `JSON.stringify` prints it: integral numbers
/// without a fractional part (`5.0` parses to `5` in JS and echoes as `5`).
fn render_id(id: &Value) -> String {
    match id {
        Value::String(text) => serde_json::to_string(text).unwrap_or_else(|_| "\"\"".to_string()),
        Value::Number(number) => {
            if let Some(int) = number.as_i64() {
                return int.to_string();
            }
            if let Some(uint) = number.as_u64() {
                return uint.to_string();
            }
            let float = number.as_f64().unwrap_or(0.0);
            if float.fract() == 0.0 && float.abs() < 1e21 {
                format!("{}", float as i128)
            } else {
                serde_json::to_string(&float).unwrap_or_else(|_| "0".to_string())
            }
        }
        _ => "null".to_string(),
    }
}
