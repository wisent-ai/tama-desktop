//! The guards that keep the gates and the history intact.
//!
//! Hooks first: the authorization variable has to come from the operator's
//! settings, not from a command prefix, because a prefix is something an
//! agent can type. Writing to the hook tree from a shell, or running a script
//! out of it, needs the same authorization.
//!
//! Then git: no hook bypass on commit or push, no `git checkout` at all — on
//! 2026-05-13 an unauthorized `git checkout <ref> -- <paths>` destroyed
//! uncommitted work in two files with no prompt and no backup, and `git
//! switch` and `git restore` do everything it did, visibly — no authorship
//! trailer for a tool, and no pull request against the managed database
//! repositories.
//!
//! Finally the product flags that quietly narrow a run: the sampling
//! overrides on `wisent`, and pinning a compute job to one provider.

use std::sync::LazyLock;

use regex::Regex;

use crate::ports::transport_common as common;

const AUTHORIZED_ENV: &str = "HOOK_EDIT_AUTHORIZED";
const AUTHORIZED_VALUE: &str = "1";
const PIN_ENV: &str = "WC_PIN_AUTHORIZED";

static INLINE_AUTHORIZATION: LazyLock<Regex> =
    LazyLock::new(|| common::compile("^[[:space:]]*HOOK_EDIT_AUTHORIZED="));
static HOOK_TREE_WRITE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile("(>>?|cp |mv |tee |install )[[:space:]]*[^[:space:]]*\\.shared-hooks/")
});
static HOOK_TREE_RUN: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        "(^|[;&|`(]|[[:space:]])({})[[:space:]]+[^[:space:]]*\\.shared-hooks/",
        crate::ports::shell_text::shell_alternation()
    ))
});
static NO_VERIFY: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(^|[;&|`(]|[[:space:]])git([^;&|`]*[[:space:]])?(commit|push)([[:space:]][^;&|`]*)?",
        "[[:space:]]--no-verify([[:space:]]|$|[;&|`])",
    ))
});
static COMMIT_SHORT_FLAG: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(^|[;&|`(]|[[:space:]])git([^;&|`]*[[:space:]])?commit([[:space:]][^;&|`]*)?",
        "[[:space:]]-[A-Za-z]*n[A-Za-z]*([[:space:]]|$|[;&|`])",
    ))
});
static CHECKOUT: LazyLock<Regex> = LazyLock::new(|| {
    common::compile("(^|[;&|`(]|[[:space:]])git[[:space:]]+checkout([[:space:]]|$)")
});
static COMMIT: LazyLock<Regex> =
    LazyLock::new(|| common::compile("(^|[;&|`(]|[[:space:]])git[[:space:]]+commit\\b"));
static TOOL_TRAILER: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(
        "(?i)Co-Authored-By:[[:space:]].*(Claude|@anthropic\\.com|factory-droid\\[bot\\])",
    )
});
static PULL_REQUEST: LazyLock<Regex> = LazyLock::new(|| {
    common::compile("(^|[[:space:]])gh[[:space:]]+pr[[:space:]]+(create|merge)\\b")
});
static MANAGED_DATABASE: LazyLock<Regex> =
    LazyLock::new(|| common::compile("wisent-supabase-(wisent-app|content-platform)"));
static WISENT_TOOL: LazyLock<Regex> =
    LazyLock::new(|| common::compile("(^|[[:space:]])wisent[[:space:]]"));
static SAMPLING_FLAGS: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(^|[[:space:]])(--limit|--max-pairs|--max-samples|--num-samples|--batch-size",
        "|--max-iterations|--n-pairs|--sample-size|--subset|--quick)([[:space:]]|=|$)",
    ))
});
static SUBMIT: LazyLock<Regex> =
    LazyLock::new(|| common::compile("(^|[;&|`(]|[[:space:]])wc[[:space:]]+submit\\b"));
static PIN_PROVIDER: LazyLock<Regex> =
    LazyLock::new(|| common::compile("(^|[[:space:]])--pin-provider([[:space:]]|$)"));
/// `--provider <name>`: the value is whatever Stado offers, so the guard
/// matches the shape of a provider name rather than a list of them — a
/// provider added to Stado is pinned here without a change in Tama.
static CHOSEN_PROVIDER: LazyLock<Regex> = LazyLock::new(|| {
    common::compile("(^|[[:space:]])--provider([[:space:]]|=)[A-Za-z][A-Za-z0-9_-]*\\b")
});

const INLINE_REFUSAL: &str =
    "BLOCKED: HOOK_EDIT_AUTHORIZED must be set in settings.json env, not inline. (v7)";
const HOOK_WRITE_REFUSAL: &str = concat!(
    "BLOCKED: writes to ~/.shared-hooks/ require HOOK_EDIT_AUTHORIZED=1 in settings.json. (v7)",
);
const HOOK_RUN_REFUSAL: &str = concat!(
    "BLOCKED: invoking scripts under ~/.shared-hooks/ requires HOOK_EDIT_AUTHORIZED=1 in ",
    "settings.json. (v7)",
);
const NO_VERIFY_REFUSAL: &str = concat!(
    "BLOCKED: Git hook bypass is forbidden for this agent. Run commit and push normally so ",
    "device-level and repo-level hooks execute.",
);
const SHORT_FLAG_REFUSAL: &str = concat!(
    "BLOCKED: git commit -n bypasses required hooks. Run commit normally so device-level and ",
    "repo-level hooks execute.",
);
const CHECKOUT_REFUSAL: &str = concat!(
    "BLOCKED: 'git checkout' is forbidden — it silently destroys uncommitted working-tree ",
    "changes. Use 'git switch <branch>' for branch changes or 'git restore --source=<ref> ",
    "<path>' for file restoration (which still requires explicit --worktree to overwrite ",
    "uncommitted edits).",
);
const TRAILER_REFUSAL: &str = "BLOCKED: Co-Authored-By Claude trailer.";
const PULL_REQUEST_REFUSAL: &str = "BLOCKED: No PRs against wisent-supabase-* repos.";
const PIN_REFUSAL: &str = concat!(
    "BLOCKED: 'wc submit --pin-provider' restricts the wisent-compute job to one backend ",
    "(gcp/aws/azure/local). The user has not authorized that. Set WC_PIN_AUTHORIZED=1 to ",
    "override.",
);
const CHOSEN_REFUSAL: &str = concat!(
    "BLOCKED: 'wc submit --provider <X>' selects a single wisent-compute backend. Submit ",
    "without --provider so any provider can claim, or set WC_PIN_AUTHORIZED=1 with explicit ",
    "user OK.",
);

fn authorized(name: &str) -> bool {
    std::env::var(name).ok().as_deref() == Some(AUTHORIZED_VALUE)
}

/// The refusal this command earns from the hook, history and product-flag
/// guards, if any. The two authorizations are parameters so a test never
/// depends on what this machine happens to export.
pub(crate) fn refusal_with(
    command: &str,
    hook_edits: bool,
    provider_pinning: bool,
) -> Option<String> {
    if INLINE_AUTHORIZATION.is_match(command) {
        return Some(INLINE_REFUSAL.to_string());
    }
    if !hook_edits {
        if HOOK_TREE_WRITE.is_match(command) {
            return Some(HOOK_WRITE_REFUSAL.to_string());
        }
        if HOOK_TREE_RUN.is_match(command) {
            return Some(HOOK_RUN_REFUSAL.to_string());
        }
    }
    if NO_VERIFY.is_match(command) {
        return Some(NO_VERIFY_REFUSAL.to_string());
    }
    if COMMIT_SHORT_FLAG.is_match(command) {
        return Some(SHORT_FLAG_REFUSAL.to_string());
    }
    if CHECKOUT.is_match(command) {
        return Some(CHECKOUT_REFUSAL.to_string());
    }
    if COMMIT.is_match(command) && TOOL_TRAILER.is_match(command) {
        return Some(TRAILER_REFUSAL.to_string());
    }
    if PULL_REQUEST.is_match(command) && MANAGED_DATABASE.is_match(command) {
        return Some(PULL_REQUEST_REFUSAL.to_string());
    }
    if WISENT_TOOL.is_match(command) {
        if let Some(found) = SAMPLING_FLAGS.find(command) {
            let flag = found.as_str().trim();
            return Some(format!("BLOCKED: Override flag '{flag}' is forbidden."));
        }
    }
    if SUBMIT.is_match(command) && !provider_pinning {
        if PIN_PROVIDER.is_match(command) {
            return Some(PIN_REFUSAL.to_string());
        }
        if CHOSEN_PROVIDER.is_match(command) {
            return Some(CHOSEN_REFUSAL.to_string());
        }
    }
    None
}

pub(crate) fn refusal(command: &str) -> Option<String> {
    refusal_with(command, authorized(AUTHORIZED_ENV), authorized(PIN_ENV))
}

#[cfg(test)]
mod tests {
    use super::refusal_with;

    /// Neither authorization is granted in these cases unless it is the
    /// point of the case.
    fn refusal(command: &str) -> Option<String> {
        refusal_with(command, false, false)
    }

    /// A variable an agent can type is not a permission an operator granted.
    #[test]
    fn an_inline_authorization_is_refused() {
        let found =
            refusal("HOOK_EDIT_AUTHORIZED=1 cp x ~/.shared-hooks/y.sh").expect("an inline grant");
        assert!(found.contains("settings.json env, not inline"), "{found}");
    }
    /// The rule reads the verb and the path next to each other, so a
    /// redirection or a `tee` into the hook tree is caught here while
    /// `cp source target` is not — that spelling is refused by the consent
    /// guard, which reads every token of the command. Recorded rather than
    /// widened, because the two gates are selected independently.
    #[test]
    fn writing_or_running_the_hook_tree_from_a_shell_is_refused() {
        assert!(refusal("printf x > ~/.shared-hooks/registry.json").is_some());
        assert!(refusal("printf x | tee ~/.shared-hooks/registry.json").is_some());
        assert!(refusal("bash ~/.shared-hooks/pre_bash.sh").is_some());
        assert_eq!(refusal("cp candidate.sh ~/.shared-hooks/pre_bash.sh"), None);
    }
    #[test]
    fn a_hook_bypass_on_commit_or_push_is_refused() {
        assert!(refusal("git commit --no-verify -m x").is_some());
        assert!(refusal("git push --no-verify").is_some());
        assert!(refusal("git commit -n -m x").is_some());
    }

    /// The command that destroyed uncommitted work, and the two that replace
    /// it.
    #[test]
    fn checkout_is_refused_and_its_replacements_are_named() {
        let found = refusal("git checkout 7978acf -- src/human/keyboard.ts").expect("a revert");
        assert!(found.contains("git switch"), "{found}");
        assert!(found.contains("git restore"), "{found}");
        assert_eq!(refusal("git switch main"), None);
        assert_eq!(
            refusal("git restore --source=HEAD --worktree src/a.ts"),
            None
        );
    }

    #[test]
    fn a_tool_authorship_trailer_is_refused() {
        let command = "git commit -m \"fix\" -m \"Co-Authored-By: Claude <noreply@anthropic.com>\"";
        assert!(refusal(command).is_some());
        assert_eq!(refusal("git commit -m fix"), None);
    }

    /// A flag that narrows a run takes a decision the operator owns.
    #[test]
    fn the_sampling_overrides_are_refused_by_name() {
        let found = refusal("wisent evaluate --limit 10").expect("a narrowed run");
        assert!(found.contains("--limit"), "{found}");
        assert_eq!(refusal("wisent evaluate"), None);
    }

    #[test]
    fn pinning_a_compute_job_to_one_provider_is_refused() {
        assert!(refusal("wc submit --pin-provider gcp job.yaml").is_some());
        assert!(refusal("wc submit --provider aws job.yaml").is_some());
        assert_eq!(refusal("wc submit job.yaml"), None);
    }
}
