//! Raw justificationRequirements passthrough support, split out of `main.rs`.
//!
//! JS passes requirement objects from `catalog-metadata.json`/`registry.json`
//! through verbatim (source key order, all fields — e.g. `title`). tama-core's
//! typed `JustificationRequirement` flattens unknown fields into a BTreeMap,
//! which reorders them, so `list_hooks`/`show_hook` re-serialize the
//! requirements from the raw source JSON with order preserved. Merge priority
//! mirrors buildCatalog: `docs.justificationRequirements ?? hook.justificationRequirements ?? []`
//! (evaluated at the hook's first registry occurrence).

mod requirements;

pub use requirements::{load_raw_requirements, HookOut};

use serde::ser::{SerializeMap, SerializeSeq, Serializer};
use serde::Serialize;

/// Order-preserving JSON value (the subset needed for registry/metadata
/// files). Numbers are stored as f64 and re-printed the JS way.
#[derive(Debug, Clone)]
pub enum JVal {
    Null,
    Bool(bool),
    Num(f64),
    Str(String),
    Arr(Vec<JVal>),
    Obj(Vec<(String, JVal)>),
}

impl JVal {
    pub fn get<'a>(&'a self, key: &str) -> Option<&'a JVal> {
        match self {
            JVal::Obj(entries) => entries.iter().find(|(k, _)| k == key).map(|(_, v)| v),
            _ => None,
        }
    }

    fn as_array(&self) -> Option<&[JVal]> {
        match self {
            JVal::Arr(items) => Some(items),
            _ => None,
        }
    }

    fn as_str(&self) -> Option<&str> {
        match self {
            JVal::Str(text) => Some(text),
            _ => None,
        }
    }
}

impl Serialize for JVal {
    fn serialize<S: Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        match self {
            JVal::Null => serializer.serialize_none(),
            JVal::Bool(flag) => serializer.serialize_bool(*flag),
            JVal::Num(float) => {
                // JS number printing for the magnitudes used in these files.
                if float.fract() == 0.0 && float.abs() < 1e15 {
                    serializer.serialize_i64(*float as i64)
                } else {
                    serializer.serialize_f64(*float)
                }
            }
            JVal::Str(text) => serializer.serialize_str(text),
            JVal::Arr(items) => {
                let mut seq = serializer.serialize_seq(Some(items.len()))?;
                for item in items {
                    seq.serialize_element(item)?;
                }
                seq.end()
            }
            JVal::Obj(entries) => {
                let mut map = serializer.serialize_map(Some(entries.len()))?;
                for (key, value) in entries {
                    map.serialize_entry(key, value)?;
                }
                map.end()
            }
        }
    }
}

/// Minimal JSON parser producing [`JVal`] with object key order preserved.
pub struct JParser<'a> {
    bytes: &'a [u8],
    pos: usize,
}

impl<'a> JParser<'a> {
    pub fn new(text: &'a str) -> Self {
        Self {
            bytes: text.as_bytes(),
            pos: Default::default(),
        }
    }

    fn peek(&self) -> Option<u8> {
        self.bytes.get(self.pos).copied()
    }

    fn skip_ws(&mut self) {
        while matches!(self.peek(), Some(b' ' | b'\t' | b'\n' | b'\r')) {
            self.pos += 1;
        }
    }

    fn expect(&mut self, byte: u8) -> Option<()> {
        if self.peek() == Some(byte) {
            self.pos += 1;
            Some(())
        } else {
            None
        }
    }

    pub fn value(&mut self) -> Option<JVal> {
        self.skip_ws();
        match self.peek()? {
            b'{' => self.object(),
            b'[' => self.array(),
            b'"' => self.string().map(JVal::Str),
            b't' => {
                self.literal(b"true")?;
                Some(JVal::Bool(true))
            }
            b'f' => {
                self.literal(b"false")?;
                Some(JVal::Bool(false))
            }
            b'n' => {
                self.literal(b"null")?;
                Some(JVal::Null)
            }
            _ => self.number(),
        }
    }

    fn literal(&mut self, text: &[u8]) -> Option<()> {
        if self.bytes.get(self.pos..self.pos + text.len())? == text {
            self.pos += text.len();
            Some(())
        } else {
            None
        }
    }

    fn number(&mut self) -> Option<JVal> {
        let start = self.pos;
        while matches!(
            self.peek(),
            Some(b'-' | b'+' | b'.' | b'e' | b'E' | b'0'..=b'9')
        ) {
            self.pos += 1;
        }
        let text = std::str::from_utf8(self.bytes.get(start..self.pos)?).ok()?;
        text.parse::<f64>().ok().map(JVal::Num)
    }

    fn string(&mut self) -> Option<String> {
        self.expect(b'"')?;
        let mut out = String::new();
        loop {
            match self.peek()? {
                b'"' => {
                    self.pos += 1;
                    return Some(out);
                }
                b'\\' => {
                    self.pos += 1;
                    match self.peek()? {
                        b'"' => out.push('"'),
                        b'\\' => out.push('\\'),
                        b'/' => out.push('/'),
                        b'b' => out.push('\u{8}'),
                        b'f' => out.push('\u{c}'),
                        b'n' => out.push('\n'),
                        b'r' => out.push('\r'),
                        b't' => out.push('\t'),
                        b'u' => {
                            self.pos += 1;
                            let first = self.hex4()?;
                            let code = if (0xD800..0xDC00).contains(&first) {
                                // surrogate pair
                                if self.bytes.get(self.pos..self.pos + 2) == Some(b"\\u") {
                                    self.pos += 2;
                                    let second = self.hex4()?;
                                    0x10000 + ((first - 0xD800) << 10) + second.wrapping_sub(0xDC00)
                                } else {
                                    0xFFFD
                                }
                            } else {
                                first
                            };
                            out.push(char::from_u32(code).unwrap_or('\u{FFFD}'));
                            continue;
                        }
                        other => out.push(other as char),
                    }
                    self.pos += 1;
                }
                _ => {
                    // copy one UTF-8 encoded char verbatim
                    let start = self.pos;
                    self.pos += 1;
                    while self.pos < self.bytes.len() && (self.bytes[self.pos] & 0xC0) == 0x80 {
                        self.pos += 1;
                    }
                    out.push_str(std::str::from_utf8(self.bytes.get(start..self.pos)?).ok()?);
                }
            }
        }
    }

    fn hex4(&mut self) -> Option<u32> {
        let hex = self.bytes.get(self.pos..self.pos + 4)?;
        self.pos += 4;
        u32::from_str_radix(std::str::from_utf8(hex).ok()?, 16).ok()
    }

    fn object(&mut self) -> Option<JVal> {
        self.expect(b'{')?;
        let mut entries = Vec::new();
        self.skip_ws();
        if self.peek() == Some(b'}') {
            self.pos += 1;
            return Some(JVal::Obj(entries));
        }
        loop {
            self.skip_ws();
            let key = self.string()?;
            self.skip_ws();
            self.expect(b':')?;
            let value = self.value()?;
            entries.push((key, value));
            self.skip_ws();
            match self.peek()? {
                b',' => self.pos += 1,
                b'}' => {
                    self.pos += 1;
                    return Some(JVal::Obj(entries));
                }
                _ => return None,
            }
        }
    }

    fn array(&mut self) -> Option<JVal> {
        self.expect(b'[')?;
        let mut items = Vec::new();
        self.skip_ws();
        if self.peek() == Some(b']') {
            self.pos += 1;
            return Some(JVal::Arr(items));
        }
        loop {
            let value = self.value()?;
            items.push(value);
            self.skip_ws();
            match self.peek()? {
                b',' => self.pos += 1,
                b']' => {
                    self.pos += 1;
                    return Some(JVal::Arr(items));
                }
                _ => return None,
            }
        }
    }
}
