//! `tama copies` against real repositories: one story per case.
//!
//! Every case drives the built binary over the fixture layout and then reads
//! the filesystem, because the claim this command makes is about directories
//! that are gone or still there — stdout is the supporting evidence, never
//! the only one.

mod copies_fixture;
#[path = "copies/dependencies.rs"]
mod dependencies;
#[path = "copies/history.rs"]
mod history;
#[path = "copies/recovery.rs"]
mod recovery;

use copies_fixture::{stderr, stdout, text, Fixture};

#[test]
fn http_removal_refuses_a_canonical_selection_then_removes_only_the_named_copy() {
    let fixture = Fixture::new("http-selection");
    let server = fixture.serve();
    let route = "/v1/copies/remove";
    let (status, refusal) = server.post(
        route,
        serde_json::json!({
            "roots": [fixture.root()],
            "only": [fixture.checkout()],
            "apply": true,
            "force": true
        }),
    );
    assert_eq!(status, 400, "{refusal}");
    assert_eq!(
        std::fs::read(fixture.checkout().join("file.txt")).unwrap(),
        b"one\n"
    );
    assert!(
        fixture.copy().is_dir(),
        "the refused request removed no copy"
    );
    let (status, result) = server.post(
        route,
        serde_json::json!({
            "roots": [fixture.root()],
            "only": [fixture.copy()],
            "apply": true
        }),
    );
    assert_eq!(status, 200, "{result}");
    assert_eq!(result["removed"], serde_json::json!([fixture.copy()]));
    assert!(!fixture.copy().exists());
    assert_eq!(
        std::fs::read(fixture.checkout().join("file.txt")).unwrap(),
        b"one\n"
    );
    assert_eq!(
        std::fs::read(fixture.lone().join("file.txt")).unwrap(),
        b"one\n"
    );
}

#[test]
fn the_named_root_is_never_a_copy_of_itself() {
    let fixture = Fixture::new("root-itself");
    // Naming one repository as the root: its own checkout is the original,
    // and the clone nested inside it is the copy. The loopback route caught
    // this the other way round first, offering the root for deletion.
    let listed = fixture.tama(&[
        "copies",
        "list",
        "--root",
        &text(fixture.checkout()),
        "--json",
    ]);
    assert!(listed.status.success(), "{}", stderr(&listed));
    let document: serde_json::Value =
        serde_json::from_str(&stdout(&listed)).expect("the document is JSON");
    let copies = document["copies"]
        .as_array()
        .expect("copies is an array")
        .iter()
        .map(|copy| copy["path"].as_str().unwrap_or_default().to_string())
        .collect::<Vec<String>>();
    assert!(
        !copies.contains(&text(fixture.checkout())),
        "the root is not a copy: {copies:?}"
    );
    assert!(
        copies.contains(&text(fixture.copy())),
        "the clone nested in the root is: {copies:?}"
    );
    assert_eq!(
        document["copies"][0]["owner"].as_str(),
        Some(text(fixture.checkout()).as_str()),
        "and it is owned by the root: {document}"
    );
}

#[test]
fn preview_removes_nothing() {
    let fixture = Fixture::new("preview");
    let previewed = fixture.tama(&["copies", "remove", "--root", &fixture.root()]);
    assert!(previewed.status.success(), "{}", stderr(&previewed));
    assert!(fixture.copy().is_dir(), "a preview deletes nothing");
    assert!(fixture.lone().is_dir(), "a preview deletes nothing");
}

#[test]
fn apply_removes_the_copy_and_keeps_the_checkout() {
    let fixture = Fixture::new("apply");
    // The sole-checkout clone would refuse the whole pass, and the pass is
    // all-or-nothing, so it is spared by name.
    let applied = fixture.tama(&[
        "copies",
        "remove",
        "--root",
        &fixture.root(),
        "--except",
        &text(fixture.lone()),
        "--apply",
    ]);
    assert!(applied.status.success(), "{}", stderr(&applied));
    assert!(!fixture.copy().exists(), "the copy is gone");
    assert!(
        fixture.checkout().join(".git").is_dir(),
        "the canonical checkout survives"
    );
    assert!(fixture.lone().is_dir(), "the excepted clone survives");
}

#[test]
fn uncommitted_changes_refuse_the_pass() {
    let fixture = Fixture::new("dirty");
    fixture.dirty(&fixture.copy());
    let refused = fixture.tama(&[
        "copies",
        "remove",
        "--root",
        &fixture.root(),
        "--except",
        &text(fixture.lone()),
        "--apply",
    ]);
    assert_eq!(refused.status.code(), Some(1));
    assert!(fixture.copy().is_dir(), "a refused pass deletes nothing");
}

#[test]
fn commits_absent_from_every_remote_refuse_the_pass() {
    let fixture = Fixture::new("unpushed");
    fixture.commit_locally(&fixture.copy());
    let refused = fixture.tama(&[
        "copies",
        "remove",
        "--root",
        &fixture.root(),
        "--except",
        &text(fixture.lone()),
        "--apply",
    ]);
    assert_eq!(refused.status.code(), Some(1));
    assert!(fixture.copy().is_dir(), "a refused pass deletes nothing");
}

#[test]
fn a_sole_checkout_is_refused_until_the_operator_names_it() {
    let fixture = Fixture::new("lone");
    let refused = fixture.tama(&["copies", "remove", "--root", &fixture.root(), "--apply"]);
    assert_eq!(refused.status.code(), Some(1));
    assert!(fixture.lone().is_dir(), "a refused pass deletes nothing");

    let named = fixture.tama(&[
        "copies",
        "remove",
        "--root",
        &fixture.root(),
        "--only",
        &text(fixture.lone()),
        "--apply",
    ]);
    assert!(named.status.success(), "{}", stderr(&named));
    assert!(!fixture.lone().exists(), "the named clone is gone");
    assert!(
        fixture.copy().is_dir(),
        "narrowing left the other copy alone"
    );
}

#[test]
fn naming_a_dirty_sole_checkout_still_refuses() {
    let fixture = Fixture::new("named-dirty");
    fixture.dirty(&fixture.lone());
    let refused = fixture.tama(&[
        "copies",
        "remove",
        "--root",
        &fixture.root(),
        "--only",
        &text(fixture.lone()),
        "--apply",
    ]);
    assert_eq!(refused.status.code(), Some(1));
    assert!(fixture.lone().is_dir(), "a refused pass deletes nothing");
}

#[test]
fn an_unknown_only_path_is_a_usage_refusal() {
    let fixture = Fixture::new("unknown-only");
    let refused = fixture.tama(&[
        "copies",
        "remove",
        "--root",
        &fixture.root(),
        "--only",
        &text(fixture.base.join("tree/absent")),
        "--apply",
    ]);
    assert_eq!(refused.status.code(), Some(2));
    assert!(fixture.copy().is_dir(), "a usage refusal deletes nothing");
}

#[test]
fn a_linked_worktree_is_crossed_not_removed() {
    let fixture = Fixture::new("worktree");
    let worktree = fixture.base.join("tree/repo/vendor/wt");
    fixture.git(
        &fixture.checkout(),
        &["worktree", "add", "-q", "-b", "wt", &text(worktree.clone())],
    );
    let listed = fixture.tama(&["copies", "list", "--root", &fixture.root(), "--json"]);
    assert!(listed.status.success(), "{}", stderr(&listed));
    let document: serde_json::Value =
        serde_json::from_str(&stdout(&listed)).expect("the document is JSON");
    let crossed = document["linkedWorktrees"]
        .as_array()
        .expect("linkedWorktrees is an array");
    assert_eq!(crossed.len(), 1, "{document}");
    assert!(
        document["copies"]
            .as_array()
            .expect("copies is an array")
            .iter()
            .all(|copy| copy["path"] != crossed[0]),
        "a linked worktree is never a copies candidate: {document}"
    );
    assert!(worktree.is_dir(), "listing removes nothing");
}

#[test]
fn copies_in_separate_roots_find_the_canonical_checkout() {
    let fixture = Fixture::new("separate-roots");
    let cache_root = fixture.base.join("cache");
    let dependency = cache_root.join("build/dependency");
    std::fs::create_dir_all(dependency.parent().unwrap()).unwrap();
    std::fs::rename(fixture.copy(), &dependency).unwrap();
    let path = text(dependency.clone());
    let listed = fixture.tama(&[
        "copies",
        "list",
        "--root",
        &text(cache_root.clone()),
        "--root",
        &fixture.root(),
        "--json",
    ]);
    assert!(listed.status.success(), "{}", stderr(&listed));
    let document: serde_json::Value = serde_json::from_str(&stdout(&listed)).unwrap();
    let row = document["copies"]
        .as_array()
        .unwrap()
        .iter()
        .find(|row| row["path"] == path)
        .expect("dependency under the first root");
    assert_eq!(row["owner"], text(fixture.checkout()));

    let removed = fixture.tama(&[
        "copies",
        "remove",
        "--root",
        &text(cache_root),
        "--root",
        &fixture.root(),
        "--except",
        &text(fixture.lone()),
        "--apply",
        "--json",
    ]);
    assert!(removed.status.success(), "{}", stderr(&removed));
    assert!(!dependency.exists());
    assert!(fixture.checkout().join(".git").is_dir());
    assert!(fixture.lone().is_dir());
}
