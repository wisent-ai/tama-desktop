//! Logic for `tama-block-inline-execution`, registry hook
//! `block-inline-execution`: executable logic lives in a checked-in file that
//! can be reviewed, rerun and diffed — never in a command-line argument.
//!
//! Three ways a payload runs an inline program, and all three are refused:
//!
//!   * a tool whose whole purpose is inline execution — the evaluator, the
//!     notebook, the JavaScript kernel;
//!   * a tool that takes a program as an argument: a browser `run`, a
//!     debugger `evaluate`, or a write aimed at one of their devices;
//!   * a shell command carrying an interpreter program, a here-document, a
//!     process substitution, an `awk` or `jq` filter, or shell control flow.
//!
//! The exit status is Python's `os.EX_NOPERM`, which is what the runners on
//! this machine already read as a refusal.

mod patterns;

use serde_json::Value;
use tama_hooks::session_record::read_payload;

use crate::ports::pyvalue::first_truthy_py_str;
use crate::ports::shell_text;

use crate::ports::tool_vocabulary::{COMMAND_KEYS, HUB_TOOLS, INPUT_KEYS};

const TOOL_KEYS: &[&str] = &["tool_name", "name", "tool"];
const NESTED_KEY: &str = "tool";
const PATH_KEY: &str = "path";
const CONTENT_KEY: &str = "content";
const ACTION_KEY: &str = "action";

const OPERATION_KEY: &str = "op";
const APPLICATION_KEY: &str = "application";
const ARGS_KEY: &str = "args";
const START_OPERATION: &str = "start";
const RUN_ACTION: &str = "run";
const EVALUATE_ACTION: &str = "evaluate";
const ALWAYS_INLINE_TOOLS: &[&str] = &[
    "eval",
    "functions.eval",
    "notebook",
    "functions.notebook",
    "node_repl",
    "node_repl/js",
    "mcp__node_repl_js",
];
const WRITE_TOOLS: &[&str] = &["write", "functions.write"];
const BROWSER_TOOLS: &[&str] = &["browser", "functions.browser"];
const DEBUG_TOOLS: &[&str] = &["debug", "functions.debug"];

const NODE_REPL_DEVICE: &str = "xd://mcp__node_repl_js";
const BROWSER_DEVICE: &str = "xd://browser";
const DEBUG_DEVICE: &str = "xd://debug";
const REFUSAL: &str = concat!(
    "BLOCKED: inline code execution is forbidden. ",
    "Put executable logic in a checked-in reusable file and run that file. ",
    "Detected: ",
);
/// `os.EX_NOPERM`.
const REFUSAL_STATUS_TEXT: &str = "77";

fn refusal_status() -> i32 {
    REFUSAL_STATUS_TEXT.parse().unwrap_or_default()
}

fn tool_of(payload: &Value) -> String {
    let direct = payload
        .get(TOOL_KEYS[0])
        .or_else(|| payload.get(TOOL_KEYS[1]))
        .or_else(|| payload.get(TOOL_KEYS[2]));
    let text = match direct {
        Some(Value::Object(nested)) => nested
            .get("name")
            .or_else(|| nested.get("tool_name"))
            .and_then(Value::as_str)
            .unwrap_or_default()
            .to_string(),
        Some(Value::String(name)) => name.clone(),
        _ => String::new(),
    };
    text.trim().to_lowercase()
}

fn input_of(payload: &Value) -> Value {
    let direct = INPUT_KEYS
        .iter()
        .filter_map(|key| payload.get(*key))
        .find(|value| value.is_object());
    if let Some(found) = direct {
        return found.clone();
    }
    let nested = payload.get(NESTED_KEY).filter(|value| value.is_object());
    let inner = nested
        .and_then(|value| {
            value
                .get("input")
                .or_else(|| value.get("tool_input"))
                .filter(|inner| inner.is_object())
        })
        .cloned();
    inner.unwrap_or_else(|| Value::Object(Default::default()))
}

/// A device write carries its arguments as JSON, in an object or in a string.
fn device_content(value: Option<&Value>) -> Value {
    match value {
        Some(Value::Object(map)) => Value::Object(map.clone()),
        Some(Value::String(text)) => serde_json::from_str::<Value>(text)
            .ok()
            .filter(Value::is_object)
            .unwrap_or_else(|| Value::Object(Default::default())),
        _ => Value::Object(Default::default()),
    }
}

fn text(value: &Value, key: &str) -> String {
    value
        .get(key)
        .and_then(Value::as_str)
        .unwrap_or_default()
        .to_lowercase()
}

/// `[.application, (.args // [])[]] | join(" ")` for a supervised process.
fn process_command(input: &Value) -> String {
    let application = input
        .get(APPLICATION_KEY)
        .and_then(Value::as_str)
        .unwrap_or_default()
        .to_string();
    let mut parts = vec![application];
    if let Some(Value::Array(args)) = input.get(ARGS_KEY) {
        parts.extend(args.iter().map(|arg| match arg {
            Value::String(value) => value.clone(),
            other => other.to_string(),
        }));
    }
    parts.join(" ").trim().to_string()
}

fn command_text(tool: &str, input: &Value) -> String {
    let direct = first_truthy_py_str(input, COMMAND_KEYS);
    if !direct.is_empty() {
        return direct;
    }
    match HUB_TOOLS.contains(&tool) && text(input, OPERATION_KEY) == START_OPERATION {
        true => process_command(input),
        false => String::new(),
    }
}

/// Why this payload is an inline program, if it is one.
pub fn inline_execution_reason(payload: &Value) -> Option<String> {
    let tool = tool_of(payload);
    let input = input_of(payload);

    if ALWAYS_INLINE_TOOLS.contains(&tool.as_str()) {
        return Some(format!("inline execution tool: {tool}"));
    }

    let action = text(&input, ACTION_KEY);
    if BROWSER_TOOLS.contains(&tool.as_str()) && action == RUN_ACTION {
        return Some("inline JavaScript in browser run".to_string());
    }
    if DEBUG_TOOLS.contains(&tool.as_str()) && action == EVALUATE_ACTION {
        return Some("inline debugger evaluation".to_string());
    }

    if WRITE_TOOLS.contains(&tool.as_str()) {
        let path = input
            .get(PATH_KEY)
            .and_then(Value::as_str)
            .unwrap_or_default();
        if path == NODE_REPL_DEVICE {
            return Some("inline JavaScript in the Node REPL device".to_string());
        }
        let device = device_content(input.get(CONTENT_KEY));
        let device_action = text(&device, ACTION_KEY);
        if path == BROWSER_DEVICE && device_action == RUN_ACTION {
            return Some("inline JavaScript in the browser device".to_string());
        }
        if path == DEBUG_DEVICE && device_action == EVALUATE_ACTION {
            return Some("inline debugger evaluation through the debug device".to_string());
        }
    }

    let command = command_text(&tool, &input);
    if command.is_empty() {
        return None;
    }
    // Quoted text is an argument: `printf 'python3 -c x' > note.txt` runs no
    // Python, and refusing it taught nobody anything. An interpreter's own
    // quoted program is unwrapped by the same reader, so smuggling a loop
    // into `bash -c '…'` is still a loop.
    let acting = shell_text::effective_command(&command);
    if patterns::CONTROL_FLOW.is_match(&acting) {
        return Some("inline shell control flow in a command".to_string());
    }
    let inline = patterns::PROGRAMS
        .iter()
        .any(|pattern| pattern.is_match(&acting))
        || patterns::jq_runs_an_inline_program(&acting);
    match inline {
        true => Some("inline interpreter program in a command".to_string()),
        false => None,
    }
}

pub fn run() {
    let Some(reason) = inline_execution_reason(&read_payload()) else {
        return;
    };
    eprintln!("{REFUSAL}{reason}");
    std::process::exit(refusal_status());
}

#[cfg(test)]
mod tests {
    use super::inline_execution_reason;
    use serde_json::json;

    fn bash(command: &str) -> serde_json::Value {
        json!({ "tool_name": "bash", "tool_input": { "command": command } })
    }

    #[test]
    fn an_evaluator_is_inline_by_definition() {
        let reason = inline_execution_reason(&json!({ "tool_name": "eval" }))
            .expect("the evaluator runs inline code");
        assert!(reason.contains("inline execution tool"), "{reason}");
    }

    #[test]
    fn an_inline_interpreter_program_is_named_as_such() {
        let reason = inline_execution_reason(&bash("python3 -c 'print(1)'"))
            .expect("a program on the command line");
        assert_eq!(reason, "inline interpreter program in a command");
    }

    #[test]
    fn shell_control_flow_is_named_separately() {
        let reason =
            inline_execution_reason(&bash("for f in *; do echo $f; done")).expect("a loop");
        assert_eq!(reason, "inline shell control flow in a command");
    }

    /// The same program smuggled through a supervised process is the same
    /// program.
    #[test]
    fn a_supervised_process_is_read_as_a_command() {
        let payload = json!({
            "tool_name": "hub",
            "tool_input": { "op": "start", "application": "python3", "args": ["-c", "print(1)"] }
        });
        assert!(inline_execution_reason(&payload).is_some());
    }

    /// A device write is the same evaluation with a different address.
    #[test]
    fn a_device_write_is_read_as_execution() {
        let repl = json!({
            "tool_name": "write",
            "tool_input": { "path": "xd://mcp__node_repl_js", "content": "1 + 1" }
        });
        assert!(inline_execution_reason(&repl).is_some());
        let browser = json!({
            "tool_name": "write",
            "tool_input": {
                "path": "xd://browser",
                "content": "{\"action\":\"run\",\"code\":\"1\"}"
            }
        });
        assert!(inline_execution_reason(&browser).is_some());
    }

    #[test]
    fn running_a_checked_in_file_passes() {
        assert_eq!(
            inline_execution_reason(&bash("python3 scripts/report.py")),
            None
        );
        assert_eq!(inline_execution_reason(&bash("git status --short")), None);
        assert_eq!(
            inline_execution_reason(&json!({
                "tool_name": "write",
                "tool_input": { "path": "src/main.rs", "content": "fn main() {}" }
            })),
            None
        );
    }
}
