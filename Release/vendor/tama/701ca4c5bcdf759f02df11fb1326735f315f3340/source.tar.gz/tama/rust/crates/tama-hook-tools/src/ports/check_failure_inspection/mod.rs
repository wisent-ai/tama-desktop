//! `check-failure-inspection` — Rust port of
//! `shared-hooks/check_failure_inspection.py` (registry id
//! `check-failure-inspection`, `stop` event).
//!
//! Blocks a failure claim about a trajectory until the turn has actually Read
//! frames from that run. `main()` lives here; the detection it drives is split
//! across the `check_failure_inspection_*` siblings.
//!
//! Exit contract, preserved from the Python: although the hook is registered
//! on `stop`, it denies the PreToolUse way — banner on stderr, exit 2, nothing
//! on stdout — rather than emitting a `{"decision":"block"}` document.

use super::check_failure_inspection_claim::ClaimMatcher;
use super::check_failure_inspection_labels::referenced_labels;
use super::check_failure_inspection_recording::{frame_reads_satisfied, Recordings};
use super::check_failure_inspection_transcript::{read_file_paths, Transcript};
use regex::Regex;
use serde_json::Value;
use std::path::{Path, PathBuf};
use tama_hooks::session_record::{deny_tool_use, last_assistant_message, read_payload};

const DISABLE_VAR: &str = "CHECK_FAILURE_INSPECTION_DISABLED";
const DISABLE_VALUE: &str = "1";
const HOME_VAR: &str = "HOME";
/// `Path(os.environ.get("HOME", "/tmp"))`.
const FALLBACK_HOME: &str = "/tmp";
/// The legacy `inspect_required.json` scan reads `lines[-240:]`.
const LEGACY_LOOKBACK_TEXT: &str = "240";
/// `"=" * 60`.
const BANNER_WIDTH_TEXT: &str = "60";
const BANNER_CHAR: char = '=';
const BANNER_HEADLINE: &str =
    "  BLOCKED: failure claim without enough frame Reads (1 frame / second of recording)";
const BANNER_BYPASS: &str = "Bypass: CHECK_FAILURE_INSPECTION_DISABLED=1.";

fn legacy_lookback() -> usize {
    LEGACY_LOOKBACK_TEXT.parse().unwrap_or_default()
}

fn banner_width() -> usize {
    BANNER_WIDTH_TEXT.parse().unwrap_or_default()
}

/// An `inspect_required.json` registration whose `failure_state` was never Read.
struct LegacyMissing {
    label: String,
    sha8: String,
    failure_state: String,
}

/// A recording on disk the turn talked about without inspecting enough frames.
struct FrameMissing {
    label: String,
    sha8: String,
    recording: String,
    distinct: usize,
    required: usize,
}

pub fn run() {
    if std::env::var(DISABLE_VAR).as_deref() == Ok(DISABLE_VALUE) {
        return;
    }
    let payload = read_payload();
    // Claude Code sends the pending response as `last_assistant_message`; a
    // missing, non-string or blank one is not a claim.
    let response = match last_assistant_message(&payload) {
        Some(text) if !text.trim().is_empty() => text.to_string(),
        _ => return,
    };
    let matcher = ClaimMatcher::new();
    if !matcher.claims_failure(&response) {
        return;
    }

    let home = std::env::var(HOME_VAR)
        .map(PathBuf::from)
        .unwrap_or_else(|_| PathBuf::from(FALLBACK_HOME));
    let cwd = std::env::current_dir().unwrap_or_default();
    // Pin scanning to THIS session's transcript; mtime heuristics cannot
    // identify the active session when sessions run concurrently.
    let pinned = payload
        .get("transcript_path")
        .and_then(Value::as_str)
        .unwrap_or_default();
    let transcript = Transcript::locate(&home, &cwd, pinned);

    // Path A: legacy inspect_required.json registrations.
    let legacy = legacy_missing(&home, &transcript, &matcher, &response);

    // Path B: filesystem-discovered labels with recordings on disk.
    let mut recordings = Recordings::new(&cwd);
    let referenced = referenced_labels(
        &home,
        &cwd,
        &transcript,
        &matcher,
        &response,
        &mut recordings,
    );
    let mut frames = Vec::new();
    for label in referenced {
        let Some((sha8, recording)) = recordings.latest(&label) else {
            continue;
        };
        let (ok, distinct, required) = frame_reads_satisfied(&transcript, &label, &sha8);
        if ok {
            continue;
        }
        frames.push(FrameMissing {
            label,
            sha8,
            recording: recording
                .file_name()
                .unwrap_or_default()
                .to_string_lossy()
                .to_string(),
            distinct,
            required,
        });
    }

    if legacy.is_empty() && frames.is_empty() {
        return;
    }
    deny_tool_use(&banner(&legacy, &frames));
}

/// Registrations in `inspect_required.json` that the response claims failure
/// about and whose `failure_state` artifact this turn never Read.
fn legacy_missing(
    home: &Path,
    transcript: &Transcript,
    matcher: &ClaimMatcher,
    response: &str,
) -> Vec<LegacyMissing> {
    let state = home
        .join(".shared-hooks")
        .join("state")
        .join("inspect_required.json");
    if !state.is_file() {
        return Vec::new();
    }
    let data = std::fs::read_to_string(&state)
        .ok()
        .and_then(|text| serde_json::from_str::<Value>(&text).ok())
        .unwrap_or(Value::Null);
    let Some(entries) = data.as_object() else {
        return Vec::new();
    };
    let reads = read_file_paths(transcript.tail(legacy_lookback()));
    let mut missing = Vec::new();
    for (label, info) in entries {
        if !matcher.label_in_response(label, response) {
            continue;
        }
        let sha8 = info.get("sha8").and_then(Value::as_str).unwrap_or_default();
        let failure_state = info
            .get("failure_state")
            .and_then(Value::as_str)
            .unwrap_or_default();
        if sha8.is_empty() || failure_state.is_empty() || !Path::new(failure_state).is_file() {
            continue;
        }
        let pattern = super::failure_artefacts::failure_state_pattern(label, sha8);
        let Ok(artifact) = Regex::new(&pattern) else {
            continue;
        };
        if reads.iter().any(|read| artifact.is_match(read)) {
            continue;
        }
        missing.push(LegacyMissing {
            label: label.clone(),
            sha8: sha8.to_string(),
            failure_state: failure_state.to_string(),
        });
    }
    missing
}

fn banner(legacy: &[LegacyMissing], frames: &[FrameMissing]) -> String {
    let rule = BANNER_CHAR.to_string().repeat(banner_width());
    let mut lines = vec![rule.clone(), BANNER_HEADLINE.to_string(), rule];
    for entry in legacy {
        lines.push(format!(
            "  trajectory '{}' (sha8={})",
            entry.label, entry.sha8
        ));
        lines.push(format!(
            "    Read {} before claiming what made the run fail.",
            entry.failure_state
        ));
    }
    for entry in frames {
        lines.push(format!(
            "  trajectory '{}' — latest {} (sha8={})",
            entry.label, entry.recording, entry.sha8
        ));
        lines.push(format!(
            "    Read {}/{} required frames so far.",
            entry.distinct, entry.required
        ));
        lines.push(format!(
            "    Read ~/.weles/runs/{}/frame_{}_*.png (need {} distinct paths) OR run",
            entry.label, entry.sha8, entry.required
        ));
        lines.push(format!(
            "      $HOME/.shared-hooks/inspect_trajectory.sh {}",
            entry.label
        ));
    }
    lines.push(String::new());
    lines.push(BANNER_BYPASS.to_string());
    lines.join("\n")
}
