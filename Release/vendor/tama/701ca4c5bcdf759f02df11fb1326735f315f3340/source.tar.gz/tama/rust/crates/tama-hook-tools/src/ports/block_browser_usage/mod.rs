//! Logic for `tama-block-browser-usage`, registry hook
//! `block-browser-usage`: no browser is driven from an agent session.
//!
//! A browser runs through Weles, and its runtime executes on a Stado target
//! carrying a Weles placement policy. Everything else is direct use: a
//! browser tool, a mounted `xd://browser` device, or browser control hidden
//! inside a general execution tool. Closing or inspecting a direct-browser tab
//! is still direct use.
//!
//! Three exemptions, each written after a real refusal:
//!
//!   * One non-compound, built-in Git operation is repository maintenance,
//!     even when the repository path contains `weles` or `browser`.
//!   * `weles-chromium` and `weles-firefox` are repository names, not
//!     runtimes: the checkouts holding Weles's patched browser sources.
//!     Only the name is neutralised, so a path *into* one of them — a browser
//!     built under its output directory — is still refused. Measured on
//!     2026-09-10: a compound `git -C <that repo> status` was refused, and so
//!     was recording a test justification that merely quoted the operator
//!     asking for this repair.
//!   * `tab.`, `page.` and `browser.` are a driver only when something is
//!     called on them. Matching them wherever a dot followed refused every
//!     English sentence ending on one of those words and every file called
//!     `page.js` or `<name>-tab.json`. Measured on 2026-09-10: a `git commit`
//!     whose message read "a documentation page." was refused.
//!   * A name inside a quoted argument or a here-document body is text, not a
//!     runtime. Measured on 2026-09-16: writing a repository's
//!     violations-ignore declaration was refused because the sentence
//!     explaining which upstream engine a patch series belongs to named that
//!     engine. The payload is read through the shared
//!     [`crate::ports::shell_text`] reader, which blanks quoted text, drops a
//!     body handed to a file, and keeps a body handed to an interpreter.
//!
//! The shell printed its refusal on stdout and failed with `false`; that is
//! kept, because it is the refusal the operator has been reading.

mod placement;
mod vocabulary;

use serde_json::Value;
use tama_hooks::session_record::read_payload;

use crate::ports::check_numeric_literals_payload::path_texts;
use crate::ports::pyvalue::first_truthy_py_str;
use crate::ports::shell_text;
use crate::ports::tool_vocabulary::{BASH_TOOLS, COMMAND_KEYS, EVAL_TOOLS, HUB_TOOLS, INPUT_KEYS};
use vocabulary::{
    refusal_status, APPLICATION_KEY, ARGS_KEY, BROWSER_DEVICE, BROWSER_RUNTIME,
    BROWSER_SOURCE_REPOSITORIES, BROWSER_TOOL, CODE_KEY, COMPOUND, NEUTRAL_NAME, OPERATION_KEYS,
    PATH_KEY, REFUSAL, REPL_DEVICE, SAFE_GIT, START_OPERATION, TOOL_KEYS, WELES_RUNTIME,
    WRITE_TOOLS,
};

fn input_of(payload: &Value) -> Value {
    INPUT_KEYS
        .iter()
        .filter_map(|key| payload.get(*key))
        .find(|value| value.is_object())
        .cloned()
        .unwrap_or_else(|| Value::Object(Default::default()))
}

fn every_string(input: &Value) -> String {
    path_texts(input)
        .into_iter()
        .map(|(_, text)| text)
        .collect::<Vec<_>>()
        .join("\n")
}

/// `[.application, (.args // [])[]] | join("\n")`.
fn process_text(input: &Value) -> String {
    let mut parts: Vec<String> = Vec::new();
    if let Some(Value::String(application)) = input.get(APPLICATION_KEY) {
        parts.push(application.clone());
    }
    if let Some(Value::Array(args)) = input.get(ARGS_KEY) {
        for arg in args {
            if let Value::String(text) = arg {
                parts.push(text.clone());
            }
        }
    }
    parts.join("\n")
}

/// Whether this payload drives a browser outside Weles's placement.
pub fn is_direct_browser_use(payload: &Value) -> bool {
    let tool = first_truthy_py_str(payload, TOOL_KEYS).to_lowercase();
    let input = input_of(payload);
    let path = first_truthy_py_str(&input, &[PATH_KEY]).to_lowercase();
    if BROWSER_TOOL.is_match(&tool) || BROWSER_DEVICE.is_match(&path) {
        return true;
    }

    // What the call can actually run: quoted text blanked, here-document
    // bodies dropped unless an interpreter receives them, and an
    // interpreter's quoted program read as a command of its own.
    let command = first_truthy_py_str(&input, COMMAND_KEYS).to_lowercase();
    let executable = match tool.as_str() {
        found if BASH_TOOLS.contains(&found) => shell_text::effective_command(&command),
        found if EVAL_TOOLS.contains(&found) => {
            shell_text::effective_command(&first_truthy_py_str(&input, &[CODE_KEY]).to_lowercase())
        }
        found if HUB_TOOLS.contains(&found) => {
            match first_truthy_py_str(&input, OPERATION_KEYS).to_lowercase() == START_OPERATION {
                true => process_text(&input).to_lowercase(),
                false => String::new(),
            }
        }
        found if WRITE_TOOLS.contains(&found) => match REPL_DEVICE.is_match(&path) {
            true => every_string(&input).to_lowercase(),
            false => String::new(),
        },
        _ => String::new(),
    };
    if executable.is_empty() {
        return false;
    }

    let is_bash = BASH_TOOLS.contains(&tool.as_str());
    if is_bash && SAFE_GIT.is_match(&command) && !COMPOUND.is_match(&command) {
        return false;
    }

    let judged = BROWSER_SOURCE_REPOSITORIES
        .replace_all(&executable, NEUTRAL_NAME)
        .into_owned();
    if !BROWSER_RUNTIME.is_match(&judged) && !WELES_RUNTIME.is_match(&judged) {
        return false;
    }
    if WELES_RUNTIME.is_match(&judged)
        && placement::allows_weles_runtime(&placement::registry_path(), &placement::current_host())
    {
        return false;
    }
    true
}

pub fn run() {
    if is_direct_browser_use(&read_payload()) {
        for line in REFUSAL {
            println!("{line}");
        }
        std::process::exit(refusal_status());
    }
}

#[cfg(test)]
mod tests {
    use super::is_direct_browser_use;
    use serde_json::json;

    fn bash(command: &str) -> serde_json::Value {
        json!({ "tool_name": "bash", "tool_input": { "command": command } })
    }

    #[test]
    fn a_browser_tool_is_direct_use() {
        assert!(is_direct_browser_use(&json!({ "tool_name": "browser" })));
        assert!(is_direct_browser_use(&json!({
            "tool_name": "write",
            "tool_input": { "path": "xd://mcp__browser" }
        })));
    }

    #[test]
    fn a_browser_runtime_inside_a_command_is_direct_use() {
        for command in [
            "chromium --headless https://example.com",
            "npx playwright test",
            "node -e \"await page.goto('https://x')\"",
        ] {
            assert!(is_direct_browser_use(&bash(command)), "{command}");
        }
    }
    /// Repository maintenance is not browser execution, and the exemption
    /// covers exactly one operation: chaining a second command onto it puts
    /// the whole text back under the runtime patterns.
    #[test]
    fn one_builtin_git_operation_passes() {
        assert!(!is_direct_browser_use(&bash(
            "git -C /repo/weles status --short"
        )));
        assert!(is_direct_browser_use(&bash(
            "git status && playwright test"
        )));
    }

    /// The declaration this gate refused on 2026-09-16: a here-document body
    /// written into a repository file, whose sentence named the upstream
    /// engine a patch series belongs to.
    #[test]
    fn a_here_document_written_into_a_file_is_not_browser_use() {
        let payload = concat!(
            "cat >> .tama/violations-ignore <<'DECLARE'\n",
            "# Each file is the output of git format-patch against upstream\n",
            "# Chromium and is read back by git am, in order.\n",
            "patches\n",
            "DECLARE"
        );

        assert!(!is_direct_browser_use(&bash(payload)), "{payload}");
    }

    /// A shell handed a here-document runs it, so that body is a command.
    #[test]
    fn a_here_document_handed_to_a_shell_is_browser_use() {
        let payload = "bash <<'END'\nchromium --headless https://example.com\nEND";

        assert!(is_direct_browser_use(&bash(payload)), "{payload}");
    }

    /// A sentence in a commit message reaches nothing.
    #[test]
    fn a_quoted_sentence_naming_a_runtime_is_not_browser_use() {
        let payload = "git commit -m \"docs: explain why chromium runs through Weles only\"";

        assert!(!is_direct_browser_use(&bash(payload)), "{payload}");
    }

    /// The two checkouts are names, not runtimes.
    #[test]
    fn the_browser_source_repositories_are_names() {
        assert!(!is_direct_browser_use(&bash(
            "cat /repo/weles-chromium/README.md"
        )));
        assert!(is_direct_browser_use(&bash(
            "/repo/weles-chromium/out/Default/chromium --headless"
        )));
    }

    /// The driver words are a driver only when something is called on them.
    #[test]
    fn prose_and_file_names_are_not_drivers() {
        assert!(!is_direct_browser_use(&bash(
            "git commit -m \"a documentation page.\""
        )));
        assert!(!is_direct_browser_use(&bash(
            "cat payloads/refuse-tab.json"
        )));
    }
}
