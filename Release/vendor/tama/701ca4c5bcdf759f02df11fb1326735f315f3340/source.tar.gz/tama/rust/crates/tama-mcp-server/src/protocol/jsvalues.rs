//! JS value semantics used by the tool handlers, split out of `main.rs`.

use serde_json::Value;

/// JS truthiness.
pub fn js_truthy(value: Option<&Value>) -> bool {
    match value {
        None | Some(Value::Null) => false,
        Some(Value::Bool(flag)) => *flag,
        Some(Value::Number(number)) => number
            .as_f64()
            .map(|f| f != 0.0 && !f.is_nan())
            .unwrap_or(false),
        Some(Value::String(text)) => !text.is_empty(),
        Some(Value::Array(_)) | Some(Value::Object(_)) => true,
    }
}

/// JS template-literal interpolation (`${value}`).
pub fn js_template(value: Option<&Value>) -> String {
    match value {
        None => "undefined".to_string(),
        Some(Value::Null) => "null".to_string(),
        Some(Value::Bool(flag)) => flag.to_string(),
        Some(Value::Number(number)) => js_number_to_string(number),
        Some(Value::String(text)) => text.clone(),
        // Array.prototype.toString: join(','), null/undefined elements empty.
        Some(Value::Array(items)) => items
            .iter()
            .map(|item| match item {
                Value::Null => String::new(),
                other => js_template(Some(other)),
            })
            .collect::<Vec<_>>()
            .join(","),
        Some(Value::Object(_)) => "[object Object]".to_string(),
    }
}

/// `String(number)` for the magnitudes that can appear in arguments.
fn js_number_to_string(number: &serde_json::Number) -> String {
    if let Some(int) = number.as_i64() {
        return int.to_string();
    }
    if let Some(uint) = number.as_u64() {
        return uint.to_string();
    }
    let float = number.as_f64().unwrap_or(f64::NAN);
    if float.is_nan() {
        return "NaN".to_string();
    }
    if float.is_infinite() {
        return if float > 0.0 { "Infinity" } else { "-Infinity" }.to_string();
    }
    if float.fract() == 0.0 && float.abs() < 1e21 {
        return format!("{}", float as i128);
    }
    // Exponential range: Rust `{:e}` matches JS digits; JS adds '+' for
    // positive exponents.
    let rendered = format!("{:e}", float);
    match rendered.split_once('e') {
        Some((mantissa, exponent)) if !exponent.starts_with('-') => {
            format!("{}e+{}", mantissa, exponent)
        }
        _ => rendered,
    }
}
