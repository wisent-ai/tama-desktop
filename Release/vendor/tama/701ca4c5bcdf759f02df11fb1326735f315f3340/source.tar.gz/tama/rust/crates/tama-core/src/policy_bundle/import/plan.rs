//! What an import would change: every file it would copy, leave alone or
//! drop, and every conflict that stops it.
//!
//! Split out of `policy_bundle.rs`, which had grown past the
//! three-hundred-line limit.

use std::collections::{BTreeMap, BTreeSet};
use std::path::Path;

use crate::Result;

use super::super::inspect::{file_state, files_in_existing_bundle};
use super::super::records::{
    BundleFileRecord, PolicyBundleConflict, PolicyBundleRecord, SelectedFile, Selection,
};
use super::super::safe_join;

/// A plan starts having counted nothing.
const NONE_YET: usize = 0;

/// The three counts an import reports, and the conflicts that would stop it.
pub(super) struct Plan {
    pub unchanged: usize,
    pub imported: usize,
    pub removed: usize,
    pub conflicts: Vec<PolicyBundleConflict>,
}

/// Compare the selected source against what the store already holds.
///
/// `replace` is the operator's explicit permission to overwrite a stored
/// definition or drop one the source no longer carries; without it either
/// case is a conflict rather than a silent change.
pub(super) fn plan(
    selection: &Selection,
    existing: Option<&PolicyBundleRecord>,
    bundle_root: &Path,
    replace: bool,
) -> Result<Plan> {
    let incoming: BTreeMap<&str, &SelectedFile> = selection
        .files
        .iter()
        .map(|file| (file.relative.as_str(), file))
        .collect();
    let previous: BTreeMap<&str, &BundleFileRecord> = existing
        .map(|bundle| {
            bundle
                .files
                .iter()
                .map(|file| (file.path.as_str(), file))
                .collect()
        })
        .unwrap_or_default();
    let mut conflicts = Vec::new();
    let mut unchanged = NONE_YET;
    let mut imported = NONE_YET;
    let mut removed = NONE_YET;

    for file in &selection.files {
        let current_state = file_state(&safe_join(bundle_root, &file.relative)?)?;
        let current_sha256 = current_state.as_ref().map(|(digest, _)| digest.clone());
        if current_state
            .as_ref()
            .is_some_and(|(digest, mode)| digest == &file.sha256 && *mode == file.mode)
        {
            unchanged += 1;
            continue;
        }
        if let Some(previous_file) = previous.get(file.relative.as_str()) {
            if current_state.as_ref().is_some_and(|(digest, mode)| {
                digest != &previous_file.sha256 || *mode != previous_file.mode
            }) {
                conflicts.push(PolicyBundleConflict {
                    path: file.relative.clone(),
                    reason: "stored definition has local content or mode changes".to_string(),
                    existing_sha256: current_sha256,
                    incoming_sha256: Some(file.sha256.clone()),
                });
                continue;
            }
        }
        if current_state.is_some() && !replace {
            conflicts.push(PolicyBundleConflict {
                path: file.relative.clone(),
                reason:
                    "stored definition content or mode differs; explicit replacement is required"
                        .to_string(),
                existing_sha256: current_sha256,
                incoming_sha256: Some(file.sha256.clone()),
            });
        } else {
            imported += 1;
        }
    }

    for (relative, previous_file) in &previous {
        if incoming.contains_key(relative) {
            continue;
        }
        let current_state = file_state(&safe_join(bundle_root, relative)?)?;
        let current_sha256 = current_state.as_ref().map(|(digest, _)| digest.clone());
        if current_state.is_none() {
            continue;
        }
        if current_state.as_ref().is_some_and(|(digest, mode)| {
            digest != &previous_file.sha256 || *mode != previous_file.mode
        }) {
            conflicts.push(PolicyBundleConflict {
                path: (*relative).to_string(),
                reason: "stored definition removed upstream has local content or mode changes"
                    .to_string(),
                existing_sha256: current_sha256,
                incoming_sha256: None,
            });
        } else if !replace {
            conflicts.push(PolicyBundleConflict {
                path: (*relative).to_string(),
                reason: "stored definition is absent from the selected source".to_string(),
                existing_sha256: current_sha256,
                incoming_sha256: None,
            });
        } else {
            removed += 1;
        }
    }

    let tracked: BTreeSet<&str> = previous.keys().copied().collect();
    for relative in files_in_existing_bundle(bundle_root)? {
        if tracked.contains(relative.as_str()) {
            continue;
        }
        conflicts.push(PolicyBundleConflict {
            path: relative,
            reason: "stored bundle contains an untracked file".to_string(),
            existing_sha256: None,
            incoming_sha256: None,
        });
    }

    Ok(Plan {
        unchanged,
        imported,
        removed,
        conflicts,
    })
}
