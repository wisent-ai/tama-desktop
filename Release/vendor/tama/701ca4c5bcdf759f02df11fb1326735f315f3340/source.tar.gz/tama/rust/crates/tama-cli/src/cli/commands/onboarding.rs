//! `tama onboarding`: the first-use walkthrough, and the policy bundle it
//! may adopt on the way in.
//!
//! Split out of `cli/commands.rs`, which had grown past the
//! three-hundred-line limit; the other command handlers stay there.

use std::path::Path;

use tama_core::policy_bundle::{import_policy_bundle, ImportPolicyBundleOptions};

use crate::cli::args::{arg_after, has, option_value};
use crate::cli::output::{print_policy_import, unwrap_or_exit};
use crate::EXIT_USAGE;

pub fn onboarding(argv: &[String], root: &Path) -> i32 {
    let source = arg_after(argv, "--policy-bundle").filter(|value| !value.starts_with("--"));
    if has(argv, "--policy-bundle") && source.is_none() {
        eprintln!("--policy-bundle requires a directory");
        return EXIT_USAGE;
    }
    if has(argv, "--replace") && source.is_none() {
        eprintln!("--replace requires --policy-bundle <dir>");
        return EXIT_USAGE;
    }
    let home = option_value(argv, "--home").filter(|value| !value.starts_with("--"));
    if has(argv, "--home") && home.is_none() {
        eprintln!("--home requires a directory");
        return EXIT_USAGE;
    }
    let allowed = [
        "onboarding",
        "--reset",
        "--policy-bundle",
        "--replace",
        "--home",
    ];
    for (index, argument) in argv.iter().enumerate().skip(1) {
        if (argv[index - 1] == "--policy-bundle" || argv[index - 1] == "--home")
            && !argument.starts_with("--")
        {
            continue;
        }
        if !allowed.contains(&argument.as_str()) {
            eprintln!("unknown onboarding option: {argument}");
            return EXIT_USAGE;
        }
    }
    let imported = source.as_ref().map(|source| {
        unwrap_or_exit(import_policy_bundle(ImportPolicyBundleOptions {
            source: Path::new(source),
            home: home.as_deref().map(Path::new),
            replace: has(argv, "--replace"),
        }))
    });
    if let Some(result) = &imported {
        print_policy_import(result, false);
        if result.status == "conflict" || result.status == "rejected" {
            return 1;
        }
    }
    if let Err(error) = crate::onboarding::run(root, has(argv, "--reset"), imported.as_ref()) {
        eprintln!("{error}");
        return 1;
    }
    0
}
