//! What the adaptive layer learns from a dispatch.
//!
//! The legacy per-provider runner recorded every block into the adaptive
//! layer: the causal episode record a later prompt is attributed against, the
//! decision frame, and the real payload in the replay corpus. The shared
//! runtime that the providers talk to now recorded none of it, and it also
//! never handed a prompt to the feedback bridge. Measured 2026-09-10 on a
//! machine driven only through the shared runtime: `~/.hooks-adaptive/corpus`
//! last changed on 2026-07-09 although hooks blocked many times a day,
//! `adaptive status` reported `contested=false` for all 69 hooks, `adaptive
//! queue` was empty, and `adaptive repair` refused every candidate for want of
//! labeled cases — so the documented route for repairing a hook the owner
//! questioned by name could not be walked at all, twice in one day.
//!
//! Two rules hold here. Feedback attribution may never change a verdict, so
//! every call is best-effort and its failure is silent. And the enforcement
//! state machine is fed nothing from this path: a block observed without the
//! run that closes it is half a signal, and half a signal must not be able to
//! weaken a hook. Outcomes and baselines stay with the runner that owns them.

use serde_json::Value;

use tama_adaptive::engine::load_engine;
use tama_adaptive::state::EpisodeBlockInput;
use tama_adaptive::telemetry::open_telemetry;

fn text(payload: &Value, keys: &[&str]) -> Option<String> {
    keys.iter()
        .find_map(|key| payload.get(*key))
        .and_then(Value::as_str)
        .map(str::to_owned)
        .filter(|value| !value.is_empty())
}

/// One refused tool call, as the adaptive layer needs to see it: the causal
/// episode record that names the hook and the session, the decision frame, and
/// the payload itself in that hook's replay corpus. A repair candidate is
/// validated against those payloads, so a corpus with no cases is the reason a
/// repair cannot be proposed.
pub(crate) fn block(event: &str, hook_id: Option<&Value>, reason: &str, payload: &Value) {
    let Some(hook_id) = hook_id.filter(|id| id.is_string()) else {
        return;
    };
    let id_text = hook_id.as_str().unwrap_or_default();
    if id_text.is_empty() {
        return;
    }
    let session_id = text(payload, &["session_id", "sessionId"]);
    let episode_id = text(payload, &["turn_id", "turnId"]);
    let engine = load_engine();
    let telemetry = open_telemetry(&engine.state_dir);
    let episode = engine.record_episode_block(&EpisodeBlockInput {
        hook_id: Some(id_text.to_owned()),
        session_id: session_id.clone(),
        episode_id: episode_id.clone(),
        reason: Some(reason.to_owned()),
    });
    telemetry.record(&serde_json::json!({
        "event": event,
        "id": id_text,
        "decision": "block",
        "reason": reason,
        "session_id": session_id,
        "episode_id": episode_id,
        "causalEpisodePersisted": episode.persisted,
        "runtime": "shared",
    }));
    telemetry.corpus_add(
        hook_id,
        payload,
        &serde_json::json!({
            "event": event,
            "reason": reason,
            "session_id": session_id,
            "episode_id": episode_id,
        }),
    );
    telemetry.close();
}

/// One owner prompt, handed to the feedback bridge. The bridge decides whether
/// it is an explicit correction of the blocks in that session's latest episode
/// — which labels their corpus cases and queues a repair — or recommendation
/// evidence only.
pub(crate) fn prompt(normalized: &str) {
    tama_adaptive::bridge::dispatch(normalized);
}
