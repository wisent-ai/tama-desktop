//! `tama-record-hook-metadata`, driven as the real binary against real files.
//!
//! The command closes the half of the documented hook-change contract that had
//! no tool: `register-hook.mjs` refuses a hook that `catalog-metadata.json`
//! does not describe, so a missing entry means the hook cannot be registered at
//! all. Every case below holds the command to what the file on disk looks like
//! afterwards, not to what it printed.
//!
//! The last case runs `--check` over every entry of the repository's real
//! catalogue with the values that entry already holds. That is the guarantee
//! the renderer reproduces the document instead of reformatting it, which is
//! what `serde_json` would do here: this crate builds it without
//! `preserve_order`, so its map sorts keys, and the real document is not sorted.

mod support;

use std::fs;

use support::{
    argv, fixture, refuses, run, stderr, stdout, CATALOG, EXIT_DIFFERS, EXIT_OK, REAL_CATALOG,
    RECORDED,
};

#[test]
fn a_new_entry_is_added_and_every_other_entry_keeps_its_bytes() {
    let catalog = fixture("added");
    let output = run(&argv(&[], &catalog.to_string_lossy(), "block-mid", ""));
    assert_eq!(output.status.code(), Some(EXIT_OK), "{}", stderr(&output));
    assert!(
        stdout(&output).contains("recorded block-mid"),
        "{}",
        stdout(&output)
    );
    let after = fs::read_to_string(&catalog).expect("read the catalogue");
    let expected = CATALOG.replace("  \"block-omega\"", &format!("{RECORDED}  \"block-omega\""));
    assert_eq!(after, expected, "only the new entry may appear");
}

#[test]
fn recording_the_same_entry_again_writes_nothing() {
    let catalog = fixture("idempotent");
    let arguments = argv(&[], &catalog.to_string_lossy(), "block-mid", "");
    run(&arguments);
    let bytes = fs::read(&catalog).expect("read the catalogue");
    let stamp = fs::metadata(&catalog)
        .and_then(|data| data.modified())
        .expect("modification time");

    let output = run(&arguments);
    assert_eq!(output.status.code(), Some(EXIT_OK), "{}", stderr(&output));
    let printed = stdout(&output);
    assert!(printed.contains("already records block-mid"), "{printed}");
    assert_eq!(
        fs::read(&catalog).expect("reread"),
        bytes,
        "the bytes changed"
    );
    assert_eq!(
        fs::metadata(&catalog)
            .and_then(|data| data.modified())
            .expect("modification time"),
        stamp,
        "the file was rewritten"
    );
}

#[test]
fn updating_an_entry_keeps_the_fields_the_command_does_not_own() {
    let catalog = fixture("extras");
    let output = run(&argv(&[], &catalog.to_string_lossy(), "block-omega", ""));
    assert_eq!(output.status.code(), Some(EXIT_OK), "{}", stderr(&output));
    let after = fs::read_to_string(&catalog).expect("read the catalogue");
    let rewritten = "\"why\": \"The limit the operator asked for.\"";
    assert!(
        after.contains(rewritten),
        "the managed field is rewritten:\n{after}"
    );
    assert!(
        after.contains("\"type\": \"requires_justification\""),
        "{after}"
    );
    assert!(
        after.contains("        \"title\": \"File justification\""),
        "the nested justification requirement survives:\n{after}"
    );
    assert!(
        after.contains("\"block-alpha\""),
        "the other entry survives"
    );
    assert!(after.ends_with("}\n"), "the trailing newline survives");
}

#[test]
fn check_refuses_an_absent_entry_and_accepts_a_matching_one() {
    let catalog = fixture("check");
    let path = catalog.to_string_lossy().into_owned();
    let checking = argv(&["--check"], &path, "block-mid", "");

    let absent = run(&checking);
    assert_eq!(
        absent.status.code(),
        Some(EXIT_DIFFERS),
        "{}",
        stderr(&absent)
    );
    assert_eq!(
        stderr(&absent),
        format!("{path} has no entry for block-mid")
    );
    assert_eq!(
        fs::read_to_string(&catalog).expect("read the catalogue"),
        CATALOG,
        "--check must not write"
    );

    run(&argv(&[], &path, "block-mid", ""));
    let matching = run(&checking);
    assert_eq!(
        matching.status.code(),
        Some(EXIT_OK),
        "{}",
        stderr(&matching)
    );
}

#[test]
fn check_names_the_field_that_differs() {
    let catalog = fixture("differs");
    let path = catalog.to_string_lossy().into_owned();
    let front = ["--check", "--description", "Second entry."];
    let output = run(&argv(&front, &path, "block-omega", "--description"));
    assert_eq!(
        output.status.code(),
        Some(EXIT_DIFFERS),
        "{}",
        stdout(&output)
    );
    let message = stderr(&output);
    assert!(
        message.starts_with(&format!("{path} records a different why for block-omega")),
        "{message}"
    );
    assert!(
        message.contains("Carries fields the command does not own."),
        "{message}"
    );
}

#[test]
fn a_missing_required_option_is_refused_by_name() {
    let catalog = fixture("missing-option");
    refuses(
        &argv(&[], &catalog.to_string_lossy(), "block-mid", "--why"),
        "--why is required",
    );
}

#[test]
fn an_unknown_option_is_refused() {
    let catalog = fixture("unknown-option");
    refuses(
        &argv(&["--force"], &catalog.to_string_lossy(), "block-mid", ""),
        "unknown option --force",
    );
}

#[test]
fn a_malformed_hook_id_is_refused() {
    let catalog = fixture("malformed-id");
    refuses(
        &argv(&[], &catalog.to_string_lossy(), "Block_Mid", ""),
        "hook id must be lowercase letters, digits and hyphens: Block_Mid",
    );
}

#[test]
fn a_missing_catalog_is_refused() {
    let absent = fixture("missing-catalog").with_file_name("absent.json");
    let path = absent.to_string_lossy().into_owned();
    refuses(
        &argv(&[], &path, "block-mid", ""),
        &format!("no catalog at {path}"),
    );
}

/// The renderer against the real document: every entry recording all five
/// fields, checked with the values it holds, must report no difference. An
/// entry the document leaves incomplete must be reported as differing in the
/// field it lacks, which is the state this command exists to complete.
#[test]
fn every_entry_of_the_real_catalogue_checks_clean() {
    const FIELDS: [[&str; 2]; 5] = [
        ["--status", "status"],
        ["--category", "category"],
        ["--description", "description"],
        ["--why", "why"],
        ["--side-effects", "sideEffects"],
    ];
    let text = fs::read_to_string(REAL_CATALOG).expect("read the real catalogue");
    let document: serde_json::Value = serde_json::from_str(&text).expect("parse it");
    let entries = document.as_object().expect("a JSON object");
    assert!(
        entries.len() > usize::from(true),
        "the catalogue has entries"
    );
    let mut incomplete: Vec<&str> = Vec::new();
    for (id, entry) in entries {
        let mut arguments = vec!["--check".to_string()];
        let mut absent: Option<&str> = None;
        for [option, field] in FIELDS {
            let value = entry.get(field).and_then(serde_json::Value::as_str);
            absent = absent.or_else(|| value.is_none().then_some(field));
            arguments.push(option.to_string());
            arguments.push(value.unwrap_or("not recorded").to_string());
        }
        arguments.push(REAL_CATALOG.to_string());
        arguments.push(id.to_string());
        let output = run(&arguments);
        let expected = if absent.is_some() {
            EXIT_DIFFERS
        } else {
            EXIT_OK
        };
        let message = stderr(&output);
        assert_eq!(output.status.code(), Some(expected), "{id}: {message}");
        if let Some(field) = absent {
            assert!(
                message.contains(&format!("a different {field}")),
                "{id}: {message}"
            );
            incomplete.push(id.as_str());
        }
    }
    let clean = entries.len() - incomplete.len();
    println!(
        "{clean} of {} check clean; incomplete: {incomplete:?}",
        entries.len()
    );
    assert_eq!(
        fs::read_to_string(REAL_CATALOG).expect("reread"),
        text,
        "--check must leave the real catalogue alone"
    );
}
