//! Unit tests for the capability normalization ports, moved from the tail of
//! the original `session_capability.rs`.

use serde_json::{json, Value};

use super::*;
use crate::jsutil;

fn base_capability() -> Value {
    json!({
        "schemaVersion": CAPABILITY_SCHEMA_VERSION,
        "issuedBy": "issuer",
        "nonce": "abc",
        "sessionId": "sess-1",
        "controlKey": "ck",
        "releaseId": "rel",
        "catalogChecksum": "sum",
        "lifetime": "current-session",
        "grants": [{ "tool": "Bash", "actions": ["Read", "read", "exec"] }],
    })
}

#[test]
fn normalizes_grants() {
    let grants = json!([
        { "tool": "Bash", "actions": ["Exec"] },
        { "tool": "bash", "actions": ["read"] },
        { "tool": "read" },
    ]);
    let out = normalize_capability_grants(&grants).unwrap();
    // "bash" grants merge into a sorted action union; sorted by tool name.
    assert_eq!(
        out,
        json!([{ "actions": ["exec", "read"], "tool": "bash" }, { "tool": "read" }])
    );
}

#[test]
fn wildcard_grant_wins() {
    let grants = json!([
        { "tool": "bash", "actions": ["exec"] },
        { "tool": "bash" },
    ]);
    let out = normalize_capability_grants(&grants).unwrap();
    assert_eq!(out, json!([{ "tool": "bash" }]));
}

#[test]
fn rejects_invalid_grants() {
    assert!(normalize_capability_grants(&json!([])).is_none());
    assert!(normalize_capability_grants(&json!({})).is_none());
    assert!(normalize_capability_grants(&json!([{ "tool": "1bad" }])).is_none());
    assert!(normalize_capability_grants(&json!([{ "tool": "ok", "actions": [] }])).is_none());
    assert!(normalize_capability_grants(&json!([{ "tool": "ok", "actions": ["BAD!"] }])).is_none());
}

#[test]
fn normalizes_capability() {
    let now = jsutil::now_millis();
    let cap = normalized_capability(
        &base_capability(),
        "sess-1",
        now,
        &CapabilityIdentity::default(),
    )
    .unwrap();
    assert_eq!(
        cap["grants"],
        json!([{ "actions": ["exec", "read"], "tool": "bash" }])
    );

    // Wrong session id.
    assert!(normalized_capability(
        &base_capability(),
        "other",
        now,
        &CapabilityIdentity::default()
    )
    .is_none());
    // Identity mismatch.
    assert!(normalized_capability(
        &base_capability(),
        "sess-1",
        now,
        &CapabilityIdentity {
            control_key: Some("different".into()),
            ..Default::default()
        }
    )
    .is_none());
}

#[test]
fn lifetimes() {
    let now = 1_700_000_000_000.0;
    let identity = CapabilityIdentity::default();

    let mut cap = base_capability();
    cap["lifetime"] = json!("expires-at");
    cap["expiresAt"] = json!("2030-01-01T00:00:00Z");
    let out = normalized_capability(&cap, "sess-1", now, &identity).unwrap();
    assert_eq!(out["expiresAt"], json!("2030-01-01T00:00:00.000Z"));

    // Expired.
    cap["expiresAt"] = json!("2020-01-01T00:00:00Z");
    assert!(normalized_capability(&cap, "sess-1", now, &identity).is_none());

    // single-use requires remainingUses === 1.
    let mut cap = base_capability();
    cap["lifetime"] = json!("single-use");
    assert!(normalized_capability(&cap, "sess-1", now, &identity).is_none());
    cap["remainingUses"] = json!(1);
    assert!(normalized_capability(&cap, "sess-1", now, &identity).is_some());
    cap["remainingUses"] = json!("1"); // string is not === 1
    assert!(normalized_capability(&cap, "sess-1", now, &identity).is_none());
}
