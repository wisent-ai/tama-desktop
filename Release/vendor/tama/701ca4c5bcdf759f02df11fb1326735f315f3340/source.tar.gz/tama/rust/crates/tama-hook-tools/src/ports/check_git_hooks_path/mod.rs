//! Port of `shared-hooks/check_git_hooks_path.py` (registry hook
//! `check-git-hooks-path`).
//!
//! Refuses `git commit`/`git push` from an agent shell when the worktree the
//! command targets has no usable `core.hooksPath`: unset, missing a required
//! hook, or holding one that is not executable.
//!
//! Divergences forced by the runtime, all noted rather than smoothed over:
//!   * The Python passes `timeout=5` to every `subprocess.run`. `std::process`
//!     has no timeout, so the `git` calls here run to completion; the hook
//!     registration already caps the whole process.
//!   * Python lets a `git` failure after the first call raise, which aborts the
//!     hook. Those calls only run once `git rev-parse` has already succeeded,
//!     so a failure there is unreachable; it degrades to an empty result.
//!   * `is_executable` swallows every `stat` error, where Python swallows only
//!     `FileNotFoundError`.

use std::os::unix::fs::MetadataExt;
use std::path::Path;
use std::process::Command;

use serde_json::Value;
use tama_hooks::session_record::{deny_tool_use, read_payload};

use super::python_stdlib::{expanduser, expandvars, one, realpath, shell_tokens};
use super::pyvalue::{first_truthy_py_str, py_str, truthy};

/// Matched against the raw `tool_name`, case-sensitively, exactly as Python's
/// `data.get("tool_name") not in SHELL_TOOL_NAMES` does.
const SHELL_TOOL_NAMES: &[&str] = &[
    "bash",
    "Bash",
    "exec_command",
    "functions.exec_command",
    "run_command",
    "run_package_script",
];
const REQUIRED_HOOKS: &[&str] = &["pre-commit", "pre-push"];
const TOOL_NAME_KEY: &str = "tool_name";
const TOOL_INPUT_KEY: &str = "tool_input";
const TOOL_KEY: &str = "tool";
const INPUT_KEY: &str = "input";
const RAW_EVENT_KEY: &str = "raw_event";
const CWD_KEY: &str = "cwd";
const PROJECT_DIR_KEY: &str = "project_dir";
const COMMAND_KEYS: &[&str] = &["command", "cmd"];
const GIT_PROGRAM: &str = "git";
const CD_PROGRAM: &str = "cd";
const AND_OPERATOR: &str = "&&";
const GIT_DIRECTORY_OPTION: &str = "-C";
const GIT_WRITE_SUBCOMMANDS: &[&str] = &["commit", "push"];
const INSIDE_WORK_TREE_ARGS: &[&str] = &["rev-parse", "--is-inside-work-tree"];
const TOPLEVEL_ARGS: &[&str] = &["rev-parse", "--show-toplevel"];
const HOOKS_PATH_ARGS: &[&str] = &["config", "--get", "core.hooksPath"];
const INSIDE_TRUE: &str = "true";
const HOOKSPATH_UNSET: &str = "git core.hooksPath is not configured for this worktree";

/// `cd <dir> && git …` is four tokens wide.
const CD_GIT_WINDOW_TEXT: &str = "4";
/// `stat.S_IXUSR`, the owner execute bit (octal 100).
const OWNER_EXEC_BIT_TEXT: &str = "64";

fn cd_git_window() -> usize {
    CD_GIT_WINDOW_TEXT.parse().unwrap_or_default()
}

fn owner_exec_bit() -> u32 {
    OWNER_EXEC_BIT_TEXT.parse().unwrap_or_default()
}

#[derive(Default)]
struct GitOutput {
    ok: bool,
    stdout: String,
}

fn git(cwd: &str, args: &[&str]) -> std::io::Result<GitOutput> {
    let output = Command::new(GIT_PROGRAM)
        .args(args)
        .current_dir(cwd)
        .output()?;
    Ok(GitOutput {
        ok: output.status.success(),
        stdout: String::from_utf8_lossy(&output.stdout).into_owned(),
    })
}

fn command_from(data: &Value) -> String {
    let nested = data.get(TOOL_KEY).and_then(|tool| tool.get(INPUT_KEY));
    let chosen = [data.get(TOOL_INPUT_KEY), nested]
        .into_iter()
        .flatten()
        .find(|value| truthy(value));
    let Some(value) = chosen else {
        return String::new();
    };
    if !value.is_object() {
        return py_str(value);
    }
    first_truthy_py_str(value, COMMAND_KEYS)
}

fn cwd_from(data: &Value) -> String {
    let raw_event = data.get(RAW_EVENT_KEY).filter(|value| value.is_object());
    let candidates = [
        data.get(CWD_KEY),
        raw_event.and_then(|event| event.get(CWD_KEY)),
        data.get(PROJECT_DIR_KEY),
    ];
    for candidate in candidates.into_iter().flatten() {
        if truthy(candidate) {
            return realpath(&expanduser(&py_str(candidate)));
        }
    }
    std::env::current_dir()
        .unwrap_or_default()
        .to_string_lossy()
        .into_owned()
}

/// `Path(token).name == "git"` — the basename, so `/usr/bin/git` counts.
fn is_git(token: &str) -> bool {
    Path::new(token).file_name().and_then(|name| name.to_str()) == Some(GIT_PROGRAM)
}

fn expands(value: &str, base: &str) -> String {
    let expanded = expanduser(&expandvars(value));
    if expanded.starts_with('/') {
        return realpath(&expanded);
    }
    realpath(&format!("{base}/{expanded}"))
}

/// The directory the `git` in this command line actually runs in: an explicit
/// `cd <dir> && git …`, then a `-C <dir>` reached before `commit`/`push`.
fn target_cwd(base: &str, command: &str) -> String {
    let tokens = shell_tokens(command);
    let width = cd_git_window();
    if width > usize::MIN {
        for window in tokens.windows(width) {
            if let [leader, directory, separator, program] = window {
                if leader == CD_PROGRAM && separator == AND_OPERATOR && is_git(program) {
                    return expands(directory, base);
                }
            }
        }
    }
    for (index, token) in tokens.iter().enumerate() {
        if !is_git(token) {
            continue;
        }
        let mut after = tokens[index..].iter();
        after.next();
        while let Some(current) = after.next() {
            if current == GIT_DIRECTORY_OPTION {
                if let Some(directory) = after.as_slice().first() {
                    return expands(directory, base);
                }
            }
            if GIT_WRITE_SUBCOMMANDS.contains(&current.as_str()) {
                break;
            }
        }
    }
    base.to_string()
}

fn mentions_git_commit_or_push(command: &str) -> bool {
    let tokens = shell_tokens(command);
    let mut rest = tokens.iter();
    while let Some(token) = rest.next() {
        if !is_git(token) {
            continue;
        }
        if rest
            .as_slice()
            .iter()
            .any(|later| GIT_WRITE_SUBCOMMANDS.contains(&later.as_str()))
        {
            return true;
        }
    }
    false
}

fn is_executable(path: &Path) -> bool {
    match std::fs::metadata(path) {
        Ok(metadata) => metadata.mode() & owner_exec_bit() > u32::MIN,
        Err(_) => false,
    }
}

/// `str(PurePosixPath(text))`: empty and `.` components dropped, `..` kept, and
/// a leading `//` (exactly two) preserved. Only the already-absolute
/// `core.hooksPath` reaches the banner unresolved, so only it needs this.
fn pure_path_text(text: &str) -> String {
    let mut leading = usize::MIN;
    if text.starts_with('/') {
        leading = one();
        if text.starts_with("//") && !text.starts_with("///") {
            leading = one() + one();
        }
    }
    let parts: Vec<&str> = text
        .split('/')
        .filter(|part| !part.is_empty() && *part != ".")
        .collect();
    let mut out = "/".repeat(leading);
    out.push_str(&parts.join("/"));
    if out.is_empty() {
        return ".".to_string();
    }
    out
}

/// The required hooks under `base` that fail `absent`. Returns owned names: an
/// explicit lifetime would desync the repository's numeric-literal guard, which
/// reads a lifetime tick as an opening quote.
fn missing_named(base: &Path, absent: impl Fn(&Path) -> bool) -> Vec<String> {
    REQUIRED_HOOKS
        .iter()
        .filter(|name| absent(&base.join(name)))
        .map(|name| name.to_string())
        .collect()
}

fn verify_hooks(cwd: &str) -> Option<String> {
    let inside = match git(cwd, INSIDE_WORK_TREE_ARGS) {
        Ok(result) => result,
        Err(error) => return Some(format!("cannot inspect git worktree at {cwd}: {error}")),
    };
    if !inside.ok || inside.stdout.trim() != INSIDE_TRUE {
        return None;
    }
    let root = git(cwd, TOPLEVEL_ARGS).unwrap_or_default();
    let hooks = git(cwd, HOOKS_PATH_ARGS).unwrap_or_default();
    let hooks_path = hooks.stdout.trim();
    if !hooks.ok || hooks_path.is_empty() {
        return Some(HOOKSPATH_UNSET.to_string());
    }

    let base_text = if hooks_path.starts_with('/') {
        pure_path_text(hooks_path)
    } else {
        let anchor = root.stdout.trim();
        let anchor = if anchor.is_empty() { cwd } else { anchor };
        realpath(&format!("{anchor}/{hooks_path}"))
    };
    let base = Path::new(&base_text);

    let missing = missing_named(base, |path| !path.exists());
    if !missing.is_empty() {
        let names = missing.join(", ");
        return Some(format!(
            "git hooksPath missing required hook(s): {names} in {base_text}"
        ));
    }
    let not_exec = missing_named(base, |path| !is_executable(path));
    if !not_exec.is_empty() {
        let names = not_exec.join(", ");
        return Some(format!(
            "git hooksPath has non-executable hook(s): {names} in {base_text}"
        ));
    }
    None
}

pub fn run() {
    let data = read_payload();
    let matches_shell = data
        .get(TOOL_NAME_KEY)
        .and_then(Value::as_str)
        .is_some_and(|name| SHELL_TOOL_NAMES.contains(&name));
    if !matches_shell {
        return;
    }
    let command = command_from(&data);
    if !mentions_git_commit_or_push(&command) {
        return;
    }
    let Some(reason) = verify_hooks(&target_cwd(&cwd_from(&data), &command)) else {
        return;
    };
    deny_tool_use(&format!(
        "BLOCKED: Git hooksPath is not ready for git commit/push.\n  reason: {reason}"
    ));
}
