//! The part of a shell command that can act.
//!
//! A verb inside quotes is an argument, not a command: `grep "install" .`
//! changes nothing, and `printf 'python3 -c x' > note.txt` runs no Python. So
//! quoted text is blanked before a gate reads the command — with one
//! exception, which is the whole reason this is a shared module: an
//! interpreter told to run a quoted program does execute that quote, so the
//! program is unwrapped and read as a command in its own right, to three
//! levels of nesting.
//!
//! Two gates learned this the same way. The consent guard refused a search
//! that quoted mutation words, and the inline-execution gate refused a
//! `printf` whose quoted text mentioned `python3 -c`. Neither command could
//! change or execute anything.
//!
//! The sibling `commands` answers the other half of the same question: where
//! one command ends and the next begins, which program each piece runs, and
//! which of its tokens are command words rather than sentences.

mod commands;
mod heredoc;

pub use commands::{
    awk_alternation, command_word, commands, eval_flag_alternation, inner_command,
    javascript_alternation, javascript_runtime_alternation, program, scripting_alternation,
    shell_alternation, shells, source_extension_alternation, wrapper_alternation,
};
pub use heredoc::split as heredoc_split;

use std::sync::LazyLock;

use regex::Regex;

use crate::ports::transport_common as common;

const BLANK: &str = " ";
const JOIN: &str = "\n";
const QUOTE_TRIM: &[char] = &['"', '\''];
const PROGRAM_GROUP: &str = "program";
/// Three levels is what a human would plausibly type, and each level is one
/// more quoting layer to get wrong.
const MAX_DEPTH: usize = 3;

pub static QUOTED: LazyLock<Regex> =
    LazyLock::new(|| common::compile("[\\x27][^\\x27]*[\\x27]|[\\x22][^\\x22]*[\\x22]"));

/// An interpreter handed a quoted program. The shells take `-c`, and the `c`
/// may be bundled with other letters: `bash -lc '…'` is the spelling every
/// wrapper script uses. The language runtimes take their own execute flag —
/// `python3 -c`, `node -e`, `node -p`, `ruby -e`, `perl -e`, `osascript -e`,
/// `bun -e`, `deno eval` — and that argument is a program just the same.
pub static INTERPRETER_ARGUMENT: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "\\b(?:",
        "(?:ba|z|k|a|da)?sh[[:space:]]+(?:-[a-zA-Z]+[[:space:]]+)*-[a-zA-Z]*c",
        "|(?:python3?|ruby|perl|osascript)[[:space:]]+(?:-[a-zA-Z]+[[:space:]]+)*-[ce]",
        "|(?:node|bun)[[:space:]]+(?:-[a-zA-Z]+[[:space:]]+)*(?:-e|-p|--eval|--print)",
        "|deno[[:space:]]+eval",
        ")[[:space:]]+",
        "(?P<program>[\\x27][^\\x27]*[\\x27]|[\\x22][^\\x22]*[\\x22])",
    ))
});

fn collect(command: &str, depth: usize, parts: &mut Vec<String>) {
    if depth >= MAX_DEPTH {
        return;
    }
    for caps in INTERPRETER_ARGUMENT.captures_iter(command) {
        let Some(program) = caps.name(PROGRAM_GROUP) else {
            continue;
        };
        let unquoted = program.as_str().trim_matches(QUOTE_TRIM);
        parts.push(QUOTED.replace_all(unquoted, BLANK).into_owned());
        collect(unquoted, depth + 1, parts);
    }
}

/// The command with here-document bodies removed and quoted text blanked,
/// plus every program an interpreter was handed appended as a command of its
/// own: a quoted `-c` argument, and a here-document fed to a shell.
pub fn effective_command(command: &str) -> String {
    let documents = heredoc::split(command);
    let mut parts = vec![QUOTED
        .replace_all(&documents.without_bodies, BLANK)
        .into_owned()];
    for body in &documents.executed {
        parts.push(QUOTED.replace_all(body, BLANK).into_owned());
        collect(body, 0, &mut parts);
    }
    collect(&documents.without_bodies, 0, &mut parts);
    parts.join(JOIN)
}

#[cfg(test)]
mod tests {
    use super::{command_word, commands, effective_command, inner_command, program};
    use crate::ports::python_stdlib::shell_tokens;

    #[test]
    fn quoted_text_is_not_a_command() {
        let text = effective_command("printf 'python3 -c print(1)' > note.txt");
        assert!(!text.contains("python3"), "{text}");
        assert!(text.contains("printf"), "{text}");
    }

    /// The quoted program of an interpreter is exactly the text that runs.
    #[test]
    fn an_interpreter_program_survives() {
        let text = effective_command("bash -lc 'cp a b'");
        assert!(text.contains("cp a b"), "{text}");
    }

    #[test]
    fn nesting_is_followed_but_bounded() {
        let text = effective_command("bash -c \"sh -c 'rm -rf x'\"");
        assert!(text.contains("rm -rf x"), "{text}");
    }

    /// An unquoted command is untouched, so a gate reading it sees what runs.
    #[test]
    fn an_unquoted_command_is_unchanged() {
        assert_eq!(effective_command("git status"), "git status");
    }

    #[test]
    fn a_separator_inside_a_quoted_argument_is_text() {
        let line = "oko-cli evidence --commit \"ran 'tama enforcement only x'; it refused\"";

        let pieces = commands(line);

        assert_eq!(pieces.len(), 1, "{pieces:?}");
        assert_eq!(program(&shell_tokens(pieces[0])), Some("oko-cli"));
    }

    #[test]
    fn real_separators_still_cut() {
        assert_eq!(
            commands("cd repo && node shared-hooks/register-hook.mjs a"),
            vec!["cd repo", "node shared-hooks/register-hook.mjs a"]
        );
        assert_eq!(commands("a; b | c\nd & e"), vec!["a", "b", "c", "d", "e"]);
    }

    /// A duplicated file descriptor starts nothing: missing that cost a false
    /// refusal of a `2>&1` pipeline once already.
    #[test]
    fn a_redirection_is_not_a_separator() {
        assert_eq!(
            commands("stado host disk-cleanup 2>&1 | sed -n 1p"),
            vec!["stado host disk-cleanup 2>&1", "sed -n 1p"]
        );
    }

    #[test]
    fn a_substitution_is_code_even_inside_double_quotes() {
        let pieces = commands("echo \"now $(tama enforcement only x) done\"");

        assert!(
            pieces
                .iter()
                .any(|piece| *piece == "tama enforcement only x"),
            "{pieces:?}"
        );
        let back = commands("echo `tama install`");
        assert!(
            back.iter().any(|piece| *piece == "tama install"),
            "{back:?}"
        );
    }

    #[test]
    fn the_program_is_the_one_that_runs() {
        assert_eq!(
            program(&shell_tokens("FOO=1 sudo -n tama install")),
            Some("tama")
        );
        assert_eq!(
            program(&shell_tokens("timeout 30 tama-cli list")),
            Some("tama-cli")
        );
        assert_eq!(
            program(&shell_tokens("/opt/homebrew/bin/oko-cli hooks pull")),
            Some("oko-cli")
        );
        assert_eq!(program(&shell_tokens("")), None);
    }

    #[test]
    fn an_executors_argument_is_read_as_code() {
        assert_eq!(
            inner_command(&shell_tokens("bash -lc \"tama enforcement only x\"")),
            Some("tama enforcement only x")
        );
        assert_eq!(
            inner_command(&shell_tokens("node script.mjs --apply")),
            None
        );
    }

    #[test]
    fn a_sentence_is_not_a_command_word() {
        assert!(command_word("shared-hooks/generate-configs.mjs"));
        assert!(command_word("--apply"));
        assert!(!command_word("ran tama enforcement only x and it refused"));
    }
}
