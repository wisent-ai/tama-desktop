//! Port of `src/core/catalog.mjs`.
//!
//! Notable fidelity choices:
//! - JS `JSON.parse` preserves object key insertion order. The typed
//!   [`Registry`] uses `BTreeMap`, so insertion order for observable event and
//!   adapter arrays is recovered from the raw JSON text.
//! - JS `.sort()` on the ASCII strings used here is byte-lexicographic, as is
//!   Rust's `str::cmp`. Non-ASCII locale ordering is outside this catalogue.
//!
//! One file grew past the limit, so the subject is four modules now: building
//! the catalogue a reader sees ([`build`]), the validation verdict
//! ([`validate`]), the filesystem primitives both need ([`fs_scan`]), and the
//! raw key-order scanner ([`key_order`]). What is left here is where the
//! archive is and how its documents are loaded. Every name this module
//! published before is re-exported, so `crate::catalog::…` paths are
//! unchanged.

pub mod build;
pub mod fs_scan;
pub mod key_order;
pub mod validate;

pub use build::{build_catalog, find_hook, Catalog, CatalogHook, CatalogHookEvent};
pub use validate::{validate_catalog, ValidationResult};

use serde::Serialize;
use std::fs;
use std::path::{Component, Path, PathBuf};

use crate::registry::{CatalogMetadata, Registry};
use crate::Result;

use fs_scan::{join_path, root_str, strip_root, walk};

/// JS `repoRoot()`: the repository root.
///
/// Resolved as `$TAMA_ROOT` when the variable is set (and non-empty),
/// otherwise relative to `env!("CARGO_MANIFEST_DIR")` three levels up
/// (`rust/crates/tama-core/../../..`).
pub fn repo_root() -> PathBuf {
    if let Ok(root) = std::env::var("TAMA_ROOT") {
        if !root.is_empty() {
            return PathBuf::from(root);
        }
    }
    normalize_path(
        &PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .join("..")
            .join("..")
            .join(".."),
    )
}

/// Normalize `.`/`..` components without touching the filesystem
/// (like Node's `path.resolve`, which does not resolve symlinks).
fn normalize_path(path: &Path) -> PathBuf {
    let mut out = PathBuf::new();
    for component in path.components() {
        match component {
            Component::CurDir => {}
            Component::ParentDir => {
                out.pop();
            }
            other => out.push(other.as_os_str()),
        }
    }
    out
}

/// JS `readJson(path)` = `JSON.parse(readFileSync(path, 'utf8'))`.
pub fn read_json(path: &Path) -> Result<serde_json::Value> {
    Ok(serde_json::from_str(&fs::read_to_string(path)?)?)
}

/// JS `commandSourcePath(command)`: map a hook command or recorded source
/// back to its archived repo-relative path, or `None`. The last prefix is
/// wider than the JS list: a ported hook declares a Rust source under
/// `rust/crates/`, which none of the three hook directories covers, and an
/// unmapped source is a hook whose file nothing checks for existence.
///
/// The registry became portable, so `tama-reconcile-registry-sources` records
/// a repaired source repo-relative. The JS only ever matched absolute
/// prefixes, so those entries mapped to nothing: sixty-three hooks reported
/// "source path could not be mapped from command" while naming a file that
/// was right there, and nothing checked those files existed. A relative
/// spelling that resolves under the archive is accepted below.
pub fn command_source_path(command: Option<&str>, root: &Path) -> Option<String> {
    let command = command?;
    if command.is_empty() {
        return None; // JS: `if (!command || typeof command !== 'string') return null`
    }
    // JS `SOURCE_PREFIXES` are built once from the module-level `ROOT`
    // (the real repo root), never from the `--root` argument.
    let root_s = root_str(&repo_root());
    let prefixes = [
        (
            "/Users/lukaszbartoszcze/.shared-hooks/".to_string(),
            "shared-hooks/",
        ),
        (
            "/Users/lukaszbartoszcze/.codex/hooks/".to_string(),
            "codex-hooks/",
        ),
        (
            "/Users/lukaszbartoszcze/.claude/hooks/".to_string(),
            "claude-hooks/",
        ),
        (
            format!("{}/", join_path(&root_s, "shared-hooks")),
            "shared-hooks/",
        ),
        (
            format!("{}/", join_path(&root_s, "codex-hooks")),
            "codex-hooks/",
        ),
        (
            format!("{}/", join_path(&root_s, "claude-hooks")),
            "claude-hooks/",
        ),
        (format!("{root_s}/"), ""),
    ];
    for (prefix, repo_dir) in &prefixes {
        if let Some(idx) = command.find(prefix.as_str()) {
            let rest = command[idx + prefix.len()..]
                .split_whitespace()
                .next()
                .unwrap_or("");
            // Node `join('shared-hooks/', '')` normalizes to 'shared-hooks'.
            return Some(if rest.is_empty() {
                repo_dir.trim_end_matches('/').to_string()
            } else {
                format!("{repo_dir}{rest}")
            });
        }
    }
    let relative = command.split_whitespace().next().unwrap_or_default();
    if !relative.is_empty() && !relative.starts_with('/') && root.join(relative).is_file() {
        return Some(relative.to_string());
    }
    None
}

/// JS catalog `loadRegistry(root)`: parsed `shared-hooks/registry.json`,
/// or `{ events: {} }` when the file does not exist.
pub fn load_registry(root: &Path) -> Result<Registry> {
    Ok(load_registry_raw(root)?.0)
}

/// Registry plus the raw file text (needed to recover JSON key order).
pub(crate) fn load_registry_raw(root: &Path) -> Result<(Registry, Option<String>)> {
    let path = root.join("shared-hooks").join("registry.json");
    if !path.exists() {
        return Ok((Registry::default(), None));
    }
    let raw = fs::read_to_string(path)?;
    Ok((serde_json::from_str(&raw)?, Some(raw)))
}

/// JS `loadCatalogMetadata(root)`: `shared-hooks/catalog-metadata.json` as a
/// map of hook id -> docs, empty when the file does not exist.
pub fn load_catalog_metadata(root: &Path) -> Result<CatalogMetadata> {
    let path = root.join("shared-hooks").join("catalog-metadata.json");
    if !path.exists() {
        return Ok(CatalogMetadata::new());
    }
    Ok(serde_json::from_str(&fs::read_to_string(path)?)?)
}

/// JS `listSourceFiles(root)`: repo-relative paths of every file under
/// `claude-hooks`, `codex-hooks`, `shared-hooks`, `repo-githooks`
/// (skipping `.git`, `__pycache__`, `state`, `recall_dumps`), sorted.
pub fn list_source_files(root: &Path) -> Result<Vec<String>> {
    let root_s = root_str(root);
    let mut files = Vec::new();
    for dir in [
        "claude-hooks",
        "codex-hooks",
        "shared-hooks",
        "repo-githooks",
    ] {
        walk(&join_path(&root_s, dir), &mut files)?;
    }
    let mut rel: Vec<String> = files
        .iter()
        .map(|p| strip_root(&root_s, p).to_string())
        .collect();
    rel.sort();
    Ok(rel)
}

/// One entry of JS `listRepoGitHooks(root)`.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct RepoGitHook {
    pub project: String,
    pub event: String,
    pub source_path: String,
}

/// JS `listRepoGitHooks(root)`, sorted by `project:event`.
pub fn list_repo_git_hooks(root: &Path) -> Result<Vec<RepoGitHook>> {
    let mut hooks: Vec<RepoGitHook> = list_source_files(root)?
        .into_iter()
        .filter(|path| path.starts_with("repo-githooks/"))
        .map(|path| {
            let parts: Vec<&str> = path.split('/').collect();
            // JS `parts[1]`/`parts[2]` may be `undefined`, which stringifies
            // as "undefined"; reproduced literally for pathological layouts.
            let part = |i: usize| {
                parts
                    .get(i)
                    .map(|s| s.to_string())
                    .unwrap_or_else(|| "undefined".to_string())
            };
            RepoGitHook {
                project: part(1),
                event: part(2),
                source_path: path,
            }
        })
        .collect();
    hooks.sort_by(|a, b| {
        format!("{}:{}", a.project, a.event).cmp(&format!("{}:{}", b.project, b.event))
    });
    Ok(hooks)
}
