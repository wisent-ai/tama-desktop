//! Screen navigation and rendering helpers: pure functions over the journey
//! definition JSON. No state I/O lives here.

use serde_json::Value;

pub(super) fn screen_by_id<'a>(
    definition: &'a Value,
    screen_id: &str,
) -> Result<&'a Value, String> {
    definition
        .get("screens")
        .and_then(Value::as_array)
        .and_then(|screens| {
            screens
                .iter()
                .find(|screen| screen.get("screen_id").and_then(Value::as_str) == Some(screen_id))
        })
        .ok_or_else(|| format!("Tama onboarding screen is unavailable: {screen_id}"))
}

pub(super) fn next_screen_id(screen: &Value) -> Result<Option<String>, String> {
    let Some(transitions) = screen.get("transitions").and_then(Value::as_array) else {
        return Ok(None);
    };
    transitions
        .iter()
        .max_by_key(|transition| {
            transition
                .get("priority")
                .and_then(Value::as_i64)
                .unwrap_or_default()
        })
        .map(|transition| {
            transition
                .get("next_screen_id")
                .and_then(Value::as_str)
                .map(str::to_string)
                .ok_or_else(|| "Tama onboarding transition has no target".to_string())
        })
        .transpose()
}

pub(super) fn evidence_satisfied(screen: &Value, fact: &str) -> Result<bool, String> {
    let rule = screen
        .get("completion_evidence")
        .filter(|value| !value.is_null())
        .ok_or_else(|| "Tama onboarding final screen has no completion evidence".to_string())?;
    Ok(rule.get("kind").and_then(Value::as_str) == Some("fact")
        && rule.get("operator").and_then(Value::as_str) == Some("eq")
        && rule.get("fact").and_then(Value::as_str) == Some(fact)
        && rule.get("value").and_then(Value::as_bool) == Some(true))
}

pub(super) fn render(screen: &Value) -> Result<(), String> {
    let title = screen
        .pointer("/presentation/title")
        .and_then(Value::as_str)
        .ok_or_else(|| "Tama onboarding screen has no presentation title".to_string())?;
    let body = screen
        .pointer("/presentation/body")
        .and_then(Value::as_str)
        .ok_or_else(|| "Tama onboarding screen has no presentation body".to_string())?;
    println!("== {title} ==");
    println!("{body}");
    Ok(())
}
