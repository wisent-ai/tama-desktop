use super::{file_is_declared, folder_is_declared, is_declared, parse_entries, Declarations};

/// Scratch repositories live under the checkout's ignored build directory:
/// nothing this workshop runs writes to the system temporary directory. Each
/// one carries a `.git` marker, because that is what makes it a repository
/// of its own rather than a folder inside this checkout.
fn repo_with(name: &str, declaration: &str) -> std::path::PathBuf {
    let dir = scratch(name);
    std::fs::create_dir_all(dir.join(".tama")).expect("a repository to read");
    std::fs::write(dir.join(".tama").join("violations-ignore"), declaration)
        .expect("its declaration");
    dir
}

fn scratch(name: &str) -> std::path::PathBuf {
    let dir = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("../../target/tmp")
        .join(format!("tama-declarations-{name}"));
    let _ = std::fs::remove_dir_all(&dir);
    std::fs::create_dir_all(dir.join(".git")).expect("a repository boundary");
    dir
}

#[test]
fn comments_and_blank_lines_name_nothing() {
    let entries = parse_entries("# why this folder\n\nassets/\n  \n.\n");

    assert_eq!(entries, vec!["assets/".to_string(), ".".to_string()]);
}

#[test]
fn a_directory_entry_covers_what_is_below_it() {
    let entries = parse_entries("assets/\npricing/costs.json\n");

    assert!(is_declared("assets/logo.svg", &entries));
    assert!(is_declared("pricing/costs.json", &entries));
    assert!(!is_declared("src/logo.svg", &entries));
    assert!(!is_declared("pricing/costs.json.bak", &entries));
}

#[test]
fn a_declared_root_answers_for_its_own_crowding() {
    let repo = repo_with("root", "# the root is fixed by npm and git\n.\n");
    let declarations =
        Declarations::nearest(&repo.join("package.json")).expect("declarations at the root");

    assert!(declarations.declares_folder(&repo));
    assert!(!declarations.declares_folder(&repo.join("src")));
    let _ = std::fs::remove_dir_all(&repo);
}

#[test]
fn a_declared_folder_answers_in_either_spelling() {
    let repo = repo_with("folders", "assets\nvendor/\n");
    let declarations = Declarations::nearest(&repo.join("assets")).expect("declarations");

    assert!(declarations.declares_folder(&repo.join("assets")));
    assert!(declarations.declares_folder(&repo.join("vendor")));
    assert!(!declarations.declares_folder(&repo.join("src")));
    let _ = std::fs::remove_dir_all(&repo);
}

#[test]
fn a_declared_file_is_found_from_a_nested_path() {
    let repo = repo_with("nested", "data/\n");
    let nested = repo.join("data").join("deep").join("registry.json");

    assert!(file_is_declared(&nested.to_string_lossy()));
    assert!(!file_is_declared(
        &repo.join("src").join("main.rs").to_string_lossy()
    ));
    let _ = std::fs::remove_dir_all(&repo);
}

/// A repository that declared nothing is judged exactly as before, and does
/// not inherit the declarations of a checkout it sits inside.
#[test]
fn a_repository_without_a_declaration_file_declares_nothing() {
    let dir = scratch("absent");

    assert!(Declarations::nearest(&dir.join("src.rs")).is_none());
    assert!(!file_is_declared(&dir.join("src.rs").to_string_lossy()));
    assert!(!folder_is_declared(&dir.to_string_lossy()));
    let _ = std::fs::remove_dir_all(&dir);
}
