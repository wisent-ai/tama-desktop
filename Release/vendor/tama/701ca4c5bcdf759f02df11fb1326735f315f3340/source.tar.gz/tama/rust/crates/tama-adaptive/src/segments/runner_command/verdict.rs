//! What a finished hook command means: the decision it printed, and the
//! sentences for an overrun or a crash.
//!
//! Split out of `runner_command.rs`, which had grown past the
//! three-hundred-line limit; running the command stays there.

use std::path::Path;

use super::{CommandResult, HookSpec};

/// `decisionFromOutput(text)`.
pub fn decision_from_output(text: &str) -> Option<String> {
    let trimmed = text.trim();
    if trimmed.is_empty() {
        return None;
    }
    let mut candidates = vec![trimmed];
    candidates.extend(trimmed.split('\n'));
    for candidate in candidates {
        let line = candidate.trim();
        if line.is_empty() {
            continue;
        }
        if let Ok(parsed) = serde_json::from_str::<serde_json::Value>(line) {
            if parsed.is_object()
                && parsed.get("decision").and_then(|v| v.as_str()) == Some("block")
            {
                let reason = parsed.get("reason").filter(|r| crate::util::js_truthy(r));
                return Some(match reason {
                    Some(value) => crate::util::js_string(value),
                    None => "hook returned block decision".to_string(),
                });
            }
        }
        if line.starts_with("BLOCKED:") {
            return Some(line.to_string());
        }
    }
    None
}

/// Node-style number rendering inside templates (`${hook.timeout}`).
pub fn js_number_string(value: &serde_json::Value) -> String {
    match value {
        serde_json::Value::Number(n) => {
            if let Some(i) = n.as_i64() {
                i.to_string()
            } else if let Some(u) = n.as_u64() {
                u.to_string()
            } else {
                let f = n.as_f64().unwrap_or(f64::NAN);
                if f.fract() == 0.0 && f.is_finite() && f.abs() < 1e15 {
                    format!("{}", f as i64)
                } else {
                    format!("{}", f)
                }
            }
        }
        other => crate::util::js_string(other),
    }
}

/// `crashReason(hook, result)`.
pub fn crash_reason(hook: &HookSpec, result: &CommandResult) -> String {
    let reason_text = if !result.stderr.is_empty() {
        result.stderr.trim().to_string()
    } else if !result.stdout.is_empty() {
        result.stdout.trim().to_string()
    } else {
        let code = result
            .code
            .map(|c| c.to_string())
            .unwrap_or_else(|| "null".to_string());
        format!("exit {}", code)
    };
    format!("{}: {}", hook.id_text(), reason_text)
}

/// Node `path.extname`: suffix from the last dot of the basename, `''` for
/// dotfiles and names without a dot.
pub fn extname(path: &str) -> String {
    let base = Path::new(path)
        .file_name()
        .map(|n| n.to_string_lossy().to_string())
        .unwrap_or_default();
    match base.rfind('.') {
        Some(index) if index > 0 => base[index..].to_string(),
        _ => String::new(),
    }
}
