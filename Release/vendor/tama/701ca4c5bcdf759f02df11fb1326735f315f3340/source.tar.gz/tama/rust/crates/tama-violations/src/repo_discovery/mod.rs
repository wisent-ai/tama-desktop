//! Repository discovery for multi-repo scans: which local checkouts under a
//! tree belong to this workspace (`walk`), which repositories an owner has
//! on GitHub and where they are cloned (`github`), and the resolution of
//! `--repo`, `--tree`, `--owner` and `--me` into one deduplicated target
//! list.

mod descent;
pub mod github;
pub mod walk;

use serde::Serialize;
use std::collections::HashSet;
use std::path::Path;

use crate::resolve_path;

pub use github::{ensure_checkout, github_login, github_orgs, github_repos, Checkout};
pub use walk::{
    discover_checkouts, discover_checkouts_at_root_reporting, discover_every_checkout,
    discover_every_checkout_deep, discover_every_checkout_deep_reporting,
    discover_every_checkout_reporting, discover_repos, Discovered, UnreadableDirectory,
};

#[derive(Debug, Clone, Serialize)]
pub struct Target {
    pub path: String,
    pub via: String,
}

#[derive(Debug, Clone, Serialize)]
pub struct Problem {
    pub owner: String,
    /// Always present in the JSON shape, `null` when the failure is not
    /// tied to one repository (mirrors the JS `{ owner, repo: null, error }`).
    pub repo: Option<String>,
    pub error: String,
    /// A checkout left out on purpose rather than one that could not be
    /// read. Somebody else's product in this tree is reported and never
    /// counted against the exit status: a workshop with nothing left to fix
    /// has to be able to finish at zero while `oh-my-pi` sits beside it.
    pub skipped: bool,
}

impl Problem {
    /// A repository that could not be listed, cloned or read.
    pub fn failure(owner: String, repo: Option<String>, error: String) -> Self {
        Problem {
            owner,
            repo,
            error,
            skipped: false,
        }
    }
}

#[derive(Debug, Clone)]
pub struct ResolvedTargets {
    pub targets: Vec<Target>,
    pub problems: Vec<Problem>,
}

/// The subset of parsed scan arguments discovery needs (`resolveTargets`).
pub struct DiscoveryArgs<'a> {
    pub repos: &'a [String],
    pub trees: &'a [String],
    pub owners: &'a [String],
    pub me: bool,
    pub clone_dir: &'a Path,
}

fn add(path: &str, via: &str, seen: &mut HashSet<String>, targets: &mut Vec<Target>) {
    let full = resolve_path(&[Path::new(path)])
        .to_string_lossy()
        .into_owned();
    if !seen.insert(full.clone()) {
        return;
    }
    targets.push(Target {
        path: full,
        via: via.to_string(),
    });
}

fn add_owner_repos(
    owner: &str,
    clone_dir: &Path,
    seen: &mut HashSet<String>,
    targets: &mut Vec<Target>,
    problems: &mut Vec<Problem>,
) {
    let (repos, error) = github_repos(owner);
    let repos = match repos {
        Some(repos) => repos,
        None => {
            problems.push(Problem::failure(
                owner.to_string(),
                None,
                error.unwrap_or_else(|| "gh repo list failed".to_string()),
            ));
            return;
        }
    };
    for name_with_owner in repos {
        let checkout = ensure_checkout(&name_with_owner, clone_dir);
        if let Some(error) = checkout.error {
            problems.push(Problem::failure(
                owner.to_string(),
                Some(name_with_owner.clone()),
                error,
            ));
            continue;
        }
        add(&checkout.path, "github", seen, targets);
    }
}

fn add_my_repos(
    clone_dir: &Path,
    seen: &mut HashSet<String>,
    targets: &mut Vec<Target>,
    problems: &mut Vec<Problem>,
) {
    let (login, error) = github_login();
    let Some(login) = login else {
        problems.push(Problem::failure(
            "me".to_string(),
            None,
            error.unwrap_or_else(|| "gh api user failed".to_string()),
        ));
        return;
    };
    add_owner_repos(&login, clone_dir, seen, targets, problems);
    let (orgs, error) = github_orgs();
    let Some(orgs) = orgs else {
        problems.push(Problem::failure(
            "me".to_string(),
            None,
            error.unwrap_or_else(|| "gh api user/orgs failed".to_string()),
        ));
        return;
    };
    for org in orgs {
        add_owner_repos(&org, clone_dir, seen, targets, problems);
    }
}

pub fn resolve_targets(args: &DiscoveryArgs) -> ResolvedTargets {
    let mut targets: Vec<Target> = Vec::new();
    let mut problems: Vec<Problem> = Vec::new();
    let mut seen: HashSet<String> = HashSet::new();

    for repo in args.repos {
        add(repo, "repo", &mut seen, &mut targets);
    }
    for tree in args.trees {
        let resolved = resolve_path(&[Path::new(tree)]);
        for found in discover_repos(&resolved) {
            // A sweep says what this workshop has to fix. Somebody else's
            // product in the same tree is neither fixable nor ours to
            // touch, so it is named and left alone; an explicit --repo
            // still scans whatever it is pointed at.
            match walk::foreign_owner(&found) {
                Some(owner) => problems.push(Problem {
                    owner,
                    repo: Some(found.clone()),
                    error: "owns this checkout, so its layout is not ours to repair".to_string(),
                    skipped: true,
                }),
                None => add(&found, "tree", &mut seen, &mut targets),
            }
        }
    }
    if args.me {
        add_my_repos(args.clone_dir, &mut seen, &mut targets, &mut problems);
    }
    for owner in args.owners {
        add_owner_repos(
            owner,
            args.clone_dir,
            &mut seen,
            &mut targets,
            &mut problems,
        );
    }
    ResolvedTargets { targets, problems }
}
