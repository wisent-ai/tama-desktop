//! The Tama objective reviewer: what the user asked for, what the turn did,
//! and one authorization verdict. The gateway it asks lives in
//! `crate::brama`, which every Wisent component shares.

use serde::Serialize;
use serde_json::Value;
use std::io::{BufRead, BufReader};
use std::path::PathBuf;
use tama_hooks::session_record::session_id_of;

#[derive(Serialize)]
pub struct ReviewContext {
    pub user_contract: Vec<String>,
    pub turn_evidence: Vec<String>,
    pub failed_tool_evidence: Vec<String>,
    pub last_assistant_message: String,
}

pub fn context(payload: &Value) -> Result<ReviewContext, String> {
    let path = payload
        .get("transcript_path")
        .and_then(Value::as_str)
        .filter(|path| !path.is_empty())
        .map(PathBuf::from)
        .filter(|path| path.is_file())
        .or_else(|| transcript_path(&session_id_of(payload)))
        .ok_or("no readable user transcript")?;
    let mut context = contract_from_transcript(&path)
        .ok_or("no user-authored contract was found in the session transcript")?;
    if let Some(message) = payload
        .get("last_assistant_message")
        .and_then(Value::as_str)
        .filter(|message| !message.trim().is_empty())
    {
        context.last_assistant_message = message.to_owned();
    }
    Ok(context)
}

fn home_dir() -> PathBuf {
    std::env::var("HOME").map(PathBuf::from).unwrap_or_default()
}

fn sessions_root() -> PathBuf {
    match std::env::var("TAMA_OMP_SESSION_ROOT") {
        Ok(custom) if !custom.is_empty() => PathBuf::from(custom),
        _ => home_dir().join(".omp").join("agent").join("sessions"),
    }
}

fn transcript_path(session: &str) -> Option<PathBuf> {
    if session.is_empty() {
        return None;
    }
    let mut newest = None;
    let mut stack = vec![sessions_root()];
    while let Some(directory) = stack.pop() {
        let Ok(entries) = std::fs::read_dir(directory) else {
            continue;
        };
        for entry in entries.flatten() {
            let path = entry.path();
            if path.is_dir() {
                stack.push(path);
                continue;
            }
            let Some(name) = path.file_name().and_then(|name| name.to_str()) else {
                continue;
            };
            if !name.contains(session) || !name.ends_with(".jsonl") {
                continue;
            }
            let modified = entry
                .metadata()
                .and_then(|metadata| metadata.modified())
                .unwrap_or(std::time::UNIX_EPOCH);
            if newest
                .as_ref()
                .map(|(seen, _)| modified > *seen)
                .unwrap_or(true)
            {
                newest = Some((modified, path));
            }
        }
    }
    newest.map(|(_, path)| path)
}

fn max_contract_messages() -> usize {
    "16".parse().expect("valid contract message limit")
}

fn max_contract_chars() -> usize {
    "48000".parse().expect("valid contract character limit")
}

fn max_contract_message_chars() -> usize {
    "12000"
        .parse()
        .expect("valid contract message character limit")
}

fn max_evidence_messages() -> usize {
    "8".parse().expect("valid evidence message limit")
}

fn max_evidence_chars() -> usize {
    "16000".parse().expect("valid evidence character limit")
}

fn bounded_text(value: &str, limit: usize) -> String {
    let count = value.chars().count();
    if count <= limit {
        return value.to_owned();
    }
    let head_chars = limit / "4".parse::<usize>().expect("valid text split");
    let tail_chars = limit.saturating_sub(head_chars);
    let head_end = value
        .char_indices()
        .nth(head_chars)
        .map(|(index, _)| index)
        .unwrap_or(value.len());
    let tail_start = value
        .char_indices()
        .nth(count.saturating_sub(tail_chars))
        .map(|(index, _)| index)
        .unwrap_or_default();
    format!(
        "{}\n[older content truncated by Tama]\n{}",
        &value[..head_end],
        &value[tail_start..]
    )
}

fn bounded_messages(messages: Vec<String>, max_messages: usize, max_chars: usize) -> Vec<String> {
    let mut selected = Vec::new();
    let mut used = 0_usize;
    for message in messages.into_iter().rev().take(max_messages) {
        let bounded = bounded_text(&message, max_contract_message_chars());
        let remaining = max_chars.saturating_sub(used);
        if remaining == usize::default() {
            break;
        }
        let bounded = bounded_text(&bounded, remaining);
        used = used.saturating_add(bounded.chars().count());
        selected.push(bounded);
    }
    selected.reverse();
    selected
}

fn text_content(message: &Value) -> String {
    if let Some(text) = message.get("content").and_then(Value::as_str) {
        return text.to_owned();
    }
    let Some(items) = message.get("content").and_then(Value::as_array) else {
        return String::new();
    };
    items
        .iter()
        .filter_map(|item| item.get("text").and_then(Value::as_str))
        .collect::<Vec<_>>()
        .join("\n")
}

fn record_message(record: &Value) -> Option<(&str, String)> {
    if let Some(message) = record.get("message").filter(|message| message.is_object()) {
        let role = message.get("role").and_then(Value::as_str)?;
        return Some((role, text_content(message)));
    }
    let kind = record.pointer("/payload/type").and_then(Value::as_str)?;
    let data = record.pointer("/payload/data")?;
    match kind {
        "user" => data
            .get("task")
            .and_then(Value::as_str)
            .map(|text| ("user", text.to_string())),
        "tool_result" => data
            .get("replayMessage")
            .and_then(Value::as_str)
            .map(|text| ("toolResult", text.to_string())),
        _ => None,
    }
}

fn contract_from_transcript(path: &PathBuf) -> Option<ReviewContext> {
    let file = std::fs::File::open(path).ok()?;
    let mut users = Vec::new();
    let mut current_turn_evidence = Vec::new();
    let mut failed_tool_evidence = Vec::new();
    let mut last_assistant_message = String::new();
    for line in BufReader::new(file).lines() {
        let line = line.ok()?;
        let Ok(record) = serde_json::from_str::<Value>(&line) else {
            continue;
        };
        let Some((role, text)) = record_message(&record) else {
            continue;
        };
        match role {
            "user" => {
                if !text.trim().is_empty() {
                    users.push(text);
                }
                current_turn_evidence.clear();
                failed_tool_evidence.clear();
                last_assistant_message.clear();
            }
            "toolResult" => {
                if !text.trim().is_empty() {
                    let message = record.get("message").unwrap_or(&Value::Null);
                    let failed = message.get("isError").and_then(Value::as_bool) == Some(true);
                    let tool = message
                        .get("toolName")
                        .and_then(Value::as_str)
                        .unwrap_or("tool");
                    let evidence = format!("{tool} (isError={failed}): {text}");
                    if failed {
                        failed_tool_evidence.push(evidence.clone());
                    }
                    current_turn_evidence.push(evidence);
                }
            }
            "assistant" if !text.trim().is_empty() => {
                last_assistant_message = bounded_text(&text, max_contract_message_chars());
            }
            _ => {}
        }
    }
    let user_contract = bounded_messages(users, max_contract_messages(), max_contract_chars());
    let turn_evidence = bounded_messages(
        current_turn_evidence,
        max_evidence_messages(),
        max_evidence_chars(),
    );
    (!user_contract.is_empty()).then_some(ReviewContext {
        user_contract,
        turn_evidence,
        failed_tool_evidence: bounded_messages(
            failed_tool_evidence,
            max_contract_messages(),
            max_evidence_chars(),
        ),
        last_assistant_message,
    })
}

/// Seconds the reviewer waits for its one-line verdict, and the tokens it may
/// take: both unchanged from when the request lived in this file.
fn verdict_deadline() -> u32 {
    "25".parse().expect("valid verdict deadline")
}

fn verdict_tokens() -> u32 {
    "160".parse().expect("valid verdict token budget")
}

/// The authorization verdict the objective-substitution guard asks for.
pub fn verdict(system_prompt: &str, evidence: &str) -> Result<String, String> {
    let verdict = crate::brama::chat(
        &crate::brama::credentials::model_route()?,
        system_prompt,
        evidence,
        verdict_tokens(),
        verdict_deadline(),
    )?;
    if verdict == "PASS"
        || verdict
            .strip_prefix("BLOCK:")
            .is_some_and(|reason| !reason.trim().is_empty() && !reason.contains('\n'))
    {
        Ok(verdict)
    } else {
        Err(format!(
            "Brama reviewer returned no valid authorization verdict; expected PASS or BLOCK: <reason> on one line, received {verdict:?}"
        ))
    }
}
