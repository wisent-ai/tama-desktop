//! Changing the build policy: what an option may do, and what needs the
//! operator's device approval.
//!
//! Split out of `builds/policy.rs`, which had grown past the
//! three-hundred-line limit. The limits and how they are read stay there;
//! writing a new value is here, because that is where the approval belongs.

use std::path::Path;

use serde_json::{json, Value};

use super::policy::{load, Policy, CONSENT_ENV, CONSENT_VALUE, LIMITS};

fn approved() -> bool {
    std::env::var(CONSENT_ENV).ok().as_deref() == Some(CONSENT_VALUE)
}

/// Applies the options present in `argv` to the stored policy. Returns the new
/// policy and the lines describing what changed; refuses a loosening without
/// device approval, naming the option and the direction.
pub fn revise(path: &Path, argv: &[String]) -> Result<(Policy, Vec<String>), String> {
    let before = load(path)?;
    let mut document = before.document();
    let mut changes = Vec::new();
    for limit in LIMITS.iter() {
        let Some(raw) = argv
            .iter()
            .position(|item| item == limit.option)
            .and_then(|index| argv.get(index + 1))
        else {
            continue;
        };
        let value: u64 = raw
            .parse()
            .map_err(|_| format!("{} is a whole number, not {raw}", limit.option))?;
        let was = document
            .get(limit.field)
            .and_then(Value::as_u64)
            .unwrap_or(limit.default);
        if value == was {
            continue;
        }
        let loosens = if limit.larger_permits_more {
            value > was
        } else {
            value < was
        };
        if loosens && !approved() {
            return Err(format!(
                "{} from {was} to {value} permits more work than the operator's policy does, so it \
                 needs {CONSENT_ENV}={CONSENT_VALUE} set outside the agent session. Tightening a \
                 limit needs nothing.",
                limit.option
            ));
        }
        document[limit.field] = json!(value);
        let direction = if loosens { "loosened" } else { "tightened" };
        changes.push(format!("{} {direction} {was} -> {value}", limit.field));
    }
    if changes.is_empty() {
        return Ok((before, changes));
    }
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)
            .map_err(|error| format!("{} cannot be created: {error}", parent.display()))?;
    }
    let text = serde_json::to_string_pretty(&document).unwrap_or_default();
    std::fs::write(path, format!("{text}\n"))
        .map_err(|error| format!("{} cannot be written: {error}", path.display()))?;
    Ok((load(path)?, changes))
}
