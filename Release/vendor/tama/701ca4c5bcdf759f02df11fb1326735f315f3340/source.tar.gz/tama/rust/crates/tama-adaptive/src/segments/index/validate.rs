//! Reading a segment back and deciding whether it is intact: the header,
//! the frames, the footer's digest, and the acknowledgement beside it.
//!
//! Split out of `segments/index.rs`, which had grown past the
//! three-hundred-line limit; writing segments stays there.

use std::fs;
use std::path::Path;

use super::{
    ack_name, digest_bytes, get_str, is_hex_64, is_number, parse_object, segment_name,
    ValidSegment, ACK_PROTOCOL, PROTOCOL,
};

/// `validateSegment(path)` — header/footer/shape checks, payload sha.
pub fn validate_segment(path: &Path) -> Option<ValidSegment> {
    let source = fs::read_to_string(path).ok()?;
    if !source.ends_with('\n') {
        return None;
    }
    let rows: Vec<&str> = source[..source.len() - 1].split('\n').collect();
    if rows.len() < 2 {
        return None;
    }
    let header = parse_object(rows[0])?;
    let footer = parse_object(rows[rows.len() - 1])?;
    if get_str(&header, "kind") != Some("segment_open")
        || get_str(&header, "protocol") != Some(PROTOCOL)
    {
        return None;
    }
    let segment_id = get_str(&header, "segmentId")?.to_string();
    if segment_id.is_empty() {
        return None;
    }
    let base = path.file_name()?.to_string_lossy();
    if base != segment_name(&segment_id) {
        return None;
    }
    let producer_id = get_str(&header, "producerId")?;
    let invocation_id = get_str(&header, "invocationId")?;
    if producer_id.is_empty() || invocation_id.is_empty() {
        return None;
    }
    if !header.get("createdAt").map(is_number).unwrap_or(false) {
        return None;
    }
    let source_field = header.get("source")?;
    if source_field.is_null() || get_str(source_field, "producer") != Some("tama") {
        return None;
    }
    let mut events = Vec::new();
    for row in &rows[1..rows.len() - 1] {
        let frame = parse_object(row)?;
        if get_str(&frame, "kind") != Some("event") {
            return None;
        }
        if frame.get("sequence").and_then(|v| v.as_i64()) != Some(events.len() as i64) {
            return None;
        }
        let event = frame.get("event")?;
        if !event.is_object() {
            return None;
        }
        events.push(event.clone());
    }
    let payload = format!("{}\n", rows[..rows.len() - 1].join("\n"));
    let payload_sha256 = digest_bytes(payload.as_bytes());
    if get_str(&footer, "kind") != Some("segment_close")
        || get_str(&footer, "protocol") != Some(PROTOCOL)
        || get_str(&footer, "segmentId") != Some(segment_id.as_str())
    {
        return None;
    }
    if footer.get("eventCount").and_then(|v| v.as_i64()) != Some(events.len() as i64) {
        return None;
    }
    if get_str(&footer, "payloadSha256") != Some(payload_sha256.as_str()) {
        return None;
    }
    if !footer.get("closedAt").map(is_number).unwrap_or(false) {
        return None;
    }
    Some(ValidSegment {
        segment_id,
        event_count: events.len(),
        payload_sha256,
        source_sha256: digest_bytes(source.as_bytes()),
        source_size: source.len(),
        events,
    })
}

/// `validateAck(path, segment)`.
pub(super) fn validate_ack(path: &Path, segment: &ValidSegment) -> Option<serde_json::Value> {
    let ack = parse_object(&fs::read_to_string(path).ok()?)?;
    let base = path.file_name()?.to_string_lossy();
    if base != ack_name(&segment.segment_id) {
        return None;
    }
    if get_str(&ack, "protocol") != Some(ACK_PROTOCOL)
        || get_str(&ack, "segmentId") != Some(segment.segment_id.as_str())
    {
        return None;
    }
    if get_str(&ack, "sourceSha256") != Some(segment.source_sha256.as_str()) {
        return None;
    }
    if ack.get("sourceSize").and_then(|v| v.as_i64()) != Some(segment.source_size as i64) {
        return None;
    }
    if ack.get("eventCount").and_then(|v| v.as_i64()) != Some(segment.event_count as i64)
        || get_str(&ack, "payloadSha256") != Some(segment.payload_sha256.as_str())
    {
        return None;
    }
    let lake_commit_id = get_str(&ack, "lakeCommitId")?;
    if lake_commit_id.is_empty() {
        return None;
    }
    let outputs = ack.get("outputs")?.as_array()?;
    if outputs.is_empty() {
        return None;
    }
    let outputs_valid = outputs.iter().all(|item| {
        let Some(item_path) = get_str(item, "path") else {
            return false;
        };
        if item_path.is_empty() {
            return false;
        }
        let Some(item_sha) = get_str(item, "sha256") else {
            return false;
        };
        if !is_hex_64(item_sha) {
            return false;
        }
        let Ok(meta) = fs::symlink_metadata(item_path) else {
            return false;
        };
        if !meta.is_file() || meta.file_type().is_symlink() {
            return false;
        }
        match fs::read(item_path) {
            Ok(bytes) => digest_bytes(&bytes) == item_sha,
            Err(_) => false,
        }
    });
    if !outputs_valid {
        return None;
    }
    Some(ack)
}

/// `decisionsPersisted(segment)`.
pub(super) fn decisions_persisted(segment: &ValidSegment) -> bool {
    segment.events.iter().all(|event| {
        get_str(event, "type") != Some("decision")
            || event
                .get("adaptiveStatePersisted")
                .and_then(|v| v.as_bool())
                == Some(true)
    })
}
