//! `tama-block-unregistered-build-or-restart`, driven as the real binary with
//! a real payload on stdin, against a registry the real `tama build record`
//! wrote.
//!
//! The evening of 2026-09-20 is what these cases are about: ten release
//! submissions from one session, several failing on a gate that runs locally
//! in a minute, plus a launchd unit installed, restarted and retired that
//! nobody had asked for. Each case holds one command to its exit status, so a
//! later rewrite can neither widen the gate onto `stado release status` nor
//! narrow it off a build with no recorded intent.

mod common;

use std::io::Write as _;
use std::process::{Command, Output, Stdio};

use serde_json::json;

use common::{build as record, said, Scratch};

const EXIT_PASS: i32 = false as i32;
const EXIT_REFUSED: i32 = true as i32 + true as i32;

const GUARD: &str = env!("CARGO_BIN_EXE_tama-block-unregistered-build-or-restart");
const BANNER: &str = "BLOCKED: unregistered ";
/// The revision one recorded build carries in these cases; a full source
/// revision is what the registry demands of a build entry.
const REVISION: &str = "45a5c678042147f76241adf76fb7cf217e121ca6";
const REASON: &str = "skarbiec 0.3.11 carries the identity kind and the duplicate refusal";

fn run(scratch: &Scratch, command: &str) -> Output {
    let payload = json!({ "tool_name": "Bash", "tool_input": { "command": command } });
    let mut child = Command::new(GUARD)
        .env("HOME", scratch.home())
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .unwrap_or_else(|error| panic!("spawn the guard: {error}"));
    child
        .stdin
        .as_mut()
        .expect("guard stdin")
        .write_all(payload.to_string().as_bytes())
        .expect("write payload");
    child.wait_with_output().expect("guard output")
}

fn refused(scratch: &Scratch, command: &str) -> String {
    let output = run(scratch, command);
    let stderr = String::from_utf8_lossy(&output.stderr).into_owned();
    assert_eq!(
        output.status.code(),
        Some(EXIT_REFUSED),
        "{command} must be refused; stderr: {stderr}"
    );
    assert!(stderr.contains(BANNER), "{stderr}");
    stderr
}

fn passes(scratch: &Scratch, command: &str) {
    let output = run(scratch, command);
    assert_eq!(
        output.status.code(),
        Some(EXIT_PASS),
        "{command} must pass; stderr: {}",
        String::from_utf8_lossy(&output.stderr)
    );
}

/// The target of a `release submit` is the repository the command runs in,
/// which for this test is this checkout.
fn repository_here() -> String {
    std::env::current_dir()
        .ok()
        .and_then(|path| {
            path.ancestors()
                .find(|directory| directory.join(".git").exists())
                .and_then(|directory| directory.file_name())
                .and_then(|name| name.to_str())
                .map(str::to_string)
        })
        .expect("a repository to name")
}

#[test]
fn a_build_is_refused_until_its_intent_is_recorded_and_again_once_it_closes() {
    let scratch = Scratch::new("guard-build");
    let command = "stado release submit --source . --version 0.3.11";

    let stderr = refused(&scratch, command);
    assert!(
        stderr.contains("tama-cli build record --kind build"),
        "{stderr}"
    );
    assert!(stderr.contains("--revision"), "{stderr}");

    let target = repository_here();
    let recorded = record(
        &scratch,
        &[
            "record",
            "--kind",
            "build",
            "--target",
            &target,
            "--reason",
            REASON,
            "--revision",
            REVISION,
        ],
    );
    assert!(recorded.status.success(), "{}", said(&recorded));
    passes(&scratch, command);

    // An authorization that never closed would make the first recorded build a
    // standing permission for every later one.
    let closed = record(&scratch, &["close", "--kind", "build", "--target", &target]);
    assert!(closed.status.success(), "{}", said(&closed));
    refused(&scratch, command);
}

#[test]
fn a_restart_is_refused_until_its_intent_is_recorded() {
    let scratch = Scratch::new("guard-restart");
    let command = "stado service restart brama-grant-sync --host lukasz-macbook";

    let stderr = refused(&scratch, command);
    assert!(stderr.contains("--target brama-grant-sync"), "{stderr}");
    assert!(!stderr.contains("--revision"), "{stderr}");

    let recorded = record(
        &scratch,
        &[
            "record",
            "--kind",
            "restart",
            "--target",
            "brama-grant-sync",
            "--reason",
            "the unit runs the sweep the operator asked to keep running",
        ],
    );
    assert!(recorded.status.success(), "{}", said(&recorded));
    passes(&scratch, command);

    // One entry authorizes one target: another unit is still refused.
    refused(
        &scratch,
        "launchctl kickstart -k gui/501/com.wisent.always-on.brama",
    );
}

/// A read is not a build and a mention is not a restart.
#[test]
fn reads_and_mentions_are_never_touched() {
    let scratch = Scratch::new("guard-reads");
    passes(&scratch, "stado release status brama");
    passes(&scratch, "stado service list --unowned");
    passes(&scratch, "grep 'cargo build' notes.md");
    passes(&scratch, "cargo test --test identities");
    passes(&scratch, "cargo fmt --check");
    passes(&scratch, "stado release submit --help");
    passes(&scratch, "stado release status brama");
    passes(&scratch, "stado queue budget");
    passes(&scratch, "stado job watch job-5278 --follow");
}

/// The fleet's three daily builds are spent by the release pipeline, and on
/// 2026-09-21 a whole day went that way for single commits. Build recipes
/// and their poller were removed that evening, so what this gate stands in
/// front of is the release: it is stated first, and one entry authorizes one
/// product.
#[test]
fn submitting_a_release_is_refused_until_its_intent_is_recorded() {
    let scratch = Scratch::new("guard-fleet-builds");
    let product = "brama";
    let submit =
        format!("stado release submit --source . --commit 6c9f32cb --version 0.4.48 --product {product}");

    let stderr = refused(&scratch, &submit);
    assert!(stderr.contains("--target"), "{stderr}");

    let recorded = record(
        &scratch,
        &[
            "record", "--kind", "build", "--target", product, "--reason", REASON, "--revision",
            REVISION,
        ],
    );
    assert!(recorded.status.success(), "{}", said(&recorded));
    passes(&scratch, &submit);

    // One entry authorizes one product: the next one is still refused.
    refused(
        &scratch,
        "stado release submit --source . --commit 6c9f32cb --version 0.21.50 --product stado",
    );
}

/// An entry the registry cannot hold is no authorization: a build entry with
/// no revision is refused by the command itself, so the gate never sees one.
#[test]
fn the_command_refuses_a_build_entry_with_no_revision() {
    let scratch = Scratch::new("guard-norev");
    let refused_entry = record(
        &scratch,
        &[
            "record", "--kind", "build", "--target", "skarbiec", "--reason", REASON,
        ],
    );
    assert_eq!(refused_entry.status.code(), Some(1));
    assert!(
        said(&refused_entry).contains("--revision is required"),
        "{}",
        said(&refused_entry)
    );
}
