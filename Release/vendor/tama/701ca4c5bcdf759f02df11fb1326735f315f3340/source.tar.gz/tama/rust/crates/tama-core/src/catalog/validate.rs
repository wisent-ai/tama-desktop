//! JS `validateCatalog(root)`: what refuses, and what only warns.
//!
//! One repair lives here. A drift entry that is not material used to be
//! labelled from a fixed list of three causes — acknowledged, unsupported
//! event, runtime not required for live coverage — and an adapter-level entry
//! fits none of them, so the report told the operator the runtime was not
//! required for live coverage when the truth was that this registry declares
//! no adapter path at all. An entry that already states its own cause now
//! keeps it.

use serde::Serialize;
use std::collections::HashSet;
use std::fs;
use std::path::Path;

use crate::runtime::detect_runtime_install_drift;
use crate::Result;

use super::build::build_catalog;
use super::fs_scan::{has_high_entropy_token, js_opt, list_managed_files};

/// Result of JS `validateCatalog(root)`.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ValidationResult {
    pub ok: bool,
    pub errors: Vec<String>,
    pub warnings: Vec<String>,
    pub hook_count: usize,
    pub orphan_source_count: usize,
}

/// JS `validateCatalog(root)`.
pub fn validate_catalog(root: &Path) -> Result<ValidationResult> {
    let catalog = build_catalog(root)?;
    let mut errors: Vec<String> = Vec::new();
    let mut warnings: Vec<String> = Vec::new();
    let mut seen: HashSet<&str> = HashSet::new();
    for hook in &catalog.hooks {
        if seen.contains(hook.id.as_str()) {
            errors.push(format!("duplicate hook id: {}", hook.id));
        }
        seen.insert(hook.id.as_str());
        if hook.source_path.is_none() {
            warnings.push(format!(
                "{}: source path could not be mapped from command",
                hook.id
            ));
        }
        if let Some(source_path) = &hook.source_path {
            if !root.join(source_path).exists() {
                errors.push(format!("{}: missing source file {}", hook.id, source_path));
            }
        }
        if hook.events.is_empty() {
            errors.push(format!("{}: no events", hook.id));
        }
        if hook.hook_type == "requires_justification" {
            if hook.justification_requirements.is_empty() {
                errors.push(format!(
                    "{}: requires_justification has no requirements",
                    hook.id
                ));
            }
            let mut kinds: HashSet<Option<&str>> = HashSet::new();
            for requirement in &hook.justification_requirements {
                if requirement.kind.is_none() {
                    errors.push(format!(
                        "{}: justification requirement has no kind",
                        hook.id
                    ));
                }
                if kinds.contains(&requirement.kind.as_deref()) {
                    errors.push(format!(
                        "{}: duplicate justification kind {}",
                        hook.id,
                        js_opt(requirement.kind.as_deref())
                    ));
                }
                kinds.insert(requirement.kind.as_deref());
                let kind = js_opt(requirement.kind.as_deref());
                if requirement.registry_path.is_none() {
                    errors.push(format!(
                        "{}: {} justification has no registryPath",
                        hook.id, kind
                    ));
                }
                if requirement.field.is_none() {
                    errors.push(format!("{}: {} justification has no field", hook.id, kind));
                }
                if requirement.kind.as_deref() == Some("test")
                    && requirement.direct_user_quote_field.is_none()
                {
                    errors.push(format!(
                        "{}: test justification has no directUserQuoteField",
                        hook.id
                    ));
                }
                // JS: `!Number.isInteger(minimumWords) || minimumWords < 1`
                match requirement.minimum_words {
                    Some(words) if words >= 1 => {}
                    _ => errors.push(format!(
                        "{}: {} justification has invalid minimumWords",
                        hook.id, kind
                    )),
                }
            }
        }
    }
    for file in list_managed_files(root)? {
        let bytes = fs::read(root.join(&file))?;
        let text = String::from_utf8_lossy(&bytes);
        if has_high_entropy_token(&text) {
            errors.push(format!("{}: high-entropy token detected", file));
        }
    }
    for entry in detect_runtime_install_drift(root)? {
        let where_ = match &entry.event {
            Some(event) => format!(
                "{} {} {}",
                entry.runtime,
                event,
                js_opt(entry.hook_id.as_deref())
            ),
            None => entry.runtime.clone(),
        };
        let message = format!("install drift: {} — {}", where_, entry.reason);
        if entry.material {
            errors.push(message);
        } else if entry.hook_id.is_none() {
            // An adapter-level entry carries the whole cause in its own
            // sentence; the three labels below describe a hook, not this.
            warnings.push(format!("{message} (non-material)"));
        } else {
            let why = if entry.acknowledged.unwrap_or(false) {
                "acknowledged"
            } else if entry.unsupported_event {
                "unsupported event"
            } else {
                "runtime not required for live coverage"
            };
            warnings.push(format!("{} (non-material: {})", message, why));
        }
    }
    Ok(ValidationResult {
        ok: errors.is_empty(),
        errors,
        warnings,
        hook_count: catalog.hooks.len(),
        orphan_source_count: catalog.orphan_sources.len(),
    })
}
