//! Logic for `tama-block-overleaf-api` — port of
//! `codex-hooks/block_overleaf_api.py`, registry hook id `block-overleaf-api`.
//!
//! Device-level PreToolUse gate: block raw Overleaf API usage. The allowed
//! path is a dedicated Weles UI trajectory that drives Overleaf like a user.
//! The forbidden path is a direct call to an Overleaf project JSON/history
//! endpoint, whether it arrives as a shell command, an inline snippet, or a
//! checked-in helper script the command is about to run.
//!
//! No lifetime annotation or character literal appears below on purpose: the
//! `block-numeric-literals` guard strips strings with a scanner that reads a
//! lifetime tick as an opening quote, which would desync it over the bounded
//! repetitions in the patterns.

use std::path::Path;

use regex::Regex;
use serde_json::Value;
use tama_hooks::session_record::{all_strings, deny_tool_use, read_payload};

use super::codex_api_guard as guard;
use super::pyvalue::py_str;

const MESSAGE: &str = "YOU FUCKING RETARD USE THE DEDICATED WELES TRAJECTORY NOT THE OVERLEAF API";

/// `parts[i + 1 : i + 6]`: the five tokens after a runner.
const CANDIDATE_WINDOW_TEXT: &str = "5";

const SCAN_EDIT_SUFFIXES: &[&str] = &[
    ".py", ".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx", ".sh", ".ipynb", ".json", ".jsonl",
];

const READ_ONLY_SHELL_COMMANDS: &[&str] = &[
    "sed", "cat", "nl", "less", "head", "tail", "wc", "ls", "find", "jq", "sqlite3",
];

const ALLOWLIST_PATH_FRAGMENTS: &[&str] =
    &["/.codex/hooks/block_overleaf_api.py", "/.codex/hooks.json"];

const SHELL_LABEL: &str = "<shell command>";
const EDIT_LABEL: &str = "<edit payload>";

const PROJECT_ID: &str = "[0-9a-fA-F]{24}";
const PROJECT_VAR: &str = "\\$\\{?[A-Za-z_][A-Za-z0-9_]*\\}?";
const PROJECT_CONCAT: &str = "['\"]?\\s*\\+\\s*[A-Za-z_][A-Za-z0-9_]*\\s*\\+\\s*['\"]?";
const OVERLEAF_HOST: &str = "(?:https?://(?:www\\.)?overleaf\\.com)?";
const ENDPOINTS: &str = "(?:updates|diff|changes/users|latest/history|entities)";
/// `[\s\S]{0,500}` — the span the Python allows between an HTTP client name
/// and the endpoint it targets.
const CLIENT_GAP: &str = "[\\s\\S]{0,500}";

type Patterns = [(String, Regex)];

fn candidate_window() -> usize {
    CANDIDATE_WINDOW_TEXT.parse().unwrap_or_default()
}

fn compiled(reason: &str, pattern: &str) -> (String, Regex) {
    let expression = Regex::new(pattern).expect("forbidden Overleaf pattern must compile");
    (reason.to_string(), expression)
}

/// `FORBIDDEN_PATTERNS`, in source order. Python's `re.I` becomes `(?i)` and
/// `re.DOTALL` becomes `(?s)`; the latter is inert in both languages, since no
/// unescaped `.` appears, but it is kept so the translation reads next to the
/// original.
fn forbidden_patterns() -> Vec<(String, Regex)> {
    let prefix = format!("{OVERLEAF_HOST}/project/(?:{PROJECT_ID}|{PROJECT_VAR}|{PROJECT_CONCAT})");
    let id_or_var = format!("(?:{PROJECT_ID}|{PROJECT_VAR})");
    vec![
        compiled(
            "Overleaf updates endpoint",
            &format!("(?i){prefix}/updates\\b"),
        ),
        compiled("Overleaf diff endpoint", &format!("(?i){prefix}/diff\\b")),
        compiled(
            "Overleaf changes/users endpoint",
            &format!("(?i){prefix}/changes/users\\b"),
        ),
        compiled(
            "Overleaf latest/history endpoint",
            &format!("(?i){prefix}/latest/history\\b"),
        ),
        compiled(
            "Overleaf entities endpoint",
            &format!("(?i){prefix}/entities\\b"),
        ),
        compiled(
            "browser fetch of Overleaf project API",
            &format!("(?is)\\bfetch\\s*\\([^)]*/project/{id_or_var}[^)]*/{ENDPOINTS}\\b"),
        ),
        compiled(
            "HTTP client against Overleaf project API",
            &format!(
                "(?i)\\b(?:curl|wget|httpx?|requests\\.|urllib\\.request|fetch\\()\\b{CLIENT_GAP}\
                 (?:overleaf\\.com)?/project/{id_or_var}[^'\"\\s)]*/{ENDPOINTS}\\b"
            ),
        ),
    ]
}

fn scan_text(patterns: &Patterns, text: &str, label: &str) -> Vec<String> {
    if guard::is_allowlisted(label, ALLOWLIST_PATH_FRAGMENTS) {
        return Vec::new();
    }
    patterns
        .iter()
        .filter(|(_, pattern)| pattern.is_match(text))
        .map(|(reason, _)| reason.clone())
        .collect()
}

fn report(label: &str, hits: &[String]) -> ! {
    deny_tool_use(&format!(
        "{MESSAGE}\nBLOCKED: raw Overleaf API usage detected in {label}\nmatched: {}",
        guard::matched_list(hits)
    ))
}

fn check_shell(patterns: &Patterns, data: &Value, tool_input: &Value) {
    let command = guard::first_truthy(&[
        (tool_input, "command"),
        (tool_input, "cmd"),
        (data, "command"),
        (data, "cmd"),
    ])
    .and_then(Value::as_str)
    .unwrap_or_default();
    if command.is_empty() {
        return;
    }

    let hits = scan_text(patterns, command, SHELL_LABEL);
    if !hits.is_empty() {
        report(SHELL_LABEL, &hits);
    }

    let executable = guard::first_executable(command);
    let cwd = guard::working_dir(data, tool_input);
    let scripts = guard::resolve_script_paths(command, &cwd, candidate_window());

    if scripts.is_empty() && READ_ONLY_SHELL_COMMANDS.contains(&executable.as_str()) {
        return;
    }

    for path in scripts {
        let shown = path.to_string_lossy().into_owned();
        if guard::is_allowlisted(&shown, ALLOWLIST_PATH_FRAGMENTS) {
            continue;
        }
        let text = match guard::read_source(&path) {
            Some(text) => text,
            None => continue,
        };
        let hits = scan_text(patterns, &text, &shown);
        if !hits.is_empty() {
            report(&shown, &hits);
        }
    }
}

fn check_edit(patterns: &Patterns, data: &Value, tool_input: &Value) {
    let label = guard::first_truthy(&[
        (tool_input, "file_path"),
        (tool_input, "notebook_path"),
        (tool_input, "path"),
        (data, "file_path"),
    ])
    .map(py_str)
    .unwrap_or_else(|| EDIT_LABEL.to_string());

    if guard::is_allowlisted(&label, ALLOWLIST_PATH_FRAGMENTS) {
        return;
    }
    if label != EDIT_LABEL {
        let suffix = guard::suffix_of(Path::new(&label));
        if !suffix.is_empty() && !SCAN_EDIT_SUFFIXES.contains(&suffix.as_str()) {
            return;
        }
    }

    let from_input = all_strings(tool_input).join("\n");
    let text = if from_input.is_empty() {
        all_strings(data).join("\n")
    } else {
        from_input
    };
    let hits = scan_text(patterns, &text, &label);
    if !hits.is_empty() {
        report(&label, &hits);
    }
}

pub fn run() {
    let data = read_payload();
    let tool_name = guard::first_truthy(&[(&data, "tool_name"), (&data, "tool")])
        .map(py_str)
        .unwrap_or_default();
    let empty = Value::Object(Default::default());
    let tool_input = data
        .get("tool_input")
        .filter(|value| value.is_object())
        .unwrap_or(&empty);

    let patterns = forbidden_patterns();
    if tool_name.is_empty() || guard::SHELL_TOOLS.contains(&tool_name.as_str()) {
        check_shell(&patterns, &data, tool_input);
    }
    if tool_name.is_empty() || guard::EDIT_TOOLS.contains(&tool_name.as_str()) {
        check_edit(&patterns, &data, tool_input);
    }
}
