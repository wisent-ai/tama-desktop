//! Where a scan or a repair finds the write guard it replays.
//!
//! `repo_root()` is compiled in from `CARGO_MANIFEST_DIR`, and the installed
//! CLI is built inside the release's export tree — a directory the release
//! deletes as soon as the build finishes. So every default scan run outside a
//! tama checkout refused with
//! `hook not found: .../rust/target/hook-release-src/shared-hooks/pre_write_edit.sh`,
//! naming a path that has not existed since the release that built the
//! binary. That is what answered a whole-workshop size audit on 2026-09-21:
//! nothing scanned, one dead path printed, and no statement of where else a
//! hook could have been found.
//!
//! `tama install` writes the guards to `~/.shared-hooks`, and that copy is
//! the one enforcing policy on this machine, so it answers when the checkout
//! does not. A `--hook` the caller named always wins over both.

use std::path::{Path, PathBuf};

use crate::homedir;

/// The guard the replay drives. `block_oversized_files.sh` is read from
/// beside it, so both halves of the size rule come from one tree.
pub const HOOK_FILE: &str = "pre_write_edit.sh";

/// Every place a hook tree lives, in the order they are consulted: the
/// checkout the command resolved, then the installed copy.
pub fn hook_candidates(root: &Path) -> Vec<PathBuf> {
    vec![
        root.join("shared-hooks").join(HOOK_FILE),
        homedir().join(".shared-hooks").join(HOOK_FILE),
    ]
}

/// The default `--hook`: the first candidate that is really there. When
/// neither is, the checkout path is returned so the refusal names the place a
/// source tree would hold it.
pub fn default_hook_path(root: &Path) -> PathBuf {
    let mut first = None;
    for candidate in hook_candidates(root) {
        if candidate.is_file() {
            return candidate;
        }
        if first.is_none() {
            first = Some(candidate);
        }
    }
    first.unwrap_or_else(|| PathBuf::from(HOOK_FILE))
}

/// The `hook not found` refusal.
///
/// The first line stays the documented sentence. When the caller named no
/// hook, the following lines say which paths were tried and what makes the
/// scan runnable again, because a single dead path is not a diagnosis.
pub fn hook_missing_message(path: &str, root: &Path, explicit: bool) -> String {
    let refusal = format!("hook not found: {path}");
    if explicit {
        return refusal;
    }
    let searched: Vec<String> = hook_candidates(root)
        .iter()
        .map(|candidate| format!("  {}", candidate.display()))
        .collect();
    format!(
        "{refusal}\nsearched:\n{}\ninstall the guards with `tama install`, name one with --hook, \
         or use --size-only for the two size rules, which need no hook.",
        searched.join("\n")
    )
}
