//! Preserve failed Git observations alongside the copy they describe.
use std::path::Path;

use super::{discovery::Copy, state};

pub(super) fn inspect(
    candidate: String,
    origin: Option<String>,
    owner: Option<String>,
    canonicals: &[(String, String)],
) -> Copy {
    let path = Path::new(&candidate);
    let dirty = state::dirty(path);
    let history = state::history(
        path,
        owner.as_deref(),
        canonicals.iter().map(|(_, path)| path.as_str()),
    );
    let mut errors = Vec::new();
    let dirty = match dirty {
        Ok(value) => Some(value),
        Err(error) => {
            errors.push(error);
            None
        }
    };
    let (unpublished, history_retained_by) = match history {
        Ok((value, retained)) => (Some(value), retained),
        Err(error) => {
            errors.push(error);
            (None, None)
        }
    };
    Copy {
        bytes: state::bytes(path),
        owns_worktrees: state::owns_worktrees(path),
        path: candidate,
        origin,
        owner,
        dirty,
        unpublished,
        history_retained_by,
        inspection_error: if errors.is_empty() {
            None
        } else {
            Some(errors.join("\n"))
        },
        named: false,
    }
}
