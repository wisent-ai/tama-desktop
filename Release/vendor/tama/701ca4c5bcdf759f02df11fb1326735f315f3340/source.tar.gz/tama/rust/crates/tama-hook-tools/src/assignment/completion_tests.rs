//! How the guard reads Oko's ledger. The shapes below are the ones
//! `tama-cli assignment show` returned for session 01a0b600… on 2026-09-19:
//! an original task with its proof and a judge outage newer than it, and a
//! reaction message Oko relates to it as `duplicate-of`.

use super::*;
use serde_json::json;

fn ledger(tasks: serde_json::Value) -> rules::TaskLedger {
    rules::TaskLedger {
        value: json!({ "tasks": tasks }),
        digest: String::new(),
    }
}

fn original(with_proof: bool) -> serde_json::Value {
    let mut task = json!({
        "id": "task-01caae3a30c2003a", "ordinal": 14, "status": "not done",
        "text": "Ty masz robic WSZYSTKIE ZADANIA. WSZYSTKIE SESJE MAJA PRACOWAC",
        "relations": [{ "name": "duplicated-by", "other": "task-ac220c91886342b1" }],
    });
    if with_proof {
        task["proof"] = json!({ "recordedAt": "2026-09-19T02:06:25Z" });
        task["judgeOutage"] = json!({ "at": "2026-09-19T02:06:46Z",
            "detail": "Brama answered HTTP 429: subscription_unavailable" });
    }
    task
}

fn duplicate() -> serde_json::Value {
    json!({
        "id": "task-ac220c91886342b1", "ordinal": 24, "status": "not done",
        "text": "jestes chory psychicznie. nie da sie z Toba pracowac",
        "relations": [{ "name": "duplicate-of", "other": "task-01caae3a30c2003a" }],
        "waitingOn": ["task-01caae3a30c2003a"],
    })
}

#[test]
fn a_duplicate_is_carried_by_its_original() {
    let pending = pending_from(&ledger(json!([original(true), duplicate()]))).unwrap();
    assert!(pending.is_empty(), "{pending:?}");
}

#[test]
fn an_original_without_proof_still_holds_the_turn_and_its_duplicate_is_not_listed_twice() {
    let pending = pending_from(&ledger(json!([original(false), duplicate()]))).unwrap();
    assert_eq!(pending.len(), 1, "{pending:?}");
    assert!(pending[0].starts_with("#14: "), "{pending:?}");
}
