//! What Oko's registers say about the entry a scope declaration names.
//!
//! Split out of `scope_cli.rs`, which had grown past the three-hundred-line
//! limit; the command itself stays there.

/// The open defect this identifier names, or why it is not one.
///
/// The register is the authority, not the session's memory of it: a defect
/// nobody recorded, or one already closed by a revision, authorises nothing.
pub(super) fn open_defect(id: &str) -> Result<String, String> {
    let output = std::process::Command::new(oko_cli())
        .args(["defects", "show", id, "--json"])
        .stdin(std::process::Stdio::null())
        .output()
        .map_err(|error| format!("cannot run the Oko CLI for defect {id}: {error}"))?;
    if !output.status.success() {
        return Err(format!(
            "Oko's register holds no defect {id}: {}",
            String::from_utf8_lossy(&output.stderr).trim()
        ));
    }
    let text = String::from_utf8_lossy(&output.stdout).to_string();
    if text.contains("\"fixed_at\"") {
        return Err(format!(
            "defect {id} is already closed, so no work belongs to it; record what is wrong now \
             with `oko-cli defects record`"
        ));
    }
    Ok(id.to_string())
}

/// The task this identifier names in Oko's task register, or why it is none.
pub(super) fn known_task(id: &str) -> Result<String, String> {
    let output = std::process::Command::new(oko_cli())
        .args(["transcripts", "tasks", "show", id, "--json"])
        .stdin(std::process::Stdio::null())
        .output()
        .map_err(|error| format!("cannot run the Oko CLI for task {id}: {error}"))?;
    if !output.status.success() {
        return Err(format!(
            "Oko's task register holds no task {id}: {}",
            String::from_utf8_lossy(&output.stderr).trim()
        ));
    }
    Ok(id.to_string())
}

/// The Oko CLI this machine has, the way the assignment reader resolves it.
fn oko_cli() -> String {
    std::env::var("TAMA_OKO_CLI")
        .ok()
        .filter(|value| !value.is_empty())
        .unwrap_or_else(|| "oko-cli".to_string())
}
