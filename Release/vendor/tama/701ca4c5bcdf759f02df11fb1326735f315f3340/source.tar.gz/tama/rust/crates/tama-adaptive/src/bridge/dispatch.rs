//! Handing one prompt to the feedback bridge, without waiting for it.
//!
//! Both entry points that see an owner prompt call this: the legacy
//! per-provider runner, and the shared runtime the providers talk to now. The
//! shared runtime never did, so on a machine driven through it no prompt ever
//! reached the bridge, nothing was ever contested, and the repair queue stayed
//! empty while hooks blocked many times a day — measured 2026-09-10.
//!
//! The child is the running executable with the `adaptive-bridge` argument, so
//! whichever binary calls this has to route that argument to `bridge::main`.
//! Failure is silent by design: feedback attribution may never change a
//! verdict, and the bridge outlives the dispatch that started it.

use std::io::Write;
use std::os::unix::process::CommandExt;
use std::process::{Command, Stdio};

pub fn dispatch(normalized: &str) {
    let attempt = || -> std::io::Result<()> {
        let exe = std::env::current_exe()?;
        let mut child = unsafe {
            Command::new(exe)
                .arg("adaptive-bridge")
                .stdin(Stdio::piped())
                .stdout(Stdio::null())
                .stderr(Stdio::null())
                .pre_exec(|| {
                    detach_session();
                    Ok(())
                })
                .spawn()?
        };
        if let Some(mut stdin) = child.stdin.take() {
            let _ = stdin.write_all(normalized.as_bytes());
        }
        Ok(())
    };
    let _ = attempt();
}

extern "C" {
    fn setsid() -> i32;
}

fn detach_session() {
    unsafe {
        setsid();
    }
}
