use std::net::TcpStream;
use std::path::PathBuf;

use super::http::{json_body, send_error, send_json, Request};
use crate::builds::api;

pub(super) fn handle(request: Request, writer: &mut TcpStream) {
    let home = match std::env::var_os("HOME") {
        Some(home) => PathBuf::from(home),
        None => return send_error(writer, 500, "HOME is not set"),
    };
    let result = if request.method == "GET" {
        api::list(&home)
    } else {
        let body = match json_body(&request) {
            Ok(body) => body,
            Err((status, message)) => return send_error(writer, status, &message),
        };
        if request.path == "/v1/builds/close" {
            serde_json::from_value::<api::CloseRequest>(body)
                .map_err(|error| format!("invalid build close request: {error}"))
                .and_then(|input| input.close(&home))
        } else {
            serde_json::from_value::<api::RecordRequest>(body)
                .map_err(|error| format!("invalid build record request: {error}"))
                .and_then(|input| input.record(&home))
        }
    };
    match result {
        Ok(document) => send_json(writer, 200, &document),
        Err(error) => send_error(writer, 400, &error),
    }
}
