//! What Brama says about this machine's credentials, without spending quota.
//!
//! `GET /v1/models` is the documented first machine workflow: one bearer, no
//! agent signature, no provider call. It separates the two ways a chat
//! request can be refused — an unknown client bearer answers here too, while
//! a bearer that works here and a chat that still returns 401 means the
//! agent signature or its secret is the problem.

use std::process::{Command, Stdio};

use serde::Serialize;

use super::credentials::{allowed_endpoint, read};

/// What the probe observed. No credential value ever enters this struct.
#[derive(Debug, Serialize)]
pub struct Reachability {
    /// The chat endpoint the client would post to.
    pub endpoint: String,
    /// Whether that endpoint passes the client's own transport policy.
    pub endpoint_allowed: bool,
    /// The models endpoint actually probed.
    pub probed: String,
    pub status: Option<u16>,
    /// Brama's own error body, or the model count when it answered.
    pub detail: String,
    /// Who this machine says it is, and where its token lives.
    pub consumer: String,
    pub token_file: String,
    /// The route the reviewer would ask for.
    pub route: String,
    /// Whether this machine's own authority grants that route to that
    /// consumer on the token in that file.
    pub local_grant: Option<bool>,
    pub local_grant_detail: String,
    /// Which of the two halves is missing, in one sentence.
    pub verdict: String,
}

/// The sentence an operator acts on.
///
/// A `401` used to mean "repair that credential at its authority", which sent
/// three hours into the vault on 2026-09-11 while the bearer had been valid
/// there all along: the gateway was deployed without the authority variables
/// that let it ask. These two facts, read together, say which side is wrong.
pub fn verdict(status: Option<u16>, allowed: bool, local_grant: Option<bool>) -> String {
    let unauthorized: u16 = "401".parse().expect("valid HTTP status");
    let accepted: u16 = "200".parse().expect("valid HTTP status");
    if !allowed {
        return "the address this machine resolved is not one this client may use".to_string();
    }
    match (status, local_grant) {
        (Some(code), _) if code == accepted => "the gateway accepts this bearer".to_string(),
        (Some(code), Some(true)) if code == unauthorized => {
            "this machine's authority grants the route on this bearer, and the gateway still \
             refuses it: the gateway is not asking this authority - check that its deployment \
             carries WC_SKARBIEC_URL, BRAMA_SKARBIEC_CONSUMER and BRAMA_SKARBIEC_TOKEN_FILE"
                .to_string()
        }
        (Some(code), Some(false)) if code == unauthorized => {
            "this machine's authority does not grant this route to this consumer: issue it with \
             `skarbiec grant issue <consumer> --capabilities call:brama#<route> --token-file \
             <path>`"
                .to_string()
        }
        (Some(code), None) if code == unauthorized => {
            "the gateway refuses this bearer and this machine's authority could not be asked"
                .to_string()
        }
        (Some(code), _) => format!("the gateway answered {code}; read the detail below"),
        (None, _) => "nothing answered at that address".to_string(),
    }
}

fn models_url(chat_endpoint: &str) -> String {
    chat_endpoint
        .strip_suffix("/chat/completions")
        .map(|base| format!("{base}/models"))
        .unwrap_or_else(|| chat_endpoint.to_string())
}

/// Presents the client bearer to `GET /v1/models` and reports what Brama
/// answered. Errors only when the credentials cannot be read at all.
pub fn reachability() -> Result<Reachability, String> {
    let credentials = read()?;
    let endpoint = credentials.endpoint.clone();
    let probed = models_url(&endpoint);
    let output = Command::new("/usr/bin/curl")
        .args(["--silent", "--show-error", "--max-time", "20"])
        .args(["--write-out", "\n%{http_code}"])
        .args([
            "--header",
            &format!("Authorization: Bearer {}", credentials.bearer),
        ])
        .args(["--header", "Accept: application/json"])
        .arg(&probed)
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .output()
        .map_err(|error| format!("cannot start Brama HTTP client: {error}"))?;
    let route = super::credentials::model_route()?;
    let (local_grant, local_grant_detail) = match super::credentials::local_grant(&route) {
        Ok(allowed) => (Some(allowed), String::new()),
        Err(refusal) => (None, refusal),
    };
    let consumer = super::credentials::consumer();
    let token_file = super::credentials::token_path().display().to_string();
    let allowed = allowed_endpoint(&endpoint);
    if !output.status.success() {
        return Ok(Reachability {
            endpoint_allowed: allowed,
            endpoint,
            probed,
            status: None,
            detail: String::from_utf8_lossy(&output.stderr).trim().to_string(),
            consumer,
            token_file,
            route,
            local_grant,
            local_grant_detail,
            verdict: verdict(None, allowed, local_grant),
        });
    }
    let response = String::from_utf8_lossy(&output.stdout).to_string();
    let (body, code) = response
        .rsplit_once('\n')
        .ok_or_else(|| "Brama response omitted its HTTP status".to_string())?;
    let status = code.trim().parse::<u16>().ok();
    let detail = model_count(body).unwrap_or_else(|| body.trim().to_string());
    Ok(Reachability {
        endpoint_allowed: allowed,
        endpoint,
        probed,
        status,
        detail,
        consumer,
        token_file,
        route,
        local_grant,
        local_grant_detail,
        verdict: verdict(status, allowed, local_grant),
    })
}

#[cfg(test)]
mod tests {
    use super::verdict;

    const ACCEPTED: u16 = 200;
    const UNAUTHORIZED: u16 = 401;
    const SERVER_ERROR: u16 = 503;

    /// The state this machine was in on 2026-09-11: the bearer was valid at
    /// its own authority all along, and the gateway was deployed without the
    /// variables that let it ask. The sentence has to send the reader to the
    /// gateway, not back into the vault.
    #[test]
    fn a_granted_route_refused_by_the_gateway_points_at_the_gateway() {
        let said = verdict(Some(UNAUTHORIZED), true, Some(true));
        assert!(
            said.contains("not asking this authority") && said.contains("WC_SKARBIEC_URL"),
            "{said}"
        );
    }

    #[test]
    fn a_missing_grant_points_at_this_machine_and_names_the_repair() {
        let said = verdict(Some(UNAUTHORIZED), true, Some(false));
        assert!(
            said.contains("does not grant this route") && said.contains("skarbiec grant issue"),
            "{said}"
        );
    }

    #[test]
    fn an_unreachable_authority_is_not_reported_as_a_missing_grant() {
        let said = verdict(Some(UNAUTHORIZED), true, None);
        assert!(
            said.contains("could not be asked") && !said.contains("does not grant"),
            "{said}"
        );
    }

    #[test]
    fn an_accepted_bearer_and_a_refused_address_are_their_own_answers() {
        assert!(verdict(Some(ACCEPTED), true, Some(false)).contains("accepts this bearer"));
        assert!(verdict(Some(ACCEPTED), false, Some(true)).contains("not one this client may use"));
        assert!(verdict(Some(SERVER_ERROR), true, Some(true)).contains("answered 503"));
        assert!(verdict(None, true, Some(true)).contains("nothing answered"));
    }
}

/// A successful answer is a model list; report its size rather than its
/// contents, which are long and not what the probe is asking about.
fn model_count(body: &str) -> Option<String> {
    let decoded: serde_json::Value = serde_json::from_str(body).ok()?;
    let models = decoded.get("data")?.as_array()?;
    Some(format!("{} models offered", models.len()))
}
