//! One model judgement, asked through Brama.
//!
//! Tama's guards judge text. Where a rule cannot be decided by shape — is
//! this claim grounded, does this sentence hand work back to the operator —
//! the honest decider is a model, and on this fleet every model call goes
//! through Brama. A hook that spawned a vendor CLI (`claude -p`) was asking
//! a provider directly, which is the boundary `~/agents/boundaries.md`
//! draws, and it also meant the hook worked only on a machine where that
//! vendor's binary was installed and signed in.
//!
//! The route is the product's own one-shot call, `oko-cli proxy-call`: Oko
//! owns the signed-agent bearer and the local router proxy, and the call
//! returns Brama's OpenAI-shaped answer. A judgement nobody could obtain is
//! never a denial — an absent CLI, a spawn error, a non-200 body, an empty
//! answer all yield [`Judgement::Unavailable`], and a guard that gets one
//! lets the turn through.

use std::path::PathBuf;
use std::process::{Command, Stdio};

/// Where the answer's text lives in Brama's OpenAI-shaped reply.
const CHOICES: &str = "choices";
const MESSAGE: &str = "message";
const CONTENT: &str = "content";
/// `oko-cli proxy-call` prints the status line and headers, then the body
/// after this separator on its own line.
const BODY_SEPARATOR: &str = "\n---\n";
const OKO_CLI: &str = "oko-cli";
/// Where an installed Oko CLI lives when PATH does not carry it.
const INSTALLED: &str = "~/.local/bin/oko-cli";

/// What the model said, or why nothing was said.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Judgement {
    /// The model answered; the text is its answer, trimmed.
    Answered(String),
    /// Nobody could be asked. The string says what happened, for the log.
    Unavailable(String),
}

impl Judgement {
    /// The answer, or `None` when there was none. A guard that denies on a
    /// verdict uses this, so an unreachable Brama can never deny.
    pub fn answer(&self) -> Option<&str> {
        match self {
            Self::Answered(text) => Some(text.as_str()),
            Self::Unavailable(_) => None,
        }
    }
}

/// The Oko CLI this machine has, from PATH or from its installed location.
fn oko_cli() -> Option<PathBuf> {
    use std::os::unix::fs::PermissionsExt;
    let executable = |candidate: PathBuf| -> Option<PathBuf> {
        let meta = std::fs::metadata(&candidate).ok()?;
        let any_execute = u32::from_str_radix("111", 8).unwrap_or_default();
        (!meta.is_dir() && meta.permissions().mode() & any_execute != 0).then_some(candidate)
    };
    let path = std::env::var("PATH").unwrap_or_default();
    for directory in path.split(':').filter(|entry| !entry.is_empty()) {
        if let Some(found) = executable(PathBuf::from(directory).join(OKO_CLI)) {
            return Some(found);
        }
    }
    executable(PathBuf::from(super::python_stdlib::expanduser(INSTALLED)))
}

/// The body of an `oko-cli proxy-call` response, as JSON.
fn body(output: &str) -> Option<serde_json::Value> {
    let (_, body) = output.split_once(BODY_SEPARATOR)?;
    serde_json::from_str(body.trim()).ok()
}

/// Ask Brama one question and return what it said.
///
/// `prompt` is the whole prompt, including whatever answer format the caller
/// requires; this port does not interpret the answer, so a guard keeps its
/// own contract with the model.
pub fn ask(prompt: &str) -> Judgement {
    let Some(cli) = oko_cli() else {
        return Judgement::Unavailable(format!("{OKO_CLI} is not installed on this machine"));
    };
    let spawned = Command::new(&cli)
        .arg("proxy-call")
        .arg("--prompt")
        .arg(prompt)
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn();
    let child = match spawned {
        Ok(child) => child,
        Err(error) => return Judgement::Unavailable(format!("{OKO_CLI} did not start: {error}")),
    };
    let output = match child.wait_with_output() {
        Ok(output) => output,
        Err(error) => return Judgement::Unavailable(format!("{OKO_CLI} did not finish: {error}")),
    };
    let stdout = String::from_utf8_lossy(&output.stdout).to_string();
    if !output.status.success() {
        let detail = String::from_utf8_lossy(&output.stderr).trim().to_string();
        let said = if detail.is_empty() {
            stdout.trim().to_string()
        } else {
            detail
        };
        return Judgement::Unavailable(format!("Brama refused the call: {said}"));
    }
    let Some(body) = body(&stdout) else {
        return Judgement::Unavailable(format!(
            "Brama answered nothing readable: {}",
            stdout.trim()
        ));
    };
    let text = body[CHOICES]
        .get(0)
        .and_then(|choice| choice.get(MESSAGE))
        .and_then(|message| message.get(CONTENT))
        .and_then(serde_json::Value::as_str)
        .unwrap_or_default()
        .trim()
        .to_string();
    if text.is_empty() {
        return Judgement::Unavailable("Brama answered with an empty message".to_string());
    }
    Judgement::Answered(text)
}

#[cfg(test)]
mod tests {
    use super::{body, Judgement};

    #[test]
    fn the_answer_is_read_out_of_bramas_reply() {
        let reply = "HTTP 200\n  content-type: application/json\n---\n\
{\"choices\":[{\"message\":{\"role\":\"assistant\",\"content\":\"PASS\"}}]}\n";
        let parsed = body(reply).expect("a JSON body after the separator");
        assert_eq!(parsed["choices"][0]["message"]["content"], "PASS");
    }

    #[test]
    fn a_reply_without_a_body_is_not_an_answer() {
        assert!(body("HTTP 503\n  content-type: application/json\n").is_none());
    }

    /// The whole point of the type: a guard asking for the answer of an
    /// unavailable judgement gets nothing, so it cannot deny.
    #[test]
    fn an_unavailable_judgement_carries_no_answer() {
        assert_eq!(Judgement::Unavailable("gateway down".into()).answer(), None);
        assert_eq!(
            Judgement::Answered("BLOCK: no evidence".into()).answer(),
            Some("BLOCK: no evidence")
        );
    }
}
