//! What the fleet says is left of today's builds.
//!
//! Until 2026-09-21 this gate kept its own count of builds beside Stado's,
//! and on that evening the two disagreed in the same minute: `tama build
//! record --kind build --target brama` refused with "the policy allows 3
//! builds in any 24 hours and this machine has spent all 3 … the next one is
//! authorized in 367 min", while `stado queue budget` answered "1 of 3 build
//! job(s) used, 2 left". One counted intents recorded on this machine over a
//! rolling day, the other counted jobs the fleet actually charged over a UTC
//! day. Two ceilings enforced by different arithmetic mean nobody can say
//! whether a build is permitted.
//!
//! So the count belongs to the fleet, which is where a build is really spent,
//! and this gate asks it. What stays here is the judgement Stado does not
//! make: whether this particular build carries enough accumulated change to
//! be worth one of them.

use std::path::PathBuf;
use std::process::Command;

use serde_json::Value;

/// Where the fleet's own CLI lives, as every other Tama caller of it looks.
fn stado() -> PathBuf {
    let home = std::env::var("HOME").unwrap_or_else(|_| String::from("."));
    PathBuf::from(home).join(".local").join("bin").join("stado")
}

/// What the fleet says is left of today's builds, or `None` when the fleet
/// could not be asked at all — a missing binary, a refusal, or an answer this
/// build cannot read. `None` is not permission: the caller keeps its own
/// count for that case.
pub fn remaining() -> Option<u64> {
    let binary = stado();
    if !binary.is_file() {
        return None;
    }
    let output = Command::new(&binary)
        .args(["queue", "budget", "--json"])
        .output()
        .ok()?;
    if !output.status.success() {
        return None;
    }
    let document: Value = serde_json::from_slice(&output.stdout).ok()?;
    document.get("remaining").and_then(Value::as_u64)
}

/// The refusal when the fleet itself has nothing left today.
pub fn spent_refusal() -> String {
    String::from(
        "the fleet's daily build budget is spent: `stado queue budget` reports nothing left \
         today, and the count resets at midnight UTC. Gather the work into one build instead, \
         or record the user's explicit exception with `tama-cli build record --approval-session \
         <id> --approval-quote <verbatim message>`. This leaves the default ceiling unchanged.",
    )
}

