//! State locations: the platform state root and the env-overridable
//! session-control and emergency-state paths.

use std::env;
use std::path::PathBuf;

use crate::jsutil;

/// Platform state root, mirroring `tamaStateRoot()`.
pub fn tama_state_root() -> PathBuf {
    #[cfg(target_os = "macos")]
    {
        jsutil::home_dir()
            .join("Library")
            .join("Application Support")
            .join("Tama")
    }
    #[cfg(target_os = "windows")]
    {
        let base = env::var_os("LOCALAPPDATA")
            .filter(|v| !v.is_empty())
            .map(PathBuf::from)
            .unwrap_or_else(|| jsutil::home_dir().join("AppData").join("Local"));
        base.join("Tama")
    }
    #[cfg(all(unix, not(target_os = "macos")))]
    {
        let base = env::var_os("XDG_STATE_HOME")
            .filter(|v| !v.is_empty())
            .map(PathBuf::from)
            .unwrap_or_else(|| jsutil::home_dir().join(".local").join("state"));
        base.join("tama")
    }
    #[cfg(not(any(unix, windows)))]
    {
        jsutil::home_dir().join(".tama")
    }
}

/// `sessionControlRoot` — `TAMA_SESSION_CONTROL_ROOT` or
/// `<tamaStateRoot>/session-control`.
pub fn session_control_root() -> PathBuf {
    env::var_os("TAMA_SESSION_CONTROL_ROOT")
        .filter(|v| !v.is_empty())
        .map(PathBuf::from)
        .unwrap_or_else(|| tama_state_root().join("session-control"))
}

/// `emergencyStatePath` — `TAMA_EMERGENCY_STATE` or
/// `<tamaStateRoot>/hook-emergency-state.json`.
pub fn emergency_state_path() -> PathBuf {
    env::var_os("TAMA_EMERGENCY_STATE")
        .filter(|v| !v.is_empty())
        .map(PathBuf::from)
        .unwrap_or_else(|| tama_state_root().join("hook-emergency-state.json"))
}
