//! Violation cleaner ("gate"): scans target repositories with the real hook
//! replay, hands the violation report to Brama for one patch per repository
//! per round, applies it, then re-scans. Repeats until clean or out of
//! rounds. Kill switch: the disable variable named in `cli`. Test seam:
//! TAMA_CLEAN_AGENT_CMD replaces the model step. Audit journal:
//! state/clean-journal.jsonl; per-repo mkdir locks in state/clean-locks/.
//!
//! The parts live in their own modules because the whole loop shared one
//! file and the file could not be edited under the three-hundred-line rule.
//! `cli` is what the operator types; `rounds` is the repair loop with the
//! brief it sends, the agent it calls and the journal it writes.

pub mod cli;
pub mod rounds;

pub use cli::{
    clean_summary_lines, default_route, main, parse_clean_args, print_clean_usage, CleanArgs,
    CleanJsonOutput,
};
pub use rounds::brief::{build_brief, is_actionable, BriefParams, GENERATED_PATHS};
pub use rounds::{clean_repo, CleanParams, CleanResult, Round};
