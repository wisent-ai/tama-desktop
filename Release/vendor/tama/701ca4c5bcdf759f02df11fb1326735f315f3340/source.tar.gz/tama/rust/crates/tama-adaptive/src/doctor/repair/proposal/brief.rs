//! The brief a repair candidate is drafted from: the hook, its script, and
//! samples of what must block and what must pass.
//!
//! Split out of `doctor/repair.rs`, which had grown past the
//! three-hundred-line limit.

use std::fs;
use std::path::{Path, PathBuf};

use super::super::corpus::{hook_paths, split_corpus};
use super::super::{SAMPLE_CHARS, SAMPLE_LIMIT};
use crate::engine::load_engine;

pub struct Brief {
    pub hook_id: String,
    pub command: Option<String>,
    pub live: Option<String>,
    pub archive: Option<PathBuf>,
    pub must_pass_count: usize,
    pub must_block_count: usize,
    pub text: String,
}

/// `buildBrief(hookId)`.
pub fn build_brief(hook_id: &str) -> Result<Brief, String> {
    let core = load_engine();
    let paths = hook_paths(hook_id, &core);
    let corpus = split_corpus(&core.state_dir, hook_id)?;
    let source_path = paths
        .live
        .clone()
        .filter(|live| Path::new(live).exists())
        .or_else(|| {
            paths
                .archive
                .as_ref()
                .map(|a| a.to_string_lossy().to_string())
        });
    let source = source_path
        .as_deref()
        .filter(|p| Path::new(p).exists())
        .and_then(|p| fs::read_to_string(p).ok())
        .unwrap_or_default();
    let sample = |rows: &[serde_json::Value]| -> Vec<String> {
        rows.iter()
            .rev()
            .take(SAMPLE_LIMIT)
            .collect::<Vec<_>>()
            .into_iter()
            .rev()
            .map(|row| {
                let payload = row
                    .get("payload")
                    .cloned()
                    .unwrap_or_else(|| serde_json::json!({}));
                let text = serde_json::to_string(&payload).unwrap_or_default();
                text.chars().take(SAMPLE_CHARS).collect()
            })
            .collect()
    };
    let mut lines: Vec<String> = vec![
        format!("Hook under repair: {}", hook_id),
        format!(
            "Live script: {}",
            paths
                .live
                .clone()
                .unwrap_or_else(|| "unknown path".to_string())
        ),
        format!(
            "Registry command: {}",
            paths
                .command
                .clone()
                .unwrap_or_else(|| "not registered".to_string())
        ),
        "Goal: produce a minimal patch of the script so that every MUST-BLOCK payload".to_string(),
        "still blocks (nonzero exit or {\"decision\":\"block\"} JSON) and every MUST-PASS"
            .to_string(),
        "payload passes cleanly (zero exit, no block JSON). It must not crash on {}.".to_string(),
        format!(
            "--- MUST BLOCK payload samples ({} total) ---",
            corpus.must_block.len()
        ),
    ];
    lines.extend(sample(&corpus.must_block));
    lines.push(format!(
        "--- MUST PASS payload samples ({} total) ---",
        corpus.must_pass.len()
    ));
    lines.extend(sample(&corpus.must_pass));
    lines.push("--- CURRENT SOURCE ---".to_string());
    lines.push(source);
    lines.push(
        "Reply with the complete corrected file content only. No commentary, no markdown fences."
            .to_string(),
    );
    Ok(Brief {
        hook_id: hook_id.to_string(),
        command: paths.command,
        live: paths.live,
        archive: paths.archive,
        must_pass_count: corpus.must_pass.len(),
        must_block_count: corpus.must_block.len(),
        text: lines.join("\n"),
    })
}
