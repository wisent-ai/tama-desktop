//! Command layer extracted from the crate root: argument helpers, output
//! helpers, and the per-command handlers `main()` dispatches to.

pub mod args;
pub mod commands;
pub mod output;
pub mod sessions;

/// Where `tama hooks release` records the checkout it installed from,
/// relative to the operator's home. An installed copy run from anywhere
/// else has no other way to find the registry: the working directory is not
/// a checkout and the compiled-in path is the build tree the release
/// deleted, so the command reported "0/0 installed" from the operator's own
/// prompt on 2026-09-21.
pub const INSTALLED_CHECKOUT_FILE: &str = ".tama/installed-from";
