//! Logic for `tama-detect-frustration`, registry hook `detect-frustration`:
//! when the operator is correcting the assistant, turn the correction into a
//! rule instead of forgetting it.
//!
//! The hook itself answers immediately and never blocks a prompt: it reads
//! the message, decides whether it looks like a correction at all, and if so
//! hands the work to a detached copy of itself. The model calls and the
//! registry write happen there, so a slow gateway cannot delay the operator's
//! turn.
//!
//! What changed from the shell: the model is reached through Brama rather than
//! a provider's command-line tool, and the drafted rule is recorded as a row
//! in `auto_rules` rather than spliced into a protected script. A draft that
//! names a script, or carries a pattern that does not compile, is logged and
//! dropped — the log is the operator's record either way.

mod drafter;
mod record;

use std::sync::LazyLock;

use regex::Regex;
use serde_json::Value;
use tama_hooks::session_record::read_payload;

use crate::ports::python_stdlib::expanduser;
use crate::ports::transport_common as common;

const ACTIVE_ENV: &str = "DETECT_FRUSTRATION_ACTIVE";
const ACTIVE_VALUE: &str = "1";
const DRAFT_FLAG: &str = "--draft";
const PROMPT_ENV: &str = "TAMA_FRUSTRATION_PROMPT";
const PRIOR_ENV: &str = "TAMA_FRUSTRATION_PRIOR";
const PROMPT_KEY: &str = "prompt";
const TRANSCRIPT_KEY: &str = "transcript_path";
const REGISTRY_PATH: &str = "~/.shared-hooks/auto_rules.json";
/// `tail -300` of the transcript, `tail -c 1500` of the assistant text, and
/// `${PROMPT:0:120}` in the log line.
const TAIL_LINES_TEXT: &str = "300";
const PRIOR_CHARS_TEXT: &str = "1500";
const LOGGED_CHARS_TEXT: &str = "120";

/// The shapes a correction takes, from the one declaration in
/// `tama_core::frustration`. The detector, the adaptive bridge and the
/// shell script it replaced each used to carry their own copy.
static FRUSTRATION: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        "(?i){}",
        tama_core::frustration::correction_pattern("[[:space:]]")
    ))
});

fn count(text: &str) -> usize {
    text.parse().unwrap_or_default()
}

/// Whether this message reads as a correction of the assistant.
pub fn looks_like_a_correction(prompt: &str) -> bool {
    !prompt.is_empty() && FRUSTRATION.is_match(prompt)
}

fn assistant_text(value: &Value) -> String {
    match value.get("content") {
        Some(Value::String(text)) => text.clone(),
        Some(Value::Array(parts)) => parts
            .iter()
            .filter_map(|part| part.get("text").and_then(Value::as_str))
            .collect::<Vec<_>>()
            .join(" "),
        _ => String::new(),
    }
}

/// The assistant's last words before the correction, for context.
pub fn prior_turn(transcript: &str) -> String {
    let Ok(text) = std::fs::read_to_string(transcript) else {
        return String::new();
    };
    let lines: Vec<&str> = text.lines().collect();
    let start = lines.len().saturating_sub(count(TAIL_LINES_TEXT));
    let mut collected = String::new();
    for line in &lines[start..] {
        let Ok(entry) = serde_json::from_str::<Value>(line) else {
            continue;
        };
        let holder = entry
            .get("message")
            .filter(|value| value.is_object())
            .unwrap_or(&entry);
        let role = holder
            .get("role")
            .or_else(|| entry.get("type"))
            .and_then(Value::as_str)
            .unwrap_or_default();
        if role != "assistant" {
            continue;
        }
        collected.push(' ');
        collected.push_str(&assistant_text(holder));
    }
    let keep = count(PRIOR_CHARS_TEXT);
    match collected.chars().count() > keep {
        true => collected
            .chars()
            .skip(collected.chars().count() - keep)
            .collect(),
        false => collected,
    }
}

fn head(text: &str) -> String {
    text.chars().take(count(LOGGED_CHARS_TEXT)).collect()
}

/// The detached half: classify, draft, record. Its outcome is the log.
fn draft_and_record() {
    let prompt = std::env::var(PROMPT_ENV).unwrap_or_default();
    let prior = std::env::var(PRIOR_ENV).unwrap_or_default();
    if prompt.is_empty() {
        return;
    }
    match drafter::classify(&prompt) {
        Ok(false) => {
            record::log("NOT_FRUSTRATED");
            return;
        }
        Err(error) => {
            record::log(&format!("CLASSIFY_FAILED {error}"));
            return;
        }
        Ok(true) => {}
    }
    let drafted = match drafter::draft(&prompt, &prior) {
        Ok(draft) => draft,
        Err(error) => {
            record::log(&format!("DRAFT_REFUSED {error}"));
            return;
        }
    };
    if !drafter::confident(&drafted) {
        record::log(&format!(
            "LOW_CONF conf={} target={} summary={}",
            drafted.confidence, drafted.target, drafted.summary
        ));
        return;
    }
    let outcome = record::append(
        &expanduser(REGISTRY_PATH),
        &drafted.target,
        &drafted.pattern,
        &drafted.message,
        &drafted.summary,
        &prompt,
    );
    match outcome {
        Ok(line) => record::log(&line),
        Err(error) => record::log(&format!("NOT_RECORDED {error}")),
    }
}

pub fn run() {
    let args: Vec<String> = std::env::args().skip(true as usize).collect();
    if args.iter().any(|arg| arg == DRAFT_FLAG) {
        draft_and_record();
        return;
    }
    if std::env::var(ACTIVE_ENV).is_ok() {
        return;
    }
    let payload = read_payload();
    let prompt = payload
        .get(PROMPT_KEY)
        .and_then(Value::as_str)
        .unwrap_or_default()
        .to_string();
    if !looks_like_a_correction(&prompt) {
        return;
    }
    let transcript = payload
        .get(TRANSCRIPT_KEY)
        .and_then(Value::as_str)
        .unwrap_or_default();
    let prior = prior_turn(transcript);
    let Ok(program) = std::env::current_exe() else {
        record::log("NO_SELF_PATH");
        return;
    };
    // Detached on purpose: the operator's turn must not wait for a gateway.
    let spawned = std::process::Command::new(program)
        .arg(DRAFT_FLAG)
        .env(ACTIVE_ENV, ACTIVE_VALUE)
        .env(PROMPT_ENV, &prompt)
        .env(PRIOR_ENV, prior)
        .stdin(std::process::Stdio::null())
        .stdout(std::process::Stdio::null())
        .stderr(std::process::Stdio::null())
        .spawn();
    match spawned {
        Ok(_) => record::log(&format!("DISPATCHED prompt={}", head(&prompt))),
        Err(error) => record::log(&format!("DISPATCH_FAILED {error}")),
    }
}

#[cfg(test)]
mod tests {
    use super::{looks_like_a_correction, prior_turn};
    use serde_json::json;

    #[test]
    fn a_correction_is_recognised_in_either_language_of_swearing() {
        for prompt in [
            "stop asking me the same thing",
            "I told you not to do that",
            "why did you write a script for this",
            "that's not what I asked for",
            "this is fucking annoying",
        ] {
            assert!(looks_like_a_correction(prompt), "{prompt}");
        }
    }

    /// An ordinary request is not a correction, and neither is swearing at
    /// something else.
    #[test]
    fn an_ordinary_request_is_not_a_correction() {
        for prompt in [
            "please add a test for the limit",
            "the network is down again",
            "",
            "thanks, that worked",
        ] {
            assert!(!looks_like_a_correction(prompt), "{prompt}");
        }
    }

    /// The prior turn is read from the transcript's tail so the drafter has
    /// the behaviour being complained about.
    #[test]
    fn the_prior_assistant_turn_is_read_from_the_transcript() {
        let dir = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../target/tmp")
            .join("tama-frustration-prior");
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).expect("a folder for the fixture");
        let path = dir.join("session.jsonl");
        let lines = [
            json!({ "message": { "role": "user", "content": "do it" } }).to_string(),
            json!({ "message": { "role": "assistant", "content": "I wrote a quick script." } })
                .to_string(),
        ];
        std::fs::write(&path, lines.join("\n")).expect("a transcript");
        let prior = prior_turn(&path.to_string_lossy());
        assert!(prior.contains("quick script"), "{prior}");
        assert_eq!(prior_turn("/nonexistent/session.jsonl"), "");
        let _ = std::fs::remove_dir_all(&dir);
    }
}
