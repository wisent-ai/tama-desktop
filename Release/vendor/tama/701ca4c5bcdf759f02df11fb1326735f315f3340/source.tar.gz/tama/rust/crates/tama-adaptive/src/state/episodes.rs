//! Episode blocks: the causal record a block leaves for the session it
//! happened in, and the read that consumes the latest episode's blocks.
//!
//! Split out of `state/mod.rs`, which had grown past the
//! three-hundred-line limit; the per-hook projections stay there.

use std::fs::{self, OpenOptions};
use std::io::Write;
use std::path::PathBuf;

use super::{key_of, EpisodeBlockInput, EpisodeWriteResult, StateStore};
use crate::util::{js_truthy, pretty_json_line, uuid_v4};

impl StateStore {
    fn episode_path(&self, session_id: &str) -> PathBuf {
        self.episode_dir
            .join(format!("{}.json", key_of(session_id)))
    }

    fn with_episode_lock<T>(
        &self,
        session_id: &str,
        action: impl FnOnce() -> Result<T, String>,
        unavailable: T,
    ) -> T {
        let ownership = match self
            .locks
            .acquire(&format!("episode-{}", key_of(session_id)))
        {
            Ok(ownership) => Some(ownership),
            // JS `acquire` throws only past the caller's `try`; treating an
            // acquisition failure as "unavailable" matches the unavailable
            // result contract without crashing the hook path.
            Err(_) => None,
        };
        let Some(ownership) = ownership else {
            return unavailable;
        };
        let result = match action() {
            Ok(value) => value,
            Err(error) => {
                (self.warn)(&format!("adaptive episode persistence failed: {}", error));
                unavailable
            }
        };
        self.locks.release(Some(ownership));
        result
    }

    /// `recordEpisodeBlock(value)` — appends a causal block record.
    pub fn record_episode_block(&self, value: &EpisodeBlockInput) -> EpisodeWriteResult {
        let session_id = value.session_id.clone().unwrap_or_default();
        let hook_id = value.hook_id.clone().unwrap_or_default();
        if session_id.is_empty() || hook_id.is_empty() {
            return EpisodeWriteResult {
                persisted: false,
                reason: Some("missing-causal-identity".to_string()),
            };
        }
        self.with_episode_lock(
            &session_id,
            || {
                fs::create_dir_all(&self.episode_dir).map_err(|e| e.to_string())?;
                let mut blocks: Vec<serde_json::Value> =
                    fs::read_to_string(self.episode_path(&session_id))
                        .ok()
                        .and_then(|text| serde_json::from_str::<serde_json::Value>(&text).ok())
                        .and_then(|v| v.as_array().cloned())
                        .unwrap_or_default();
                blocks.push(serde_json::json!({
                    "id": uuid_v4(),
                    "hookId": hook_id,
                    "episodeId": value.episode_id,
                    "reason": value.reason.clone().unwrap_or_default(),
                }));
                fs::create_dir_all(&self.tmp_dir).map_err(|e| e.to_string())?;
                let temporary = self.tmp_dir.join(format!("episode-{}.json", uuid_v4()));
                {
                    let mut file = OpenOptions::new()
                        .write(true)
                        .create_new(true)
                        .open(&temporary)
                        .map_err(|e| e.to_string())?;
                    file.write_all(pretty_json_line(&serde_json::Value::Array(blocks)).as_bytes())
                        .map_err(|e| e.to_string())?;
                }
                fs::rename(&temporary, self.episode_path(&session_id))
                    .map_err(|e| e.to_string())?;
                Ok(EpisodeWriteResult {
                    persisted: true,
                    reason: None,
                })
            },
            EpisodeWriteResult {
                persisted: false,
                reason: Some("concurrent-episode-update".to_string()),
            },
        )
    }

    /// `consumeLatestEpisodeBlocks(sessionId)` — reads and removes the
    /// episode file, returning only blocks of the latest episode.
    pub fn consume_latest_episode_blocks(
        &self,
        session_id: Option<&str>,
    ) -> Vec<serde_json::Value> {
        let id = session_id.unwrap_or("").to_string();
        if id.is_empty() {
            return Vec::new();
        }
        self.with_episode_lock(
            &id,
            || {
                let blocks: Vec<serde_json::Value> = fs::read_to_string(self.episode_path(&id))
                    .ok()
                    .and_then(|text| serde_json::from_str::<serde_json::Value>(&text).ok())
                    .and_then(|v| v.as_array().cloned())
                    .unwrap_or_default();
                let _ = fs::remove_file(self.episode_path(&id));
                if blocks.is_empty() {
                    return Ok(Vec::new());
                }
                // JS: `blocks[blocks.length - 1].episodeId` is `undefined`
                // (not null) when the key is missing or the entry is not an
                // object; `None` models `undefined` here.
                let latest_episode_id: Option<serde_json::Value> =
                    blocks.last().and_then(|b| b.get("episodeId")).cloned();
                Ok(blocks
                    .into_iter()
                    .filter(|block| {
                        js_truthy(block) && block.get("episodeId").cloned() == latest_episode_id
                    })
                    .collect())
            },
            Vec::new(),
        )
    }
}
