//! How a payload changes a file, declared once.
//!
//! A guard deciding whether a command or an edit can change a byte reads
//! two families: the shell programs that write, and the language calls
//! that do the same from inside a program. The consent guard carried each
//! list twice — once in the coarse "is there a write anywhere" pattern
//! that the break-glass test uses, and once in the exact pattern the
//! consent test uses — so a writer added to one was refused by one test
//! and invisible to the other.
//!
//! The declaration is `vocabulary/write-verbs.json`; the patterns are
//! built here.

const DECLARED: &str = include_str!("../vocabulary/write-verbs.json");

fn declared() -> serde_json::Value {
    serde_json::from_str(DECLARED).expect("write-verbs.json beside this module is valid JSON")
}

fn branch(key: &str) -> String {
    declared()[key]
        .as_array()
        .unwrap_or_else(|| panic!("write-verbs.json declares no {key} array"))
        .iter()
        .filter_map(|entry| entry.as_str())
        .collect::<Vec<_>>()
        .join("|")
}

/// `sed -i` and its spellings: an edit in place, which is a write.
pub fn in_place_edit() -> String {
    declared()["in_place_edit"]
        .as_str()
        .expect("write-verbs.json declares in_place_edit")
        .to_owned()
}

/// A shell program that writes, or an in-place edit: the verb test, which
/// is read against text where a quote is not syntax.
pub fn verb_pattern() -> String {
    format!(
        r"(?i)(\b({})\b|{})",
        branch("shell_writers"),
        in_place_edit()
    )
}

/// A language call that writes. Matched against raw text, because in code
/// a quote is syntax and the mode argument of an `open` call lives inside
/// one.
pub fn api_pattern() -> String {
    format!(r"(?i)\b({})\b", branch("api_writers"))
}

/// "Is there any write shape at all in this text", including a bare
/// redirection: coarse on purpose, for a test that only asks whether a
/// payload could change something.
pub fn any_write_pattern() -> String {
    format!(
        r"(?i)(>\s*[^\s;|&]+|\b({})\b|{}|\b({})\b)",
        branch("shell_writers"),
        in_place_edit(),
        branch("api_writers")
    )
}

#[cfg(test)]
mod tests {
    use super::{any_write_pattern, api_pattern, verb_pattern};
    use regex::Regex;

    #[test]
    fn a_shell_writer_is_a_verb_and_an_api_call_is_not() {
        let verbs = Regex::new(&verb_pattern()).expect("compiles");
        assert!(verbs.is_match("cp a b"));
        assert!(verbs.is_match("sed -i.bak s/a/b/ file"));
        assert!(!verbs.is_match("const x = fs.writeFile(p, c)"));
    }

    #[test]
    fn a_language_call_is_matched_by_the_api_pattern() {
        let api = Regex::new(&api_pattern()).expect("compiles");
        assert!(api.is_match("await fs.writeFile(path, text)"));
        assert!(api.is_match("Path(p).write_text(t)"));
        assert!(!api.is_match("read_text(p)"));
    }

    /// The coarse pattern answers yes to a redirection, which the exact
    /// verb test deliberately does not: `2>/dev/null` changes nothing.
    #[test]
    fn only_the_coarse_pattern_counts_a_bare_redirection() {
        assert!(Regex::new(&any_write_pattern())
            .expect("compiles")
            .is_match("run > out.txt"));
        assert!(!Regex::new(&verb_pattern())
            .expect("compiles")
            .is_match("run 2>/dev/null"));
    }
}
