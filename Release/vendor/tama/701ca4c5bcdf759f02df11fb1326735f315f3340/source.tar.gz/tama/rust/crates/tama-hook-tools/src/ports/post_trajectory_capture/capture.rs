//! Finding the recording of a failed run, taking its last frame, and
//! registering the inspection it requires.
//!
//! The recording is looked for under the trajectory's own label first, then
//! among any recording touched in the last minute: a run wrapped in
//! `bash run.sh` names no trajectory, and a failure with no frame to look at
//! is how a detection screen gets explained away as a network error.

use std::path::{Path, PathBuf};
use std::process::Command;
use std::time::{SystemTime, UNIX_EPOCH};

use crate::util::sha256_hex;

const RECORDING_SUFFIX: &str = ".webm";
const BAN_SIGNAL_NAME: &str = "ban_signal.json";
const UNHEALTHY: &str = "\"healthy\"";
const FALSE_TEXT: &str = "false";
/// A recording this new belongs to the run that just finished.
const FRESH_RECORDING_SECONDS_TEXT: &str = "60";
/// A ban signal is allowed to be slightly older: it is written before the
/// browser closes.
const FRESH_SIGNAL_SECONDS_TEXT: &str = "90";
/// `${SHA:0:8}`.
const SHA_PREFIX_TEXT: &str = "8";
const FFPROBE: &str = "ffprobe";
const FFPROBE_ARGS: &[&str] = &[
    "-v",
    "error",
    "-show_entries",
    "format=duration",
    "-of",
    "default=noprint_wrappers=1:nokey=1",
];
const FFMPEG: &str = "ffmpeg";
const ACTIVE_ENV: &str = "DETECT_POST_TRAJECTORY_ACTIVE";
const ACTIVE_VALUE: &str = "1";
/// The last frame is half a second before the end: the very last frame of a
/// closing browser is often blank.
const BACKOFF_SECONDS_TEXT: &str = "0.5";

fn seconds(text: &str) -> u64 {
    text.parse().unwrap_or_default()
}

fn prefix_len() -> usize {
    SHA_PREFIX_TEXT.parse().unwrap_or_default()
}

fn backoff() -> f64 {
    BACKOFF_SECONDS_TEXT.parse().unwrap_or_default()
}

fn age_seconds(path: &Path) -> u64 {
    let Ok(metadata) = std::fs::metadata(path) else {
        return u64::MAX;
    };
    let Ok(modified) = metadata.modified() else {
        return u64::MAX;
    };
    let now = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|value| value.as_secs())
        .unwrap_or_default();
    let then = modified
        .duration_since(UNIX_EPOCH)
        .map(|value| value.as_secs())
        .unwrap_or_default();
    now.saturating_sub(then)
}

fn walk(root: &Path, found: &mut Vec<PathBuf>) {
    let Ok(entries) = std::fs::read_dir(root) else {
        return;
    };
    for entry in entries.flatten() {
        let path = entry.path();
        match path.is_dir() {
            true => walk(&path, found),
            false => found.push(path),
        }
    }
}

/// The recording roots for a repository: Weles's own beside it, and its own.
pub(crate) fn roots(repo: &Path) -> Vec<PathBuf> {
    vec![repo.join("../weles/recordings"), repo.join("recordings")]
}

/// Recordings touched within the last minute, newest first.
pub(crate) fn fresh_recordings(repo: &Path) -> Vec<PathBuf> {
    let mut found: Vec<PathBuf> = Vec::new();
    for root in roots(repo).iter().filter(|root| root.is_dir()) {
        let mut files: Vec<PathBuf> = Vec::new();
        walk(root, &mut files);
        found.extend(files.into_iter().filter(|path| {
            path.to_string_lossy().ends_with(RECORDING_SUFFIX)
                && age_seconds(path) <= seconds(FRESH_RECORDING_SECONDS_TEXT)
        }));
    }
    found.sort_by_key(|path| age_seconds(path));
    found
}

/// Whether a ban signal written in the last minute and a half says the
/// session was unhealthy.
pub(crate) fn banned(repo: &Path) -> bool {
    for root in roots(repo).iter().filter(|root| root.is_dir()) {
        let mut files: Vec<PathBuf> = Vec::new();
        walk(root, &mut files);
        for path in files.iter().filter(|path| {
            path.file_name().map(|name| name == BAN_SIGNAL_NAME) == Some(true)
                && age_seconds(path) <= seconds(FRESH_SIGNAL_SECONDS_TEXT)
        }) {
            let Ok(text) = std::fs::read_to_string(path) else {
                continue;
            };
            let flattened: String = text.chars().filter(|c| !c.is_whitespace()).collect();
            if flattened.contains(&format!("{UNHEALTHY}:{FALSE_TEXT}")) {
                return true;
            }
        }
    }
    false
}

/// The newest recording under this label, if the label has a folder.
pub(crate) fn recording_for(repo: &Path, label: &str) -> Option<PathBuf> {
    let mut best: Option<PathBuf> = None;
    for root in roots(repo) {
        let folder = root.join(label);
        if !folder.is_dir() {
            continue;
        }
        let Ok(entries) = std::fs::read_dir(&folder) else {
            continue;
        };
        for path in entries
            .flatten()
            .map(|entry| entry.path())
            .filter(|path| path.to_string_lossy().ends_with(RECORDING_SUFFIX))
        {
            let newer = match &best {
                Some(current) => age_seconds(&path) < age_seconds(current),
                None => true,
            };
            if newer {
                best = Some(path);
            }
        }
        if best.is_some() {
            return best;
        }
    }
    best
}

pub(crate) fn short_sha(path: &Path) -> String {
    let Ok(bytes) = std::fs::read(path) else {
        return String::new();
    };
    let digest = sha256_hex(&bytes);
    digest.chars().take(prefix_len()).collect()
}

/// The last frame of the recording, written beside the run's work directory.
pub(crate) fn extract_last_frame(recording: &Path, out: &Path) -> bool {
    let Ok(probe) = Command::new(FFPROBE)
        .args(FFPROBE_ARGS)
        .arg(recording)
        .output()
    else {
        return false;
    };
    let duration: f64 = String::from_utf8_lossy(&probe.stdout)
        .trim()
        .parse()
        .unwrap_or_default();
    if duration <= 0.0 {
        return false;
    }
    let at = match duration > backoff() {
        true => duration - backoff(),
        false => 0.0,
    };
    Command::new(FFMPEG)
        .env(ACTIVE_ENV, ACTIVE_VALUE)
        .args(["-y", "-loglevel", "error", "-ss"])
        .arg(format!("{at:.2}"))
        .arg("-i")
        .arg(recording)
        .args(["-frames:v", "1"])
        .arg(out)
        .status()
        .map(|status| status.success())
        .unwrap_or_default()
}
