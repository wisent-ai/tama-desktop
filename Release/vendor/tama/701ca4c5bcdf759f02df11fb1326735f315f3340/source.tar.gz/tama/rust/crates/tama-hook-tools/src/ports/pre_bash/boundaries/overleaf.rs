//! The Overleaf history API, which has a dedicated Weles trajectory, and
//! the check that tells a trajectory apart from a script that reads the API
//! itself.
//!
//! Split out of `boundaries/mod.rs`, which had grown past the
//! three-hundred-line limit; the other product boundaries stay there.

use std::path::{Path, PathBuf};
use std::sync::LazyLock;

use regex::Regex;

use crate::ports::transport_common as common;

pub(super) const OVERLEAF_REFUSAL: &str =
    "YOU FUCKING RETARD USE THE DEDICATED WELES TRAJECTORY NOT THE OVERLEAF API";

pub(super) static OVERLEAF_API: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(?i)overleaf\\.com/project/[0-9a-f]{24}/(updates|diff|changes/users|latest/history",
        "|entities)\\b|/project/([0-9a-f]{24}|\\$\\{?[A-Za-z_][A-Za-z0-9_]*\\}?)/",
        "(updates|diff|changes/users|latest/history|entities)\\b",
        "|fetch\\([^)]*/project/[^)]*/(updates|diff|changes/users|latest/history|entities)\\b",
    ))
});
pub(super) static OVERLEAF_SCANNER: LazyLock<Regex> = LazyLock::new(|| {
    common::compile("scripts/trajectories/overleaf/(phrase_history|history_scan)\\.mjs")
});
static OVERLEAF_SCRIPT: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(
        "([A-Za-z0-9_./~$-]+/)?scripts/trajectories/overleaf/[A-Za-z0-9_./~$-]+\\.[mc]?[tj]sx?",
    )
});
static OVERLEAF_ROUTE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile("(?i)/(updates|diff|changes/users|latest/history|entities)\\b")
});
static OVERLEAF_SUBJECT: LazyLock<Regex> =
    LazyLock::new(|| common::compile("(?i)overleaf|/project/"));

/// Whether a referenced Overleaf trajectory reads the history API itself.
pub(super) fn script_reads_the_api(command: &str, workdir: &str) -> bool {
    let Some(found) = OVERLEAF_SCRIPT.find(command) else {
        return false;
    };
    let mut path = PathBuf::from(found.as_str());
    if path.is_relative() && !workdir.is_empty() {
        path = Path::new(workdir).join(path);
    }
    let Ok(text) = std::fs::read_to_string(&path) else {
        return false;
    };
    OVERLEAF_ROUTE.is_match(&text) && OVERLEAF_SUBJECT.is_match(&text)
}
