//! What a session declared it was asked for, and what that leaves out.
//!
//! Split out of `block_off_task_work/mod.rs`, which had grown past the
//! three-hundred-line limit; reading a hook payload stays there.

use std::path::{Path, PathBuf};

use serde::Deserialize;

use crate::ports::python_stdlib::expanduser;

/// Where a session's declaration lives.
pub(crate) const SCOPE_HOME_RELATIVE: &str = ".tama/task-scope";

/// The instant a declaration was written, as the register reads it.
pub(crate) fn now_utc() -> String {
    crate::util::iso_now()
}

/// The workspace every Wisent repository is checked out under, one level
/// deep: `<root>/<repository>`.
pub(crate) const WORKSPACE_HOME_RELATIVE: &str = "Documents/CodingProjects/Wisent";
const BANNER: &str = "BLOCKED: this is not what the session was asked for. ";
/// The command the refusal prints. It carries `--session`, which the CLI
/// requires and the first version of this sentence left out: a refusal that
/// prints a command the product then rejects teaches the reader to ignore
/// the refusal.
const DECLARE: &str = "`tama task scope set --session <SESSION> --repository <NAME>… \
     --defect <DEFECT ID> | --task <TASK ID>`, which copies the operator's current instruction \
     from Tama's own capture of it and refuses an entry the register does not hold open";

/// What one session says the current instruction touches.
#[derive(Debug, Deserialize)]
pub struct TaskScope {
    /// Digest of the operator instruction this scope was declared for. A
    /// newer instruction has a different digest, so a scope never silently
    /// outlives the task it was written for.
    #[serde(default)]
    pub turn_digest: String,
    /// The operator's own words, copied from the captured instruction.
    #[serde(default)]
    pub task: String,
    /// Repositories that instruction touches.
    #[serde(default)]
    pub repositories: Vec<String>,
    /// The defect this work belongs to, from Oko's defect register.
    #[serde(default)]
    pub defect: String,
    /// The task this work belongs to, from Oko's task register.
    #[serde(default)]
    pub task_id: String,
}

impl TaskScope {
    /// The declaration this session wrote, if it wrote one.
    pub fn read(session: &str, home: &Path) -> Option<Self> {
        if session.is_empty() {
            return None;
        }
        let path = home
            .join(SCOPE_HOME_RELATIVE)
            .join(format!("{session}.json"));
        let text = std::fs::read_to_string(path).ok()?;
        serde_json::from_str(&text).ok()
    }

    fn covers(&self, repository: &str) -> bool {
        self.repositories
            .iter()
            .any(|declared| declared == repository)
    }

    /// The register entry this work belongs to, as the refusal names it.
    fn entry(&self) -> String {
        match (self.defect.trim(), self.task_id.trim()) {
            ("", "") => String::new(),
            (defect, "") => format!("defect {defect}"),
            ("", task) => format!("task {task}"),
            (defect, task) => format!("defect {defect} and task {task}"),
        }
    }

    fn declared(&self) -> String {
        if self.repositories.is_empty() {
            return "nothing".to_string();
        }
        self.repositories.join(", ")
    }
}

/// The workspace repository one path belongs to, if any.
///
/// Paths outside the workspace — a product's installed files, the operator's
/// own state, anything under `/tmp` — are other gates' subject, not this
/// one's, and are left alone.
pub fn repository_of(path: &str, home: &Path) -> Option<String> {
    let expanded = expanduser(path);
    let absolute = if Path::new(&expanded).is_absolute() {
        PathBuf::from(&expanded)
    } else {
        std::env::current_dir().ok()?.join(&expanded)
    };
    let workspace = home.join(WORKSPACE_HOME_RELATIVE);
    let relative = absolute.strip_prefix(&workspace).ok()?;
    relative
        .components()
        .next()
        .map(|component| component.as_os_str().to_string_lossy().to_string())
        .filter(|name| !name.is_empty())
}

/// Why this mutation is outside the session's declared work, if it is.
///
/// Three things have to line up. The scope must have been declared for the
/// operator instruction being served — `instruction` is the digest of Tama's
/// own capture of it — because a scope written for an earlier prompt is how a
/// session drifts, one reasonable step at a time. It must name the defect or
/// task in Oko's registers that this work belongs to, because "I was asked
/// for something in this repository" is not the same as "this change is part
/// of the thing I was asked for". And the repository being changed must be
/// one the declaration lists.
pub fn refusal(repository: &str, session: &str, instruction: &str, home: &Path) -> Option<String> {
    let scope = TaskScope::read(session, home);
    let Some(scope) = scope.filter(|scope| scope.turn_digest == instruction) else {
        return Some(format!(
            "{BANNER}This session has not said which defect or task the operator's current \
             instruction is, or which repositories it touches, and this call changes \
             {repository}. Say it once and every later change is checked against it: {DECLARE}"
        ));
    };
    let entry = scope.entry();
    if entry.is_empty() {
        return Some(format!(
            "{BANNER}The scope of this session names no defect and no task, so nothing says this \
             change to {repository} is part of anything. Record what is wrong with `oko-cli \
             defects record`, or name the task it belongs to, and declare it: {DECLARE}"
        ));
    }
    if scope.covers(repository) {
        return None;
    }
    Some(format!(
        "{BANNER}This session is working on {entry}: {}. It was declared to touch {}, and this \
         call changes {repository}. Something really being broken is not the same as being asked \
         to fix it — record it where it will be read (`oko-cli defects record`) and say so in the \
         answer. If this change really is part of that work, widen the scope: {DECLARE}",
        scope.task.trim(),
        scope.declared()
    ))
}
