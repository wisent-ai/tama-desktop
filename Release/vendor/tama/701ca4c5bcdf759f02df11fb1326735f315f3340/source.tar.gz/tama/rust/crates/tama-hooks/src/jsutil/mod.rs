//! Internal helpers reproducing small pieces of JavaScript semantics that the
//! ported modules rely on: whitespace classes, truthiness, `String()`/`Number()`
//! coercion, ISO-8601 timestamps (`Date.parse` / `Date#toISOString`), the home
//! directory and POSIX `path.basename`.

mod coerce;
mod datetime;
mod sys;

pub use coerce::{
    is_js_whitespace, js_safe_integer_positive, js_string_or_empty, js_to_string, js_to_string_opt,
    js_truthy, trim_js,
};
pub use datetime::{now_millis, parse_date, to_iso_string};
pub use sys::{home_dir, js_basename, random_token};
