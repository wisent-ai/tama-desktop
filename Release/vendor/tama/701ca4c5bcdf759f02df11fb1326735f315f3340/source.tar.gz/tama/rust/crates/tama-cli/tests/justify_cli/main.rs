//! `tama justify` driven as an agent drives it, against an isolated home.
//!
//! The authorization gates require a justification before a new file or a new
//! test is written, and the registries holding them sit inside the protected
//! hook directory: hand editing is refused by three separate gates. This
//! command is the only way to record one, so what it accepts and what it
//! refuses is the contract, and a refusal sentence is part of it.
//!
//! Every case runs the real binary and reads the registry document off disk.
//! `--home` points at a temporary directory, so the operator's own registries
//! are never touched.

mod support;

use serde_json::Value;
use support::{stderr, stdout, Home, JUSTIFICATION};

#[test]
fn record_stores_the_entry_the_gate_reads_and_remove_takes_it_away() {
    let home = Home::new("record");
    let target = "/private/tmp/tama-justify-target/module.rs";

    let recorded = home.run(&["record", "--file", target, "--justification", JUSTIFICATION]);
    assert!(
        recorded.status.success(),
        "record failed: {}",
        stderr(&recorded)
    );

    let document = home.document("file").expect("the registry was written");
    let entry = document
        .get(target)
        .expect("the entry is keyed by the absolute path the gate looks up");
    assert_eq!(entry["justification"], JUSTIFICATION);
    assert!(
        entry.get("user_request_quote").is_none(),
        "a file justification carries no user quote"
    );

    let shown = home.run(&["show", "--file", target]);
    assert!(shown.status.success(), "show failed: {}", stderr(&shown));
    assert!(stdout(&shown).contains("This entry exists because"));

    let removed = home.run(&["remove", "--file", target]);
    assert!(
        removed.status.success(),
        "remove failed: {}",
        stderr(&removed)
    );
    assert_eq!(
        home.document("file").expect("the registry still exists"),
        serde_json::json!({}),
        "removing the only entry leaves an empty registry, not a broken one"
    );
}

#[test]
fn record_keeps_every_other_entry_untouched() {
    let home = Home::new("neighbours");
    let first = "/private/tmp/tama-justify-target/first.rs";
    let second = "/private/tmp/tama-justify-target/second.rs";

    for target in [first, second] {
        let output = home.run(&["record", "--file", target, "--justification", JUSTIFICATION]);
        assert!(
            output.status.success(),
            "record failed: {}",
            stderr(&output)
        );
    }
    let removed = home.run(&["remove", "--file", first]);
    assert!(
        removed.status.success(),
        "remove failed: {}",
        stderr(&removed)
    );

    let document = home.document("file").expect("the registry was written");
    let object = document.as_object().expect("a JSON object");
    assert!(object.get(first).is_none(), "the removed entry is gone");
    assert_eq!(
        object.get(second).map(|entry| &entry["justification"]),
        Some(&Value::String(JUSTIFICATION.to_string())),
        "the entry nobody asked about survives byte for byte"
    );
    assert_eq!(object.len(), usize::from(true), "no entry was invented");

    let listed = home.run(&["list"]);
    assert!(listed.status.success(), "list failed: {}", stderr(&listed));
    assert_eq!(stdout(&listed), second, "list prints the surviving path");
}

#[test]
fn a_short_justification_is_refused_and_nothing_is_written() {
    let home = Home::new("short");
    let output = home.run(&[
        "record",
        "--file",
        "/private/tmp/tama-justify-target/short.rs",
        "--justification",
        "Three words only",
    ]);

    assert!(
        !output.status.success(),
        "a short justification must be refused"
    );
    assert_eq!(
        stderr(&output),
        "the justification is 3 words and the registry requires 50"
    );
    assert!(
        home.document("file").is_none(),
        "a refused record writes no registry at all"
    );
}

#[test]
fn a_relative_path_is_refused_because_the_gate_looks_up_absolute_ones() {
    let home = Home::new("relative");
    let output = home.run(&[
        "record",
        "--file",
        "src/module.rs",
        "--justification",
        JUSTIFICATION,
    ]);

    assert!(!output.status.success(), "a relative path must be refused");
    assert_eq!(
        stderr(&output),
        "the registry is keyed by absolute paths, and src/module.rs is relative"
    );
    assert!(home.document("file").is_none());
}

#[test]
fn a_test_justification_needs_the_request_quoted_inside_it() {
    let home = Home::new("quote");
    let target = "/private/tmp/tama-justify-target/module_test.rs";

    let missing = home.run(&[
        "record",
        "--kind",
        "test",
        "--file",
        target,
        "--justification",
        JUSTIFICATION,
    ]);
    assert!(
        !missing.status.success(),
        "a test entry without a quote must be refused"
    );
    assert_eq!(
        stderr(&missing),
        format!(
            "a test justification needs --quote, copied verbatim from the request that asked for {target}"
        )
    );

    let absent = home.run(&[
        "record",
        "--kind",
        "test",
        "--file",
        target,
        "--justification",
        JUSTIFICATION,
        "--quote",
        "a sentence this justification does not contain",
    ]);
    assert!(
        !absent.status.success(),
        "a quote outside the justification must be refused"
    );
    assert_eq!(
        stderr(&absent),
        "the justification must contain the quote verbatim, because the gate checks that"
    );
    assert!(
        home.document("test").is_none(),
        "neither refusal wrote the test registry"
    );
}

#[test]
fn show_and_remove_refuse_a_path_with_no_entry() {
    let home = Home::new("absent");
    let target = "/private/tmp/tama-justify-target/never-recorded.rs";

    let shown = home.run(&["show", "--file", target]);
    assert!(!shown.status.success());
    assert_eq!(
        stderr(&shown),
        format!("no file justification is recorded for {target}")
    );

    let removed = home.run(&["remove", "--file", target]);
    assert!(!removed.status.success());
    assert_eq!(
        stderr(&removed),
        format!("no justification is recorded for {target}")
    );
}

#[test]
fn an_unknown_action_prints_usage_and_exits_two() {
    let home = Home::new("usage");
    let output = home.run(&["invent"]);

    assert_eq!(
        output.status.code(),
        Some(2),
        "an unknown action is a usage error"
    );
    assert!(stderr(&output).contains("usage: tama justify"));
}

#[test]
fn the_written_registry_is_the_one_the_gate_would_read() {
    let home = Home::new("gate");
    let target = "/private/tmp/tama-justify-target/gate.rs";
    let output = home.run(&["record", "--file", target, "--justification", JUSTIFICATION]);
    assert!(
        output.status.success(),
        "record failed: {}",
        stderr(&output)
    );

    // The gate reads `$HOME/.shared-hooks/file_justifications.json` and looks
    // the path up with `jq '.[$p].justification'`, so the location and the
    // shape are both part of the contract.
    let path = home.registry("file");
    assert!(
        path.ends_with(".shared-hooks/file_justifications.json"),
        "the registry sits where the gate looks for it: {}",
        path.display()
    );
    let words = home.document("file").expect("a document")[target]["justification"]
        .as_str()
        .expect("a string justification")
        .split_whitespace()
        .count();
    assert!(
        words >= 50,
        "the stored justification satisfies the gate: {words} words"
    );
}
