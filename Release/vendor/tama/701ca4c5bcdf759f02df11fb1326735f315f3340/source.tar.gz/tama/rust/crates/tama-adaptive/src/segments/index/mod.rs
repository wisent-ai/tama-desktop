//! Port of `src/adaptive/segments/index.mjs`: durable immutable telemetry
//! segments (open -> ready -> acked) with integrity footers.

mod reclaim;
mod validate;

pub use validate::validate_segment;

use sha2::{Digest, Sha256};
use std::fs::{self, File, OpenOptions};
use std::io::Write;
use std::path::{Path, PathBuf};

use crate::state::journal::sync_directory;
use crate::state::Warn;
use crate::util::{now_ms, uuid_v4};

pub const PROTOCOL: &str = "hooks-telemetry-segment-v1";
pub const ACK_PROTOCOL: &str = "hooks-telemetry-ack-v1";
const LEGACY_NAMES: [&str; 3] = [
    "telemetry.prev.jsonl",
    "telemetry.jsonl",
    "repair-queue.jsonl",
];

fn digest_bytes(value: &[u8]) -> String {
    format!("{:x}", Sha256::digest(value))
}

fn line(value: &serde_json::Value) -> String {
    format!("{}\n", serde_json::to_string(value).unwrap_or_default())
}

pub fn segment_name(id: &str) -> String {
    format!("segment-{}.jsonl", id)
}

fn ack_name(id: &str) -> String {
    format!("segment-{}.ack.json", id)
}

fn write_all(descriptor: &mut File, text: &str) -> std::io::Result<()> {
    descriptor.write_all(text.as_bytes())
}

fn safe_names(path: &Path) -> Vec<String> {
    match fs::read_dir(path) {
        Ok(entries) => entries
            .flatten()
            .map(|entry| entry.file_name().to_string_lossy().to_string())
            .collect(),
        Err(_) => Vec::new(),
    }
}

fn parse_object(text: &str) -> Option<serde_json::Value> {
    let value = serde_json::from_str::<serde_json::Value>(text).ok()?;
    if value.is_object() {
        Some(value)
    } else {
        None
    }
}

fn is_hex_64(text: &str) -> bool {
    text.len() == 64
        && text
            .bytes()
            .all(|b| b.is_ascii_hexdigit() && !b.is_ascii_uppercase())
}

/// A validated ready segment (`validateSegment`).
pub struct ValidSegment {
    pub segment_id: String,
    pub event_count: usize,
    pub payload_sha256: String,
    pub source_sha256: String,
    pub source_size: usize,
    pub events: Vec<serde_json::Value>,
}

fn get_str<'a>(value: &'a serde_json::Value, key: &str) -> Option<&'a str> {
    value.get(key).and_then(|v| v.as_str())
}

fn is_number(value: &serde_json::Value) -> bool {
    value.is_number()
}
/// `createSegmentWriter(stateDir, warn)`.
pub struct SegmentWriter {
    state_dir: PathBuf,
    open_dir: PathBuf,
    ready_dir: PathBuf,
    acked_dir: PathBuf,
    invocation_id: String,
    producer_id: String,
    descriptor: Option<File>,
    open_path: PathBuf,
    ready_path: PathBuf,
    segment_id: String,
    payload_hash: Sha256,
    event_count: u64,
    closed: bool,
    failed: bool,
    warn: Warn,
}

impl SegmentWriter {
    pub fn create(state_dir: &Path, warn: Warn) -> Self {
        let root = state_dir.join("telemetry-segments");
        SegmentWriter {
            state_dir: state_dir.to_path_buf(),
            open_dir: root.join("open"),
            ready_dir: root.join("ready"),
            acked_dir: root.join("acked"),
            invocation_id: uuid_v4(),
            producer_id: format!("tama:{}", std::process::id()),
            descriptor: None,
            open_path: PathBuf::new(),
            ready_path: PathBuf::new(),
            segment_id: String::new(),
            payload_hash: Sha256::new(),
            event_count: 0,
            closed: false,
            failed: false,
            warn,
        }
    }

    fn report(&self, error: &str) {
        (self.warn)(&format!("adaptive telemetry loss: {}", error));
    }

    fn ensure_open(&mut self) -> std::io::Result<()> {
        fs::create_dir_all(&self.open_dir)?;
        fs::create_dir_all(&self.ready_dir)?;
        fs::create_dir_all(&self.acked_dir)?;
        self.segment_id = uuid_v4();
        self.open_path = self
            .open_dir
            .join(format!("{}.open", segment_name(&self.segment_id)));
        self.ready_path = self.ready_dir.join(segment_name(&self.segment_id));
        let mut descriptor = OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&self.open_path)?;
        self.payload_hash = Sha256::new();
        let header = line(&serde_json::json!({
            "kind": "segment_open",
            "protocol": PROTOCOL,
            "segmentId": self.segment_id,
            "producerId": self.producer_id,
            "invocationId": self.invocation_id,
            "createdAt": now_ms(),
            "source": { "producer": "tama" },
        }));
        write_all(&mut descriptor, &header)?;
        self.payload_hash.update(header.as_bytes());
        self.descriptor = Some(descriptor);
        Ok(())
    }

    fn abandon(&mut self) {
        if let Some(descriptor) = self.descriptor.take() {
            drop(descriptor);
        }
        self.failed = true;
    }

    fn append(&mut self, event: &serde_json::Value, retried: bool) -> bool {
        let attempt = |writer: &mut SegmentWriter| -> std::io::Result<()> {
            if writer.descriptor.is_none() {
                writer.ensure_open()?;
            }
            let frame = line(&serde_json::json!({
                "kind": "event",
                "sequence": writer.event_count,
                "event": event,
            }));
            let descriptor = writer.descriptor.as_mut().expect("descriptor opened above");
            write_all(descriptor, &frame)?;
            writer.payload_hash.update(frame.as_bytes());
            writer.event_count += 1;
            Ok(())
        };
        match attempt(self) {
            Ok(()) => true,
            Err(error) => {
                self.abandon();
                // ENOSPC (28) / EDQUOT (69) trigger a one-time reclaim retry.
                if !retried && matches!(error.raw_os_error(), Some(28) | Some(69)) {
                    self.reclaim_acked();
                    self.failed = false;
                    return self.append(event, true);
                }
                self.report(&error.to_string());
                false
            }
        }
    }

    /// `record(event)`.
    pub fn record(&mut self, event: &serde_json::Value) -> bool {
        if self.closed || self.failed || !event.is_object() {
            return false;
        }
        self.append(event, false)
    }

    /// `close()`.
    pub fn close(&mut self) -> bool {
        if self.closed {
            return false;
        }
        self.closed = true;
        if self.descriptor.is_none() || self.failed {
            return false;
        }
        let attempt = |writer: &mut SegmentWriter| -> std::io::Result<()> {
            let digest = writer.payload_hash.clone().finalize();
            let footer = line(&serde_json::json!({
                "kind": "segment_close",
                "protocol": PROTOCOL,
                "segmentId": writer.segment_id,
                "eventCount": writer.event_count,
                "payloadSha256": format!("{:x}", digest),
                "closedAt": now_ms(),
            }));
            let mut descriptor = writer.descriptor.take().expect("checked above");
            write_all(&mut descriptor, &footer)?;
            descriptor.sync_all()?;
            drop(descriptor);
            fs::rename(&writer.open_path, &writer.ready_path)?;
            sync_directory(&writer.ready_dir);
            Ok(())
        };
        match attempt(self) {
            Ok(()) => true,
            Err(error) => {
                self.abandon();
                self.report(&error.to_string());
                false
            }
        }
    }

    /// `status()`.
    pub fn status(&self) -> serde_json::Value {
        let open = safe_names(&self.open_dir)
            .iter()
            .filter(|name| name.ends_with(".jsonl.open"))
            .count();
        let ready_names: Vec<String> = safe_names(&self.ready_dir)
            .into_iter()
            .filter(|name| name.ends_with(".jsonl"))
            .collect();
        let acked = safe_names(&self.acked_dir)
            .iter()
            .filter(|name| name.ends_with(".ack.json"))
            .count();
        let mut valid_ready = 0u64;
        let mut reclaimable = 0u64;
        for name in &ready_names {
            if let Some(item) = self.inspect_ready(name) {
                valid_ready += 1;
                if item.reclaimable {
                    reclaimable += 1;
                }
            }
        }
        let mut legacy = Vec::new();
        for name in LEGACY_NAMES {
            if let Ok(meta) = fs::metadata(self.state_dir.join(name)) {
                legacy.push(serde_json::json!({ "name": name, "size": meta.len() }));
            }
        }
        serde_json::json!({
            "open": open,
            "ready": ready_names.len(),
            "acked": acked,
            "validReady": valid_ready,
            "reclaimable": reclaimable,
            "legacy": legacy,
        })
    }
}
