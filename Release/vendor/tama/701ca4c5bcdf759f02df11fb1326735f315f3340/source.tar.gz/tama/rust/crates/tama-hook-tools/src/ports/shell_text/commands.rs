//! Where one command ends and the next begins.
//!
//! Three gates cut a payload with `text.split([';', '|', '&'])` and then
//! tokenized each piece. Cutting first reads a quoted argument as commands.
//! On 2026-09-16 that refused
//!
//! ```text
//! oko-cli transcripts tasks evidence <session> 202 --commit "... followed by
//! 'tama-cli enforcement only <ids>'; the engine refuses that write ..."
//! ```
//!
//! because the semicolon inside the quoted sentence cut the argument in half,
//! the first half had no closing quote, `shlex.split` gave up, the
//! split-on-spaces path it takes then turned the sentence into command words,
//! and `tama-cli`, `enforcement` and `only` were all among them. A guard that
//! refuses an honest report of its own refusal teaches people to stop
//! reporting.
//!
//! So the cut happens here, on characters, with quote state: a separator
//! inside `'…'` or `"…"` is text. A command substitution is not text — `$(…)`
//! and backticks run code inside double quotes too, so each opens a piece of
//! its own.

/// One character, for the index arithmetic this scan needs.
const ONE: usize = 1;

/// Where one command ends and the next begins, outside quotes.
const SEPARATORS: &[char] = &[';', '|', '\n'];

/// Programs that are handed a command line to run, rather than arguments.
///
/// Read from `shells.json` beside this file, compiled in: the names are
/// data the product declares, not a list written into code. Three guards
/// carried four of them inside their own regex alternation, where a rename
/// would be found by nobody; they compose [`shell_alternation`] now.
static EXECUTORS: std::sync::LazyLock<Vec<String>> =
    std::sync::LazyLock::new(|| declared(include_str!("vocabulary/shells.json"), "shells"));

/// One declared list of program names, from the JSON beside this module.
fn declared(source: &str, key: &str) -> Vec<String> {
    let document: serde_json::Value =
        serde_json::from_str(source).expect("the program-name declaration is valid JSON");
    document[key]
        .as_array()
        .unwrap_or_else(|| panic!("the program-name declaration has no {key} array"))
        .iter()
        .filter_map(|name| name.as_str().map(str::to_owned))
        .collect()
}

/// One regex branch, `a|b|…`, from the names declared under `key`.
fn interpreters(key: &str) -> String {
    declared(include_str!("vocabulary/interpreters.json"), key).join("|")
}

/// The runtimes that execute JavaScript or TypeScript source.
pub fn javascript_runtime_alternation() -> String {
    interpreters("javascript_runtimes")
}

/// The JavaScript runtimes together with the tooling that launches them,
/// which is what a guard on running a project's own scripts must see.
pub fn javascript_alternation() -> String {
    format!(
        "{}|{}",
        javascript_runtime_alternation(),
        interpreters("javascript_tooling")
    )
}

/// Interpreters other than the JavaScript family and Python, which carries
/// its version suffix and so has its own pattern.
pub fn scripting_alternation() -> String {
    interpreters("scripting_runtimes")
}

/// Runtimes that take their source after a `-e`-style flag, once their own
/// options have been given.
pub fn eval_flag_alternation() -> String {
    interpreters("eval_flag_runtimes")
}

/// The awk family, which takes its program as the first argument.
pub fn awk_alternation() -> String {
    interpreters("awk_family")
}

/// The suffixes of files that carry code, as one regex branch.
pub fn source_extension_alternation() -> String {
    declared(
        include_str!("vocabulary/source_extensions.json"),
        "source_extensions",
    )
    .join("|")
}

/// The wrappers that precede the real program, as one regex branch, for a
/// guard that matches command text instead of walking tokens.
pub fn wrapper_alternation() -> String {
    WRAPPERS.join("|")
}

/// The declared shells as names, for a guard that compares tokens rather
/// than matching text.
pub fn shells() -> &'static [String] {
    &EXECUTORS
}

/// The declared shells as one regex branch, `bash|sh|…`.
///
/// A guard that refuses one shell has no reason to allow another, so the
/// branch is the whole declaration rather than the four names the guards
/// used to spell out.
pub fn shell_alternation() -> String {
    EXECUTORS.join("|")
}

/// Programs that run the command after them, so the program to judge is the
/// next token rather than this one.
static WRAPPERS: std::sync::LazyLock<Vec<String>> =
    std::sync::LazyLock::new(|| declared(include_str!("vocabulary/wrappers.json"), "wrappers"));

/// The program a token names, without its directory.
fn basename(token: &str) -> &str {
    token.rsplit('/').next().unwrap_or(token)
}

/// Is this a `NAME=value` prefix rather than the program?
fn assignment(token: &str) -> bool {
    match token.find('=') {
        Some(at) if at > usize::MIN => token[..at]
            .chars()
            .all(|c| c.is_ascii_alphanumeric() || c == '_'),
        _ => false,
    }
}

/// `30`, `5m`, `1.5h` — a wrapper's time limit, not the program.
fn duration(token: &str) -> bool {
    let digits = token.trim_end_matches(['s', 'm', 'h', 'd']);
    !digits.is_empty() && digits.chars().all(|c| c.is_ascii_digit() || c == '.')
}

/// The commands this line runs, in order, each a slice of the line.
///
/// Cuts at `;`, `|`, `&` and newline outside quotes, and at the boundaries of
/// a `$(…)` or backtick substitution, which is code even inside double
/// quotes. `&&` and `||` are one cut; `2>&1`, `&>` and `>&` duplicate a file
/// descriptor and are left where they are.
pub fn commands(line: &str) -> Vec<&str> {
    let characters: Vec<char> = line.chars().collect();
    let mut pieces: Vec<&str> = Vec::new();
    // Byte offsets, because the slices returned are of the original text.
    let mut offsets: Vec<usize> = Vec::with_capacity(characters.len() + ONE);
    let mut byte = usize::MIN;
    for character in &characters {
        offsets.push(byte);
        byte += character.len_utf8();
    }
    offsets.push(byte);

    let mut single = false;
    let mut double = false;
    let mut substitution = usize::MIN;
    let mut index = usize::MIN;
    let mut start = usize::MIN;
    while index < characters.len() {
        let character = characters[index];
        if character == '\\' && !single {
            index += ONE + ONE;
            continue;
        }
        if character == '\'' && !double {
            single = !single;
            index += ONE;
            continue;
        }
        if character == '"' && !single {
            double = !double;
            index += ONE;
            continue;
        }
        if single {
            index += ONE;
            continue;
        }
        if character == '$' && characters.get(index + ONE) == Some(&'(') {
            pieces.push(&line[offsets[start]..offsets[index]]);
            substitution += ONE;
            index += ONE + ONE;
            start = index;
            continue;
        }
        if character == '`' {
            pieces.push(&line[offsets[start]..offsets[index]]);
            index += ONE;
            start = index;
            continue;
        }
        if character == ')' && substitution > usize::MIN {
            pieces.push(&line[offsets[start]..offsets[index]]);
            substitution -= ONE;
            index += ONE;
            start = index;
            continue;
        }
        if double {
            index += ONE;
            continue;
        }
        if SEPARATORS.contains(&character) {
            pieces.push(&line[offsets[start]..offsets[index]]);
            index += ONE;
            start = index;
            continue;
        }
        if character == '&' {
            let next = characters.get(index + ONE);
            if next == Some(&'>') || (index > usize::MIN && characters[index - ONE] == '>') {
                index += ONE;
                continue;
            }
            pieces.push(&line[offsets[start]..offsets[index]]);
            index += if next == Some(&'&') { ONE + ONE } else { ONE };
            start = index;
            continue;
        }
        index += ONE;
    }
    pieces.push(&line[offsets[start]..]);
    pieces
        .into_iter()
        .map(str::trim)
        .filter(|piece| !piece.is_empty())
        .collect()
}

/// Where the command proper starts: after its `NAME=value` prefixes and after
/// wrappers such as `env`, `sudo`, `nohup` and `timeout`, whose own flags and
/// duration argument are stepped over too.
fn command_start(tokens: &[String]) -> Option<&[String]> {
    let mut rest = tokens;
    let mut stepping = false;
    loop {
        let (first, tail) = rest.split_first()?;
        let name = basename(first);
        if assignment(first) || (stepping && (first.starts_with('-') || duration(first))) {
            rest = tail;
            continue;
        }
        if WRAPPERS.iter().any(|wrapper| wrapper == name) && !tail.is_empty() {
            stepping = true;
            rest = tail;
            continue;
        }
        return Some(rest);
    }
}

/// The program this command runs, without its directory.
pub fn program(tokens: &[String]) -> Option<&str> {
    command_start(tokens)?.first().map(|token| basename(token))
}

/// The command line an executor is handed: the argument after a `-c`-style
/// flag of `bash`, `sh`, `zsh` and their kin. That text is code and has to be
/// read as code.
pub fn inner_command(tokens: &[String]) -> Option<&str> {
    let (first, tail) = command_start(tokens)?.split_first()?;
    if !EXECUTORS.iter().any(|shell| shell == basename(first)) {
        return None;
    }
    let flag = tail
        .iter()
        .position(|token| token.starts_with('-') && token.contains('c'))?;
    tail.get(flag + ONE).map(String::as_str)
}

/// Is this token a command word — a program, a path, a flag — rather than a
/// sentence handed to one? A prose argument survives tokenizing as a single
/// token with spaces in it; no program name or flag has a space.
pub fn command_word(token: &str) -> bool {
    !token.chars().any(char::is_whitespace)
}
