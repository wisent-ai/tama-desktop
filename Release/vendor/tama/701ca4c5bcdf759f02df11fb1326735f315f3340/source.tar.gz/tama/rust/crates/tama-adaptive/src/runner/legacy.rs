//! The kill-switch path (`HOOKS_ADAPTIVE_DISABLED`): legacy semantics
//! exactly — serial spawning, first block short-circuits, fail closed on
//! overrun and crash for blocking events, no engine consultation, no
//! telemetry.
//!
//! Split out of `runner/mod.rs`, which had grown past the
//! three-hundred-line limit; the adaptive path stays there.

use crate::segments::runner_command::{
    crash_reason, decision_from_output, parse_payload, run_command, stdin_text,
};
use crate::util::{home_dir, js_truthy};

use super::{
    blocking, emit, hook_spec, hooks_of, json, normalized_payload, result_entry, results_array,
};

pub(super) fn run_legacy(event: &str) -> Result<(), String> {
    let registry_path = std::env::var("AGENT_HOOK_REGISTRY")
        .ok()
        .filter(|v| !v.is_empty())
        .unwrap_or_else(|| {
            home_dir()
                .join(".shared-hooks")
                .join("registry.json")
                .to_string_lossy()
                .to_string()
        });
    let text = std::fs::read_to_string(&registry_path)
        .map_err(|e| format!("Error: {}: {}", node_io_code(&e), registry_path))?;
    let registry: serde_json::Value =
        serde_json::from_str(&text).map_err(|e| format!("SyntaxError: {}", e))?;
    let entry = registry
        .get("events")
        .and_then(|events| events.get(event))
        .filter(|v| js_truthy(v));
    let Some(entry) = entry else {
        emit(&[
            ("decision", json(&"pass".into())),
            ("reason", json(&format!("no hooks for {}", event).into())),
        ]);
        return Ok(());
    };
    let payload = parse_payload(&stdin_text());
    let normalized = normalized_payload(&payload, event);
    let mut results: Vec<String> = Vec::new();
    for hook in hooks_of(entry) {
        let spec = hook_spec(&hook);
        let result = run_command(&spec.command, &normalized);
        results.push(result_entry(&spec, result.code));
        if let Some(spawn_error) = &result.spawn_error {
            if blocking(entry) {
                emit(&[
                    ("decision", json(&"block".into())),
                    (
                        "reason",
                        json(&format!("{}: {}", spec.id_text(), spawn_error).into()),
                    ),
                    ("results", results_array(&results)),
                ]);
                return Ok(());
            }
        }
        let block_reason =
            decision_from_output(&result.stdout).or_else(|| decision_from_output(&result.stderr));
        if let Some(block_reason) = block_reason {
            emit(&[
                ("decision", json(&"block".into())),
                (
                    "reason",
                    json(&format!("{}: {}", spec.id_text(), block_reason).into()),
                ),
                ("results", results_array(&results)),
            ]);
            return Ok(());
        }
        if result.code.map(|c| c != 0).unwrap_or(false) && blocking(entry) {
            emit(&[
                ("decision", json(&"block".into())),
                ("reason", json(&crash_reason(&spec, &result).into())),
                ("results", results_array(&results)),
            ]);
            return Ok(());
        }
    }
    emit(&[
        ("decision", json(&"pass".into())),
        ("results", results_array(&results)),
    ]);
    Ok(())
}

/// Node-style fs error prefix (`ENOENT: no such file or directory, open`).
pub(super) fn node_io_code(error: &std::io::Error) -> String {
    match error.kind() {
        std::io::ErrorKind::NotFound => "ENOENT: no such file or directory, open".to_string(),
        std::io::ErrorKind::PermissionDenied => "EACCES: permission denied, open".to_string(),
        _ => format!("Error: {}", error),
    }
}
