//! Logic for `tama-block-wait-polling`, registry hook `block-wait-polling`:
//! a wait is not work, and the same look taken again and again is a wait.
//!
//! `pre-bash` and `pre-wait-tools` cap how long one call may block. Capped,
//! an agent that has nothing to do but wait for a build turns into a loop of
//! ten-second sleeps and identical status reads — on 2026-09-18 an agent
//! spent turn after turn on `sleep 9; echo` and the same `hub wait` on the
//! same process, which the operator named for what it is: no different from
//! waiting an hour, only louder. The process the agent waited for reports
//! its own exit; the right move was other work, or one wait for that exit.
//!
//! Two rules, one hook:
//!
//! 1. A shell call that only sleeps is refused. A command line whose every
//!    command is `sleep`, `echo`, `printf`, `true` or `:` does nothing but
//!    pass time.
//! 2. A repeated look is refused. The same read-only tool call — the same
//!    tool, the same operation, the same subject — taken for the
//!    [`REPEAT_LIMIT`]th time inside [`REPEAT_WINDOW_SECONDS`] is polling.
//!    Looks are counted per session in a small ring under the session-control
//!    root; a look at a different subject, or a write, starts nothing.
//!
//! There is deliberately no environment escape: a variable an agent can set
//! is not a permission an operator granted.

mod ring;

use serde_json::Value;
use tama_hooks::session_record::{deny_tool_use, read_payload, session_id_of, tool_name_of};

use super::shell_text;

/// The tool whose `command` is a shell line.
const SHELL_TOOL: &str = "bash";
/// The supervisor tool whose read operations are looks, keyed by `op`.
const HUB_TOOL: &str = "hub";
const HUB_OP_KEY: &str = "op";
const HUB_READ_OPS: [&str; 4] = ["wait", "logs", "ps", "jobs"];
/// The hub fields that name what a look is at.
const HUB_SUBJECT_KEYS: [&str; 5] = ["name", "ids", "grep", "from", "pattern"];
/// Programs that only pass time or print.
const IDLE_PROGRAMS: [&str; 5] = ["sleep", "echo", "printf", "true", ":"];
/// The look that is one too many, and the window it is counted in.
pub const REPEAT_LIMIT: usize = 3;
pub const REPEAT_WINDOW_SECONDS: u64 = 120;

const SLEEP_REFUSAL: &str = "BLOCKED: this call only passes time. A wait is not work: the \
    process you are waiting for reports its own exit; do other work until it does, or wait \
    once for that exit (`hub wait` with `for: exit` and a timeout that covers it) instead of \
    sleeping in slices.";

fn tool_input(payload: &Value) -> Value {
    payload
        .get("tool_input")
        .cloned()
        .unwrap_or(Value::Object(Default::default()))
}

/// Whether every command on the line only sleeps or prints.
pub fn only_passes_time(command: &str) -> bool {
    let effective = shell_text::effective_command(command);
    let commands = shell_text::commands(&effective);
    if commands.is_empty() {
        return false;
    }
    let mut slept = false;
    for piece in commands {
        let tokens = super::python_stdlib::shell_tokens(piece);
        if tokens.is_empty() {
            continue;
        }
        let Some(program) = shell_text::program(&tokens) else {
            continue;
        };
        if !IDLE_PROGRAMS.contains(&program) {
            return false;
        }
        slept |= program == "sleep";
    }
    slept
}

/// The fingerprint of a read-only look, or `None` for a call that is not one.
pub fn look_fingerprint(tool: &str, input: &Value) -> Option<String> {
    if tool != HUB_TOOL {
        return None;
    }
    let op = input.get(HUB_OP_KEY).and_then(Value::as_str)?;
    if !HUB_READ_OPS.contains(&op) {
        return None;
    }
    let mut parts = vec![format!("{HUB_TOOL}:{op}")];
    for key in HUB_SUBJECT_KEYS {
        if let Some(value) = input.get(key) {
            parts.push(format!("{key}={value}"));
        }
    }
    Some(parts.join(" "))
}

fn repeat_refusal(fingerprint: &str, seen: usize) -> String {
    format!(
        "BLOCKED: this is look number {seen} at the same thing inside {REPEAT_WINDOW_SECONDS}s \
         ({fingerprint}); repeating a read until it changes is polling, and polling is waiting \
         that fills the transcript. The process reports its own exit: do other work until it \
         does, or wait once for that exit with a timeout that covers it."
    )
}

/// The refusal this call earns, if any. `now` is seconds since the epoch;
/// `record` is where looks are counted (a session's ring), or `None` for a
/// call outside any session, which is never counted.
pub fn check(payload: &Value, now: u64, record: Option<&std::path::Path>) -> Option<String> {
    let tool = tool_name_of(payload);
    let input = tool_input(payload);
    if tool == SHELL_TOOL {
        let command = input
            .get("command")
            .and_then(Value::as_str)
            .unwrap_or_default();
        return only_passes_time(command).then(|| SLEEP_REFUSAL.to_string());
    }
    let fingerprint = look_fingerprint(&tool, &input)?;
    let record = record?;
    let seen = ring::record_look(record, &fingerprint, now, REPEAT_WINDOW_SECONDS);
    (seen >= REPEAT_LIMIT).then(|| repeat_refusal(&fingerprint, seen))
}

pub fn run() {
    let payload = read_payload();
    let session = session_id_of(&payload);
    let record = (!session.is_empty()).then(|| ring::path_for(&session));
    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|elapsed| elapsed.as_secs())
        .unwrap_or_default();
    if let Some(refusal) = check(&payload, now, record.as_deref()) {
        deny_tool_use(&refusal);
    }
}
