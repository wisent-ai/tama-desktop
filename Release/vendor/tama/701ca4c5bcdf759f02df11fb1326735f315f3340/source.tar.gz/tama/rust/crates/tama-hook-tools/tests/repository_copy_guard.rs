//! `tama-block-repository-copies`, driven as the real binary with a real
//! payload on stdin.
//!
//! The operator's rule is one checkout per repository: no linked worktrees, no
//! second clones, no recursive copies of a checkout. Each case below holds one
//! command to its own exit status and, when refused, to the exact refusal
//! sentence, so a later rewrite cannot quietly widen the guard onto
//! `git worktree list` or narrow it off `git worktree add`.
//!
//! The copy cases build real fixture directories: whether a source is a
//! checkout is answered from the filesystem, so the fixture has to carry a
//! real `.git`.

use std::fs;
use std::io::Write as _;
use std::path::{Path, PathBuf};
use std::process::{Command, Output, Stdio};
use std::time::{SystemTime, UNIX_EPOCH};

use serde_json::json;

const EXIT_PASS: i32 = false as i32;
const EXIT_REFUSED: i32 = true as i32 + true as i32;

const GUARD: &str = env!("CARGO_BIN_EXE_tama-block-repository-copies");

const WORKTREE_REFUSAL: &str = "BLOCKED: repository copies are forbidden. 'git worktree add' \
                                makes a second checkout; work in the existing checkout instead. \
                                Remove existing worktrees with 'tama worktrees remove --root \
                                <PATH> --apply'.";
const COPY_REFUSAL: &str = "BLOCKED: recursively copying a git repository makes a copy of it. \
                            Work in the existing checkout instead.";

fn clone_refusal(source: &str) -> String {
    format!(
        "BLOCKED: cloning a local repository makes a copy of it. Work in the existing checkout at \
         {source} instead."
    )
}

/// Fixtures live under the crate's own `CARGO_TARGET_TMPDIR` inside
/// `target/`, never the OS temp directory this machine sweeps and never
/// `~/.stado/work`, which belongs to Stado: a fixture that vanishes mid-run
/// fails a test for a reason that has nothing to do with the guard.
fn scratch(label: &str) -> PathBuf {
    let nonce = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .expect("clock after epoch")
        .as_nanos();
    let thread = format!("{:?}", std::thread::current().id()).replace(['(', ')'], "-");
    let path = PathBuf::from(env!("CARGO_TARGET_TMPDIR"))
        .join(format!("tama-repository-copies-{label}-{thread}{nonce}"));
    fs::create_dir_all(&path).expect("create scratch root");
    path
}

/// A directory that really is a checkout, and one that really is not.
fn fixtures(label: &str) -> (PathBuf, PathBuf, PathBuf) {
    let root = scratch(label);
    let checkout = root.join("checkout");
    fs::create_dir_all(checkout.join(".git")).expect("create fixture checkout");
    let plain = root.join("notes");
    fs::create_dir_all(&plain).expect("create fixture folder");
    (root, checkout, plain)
}

fn run_payload(payload: &serde_json::Value) -> Output {
    let mut child = Command::new(GUARD)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .unwrap_or_else(|error| panic!("spawn the guard: {error}"));
    child
        .stdin
        .as_mut()
        .expect("guard stdin")
        .write_all(payload.to_string().as_bytes())
        .expect("write payload");
    child.wait_with_output().expect("guard output")
}

fn run(command: &str) -> Output {
    run_payload(&json!({ "tool_name": "Bash", "tool_input": { "command": command } }))
}

fn refuses(command: &str, sentence: &str) {
    let output = run(command);
    let stderr = String::from_utf8_lossy(&output.stderr).into_owned();
    assert_eq!(
        output.status.code(),
        Some(EXIT_REFUSED),
        "{command} should be refused; stderr: {stderr}"
    );
    assert_eq!(
        stderr.trim_end(),
        sentence,
        "refusal sentence for {command}"
    );
}

fn passes(command: &str) {
    let output = run(command);
    let stderr = String::from_utf8_lossy(&output.stderr).into_owned();
    assert_eq!(
        output.status.code(),
        Some(EXIT_PASS),
        "{command} should pass; stderr: {stderr}"
    );
    assert!(stderr.is_empty(), "a passing call prints nothing: {stderr}");
}

fn display(path: &Path) -> String {
    path.display().to_string()
}

#[test]
fn worktree_add_is_refused() {
    refuses(
        "git worktree add ../brama-stub-purge main",
        WORKTREE_REFUSAL,
    );
}

#[test]
fn worktree_add_behind_a_repository_option_is_refused() {
    let (root, checkout, _plain) = fixtures("worktree-option");
    let command = format!(
        "git -C {} worktree add {} main",
        display(&checkout),
        display(&root.join("second"))
    );
    refuses(&command, WORKTREE_REFUSAL);
    fs::remove_dir_all(&root).expect("remove scratch root");
}

#[test]
fn clone_of_a_local_path_is_refused() {
    let (root, checkout, _plain) = fixtures("clone-local");
    let source = display(&checkout);
    let command = format!("git clone {source} {}", display(&root.join("copy")));
    refuses(&command, &clone_refusal(&source));
    fs::remove_dir_all(&root).expect("remove scratch root");
}

#[test]
fn clone_of_a_remote_url_passes() {
    passes("git clone https://github.com/wisent-ai/tama.git tama");
}

#[test]
fn worktree_list_passes() {
    passes("git worktree list --porcelain");
}

#[test]
fn recursive_copy_of_a_checkout_is_refused() {
    let (root, checkout, _plain) = fixtures("cp-repo");
    let command = format!(
        "cp -r {} {}",
        display(&checkout),
        display(&root.join("copy"))
    );
    refuses(&command, COPY_REFUSAL);
    fs::remove_dir_all(&root).expect("remove scratch root");
}

#[test]
fn rsync_of_a_checkout_is_refused() {
    let (root, checkout, _plain) = fixtures("rsync-repo");
    let command = format!(
        "rsync -a {}/ {}",
        display(&checkout),
        display(&root.join("copy"))
    );
    refuses(&command, COPY_REFUSAL);
    fs::remove_dir_all(&root).expect("remove scratch root");
}

#[test]
fn a_later_segment_carrying_worktree_add_is_refused() {
    refuses(
        "echo preparing the checkout && git worktree add ../copy main",
        WORKTREE_REFUSAL,
    );
}

#[test]
fn recursive_copy_of_a_folder_without_a_repository_passes() {
    let (root, _checkout, plain) = fixtures("cp-plain");
    let command = format!("cp -r {} {}", display(&plain), display(&root.join("copy")));
    passes(&command);
    fs::remove_dir_all(&root).expect("remove scratch root");
}

/// The hole a live session found, and the reason the earlier suite passed
/// while the ban did nothing.
///
/// Every copy case here used a literal path, so the guard could stat the
/// source and see its `.git`. A real agent writes the path into a variable,
/// and the hook sees the command text rather than the shell's expansion of
/// it: `cp -r "$REPO" dest` offered the literal `$REPO`, which stats as
/// nothing, and the copy went through with the hook loaded and enabled. A
/// source the guard cannot examine is now refused, because it cannot prove
/// the source is not a checkout.
#[test]
fn a_copy_whose_source_is_a_shell_variable_is_refused() {
    let (root, _checkout, _plain) = fixtures("cp-variable");
    let destination = display(&root.join("copy"));
    for source in ["$REPO", "\"$REPO\"", "${REPO}", "$(pwd)/repo", "`pwd`/repo"] {
        let command = format!("cp -r {source} {destination}");
        let output = run(&command);
        let stderr = String::from_utf8_lossy(&output.stderr).into_owned();
        assert_eq!(
            output.status.code(),
            Some(EXIT_REFUSED),
            "{command} should be refused; stderr: {stderr}"
        );
        assert!(
            stderr.contains("is a git repository, because the path is not literal"),
            "unexaminable source sentence for {command}: {stderr}"
        );
    }
    let plain = format!("cp -r {} {destination}", display(&root.join("notes")));
    passes(&plain);
    fs::remove_dir_all(&root).expect("remove scratch root");
}

/// `rsync` needs no recursive flag, so the same hole applied to it.
#[test]
fn an_rsync_whose_source_is_a_shell_variable_is_refused() {
    let (root, _checkout, _plain) = fixtures("rsync-variable");
    let command = format!("rsync -a \"$REPO\"/ {}", display(&root.join("copy")));
    let output = run(&command);
    let stderr = String::from_utf8_lossy(&output.stderr).into_owned();
    assert_eq!(
        output.status.code(),
        Some(EXIT_REFUSED),
        "{command} should be refused; stderr: {stderr}"
    );
    fs::remove_dir_all(&root).expect("remove scratch root");
}

/// Jeden runs worktrees as a tool, not a shell command, and its payload
/// carries `action` instead of `command`. Registering this guard on
/// `pre_tool_use:git_worktree` only helps if the payload is read that way.
#[test]
fn the_native_worktree_tool_is_refused_on_add() {
    let payload = json!({
        "tool_name": "git_worktree",
        "tool_input": { "action": "add", "path": "../copy" },
    });
    let output = run_payload(&payload);
    let stderr = String::from_utf8_lossy(&output.stderr).into_owned();
    assert_eq!(output.status.code(), Some(EXIT_REFUSED), "stderr: {stderr}");
    assert_eq!(stderr.trim_end(), WORKTREE_REFUSAL);
}

/// Cleaning a machine up must stay possible, so the read and prune actions
/// of that same tool pass.
#[test]
fn the_native_worktree_tool_passes_on_list_and_prune() {
    for action in ["list", "prune", "remove"] {
        let payload = json!({
            "tool_name": "git_worktree",
            "tool_input": { "action": action },
        });
        let output = run_payload(&payload);
        assert_eq!(
            output.status.code(),
            Some(EXIT_PASS),
            "{action} should pass: {}",
            String::from_utf8_lossy(&output.stderr)
        );
    }
}
