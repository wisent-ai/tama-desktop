//! What a provider adapter config says, and what it actually installs.
//!
//! One repair lives here, and it is the reason this module exists as its own
//! file. The registry became portable: every path in it is spelled
//! `$HOME/...` so the document can be published and installed anywhere. This
//! reader took the adapter path verbatim and handed it to the filesystem,
//! which knows nothing about `$HOME`, so on every machine both provider
//! configs read as absent — and the drift report above turned that into one
//! word, "unreadable", and refused. The coverage those providers really
//! install was never compared to the catalogue at all: the check that was
//! supposed to catch a provider missing a hook had been answering a question
//! about a path that cannot exist.
//!
//! So the path is expanded here, and a failure now says which of the three
//! things happened: the registry declares no path, the declared path holds no
//! file, or the file could not be read as JSON. Those are different states
//! with different repairs, and one word covered all three.

use std::collections::BTreeMap;
use std::fs;

use serde_json::Value;

use super::js_str;
use crate::registry::Registry;
use crate::{err, Result};

const HOME_ENV: &str = "HOME";
const HOME_VARIABLE: &str = "$HOME";
const HOME_VARIABLE_BRACED: &str = "${HOME}";
const HOME_TILDE: &str = "~";

/// One `{ event, command }` pair extracted from an adapter config.
#[derive(Debug, Clone)]
pub struct AdapterHookEntry {
    pub event: String,
    pub command: String,
}

/// JS `adapterCommandIndex`: event name -> installed command strings.
pub type AdapterCommandIndex = BTreeMap<String, Vec<String>>;

/// Why an adapter config could not be indexed. Each variant is a different
/// state of the world, and the drift report names them apart.
#[derive(Debug, Clone)]
pub enum AdapterConfigProblem {
    /// This registry document declares no path for the runtime. An installed
    /// registry is stamped without its adapter block, so this is the normal
    /// state there and says nothing about coverage.
    Undeclared { runtime: String },
    /// The registry declares a path and nothing is there.
    Missing { runtime: String, path: String },
    /// The file is there and could not be read or parsed.
    Unreadable {
        runtime: String,
        path: String,
        detail: String,
    },
}

impl AdapterConfigProblem {
    /// The sentence a report prints for this state.
    pub fn reason(&self) -> String {
        match self {
            Self::Undeclared { runtime } => format!(
                "this registry declares no {runtime} adapter path, so what that runtime installs \
                 was not compared"
            ),
            Self::Missing { runtime, path } => {
                format!("the {runtime} adapter config declared at {path} is not on this machine")
            }
            Self::Unreadable {
                runtime,
                path,
                detail,
            } => format!("the {runtime} adapter config at {path} could not be read: {detail}"),
        }
    }
}

/// A registry path made usable on this machine: `$HOME`, `${HOME}` and a
/// leading `~` all stand for the home directory. An unset home leaves the
/// text as written, so the reader reports the path it actually tried.
pub fn expand_home_path(value: &str) -> String {
    let Ok(home) = std::env::var(HOME_ENV) else {
        return value.to_string();
    };
    let home = home.trim_end_matches('/');
    if value == HOME_TILDE || value == HOME_VARIABLE || value == HOME_VARIABLE_BRACED {
        return home.to_string();
    }
    for prefix in [HOME_VARIABLE_BRACED, HOME_VARIABLE, HOME_TILDE] {
        if let Some(rest) = value.strip_prefix(&format!("{prefix}/")) {
            return format!("{home}/{rest}");
        }
    }
    value.to_string()
}

/// JS `adapterCommandIndex(registry, runtime)`, with the state named when it
/// cannot be built.
pub fn adapter_command_index_result(
    registry: &Registry,
    runtime: &str,
) -> std::result::Result<AdapterCommandIndex, AdapterConfigProblem> {
    let declared = registry
        .adapters
        .get(runtime)
        .and_then(|adapter| adapter.path.clone())
        .filter(|path| !path.is_empty())
        .ok_or_else(|| AdapterConfigProblem::Undeclared {
            runtime: runtime.to_string(),
        })?;
    let path = expand_home_path(&declared);
    let text = fs::read_to_string(&path).map_err(|error| match error.kind() {
        std::io::ErrorKind::NotFound => AdapterConfigProblem::Missing {
            runtime: runtime.to_string(),
            path: path.clone(),
        },
        _ => AdapterConfigProblem::Unreadable {
            runtime: runtime.to_string(),
            path: path.clone(),
            detail: error.to_string(),
        },
    })?;
    let config: Value =
        serde_json::from_str(&text).map_err(|error| AdapterConfigProblem::Unreadable {
            runtime: runtime.to_string(),
            path: path.clone(),
            detail: error.to_string(),
        })?;
    let mut by_event: AdapterCommandIndex = BTreeMap::new();
    for entry in hook_entries_from_adapter_config(&config) {
        by_event.entry(entry.event).or_default().push(entry.command);
    }
    Ok(by_event)
}

/// The same index for callers that only need an error message.
pub fn adapter_command_index(registry: &Registry, runtime: &str) -> Result<AdapterCommandIndex> {
    adapter_command_index_result(registry, runtime).map_err(|problem| err(problem.reason()))
}

/// JS `toolEventsFromMatcher(matcher)`, preserving first-insertion order
/// (JS `Set` semantics).
fn tool_events_from_matcher(matcher: &str) -> Vec<String> {
    let mut events: Vec<&str> = Vec::new();
    let mut push = |event: &'static str| {
        if !events.contains(&event) {
            events.push(event);
        }
    };
    for tool in matcher
        .split('|')
        .map(|tool| tool.trim().to_lowercase())
        .filter(|tool| !tool.is_empty())
    {
        match tool.as_str() {
            "bash" | "run_command" | "runcommands" | "runpackagecommand" | "runpackagescript" => {
                push("pre_tool_use:bash")
            }
            "read" | "readfile" => push("pre_tool_use:read"),
            "edit" | "apply_patch" => push("pre_tool_use:edit"),
            "write" | "writefile" => push("pre_tool_use:write"),
            "multiedit" => push("pre_tool_use:multiedit"),
            "task" | "agent" => push("pre_tool_use:task"),
            "todo" => push("pre_tool_use:todo"),
            "goal" => push("pre_tool_use:goal"),
            "grep" | "glob" | "search" | "lsp" | "astgrep" | "ast_grep" => {
                push("pre_tool_use:lookup")
            }
            "eval" | "execute_code" | "mcp__node_repl_js" | "node_repl/js" => {
                push("pre_tool_use:eval")
            }
            "ssh" => push("pre_tool_use:ssh"),
            "notebookedit" | "notebook_edit" => push("pre_tool_use:notebook"),
            "monitor" | "schedulewakeup" | "schedule_wakeup" | "wait" => push("pre_tool_use:wait"),
            _ => {}
        }
    }
    events.into_iter().map(str::to_string).collect()
}

/// JS `adapterEvents(adapterEvent, matcher)`.
fn adapter_events(adapter_event: &str, matcher: &str) -> Vec<String> {
    let key = adapter_event.to_lowercase();
    match key.as_str() {
        "stop" => vec!["stop".to_string()],
        "userpromptsubmit" | "user_prompt_submit" => vec!["user_prompt_submit".to_string()],
        "sessionstart" | "session_start" => vec!["session_start:compact".to_string()],
        "posttooluse" | "post_tool_use" => tool_events_from_matcher(matcher)
            .into_iter()
            .map(|event| event.replacen("pre_tool_use:", "post_tool_use:", 1))
            .collect(),
        "pretooluse" | "pre_tool_use" => tool_events_from_matcher(matcher),
        _ => Vec::new(),
    }
}

/// JS `hookEntriesFromAdapterConfig(config)`.
fn hook_entries_from_adapter_config(config: &Value) -> Vec<AdapterHookEntry> {
    let mut entries = Vec::new();
    let empty: Vec<Value> = Vec::new();
    let hooks_root = config.get("hooks").and_then(Value::as_object);
    if let Some(hooks_root) = hooks_root {
        for (adapter_event, blocks) in hooks_root {
            for block in blocks.as_array().unwrap_or(&empty) {
                let matcher = js_str(block.get("matcher"));
                for event in adapter_events(adapter_event, &matcher) {
                    for hook in block
                        .get("hooks")
                        .and_then(Value::as_array)
                        .unwrap_or(&empty)
                    {
                        // JS: `if (hook.command)` — truthy (non-empty) string.
                        if let Some(command) = hook
                            .get("command")
                            .and_then(Value::as_str)
                            .filter(|c| !c.is_empty())
                        {
                            entries.push(AdapterHookEntry {
                                event: event.clone(),
                                command: command.to_string(),
                            });
                        }
                    }
                }
            }
        }
    }
    entries
}

/// JS `basenameFromCommand(command)`: last path segment of the first token
/// ending in `.py`/`.sh`/`.mjs`/`.js` (or of the first token), with one
/// leading/trailing quote stripped per token.
pub(crate) fn basename_from_command(command: &str) -> String {
    let parts: Vec<&str> = command
        .trim()
        .split_whitespace()
        .map(|part| {
            let part = part.strip_prefix(|c| c == '\'' || c == '"').unwrap_or(part);
            part.strip_suffix(|c| c == '\'' || c == '"').unwrap_or(part)
        })
        .collect();
    let first = parts.first().copied().unwrap_or("");
    let last = parts
        .iter()
        .copied()
        .find(|part| {
            part.ends_with(".py")
                || part.ends_with(".sh")
                || part.ends_with(".mjs")
                || part.ends_with(".js")
        })
        .unwrap_or(first);
    last.rsplit('/').next().unwrap_or("").to_string()
}

/// JS `commandsMatch(adapterCommand, registryCommand, hookId)`.
pub(crate) fn commands_match(adapter_command: &str, registry_command: &str, hook_id: &str) -> bool {
    if adapter_command == registry_command {
        return true;
    }
    if !hook_id.is_empty()
        && (adapter_command.contains(&format!("TAMA_ONLY_HOOK_ID='{hook_id}'"))
            || adapter_command.contains(&format!("TAMA_ONLY_HOOK_ID=\"{hook_id}\"")))
        && matches!(
            basename_from_command(adapter_command).as_str(),
            "run-hook.mjs" | "tama-run-hook"
        )
    {
        return true;
    }
    let adapter_base = basename_from_command(adapter_command);
    let registry_base = basename_from_command(registry_command);
    !adapter_base.is_empty() && !registry_base.is_empty() && adapter_base == registry_base
}
