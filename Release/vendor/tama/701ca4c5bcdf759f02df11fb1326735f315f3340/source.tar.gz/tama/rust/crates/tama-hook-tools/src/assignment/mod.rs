//! Session-bound operator instructions and receipts for reading Oko's ledger.
//! A different session cannot replace an instruction or acknowledge its read.
//! Receipts are separate from captured instructions, so a slow read cannot
//! overwrite a newer prompt. The acting model's summary is never a source.

use std::fs;
use std::io::{self, Write};
use std::path::{Path, PathBuf};

use serde::{Deserialize, Serialize};
use serde_json::Value;
use tama_hooks::session_control::tama_state_root;
use tama_hooks::sha256::sha256_hex;

pub mod completion;
pub mod rules;
pub mod stop_order;
const USAGE_EXIT: i32 = 2;

/// One operator instruction, as it was written.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Assignment {
    /// The session the instruction belongs to; an instruction does not carry
    /// over into another session.
    pub session_id: String,
    /// Digest of the session and the exact words, so a later prompt supersedes
    /// an earlier one without anyone comparing prose.
    pub turn_digest: String,
    pub captured_at: String,
    /// Verbatim. Never summarised.
    pub text: String,
}

#[derive(Serialize, Deserialize)]
struct ReadReceipt {
    turn_digest: String,
    ledger_digest: String,
}

impl Assignment {
    /// Both this prompt and the current authoritative task state must be read.
    pub fn unread(&self) -> Result<bool, String> {
        self.unread_with(|| rules::task_ledger(&self.session_id))
    }

    /// The same check with the ledger supplied by the caller, read only when
    /// the receipt makes it necessary.
    pub fn unread_with(
        &self,
        ledger: impl FnOnce() -> Result<rules::TaskLedger, String>,
    ) -> Result<bool, String> {
        let receipt: Option<ReadReceipt> = read_json(&session_path(&self.session_id, "read.json"))
            .map_err(|error| error.to_string())?;
        let Some(receipt) = receipt else {
            return Ok(true);
        };
        if receipt.turn_digest != self.turn_digest {
            return Ok(true);
        }
        Ok(receipt.ledger_digest != ledger()?.digest)
    }
}

/// The override selects a namespace, never another session's assignment.
fn state_path() -> PathBuf {
    match std::env::var("TAMA_ASSIGNMENT_STATE") {
        Ok(path) if !path.is_empty() => PathBuf::from(path),
        _ => tama_state_root().join("current-assignment.json"),
    }
}

fn session_path(session_id: &str, suffix: &str) -> PathBuf {
    state_path().with_extension(format!("{}.{suffix}", sha256_hex(session_id.as_bytes())))
}

fn read_json<T: serde::de::DeserializeOwned>(path: &Path) -> io::Result<Option<T>> {
    let bytes = match fs::read(path) {
        Ok(bytes) => bytes,
        Err(error) if error.kind() == io::ErrorKind::NotFound => return Ok(None),
        Err(error) => {
            return Err(io::Error::new(
                error.kind(),
                format!("{}: {error}", path.display()),
            ))
        }
    };
    serde_json::from_slice(&bytes).map(Some).map_err(|error| {
        io::Error::new(
            io::ErrorKind::InvalidData,
            format!("{}: {error}", path.display()),
        )
    })
}

pub fn load(session_id: &str) -> io::Result<Option<Assignment>> {
    let record: Option<Assignment> = read_json(&session_path(session_id, "json"))?;
    if record
        .as_ref()
        .is_some_and(|record| record.session_id != session_id)
    {
        return Err(io::Error::new(
            io::ErrorKind::InvalidData,
            "assignment belongs to a different session",
        ));
    }
    Ok(record)
}

fn write_json(path: &Path, value: &impl Serialize) -> io::Result<()> {
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent)?;
    }
    let body = serde_json::to_vec_pretty(value).map_err(io::Error::other)?;
    let pending = path.with_extension(format!("pending{}", std::process::id()));
    let result = fs::write(&pending, body).and_then(|_| fs::rename(&pending, path));
    if result.is_err() {
        let _ = fs::remove_file(&pending);
    }
    result
}

/// Even identical words in a later turn require a new read. Preserve their
/// whitespace; it is part of the operator's input, not an agent summary.
pub fn capture(session_id: &str, text: &str) -> io::Result<Option<Assignment>> {
    if session_id.is_empty() {
        return Err(io::Error::new(
            io::ErrorKind::InvalidInput,
            "the prompt has no session identifier",
        ));
    }
    if text.trim().is_empty() {
        return Ok(None);
    }
    let captured = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map_err(io::Error::other)?;
    let record = Assignment {
        session_id: session_id.to_string(),
        turn_digest: sha256_hex(
            format!("{session_id}\u{0}{}\u{0}{text}", captured.as_nanos()).as_bytes(),
        ),
        captured_at: captured.as_secs().to_string(),
        text: text.to_string(),
    };
    write_json(&session_path(session_id, "json"), &record)?;
    Ok(Some(record))
}

/// The prompt text of a `user_prompt_submit` payload, wherever the harness put
/// it.
pub fn prompt_of(payload: &Value) -> String {
    for key in ["prompt", "user_message", "text"] {
        if let Some(text) = payload.get(key).and_then(Value::as_str) {
            if !text.trim().is_empty() {
                return text.to_string();
            }
        }
    }
    payload
        .get("raw_event")
        .and_then(|event| event.get("text").or_else(|| event.get("prompt")))
        .and_then(Value::as_str)
        .unwrap_or_default()
        .to_string()
}

/// `tama-cli assignment show` — the reading surface the stop guard requires.
pub fn cli_main(args: &[String]) -> i32 {
    let mut args = args.iter();
    let mut session = None;
    let mut json = false;
    if args.next().map(String::as_str) != Some("show") {
        eprintln!("usage: tama-cli assignment show --session ID [--json]");
        return USAGE_EXIT;
    }
    while let Some(argument) = args.next() {
        match argument.as_str() {
            "--session" if session.is_none() => {
                session = args
                    .next()
                    .filter(|value| !value.is_empty() && !value.starts_with("--"))
            }
            "--json" => json = true,
            _ => {
                eprintln!("usage: tama-cli assignment show --session ID [--json]");
                return USAGE_EXIT;
            }
        }
    }
    let Some(session) = session else {
        eprintln!("assignment show requires --session ID; another session's instruction is not a fallback");
        return USAGE_EXIT;
    };
    match show(session, json) {
        Ok(()) => 0,
        Err(error) => {
            eprintln!("cannot read the current assignment for session {session}: {error}");
            1
        }
    }
}

fn show(session: &str, json: bool) -> Result<(), String> {
    let record = load(session)
        .map_err(|error| error.to_string())?
        .ok_or_else(|| {
            format!(
                "no instruction recorded for session {session}; check record-current-assignment"
            )
        })?;
    let ledger = rules::task_ledger(session)?;
    let current = load(session).map_err(|error| error.to_string())?;
    if current.as_ref().map(|value| &value.turn_digest) != Some(&record.turn_digest) {
        return Err(
            "the operator spoke while Oko was being read; read the current assignment again"
                .to_string(),
        );
    }
    #[derive(Serialize)]
    struct Reading<'a> {
        #[serde(flatten)]
        assignment: &'a Assignment,
        ledger: &'a Value,
    }
    let output = if json {
        serde_json::to_string_pretty(&Reading {
            assignment: &record,
            ledger: &ledger.value,
        })
        .map_err(|error| error.to_string())?
            + "\n"
    } else {
        format!(
            "session: {}\ncaptured: {}\noperator instruction:\n{}\n\nOko task ledger:\n{}\n\n{}",
            record.session_id,
            record.captured_at,
            record.text,
            serde_json::to_string_pretty(&ledger.value).map_err(|error| error.to_string())?,
            rules::rules_or_reason()
        )
    };
    let mut stdout = io::stdout().lock();
    stdout
        .write_all(output.as_bytes())
        .and_then(|_| stdout.flush())
        .map_err(|error| format!("cannot deliver the task reading: {error}"))?;
    write_json(
        &session_path(session, "read.json"),
        &ReadReceipt {
            turn_digest: record.turn_digest,
            ledger_digest: ledger.digest,
        },
    )
    .map_err(|error| format!("cannot record the task reading: {error}"))
}
