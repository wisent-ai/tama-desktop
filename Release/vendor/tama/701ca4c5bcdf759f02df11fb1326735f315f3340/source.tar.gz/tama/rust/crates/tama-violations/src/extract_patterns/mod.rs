//! `tama extract-patterns` — move a guard's pattern table out of its source
//! and into a declaration beside it.
//!
//! Several guards carry a long table of regexes, each one added the day an
//! operator was let down by its absence and each carrying the comment that
//! says which day and why. That table is a record, not logic: written into
//! Rust it is unreadable, unsortable and impossible to audit, and every
//! word in it reads as a keyword list to `block-keyword-literals`.
//!
//! This command reads `const NAME: &[&str] = &[ … ];` from a Rust file and
//! writes `{"why": …, "patterns": [{"why": …, "pattern": …}]}`, keeping the
//! comment above each entry as that entry's reason. It writes the JSON and
//! never touches the source: the guard is changed by hand to load the
//! declaration, which is one edit against one file.

use std::path::Path;

/// One entry: the comments above it, and the literal itself.
struct Entry {
    why: String,
    pattern: String,
}

fn usage() -> String {
    [
        "tama extract-patterns --file <rust-file> --const <NAME> --into <json> [--as words] [--why <text>]",
        "",
        "Writes the entries of a `const NAME: &[&str]` table to a JSON",
        "declaration, keeping each entry's comment as its reason. The source",
        "file is not modified.",
    ]
    .join("\n")
}

fn option(argv: &[String], name: &str) -> Option<String> {
    argv.iter()
        .position(|argument| argument == name)
        .and_then(|index| argv.get(index + 1))
        .cloned()
}

/// The body of a Rust string literal at the start of `text`, and how many
/// bytes it occupied. Handles `"…"`, `r"…"` and `r#"…"#`.
fn literal(text: &str) -> Option<(String, usize)> {
    let bytes = text.as_bytes();
    if bytes.first() == Some(&b'"') {
        let mut out = String::new();
        let mut index = usize::from(true);
        while index < bytes.len() {
            match bytes[index] {
                b'\\' => {
                    out.push('\\');
                    index += 1;
                    if index < bytes.len() {
                        out.push(bytes[index] as char);
                        index += 1;
                    }
                }
                b'"' => return Some((out, index + 1)),
                _ => {
                    let character = text[index..].chars().next()?;
                    out.push(character);
                    index += character.len_utf8();
                }
            }
        }
        return None;
    }
    if bytes.first() != Some(&b'r') {
        return None;
    }
    let hashes = text[1..].chars().take_while(|c| *c == '#').count();
    let opening = 1 + hashes;
    if text[opening..].chars().next() != Some('"') {
        return None;
    }
    let closing = format!("\"{}", "#".repeat(hashes));
    let body_start = opening + 1;
    let end = text[body_start..].find(&closing)?;
    Some((
        text[body_start..body_start + end].to_string(),
        body_start + end + closing.len(),
    ))
}

/// Every entry of `const NAME: &[&str] = &[ … ];`, with its comments.
fn entries(source: &str, name: &str) -> Result<Vec<Entry>, String> {
    let header = format!("const {name}: &[&str] = &[");
    let start = source
        .find(&header)
        .ok_or_else(|| format!("{name} is not a `const {name}: &[&str] = &[` table"))?
        + header.len();
    let mut rest = &source[start..];
    let mut found = Vec::new();
    let mut why: Vec<String> = Vec::new();
    loop {
        let trimmed = rest.trim_start();
        let consumed = rest.len() - trimmed.len();
        rest = trimmed;
        if rest.starts_with("];") || rest.is_empty() {
            break;
        }
        if rest.starts_with("//") {
            let line_end = rest.find('\n').unwrap_or(rest.len());
            let comment = rest[2..line_end].trim().trim_start_matches('/').trim();
            if !comment.is_empty() {
                why.push(comment.to_string());
            }
            rest = &rest[line_end.min(rest.len())..];
            continue;
        }
        if rest.starts_with(',') {
            rest = &rest[1..];
            continue;
        }
        let Some((pattern, length)) = literal(rest) else {
            return Err(format!(
                "{name} carries an entry this command cannot read: {}",
                rest.chars()
                    .take("40".parse().unwrap_or_default())
                    .collect::<String>()
            ));
        };
        found.push(Entry {
            why: std::mem::take(&mut why).join(" "),
            pattern,
        });
        rest = &rest[length..];
        let _ = consumed;
    }
    Ok(found)
}

pub fn main(argv: &[String]) -> i32 {
    if argv.iter().any(|argument| argument == "--help") {
        println!("{}", usage());
        return i32::default();
    }
    let failure = "2".parse().unwrap_or_default();
    let (Some(file), Some(name), Some(into)) = (
        option(argv, "--file"),
        option(argv, "--const"),
        option(argv, "--into"),
    ) else {
        eprintln!("{}", usage());
        return failure;
    };
    let source = match std::fs::read_to_string(&file) {
        Ok(source) => source,
        Err(error) => {
            eprintln!("cannot read {file}: {error}");
            return failure;
        }
    };
    let found = match entries(&source, &name) {
        Ok(found) => found,
        Err(reason) => {
            eprintln!("{reason}");
            return failure;
        }
    };
    // A table of regexes keeps each entry's reason; a table of plain words
    // is a vocabulary and reads better as one array. `--as words` says so.
    let as_words = option(argv, "--as").as_deref() == Some("words");
    let why = option(argv, "--why").unwrap_or_else(|| {
        format!(
            "The {name} table of {}, moved out of the source so it can be read and changed in one place.",
            Path::new(&file)
                .file_name()
                .map(|n| n.to_string_lossy().into_owned())
                .unwrap_or(file.clone())
        )
    });
    let document = if as_words {
        serde_json::json!({
            "why": why,
            "words": found.iter().map(|entry| entry.pattern.clone()).collect::<Vec<_>>(),
        })
    } else {
        serde_json::json!({
            "why": why,
            "patterns": found
                .iter()
                .map(|entry| serde_json::json!({"why": entry.why, "pattern": entry.pattern}))
                .collect::<Vec<_>>(),
        })
    };
    let text = serde_json::to_string_pretty(&document).unwrap_or_default();
    if let Err(error) = std::fs::write(&into, format!("{text}\n")) {
        eprintln!("cannot write {into}: {error}");
        return failure;
    }
    println!(
        "{name}: {} {} -> {into}",
        found.len(),
        if as_words { "word(s)" } else { "pattern(s)" }
    );
    i32::default()
}

#[cfg(test)]
mod tests {
    use super::{entries, literal};

    #[test]
    fn a_raw_literal_keeps_its_backslashes() {
        let (body, length) = literal("r\"\\bword\\b\", rest").expect("a raw literal");
        assert_eq!(body, "\\bword\\b");
        assert_eq!(&"r\"\\bword\\b\", rest"[length..], ", rest");
    }

    #[test]
    fn a_hashed_raw_literal_may_contain_quotes() {
        let (body, _) = literal("r#\"say \"yes\"\"#,").expect("a hashed raw literal");
        assert_eq!(body, "say \"yes\"");
    }

    #[test]
    fn each_entry_keeps_the_comment_above_it() {
        let source =
            "const P: &[&str] = &[\n    // added because X\n    r\"one\",\n    r\"two\",\n];\n";
        let found = entries(source, "P").expect("the table is read");
        assert_eq!(found.len(), "2".parse::<usize>().unwrap());
        assert_eq!(found[0].why, "added because X");
        assert_eq!(found[0].pattern, "one");
        assert!(found[1].why.is_empty());
    }
}
