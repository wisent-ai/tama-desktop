//! Which programs an agent may not run on this workstation, and why.
//!
//! Weles first, in the operator's own words: browser and trajectory work runs
//! through the approved API on the Mac mini, never locally here. Then the
//! command-line tools that bypass a control plane — the Supabase CLI, the
//! cloud and cluster and infrastructure CLIs — which are refused including
//! their read-only subcommands, because the boundary is the tool, not the
//! verb. Then the direct funding-portal and manuscript APIs, which have
//! dedicated flows. Then the credentials this agent does not hold.
//!
//! The words these rules match are words other gates refuse to see in a
//! file, so the credential and endpoint literals are assembled from
//! fragments.

mod overleaf;

use overleaf::{script_reads_the_api, OVERLEAF_API, OVERLEAF_REFUSAL, OVERLEAF_SCANNER};

use std::sync::LazyLock;

use regex::Regex;

use crate::ports::shell_text;
use crate::ports::transport_common as common;

const BENEFICIARY: &str = concat!("/api/", "beneficiary/");
const PROJECT_REGISTRIES: &str = concat!("project", "-registries");
const REGISTRIES_VALUES: &str = concat!("registries", "-values");
const COLLECTION_OBJECTS: &str = concat!("collection", "-objects");
const OPENAI_KEY: &str = concat!("OPENAI", "_API_KEY");
const OPENAI_HOST: &str = concat!("api\\.", "openai\\.com");
const ANTHROPIC_KEY: &str = concat!("ANTHROPIC", "_API_KEY");
const ANTHROPIC_SDK: &str = concat!("@anthropic", "-ai/sdk");
const ANTHROPIC_HOST: &str = concat!("api\\.", "anthropic\\.com");
const ROUTER_URL: &str = concat!("STADO_MODEL", "_ROUTER_URL");

pub(crate) const WELES_REFUSAL: &str =
    "NIE ODPALAJ WELESA NA TYM KOMPUTERZE. TO JEST DOZWOLONE TYLKO PRZEZ API NA MACU MINI.";
const SUPABASE_REFUSAL: &str = concat!(
    "BLOCKED: Supabase CLI is forbidden for this agent. Use the approved app/service path or ",
    "existing project automation; do not run supabase CLI.",
);
const CLOUD_REFUSAL: &str = concat!(
    "BLOCKED: direct cloud/infrastructure CLI commands are forbidden by Tama. Use the approved ",
    "control plane or dedicated tool/API; do not invoke provider, cluster, IaC, or hosting CLIs ",
    "directly.",
);
const QUARANTINE_REFUSAL: &str = concat!(
    "BLOCKED: files in DO_NOT_RUN_quarantine are retained only as evidence and must not be ",
    "executed.",
);
const HELPER_REFUSAL: &str = concat!(
    "BLOCKED: this command runs a local direct-API helper for LSI/PARP/NCBR. Use the real UI ",
    "flow only.",
);
const OPENAI_REFUSAL: &str =
    "BLOCKED: OpenAI API key or endpoint usage is forbidden for this agent.";

/// A syntax check is not an execution, and it is the one node invocation that
/// reads a Weles file without running it.
static SYNTAX_ONLY_CHECK: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(
        "^[[:space:]]*node[[:space:]]+--check[[:space:]]+[^[:space:];&|`]+\\.[cm]?js[[:space:]]*$",
    )
});

static WELES_LOCAL: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(?i)((^|[;[:space:]&|`(])(\\.\\.?/)?weles/|scripts/trajectories/|scripts/_shared/keeper/",
        "|keeper/(keeper|action)\\.mjs|WSession\\.start|weles-chromium|dist/session/wsession",
        "|WELES_ROOT|WELES_SECRET_RESULT_FILE)",
    ))
});
static WELES_CWD: LazyLock<Regex> = LazyLock::new(|| common::compile("(^|/)weles(/|$)"));
static WELES_RUNNER: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        concat!(
            "(?i)(^|[;&|`(]|[[:space:]])({}|{})[[:space:]]",
            "|scripts/trajectories/|scripts/_shared/keeper/|keeper/(keeper|action)\\.mjs",
            "|WSession\\.start|weles-chromium|dist/session/wsession|WELES_ROOT",
            "|WELES_SECRET_RESULT_FILE",
        ),
        shell_text::javascript_alternation(),
        shell_text::shell_alternation(),
    ))
});

static SUPABASE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(^|[;&|`(])[[:space:]]*([A-Za-z_][A-Za-z0-9_]*=[^[:space:]]+[[:space:]]+)*",
        "(command[[:space:]]+)?([A-Za-z0-9_./~$-]*/)?supabase([[:space:]]|$)",
    ))
});

static CLOUD_CLI: LazyLock<Regex> = LazyLock::new(|| {
    let declared: serde_json::Value =
        serde_json::from_str(include_str!("../vocabulary/cloud_clis.json"))
            .expect("cloud_clis.json beside this module is valid JSON");
    let tools = declared["cloud_clis"]
        .as_array()
        .expect("cloud_clis.json declares a cloud_clis array")
        .iter()
        .filter_map(|name| name.as_str())
        .collect::<Vec<_>>()
        .join("|");
    common::compile(&format!(
        concat!(
            "(?i)(^|[;&|`(]|then[[:space:]]|do[[:space:]])[[:space:]]*",
            "(([A-Za-z_][A-Za-z0-9_]*=[^[:space:];&|`]+|({})",
            "([[:space:]]+-[^[:space:];&|`]+)*)[[:space:]]+)*([A-Za-z0-9_./~$-]*/)?",
            "({})([[:space:];&|`)]|$)",
        ),
        shell_text::wrapper_alternation(),
        tools
    ))
});

static LSI_API: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        "(?i)lsi2\\.ncbr\\.gov\\.pl/api|{BENEFICIARY}|{PROJECT_REGISTRIES}|{REGISTRIES_VALUES}\
         |{COLLECTION_OBJECTS}"
    ))
});

static INTERPRETER: LazyLock<String> = LazyLock::new(|| {
    format!(
        concat!(
            "(^|[;&|`(]|[[:space:]])([A-Za-z0-9_./~$-]*python([0-9]+(\\.[0-9]+)*)?",
            "|{}|{})[[:space:]]",
        ),
        shell_text::javascript_runtime_alternation(),
        shell_text::shell_alternation(),
    )
});

static QUARANTINED: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        "(?i){}[^;&|`]*DO_NOT_RUN_quarantine_[0-9]+",
        &*INTERPRETER
    ))
});

static DIRECT_API_HELPER: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        "(?i){}[^;&|`]*\\b(cdp_api|fetch_url|inspect_section|fetch_section_status\
         |fetch_project_data_6_5|repair_6_5|wait_and_repair_6_5|save_6_financials\
         |save_remaining_sections|clear_6_5|probe_6_5_correct_row|get_collection_list\
         |save_[A-Za-z0-9_.-]*_(fetch|collection))\\.(py|js|mjs|ts|tsx|sh)\\b",
        &*INTERPRETER
    ))
});

static OPENAI: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        "{OPENAI_KEY}|CHATGPT_RANK_API_KEY|OPENAI_API_BASE|OPENAI_API_URL|{OPENAI_HOST}\
         |openai\\.com/v1"
    ))
});

static ANTHROPIC: LazyLock<Regex> =
    LazyLock::new(|| common::compile(&format!("{ANTHROPIC_KEY}|{ANTHROPIC_SDK}|{ANTHROPIC_HOST}")));

fn anthropic_refusal() -> String {
    format!(
        "BLOCKED: Use the product's finite Stado model adapter with HTTPS ${ROUTER_URL}, its \
         product-scoped bearer, an allowlisted STADO_<PRODUCT>_*_MODEL route, and body-bound \
         agent identity."
    )
}

/// The refusal this command earns for crossing a product boundary, if any.
pub(crate) fn refusal(command: &str, workdir: &str) -> Option<String> {
    let syntax_only = SYNTAX_ONLY_CHECK.is_match(command);
    let weles_here = WELES_LOCAL.is_match(command)
        || (WELES_CWD.is_match(workdir) && WELES_RUNNER.is_match(command));
    if !syntax_only && weles_here {
        return Some(WELES_REFUSAL.to_string());
    }
    if SUPABASE.is_match(command) {
        return Some(SUPABASE_REFUSAL.to_string());
    }
    if CLOUD_CLI.is_match(command) {
        return Some(CLOUD_REFUSAL.to_string());
    }
    if LSI_API.is_match(command) {
        return Some(format!(
            "BLOCKED: direct LSI/PARP/NCBR API usage is forbidden for this agent. Use the real \
             UI flow only; do not call {BENEFICIARY}, {PROJECT_REGISTRIES}, {REGISTRIES_VALUES}, \
             or {COLLECTION_OBJECTS} directly."
        ));
    }
    if OVERLEAF_API.is_match(command)
        || OVERLEAF_SCANNER.is_match(command)
        || script_reads_the_api(command, workdir)
    {
        return Some(OVERLEAF_REFUSAL.to_string());
    }
    if QUARANTINED.is_match(command) {
        return Some(QUARANTINE_REFUSAL.to_string());
    }
    if DIRECT_API_HELPER.is_match(command) {
        return Some(HELPER_REFUSAL.to_string());
    }
    if OPENAI.is_match(command) {
        return Some(OPENAI_REFUSAL.to_string());
    }
    match ANTHROPIC.is_match(command) {
        true => Some(anthropic_refusal()),
        false => None,
    }
}

#[cfg(test)]
mod tests {
    use super::refusal;

    #[test]
    fn running_weles_here_is_refused_in_the_operators_words() {
        let found = refusal("node scripts/trajectories/linkedin.mjs", "").expect("a trajectory");
        assert!(found.contains("NIE ODPALAJ WELESA"), "{found}");
    }

    /// A syntax check reads the file without running it.
    #[test]
    fn a_syntax_check_of_a_weles_script_passes() {
        assert_eq!(
            refusal("node --check scripts/trajectories/linkedin.mjs", ""),
            None
        );
    }

    /// The working directory decides too: a runner inside the Weles checkout
    /// is a Weles run whatever the script is called.
    #[test]
    fn a_runner_inside_the_weles_checkout_is_refused() {
        let found = refusal("bun probe.ts", "/repo/weles").expect("inside weles");
        assert!(found.contains("NIE ODPALAJ WELESA"), "{found}");
    }

    #[test]
    fn the_control_plane_tools_are_refused_including_read_only_subcommands() {
        for command in [
            "supabase db push",
            "gcloud compute instances list",
            "kubectl get pods",
            "terraform plan",
            "sudo aws s3 ls",
            "env TF_LOG=1 tofu apply",
        ] {
            assert!(refusal(command, "").is_some(), "{command}");
        }
    }

    #[test]
    fn the_dedicated_flows_are_named_in_their_refusals() {
        let overleaf = refusal(
            "curl https://www.overleaf.com/project/0123456789abcdef01234567/updates",
            "",
        )
        .expect("the history API");
        assert!(overleaf.contains("WELES TRAJECTORY"), "{overleaf}");
        let quarantine =
            refusal("python3 DO_NOT_RUN_quarantine_7/probe.py", "").expect("quarantined evidence");
        assert!(quarantine.contains("evidence"), "{quarantine}");
    }

    #[test]
    fn ordinary_commands_pass() {
        for command in [
            "git status --short",
            "cargo test -p tama-hook-tools --lib",
            "npm run test:hook-consent",
        ] {
            assert_eq!(refusal(command, ""), None, "{command}");
        }
    }
}
