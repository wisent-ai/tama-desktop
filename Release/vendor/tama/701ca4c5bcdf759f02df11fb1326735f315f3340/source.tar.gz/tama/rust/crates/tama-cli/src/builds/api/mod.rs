//! The build registry operations shared by the CLI and desktop backend.

mod approval;

use serde::Deserialize;
use serde_json::{json, Value};
use std::path::Path;

use super::{intent, policy, ration, REGISTRY_FILE};
use crate::justify::registry;
use ration::{ledger, Admission};

#[derive(Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub(crate) struct RecordRequest {
    kind: String,
    target: String,
    reason: String,
    revision: Option<String>,
    repository: Option<String>,
    minutes: Option<u64>,
    approval_session: Option<String>,
    approval_quote: Option<String>,
}

impl RecordRequest {
    pub(crate) fn record(self, home: &Path) -> Result<Value, String> {
        let mut args = vec![
            "--kind".into(),
            self.kind,
            "--target".into(),
            self.target,
            "--reason".into(),
            self.reason,
        ];
        for (flag, value) in [
            ("--revision", self.revision),
            ("--repository", self.repository),
            ("--minutes", self.minutes.map(|value| value.to_string())),
            ("--approval-session", self.approval_session),
            ("--approval-quote", self.approval_quote),
        ] {
            if let Some(value) = value {
                args.extend([flag.into(), value]);
            }
        }
        record(&args, home)
    }
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct CloseRequest {
    kind: String,
    target: String,
}

impl CloseRequest {
    pub(crate) fn close(self, home: &Path) -> Result<Value, String> {
        close(
            &["--kind".into(), self.kind, "--target".into(), self.target],
            home,
        )
    }
}

pub(crate) fn close(argv: &[String], home: &Path) -> Result<Value, String> {
    let kind = intent::kind_of(argv)?;
    let target = intent::target_of(argv)?;
    let _lock = registry::Lock::acquire(&ledger::file(home))?;
    let path = home.join(".shared-hooks").join(REGISTRY_FILE);
    let key = format!("{kind}:{target}");
    registry::forget(&path, &key)?;
    Ok(json!({"closed": key, "registry": path}))
}

pub(crate) fn record(argv: &[String], home: &Path) -> Result<Value, String> {
    let policy = policy::load(&policy::file(home))?;
    let kind = intent::kind_of(argv)?;
    let target = intent::target_of(argv)?;
    let mut document = intent::entry(argv, &policy, &kind, &target)?;
    let approval = approval::requested(
        argv,
        &kind,
        &target,
        document["revision"].as_str().unwrap_or_default(),
    )?;
    // Network access happens before the file lock; only local checks and writes
    // belong in the registry transaction.
    let fleet_remaining = (kind == "build" && approval.is_none())
        .then(ration::fleet::remaining)
        .flatten();
    let ledger_file = ledger::file(home);
    let _lock = registry::Lock::acquire(&ledger_file)?;
    if let Some(approval) = approval {
        if ledger::approval_used(&ledger_file, &approval)? {
            return Err("this operator message already authorized a build of this product; closing the entry does not renew consent".into());
        }
        document["user_approval"] = approval;
    }
    let at = intent::now();
    let window = document["expires_at_epoch"].as_u64().expect("entry expiry")
        - document["recorded_at_epoch"]
            .as_u64()
            .expect("entry timestamp");
    document["recorded_at_epoch"] = json!(at);
    document["expires_at_epoch"] = json!(at + window);
    let admission = Admission {
        at,
        fleet_remaining,
        approved: document.get("user_approval").is_some(),
    };
    ration::rationed(argv, &policy, &ledger_file, &kind, &target, &admission)?;
    let path = home.join(".shared-hooks").join(REGISTRY_FILE);
    let key = format!("{kind}:{target}");
    if let Some(approval) = document.get("user_approval") {
        approval::still_current(approval)?;
    }
    // Never publish an authorization before its evidence is durable. A failed
    // registry write leaves a spent, auditable intent, not unrecorded permission.
    ledger::append(&ledger_file, &document)?;
    registry::record(&path, &key, document.clone())?;
    let spent = ledger::spent(&ledger_file, &kind, at, policy::WINDOW_SECONDS)?.len();
    Ok(json!({"recorded": key, "entry": document, "registry": path,
        "spent": spent, "allowed": policy.per_day(&kind)}))
}

pub(crate) fn list(home: &Path) -> Result<Value, String> {
    let path = home.join(".shared-hooks").join(REGISTRY_FILE);
    let entries = registry::load(&path)?;
    let at = intent::now();
    let policy = policy::load(&policy::file(home))?;
    let ledger_file = ledger::file(home);
    let rows: Vec<Value> = entries.into_iter().map(|(key, entry)|
        json!({"key": key, "open": intent::minutes_left(&entry, at).is_some(), "entry": entry})
    ).collect();
    let mut ration = Vec::new();
    for kind in ["build", "restart"] {
        let spent = ledger::spent(&ledger_file, kind, at, policy::WINDOW_SECONDS)?.len();
        let allowed = policy.per_day(kind);
        ration.push(json!({"kind": kind, "spent": spent, "allowed": allowed,
            "left": allowed.saturating_sub(spent as u64)}));
    }
    Ok(json!({"registry": path, "entries": rows, "ration": ration,
        "approval_history": ledger::approvals(&ledger_file)?}))
}

/// The fleet reads this before spending an exception. A caller supplies only
/// coordinates; consent comes from the registry and its matching audit entry.
pub(crate) fn approval(argv: &[String], home: &Path) -> Result<Value, String> {
    let target = intent::target_of(argv)?;
    let revision = intent::option(argv, "--revision").ok_or("--revision is required")?;
    let ledger_file = ledger::file(home);
    let _lock = registry::Lock::acquire(&ledger_file)?;
    let path = home.join(".shared-hooks").join(REGISTRY_FILE);
    let entries = registry::load(&path)?;
    let entry = entries
        .get(&format!("build:{target}"))
        .ok_or_else(|| format!("no recorded build approval for {target}"))?;
    if entry["revision"].as_str() != Some(revision.as_str())
        || intent::minutes_left(entry, intent::now()).is_none()
        || !entry["user_approval"].is_object()
        || !ledger::approvals(&ledger_file)?
            .iter()
            .any(|recorded| recorded == entry)
    {
        return Err(format!(
            "no unexpired, audited user approval for {target} at {revision}"
        ));
    }
    Ok(entry.clone())
}
