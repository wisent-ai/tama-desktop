//! The fixture catalogue every case starts from, the command line they
//! build, and the two ways a case reads the result.
//!
//! Split out of `tests/hook_metadata.rs`, which had grown past the
//! three-hundred-line limit; the cases are in `main.rs`.

use std::fs;
use std::path::PathBuf;
use std::process::{Command, Output};
use std::time::{SystemTime, UNIX_EPOCH};

pub const TOOL: &str = env!("CARGO_BIN_EXE_tama-record-hook-metadata");
pub const REAL_CATALOG: &str = concat!(
    env!("CARGO_MANIFEST_DIR"),
    "/../../../shared-hooks/catalog-metadata.json"
);

pub const EXIT_OK: i32 = false as i32;
pub const EXIT_DIFFERS: i32 = true as i32;
pub const EXIT_REFUSED: i32 = true as i32 + true as i32;

/// A document shaped like the real one: two-space indentation, a trailing
/// newline, punctuation inside a description that a careless scanner would
/// read as structure, and one entry carrying fields this tool does not own.
pub const CATALOG: &str = r#"{
  "block-alpha": {
    "status": "active",
    "category": "edit safety",
    "description": "Braces {}, a comma, and a \"quoted\" word, so a scan cannot end this early.",
    "why": "Held byte for byte to prove no other entry moves.",
    "sideEffects": "Reads the tool payload; exits non-zero on a violation."
  },
  "block-omega": {
    "status": "active",
    "category": "edit safety",
    "type": "requires_justification",
    "description": "Second entry.",
    "why": "Carries fields the command does not own.",
    "sideEffects": "Reads the justification registry.",
    "justificationRequirements": [
      {
        "kind": "file",
        "title": "File justification"
      }
    ]
  }
}
"#;

/// The four options the command requires, with the values every case uses.
pub const REQUIRED: [[&str; 2]; 4] = [
    ["--category", "edit safety"],
    [
        "--description",
        "Refuses a write that would leave the file over the limit.",
    ],
    ["--why", "The limit the operator asked for."],
    [
        "--side-effects",
        "Reads the tool payload; exits non-zero over the limit.",
    ],
];

/// The entry those options must produce, at the document's indentation.
pub const RECORDED: &str = r#"  "block-mid": {
    "status": "active",
    "category": "edit safety",
    "description": "Refuses a write that would leave the file over the limit.",
    "why": "The limit the operator asked for.",
    "sideEffects": "Reads the tool payload; exits non-zero over the limit."
  },
"#;

/// Fixtures live under the crate's own `CARGO_TARGET_TMPDIR` inside
/// `target/`, never the OS temp directory this machine sweeps and never
/// `~/.stado/work`, which belongs to Stado: a catalogue that vanishes
/// mid-run fails a test for a reason that has nothing to do with the command.
pub fn fixture(label: &str) -> PathBuf {
    let nonce = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .expect("clock after epoch")
        .as_nanos();
    let root = PathBuf::from(env!("CARGO_TARGET_TMPDIR"))
        .join(format!("tama-hook-metadata-{label}-{nonce}"));
    fs::create_dir_all(&root).expect("create scratch root");
    let path = root.join("catalog-metadata.json");
    fs::write(&path, CATALOG).expect("write the fixture catalogue");
    path
}

/// A command line: `front`, then every required option except `skip`, then the
/// catalogue path and the hook id.
pub fn argv(front: &[&str], catalog: &str, id: &str, skip: &str) -> Vec<String> {
    let mut argv: Vec<String> = front.iter().map(|part| (*part).to_string()).collect();
    for [name, value] in REQUIRED {
        if name != skip {
            argv.push(name.to_string());
            argv.push(value.to_string());
        }
    }
    argv.push(catalog.to_string());
    argv.push(id.to_string());
    argv
}

pub fn run(arguments: &[String]) -> Output {
    Command::new(TOOL)
        .args(arguments)
        .output()
        .unwrap_or_else(|error| panic!("spawn the command: {error}"))
}

pub fn stderr(output: &Output) -> String {
    String::from_utf8_lossy(&output.stderr)
        .trim_end()
        .to_owned()
}

pub fn stdout(output: &Output) -> String {
    String::from_utf8_lossy(&output.stdout)
        .trim_end()
        .to_owned()
}

pub fn refuses(arguments: &[String], sentence: &str) {
    let output = run(arguments);
    assert_eq!(
        output.status.code(),
        Some(EXIT_REFUSED),
        "{}",
        stderr(&output)
    );
    assert_eq!(stderr(&output).lines().next().unwrap_or_default(), sentence);
}
