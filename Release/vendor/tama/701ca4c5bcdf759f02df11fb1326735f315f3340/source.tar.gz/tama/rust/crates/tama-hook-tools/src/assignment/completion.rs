//! Oko owns completion and qualified blockers; a local plan cannot replace it.

use super::rules;
use crate::registry::shell_quote;
use sha2::{Digest, Sha256};

pub fn pending(session: &str) -> Result<Vec<String>, String> {
    if session.trim().is_empty() {
        return Err("the Stop payload contains no session identity".to_owned());
    }
    pending_from(&rules::task_ledger(session)?)
}

/// The open requests in a ledger already read. Tasks whose judge Oko itself
/// recorded as unable to answer, after their evidence was recorded, are
/// reported on stderr and not counted: the verdict they wait for cannot be
/// produced by continuing the turn, and Oko's control loop re-judges them
/// once the judge answers.
pub fn pending_from(ledger: &rules::TaskLedger) -> Result<Vec<String>, String> {
    let tasks = ledger.value["tasks"]
        .as_array()
        .ok_or("Oko returned no task array")?;
    let mut pending = Vec::new();
    for task in tasks {
        match task["status"].as_str() {
            Some("done" | "withdrawn") => continue,
            Some("not done") => {}
            _ => return Err(format!("Oko returned an unknown task status: {task}")),
        }
        // The verdict's prose cannot authorize stopping. Require Oko's
        // operation-backed receipt bound to this exact operator request.
        if task["verdict"]["outcome"].as_str() == Some("blocked") && qualified_blocker(task) {
            continue;
        }
        let ordinal = task["ordinal"]
            .as_u64()
            .ok_or("Oko returned an open task without its ordinal")?;
        let text = task["text"]
            .as_str()
            .filter(|text| !text.trim().is_empty())
            .ok_or("Oko returned an open task without its request")?;
        if let Some(outage) = judge_outage(task) {
            eprintln!(
                "completion: task #{ordinal} has recorded evidence and Oko's judge could not answer \
                 ({outage}); it is unjudged, not open, until the judge answers and `oko-cli transcripts \
                 tasks control` re-judges it."
            );
            continue;
        }
        // A task Oko records as a duplicate of another has no work of its
        // own: the original carries it, and the original is judged in this
        // same pass. On 2026-09-19 a reaction message related to the task it
        // resumed kept a session looping after the original had its proof
        // and its judge outage recorded.
        if let Some(original) = duplicate_of(task) {
            eprintln!(
                "completion: task #{ordinal} is a duplicate of {original}, which carries the work \
                 and is judged in its place."
            );
            continue;
        }
        pending.push(format!("#{ordinal}: {text}"));
    }
    Ok(pending)
}

/// Oko's own record that the judge failed after this task's evidence was
/// recorded: the report carries `proof` and a `judgeOutage` newer than it.
fn judge_outage(task: &serde_json::Value) -> Option<String> {
    let proof_at = task["proof"]["recordedAt"].as_str()?;
    let outage = &task["judgeOutage"];
    let at = outage["at"].as_str()?;
    let detail = outage["detail"]
        .as_str()
        .filter(|detail| !detail.trim().is_empty())?;
    // ISO-8601 timestamps from one writer compare as text.
    (at > proof_at).then(|| format!("{detail} at {at}"))
}

/// The task Oko says this one duplicates.
fn duplicate_of(task: &serde_json::Value) -> Option<String> {
    task["relations"]
        .as_array()?
        .iter()
        .find(|relation| relation["name"].as_str() == Some("duplicate-of"))
        .and_then(|relation| relation["other"].as_str())
        .map(str::to_owned)
}

fn qualified_blocker(task: &serde_json::Value) -> bool {
    let blocker = &task["verdict"]["blocker"];
    let Some(text) = task["text"].as_str() else {
        return false;
    };
    let digest = format!("{:x}", Sha256::digest(text.as_bytes()));
    let failure = &blocker["failure"];
    let observed_operation = |operation: &serde_json::Value| {
        ["callID", "tool", "arguments"].iter().all(|field| {
            operation[*field]
                .as_str()
                .is_some_and(|value| !value.trim().is_empty())
        }) && operation["result"].is_string()
            && operation["resultRecord"].as_u64().is_some()
    };
    blocker["taskOrdinal"] == task["ordinal"]
        && blocker["taskSHA256"].as_str() == Some(digest.as_str())
        && [
            "transcriptSHA256",
            "operation",
            "cause",
            "observedState",
            "resumeWhen",
        ]
        .iter()
        .all(|field| {
            blocker[*field]
                .as_str()
                .is_some_and(|value| !value.trim().is_empty())
        })
        && failure["isError"].as_bool() == Some(true)
        && observed_operation(failure)
        && blocker["alternatives"]
            .as_array()
            .is_some_and(|alternatives| {
                !alternatives.is_empty()
                    && alternatives.iter().all(|alternative| {
                        alternative["method"]
                            .as_str()
                            .is_some_and(|method| !method.trim().is_empty())
                            && alternative["operations"]
                                .as_array()
                                .is_some_and(|operations| {
                                    !operations.is_empty()
                                        && operations.iter().all(observed_operation)
                                        && operations.iter().any(|operation| {
                                            operation["callID"] != failure["callID"]
                                        })
                                })
                    })
            })
}

pub fn refusal(session: &str, pending: &[String]) -> String {
    let mut verify = format!(
        "{} transcripts tasks verify --before-stop --session {}",
        shell_quote(&rules::oko_cli()),
        shell_quote(session)
    );
    if let Ok(database) = std::env::var("OKO_TRANSCRIPT_INDEX_PATH") {
        if !database.is_empty() {
            verify.push_str(&format!(" --db {}", shell_quote(&database)));
        }
    }
    format!(
        "BLOCKED (completion): Oko still has executable work:\n{}\n\
         Continue the assigned work. After delivering and checking its real result, run \
         {verify} and inspect the verdict. A completed or blocked local plan does not close \
         the operator's tasks. A blocker needs independently inspected failed-operation and \
         alternative-method evidence, bound to this request, plus its resumption condition. \
         Missing observations require diagnosis, not an operator acknowledgement. Do not edit \
         the ledger or bypass a real permission refusal.",
        pending.join("\n")
    )
}

#[cfg(test)]
#[path = "completion_tests.rs"]
mod tests;
