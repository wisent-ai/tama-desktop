//! Which violations a repair round may touch, and the brief it is given.

use crate::find_violations::{is_ignored, Violation};
use crate::js_num;

/// Files a repair agent never edits: generated or structurally owned.
pub const GENERATED_PATHS: [&str; 3] = [
    "package-lock.json",
    "shared-hooks/registry.json",
    "shared-hooks/catalog-metadata.json",
];

pub fn is_actionable(violation: &Violation, skip: &[String], ignore_entries: &[String]) -> bool {
    if GENERATED_PATHS.contains(&violation.path.as_str()) {
        return false;
    }
    if is_ignored(&violation.path, ignore_entries) {
        return false;
    }
    for fragment in skip {
        if violation.path.contains(fragment.as_str()) {
            return false;
        }
    }
    true
}

pub struct BriefParams<'a> {
    pub repo: &'a str,
    pub violations: &'a [Violation],
    pub round: i64,
    pub max_rounds: f64,
    pub skip: &'a [String],
    /// The round may change only what the two size rules ask for. The
    /// content rules are still enforced on every write, so a split that
    /// trips one is refused — but this round is not asked to go fix them.
    pub size_only: bool,
    pub note: Option<&'a str>,
    pub feedback: &'a [String],
}

/// Port of `buildBrief`: the exact prompt handed to the cleaning agent.
pub fn build_brief(params: &BriefParams) -> String {
    let list = if params.violations.is_empty() {
        "(no scanner violations; follow the additional instruction below)".to_string()
    } else {
        params
            .violations
            .iter()
            .map(|v| format!("- {} — {}", v.path, v.message))
            .collect::<Vec<_>>()
            .join("\n")
    };
    let mut lines: Vec<String> = vec![
        format!(
            "You are cleaning the repository at {} so it passes the enforced hook content rules.",
            params.repo
        ),
        format!(
            "Round {} of {}. The scanner reports {} violation(s):",
            params.round,
            js_num(params.max_rounds),
            params.violations.len()
        ),
        String::new(),
        list,
        String::new(),
        if params.size_only {
            "Rules in scope for this round (the two size rules, nothing else):".to_string()
        } else {
            "Rules being enforced (checked by replaying the real pre-write hook):".to_string()
        },
        "- max 300 lines per file: split longer files into smaller modules. Structured data"
            .to_string(),
        "  (.json, .jsonl, .ndjson, .toml, .lock, .csv, .tsv) and manuscript sources (.tex, .bib,"
            .to_string(),
        "  .sty, .bst, .cls) are exempt: splitting a registry breaks the reader that loads it,"
            .to_string(),
        "  and a chapter is not a module.".to_string(),
        "- max 5 files per folder: move files into sub-folders or consolidate (folders matching"
            .to_string(),
        "  supabase/migrations, node_modules, .git, __pycache__, tests, migrations are exempt)."
            .to_string(),
        if params.size_only {
            "- the content rules are NOT this round's work: leave a flagged constant, pattern"
                .to_string()
        } else {
            "- forbidden content patterns, time-limit and retry bans, provider/key bans, and"
                .to_string()
        },
        if params.size_only {
            "  or wording exactly as it is, even when you move it into a new module.".to_string()
        } else {
            "  unsubstantiated numeric constants (each violation message names its rule)."
                .to_string()
        },
        String::new(),
        "Do not game the rules:".to_string(),
        "- Splits must produce REAL modules with ordinary imports/exports between them. Never"
            .to_string(),
        "  glue sources into a runtime blob: no data-URL module imports, no eval, no globalThis"
            .to_string(),
        "  smuggling of shared symbols, no invented pseudo-extensions like .source/.part/.inc."
            .to_string(),
        "- Every file you create must be reachable from its crate or package: declare new Rust"
            .to_string(),
        "  modules where their parent expects them, and import new modules where they are used."
            .to_string(),
        "  A copy nothing compiles is not a split.".to_string(),
        "- Do not rename files to dodge hook gates (for example dropping \"test\" from a test"
            .to_string(),
        "  file name). Comply with the gates instead (file/test justifications).".to_string(),
        "- Put new files in semantically matching folders — read what a folder holds first;"
            .to_string(),
        "  create a new well-named subfolder when nothing matches.".to_string(),
        "- Module names must say what is inside; no near-duplicate names in one folder."
            .to_string(),
        String::new(),
        "How to fix:".to_string(),
        "- Fix in place: split long files into focused modules, move files into sub-folders,"
            .to_string(),
        "  rewrite flagged constructs. Preserve behavior; do not delete features.".to_string(),
        "- Creating a file may require a 50+ word justification entry under its absolute path in"
            .to_string(),
        "  ~/.shared-hooks/file_justifications.json — add it first when the tooling asks for it."
            .to_string(),
        "- Do NOT commit, push, or create branches. Leave all changes in the working tree."
            .to_string(),
        "- Do NOT touch .git/, generated files (package-lock.json, shared-hooks/registry.json,"
            .to_string(),
        "  shared-hooks/catalog-metadata.json), or anything outside this repo.".to_string(),
    ];
    if !params.skip.is_empty() {
        lines.push(format!(
            "Explicitly out of scope, do not touch: {}.",
            params.skip.join(", ")
        ));
    }
    if !params.feedback.is_empty() {
        lines.push(String::new());
        lines.push("Your previous attempt was rejected for rule-gaming:".to_string());
        lines.extend(params.feedback.iter().cloned());
        lines.push("Redo it properly: real modules, honest names, correct folders.".to_string());
    }
    if let Some(note) = params.note {
        lines.push(String::new());
        lines.push("Additional instruction from the operator:".to_string());
        lines.push(note.to_string());
    }
    lines.push("- When done, print one summary line per file you changed.".to_string());
    lines.join("\n")
}
