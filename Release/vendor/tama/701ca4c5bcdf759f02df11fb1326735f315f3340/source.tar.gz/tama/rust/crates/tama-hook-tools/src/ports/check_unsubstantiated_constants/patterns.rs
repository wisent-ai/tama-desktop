//! What an unsubstantiated constant looks like, and where one is expected.
//!
//! The shapes are deliberately broad: a number that configures, estimates or
//! tunes something has to be traceable to a decision, and the cheapest place
//! to catch it is where it is typed.

use std::sync::LazyLock;

use regex::Regex;

use crate::ports::transport_common as common;

/// Files where numeric constants are expected and allowed.
const ALLOWED_PATHS: &[&str] = &[
    "[Cc]onstants?\\.",
    "[Cc]onstants?/",
    "_catalog/",
    "config\\.py$",
    "config\\.toml$",
    "settings\\.py$",
    "setup\\.py$",
    "setup\\.cfg$",
    "pyproject\\.toml$",
    "\\.shared-hooks/file_justifications\\.json$",
    "\\.shared-hooks/check_unsubstantiated_constants\\.py$",
];

/// `(pattern, description)`, in the order the Python checked them.
const SHAPES: &[(&str, &str)] = &[
    (
        "^[[:space:]]*[A-Z_][A-Z0-9_]*[[:space:]]*[:=][[:space:]]*-?[0-9]+(\\.[0-9]+)?\\b",
        "UPPER_SNAKE constant assignment",
    ),
    (
        "os\\.(environ\\.get|getenv)[[:space:]]*\\([[:space:]]*['\\x22][^'\\x22]+['\\x22][[:space:]]*,[[:space:]]*['\\x22]?-?[0-9]+(\\.[0-9]+)?['\\x22]?[[:space:]]*\\)",
        "numeric env default",
    ),
    (
        "\\bdef[[:space:]]+\\w+[[:space:]]*\\([^)]*\\b\\w+[[:space:]]*=[[:space:]]*-?[0-9]+(\\.[0-9]+)?\\b",
        "numeric function default",
    ),
    (
        "^[[:space:]]*Environment[[:space:]]*=[[:space:]]*[A-Z_][A-Z0-9_]*[[:space:]]*=[[:space:]]*-?[0-9]+(\\.[0-9]+)?\\b",
        "systemd numeric env var",
    ),
    (
        "\\bexport[[:space:]]+[A-Z_][A-Z0-9_]*[[:space:]]*=[[:space:]]*-?[0-9]+(\\.[0-9]+)?\\b",
        "shell numeric env export",
    ),
    (
        "['\\x22]?[a-z_][a-z0-9_]*['\\x22]?[[:space:]]*:[[:space:]]*-?[0-9]+(\\.[0-9]+)?\\b",
        "numeric key-value config",
    ),
];

/// A bare numeric return, which Python spells with a negative lookahead to
/// keep `return 0` and `return 1` — a status, not a tuning constant. The Rust
/// engine has no lookaround, so the number is captured and compared instead.
const BARE_RETURN: &str = "^[[:space:]]*return[[:space:]]+-?(?P<number>[0-9]+(\\.[0-9]+)?)\\b";
pub(crate) const BARE_RETURN_DESCRIPTION: &str = "bare numeric return";
const STATUS_RETURNS: &[&str] = &["0", "1"];

/// Obvious non-constants: a version string, a year, an octal or hex literal.
const VERSION: &str = "(?i)version[[:space:]]*[:=][[:space:]]*['\\x22]?[0-9]";
const YEAR: &str = "\\b20[0-9][0-9]\\b";
const RADIX: &str = "\\b0o[0-9]+|0x[0-9a-fA-F]+";

pub(crate) static ALLOWED_PATH: LazyLock<Vec<Regex>> =
    LazyLock::new(|| ALLOWED_PATHS.iter().map(|p| common::compile(p)).collect());

pub(crate) static CONSTANT_SHAPES: LazyLock<Vec<(Regex, &'static str)>> = LazyLock::new(|| {
    SHAPES
        .iter()
        .map(|(pattern, description)| (common::compile(pattern), *description))
        .collect()
});

pub(crate) static BARE_NUMERIC_RETURN: LazyLock<Regex> =
    LazyLock::new(|| common::compile(BARE_RETURN));
pub(crate) static NOT_A_CONSTANT: LazyLock<Vec<Regex>> = LazyLock::new(|| {
    [VERSION, YEAR, RADIX]
        .iter()
        .map(|p| common::compile(p))
        .collect()
});

/// Whether this line returns a status rather than a tuning constant.
pub(crate) fn returns_a_status(line: &str) -> bool {
    match BARE_NUMERIC_RETURN.captures(line) {
        Some(caps) => match caps.name("number") {
            Some(found) => STATUS_RETURNS.contains(&found.as_str()),
            None => true,
        },
        None => true,
    }
}

/// Remote writes that reach an installed package or a unit file, which is how
/// a constant gets injected on a host without passing a local gate.
pub(crate) static REMOTE_WRITE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(?i)\\bssh\\b.*?(>>?|\\bcp[[:space:]]|\\bmv[[:space:]]|\\btee[[:space:]]",
        "|\\bsed[[:space:]]+-[a-zA-Z]*i|\\binstall[[:space:]]",
        "|\\bpython3[[:space:]]+-.*\\bopen\\(|\\bcat[[:space:]]*>).*?",
        "(\\.(py|conf|service|socket|timer)|/site-packages/|/systemd/system/)",
    ))
});

pub(crate) static SCP_WRITE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(
        "(?i)\\bscp\\b.*?:~?(/etc/systemd/system|/site-packages|/usr/lib/systemd|/opt)\\S*",
    )
});

pub(crate) static RSYNC_WRITE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(?i)\\brsync\\b.*?:~?(/etc/systemd/system|/site-packages|/usr/lib/systemd|/opt",
        "|/home/[^/[:space:]]+/\\.local/lib/[^/[:space:]]+/site-packages)\\S*",
    ))
});

pub(crate) static REMOTE_ENV_CONSTANT: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(?i)\\bssh\\b.*?(Environment[[:space:]]*=[[:space:]]*[A-Z_][A-Z0-9_]*[[:space:]]*=[[:space:]]*[0-9]+",
        "|export[[:space:]]+[A-Z_][A-Z0-9_]*[[:space:]]*=[[:space:]]*[0-9]+)",
    ))
});

/// The marker that says a remote write carries its reason with it.
pub(crate) static JUSTIFY_MARKER: LazyLock<Regex> =
    LazyLock::new(|| common::compile("#[[:space:]]*justify:[[:space:]]*\\S"));
