//! JSON-lines transport; all hook and reload decisions belong to Runtime.

use std::io::{BufRead, Write};
use std::path::Path;

use serde_json::{json, Value};

use crate::{InvocationOptions, Runtime};

fn operation(
    runtime: &mut Runtime,
    request: &Value,
    agent_id: &str,
    provider: &str,
    options: &InvocationOptions,
) -> Result<Value, String> {
    let op = request
        .get("op")
        .and_then(Value::as_str)
        .ok_or_else(|| "runtime request requires a string op".to_owned())?;
    match op {
        "status" => Ok(Value::Null),
        "reload" => {
            let changed = runtime.reload()?;
            Ok(json!({ "reloaded": true, "changed": changed }))
        }
        "dispatch" => {
            let event = request
                .get("event")
                .and_then(Value::as_str)
                .filter(|event| !event.is_empty())
                .ok_or_else(|| "dispatch requires a nonempty event".to_owned())?;
            let payload = request
                .get("payload")
                .filter(|payload| payload.is_object())
                .ok_or_else(|| "dispatch requires an object payload".to_owned())?;
            let decision = crate::flow::dispatch_for_provider(
                runtime, event, agent_id, provider, options, payload,
            )?;
            serde_json::from_str(&decision.document).map_err(|error| error.to_string())
        }
        _ => Err(format!("unsupported runtime operation: {op}")),
    }
}

fn frame(writer: &mut impl Write, value: &Value) -> Result<(), String> {
    serde_json::to_writer(&mut *writer, value).map_err(|error| error.to_string())?;
    writer.write_all(b"\n").map_err(|error| error.to_string())?;
    writer.flush().map_err(|error| error.to_string())
}

pub(crate) fn serve(
    registry_path: &Path,
    agent_id: &str,
    provider: &str,
    options: &InvocationOptions,
) -> Result<(), String> {
    let mut runtime = Runtime::load(registry_path)?;
    let mut writer = std::io::stdout().lock();
    frame(
        &mut writer,
        &json!({ "type": "ready", "state": runtime.status() }),
    )?;
    for line in std::io::stdin().lock().lines() {
        let line = line.map_err(|error| error.to_string())?;
        let request = serde_json::from_str::<Value>(&line);
        let response = match request {
            Ok(request) => {
                let result = operation(&mut runtime, &request, agent_id, provider, options);
                let mut response = match result {
                    Ok(result) => json!({
                        "id": request.get("id"), "ok": true,
                        "result": result, "state": runtime.status(),
                    }),
                    Err(error) => json!({
                        "id": request.get("id"), "ok": false,
                        "error": error, "state": runtime.status(),
                    }),
                };
                if request.get("knownCatalogChecksum").and_then(Value::as_str)
                    != Some(runtime.catalog_checksum())
                {
                    response["catalog"] = runtime.catalog().clone();
                }
                response
            }
            Err(error) => json!({
                "id": null, "ok": false,
                "error": format!("invalid runtime request: {error}"),
                "state": runtime.status(),
            }),
        };
        frame(&mut writer, &response)?;
    }
    Ok(())
}
