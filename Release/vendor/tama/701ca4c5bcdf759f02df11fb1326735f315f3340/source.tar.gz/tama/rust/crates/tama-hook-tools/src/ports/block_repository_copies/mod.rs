//! Decision half of `tama-block-repository-copies` (registry hook
//! `block-repository-copies`).
//!
//! Unlike its neighbours this module ports no Python source: the guard is new,
//! so the policy is stated here once and the binary under
//! `src/bin/block/repo/` only carries it to the process boundary. The shape is
//! the one `block_unauthorized_ssh` uses — a pure
//! [`evaluate`] over the payload, returning the refusal banner — so the policy
//! is testable without spawning anything.
//!
//! The operator's order is that this machine holds one checkout per
//! repository: no linked worktrees, no second clones, no recursive copies of a
//! checkout. That is a disk-space rule, and the numbers behind it were
//! measured here: `~/.stado/work` held 1568 entries and 178 GB, and
//! `~/Documents/CodingProjects/Wisent` held 519 GB, with 12.4 GiB free of
//! 1.8 TB on the boot volume. A second checkout of one of those repositories
//! duplicates its build output, which is the large part, not its source.
//!
//! Two nouns are refused and they are not the same thing. A *linked worktree*
//! (`git worktree add`) is a checkout whose `.git` is a file pointing into the
//! owner's `.git/worktrees/`; `~/Documents/CodingProjects/Wisent/.worktrees/
//! brama-stub-purge/.git` on this machine is one. A *repository copy* is a
//! second full checkout with its own `.git` directory, which is what a clone
//! of a local path or a recursive copy produces; `~/worktrees/brama-build`
//! here is one of those. `tama worktrees remove` reclaims the first kind,
//! because that is the noun git itself tracks.
//!
//! Everything that only reads or repairs an existing layout still passes:
//! `git worktree list`, `remove`, `prune`, `unlock`, `repair`, a clone from a
//! remote URL, and any copy that touches no repository.

use std::path::Path;

use serde_json::Value;

mod native;

use crate::ports::python_stdlib::{one, shell_tokens};
use crate::ports::pyvalue::{first_truthy_py_str, py_str, truthy};

use crate::ports::tool_vocabulary::{COMMAND_KEYS, TOOL_INPUT_KEY};

/// Shell separators. A guard that reads only the first word of the payload
/// misses `cd repo && git worktree add ../copy`, so every segment is judged.
const SEGMENT_SPLIT: &[char] = &[';', '&', '|', '\n'];

const GIT_PROGRAM: &str = "git";
const WORKTREE: &str = "worktree";
const ADD: &str = "add";
const CLONE: &str = "clone";
const GIT_DIR: &str = ".git";
const END_OF_OPTIONS: &str = "--";
const SCHEME_MARK: &str = "://";
const FILE_SCHEME: &str = "file";

/// `git` options that consume the token after them, so the subcommand scan
/// does not read `<dir>` of `git -C <dir> worktree add` as the subcommand.
const GIT_VALUE_OPTIONS: &[&str] = &["-C", "-c", "--git-dir", "--work-tree", "--namespace"];

/// `git clone` options that consume the token after them, so the source is
/// the first real operand and not `--depth`'s argument.
const CLONE_VALUE_OPTIONS: &[&str] = &[
    "-o",
    "--origin",
    "-b",
    "--branch",
    "-u",
    "--upload-pack",
    "-c",
    "--config",
    "-j",
    "--jobs",
    "--reference",
    "--reference-if-able",
    "--separate-git-dir",
    "--depth",
    "--shallow-since",
    "--shallow-exclude",
    "--template",
    "--filter",
    "--server-option",
    "--bundle-uri",
];

/// Recursive copy programs. `cp` copies one file without `-r`, so it needs the
/// flag; `rsync` and `ditto` copy trees by nature.
const CP_PROGRAM: &str = "cp";
const COPY_PROGRAMS: &[&str] = &[CP_PROGRAM, "rsync", "ditto"];
const RECURSIVE_FLAGS: &[char] = &['r', 'R', 'a'];

/// Copy options that consume the token after them, so `rsync -e ssh repo dest`
/// does not offer `ssh` as a source path.
const COPY_VALUE_OPTIONS: &[&str] = &[
    "-e",
    "--rsh",
    "--exclude",
    "--include",
    "--exclude-from",
    "--include-from",
    "--files-from",
    "--filter",
    "--log-file",
    "--partial-dir",
    "--temp-dir",
];

const WORKTREE_REASON: &str = "BLOCKED: repository copies are forbidden. 'git worktree add' makes \
                               a second checkout; work in the existing checkout instead. Remove \
                               existing worktrees with 'tama worktrees remove --root <PATH> \
                               --apply'.";
const COPY_REASON: &str = "BLOCKED: recursively copying a git repository makes a copy of it. Work \
                           in the existing checkout instead.";

fn clone_reason(source: &str) -> String {
    format!(
        "BLOCKED: cloning a local repository makes a copy of it. Work in the existing checkout at \
         {source} instead."
    )
}

/// A copy whose source cannot be examined is refused, not waved through: the
/// guard cannot prove the source is not a checkout, and the whole point of
/// this hook is that a copy must not happen.
fn opaque_reason(source: &str) -> String {
    format!(
        "BLOCKED: cannot tell whether {source} is a git repository, because the path is not \
         literal. Pass the real path so the copy can be checked, or work in the existing \
         checkout instead."
    )
}

/// The shell command a payload carries: the named field, else the whole input
/// rendered as Python would render it — the shape the neighbouring shell
/// guards already use.
fn command_from(payload: &Value) -> String {
    let Some(raw) = payload.get(TOOL_INPUT_KEY).filter(|value| truthy(value)) else {
        return String::new();
    };
    if raw.is_object() {
        let named = first_truthy_py_str(raw, COMMAND_KEYS);
        if !named.is_empty() {
            return named;
        }
    }
    py_str(raw)
}

/// `Path(token).name`, so `/usr/bin/git` counts as `git`.
fn program_is(token: &str, program: &str) -> bool {
    Path::new(token).file_name().and_then(|name| name.to_str()) == Some(program)
}

/// The subcommand of a `git` invocation and the tokens after it, with the
/// global options — and the argument of those that take one — stepped over.
fn git_subcommand(tokens: &[String]) -> Option<(&str, &[String])> {
    let mut cursor = usize::MIN;
    while cursor < tokens.len() && tokens[cursor].starts_with('-') {
        let option = tokens[cursor].as_str();
        cursor += one();
        if GIT_VALUE_OPTIONS.contains(&option) && cursor < tokens.len() {
            cursor += one();
        }
    }
    let subcommand = tokens.get(cursor)?;
    Some((subcommand.as_str(), &tokens[cursor + one()..]))
}

/// The non-option arguments, with the argument of every value-taking option
/// stepped over. A lone `-` is an operand; `--` ends the options.
fn operands<'a>(tokens: &'a [String], value_options: &[&str]) -> Vec<&'a str> {
    let mut found: Vec<&str> = Vec::new();
    let mut skip_value = false;
    let mut options_done = false;
    for token in tokens {
        if skip_value {
            skip_value = false;
            continue;
        }
        if !options_done && token == END_OF_OPTIONS {
            options_done = true;
            continue;
        }
        if !options_done && token.len() > one() && token.starts_with('-') {
            skip_value = value_options.contains(&token.as_str());
            continue;
        }
        found.push(token.as_str());
    }
    found
}

/// A clone source is remote when it names a scheme other than `file`, or when
/// it is an `scp`-style `user@host:path` — a colon before the first slash.
/// Everything else is a path on this filesystem: absolute, relative, or
/// `file://`.
fn source_is_local(source: &str) -> bool {
    if let Some((scheme, _)) = source.split_once(SCHEME_MARK) {
        return scheme.eq_ignore_ascii_case(FILE_SCHEME);
    }
    match source.split_once(':') {
        Some((host, _)) => host.contains('/'),
        None => true,
    }
}

/// A source path is or contains a repository: a `.git` component names one
/// outright, and a directory holding `.git` is a checkout.
fn holds_repository(path: &str) -> bool {
    let candidate = Path::new(path);
    if candidate
        .components()
        .any(|part| part.as_os_str() == GIT_DIR)
    {
        return true;
    }
    candidate.join(GIT_DIR).exists()
}

/// `-r`, `-R`, `-a`, and the same letters inside a bundle such as `-av`.
fn is_recursive_flag(token: &str) -> bool {
    token.starts_with('-')
        && !token.starts_with(END_OF_OPTIONS)
        && token.chars().any(|flag| RECURSIVE_FLAGS.contains(&flag))
}

fn git_refusal(tokens: &[String]) -> Option<String> {
    let mut rest = tokens;
    while let Some((token, after_program)) = rest.split_first() {
        rest = after_program;
        if !program_is(token, GIT_PROGRAM) {
            continue;
        }
        let Some((subcommand, arguments)) = git_subcommand(after_program) else {
            continue;
        };
        if subcommand == WORKTREE && operands(arguments, &[]).first() == Some(&ADD) {
            return Some(WORKTREE_REASON.to_string());
        }
        if subcommand == CLONE {
            if let Some(source) = operands(arguments, CLONE_VALUE_OPTIONS).first() {
                if source_is_local(source) {
                    return Some(clone_reason(source));
                }
            }
        }
    }
    None
}

/// Does the token carry a shell expansion, so its real value is unknown here?
///
/// The hook sees the command text, not the shell's expansion of it, and the
/// copy check has to look at the source on disk to answer whether it is a
/// checkout. `cp -r "$REPO" dest` therefore offered the literal `$REPO`,
/// which stats as nothing, and the copy sailed through — proven live on
/// 2026-09-09 in a session that had this hook loaded and enabled, while the
/// same command with a literal path was refused. An agent writing paths into
/// variables is ordinary, so failing open here left the ban decorative.
fn is_unexpanded(token: &str) -> bool {
    token.contains('$') || token.contains('`')
}

fn copy_refusal(tokens: &[String]) -> Option<String> {
    let (program, arguments) = tokens.split_first()?;
    if !COPY_PROGRAMS
        .iter()
        .any(|candidate| program_is(program, candidate))
    {
        return None;
    }
    if program_is(program, CP_PROGRAM) && !arguments.iter().any(|token| is_recursive_flag(token)) {
        return None;
    }
    let paths = operands(arguments, COPY_VALUE_OPTIONS);
    let (_destination, sources) = paths.split_last()?;
    if let Some(source) = sources.iter().find(|source| is_unexpanded(source)) {
        return Some(opaque_reason(source));
    }
    sources
        .iter()
        .any(|source| holds_repository(source))
        .then(|| COPY_REASON.to_string())
}

/// The refusal this call earns, or `None` when it passes. The caller writes
/// the banner to stderr and exits 2.
pub fn evaluate(payload: &Value) -> Option<String> {
    if let Some(reason) = native::refusal(payload) {
        return Some(reason);
    }
    let command = command_from(payload);
    command
        .split(SEGMENT_SPLIT)
        .map(shell_tokens)
        .find_map(|tokens| git_refusal(&tokens).or_else(|| copy_refusal(&tokens)))
}
