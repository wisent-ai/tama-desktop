//! `tama hooks warm`: run every hook binary the registry names once, on
//! purpose, so the operating system's first-execution work is paid here
//! instead of inside a live hook event.
//!
//! On 2026-09-20 a stop event answered `block-delegating-own-work timed out
//! after 10s` and a finished turn was blocked. The binary was innocent: it
//! answers an empty payload in four milliseconds. What took the time was the
//! first execution of a newly installed copy — macOS assesses an executable
//! the first time it sees its code directory, `syspolicyd` makes a network
//! round trip to do it and XProtect scans the image. Measured on that machine
//! the first run took 147 seconds and every run after it took under 5
//! milliseconds. The engine waits for a hook rather than killing it, so that
//! cost is no longer a refusal — but it is still 147 seconds a person waits
//! inside a live event. Installing a binary and never running it is what
//! leaves that in front of the next real event, so `tama hooks release` warms
//! what it installs and this command warms a machine whose binaries arrived
//! some other way.

mod run;

use std::path::{Path, PathBuf};

use serde_json::Value;

pub use run::{
    registry_hooks, release_hooks, runtime_binary, warm_hooks, HookBinary, State, Warmed,
};

pub const USAGE: &str = "usage: tama hooks warm [--only <hook-id>[,<hook-id>…]] [--json]";

const REFUSED: i32 = 2;
const FAILED: i32 = 1;

/// The line a person reads for one hook.
fn line(warmed: &Warmed) -> String {
    format!(
        "{:<7} {:>7} ms  {}  ({})",
        warmed.state.text(),
        warmed.elapsed_ms,
        warmed.hook.id,
        warmed.hook.path.display()
    )
}

/// What a warm run observed, as one document: the desktop backend answers
/// with exactly this, and `--json` prints exactly this, so the screen and
/// the terminal cannot disagree about what a machine's gates cost.
pub fn report_value(results: &[Warmed]) -> Value {
    let rows: Vec<Value> = results
        .iter()
        .map(|warmed| {
            serde_json::json!({
                "id": warmed.hook.id,
                "command": warmed.hook.command,
                "path": warmed.hook.path.display().to_string(),
                "elapsedMs": warmed.elapsed_ms,
                "exitCode": warmed.code,
                "state": warmed.state.text(),
            })
        })
        .collect();
    let unusable = results
        .iter()
        .filter(|warmed| warmed.state == State::Missing)
        .count();
    let slowest = results
        .iter()
        .filter(|warmed| warmed.state == State::Warm)
        .max_by_key(|warmed| warmed.elapsed_ms);
    serde_json::json!({
        "hooks": rows,
        "warmed": results.len() - unusable,
        "slowest": slowest.map(|warmed| warmed.hook.id.clone()),
        "slowestMs": slowest.map(|warmed| warmed.elapsed_ms),
        "unusable": unusable,
    })
}

/// The hooks a selection names, or the refusal that names what it got wrong.
/// Shared so the command and the desktop backend refuse identically.
pub fn select(root: &Path, only: &[String]) -> Result<Vec<HookBinary>, String> {
    let registry = root.join("shared-hooks/registry.json");
    let home = PathBuf::from(std::env::var("HOME").unwrap_or_default());
    let mut all = registry_hooks(&registry);
    // The engine runs the sealed release, not the registry's copies: two
    // files, two first assessments, and only one of them was ever paid here.
    for sealed in release_hooks(&home) {
        if !all.iter().any(|known| known.path == sealed.path) {
            all.push(sealed);
        }
    }
    if all.is_empty() {
        return Err(format!(
            "{} names no hook binary of ours and {} holds none; there is nothing to warm",
            registry.display(),
            home.join("Library/Application Support/Tama/hooks-runtime/current/bin").display()
        ));
    }
    let unknown: Vec<&str> = only
        .iter()
        .filter(|id| !all.iter().any(|hook| &hook.id == *id))
        .map(String::as_str)
        .collect();
    if !unknown.is_empty() {
        return Err(format!(
            "{} names no hook called {}",
            registry.display(),
            unknown.join(", ")
        ));
    }
    Ok(match only.is_empty() {
        true => all,
        false => all
            .into_iter()
            .filter(|hook| only.contains(&hook.id))
            .collect(),
    })
}

/// Print what a warm run observed and answer with its exit code. Shared by
/// this command and by `tama hooks release`, which warms what it installs.
pub fn report(results: &[Warmed], json: bool) -> i32 {
    let unusable: Vec<&Warmed> = results
        .iter()
        .filter(|warmed| warmed.state == State::Missing)
        .collect();
    let slowest = results
        .iter()
        .filter(|warmed| warmed.state == State::Warm)
        .max_by_key(|warmed| warmed.elapsed_ms);
    match json {
        true => println!(
            "{}",
            serde_json::to_string_pretty(&report_value(results)).unwrap_or_default()
        ),
        false => {
            results
                .iter()
                .for_each(|warmed| println!("{}", line(warmed)));
            let cost = match slowest {
                Some(warmed) => format!(
                    "slowest {} at {} ms",
                    warmed.hook.id, warmed.elapsed_ms
                ),
                None => "nothing ran".to_string(),
            };
            println!(
                "hook binaries: {} warmed, {cost}, {} unusable",
                results.len() - unusable.len(),
                unusable.len()
            );
        }
    }
    for warmed in &unusable {
        eprintln!(
            "{} is {}: {} — a live event would refuse on it",
            warmed.hook.id,
            warmed.state.text(),
            warmed.hook.path.display()
        );
    }
    match unusable.is_empty() {
        true => 0,
        false => FAILED,
    }
}

fn refusal(message: &str) -> i32 {
    eprintln!("{message}");
    REFUSED
}

pub fn main(argv: &[String], root: &Path) -> i32 {
    if argv.iter().any(|arg| arg == "--help" || arg == "-h") {
        println!("{USAGE}");
        return 0;
    }
    let json = argv.iter().any(|arg| arg == "--json");
    let only: Vec<String> = argv
        .iter()
        .position(|arg| arg == "--only")
        .and_then(|at| argv.get(at + 1))
        .map(|list| list.split(',').map(|id| id.trim().to_string()).collect())
        .unwrap_or_default();
    match select(root, &only) {
        Ok(selected) => report(&warm_hooks(root, &selected), json),
        Err(error) => refusal(&error),
    }
}
