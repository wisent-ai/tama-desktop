use std::path::Path;

use serde_json::{json, Map, Value};

use super::super::registry;
use super::SCHEMA;

fn checked(mut document: Map<String, Value>, path: &Path) -> Result<Map<String, Value>, String> {
    if !path.exists() && document.is_empty() {
        document.insert("schema".into(), json!(SCHEMA));
        document.insert("authorizations".into(), json!([]));
    }
    if document.get("schema").and_then(Value::as_str) != Some(SCHEMA) {
        return Err(format!(
            "{} is not a {SCHEMA} registry; nothing was changed",
            path.display()
        ));
    }
    if !document.get("authorizations").is_some_and(Value::is_array) {
        return Err(format!(
            "{} must contain an authorizations array; nothing was changed",
            path.display()
        ));
    }
    Ok(document)
}

pub(super) fn load(path: &Path) -> Result<Map<String, Value>, String> {
    checked(registry::load(path)?, path)
}

pub(super) fn record(path: &Path, entry: Value) -> Result<(), String> {
    registry::update(path, |document| {
        let mut document = checked(document, path)?;
        let entries = document
            .get_mut("authorizations")
            .and_then(Value::as_array_mut)
            .ok_or("authorizations is not an array")?;
        entries.retain(|existing| {
            !(existing.get("userRequestQuote") == entry.get("userRequestQuote")
                && existing.get("allowedBundleId") == entry.get("allowedBundleId"))
        });
        // The installed policy selects the first backed grant. The requested
        // grant must not be hidden behind an earlier, narrower recording.
        entries.insert(0, entry);
        Ok(document)
    })
}

pub(super) fn forget(path: &Path, quote: &str) -> Result<usize, String> {
    let mut removed = 0;
    registry::update(path, |document| {
        let mut document = checked(document, path)?;
        let entries = document
            .get_mut("authorizations")
            .and_then(Value::as_array_mut)
            .ok_or("authorizations is not an array")?;
        let before = entries.len();
        entries
            .retain(|entry| entry.get("userRequestQuote").and_then(Value::as_str) != Some(quote));
        removed = before - entries.len();
        if removed == 0 {
            return Err("no CUA grant is recorded for that quote".into());
        }
        Ok(document)
    })?;
    Ok(removed)
}
