//! Where an identity can come from, and how each place is asked.
//!
//! Three sources count, and the roots of all three are injectable so a test
//! runs against a small fixture instead of the real multi-gigabyte store.
//! Walking the real store per literal is what made an earlier version of this
//! gate take minutes per check.

use std::path::{Path, PathBuf};

use serde_json::Value;

use crate::ports::check_numeric_literals_provenance::quote_in_user_msg;

const PROVENANCE_ENV: &str = "IDENTITY_PROVENANCE_FILE";
const PROVENANCE_DEFAULT: &str = "~/.shared-hooks/identity_provenance.json";
const TRANSCRIPT_ENV: &str = "IDENTITY_TRANSCRIPT_ROOT";
const TRANSCRIPT_DEFAULT: &str = "~/.omp/agent/sessions";
const ARTIFACT_ENV: &str = "IDENTITY_ARTIFACT_ROOTS";
/// A token cache, a cloud profile, a machine registry, the names file: places
/// that know an identity because something outside a conversation issued it.
const ARTIFACT_DEFAULT: &[&str] = &[
    "~/.azure/msal_token_cache.json",
    "~/.azure/azureProfile.json",
    "~/.stado/local-storage/registry.json",
    "~/.stado/forwards",
    "~/NAMES.md",
];
/// Never opened while searching for an artifact: a vault is ciphertext and a
/// log is chat output under another name, so either would make the artifact
/// test meaningless.
const ARTIFACT_SKIP: &[&str] = &[".vault.json", ".jsonl", ".log", ".audit.jsonl"];
const TRANSCRIPT_SUFFIX: &str = ".jsonl";
const USER_ROLE: &str = "user";
const MESSAGE_KEY: &str = "message";
const CONTENT_KEY: &str = "content";
const ROLE_KEY: &str = "role";
const TEXT_KEY: &str = "text";
const USER_SAID_KEY: &str = "user_said";
/// The question is only ever "in more than one session", so counting stops
/// there and a value the user uses constantly costs no full walk.
const SESSIONS_ENOUGH: usize = true as usize + true as usize;

fn expand(path: &str) -> PathBuf {
    match path.strip_prefix("~/") {
        Some(rest) => match std::env::var("HOME") {
            Ok(home) => Path::new(&home).join(rest),
            Err(_) => PathBuf::from(path),
        },
        None => PathBuf::from(path),
    }
}

fn from_env(name: &str, default: &str) -> PathBuf {
    match std::env::var(name) {
        Ok(value) if !value.is_empty() => expand(&value),
        _ => expand(default),
    }
}

fn artifact_roots() -> Vec<PathBuf> {
    match std::env::var(ARTIFACT_ENV) {
        Ok(value) if !value.is_empty() => value
            .split(':')
            .filter(|part| !part.is_empty())
            .map(expand)
            .collect(),
        _ => ARTIFACT_DEFAULT.iter().copied().map(expand).collect(),
    }
}

fn file_contains(path: &Path, needle: &str) -> bool {
    match std::fs::read(path) {
        Ok(bytes) => String::from_utf8_lossy(&bytes)
            .to_lowercase()
            .contains(needle),
        Err(_) => false,
    }
}

fn walk(root: &Path, found: &mut Vec<PathBuf>) {
    let Ok(entries) = std::fs::read_dir(root) else {
        return;
    };
    for entry in entries.flatten() {
        let path = entry.path();
        match path.is_dir() {
            true => walk(&path, found),
            false => found.push(path),
        }
    }
}

fn skipped(path: &Path) -> bool {
    let name = path.to_string_lossy().to_lowercase();
    ARTIFACT_SKIP.iter().any(|suffix| name.ends_with(suffix))
}

/// True when something outside any conversation knows this identity.
pub fn in_an_artifact(value: &str) -> bool {
    let needle = value.to_lowercase();
    for root in artifact_roots() {
        if root.is_file() {
            if file_contains(&root, &needle) {
                return true;
            }
            continue;
        }
        let mut files: Vec<PathBuf> = Vec::new();
        walk(&root, &mut files);
        if files
            .iter()
            .any(|path| !skipped(path) && file_contains(path, &needle))
        {
            return true;
        }
    }
    false
}

fn texts_of(record: &Value) -> Vec<String> {
    let holder = record
        .get(MESSAGE_KEY)
        .filter(|value| value.is_object())
        .unwrap_or(record);
    match holder.get(CONTENT_KEY) {
        Some(Value::String(text)) => vec![text.clone()],
        Some(Value::Array(parts)) => parts
            .iter()
            .filter(|part| part.is_object())
            .map(|part| match part.get(TEXT_KEY) {
                Some(Value::String(text)) => text.clone(),
                _ => String::new(),
            })
            .collect(),
        _ => Vec::new(),
    }
}

/// How many distinct stored sessions carry this value in a user message.
pub fn user_sessions_mentioning(value: &str) -> usize {
    let needle = value.to_lowercase();
    let mut transcripts: Vec<PathBuf> = Vec::new();
    walk(
        &from_env(TRANSCRIPT_ENV, TRANSCRIPT_DEFAULT),
        &mut transcripts,
    );
    let mut hits = 0;
    for path in transcripts
        .iter()
        .filter(|path| path.to_string_lossy().ends_with(TRANSCRIPT_SUFFIX))
    {
        if !file_contains(path, &needle) {
            continue;
        }
        let Ok(text) = std::fs::read_to_string(path) else {
            continue;
        };
        for line in text.lines() {
            let Ok(record) = serde_json::from_str::<Value>(line) else {
                continue;
            };
            let role = record
                .get(MESSAGE_KEY)
                .filter(|value| value.is_object())
                .and_then(|message| message.get(ROLE_KEY))
                .or_else(|| record.get(ROLE_KEY))
                .and_then(Value::as_str)
                .unwrap_or_default();
            if role != USER_ROLE {
                continue;
            }
            if texts_of(&record)
                .iter()
                .any(|text| text.to_lowercase().contains(&needle))
            {
                hits += 1;
                break;
            }
        }
        if hits >= SESSIONS_ENOUGH {
            return hits;
        }
    }
    hits
}

/// The provenance document, and the complaint when it cannot be read.
pub fn load_provenance() -> (Value, Option<String>) {
    let path = from_env(PROVENANCE_ENV, PROVENANCE_DEFAULT);
    let Ok(text) = std::fs::read_to_string(&path) else {
        return (Value::Object(Default::default()), None);
    };
    match serde_json::from_str::<Value>(&text) {
        Ok(Value::Object(map)) => (Value::Object(map), None),
        Ok(_) => (
            Value::Object(Default::default()),
            Some("identity_provenance.json must be an object: value -> {user_said}".to_string()),
        ),
        Err(error) => (
            Value::Object(Default::default()),
            Some(format!(
                "identity_provenance.json is not valid JSON: {error}"
            )),
        ),
    }
}

/// True when the document records a verbatim user quote declaring this value
/// and that quote is found in a real `role=user` message.
pub fn provenanced(value: &str, doc: &Value, sanitize: fn(&str) -> String) -> bool {
    let Some(map) = doc.as_object() else {
        return false;
    };
    for (recorded, entry) in map {
        if sanitize(recorded) != value {
            continue;
        }
        let quote = match entry.get(USER_SAID_KEY) {
            Some(Value::String(text)) => text.clone(),
            _ => return false,
        };
        if !quote.to_lowercase().contains(value) {
            return false;
        }
        return quote_in_user_msg(&quote);
    }
    false
}
