//! Logic for `tama-check-merge-deletion-loss`, registry hook
//! `check-merge-deletion-loss`: a push may not carry a merge that quietly
//! reverted a large deliberate deletion.
//!
//! The incident, 2026-05-17: an Overleaf sync branch held the author's
//! deliberate condensation of a paper to 1291 lines. It was merged into a
//! stale `main` of 1990 lines, and the three-way merge produced 1867 lines —
//! about 576 of the roughly 699 deleted lines came back. It was committed and
//! pushed without anyone comparing the merge result against the branch that
//! did the cutting.
//!
//! The test is arithmetic, per tracked text file and per parent:
//!
//! ```text
//! shrink = lines(merge-base:f) - lines(parent:f)   // what that side cut
//! readd  = lines(merge:f)      - lines(parent:f)   // what the merge kept back
//! ```
//!
//! A shrink of at least eighty lines whose `readd` reaches half of it is a
//! condensation the merge undid, and the push is refused.
//!
//! The acknowledgement is deliberately not available inline:
//! `MERGE_DELETION_LOSS_ACK=1` has to be in the session environment, the same
//! convention `pre-bash` uses, so a per-command prefix cannot wave it through.

mod git;

use std::path::{Path, PathBuf};
use std::sync::LazyLock;

use regex::Regex;
use serde_json::Value;
use tama_hooks::session_record::{deny_tool_use, read_payload};

use crate::ports::transport_common as common;

const INPUT_KEY: &str = "tool_input";
const COMMAND_KEY: &str = "command";
const CWD_KEY: &str = "cwd";
const ACK_ENV: &str = "MERGE_DELETION_LOSS_ACK";
const ACK_VALUE: &str = "1";
const MIN_SHRINK_ENV: &str = "MERGE_DELETION_LOSS_MIN";
/// `MERGE_DELETION_LOSS_MIN` default in the shell.
const MIN_SHRINK_TEXT: &str = "80";
/// `readd >= shrink / 2`: half of a condensation coming back is the failure.
const HALF_TEXT: &str = "2";
const INLINE_REFUSAL: &str =
    "BLOCKED: MERGE_DELETION_LOSS_ACK must be set in settings.json env, not inline.";
const HEAD_REFUSAL: &str =
    "BLOCKED: push contains a merge that reverted a large deliberate deletion.";
const TAIL_REFUSAL: &str = concat!(
    "A three-way merge silently re-added content one branch had intentionally\n",
    "removed (e.g. an Overleaf condensation). Do NOT push this.\n",
    "Fix: re-resolve the merge so the file matches the branch that did the\n",
    "deletion (e.g. 'git checkout <that-branch> -- <file>' then recommit), or\n",
    "if the re-addition is genuinely intended, set MERGE_DELETION_LOSS_ACK=1\n",
    "in ~/.claude/settings.json env and retry.",
);

static IS_PUSH: LazyLock<Regex> =
    LazyLock::new(|| common::compile("(^|[;&|]|\\s)git\\b([^;&|]*\\s)?push\\b"));
static INLINE_ACK: LazyLock<Regex> =
    LazyLock::new(|| common::compile("(^|[;&|]|\\s)MERGE_DELETION_LOSS_ACK="));
/// Prose, not code: the files a person condenses.
static TEXT_FILE: LazyLock<Regex> =
    LazyLock::new(|| common::compile("(?i)\\.(tex|bib|bbl|md|markdown|txt|rst|rmd|org)$"));

fn min_shrink() -> i64 {
    match std::env::var(MIN_SHRINK_ENV) {
        Ok(value) if !value.is_empty() => value.parse().unwrap_or_default(),
        _ => MIN_SHRINK_TEXT.parse().unwrap_or_default(),
    }
}

fn half(value: i64) -> i64 {
    value / HALF_TEXT.parse::<i64>().unwrap_or(i64::MAX)
}

fn working_dir(payload: &Value) -> PathBuf {
    match payload.get(CWD_KEY).and_then(Value::as_str) {
        Some(cwd) if !cwd.is_empty() => PathBuf::from(cwd),
        _ => std::env::current_dir().unwrap_or_default(),
    }
}

fn violation(
    dir: &Path,
    merge: &str,
    parent: &str,
    file: &str,
    base_lines: i64,
    merge_lines: i64,
) -> Option<String> {
    let parent_lines = git::lines_at(dir, parent, file);
    let shrink = base_lines - parent_lines;
    if shrink < min_shrink() {
        return None;
    }
    let readd = merge_lines - parent_lines;
    if readd < half(shrink) {
        return None;
    }
    Some(format!(
        "  merge {}  file {file}\n    merge-base={base_lines}L  parent {}={parent_lines}L  \
         merge result={merge_lines}L\n    that parent deliberately cut {shrink} lines; the merge \
         added {readd} back (>=50%).",
        git::short(dir, merge),
        git::short(dir, parent),
    ))
}

/// Every merge in the unpushed history that undid a condensation.
pub fn violations(dir: &Path) -> Vec<String> {
    if !dir.is_dir() || !git::inside_work_tree(dir) {
        return Vec::new();
    }
    let mut found: Vec<String> = Vec::new();
    for merge in git::unpushed(dir) {
        let Some(second) = git::resolve(dir, &format!("{merge}^2")) else {
            continue;
        };
        let Some(first) = git::resolve(dir, &format!("{merge}^1")) else {
            continue;
        };
        let Some(base) = git::merge_base(dir, &first, &second) else {
            continue;
        };
        let mut files: Vec<String> = git::changed_files(dir, &first, &merge);
        files.extend(git::changed_files(dir, &second, &merge));
        files.sort();
        files.dedup();
        for file in files.iter().filter(|file| TEXT_FILE.is_match(file)) {
            let base_lines = git::lines_at(dir, &base, file);
            let merge_lines = git::lines_at(dir, &merge, file);
            for parent in [&first, &second] {
                if let Some(text) = violation(dir, &merge, parent, file, base_lines, merge_lines) {
                    found.push(text);
                }
            }
        }
    }
    found
}

/// The refusal this push earns, if any.
pub fn check(payload: &Value) -> Option<String> {
    let command = payload
        .get(INPUT_KEY)
        .and_then(|input| input.get(COMMAND_KEY))
        .and_then(Value::as_str)
        .unwrap_or_default();
    if command.is_empty() || !IS_PUSH.is_match(command) {
        return None;
    }
    if INLINE_ACK.is_match(command) {
        return Some(INLINE_REFUSAL.to_string());
    }
    if std::env::var(ACK_ENV).ok().as_deref() == Some(ACK_VALUE) {
        return None;
    }
    let found = violations(&working_dir(payload));
    match found.is_empty() {
        true => None,
        false => Some(format!(
            "{HEAD_REFUSAL}\n{}\n\n{TAIL_REFUSAL}",
            found.join("\n")
        )),
    }
}

pub fn run() {
    if let Some(refusal) = check(&read_payload()) {
        deny_tool_use(&refusal);
    }
}

#[cfg(test)]
mod tests {
    use super::{check, half, min_shrink};
    use serde_json::json;

    fn push(command: &str) -> serde_json::Value {
        json!({ "tool_name": "bash", "cwd": "/nonexistent/repo", "tool_input": { "command": command } })
    }

    /// The gate engages on the outbound step and on nothing else.
    #[test]
    fn only_a_push_is_examined() {
        assert_eq!(check(&push("git status")), None);
        assert_eq!(check(&push("git commit -m x")), None);
        assert_eq!(check(&push("echo push")), None);
    }

    /// The acknowledgement must come from the session environment; a
    /// per-command prefix is refused outright, the way `pre-bash` refuses
    /// `HOOK_EDIT_AUTHORIZED=`.
    #[test]
    fn an_inline_acknowledgement_is_refused() {
        let refusal = check(&push("MERGE_DELETION_LOSS_ACK=1 git push")).expect("inline ack");
        assert!(refusal.contains("not inline"), "{refusal}");
    }

    /// A directory that is not a repository has no merges to judge.
    #[test]
    fn a_push_outside_a_repository_passes() {
        assert_eq!(check(&push("git push origin main")), None);
    }

    #[test]
    fn the_thresholds_are_the_documented_ones() {
        assert_eq!(min_shrink(), 80);
        assert_eq!(half(699), 349);
    }
}
