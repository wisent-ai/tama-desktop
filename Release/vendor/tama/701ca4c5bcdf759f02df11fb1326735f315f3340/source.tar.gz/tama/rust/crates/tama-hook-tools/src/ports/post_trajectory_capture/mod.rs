//! Logic for `tama-post-trajectory-capture`, registry hook
//! `post-trajectory-capture`: after a trajectory run fails, keep the evidence.
//!
//! A failed run is one that exits non-zero, prints a `FAIL:` marker, leaves a
//! fresh `ban_signal` saying the session was unhealthy, or returns nothing at
//! all — "0 handles", "0 results", "no results" repeatedly, which is a scrape
//! that succeeded into an empty room. The last frame of its recording is
//! extracted to `.work/<label>/failure_state_<sha8>.png` and an
//! `inspect_required` entry is registered, so the Stop and PreToolUse gates
//! can insist somebody actually looks at it.
//!
//! The run is recognised three ways, because wrapping a trajectory in
//! `bash run.sh` used to hide it from this hook: the trajectory path in the
//! command, an interpreter invocation whose script contains `WSession.start`,
//! and, failing both, any recording touched in the last minute.

mod capture;

use std::path::{Path, PathBuf};
use std::sync::LazyLock;

use regex::Regex;
use serde_json::{json, Value};
use tama_hooks::session_record::read_payload;

use crate::ports::python_stdlib::expanduser;
use crate::ports::pyvalue::first_truthy_py_str;
use crate::ports::transport_common as common;

const INPUT_KEY: &str = "tool_input";
const RESPONSE_KEY: &str = "tool_response";
const COMMAND_KEY: &str = "command";
const EXIT_KEYS: &[&str] = &["exitCode", "exit_code"];
const OUTPUT_KEYS: &[&str] = &["stdout", "output", "content"];
const STDERR_KEY: &str = "stderr";
const ACTIVE_ENV: &str = "DETECT_POST_TRAJECTORY_ACTIVE";
const STATE_PATH: &str = "~/.shared-hooks/state/inspect_required.json";
const WORK_DIR: &str = ".work";
const FRAME_PREFIX: &str = "failure_state_";
const FRAME_SUFFIX: &str = ".png";
const SESSION_MARKER: &str = "WSession.start";
const SESSION_MARKER_LOWER: &str = "wsession.start";
/// Three "got nothing" markers in one run is an empty-result failure.
const EMPTY_HITS_TEXT: &str = "3";
const SUCCESS_EXIT: &str = "0";

static FAIL_MARKER: LazyLock<Regex> =
    LazyLock::new(|| common::compile("(^|\\\\n|[[:space:]])FAIL:[[:space:]]"));

static EMPTY_MARKER: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(
        "0 handles \\(running total 0\\)|\\b0 entries\\b|\\b0 results\\b|\\bno results\\b|running total 0\\)",
    )
});

static TRAJECTORY_PATH: LazyLock<Regex> =
    LazyLock::new(|| common::compile("scripts/trajectories/[A-Za-z0-9_./-]+\\.[mc]?[tj]sx?"));

static INTERPRETED_SCRIPT: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(node|tsx|bun|deno|ts-node|npx)([[:space:]]+(run|--[A-Za-z0-9_-]+(=[^[:space:]]+)?))*",
        "[[:space:]]+(?P<script>[A-Za-z0-9_./~$-]+\\.[mc]?[tj]sx?)",
    ))
});

static SCRIPT_SUFFIX: LazyLock<Regex> = LazyLock::new(|| common::compile("\\.[mc]?[tj]sx?$"));

fn empty_threshold() -> usize {
    EMPTY_HITS_TEXT.parse().unwrap_or_default()
}

/// `date -u +%Y-%m-%dT%H:%M:%SZ`: the shell's stamp has no milliseconds, and
/// the state file is read by eye as often as by tool.
fn set_at() -> String {
    let stamp = crate::util::iso_now();
    match stamp.split_once('.') {
        Some((whole, _)) => format!("{whole}Z"),
        None => stamp,
    }
}

/// Why this run counts as failed, in the shell's own wording.
#[derive(Default)]
pub struct Failure {
    pub by_exit: bool,
    pub by_stdout: bool,
    pub by_ban: bool,
    pub by_empty: bool,
}

impl Failure {
    pub fn any(&self) -> bool {
        self.by_exit || self.by_stdout || self.by_ban || self.by_empty
    }

    pub fn reason(&self) -> String {
        format!(
            "exit:{},stdout:{},ban:{},empty:{}",
            self.by_exit as u8, self.by_stdout as u8, self.by_ban as u8, self.by_empty as u8
        )
    }
}

fn response_text(response: &Value) -> String {
    let out = first_truthy_py_str(response, OUTPUT_KEYS);
    let err = first_truthy_py_str(response, &[STDERR_KEY]);
    format!("{out}{err}")
}

fn exited_non_zero(response: &Value) -> bool {
    let text = match EXIT_KEYS.iter().filter_map(|key| response.get(*key)).next() {
        Some(Value::Number(value)) => value.to_string(),
        Some(Value::String(value)) => value.clone(),
        _ => SUCCESS_EXIT.to_string(),
    };
    text != SUCCESS_EXIT
}

/// Everything about the failure except the recording: readable without
/// touching the machine's recordings.
pub fn failure_of(payload: &Value, repo: &Path) -> Failure {
    let empty = Value::Object(Default::default());
    let response = payload.get(RESPONSE_KEY).unwrap_or(&empty);
    let text = response_text(response);
    Failure {
        by_exit: exited_non_zero(response),
        by_stdout: FAIL_MARKER.is_match(&text),
        by_ban: capture::banned(repo),
        by_empty: EMPTY_MARKER.find_iter(&text).count() >= empty_threshold(),
    }
}

/// The trajectory this command ran, as a label, if it named one.
pub fn label_of(command: &str) -> Option<String> {
    let path = match TRAJECTORY_PATH.find(command) {
        Some(found) => found.as_str().to_string(),
        None => {
            let script = INTERPRETED_SCRIPT
                .captures(command)?
                .name("script")?
                .as_str()
                .to_string();
            let runs_a_session = std::fs::read_to_string(&script)
                .map(|body| body.contains(SESSION_MARKER) || body.contains(SESSION_MARKER_LOWER))
                .unwrap_or_default();
            match runs_a_session {
                true => script,
                false => return None,
            }
        }
    };
    let name = Path::new(&path).file_name()?.to_string_lossy().to_string();
    Some(SCRIPT_SUFFIX.replace(&name, "").to_string())
}

fn register(label: &str, sha: &str, recording: &Path, frame: &Path, reason: &str) {
    let path = PathBuf::from(expanduser(STATE_PATH));
    let Some(parent) = path.parent() else {
        return;
    };
    let _ = std::fs::create_dir_all(parent);
    let mut doc = std::fs::read_to_string(&path)
        .ok()
        .and_then(|text| serde_json::from_str::<Value>(&text).ok())
        .unwrap_or_else(|| json!({}));
    let Some(map) = doc.as_object_mut() else {
        return;
    };
    map.insert(
        label.to_string(),
        json!({
            "sha8": sha,
            "recording": recording.to_string_lossy(),
            "failure_state": frame.to_string_lossy(),
            "reason": reason,
            "set_at": set_at(),
        }),
    );
    let _ = std::fs::write(&path, doc.to_string());
}

pub fn run() {
    if std::env::var(ACTIVE_ENV).is_ok() {
        return;
    }
    let payload = read_payload();
    let command = payload
        .get(INPUT_KEY)
        .and_then(|input| input.get(COMMAND_KEY))
        .and_then(Value::as_str)
        .unwrap_or_default()
        .to_string();
    if command.is_empty() {
        return;
    }
    let repo = std::env::current_dir().unwrap_or_default();
    let mut label = label_of(&command);
    let fresh = capture::fresh_recordings(&repo);
    if label.is_none() && fresh.is_empty() {
        return;
    }
    let failure = failure_of(&payload, &repo);
    if !failure.any() {
        return;
    }
    let recording = label
        .as_deref()
        .and_then(|name| capture::recording_for(&repo, name))
        .or_else(|| fresh.first().cloned());
    let Some(recording) = recording.filter(|path| path.is_file()) else {
        return;
    };
    if label.is_none() {
        label = recording
            .parent()
            .and_then(Path::file_name)
            .map(|name| name.to_string_lossy().to_string());
    }
    let Some(label) = label else {
        return;
    };
    let sha = capture::short_sha(&recording);
    let work = repo.join(WORK_DIR).join(&label);
    let _ = std::fs::create_dir_all(&work);
    let frame = work.join(format!("{FRAME_PREFIX}{sha}{FRAME_SUFFIX}"));
    capture::extract_last_frame(&recording, &frame);
    register(&label, &sha, &recording, &frame, &failure.reason());
}

#[cfg(test)]
mod tests {
    use super::{failure_of, label_of, Failure};
    use serde_json::{json, Value};

    fn repo() -> std::path::PathBuf {
        std::path::PathBuf::from("/nonexistent/repo")
    }

    /// `jq -r` handed the shell text, so text is what the port reads.
    fn exited(code: &str) -> Value {
        json!({ "tool_response": { "exitCode": code } })
    }

    fn printed(text: &str) -> Value {
        json!({ "tool_response": { "stdout": text } })
    }

    #[test]
    fn a_non_zero_exit_is_a_failure() {
        assert!(failure_of(&exited("1"), &repo()).by_exit);
        assert!(!failure_of(&exited("0"), &repo()).by_exit);
    }

    #[test]
    fn a_fail_marker_in_the_output_is_a_failure() {
        assert!(failure_of(&printed("step 3\nFAIL: challenge page\n"), &repo()).by_stdout);
    }

    /// A word that merely contains the marker is not the marker.
    #[test]
    fn the_word_failure_alone_is_not_the_marker() {
        assert!(!failure_of(&printed("FAILURE_MODE=none"), &repo()).by_stdout);
    }

    /// One "0 results" is a quiet day; three is a run that found nothing.
    #[test]
    fn three_empty_markers_are_a_failure_and_two_are_not() {
        assert!(!failure_of(&printed("0 results\n0 entries\n"), &repo()).by_empty);
        assert!(failure_of(&printed("0 results\n0 entries\nno results\n"), &repo()).by_empty);
    }

    #[test]
    fn the_trajectory_label_comes_from_the_command() {
        assert_eq!(
            label_of("node scripts/trajectories/linkedin_scrape.mjs --headful"),
            Some("linkedin_scrape".to_string())
        );
        assert_eq!(label_of("echo hello"), None);
    }

    /// The registered reason names every signal, so a later reader can see
    /// which one fired.
    #[test]
    fn the_reason_names_every_signal() {
        let failure = Failure {
            by_exit: true,
            by_stdout: true,
            ..Default::default()
        };
        let expected = format!(
            "exit:{},stdout:{},ban:{},empty:{}",
            true as u8, true as u8, false as u8, false as u8
        );
        assert_eq!(failure.reason(), expected);
        assert!(failure.any());
        assert!(!Failure::default().any());
    }
}
