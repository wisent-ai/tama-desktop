//! Rust port of `shared-hooks/block_unauthorized_ssh.py` (hook id
//! `block-unauthorized-ssh`): block every SSH transport without a
//! transcript-backed, exact registry grant.
//!
//! `quote_authorizes_targets`, `command_targets`, `entry_matches` and
//! `quote_is_in_current_session` are the acceptance predicate: a grant counts
//! only when the user's own words name SSH and the target, the words are
//! really in this session's transcript, and a `ssh_justification.json` entry
//! covers the exact target, operation and path or command. They are public
//! so a later guard can reuse this one implementation instead of restating
//! the policy.
//!
//! The two halves this module orchestrates are
//! [`crate::ports::block_unauthorized_ssh_detect`] (patterns and command
//! shape) and [`crate::ports::block_unauthorized_ssh_targets`] (target
//! extraction); both are re-exported here, so this module is the whole
//! port's surface.

mod grants;

pub use grants::{authorized, entry_matches};
use std::collections::BTreeSet;

use serde_json::Value;

use crate::ports::block_unauthorized_ssh_detect as detect;
use crate::ports::block_unauthorized_ssh_targets as targets;
use crate::ports::pystr;
use crate::ports::python_stdlib;
use crate::ports::pyvalue;
use crate::ports::transport_common as common;

pub use crate::ports::block_unauthorized_ssh_detect::{
    command_operation, command_text, contains_ssh_command,
};
pub use crate::ports::block_unauthorized_ssh_targets::{canonical_target, targets_from_urls};
pub use crate::ports::transport_common::quote_is_in_current_session;

/// `tool_name` reads these keys in this order here; the CUA hook uses a
/// different order.
const TOOL_KEYS: &[&str] = &["tool_name", "name", "tool"];
const PATH_KEYS: &[&str] = &["path", "paths", "file", "files"];
const ACTION_KEYS: &[&str] = &["action", "op"];
/// `SSH_OPTIONS_WITH_VALUE`: the scan steps over the option and its argument.
const SSH_OPTIONS_WITH_VALUE: &[&str] = &[
    "-b", "-c", "-D", "-E", "-e", "-F", "-I", "-i", "-J", "-L", "-l", "-m", "-O", "-o", "-p", "-Q",
    "-R", "-S", "-W", "-w",
];
const SSH_BINARIES: &[&str] = &["ssh", "sftp"];
const OPERATIONS: &[&str] = &["read", "write", "exec", "transfer", "tunnel", "git"];
const PATH_OPERATIONS: &[&str] = &["read", "write"];
const READ_OP: &str = "read";
const WRITE_OP: &str = "write";
const SSH_TOOL: &str = "ssh";
const SESSION_LIFETIME: &str = "current OMP session";
const SCHEMA: &str = "ai.wisent.tama.ssh-justification.v1";
const JUSTIFICATION_ENV: &str = "TAMA_SSH_JUSTIFICATION";
const HOOK_HOME: &str = ".shared-hooks";
const JUSTIFICATION_FILE: &str = "ssh_justification.json";
const BANNER: &str = "BLOCKED: unauthorized SSH: ";

/// `ssh -o Foo host`: an option that takes a value consumes the option token
/// and its argument, so the target scan steps over both.
const OPTION_WITH_VALUE_SPAN_TEXT: &str = "2";

fn option_with_value_span() -> usize {
    OPTION_WITH_VALUE_SPAN_TEXT.parse().unwrap_or_default()
}

/// One SSH-carrying tool call, reduced to what a grant has to cover.
#[derive(Debug, Clone)]
pub struct SshRequest {
    pub operation: String,
    pub targets: Vec<String>,
    pub paths: Vec<String>,
    pub command: Option<String>,
}

fn justification_path() -> std::path::PathBuf {
    common::env_path(
        JUSTIFICATION_ENV,
        common::home().join(HOOK_HOME).join(JUSTIFICATION_FILE),
    )
}

/// `command_targets`: every host this command line would reach — from URLs,
/// from `user@host:path` specs, and from the first non-option argument after
/// an `ssh` or `sftp` binary.
pub fn command_targets(command: &str) -> BTreeSet<String> {
    let mut found = targets::targets_from_urls(&targets::ssh_urls(command));
    for captured in targets::REMOTE_SPEC_RE.captures_iter(command) {
        let spec = match captured.get(targets::spec_group()) {
            Some(spec) => spec,
            None => continue,
        };
        if let Some(target) = targets::canonical_target(spec.as_str()) {
            found.insert(target);
        }
    }
    let tokens = python_stdlib::shell_tokens(command);
    for (index, token) in tokens.iter().enumerate() {
        let binary = token.rsplit('/').next().unwrap_or_default().to_lowercase();
        if !SSH_BINARIES.contains(&binary.as_str()) {
            continue;
        }
        let mut cursor = index.saturating_add(python_stdlib::one());
        while cursor < tokens.len() {
            let candidate = tokens[cursor].as_str();
            if SSH_OPTIONS_WITH_VALUE.contains(&candidate) {
                cursor = cursor.saturating_add(option_with_value_span());
                continue;
            }
            if candidate.starts_with('-') {
                cursor = cursor.saturating_add(python_stdlib::one());
                continue;
            }
            if let Some(target) = targets::canonical_target(candidate) {
                found.insert(target);
            }
            break;
        }
    }
    found
}

/// `ssh_request`: the SSH request a payload carries, or `None` when the call
/// is not an SSH transport at all.
pub fn ssh_request(payload: &Value) -> Option<SshRequest> {
    let name = common::tool_name(payload, TOOL_KEYS).to_lowercase();
    let input = common::tool_input(payload);
    let mut urls: Vec<String> = Vec::new();
    for key in PATH_KEYS {
        let value = input.get(key).cloned().unwrap_or(Value::Null);
        for text in common::strings(&value) {
            urls.extend(targets::ssh_urls(&text));
        }
    }
    if !urls.is_empty() {
        let operation = match detect::WRITE_TOOLS.contains(&name.as_str()) {
            true => WRITE_OP,
            false => READ_OP,
        };
        let paths: BTreeSet<String> = urls.iter().cloned().collect();
        return Some(SshRequest {
            operation: operation.to_string(),
            targets: targets::targets_from_urls(&urls).into_iter().collect(),
            paths: paths.into_iter().collect(),
            command: None,
        });
    }
    let command = command_text(&name, &input);
    let direct_tool = detect::SSH_TOOL_RE.is_match(&name);
    let executable = detect::EXECUTABLE_TOOLS.contains(&name.as_str());
    if !direct_tool && !(executable && contains_ssh_command(&command)) {
        return None;
    }
    let mut operation =
        pystr::strip(&pyvalue::first_truthy_py_str(&input, ACTION_KEYS)).to_lowercase();
    if !OPERATIONS.contains(&operation.as_str()) {
        operation = match command.is_empty() {
            true => detect::EXEC_OP.to_string(),
            false => command_operation(&command),
        };
    }
    Some(SshRequest {
        operation,
        targets: command_targets(&command).into_iter().collect(),
        paths: Vec::new(),
        command: match command.is_empty() {
            true => None,
            false => Some(command),
        },
    })
}

/// `quote_authorizes_targets`: the user's own words name SSH, carry a direct
/// grant, and name every target the call would reach.
pub fn quote_authorizes_targets(quote: &str, requested: &[String]) -> bool {
    if !detect::SSH_QUOTE_RE.is_match(quote)
        || !(common::DIRECT_CONSENT_RE.is_match(quote)
            || detect::DIRECT_IMPERATIVE_RE.is_match(quote))
    {
        return false;
    }
    let lowered = quote.to_lowercase();
    for target in requested {
        let after_user = target
            .rsplit_once('@')
            .map(|(_, host)| host)
            .unwrap_or(target);
        let host = after_user
            .split_once(':')
            .map(|(head, _)| head)
            .unwrap_or(after_user);
        if !lowered.contains(&target.to_lowercase()) && !lowered.contains(host) {
            return false;
        }
    }
    !requested.is_empty()
}

/// `evaluate_payload`: the deny banner when the call is refused, `None` when
/// it passes. The caller writes the banner to stderr and exits 2.
pub fn evaluate(payload: &Value) -> Option<String> {
    let request = ssh_request(payload)?;
    if request.targets.is_empty() {
        return Some(format!(
            "{BANNER}the operation uses SSH but its exact target could not be determined"
        ));
    }
    if !authorized(payload, &request) {
        return Some(format!(
            "{BANNER}an exact current-session user authorization and matching \
             ssh_justification.json entry are both required"
        ));
    }
    None
}
