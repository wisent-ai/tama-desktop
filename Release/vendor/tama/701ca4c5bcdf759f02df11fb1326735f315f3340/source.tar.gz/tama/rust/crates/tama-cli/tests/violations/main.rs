//! Real CLI and real hook scripts; source files remain byte-identical.
mod declare_root;
mod fixture;
mod hook_resolution;

use fixture::{Fixture, LIMIT};
use serde_json::Value;
use std::fs;

#[test]
fn scan_counts_file_limit_and_crowded_folder_once_without_mutation() {
    let f = Fixture::new();
    let long = "// source row\n".repeat(LIMIT + 1);
    fs::write(f.repo.join("long.js"), &long).unwrap();
    fs::write(f.repo.join("edge.js"), "// source row\n".repeat(LIMIT)).unwrap();
    fs::create_dir(f.repo.join("dense")).unwrap();
    for name in ["a", "b", "c", "d", "e", "f"] {
        fs::write(
            f.repo.join("dense").join(format!("{name}.js")),
            "// source\n",
        )
        .unwrap();
    }
    let out = f.run("scan", "find-violations", &["--json"]);
    assert_eq!(
        out.status.code(),
        Some(1),
        "{}",
        String::from_utf8_lossy(&out.stderr)
    );
    let report: Value = serde_json::from_slice(&out.stdout).unwrap();
    let hits = report["repos"][0]["violations"].as_array().unwrap();
    assert_eq!(
        hits.iter().filter(|hit| hit["path"] == "long.js").count(),
        1,
        "{report}"
    );
    assert_eq!(
        hits.iter().filter(|hit| hit["path"] == "dense").count(),
        1,
        "{report}"
    );
    assert!(!hits.iter().any(|hit| hit["path"] == "edge.js"), "{report}");
    assert_eq!(fs::read_to_string(f.repo.join("long.js")).unwrap(), long);
    assert_eq!(report["repos"][0]["errors"], serde_json::json!([]));
}

#[test]
fn ignore_paths_and_clean_preview_use_the_same_size_rule() {
    let f = Fixture::new();
    let long = "// source row\n".repeat(LIMIT + 1);
    fs::create_dir(f.repo.join("ignored")).unwrap();
    fs::write(f.repo.join("ignored/old.js"), &long).unwrap();
    fs::write(f.repo.join(".tama-violations-ignore"), "ignored/\n").unwrap();
    fs::write(f.repo.join("long.js"), &long).unwrap();
    let out = f.run("scan", "find-violations", &["--json"]);
    let report: Value = serde_json::from_slice(&out.stdout).unwrap();
    let hits = report["repos"][0]["violations"].as_array().unwrap();
    assert_eq!(
        hits.iter().filter(|hit| hit["path"] == "long.js").count(),
        1
    );
    assert!(!hits.iter().any(|hit| hit["path"] == "ignored/old.js"));
    let preview = f.run("clean-preview", "clean", &["--dry-run"]);
    assert!(
        String::from_utf8_lossy(&preview.stdout).contains("long.js"),
        "{}",
        String::from_utf8_lossy(&preview.stderr)
    );
    assert_eq!(fs::read_to_string(f.repo.join("long.js")).unwrap(), long);
    fs::write(f.repo.join("long.js"), "// source\n").unwrap();
    let fixed = f.run("rescanned", "find-violations", &["--json"]);
    assert_eq!(
        fixed.status.code(),
        Some(0),
        "{}",
        String::from_utf8_lossy(&fixed.stderr)
    );
}

/// `--size-only` exists because the replay spawns two shells per file and a
/// whole-machine scan never finishes. It is only usable if it answers the two
/// size rules exactly as the hooks do, so this drives both modes over one
/// repository and compares what they report, sentence for sentence.
#[test]
fn size_only_matches_hook_replay() {
    let f = Fixture::new();
    fs::write(f.repo.join("long.js"), "// source row\n".repeat(LIMIT + 1)).unwrap();
    fs::write(f.repo.join("edge.js"), "// source row\n".repeat(LIMIT)).unwrap();
    // A registry is data its reader loads whole: the hook leaves it out of the
    // line count, so the fast pass must leave it out too, or a whole-machine
    // scan would order splits the real guard never asks for. The entries carry
    // text, because the content rules the replay also runs are not the subject
    // here and a bare number in a registry trips one of them.
    fs::write(
        f.repo.join("registry.json"),
        "{\n".to_string() + &"  \"entry\": \"recorded\",\n".repeat(LIMIT) + "}\n",
    )
    .unwrap();
    fs::create_dir(f.repo.join("ignored")).unwrap();
    fs::write(
        f.repo.join("ignored/old.js"),
        "// source row\n".repeat(LIMIT + 1),
    )
    .unwrap();
    fs::write(f.repo.join(".tama-violations-ignore"), "ignored/\n").unwrap();
    fs::create_dir(f.repo.join("dense")).unwrap();
    for name in ["a", "b", "c", "d", "e", "f"] {
        fs::write(
            f.repo.join("dense").join(format!("{name}.js")),
            "// source\n",
        )
        .unwrap();
    }

    let replayed: Value =
        serde_json::from_slice(&f.run("scan", "find-violations", &["--json"]).stdout).unwrap();
    let fast = f.run(
        "scan-size-only",
        "find-violations",
        &["--json", "--size-only"],
    );
    assert_eq!(
        fast.status.code(),
        Some(1),
        "{}",
        String::from_utf8_lossy(&fast.stderr)
    );
    let measured: Value = serde_json::from_slice(&fast.stdout).unwrap();

    let sentences = |report: &Value| -> Vec<String> {
        report["repos"][0]["violations"]
            .as_array()
            .unwrap()
            .iter()
            .map(|hit| format!("{} :: {}", hit["path"], hit["message"]))
            .collect()
    };
    assert_eq!(sentences(&measured), sentences(&replayed), "{measured}");
    assert_eq!(
        measured["repos"][0]["scannedFiles"],
        replayed["repos"][0]["scannedFiles"]
    );
    assert!(
        !sentences(&measured)
            .iter()
            .chain(sentences(&replayed).iter())
            .any(|sentence| sentence.contains("registry.json")),
        "a registry over the limit is exempt from the line count in both passes: {measured}"
    );
    assert_eq!(measured["repos"][0]["errors"], serde_json::json!([]));
}

/// A repository declares its generated files to this audit in a file at its
/// own root — and the write guard refuses a sixth file in any folder, which a
/// repository root almost always already has. `.tama/violations-ignore` is the
/// form that can actually be created; both must be honoured.
#[test]
fn folded_ignore_file_excludes_the_same_paths_as_the_root_form() {
    let f = Fixture::new();
    let long = "// source row\n".repeat(LIMIT + 1);
    fs::create_dir(f.repo.join("generated")).unwrap();
    fs::write(f.repo.join("generated/art.svg"), &long).unwrap();
    for name in ["a", "b", "c", "d", "e", "f"] {
        fs::write(
            f.repo.join("generated").join(format!("{name}.svg")),
            "<svg/>\n",
        )
        .unwrap();
    }
    fs::write(f.repo.join("kept.js"), &long).unwrap();
    fs::create_dir(f.repo.join("dense")).unwrap();
    for name in ["a", "b", "c", "d", "e", "f"] {
        fs::write(
            f.repo.join("dense").join(format!("{name}.js")),
            "// source\n",
        )
        .unwrap();
    }
    fs::create_dir(f.repo.join(".tama")).unwrap();
    fs::write(
        f.repo.join(".tama/violations-ignore"),
        "# rendered by the product\ngenerated/\n",
    )
    .unwrap();

    let out = f.run("scan", "find-violations", &["--json", "--size-only"]);
    let report: Value = serde_json::from_slice(&out.stdout).unwrap();
    let hits = report["repos"][0]["violations"].as_array().unwrap();
    let paths: Vec<&str> = hits
        .iter()
        .map(|hit| hit["path"].as_str().unwrap_or_default())
        .collect();
    assert!(paths.contains(&"kept.js"), "{report}");
    assert!(paths.contains(&"dense"), "{report}");
    assert!(!paths.contains(&"generated/art.svg"), "{report}");
    assert!(!paths.contains(&"generated"), "{report}");
    assert!(
        report["repos"][0]["skippedFiles"]
            .as_array()
            .unwrap()
            .iter()
            .any(|skip| skip["path"] == "generated/art.svg"),
        "{report}"
    );
}

/// A journey's evidence folder holds the recording and one screenshot per
/// state, and the audit used to report every one of them as a crowded
/// folder: 267 of them in `spis` alone, next to skip lines saying the same
/// files could not even be read. A capture is not a module, so it is not
/// counted — while the modules beside it still are.
#[test]
fn captured_evidence_is_not_a_crowded_folder() {
    let f = Fixture::new();
    fs::create_dir(f.repo.join("journey")).unwrap();
    fs::write(f.repo.join("journey/official-recording.mp4"), "frames\n").unwrap();
    for state in 1..9 {
        fs::write(
            f.repo.join("journey").join(format!("state-0{state}.png")),
            "pixels\n",
        )
        .unwrap();
    }
    fs::create_dir(f.repo.join("mixed")).unwrap();
    for name in ["a", "b", "c", "d"] {
        fs::write(
            f.repo.join("mixed").join(format!("{name}.js")),
            "// source\n",
        )
        .unwrap();
    }
    for shot in 1..9 {
        fs::write(
            f.repo.join("mixed").join(format!("shot-{shot}.PNG")),
            "pixels\n",
        )
        .unwrap();
    }
    fs::create_dir(f.repo.join("dense")).unwrap();
    for name in ["a", "b", "c", "d", "e", "f"] {
        fs::write(
            f.repo.join("dense").join(format!("{name}.js")),
            "// source\n",
        )
        .unwrap();
    }

    for mode in [vec!["--json"], vec!["--json", "--size-only"]] {
        let out = f.run("scan", "find-violations", &mode);
        let report: Value = serde_json::from_slice(&out.stdout).unwrap();
        let paths: Vec<&str> = report["repos"][0]["violations"]
            .as_array()
            .unwrap()
            .iter()
            .map(|hit| hit["path"].as_str().unwrap_or_default())
            .collect();
        assert!(paths.contains(&"dense"), "{mode:?} {report}");
        assert!(!paths.contains(&"journey"), "{mode:?} {report}");
        assert!(!paths.contains(&"mixed"), "{mode:?} {report}");
    }
}

/// A folder named for a build system is build output at a package root and
/// product code inside a source tree. Stado writes its coverage orchestrator
/// at `src/coverage` and the command that prints it at
/// `src/cli/space/coverage`; this audit read both as build output and
/// exempted thirty-one hand-written modules from both size rules while
/// printing "vendored or build-output dir" beside each of them.
#[test]
fn a_build_name_inside_a_source_tree_is_still_audited() {
    let f = Fixture::new();
    let long = "// source row\n".repeat(LIMIT + 1);
    fs::create_dir_all(f.repo.join("src/coverage")).unwrap();
    fs::write(f.repo.join("src/coverage/orchestrator.rs"), &long).unwrap();
    fs::create_dir_all(f.repo.join("crates/engine/src/build")).unwrap();
    fs::write(f.repo.join("crates/engine/src/build/plan.rs"), &long).unwrap();
    fs::create_dir_all(f.repo.join("target/debug")).unwrap();
    fs::write(f.repo.join("target/debug/generated.rs"), &long).unwrap();
    fs::create_dir_all(f.repo.join("web/dist")).unwrap();
    fs::write(f.repo.join("web/dist/bundle.js"), &long).unwrap();

    for mode in [vec!["--json"], vec!["--json", "--size-only"]] {
        let out = f.run("scan", "find-violations", &mode);
        let report: Value = serde_json::from_slice(&out.stdout).unwrap();
        let paths: Vec<&str> = report["repos"][0]["violations"]
            .as_array()
            .unwrap()
            .iter()
            .map(|hit| hit["path"].as_str().unwrap_or_default())
            .collect();
        assert!(
            paths.contains(&"src/coverage/orchestrator.rs"),
            "{mode:?} {report}"
        );
        assert!(
            paths.contains(&"crates/engine/src/build/plan.rs"),
            "{mode:?} {report}"
        );
        assert!(
            !paths.contains(&"target/debug/generated.rs"),
            "{mode:?} {report}"
        );
        assert!(!paths.contains(&"web/dist/bundle.js"), "{mode:?} {report}");
    }
}

/// A declared directory covers its tree whether or not whoever wrote the
/// line ended it with a slash.
///
/// `echo-web` declared `applications/feng-sciezka-smart/source` for the
/// grant call's own published PDFs and result lists. The line reads exactly
/// right and sits in the file the documentation names, and it excluded
/// nothing: the audit went on ordering three documents the funding body
/// published to be split into modules.
#[test]
fn a_declared_directory_covers_its_tree_without_a_trailing_slash() {
    let f = Fixture::new();
    let long = "// source row\n".repeat(LIMIT + 1);
    fs::create_dir_all(f.repo.join("sources/call")).unwrap();
    fs::write(f.repo.join("sources/call/results.txt"), &long).unwrap();
    fs::write(f.repo.join("kept.js"), &long).unwrap();
    fs::create_dir(f.repo.join(".tama")).unwrap();
    fs::write(
        f.repo.join(".tama/violations-ignore"),
        "# what the funding body published\nsources\n",
    )
    .unwrap();

    for mode in [vec!["--json"], vec!["--json", "--size-only"]] {
        let out = f.run("scan", "find-violations", &mode);
        let report: Value = serde_json::from_slice(&out.stdout).unwrap();
        let paths: Vec<&str> = report["repos"][0]["violations"]
            .as_array()
            .unwrap()
            .iter()
            .map(|hit| hit["path"].as_str().unwrap_or_default())
            .collect();
        assert!(paths.contains(&"kept.js"), "{mode:?} {report}");
        assert!(
            !paths.contains(&"sources/call/results.txt"),
            "{mode:?} {report}"
        );
    }
}
