//! Logic for `tama-check-unsubstantiated-constants`: a number that configures,
//! estimates or tunes something has to be traceable to a decision.
//!
//! Two questions, one per entry point. A local write is read line by line for
//! the shapes a tuning constant takes, and a shell command is read for a
//! remote write that would inject one on a host without passing any local
//! gate. Either is allowed when the number belongs where it is — a constants
//! module, a settings file, a project manifest — or when the file carries a
//! fifteen-word reason in `~/.shared-hooks/file_justifications.json` that
//! actually talks about constants, config, tuning or parameters.
//!
//! The gate is strict on purpose: the numbers it catches are the ones nobody
//! can explain six months later, and the explanation is cheapest to write on
//! the day the number is chosen.

mod patterns;
#[cfg(test)]
mod tests;

use std::io::Read;

use serde_json::Value;

use crate::ports::python_stdlib::expanduser;

const REGISTRY_PATH: &str = "~/.shared-hooks/file_justifications.json";
const JUSTIFICATION_KEY: &str = "justification";
/// `MIN_JUSTIFICATION_WORDS`.
const MIN_WORDS_TEXT: &str = "15";
/// A reason that never names what kind of number it is explaining is not a
/// reason for this gate.
const REQUIRED_WORDS: &[&str] = &["constant", "config", "tuning", "parameter"];
/// `stripped[:80]` in the report.
const SHOWN_CHARS_TEXT: &str = "80";
const BASH_FLAG: &str = "--bash";
const NUL: char = '\0';
const FILE_HEAD: &str = "BLOCKED: unsubstantiated hardcoded constants in ";
const BASH_HEAD: &str = "BLOCKED: unsubstantiated constant injection detected:";
const BASH_TAIL: &str = concat!(
    "Add a justification marker '# justify: <reason>' to the command, or move the constant to a ",
    "tracked config/constants file.",
);
const REMOTE_WRITE_COMPLAINT: &str =
    "remote write to installed package/systemd config without '# justify: ...' marker";
const REMOTE_ENV_COMPLAINT: &str =
    "remote injection of numeric env constant without '# justify: ...' marker";
/// A refusal is exit 2, as every other write gate on this machine.
const REFUSAL_STATUS_TEXT: &str = "2";

fn min_words() -> usize {
    MIN_WORDS_TEXT.parse().unwrap_or_default()
}

fn shown_chars() -> usize {
    SHOWN_CHARS_TEXT.parse().unwrap_or_default()
}

fn refusal_status() -> i32 {
    REFUSAL_STATUS_TEXT.parse().unwrap_or_default()
}

pub(crate) fn registry_path() -> String {
    expanduser(REGISTRY_PATH)
}

/// Whether this path is a place numeric constants belong.
fn allowed_path(path: &str) -> bool {
    patterns::ALLOWED_PATH
        .iter()
        .any(|pattern| pattern.is_match(path))
}

/// Whether the registry carries a reason for this file that names the kind of
/// number it is explaining.
///
/// A payload may name the file the way a person types it — `~/…` — while the
/// registry is keyed by absolute paths, which is what `tama justify record`
/// refuses to write any other way. Looking the written path up as it is, and
/// again with `~` expanded, is the difference between a recorded reason that
/// counts and one the writer is told to record again.
fn justified(registry: &str, path: &str) -> bool {
    let Ok(text) = std::fs::read_to_string(registry) else {
        return false;
    };
    let Ok(doc) = serde_json::from_str::<Value>(&text) else {
        return false;
    };
    let expanded = expanduser(path);
    let reason = doc
        .get(path)
        .or_else(|| doc.get(&expanded))
        .and_then(|entry| entry.get(JUSTIFICATION_KEY))
        .and_then(Value::as_str)
        .unwrap_or_default();
    if reason.split_whitespace().count() < min_words() {
        return false;
    }
    let lowered = reason.to_lowercase();
    REQUIRED_WORDS.iter().any(|word| lowered.contains(word))
}

fn shown(line: &str) -> String {
    line.chars().take(shown_chars()).collect()
}

/// What shape of constant this line introduces, if any.
fn shape_of(line: &str) -> Option<&'static str> {
    for (pattern, description) in patterns::CONSTANT_SHAPES.iter() {
        if pattern.is_match(line) {
            return Some(description);
        }
    }
    match patterns::BARE_NUMERIC_RETURN.is_match(line) && !patterns::returns_a_status(line) {
        true => Some(patterns::BARE_RETURN_DESCRIPTION),
        false => None,
    }
}

/// Every unsubstantiated constant this content introduces, one per line at
/// most. `registry` is injectable so a test runs against a fixture.
pub fn file_violations_with(registry: &str, path: &str, content: &str) -> Vec<String> {
    if allowed_path(path) || justified(registry, path) {
        return Vec::new();
    }
    let mut found: Vec<String> = Vec::new();
    for (index, line) in content.lines().enumerate() {
        let stripped = line.trim();
        if patterns::NOT_A_CONSTANT
            .iter()
            .any(|pattern| pattern.is_match(stripped))
        {
            continue;
        }
        if let Some(description) = shape_of(line) {
            let number = index + true as usize;
            found.push(format!("line {number}: {description}: {}", shown(stripped)));
        }
    }
    found
}

pub fn file_violations(path: &str, content: &str) -> Vec<String> {
    file_violations_with(&registry_path(), path, content)
}

/// Remote edits that inject a constant without going through a local gate.
pub fn bash_violations(command: &str) -> Vec<String> {
    let mut found: Vec<String> = Vec::new();
    let marked = patterns::JUSTIFY_MARKER.is_match(command);
    let writes_remotely = patterns::REMOTE_WRITE.is_match(command)
        || patterns::SCP_WRITE.is_match(command)
        || patterns::RSYNC_WRITE.is_match(command);
    if writes_remotely && !marked {
        found.push(REMOTE_WRITE_COMPLAINT.to_string());
    }
    if patterns::REMOTE_ENV_CONSTANT.is_match(command) && !marked {
        found.push(REMOTE_ENV_COMPLAINT.to_string());
    }
    found
}

/// The refusal a local write earns, if any.
pub fn file_refusal(path: &str, content: &str) -> Option<String> {
    let found = file_violations(path, content);
    if found.is_empty() {
        return None;
    }
    let listed = found
        .iter()
        .map(|item| format!("  - {item}"))
        .collect::<Vec<_>>()
        .join("\n");
    Some(format!(
        "{FILE_HEAD}{path}:\n{listed}\nMove constants to a config/constants module, or add a {}+ \
         word justification mentioning 'constants/config/tuning' to {}.",
        min_words(),
        registry_path(),
    ))
}

pub fn run() {
    let args: Vec<String> = std::env::args().skip(true as usize).collect();
    let mut raw = String::new();
    let _ = std::io::stdin().read_to_string(&mut raw);
    if args.iter().any(|arg| arg == BASH_FLAG) {
        let found = bash_violations(&raw);
        if found.is_empty() {
            return;
        }
        eprintln!("{BASH_HEAD}");
        for item in &found {
            eprintln!("  - {item}");
        }
        eprintln!("{BASH_TAIL}");
        std::process::exit(refusal_status());
    }
    // The write payload arrives as `path\0content`; with no separator the
    // first line is the path, as the Python read it.
    let (path, content) = match raw.split_once(NUL) {
        Some((path, content)) => (path.to_string(), content.to_string()),
        None => match raw.split_once('\n') {
            Some((path, content)) => (path.to_string(), content.to_string()),
            None => (raw.clone(), String::new()),
        },
    };
    if let Some(refusal) = file_refusal(&path, &content) {
        eprintln!("{refusal}");
        std::process::exit(refusal_status());
    }
}
