//! `tama brama-check` when the credential or the endpoint is not usable.
//!
//! The client's identity is a Skarbiec consumer and its credential is a
//! token minted for that consumer, so the refusals name the consumer and the
//! file, and say which command mints one. They are what an operator reads
//! when a repair round or the objective reviewer comes back empty, so each
//! one is asserted by its exact words.

use std::fs;
use std::path::PathBuf;
use std::process::{Command, Output};
use std::time::{SystemTime, UNIX_EPOCH};

fn scratch(label: &str) -> PathBuf {
    let unique = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .expect("clock before epoch")
        .as_nanos();
    let path = std::env::temp_dir().join(format!(
        "tama-brama-check-{label}-{}-{unique}",
        std::process::id()
    ));
    fs::create_dir_all(&path).expect("create scratch root");
    path
}

fn check(env: &[(&str, &str)]) -> Output {
    let mut command = Command::new(env!("CARGO_BIN_EXE_tama-cli"));
    command.arg("brama-check");
    for (name, value) in env {
        command.env(name, value);
    }
    command.output().expect("run tama brama-check")
}

#[test]
fn a_missing_token_names_the_consumer_the_path_and_the_repair() {
    let root = scratch("missing");
    let missing = root.join("absent-token");
    let output = check(&[
        ("TAMA_BRAMA_CONSUMER", "tama-probe"),
        ("TAMA_BRAMA_TOKEN_FILE", &missing.to_string_lossy()),
        ("BRAMA_URL", "https://brama.example/v1/chat/completions"),
    ]);
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        stderr.contains("no Brama token for consumer tama-probe at"),
        "the refusal must name the consumer and the file, got {stderr}"
    );
    assert!(
        stderr.contains("skarbiec token-mint tama-probe --capabilities call:brama#<route>"),
        "the refusal must name the command that mints one, got {stderr}"
    );
    assert!(
        !output.status.success(),
        "a client without a token has not reached Brama"
    );
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn an_empty_token_file_is_not_treated_as_a_credential() {
    let root = scratch("empty");
    let token = root.join("empty-token");
    fs::write(&token, "\n").expect("write empty token");
    let output = check(&[
        ("TAMA_BRAMA_CONSUMER", "tama-probe"),
        ("TAMA_BRAMA_TOKEN_FILE", &token.to_string_lossy()),
        ("BRAMA_URL", "https://brama.example/v1/chat/completions"),
    ]);
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        stderr.contains("is empty"),
        "an empty file must be refused as empty, got {stderr}"
    );
    assert!(!output.status.success());
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn a_token_file_holding_more_than_one_token_is_refused() {
    let root = scratch("multi");
    let token = root.join("two-tokens");
    fs::write(&token, "first second\n").expect("write two tokens");
    let output = check(&[
        ("TAMA_BRAMA_CONSUMER", "tama-probe"),
        ("TAMA_BRAMA_TOKEN_FILE", &token.to_string_lossy()),
        ("BRAMA_URL", "https://brama.example/v1/chat/completions"),
    ]);
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        stderr.contains("does not hold one token"),
        "a file with two words is not a token, got {stderr}"
    );
    let _ = fs::remove_dir_all(&root);
}

#[test]
fn an_endpoint_the_client_would_refuse_is_reported_as_such() {
    let root = scratch("transport");
    let token = root.join("token");
    fs::write(&token, "0123456789abcdef\n").expect("write token");
    // `http` off loopback is refused by the client's own transport policy:
    // a bearer is never posted in the clear to a remote host.
    let output = check(&[
        ("TAMA_BRAMA_CONSUMER", "tama-probe"),
        ("TAMA_BRAMA_TOKEN_FILE", &token.to_string_lossy()),
        ("BRAMA_URL", "http://brama.example/v1/chat/completions"),
    ]);
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(
        stdout.contains("refused by the client's own policy"),
        "the transport verdict must say the client refused it, got {stdout}"
    );
    assert!(
        !output.status.success(),
        "an endpoint the client refuses cannot be reported as reachable"
    );
    let _ = fs::remove_dir_all(&root);
}
