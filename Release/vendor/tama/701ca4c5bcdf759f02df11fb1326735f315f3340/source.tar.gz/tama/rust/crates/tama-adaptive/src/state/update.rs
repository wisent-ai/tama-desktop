//! One transition: the lock it takes, the fact it journals, and the
//! projection it persists.
//!
//! Split out of `state/mod.rs`, which had grown past the
//! three-hundred-line limit; reading state stays there.

use super::lock::LockOwnership;
use super::projections::Projection;
use super::{key_of, valid_state, HookState, StateStore, TransitionResult};
use crate::util::uuid_v4;

impl StateStore {
    /// `update(hookId, transition, fact)`. A lock acquisition failure
    /// propagates like the JS throw outside the `try` block.
    pub fn update<F>(
        &self,
        hook_id: &str,
        transition: F,
        fact: Option<serde_json::Value>,
    ) -> std::io::Result<TransitionResult>
    where
        F: FnOnce(&HookState, &serde_json::Value) -> Projection,
    {
        let id = hook_id.to_string();
        if id.is_empty() {
            return Ok(TransitionResult {
                ok: false,
                persisted: false,
                mode: String::new(),
                transition: None,
                reason: Some("missing-hook-id".to_string()),
                state: HookState::initial(&id),
            });
        }
        let ownership: LockOwnership = match self.locks.acquire(&key_of(&id)) {
            Ok(ownership) => ownership,
            Err(error) => return Err(error),
        };
        let result = self.update_locked(&id, transition, fact);
        self.locks.release(Some(ownership));
        Ok(result)
    }

    fn update_locked<F>(
        &self,
        id: &str,
        transition: F,
        fact: Option<serde_json::Value>,
    ) -> TransitionResult
    where
        F: FnOnce(&HookState, &serde_json::Value) -> Projection,
    {
        match self.try_update(id, transition, fact) {
            Ok(result) => result,
            Err(error) => {
                (self.warn)(&format!(
                    "adaptive state persistence failed for {}: {}",
                    id, error
                ));
                TransitionResult {
                    ok: false,
                    persisted: false,
                    mode: String::new(),
                    transition: None,
                    reason: Some("persistence-failed".to_string()),
                    state: HookState::initial(id),
                }
            }
        }
    }

    fn try_update<F>(
        &self,
        id: &str,
        transition: F,
        fact: Option<serde_json::Value>,
    ) -> Result<TransitionResult, String>
    where
        F: FnOnce(&HookState, &serde_json::Value) -> Projection,
    {
        let prior = self.read_state(id, true)?;
        let fact = fact
            .filter(|f| f.is_object())
            .ok_or("missing adaptive transition fact")?;
        let mut durable_fact = serde_json::Map::new();
        durable_fact.insert("id".into(), uuid_v4().into());
        durable_fact.insert("hookId".into(), id.into());
        if let serde_json::Value::Object(extra) = fact {
            durable_fact.extend(extra);
        }
        let durable_fact = serde_json::Value::Object(durable_fact);
        let result = transition(&prior, &durable_fact);
        if !result.changed {
            let transition_name = result.transition;
            // JS: `transition` key only added when truthy; all projection
            // transition names are non-empty strings, so it is always set.
            return Ok(TransitionResult {
                ok: true,
                persisted: true,
                mode: String::new(),
                transition: Some(transition_name.to_string()),
                reason: None,
                state: prior,
            });
        }
        let mut next = result.state;
        next.journal_count = prior.journal_count + 1;
        let checked = valid_state(&next.to_value(), id).ok_or("invalid adaptive projection")?;
        self.journal
            .append(id, &durable_fact)
            .map_err(|e| format!("Error: {}", e))?;
        self.persist(id, &checked)
            .map_err(|e| format!("Error: {}", e))?;
        Ok(TransitionResult {
            ok: true,
            persisted: true,
            mode: String::new(),
            transition: Some(result.transition.to_string()),
            reason: None,
            state: checked,
        })
    }
}
