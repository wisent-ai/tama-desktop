//! The operator's break-glass controls, which no agent may touch.
//!
//! Turning every hook off at once is how the operator recovers a machine a
//! hook has wedged. It is his control, not a tool: an agent that can disable
//! the gates has no gates. So the emergency state file, its backup directory,
//! the per-session override files and the commands that drive them are refused
//! outright, with their own banner, before the consent question is even asked
//! — consent to edit a hook is not consent to switch the enforcement off.
//!
//! Python states this rule and then cannot run it: `operator_recovery_target`
//! references a `WRITE_COMMAND_RE` that no line defines, so the moment a
//! payload names the emergency state file the guard dies with a `NameError`
//! and exits 1 instead of refusing. Reproduced on 2026-09-15 with
//! `cp x "$HOME/Library/Application Support/Tama/hook-emergency-state.json"`.
//! Here the blanket write shape is `patterns.write_command`, which is exactly
//! the coarse "is there a write anywhere in this text" the rule wants.

use super::super::block_hook_config_edits_without_consent_patterns::Patterns;

pub(crate) const BLOCK_REASON: &str = concat!(
    "BLOCKED: global Tama emergency disable/re-enable is an operator-only ",
    "break-glass control and cannot be invoked or mutated by an agent.",
);

fn normalize(text: &str) -> String {
    text.replace('\\', "/")
}

/// Whether a write tool aims at a break-glass file.
pub(crate) fn write_tool_target(patterns: &Patterns, paths: &[String]) -> bool {
    paths
        .iter()
        .any(|path| patterns.operator_recovery_path.is_match(&normalize(path)))
}

/// Whether an execution payload drives a break-glass control: naming one of
/// its commands is enough, and naming one of its files counts once the text
/// also carries any write shape at all.
pub(crate) fn execution_target(patterns: &Patterns, text: &str) -> bool {
    let normalized = normalize(text);
    if patterns.operator_recovery_command.is_match(&normalized) {
        return true;
    }
    patterns.operator_recovery_path.is_match(&normalized)
        && (patterns.write_command.is_match(&normalized)
            || patterns.opaque_patch.is_match(&normalized))
}

#[cfg(test)]
mod tests {
    use super::{execution_target, write_tool_target};
    use crate::ports::block_hook_config_edits_without_consent_patterns::Patterns;

    const STATE: &str = "/Users/someone/Library/Application Support/Tama/hook-emergency-state.json";

    /// The case that made Python exit 1 with a `NameError` instead of refusing.
    #[test]
    fn a_copy_onto_the_emergency_state_is_refused() {
        let patterns = Patterns::compile();
        let command = format!("cp x \"{STATE}\"");
        assert!(execution_target(&patterns, &command));
    }

    #[test]
    fn the_emergency_command_is_refused_with_no_write_in_sight() {
        let patterns = Patterns::compile();
        assert!(execution_target(
            &patterns,
            "TAMA_EMERGENCY_ACTION=disable tama enforcement off"
        ));
        assert!(execution_target(&patterns, "./emergency_disable_hooks"));
    }

    /// Reading the state is how an agent reports what the operator switched
    /// off, so it stays allowed.
    #[test]
    fn reading_the_emergency_state_is_allowed() {
        let patterns = Patterns::compile();
        assert!(!execution_target(&patterns, &format!("cat \"{STATE}\"")));
    }

    #[test]
    fn a_write_tool_aimed_at_a_session_override_is_refused() {
        let patterns = Patterns::compile();
        let paths = vec![
            "/Users/someone/Library/Application Support/Tama/session-control/abc.override.json"
                .to_string(),
        ];
        assert!(write_tool_target(&patterns, &paths));
        assert!(!write_tool_target(&patterns, &["notes.md".to_string()]));
    }
}
