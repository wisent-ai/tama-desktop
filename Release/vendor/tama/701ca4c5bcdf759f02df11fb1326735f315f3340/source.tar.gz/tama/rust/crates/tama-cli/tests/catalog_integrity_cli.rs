use std::fs;
use std::path::PathBuf;
use std::process::{Command, Output};
use std::time::{SystemTime, UNIX_EPOCH};

use serde_json::json;

const HOOK_ID: &str = "wired-but-uncatalogued";

struct FixtureRoot {
    path: PathBuf,
}

impl FixtureRoot {
    fn new(catalogued: bool) -> Self {
        // `SystemTime::now()` is microsecond-grained here, so two tests
        // starting in the same microsecond shared one fixture root and read
        // each other's registry. The thread id separates them by construction.
        let unique = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock before epoch")
            .as_nanos();
        let thread = format!("{:?}", std::thread::current().id()).replace(['(', ')'], "-");
        // The crate's own `CARGO_TARGET_TMPDIR` inside `target/`, never
        // `/tmp`: this workshop keeps a run's throwaway state in the
        // checkout's ignored build tree.
        let path = PathBuf::from(env!("CARGO_TARGET_TMPDIR")).join(format!(
            "tama-catalog-integrity-{}-{thread}{unique}",
            std::process::id()
        ));
        fs::create_dir_all(path.join("shared-hooks")).expect("create fixture root");
        let agent_hooks = if catalogued {
            vec![json!({ "id": HOOK_ID })]
        } else {
            Vec::new()
        };
        let registry = json!({
            "version": 1,
            "adapters": {
                "claude": { "requiredLiveCoverage": false },
                "codex": { "requiredLiveCoverage": false }
            },
            "catalog": { "agentHooks": agent_hooks },
            "events": {
                "pre_tool_use:write": {
                    "blocking": true,
                    "hooks": [{ "id": HOOK_ID, "command": "/bin/true" }]
                },
                "stop": {
                    "blocking": true,
                    "hooks": [{ "id": HOOK_ID, "command": "/bin/true" }]
                }
            }
        });
        fs::write(
            path.join("shared-hooks/registry.json"),
            serde_json::to_vec_pretty(&registry).expect("serialize fixture registry"),
        )
        .expect("write fixture registry");
        Self { path }
    }

    fn validate(&self) -> Output {
        Command::new(env!("CARGO_BIN_EXE_tama-cli"))
            .arg("validate")
            .env("TAMA_ROOT", &self.path)
            .output()
            .expect("run real tama-cli binary")
    }
}

impl Drop for FixtureRoot {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.path);
    }
}

fn stderr(output: &Output) -> String {
    String::from_utf8(output.stderr.clone()).expect("stderr is UTF-8")
}

#[test]
fn validate_rejects_runtime_hook_missing_from_catalog() {
    let output = FixtureRoot::new(false).validate();

    assert_eq!(output.status.code(), Some(1));
    assert_eq!(
        stderr(&output),
        "ERROR install drift: registry pre_tool_use:write, stop wired-but-uncatalogued — runtime event wiring declares this hook for the event but the registry catalog does not declare it\n"
    );
}

#[test]
fn validate_accepts_consistent_runtime_and_catalog() {
    let output = FixtureRoot::new(true).validate();

    assert!(
        output.status.success(),
        "validate failed with stderr:\n{}",
        stderr(&output)
    );
    assert!(!stderr(&output).contains("runtime event wiring declares this hook"));
}
