//! The printed shapes of both leaves.
//!
//! Split out of `mod.rs` when adding `--except` would have pushed that file
//! past the three-hundred-line limit `block-oversized-files` enforces. The
//! seam is meaningful rather than arithmetic: everything here turns a
//! document into text, and nothing here parses arguments or chooses an exit
//! code.

use serde::Serialize;
use tama_violations::repo_discovery::UnreadableDirectory;

use super::discovery::{ListDocument, Refusal, RemoveDocument};
use super::porcelain::Worktree;

/// The one place a refusal is worded. `CommandError::Refused` prints the same
/// sentences to stderr when an `--apply` pass is refused.
pub(super) fn refusal_sentence(refusal: &Refusal) -> String {
    match refusal.reason {
        "locked" => format!(
            "Refusing to remove {}: git reports it locked. Unlock it with git worktree unlock, or pass --force.",
            refusal.path
        ),
        _ => format!(
            "Refusing to remove {}: it carries uncommitted changes. Commit them in that worktree, or pass --force to discard them.",
            refusal.path
        ),
    }
}

fn print_worktree(worktree: &Worktree) {
    let branch = worktree.branch.as_deref().unwrap_or("(detached)");
    let mut flags = String::new();
    for (set, label) in [
        (worktree.dirty, "dirty"),
        (worktree.locked, "locked"),
        (worktree.prunable, "prunable"),
    ] {
        if set {
            flags.push_str("  ");
            flags.push_str(label);
        }
    }
    println!("  {}  {branch}  {}{flags}", worktree.path, worktree.head);
}

pub(super) fn print_list(document: &ListDocument) {
    for repository in &document.repositories {
        println!("{}", repository.repository);
        for worktree in &repository.worktrees {
            print_worktree(worktree);
        }
    }
    println!(
        "{} linked worktree(s) in {} repository(ies).",
        document.worktree_count,
        document.repositories.len()
    );
    for path in &document.unreadable {
        eprintln!("skipped {path}: git does not answer for it as a repository");
    }
    print_unreadable_directories(&document.unreadable_directories);
}

/// What the walk could not read, and what that costs the answer above. An
/// operator reading `0 worktrees` has to see this in the same breath, so it
/// goes to stderr on every leaf and the leaf exits non-zero.
pub(super) fn print_unreadable_directories(directories: &[UnreadableDirectory]) {
    for directory in directories {
        eprintln!("could not read {}: {}", directory.path, directory.reason);
    }
    if !directories.is_empty() {
        eprintln!("{}", incomplete_walk_sentence(directories));
    }
}

/// The one sentence a pass makes when it could not look everywhere.
pub(super) fn incomplete_walk_sentence(directories: &[UnreadableDirectory]) -> String {
    format!(
        "this pass could not read {} director{} under the roots, so it cannot say what they hold; nothing was removed",
        directories.len(),
        if directories.len() == 1 { "y" } else { "ies" }
    )
}

pub(super) fn print_json<T: Serialize>(document: &T) {
    println!(
        "{}",
        serde_json::to_string_pretty(document).unwrap_or_default()
    );
}

/// What `--except` held back, printed on its own before anything the pass
/// judged: kept is the operator's choice, refused is the product's judgement,
/// and running them together would read as one list of problems.
fn print_excepted(document: &RemoveDocument) {
    if document.excepted.is_empty() {
        return;
    }
    println!(
        "Kept {} linked worktree(s) by --except:",
        document.excepted.len()
    );
    for path in &document.excepted {
        println!("  {path}");
    }
}

/// The preview lists what would go and, separately, what would block the
/// pass. A refused `--apply` prints nothing here: its refusals go to stderr
/// with the exit code that carries them.
pub(super) fn print_remove(document: &RemoveDocument, apply: bool) {
    if document.applied {
        print_excepted(document);
        println!("Removed {} linked worktree(s).", document.removed.len());
        for path in &document.removed {
            println!("  {path}");
        }
        return;
    }
    // An `--apply` that removed nothing because the walk was incomplete still
    // owes the operator the list of directories that ended it, so this runs
    // before the early return every other refused apply takes.
    print_unreadable_directories(&document.unreadable_directories);
    if apply {
        return;
    }
    print_excepted(document);
    let refused: Vec<&str> = document
        .refused
        .iter()
        .map(|refusal| refusal.path.as_str())
        .collect();
    println!(
        "Would remove {} linked worktree(s); nothing was changed. Pass --apply to remove them.",
        document.worktree_count - refused.len()
    );
    for repository in &document.repositories {
        for worktree in &repository.worktrees {
            if !refused.contains(&worktree.path.as_str()) {
                print_worktree(worktree);
            }
        }
    }
    for refusal in &document.refused {
        println!("{}", refusal_sentence(refusal));
    }
}
