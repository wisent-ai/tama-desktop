//! Durable machine-wide hook selection and additive session resolution.

use std::collections::HashSet;
use std::env;
use std::fs;
use std::io;
use std::path::{Path, PathBuf};

use serde::{Deserialize, Serialize};

use crate::jsutil;
use crate::session_control::{
    hooks_globally_disabled, read_session_override, tama_state_root, SessionContext,
};

pub const HOOK_ENFORCEMENT_SCHEMA: &str = "ai.wisent.tama.hook-enforcement.v1";

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum EnforcementMode {
    All,
    Only,
}

impl EnforcementMode {
    pub fn as_str(self) -> &'static str {
        match self {
            Self::All => "all",
            Self::Only => "only",
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct PreviousEnforcement {
    pub mode: EnforcementMode,
    pub enabled: Vec<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct EnforcementSelection {
    pub schema: String,
    pub mode: EnforcementMode,
    pub enabled: Vec<String>,
    pub changed_at: String,
    pub previous: PreviousEnforcement,
}

impl EnforcementSelection {
    /// Effective default for an absent or unreadable state file.
    pub fn all() -> Self {
        Self {
            schema: HOOK_ENFORCEMENT_SCHEMA.to_string(),
            mode: EnforcementMode::All,
            enabled: Vec::new(),
            changed_at: String::new(),
            previous: PreviousEnforcement {
                mode: EnforcementMode::All,
                enabled: Vec::new(),
            },
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct EnforcementRead {
    pub selection: EnforcementSelection,
    /// Absent files are normal and have no error. Every other read or
    /// validation failure is reported here while `selection` safely falls
    /// back to `all`.
    pub error: Option<String>,
}

pub fn enforcement_state_path() -> PathBuf {
    env::var_os("TAMA_HOOK_ENFORCEMENT")
        .filter(|value| !value.is_empty())
        .map(PathBuf::from)
        .unwrap_or_else(|| tama_state_root().join("hook-enforcement.json"))
}

/// macOS product path rooted at an explicit home, used by operator tools.
pub fn enforcement_state_path_for_home(home: &Path) -> PathBuf {
    home.join("Library")
        .join("Application Support")
        .join("Tama")
        .join("hook-enforcement.json")
}

fn valid_ids(mode: EnforcementMode, ids: &[String]) -> bool {
    if mode == EnforcementMode::All && !ids.is_empty() {
        return false;
    }
    if mode == EnforcementMode::Only && ids.is_empty() {
        return false;
    }
    let mut seen = HashSet::with_capacity(ids.len());
    ids.iter()
        .all(|id| !id.is_empty() && id.trim() == id && seen.insert(id.as_str()))
}

fn validate(selection: &EnforcementSelection) -> Result<(), &'static str> {
    if selection.schema != HOOK_ENFORCEMENT_SCHEMA {
        return Err("schema is not ai.wisent.tama.hook-enforcement.v1");
    }
    if !valid_ids(selection.mode, &selection.enabled) {
        return Err("mode and enabled hook ids are inconsistent");
    }
    if selection.changed_at.is_empty() || jsutil::parse_date(&selection.changed_at).is_none() {
        return Err("changedAt is not a valid ISO-8601 timestamp");
    }
    if !valid_ids(selection.previous.mode, &selection.previous.enabled) {
        return Err("previous mode and enabled hook ids are inconsistent");
    }
    Ok(())
}

pub fn read_enforcement_selection() -> EnforcementRead {
    read_enforcement_selection_at(&enforcement_state_path())
}

pub fn read_enforcement_selection_at(path: &Path) -> EnforcementRead {
    let text = match fs::read_to_string(path) {
        Ok(text) => text,
        Err(error) if error.kind() == io::ErrorKind::NotFound => {
            return EnforcementRead {
                selection: EnforcementSelection::all(),
                error: None,
            };
        }
        Err(error) => {
            return EnforcementRead {
                selection: EnforcementSelection::all(),
                error: Some(format!("could not read {}: {error}", path.display())),
            };
        }
    };
    let parsed = serde_json::from_str::<EnforcementSelection>(&text)
        .map_err(|error| format!("invalid {}: {error}", path.display()))
        .and_then(|selection| {
            validate(&selection).map_err(|error| format!("invalid {}: {error}", path.display()))?;
            Ok(selection)
        });
    match parsed {
        Ok(selection) => EnforcementRead {
            selection,
            error: None,
        },
        Err(error) => EnforcementRead {
            selection: EnforcementSelection::all(),
            error: Some(error),
        },
    }
}

pub fn write_enforcement_selection(
    mode: EnforcementMode,
    enabled: &[String],
) -> io::Result<EnforcementSelection> {
    write_enforcement_selection_at(&enforcement_state_path(), mode, enabled)
}

pub fn write_enforcement_selection_at(
    path: &Path,
    mode: EnforcementMode,
    enabled: &[String],
) -> io::Result<EnforcementSelection> {
    let mut enabled = enabled.to_vec();
    enabled.sort();
    enabled.dedup();
    if !valid_ids(mode, &enabled) {
        return Err(io::Error::new(
            io::ErrorKind::InvalidInput,
            "mode and enabled hook ids are inconsistent",
        ));
    }
    let current = read_enforcement_selection_at(path).selection;
    let selection = EnforcementSelection {
        schema: HOOK_ENFORCEMENT_SCHEMA.to_string(),
        mode,
        enabled,
        changed_at: jsutil::to_iso_string(jsutil::now_millis()),
        previous: PreviousEnforcement {
            mode: current.mode,
            enabled: current.enabled,
        },
    };
    atomic_write(path, &selection)?;
    Ok(selection)
}

fn atomic_write(path: &Path, selection: &EnforcementSelection) -> io::Result<()> {
    let parent = path
        .parent()
        .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidInput, "state path has no parent"))?;
    fs::create_dir_all(parent)?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        fs::set_permissions(parent, fs::Permissions::from_mode(0o700))?;
    }
    let mut temporary = path.as_os_str().to_owned();
    temporary.push(format!(
        ".{}.{}.tmp",
        std::process::id(),
        jsutil::random_token()
    ));
    let temporary = PathBuf::from(temporary);
    let payload = format!(
        "{}\n",
        serde_json::to_string(selection).map_err(io::Error::other)?
    );
    let result = (|| -> io::Result<()> {
        let mut options = fs::OpenOptions::new();
        options.write(true).create_new(true);
        #[cfg(unix)]
        {
            use std::os::unix::fs::OpenOptionsExt;
            options.mode(0o600);
        }
        let mut file = options.open(&temporary)?;
        use std::io::Write;
        file.write_all(payload.as_bytes())?;
        file.sync_all()?;
        drop(file);
        fs::rename(&temporary, path)
    })();
    let _ = fs::remove_file(&temporary);
    result
}

pub fn selection_enforces_hook(
    selection: &EnforcementSelection,
    globally_disabled: bool,
    hook_id: &str,
    session_enabled_hook_ids: &[String],
) -> bool {
    let session_enabled = session_enabled_hook_ids.iter().any(|id| id == hook_id);
    if globally_disabled {
        return session_enabled;
    }
    selection.mode == EnforcementMode::All
        || selection.enabled.iter().any(|id| id == hook_id)
        || session_enabled
}

/// Resolve machine selection plus the session's additive-only override.
pub fn hook_enforces(
    selection: &EnforcementSelection,
    hook_id: &str,
    context: Option<&SessionContext>,
    known_hook_ids: Option<&HashSet<String>>,
) -> bool {
    let session = read_session_override(context, known_hook_ids);
    selection_enforces_hook(
        selection,
        hooks_globally_disabled(),
        hook_id,
        &session.enabled_hook_ids,
    )
}
