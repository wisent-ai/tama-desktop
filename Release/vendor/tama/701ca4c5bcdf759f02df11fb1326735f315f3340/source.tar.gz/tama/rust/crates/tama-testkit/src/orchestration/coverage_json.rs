//! Rendering the coverage summary the harness prints, in the JS module's
//! own key order.
//!
//! Split out of `orchestration/mod.rs`, which had grown past the
//! three-hundred-line limit; running the scenarios stays there.

use tama_core::runtime::{CoverageSummary, RequiredCoverage};

use crate::json::Json;

pub(super) fn json_string_or_empty(value: Option<&Json>) -> String {
    crate::json::js_string_opt(value)
}

/// `missing` entries keep the JS object key order from
/// `buildRequiredCoverage`.
fn required_coverage_json(item: &RequiredCoverage) -> Json {
    match item {
        RequiredCoverage::Runtime(entry) => {
            let mut entries = vec![
                ("runtime".to_string(), Json::str(entry.runtime.clone())),
                ("event".to_string(), Json::str(entry.event.clone())),
                (
                    "runtimeEvent".to_string(),
                    Json::str(entry.runtime_event.clone()),
                ),
                ("hookId".to_string(), Json::str(entry.hook_id.clone())),
            ];
            if let Some(command) = &entry.command {
                entries.push(("command".to_string(), Json::str(command.clone())));
            }
            entries.push((
                "coverageKey".to_string(),
                Json::str(entry.coverage_key.clone()),
            ));
            Json::obj(entries)
        }
        RequiredCoverage::Git(entry) => {
            let mut entries = vec![
                ("runtime".to_string(), Json::str(entry.runtime.clone())),
                ("event".to_string(), Json::str(entry.event.clone())),
                ("hookId".to_string(), Json::str(entry.hook_id.clone())),
            ];
            if let Some(source) = &entry.source {
                entries.push(("source".to_string(), crate::json::from_serde(source)));
            }
            if let Some(repo) = &entry.repo {
                entries.push(("repo".to_string(), crate::json::from_serde(repo)));
            }
            if let Some(hooks_path) = &entry.hooks_path {
                entries.push(("hooksPath".to_string(), crate::json::from_serde(hooks_path)));
            }
            if let Some(scope) = &entry.scope {
                entries.push(("scope".to_string(), crate::json::from_serde(scope)));
            }
            entries.push((
                "coverageKey".to_string(),
                Json::str(entry.coverage_key.clone()),
            ));
            Json::obj(entries)
        }
    }
}

fn ordered_counts_json(map: &tama_core::registry::OrderedMap<usize>) -> Json {
    Json::obj(
        map.iter()
            .map(|(key, count)| (key.clone(), Json::num_usize(*count)))
            .collect(),
    )
}

/// `coverageSummary` (full) or `compactCoverageSummary` (without `missing`).
pub(super) fn coverage_summary_json(summary: &CoverageSummary, full: bool) -> Json {
    let mut entries = vec![
        (
            "requiredCount".to_string(),
            Json::num_usize(summary.required_count),
        ),
        (
            "passedCount".to_string(),
            Json::num_usize(summary.passed_count),
        ),
        (
            "missingCount".to_string(),
            Json::num_usize(summary.missing_count),
        ),
        (
            "missingByRuntime".to_string(),
            ordered_counts_json(&summary.missing_by_runtime),
        ),
        (
            "missingByEvent".to_string(),
            ordered_counts_json(&summary.missing_by_event),
        ),
    ];
    if full {
        entries.push((
            "missing".to_string(),
            Json::arr(summary.missing.iter().map(required_coverage_json).collect()),
        ));
    }
    Json::obj(entries)
}
