//! Block-decision recognition in hook output.

use serde_json::Value;

use crate::jssem::{js_to_string_opt, js_truthy, trim_js};

/// Port of `decisionFromOutput`: the whole trimmed output must be a JSON
/// object with `decision === 'block'`; the reason is `parsed.reason ||
/// 'hook returned block decision'` (stringified like a template literal).
pub(crate) fn decision_from_output(text: &str) -> Option<String> {
    let trimmed = trim_js(text);
    if trimmed.is_empty() {
        return None;
    }
    let parsed: Value = serde_json::from_str(trimmed).ok()?;
    if parsed.is_object() && parsed.get("decision").and_then(Value::as_str) == Some("block") {
        let reason = parsed.get("reason");
        return Some(if js_truthy(reason) {
            js_to_string_opt(reason)
        } else {
            "hook returned block decision".to_string()
        });
    }
    None
}
