//! Refuse mutations of upstream-owned source, including locally renamed forks.
mod provenance;
mod shell;

use crate::ports::python_stdlib::expanduser;
use serde_json::Value;
use std::path::{Path, PathBuf};

fn patch_paths(patch: &str, targets: &mut Vec<String>) {
    for line in patch.lines() {
        if let Some(path) = [
            "*** Update File: ",
            "*** Add File: ",
            "*** Delete File: ",
            "*** Move to: ",
            "MV ",
        ]
        .iter()
        .find_map(|prefix| line.strip_prefix(prefix))
        {
            targets.push(path.trim().trim_matches('"').to_owned());
        } else if let Some(header) = line
            .strip_prefix('[')
            .and_then(|line| line.strip_suffix(']'))
        {
            if let Some((path, tag)) = header.rsplit_once('#') {
                if !tag.is_empty() && tag.chars().all(|value| value.is_ascii_hexdigit()) {
                    targets.push(path.to_owned());
                }
            }
        }
    }
}

fn file_targets(tool: &str, input: &Value) -> Result<Vec<String>, String> {
    let mut targets = Vec::new();
    for key in [
        "file_path",
        "path",
        "file",
        "destination",
        "newPath",
        "new_path",
    ] {
        if let Some(path) = input.get(key).and_then(Value::as_str) {
            targets.push(path.to_owned());
        }
    }
    if let Some(paths) = input.get("paths").and_then(Value::as_array) {
        targets.extend(paths.iter().filter_map(Value::as_str).map(str::to_owned));
    }
    for key in ["patch", "patch_text", "patchText"] {
        if let Some(patch) = input.get(key).and_then(Value::as_str) {
            patch_paths(patch, &mut targets);
        }
    }
    if let Some(patch) = input.as_str() {
        patch_paths(patch, &mut targets);
    }
    if let Some(operations) = input.get("edits").and_then(Value::as_array) {
        for operation in operations {
            targets.extend(file_targets(tool, operation)?);
        }
    }
    if let Some(path) = input.get("path").and_then(Value::as_str) {
        if path.starts_with("xd://") {
            if path != "xd://ast_edit" && path != "xd://lsp" {
                return Ok(Vec::new());
            }
            let content = input
                .get("content")
                .and_then(Value::as_str)
                .ok_or("refactor payload has no content")?;
            let refactor: Value = serde_json::from_str(content)
                .map_err(|error| format!("unreadable refactor: {error}"))?;
            if path == "xd://lsp"
                && !["rename", "rename_file", "code_actions"]
                    .contains(&refactor["action"].as_str().unwrap_or_default())
            {
                return Ok(Vec::new());
            }
            if refactor["apply"] == false {
                return Ok(Vec::new());
            }
            if path == "xd://lsp"
                && refactor["action"] == "code_actions"
                && refactor["apply"] != true
            {
                return Ok(Vec::new());
            }
            return file_targets("refactor", &refactor);
        }
    }
    if tool == "refactor" && targets.iter().any(|path| path.contains(['*', '?', '['])) {
        return Err(
            "refactor targets must name concrete files so each source owner can be checked".into(),
        );
    }
    Ok(targets)
}

pub fn evaluate(payload: &Value) -> Option<String> {
    let input = payload.get("tool_input").unwrap_or(&Value::Null);
    let cwd = input
        .get("cwd")
        .or_else(|| payload.get("cwd"))
        .and_then(Value::as_str)
        .map(PathBuf::from)
        .or_else(|| std::env::current_dir().ok())?;
    let tool = payload
        .get("tool_name")
        .or_else(|| payload.get("tool"))
        .and_then(Value::as_str)
        .unwrap_or_default()
        .rsplit(['.', ':', '/'])
        .next()
        .unwrap_or_default()
        .to_lowercase();
    if [
        "bash",
        "exec",
        "shell",
        "execute",
        "run_command",
        "run_process",
    ]
    .contains(&tool.as_str())
    {
        return shell::refusal(input, &cwd);
    }
    if ![
        "write",
        "write_file",
        "edit",
        "edit_file",
        "multiedit",
        "multi_edit",
        "create",
        "apply_patch",
        "ast_edit",
        "rename",
        "rename_file",
        "delete",
        "remove",
        "move",
    ]
    .contains(&tool.as_str())
    {
        return None;
    }
    let paths = match file_targets(&tool, input) {
        Ok(paths) => paths,
        Err(error) => {
            return Some(format!(
                "BLOCKED: {error}; no source mutation was authorized"
            ))
        }
    };
    for path in paths {
        if path.contains("://") {
            return Some(format!("BLOCKED: cannot establish external source ownership for mutation target {path}; use the owning product's supported interface"));
        }
        let expanded = expanduser(&path);
        if let Some(reason) = provenance::refusal(Path::new(&expanded), &cwd) {
            return Some(reason);
        }
    }
    None
}
