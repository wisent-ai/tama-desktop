//! Argument-scanning helpers shared by the extracted command handlers.
//!
//! These are the closures `main()` used to define over `argv`, turned into
//! plain functions so every handler in this directory can use them.

/// JS `has(flag)` = `process.argv.includes(flag)`; the leading node/script
/// entries never equal a flag.
pub fn has(argv: &[String], flag: &str) -> bool {
    argv.iter().any(|arg| arg == flag)
}

/// JS `argAfter(flag)`: value right after the first occurrence, or None.
pub fn arg_after(argv: &[String], flag: &str) -> Option<String> {
    argv.iter()
        .position(|arg| arg == flag)
        .and_then(|i| argv.get(i + 1))
        .cloned()
}

/// JS `optionValue(flag, alt)`.
pub fn option_value(argv: &[String], flag: &str) -> Option<String> {
    arg_after(argv, flag)
}
