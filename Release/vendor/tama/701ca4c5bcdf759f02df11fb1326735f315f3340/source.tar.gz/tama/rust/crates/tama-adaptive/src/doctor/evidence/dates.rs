//! `Date.parse` for the ISO-8601 shapes the lake writes, and the ordering
//! the queue sorts timestamps by.
//!
//! Split out of `doctor/evidence.rs`, which had grown past the
//! three-hundred-line limit; reading and validating evidence stays there.

pub(super) fn ordered_float(value: f64) -> i64 {
    // Timestamps here are integral milliseconds; comparing as i64 keeps the
    // total order simple and matches the JS numeric subtraction comparator.
    value as i64
}

/// `Date.parse` for the ISO-8601 shapes the lake writes
/// (`YYYY-MM-DD[T ]HH:MM:SS[.sss][Z|±HH:MM]` or date-only).
pub fn parse_date_ms(text: &str) -> Option<u64> {
    let (date_part, time_part) = match text.find(['T', ' ']) {
        Some(index) => (&text[..index], &text[index + 1..]),
        None => (text, ""),
    };
    let date_segs: Vec<&str> = date_part.split('-').collect();
    if date_segs.len() != 3 {
        return None;
    }
    let year: i64 = date_segs[0].parse().ok()?;
    let month: i64 = date_segs[1].parse().ok()?;
    let day: i64 = date_segs[2].parse().ok()?;
    if !(1..=12).contains(&month) || !(1..=31).contains(&day) {
        return None;
    }
    let days = days_from_civil(year, month as u32, day as u32);
    let mut seconds = 0i64;
    let mut millis = 0i64;
    let mut offset_seconds = 0i64;
    if !time_part.is_empty() {
        let (time_main, offset) = split_offset(time_part);
        offset_seconds = offset?;
        let time_segs: Vec<&str> = time_main.split(':').collect();
        if time_segs.len() < 2 {
            return None;
        }
        let hour: i64 = time_segs[0].parse().ok()?;
        let minute: i64 = time_segs[1].parse().ok()?;
        let (sec_str, frac) = match time_segs.get(2).map(|s| s.split_once('.')) {
            Some(Some((sec, frac))) => (sec, frac),
            Some(None) => (time_segs[2], ""),
            None => ("0", ""),
        };
        let second: i64 = sec_str.parse().ok()?;
        if !frac.is_empty() {
            let padded = format!("{:0<3}", &frac[..frac.len().min(3)]);
            millis = padded.parse().ok()?;
        }
        seconds = hour * 3600 + minute * 60 + second;
    }
    let total = (days * 86_400 + seconds - offset_seconds) * 1000 + millis;
    if total < 0 {
        return None;
    }
    Some(total as u64)
}

fn split_offset(time: &str) -> (&str, Option<i64>) {
    if let Some(stripped) = time.strip_suffix('Z') {
        return (stripped, Some(0));
    }
    let bytes = time.as_bytes();
    for index in (0..bytes.len()).rev() {
        let c = bytes[index] as char;
        if (c == '+' || c == '-') && index > 0 {
            let offset = &time[index..];
            let sign = if c == '+' { 1 } else { -1 };
            let body = &offset[1..];
            let (h, m) = body.split_once(':').unwrap_or((body, "0"));
            if let (Ok(h), Ok(m)) = (h.parse::<i64>(), m.parse::<i64>()) {
                return (&time[..index], Some(sign * (h * 3600 + m * 60)));
            }
            return (time, None);
        }
    }
    (time, Some(0))
}

fn days_from_civil(y: i64, m: u32, d: u32) -> i64 {
    let y = if m <= 2 { y - 1 } else { y };
    let era = if y >= 0 { y } else { y - 399 } / 400;
    let yoe = (y - era * 400) as u64;
    let mp = if m > 2 { m - 3 } else { m + 9 } as u64;
    let doy = (153 * mp + 2) / 5 + d as u64 - 1;
    let doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    era * 146_097 + doe as i64 - 719_468
}
