//! The minimal `src/core/catalog.mjs` surface the doctor needs: where a
//! command's source lives, the hooks the registry declares, and finding one.
//!
//! Split out of `doctor/repair.rs`, which had grown past the
//! three-hundred-line limit.

use std::collections::HashMap;
use std::fs;
use std::path::Path;

use crate::util::repo_root;

/// `commandSourcePath(command)` from `src/core/catalog.mjs`.
pub fn command_source_path(command: &str) -> Option<String> {
    if command.is_empty() {
        return None;
    }
    let root = repo_root();
    let prefixes: [(String, &str); 6] = [
        (
            "/Users/lukaszbartoszcze/.shared-hooks/".to_string(),
            "shared-hooks/",
        ),
        (
            "/Users/lukaszbartoszcze/.codex/hooks/".to_string(),
            "codex-hooks/",
        ),
        (
            "/Users/lukaszbartoszcze/.claude/hooks/".to_string(),
            "claude-hooks/",
        ),
        (
            format!("{}/", root.join("shared-hooks").display()),
            "shared-hooks/",
        ),
        (
            format!("{}/", root.join("codex-hooks").display()),
            "codex-hooks/",
        ),
        (
            format!("{}/", root.join("claude-hooks").display()),
            "claude-hooks/",
        ),
    ];
    for (prefix, repo_dir) in &prefixes {
        if let Some(index) = command.find(prefix.as_str()) {
            let rest = &command[index + prefix.len()..];
            let first = rest.split(char::is_whitespace).next().unwrap_or("");
            return Some(format!("{}{}", repo_dir, first));
        }
    }
    None
}

/// The catalog view the doctor needs (`buildCatalog().hooks`).
#[derive(Debug, Clone)]
pub struct CatalogHook {
    pub id: String,
    pub command: String,
    pub source_path: Option<String>,
}

fn load_repo_registry(root: &Path) -> serde_json::Value {
    let path = root.join("shared-hooks").join("registry.json");
    match fs::read_to_string(path) {
        Ok(text) => {
            serde_json::from_str(&text).unwrap_or_else(|_| serde_json::json!({ "events": {} }))
        }
        Err(_) => serde_json::json!({ "events": {} }),
    }
}

/// `buildCatalog(root).hooks` reduced to id/command/sourcePath, sorted by id.
pub fn build_catalog_hooks(root: &Path) -> Vec<CatalogHook> {
    let registry = load_repo_registry(root);
    let mut by_id: HashMap<String, CatalogHook> = HashMap::new();
    if let Some(events) = registry.get("events").and_then(|e| e.as_object()) {
        for config in events.values() {
            let hooks = config.get("hooks").and_then(|h| h.as_array());
            let Some(hooks) = hooks else { continue };
            for hook in hooks {
                let source = hook
                    .get("source")
                    .filter(|s| crate::util::js_truthy(s))
                    .and_then(|s| s.as_str())
                    .and_then(command_source_path)
                    .or_else(|| {
                        hook.get("command")
                            .and_then(|c| c.as_str())
                            .and_then(command_source_path)
                    });
                let id = hook
                    .get("id")
                    .and_then(|v| v.as_str())
                    .unwrap_or("")
                    .to_string();
                let entry = by_id.entry(id.clone()).or_insert_with(|| CatalogHook {
                    id,
                    command: hook
                        .get("command")
                        .and_then(|c| c.as_str())
                        .unwrap_or("")
                        .to_string(),
                    source_path: None,
                });
                if entry.source_path.is_none() && source.is_some() {
                    entry.source_path = source;
                }
            }
        }
    }
    let mut catalog: Vec<CatalogHook> = by_id.into_values().collect();
    catalog.sort_by(|a, b| a.id.cmp(&b.id));
    catalog
}

/// `findHook(id, root)`.
pub fn find_hook(id: &str, root: &Path) -> Option<CatalogHook> {
    build_catalog_hooks(root)
        .into_iter()
        .find(|hook| hook.id == id)
}
