//! `tama declare-root` on the command line: what it accepts, what it
//! prints, and the exit status it leaves.
//!
//! Split out of `declare_root/mod.rs`, which had grown past the
//! three-hundred-line limit; inspecting one root stays there.

use std::path::Path;

use crate::EXIT_USAGE;

use super::{inspect, junk_reason, RootReport};


pub fn print_usage() {
    eprintln!(
        "tama declare-root (--repo <path> | --tree <dir>) [...] [--apply] [--tidy] [--commit] [--push] [--json]

Declare a repository root to the audit when every file it holds is fixed
there by a tool: npm reads package.json from the root, cargo reads
Cargo.toml, git reads .gitignore, GitHub shows README.md, the release
tooling reads .wisent-release.json. Six such files already exceed the
five-files-per-folder rule, and no arrangement of folders can help.

The command refuses while the root still holds anything a person could
move, and names those files: they belong in a folder, not in a
declaration. Without --apply it reports what it would write. --tree walks
every Git checkout under a directory, so a whole workshop is one command,
and --commit (with --push) carries what it wrote into each repository's
history, because a declaration in a working tree is one the next clone
does not have. --tidy clears what a root should not carry at all - Finder
metadata, a build's own cache - deleting each file, dropping it from the
index when it was committed and naming it in .gitignore, because asking an
operator to delete the same two files in a hundred repositories is the
one-off repair this command exists to replace. The entry and its reasons
are appended to .tama/violations-ignore; an existing file is never
replaced. Exits 1 when a root was not declared."
    );
}

pub fn main(args: &[String]) -> i32 {
    let mut repos: Vec<String> = Vec::new();
    let mut trees: Vec<String> = Vec::new();
    let mut apply = false;
    let mut tidy = false;
    let mut json = false;
    let mut commit = false;
    let mut push = false;
    let mut index = 0;
    while index < args.len() {
        match args[index].as_str() {
            "--apply" => apply = true,
            "--tidy" => tidy = true,
            "--commit" => commit = true,
            "--push" => push = true,
            "--json" => json = true,
            "--repo" | "--tree" => {
                let Some(value) = args.get(index + 1).filter(|value| !value.is_empty()) else {
                    print_usage();
                    return EXIT_USAGE;
                };
                if args[index] == "--repo" {
                    repos.push(value.clone());
                } else {
                    trees.push(value.clone());
                }
                index += 1;
            }
            _ => {
                print_usage();
                return EXIT_USAGE;
            }
        }
        index += 1;
    }
    if repos.is_empty() && trees.is_empty() {
        print_usage();
        return EXIT_USAGE;
    }
    for target in repos.iter().chain(trees.iter()) {
        if !Path::new(target).is_dir() {
            eprintln!("repo not found: {target}");
            return EXIT_USAGE;
        }
    }
    let resolved = crate::repo_discovery::resolve_targets(&crate::repo_discovery::DiscoveryArgs {
        repos: &repos,
        trees: &trees,
        owners: &[],
        me: false,
        clone_dir: Path::new(""),
    });
    let mut reports = Vec::new();
    for target in &resolved.targets {
        // A repository that cannot be written, committed or pushed - a
        // branch with no upstream, a read-only checkout - is one finding,
        // not the end of a sweep over a workshop. It is reported as its
        // own undeclared root and the walk goes on.
        let report = match inspect(Path::new(&target.path), apply, tidy, commit, push) {
            Ok(report) => report,
            Err(message) => RootReport {
                repo: target.path.clone(),
                fixed: Vec::new(),
                movable: Vec::new(),
                junk: Vec::new(),
                declared: false,
                declaration: String::new(),
                reason: message,
                tidied: Vec::new(),
                revision: String::new(),
            },
        };
        reports.push(report);
    }
    let undeclared = reports.iter().filter(|report| !report.declared).count();
    if json {
        crate::write_json_line(&serde_json::to_string_pretty(&reports).unwrap_or_default());
    } else {
        for report in &reports {
            println!("{} — {}", report.repo, report.reason);
            if reports.len() > true as usize {
                continue;
            }
            for file in &report.fixed {
                println!("  {} — {}", file.name, file.fixed_by);
            }
            for name in &report.movable {
                println!("  {name} — move this into a folder");
            }
            for name in &report.junk {
                println!("  {name} — {}", junk_reason(name));
            }
        }
        println!(
            "{} root(s): {} declared, {undeclared} not",
            reports.len(),
            reports.len() - undeclared
        );
    }
    i32::from(undeclared > 0)
}
