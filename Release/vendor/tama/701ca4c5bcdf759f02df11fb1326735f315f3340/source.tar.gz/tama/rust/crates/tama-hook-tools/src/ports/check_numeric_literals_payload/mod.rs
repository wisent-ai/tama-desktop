//! Where `check_numeric_literals.py` (hook `block-numeric-literals`) finds the
//! text it scans.
//!
//! The hook scans the WHOLE post-edit content, not the diff, so an existing
//! literal cannot be edited around. That means reconstructing what the file will
//! say once the tool call lands: the replacement applied to the file on disk for
//! a string edit, the concatenation for an append, the added lines of a patch,
//! or one section per `[path#tag]` header for the hashline edit DSL.
//!
//! Where the Python would raise on a payload shape it cannot use, this raises
//! too — the same non-blocking exit 1, not a silent allow.

use regex::Regex;
use serde_json::Value;

use super::{pystr, python_stdlib, pyvalue};

/// `HASHLINE_HEADER` — a hashline section header and its four-hex snapshot tag.
const HASHLINE_HEADER: &str = "^\\[(?P<path>[^#\\]\\n]+)#[0-9A-Fa-f]{4}\\]\\s*$";
const PATH_GROUP: &str = "path";
const PLUS: &str = "+";
const PATCH_HEADER: &str = "+++";
const FILE_SCHEME: &str = "file";
/// `parsed.netloc not in ('','localhost')`.
const LOCAL_NETLOCS: &[&str] = &["", "localhost"];
const PATH_KEYS: &[&str] = &["file_path", "path"];
const DSL_KEYS: &[&str] = &["input", "patch"];
const OLD_KEY: &str = "old_string";
const NEW_KEY: &str = "new_string";
/// Python reports an uncaught `AttributeError`/`TypeError` as exit 1.
const CRASH_STATUS_TEXT: &str = "1";

pub fn crash() -> ! {
    eprintln!("check_numeric_literals: payload shape is not usable");
    std::process::exit(CRASH_STATUS_TEXT.parse().unwrap_or_default())
}

/// A value the Python goes on to treat as text. A falsy non-string is skipped
/// downstream by `not text`; a truthy one reaches `in text` and raises.
fn require_text(value: Option<&Value>) -> String {
    match value {
        None => String::new(),
        Some(Value::String(text)) => text.clone(),
        Some(other) if pyvalue::truthy(other) => crash(),
        Some(_) => String::new(),
    }
}

/// `a or b or ""` where the winner is then used as text.
fn first_truthy_text(input: &Value, keys: &[&str]) -> String {
    for key in keys {
        let Some(value) = input.get(key) else {
            continue;
        };
        if !pyvalue::truthy(value) {
            continue;
        }
        return require_text(Some(value));
    }
    String::new()
}

/// `e.get("new_string","")` feeding `str.join`, which refuses anything but a
/// string — `None` from an explicit JSON null included.
fn joinable_text(value: Option<&Value>) -> String {
    match value {
        None => String::new(),
        Some(Value::String(text)) => text.clone(),
        Some(_) => crash(),
    }
}

fn read_replacing(path: &str) -> Option<String> {
    let bytes = std::fs::read(path).ok()?;
    Some(String::from_utf8_lossy(&bytes).into_owned())
}

pub fn added_from_patch(patch: &str) -> String {
    pystr::splitlines(patch)
        .into_iter()
        .filter(|line| line.starts_with(PLUS) && !line.starts_with(PATCH_HEADER))
        .map(|line| line.strip_prefix(PLUS).unwrap_or(line))
        .collect::<Vec<&str>>()
        .join("\n")
}

/// One section per header, in first-seen order, holding that section's added
/// lines. A repeated header appends to the section it already opened.
pub fn hashline_sections(text: &str) -> Vec<(String, String)> {
    let header = Regex::new(HASHLINE_HEADER).unwrap();
    let mut sections: Vec<(String, Vec<&str>)> = Vec::new();
    let mut current: Option<String> = None;
    for line in pystr::splitlines(text) {
        if let Some(caps) = header.captures(pystr::strip(line)) {
            let found = caps
                .name(PATH_GROUP)
                .map(|hit| hit.as_str())
                .unwrap_or_default();
            let name = pystr::strip(found).to_string();
            if !sections.iter().any(|(known, _)| *known == name) {
                sections.push((name.clone(), Vec::new()));
            }
            current = Some(name);
            continue;
        }
        let Some(name) = current.as_deref() else {
            continue;
        };
        let Some(rest) = line.strip_prefix(PLUS) else {
            continue;
        };
        if let Some(section) = sections.iter_mut().find(|(known, _)| known == name) {
            section.1.push(rest);
        }
    }
    sections
        .into_iter()
        .map(|(name, lines)| (name, lines.join("\n")))
        .collect()
}

/// `cur.replace(old,new,1) if old else cur+"\n"+new`, and any failure inside the
/// attempt yields the replacement text alone.
fn apply_single_edit(path: &str, old: Option<&Value>, new: Option<&Value>) -> String {
    let Some(current) = read_replacing(path) else {
        return require_text(new);
    };
    let Some(new_text) = new.and_then(Value::as_str) else {
        return require_text(new);
    };
    if old.map(pyvalue::truthy).unwrap_or_default() {
        let Some(old_text) = old.and_then(Value::as_str) else {
            return require_text(new);
        };
        return current.replacen(old_text, new_text, python_stdlib::one());
    }
    format!("{current}\n{new_text}")
}

/// The multi-edit replay. `None` is the Python's `except Exception: pass`, which
/// falls through to joining the replacements instead.
fn apply_edits(path: &str, edits: &[Value]) -> Option<String> {
    let mut current = read_replacing(path)?;
    for edit in edits {
        if !edit.is_object() {
            return None;
        }
        let old = edit.get(OLD_KEY);
        let new_text = match edit.get(NEW_KEY) {
            None => "",
            Some(value) => value.as_str()?,
        };
        if old.map(pyvalue::truthy).unwrap_or_default() {
            current =
                current.replacen(old.and_then(Value::as_str)?, new_text, python_stdlib::one());
            continue;
        }
        current = format!("{current}\n{new_text}");
    }
    Some(current)
}

fn join_new_strings(edits: &[Value]) -> String {
    let mut parts = Vec::new();
    for edit in edits {
        if !edit.is_object() {
            crash();
        }
        parts.push(joinable_text(edit.get(NEW_KEY)));
    }
    parts.join("\n")
}

/// The file as it will read after the call.
pub fn post_edit_text(input: &Value) -> String {
    let content = input.get("content");
    if content.map(pyvalue::truthy).unwrap_or_default() {
        return require_text(content);
    }
    let path = first_truthy_text(input, PATH_KEYS);
    let old = input.get(OLD_KEY);
    let new = input.get(NEW_KEY);
    let has_new = new.map(|value| !value.is_null()).unwrap_or_default();
    let exists = !path.is_empty() && std::path::Path::new(&path).exists();
    if has_new && exists {
        return apply_single_edit(&path, old, new);
    }
    if has_new {
        return require_text(new);
    }
    let Some(edits) = input.get("edits").and_then(Value::as_array) else {
        let patch = input.get("patch");
        if patch.map(pyvalue::truthy).unwrap_or_default() {
            return added_from_patch(&require_text(patch));
        }
        return String::new();
    };
    if exists {
        if let Some(replayed) = apply_edits(&path, edits) {
            return replayed;
        }
    }
    join_new_strings(edits)
}

/// The hashline DSL wins when it parses; otherwise the single edited path.
pub fn path_texts(input: &Value) -> Vec<(String, String)> {
    let dsl = first_truthy_text(input, DSL_KEYS);
    let sections = hashline_sections(&dsl);
    if !sections.is_empty() {
        return sections;
    }
    let path = first_truthy_text(input, PATH_KEYS);
    if path.is_empty() {
        return Vec::new();
    }
    vec![(path, post_edit_text(input))]
}

/// A bare path is itself; a `file:` URL on this host is its decoded path;
/// anything else is not a local file and is not scanned.
pub fn local_file_path(path: &str) -> Option<String> {
    let (scheme, netloc, url_path) = python_stdlib::urlsplit_parts(path);
    if scheme.is_empty() {
        return Some(path.to_string());
    }
    if scheme != FILE_SCHEME || !LOCAL_NETLOCS.contains(&netloc.as_str()) {
        return None;
    }
    Some(python_stdlib::unquote(&url_path))
}
