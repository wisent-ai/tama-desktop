//! How an operator says the agent got it wrong, declared once.
//!
//! The frustration detector, the adaptive bridge's base pattern and its
//! narrower explicit-correction pattern each carried their own copy of the
//! same words, and the shell script they replaced carried a fourth. One
//! reader learning a new phrasing left the others deaf to it.
//!
//! The declaration lives in `vocabulary.json` beside this module. Each
//! reader asks for the pattern it needs and passes the whitespace token its
//! own engine speaks — `\s` for the bridge's minimal engine, `[[:space:]]`
//! for the POSIX-class one the hook uses — so the two compile to the same
//! meaning without sharing a spelling.

const DECLARED: &str = include_str!("vocabulary.json");

fn group(key: &str) -> Vec<String> {
    let document: serde_json::Value =
        serde_json::from_str(DECLARED).expect("vocabulary.json beside this module is valid JSON");
    document[key]
        .as_array()
        .unwrap_or_else(|| panic!("vocabulary.json declares no {key} array"))
        .iter()
        .filter_map(|word| word.as_str().map(str::to_owned))
        .collect()
}

fn branch(key: &str, space: &str) -> String {
    group(key).join("|").replace("\\s", space)
}

/// Everything that reads as irritation or a correction: what the detector
/// asks for.
pub fn correction_pattern(space: &str) -> String {
    format!(
        "\\b(stop{space}+({stop})|don.?t{space}+({dont})|never{space}+({never})\
         |i{space}+({dislikes}|{told})|{outbursts}|{accusations})\\b",
        space = space,
        stop = branch("stop_verbs", space),
        dont = branch("dont_verbs", space),
        never = branch("never_verbs", space),
        dislikes = branch("dislikes", space),
        told = branch("told_you", space),
        outbursts = branch("outbursts", space),
        accusations = branch("accusations", space),
    )
}

/// Only the phrasings that are a correction of something already said — the
/// bridge attributes a rule to these, and irritation alone is not enough.
pub fn explicit_correction_pattern(space: &str) -> String {
    format!(
        "\\b(stop{space}+({stop})|don.?t{space}+({dont})|never{space}+({never})\
         |i{space}+({told})|how{space}+many{space}+times|that.?s{space}+not{space}+what\
         |i{space}+didn.?t{space}+ask|not{space}+what{space}+i{space}+(asked|wanted)\
         |stop{space}+asking)\\b",
        space = space,
        stop = branch("stop_verbs", space),
        dont = branch("dont_verbs", space),
        never = branch("never_verbs", space),
        told = branch("told_you", space),
    )
}

/// The Polish phrasings, as their own patterns: each is a prefix, so
/// inflected forms match without listing them.
pub fn polish_patterns(space: &str) -> Vec<String> {
    group("polish")
        .into_iter()
        .map(|pattern| pattern.replace("\\s", space))
        .collect()
}

#[cfg(test)]
mod tests {
    use super::{correction_pattern, explicit_correction_pattern, polish_patterns};

    #[test]
    fn the_pattern_speaks_the_engines_whitespace() {
        let posix = correction_pattern("[[:space:]]");
        assert!(!posix.contains("\\s"), "{posix}");
        let minimal = correction_pattern("\\s");
        assert!(minimal.contains("\\s"), "{minimal}");
    }

    /// Irritation is a correction; the narrower pattern keeps only the
    /// phrasings that correct something already said.
    #[test]
    fn the_explicit_pattern_is_narrower_than_the_full_one() {
        let full = correction_pattern("\\s");
        let explicit = explicit_correction_pattern("\\s");
        assert!(full.len() > explicit.len(), "{explicit}");
        assert!(full.contains("bullshit"), "{full}");
        assert!(!explicit.contains("bullshit"), "{explicit}");
    }

    #[test]
    fn every_polish_phrasing_is_its_own_pattern() {
        let patterns = polish_patterns("\\s");
        assert!(
            patterns.len() > "10".parse::<usize>().unwrap(),
            "{patterns:?}"
        );
        assert!(patterns.iter().all(|pattern| pattern.starts_with("\\b")));
    }
}
