//! Recording identity and frame-Read counting for the
//! `check-failure-inspection` port of `shared-hooks/check_failure_inspection.py`.
//!
//! Ports `latest_recording_sha8()`, `count_distinct_frame_reads()` and
//! `session_has_frame_or_failure_read()`.
//!
//! Two pieces of the Python are deliberately absent because nothing calls
//! them: `recording_duration_seconds()` (the v7 ffprobe gate, dead since v8
//! switched to a fixed frame count, along with its `FFPROBE_TIMEOUT_S`) and
//! the unused `rec_mt = rec_path.stat().st_mtime` line inside
//! `count_distinct_frame_reads`.

use super::check_failure_inspection_labels::recording_roots;
use super::check_failure_inspection_transcript::{glob_match, read_file_paths, Transcript};
use crate::util::sha256_hex;
use regex::Regex;
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::time::SystemTime;

/// `count_distinct_frame_reads(lookback=400)`.
const FRAME_LOOKBACK_TEXT: &str = "400";
/// `h.hexdigest()[:8]`.
const SHA8_LEN_TEXT: &str = "8";
/// `CHECK_FAILURE_MIN_FRAMES` default in `session_has_frame_or_failure_read`.
const MIN_FRAMES_TEXT: &str = "3";
const MIN_FRAMES_VAR: &str = "CHECK_FAILURE_MIN_FRAMES";
const WEBM_SUFFIX: &str = ".webm";
const NO_PREFIX: &str = "";

fn frame_lookback() -> usize {
    FRAME_LOOKBACK_TEXT.parse().unwrap_or_default()
}

fn sha8_len() -> usize {
    SHA8_LEN_TEXT.parse().unwrap_or_default()
}

/// A non-numeric `CHECK_FAILURE_MIN_FRAMES` raises in the Python, which aborts
/// the hook without a decision; here it degrades to a requirement of zero,
/// which likewise lets the turn through.
fn min_frames() -> usize {
    std::env::var(MIN_FRAMES_VAR)
        .unwrap_or_else(|_| MIN_FRAMES_TEXT.to_string())
        .parse()
        .unwrap_or_default()
}

/// The newest `*.webm` filed under either `recordings/<label>/` root, with the
/// first eight hex characters of its SHA-256.
pub fn latest_recording_sha8(cwd: &Path, label: &str) -> Option<(String, PathBuf)> {
    let mut latest: Option<(SystemTime, PathBuf)> = None;
    for base in recording_roots(cwd) {
        let mut candidates: Vec<PathBuf> = match std::fs::read_dir(base.join(label)) {
            Ok(entries) => entries
                .flatten()
                .filter(|entry| {
                    glob_match(&entry.file_name().to_string_lossy(), NO_PREFIX, WEBM_SUFFIX)
                })
                .map(|entry| entry.path())
                .collect(),
            Err(_) => Vec::new(),
        };
        candidates.sort();
        for candidate in candidates {
            let Ok(modified) = candidate.metadata().and_then(|meta| meta.modified()) else {
                continue;
            };
            // `max()` keeps the first of equal keys, so only a strictly newer
            // file replaces the incumbent.
            let newer = match latest.as_ref() {
                Some((best, _)) => modified > *best,
                None => true,
            };
            if newer {
                latest = Some((modified, candidate));
            }
        }
    }
    let (_, path) = latest?;
    let digest = sha256_hex(&std::fs::read(&path).ok()?);
    Some((digest.chars().take(sha8_len()).collect(), path))
}

/// `count_distinct_frame_reads()`: distinct `frame_<sha8>_*` / legacy
/// `failure_state_<sha8>*` artifact paths Read in this turn.
///
/// The Python's old `abs(frame_mtime - rec_mtime) <= 2.0` coupling is gone
/// there and gone here: the sha8 in the filename already pins the Read to this
/// recording.
pub fn count_distinct_frame_reads(transcript: &Transcript, label: &str, sha8: &str) -> usize {
    let pattern = super::failure_artefacts::any_frame_pattern(label, sha8);
    let Ok(artifact) = Regex::new(&pattern) else {
        return usize::MIN;
    };
    let mut seen: Vec<String> = read_file_paths(transcript.tail(frame_lookback()))
        .into_iter()
        .filter(|path| artifact.is_match(path))
        .collect();
    seen.sort();
    seen.dedup();
    seen.len()
}

/// `session_has_frame_or_failure_read()`: `(ok, distinct_reads, required)`.
pub fn frame_reads_satisfied(
    transcript: &Transcript,
    label: &str,
    sha8: &str,
) -> (bool, usize, usize) {
    let required = min_frames();
    let distinct = count_distinct_frame_reads(transcript, label, sha8);
    (distinct >= required, distinct, required)
}

/// Memo over `latest_recording_sha8`.
///
/// The Python re-hashes the same `*.webm` once per referenced label, once per
/// sibling probe and once more per verdict. Nothing in the run can change the
/// recordings directory, so one hash per label yields the same answers for a
/// fraction of the work.
pub struct Recordings {
    cwd: PathBuf,
    known: HashMap<String, Option<(String, PathBuf)>>,
}

impl Recordings {
    pub fn new(cwd: &Path) -> Self {
        Self {
            cwd: cwd.to_path_buf(),
            known: HashMap::new(),
        }
    }

    pub fn latest(&mut self, label: &str) -> Option<(String, PathBuf)> {
        if let Some(known) = self.known.get(label) {
            return known.clone();
        }
        let found = latest_recording_sha8(&self.cwd, label);
        self.known.insert(label.to_string(), found.clone());
        found
    }
}
