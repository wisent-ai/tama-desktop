//! Label discovery and expansion for the `check-failure-inspection` port of
//! `shared-hooks/check_failure_inspection.py`.
//!
//! Ports `discover_all_labels()`, `session_log_reads_imply_labels()` and the
//! sibling-expansion block of `main()`.
//!
//! Both Python discovery functions return `list(set)`, whose order is
//! randomized per process by string hash seeding. The ports return the same
//! members sorted, which removes run-to-run variance the Python never relied
//! on: the order only decides which of several equally-matching siblings is
//! probed first.

use super::check_failure_inspection_claim::{label_tokens, ClaimMatcher};
use super::check_failure_inspection_recording::Recordings;
use super::check_failure_inspection_transcript::{
    glob_match, read_file_paths, since_last_user, Transcript,
};
use super::check_failure_inspection_wsession::resolve_wsession_label;
use regex::Regex;
use serde_json::Value;
use std::collections::BTreeSet;
use std::path::{Path, PathBuf};

/// `session_log_reads_imply_labels(lookback=120)`.
const LOG_LOOKBACK_TEXT: &str = "120";

const WORK_LABEL_PATTERN: &str = r"\.weles/runs/([^/]+)/";
const RECORDING_LABEL_PATTERN: &str = r"recordings/([^/]+)/";
const SURVEY_RUN_PATTERN: &str = r"avatar-survey/data/run_([a-z]+)_";
/// Python's non-multiline `$` also matches before one trailing newline; Rust's
/// `$` is end-of-text only and the crate has no lookahead, so every ported `$`
/// is written `\n?\z`. The optional newline sits after group 1, so captures are
/// unaffected.
const SURVEY_JSON_PATTERN: &str = r"avatar-survey/data/([a-z_]+)\.json\n?\z";

const PLATFORM_CODES: &[(&str, &str)] = &[
    ("li", "linkedin"),
    ("ig", "instagram"),
    ("tt", "tiktok"),
    ("tw", "twitter"),
    ("rd", "reddit"),
    ("yt", "youtube"),
];
const SURVEY_JSON_SKIP: &[&str] = &["data", "config"];

const WEBM_SUFFIX: &str = ".webm";
const PNG_SUFFIX: &str = ".png";
const FRAME_PREFIX: &str = "frame_";
const FAILURE_STATE_PREFIX: &str = "failure_state_";
const NO_PREFIX: &str = "";

fn log_lookback() -> usize {
    LOG_LOOKBACK_TEXT.parse().unwrap_or_default()
}

/// The `recordings/<label>/` roots `discover_all_labels` and
/// `latest_recording_sha8` both scan, in the Python's order.
pub fn recording_roots(cwd: &Path) -> Vec<PathBuf> {
    vec![
        cwd.parent().unwrap_or(cwd).join("weles").join("recordings"),
        cwd.join("recordings"),
    ]
}

/// `discover_all_labels()`.
pub fn discover_all_labels(home: &Path, cwd: &Path) -> Vec<String> {
    let mut labels: BTreeSet<String> = BTreeSet::new();
    let state = home
        .join(".shared-hooks")
        .join("state")
        .join("trajectory_runs.json");
    if state.is_file() {
        if let Some(runs) = std::fs::read_to_string(&state)
            .ok()
            .and_then(|text| serde_json::from_str::<Value>(&text).ok())
            .as_ref()
            .and_then(Value::as_object)
        {
            for key in runs.keys() {
                labels.insert(key.rsplit('/').next().unwrap_or(key).to_string());
            }
        }
    }
    for base in recording_roots(cwd) {
        for entry in subdirectories(&base) {
            if dir_contains(&entry, NO_PREFIX, WEBM_SUFFIX) {
                labels.insert(file_name(&entry));
            }
        }
    }
    for entry in subdirectories(&crate::evidence::evidence_root()) {
        if dir_contains(&entry, FRAME_PREFIX, PNG_SUFFIX)
            || dir_contains(&entry, FAILURE_STATE_PREFIX, PNG_SUFFIX)
        {
            labels.insert(file_name(&entry));
        }
    }
    labels.into_iter().collect()
}

/// `session_log_reads_imply_labels()`: labels implied by the frame Reads this
/// turn already performed.
pub fn reads_imply_labels(transcript: &Transcript) -> Vec<String> {
    let work = Regex::new(WORK_LABEL_PATTERN).expect("work label pattern");
    let recording = Regex::new(RECORDING_LABEL_PATTERN).expect("recording label pattern");
    let survey_run = Regex::new(SURVEY_RUN_PATTERN).expect("survey run pattern");
    let survey_json = Regex::new(SURVEY_JSON_PATTERN).expect("survey json pattern");

    let mut labels: BTreeSet<String> = BTreeSet::new();
    for path in read_file_paths(since_last_user(transcript, log_lookback())) {
        if let Some(found) = captured(&work, &path) {
            labels.insert(found);
        }
        if let Some(found) = captured(&recording, &path) {
            labels.insert(found);
        }
        if let Some(code) = captured(&survey_run, &path) {
            let platform = PLATFORM_CODES
                .iter()
                .find(|(short, _)| *short == code)
                .map(|(_, full)| (*full).to_string())
                .unwrap_or(code);
            labels.insert(format!("{platform}_avatar_survey"));
            labels.insert(format!("{platform}_scrape"));
        }
        if let Some(stem) = captured(&survey_json, &path) {
            if !SURVEY_JSON_SKIP.contains(&stem.as_str()) {
                labels.insert(format!("{stem}_avatar_survey"));
            }
        }
    }
    labels.into_iter().collect()
}

fn captured(pattern: &Regex, text: &str) -> Option<String> {
    pattern
        .captures(text)?
        .get(FIRST_GROUP)
        .map(|group| group.as_str().to_string())
}

/// `m.group(1)`: group 0 is the whole match.
const FIRST_GROUP: usize = "g".len();

fn subdirectories(base: &Path) -> Vec<PathBuf> {
    let Ok(entries) = std::fs::read_dir(base) else {
        return Vec::new();
    };
    let mut found: Vec<PathBuf> = entries
        .flatten()
        .map(|entry| entry.path())
        .filter(|path| path.is_dir())
        .collect();
    found.sort();
    found
}

/// Python's `any(d.glob("<prefix>*<suffix>"))`.
fn dir_contains(dir: &Path, prefix: &str, suffix: &str) -> bool {
    let Ok(entries) = std::fs::read_dir(dir) else {
        return false;
    };
    entries
        .flatten()
        .any(|entry| glob_match(&entry.file_name().to_string_lossy(), prefix, suffix))
}

fn file_name(path: &Path) -> String {
    path.file_name()
        .unwrap_or_default()
        .to_string_lossy()
        .to_string()
}

/// Sibling expansion only considers tokens of at least four characters.
const SIBLING_TOKEN_LEN_TEXT: &str = "4";

fn sibling_token_len() -> usize {
    SIBLING_TOKEN_LEN_TEXT.parse().unwrap_or_default()
}

/// The labels the verdict is judged against: those the response claims failure
/// about, those this turn's frame Reads imply, and — for a label with no
/// recording of its own — the run it actually names.
///
/// Same precedence as `check_visual_claims`: source-level resolution via
/// `WSession.start({label})`, else the most-recent token-overlapping sibling.
pub fn referenced_labels(
    home: &Path,
    cwd: &Path,
    transcript: &Transcript,
    matcher: &ClaimMatcher,
    response: &str,
    recordings: &mut Recordings,
) -> Vec<String> {
    let labels = discover_all_labels(home, cwd);
    let mut referenced: Vec<String> = labels
        .iter()
        .filter(|label| matcher.label_in_response(label, response))
        .cloned()
        .collect();
    for implied in reads_imply_labels(transcript) {
        if !referenced.contains(&implied) {
            referenced.push(implied);
        }
    }

    let parent = cwd.parent().unwrap_or(cwd);
    let search_roots = vec![
        cwd.to_path_buf(),
        crate::evidence::evidence_root(),
        parent.join("weles").join("scripts"),
        parent.join("weles").join("src"),
    ];
    let mut expanded = referenced.clone();
    for label in &referenced {
        if recordings.latest(label).is_some() {
            continue;
        }
        if let Some(aliased) = resolve_wsession_label(label, &search_roots) {
            if !expanded.contains(&aliased) && recordings.latest(&aliased).is_some() {
                expanded.push(aliased);
                continue;
            }
        }
        if let Some(sibling) = newest_sibling(label, &labels, &expanded, recordings) {
            expanded.push(sibling);
        }
    }
    expanded
}

/// The most recently recorded label that shares a long token with `label`.
fn newest_sibling(
    label: &str,
    labels: &[String],
    expanded: &[String],
    recordings: &mut Recordings,
) -> Option<String> {
    let wanted = long_tokens(label);
    if wanted.is_empty() {
        return None;
    }
    let mut best: Option<(std::time::SystemTime, String)> = None;
    for other in labels {
        if other == label || expanded.contains(other) {
            continue;
        }
        if long_tokens(other).is_disjoint(&wanted) {
            continue;
        }
        let Some((_, recording)) = recordings.latest(other) else {
            continue;
        };
        let Ok(modified) = recording.metadata().and_then(|meta| meta.modified()) else {
            continue;
        };
        let newer = match best.as_ref() {
            Some((incumbent, _)) => modified > *incumbent,
            None => true,
        };
        if newer {
            best = Some((modified, other.clone()));
        }
    }
    best.map(|(_, sibling)| sibling)
}

fn long_tokens(label: &str) -> BTreeSet<String> {
    label_tokens(label)
        .into_iter()
        .filter(|token| token.chars().count() >= sibling_token_len())
        .collect()
}
