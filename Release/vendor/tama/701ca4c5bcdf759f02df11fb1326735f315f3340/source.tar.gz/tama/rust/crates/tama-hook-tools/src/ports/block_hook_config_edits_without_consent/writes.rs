//! Whether command text can change a byte of a protected file.
//!
//! Three questions, and they are deliberately not one regex over the whole
//! text:
//!
//!   * a verb in a position where it can act — quoted text is an argument, so
//!     `grep "install" .` and `grep "cp" .` change nothing;
//!   * a language write call, matched against the raw text, because in code a
//!     quote is syntax and the mode of an `open` call lives inside one;
//!   * a stream aimed at a protected file, which `2>/dev/null` is not.
//!
//! Measured on 2026-09-10 against the coarse single regex: a recursive search
//! over the live hook root was refused for sending its errors to the null
//! device, and a search whose quoted pattern listed mutation words was refused
//! for quoting them. Both are read-only.

use super::super::block_hook_config_edits_without_consent_patterns::Patterns;
use crate::ports::shell_text::effective_command;

const TARGET_GROUP: &str = "target";
const QUOTE_TRIM: &[char] = &['"', '\''];

/// Whether a stream is aimed at a hook, rather than merely redirected.
fn redirection_targets_protected(
    patterns: &Patterns,
    text: &str,
    protected: &impl Fn(&str) -> bool,
) -> bool {
    let normalized = text.replace('\\', "/");
    patterns
        .redirection
        .captures_iter(&normalized)
        .filter_map(|caps| caps.name(TARGET_GROUP))
        .map(|found| found.as_str().trim_matches(QUOTE_TRIM))
        .any(|target| !target.is_empty() && protected(target))
}

/// Whether this text writes something protected.
pub(crate) fn writes_to_protected_path(
    patterns: &Patterns,
    text: &str,
    protected: &impl Fn(&str) -> bool,
) -> bool {
    redirection_targets_protected(patterns, text, protected)
        || patterns.write_api.is_match(text)
        || patterns.write_verb.is_match(&effective_command(text))
}

#[cfg(test)]
mod tests {
    use super::writes_to_protected_path;
    use crate::ports::block_hook_config_edits_without_consent_patterns::Patterns;
    use crate::ports::shell_text::effective_command;

    fn under_the_live_root(path: &str) -> bool {
        path.contains(".shared-hooks")
    }

    #[test]
    fn a_search_that_discards_its_errors_is_not_a_write() {
        let patterns = Patterns::compile();
        let command = "grep -rln clipboard \"$HOME/.shared-hooks\" 2>/dev/null | head -8";
        assert!(!writes_to_protected_path(
            &patterns,
            command,
            &under_the_live_root
        ));
    }

    #[test]
    fn a_search_whose_pattern_lists_mutation_words_is_not_a_write() {
        let patterns = Patterns::compile();
        let command =
            "grep -rn \"copy\\|install\\|write\\|sync\" \"$HOME/.shared-hooks/registry.json\"";
        assert!(!writes_to_protected_path(
            &patterns,
            command,
            &under_the_live_root
        ));
    }

    #[test]
    fn a_copy_onto_a_live_hook_is_a_write() {
        let patterns = Patterns::compile();
        let command = "cp candidate.sh \"$HOME/.shared-hooks/block_browser_usage.sh\"";
        assert!(writes_to_protected_path(
            &patterns,
            command,
            &under_the_live_root
        ));
    }

    #[test]
    fn a_redirection_into_a_live_hook_is_a_write() {
        let patterns = Patterns::compile();
        let command = "printf 'x' > \"$HOME/.shared-hooks/registry.json\"";
        assert!(writes_to_protected_path(
            &patterns,
            command,
            &under_the_live_root
        ));
    }

    /// The one place quoted text runs, so the quoted program is unwrapped and
    /// judged as a command instead of being dropped with the rest.
    #[test]
    fn a_copy_smuggled_into_an_interpreter_argument_is_a_write() {
        let patterns = Patterns::compile();
        let command = "bash -lc 'cp candidate.sh \"$HOME/.shared-hooks/x.sh\"'";
        let effective = effective_command(command);
        assert!(effective.contains("cp"), "{effective}");
        assert!(writes_to_protected_path(
            &patterns,
            command,
            &under_the_live_root
        ));
    }
}
