//! The operator's standing rules, read from Oko's ledger.
//!
//! A rule the operator gives lives in the transcript of the session it was
//! given in. The next session starts without it, and the operator says it
//! again, less patiently. Oko's ledger tells standing rules apart from turn
//! orders; this asks it for the rules of the last week, in the operator's
//! own words, with the session and message each came from.
//!
//! Turn orders such as "nie koduj" are deliberately not here: a "do not code"
//! that followed an agent into every session would freeze every agent.

use std::io::Read;
use std::process::{Command, Stdio};
use std::time::{Duration, Instant};

use serde_json::Value;
use tama_hooks::sha256::sha256_hex;

/// A week: long enough to cover the sessions an operator still has open.
const RULE_WINDOW_HOURS: &str = "168";
/// Claude Code caps SessionStart context at ten thousand characters and
/// replaces anything longer with a file, silently. Stay well under it.
const CONTEXT_CHARS: usize = 8000;
/// Leave time for a structured refusal before the registered ten-second hook deadline.
const OKO_READ_TIMEOUT: Duration = Duration::from_secs(8);

pub struct Rule {
    pub session: String,
    pub ordinal: i64,
    pub at: String,
    pub text: String,
}

pub(super) fn oko_cli() -> String {
    std::env::var("TAMA_OKO_CLI")
        .ok()
        .filter(|value| !value.is_empty())
        .unwrap_or_else(|| "oko-cli".to_string())
}

fn read_oko(args: &[&str]) -> Result<Value, String> {
    let program = oko_cli();
    let mut command = Command::new(&program);
    command
        .args(args)
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped());
    if let Ok(database) = std::env::var("OKO_TRANSCRIPT_INDEX_PATH") {
        if !database.is_empty() {
            command.args(["--db", &database]);
        }
    }
    let operation = format!("{command:?}");
    let mut child = command
        .spawn()
        .map_err(|error| format!("cannot run {operation}: {error}"))?;
    let mut stdout = child
        .stdout
        .take()
        .expect("stdout was configured as a pipe");
    let mut stderr = child
        .stderr
        .take()
        .expect("stderr was configured as a pipe");
    std::thread::scope(|scope| {
        let output = scope.spawn(|| {
            let mut bytes = Vec::new();
            stdout.read_to_end(&mut bytes).map(|_| bytes)
        });
        let errors = scope.spawn(|| {
            let mut bytes = Vec::new();
            stderr.read_to_end(&mut bytes).map(|_| bytes)
        });
        let started = Instant::now();
        let status = loop {
            match child.try_wait() {
                Ok(Some(status)) => break status,
                Ok(None) if started.elapsed() < OKO_READ_TIMEOUT => {
                    std::thread::sleep(Duration::from_millis(5));
                }
                result => {
                    let _ = child.kill();
                    let _ = child.wait();
                    return Err(match result {
                        Err(error) => format!("cannot observe {operation}: {error}"),
                        _ => format!("{operation} did not finish within {OKO_READ_TIMEOUT:?}; no task reading was accepted"),
                    });
                }
            }
        };
        let output = output
            .join()
            .map_err(|_| format!("cannot collect stdout from {operation}"))?
            .map_err(|error| format!("cannot read stdout from {operation}: {error}"))?;
        let errors = errors
            .join()
            .map_err(|_| format!("cannot collect stderr from {operation}"))?
            .map_err(|error| format!("cannot read stderr from {operation}: {error}"))?;
        if !status.success() {
            return Err(format!(
                "{operation} exited with {status}: {}",
                String::from_utf8_lossy(&errors)
            ));
        }
        serde_json::from_slice(&output).map_err(|error| {
            format!(
                "{operation} returned invalid JSON: {error}; output: {}",
                String::from_utf8_lossy(&output)
            )
        })
    })
}

pub struct TaskLedger {
    pub value: Value,
    pub digest: String,
}

/// Oko owns task classification, evidence and verdict precedence. This reader
/// preserves its report instead of implementing a second task list in Tama.
pub fn task_ledger(session: &str) -> Result<TaskLedger, String> {
    let mut report = read_oko(&[
        "transcripts",
        "tasks",
        "--session",
        session,
        "--read-only",
        "--json",
    ])?;
    let reports = report
        .as_array_mut()
        .ok_or("Oko's task report is not a session array")?;
    if reports.len() != 1 {
        return Err(format!(
            "Oko returned {} sessions for the exact session {session}",
            reports.len()
        ));
    }
    let value = reports.remove(0);
    if value.get("sessionId").and_then(Value::as_str) != Some(session)
        || !value.get("tasks").is_some_and(Value::is_array)
        || !value.get("operatorMessages").is_some_and(Value::is_u64)
    {
        return Err(format!(
            "Oko did not return a valid task ledger for session {session}"
        ));
    }
    let mut identity = std::env::var("OKO_TRANSCRIPT_INDEX_PATH")
        .unwrap_or_default()
        .into_bytes();
    identity.push(0);
    serde_json::to_writer(&mut identity, &value).map_err(|error| error.to_string())?;
    Ok(TaskLedger {
        digest: sha256_hex(&identity),
        value,
    })
}

/// The rules, newest first. The error names why they could not be read,
/// because a session that starts without them has to know it did.
pub fn standing_rules() -> Result<Vec<Rule>, String> {
    let rules = read_oko(&[
        "transcripts",
        "rules",
        "--open",
        "--hours",
        RULE_WINDOW_HOURS,
        "--json",
    ])?;
    let mut out: Vec<Rule> = rules
        .as_array()
        .map(|rules| {
            rules
                .iter()
                .map(|rule| Rule {
                    session: rule
                        .get("sessionId")
                        .and_then(Value::as_str)
                        .unwrap_or("?")
                        .to_string(),
                    ordinal: rule
                        .get("ordinal")
                        .and_then(Value::as_i64)
                        .unwrap_or_default(),
                    at: rule
                        .get("at")
                        .and_then(Value::as_str)
                        .unwrap_or("")
                        .to_string(),
                    text: rule
                        .get("text")
                        .and_then(Value::as_str)
                        .unwrap_or("")
                        .to_string(),
                })
                .collect()
        })
        .unwrap_or_default();
    out.reverse();
    Ok(out)
}

/// The rules as one block of text an agent reads, bounded for a hook's
/// context and honest about what it left out.
pub fn rules_text(rules: &[Rule]) -> String {
    let mut out = String::from(
        "# Operator's standing rules (Oko ledger, last 7 days). These bind this session.\n",
    );
    for rule in rules {
        let line = format!(
            "- {} ({} #{}): {}\n",
            rule.at,
            short(&rule.session),
            rule.ordinal,
            rule.text.replace('\n', " ")
        );
        if out.len() + line.len() > CONTEXT_CHARS {
            out.push_str(
                "- (older rules omitted: run `oko-cli transcripts rules --open --hours 168`)\n",
            );
            break;
        }
        out.push_str(&line);
    }
    out
}

/// What `assignment show` and the hook print when the rules cannot be read.
pub fn rules_or_reason() -> String {
    match standing_rules() {
        Ok(rules) if rules.is_empty() => {
            "# Operator's standing rules: none recorded in the last 7 days.\n".to_string()
        }
        Ok(rules) => rules_text(&rules),
        Err(reason) => {
            format!("# Operator's standing rules are unavailable in this session: {reason}\n")
        }
    }
}

fn short(session: &str) -> &str {
    let key = session.rsplit('_').next().unwrap_or(session);
    let end = key
        .char_indices()
        .nth("01a0870f".len())
        .map(|(index, _)| index)
        .unwrap_or(key.len());
    &key[..end]
}
