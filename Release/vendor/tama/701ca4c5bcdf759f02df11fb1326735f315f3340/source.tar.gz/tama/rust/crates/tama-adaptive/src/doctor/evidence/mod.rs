//! Port of `src/adaptive/doctor/evidence.mjs`: validated immutable evidence
//! projection for the doctor queue and repair commands.

mod dates;
mod lake;
mod segment;

use dates::{ordered_float, parse_date_ms};
use lake::read_lake_evidence;
use segment::validated_segment;

use std::fs;
use std::path::Path;

use crate::util::{home_dir, shell_words};

const SEGMENT_PROTOCOL: &str = "hooks-telemetry-segment-v1";
const EVIDENCE_TYPES: [&str; 3] = ["repair_proposal", "corpus_add", "corpus_label"];

/// `liveScriptPath(command)` — first shell word ending in `.py`/`.sh`/`.mjs`
/// after `~`/`$HOME` expansion.
pub fn live_script_path(command: &str) -> Option<String> {
    let home = home_dir().to_string_lossy().to_string();
    for word in shell_words(command) {
        let token = expand_home_word(&word, &home);
        if token.ends_with(".py") || token.ends_with(".sh") || token.ends_with(".mjs") {
            return Some(token);
        }
    }
    None
}

fn expand_home_word(word: &str, home: &str) -> String {
    let chars: Vec<char> = word.chars().collect();
    let mut out = String::with_capacity(word.len());
    let mut index = 0;
    while index < chars.len() {
        let c = chars[index];
        if c == '~' && (index + 1 == chars.len() || chars[index + 1] == '/') {
            out.push_str(home);
            index += 1;
        } else if c == '$' && chars[index..].starts_with(&['$', 'H', 'O', 'M', 'E']) {
            out.push_str(home);
            index += 5;
        } else {
            out.push(c);
            index += 1;
        }
    }
    out
}

/// `object(text)` — strict object parse; errors propagate like the JS throw.
pub(super) fn object(text: &str) -> Result<serde_json::Value, String> {
    let value: serde_json::Value =
        serde_json::from_str(text).map_err(|e| format!("SyntaxError: {}", e))?;
    if value.is_object() {
        Ok(value)
    } else {
        Ok(serde_json::Value::Null)
    }
}

pub(super) enum Canon {
    /// `false` in JS — the whole segment is invalid.
    Invalid,
    /// `null` in JS — the row carries no evidence, skip it.
    Skip,
    Row(serde_json::Value),
}

fn is_integer(value: &serde_json::Value) -> bool {
    match value {
        serde_json::Value::Number(n) => {
            n.as_i64().is_some()
                || n.as_f64()
                    .map(|f| f.is_finite() && f.fract() == 0.0)
                    .unwrap_or(false)
        }
        _ => false,
    }
}

fn is_finite_number(value: &serde_json::Value) -> bool {
    value.as_f64().map(|f| f.is_finite()).unwrap_or(false)
}

/// `canonicalEvidence(row, segmentId)`.
pub(super) fn canonical_evidence(row: &serde_json::Value, segment_id: &str) -> Canon {
    if row.get("runtime").and_then(|v| v.as_str()) != Some("hooks")
        || row.get("event_type").and_then(|v| v.as_str()) != Some("hook_decision")
    {
        return Canon::Invalid;
    }
    let extra = row
        .get("extra")
        .filter(|v| v.is_object())
        .cloned()
        .unwrap_or(serde_json::Value::Null);
    if !extra.is_object() {
        return Canon::Invalid;
    }
    let source_type = extra
        .get("source_type")
        .and_then(|v| v.as_str())
        .unwrap_or("");
    if !EVIDENCE_TYPES.contains(&source_type) {
        return Canon::Skip;
    }
    let hook_id = extra.get("hook_id").and_then(|v| v.as_str()).unwrap_or("");
    if hook_id.is_empty() {
        return Canon::Invalid;
    }
    if source_type == "corpus_add" && extra.get("payload").is_none() {
        return Canon::Invalid;
    }
    if source_type == "corpus_label" && !extra.get("label").map(|v| v.is_string()).unwrap_or(false)
    {
        return Canon::Invalid;
    }
    if extra.get("segment_id").and_then(|v| v.as_str()) != Some(segment_id)
        || !extra.get("sequence").map(is_integer).unwrap_or(false)
    {
        return Canon::Invalid;
    }
    if !extra
        .get("segment_created_at")
        .map(is_finite_number)
        .unwrap_or(false)
    {
        return Canon::Invalid;
    }
    let timestamp = row
        .get("ts")
        .and_then(|v| v.as_str())
        .and_then(parse_date_ms);
    let Some(timestamp) = timestamp else {
        return Canon::Invalid;
    };
    let mut out = serde_json::Map::new();
    out.insert("type".into(), source_type.into());
    out.insert("ts".into(), timestamp.into());
    out.insert("id".into(), hook_id.into());
    if let Some(payload) = extra.get("payload") {
        out.insert("payload".into(), payload.clone());
    }
    if let Some(label) = extra.get("label") {
        out.insert("label".into(), label.clone());
    }
    if let Some(payload_ts) = extra.get("payload_ts").filter(|v| is_finite_number(v)) {
        out.insert("payloadTs".into(), payload_ts.clone());
    }
    if let Some(kind) = extra.get("repair_kind") {
        out.insert("kind".into(), kind.clone());
    }
    if let Some(evidence) = extra.get("evidence") {
        out.insert("evidence".into(), evidence.clone());
    }
    out.insert(
        "__segmentCreatedAt".into(),
        extra
            .get("segment_created_at")
            .cloned()
            .unwrap_or(serde_json::Value::Null),
    );
    out.insert("__segmentId".into(), segment_id.into());
    out.insert(
        "__segmentSequence".into(),
        extra
            .get("sequence")
            .cloned()
            .unwrap_or(serde_json::Value::Null),
    );
    Canon::Row(serde_json::Value::Object(out))
}

/// `readClosedTelemetryEvents(stateDir)`.
pub fn read_closed_telemetry_events(state_dir: &Path) -> Result<Vec<serde_json::Value>, String> {
    let (durable_rows, segment_ids) = read_lake_evidence()?;
    let mut rows = durable_rows;
    let ready_dir = state_dir.join("telemetry-segments").join("ready");
    let mut names: Vec<String> = if ready_dir.exists() {
        fs::read_dir(&ready_dir)
            .map_err(|e| format!("Error: {}", e))?
            .flatten()
            .map(|entry| entry.file_name().to_string_lossy().to_string())
            .collect()
    } else {
        Vec::new()
    };
    names.sort();
    for name in names {
        let Some(middle) = name
            .strip_prefix("segment-")
            .and_then(|r| r.strip_suffix(".jsonl"))
        else {
            continue;
        };
        if middle.is_empty() || name.contains('/') || name.contains('\\') {
            continue;
        }
        if segment_ids.contains(middle) {
            continue;
        }
        let Some(segment) = validated_segment(&ready_dir.join(&name), &name) else {
            continue;
        };
        for (event, sequence) in segment.events {
            let event_type = event.get("type").and_then(|v| v.as_str()).unwrap_or("");
            if !EVIDENCE_TYPES.contains(&event_type) {
                continue;
            }
            let mut row = event.as_object().cloned().unwrap_or_default();
            row.insert("__segmentCreatedAt".into(), segment.created_at.clone());
            row.insert("__segmentId".into(), segment.segment_id.clone().into());
            row.insert("__segmentSequence".into(), sequence.into());
            rows.push(serde_json::Value::Object(row));
        }
    }
    rows.sort_by(|left, right| {
        let key = |row: &serde_json::Value| {
            let created = row
                .get("__segmentCreatedAt")
                .and_then(|v| v.as_f64())
                .unwrap_or(0.0);
            let ts = row.get("ts").and_then(|v| v.as_f64()).unwrap_or(created);
            (
                ordered_float(ts),
                ordered_float(created),
                row.get("__segmentId")
                    .and_then(|v| v.as_str())
                    .unwrap_or("")
                    .to_string(),
                row.get("__segmentSequence")
                    .and_then(|v| v.as_i64())
                    .unwrap_or(0),
            )
        };
        key(left).cmp(&key(right))
    });
    Ok(rows)
}
