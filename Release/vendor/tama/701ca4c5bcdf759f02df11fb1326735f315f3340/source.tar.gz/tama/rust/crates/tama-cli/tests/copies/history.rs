use std::fs;

use serde_json::Value;

use crate::copies_fixture::{stderr, stdout, text, Fixture};

#[test]
fn unborn_history_is_readable_but_corrupt_head_still_refuses_removal() {
    let fixture = Fixture::new("unborn");
    let repository = fixture.checkout().join("vendor/unborn");
    fs::create_dir_all(&repository).unwrap();
    fixture.git(&repository, &["init", "--quiet"]);
    let path = text(repository.clone());
    let listed = fixture.tama(&["copies", "list", "--root", &fixture.root(), "--json"]);
    assert!(listed.status.success(), "{}", stderr(&listed));
    let document: Value = serde_json::from_str(&stdout(&listed)).unwrap();
    let row = document["copies"]
        .as_array()
        .unwrap()
        .iter()
        .find(|row| row["path"] == path)
        .expect("an initialized repository without commits is readable");
    assert_eq!(row["unpublished"], false);

    let head_path = repository.join(".git/HEAD");
    let original_head = fs::read(&head_path).unwrap();
    let invalid_head = b"not a Git reference\n";
    fs::write(&head_path, invalid_head).unwrap();
    let refused = fixture.tama(&[
        "copies",
        "remove",
        "--root",
        &fixture.root(),
        "--only",
        &path,
        "--apply",
        "--force",
        "--json",
    ]);
    assert!(!refused.status.success());
    assert_eq!(fs::read(&head_path).unwrap(), invalid_head);

    fs::write(&head_path, original_head).unwrap();
    let removed = fixture.tama(&[
        "copies",
        "remove",
        "--root",
        &fixture.root(),
        "--only",
        &path,
        "--apply",
        "--force",
        "--json",
    ]);
    assert!(removed.status.success(), "{}", stderr(&removed));
    assert!(!repository.exists());
    assert_eq!(
        fs::read_to_string(fixture.checkout().join("file.txt")).unwrap(),
        "one\n"
    );
    assert!(fixture.copy().is_dir());
}

#[test]
fn canonical_history_allows_a_named_copy_without_an_origin() {
    let fixture = Fixture::new("canonical-history");
    fixture.git(&fixture.copy(), &["remote", "remove", "origin"]);
    let retained = stdout(&fixture.git(&fixture.checkout(), &["rev-parse", "HEAD"]));
    let removed = fixture.tama(&[
        "copies",
        "remove",
        "--root",
        &fixture.root(),
        "--only",
        &text(fixture.copy()),
        "--apply",
        "--json",
    ]);
    assert!(removed.status.success(), "{}", stderr(&removed));
    let document: Value = serde_json::from_str(&stdout(&removed)).unwrap();
    assert_eq!(
        document["copies"][0]["historyRetainedBy"],
        text(fixture.checkout())
    );
    assert!(!fixture.copy().exists());
    assert_eq!(
        stdout(&fixture.git(&fixture.checkout(), &["rev-parse", "HEAD"])),
        retained
    );
    assert!(fixture.lone().is_dir());
}

#[test]
fn a_dangling_commit_remains_protected_after_its_branch_is_reset() {
    let fixture = Fixture::new("dangling-history");
    let published = stdout(&fixture.git(&fixture.copy(), &["rev-parse", "HEAD"]));
    fixture.commit_locally(&fixture.copy());
    let unpublished = stdout(&fixture.git(&fixture.copy(), &["rev-parse", "HEAD"]));
    fixture.git(&fixture.copy(), &["reset", "--hard", published.trim()]);
    let refused = fixture.tama(&[
        "copies",
        "remove",
        "--root",
        &fixture.root(),
        "--only",
        &text(fixture.copy()),
        "--apply",
        "--json",
    ]);
    assert_eq!(refused.status.code(), Some(1), "{}", stdout(&refused));
    assert!(fixture.copy().is_dir());
    assert_eq!(
        stdout(&fixture.git(&fixture.copy(), &["cat-file", "-t", unpublished.trim()])),
        "commit\n"
    );
    assert_eq!(
        stdout(&fixture.git(&fixture.checkout(), &["rev-parse", "HEAD"])),
        published
    );
}

#[test]
fn an_alternate_object_store_is_not_a_canonical_retention_proof() {
    let fixture = Fixture::new("dependent-object-store");
    fixture.git(&fixture.copy(), &["remote", "remove", "origin"]);
    let objects = fixture.checkout().join(".git/objects");
    fs::rename(&objects, fixture.base.join("original-objects")).unwrap();
    fs::create_dir_all(objects.join("info")).unwrap();
    fs::write(
        objects.join("info/alternates"),
        format!("{}\n", fixture.copy().join(".git/objects").display()),
    )
    .unwrap();
    let refused = fixture.tama(&[
        "copies",
        "remove",
        "--root",
        &fixture.root(),
        "--only",
        &text(fixture.copy()),
        "--apply",
        "--json",
    ]);
    assert_eq!(refused.status.code(), Some(1), "{}", stdout(&refused));
    assert!(fixture.copy().is_dir());
    assert_eq!(
        stdout(&fixture.git(&fixture.checkout(), &["show", "HEAD:file.txt"])),
        "one\n"
    );
}
