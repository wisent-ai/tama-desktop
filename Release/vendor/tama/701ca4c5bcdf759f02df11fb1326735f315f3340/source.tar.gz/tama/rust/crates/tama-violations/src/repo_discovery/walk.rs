//! Which Git checkouts under a tree are ours to scan.
//!
//! A name list cannot answer that. It was tried three times: `.build`,
//! `Pods` and `SourcePackages` were added when one tree scan turned into six
//! hundred and fifty-five targets, and the same shape came back as
//! `.lake/packages/mathlib`, `codex-home/.tmp/plugins`, vendored
//! `espeak-ng-spm`, and a linked worktree of a repository already in the
//! list — 61 965 file-length violations, most of them somebody else's code
//! counted as ours.
//!
//! So provenance decides, and it needs exactly two structural facts:
//!
//! - a checkout whose `.git` is a **file** is a linked worktree or a
//!   submodule, so its content belongs to the repository that owns it;
//! - a checkout inside a path its owning repository **ignores** was written
//!   by a package manager, a cache or a scratch run, never by us.
//!
//! Both hold for any tool, including ones that do not exist yet. The name
//! list below stays only to keep the walk cheap.
//!
//! The descent itself, and the report of what it could not read, live in
//! [`super::descent`].

use std::collections::BTreeMap;
use std::path::Path;
use std::process::{Command, Stdio};

use super::descent::{visit, visit_pruning, visit_with};
pub use super::descent::{Discovered, UnreadableDirectory};

/// Directories that never hold interesting checkouts and are expensive to
/// walk. Correctness comes from the two rules above; this is speed.
pub const PRUNE_DIR_NAMES: [&str; 19] = [
    ".git",
    "node_modules",
    "Library",
    ".Trash",
    ".cache",
    ".next",
    "__pycache__",
    "chromium-build",
    "dist",
    "build",
    ".build",
    "Pods",
    "SourcePackages",
    "vendor",
    "target",
    ".venv",
    "venv",
    "coverage",
    ".live-runtime-tmp",
];

/// Every Git checkout under `root_dir` that belongs to this workspace, with
/// no per-origin deduplication.
///
/// Content scanning wants one checkout per repository; ownership questions
/// want them all. `wisent-compute` and `stado` in this workspace share the
/// origin `https://github.com/wisent-ai/stado.git`, so [`discover_repos`]
/// keeps only `stado` — and `wisent-compute` was holding twenty linked
/// worktrees that no reader of the deduplicated list could see. A worktree
/// registration lives in the checkout that created it, so a caller asking
/// what a tree owns has to see every checkout.
pub fn discover_checkouts(root_dir: &Path) -> Vec<String> {
    let mut repos = Vec::new();
    let mut unreadable = Vec::new();
    visit(
        root_dir,
        &mut repos,
        &mut unreadable,
        None,
        &PRUNE_DIR_NAMES,
    );
    repos
}

/// Every Git checkout under `root_dir`, including the ones their owning
/// repository ignores.
///
/// The provenance rule in this module's header is right for content and
/// wrong for ownership, and the difference cost a false answer twice.
/// `paper-repos` is itself a repository that ignores the twenty-odd
/// checkouts nested inside it, so [`discover_checkouts`] returns only
/// `paper-repos`, and `wisent-general-theory` — which was holding a linked
/// worktree — was invisible to every reader of that list.
///
/// A checkout being ignored says who wrote its content. It says nothing
/// about what worktrees it registered, and a caller asking what this machine
/// owns has to see it. Content scanning keeps the filtered lists above.
pub fn discover_every_checkout(root_dir: &Path) -> Vec<String> {
    discover_every_checkout_reporting(root_dir).checkouts
}

/// [`discover_every_checkout`], with the directories the walk could not read.
///
/// A caller whose answer is a claim about a whole tree — which second
/// checkouts exist, which worktrees are registered — has to use this one: a
/// directory that refused to be listed can hold exactly what the caller is
/// looking for, and dropping it turns "none found" into "none exist".
pub fn discover_every_checkout_reporting(root_dir: &Path) -> Discovered {
    let mut checkouts = Vec::new();
    let mut unreadable = Vec::new();
    visit_with(
        root_dir,
        &mut checkouts,
        &mut unreadable,
        None,
        false,
        &PRUNE_DIR_NAMES,
    );
    Discovered {
        checkouts,
        unreadable,
    }
}

/// A copies pass excludes only Git's own metadata. Dependency checkouts are
/// second copies too, including under `checkouts`, `Pods`, `node_modules`,
/// caches and build directories. Root selection belongs to the caller; hiding
/// subtrees by their basename would make a complete inventory impossible.
pub const COPY_PRUNE_DIR_NAMES: &[&str] = &[".git"];

/// Every Git checkout under `root_dir`, walking the build and vendor
/// directories [`discover_every_checkout`] prunes for speed.
pub fn discover_every_checkout_deep(root_dir: &Path) -> Vec<String> {
    discover_every_checkout_deep_reporting(root_dir).checkouts
}

/// [`discover_every_checkout_deep`], with the directories the walk could not
/// read, for the same reason [`discover_every_checkout_reporting`] exists.
pub fn discover_every_checkout_deep_reporting(root_dir: &Path) -> Discovered {
    let mut checkouts = Vec::new();
    let mut unreadable = Vec::new();
    visit_pruning(
        root_dir,
        &mut checkouts,
        &mut unreadable,
        None,
        false,
        COPY_PRUNE_DIR_NAMES,
        None,
    );
    Discovered {
        checkouts,
        unreadable,
    }
}

/// Repository headers at the root and in its immediate child directories.
/// A named-copy removal needs these canonical owners, not a recursive scan
/// of every unrelated checkout, cache and mounted document below them.
pub fn discover_checkouts_at_root_reporting(root_dir: &Path) -> Discovered {
    let mut discovered = Discovered::default();
    visit_pruning(
        root_dir,
        &mut discovered.checkouts,
        &mut discovered.unreadable,
        None,
        false,
        COPY_PRUNE_DIR_NAMES,
        Some(1),
    );
    discovered
}

/// Finds the Git checkouts under `root_dir` that belong to this workspace.
///
/// Two checkouts of one repository are one repository: a scratch clone
/// reports the same file twice and fixing the source fixes both, so the
/// shortest path per origin remote is kept. A checkout with no origin is
/// nobody's copy and is always kept.
pub fn discover_repos(root_dir: &Path) -> Vec<String> {
    dedupe_by_origin(discover_checkouts(root_dir))
}

fn origin_remote(repo: &str) -> Option<String> {
    let output = Command::new("git")
        .arg("-C")
        .arg(repo)
        .args(["remote", "get-url", "origin"])
        .stdin(Stdio::null())
        .stderr(Stdio::null())
        .output()
        .ok()?;
    if !output.status.success() {
        return None;
    }
    let url = String::from_utf8_lossy(&output.stdout).trim().to_string();
    // A trailing `.git` or slash is the same repository spelled twice.
    let url = url
        .trim_end_matches('/')
        .trim_end_matches(".git")
        .to_string();
    (!url.is_empty()).then_some(url)
}

/// The organisation whose layout this workshop decides, beside whoever is
/// signed in to GitHub here and the organisations they belong to. The first
/// sweep with this rule skipped ten of our own repositories — `potyczka`,
/// `versioning`, `wisent-benchmark` and the rest live under the operator's
/// personal account, not under the organisation — so "ours" is read the
/// same way `--me` reads it.
const OUR_ORGANISATION: &str = "wisent-ai";

static OUR_OWNERS: std::sync::LazyLock<std::collections::HashSet<String>> =
    std::sync::LazyLock::new(|| {
        let mut owners: std::collections::HashSet<String> =
            std::iter::once(OUR_ORGANISATION.to_string()).collect();
        if let (Some(login), _) = super::github::github_login() {
            owners.insert(login);
        }
        if let (Some(orgs), _) = super::github::github_orgs() {
            owners.extend(orgs);
        }
        owners
    });

/// The GitHub owner of a checkout's origin, when someone other than us owns
/// it.
///
/// A tree sweep walked into `oh-my-pi`, a product of `can1357` this
/// workshop uses and never patches, and reported 1800 files over the line
/// limit and 238 crowded folders — 55% of everything the sweep found, none
/// of it ours to move. A repository we do not own has no violations we can
/// repair, so naming the owner is the whole answer.
///
/// A checkout with no origin, or one on a host this cannot read as
/// `owner/name`, stays ours: an unpublished repository is nobody else's.
/// So does every checkout when GitHub cannot be asked who is signed in:
/// a failed lookup must not turn the workshop's own code into somebody
/// else's.
pub fn foreign_owner(repo: &str) -> Option<String> {
    let origin = origin_remote(repo)?;
    let path = origin
        .split_once("github.com")
        .map(|(_, rest)| rest.trim_start_matches([':', '/']))?;
    let owner = path.split('/').next()?;
    (!owner.is_empty() && !OUR_OWNERS.contains(owner)).then(|| owner.to_string())
}

/// The copy an operator would edit: fewest path components, then the
/// lexicographically first, so the answer never depends on walk order.
fn preferred(current: &str, candidate: &str) -> bool {
    let depth = |path: &str| path.split('/').count();
    match depth(candidate).cmp(&depth(current)) {
        std::cmp::Ordering::Less => true,
        std::cmp::Ordering::Greater => false,
        std::cmp::Ordering::Equal => candidate < current,
    }
}

fn dedupe_by_origin(repos: Vec<String>) -> Vec<String> {
    let mut kept: BTreeMap<String, String> = BTreeMap::new();
    let mut anonymous: Vec<String> = Vec::new();
    for repo in repos {
        match origin_remote(&repo) {
            Some(origin) => match kept.get(&origin) {
                Some(current) if !preferred(current, &repo) => {}
                _ => {
                    kept.insert(origin, repo);
                }
            },
            None => anonymous.push(repo),
        }
    }
    let mut out: Vec<String> = kept.into_values().chain(anonymous).collect();
    out.sort();
    out
}
