//! Where the visual and failure-inspection checks look for a run's evidence.
//!
//! Eight checks read this root. If it pointed at a directory nothing writes
//! to, every one of them would pass every payload and enforce nothing, which
//! is exactly the defect shape they exist to prevent — so the root itself is
//! asserted here rather than assumed.
//!
//! One test function, not four: the answer depends on a process-wide
//! environment variable, and separate cases would race each other.

use std::path::{Path, PathBuf};

use tama_hook_tools::evidence::{evidence_dir, evidence_root, EVIDENCE_PATH_SEGMENT};

const VARIABLE: &str = "WELES_RUN_OUTPUT_DIR";

#[test]
fn the_root_is_the_product_state_directory_and_only_an_absolute_override_moves_it() {
    let home = PathBuf::from(std::env::var_os("HOME").expect("HOME is set"));
    let previous = std::env::var_os(VARIABLE);

    std::env::remove_var(VARIABLE);
    let default = evidence_root();
    assert_eq!(default, home.join(".weles").join("runs"));
    let labelled = evidence_dir("credential-hook");
    assert_eq!(labelled, default.join("credential-hook"));
    assert!(
        labelled.to_string_lossy().contains(EVIDENCE_PATH_SEGMENT),
        "an evidence path has to carry the segment the payload patterns match: {}",
        labelled.display()
    );

    // A run driven against another root is checked against the evidence it
    // actually produced, which is what the trajectories' own override does.
    std::env::set_var(VARIABLE, "/tmp/does-not-need-to-exist/runs");
    assert_eq!(
        evidence_root(),
        Path::new("/tmp/does-not-need-to-exist/runs")
    );

    // A relative override is ignored rather than resolved against whatever
    // directory a hook happens to run in: that ambiguity is why the old
    // location was abandoned.
    std::env::set_var(VARIABLE, ".work/keeper");
    assert_eq!(evidence_root(), home.join(".weles").join("runs"));

    match previous {
        Some(value) => std::env::set_var(VARIABLE, value),
        None => std::env::remove_var(VARIABLE),
    }
}
