//! zod v4 issue emulation (invalid_type only; shapes the schemas require),
//! split out of `main.rs`.

use serde::Serialize;
use serde_json::Value;

pub struct Issue {
    expected: &'static str,
    path: Vec<String>,
    received: &'static str,
}

#[derive(Serialize)]
struct IssueJson<'a> {
    expected: &'a str,
    code: &'a str,
    path: &'a [String],
    message: String,
}

/// zod v4's parsed-type names for JSON values (`undefined` when absent).
fn js_type(value: Option<&Value>) -> &'static str {
    match value {
        None => "undefined",
        Some(Value::Null) => "null",
        Some(Value::Bool(_)) => "boolean",
        Some(Value::Number(_)) => "number",
        Some(Value::String(_)) => "string",
        Some(Value::Array(_)) => "array",
        Some(Value::Object(_)) => "object",
    }
}

fn invalid_type(expected: &'static str, path: &[&str], value: Option<&Value>) -> Issue {
    Issue {
        expected,
        path: path.iter().map(|p| p.to_string()).collect(),
        received: js_type(value),
    }
}

/// `JSON.stringify(issues, null, 2)` of zod v4 `invalid_type` issues.
pub fn issues_json(issues: &[Issue]) -> String {
    let rendered: Vec<IssueJson> = issues
        .iter()
        .map(|issue| IssueJson {
            expected: issue.expected,
            code: "invalid_type",
            path: &issue.path,
            message: format!(
                "Invalid input: expected {}, received {}",
                issue.expected, issue.received
            ),
        })
        .collect();
    serde_json::to_string_pretty(&rendered).unwrap_or_else(|_| "[]".to_string())
}

/// `InitializeRequestParamsSchema`: required `protocolVersion` (string),
/// `capabilities` (object), `clientInfo` (object with string `name`/`version`;
/// optional `title`/`websiteUrl`/`description` strings). Issues in zod's
/// shape-key order.
pub fn validate_initialize(params: Option<&Value>) -> Vec<Issue> {
    let mut issues = Vec::new();
    let object = match params {
        Some(Value::Object(object)) => object,
        other => {
            issues.push(invalid_type("object", &["params"], other));
            return issues;
        }
    };
    if !matches!(object.get("protocolVersion"), Some(Value::String(_))) {
        issues.push(invalid_type(
            "string",
            &["params", "protocolVersion"],
            object.get("protocolVersion"),
        ));
    }
    if !matches!(object.get("capabilities"), Some(Value::Object(_))) {
        issues.push(invalid_type(
            "object",
            &["params", "capabilities"],
            object.get("capabilities"),
        ));
    }
    match object.get("clientInfo") {
        Some(Value::Object(info)) => {
            if !matches!(info.get("name"), Some(Value::String(_))) {
                issues.push(invalid_type(
                    "string",
                    &["params", "clientInfo", "name"],
                    info.get("name"),
                ));
            }
            if let Some(title) = info.get("title") {
                if !title.is_string() {
                    issues.push(invalid_type(
                        "string",
                        &["params", "clientInfo", "title"],
                        Some(title),
                    ));
                }
            }
            if !matches!(info.get("version"), Some(Value::String(_))) {
                issues.push(invalid_type(
                    "string",
                    &["params", "clientInfo", "version"],
                    info.get("version"),
                ));
            }
            for key in ["websiteUrl", "description"] {
                if let Some(value) = info.get(key) {
                    if !value.is_string() {
                        issues.push(invalid_type(
                            "string",
                            &["params", "clientInfo", key],
                            Some(value),
                        ));
                    }
                }
            }
        }
        other => issues.push(invalid_type("object", &["params", "clientInfo"], other)),
    }
    issues
}

/// `ListToolsRequestSchema` (paginated): optional params, optional string
/// `cursor`. Params is guaranteed an object by the envelope check.
pub fn validate_tools_list(params: Option<&Value>) -> Vec<Issue> {
    let mut issues = Vec::new();
    if let Some(Value::Object(object)) = params {
        if let Some(cursor) = object.get("cursor") {
            if !cursor.is_string() {
                issues.push(invalid_type("string", &["params", "cursor"], Some(cursor)));
            }
        }
    }
    issues
}

/// `CallToolRequestParamsSchema`: required object params with `name` (string),
/// optional `arguments` (record = non-array object), optional `task` (object).
/// Issues in zod's shape-key order (`task`, `name`, `arguments`).
pub fn validate_call_tool(params: Option<&Value>) -> Vec<Issue> {
    let mut issues = Vec::new();
    let object = match params {
        Some(Value::Object(object)) => object,
        other => {
            issues.push(invalid_type("object", &["params"], other));
            return issues;
        }
    };
    if let Some(task) = object.get("task") {
        if !task.is_object() {
            issues.push(invalid_type("object", &["params", "task"], Some(task)));
        }
    }
    if !matches!(object.get("name"), Some(Value::String(_))) {
        issues.push(invalid_type(
            "string",
            &["params", "name"],
            object.get("name"),
        ));
    }
    if let Some(arguments) = object.get("arguments") {
        if !arguments.is_object() {
            issues.push(invalid_type(
                "record",
                &["params", "arguments"],
                Some(arguments),
            ));
        }
    }
    issues
}
