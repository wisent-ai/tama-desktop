//! Where the registry, the provider catalog and the work root live, what a
//! valid provider entry looks like, and how its argument template expands.
//!
//! Split out of `one_session/mod.rs`, which had grown past the
//! three-hundred-line limit; the launch itself is next door.

use crate::util::{js_string_or_empty, shared_hooks_root};
use serde_json::{Map, Value};
use std::path::{Path, PathBuf};

pub const PROVIDER_CATALOG_SCHEMA: &str = "ai.wisent.tama.providers.v1";

/// `registryPath` / `providerCatalogPath` / `workRoot` resolution.
pub fn registry_path() -> PathBuf {
    std::env::var_os("AGENT_HOOK_REGISTRY")
        .map(PathBuf::from)
        .unwrap_or_else(|| shared_hooks_root().join("registry.json"))
}

pub fn provider_catalog_path() -> PathBuf {
    std::env::var_os("TAMA_PROVIDER_CATALOG")
        .map(PathBuf::from)
        .unwrap_or_else(|| shared_hooks_root().join("providers.json"))
}

pub fn work_root() -> PathBuf {
    std::env::var_os("TAMA_SESSION_HOOK_WORK_ROOT")
        .map(PathBuf::from)
        .unwrap_or_else(|| {
            shared_hooks_root()
                .parent()
                .unwrap_or_else(|| Path::new("/"))
                .join(".tama")
                .join("one-session-hook")
        })
}

/// `extensionPath` in JS is the run-one-session-hook script itself; OMP can
/// only load JS extensions, so the port keeps pointing at the JS file.
pub fn extension_path() -> PathBuf {
    shared_hooks_root().join("run-one-session-hook.js")
}

pub fn run_hook_path() -> PathBuf {
    shared_hooks_root().join("run-hook.mjs")
}

/// Port of the top-level provider catalog validation.
pub fn load_provider_catalog(path: &Path) -> Result<Map<String, Value>, String> {
    let text = std::fs::read_to_string(path).map_err(|e| {
        if e.kind() == std::io::ErrorKind::NotFound {
            format!(
                "ENOENT: no such file or directory, open '{}'",
                path.display()
            )
        } else {
            e.to_string()
        }
    })?;
    let catalog: Value = serde_json::from_str(&text).map_err(|e| format!("{}", e))?;
    let valid = catalog.get("schema").and_then(Value::as_str) == Some(PROVIDER_CATALOG_SCHEMA)
        && catalog
            .get("providers")
            .map(Value::is_object)
            .unwrap_or(false);
    if !valid {
        return Err(format!("Invalid Tama provider catalog: {}", path.display()));
    }
    Ok(catalog
        .get("providers")
        .and_then(Value::as_object)
        .cloned()
        .unwrap_or_default())
}

/// Port of `expandArguments`.
pub fn expand_arguments(
    template: &[Value],
    values: &Map<String, Value>,
) -> Result<Vec<String>, String> {
    let mut out = Vec::new();
    for argument in template {
        let Some(argument) = argument.as_str() else {
            continue;
        };
        if argument == "{session}" && values.get("session").is_none() {
            continue;
        }
        if !(argument.starts_with('{') && argument.ends_with('}')) {
            out.push(argument.to_string());
            continue;
        }
        let key = &argument[1..argument.len() - 1];
        match values.get(key) {
            Some(value) => out.push(js_string_or_empty(Some(value))),
            None => {
                return Err(format!(
                    "Unknown provider argument placeholder: {}",
                    argument
                ))
            }
        }
    }
    Ok(out)
}

pub(super) fn validate_provider(provider: &Value) -> Result<(), String> {
    let ok = provider
        .get("executable")
        .map(Value::is_string)
        .unwrap_or(false)
        && provider
            .get("executableEnv")
            .map(Value::is_string)
            .unwrap_or(false)
        && provider
            .get("hookTransport")
            .map(Value::is_string)
            .unwrap_or(false)
        && provider
            .get("newArguments")
            .map(Value::is_array)
            .unwrap_or(false)
        && provider
            .get("resumeArguments")
            .map(Value::is_array)
            .unwrap_or(false);
    if !ok {
        return Err("Invalid provider entry in Tama provider catalog.".to_string());
    }
    Ok(())
}
