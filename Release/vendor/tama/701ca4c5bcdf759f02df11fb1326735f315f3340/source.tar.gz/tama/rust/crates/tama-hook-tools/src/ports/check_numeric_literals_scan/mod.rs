//! Language coverage and literal detection for `check_numeric_literals.py`
//! (hook `block-numeric-literals`).
//!
//! Three rules decide what counts. A file is CODE when its name ends in one of
//! the `CODE_EXT` suffixes, and then its strings and comments are blanked before
//! the scan, so a number inside a quote or a comment is not a literal. A file
//! whose name ends in one of the `TEXT_EXT` suffixes is exempt outright.
//! Anything else is scanned verbatim, comments and strings included.
//!
//! Within code, a digit run glued to an identifier is not a literal: the two
//! lookbehind assertions the Python spells out are what let `Int64`, `sha256`
//! and `u8` through, and they are reproduced here as an explicit check on the
//! preceding character because Rust's engine has no lookbehind.

mod blanking;

pub use blanking::strip_sc;
use regex::Regex;

use crate::ports::{pystr, python_stdlib};

/// `CODE_EXT` — order is load-bearing: `lang_for` returns the first suffix that
/// matches, so this stays in the Python's insertion order.
const CODE_EXT: &[(&str, &str)] = &[
    (".swift", "swift"),
    (".ts", "ts"),
    (".tsx", "ts"),
    (".js", "js"),
    (".mjs", "js"),
    (".jsx", "js"),
    (".py", "py"),
    (".rs", "rust"),
    (".go", "go"),
    (".c", "c"),
    (".h", "c"),
    (".cpp", "c"),
    (".cc", "c"),
    (".hpp", "c"),
    (".m", "c"),
    (".mm", "c"),
    (".cs", "c"),
    (".java", "c"),
    (".kt", "c"),
    (".kts", "c"),
    (".scala", "c"),
    (".groovy", "c"),
    (".gradle", "c"),
    (".php", "c"),
    (".sh", "sh"),
    (".bash", "sh"),
    (".zsh", "sh"),
    (".rb", "sh"),
    (".pl", "sh"),
    (".r", "sh"),
    (".jl", "sh"),
    (".lua", "sql"),
    (".sql", "sql"),
];

/// `TEXT_EXT` — exempt entirely, neither scanned nor stripped.
pub const TEXT_EXT: &[&str] = &[
    ".md", ".mdx", ".css", ".scss", ".html", ".htm", ".ipynb", ".jsonl", ".rst", ".txt", ".xml",
    ".svg", ".vue", ".svelte",
];

/// `LC` — line-comment opener per language, `//` for anything unlisted.
const LC: &[(&str, &str)] = &[
    ("swift", "//"),
    ("js", "//"),
    ("ts", "//"),
    ("py", "#"),
    ("rust", "//"),
    ("go", "//"),
    ("c", "//"),
    ("sh", "#"),
    ("sql", "--"),
];
const DEFAULT_LINE_COMMENT: &str = "//";

/// `BLK` — languages with `/* */`. `css`/`scss` are unreachable: they are
/// `TEXT_EXT`, so `lang_for` never returns them. Kept as the Python has them.
const BLK: &[&str] = &["swift", "js", "ts", "rust", "go", "c", "sql", "css", "scss"];

/// `SUF` — the magnitude suffixes a user quote may use, as the Python spells
/// them: `120k` declares `120000`.
const SUF: &[(char, &str)] = &[('k', "1e3"), ('m', "1e6"), ('b', "1e9"), ('g', "1e9")];
/// `canon` inspects `t[:2]` for a radix prefix.
const RADIX_PREFIX_LEN_TEXT: &str = "2";
const RADIX: &[(&str, &str)] = &[("0x", "16"), ("0b", "2"), ("0o", "8")];
/// `mul=1.0` before a suffix is seen.
const IDENTITY_TEXT: &str = "1.0";

/// `NUM`, minus its two lookbehinds. Group 1 is the first alternative, which
/// carries the stricter guard.
const NUM: &str = "(0[xXbBoO][0-9a-fA-F_]+|\\d[\\d_]*(?:,\\d{3})*(?:\\.\\d+)?(?:[eE][+-]?\\d+)?)\
|\\.\\d[\\d_]*(?:[eE][+-]?\\d+)?";
/// `QNUM` — the shapes a user quote may spell a number in. No lookbehind.
const QNUM: &str =
    "0[xXbBoO][0-9a-fA-F_]+|\\d[\\d_,]*(?:\\.\\d+)?(?:[eE][+-]?\\d+)?\\s*[kmbgKMBG]?\
|\\.\\d[\\d_]*(?:[eE][+-]?\\d+)?";

/// `(?<![A-Za-z0-9_.$])` — the digit-run guard. A leading `.`, `$` or word
/// character means the digits belong to an identifier or a member access.
const GUARD_DIGITS_EXTRA: &str = "_.$";
/// `(?<![A-Za-z0-9_$).\]])` — the bare-fraction guard also refuses a `)` or `]`,
/// so `foo().5` and `x[i].5` are member access rather than a literal.
const GUARD_FRACTION_EXTRA: &str = "_$).]";

fn radix_prefix_len() -> usize {
    RADIX_PREFIX_LEN_TEXT.parse().unwrap_or_default()
}

fn lookup(table: &[(&str, &str)], key: &str) -> Option<String> {
    table
        .iter()
        .find(|(name, _)| *name == key)
        .map(|(_, value)| (*value).to_string())
}

/// `canon` — one number, however spelled: `120k`, `120_000`, `120,000`,
/// `0x1E240` and `120000.0` all reduce to the same float.
pub fn canon(text: &str) -> Option<f64> {
    let mut trimmed = pystr::strip(text)
        .to_lowercase()
        .replace(',', "")
        .replace('_', "")
        .replace(' ', "");
    let prefix = pystr::head_chars(&trimmed, radix_prefix_len()).to_string();
    if let Some(radix) = lookup(RADIX, &prefix) {
        let radix: u32 = radix.parse().unwrap_or_default();
        let digits = &trimmed[prefix.len()..];
        return u128::from_str_radix(digits, radix)
            .ok()
            .map(|value| value as f64);
    }
    let mut multiplier: f64 = IDENTITY_TEXT.parse().unwrap_or_default();
    if let Some(last) = trimmed.chars().last() {
        if let Some(factor) = SUF.iter().find(|(suffix, _)| *suffix == last) {
            multiplier = factor.1.parse().unwrap_or_default();
            trimmed.pop();
        }
    }
    trimmed.parse::<f64>().ok().map(|value| value * multiplier)
}

/// `lang_for` — the first `CODE_EXT` suffix the path ends with, or nothing.
pub fn lang_for(path: &str) -> Option<String> {
    CODE_EXT
        .iter()
        .find(|(ext, _)| path.ends_with(ext))
        .map(|(_, lang)| (*lang).to_string())
}

/// One `NUM` hit: the matched text and its byte offset in the scanned string.
pub struct Literal {
    pub text: String,
    pub start: usize,
}

fn guarded(previous: Option<char>, extra: &str) -> bool {
    match previous {
        Some(c) => c.is_ascii_alphanumeric() || extra.contains(c),
        None => false,
    }
}

/// `NUM.finditer(s)` with the lookbehinds applied by hand. A rejected hit
/// resumes one character on, exactly where the Python's scan would continue.
pub fn numeric_literals(text: &str) -> Vec<Literal> {
    let pattern = Regex::new(NUM).unwrap();
    let digits_group = python_stdlib::one();
    let mut out = Vec::new();
    let mut offset = usize::MIN;
    while offset <= text.len() {
        let Some(caps) = pattern.captures_at(text, offset) else {
            break;
        };
        let Some(hit) = caps.get(usize::MIN) else {
            break;
        };
        let extra = match caps.get(digits_group) {
            Some(_) => GUARD_DIGITS_EXTRA,
            None => GUARD_FRACTION_EXTRA,
        };
        let previous = text[..hit.start()].chars().next_back();
        if guarded(previous, extra) {
            let width = text[hit.start()..].chars().next().map(char::len_utf8);
            offset = hit.start() + width.unwrap_or(digits_group);
            continue;
        }
        out.push(Literal {
            text: hit.as_str().to_string(),
            start: hit.start(),
        });
        offset = hit.end();
    }
    out
}

/// `declares` — the quote declares the value when any number it spells reduces
/// to the same float.
pub fn declares(quote: &str, literal: &str) -> bool {
    let Some(target) = canon(literal) else {
        return false;
    };
    Regex::new(QNUM)
        .unwrap()
        .find_iter(quote)
        .any(|hit| canon(hit.as_str()) == Some(target))
}
