//! One telemetry segment read back and checked: the header, the frames in
//! sequence, and the footer's digest over the payload.
//!
//! Split out of `evidence/mod.rs`, which had grown past the
//! three-hundred-line limit.

use std::fs;
use std::path::Path;

use sha2::{Digest, Sha256};

use super::{object, SEGMENT_PROTOCOL};

pub(super) struct EvidenceSegment {
    pub(super) segment_id: String,
    pub(super) created_at: serde_json::Value,
    pub(super) events: Vec<(serde_json::Value, i64)>,
}

/// `validatedSegment(path, expectedName)` from evidence.mjs.
pub(super) fn validated_segment(path: &Path, expected_name: &str) -> Option<EvidenceSegment> {
    let source = fs::read_to_string(path).ok()?;
    if !source.ends_with('\n') {
        return None;
    }
    let lines: Vec<&str> = source[..source.len() - 1].split('\n').collect();
    if lines.len() < 2 {
        return None;
    }
    let header = object(lines[0]).ok().filter(|v| v.is_object())?;
    let footer = object(lines[lines.len() - 1])
        .ok()
        .filter(|v| v.is_object())?;
    let name_match = expected_name
        .strip_prefix("segment-")
        .and_then(|rest| rest.strip_suffix(".jsonl"))
        .filter(|middle| !middle.is_empty())?;
    if header.get("kind").and_then(|v| v.as_str()) != Some("segment_open")
        || header.get("protocol").and_then(|v| v.as_str()) != Some(SEGMENT_PROTOCOL)
    {
        return None;
    }
    if header.get("segmentId").and_then(|v| v.as_str()) != Some(name_match) {
        return None;
    }
    if !header
        .get("createdAt")
        .map(|v| v.is_number())
        .unwrap_or(false)
    {
        return None;
    }
    let producer_ok = header
        .get("producerId")
        .and_then(|v| v.as_str())
        .map(|s| !s.is_empty())
        .unwrap_or(false);
    let invocation_ok = header
        .get("invocationId")
        .and_then(|v| v.as_str())
        .map(|s| !s.is_empty())
        .unwrap_or(false);
    if !producer_ok || !invocation_ok {
        return None;
    }
    let source_field = header.get("source")?;
    if source_field.is_null()
        || source_field.get("producer").and_then(|v| v.as_str()) != Some("tama")
    {
        return None;
    }
    let mut events = Vec::new();
    for (sequence, text) in lines[1..lines.len() - 1].iter().enumerate() {
        let frame = object(text).ok().filter(|v| v.is_object())?;
        if frame.get("kind").and_then(|v| v.as_str()) != Some("event") {
            return None;
        }
        if frame.get("sequence").and_then(|v| v.as_i64()) != Some(sequence as i64) {
            return None;
        }
        let event = frame.get("event")?.clone();
        if !event.is_object() {
            return None;
        }
        events.push((event, sequence as i64));
    }
    let payload = format!("{}\n", lines[..lines.len() - 1].join("\n"));
    let payload_sha256 = format!("{:x}", Sha256::digest(payload.as_bytes()));
    if footer.get("kind").and_then(|v| v.as_str()) != Some("segment_close")
        || footer.get("protocol").and_then(|v| v.as_str()) != Some(SEGMENT_PROTOCOL)
        || footer.get("segmentId").and_then(|v| v.as_str())
            != header.get("segmentId").and_then(|v| v.as_str())
    {
        return None;
    }
    if footer.get("eventCount").and_then(|v| v.as_i64()) != Some(events.len() as i64)
        || footer.get("payloadSha256").and_then(|v| v.as_str()) != Some(payload_sha256.as_str())
        || !footer
            .get("closedAt")
            .map(|v| v.is_number())
            .unwrap_or(false)
    {
        return None;
    }
    Some(EvidenceSegment {
        segment_id: name_match.to_string(),
        created_at: header
            .get("createdAt")
            .cloned()
            .unwrap_or(serde_json::Value::Null),
        events,
    })
}
