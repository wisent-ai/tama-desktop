//! Payload handling: stdin parsing, usage text and the normalized hook
//! payload passed to each hook command.

use serde_json::Value;

use crate::emit::{json_str, json_value};
use crate::jssem::{js_truthy, trim_js};

pub(crate) mod inner;

pub fn usage() -> &'static str {
    "Usage: tama-run-hook <event> <agent-id>\n       tama-run-hook --serve <agent-id>\n"
}

/// Port of `parsePayload`: empty input is `{}`, unparseable input is
/// `{ raw: text }`.
pub(crate) fn parse_payload(text: &str) -> Value {
    if trim_js(text).is_empty() {
        return Value::Object(serde_json::Map::new());
    }
    serde_json::from_str(text).unwrap_or_else(|_| {
        let mut m = serde_json::Map::new();
        m.insert("raw".to_string(), Value::String(text.to_string()));
        Value::Object(m)
    })
}

/// Port of the `normalized` payload construction. Returns the JSON string
/// passed to hooks on stdin. Key order follows the JS object spread:
/// payload keys first (see note), then `cwd`, `transcript_path` and
/// `agent_hook_event` appended when absent; `raw_event` is dropped.
///
/// Deviation: `serde_json::Value` does not preserve source key order (the
/// workspace does not enable `preserve_order`), so payload keys are emitted
/// sorted instead of in original document order; this affects nested objects
/// as well. Also, float values re-serialize as `1.0` where JS emits `1`.
pub(crate) fn normalized_payload(payload: &Value, event: &str) -> String {
    // `{ ...payload }` — objects spread their own keys, arrays and strings
    // spread indexed entries, everything else spreads nothing.
    let mut entries: Vec<(String, Value)> = match payload {
        Value::Object(map) => map.iter().map(|(k, v)| (k.clone(), v.clone())).collect(),
        Value::Array(items) => items
            .iter()
            .enumerate()
            .map(|(i, v)| (i.to_string(), v.clone()))
            .collect(),
        Value::String(s) => s
            .chars()
            .enumerate()
            .map(|(i, c)| (i.to_string(), Value::String(c.to_string())))
            .collect(),
        _ => Vec::new(),
    };
    let object = payload.as_object();
    let get = |key: &str| object.and_then(|m| m.get(key));
    let raw_event = match payload.get("raw_event") {
        // `payload.raw_event && typeof payload.raw_event === 'object'` — only
        // plain objects expose the raw-event lookup keys (arrays have none of
        // them).
        Some(v @ Value::Object(_)) => Some(v),
        _ => None,
    };
    let raw_get = |key: &str| raw_event.and_then(|m| m.get(key));

    // `payload.cwd || rawEvent.cwd || payload.project_dir` — when nothing is
    // truthy the value is `undefined`, which `JSON.stringify` drops entirely.
    let cwd = ["cwd", "raw_event.cwd", "project_dir"]
        .iter()
        .map(|k| match *k {
            "raw_event.cwd" => raw_get("cwd"),
            k => get(k),
        })
        .find(|v| js_truthy(*v))
        .flatten()
        .cloned();
    // `... || null` — always defined, so the key is always emitted.
    let transcript_path = [
        "transcript_path",
        "raw_event.transcript_path",
        "transcriptPath",
    ]
    .iter()
    .map(|k| match *k {
        "raw_event.transcript_path" => raw_get("transcript_path"),
        "transcriptPath" => raw_get("transcriptPath"),
        k => get(k),
    })
    .find(|v| js_truthy(*v))
    .flatten()
    .cloned()
    .unwrap_or(Value::Null);

    fn upsert(entries: &mut Vec<(String, Value)>, key: &str, value: Value) {
        if let Some(entry) = entries.iter_mut().find(|(k, _)| k == key) {
            entry.1 = value;
        } else {
            entries.push((key.to_string(), value));
        }
    }
    match cwd {
        Some(v) => upsert(&mut entries, "cwd", v),
        None => entries.retain(|(k, _)| k != "cwd"),
    }
    upsert(&mut entries, "transcript_path", transcript_path);
    entries.retain(|(k, _)| k != "raw_event");
    upsert(
        &mut entries,
        "agent_hook_event",
        Value::String(event.to_string()),
    );

    let mut out = String::from("{");
    for (i, (key, value)) in entries.iter().enumerate() {
        if i > 0 {
            out.push(',');
        }
        out.push_str(&json_str(key));
        out.push(':');
        out.push_str(&json_value(value));
    }
    out.push('}');
    out
}

/// Translate the frozen per-hook Codex wrapper contract at the adapter edge.
/// The common engine receives only the resulting invocation filters.
pub(crate) fn dispatch_for_provider(
    runtime: &mut crate::Runtime,
    event: &str,
    agent_id: &str,
    provider: &str,
    options: &crate::InvocationOptions,
    payload: &Value,
) -> Result<crate::Decision, String> {
    runtime.refresh_for_dispatch()?;
    dispatch_loaded_for_provider(runtime, event, agent_id, provider, options, payload)
}

pub(crate) fn dispatch_loaded_for_provider(
    runtime: &crate::Runtime,
    event: &str,
    agent_id: &str,
    provider: &str,
    options: &crate::InvocationOptions,
    payload: &Value,
) -> Result<crate::Decision, String> {
    let translated;
    let options = if provider == "codex" && !options.only_hook_id.is_empty() {
        if runtime.first_hook_id(event) != Some(options.only_hook_id.as_str()) {
            return Ok(crate::Decision::pass(crate::emit::pass_with_reason_json(
                &format!(
                    "legacy wrapper {} delegated to dispatcher",
                    options.only_hook_id
                ),
            )));
        }
        translated = crate::InvocationOptions {
            only_hook_id: String::new(),
            ..options.clone()
        };
        &translated
    } else {
        options
    };
    let decision = runtime.dispatch_loaded(event, agent_id, options, payload)?;
    // The prompt is the only place an owner correction can be attributed to the
    // blocks it followed, and this runtime never handed one over.
    if event == "user_prompt_submit" {
        crate::observation::prompt(&normalized_payload(payload, event));
    }
    Ok(decision)
}
