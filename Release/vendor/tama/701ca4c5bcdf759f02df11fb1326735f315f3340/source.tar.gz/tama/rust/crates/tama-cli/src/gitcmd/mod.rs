//! Running git, and the three answers both checkout commands need from it.
//!
//! `worktrees` and `copies` ask git different questions about the same
//! machine, and both need the same plumbing: run a command inside a
//! directory, resolve a path the way the filesystem sees it, and say whether a
//! checkout carries uncommitted work. These lived privately in
//! `worktrees/porcelain.rs` until `copies` needed them; the worktree porcelain
//! parser stayed there, because only that command reads it.

use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};

pub(crate) fn git(dir: &Path, args: &[&str]) -> Result<String, String> {
    let output = Command::new("git")
        .arg("-C")
        .arg(dir)
        .args(args)
        // Local inventory must not authenticate or fetch a partial clone's missing objects.
        .env("GIT_NO_LAZY_FETCH", "1")
        .stdin(Stdio::null())
        .output()
        .map_err(|error| format!("git {} in {}: {error}", args.join(" "), dir.display()))?;
    if !output.status.success() {
        return Err(format!(
            "git {} in {} failed: {}",
            args.join(" "),
            dir.display(),
            String::from_utf8_lossy(&output.stderr).trim()
        ));
    }
    Ok(String::from_utf8_lossy(&output.stdout).into_owned())
}

/// A checkout is dirty when `git status --porcelain` prints anything. A path
/// git has already lost has no status to read and is not dirty.
pub(crate) fn is_dirty(path: &Path) -> bool {
    if !path.is_dir() {
        return false;
    }
    git(path, &["status", "--porcelain"]).is_ok_and(|text| !text.trim().is_empty())
}

/// The path as the filesystem knows it, so a symlinked or trailing-slashed
/// spelling compares equal to git's own answer. A path that cannot be
/// resolved is compared as written.
pub(crate) fn canonical(path: &Path) -> PathBuf {
    std::fs::canonicalize(path).unwrap_or_else(|_| path.to_path_buf())
}

pub(crate) fn same_path(left: &str, right: &Path) -> bool {
    canonical(Path::new(left)) == canonical(right)
}

/// Git may silently walk up to a parent when a candidate's metadata is
/// damaged. Never use that parent's history to authorize deleting the child.
pub(crate) fn verify_repository(path: &Path) -> Result<(), String> {
    let bare = git(path, &["rev-parse", "--is-bare-repository"])?;
    let root_option = if bare.trim() == "true" {
        "--absolute-git-dir"
    } else {
        "--show-toplevel"
    };
    let root = git(path, &["rev-parse", root_option])?;
    if !same_path(root.trim(), path) {
        return Err(format!(
            "git resolved {} to a different repository: {}",
            path.display(),
            root.trim()
        ));
    }
    Ok(())
}
