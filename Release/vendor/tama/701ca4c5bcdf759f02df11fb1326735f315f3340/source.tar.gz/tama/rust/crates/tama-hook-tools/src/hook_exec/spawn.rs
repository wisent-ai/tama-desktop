//! Running one hook command: argv, never a shell string.
//!
//! Split out of `hook_exec/mod.rs`, which had grown past the
//! three-hundred-line limit. Reading what came back stays there.

use std::io::{Read, Write};
use std::process::{Command, Stdio};

use serde_json::Value;

use super::{tokenize_command, HookOutput};

/// Node-style spawn error message (`spawn <program> ENOENT`).
fn spawn_error_message(program: &str, error: &std::io::Error) -> String {
    if error.kind() == std::io::ErrorKind::NotFound {
        format!("spawn {} ENOENT", program)
    } else {
        format!("spawn {} {}", program, error)
    }
}

/// Run one hook command: argv spawn (no shell), JSON payload on stdin,
/// stdout/stderr captured, and the command waited for. `env_set` overrides
/// and `env_remove` deletes variables on top of the inherited environment.
///
/// Nothing here kills the command at a number of milliseconds. The number
/// was always a guess at how long an answer may take, and the hook killed at
/// it answered with a refusal nobody wrote.
pub fn run_hook_command(
    command: &str,
    payload: &Value,
    env_set: &[(String, String)],
    env_remove: &[String],
) -> HookOutput {
    let tokens = tokenize_command(command);
    let (program, args) = match tokens.split_first() {
        Some((program, args)) if !program.is_empty() => (program.clone(), args.to_vec()),
        _ => {
            return HookOutput {
                code: None,
                signal: None,
                stdout: String::new(),
                stderr: "empty hook command".to_string(),
                spawn_error: true,
            }
        }
    };
    let mut cmd = Command::new(&program);
    cmd.args(&args)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped());
    for (key, value) in env_set {
        cmd.env(key, value);
    }
    for key in env_remove {
        cmd.env_remove(key);
    }
    let mut child = match cmd.spawn() {
        Ok(child) => child,
        Err(error) => {
            return HookOutput {
                code: None,
                signal: None,
                stdout: String::new(),
                stderr: spawn_error_message(&program, &error),
                spawn_error: true,
            }
        }
    };
    let body = serde_json::to_string(payload).unwrap_or_default();
    let mut stdin_error = None;
    if let Some(mut stdin) = child.stdin.take() {
        if let Err(error) = stdin.write_all(body.as_bytes()) {
            stdin_error = Some(error.to_string());
        }
        // Dropping stdin closes it, like `child.stdin.end(...)`.
    }
    let mut stdout_handle = child.stdout.take();
    let mut stderr_handle = child.stderr.take();
    let stdout_thread = std::thread::spawn(move || -> Vec<u8> {
        let mut buf = Vec::new();
        if let Some(mut out) = stdout_handle.take() {
            let _ = out.read_to_end(&mut buf);
        }
        buf
    });
    let stderr_thread = std::thread::spawn(move || -> Vec<u8> {
        let mut buf = Vec::new();
        if let Some(mut err) = stderr_handle.take() {
            let _ = err.read_to_end(&mut buf);
        }
        buf
    });
    let status = child.wait().ok();
    let stdout_bytes = stdout_thread.join().unwrap_or_default();
    let stderr_bytes = stderr_thread.join().unwrap_or_default();
    let mut stderr = String::from_utf8_lossy(&stderr_bytes).into_owned();
    if let Some(message) = stdin_error {
        stderr.push_str(&message);
    }
    let (code, signal) = match status {
        Some(status) => {
            use std::os::unix::process::ExitStatusExt;
            (status.code(), status.signal())
        }
        None => (None, None),
    };
    HookOutput {
        code,
        signal,
        stdout: String::from_utf8_lossy(&stdout_bytes).into_owned(),
        stderr,
        spawn_error: false,
    }
}
