//! Port of `src/adaptive/runner.mjs`: adaptive hook runner — a drop-in
//! replacement for the legacy shared-hooks run-hook CLI, with the same
//! argv/stdin/stdout contract and reason strings. Fail posture stays
//! closed: any internal error prints a block decision and exits zero.

mod legacy;
mod shapes;

use shapes::{
    blocking, emit, hook_spec, hooks_of, json, normalized_payload, result_entry, results_array,
    usage,
};

use legacy::run_legacy;
use std::io::Write;

use crate::engine::{load_engine, OutcomeObservation};
use crate::segments::runner_command::{
    crash_reason, decision_from_output, parse_payload, run_command, stdin_text,
};
use crate::state::EpisodeBlockInput;
use crate::telemetry::{open_telemetry, Telemetry};
use crate::util::{js_string, js_truthy};
use crate::EXIT_USAGE;

/// Fire-and-forget frustration bridge; never waits, never propagates
/// failures. The hand-off itself lives in `bridge::dispatch`, because the
/// shared runtime the providers talk to now needs exactly the same one.
fn dispatch_bridge(normalized: &str) {
    crate::bridge::dispatch(normalized);
}

fn js_opt_string(value: &serde_json::Value) -> Option<String> {
    // `String(value || '')` semantics: falsy JSON becomes None (→ '' later).
    if js_truthy(value) {
        Some(js_string(value))
    } else {
        None
    }
}

fn run_adaptive_body(
    event: &str,
    engine: &crate::engine::Engine,
    telemetry: &Telemetry,
) -> Result<(), String> {
    let entry = engine.registry_event(event);
    let Some(entry) = entry else {
        emit(&[
            ("decision", json(&"pass".into())),
            ("reason", json(&format!("no hooks for {}", event).into())),
        ]);
        return Ok(());
    };
    let payload = parse_payload(&stdin_text());
    let raw_event = payload
        .get("raw_event")
        .filter(|v| v.is_object())
        .cloned()
        .unwrap_or_else(|| serde_json::json!({}));
    let first = |keys: &[&str]| -> serde_json::Value {
        keys.iter()
            .find_map(|key| payload.get(*key))
            .filter(|v| js_truthy(v))
            .or_else(|| {
                keys.iter()
                    .find_map(|key| raw_event.get(*key))
                    .filter(|v| js_truthy(v))
            })
            .cloned()
            .unwrap_or(serde_json::Value::Null)
    };
    let session_id = first(&["session_id", "sessionId"]);
    let episode_id = first(&["turn_id", "turnId"]);
    // `payload.cwd || payload.project_dir || rawEvent.cwd || null`
    let project = payload
        .get("cwd")
        .filter(|v| js_truthy(v))
        .or_else(|| payload.get("project_dir").filter(|v| js_truthy(v)))
        .or_else(|| raw_event.get("cwd").filter(|v| js_truthy(v)))
        .cloned()
        .unwrap_or(serde_json::Value::Null);
    let normalized = normalized_payload(&payload, event);
    let tool = payload
        .get("tool_name")
        .and_then(|v| v.as_str())
        .map(str::to_string);

    let mut planned = Vec::new();
    for hook in hooks_of(&entry) {
        let spec = hook_spec(&hook);
        let id_str = js_opt_string(&spec.id).unwrap_or_default();
        let mode = engine.effective_mode(&id_str).to_string();
        let tier = engine.tier_of(&id_str);
        planned.push((spec, mode, tier));
    }
    let settled: Vec<_> = planned
        .iter()
        .map(|(spec, _, _)| run_command(&spec.command, &normalized))
        .collect();

    let mut results: Vec<String> = Vec::new();
    let mut warnings: Vec<String> = Vec::new();
    let mut block_reason: Option<String> = None;
    for ((spec, mode, tier), result) in planned.iter().zip(settled.iter()) {
        results.push(result_entry(spec, result.code));
        let mut base = serde_json::Map::new();
        base.insert("event".into(), event.into());
        base.insert("id".into(), spec.id.clone());
        base.insert("ms".into(), result.ms.into());
        base.insert(
            "code".into(),
            result
                .code
                .map(Into::into)
                .unwrap_or(serde_json::Value::Null),
        );
        if let Some(tool) = &tool {
            base.insert("tool".into(), tool.clone().into());
        }
        base.insert("session_id".into(), session_id.clone());
        base.insert("episode_id".into(), episode_id.clone());
        base.insert("project".into(), project.clone());
        let verdict =
            decision_from_output(&result.stdout).or_else(|| decision_from_output(&result.stderr));
        if let Some(verdict) = verdict {
            let reason = format!("{}: {}", spec.id_text(), verdict);
            let transition = engine
                .record_outcome(Some(&OutcomeObservation {
                    hook_id: Some(js_opt_string(&spec.id).unwrap_or_default()),
                    outcome: Some("block".to_string()),
                }))
                .map_err(|e| format!("Error: {}", e))?;
            let episode = engine.record_episode_block(&EpisodeBlockInput {
                hook_id: js_opt_string(&spec.id),
                session_id: js_opt_string(&session_id),
                episode_id: js_opt_string(&episode_id),
                reason: Some(reason.clone()),
            });
            let mut observed = base.clone();
            observed.insert("reason".into(), reason.clone().into());
            observed.insert("adaptiveStatePersisted".into(), transition.persisted.into());
            observed.insert("causalEpisodePersisted".into(), episode.persisted.into());
            if tier.enforce_verdict && mode == "enforce" {
                observed.insert("decision".into(), "block".into());
                telemetry.record(&serde_json::Value::Object(observed));
                if block_reason.is_none() {
                    block_reason = Some(reason.clone());
                }
            } else {
                observed.insert("decision".into(), "warn".into());
                telemetry.record(&serde_json::Value::Object(observed));
                warnings.push(reason.clone());
            }
            telemetry.corpus_add(
                &spec.id,
                &payload,
                &serde_json::json!({
                    "event": event,
                    "reason": reason,
                    "session_id": session_id,
                    "episode_id": episode_id,
                }),
            );
            continue;
        }
        let infra_failed = result.spawn_error.is_some()
            || result.signal.is_some()
            || result.code.map(|c| c != 0).unwrap_or(false);
        if infra_failed {
            let reason = crash_reason(spec, result);
            let transition = engine
                .record_outcome(Some(&OutcomeObservation {
                    hook_id: Some(js_opt_string(&spec.id).unwrap_or_default()),
                    outcome: Some("infra_failure".to_string()),
                }))
                .map_err(|e| format!("Error: {}", e))?;
            let mut infra = base.clone();
            infra.insert("infra".into(), true.into());
            infra.insert("reason".into(), reason.clone().into());
            infra.insert("adaptiveStatePersisted".into(), transition.persisted.into());
            if tier.on_infra_failure == "block" && blocking(&entry) {
                infra.insert("decision".into(), "block".into());
                telemetry.record(&serde_json::Value::Object(infra));
                if block_reason.is_none() {
                    block_reason = Some(reason);
                }
            } else if tier.on_infra_failure == "warn" {
                infra.insert("decision".into(), "warn".into());
                telemetry.record(&serde_json::Value::Object(infra));
                warnings.push(reason);
            } else {
                infra.insert("decision".into(), "error".into());
                telemetry.record(&serde_json::Value::Object(infra));
            }
            continue;
        }
        let transition = engine
            .record_outcome(Some(&OutcomeObservation {
                hook_id: Some(js_opt_string(&spec.id).unwrap_or_default()),
                outcome: Some("pass".to_string()),
            }))
            .map_err(|e| format!("Error: {}", e))?;
        let mut frame = base.clone();
        frame.insert("decision".into(), "pass".into());
        frame.insert("adaptiveStatePersisted".into(), transition.persisted.into());
        telemetry.record(&serde_json::Value::Object(frame));
    }
    let decision_text = if block_reason.is_some() {
        "block"
    } else {
        "pass"
    };
    let mut output: Vec<(&str, String)> = vec![
        ("decision", json(&decision_text.into())),
        ("results", results_array(&results)),
    ];
    if let Some(reason) = &block_reason {
        output.push(("reason", json(&reason.clone().into())));
    }
    if !warnings.is_empty() {
        let list: Vec<String> = warnings.iter().map(|w| json(&w.clone().into())).collect();
        output.push(("warnings", format!("[{}]", list.join(","))));
    }
    emit(&output);
    if event == "user_prompt_submit" {
        dispatch_bridge(&normalized);
    }
    Ok(())
}

fn run_adaptive(event: &str) -> Result<(), String> {
    let engine = load_engine();
    let telemetry = open_telemetry(&engine.state_dir);
    let result = run_adaptive_body(event, &engine, &telemetry);
    telemetry.close();
    result
}

/// `main()` from `runner.mjs`. `args` is the full argv including the
/// program name; the event is `args[1]`.
pub fn main(args: &[String]) -> i32 {
    let Some(event) = args.get(1) else {
        let _ = write!(std::io::stderr(), "{}", usage());
        let _ = std::io::stderr().flush();
        return EXIT_USAGE;
    };
    let result = if std::env::var("HOOKS_ADAPTIVE_DISABLED").ok().as_deref() == Some("1") {
        run_legacy(event)
    } else {
        run_adaptive(event)
    };
    match result {
        Ok(()) => 0,
        Err(error) => {
            emit(&[
                ("decision", json(&"block".into())),
                ("reason", json(&error.into())),
            ]);
            0
        }
    }
}
