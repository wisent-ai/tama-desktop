//! Reading the registry for hook binaries, and running one of them once.
//!
//! Split from `warm.rs` because a source file here stays at three hundred
//! lines or fewer: the command surface is one half, what it measures is this
//! one.

use std::io::Write;
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::time::{Duration, Instant};

use serde_json::Value;

/// A hook that cannot see its input must not act, so an empty object
/// exercises process start-up and nothing else.
const WARM_PAYLOAD: &str = "{}";
/// Scratch `HOME` for warm runs, under the checkout's ignored build tree, so
/// a hook that does write state writes it there and never into the
/// operator's.
const WARM_HOME: &str = "rust/target/hook-warm-home";
/// How often a warm run asks whether the child has finished.
const POLL_MILLIS: u64 = 5;
/// What a registry command ends with when the hook is one of ours, whichever
/// way the entry spells the directory it lives in.
pub const BIN_MARKER: &str = "bin/tama-";
/// Set in a warm run's environment so a hook can tell start-up from an event.
const WARM_MARKER: &str = "1";
/// Where a machine keeps the release its engine actually executes, and what
/// a hook binary's file name begins with inside it.
const RELEASE_BIN_DIR: &str = "Library/Application Support/Tama/hooks-runtime/current/bin";
const HOOK_BINARY_PREFIX: &str = "tama-";

/// One hook binary the registry points at.
#[derive(Clone)]
pub struct HookBinary {
    pub id: String,
    pub command: String,
    pub path: PathBuf,
}

/// What one warm run observed.
pub struct Warmed {
    pub hook: HookBinary,
    pub elapsed_ms: u128,
    pub code: Option<i32>,
    pub state: State,
}

#[derive(PartialEq, Eq, Clone, Copy)]
pub enum State {
    /// It ran and exited; `elapsed_ms` says what that cost.
    Warm,
    /// The registry names it and the install directory does not hold it.
    Missing,
}

impl State {
    pub fn text(self) -> &'static str {
        match self {
            State::Warm => "warm",
            State::Missing => "missing",
        }
    }
}

/// `$HOME/.local/bin/tama-x`, `${HOME}/…`, `~/…` and an absolute path all name
/// the same file; the registry carries every spelling.
fn expand_home(command: &str) -> PathBuf {
    let home = std::env::var("HOME").unwrap_or_default();
    for prefix in ["$HOME/", "${HOME}/", "~/"] {
        if let Some(rest) = command.strip_prefix(prefix) {
            return Path::new(&home).join(rest);
        }
    }
    PathBuf::from(command)
}

fn collect(value: &Value, found: &mut Vec<HookBinary>) {
    match value {
        Value::Array(items) => items.iter().for_each(|item| collect(item, found)),
        Value::Object(map) => {
            let command = map
                .get("command")
                .and_then(Value::as_str)
                .unwrap_or_default();
            if command.contains(BIN_MARKER)
                && !found.iter().any(|hook| hook.command == command)
            {
                found.push(HookBinary {
                    id: map
                        .get("id")
                        .and_then(Value::as_str)
                        .unwrap_or_default()
                        .to_string(),
                    command: command.to_string(),
                    path: expand_home(command),
                });
            }
            map.values().for_each(|nested| collect(nested, found));
        }
        _ => {}
    }
}

/// Every `tama-…` binary the registry points at, in registry order.
pub fn registry_hooks(registry: &Path) -> Vec<HookBinary> {
    let Ok(text) = std::fs::read_to_string(registry) else {
        return Vec::new();
    };
    let Ok(value) = serde_json::from_str::<Value>(&text) else {
        return Vec::new();
    };
    let mut found = Vec::new();
    collect(&value, &mut found);
    found
}

/// A program that is not a registry hook but runs on the same path and pays
/// the same first-run cost: the engine a provider dispatcher executes, and
/// the CLI beside it.
pub fn runtime_binary(name: &str, path: PathBuf) -> HookBinary {
    HookBinary {
        id: name.to_string(),
        command: path.display().to_string(),
        path,
    }
}

/// Every `tama-…` binary in the sealed release under
/// `~/Library/Application Support/Tama/hooks-runtime/current/bin`.
///
/// These are the copies the engine executes. They are separate files from
/// the ones in `~/.local/bin` the registry names, so each owes the operating
/// system its own first assessment — and on 2026-09-21 one of them,
/// `tama-block-unprompted-topics`, was killed at ten seconds inside a live
/// stop event while every registry copy had been warm for hours (defect
/// 359667bc).
pub fn release_hooks(home: &Path) -> Vec<HookBinary> {
    let Ok(entries) = std::fs::read_dir(home.join(RELEASE_BIN_DIR)) else {
        return Vec::new();
    };
    let mut found: Vec<HookBinary> = entries
        .filter_map(Result::ok)
        .map(|entry| entry.path())
        .filter(|path| path.is_file())
        .filter_map(|path| {
            let name = path.file_name()?.to_str()?.to_string();
            let id = name.strip_prefix(HOOK_BINARY_PREFIX)?.to_string();
            Some(HookBinary {
                id,
                command: path.display().to_string(),
                path,
            })
        })
        .collect();
    found.sort_by(|left, right| left.command.cmp(&right.command));
    found
}

fn observed(hook: &HookBinary, started: Instant, code: Option<i32>, state: State) -> Warmed {
    Warmed {
        hook: hook.clone(),
        elapsed_ms: started.elapsed().as_millis(),
        code,
        state,
    }
}

fn warm_one(hook: &HookBinary, home: &Path) -> Warmed {
    let started = Instant::now();
    if !hook.path.is_file() {
        return observed(hook, started, None, State::Missing);
    }
    let spawned = Command::new(&hook.path)
        .env_clear()
        .env("HOME", home)
        .env("PATH", std::env::var("PATH").unwrap_or_default())
        .env("TAMA_HOOK_WARM", WARM_MARKER)
        .stdin(Stdio::piped())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .spawn();
    let Ok(mut child) = spawned else {
        return observed(hook, started, None, State::Missing);
    };
    if let Some(mut stdin) = child.stdin.take() {
        let _ = stdin.write_all(WARM_PAYLOAD.as_bytes());
    }
    loop {
        match child.try_wait() {
            // Nothing here kills a slow run: paying the operating system's
            // first-execution assessment is the whole point of this command,
            // and what it costs is the measurement, not a failure.
            Ok(Some(status)) => return observed(hook, started, status.code(), State::Warm),
            Ok(None) => std::thread::sleep(Duration::from_millis(POLL_MILLIS)),
            Err(_) => return observed(hook, started, None, State::Missing),
        }
    }
}

/// Warm every hook given, in order, and report what each run observed.
pub fn warm_hooks(root: &Path, hooks: &[HookBinary]) -> Vec<Warmed> {
    let home = root.join(WARM_HOME);
    let _ = std::fs::create_dir_all(&home);
    let warmed = hooks.iter().map(|hook| warm_one(hook, &home)).collect();
    let _ = std::fs::remove_dir_all(&home);
    warmed
}
