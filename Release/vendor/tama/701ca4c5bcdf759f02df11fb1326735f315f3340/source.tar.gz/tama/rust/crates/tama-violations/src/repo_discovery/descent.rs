//! The recursive descent itself, and what it could not read.
//!
//! Split out of [`super::walk`] when the walk gained its unreadable-directory
//! report and the file crossed the three-hundred-line limit the operator's own
//! gate enforces. The seam is meaningful rather than arithmetic: everything
//! here descends the filesystem, and nothing here decides which entry points
//! exist or which directory names are worth pruning.

use std::path::Path;
use std::process::{Command, Stdio};

use serde::Serialize;

/// A directory the walk asked the operating system for and did not get.
///
/// Silence here is what let a pass over a tree it could not read report a
/// clean answer. On 2026-09-12 `tama worktrees list --root
/// ~/Documents/CodingProjects --json` reported no worktrees and nothing
/// unreadable while every `read_dir` under that root was refused with
/// `Operation not permitted`, and that answer was then read as proof that this
/// machine holds no second checkouts. A walk that could not look has to say
/// which directory it could not look into, and why.
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct UnreadableDirectory {
    pub path: String,
    /// The operating system's own sentence, kept verbatim: `Permission
    /// denied`, `Operation not permitted`, `No such file or directory`.
    pub reason: String,
}

/// What one walk found, and what it could not read.
#[derive(Debug, Clone, Default)]
pub struct Discovered {
    pub checkouts: Vec<String>,
    pub unreadable: Vec<UnreadableDirectory>,
}

/// Does `owner` ignore `path`? A dependency checkout always lands in an
/// ignored directory, because the repository that pulled it in refuses to
/// track it.
fn ignored_by_owner(owner: &Path, path: &Path) -> bool {
    Command::new("git")
        .arg("-C")
        .arg(owner)
        .args(["check-ignore", "--quiet", "--"])
        .arg(path)
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .status()
        .map(|status| status.success())
        .unwrap_or(false)
}

pub(super) fn visit(
    dir: &Path,
    repos: &mut Vec<String>,
    unreadable: &mut Vec<UnreadableDirectory>,
    owner: Option<&Path>,
    prune: &[&str],
) {
    visit_pruning(dir, repos, unreadable, owner, true, prune, None)
}

pub(super) fn visit_with(
    dir: &Path,
    repos: &mut Vec<String>,
    unreadable: &mut Vec<UnreadableDirectory>,
    owner: Option<&Path>,
    respect_ignore: bool,
    prune: &[&str],
) {
    visit_pruning(dir, repos, unreadable, owner, respect_ignore, prune, None)
}

/// `respect_ignore` false keeps a checkout its owner ignores, and keeps
/// descending past it. See [`super::walk::discover_every_checkout`] for why
/// ownership questions need that and content questions do not. `prune` is the
/// caller's speed list, because a copies pass and a content scan disagree
/// about which directories are worth walking.
pub(super) fn visit_pruning(
    dir: &Path,
    repos: &mut Vec<String>,
    unreadable: &mut Vec<UnreadableDirectory>,
    owner: Option<&Path>,
    respect_ignore: bool,
    prune: &[&str],
    max_depth: Option<usize>,
) {
    let entries = match std::fs::read_dir(dir) {
        Ok(entries) => entries,
        Err(error) => {
            unreadable.push(UnreadableDirectory {
                path: dir.to_string_lossy().into_owned(),
                reason: error.to_string(),
            });
            return;
        }
    };
    let mut names: Vec<(String, bool)> = Vec::new();
    let mut git_is_file = false;
    let mut is_checkout = false;
    for entry in entries {
        let entry = match entry {
            Ok(entry) => entry,
            Err(error) => {
                unreadable.push(UnreadableDirectory {
                    path: dir.to_string_lossy().into_owned(),
                    reason: error.to_string(),
                });
                continue;
            }
        };
        let file_name = entry.file_name();
        if max_depth == Some(0)
            && file_name != ".git"
            && file_name != "HEAD"
            && file_name != "objects"
        {
            continue;
        }
        let kind = match entry.file_type() {
            Ok(kind) => kind,
            Err(error) => {
                unreadable.push(UnreadableDirectory {
                    path: entry.path().to_string_lossy().into_owned(),
                    reason: error.to_string(),
                });
                continue;
            }
        };
        let is_dir = kind.is_dir();
        let name = file_name.to_string_lossy().into_owned();
        if name == ".git" {
            is_checkout = true;
            git_is_file = !is_dir;
        }
        names.push((name, is_dir));
    }
    // Package managers also keep bare Git clones. Their metadata is the
    // repository itself, not another tree of candidate checkouts.
    if !respect_ignore
        && !is_checkout
        && names
            .iter()
            .any(|(name, directory)| name == "HEAD" && !directory)
        && names
            .iter()
            .any(|(name, directory)| name == "objects" && *directory)
    {
        let output = Command::new("git")
            .arg("-C")
            .arg(dir)
            .args(["rev-parse", "--is-bare-repository"])
            .stdin(Stdio::null())
            .output();
        match output {
            Ok(output) if output.status.success() => {
                if output.stdout == b"true\n" {
                    repos.push(dir.to_string_lossy().into_owned());
                    return;
                }
            }
            Ok(output) => unreadable.push(UnreadableDirectory {
                path: dir.to_string_lossy().into_owned(),
                reason: String::from_utf8_lossy(&output.stderr).trim().to_owned(),
            }),
            Err(error) => unreadable.push(UnreadableDirectory {
                path: dir.to_string_lossy().into_owned(),
                reason: error.to_string(),
            }),
        }
    }
    // Node `readdirSync` returns entries sorted by name.
    names.sort_by(|left, right| left.0.cmp(&right.0));
    if is_checkout {
        // Content scanning excludes linked worktrees and submodules. An
        // ownership inventory must report them, including nested dependencies.
        if git_is_file && respect_ignore {
            return;
        }
        if respect_ignore && owner.is_some_and(|owner| ignored_by_owner(owner, dir)) {
            return;
        }
        repos.push(dir.to_string_lossy().into_owned());
    }
    if max_depth == Some(0) {
        return;
    }
    let child_depth = max_depth.map(|depth| depth - 1);
    let descend_owner = if is_checkout { Some(dir) } else { owner };
    for (name, is_dir) in names {
        if !is_dir || prune.contains(&name.as_str()) {
            continue;
        }
        visit_pruning(
            &dir.join(&name),
            repos,
            unreadable,
            descend_owner,
            respect_ignore,
            prune,
            child_depth,
        );
    }
}
