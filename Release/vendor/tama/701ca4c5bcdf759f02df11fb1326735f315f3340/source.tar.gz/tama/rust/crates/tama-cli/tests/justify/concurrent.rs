//! Several `tama justify record` commands at once, through the real CLI.
//!
//! The registries are one JSON document each, and recording means read, splice
//! one entry, rename the result over the file. Nothing serialised that, so two
//! commands started together each spliced into the same base and the second
//! rename dropped the first entry - while both printed the success line. On
//! 2026-09-10 four entries were recorded from two parallel calls and two of
//! them were simply gone, discovered only because a later gate asked for one of
//! the missing ones.
//!
//! A lost entry is invisible by nature, so the case has to be run rather than
//! reasoned about: these tests drive the built binary against their own
//! registry root and read the result back through the product's own reader.

use std::fs;
use std::path::{Path, PathBuf};
use std::process::{Child, Command, Output, Stdio};
use std::time::{SystemTime, UNIX_EPOCH};

/// A registry root of this test's own, inside the crate's build directory, so
/// no case can touch the operator's registries.
fn registry_root(label: &str) -> PathBuf {
    let unique = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .expect("clock before epoch")
        .as_nanos();
    let path = Path::new(env!("CARGO_TARGET_TMPDIR"))
        .join(format!("justify-{label}-{}-{unique}", std::process::id()));
    fs::create_dir_all(path.join(".shared-hooks")).expect("create the registry root");
    path
}

fn registry_file(home: &Path) -> PathBuf {
    home.join(".shared-hooks").join("file_justifications.json")
}

/// The registry requires fifty words, so the fixture supplies them; the text is
/// what an operator would read next to the entry.
fn justification(key: &str) -> String {
    format!(
        "This entry was written by the concurrency suite for {key} to prove that a recording made \
         at the same moment as its neighbours is still present afterwards, because the registry is \
         a single shared document and a lost entry looks exactly like an entry that was never \
         asked for, which is the failure this test exists to catch before an operator does."
    )
}

fn spawn_record(home: &Path, key: &str) -> Child {
    Command::new(env!("CARGO_BIN_EXE_tama-cli"))
        .args([
            "justify",
            "record",
            "--kind",
            "file",
            "--home",
            &home.to_string_lossy(),
            "--file",
            key,
            "--justification",
            &justification(key),
        ])
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .expect("start tama justify record")
}

fn listed(home: &Path) -> Output {
    Command::new(env!("CARGO_BIN_EXE_tama-cli"))
        .args([
            "justify",
            "list",
            "--kind",
            "file",
            "--home",
            &home.to_string_lossy(),
        ])
        .output()
        .expect("run tama justify list")
}

fn keys(count: usize) -> Vec<String> {
    (0..count)
        .map(|index| format!("/workshop/parallel/case-{index}.swift"))
        .collect()
}

#[test]
fn every_recording_made_in_parallel_is_there_afterwards() {
    let home = registry_root("parallel");
    let keys = keys(6);

    let children: Vec<Child> = keys.iter().map(|key| spawn_record(&home, key)).collect();
    for child in children {
        let output = child.wait_with_output().expect("the recording finishes");
        assert!(
            output.status.success(),
            "a recording failed: {}",
            String::from_utf8_lossy(&output.stderr)
        );
    }

    let output = listed(&home);
    assert!(output.status.success(), "the listing failed");
    let listing = String::from_utf8_lossy(&output.stdout).to_string();
    for key in &keys {
        assert!(
            listing.contains(key.as_str()),
            "{key} reported success and is not in the registry:\n{listing}"
        );
    }
}

#[test]
fn a_registry_written_in_parallel_stays_readable() {
    let home = registry_root("readable");
    let keys = keys(6);

    let children: Vec<Child> = keys.iter().map(|key| spawn_record(&home, key)).collect();
    for mut child in children {
        child.wait().expect("the recording finishes");
    }

    // The document is edited in place by splicing, so overlapping writers could
    // publish a file that no longer parses. The product's own reader is the
    // judge: it refuses a registry it cannot read.
    let output = listed(&home);
    assert!(
        output.status.success(),
        "the registry no longer reads back: {}",
        String::from_utf8_lossy(&output.stderr)
    );
    let text = fs::read_to_string(registry_file(&home)).expect("read the registry");
    assert_eq!(
        text.matches("\"justification\"").count(),
        keys.len(),
        "the document holds a different number of entries than were recorded:\n{text}"
    );
}

#[test]
fn a_writer_that_holds_the_registry_gets_a_refusal_not_a_lost_entry() {
    let home = registry_root("held");
    let key = "/workshop/held/case.swift";
    let first = "/workshop/held/first.swift";

    let recorded = spawn_record(&home, first)
        .wait_with_output()
        .expect("the first recording finishes");
    assert!(recorded.status.success(), "the first recording failed");

    // The serialisation marker the product uses while it edits the document.
    let lock = registry_file(&home).with_extension("lock");
    fs::write(&lock, "").expect("hold the registry");

    let refused = spawn_record(&home, key)
        .wait_with_output()
        .expect("the blocked recording finishes");
    fs::remove_file(&lock).expect("release the registry");

    assert!(
        !refused.status.success(),
        "a recording that could not take the registry reported success"
    );
    let said = String::from_utf8_lossy(&refused.stderr).to_string();
    assert!(
        said.contains("still writing"),
        "the refusal has to say the registry was taken: {said}"
    );

    let listing = String::from_utf8_lossy(&listed(&home).stdout).to_string();
    assert!(
        listing.contains(first),
        "the earlier entry was disturbed:\n{listing}"
    );
    assert!(
        !listing.contains(key),
        "the refused recording was written anyway:\n{listing}"
    );
}
