//! Turning a provider entry into a command line: which executable, which
//! arguments, and how the hooks reach the session it starts.
//!
//! Split out of `one_session/mod.rs`, which had grown past the
//! three-hundred-line limit.

use crate::registry::provider_hooks;
use crate::util::home_dir;
use serde_json::{json, Map, Value};
use std::path::PathBuf;

use super::catalog::{expand_arguments, extension_path, run_hook_path, validate_provider};
use super::isolated_omp_agent;
use super::isolation::isolated_codex_home;

/// A prepared provider launch (`launchForProvider` result).
pub struct LaunchPlan {
    pub executable: String,
    pub args: Vec<String>,
    pub env: Vec<(String, String)>,
    /// Temp directory to remove after the child exits (`cleanup()`).
    pub cleanup: Option<PathBuf>,
}

/// Port of `launchForProvider`.
pub fn launch_for_provider(
    registry: &Value,
    provider_name: &str,
    provider: &Value,
    hook_id: &str,
    mode: &str,
    session: Option<&str>,
    cwd: &str,
) -> Result<LaunchPlan, String> {
    validate_provider(provider)?;
    let mut env = vec![
        ("TAMA_ONE_SESSION_HOOK_ID".to_string(), hook_id.to_string()),
        (
            "TAMA_SESSION_OWNER_PID".to_string(),
            std::process::id().to_string(),
        ),
    ];
    let mut values = Map::new();
    values.insert("cwd".into(), json!(cwd));
    values.insert(
        "extensionPath".into(),
        json!(extension_path().display().to_string()),
    );
    if let Some(session) = session {
        values.insert("session".into(), json!(session));
    }
    let session_dir = std::env::var_os("PI_CODING_AGENT_DIR")
        .map(PathBuf::from)
        .unwrap_or_else(|| home_dir().join(".omp").join("agent"))
        .join("sessions");
    values.insert(
        "sessionDir".into(),
        json!(session_dir.display().to_string()),
    );
    let mut cleanup = None;

    let transport = provider
        .get("hookTransport")
        .and_then(Value::as_str)
        .unwrap_or_default();
    match transport {
        "inline-settings" => {
            let hooks = provider_hooks(registry, hook_id, provider_name, &run_hook_path())?;
            values.insert(
                "hooksJson".into(),
                json!(serde_json::to_string(&json!({ "hooks": hooks })).unwrap_or_default()),
            );
        }
        "isolated-codex-home" => {
            let isolated = isolated_codex_home(registry, hook_id, cwd, provider_name)?;
            env.push(("CODEX_HOME".to_string(), isolated.display().to_string()));
            cleanup = Some(isolated);
        }
        "omp-extension" => {
            let isolated = isolated_omp_agent()?;
            env.push((
                "PI_CODING_AGENT_DIR".to_string(),
                isolated.display().to_string(),
            ));
            cleanup = Some(isolated);
        }
        other => return Err(format!("Unsupported provider hook transport: {}", other)),
    }

    let template = if mode == "new" {
        provider
            .get("newArguments")
            .and_then(Value::as_array)
            .cloned()
            .unwrap_or_default()
    } else {
        provider
            .get("resumeArguments")
            .and_then(Value::as_array)
            .cloned()
            .unwrap_or_default()
    };
    let executable_env = provider
        .get("executableEnv")
        .and_then(Value::as_str)
        .unwrap_or_default();
    let executable = std::env::var(executable_env)
        .ok()
        .filter(|v| !v.is_empty())
        .unwrap_or_else(|| {
            provider
                .get("executable")
                .and_then(Value::as_str)
                .unwrap_or_default()
                .to_string()
        });
    Ok(LaunchPlan {
        executable,
        args: expand_arguments(&template, &values)?,
        env,
        cleanup,
    })
}
