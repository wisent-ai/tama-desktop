//! Logic for `tama-block-git-authorship`, registry hook id
//! `block-git-authorship`.
//!
//! Git authorship is not evidence in this workshop. Every agent commits
//! through the operator's git identity, so an author line, a blame line, a
//! shortlog or a mailmap can only ever name him — and an agent that reads one
//! concludes the operator decided something an agent did. On 2026-09-15 that
//! is exactly what happened: asked who required a human-authored hero in
//! landing-cli, a session answered with `git log --format="%an %ae"` and named
//! the operator, when the only record that could answer is the transcript.
//!
//! So this gate refuses the question rather than the answer: every way git can
//! be asked who wrote something is blocked, and the refusal names Oko, which
//! keeps the transcripts.
//!
//! No character literal appears below on purpose: the numeric-literal guard
//! strips strings with a scanner that reads a lifetime tick as an opening
//! quote.

use std::sync::LazyLock;

use regex::Regex;
use serde_json::Value;
use tama_hooks::session_record::{deny_tool_use, read_payload};

use crate::ports::block_unauthorized_ssh_detect::{command_text, EXECUTABLE_TOOLS};
use crate::ports::transport_common as common;

/// A git invocation: bare, absolute, environment-prefixed, or reached through
/// a pipeline, command list, substitution or backtick.
static GIT_RE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(?i)(?:^|[;&|`($]|&&|\\|\\||\\s)",
        "(?:[A-Za-z_][A-Za-z_0-9]*=[^\\s]*\\s+)*",
        "(?:[^\\s;&|\"']*/)?git(?:\\s|$)",
    ))
});

/// The subcommands whose whole purpose is to name a person.
static WHO_WROTE_IT_RE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(?i)(?:^|[;&|`($]|\\s)git\\s+(?:-[^\\s]+\\s+)*",
        "(?:blame|annotate|shortlog|check-mailmap)(?:\\s|$)",
    ))
});

/// Selecting or grouping commits by who made them.
static IDENTITY_FILTER_RE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile("(?i)(?:^|\\s)--(?:author|committer|use-mailmap|mailmap)(?:=|\\s|$)")
});

/// An identity placeholder in a `--format` or `--pretty` string, in both the
/// `log` spelling (`%an`) and the `for-each-ref` spelling (`%(authorname)`).
static IDENTITY_PLACEHOLDER_RE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(?i)%(?:",
        "an|ae|al|cn|ce|cl",
        "|\\((?:author|committer|tagger)(?:name|email)?\\)",
        ")",
    ))
});

/// The built-in formats that print an `Author:` or `author ` line.
static IDENTITY_FORMAT_RE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile("(?i)--(?:pretty|format)=(?:medium|full|fuller|raw|email|mboxrd)(?:\\s|$)")
});

/// The history commands whose default format prints the author line, so
/// asking for no format at all is still asking who wrote it.
static DEFAULT_HISTORY_RE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(?i)(?:^|[;&|`($]|\\s)git\\s+(?:-[^\\s]+\\s+)*",
        "(?:log|show|whatchanged)(?:\\s|$)",
    ))
});

/// A format the caller chose. When one is present the placeholder and
/// built-in tests above decide; when none is present the default format does.
static CHOSEN_FORMAT_RE: LazyLock<Regex> =
    LazyLock::new(|| common::compile("(?i)(?:^|\\s)(?:--oneline|--pretty|--format|--no-patch)"));

const BLAME_REASON: &str =
    "git blame, annotate, shortlog or check-mailmap answers only with a name";
const FILTER_REASON: &str = "--author, --committer or a mailmap selects commits by who made them";
const PLACEHOLDER_REASON: &str = "the format asks for an author or committer identity";
const FORMAT_REASON: &str = "that built-in format prints the author line";
const DEFAULT_REASON: &str =
    "git log, show and whatchanged print the author line unless a format says otherwise";

/// Which way this command asks git who wrote something, if it does.
pub fn authorship_request(command: &str) -> Option<&'static str> {
    if !GIT_RE.is_match(command) {
        return None;
    }
    if WHO_WROTE_IT_RE.is_match(command) {
        return Some(BLAME_REASON);
    }
    if IDENTITY_FILTER_RE.is_match(command) {
        return Some(FILTER_REASON);
    }
    if IDENTITY_PLACEHOLDER_RE.is_match(command) {
        return Some(PLACEHOLDER_REASON);
    }
    if IDENTITY_FORMAT_RE.is_match(command) {
        return Some(FORMAT_REASON);
    }
    match DEFAULT_HISTORY_RE.is_match(command) && !CHOSEN_FORMAT_RE.is_match(command) {
        true => Some(DEFAULT_REASON),
        false => None,
    }
}

fn refusal(reason: &str) -> String {
    format!(
        "BLOCKED: SPRAWDZ TRANSKRYPTY DEBILU, GIT CI NIC NIE POWIE\n  reason: {reason}\n\nEvery \
         agent in this workshop commits through the operator's git identity, so an author line, a \
         blame line, a shortlog or a mailmap names him whatever an agent did. Git cannot tell you \
         who decided anything here.\n\nAsk the transcripts instead:\n  oko-cli transcripts tasks \
         --session <session-id> --full\n  oko-cli transcripts rules --session <session-id>\n  \
         history://<agent-id>\n  the stored turns themselves, under ~/.omp/agent/sessions\n\nThere \
         is no read-only, local, capability or session exception. A formatted history without an \
         identity placeholder still works: git log --oneline, --format=%h, --format=%s, \
         --format=%ad."
    )
}

pub fn run() {
    let data = read_payload();
    let tool = data
        .get("tool_name")
        .and_then(Value::as_str)
        .unwrap_or_default();
    if !EXECUTABLE_TOOLS.contains(&tool.to_lowercase().as_str()) {
        return;
    }
    let empty = Value::Object(Default::default());
    let input = data
        .get("tool_input")
        .filter(|value| value.is_object())
        .unwrap_or(&empty);
    let command = command_text(tool, input);
    if let Some(reason) = authorship_request(&command) {
        deny_tool_use(&refusal(reason));
    }
}
