//! Deadlines a task did not ask for.
//!
//! A cancelled task looks exactly like a failed one, and a deadline chosen by
//! an agent is a number nobody measured. So the constructs that kill work —
//! the async waiters, the alarm, the abort signal, the killing timer — are
//! refused, and so is editing an existing deadline value. The exceptions are
//! the ones a network call genuinely needs: an HTTP client, a page
//! navigation, a configured server entry.
//!
//! The agent tool directories are skipped, because a provider's own
//! configuration files carry their deadlines as data.
//!
//! As in the sibling modules, the patterns, the message text, the constant
//! names and the test fixtures are assembled from fragments: the words this
//! module matches are words it refuses to see in a file.

use std::sync::LazyLock;

use regex::Regex;

use crate::ports::transport_common as common;

/// The provider directories whose own files carry deadlines as data, plus
/// the hook runtime's own registries, which declare per-event limits the
/// dispatcher enforces rather than any product's work.
const SKIPPED_DIRECTORIES: &[&str] = &[
    "/.claude/",
    "/.factory/",
    "/.codex/",
    "/.shared-hooks/",
    "/hook-declarations/",
];
/// `statement`, `connect`, … each followed by a per-operation deadline.
const OPERATION_PREFIXES: &[&str] = &[
    "statement",
    "connect",
    "read",
    "write",
    "socket",
    "request",
    "query",
    "lock",
    "idle",
    "poll",
    "wait",
    "connection",
];
const NO_TIMEOUTS: &str = "BLOCKED: No timeouts. Do not use ";
const RUN_TO_COMPLETION: &str = ". Let tasks run to completion.";
const LIMIT_WORD_REFUSAL: &str = "BLOCKED: Content contains time limit pattern.";
const PER_OPERATION_REFUSAL: &str = "BLOCKED: Content contains time-limiting pattern.";

/// The constructs that end a task early, each with the call to name in the
/// refusal.
static KILLERS: LazyLock<Vec<(Regex, String)>> = LazyLock::new(|| {
    let calls = [
        concat!("asyncio", "\\.wait_for"),
        concat!("asyncio", "\\.timeout"),
        concat!("signal", "\\.alarm"),
        concat!("AbortSignal", "\\.timeout"),
    ];
    let shown = [
        concat!("asyncio", ".wait_for()"),
        concat!("asyncio", ".timeout()"),
        concat!("signal", ".alarm()"),
        concat!("AbortSignal", ".timeout()"),
    ];
    calls
        .iter()
        .zip(shown.iter())
        .map(|(call, name)| {
            (
                common::compile(&format!("{call}[[:space:]]*\\(")),
                (*name).to_string(),
            )
        })
        .collect()
});

/// A timer used to abort, cancel or kill.
static KILLING_TIMER: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        "{}.*(abort|cancel|kill|reject|throw|clearInterval)",
        concat!("set", "Timeout")
    ))
});

/// The word itself, wherever it is spelled into an identifier, a flag, a
/// field or a sentence: `…_ms`, `--…`, `.…(`, `recv_…`. The operator asked
/// for any use of it to be refused, so there is no exception for an HTTP
/// client, a navigation or a configured server entry any more. Assembled
/// from fragments so this file never carries the words it refuses.
static DEADLINE_WORD: LazyLock<Regex> = LazyLock::new(|| {
    let words = [concat!("time", "out"), concat!("dead", "line")];
    common::compile(&format!("(?i)({})", words.join("|")))
});

/// The spellings that remove a deadline instead of setting one.
///
/// A library can carry its own: `reqwest`'s blocking client cuts every
/// request at thirty seconds unless it is told not to, and Playwright's
/// `waitFor` cuts at thirty unless it is passed zero. On 2026-09-21 deleting
/// an explicit five-minute value from a model stream made the wait *shorter*,
/// ending a route that was still answering. The calls that turn a library's
/// own number off are `…(None)`, `…(0)` and `…: 0`, and refusing them would
/// leave that number in place — the opposite of what this gate is for.
static DISABLING: LazyLock<Regex> = LazyLock::new(|| {
    let words = [concat!("time", "out"), concat!("dead", "line")];
    let word = format!("({})[[:alnum:]_]*", words.join("|"));
    let off = "([[:space:]]*\\([[:space:]]*(None|0)[[:space:]]*\\)|[[:space:]]*:[[:space:]]*0\\b)";
    common::compile(&format!("(?i){word}{off}"))
});

/// Waiting a guessed interval instead of for the outcome that owns it.
static GUESSED_WAIT: LazyLock<Regex> = LazyLock::new(|| {
    let calls = [
        concat!("thread", "::sleep"),
        concat!("time", "\\.sleep"),
        concat!("u", "sleep[[:space:]]*\\("),
        concat!("Thread", "\\.sleep"),
        concat!("\\bsleep[[:space:]]*\\("),
    ];
    common::compile(&format!("(?i)({})", calls.join("|")))
});

/// The words that name a limit outright.
static LIMIT_WORDS: LazyLock<Regex> = LazyLock::new(|| {
    let words = [
        concat!("time", "_limit"),
        concat!("time", "limit"),
        concat!("max", "_time"),
        concat!("max", "time"),
    ];
    let parts: Vec<String> = words.iter().map(|word| format!("\\b{word}\\b")).collect();
    common::compile(&format!("(?i){}", parts.join("|")))
});

/// The per-operation deadlines a database or socket layer carries.
static PER_OPERATION: LazyLock<Regex> = LazyLock::new(|| {
    let parts: Vec<String> = OPERATION_PREFIXES
        .iter()
        .map(|prefix| format!("{prefix}_time.*out"))
        .collect();
    common::compile(&format!("(?i){}", parts.join("|")))
});

fn skipped(path: &str) -> bool {
    SKIPPED_DIRECTORIES
        .iter()
        .any(|directory| path.contains(directory))
}

/// `echo "$LINES" | head -1 | xargs`: the first offending line, trimmed.
fn first_match(content: &str, shape: &Regex) -> Option<String> {
    content
        .lines()
        .find(|line| shape.is_match(line))
        .map(|line| line.split_whitespace().collect::<Vec<_>>().join(" "))
}

/// The complaint this content earns for ending work early, if any.
pub(crate) fn complaint(path: &str, content: &str) -> Option<String> {
    if skipped(path) {
        return None;
    }
    for (pattern, name) in KILLERS.iter() {
        if pattern.is_match(content) {
            return Some(format!("{NO_TIMEOUTS}{name}{RUN_TO_COMPLETION}"));
        }
    }
    if let Some(line) = first_match(content, &DEADLINE_WORD) {
        if !DISABLING.is_match(&line) {
            return Some(format!("{NO_TIMEOUTS}{line}{RUN_TO_COMPLETION}"));
        }
    }
    if let Some(line) = first_match(content, &GUESSED_WAIT) {
        return Some(format!("{NO_TIMEOUTS}{line}{RUN_TO_COMPLETION}"));
    }
    if KILLING_TIMER.is_match(content) {
        return Some(format!(
            "{NO_TIMEOUTS}{} to kill/abort tasks.",
            concat!("set", "Timeout")
        ));
    }
    if LIMIT_WORDS.is_match(content) {
        return Some(LIMIT_WORD_REFUSAL.to_string());
    }
    match PER_OPERATION.is_match(content) {
        true => Some(PER_OPERATION_REFUSAL.to_string()),
        false => None,
    }
}

#[cfg(test)]
mod tests {
    use super::complaint;

    const SOURCE: &str = "/repo/src/worker.py";
    const DEADLINE: &str = "timeout";

    #[test]
    fn the_killing_constructs_are_refused_and_named() {
        for call in [
            concat!("asyncio", ".wait_for(task)"),
            concat!("asyncio", ".timeout(5)"),
            concat!("signal", ".alarm(3)"),
            concat!("AbortSignal", ".timeout(1000)"),
        ] {
            let found = complaint(SOURCE, call).expect("a deadline");
            assert!(found.contains("No timeouts"), "{found}");
        }
    }

    #[test]
    fn a_timer_that_kills_is_refused() {
        let code = format!(
            "{}(() => controller.abort(), 500)",
            concat!("set", "Timeout")
        );
        let found = complaint(SOURCE, &code).expect("a killing timer");
        assert!(found.contains("No timeouts"), "{found}");
        assert!(found.contains("controller.abort()"), "{found}");
    }

    /// The operator's rule after a session waited out a rollout by the clock:
    /// any use of the word, including the one an HTTP client used to be
    /// allowed. Both lines below passed before 2026-09-21.
    #[test]
    fn a_network_deadline_is_refused_like_any_other() {
        for line in [
            format!("response = httpx.get(url, {DEADLINE}=30)"),
            format!("worker_{DEADLINE} = 45"),
        ] {
            let found = complaint(SOURCE, &line).expect("a deadline");
            assert!(found.contains("No timeouts"), "{found}");
            assert!(found.contains(line.trim()), "{found}");
        }
    }

    /// Turning a library's own deadline off is the opposite of setting one:
    /// `reqwest` says it with `None`, Playwright with zero.
    #[test]
    fn the_calls_that_disable_a_library_deadline_pass() {
        for line in [
            format!(".{DEADLINE}(None)"),
            format!(".{DEADLINE}(0)"),
            format!("await locator.waitFor({{ state, {DEADLINE}: 0 }});"),
            format!("{DEADLINE}Ms: 0,"),
        ] {
            assert_eq!(complaint(SOURCE, &line), None, "{line}");
        }
    }

    /// …and only those: any value beside them is still refused.
    #[test]
    fn a_value_is_refused_even_beside_the_disabling_call() {
        for line in [
            format!(".{DEADLINE}(Some(Duration::from_secs(30)))"),
            format!("await locator.waitFor({{ {DEADLINE}: 30000 }});"),
            format!("{DEADLINE}Ms: 5_000,"),
        ] {
            assert!(complaint(SOURCE, &line).is_some(), "{line}");
        }
    }

    /// A guessed interval is the same mistake spelled as a wait.
    #[test]
    fn a_guessed_wait_is_refused() {
        for call in [
            concat!("thread", "::sleep(Duration::from_secs(20))"),
            concat!("time", ".sleep(20)"),
            "sleep(20)",
        ] {
            let found = complaint(SOURCE, call).expect("a guessed wait");
            assert!(found.contains("run to completion"), "{found}");
        }
    }

    /// The hook runtime's own registry declares per-event limits as data.
    #[test]
    fn the_hook_declarations_are_skipped() {
        let declaration = format!("\"events\": [{{ \"{DEADLINE}\": 10 }}]");
        assert_eq!(
            complaint(
                "/repo/hook-declarations/block-one-off-repairs.json",
                &declaration
            ),
            None
        );
    }

    #[test]
    fn the_limit_words_are_refused() {
        for word in [
            concat!("time", "_limit"),
            concat!("max", "_time"),
            concat!("statement", "_timeout"),
        ] {
            assert!(
                complaint(SOURCE, &format!("x = {word}")).is_some(),
                "{word}"
            );
        }
    }

    /// A provider's own configuration carries its deadlines as data.
    #[test]
    fn the_agent_tool_directories_are_skipped() {
        let code = format!("{}(() => kill(), 10)", concat!("set", "Timeout"));
        assert_eq!(complaint("/Users/someone/.codex/hooks.json", &code), None);
    }

    #[test]
    fn ordinary_code_passes() {
        assert_eq!(complaint(SOURCE, "def run(): return compute()"), None);
    }
}
