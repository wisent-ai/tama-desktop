//! Shared std-only helpers for the `tama-hook-tools` binaries:
//! path resolution, JS-compatible primitives (`Number`, `String`, truthiness),
//! ISO-8601 timestamps, SHA-256, UUIDv4, atomic JSON writes and a minimal
//! unix signal FFI (declared directly, no external crates).

mod clock;
mod digest;
mod json_order;

pub use clock::{iso_from_millis, iso_now, now_millis, parse_iso_millis};
pub use digest::{random_uuid, sha256_hex};
pub use json_order::{ordered_object_keys, stringify_pretty_ordered};

use serde_json::Value;
use std::path::{Component, Path, PathBuf};

/// Node `os.homedir()` equivalent: `$HOME` on unix.
pub fn home_dir() -> PathBuf {
    std::env::var_os("HOME")
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from("/"))
}

/// Repo root: `TAMA_ROOT` when set, otherwise resolved relative to the crate
/// manifest (`rust/crates/tama-hook-tools` -> three levels up).
pub fn repo_root() -> PathBuf {
    if let Some(root) = std::env::var_os("TAMA_ROOT") {
        return PathBuf::from(root);
    }
    normalize_path(
        Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../..")
            .as_path(),
    )
}

/// Directory that mirrors the JS `shared-hooks/` folder inside the repo.
pub fn shared_hooks_root() -> PathBuf {
    repo_root().join("shared-hooks")
}

/// Lexical normalization (`.`, `..`), without touching the filesystem —
/// the same semantics as Node `path.resolve` on an already-absolute path.
pub fn normalize_path(path: &Path) -> PathBuf {
    let mut out = PathBuf::new();
    for component in path.components() {
        match component {
            Component::CurDir => {}
            Component::ParentDir => {
                out.pop();
            }
            other => out.push(other.as_os_str()),
        }
    }
    out
}

/// Node `path.resolve(value)`.
pub fn resolve_path(value: &str) -> PathBuf {
    let path = Path::new(value);
    if path.is_absolute() {
        normalize_path(path)
    } else {
        let cwd = std::env::current_dir().unwrap_or_else(|_| PathBuf::from("/"));
        normalize_path(&cwd.join(path))
    }
}

/// Node `path.extname`.
pub fn extname(path: &str) -> String {
    let base = path.rsplit('/').next().unwrap_or(path);
    match base.rfind('.') {
        None | Some(0) => String::new(),
        Some(index) => base[index..].to_string(),
    }
}

/// JS `String(value)` for JSON values.
pub fn js_string(value: &Value) -> String {
    match value {
        Value::Null => "null".to_string(),
        Value::Bool(b) => b.to_string(),
        Value::Number(n) => n.to_string(),
        Value::String(s) => s.clone(),
        Value::Array(items) => items.iter().map(js_string).collect::<Vec<_>>().join(","),
        Value::Object(_) => "[object Object]".to_string(),
    }
}

/// JS `String(value || '')` — empty string for null/missing/false/0/"".
pub fn js_string_or_empty(value: Option<&Value>) -> String {
    match value {
        Some(v) if js_truthy(v) => js_string(v),
        _ => String::new(),
    }
}

/// JS truthiness for JSON values.
pub fn js_truthy(value: &Value) -> bool {
    match value {
        Value::Null => false,
        Value::Bool(b) => *b,
        Value::Number(n) => n.as_f64().map(|f| f != 0.0 && !f.is_nan()).unwrap_or(false),
        Value::String(s) => !s.is_empty(),
        Value::Array(_) | Value::Object(_) => true,
    }
}

/// JS `Number(string)`.
pub fn js_number(text: &str) -> f64 {
    let trimmed = text.trim();
    if trimmed.is_empty() {
        return 0.0;
    }
    match trimmed {
        "Infinity" | "+Infinity" => f64::INFINITY,
        "-Infinity" => f64::NEG_INFINITY,
        _ => trimmed.parse::<f64>().unwrap_or(f64::NAN),
    }
}

/// JS number-to-string interpolation (`${n}`) for JSON numbers.
pub fn js_number_to_string(value: &Value) -> String {
    match value.as_f64() {
        Some(f) => {
            if f.is_finite() && f.fract() == 0.0 && f.abs() < 1e21 {
                format!("{}", f as i64)
            } else {
                format!("{}", f)
            }
        }
        None => js_string(value),
    }
}

/// Port of `atomicWriteJson` from session-control.mjs / omp-shared-hooks.js:
/// creates `root` with mode 0700, writes `${JSON.stringify(value)}\n` to a
/// unique sibling temp file (mode 0600, exclusive create), then renames.
pub fn atomic_write_json(root: &Path, path: &Path, value: &Value) -> std::io::Result<()> {
    use std::os::unix::fs::OpenOptionsExt;
    use std::os::unix::fs::PermissionsExt;
    std::fs::create_dir_all(root)?;
    std::fs::set_permissions(root, std::fs::Permissions::from_mode(0o700))?;
    use std::io::Write;
    let temporary = format!(
        "{}.{}.{}.tmp",
        path.display(),
        std::process::id(),
        random_uuid()
    );
    let result = (|| -> std::io::Result<()> {
        let mut file = std::fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .mode(0o600)
            .open(&temporary)?;
        file.write_all(
            format!("{}\n", serde_json::to_string(value).unwrap_or_default()).as_bytes(),
        )?;
        drop(file);
        std::fs::rename(&temporary, path)?;
        Ok(())
    })();
    let _ = std::fs::remove_file(&temporary);
    result
}

/// JS `JSON.parse(fs.readFileSync(path, 'utf8'))` with a silent fallback.
pub fn load_json(path: &Path, fallback: Value) -> Value {
    std::fs::read_to_string(path)
        .ok()
        .and_then(|text| serde_json::from_str(&text).ok())
        .unwrap_or(fallback)
}

/// Minimal unix signal FFI (libc symbols are always linked on unix; declared
/// here directly so no external crate is needed).
#[cfg(unix)]
pub mod sys {
    pub const SIGHUP: i32 = 1;
    pub const SIGINT: i32 = 2;
    pub const SIGTERM: i32 = 15;

    extern "C" {
        fn signal(signum: i32, handler: extern "C" fn(i32)) -> isize;
        fn kill(pid: i32, sig: i32) -> i32;
    }

    pub fn install_signal_handler(signum: i32, handler: extern "C" fn(i32)) {
        unsafe {
            signal(signum, handler);
        }
    }

    /// Returns false when the process no longer exists (ESRCH).
    pub fn send_signal(pid: u32, sig: i32) -> bool {
        unsafe { kill(pid as i32, sig) == 0 }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn sha256_known_vectors() {
        assert_eq!(
            sha256_hex(b"abc"),
            "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
        );
        assert_eq!(
            sha256_hex(b""),
            "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        );
    }

    /// Values cross-checked against Node `Date.parse` / `Date#toISOString`.
    #[test]
    fn iso_time_matches_node() {
        assert_eq!(
            parse_iso_millis("2026-07-25T01:46:13.612Z"),
            1784943973612.0
        );
        assert_eq!(parse_iso_millis("2026-07-25"), 1784937600000.0);
        assert_eq!(
            parse_iso_millis("2026-01-01T00:00:00+02:00"),
            1767218400000.0
        );
        assert_eq!(parse_iso_millis("2026-07-25T01:46:13Z"), 1784943973000.0);
        assert!(parse_iso_millis("not a date").is_nan());
        assert!(parse_iso_millis("2026-13-01").is_nan());
        assert_eq!(iso_from_millis(1784943973612.0), "2026-07-25T01:46:13.612Z");
        assert_eq!(iso_from_millis(1784928373612.0), "2026-07-24T21:26:13.612Z");
    }

    #[test]
    fn extname_matches_node() {
        assert_eq!(extname("foo.tar.gz"), ".gz");
        assert_eq!(extname(".gitignore"), "");
        assert_eq!(extname("/a/b/c.py"), ".py");
        assert_eq!(extname("noext"), "");
        assert_eq!(extname("foo."), ".");
    }
}
