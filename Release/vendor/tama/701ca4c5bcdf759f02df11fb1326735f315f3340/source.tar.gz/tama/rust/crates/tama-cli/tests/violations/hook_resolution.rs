//! Which write guard a scan replays, and what it says when there is none.
//!
//! The installed CLI is built inside the release's export tree, and the
//! release deletes that tree when the build finishes, so the compiled-in
//! default hook path names a directory that no longer exists. Every scan
//! started outside a tama checkout answered `hook not found: …/rust/target/
//! hook-release-src/shared-hooks/pre_write_edit.sh` and scanned nothing —
//! including `--size-only`, which replays no hook at all. These cases drive
//! the real binary with no hook tree where the compiled-in path points.

use std::fs;
use std::path::Path;

use crate::fixture::{Fixture, LIMIT};

/// A home directory with no `.shared-hooks`, and a checkout root with no
/// `shared-hooks`: the state of every machine that installed the CLI and
/// then let the release clean its build tree.
fn empty_environment(f: &Fixture) -> (std::path::PathBuf, std::path::PathBuf) {
    let root = f.root.join("no-checkout");
    let home = f.root.join("no-home");
    fs::create_dir_all(&root).unwrap();
    fs::create_dir_all(&home).unwrap();
    (root, home)
}

fn long_source(f: &Fixture) {
    fs::write(f.repo.join("long.js"), "// source row\n".repeat(LIMIT + 1)).unwrap();
}

/// The size pass reads files and counts lines. It never starts a hook, so a
/// missing hook must not stop it — that refusal is what made the fast
/// whole-machine audit unusable.
#[test]
fn size_only_scans_with_no_hook_tree_anywhere() {
    let f = Fixture::new();
    long_source(&f);
    let (root, home) = empty_environment(&f);
    let out = f.run_in(
        "size-only-no-hook",
        "find-violations",
        &["--json", "--size-only"],
        &[("TAMA_ROOT", &root), ("HOME", &home)],
    );
    let stderr = String::from_utf8_lossy(&out.stderr).into_owned();
    assert_eq!(out.status.code(), Some(1), "{stderr}");
    assert!(!stderr.contains("hook not found"), "{stderr}");
    let report: serde_json::Value = serde_json::from_slice(&out.stdout).unwrap();
    let hits = report["repos"][0]["violations"].as_array().unwrap();
    assert!(hits.iter().any(|hit| hit["path"] == "long.js"), "{report}");
}

/// `tama install` writes the guards to `~/.shared-hooks`, and that copy is
/// the one enforcing policy on the machine. When the checkout has none, the
/// replay uses it instead of refusing.
#[test]
fn replay_falls_back_to_the_installed_hook_tree() {
    let f = Fixture::new();
    long_source(&f);
    let (root, home) = empty_environment(&f);
    let installed = home.join(".shared-hooks");
    fs::create_dir_all(&installed).unwrap();
    for entry in fs::read_dir(f.tama.join("shared-hooks")).unwrap() {
        let entry = entry.unwrap();
        if entry.file_type().unwrap().is_file() {
            let target = installed.join(entry.file_name());
            fs::copy(entry.path(), &target).unwrap();
        }
    }
    let out = f.run_in(
        "replay-installed-hook",
        "find-violations",
        &["--json"],
        &[("TAMA_ROOT", &root), ("HOME", &home)],
    );
    let stderr = String::from_utf8_lossy(&out.stderr).into_owned();
    assert_eq!(out.status.code(), Some(1), "{stderr}");
    let report: serde_json::Value = serde_json::from_slice(&out.stdout).unwrap();
    let hits = report["repos"][0]["violations"].as_array().unwrap();
    assert!(
        hits.iter().any(|hit| {
            hit["path"] == "long.js"
                && hit["message"]
                    .as_str()
                    .unwrap_or_default()
                    .contains("max 300")
        }),
        "{report}"
    );
}

/// With no hook in either place, a replay cannot run. The refusal keeps its
/// documented first line and then says where the command looked and how to
/// get a scan out of the machine anyway.
#[test]
fn a_missing_hook_names_every_place_that_was_tried() {
    let f = Fixture::new();
    long_source(&f);
    let (root, home) = empty_environment(&f);
    let out = f.run_in(
        "replay-no-hook",
        "find-violations",
        &["--json"],
        &[("TAMA_ROOT", &root), ("HOME", &home)],
    );
    let stderr = String::from_utf8_lossy(&out.stderr).into_owned();
    assert_eq!(out.status.code(), Some(2), "{stderr}");
    let expected = root.join("shared-hooks").join("pre_write_edit.sh");
    assert_eq!(
        stderr.lines().next().unwrap_or_default(),
        format!("hook not found: {}", expected.display())
    );
    assert!(
        stderr.contains(
            &home
                .join(".shared-hooks")
                .join("pre_write_edit.sh")
                .display()
                .to_string()
        ),
        "{stderr}"
    );
    assert!(stderr.contains("--size-only"), "{stderr}");
}

/// A path the caller typed is answered with the one sentence the CLI
/// contract documents: their input is wrong, not the machine's layout.
#[test]
fn a_named_hook_that_is_missing_is_refused_without_a_search_list() {
    let f = Fixture::new();
    long_source(&f);
    let (root, home) = empty_environment(&f);
    let named = root.join("nowhere.sh");
    let out = f.run_in(
        "replay-named-hook",
        "find-violations",
        &["--json", "--hook", named.to_str().unwrap()],
        &[("TAMA_ROOT", &root), ("HOME", &home)],
    );
    let stderr = String::from_utf8_lossy(&out.stderr).into_owned();
    assert_eq!(out.status.code(), Some(2), "{stderr}");
    assert_eq!(
        stderr.trim(),
        format!("hook not found: {}", named.display())
    );
    assert!(!Path::new(&named).exists());
}
