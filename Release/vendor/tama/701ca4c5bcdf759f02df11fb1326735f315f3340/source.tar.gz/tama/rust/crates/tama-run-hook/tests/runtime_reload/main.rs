#![cfg(unix)]

mod process;

use std::fs;
use std::io::Write;
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::time::{SystemTime, UNIX_EPOCH};

use serde_json::{json, Value};
use tama_hooks::sha256::sha256_hex;

use process::RuntimeProcess;

fn root(label: &str) -> PathBuf {
    let nonce = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap()
        .as_nanos();
    let root = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("../../target/runtime-reload-evidence")
        .join(format!("{label}-{}-{nonce}", std::process::id()));
    fs::create_dir_all(root.join("data")).unwrap();
    root.canonicalize().unwrap()
}

fn quote(path: &Path) -> String {
    format!("'{}'", path.to_str().unwrap().replace('\'', "'\\''"))
}

fn registry(root: &Path, release: &str, program: &str, input: &str) -> Value {
    let mut document = json!({
        "releaseId": release,
        "events": {
            "pre_tool_use:read": {
                "blocking": true,
                "hooks": [{
                    "id": "persist-observation",
                    "command": format!("{program} {} {}", quote(&root.join("data").join(input)), quote(&root.join("data/observation"))),
                }],
            },
        },
    });
    let checksum = sha256_hex(&serde_json::to_vec(&document).unwrap());
    document["catalogChecksum"] = json!(checksum);
    document
}

fn publish(root: &Path, document: &Value) {
    let pending = root.join("registry.pending");
    fs::write(&pending, serde_json::to_vec(document).unwrap()).unwrap();
    fs::rename(pending, root.join("registry.json")).unwrap();
}

fn dispatch(process: &mut RuntimeProcess, id: &str) -> Value {
    process.request(json!({
        "id": id, "op": "dispatch", "event": "pre_tool_use:read",
        "payload": { "session_id": "isolated-reload-session", "tool_name": "read", "tool_input": { "path": "data" } },
    }))
}

#[test]
fn reload_changes_executed_hook_code_and_rejects_bad_replacements_without_restart() {
    let root = root("live");
    fs::write(root.join("data/a"), "first").unwrap();
    fs::write(root.join("data/b"), "replacement").unwrap();
    fs::write(root.join("data/c"), "automatic").unwrap();
    publish(&root, &registry(&root, "release-a", "/bin/cp", "a"));
    let (mut process, ready) = RuntimeProcess::start(&root, "omp");
    let pid = ready["state"]["processId"].clone();
    let first = dispatch(&mut process, "first");
    assert_eq!(first["ok"], true);
    assert_eq!(
        fs::read_to_string(root.join("data/observation")).unwrap(),
        "first"
    );
    assert!(root.join("data/a").exists());

    // This replacement runs a different executable: move, rather than copy.
    // Reading the resulting files proves that new hook code actually ran.
    publish(&root, &registry(&root, "release-b", "/bin/mv", "b"));
    let reloaded = process.request(json!({ "id": "reload", "op": "reload" }));
    assert_eq!(reloaded["ok"], true);
    assert_eq!(reloaded["result"]["reloaded"], true);
    assert_eq!(reloaded["state"]["processId"], pid);
    assert_eq!(reloaded["state"]["loadedReleaseId"], "release-b");
    assert_eq!(
        fs::read_to_string(root.join("data/observation")).unwrap(),
        "first"
    );
    let second = dispatch(&mut process, "second");
    assert_eq!(second["ok"], true);
    assert_eq!(
        fs::read_to_string(root.join("data/observation")).unwrap(),
        "replacement"
    );
    assert!(
        !root.join("data/b").exists(),
        "the replacement move hook must consume b"
    );
    let preceding = second["state"].clone();

    fs::write(root.join("registry.json"), "{\"events\":\n").unwrap();
    let malformed = process.request(json!({ "id": "malformed", "op": "reload" }));
    assert_eq!(malformed["ok"], false);
    assert!(malformed["error"]
        .as_str()
        .unwrap()
        .contains(root.join("registry.json").to_str().unwrap()));
    assert_eq!(
        malformed["state"]["catalogChecksum"],
        preceding["catalogChecksum"]
    );
    assert_eq!(malformed["state"]["generation"], preceding["generation"]);
    assert_eq!(malformed["state"]["processId"], pid);
    let refused_dispatch = dispatch(&mut process, "refused-dispatch");
    assert_eq!(refused_dispatch["ok"], false);
    assert_eq!(
        fs::read_to_string(root.join("data/observation")).unwrap(),
        "replacement"
    );

    let valid = registry(&root, "release-c", "/bin/cp", "c");
    let mut wrong_seal = valid.clone();
    wrong_seal["catalogChecksum"] = json!("incorrect");
    publish(&root, &wrong_seal);
    let mismatch = process.request(json!({ "id": "mismatch", "op": "reload" }));
    assert_eq!(mismatch["ok"], false);
    assert_eq!(
        mismatch["state"]["catalogChecksum"],
        preceding["catalogChecksum"]
    );
    assert_eq!(mismatch["state"]["generation"], preceding["generation"]);
    assert_eq!(
        fs::read_to_string(root.join("data/observation")).unwrap(),
        "replacement"
    );

    // No reload command is sent here: the next real event adopts the valid
    // replacement automatically, in this same native process and session.
    publish(&root, &valid);
    let automatic = dispatch(&mut process, "automatic");
    assert_eq!(automatic["ok"], true);
    assert_eq!(automatic["state"]["processId"], pid);
    assert_eq!(automatic["state"]["loadedReleaseId"], "release-c");
    assert_eq!(
        automatic["state"]["catalogChecksum"],
        valid["catalogChecksum"]
    );
    assert_eq!(automatic["state"]["lastReloadError"], Value::Null);
    assert_eq!(
        fs::read_to_string(root.join("data/observation")).unwrap(),
        "automatic"
    );
    assert!(root.join("data/c").exists());
    process.finish();
}

#[test]
fn harness_adapters_keep_their_response_contract_while_using_the_same_hook_engine() {
    let root = root("adapters");
    fs::write(root.join("data/input"), "first hook ran").unwrap();
    let mut document = registry(&root, "adapter-release", "/bin/cp", "input");
    let hooks = document["events"]["pre_tool_use:read"]["hooks"]
        .as_array_mut()
        .unwrap();
    hooks.push(json!({ "id": "deny-operation", "command": "/usr/bin/false" }));
    hooks.push(json!({
        "id": "must-not-run",
        "command": format!("/bin/cp {} {}", quote(&root.join("data/input")), quote(&root.join("data/after-denial"))),
    }));
    document.as_object_mut().unwrap().remove("catalogChecksum");
    document["catalogChecksum"] = json!(sha256_hex(&serde_json::to_vec(&document).unwrap()));
    publish(&root, &document);
    process::record_run(
        &root,
        json!([
            ["pre_tool_use:read", "claude"],
            ["pre_tool_use:read", "codex"]
        ]),
    );
    for (agent, expected_exit) in [("claude", 2), ("codex", 0)] {
        let mut child = Command::new(env!("CARGO_BIN_EXE_tama-run-hook"))
            .args(["pre_tool_use:read", agent])
            .current_dir(&root)
            .env("HOME", &root)
            .env("AGENT_HOOK_REGISTRY", root.join("registry.json"))
            .env("TAMA_HOOK_ENFORCEMENT", root.join("enforcement.json"))
            .env("TAMA_EMERGENCY_STATE", root.join("emergency.json"))
            .env("TAMA_SESSION_CONTROL_ROOT", root.join("sessions"))
            .env_remove("TAMA_PROVIDER")
            .env_remove("TAMA_ONLY_HOOK_ID")
            .env_remove("TAMA_ENABLED_HOOKS")
            .env_remove("TAMA_DISABLED_HOOKS")
            .env_remove("AGENT_STRUCTURED_CAPABILITY")
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .spawn()
            .unwrap();
        child
            .stdin
            .take()
            .unwrap()
            .write_all(b"{\"session_id\":\"adapter-session\",\"tool_name\":\"read\"}")
            .unwrap();
        let output = child.wait_with_output().unwrap();
        fs::write(
            root.join("reports").join(format!("{agent}.json")),
            serde_json::to_vec_pretty(&json!({
                "exitCode": output.status.code(),
                "stdin": "{\"session_id\":\"adapter-session\",\"tool_name\":\"read\"}",
                "stdout": String::from_utf8_lossy(&output.stdout),
                "stderr": String::from_utf8_lossy(&output.stderr),
            }))
            .unwrap(),
        )
        .unwrap();
        assert_eq!(output.status.code(), Some(expected_exit));
        let response: Value = serde_json::from_slice(&output.stdout).unwrap();
        assert_eq!(response["decision"], "block");
        assert_eq!(
            fs::read_to_string(root.join("data/observation")).unwrap(),
            "first hook ran"
        );
        assert!(!root.join("data/after-denial").exists());
        if agent == "codex" {
            assert!(response.get("results").is_none());
            assert!(response.get("blockedHookId").is_none());
        } else {
            assert_eq!(response["blockedHookId"], "deny-operation");
        }
        fs::remove_file(root.join("data/observation")).unwrap();
    }
    println!("retained adapter evidence: {}", root.display());
}
