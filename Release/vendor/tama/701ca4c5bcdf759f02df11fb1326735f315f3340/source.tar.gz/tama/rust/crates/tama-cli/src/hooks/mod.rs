//! `tama hooks <command>`: the three halves of adding, changing or keeping a
//! hook, each behind one verb. `declare` writes the repository documents —
//! the catalogue entry, the registry binding, the reconciled sources and the
//! seal. `release` builds the native hooks from published main, installs the
//! ones that changed, and stages, seals and installs the live release this
//! machine runs. `warm` runs each installed binary once so the operating
//! system's first-execution assessment is paid outside a live event, which is
//! what turned a 10-second hook timeout into a refusal on 2026-09-20.
//! Before these, both writing halves existed only as shell files written into
//! an ignored build directory and handed to the operator to run.

pub mod declare;
pub mod release;
pub mod warm;

use std::path::Path;

const USAGE: &str = "usage: tama hooks <declare|release|warm> [...]\n\
     \n\
     declare --file <declaration.json> [--dry-run]   catalogue entry, registry binding, reseal\n\
     release [--dry-run] [--enforce <hook-id>,…]     build from origin/main, install, stage, seal\n\
     warm [--only <hook-id>,…] [--json]              run each installed binary once, report timings";

const REFUSED: i32 = 2;

pub fn main(argv: &[String], root: &Path) -> i32 {
    match argv.first().map(String::as_str) {
        Some("declare") => declare::main(&argv[1..], root),
        Some("release") => release::main(&argv[1..], root),
        Some("warm") => warm::main(&argv[1..], root),
        Some("--help") | Some("-h") | Some("help") | None => {
            println!("{USAGE}");
            0
        }
        Some(other) => {
            eprintln!("unknown hooks command {other}\n{USAGE}");
            REFUSED
        }
    }
}
