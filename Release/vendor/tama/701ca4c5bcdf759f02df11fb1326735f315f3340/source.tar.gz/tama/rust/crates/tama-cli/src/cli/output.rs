//! Output helpers extracted from the crate root: the usage text, JSON
//! printers, and the key-order workaround shared by the command handlers.

use std::io::Write;

use serde::Serialize;

use tama_core::policy_bundle::PolicyBundleImportResult;

/// The usage text from `usage()` in `src/cli.mjs`, byte-for-byte (the JS
/// template literal ends with a newline; `console.error` adds one more).
const USAGE: &str = "tama <command>

Commands:
  list [--json]              List hooks from the catalog
  show <hook-id> [--json]    Show one hook
  validate [--json]          Validate catalog/source archive
  install-plan [--json]      Show runtime scopes and target paths
  install                    Install user-global Git dispatchers; use --set-git-config to write Git config
  onboarding [--reset] [--policy-bundle <dir>] [--replace] [--home <path>]
                             Show first use and optionally import an inactive policy bundle
  policy import --source <dir> [--replace] [--json] [--home <path>]
                             Validate and persist an inactive policy bundle
  policy list [--json] [--home <path>]
                             List imported policy bundles and source identities
  verify                     Run catalog validation and hook block fixtures
  justify <record|show|remove|list> [--file <path>] [--justification <text>] [--kind file|test] [--quote <text>] [--expires-at <iso>] [--home <path>] [--json]
                             Record, read or remove a justification the authorization gates require
  rules <list|remove> [--id <id>] [--json]
                             Read or prune the rules the frustration drafter recorded; removing one
                             the operator really asked for needs DEVICE_HOOK_EDIT_APPROVED=1
  build <record|list|close> --kind build|restart --target <name> [--reason <text>] [--revision <rev>]
                             [--minutes N] [--home <path>] [--json]
                             Write or read the build and restart registry that
                             block-unregistered-build-or-restart reads before a build or a restart runs
  mcp-config                 Print MCP server config snippet
  find-violations (--repo <path> | --tree <dir> | --owner <gh-owner> | --me) [...] [--json]
                             Report existing hook rule violations in repositories (first hit per file)
  clean (same targets) [--rule size|all] [--model <brama-route>] [--max-rounds N] [--skip <fragment>] [--dry-run]
                             Ask Brama for one patch per repo to fix violations, apply it, then re-scan
  declare-root --repo <path> [--apply] [--json]
                             Declare a repository root whose files are all fixed there by a tool
  brama-check [--json]       Which Brama address this machine resolves, and what the gateway answers
  sessions [--json] [--home <path>]  Show every live agent session and its hook state
  hooks <declare|release> [...]
                             Add or change a hook: declare --file <declaration.json> writes the
                             catalogue entry, the registry binding and the seal; release builds the
                             native hooks from origin/main, installs the changed ones and installs
                             the live release. Both need DEVICE_HOOK_EDIT_APPROVED=1.
  enforcement <command> [...] Configure machine hook selection: status|only|add|remove|all
  task scope <command> [...] What the operator's current instruction touches: show|set|clear.
                             `set --session ID --repository NAME…` copies the captured prompt and
                             binds the declaration to it; block-off-task-work reads it.
  provider-config --provider <claude|codex> --dispatcher <command> [--json]
                             Print the hook block an install writes into that provider's config
  serve [--port N]             Run the loopback desktop backend; prints one ready line, then serves /v1 endpoints
  adaptive <command> [...]   Adaptive layer doctor: status|drift|queue|repair|apply|install|uninstall|claude-config
  worktrees <command> [...]  Linked git worktrees under a tree: list|remove
  copies <command> [...]     Second full checkouts under a tree: list|remove
";

/// JS `usage()`: the text goes to stderr.
pub fn usage() {
    eprintln!("{USAGE}");
}

/// `console.log(JSON.stringify(value, null, 2))` — one synchronous
/// `write_all` + `flush` so a following `process::exit` cannot truncate it.
pub fn print_json<T: Serialize>(value: &T) {
    let text = serde_json::to_string_pretty(value).unwrap_or_else(|_| "null".to_string());
    let stdout = std::io::stdout();
    let mut out = stdout.lock();
    let _ = out.write_all(text.as_bytes());
    let _ = out.write_all(b"\n");
    let _ = out.flush();
}

pub fn print_policy_import(result: &PolicyBundleImportResult, json: bool) {
    if json {
        print_json(result);
        return;
    }
    println!(
        "{}: {} imported, {} unchanged, {} removed, {} conflicting, {} rejected",
        result.status,
        result.imported,
        result.unchanged,
        result.removed,
        result.conflicting,
        result.rejected
    );
    println!("source: {}", result.source_path);
    println!("store: {}", result.store_path);
    println!("activation: inactive (0 installed, 0 enabled)");
    for conflict in &result.conflicts {
        println!("CONFLICT {}: {}", conflict.path, conflict.reason);
    }
    for rejection in &result.rejections {
        println!("REJECTED {rejection}");
    }
    for ignored in &result.ignored_paths {
        println!("IGNORED {ignored}");
    }
}

/// JS library calls throw on I/O errors; Node exits 1 with the error on
/// stderr. Reproduce the exit code and message (not the stack trace).
pub fn unwrap_or_exit<T>(result: tama_core::Result<T>) -> T {
    match result {
        Ok(value) => value,
        Err(error) => {
            eprintln!("{error}");
            std::process::exit(1);
        }
    }
}

/// JS truthiness for an optional string (`if (hook.description)`).
pub fn truthy(value: &Option<String>) -> Option<&str> {
    value.as_deref().filter(|s| !s.is_empty())
}

/// Prints catalog/hook JSON. Works around a tama-core fidelity gap:
/// `JustificationRequirement` flattens unknown keys (`title`) after the named
/// fields, while JS `JSON.parse` preserves the source order
/// (`kind, title, registryPath, field, ..., minimumWords`). Each `"title"`
/// line inside a `justificationRequirements` object is moved right after
/// `"kind"` in the pretty-printed text.
pub fn print_catalog_json<T: Serialize>(value: &T) {
    let text = serde_json::to_string_pretty(value).unwrap_or_else(|_| "null".to_string());
    let text = restore_requirement_key_order(&text);
    let stdout = std::io::stdout();
    let mut out = stdout.lock();
    let _ = out.write_all(text.as_bytes());
    let _ = out.write_all(b"\n");
    let _ = out.flush();
}

fn restore_requirement_key_order(text: &str) -> String {
    let lines: Vec<&str> = text.split('\n').collect();
    let mut out: Vec<String> = Vec::with_capacity(lines.len());
    let mut i = 0;
    while i < lines.len() {
        let line = lines[i];
        let trimmed = line.trim_start();
        if trimmed != "\"justificationRequirements\": [" {
            out.push(line.to_string());
            i += 1;
            continue;
        }
        let base_indent = line.len() - trimmed.len();
        out.push(line.to_string());
        i += 1;
        while i < lines.len() {
            let l = lines[i];
            let t = l.trim_start();
            let indent = l.len() - t.len();
            if indent <= base_indent && t.starts_with(']') {
                out.push(l.to_string());
                i += 1;
                break;
            }
            if t == "{" {
                let mut object: Vec<String> = vec![l.to_string()];
                i += 1;
                while i < lines.len() {
                    let l2 = lines[i];
                    let t2 = l2.trim_start();
                    let indent2 = l2.len() - t2.len();
                    object.push(l2.to_string());
                    i += 1;
                    if indent2 == indent && (t2 == "}" || t2 == "},") {
                        break;
                    }
                }
                reorder_title(&mut object);
                out.extend(object);
            } else {
                out.push(l.to_string());
                i += 1;
            }
        }
    }
    out.join("\n")
}

/// Moves the `"title"` property line of one justification-requirement object
/// (including its braces) to directly after `"kind"`, preserving commas.
fn reorder_title(object: &mut Vec<String>) {
    let Some(title_pos) = object
        .iter()
        .position(|l| l.trim_start().starts_with("\"title\":"))
    else {
        return;
    };
    let mut title = object.remove(title_pos);
    // `object` still holds the braces; property lines sit between them.
    let property_count = object.len().saturating_sub(2);
    if property_count == 0 {
        object.insert(1, title);
        return;
    }
    if !title.trim_end().ends_with(',') {
        // `title` was the last property: transfer its missing comma.
        title.push(',');
        let last = object.len() - 2;
        if object[last].ends_with(',') {
            object[last].pop();
        }
    }
    let insert_at = object
        .iter()
        .position(|l| l.trim_start().starts_with("\"kind\":"))
        .map(|pos| pos + 1)
        .unwrap_or(1);
    object.insert(insert_at, title);
}
