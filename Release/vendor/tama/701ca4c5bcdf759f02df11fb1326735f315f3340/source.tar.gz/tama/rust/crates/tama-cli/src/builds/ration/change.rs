//! How big the change a build carries is.
//!
//! "Serious change" is not a judgement the writer can be trusted to make about
//! its own work, so it is measured: the lines between the revision the last
//! recorded build of this target carried and the revision this one carries. A
//! version bump and a typo are a handful of lines; the work that deserves
//! forty minutes of a builder is not.

use std::path::{Path, PathBuf};
use std::process::Command;

/// Where the change is measured. `--repository` names it; without that option
/// it is the repository the command runs in.
pub fn repository(argv: &[String]) -> Result<PathBuf, String> {
    if let Some(named) = argv
        .iter()
        .position(|item| item == "--repository")
        .and_then(|index| argv.get(index + 1))
    {
        return Ok(PathBuf::from(named));
    }
    let here = std::env::current_dir()
        .map_err(|error| format!("this command has no working directory: {error}"))?;
    root(&here).ok_or_else(|| {
        format!(
            "{} is in no repository, so a build's change cannot be measured; name one with \
             --repository <path>",
            here.display()
        )
    })
}

fn root(from: &Path) -> Option<PathBuf> {
    from.ancestors()
        .find(|directory| directory.join(".git").exists())
        .map(Path::to_path_buf)
}

fn git(repository: &Path, arguments: &[&str]) -> Result<String, String> {
    let output = Command::new("git")
        .arg("-C")
        .arg(repository)
        .args(arguments)
        .output()
        .map_err(|error| format!("git {} could not run: {error}", arguments.join(" ")))?;
    if !output.status.success() {
        return Err(format!(
            "git {} in {} failed: {}",
            arguments.join(" "),
            repository.display(),
            String::from_utf8_lossy(&output.stderr).trim()
        ));
    }
    Ok(String::from_utf8_lossy(&output.stdout).into_owned())
}

/// Added plus deleted lines between two revisions. A revision the repository
/// does not know is refused with git's own words rather than guessed at, so a
/// build is never let through because the measurement failed.
pub fn changed_lines(repository: &Path, from: &str, to: &str) -> Result<u64, String> {
    let numstat = git(repository, &["diff", "--numstat", from, to])?;
    let mut total = 0;
    for line in numstat.lines() {
        for count in line.split_whitespace().take(2) {
            // A binary file's counts are printed as `-`.
            total += count.parse::<u64>().unwrap_or_default();
        }
    }
    Ok(total)
}

#[cfg(test)]
mod tests {
    use super::{changed_lines, repository, root};

    #[test]
    fn the_repository_this_command_runs_in_is_the_one_measured() {
        let here = repository(&[]).expect("this crate is in a repository");
        assert!(here.join(".git").exists(), "{}", here.display());
        assert_eq!(
            repository(&[
                String::from("--repository"),
                String::from("/tmp/named-instead")
            ])
            .expect("the named one"),
            std::path::PathBuf::from("/tmp/named-instead")
        );
    }

    #[test]
    fn a_revision_the_repository_does_not_know_is_refused_with_gits_words() {
        let here = repository(&[]).expect("a repository");
        let refusal = changed_lines(&here, "0000000000000000000000000000000000000000", "HEAD")
            .expect_err("a refusal");
        assert!(refusal.contains("git diff --numstat"), "{refusal}");
    }

    #[test]
    fn a_revision_against_itself_is_no_change_at_all() {
        let here = repository(&[]).expect("a repository");
        assert_eq!(
            changed_lines(&here, "HEAD", "HEAD").expect("a measurement"),
            0
        );
    }

    #[test]
    fn the_root_is_the_directory_holding_the_repository() {
        let here = std::path::Path::new(env!("CARGO_MANIFEST_DIR"));
        let found = root(here).expect("an ancestor with .git");
        assert!(here.starts_with(&found), "{}", found.display());
        assert_eq!(root(std::path::Path::new("/")), None);
    }
}
