//! What worktrees exist and what removing them does.
//!
//! Two structural facts shape this module:
//!
//! - `tama_violations::repo_discovery::discover_every_checkout` answers
//!   "which checkouts exist under this tree", and the emphasis is on EVERY.
//!   Its two filtered siblings are deliberately NOT used, because each one
//!   hid a real worktree from a pass that reported success. `discover_repos`
//!   keeps one checkout per origin, and `wisent-compute` shares an origin
//!   with `stado` while holding twenty worktrees of its own.
//!   `discover_checkouts` still drops a checkout its owning repository
//!   ignores, and `paper-repos` is itself a repository that ignores the
//!   checkouts nested in it, so `wisent-general-theory` and the worktree it
//!   registered were invisible too. Being ignored says who wrote a
//!   checkout's content; it says nothing about what it registered.
//! - Git, not Tama, is the authority on what worktrees a repository has:
//!   `git worktree list --porcelain` is the only place that knowledge lives,
//!   and it lists the main worktree first, which is never ours to remove.
//!   Reading that answer lives in [`super::porcelain`].

use std::collections::BTreeSet;
use std::path::{Path, PathBuf};

use serde::Serialize;
use tama_violations::repo_discovery::{
    discover_every_checkout_deep_reporting, UnreadableDirectory,
};
use tama_violations::resolve_path;

use super::porcelain::{canonical, git, linked_worktrees, same_path, Worktree};
use super::CommandError;

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub(crate) struct RepositoryWorktrees {
    pub repository: String,
    pub worktrees: Vec<Worktree>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub(crate) struct ListDocument {
    pub schema_version: u32,
    pub roots: Vec<String>,
    pub repositories: Vec<RepositoryWorktrees>,
    pub worktree_count: usize,
    /// Candidates the walk found a `.git` for and git then refused to answer
    /// for. Reported rather than dropped: silence would be the pass claiming
    /// it read a checkout it never read.
    pub unreadable: Vec<String>,
    /// Directories the walk could not list at all, each with the operating
    /// system's own reason. A pass that met one cannot say the roots hold no
    /// worktrees, only that it did not see one where it could look, so the
    /// leaves exit non-zero when this is not empty.
    pub unreadable_directories: Vec<UnreadableDirectory>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub(crate) struct Refusal {
    pub path: String,
    pub reason: &'static str,
}

/// The list document plus the outcome. The shared fields are spelled out
/// rather than flattened so the document is one plain struct in declaration
/// order.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub(crate) struct RemoveDocument {
    pub schema_version: u32,
    pub roots: Vec<String>,
    pub repositories: Vec<RepositoryWorktrees>,
    pub worktree_count: usize,
    pub unreadable: Vec<String>,
    pub unreadable_directories: Vec<UnreadableDirectory>,
    /// The worktrees `--except` held back, canonicalised and sorted. They are
    /// absent from `repositories`, `worktreeCount`, `removed` and `refused`:
    /// the pass never considered them.
    pub excepted: Vec<String>,
    pub applied: bool,
    pub removed: Vec<String>,
    pub refused: Vec<Refusal>,
}

/// The list document. Only repositories that actually have a linked worktree
/// are reported: the document answers "which second checkouts exist", not
/// "which repositories were walked".
pub(crate) fn list_document(roots: &[String]) -> Result<ListDocument, CommandError> {
    if roots.is_empty() {
        return Err(CommandError::MissingRoot);
    }
    let mut resolved_roots: Vec<String> = Vec::new();
    let mut repositories: Vec<RepositoryWorktrees> = Vec::new();
    let mut unreadable: Vec<String> = Vec::new();
    let mut unreadable_directories: Vec<UnreadableDirectory> = Vec::new();
    let mut seen: BTreeSet<String> = BTreeSet::new();
    let mut worktree_count = 0usize;
    for root in roots {
        let resolved: PathBuf = resolve_path(&[Path::new(root)]);
        resolved_roots.push(resolved.to_string_lossy().into_owned());
        let walked = discover_every_checkout_deep_reporting(&resolved);
        unreadable_directories.extend(walked.unreadable);
        for repo in walked.checkouts {
            if seen.contains(&repo) {
                continue;
            }
            // A candidate git refuses to recognise owns no worktrees, so it
            // cannot hide one and must not end the pass. The walk finds a
            // `.git` on the filesystem; git decides whether that is a
            // repository. `~/.npm/_cacache/tmp/git-cloneHQNSiU` on this
            // machine is the real case: an abandoned npm clone carrying a
            // `.git` that git answers for with "not a git repository", and
            // it aborted a whole removal pass over thirty repositories that
            // had nothing to do with it.
            let Ok((repository, worktrees)) = linked_worktrees(Path::new(&repo)) else {
                unreadable.push(repo);
                continue;
            };
            if !seen.insert(repository.clone()) || worktrees.is_empty() {
                continue;
            }
            worktree_count += worktrees.len();
            repositories.push(RepositoryWorktrees {
                repository,
                worktrees,
            });
        }
    }
    repositories.sort_by(|left, right| left.repository.cmp(&right.repository));
    unreadable.sort();
    unreadable_directories.sort_by(|left, right| left.path.cmp(&right.path));
    unreadable_directories.dedup();
    Ok(ListDocument {
        schema_version: 1,
        roots: resolved_roots,
        repositories,
        worktree_count,
        unreadable,
        unreadable_directories,
    })
}

/// Every worktree the pass would have to refuse. `--force` refuses nothing.
pub(crate) fn refusals(document: &ListDocument, force: bool) -> Vec<Refusal> {
    if force {
        return Vec::new();
    }
    let mut refusals = Vec::new();
    for repository in &document.repositories {
        for worktree in &repository.worktrees {
            // One sentence per worktree: uncommitted work is the fact the
            // operator has to act on even when git also holds a lock.
            if worktree.dirty {
                refusals.push(Refusal {
                    path: worktree.path.clone(),
                    reason: "uncommitted-changes",
                });
            } else if worktree.locked {
                refusals.push(Refusal {
                    path: worktree.path.clone(),
                    reason: "locked",
                });
            }
        }
    }
    refusals
}

/// Drops every `--except` worktree from the pass before anything judges it,
/// which is the whole point of the flag: an excepted worktree that is dirty
/// or locked must not be able to refuse a pass it is not part of. A value
/// matching nothing is a usage error rather than a no-op, because a pass the
/// operator believed narrowed would otherwise remove everything.
fn withhold(listed: &mut ListDocument, except: &[String]) -> Result<Vec<String>, CommandError> {
    if except.is_empty() {
        return Ok(Vec::new());
    }
    let mut excepted: BTreeSet<String> = BTreeSet::new();
    for wanted in except {
        let mut matched = false;
        for repository in &listed.repositories {
            for worktree in &repository.worktrees {
                if same_path(&worktree.path, Path::new(wanted)) {
                    let real = canonical(Path::new(&worktree.path));
                    excepted.insert(real.to_string_lossy().into_owned());
                    matched = true;
                }
            }
        }
        if !matched {
            return Err(CommandError::UnknownExcept(wanted.clone()));
        }
    }
    for repository in &mut listed.repositories {
        repository.worktrees.retain(|worktree| {
            let real = canonical(Path::new(&worktree.path));
            !excepted.contains(real.to_string_lossy().as_ref())
        });
    }
    // A repository whose only worktree was excepted has nothing left to
    // report; the list document only ever names repositories with worktrees.
    listed
        .repositories
        .retain(|repository| !repository.worktrees.is_empty());
    listed.worktree_count = listed
        .repositories
        .iter()
        .map(|repository| repository.worktrees.len())
        .sum();
    Ok(excepted.into_iter().collect())
}

/// `git worktree remove` then `git worktree prune`, per repository. Nothing
/// is deleted unless `apply` is set, the whole pass is free of refusals, and
/// the walk read every directory under the roots: a pass that could not look
/// everywhere cannot be the all-or-nothing pass this command promises.
pub(crate) fn remove_document(
    roots: &[String],
    except: &[String],
    apply: bool,
    force: bool,
) -> Result<RemoveDocument, CommandError> {
    let mut listed = list_document(roots)?;
    let excepted = withhold(&mut listed, except)?;
    let refused = refusals(&listed, force);
    let applied = apply && refused.is_empty() && listed.unreadable_directories.is_empty();
    let mut removed: Vec<String> = Vec::new();
    if applied {
        for repository in &listed.repositories {
            let repo = Path::new(&repository.repository);
            for worktree in &repository.worktrees {
                remove_one(repo, worktree, force)?;
                removed.push(worktree.path.clone());
            }
            git(repo, &["worktree", "prune"]).map_err(CommandError::Operational)?;
        }
    }
    Ok(RemoveDocument {
        schema_version: listed.schema_version,
        roots: listed.roots,
        repositories: listed.repositories,
        worktree_count: listed.worktree_count,
        unreadable: listed.unreadable,
        unreadable_directories: listed.unreadable_directories,
        excepted,
        applied,
        removed,
        refused,
    })
}

fn remove_one(repo: &Path, worktree: &Worktree, force: bool) -> Result<(), CommandError> {
    // A worktree whose directory git has already lost is not removable —
    // `git worktree remove` fails on it. The `prune` that follows the loop is
    // the operation git provides for such a record.
    if worktree.prunable {
        return Ok(());
    }
    let mut args = vec!["worktree", "remove"];
    if force {
        args.push("--force");
        // Git requires --force twice to remove a locked worktree.
        if worktree.locked {
            args.push("--force");
        }
    }
    args.push(&worktree.path);
    git(repo, &args).map_err(CommandError::Operational)?;
    Ok(())
}
