//! Applying a validated proposal to the live hook, behind the owner's
//! device consent, with a backup of what was there.
//!
//! Split out of `doctor/repair.rs`, which had grown past the
//! three-hundred-line limit.

use std::fs;
use std::path::Path;

use super::super::corpus::hook_paths;
use crate::engine::load_engine;
use crate::segments::runner_command::extname;
use crate::telemetry::open_telemetry;
use crate::util::{js_string, now_ms};

/// `applyProposal(proposalDir)` — fs/JSON errors propagate like the JS
/// throws, which `doctor/cli` turns into `doctor: <error>` and exit 1.
pub fn apply_proposal(proposal_dir: &str) -> Result<i32, String> {
    use std::io::Write as _;
    if std::env::var("DEVICE_HOOK_EDIT_APPROVED").ok().as_deref() != Some("1") {
        let _ = writeln!(
            std::io::stderr(),
            "refusing to modify live hooks: DEVICE_HOOK_EDIT_APPROVED is not set."
        );
        let _ = writeln!(
            std::io::stderr(),
            "Owner consent flow: see https://tama.wisent.com/docs/hook-management"
        );
        return Ok(1);
    }
    let report_path = Path::new(proposal_dir).join("report.json");
    if !report_path.exists() {
        let _ = writeln!(std::io::stderr(), "no report.json in {}", proposal_dir);
        return Ok(1);
    }
    let report: serde_json::Value = match fs::read_to_string(&report_path)
        .ok()
        .and_then(|text| serde_json::from_str(&text).ok())
    {
        Some(report) => report,
        None => {
            let _ = writeln!(
                std::io::stderr(),
                "unreadable report.json: SyntaxError: Unexpected token in JSON"
            );
            return Ok(1);
        }
    };
    let core = load_engine();
    let hook_id = report.get("hookId").and_then(|v| v.as_str()).unwrap_or("");
    let paths = hook_paths(hook_id, &core);
    let proposed = report
        .get("proposed")
        .and_then(|v| v.as_str())
        .map(str::to_string)
        .unwrap_or_else(|| {
            let ext = extname(paths.live.as_deref().unwrap_or(""));
            Path::new(proposal_dir)
                .join(format!("proposed{}", ext))
                .to_string_lossy()
                .to_string()
        });
    let live = match &paths.live {
        Some(live) if Path::new(&proposed).exists() => live.clone(),
        _ => {
            let rendered = report
                .get("hookId")
                .map(js_string)
                .unwrap_or_else(|| "undefined".to_string());
            let _ = writeln!(
                std::io::stderr(),
                "missing live path or proposed file for {}",
                rendered
            );
            return Ok(1);
        }
    };
    let backup_dir = core.state_dir.join("backup");
    fs::create_dir_all(&backup_dir).map_err(|e| format!("Error: {}", e))?;
    let backup_name = Path::new(&live)
        .file_name()
        .map(|n| n.to_string_lossy().to_string())
        .unwrap_or_default();
    let backup_path = backup_dir.join(format!("{}.{}", backup_name, now_ms()));
    if Path::new(&live).exists() {
        fs::copy(&live, &backup_path).map_err(|e| format!("Error: {}", e))?;
    }
    fs::copy(&proposed, &live).map_err(|e| format!("Error: {}", e))?;
    if let Some(archive) = &paths.archive {
        fs::copy(&proposed, archive).map_err(|e| format!("Error: {}", e))?;
    }
    let telemetry = open_telemetry(&core.state_dir);
    let archive_note = paths
        .archive
        .as_ref()
        .map(|a| format!(", archive {}", a.display()))
        .unwrap_or_default();
    telemetry.warn(&format!(
        "doctor apply: {} <- {} (backup {}{})",
        js_string(report.get("hookId").unwrap_or(&serde_json::Value::Null)),
        proposed,
        backup_path.display(),
        archive_note
    ));
    telemetry.close();
    println!(
        "applied {}; backup at {}",
        js_string(report.get("hookId").unwrap_or(&serde_json::Value::Null)),
        backup_path.display()
    );
    Ok(0)
}
