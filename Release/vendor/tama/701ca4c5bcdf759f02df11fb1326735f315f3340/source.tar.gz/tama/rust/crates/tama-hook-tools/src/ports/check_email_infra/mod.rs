//! Logic for `tama-check-email-infra`, registry hook `check-email-infra`:
//! before writing a workaround for an email provider, diagnose the mail
//! infrastructure that is actually failing.
//!
//! The shape it catches is a new `_create_<provider>` signup path, or code
//! that calls itself an alternative provider or an email workaround. Writing
//! one of those is almost always a reaction to mail that did not arrive, and
//! the reason mail did not arrive is usually in DNS, the sending domain or
//! the provider account — not in the absence of a fifth provider.
//!
//! A diagnosis within the last hour lifts the gate: the stamp file
//! `~/.claude/.email_infra_checked` is what `diagnose_email.sh` leaves
//! behind.

use std::path::PathBuf;
use std::sync::LazyLock;
use std::time::{SystemTime, UNIX_EPOCH};

use regex::Regex;
use serde_json::Value;
use tama_hooks::session_record::{deny_tool_use, read_payload};

use crate::ports::python_stdlib::expanduser;
use crate::ports::pyvalue::first_truthy_py_str;
use crate::ports::transport_common as common;

const TOOL_KEY: &str = "tool_name";
const INPUT_KEY: &str = "tool_input";
const WRITE_TOOL: &str = "Write";
const EDIT_TOOL: &str = "Edit";
const CONTENT_KEY: &str = "content";
const NEW_STRING_KEY: &str = "new_string";
const STAMP_PATH: &str = "~/.claude/.email_infra_checked";
/// `-lt 3600`: a diagnosis is good for an hour.
const FRESH_SECONDS_TEXT: &str = "3600";
const REFUSAL: &str = concat!(
    "BLOCKED: You are writing email provider workaround code.\n\n",
    "STOP. Before building workarounds, diagnose the actual email infrastructure:\n",
    "  Run: ~/.claude/hooks/diagnose_email.sh <domain>\n\n",
    "After diagnosing and fixing any issues:\n",
    "  Run: touch ~/.claude/.email_infra_checked",
);

static WORKAROUND: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(?i)_create_tuta|_create_gmail|_create_yahoo|_create_outlook|_create_mailcom",
        "|_create_protonmail|_create_hotmail|alternative.email.provider|email.workaround",
        "|email.provider.signup",
    ))
});

fn fresh_seconds() -> u64 {
    FRESH_SECONDS_TEXT.parse().unwrap_or_default()
}

fn diagnosed_recently(stamp: &PathBuf) -> bool {
    let Ok(metadata) = std::fs::metadata(stamp) else {
        return false;
    };
    let Ok(modified) = metadata.modified() else {
        return false;
    };
    let now = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|value| value.as_secs())
        .unwrap_or_default();
    let then = modified
        .duration_since(UNIX_EPOCH)
        .map(|value| value.as_secs())
        .unwrap_or_default();
    now.saturating_sub(then) < fresh_seconds()
}

/// Whether this content is an email provider workaround.
pub fn is_workaround(payload: &Value) -> bool {
    let tool = payload
        .get(TOOL_KEY)
        .and_then(Value::as_str)
        .unwrap_or_default();
    let empty = Value::Object(Default::default());
    let input = payload.get(INPUT_KEY).unwrap_or(&empty);
    let content = match tool {
        WRITE_TOOL => first_truthy_py_str(input, &[CONTENT_KEY]),
        EDIT_TOOL => first_truthy_py_str(input, &[NEW_STRING_KEY]),
        _ => String::new(),
    };
    !content.is_empty() && WORKAROUND.is_match(&content)
}

pub fn run() {
    let payload = read_payload();
    if !is_workaround(&payload) {
        return;
    }
    if diagnosed_recently(&PathBuf::from(expanduser(STAMP_PATH))) {
        return;
    }
    deny_tool_use(REFUSAL);
}

#[cfg(test)]
mod tests {
    use super::is_workaround;
    use serde_json::json;

    fn write(content: &str) -> serde_json::Value {
        json!({
            "tool_name": "Write",
            "tool_input": { "file_path": "signup.py", "content": content }
        })
    }

    #[test]
    fn a_new_provider_signup_path_is_a_workaround() {
        for content in [
            "def _create_tuta(session):",
            "async function _create_protonmail() {}",
            "EMAIL_WORKAROUND = True",
            "# email provider signup, attempt four",
        ] {
            assert!(is_workaround(&write(content)), "{content}");
        }
    }

    #[test]
    fn ordinary_mail_code_is_not_a_workaround() {
        assert!(!is_workaround(&write(
            "def send_receipt(to): return smtp.send(to)"
        )));
        assert!(!is_workaround(&json!({ "tool_name": "Read" })));
    }

    /// An edit is read through its new text, a write through its content.
    #[test]
    fn an_edit_is_read_too() {
        let payload = json!({
            "tool_name": "Edit",
            "tool_input": { "file_path": "signup.py", "new_string": "def _create_gmail(x):" }
        });
        assert!(is_workaround(&payload));
    }
}
