//! One recorded intent: the options that describe it, the document written
//! to the registry, and the sentences a later reader gets back.
//!
//! Split out of `builds/mod.rs` so both halves stay inside the
//! three-hundred-line limit; `mod.rs` keeps the command, this keeps what an
//! entry is.

use std::path::PathBuf;

use serde_json::{json, Value};

use super::policy;

/// A reason shorter than this says nothing a reader could act on. The
/// justification registries demand fifty words for a new file; an intent
/// before a build is a sentence, not an essay.
const MINIMUM_REASON_WORDS: usize = 8;
/// How long an authorization may stand, whatever the policy says. A build runs
/// in tens of minutes on this fleet's builders, and four hours is the longest
/// anything here has legitimately taken.
pub const MAXIMUM_MINUTES: u64 = 240;
pub const SECONDS_PER_MINUTE: u64 = 60;
/// The field the gate reads to decide whether an entry still authorizes.
const EXPIRES_FIELD: &str = "expires_at_epoch";
/// A source revision is a full git object name.
const REVISION_CHARS: usize = 40;

pub fn option(argv: &[String], name: &str) -> Option<String> {
    argv.iter()
        .position(|item| item == name)
        .and_then(|index| argv.get(index + 1))
        .cloned()
}

pub fn home(argv: &[String]) -> Result<PathBuf, String> {
    match option(argv, "--home") {
        Some(value) => Ok(PathBuf::from(value)),
        None => std::env::var_os("HOME")
            .map(PathBuf::from)
            .ok_or_else(|| String::from("HOME is not set, so the registry has no home")),
    }
}

pub fn now() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|elapsed| elapsed.as_secs())
        .unwrap_or_default()
}

pub fn refuse(message: &str) -> i32 {
    eprintln!("{message}");
    1
}

pub fn kind_of(argv: &[String]) -> Result<String, String> {
    match option(argv, "--kind").as_deref() {
        Some("build") => Ok(String::from("build")),
        Some("restart") => Ok(String::from("restart")),
        Some(other) => Err(format!("--kind is build or restart, not {other}")),
        None => Err(String::from("--kind is required: build or restart")),
    }
}

pub fn target_of(argv: &[String]) -> Result<String, String> {
    match option(argv, "--target") {
        Some(target) if !target.trim().is_empty() => Ok(target.trim().to_string()),
        _ => Err(String::from(
            "--target is required: the product a build carries or the unit a restart cycles",
        )),
    }
}

/// How long this entry authorizes. The policy's window is both the value when
/// the option is absent and the ceiling when it is present, so an entry cannot
/// outlast the operator's own number.
pub fn minutes_of(argv: &[String], policy: &policy::Policy) -> Result<u64, String> {
    let ceiling = policy.window_minutes.min(MAXIMUM_MINUTES);
    let Some(value) = option(argv, "--minutes") else {
        return Ok(ceiling);
    };
    let minutes: u64 = value
        .parse()
        .map_err(|_| format!("--minutes is a whole number of minutes, not {value}"))?;
    if minutes == 0 || minutes > ceiling {
        return Err(format!(
            "--minutes is between 1 and {ceiling}, the window this machine's policy allows; an \
             authorization that stands longer is a standing permission"
        ));
    }
    Ok(minutes)
}

pub fn entry(
    argv: &[String],
    policy: &policy::Policy,
    kind: &str,
    target: &str,
) -> Result<Value, String> {
    let reason = option(argv, "--reason").unwrap_or_default();
    if reason.split_whitespace().count() < MINIMUM_REASON_WORDS {
        return Err(format!(
            "--reason must say what this {kind} is for in at least {MINIMUM_REASON_WORDS} words"
        ));
    }
    let revision = option(argv, "--revision");
    if kind == "build" {
        let named = revision.as_deref().ok_or_else(|| {
            String::from("--revision is required for a build: the source revision it carries")
        })?;
        if named.len() != REVISION_CHARS || !named.bytes().all(|byte| byte.is_ascii_hexdigit()) {
            return Err(format!(
                "--revision is a full {REVISION_CHARS}-character source revision, not {named}"
            ));
        }
    }
    let recorded_at = now();
    let mut document = json!({
        "kind": kind,
        "target": target,
        "reason": reason,
        "recorded_at_epoch": recorded_at,
        "expires_at_epoch": recorded_at + minutes_of(argv, policy)? * SECONDS_PER_MINUTE,
    });
    if let Some(revision) = revision {
        document["revision"] = json!(revision);
    }
    if let Some(session) = std::env::var_os("TAMA_SESSION_ID").and_then(|id| id.into_string().ok())
    {
        document["session"] = json!(session);
    }
    Ok(document)
}

/// `--json` prints the document; a plain run prints the sentence a person
/// reads, because a registry entry exists to be read later by somebody who was
/// not there when it was written.
pub fn emit(json: bool, said: &str, document: &Value) {
    if json {
        println!(
            "{}",
            serde_json::to_string_pretty(document).unwrap_or_default()
        );
        return;
    }
    println!("{said}");
}

/// How much longer an entry authorizes, in whole minutes.
pub fn minutes_left(entry: &Value, at: u64) -> Option<u64> {
    entry
        .get(EXPIRES_FIELD)
        .and_then(Value::as_u64)
        .filter(|expiry| *expiry > at)
        .map(|expiry| (expiry - at).div_ceil(SECONDS_PER_MINUTE))
}

pub fn described(key: &str, entry: &Value, at: u64) -> String {
    let reason = entry
        .get("reason")
        .and_then(Value::as_str)
        .unwrap_or("(no reason)");
    let revision = entry
        .get("revision")
        .and_then(Value::as_str)
        .map(|revision| format!(" revision {revision}"))
        .unwrap_or_default();
    let consent = entry
        .get("user_approval")
        .map(|approval| {
            format!(
                "\n  user-approved daily-limit exception, session {}, turn {}: {}",
                approval["session_id"].as_str().unwrap_or_default(),
                approval["turn_digest"].as_str().unwrap_or_default(),
                approval["quote"].as_str().unwrap_or_default()
            )
        })
        .unwrap_or_default();
    match minutes_left(entry, at) {
        Some(left) => format!("{key}: open for {left} more min,{revision} {reason}{consent}"),
        None => format!("{key}: expired, authorizes nothing,{revision} {reason}{consent}"),
    }
}

#[cfg(test)]
mod tests {
    use super::super::policy::Policy;
    use super::{entry, minutes_of, SECONDS_PER_MINUTE};

    fn policy() -> Policy {
        Policy::default()
    }

    fn argv(words: &[&str]) -> Vec<String> {
        words.iter().map(|word| word.to_string()).collect()
    }

    const REVISION: &str = "45a5c678042147f76241adf76fb7cf217e121ca6";
    const REASON: &str = "0.3.11 carries the identity kind and the exact duplicate refusal";

    #[test]
    fn a_build_entry_states_its_revision_and_closes() {
        let document = entry(
            &argv(&["record", "--reason", REASON, "--revision", REVISION]),
            &policy(),
            "build",
            "skarbiec",
        )
        .expect("recorded");
        assert_eq!(document["kind"], "build");
        assert_eq!(document["target"], "skarbiec");
        assert_eq!(document["revision"], REVISION);
        let recorded = document["recorded_at_epoch"].as_u64().expect("stamp");
        let expires = document["expires_at_epoch"].as_u64().expect("expiry");
        assert_eq!(
            expires - recorded,
            policy().window_minutes * SECONDS_PER_MINUTE
        );
    }

    /// A build with no revision is the shape that produced ten releases in an
    /// evening: nothing in the entry said which source it carried.
    #[test]
    fn a_build_without_a_revision_is_refused() {
        let refused = entry(
            &argv(&["record", "--reason", REASON]),
            &policy(),
            "build",
            "skarbiec",
        )
        .expect_err("refused");
        assert!(refused.contains("--revision is required"), "{refused}");
    }

    #[test]
    fn a_restart_needs_no_revision_but_needs_a_reason() {
        let document = entry(
            &argv(&["record", "--reason", REASON]),
            &policy(),
            "restart",
            "web",
        )
        .expect("recorded");
        assert_eq!(document["kind"], "restart");
        assert!(document.get("revision").is_none(), "{document}");

        let refused = entry(
            &argv(&["record", "--reason", "because"]),
            &policy(),
            "restart",
            "web",
        )
        .expect_err("refused");
        assert!(refused.contains("at least"), "{refused}");
    }

    #[test]
    fn a_window_beyond_the_policy_is_refused() {
        let policy = policy();
        assert!(minutes_of(&argv(&["record", "--minutes", "241"]), &policy).is_err());
        assert!(minutes_of(&argv(&["record", "--minutes", "0"]), &policy).is_err());
        assert_eq!(
            minutes_of(&argv(&["record"]), &policy).expect("the policy's window"),
            policy.window_minutes
        );
    }
}
