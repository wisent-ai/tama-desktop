//! Whole-capability validation and the `AGENT_STRUCTURED_CAPABILITY`
//! environment contract.

use serde_json::{json, Value};

use super::grants::normalize_capability_grants;
use super::{CAPABILITY_ENV, CAPABILITY_LIFETIMES, CAPABILITY_SCHEMA_VERSION};
use crate::jsutil;

/// Optional identity cross-checks, mirroring the JS `identity` parameter
/// (fields are only enforced when present and non-empty).
#[derive(Debug, Clone, Default)]
pub struct CapabilityIdentity {
    pub control_key: Option<String>,
    pub release_id: Option<String>,
    pub catalog_checksum: Option<String>,
}

/// `normalizedExpiry`: `Date.parse`, must be finite and in the future,
/// re-emitted via `toISOString()`.
fn normalized_expiry(value: Option<&Value>, now_ms: f64) -> Option<String> {
    let ms = jsutil::parse_date(&jsutil::js_to_string_opt(value))?;
    if !ms.is_finite() || ms <= now_ms {
        return None;
    }
    Some(jsutil::to_iso_string(ms))
}

/// Port of `normalizedCapability`. `active_session_id` is the expected session
/// (pass `""` where the JS caller would pass a falsy value); `now_ms` is
/// `Date.now()` in milliseconds.
pub fn normalized_capability(
    value: &Value,
    active_session_id: &str,
    now_ms: f64,
    identity: &CapabilityIdentity,
) -> Option<Value> {
    if !value.is_object() {
        return None;
    }
    let grants = normalize_capability_grants(value.get("grants").unwrap_or(&Value::Null));
    let lifetime =
        jsutil::trim_js(&jsutil::js_string_or_empty(value.get("lifetime"))).to_lowercase();
    let control_key =
        jsutil::trim_js(&jsutil::js_string_or_empty(value.get("controlKey"))).to_string();
    let release_id =
        jsutil::trim_js(&jsutil::js_string_or_empty(value.get("releaseId"))).to_string();
    let catalog_checksum =
        jsutil::trim_js(&jsutil::js_string_or_empty(value.get("catalogChecksum"))).to_string();

    let schema_ok = value.get("schemaVersion").and_then(Value::as_f64) == Some(2.0);
    let issued_by_ok =
        !jsutil::trim_js(&jsutil::js_string_or_empty(value.get("issuedBy"))).is_empty();
    let nonce_ok = !jsutil::trim_js(&jsutil::js_string_or_empty(value.get("nonce"))).is_empty();
    let session_ok = jsutil::js_string_or_empty(value.get("sessionId")) == active_session_id;
    let identity_ok = |expected: &Option<String>, actual: &str| match expected {
        Some(e) if !e.is_empty() => e == actual,
        _ => true,
    };

    if !schema_ok
        || !issued_by_ok
        || !nonce_ok
        || !session_ok
        || control_key.is_empty()
        || release_id.is_empty()
        || catalog_checksum.is_empty()
        || !identity_ok(&identity.control_key, &control_key)
        || !identity_ok(&identity.release_id, &release_id)
        || !identity_ok(&identity.catalog_checksum, &catalog_checksum)
        || grants.is_none()
        || !CAPABILITY_LIFETIMES.contains(&lifetime.as_str())
    {
        return None;
    }

    let mut normalized = json!({
        "schemaVersion": CAPABILITY_SCHEMA_VERSION,
        "issuedBy": jsutil::js_to_string_opt(value.get("issuedBy")),
        "nonce": jsutil::js_to_string_opt(value.get("nonce")),
        "sessionId": jsutil::js_to_string_opt(value.get("sessionId")),
        "controlKey": control_key,
        "releaseId": release_id,
        "catalogChecksum": catalog_checksum,
        "lifetime": lifetime,
        "grants": grants?,
    });
    match lifetime.as_str() {
        "expires-at" => {
            let expires_at = normalized_expiry(value.get("expiresAt"), now_ms)?;
            normalized["expiresAt"] = json!(expires_at);
        }
        "single-use" => {
            if value.get("remainingUses").and_then(Value::as_f64) != Some(1.0) {
                return None;
            }
            normalized["remainingUses"] = json!(1);
        }
        _ => {}
    }
    Some(normalized)
}

fn upsert_env(env: &mut Vec<(String, String)>, key: &str, value: &str) {
    if let Some(entry) = env.iter_mut().find(|(k, _)| k == key) {
        entry.1 = value.to_string();
    } else {
        env.push((key.to_string(), value.to_string()));
    }
}

/// Port of `capabilityEnvironment`: `process.env` overlaid with `extra`, with
/// `AGENT_STRUCTURED_CAPABILITY` set to `JSON.stringify(capability)` or deleted
/// when no capability is given. Returned as an insertion-ordered list of pairs
/// (duplicate keys are overwritten in place, like JS object spread).
pub fn capability_environment(
    capability: Option<&Value>,
    extra: &[(String, String)],
) -> Vec<(String, String)> {
    let mut env: Vec<(String, String)> = std::env::vars_os()
        .map(|(k, v)| {
            (
                k.to_string_lossy().into_owned(),
                v.to_string_lossy().into_owned(),
            )
        })
        .collect();
    for (k, v) in extra {
        upsert_env(&mut env, k, v);
    }
    match capability {
        Some(c) => {
            let serialized = serde_json::to_string(c).unwrap_or_else(|_| "null".to_string());
            upsert_env(&mut env, CAPABILITY_ENV, &serialized);
        }
        None => env.retain(|(k, _)| k != CAPABILITY_ENV),
    }
    env
}
