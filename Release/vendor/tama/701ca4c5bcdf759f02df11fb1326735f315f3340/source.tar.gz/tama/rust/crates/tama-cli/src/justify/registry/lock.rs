//! Exclusive access to one registry across the whole read, splice and replace.
//!
//! Recording reads the document, splices one entry into that copy, and renames
//! the result over the file. Two commands doing it at once each spliced into
//! the same base, and the second rename dropped the first entry while both
//! printed the success line: on 2026-09-10 two of four entries recorded from
//! parallel calls were lost exactly that way, and only a later read revealed
//! it. The read and the replace belong inside one lock, so they are.

use std::fs;
use std::fs::OpenOptions;
use std::io::ErrorKind;
use std::path::{Path, PathBuf};
use std::thread;
use std::time::{Duration, Instant, SystemTime};

pub(crate) struct Lock {
    path: PathBuf,
}

impl Lock {
    /// A registry write is a splice and a rename, so waiting is bounded: a lock
    /// held past this is a crashed writer rather than a busy one, and the wait
    /// is long enough that a queue of ordinary recordings never reaches it.
    const WAIT: Duration = Duration::from_secs(5);
    const STALE: Duration = Duration::from_secs(30);
    const POLL: Duration = Duration::from_millis(20);

    pub(crate) fn acquire(registry: &Path) -> Result<Self, String> {
        let path = registry.with_extension("lock");
        // The first recording on a machine creates the registry directory, and
        // the lock sits beside the document, so the directory has to exist
        // before the lock rather than when the document is finally written.
        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent)
                .map_err(|error| format!("cannot create {}: {error}", parent.display()))?;
        }
        let deadline = Instant::now() + Self::WAIT;
        loop {
            match OpenOptions::new().write(true).create_new(true).open(&path) {
                Ok(_) => return Ok(Self { path }),
                Err(error) if error.kind() == ErrorKind::AlreadyExists => {
                    if abandoned(&path, Self::STALE) {
                        let _ = fs::remove_file(&path);
                        continue;
                    }
                    if Instant::now() >= deadline {
                        return Err(format!(
                            "another command is still writing {}, so nothing was recorded",
                            registry.display()
                        ));
                    }
                    thread::sleep(Self::POLL);
                }
                Err(error) => return Err(format!("cannot lock {}: {error}", path.display())),
            }
        }
    }
}

impl Drop for Lock {
    fn drop(&mut self) {
        let _ = fs::remove_file(&self.path);
    }
}

/// A lock file left behind by a process that died holding it.
fn abandoned(path: &Path, after: Duration) -> bool {
    let Ok(modified) = fs::metadata(path).and_then(|data| data.modified()) else {
        return false;
    };
    SystemTime::now()
        .duration_since(modified)
        .map(|age| age > after)
        .unwrap_or(false)
}
