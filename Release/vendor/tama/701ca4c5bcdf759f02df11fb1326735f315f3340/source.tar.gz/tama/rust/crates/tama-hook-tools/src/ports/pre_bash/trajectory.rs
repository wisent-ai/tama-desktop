//! Counting trajectory runs, and stopping the third one nobody looked at.
//!
//! A run is recognised two ways, because inventing a one-off file name was
//! how the canonical pattern got dodged: the trajectory path in the command,
//! or any interpreter running a script whose source starts a Weles session.
//! The keeper's own action script is excluded — it is the inspection tool.
//!
//! The inspection gate is consulted before the counter is raised. It used to
//! be after, which made the first-run branch of that gate unreachable: by the
//! time it read the counter the count was already one.

use std::path::{Path, PathBuf};
use std::sync::LazyLock;

use regex::Regex;
use serde_json::{json, Value};

use crate::ports::check_artifact_inspection;
use crate::ports::python_stdlib::expanduser;
use crate::ports::transport_common as common;
use crate::util::iso_now;

const STATE_PATH: &str = "~/.shared-hooks/state/trajectory_runs.json";
const RUNS_KEY: &str = "runs_since_inspection";
const LAST_RUN_KEY: &str = "last_run_at";
const LAST_INSPECTION_KEY: &str = "last_inspection_at";
const KEEPER_ACTION: &str = "keeper/action.mjs";
const SESSION_MARKER: &str = "WSession.start";
const SESSION_MARKER_LOWER: &str = "wsession.start";
/// `-ge 3`: the third run without an inspection is refused.
const RUN_LIMIT_TEXT: &str = "3";

static TRAJECTORY_PATH: LazyLock<Regex> =
    LazyLock::new(|| common::compile("scripts/trajectories/[A-Za-z0-9_./-]+\\.[mc]?[tj]sx?"));
static INTERPRETED_SCRIPT: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        concat!(
            "({})([[:space:]]+(run|--[A-Za-z0-9_-]+(=[^[:space:]]+)?))*",
            "[[:space:]]+(?P<script>[A-Za-z0-9_./~$-]+\\.[mc]?[tj]sx?)",
        ),
        crate::ports::shell_text::javascript_alternation()
    ))
});
static SCRIPT_SUFFIX: LazyLock<Regex> = LazyLock::new(|| common::compile("\\.[mc]?[tj]sx?$"));
/// Any action word after the keeper entry point: the actions belong to
/// Weles, so the guard matches the shape of one rather than a copy of
/// Weles' list that would go stale the day an action is added.
static INSPECTION_TRIGGER: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "inspect_trajectory\\.sh\\b|\\.work/\\.artifact_inspected/",
        "|keeper/action\\.mjs[[:space:]]+[a-z][a-z_-]*\\b",
    ))
});

fn run_limit() -> i64 {
    RUN_LIMIT_TEXT.parse().unwrap_or_default()
}

fn state_path() -> PathBuf {
    PathBuf::from(expanduser(STATE_PATH))
}

fn read_state(path: &Path) -> Value {
    std::fs::read_to_string(path)
        .ok()
        .and_then(|text| serde_json::from_str::<Value>(&text).ok())
        .filter(Value::is_object)
        .unwrap_or_else(|| json!({}))
}

fn write_state(path: &Path, doc: &Value) {
    if let Some(parent) = path.parent() {
        let _ = std::fs::create_dir_all(parent);
    }
    let _ = std::fs::write(path, doc.to_string());
}

/// The trajectory this command runs, as `<folder>/<label>`.
pub(crate) fn key_of(command: &str) -> Option<(String, String)> {
    let path = match TRAJECTORY_PATH.find(command) {
        Some(found) if !found.as_str().ends_with(KEEPER_ACTION) => found.as_str().to_string(),
        Some(_) => return None,
        None => {
            let script = INTERPRETED_SCRIPT
                .captures(command)?
                .name("script")?
                .as_str()
                .to_string();
            let starts_a_session = std::fs::read_to_string(&script)
                .map(|body| body.contains(SESSION_MARKER) || body.contains(SESSION_MARKER_LOWER))
                .unwrap_or_default();
            match starts_a_session {
                true => script,
                false => return None,
            }
        }
    };
    let target = Path::new(&path);
    let name = target.file_name()?.to_string_lossy().to_string();
    let label = SCRIPT_SUFFIX.replace(&name, "").to_string();
    let folder = target
        .parent()
        .and_then(Path::file_name)
        .map(|found| found.to_string_lossy().to_string())
        .unwrap_or_default();
    Some((format!("{folder}/{label}"), label))
}

/// Whether this command is an inspection, which clears every counter.
pub(crate) fn is_inspection(command: &str) -> bool {
    INSPECTION_TRIGGER.is_match(command)
}

/// Clear the counters after an inspection.
pub(crate) fn record_inspection(path: &Path) {
    let mut doc = read_state(path);
    let Some(map) = doc.as_object_mut() else {
        return;
    };
    let stamp = iso_now();
    for (_, value) in map.iter_mut() {
        if let Some(entry) = value.as_object_mut() {
            entry.insert(RUNS_KEY.to_string(), json!(0));
            entry.insert(LAST_INSPECTION_KEY.to_string(), json!(stamp));
        }
    }
    write_state(path, &doc);
}

/// Count this run and say whether it may proceed. `state` is injectable so a
/// test never touches the operator's own counter.
pub(crate) fn count_run(state: &Path, key: &str) -> Result<(), String> {
    let mut doc = read_state(state);
    let prior = doc
        .get(key)
        .and_then(|entry| entry.get(RUNS_KEY))
        .and_then(Value::as_i64)
        .unwrap_or_default();
    let next = prior + 1;
    if let Some(map) = doc.as_object_mut() {
        let entry = map.entry(key.to_string()).or_insert_with(|| json!({}));
        if let Some(fields) = entry.as_object_mut() {
            fields.insert(RUNS_KEY.to_string(), json!(next));
            fields.insert(LAST_RUN_KEY.to_string(), json!(iso_now()));
        }
    }
    write_state(state, &doc);
    match next >= run_limit() {
        true => Err(format!(
            "BLOCKED: trajectory '{key}' run #{next} without inspection.\nUse \
             $HOME/.shared-hooks/inspect_trajectory.sh {} to unblock.",
            key.rsplit('/').next().unwrap_or(key)
        )),
        false => Ok(()),
    }
}

/// The refusal this command earns for running a trajectory again, if any.
pub(crate) fn refusal(repo: &Path, command: &str, transcript: &str) -> Option<String> {
    if let Some((key, label)) = key_of(command) {
        // The inspection question comes first, so its own first-run branch is
        // reachable.
        if let Err(found) = check_artifact_inspection::verdict(repo, &label, transcript) {
            return Some(found);
        }
        if let Err(found) = count_run(&state_path(), &key) {
            return Some(found);
        }
    }
    if is_inspection(command) {
        record_inspection(&state_path());
    }
    None
}

#[cfg(test)]
mod tests {
    use super::{count_run, is_inspection, key_of, record_inspection, run_limit};
    use std::path::{Path, PathBuf};

    fn state(name: &str) -> PathBuf {
        let dir = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../target/tmp")
            .join(format!("tama-trajectory-{name}"));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).expect("a folder for the fixture");
        dir.join("trajectory_runs.json")
    }

    #[test]
    fn the_trajectory_key_is_its_folder_and_label() {
        let found = key_of("node weles/scripts/trajectories/linkedin_scrape.mjs --headful");
        assert_eq!(
            found,
            Some((
                "trajectories/linkedin_scrape".to_string(),
                "linkedin_scrape".to_string()
            ))
        );
    }

    /// The keeper's action script is the inspection tool, not a run.
    #[test]
    fn the_keeper_action_script_is_not_a_run() {
        assert_eq!(
            key_of("node weles/scripts/trajectories/keeper/action.mjs dump"),
            None
        );
        assert!(is_inspection(
            "node weles/scripts/trajectories/keeper/action.mjs dump"
        ));
    }

    /// Two runs pass, the third is refused, and an inspection clears it.
    #[test]
    fn the_third_uninspected_run_is_refused_and_an_inspection_clears_it() {
        let path = state("counter");
        let key = "trajectories/linkedin";
        for _ in 0..(run_limit() - 1) {
            assert!(count_run(&path, key).is_ok());
        }
        let refusal = count_run(&path, key).expect_err("the third run");
        assert!(refusal.contains("without inspection"), "{refusal}");
        assert!(
            refusal.contains("inspect_trajectory.sh linkedin"),
            "{refusal}"
        );
        record_inspection(&path);
        assert!(count_run(&path, key).is_ok(), "the counter was cleared");
        let _ = std::fs::remove_dir_all(path.parent().expect("a folder"));
    }

    #[test]
    fn an_ordinary_command_is_not_a_trajectory() {
        assert_eq!(key_of("node scripts/build.mjs"), None);
        assert!(!is_inspection("git status"));
    }
}
