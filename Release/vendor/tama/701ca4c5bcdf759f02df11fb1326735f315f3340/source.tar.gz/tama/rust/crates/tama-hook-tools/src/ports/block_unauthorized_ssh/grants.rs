//! Whether the registry holds a grant that covers one SSH request exactly.
//!
//! Split out of `block_unauthorized_ssh/mod.rs`, which had grown past the
//! three-hundred-line limit. The request shape and the refusal stay there;
//! reading `ssh_justification.json` and matching one entry against a request
//! is here.

use std::collections::BTreeSet;

use serde_json::Value;

use super::{
    justification_path, quote_authorizes_targets, quote_is_in_current_session, SshRequest,
    PATH_OPERATIONS, SCHEMA, SESSION_LIFETIME, SSH_TOOL,
};
use crate::ports::transport_common as common;

/// `exact_string_list`: a non-empty list of non-empty strings, or nothing.
fn exact_string_list(entry: &Value, key: &str) -> Option<BTreeSet<String>> {
    let items = match entry.get(key) {
        Some(Value::Array(items)) if !items.is_empty() => items,
        _ => return None,
    };
    let mut listed = BTreeSet::new();
    for item in items {
        match item {
            Value::String(text) if !text.is_empty() => listed.insert(text.clone()),
            _ => return None,
        };
    }
    Some(listed)
}

/// `entry_matches`: one registry entry covers this exact request, with the
/// quote verified against the live transcript.
pub fn entry_matches(entry: &Value, request: &SshRequest, session_id: &str) -> bool {
    let quote = match entry.get("userRequestQuote") {
        Some(Value::String(quote)) => quote.clone(),
        _ => return false,
    };
    if entry.get("allowedTool").and_then(Value::as_str) != Some(SSH_TOOL)
        || entry.get("lifetime").and_then(Value::as_str) != Some(SESSION_LIFETIME)
        || !quote_authorizes_targets(&quote, &request.targets)
        || !quote_is_in_current_session(session_id, &quote)
    {
        return false;
    }
    let allowed = match exact_string_list(entry, "allowedTargets") {
        Some(listed) => listed,
        None => return false,
    };
    let operations = match exact_string_list(entry, "allowedOperations") {
        Some(listed) => listed,
        None => return false,
    };
    let lowered: BTreeSet<String> = allowed.iter().map(|item| item.to_lowercase()).collect();
    if !request
        .targets
        .iter()
        .all(|target| lowered.contains(&target.to_lowercase()))
    {
        return false;
    }
    if !operations
        .iter()
        .any(|item| item.to_lowercase() == request.operation)
    {
        return false;
    }
    if PATH_OPERATIONS.contains(&request.operation.as_str()) {
        return match exact_string_list(entry, "allowedPaths") {
            Some(paths) => request.paths.iter().all(|path| paths.contains(path)),
            None => false,
        };
    }
    match (
        &request.command,
        exact_string_list(entry, "allowedCommands"),
    ) {
        (Some(command), Some(commands)) => commands.contains(command),
        _ => false,
    }
}

/// `authorized`: the registry holds a matching entry for this session.
pub fn authorized(payload: &Value, request: &SshRequest) -> bool {
    let registry = match common::read_registry(&justification_path()) {
        Some(registry) => registry,
        None => return false,
    };
    if !registry.is_object() || registry.get("schema").and_then(Value::as_str) != Some(SCHEMA) {
        return false;
    }
    let session_id = common::session_id_of(payload);
    let entries = match registry.get("authorizations") {
        Some(Value::Array(entries)) => entries,
        _ => return false,
    };
    entries
        .iter()
        .any(|entry| entry.is_object() && entry_matches(entry, request, &session_id))
}
