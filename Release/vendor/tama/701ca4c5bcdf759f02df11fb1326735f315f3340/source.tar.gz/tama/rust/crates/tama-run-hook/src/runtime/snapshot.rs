//! Complete candidates are read before replacing the active hook registry.

use std::collections::HashSet;
use std::path::Path;

use serde_json::Value;
use tama_hooks::sha256::sha256_hex;

use crate::jssem::{js_to_string, js_truthy};

pub(super) struct Snapshot {
    pub registry: Value,
    pub hook_ids: HashSet<String>,
    pub release_id: Option<String>,
    pub checksum: String,
}

impl Snapshot {
    pub fn read(path: &Path) -> Result<Self, String> {
        let text = std::fs::read_to_string(path)
            .map_err(|error| format!("reading hook registry {}: {error}", path.display()))?;
        let mut registry: Value = serde_json::from_str(&text)
            .map_err(|error| format!("parsing hook registry {}: {error}", path.display()))?;
        let object = registry
            .as_object_mut()
            .ok_or_else(|| format!("hook registry {} must be an object", path.display()))?;
        let declared = object.remove("catalogChecksum");
        let checksum =
            sha256_hex(&serde_json::to_vec(&registry).map_err(|error| error.to_string())?);
        if let Some(declared) = declared {
            let expected = declared.as_str().ok_or_else(|| {
                format!(
                    "hook registry {} catalogChecksum must be a string",
                    path.display()
                )
            })?;
            if expected != checksum {
                return Err(format!(
                    "hook registry {} checksum mismatch: expected {expected}, actual {checksum}",
                    path.display(),
                ));
            }
            registry
                .as_object_mut()
                .expect("validated registry object")
                .insert("catalogChecksum".into(), declared);
        }
        let release_id = match registry.get("releaseId") {
            Some(value) => Some(
                value
                    .as_str()
                    .filter(|value| !value.is_empty())
                    .ok_or_else(|| {
                        format!(
                            "hook registry {} releaseId must be a nonempty string",
                            path.display()
                        )
                    })?
                    .to_owned(),
            ),
            None => None,
        };
        let mut hook_ids = HashSet::new();
        if let Some(events) = registry.get("events") {
            let events = events.as_object().ok_or_else(|| {
                format!("hook registry {} events must be an object", path.display())
            })?;
            for (event, entry) in events {
                let entry = entry.as_object().ok_or_else(|| {
                    format!(
                        "hook registry {} event {event} must be an object",
                        path.display()
                    )
                })?;
                if let Some(hooks) = entry.get("hooks") {
                    let hooks = hooks.as_array().ok_or_else(|| {
                        format!(
                            "hook registry {} event {event} hooks must be an array",
                            path.display()
                        )
                    })?;
                    for hook in hooks {
                        if !hook.is_object() {
                            return Err(format!(
                                "hook registry {} event {event} contains a non-object hook",
                                path.display()
                            ));
                        }
                        if let Some(id) = hook.get("id").filter(|value| js_truthy(Some(value))) {
                            let id = js_to_string(id);
                            if !id.is_empty() {
                                hook_ids.insert(id);
                            }
                        }
                    }
                }
            }
        }
        Ok(Self {
            registry,
            hook_ids,
            release_id,
            checksum,
        })
    }
}
