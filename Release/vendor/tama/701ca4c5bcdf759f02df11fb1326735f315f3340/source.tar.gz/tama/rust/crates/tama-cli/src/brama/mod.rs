//! Tama's Brama-facing commands. The client itself lives in
//! `tama_hook_tools::brama`; this is the operator surface over it.

pub mod check;
