//! `inspect-required-check` — Rust port of
//! `shared-hooks/inspect_required_check.py` (registry id
//! `inspect-required-check`, `pre_tool_use:bash` event).
//!
//! PreToolUse Bash gate: while `inspect_required.json` has open entries, the
//! next Bash command must be an inspection helper. Entries clear when this
//! session's transcript shows a `Read` of the entry's `failure_state`, or when
//! the failure belongs to a different project root.
//!
//! Like the Python, this hook resolves the transcript purely from the encoded
//! CWD and ignores the payload's `transcript_path`; the sibling Stop hook is
//! the one that pins the exact session.

use super::check_failure_inspection_transcript::{read_file_paths, Transcript};
use regex::Regex;
use serde::de::{MapAccess, Visitor};
use serde_json::Value;
use std::io::Read;
use std::path::{Path, PathBuf};
use tama_hooks::session_record::deny_tool_use;

const DISABLE_VAR: &str = "INSPECT_REQUIRED_DISABLED";
const DISABLE_VALUE: &str = "1";
const HOME_VAR: &str = "HOME";
const FALLBACK_HOME: &str = "/tmp";
const WORK_SEGMENT: &str = crate::evidence::EVIDENCE_PATH_SEGMENT;
const PATH_SEPARATOR: &str = "/";
const MISSING_FAILURE_STATE: &str = "?";

/// The inspection helpers a blocked session may still run. Case-sensitive, as
/// in the Python.
const ALLOWED_PATTERN: &str = concat!(
    r"(\binspect_trajectory\.sh\b|",
    r"\b(shasum|ffmpeg|ffprobe|ls|cat|head|tail|grep|file|stat|wc)\b\s+[^|;&]*\.weles/runs/|",
    r"\b(shasum|ffmpeg|ffprobe)\b\s+[^|;&]*recordings/)",
);

/// `jsonl_has_read` scans `lines[-200:]`.
const READ_LOOKBACK_TEXT: &str = "200";
/// `"=" * 60`.
const BANNER_WIDTH_TEXT: &str = "60";
const BANNER_CHAR: char = '=';
/// `json.dumps(..., indent=2)`.
const JSON_INDENT: &str = "  ";

const BANNER_HEADLINE: &str = "  BLOCKED: inspection required before next Bash command";
const BANNER_TAIL: &[&str] = &[
    "Read the failure_state png(s) above with the Read tool, OR run",
    "$HOME/.shared-hooks/inspect_trajectory.sh <label>, then retry.",
    "Bypass: INSPECT_REQUIRED_DISABLED=1.",
];

fn read_lookback() -> usize {
    READ_LOOKBACK_TEXT.parse().unwrap_or_default()
}

fn banner_width() -> usize {
    BANNER_WIDTH_TEXT.parse().unwrap_or_default()
}

pub fn run() {
    if std::env::var(DISABLE_VAR).as_deref() == Ok(DISABLE_VALUE) {
        return;
    }
    let home = std::env::var(HOME_VAR)
        .map(PathBuf::from)
        .unwrap_or_else(|_| PathBuf::from(FALLBACK_HOME));
    let state = home
        .join(".shared-hooks")
        .join("state")
        .join("inspect_required.json");
    if !state.is_file() {
        return;
    }
    let Some(payload) = stdin_payload() else {
        return;
    };
    let command = payload
        .get("tool_input")
        .and_then(|input| input.get("command"))
        .and_then(Value::as_str)
        .unwrap_or_default();
    let allowed = Regex::new(ALLOWED_PATTERN).expect("allowed command pattern");
    if allowed.is_match(command) {
        return;
    }

    let Some(entries) = std::fs::read_to_string(&state)
        .ok()
        .as_deref()
        .and_then(parse_entries)
    else {
        return;
    };
    if entries.is_empty() {
        return;
    }

    let cwd = std::env::current_dir().unwrap_or_default();
    let transcript = Transcript::locate(&home, &cwd, "");
    let reads = read_file_paths(transcript.tail(read_lookback()));
    let here = realpath(&cwd.display().to_string());

    let mut remaining: Vec<(String, Value)> = Vec::new();
    let mut cleared = false;
    for (label, info) in entries {
        if clears(&label, &info, &here, &reads) {
            cleared = true;
            continue;
        }
        remaining.push((label, info));
    }

    if cleared {
        let _ = std::fs::write(&state, dumps_indent(&remaining));
    }
    if remaining.is_empty() {
        return;
    }
    deny_tool_use(&banner(&remaining));
}

/// An entry clears when it belongs to another project root, or when the
/// transcript shows a Read of its `failure_state` artifact.
fn clears(label: &str, info: &Value, here: &str, reads: &[String]) -> bool {
    let sha8 = info.get("sha8").and_then(Value::as_str).unwrap_or_default();
    let failure_state = info
        .get("failure_state")
        .and_then(Value::as_str)
        .unwrap_or_default();
    // CWD scoping: a failure recorded under a different project root is not
    // this session's to inspect.
    if let Some((prefix, _)) = failure_state.split_once(WORK_SEGMENT) {
        let project_root = realpath(prefix);
        if !project_root.is_empty()
            && here != project_root
            && !here.starts_with(&format!("{project_root}{PATH_SEPARATOR}"))
        {
            return true;
        }
    }
    let pattern = super::failure_artefacts::failure_state_pattern(label, sha8);
    let Ok(artifact) = Regex::new(&pattern) else {
        return false;
    };
    reads.iter().any(|read| artifact.is_match(read))
}

fn banner(remaining: &[(String, Value)]) -> String {
    let rule = BANNER_CHAR.to_string().repeat(banner_width());
    let mut lines = vec![rule.clone(), BANNER_HEADLINE.to_string(), rule];
    for (label, info) in remaining {
        lines.push(format!("  trajectory '{label}' failed; failure_state at:"));
        lines.push(format!(
            "    {}",
            match info.get("failure_state") {
                Some(Value::String(path)) => path.clone(),
                Some(other) => other.to_string(),
                None => MISSING_FAILURE_STATE.to_string(),
            }
        ));
    }
    lines.push(String::new());
    lines.extend(BANNER_TAIL.iter().map(|line| (*line).to_string()));
    lines.join("\n")
}

/// `json.loads(raw) if raw.strip() else {}`, with the Python's `except:
/// sys.exit(0)` on malformed input expressed as `None`.
fn stdin_payload() -> Option<Value> {
    let mut raw = String::new();
    if std::io::stdin().read_to_string(&mut raw).is_err() {
        return None;
    }
    if raw.trim().is_empty() {
        return Some(Value::Object(Default::default()));
    }
    serde_json::from_str(&raw).ok()
}

/// `os.path.realpath`, non-strict: an unresolvable path keeps its own text,
/// which is what `realpath` returns for a path that does not exist.
fn realpath(path: &str) -> String {
    std::fs::canonicalize(Path::new(path))
        .map(|resolved| resolved.display().to_string())
        .unwrap_or_else(|_| path.to_string())
}

/// `json.dumps(value, indent=2)` over entries in their original order.
fn dumps_indent(entries: &[(String, Value)]) -> String {
    if entries.is_empty() {
        return Value::Object(Default::default()).to_string();
    }
    let body = entries
        .iter()
        .map(|(key, value)| {
            let rendered = serde_json::to_string_pretty(value)
                .unwrap_or_default()
                .replace('\n', &format!("\n{JSON_INDENT}"));
            format!("{JSON_INDENT}{}: {rendered}", Value::String(key.clone()))
        })
        .collect::<Vec<_>>()
        .join(",\n");
    format!("{{\n{body}\n}}")
}

/// Top-level entries in document order.
///
/// `serde_json`'s `Map` is a `BTreeMap` in this workspace, which would sort the
/// labels and so reorder both the deny banner and the rewritten state file;
/// Python's `dict` keeps insertion order. A repeated key keeps its first
/// position and its last value, exactly like `dict`.
fn parse_entries(text: &str) -> Option<Vec<(String, Value)>> {
    let mut reader = serde_json::Deserializer::from_str(text);
    let parsed = serde::Deserializer::deserialize_map(&mut reader, EntriesVisitor).ok()?;
    reader.end().ok()?;
    Some(parsed)
}

struct EntriesVisitor;

impl<'de> Visitor<'de> for EntriesVisitor {
    type Value = Vec<(String, Value)>;

    fn expecting(&self, formatter: &mut std::fmt::Formatter) -> std::fmt::Result {
        formatter.write_str("a JSON object of inspect_required entries")
    }

    fn visit_map<A: MapAccess<'de>>(self, mut access: A) -> Result<Self::Value, A::Error> {
        let mut entries: Vec<(String, Value)> = Vec::new();
        while let Some((key, value)) = access.next_entry::<String, Value>()? {
            match entries.iter_mut().find(|(seen, _)| *seen == key) {
                Some(slot) => slot.1 = value,
                None => entries.push((key, value)),
            }
        }
        Ok(entries)
    }
}
