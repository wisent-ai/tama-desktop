//! What `tama worktrees` can SEE, which is a different question from what it
//! does with what it sees.
//!
//! Twice a removal pass reported success while a real worktree was invisible
//! to it, and both times the cause was a filter that is correct for scanning
//! content and wrong for asking what a machine owns. These two cases pin the
//! enumeration against both shapes; the command's own behaviour is defended
//! in `worktrees_cli.rs`, and both share `worktrees_fixture`.

mod worktrees_fixture;

use std::fs;

use worktrees_fixture::{stderr, stdout, text, Fixture};

/// `wisent-compute` and `stado` in this workspace both point at
/// `https://github.com/wisent-ai/stado.git`, so the first version of this
/// command used the origin-deduplicating `discover_repos`, reported nothing
/// for `wisent-compute` while git reported twenty linked worktrees in it, and
/// called the removal pass a success. Each checkout owns its own
/// registrations.
#[test]
fn list_reports_worktrees_of_every_checkout_sharing_one_origin() {
    let fixture = Fixture::new("shared-origin");
    let origin = "https://github.com/wisent-ai/example.git";
    fixture.git(&fixture.repo(), &["remote", "add", "origin", origin]);
    let tree = fixture.base.join("tree");
    fixture.git(&tree, &["clone", "-q", "--no-local", "repo", "second"]);
    let second = tree.join("second");
    fixture.git(&second, &["remote", "set-url", "origin", origin]);
    let sibling = text(tree.join("worktrees/wt-second"));
    fixture.git(
        &second,
        &["worktree", "add", "-q", "-b", "wt-second", &sibling],
    );

    let output = fixture.tama(&["worktrees", "list", "--root", &fixture.root()]);
    assert_eq!(output.status.code(), Some(0), "stderr: {}", stderr(&output));
    let printed = stdout(&output);
    for expected in [
        text(fixture.repo()),
        text(fixture.worktree("wt-a")),
        text(second),
        sibling,
        "3 linked worktree(s) in 2 repository(ies).".to_string(),
    ] {
        assert!(printed.contains(&expected), "{expected} missing: {printed}");
    }
}

/// A checkout its owning repository ignores still owns its own worktrees.
/// `paper-repos` is a repository that ignores the checkouts nested inside it,
/// so the ignore-respecting walk returned only `paper-repos`, and
/// `wisent-general-theory` plus the worktree it had registered were invisible
/// to a pass that then reported success. Being ignored says who wrote a
/// checkout's content; it says nothing about what it registered.
#[test]
fn list_reports_a_worktree_of_a_checkout_its_owner_ignores() {
    let fixture = Fixture::new("ignored-owner");
    let tree = fixture.base.join("tree");
    fixture.git(&tree, &["init", "-q"]);
    fs::write(tree.join(".gitignore"), "nested/\n").expect("write ignore rule");
    fixture.git(&tree, &["add", ".gitignore"]);
    fixture.git(&tree, &["commit", "-q", "-m", "ignore the nested checkout"]);

    let nested = tree.join("nested/inner");
    fs::create_dir_all(&nested).expect("create nested checkout");
    fixture.git(&nested, &["init", "-q"]);
    fs::write(nested.join("file.txt"), "one\n").expect("write tracked file");
    fixture.git(&nested, &["add", "file.txt"]);
    fixture.git(&nested, &["commit", "-q", "-m", "init"]);
    let hidden = text(tree.join("nested/hidden-worktree"));
    fixture.git(&nested, &["worktree", "add", "-q", "-b", "hidden", &hidden]);

    let output = fixture.tama(&["worktrees", "list", "--root", &fixture.root()]);
    assert_eq!(output.status.code(), Some(0), "stderr: {}", stderr(&output));
    let printed = stdout(&output);
    assert!(
        printed.contains(&text(nested)),
        "the ignored checkout is reported: {printed}"
    );
    assert!(
        printed.contains(&hidden),
        "its worktree is reported: {printed}"
    );
}
