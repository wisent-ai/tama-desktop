//! Logic for `tama-block-crowded-folders`, registry hook
//! `block-crowded-folders`: a new file may not land in a folder that already
//! holds five.
//!
//! Only new files are judged; editing a file in a crowded folder is how a
//! folder gets tidied. Four kinds of folder are exempt because their layout
//! is decided elsewhere: migration directories (one file per migration, in
//! order, named by a timestamp), vendored and generated trees, and test
//! directories. New LaTeX-family files are exempt too, because a venue
//! template puts the document, its bibliography and its style files side by
//! side ("do it in a way where the 300-line and 5-files-per-folder hooks do
//! not apply to .tex", 2026-09-14).
//!
//! A folder the repository declared to the audit, with its reason beside it,
//! is exempt as well. A repository root holding eleven files because npm,
//! Poetry, git and GitHub each read one of them is the ordinary case, and
//! before the guard read that declaration such a root could not receive the
//! `.gitignore` it was missing.

use tama_hooks::session_record::{deny_tool_use, read_payload};

use crate::ports::violations_declarations::folder_is_declared;
use crate::ports::write_payload::WritePayload;

/// `-ge 5` in the shell: five files already there is enough to refuse.
const MAX_FILES_TEXT: &str = "5";
const EXEMPT_SUFFIXES: &[&str] = &[".tex", ".bib", ".sty", ".bst", ".cls"];
/// Suffixes of files nothing reads as lines: a screenshot, a recording, an
/// icon, a font, a drawing. A folder of them is not a layout a person chose
/// -- `spis` keeps one folder per journey holding the recording and the six
/// states it passed through, so the count is the number of states the
/// journey had, and "move files into sub-folders or consolidate" asks for
/// something that cannot be done to two screenshots. The same scan that
/// refuses to read these files for the line rule ("binary content") counted
/// every one of them for the folder rule until 2026-09-21: 267 of `spis`'s
/// crowded folders were captures.
const CAPTURE_SUFFIXES: &[&str] = &[
    ".png",
    ".jpg",
    ".jpeg",
    ".gif",
    ".webp",
    ".bmp",
    ".tiff",
    ".heic",
    ".ico",
    ".icns",
    ".svg",
    ".mp4",
    ".mov",
    ".m4v",
    ".webm",
    ".mp3",
    ".wav",
    ".m4a",
    ".pdf",
    ".woff",
    ".woff2",
    ".ttf",
    ".otf",
    ".zip",
    ".gz",
    ".tar",
    ".jar",
    ".wasm",
    ".pt",
    ".bin",
    ".gguf",
    ".safetensors",
];
/// Folder shapes whose file count is not a module-discipline question. A
/// database's own directories - the migrations it applied, the seeds it
/// loads in name order - are documents it names, not modules a person
/// arranges: `wisent-supabase-echo` keeps eighteen numbered seeds that no
/// sub-folder can hold without renaming what the database loads.
const EXEMPT_FOLDERS: &[&str] = &[
    "/supabase/migrations",
    "/supabase/seeds",
    "/node_modules/",
    "/.git/",
    "/__pycache__/",
    "/tests",
    "/migrations",
];

fn max_files() -> usize {
    MAX_FILES_TEXT.parse().unwrap_or_default()
}

fn exempt_file(path: &str) -> bool {
    let lowered = path.to_lowercase();
    EXEMPT_SUFFIXES
        .iter()
        .any(|suffix| lowered.ends_with(suffix))
        || !counts_toward_folder_limit(path)
}

/// Whether this path is one of the files the five-per-folder limit is about:
/// a module somebody wrote and somebody else has to find again.
///
/// The audit asks the guard rather than keeping its own list, because two
/// answers to "is this a module" drift and then the scan reports folders the
/// guard would never refuse.
pub fn counts_toward_folder_limit(path: &str) -> bool {
    let lowered = path.to_lowercase();
    !CAPTURE_SUFFIXES
        .iter()
        .any(|suffix| lowered.ends_with(suffix))
}

/// The shell tested `case "$DIR" in */tests*|*/migrations*|…`, so a marker
/// anywhere in the folder path exempts it, and the trailing-slash forms only
/// match a parent directory.
fn exempt_folder(dir: &str) -> bool {
    EXEMPT_FOLDERS.iter().any(|marker| dir.contains(marker))
}

fn files_in(dir: &std::path::Path) -> usize {
    let Ok(entries) = std::fs::read_dir(dir) else {
        return 0;
    };
    entries
        .flatten()
        .filter(|entry| entry.path().is_file())
        .filter(|entry| counts_toward_folder_limit(&entry.path().to_string_lossy()))
        .count()
}

/// The refusal this write earns, if any.
pub fn check(payload: &serde_json::Value) -> Option<String> {
    let write = WritePayload::read(payload)?;
    if write.is_system || exempt_file(&write.file_path) {
        return None;
    }
    let target = std::path::Path::new(&write.file_path);
    if target.is_file() {
        return None;
    }
    let dir = target.parent()?;
    let shown = dir.to_string_lossy().to_string();
    if exempt_folder(&shown) || !dir.is_dir() || folder_is_declared(&shown) {
        return None;
    }
    let count = files_in(dir);
    match count >= max_files() {
        true => Some(format!(
            "BLOCKED: Folder '{shown}' already has {count} files (max {}). Move files into \
             sub-folders or consolidate.",
            max_files()
        )),
        false => None,
    }
}

pub fn run() {
    if let Some(refusal) = check(&read_payload()) {
        deny_tool_use(&refusal);
    }
}

#[cfg(test)]
mod tests {
    use super::check;
    use serde_json::json;

    fn new_file(path: &std::path::Path) -> serde_json::Value {
        json!({
            "tool_name": "Write",
            "tool_input": { "file_path": path.to_string_lossy(), "content": "x" }
        })
    }

    /// Scratch folders live under the checkout's ignored build directory:
    /// nothing this workshop runs writes to the system temporary directory.
    fn folder_with(name: &str, files: usize) -> std::path::PathBuf {
        let dir = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../target/tmp")
            .join(format!("tama-crowded-{name}"));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).expect("a folder to judge");
        for index in 0..files {
            std::fs::write(dir.join(format!("f{index}.rs")), "x").expect("a file in it");
        }
        dir
    }

    #[test]
    fn a_new_file_in_a_full_folder_is_refused_and_the_count_is_named() {
        let dir = folder_with("full", 5);
        let refusal = check(&new_file(&dir.join("sixth.rs"))).expect("five is already too many");
        assert!(refusal.contains("already has 5 files"), "{refusal}");
        assert!(refusal.contains("max 5"), "{refusal}");
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn a_new_file_in_a_folder_with_room_passes() {
        let dir = folder_with("room", 4);
        assert_eq!(check(&new_file(&dir.join("fifth.rs"))), None);
        let _ = std::fs::remove_dir_all(&dir);
    }

    /// Editing a file that is already there is how a crowded folder gets
    /// tidied, so only new files are judged.
    #[test]
    fn an_existing_file_in_a_full_folder_passes() {
        let dir = folder_with("existing", 6);
        assert_eq!(check(&new_file(&dir.join("f0.rs"))), None);
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn a_manuscript_file_is_exempt() {
        let dir = folder_with("paper", 9);
        assert_eq!(check(&new_file(&dir.join("appendix.TEX"))), None);
        let _ = std::fs::remove_dir_all(&dir);
    }

    /// A migration directory holds one file per migration, in order; its file
    /// count is not a module-discipline question.
    #[test]
    fn a_migration_folder_is_exempt() {
        let dir = folder_with("supabase-migrations", 9);
        let inner = dir.join("supabase/migrations");
        std::fs::create_dir_all(&inner).expect("a migration folder");
        for index in 0..7 {
            std::fs::write(inner.join(format!("{index}_up.sql")), "x").expect("a migration");
        }
        assert_eq!(check(&new_file(&inner.join("8_up.sql"))), None);
        let _ = std::fs::remove_dir_all(&dir);
    }

    /// A seed directory is the same shape: eighteen numbered documents the
    /// database loads in name order, which a sub-folder would rename.
    #[test]
    fn a_seed_folder_is_exempt() {
        let dir = folder_with("supabase-seeds", 9);
        let inner = dir.join("supabase/seeds");
        std::fs::create_dir_all(&inner).expect("a seed folder");
        for index in 0..7 {
            std::fs::write(inner.join(format!("{index}_seed.sql")), "x").expect("a seed");
        }
        assert_eq!(check(&new_file(&inner.join("8_seed.sql"))), None);
        let _ = std::fs::remove_dir_all(&dir);
    }

    /// A journey's folder holds its recording and one screenshot per state it
    /// passed through. Nothing can be consolidated there, and the seventh
    /// state is not a layout decision.
    #[test]
    fn a_folder_of_captures_takes_another_capture() {
        let dir = folder_with("captures", 0);
        std::fs::write(dir.join("official-recording.mp4"), "x").expect("a recording");
        for index in 1..7 {
            std::fs::write(dir.join(format!("state-0{index}.png")), "x").expect("a screenshot");
        }
        assert_eq!(check(&new_file(&dir.join("state-07.png"))), None);
        let _ = std::fs::remove_dir_all(&dir);
    }

    /// The captures beside a module do not crowd it out of the way either:
    /// four modules and twenty screenshots still leave room for a fifth
    /// module, and the sixth is still refused.
    #[test]
    fn captures_do_not_count_against_the_modules_beside_them() {
        let dir = folder_with("mixed", 4);
        for index in 0..20 {
            std::fs::write(dir.join(format!("shot-{index}.PNG")), "x").expect("a screenshot");
        }
        assert_eq!(check(&new_file(&dir.join("fifth.rs"))), None);
        std::fs::write(dir.join("fifth.rs"), "x").expect("the fifth module");
        let refusal = check(&new_file(&dir.join("sixth.rs"))).expect("five modules is too many");
        assert!(refusal.contains("already has 5 files"), "{refusal}");
        let _ = std::fs::remove_dir_all(&dir);
    }
}
