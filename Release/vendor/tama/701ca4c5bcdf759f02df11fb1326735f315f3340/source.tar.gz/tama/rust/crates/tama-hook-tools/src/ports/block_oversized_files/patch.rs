//! How many lines a patch removes and adds, when the payload says so.
//!
//! The shell this gate replaces read `old_string` and `new_string`, which is
//! what one editor sends. This harness sends a line-anchored patch instead —
//! `{"toolName":"edit","input":{"patch":"…"}}` — and with both strings absent
//! the arithmetic came out as "removes nothing, adds nothing", so the gate
//! answered with the file's current length and refused every edit to a file
//! already over the limit. Including the deletions that bring it under.
//!
//! On 2026-09-16 that refused three attempts in a row to cut 59 lines out of
//! a 357-line test file: "File would be ~357 lines after edit". A rule nobody
//! can satisfy by doing the right thing is a rule that gets worked around.
//!
//! So a patch is measured here. Range and insert operations say exactly how
//! many lines they touch. Block operations (`PUT 12*:`) name a syntactic
//! block whose end only a parser knows, and register pastes carry content
//! from elsewhere, so a patch containing one of those is unmeasurable and
//! this module says so rather than inventing a number.

/// A unified or `apply_patch` diff, recognised by its own headers.
const DIFF_MARKERS: &[&str] = &[
    "@@ ",
    "*** Update File:",
    "*** Add File:",
    "*** Delete File:",
];

/// What a patch does to a file's length.
pub struct Measured {
    pub removed: usize,
    pub added: usize,
}

/// The `[path#TAG]` header that opens a section of the line-anchored
/// language. Returns the path it names.
fn section_path(line: &str) -> Option<&str> {
    let inner = line.strip_prefix('[')?.strip_suffix(']')?;
    let (path, tag) = inner.rsplit_once('#')?;
    let tagged = !tag.is_empty() && tag.chars().all(|c| c.is_ascii_hexdigit());
    match tagged && !path.is_empty() {
        true => Some(path),
        false => None,
    }
}

/// `N.=M` — the inclusive original lines an operation replaces or cuts. The
/// range is one token of the header, which also carries the operation word
/// and may end in a colon: `PUT 10.=12:` and `CUT 231.=289`.
fn range_size(operation: &str) -> Option<usize> {
    let token = operation
        .split_whitespace()
        .find(|token| token.contains(".="))?
        .trim_end_matches(':');
    let (start, end) = token.split_once(".=")?;
    let start: usize = start.trim().parse().ok()?;
    let end: usize = end.trim().parse().ok()?;
    match end >= start {
        true => Some(end - start + 1),
        false => None,
    }
}

/// Does this operation line name something whose extent only a parser knows?
fn unmeasurable(operation: &str) -> bool {
    let head = operation.split(':').next().unwrap_or_default();
    // A block op ends in `*`, a register paste names `@register`, and the
    // whole-file operations are not a length question at all.
    head.trim_end().ends_with('*')
        || head.contains('@')
        || head.starts_with("REM")
        || head.starts_with("MV")
}

/// The line-anchored language: `PUT`/`CUT` headers with `+` body rows.
fn measure_hash_lines(patch: &str, file_path: &str) -> Option<Measured> {
    let mut removed = usize::MIN;
    let mut added = usize::MIN;
    // A patch may carry sections for several files; only this file's count.
    let mut inside = file_path.is_empty();
    let mut seen_section = false;
    for line in patch.lines() {
        if let Some(path) = section_path(line.trim_end()) {
            seen_section = true;
            inside = file_path.is_empty() || file_path.ends_with(path) || path.ends_with(file_path);
            continue;
        }
        if let Some(body) = line.strip_prefix('+') {
            if inside {
                added += 1;
            }
            let _ = body;
            continue;
        }
        let operation = line.trim();
        if !(operation.starts_with("PUT")
            || operation.starts_with("CUT")
            || operation.starts_with("REM")
            || operation.starts_with("MV"))
        {
            continue;
        }
        if !inside {
            continue;
        }
        if unmeasurable(operation) {
            return None;
        }
        if let Some(size) = range_size(operation) {
            removed += size;
        }
    }
    match seen_section || !patch.trim().is_empty() {
        true => Some(Measured { removed, added }),
        false => None,
    }
}

/// A unified diff: `+` and `-` body lines, and nothing else.
fn measure_diff(patch: &str) -> Measured {
    let mut removed = usize::MIN;
    let mut added = usize::MIN;
    for line in patch.lines() {
        if line.starts_with("+++") || line.starts_with("---") {
            continue;
        }
        if line.starts_with('+') {
            added += 1;
        } else if line.starts_with('-') {
            removed += 1;
        }
    }
    Measured { removed, added }
}

/// What this patch does to `file_path`'s length, or `None` when the payload
/// does not say.
pub fn measure(patch: &str, file_path: &str) -> Option<Measured> {
    if patch.trim().is_empty() {
        return None;
    }
    if DIFF_MARKERS.iter().any(|marker| patch.contains(marker)) {
        return Some(measure_diff(patch));
    }
    measure_hash_lines(patch, file_path)
}

#[cfg(test)]
mod tests {
    use super::measure;

    /// The edit this gate refused three times on 2026-09-16: a pure deletion
    /// of 59 lines from a file already over the limit.
    #[test]
    fn a_deletion_is_measured_as_a_deletion() {
        let measured = measure("[crates/a/tests/b.rs#30D1]\nCUT 231.=289\n", "b.rs")
            .expect("a range op is measurable");

        assert_eq!(measured.removed, 59);
        assert_eq!(measured.added, usize::MIN);
    }

    #[test]
    fn a_replacement_counts_both_sides() {
        let measured = measure(
            "[src/lib.rs#A1B2]\nPUT 10.=12:\n+one\n+two\n",
            "/repo/src/lib.rs",
        )
        .expect("a range op is measurable");

        assert_eq!(measured.removed, 3);
        assert_eq!(measured.added, 2);
    }

    #[test]
    fn an_insert_removes_nothing() {
        let measured = measure("[src/lib.rs#A1B2]\nPUT >40:\n+added\n", "src/lib.rs")
            .expect("an insert is measurable");

        assert_eq!(measured.removed, usize::MIN);
        assert_eq!(measured.added, 1);
    }

    /// Only a parser knows where a block ends, so the gate must not guess.
    #[test]
    fn a_block_operation_is_not_measurable() {
        assert!(measure("[src/lib.rs#A1B2]\nPUT 10*:\n+one\n", "src/lib.rs").is_none());
        assert!(measure("[src/lib.rs#A1B2]\nCUT 10*\n", "src/lib.rs").is_none());
        assert!(measure("[src/lib.rs#A1B2]\nPUT <5 @moved\n", "src/lib.rs").is_none());
    }

    /// A patch that edits two files counts only the one being judged.
    #[test]
    fn another_files_section_does_not_count() {
        let measured = measure(
            "[src/a.rs#A1B2]\nPUT 1.=9:\n+one\n[src/b.rs#C3D4]\nPUT 1.=2:\n+two\n",
            "src/b.rs",
        )
        .expect("range ops are measurable");

        assert_eq!(measured.removed, 2);
        assert_eq!(measured.added, 1);
    }

    #[test]
    fn a_unified_diff_counts_its_own_body() {
        let measured = measure(
            "--- a/src/lib.rs\n+++ b/src/lib.rs\n@@ -1,3 +1,2 @@\n-gone\n-also gone\n+kept\n",
            "src/lib.rs",
        )
        .expect("a diff is measurable");

        assert_eq!(measured.removed, 2);
        assert_eq!(measured.added, 1);
    }
}
