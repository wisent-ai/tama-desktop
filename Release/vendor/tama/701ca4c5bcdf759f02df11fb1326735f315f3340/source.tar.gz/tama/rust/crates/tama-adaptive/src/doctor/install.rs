//! Consent-gated installation of the native adaptive runner shim over the
//! shared-hooks runner, with backup/restore and Claude settings output.

use std::fs;
use std::io::Write;
use std::path::PathBuf;

use super::repair::spawn_sync_capture;
use crate::engine::load_engine;
use crate::util::{home_dir, now_ms};

const BACKUP_PREFIX: &str = "run-hook.mjs.";

const CLAUDE_EVENTS: [(&str, &str, Option<&str>); 9] = [
    ("stop", "Stop", None),
    ("user_prompt_submit", "UserPromptSubmit", None),
    ("pre_tool_use:bash", "PreToolUse", Some("Bash")),
    (
        "pre_tool_use:edit",
        "PreToolUse",
        Some("apply_patch|Edit|Write"),
    ),
    ("pre_tool_use:read", "PreToolUse", Some("Read")),
    ("pre_tool_use:notebook", "PreToolUse", Some("NotebookEdit")),
    (
        "pre_tool_use:wait",
        "PreToolUse",
        Some("Monitor|ScheduleWakeup"),
    ),
    ("post_tool_use:bash", "PostToolUse", Some("Bash")),
    ("session_start:compact", "SessionStart", Some("compact")),
];

fn legacy_runner_path() -> PathBuf {
    home_dir().join(".shared-hooks").join("run-hook.mjs")
}

fn tama_cli_path() -> PathBuf {
    std::env::current_exe().unwrap_or_else(|_| PathBuf::from("tama-cli"))
}

fn shell_quote(value: &str) -> String {
    format!("'{}'", value.replace('\'', "'\"'\"'"))
}

fn shim_source() -> String {
    let cli = shell_quote(&tama_cli_path().to_string_lossy());
    [
        "#!/bin/sh".to_string(),
        "# Adaptive shim installed by tama-cli; uninstall restores the backup.".to_string(),
        "export HOOKS_ADAPTIVE_SHIM=1".to_string(),
        format!("exec {cli} adaptive-runner \"$@\""),
        String::new(),
    ]
    .join("\n")
}

fn verify_shim(shim_path: &PathBuf) -> Result<(), String> {
    let result = spawn_sync_capture(
        "sh",
        &[
            shim_path.to_string_lossy().to_string(),
            "adaptive-shim-verify".to_string(),
        ],
        "{}",
    );
    if let Some(error) = result.error {
        return Err(error);
    }
    let last = result
        .stdout
        .split('\n')
        .filter(|line| !line.trim().is_empty())
        .last()
        .unwrap_or("")
        .to_string();
    match serde_json::from_str::<serde_json::Value>(&last) {
        Ok(decision) if decision.get("decision").and_then(|v| v.as_str()) == Some("pass") => Ok(()),
        Ok(_) => Err(format!("unexpected decision output: {}", last)),
        Err(_) => Err("no decision JSON on stdout".to_string()),
    }
}

/// `install()`.
pub fn install() -> i32 {
    if std::env::var("DEVICE_HOOK_EDIT_APPROVED").ok().as_deref() != Some("1") {
        let _ = writeln!(
            std::io::stderr(),
            "refusing to install: owner consent is missing."
        );
        let _ = writeln!(
            std::io::stderr(),
            "Run this yourself in a shell outside any agent session, then rerun install:"
        );
        let _ = writeln!(std::io::stderr(), "  export DEVICE_HOOK_EDIT_APPROVED='1'");
        return 1;
    }
    let core = load_engine();
    let target = legacy_runner_path();
    if !target.exists() {
        let _ = writeln!(
            std::io::stderr(),
            "legacy runner not found at {}",
            target.display()
        );
        return 1;
    }
    let backup_dir = core.state_dir.join("backup");
    if fs::create_dir_all(&backup_dir).is_err() {
        let _ = writeln!(
            std::io::stderr(),
            "cannot create backup dir {}",
            backup_dir.display()
        );
        return 1;
    }
    let backup_path = backup_dir.join(format!("{}{}", BACKUP_PREFIX, now_ms()));
    if fs::copy(&target, &backup_path).is_err() {
        let _ = writeln!(std::io::stderr(), "cannot back up legacy runner");
        return 1;
    }
    if fs::write(&target, shim_source()).is_err() {
        let _ = writeln!(std::io::stderr(), "cannot write shim");
        return 1;
    }
    match verify_shim(&target) {
        Ok(()) => {
            println!("adaptive shim installed at {}", target.display());
            println!("backup: {}", backup_path.display());
            0
        }
        Err(reason) => {
            let _ = fs::copy(&backup_path, &target);
            let _ = writeln!(
                std::io::stderr(),
                "shim verification did not pass ({}); original runner restored from {}",
                reason,
                backup_path.display()
            );
            1
        }
    }
}

/// `uninstall()`.
pub fn uninstall() -> i32 {
    let core = load_engine();
    let backup_dir = core.state_dir.join("backup");
    let target = legacy_runner_path();
    if !backup_dir.exists() {
        let _ = writeln!(
            std::io::stderr(),
            "no backup dir at {}",
            backup_dir.display()
        );
        return 1;
    }
    let mut names: Vec<String> = match fs::read_dir(&backup_dir) {
        Ok(entries) => entries
            .flatten()
            .map(|entry| entry.file_name().to_string_lossy().to_string())
            .filter(|name| name.starts_with(BACKUP_PREFIX))
            .collect(),
        Err(_) => Vec::new(),
    };
    names.sort_by(|a, b| {
        let num = |name: &str| {
            name[BACKUP_PREFIX.len()..]
                .parse::<f64>()
                .unwrap_or(f64::NAN)
        };
        num(a)
            .partial_cmp(&num(b))
            .unwrap_or(std::cmp::Ordering::Equal)
    });
    let Some(newest) = names.last() else {
        let _ = writeln!(
            std::io::stderr(),
            "no runner backups under {}",
            backup_dir.display()
        );
        return 1;
    };
    if fs::copy(backup_dir.join(newest), &target).is_err() {
        let _ = writeln!(std::io::stderr(), "cannot restore runner backup");
        return 1;
    }
    println!("restored {} from {}", target.display(), newest);
    0
}

/// `claudeConfig()` — prints (never writes) the Claude settings fragment
/// routing every mapped registry event through node + the legacy runner.
pub fn claude_config() -> i32 {
    let core = load_engine();
    let runner = legacy_runner_path();
    let mut config = serde_json::Map::new();
    let event_names: Vec<String> = core.registry.events.keys().cloned().collect();
    for event_name in event_names {
        let Some((_, hook_event, matcher)) = CLAUDE_EVENTS
            .iter()
            .find(|(name, _, _)| *name == event_name)
        else {
            continue;
        };
        let routed = serde_json::json!({
            "type": "command",
            "command": format!("node {} {}", runner.display(), event_name),
        });
        let entry = match matcher {
            Some(matcher) => serde_json::json!({ "matcher": matcher, "hooks": [routed] }),
            None => serde_json::json!({ "hooks": [routed] }),
        };
        let bucket = config
            .entry(hook_event.to_string())
            .or_insert_with(|| serde_json::Value::Array(Vec::new()));
        if let Some(list) = bucket.as_array_mut() {
            list.push(entry);
        }
    }
    let output = serde_json::json!({ "hooks": config });
    println!(
        "{}",
        serde_json::to_string_pretty(&output).unwrap_or_default()
    );
    0
}
