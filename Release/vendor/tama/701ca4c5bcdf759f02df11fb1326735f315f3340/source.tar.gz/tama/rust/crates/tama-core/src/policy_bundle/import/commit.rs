//! Writing an accepted bundle into the store: stage beside it, swap both
//! the bundle and the index into place, and put the old ones back if the
//! swap fails halfway.
//!
//! Split out of `policy_bundle.rs`, which had grown past the
//! three-hundred-line limit.

use std::fs::{self, OpenOptions};
use std::io::Write;
use std::path::Path;

use crate::Result;

use super::super::records::{BundleFileRecord, PolicyBundleRecord, Selection};
use super::super::store::{index_path, timestamp, transaction_id};
use super::super::{safe_join, set_mode};
use super::super::{PolicyBundleIndex, INACTIVE};

/// The index is the store's own bookkeeping: readable and writable by its
/// owner, by nobody else.
const INDEX_MODE: u32 = 0o600;

/// Copy the selected files into the store and record them in the index.
pub(super) fn commit(
    store: &Path,
    bundle_root: &Path,
    source: &Path,
    source_key: &str,
    selection: &Selection,
    index: &mut PolicyBundleIndex,
) -> Result<()> {
    let id = transaction_id();
    let stage_root = store.join(format!(".bundle-stage-{id}"));
    let backup_root = store.join(format!(".bundle-backup-{id}"));
    let stage_bundle = stage_root.join("bundle");
    for file in &selection.files {
        let destination = safe_join(&stage_bundle, &file.relative)?;
        if let Some(parent) = destination.parent() {
            fs::create_dir_all(parent)?;
        }
        let mut output = OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&destination)?;
        output.write_all(&file.bytes)?;
        output.flush()?;
        set_mode(&destination, file.mode)?;
    }

    let record = PolicyBundleRecord {
        source_key: source_key.to_string(),
        source_path: source.display().to_string(),
        source_digest: selection.digest.clone(),
        bundle_path: bundle_root.display().to_string(),
        imported_at_unix: timestamp(),
        hook_count: selection.hook_count,
        activation: INACTIVE.to_string(),
        files: selection
            .files
            .iter()
            .map(|file| BundleFileRecord {
                path: file.relative.clone(),
                sha256: file.sha256.clone(),
                mode: file.mode,
            })
            .collect(),
    };
    index
        .bundles
        .retain(|bundle| bundle.source_key != source_key);
    index.bundles.push(record);
    index
        .bundles
        .sort_by(|left, right| left.source_path.cmp(&right.source_path));
    let staged_index = stage_root.join("index.json");
    fs::write(&staged_index, serde_json::to_vec_pretty(&index)?)?;
    set_mode(&staged_index, INDEX_MODE)?;

    fs::create_dir_all(store.join("bundles"))?;
    fs::create_dir_all(&backup_root)?;
    let current_index = index_path(store);
    let backup_bundle = backup_root.join("bundle");
    let backup_index = backup_root.join("index.json");
    let mut backed_bundle = false;
    let mut backed_index = false;
    let mut placed_bundle = false;
    let mut placed_index = false;
    let swap = (|| -> Result<()> {
        if bundle_root.exists() {
            fs::rename(bundle_root, &backup_bundle)?;
            backed_bundle = true;
        }
        if current_index.exists() {
            fs::rename(&current_index, &backup_index)?;
            backed_index = true;
        }
        fs::rename(&stage_bundle, bundle_root)?;
        placed_bundle = true;
        fs::rename(&staged_index, &current_index)?;
        placed_index = true;
        Ok(())
    })();
    if let Err(error) = swap {
        if placed_index {
            let _ = fs::remove_file(&current_index);
        }
        if placed_bundle {
            let _ = fs::remove_dir_all(bundle_root);
        }
        if backed_index {
            let _ = fs::rename(&backup_index, &current_index);
        }
        if backed_bundle {
            let _ = fs::rename(&backup_bundle, bundle_root);
        }
        let _ = fs::remove_dir_all(&stage_root);
        let _ = fs::remove_dir_all(&backup_root);
        return Err(error);
    }
    fs::remove_dir_all(&stage_root).ok();
    fs::remove_dir_all(&backup_root).ok();
    Ok(())
}
