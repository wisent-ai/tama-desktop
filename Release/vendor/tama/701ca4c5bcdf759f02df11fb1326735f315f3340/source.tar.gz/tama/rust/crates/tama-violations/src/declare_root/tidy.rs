//! Clearing what a root should not carry: Finder metadata and a build's
//! own cache, deleted from the working tree, dropped from the index when
//! they were committed, and named in `.gitignore` so they do not come back.
//!
//! Without this a sweep over a workshop stops at every root that ever had
//! a Finder window opened on it, and the operator is asked to delete the
//! same two files by hand in a hundred repositories.

use std::fs;
use std::path::Path;

/// What one tidy pass did to a root.
pub struct Tidied {
    /// Files removed from the working tree.
    pub removed: Vec<String>,
    /// Files that were tracked and are now out of the index.
    pub untracked: Vec<String>,
    /// Patterns added to `.gitignore`.
    pub ignored: Vec<String>,
}

fn git(repo: &Path, arguments: &[&str]) -> Result<String, String> {
    let output = std::process::Command::new("git")
        .args(arguments)
        .current_dir(repo)
        .output()
        .map_err(|error| format!("cannot run git in {}: {error}", repo.display()))?;
    if !output.status.success() {
        return Err(format!(
            "git {} failed in {}: {}",
            arguments.join(" "),
            repo.display(),
            String::from_utf8_lossy(&output.stderr).trim()
        ));
    }
    Ok(String::from_utf8_lossy(&output.stdout).trim().to_string())
}

fn tracked(repo: &Path, name: &str) -> bool {
    git(repo, &["ls-files", "--error-unmatch", "--", name]).is_ok()
}

fn ignores(repo: &Path, pattern: &str) -> bool {
    fs::read_to_string(repo.join(".gitignore"))
        .map(|text| {
            text.lines()
                .any(|line| line.trim() == pattern || line.trim() == format!("/{pattern}"))
        })
        .unwrap_or_default()
}

fn append_ignore(repo: &Path, pattern: &str) -> Result<(), String> {
    let path = repo.join(".gitignore");
    let existing = fs::read_to_string(&path).unwrap_or_default();
    let separator = if existing.is_empty() || existing.ends_with('\n') {
        ""
    } else {
        "\n"
    };
    let body = format!("{existing}{separator}{pattern}\n");
    fs::write(&path, body).map_err(|error| format!("{}: {error}", path.display()))
}

/// Delete each named file from this root, drop it from the index when it
/// was committed, and make sure `.gitignore` names it.
pub fn tidy(repo: &Path, names: &[String]) -> Result<Tidied, String> {
    let mut done = Tidied {
        removed: Vec::new(),
        untracked: Vec::new(),
        ignored: Vec::new(),
    };
    for name in names {
        if tracked(repo, name) {
            git(repo, &["rm", "--quiet", "--cached", "--", name])?;
            done.untracked.push(name.clone());
        }
        let path = repo.join(name);
        if path.exists() {
            fs::remove_file(&path).map_err(|error| format!("{}: {error}", path.display()))?;
            done.removed.push(name.clone());
        }
        if !ignores(repo, name) {
            append_ignore(repo, name)?;
            done.ignored.push(name.clone());
        }
    }
    Ok(done)
}
