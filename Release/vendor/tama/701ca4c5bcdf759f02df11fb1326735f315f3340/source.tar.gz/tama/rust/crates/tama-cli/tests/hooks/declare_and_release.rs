//! `tama hooks declare` and `tama hooks release`, through the real CLI.
//!
//! Adding a hook writes in two places: the repository documents (catalogue
//! entry, registry binding, reconciled sources, seal) and the machine (the
//! native binaries the registry points at, the sealed live release, this
//! machine's selection). Neither half had a command, so each change arrived
//! as a shell file in an ignored build directory, handed to the operator with
//! a path. On 2026-09-19 they asked the obvious question about one:
//! "i jak niby mam go uruchomic".
//!
//! What is checked here is what an operator sees before anything changes: the
//! plan each half prints, the hook binaries the real registry names, the
//! refusal that arrives without the owner's device consent and the command
//! that refusal tells them to run, and the refusal for a declaration that
//! binds no event. The consenting run installs a release on the machine it
//! runs on; it belongs to the owner, and no test grants that consent to
//! itself.

use std::fs;
use std::path::{Path, PathBuf};
use std::process::{Command, Output};

/// The CLI as built, beside this test binary.
fn cli() -> PathBuf {
    let mut path = std::env::current_exe().expect("test binary path");
    path.pop();
    if path.ends_with("deps") {
        path.pop();
    }
    path.join("tama-cli")
}

/// The checkout this test runs in: the crate, two levels up.
fn repo() -> PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR"))
        .ancestors()
        .nth(3)
        .expect("the checkout above rust/crates/tama-cli")
        .to_path_buf()
}

fn run_in(directory: &Path, args: &[&str]) -> Output {
    Command::new(cli())
        .args(args)
        .current_dir(directory)
        .env_remove("DEVICE_HOOK_EDIT_APPROVED")
        .env_remove("TAMA_ROOT")
        .output()
        .expect("run tama-cli")
}

fn run(args: &[&str]) -> Output {
    run_in(&repo(), args)
}

fn text(output: &Output) -> String {
    format!(
        "{}{}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    )
}

#[test]
fn release_plan_names_every_hook_binary_the_registry_points_at() {
    let output = run(&["hooks", "release", "--dry-run"]);
    assert!(
        output.status.success(),
        "the plan failed: {}",
        text(&output)
    );
    let said = text(&output);
    let registry =
        fs::read_to_string(repo().join("shared-hooks/registry.json")).expect("read the registry");
    for hook in ["tama-block-inline-execution", "tama-pre-write-edit"] {
        if registry.contains(hook) {
            assert!(
                said.contains(hook),
                "{hook} is registered but absent from the plan: {said}"
            );
        }
    }
    assert!(
        said.contains("would stage, seal and install the live release"),
        "the plan does not say what it would install: {said}"
    );
}

/// The engine every provider dispatcher runs had no install path until
/// 2026-09-20: `tama-run-hook` in `~/.local/bin` sat six days behind the
/// engine the sealed release was already using, so a fix landed in one copy
/// and not the other. A release installs both programs from its own build
/// and warms what it installed.
#[test]
fn release_plan_installs_and_warms_the_runtime_programs() {
    let output = run(&["hooks", "release", "--dry-run"]);
    let said = text(&output);
    assert!(output.status.success(), "the plan failed: {said}");
    for program in ["tama-run-hook", "tama-cli"] {
        assert!(
            said.contains(program),
            "{program} is not part of the plan: {said}"
        );
    }
    assert!(
        said.contains("would warm every installed binary"),
        "the plan does not say it warms what it installs: {said}"
    );
}

/// The sealed runtime is staged from the checkout's working tree, so a
/// shared checkout can seal gates carrying code nobody committed. The
/// release recorded that and never showed it; now it says so.
#[test]
fn the_plan_says_where_the_installed_runtime_was_built_from() {
    let manifest = PathBuf::from(std::env::var("HOME").expect("HOME"))
        .join("Library/Application Support/Tama/hooks-runtime/current")
        .join("native-hook-binaries.json");
    if !manifest.is_file() {
        return;
    }
    let recorded = fs::read_to_string(&manifest).expect("read the native manifest");
    let identity: serde_json::Value =
        serde_json::from_str(&recorded).expect("the native manifest is JSON");
    let revision = identity["sourceIdentity"]["revision"]
        .as_str()
        .expect("a recorded revision");

    let said = text(&run(&["hooks", "release", "--dry-run"]));

    assert!(
        said.contains("installed runtime: built from") && said.contains(revision),
        "the plan does not say where the live engine came from: {said}"
    );
}

#[test]
fn a_release_without_the_owners_consent_is_refused_and_names_the_command() {
    let output = run(&["hooks", "release"]);
    assert_eq!(
        output.status.code(),
        Some(2),
        "expected a refusal: {}",
        text(&output)
    );
    let said = text(&output);
    assert!(
        said.contains("DEVICE_HOOK_EDIT_APPROVED=1 ./rust/target/release/tama-cli hooks release"),
        "the refusal does not name a command that exists on this machine today: {said}"
    );
    assert!(
        said.contains("outside any agent session"),
        "the refusal does not say where to run it: {said}"
    );
    assert!(
        !repo().join("rust/target/hook-release-src").exists(),
        "the refusal exported sources before consent"
    );
}

#[test]
fn the_declaration_in_this_repository_is_read_and_planned() {
    let declaration = repo().join("hook-declarations/block-one-off-repairs.json");
    assert!(
        declaration.is_file(),
        "{} is missing",
        declaration.display()
    );
    let output = run(&[
        "hooks",
        "declare",
        "--file",
        declaration.to_str().expect("declaration path"),
        "--dry-run",
    ]);
    assert!(
        output.status.success(),
        "the plan failed: {}",
        text(&output)
    );
    let said = text(&output);
    assert!(
        said.contains("block-one-off-repairs") && said.contains("pre_tool_use:bash"),
        "the plan does not name the hook and its event: {said}"
    );
    assert!(
        said.contains("would reconcile sources and reseal"),
        "the plan does not say the registry is resealed: {said}"
    );
}

#[test]
fn a_declaration_that_binds_no_event_is_refused() {
    let scratch = Path::new(env!("CARGO_TARGET_TMPDIR")).join("hooks-declare-no-event");
    fs::create_dir_all(&scratch).expect("create the scratch directory");
    let file = scratch.join("unbound.json");
    fs::write(
        &file,
        r#"{"id":"tama-test-unbound","category":"c","description":"d","why":"w",
            "sideEffects":"s","command":"$HOME/.local/bin/tama-test-unbound","events":[]}"#,
    )
    .expect("write the declaration");
    let output = run(&["hooks", "declare", "--file", file.to_str().expect("path")]);
    assert_eq!(
        output.status.code(),
        Some(2),
        "expected a refusal: {}",
        text(&output)
    );
    assert!(
        text(&output).contains("binds no event"),
        "the refusal does not say why: {}",
        text(&output)
    );
    fs::remove_file(&file).expect("remove the declaration");
}

/// What a release leaves behind has to be runnable.
///
/// `cargo` leaves an ad-hoc, linker-signed binary, and macOS kills such a
/// copy with signal 9 the moment anything runs it. On 2026-09-21 a release
/// installed seventy-three of them: every hook died before reading its
/// event, and `tama-cli` died with them, so the command that installs hooks
/// could not repair the machine it had broken. This drives every installed
/// hook binary the registry names and fails on that death.
#[test]
fn every_installed_hook_binary_runs_instead_of_being_killed() {
    let home = PathBuf::from(std::env::var("HOME").expect("HOME"));
    let registry =
        fs::read_to_string(repo().join("shared-hooks/registry.json")).expect("read the registry");
    let registry: serde_json::Value =
        serde_json::from_str(&registry).expect("the registry is JSON");
    let mut checked = 0usize;
    let mut killed: Vec<String> = Vec::new();
    for hook in registry["hooks"].as_array().into_iter().flatten() {
        let Some(command) = hook["command"].as_str() else {
            continue;
        };
        let Some(name) = command.rsplit('/').next() else {
            continue;
        };
        if !name.starts_with("tama-") {
            continue;
        }
        let binary = home.join(".local/bin").join(name);
        if !binary.is_file() {
            continue;
        }
        checked += 1;
        let output = Command::new(&binary)
            .stdin(std::process::Stdio::null())
            .output()
            .unwrap_or_else(|error| panic!("run {}: {error}", binary.display()));
        if output.status.code().is_none() || output.status.code() == Some(137) {
            killed.push(format!("{} -> {}", binary.display(), output.status));
        }
    }
    assert!(
        killed.is_empty(),
        "the operating system refuses {} of {checked} installed hook binaries; \
         `wisent-products signing residue` lists what is still ad-hoc:\n{}",
        killed.len(),
        killed.join("\n")
    );
}

/// A signature is not byte-stable, so a release cannot recognise its own
/// work by comparing the installed copy against the freshly built one. It
/// records the unsigned build instead, and that record is what makes a
/// repeat run install nothing.
#[test]
fn the_release_records_which_build_each_installed_binary_came_from() {
    let home = PathBuf::from(std::env::var("HOME").expect("HOME"));
    let record = home.join(".tama/installed-binaries.json");
    if !record.is_file() {
        return;
    }
    let digests: std::collections::BTreeMap<String, String> =
        serde_json::from_str(&fs::read_to_string(&record).expect("read the record"))
            .expect("the record is a name to digest map");
    assert!(
        digests.contains_key("tama-cli"),
        "{} names no CLI build: {digests:?}",
        record.display()
    );
    for (name, digest) in &digests {
        assert_eq!(digest.len(), 64, "{name} has no sha256 digest: {digest}");
        assert!(
            home.join(".local/bin").join(name).is_file(),
            "{name} is recorded as installed but missing from ~/.local/bin"
        );
    }
}
