//! `tama-check-animation-verdict`, driven as the real binary over a real
//! transcript file. The operator, 2026-09-19: "kontynuuj prace az naprawisz
//! wszystkie problemy z keywordami". The guard's three vocabularies — how a
//! turn says an animation is good, how a metric line reports a clip as
//! passing, and where the frames that would prove it live — moved out of the
//! source into `animation-verdict-patterns.json`, and the guard had no journey
//! at all. A verdict about motion with no frames read is refused; the same
//! verdict passes once four frame reads are in the transcript; a turn that
//! claims nothing about animation is left alone.

use std::fs;
use std::io::Write;
use std::path::{Path, PathBuf};
use std::process::{Command, Output, Stdio};
use std::time::{SystemTime, UNIX_EPOCH};

use serde_json::json;

const GUARD: &str = env!("CARGO_BIN_EXE_tama-check-animation-verdict");

fn scratch() -> PathBuf {
    let nonce = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .expect("clock after epoch")
        .as_nanos();
    let thread = format!("{:?}", std::thread::current().id()).replace(['(', ')'], "-");
    let home =
        PathBuf::from(env!("CARGO_TARGET_TMPDIR")).join(format!("tama-animation-{thread}{nonce}"));
    fs::create_dir_all(&home).expect("create the scratch home");
    home
}

/// A transcript of `Read` records followed by one assistant message, in the
/// shape the session log writes.
fn transcript(home: &Path, frame_reads: usize, said: &str) -> PathBuf {
    let mut lines: Vec<String> = Vec::new();
    for frame in 0..frame_reads {
        lines.push(
            json!({
                "role": "assistant",
                "content": [{
                    "type": "tool_use",
                    "name": "Read",
                    "input": { "file_path": format!(
                        "{}/.weles/runs/knight/cmp/walk/f{:03}.png",
                        home.display(),
                        frame
                    ) },
                }],
            })
            .to_string(),
        );
    }
    lines.push(
        json!({ "role": "assistant", "content": [{ "type": "text", "text": said }] }).to_string(),
    );
    let path = home.join("session.jsonl");
    fs::write(&path, lines.join("\n")).expect("write the transcript");
    path
}

fn drive(home: &Path, transcript_path: &Path) -> Output {
    let payload = json!({ "transcript_path": transcript_path });
    let mut child = Command::new(GUARD)
        .env("HOME", home)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .unwrap_or_else(|error| panic!("spawn the guard: {error}"));
    child
        .stdin
        .as_mut()
        .expect("guard stdin")
        .write_all(payload.to_string().as_bytes())
        .expect("write payload");
    child.wait_with_output().expect("guard output")
}

/// The refusal banner, or `None` when the turn was let through.
fn refusal(output: &Output) -> Option<String> {
    if output.status.success() {
        return None;
    }
    Some(String::from_utf8_lossy(&output.stderr).into_owned())
}

#[test]
fn a_verdict_about_motion_with_no_frames_read_is_refused() {
    let home = scratch();
    let path = transcript(
        &home,
        0,
        "The skinning works now and the walk clip is clean.",
    );
    let reason = refusal(&drive(&home, &path)).expect("refused");
    assert!(
        reason.contains("animation verdict needs rendered frames"),
        "{reason}"
    );
    assert!(reason.contains("only 0 Read(s)"), "{reason}");
    assert!(reason.contains("skinning works"), "{reason}");
}

#[test]
fn a_metric_line_calling_a_clip_ok_counts_as_a_verdict() {
    let home = scratch();
    let path = transcript(&home, 1, "walk  tear_score 0.041  stride 0.12  OK");
    let reason = refusal(&drive(&home, &path)).expect("refused");
    assert!(reason.contains("only 1 Read(s)"), "{reason}");
}

#[test]
fn the_same_verdict_passes_once_the_frames_were_actually_read() {
    let home = scratch();
    let path = transcript(
        &home,
        4,
        "The skinning works now and the walk clip is clean.",
    );
    let output = drive(&home, &path);
    assert_eq!(
        refusal(&output),
        None,
        "{}",
        String::from_utf8_lossy(&output.stdout)
    );
}

#[test]
fn a_turn_that_claims_nothing_about_animation_is_left_alone() {
    let home = scratch();
    let path = transcript(
        &home,
        0,
        "The lease store returned 409 and the retry succeeded.",
    );
    let output = drive(&home, &path);
    assert_eq!(
        refusal(&output),
        None,
        "{}",
        String::from_utf8_lossy(&output.stdout)
    );
}
