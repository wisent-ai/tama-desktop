//! JS `declaredProviderCoverage(root)`: what each provider's configuration
//! claims, and how much of that its own config really installs.
//!
//! Moved verbatim out of the single runtime file; the adapter reading now
//! comes from the [`crate::runtime::adapter_config`] module.

use std::collections::{BTreeMap, HashSet};
use std::path::Path;

use serde::Serialize;
use serde_json::Value;

use crate::registry::Registry;
use crate::runtime::adapter_config::{adapter_command_index, AdapterCommandIndex};
use crate::runtime::claims::{
    claimed_runtime_specs_for_event, runtime_actually_installs_hook, RuntimeSpec,
};
use crate::runtime::load_registry;
use crate::Result;

/// One mapping row of JS `declaredProviderCoverage`: a registry event claimed
/// by a runtime, or a catalogued Git hook.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ProviderCoverageMapping {
    pub provider: String,
    pub event: String,
    pub runtime_event: String,
    pub hook_id: String,
}

/// One provider entry of JS `declaredProviderCoverage`, serialized with the
/// exact keys the JS command printed.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ProviderCoverage {
    pub provider: String,
    pub coverage_kind: String,
    pub mapping_count: usize,
    pub hook_count: usize,
    pub event_count: usize,
    pub adapter_path: Option<String>,
    /// How many of those declared mappings the provider's own config really
    /// installs, for the two providers whose config Tama writes. `None`
    /// elsewhere: OMP, Git, the editors and kimi carry no such config, so the
    /// question has no answer rather than the answer zero.
    pub installed_mapping_count: Option<usize>,
    pub required_live_coverage: Option<bool>,
    pub evidence: String,
    pub note: Option<String>,
    pub mappings: Vec<ProviderCoverageMapping>,
}

const FIXED_PROVIDERS: &[&str] = &[
    "claude",
    "codex",
    "omp",
    "editor-save-guard",
    "editor-watch-session",
    "git",
    "kimi",
];

fn git_mappings(registry: &Registry, mappings: &mut Vec<ProviderCoverageMapping>) {
    let Some(git_hooks) = registry
        .extra
        .get("catalog")
        .and_then(|catalog| catalog.get("gitHooks"))
        .and_then(Value::as_array)
    else {
        return;
    };
    for hook in git_hooks {
        let Some(id) = hook.get("id").and_then(Value::as_str) else {
            continue;
        };
        let event = hook.get("event").and_then(Value::as_str).unwrap_or(id);
        mappings.push(ProviderCoverageMapping {
            provider: "git".to_string(),
            event: event.to_string(),
            runtime_event: event.to_string(),
            hook_id: id.to_string(),
        });
    }
}

/// How many of `covered` the provider's own config installs, or `None` when
/// its config cannot be indexed at all.
fn installed_mapping_count(
    registry: &Registry,
    provider: &str,
    covered: &[ProviderCoverageMapping],
) -> Option<usize> {
    let index = adapter_command_index(registry, provider).ok()?;
    let mut adapter_commands: BTreeMap<String, AdapterCommandIndex> = BTreeMap::new();
    adapter_commands.insert(provider.to_string(), index);
    Some(
        covered
            .iter()
            .filter(|mapping| {
                let command = registry
                    .events
                    .get(&mapping.event)
                    .and_then(|config| config.hooks.iter().find(|hook| hook.id == mapping.hook_id))
                    .and_then(|hook| hook.command.clone());
                runtime_actually_installs_hook(
                    &adapter_commands,
                    &RuntimeSpec {
                        runtime: provider.to_string(),
                        runtime_event: Some(mapping.runtime_event.clone()),
                    },
                    &mapping.hook_id,
                    command.as_deref(),
                    None,
                )
            })
            .count(),
    )
}

/// JS `declaredProviderCoverage(root)` with no provider filter: every
/// provider the fixed list or the mappings name, sorted byte-lexicographically
/// (identical to `.sort()` for the ASCII provider ids involved).
pub fn declared_provider_coverage(root: &Path) -> Result<Vec<ProviderCoverage>> {
    let registry = load_registry(root)?;
    let mut mappings: Vec<ProviderCoverageMapping> = Vec::new();
    for (event, config) in &registry.events {
        for hook in &config.hooks {
            for spec in claimed_runtime_specs_for_event(event, Some(&registry)) {
                mappings.push(ProviderCoverageMapping {
                    runtime_event: spec.runtime_event.unwrap_or_else(|| event.clone()),
                    provider: spec.runtime,
                    event: event.clone(),
                    hook_id: hook.id.clone(),
                });
            }
        }
    }
    git_mappings(&registry, &mut mappings);

    let mut providers: Vec<String> = FIXED_PROVIDERS
        .iter()
        .map(|provider| provider.to_string())
        .collect();
    for mapping in &mappings {
        if !providers.contains(&mapping.provider) {
            providers.push(mapping.provider.clone());
        }
    }
    providers.sort();

    Ok(providers
        .into_iter()
        .map(|provider| {
            let covered: Vec<ProviderCoverageMapping> = mappings
                .iter()
                .filter(|mapping| mapping.provider == provider)
                .cloned()
                .collect();
            // Declared coverage says what the registry claims; this says what
            // the provider's config on this machine would actually run. An
            // install that wrote an empty block used to leave the two
            // indistinguishable here.
            let installed = installed_mapping_count(&registry, &provider, &covered);
            let adapter = registry.adapters.get(&provider);
            ProviderCoverage {
                coverage_kind: if provider == "kimi" {
                    "indirect".to_string()
                } else {
                    "declared".to_string()
                },
                mapping_count: covered.len(),
                hook_count: covered
                    .iter()
                    .map(|mapping| mapping.hook_id.as_str())
                    .collect::<HashSet<_>>()
                    .len(),
                event_count: covered
                    .iter()
                    .map(|mapping| mapping.event.as_str())
                    .collect::<HashSet<_>>()
                    .len(),
                adapter_path: adapter.and_then(|adapter| adapter.path.clone()),
                installed_mapping_count: installed,
                required_live_coverage: adapter
                    .and_then(|adapter| adapter.extra.get("requiredLiveCoverage"))
                    .and_then(Value::as_bool),
                evidence: "Registry-declared mappings; not live execution evidence.".to_string(),
                note: (provider == "kimi").then(|| {
                    "No native hook adapter; coverage is indirect through editor and Git surfaces."
                        .to_string()
                }),
                mappings: covered,
                provider,
            }
        })
        .collect())
}
