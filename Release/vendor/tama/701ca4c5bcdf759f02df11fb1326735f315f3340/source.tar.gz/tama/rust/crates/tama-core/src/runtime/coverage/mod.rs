//! The two coverage readings this product publishes.
//!
//! [`provider`] answers what each provider's configuration claims and how
//! much of that its own config really installs. [`required`] answers which
//! mappings a live run must exercise, and summarises what a run passed and
//! what it missed. They grew past the file limit together, so they are
//! siblings under one family name and every published name is re-exported
//! here.

pub mod provider;
pub mod required;

pub use provider::{declared_provider_coverage, ProviderCoverage, ProviderCoverageMapping};
pub use required::{
    build_required_coverage, summarize_coverage, CoverageSummary, GitCoverage, RequiredCoverage,
    RuntimeCoverage,
};
