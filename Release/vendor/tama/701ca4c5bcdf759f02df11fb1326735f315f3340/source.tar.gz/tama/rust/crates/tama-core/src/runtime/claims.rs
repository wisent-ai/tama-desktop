//! Which runtime claims which event, and whether it really installs a hook
//! for it.
//!
//! Moved verbatim out of the single runtime file; the only change is where
//! the adapter reading comes from, which is now the [`super::adapter_config`]
//! sibling.

use std::collections::BTreeMap;

use serde_json::Value;

use super::adapter_config::{commands_match, AdapterCommandIndex};
use super::{js_str, OMP_SELECTIVE_EVENTS, OMP_SELECTIVE_HOOKS};
use super::{CLAUDE_EVENTS, CODEX_EVENTS, EDITOR_EVENTS, OMP_EVENTS};
use crate::registry::Registry;

pub(crate) fn omp_runtime_event(event: &str) -> &str {
    if event == "pre_tool_use:write" {
        "pre_tool_use:edit"
    } else {
        event
    }
}

/// JS `ompAdapterStatus(registry)`: status of the `omp-shared-hooks` adapter,
/// or `None` (JS `null`).
fn omp_adapter_status(registry: Option<&Registry>) -> Option<String> {
    let adapters = registry
        .and_then(|r| r.extra.get("catalog"))
        .and_then(|c| c.get("ompAdapters"))
        .and_then(Value::as_array)?;
    for adapter in adapters {
        if adapter.get("id").and_then(Value::as_str) == Some("omp-shared-hooks") {
            // JS: `adapter?.status || null` — only a non-empty string can
            // equal 'active-selective' downstream, so other truthy values
            // collapse to `None` here.
            return adapter
                .get("status")
                .and_then(Value::as_str)
                .filter(|s| !s.is_empty())
                .map(str::to_string);
        }
    }
    None
}

fn omp_claims_event(registry: Option<&Registry>, event: &str) -> bool {
    if omp_adapter_status(registry).as_deref() == Some("active-selective") {
        OMP_SELECTIVE_EVENTS.contains(&event)
    } else {
        OMP_EVENTS.contains(&event)
    }
}

/// JS `coverageKey(runtime, event, hookId, runtimeEvent = event)`.
pub fn coverage_key(runtime: &str, event: &str, hook_id: &str, runtime_event: &str) -> String {
    if runtime_event == event {
        format!("{runtime}:{event}:{hook_id}")
    } else {
        format!("{runtime}:{event}:via:{runtime_event}:{hook_id}")
    }
}

/// JS `{ runtime, runtimeEvent }` spec.
#[derive(Debug, Clone)]
pub struct RuntimeSpec {
    pub runtime: String,
    pub runtime_event: Option<String>,
}

/// JS `runtimeActuallyInstallsHook(adapterCommands, spec, hook, registry)`.
/// `hook_command` maps to `hook.command` (`None` = JS `undefined`).
pub fn runtime_actually_installs_hook(
    adapter_commands: &BTreeMap<String, AdapterCommandIndex>,
    spec: &RuntimeSpec,
    hook_id: &str,
    hook_command: Option<&str>,
    registry: Option<&Registry>,
) -> bool {
    if spec.runtime == "omp" && omp_adapter_status(registry).as_deref() == Some("active-selective")
    {
        return OMP_SELECTIVE_HOOKS.contains(&hook_id);
    }
    if spec.runtime != "codex" && spec.runtime != "claude" {
        return true;
    }
    let commands: &[String] = adapter_commands
        .get(&spec.runtime)
        .and_then(|by_event| {
            spec.runtime_event
                .as_ref()
                .and_then(|event| by_event.get(event))
        })
        .map(Vec::as_slice)
        .unwrap_or(&[]);
    let registry_command = hook_command.unwrap_or("");
    commands
        .iter()
        .any(|command| commands_match(command, registry_command, hook_id))
}

/// JS `requiredEditorRuntimeSpecs(registry)`.
fn required_editor_runtime_specs(registry: Option<&Registry>) -> Vec<RuntimeSpec> {
    let adapters = registry
        .and_then(|r| r.extra.get("catalog"))
        .and_then(|c| c.get("editorAdapters"))
        .and_then(Value::as_array);
    match adapters {
        None => [
            "editor-save-guard",
            "editor-watch-session",
            "editor-watch-launchd",
        ]
        .iter()
        .map(|name| RuntimeSpec {
            runtime: name.to_string(),
            runtime_event: None,
        })
        .collect(),
        Some(list) => list
            .iter()
            .filter(|adapter| adapter.get("requiredLiveCoverage") != Some(&Value::Bool(false)))
            .filter(|adapter| js_str(adapter.get("status")).starts_with("active"))
            .map(|adapter| RuntimeSpec {
                runtime: js_str(adapter.get("id")),
                runtime_event: None,
            })
            .collect(),
    }
}

/// JS `runtimeRequiredLiveCoverage(registry, runtime)`.
pub(crate) fn runtime_required_live_coverage(registry: Option<&Registry>, runtime: &str) -> bool {
    registry
        .and_then(|r| r.adapters.get(runtime))
        .and_then(|adapter| adapter.extra.get("requiredLiveCoverage"))
        != Some(&Value::Bool(false))
}

/// JS `runtimeSupportsLiveCoverageEvent(registry, runtime, event)`.
fn runtime_supports_live_coverage_event(
    registry: Option<&Registry>,
    runtime: &str,
    event: &str,
) -> bool {
    let unsupported = registry
        .and_then(|r| r.adapters.get(runtime))
        .and_then(|adapter| adapter.extra.get("unsupportedLiveCoverageEvents"))
        .and_then(Value::as_array);
    match unsupported {
        Some(list) => !list.iter().any(|value| value.as_str() == Some(event)),
        None => true,
    }
}

/// JS `claimedRuntimeSpecsForEvent(event, registry)`.
pub fn claimed_runtime_specs_for_event(
    event: &str,
    registry: Option<&Registry>,
) -> Vec<RuntimeSpec> {
    let mut specs: Vec<RuntimeSpec> = Vec::new();
    if omp_claims_event(registry, event) {
        specs.push(RuntimeSpec {
            runtime: "omp".to_string(),
            runtime_event: Some(omp_runtime_event(event).to_string()),
        });
    }
    if CODEX_EVENTS.contains(&event)
        && runtime_required_live_coverage(registry, "codex")
        && runtime_supports_live_coverage_event(registry, "codex", event)
    {
        specs.push(RuntimeSpec {
            runtime: "codex".to_string(),
            runtime_event: Some(event.to_string()),
        });
    }
    if CLAUDE_EVENTS.contains(&event)
        && runtime_required_live_coverage(registry, "claude")
        && runtime_supports_live_coverage_event(registry, "claude", event)
    {
        specs.push(RuntimeSpec {
            runtime: "claude".to_string(),
            runtime_event: Some(event.to_string()),
        });
    }
    if EDITOR_EVENTS.contains(&event) {
        for spec in required_editor_runtime_specs(registry) {
            specs.push(RuntimeSpec {
                runtime: spec.runtime,
                runtime_event: Some(event.to_string()),
            });
        }
    }
    specs
}
