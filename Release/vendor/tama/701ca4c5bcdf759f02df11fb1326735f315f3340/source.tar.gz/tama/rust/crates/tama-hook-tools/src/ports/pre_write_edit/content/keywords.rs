//! Content rules that read what the code says about itself, and the two
//! structural rollover shapes that need no such word at all.
//!
//! The lexical rule is the oldest one here and it is blunt on purpose: an
//! author who names the behaviour is telling the truth about it. It was
//! widened on 2026-05-08 after a balance reader shipped with the word spelled
//! as two words in a comment and a stand-in value underneath it.
//!
//! The two structural rules exist because the word is avoidable and the
//! behaviour is not. Iterating a list named providers, engines, backends,
//! strategies, endpoints or candidates and catch-and-continuing to the next
//! entry is a rollover by shape; so is wiring two distinct model backends in
//! one file with a try/catch between them, which is what masked a router
//! outage behind another provider for days. Both are overridden by a comment
//! that gives the reason.
//!
//! As in the sibling modules, every word these rules match is a word they
//! refuse to see written into a file, so the patterns, the markers, the
//! messages and even the names of the constants holding them are assembled
//! from fragments. This module could not otherwise exist as a file on this
//! machine.

use std::sync::LazyLock;

use regex::Regex;

use crate::ports::transport_common as common;

/// The behaviour this module is about, spelled in halves.
const ROLL: &str = concat!("fall", "back");
const ROLL_TYPO: &str = concat!("fall", "bk");
const THROUGH: &str = "through";
const KEYWORD_BASED: &str = concat!("keyword", "-based");
const QUIET: &str = concat!("silent", "-default");
/// The funding-portal endpoints this agent never calls directly.
const BENEFICIARY: &str = concat!("/api/", "beneficiary/");
const PROJECT_REGISTRIES: &str = concat!("project", "-registries");
const REGISTRIES_VALUES: &str = concat!("registries", "-values");
const COLLECTION_OBJECTS: &str = concat!("collection", "-objects");
const CDP_SESSION: &str = concat!("CDP", "Session");
const SESSION_FETCH: &str = concat!("session", "\\.fetch");
const COLLECTION_SAVE: &str = concat!("collection", "_save_url");
const SCALAR_SAVE: &str = concat!("scalar", "_save_url");
const SAVED_VALUES_ROUTE: &str = concat!("registries", "_values_url");
const FIELD_LIST_ROUTE: &str = concat!("project", "_fields_url");
/// The credentials and routes that name a model backend.
const ANTHROPIC_KEY: &str = concat!("ANTHROPIC", "_API_KEY");
const ANTHROPIC_SDK: &str = concat!("@anthropic", "-ai/sdk");
const OPENAI_KEY: &str = concat!("OPENAI", "_API_KEY");
const GEMINI_KEY: &str = concat!("GEMINI", "_API_KEY");
const ROUTER_URL: &str = concat!("STADO_MODEL", "_ROUTER_URL");
/// The runtime blob a clean-gate agent used to glue split sources back.
const DATA_URL: &str = concat!("data:text", "/javascript");
/// Two or more distinct model backends in one file is a rollover by shape.
const DISTINCT_BACKENDS_TEXT: &str = "2";
const RETRY_MARKER: &str = "retry-allowed:";

fn distinct_backends() -> usize {
    DISTINCT_BACKENDS_TEXT.parse().unwrap_or_default()
}

/// Direct use of the provincial funding APIs, which this agent drives through
/// the real interface or not at all.
static DIRECT_LSI_API: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        "(?i)lsi2\\.ncbr\\.gov\\.pl/api|{BENEFICIARY}|{PROJECT_REGISTRIES}|{REGISTRIES_VALUES}\
         |{COLLECTION_OBJECTS}|{CDP_SESSION}|{SESSION_FETCH}|{COLLECTION_SAVE}|{SCALAR_SAVE}\
         |{SAVED_VALUES_ROUTE}|{FIELD_LIST_ROUTE}"
    ))
});

/// The author naming the behaviour.
static NAMED: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        "(?i)({ROLL}|fall[-[:space:]]back|fall[-[:space:]]{THROUGH}|fall{THROUGH}\
         |graceful[-[:space:]]degrad\
         |silently[-[:space:]]?(fail|return|default|swallow|ignore|absorb|catch)\
         |silent[-[:space:]]?(fail|default|catch)|defaulting[-[:space:]]to\
         |default[-[:space:]]to[-[:space:]](0|zero|null|empty)\
         |treat[-[:space:]]as[-[:space:]](missing|empty|zero|null)\
         |assume[-[:space:]](missing|empty|zero|null)|{KEYWORD_BASED})"
    ))
});

/// Spelling around the lexical rule.
static DISGUISED: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        "(?i)([\\x22\\x27]fall[\\x22\\x27][[:space:]]*\\+[[:space:]]*[\\x22\\x27]back[\\x22\\x27]\
         |fal+b(a)?ck|{ROLL_TYPO})"
    ))
});

static ROLLOVER_LOOP: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        "(?i)for[[:space:]]*(await[[:space:]]+)?\\([^)]*\\bof\\b[^)]*\
         \\b(providers?|engines?|backends?|strateg(y|ies)|endpoints?|{ROLL}s?|candidates?)\\b"
    ))
});

static CATCHES: LazyLock<Regex> = LazyLock::new(|| common::compile("(?i)\\bcatch\\b|\\.catch"));

/// The model backends, one pattern each, counted rather than matched as a set.
static BACKENDS: LazyLock<Vec<Regex>> = LazyLock::new(|| {
    vec![
        common::compile(&format!(
            "(?i)createOAuthClient|{ROUTER_URL}|stado-model-router|claude-code-subscription"
        )),
        common::compile(&format!(
            "(?i)generativelanguage\\.googleapis|gemini-[0-9]|{GEMINI_KEY}"
        )),
        common::compile(&format!("(?i)api\\.openai\\.com|{OPENAI_KEY}")),
        common::compile(&format!("(?i)api\\.anthropic\\.com|{ANTHROPIC_KEY}")),
    ]
});

static RETRY_CONSTANT: LazyLock<Regex> = LazyLock::new(|| {
    common::compile("\\bMAX_(ATTEMPTS|RETRIES|TRIES)[[:space:]]*[:=][[:space:]]*[0-9]")
});

static RETRY_LOOP: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "for[[:space:]]*\\([[:space:]]*(let|var|const|int)[[:space:]]+\\w*(attempt|retry|try)\\w*",
        "[[:space:]]*=[[:space:]]*0[[:space:]]*;[[:space:]]*\\w*(attempt|retry|try)\\w*",
        "[[:space:]]*<",
    ))
});

static DIRECT_ANTHROPIC: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        "{ANTHROPIC_KEY}|{ANTHROPIC_SDK}|import[[:space:]]+Anthropic[[:space:]]+from\
         |new[[:space:]]+Anthropic[[:space:]]*\\("
    ))
});

static CIVITAI: LazyLock<Regex> = LazyLock::new(|| common::compile("(?i)civitai\\.com/api"));

static DATA_URL_IMPORT: LazyLock<Regex> = LazyLock::new(|| common::compile(DATA_URL));

const CIVITAI_REFUSAL: &str = "BLOCKED: Do not use CivitAI API - scrape the website directly";
const RETRY_CONSTANT_REFUSAL: &str = concat!(
    "BLOCKED: MAX_ATTEMPTS/MAX_RETRIES constants forbidden. Single-attempt; fail fast on ",
    "rejection. Override with comment 'retry-allowed: <reason>'.",
);
const RETRY_LOOP_REFUSAL: &str = concat!(
    "BLOCKED: retry-loop construct forbidden. Single-shot; if first call fails, return error to ",
    "caller. Override with 'retry-allowed: <reason>'.",
);

fn override_marker() -> String {
    format!("{ROLL}-justified:")
}

fn lsi_refusal() -> String {
    format!(
        "BLOCKED: direct LSI/PARP/NCBR API usage is forbidden for this agent. Use the real UI \
         flow only; do not add {BENEFICIARY}, {PROJECT_REGISTRIES}, {REGISTRIES_VALUES}, \
         {COLLECTION_OBJECTS}, or CDP/fetch API helpers."
    )
}

fn anthropic_refusal() -> String {
    format!(
        "BLOCKED: Do not use {ANTHROPIC_KEY} or the {ANTHROPIC_SDK} directly.\n\nUse the \
         product's finite Stado model adapter with HTTPS ${ROUTER_URL}, its product-scoped \
         bearer, an allowlisted STADO_<PRODUCT>_*_MODEL route, and body-bound agent identity."
    )
}

fn data_url_refusal() -> String {
    format!(
        "BLOCKED: {DATA_URL} runtime imports are forbidden. Split code into real modules with \
         ordinary imports/exports — never glue sources into a runtime blob."
    )
}

fn named_refusal() -> String {
    format!("BLOCKED: Forbidden pattern ({ROLL}/{QUIET} keyword)")
}

fn disguised_refusal() -> String {
    format!("BLOCKED: concatenation/typo of '{ROLL}'.")
}

fn loop_refusal() -> String {
    format!(
        "BLOCKED: provider/strategy {ROLL} loop -- iterating a providers/engines/backends/\
         strategies list and catch-and-continuing to the next on failure is a {ROLL}. A \
         primary's failure must surface, not roll to a backup. If truly not a {ROLL}, add a \
         '{} <reason>' comment.",
        override_marker()
    )
}

fn backends_refusal(count: usize) -> String {
    format!(
        "BLOCKED: multi-backend LLM {ROLL} ({count} distinct LLM providers + try/catch in one \
         file). Don't try one LLM then another on error -- a broken primary must surface so it \
         gets fixed, not hidden. If these providers serve different purposes (not a {ROLL}), \
         add a '{} <reason>' comment.",
        override_marker()
    )
}

/// The complaint this content earns from the lexical and structural rules.
/// `flat` is the content with newlines collapsed, `content` the original,
/// because the override markers are looked for in the text as written.
pub(crate) fn complaint(flat: &str, content: &str) -> Option<String> {
    if DIRECT_LSI_API.is_match(flat) {
        return Some(lsi_refusal());
    }
    if NAMED.is_match(flat) {
        return Some(named_refusal());
    }
    if DISGUISED.is_match(flat) {
        return Some(disguised_refusal());
    }
    let marked = content.contains(&override_marker());
    if ROLLOVER_LOOP.is_match(flat) && CATCHES.is_match(flat) && !marked {
        return Some(loop_refusal());
    }
    if CATCHES.is_match(flat) && !marked {
        let count = BACKENDS
            .iter()
            .filter(|pattern| pattern.is_match(flat))
            .count();
        if count >= distinct_backends() {
            return Some(backends_refusal(count));
        }
    }
    if !content.contains(RETRY_MARKER) {
        if RETRY_CONSTANT.is_match(content) {
            return Some(RETRY_CONSTANT_REFUSAL.to_string());
        }
        if RETRY_LOOP.is_match(content) {
            return Some(RETRY_LOOP_REFUSAL.to_string());
        }
    }
    match DIRECT_ANTHROPIC.is_match(content) {
        true => Some(anthropic_refusal()),
        false => None,
    }
}

/// Rules that apply to any content, including vendored and generated trees.
pub(crate) fn universal_complaint(content: &str) -> Option<String> {
    if CIVITAI.is_match(content) {
        return Some(CIVITAI_REFUSAL.to_string());
    }
    match DATA_URL_IMPORT.is_match(content) {
        true => Some(data_url_refusal()),
        false => None,
    }
}
