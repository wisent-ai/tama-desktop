//! Writing a drafted rule into the registry both gates read.
//!
//! The Python this replaces spliced a shell `if grep …; then exit 2; fi`
//! block into a protected script, or appended a line to whichever project
//! instruction file was nearest. Neither is done here. A rule is a row, and
//! the row says who added it, when, from which session, and what the
//! operator had said.

use serde_json::{json, Value};

use crate::ports::python_stdlib::expanduser;
use crate::util::iso_now;

const RULES_KEY: &str = "rules";
const ID_KEY: &str = "id";
const LOG_PATH: &str = "~/.shared-hooks/auto_rules.log";
/// The three subjects a drafted rule may read, matching the registry.
pub(crate) const TARGETS: &[&str] = &["command", "path", "content"];

/// A stable id from the summary: lowercase words joined by hyphens.
fn identifier(summary: &str) -> String {
    let words: Vec<String> = summary
        .split_whitespace()
        .map(|word| {
            word.chars()
                .filter(|c| c.is_ascii_alphanumeric())
                .collect::<String>()
                .to_lowercase()
        })
        .filter(|word| !word.is_empty())
        .take("6".parse().unwrap_or_default())
        .collect();
    match words.is_empty() {
        true => "drafted-rule".to_string(),
        false => words.join("-"),
    }
}

/// Whether this pattern is one the gates can actually run.
pub(crate) fn pattern_compiles(pattern: &str) -> bool {
    !pattern.is_empty() && regex::Regex::new(pattern).is_ok()
}

/// Append the rule, and say what happened for the log.
pub(crate) fn append(
    registry: &str,
    target: &str,
    pattern: &str,
    message: &str,
    summary: &str,
    quote: &str,
) -> Result<String, String> {
    if !TARGETS.contains(&target) {
        return Err(format!("unsupported target {target}"));
    }
    if !pattern_compiles(pattern) {
        return Err(format!("pattern does not compile: {pattern}"));
    }
    if message.trim().is_empty() {
        return Err("a rule with no refusal message teaches nothing".to_string());
    }
    let mut doc: Value = std::fs::read_to_string(registry)
        .ok()
        .and_then(|text| serde_json::from_str(&text).ok())
        .filter(Value::is_object)
        .unwrap_or_else(|| json!({ RULES_KEY: [] }));
    let id = identifier(summary);
    let row = json!({
        ID_KEY: id,
        "added": iso_now(),
        "target": target,
        "pattern": pattern,
        "message": message,
        "why": summary,
        "user_said": quote,
    });
    let rows = doc
        .as_object_mut()
        .ok_or_else(|| "the registry is not an object".to_string())?
        .entry(RULES_KEY.to_string())
        .or_insert_with(|| json!([]));
    let list = rows
        .as_array_mut()
        .ok_or_else(|| "the registry's rules are not a list".to_string())?;
    if list
        .iter()
        .any(|existing| existing.get(ID_KEY) == Some(&json!(id)))
    {
        return Err(format!("a rule with id {id} is already recorded"));
    }
    list.push(row);
    if let Some(parent) = std::path::Path::new(registry).parent() {
        let _ = std::fs::create_dir_all(parent);
    }
    std::fs::write(registry, format!("{doc:#}"))
        .map_err(|error| format!("cannot write the rule registry: {error}"))?;
    Ok(format!("RECORDED id={id} target={target}"))
}

/// A one-line log entry, appended to the same log the shell used.
pub(crate) fn log(line: &str) {
    let path = expanduser(LOG_PATH);
    if let Some(parent) = std::path::Path::new(&path).parent() {
        let _ = std::fs::create_dir_all(parent);
    }
    let Ok(mut file) = std::fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(&path)
    else {
        return;
    };
    use std::io::Write;
    let _ = writeln!(file, "{} | {line}", iso_now());
}

#[cfg(test)]
mod tests {
    use super::{append, identifier, pattern_compiles, TARGETS};
    use std::path::PathBuf;

    fn registry(name: &str) -> PathBuf {
        let dir = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../target/tmp")
            .join(format!("tama-record-{name}"));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).expect("a folder for the fixture");
        dir.join("auto_rules.json")
    }

    #[test]
    fn a_rule_is_appended_as_a_row_with_its_reason() {
        let path = registry("append");
        let outcome = append(
            &path.to_string_lossy(),
            "command",
            "\\bnode[[:space:]]+-e\\b",
            "BLOCKED: no throwaway node programs.",
            "The operator objected to ad-hoc node scripts",
            "nie pisz jednorazowych skryptow",
        )
        .expect("the row is recorded");
        assert!(outcome.contains("RECORDED"), "{outcome}");
        let text = std::fs::read_to_string(&path).expect("the registry");
        assert!(text.contains("\"target\": \"command\""), "{text}");
        assert!(text.contains("nie pisz jednorazowych skryptow"), "{text}");
        let _ = std::fs::remove_dir_all(path.parent().expect("a folder"));
    }

    /// The same rule twice is one rule.
    #[test]
    fn a_repeated_rule_is_refused() {
        let path = registry("repeat");
        let arguments = (
            "path",
            "/src/.*\\.png$",
            "BLOCKED: screenshots belong in recordings/.",
            "Screenshots kept landing in src",
            "nie wrzucaj zrzutow do src",
        );
        assert!(append(
            &path.to_string_lossy(),
            arguments.0,
            arguments.1,
            arguments.2,
            arguments.3,
            arguments.4
        )
        .is_ok());
        assert!(append(
            &path.to_string_lossy(),
            arguments.0,
            arguments.1,
            arguments.2,
            arguments.3,
            arguments.4
        )
        .is_err());
        let _ = std::fs::remove_dir_all(path.parent().expect("a folder"));
    }

    /// A pattern no engine can compile would make every later call refuse
    /// nothing, silently.
    #[test]
    fn an_uncompilable_pattern_is_refused() {
        let path = registry("bad-pattern");
        assert!(append(
            &path.to_string_lossy(),
            "command",
            "([unclosed",
            "BLOCKED: x",
            "summary",
            "quote"
        )
        .is_err());
        assert!(!pattern_compiles("([unclosed"));
        assert!(pattern_compiles("\\bnode\\b"));
        let _ = std::fs::remove_dir_all(path.parent().expect("a folder"));
    }

    #[test]
    fn an_unknown_target_is_refused_and_the_three_are_named() {
        let path = registry("target");
        assert!(append(
            &path.to_string_lossy(),
            "pre_bash.sh",
            "\\bnode\\b",
            "BLOCKED: x",
            "summary",
            "quote"
        )
        .is_err());
        assert_eq!(TARGETS.len(), 3);
        let _ = std::fs::remove_dir_all(path.parent().expect("a folder"));
    }

    #[test]
    fn the_identifier_is_readable_and_bounded() {
        assert_eq!(
            identifier("The operator objected to ad-hoc node scripts again"),
            "the-operator-objected-to-adhoc-node"
        );
        assert_eq!(identifier("   "), "drafted-rule");
    }
}
