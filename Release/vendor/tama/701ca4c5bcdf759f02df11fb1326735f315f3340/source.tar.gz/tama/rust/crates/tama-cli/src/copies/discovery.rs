//! Inventory and classify repository copies; inspection and removal are separate.

use std::collections::{BTreeMap, BTreeSet};
use std::path::Path;

use serde::Serialize;
use tama_violations::repo_discovery::{
    discover_checkouts_at_root_reporting, discover_every_checkout_deep_reporting,
    UnreadableDirectory,
};
use tama_violations::resolve_path;

use super::state;
use super::CommandError;
use crate::gitcmd::canonical;

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub(crate) struct Copy {
    pub path: String,
    pub owner: Option<String>,
    pub origin: Option<String>,
    pub bytes: u64,
    /// Unknown observations serialize as null, never as a clean checkout.
    pub dirty: Option<bool>,
    pub unpublished: Option<bool>,
    pub history_retained_by: Option<String>,
    pub inspection_error: Option<String>,
    pub owns_worktrees: bool,
    #[serde(default)]
    pub named: bool,
}

/// Canonical siblings of the same origin are never chosen for deletion.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub(crate) struct Twin {
    pub path: String,
    pub twin: String,
    pub origin: String,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub(crate) struct ListDocument {
    pub schema_version: u32,
    pub roots: Vec<String>,
    pub copies: Vec<Copy>,
    pub copy_count: usize,
    pub bytes: u64,
    pub linked_worktrees: Vec<String>,
    pub twins: Vec<Twin>,
    /// Paths Git cannot identify as repositories; never silently omitted.
    pub unreadable: Vec<String>,
    pub unreadable_directories: Vec<UnreadableDirectory>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub(crate) struct Refusal {
    pub path: String,
    pub reason: &'static str,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub(crate) struct RemoveDocument {
    pub schema_version: u32,
    pub roots: Vec<String>,
    pub copies: Vec<Copy>,
    pub copy_count: usize,
    pub bytes: u64,
    pub linked_worktrees: Vec<String>,
    pub twins: Vec<Twin>,
    pub unreadable: Vec<String>,
    pub unreadable_directories: Vec<UnreadableDirectory>,
    pub excepted: Vec<String>,
    pub applied: bool,
    pub removed: Vec<String>,
    pub refused: Vec<Refusal>,
}

/// A root and its direct repository children are canonical, never copies.
fn is_canonical(path: &Path, root: &Path) -> bool {
    let real = canonical(path);
    let root = canonical(root);
    real == root || real.parent() == Some(root.as_path())
}

fn owner_of(candidate_origin: &str, canonicals: &[(String, String)]) -> Option<String> {
    let normalized = state::normalize_origin(candidate_origin);
    if let Some((_, path)) = canonicals
        .iter()
        .find(|(origin, _)| state::normalize_origin(origin) == normalized)
    {
        return Some(path.clone());
    }
    let local = state::local_origin_path(candidate_origin)?;
    let real = canonical(Path::new(&local));
    canonicals
        .iter()
        .find(|(_, path)| canonical(Path::new(path)) == real)
        .map(|(_, path)| path.clone())
}

pub(crate) fn list_document(
    roots: &[String],
    only: &[String],
) -> Result<ListDocument, CommandError> {
    if roots.is_empty() {
        return Err(CommandError::MissingRoot);
    }
    let resolved_roots: Vec<String> = roots
        .iter()
        .map(|root| {
            resolve_path(&[Path::new(root)])
                .to_string_lossy()
                .into_owned()
        })
        .collect();
    let mut copies = Vec::new();
    let mut linked_worktrees = Vec::new();
    let mut twins = Vec::new();
    let mut unreadable = Vec::new();
    let mut unreadable_directories = Vec::new();
    let mut checkouts = BTreeSet::new();
    for root in &resolved_roots {
        let walked = if only.is_empty() {
            discover_every_checkout_deep_reporting(Path::new(root))
        } else {
            discover_checkouts_at_root_reporting(Path::new(root))
        };
        unreadable_directories.extend(walked.unreadable);
        checkouts.extend(walked.checkouts);
    }
    if !only.is_empty() {
        let bounds: BTreeSet<_> = resolved_roots
            .iter()
            .map(|root| canonical(Path::new(root)))
            .collect();
        let selected: BTreeSet<_> = only.iter().map(|path| canonical(Path::new(path))).collect();
        for path in &selected {
            if !bounds.iter().any(|root| path.starts_with(root))
                || bounds.contains(path)
                || path.parent().is_some_and(|parent| bounds.contains(parent))
                || path
                    .ancestors()
                    .skip(1)
                    .any(|parent| selected.contains(parent))
            {
                continue;
            }
            let walked = discover_every_checkout_deep_reporting(path);
            unreadable_directories.extend(walked.unreadable);
            checkouts.extend(walked.checkouts);
        }
    }
    let mut canonicals = Vec::new();
    let mut candidates = Vec::new();
    for checkout in checkouts {
        let path = Path::new(&checkout);
        if crate::gitcmd::verify_repository(path).is_err() {
            unreadable.push(checkout);
            continue;
        }
        if state::is_linked_worktree(path) {
            linked_worktrees.push(checkout);
            continue;
        }
        linked_worktrees.extend(state::linked_worktrees(path));
        if resolved_roots
            .iter()
            .any(|root| is_canonical(path, Path::new(root)))
        {
            if let Some(origin) = state::origin(path) {
                canonicals.push((origin, checkout));
            }
        } else {
            candidates.push(checkout);
        }
    }
    // All roots contribute before ownership is resolved.
    for candidate in candidates {
        let origin = state::origin(Path::new(&candidate));
        let owner = origin.as_deref().and_then(|url| owner_of(url, &canonicals));
        copies.push(super::inspection::inspect(
            candidate,
            origin,
            owner,
            &canonicals,
        ));
    }
    let mut by_origin: BTreeMap<String, Vec<String>> = BTreeMap::new();
    for (origin, path) in canonicals {
        by_origin
            .entry(state::normalize_origin(&origin))
            .or_default()
            .push(path);
    }
    for (origin, mut paths) in by_origin {
        if paths.len() < 2 {
            continue;
        }
        paths.sort();
        let first = paths[0].clone();
        for path in paths.into_iter().skip(1) {
            twins.push(Twin {
                path,
                twin: first.clone(),
                origin: origin.clone(),
            });
        }
    }
    copies.sort_by(|left, right| left.path.cmp(&right.path));
    linked_worktrees.sort();
    linked_worktrees.dedup();
    twins.sort_by(|left, right| left.path.cmp(&right.path));
    unreadable.sort();
    unreadable_directories.sort_by(|left, right| left.path.cmp(&right.path));
    unreadable_directories.dedup();
    Ok(ListDocument {
        schema_version: 1,
        roots: resolved_roots,
        copy_count: copies.len(),
        bytes: copies.iter().map(|copy| copy.bytes).sum(),
        copies,
        linked_worktrees,
        twins,
        unreadable,
        unreadable_directories,
    })
}
