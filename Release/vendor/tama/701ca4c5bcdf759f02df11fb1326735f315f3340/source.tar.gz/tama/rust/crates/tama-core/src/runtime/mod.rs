//! Port of `src/core/runtime/live-runtime-coverage.mjs` and
//! `src/core/runtime/coverage-analysis.mjs`.
//!
//! Fidelity notes:
//! - `registry.catalog` (ompAdapters / editorAdapters / gitHooks) and adapter
//!   extras (requiredLiveCoverage, unsupportedLiveCoverageEvents,
//!   acknowledgedUninstalledHooks) are accessed leniently through
//!   `serde_json::Value`, mirroring the JS optional-chaining style.
//! - Sort keys and `localeCompare` calls use byte-lexicographic ordering,
//!   identical for the ASCII strings involved here.
//! - JS template interpolation of missing values (`undefined` / `null`) is
//!   reproduced by [`js_str`] where it is observable.
//!
//! One file grew past the limit, so the four subjects are four modules now:
//! what a provider adapter config says ([`adapter_config`]), which runtime
//! claims which event ([`claims`]), the two coverage readings
//! ([`coverage`]), and the install-drift report ([`drift`]). Every name this
//! module published before is re-exported here, so `crate::runtime::…` paths
//! are unchanged.

pub mod adapter_config;
pub mod claims;
pub mod coverage;
pub mod drift;

pub use adapter_config::{
    adapter_command_index, expand_home_path, AdapterCommandIndex, AdapterConfigProblem,
    AdapterHookEntry,
};
pub use claims::{
    claimed_runtime_specs_for_event, coverage_key, runtime_actually_installs_hook, RuntimeSpec,
};
pub use coverage::{
    build_required_coverage, declared_provider_coverage, summarize_coverage, CoverageSummary,
    GitCoverage, ProviderCoverage, ProviderCoverageMapping, RequiredCoverage, RuntimeCoverage,
};
pub use drift::{detect_runtime_install_drift, DriftEntry};

use serde_json::Value;
use std::fs;
use std::path::Path;

use crate::registry::Registry;
use crate::Result;

pub const OMP_EVENTS: &[&str] = &[
    "stop",
    "user_prompt_submit",
    "post_tool_use:bash",
    "session_start:compact",
    "pre_tool_use:bash",
    "pre_tool_use:read",
    "pre_tool_use:edit",
    "pre_tool_use:write",
    "pre_tool_use:eval",
    "pre_tool_use:ssh",
    "pre_tool_use:task",
    "pre_tool_use:todo",
    "pre_tool_use:goal",
    "pre_tool_use:lookup",
];

pub(crate) const OMP_SELECTIVE_EVENTS: &[&str] = &[
    "user_prompt_submit",
    "pre_tool_use:bash",
    "pre_tool_use:edit",
    "pre_tool_use:write",
    "pre_tool_use:read",
    "pre_tool_use:multiedit",
    "pre_tool_use:task",
    "pre_tool_use:eval",
    "pre_tool_use:ssh",
    "pre_tool_use:todo",
    "pre_tool_use:goal",
    "pre_tool_use:lookup",
];

pub(crate) const OMP_SELECTIVE_HOOKS: &[&str] = &[
    "block-device-level-tests-without-consent",
    "block-unapproved-audits",
];

pub const CODEX_EVENTS: &[&str] = &[
    "stop",
    "user_prompt_submit",
    "post_tool_use:bash",
    "session_start:compact",
    "pre_tool_use:bash",
    "pre_tool_use:read",
    "pre_tool_use:edit",
    "pre_tool_use:write",
    "pre_tool_use:task",
    "pre_tool_use:todo",
    "pre_tool_use:goal",
    "pre_tool_use:lookup",
    "pre_tool_use:notebook",
    "pre_tool_use:wait",
    "pre_tool_use:eval",
    "pre_tool_use:ssh",
];

/// `new Set([...CODEX_EVENTS, 'pre_tool_use:multiedit'])`.
pub const CLAUDE_EVENTS: &[&str] = &[
    "stop",
    "user_prompt_submit",
    "post_tool_use:bash",
    "session_start:compact",
    "pre_tool_use:bash",
    "pre_tool_use:read",
    "pre_tool_use:edit",
    "pre_tool_use:write",
    "pre_tool_use:task",
    "pre_tool_use:todo",
    "pre_tool_use:goal",
    "pre_tool_use:lookup",
    "pre_tool_use:notebook",
    "pre_tool_use:wait",
    "pre_tool_use:eval",
    "pre_tool_use:ssh",
    "pre_tool_use:multiedit",
];

pub const EDITOR_EVENTS: &[&str] = &["pre_tool_use:edit", "pre_tool_use:notebook"];

/// JS runtime `loadRegistry(root)`: unlike the catalog variant this throws
/// (here: returns `Err`) when `shared-hooks/registry.json` is missing.
pub fn load_registry(root: &Path) -> Result<Registry> {
    let path = root.join("shared-hooks").join("registry.json");
    Ok(serde_json::from_str(&fs::read_to_string(path)?)?)
}

// ---------------------------------------------------------------------------
// helpers shared by the modules above
// ---------------------------------------------------------------------------

/// JS template-literal interpolation of a JSON value: missing key ->
/// "undefined", null -> "null", strings verbatim, booleans/numbers via their
/// plain string form. An array or object becomes its JSON text (JS would
/// produce e.g. "[object Object]"; not expected in this data).
pub(crate) fn js_str(value: Option<&Value>) -> String {
    match value {
        None => "undefined".to_string(),
        Some(Value::Null) => "null".to_string(),
        Some(Value::String(s)) => s.clone(),
        Some(Value::Bool(b)) => b.to_string(),
        Some(Value::Number(n)) => n.to_string(),
        Some(other) => other.to_string(),
    }
}

/// JS truthiness of a JSON value.
pub(crate) fn js_truthy(value: Option<&Value>) -> bool {
    match value {
        None | Some(Value::Null) => false,
        Some(Value::Bool(b)) => *b,
        Some(Value::String(s)) => !s.is_empty(),
        Some(Value::Number(n)) => n.as_f64().map(|f| f != 0.0).unwrap_or(true),
        Some(_) => true,
    }
}
