//! A here-document body is input to a program, not a command.
//!
//! `cat >> notes.md <<'END' … END` hands its body to `cat`. The body is not
//! quoted in the shell sense, so blanking quoted runs leaves it standing, and
//! a gate reading the payload as commands reads the prose as commands. On
//! 2026-09-16 that refused a declaration being written into a repository's
//! violations-ignore file, because the sentence explaining which upstream
//! engine the patch series belongs to named that engine.
//!
//! The exception is the same one the quoting reader makes: a shell handed a
//! here-document runs it, so `bash <<'END' … END` keeps its body as a command
//! of its own.

/// One character, for index arithmetic.
const ONE: usize = 1;

/// Programs that run a here-document instead of reading it.
const EXECUTORS: &[&str] = &[
    "bash",
    "sh",
    "zsh",
    "dash",
    "ksh",
    "fish",
    "csh",
    "tcsh",
    "busybox",
    "python",
    "python3",
    "node",
    "ruby",
    "perl",
    "osascript",
];

/// What a payload's here-documents amount to: the text with each body
/// removed, and the bodies an interpreter would execute kept separately.
pub struct Split {
    /// The payload with every data body removed.
    pub without_bodies: String,
    /// Bodies handed to an interpreter, each a command text of its own.
    pub executed: Vec<String>,
}

/// The delimiter word a `<<` redirection opens, and whether the line's
/// program executes what it receives.
fn delimiter(line: &str) -> Option<(String, bool)> {
    let at = line.find("<<")?;
    let rest = line[at + ONE + ONE..].trim_start();
    let rest = rest.strip_prefix('-').unwrap_or(rest).trim_start();
    let quoted = rest.trim_start_matches(['\'', '"']);
    let word: String = quoted
        .chars()
        .take_while(|c| c.is_alphanumeric() || *c == '_' || *c == '-')
        .collect();
    if word.is_empty() {
        return None;
    }
    let program = line[..at]
        .split_whitespace()
        .next()
        .map(|token| token.rsplit('/').next().unwrap_or(token))
        .unwrap_or_default();
    Some((word, EXECUTORS.contains(&program)))
}

/// Split a payload into the part outside here-documents and the bodies an
/// interpreter would run.
pub fn split(command: &str) -> Split {
    if !command.contains("<<") {
        return Split {
            without_bodies: command.to_string(),
            executed: Vec::new(),
        };
    }
    let mut kept: Vec<&str> = Vec::new();
    let mut executed: Vec<String> = Vec::new();
    let mut open: Option<(String, bool)> = None;
    let mut body: Vec<&str> = Vec::new();
    for line in command.lines() {
        if let Some((word, runs)) = open.clone() {
            if line.trim() == word {
                if runs {
                    executed.push(body.join("\n"));
                }
                body.clear();
                open = None;
                continue;
            }
            body.push(line);
            continue;
        }
        kept.push(line);
        open = delimiter(line);
    }
    // An unterminated body is still a body: it ends with the payload.
    if let Some((_, true)) = open {
        executed.push(body.join("\n"));
    }
    Split {
        without_bodies: kept.join("\n"),
        executed,
    }
}

#[cfg(test)]
mod tests {
    use super::split;

    /// The declaration this gate refused on 2026-09-16.
    #[test]
    fn a_body_written_into_a_file_is_not_a_command() {
        let payload = concat!(
            "cat >> .tama/violations-ignore <<'DECLARE'\n",
            "# Each file is the output of git format-patch against upstream\n",
            "# Chromium and is read back by git am.\n",
            "patches\n",
            "DECLARE\n",
            "tama-cli find-violations --repo ."
        );

        let result = split(payload);

        assert!(!result.without_bodies.contains("Chromium"));
        assert!(result.without_bodies.contains("find-violations"));
        assert!(result.executed.is_empty());
    }

    /// A shell handed a here-document runs it.
    #[test]
    fn a_body_handed_to_a_shell_is_a_command() {
        let payload = "bash <<'END'\nchromium --headless\nEND\n";

        let result = split(payload);

        assert_eq!(result.executed, vec!["chromium --headless".to_string()]);
        assert!(!result.without_bodies.contains("chromium"));
    }

    #[test]
    fn a_payload_without_a_here_document_is_unchanged() {
        let result = split("git status");

        assert_eq!(result.without_bodies, "git status");
        assert!(result.executed.is_empty());
    }

    /// An unterminated interpreter body is still code.
    #[test]
    fn an_unterminated_body_is_not_lost() {
        let result = split("python3 <<EOF\nimport os\n");

        assert_eq!(result.executed, vec!["import os".to_string()]);
    }

    #[test]
    fn the_indented_form_is_recognised() {
        let result = split("cat <<-END\n\tdata line\n\tEND\nls");

        assert!(!result.without_bodies.contains("data line"));
        assert!(result.without_bodies.contains("ls"));
    }
}
