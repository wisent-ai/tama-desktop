//! The same ban, read off a tool payload instead of a shell command.
//!
//! Jeden exposes worktrees as a first-class tool rather than a shell command,
//! so the shell scan in [`super`] cannot see it.
//! `jeden/rust/tool_services/github.rs` runs `git worktree <action>` through
//! its own process helper, and `jeden/rust/hooks/tama.rs` turns an unknown
//! Tama tool name into the matcher `^<name>$`, so registering this guard on
//! `pre_tool_use:git_worktree` reaches it — but only if the payload is read on
//! its own terms: it carries `action` and `path`, never `command`.

use serde_json::Value;

use super::{ADD, TOOL_INPUT_KEY, WORKTREE_REASON};

/// The tool this module answers for.
const WORKTREE_TOOL: &str = "git_worktree";

/// The refusal a native tool call earns. `list`, `prune` and `remove` are how
/// a machine is cleaned up and stay allowed; only creation is refused.
pub(super) fn refusal(payload: &Value) -> Option<String> {
    let tool = payload
        .get("tool_name")
        .or_else(|| payload.get("tool"))
        .and_then(Value::as_str)?;
    if tool != WORKTREE_TOOL {
        return None;
    }
    let action = payload
        .get(TOOL_INPUT_KEY)
        .and_then(|input| input.get("action"))
        .and_then(Value::as_str)
        .unwrap_or_default();
    (action == ADD).then(|| WORKTREE_REASON.to_string())
}
