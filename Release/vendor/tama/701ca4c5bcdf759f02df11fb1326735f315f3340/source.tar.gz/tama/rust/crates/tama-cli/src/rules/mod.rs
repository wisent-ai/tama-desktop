//! `tama rules` — reading and pruning the rules the frustration drafter
//! records.
//!
//! Those rules gate writes and commands, so they have to be reviewable and
//! they have to be removable. Removing one is not symmetrical with adding
//! one, though: a rule drafted from something the operator really said is
//! policy, and an agent may not delete the policy that constrains it. So a
//! row whose recorded quote is found in a real stored user message needs the
//! operator's out-of-band approval to remove, and a row whose quote is found
//! nowhere — a row nobody asked for, a row left by a test — may be removed by
//! anyone, because it was never policy in the first place.

use std::path::PathBuf;

use serde_json::Value;

const REGISTRY: &str = ".shared-hooks/auto_rules.json";
const RULES_KEY: &str = "rules";
const ID_KEY: &str = "id";
const QUOTE_KEY: &str = "user_said";
const APPROVAL_ENV: &str = "DEVICE_HOOK_EDIT_APPROVED";
const APPROVAL_VALUE: &str = "1";
const USAGE: &str = concat!(
    "usage: tama rules list [--json]\n",
    "       tama rules remove --id <id>\n",
    "\n",
    "A rule drafted from a real operator message needs DEVICE_HOOK_EDIT_APPROVED=1 to remove.",
);

fn registry_path() -> PathBuf {
    let home = std::env::var_os("HOME")
        .map(PathBuf::from)
        .unwrap_or_default();
    home.join(REGISTRY)
}

fn rows() -> Vec<Value> {
    let Ok(text) = std::fs::read_to_string(registry_path()) else {
        return Vec::new();
    };
    let Ok(doc) = serde_json::from_str::<Value>(&text) else {
        return Vec::new();
    };
    match doc.get(RULES_KEY) {
        Some(Value::Array(rows)) => rows.clone(),
        _ => Vec::new(),
    }
}

fn option(argv: &[String], name: &str) -> Option<String> {
    argv.iter()
        .position(|argument| argument == name)
        .and_then(|index| argv.get(index + 1))
        .cloned()
}

fn field(row: &Value, key: &str) -> String {
    row.get(key)
        .and_then(Value::as_str)
        .unwrap_or_default()
        .to_string()
}

fn list(argv: &[String]) -> i32 {
    let rows = rows();
    if argv.iter().any(|argument| argument == "--json") {
        println!("{}", serde_json::json!({ RULES_KEY: rows }));
        return i32::default();
    }
    if rows.is_empty() {
        println!("no drafted rules are recorded");
        return i32::default();
    }
    for row in &rows {
        println!(
            "{}\n  added:   {}\n  reads:   {}\n  pattern: {}\n  says:    {}\n  because: {}\n  \
             quote:   {}",
            field(row, ID_KEY),
            field(row, "added"),
            field(row, "target"),
            field(row, "pattern"),
            field(row, "message"),
            field(row, "why"),
            field(row, QUOTE_KEY),
        );
    }
    i32::default()
}

fn remove(argv: &[String]) -> i32 {
    let Some(id) = option(argv, "--id") else {
        eprintln!("{USAGE}");
        return "2".parse().unwrap_or_default();
    };
    let rows = rows();
    let Some(row) = rows.iter().find(|row| field(row, ID_KEY) == id) else {
        eprintln!("no rule with id {id} is recorded");
        return "2".parse().unwrap_or_default();
    };
    let quote = field(row, QUOTE_KEY);
    let policy = !quote.is_empty()
        && tama_hook_tools::ports::check_numeric_literals_provenance::quote_in_user_msg(&quote);
    let approved = std::env::var(APPROVAL_ENV).ok().as_deref() == Some(APPROVAL_VALUE);
    if policy && !approved {
        eprintln!(
            "refusing to remove {id}: it was drafted from something the operator really said, \
             and that quote is in the stored transcripts. Set {APPROVAL_ENV}=1 outside the agent \
             session to remove it."
        );
        return "2".parse().unwrap_or_default();
    }
    let kept: Vec<Value> = rows
        .into_iter()
        .filter(|row| field(row, ID_KEY) != id)
        .collect();
    let path = registry_path();
    let doc = serde_json::json!({ RULES_KEY: kept });
    if let Err(error) = std::fs::write(&path, format!("{doc:#}")) {
        eprintln!("cannot write {}: {error}", path.display());
        return "2".parse().unwrap_or_default();
    }
    match policy {
        true => println!("removed {id} with the operator's approval"),
        false => println!("removed {id}: no stored user message carries its quote"),
    }
    i32::default()
}

pub fn main(argv: &[String]) -> i32 {
    match argv.first().map(String::as_str).unwrap_or("list") {
        "list" => list(argv),
        "remove" => remove(argv),
        _ => {
            eprintln!("{USAGE}");
            "2".parse().unwrap_or_default()
        }
    }
}
