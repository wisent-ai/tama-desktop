use std::collections::HashSet;
use std::fs;
use std::path::PathBuf;
use std::time::{SystemTime, UNIX_EPOCH};

use serde_json::json;
use tama_hooks::enforcement::{
    hook_enforces, read_enforcement_selection_at, selection_enforces_hook,
    write_enforcement_selection_at, EnforcementMode, EnforcementSelection,
};
use tama_hooks::session_control::{SessionContext, SESSION_CONTROL_SCHEMA};

fn scratch(name: &str) -> PathBuf {
    let nonce = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .expect("clock after epoch")
        .as_nanos();
    std::env::temp_dir().join(format!(
        "tama-enforcement-{name}-{}-{nonce}",
        std::process::id()
    ))
}

#[test]
fn durable_selection_and_resolution_contract() {
    let root = scratch("contract");
    fs::create_dir_all(&root).expect("create scratch root");
    let state_path = root.join("hook-enforcement.json");

    let missing = read_enforcement_selection_at(&state_path);
    assert_eq!(missing.selection.mode, EnforcementMode::All);
    assert!(missing.selection.enabled.is_empty());
    assert_eq!(missing.error, None);

    fs::write(&state_path, "{not json\n").expect("write malformed state");
    let malformed = read_enforcement_selection_at(&state_path);
    assert_eq!(malformed.selection, EnforcementSelection::all());
    assert!(malformed.error.as_deref().is_some_and(|error| {
        error.contains("invalid") && error.contains("hook-enforcement.json")
    }));

    let only = write_enforcement_selection_at(
        &state_path,
        EnforcementMode::Only,
        &["beta".to_string(), "alpha".to_string()],
    )
    .expect("write only selection");
    assert_eq!(only.enabled, vec!["alpha", "beta"]);
    assert_eq!(only.previous.mode, EnforcementMode::All);
    assert!(only.previous.enabled.is_empty());
    assert_eq!(read_enforcement_selection_at(&state_path).selection, only);

    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        assert_eq!(
            fs::metadata(&state_path).unwrap().permissions().mode() & 0o777,
            0o600
        );
    }

    let session_beta = vec!["beta".to_string()];
    assert!(selection_enforces_hook(&only, false, "alpha", &[]));
    assert!(selection_enforces_hook(&only, false, "beta", &session_beta));
    assert!(!selection_enforces_hook(&only, false, "gamma", &[]));
    assert!(!selection_enforces_hook(&only, true, "alpha", &[]));
    assert!(selection_enforces_hook(&only, true, "beta", &session_beta));

    let all = write_enforcement_selection_at(&state_path, EnforcementMode::All, &[])
        .expect("write all selection");
    assert_eq!(all.mode, EnforcementMode::All);
    assert_eq!(all.previous.mode, EnforcementMode::Only);
    assert_eq!(all.previous.enabled, vec!["alpha", "beta"]);
    assert!(selection_enforces_hook(&all, false, "gamma", &[]));

    let control_root = root.join("session-control");
    fs::create_dir_all(&control_root).expect("create session control root");
    let emergency_path = root.join("emergency.json");
    std::env::set_var("TAMA_SESSION_CONTROL_ROOT", &control_root);
    std::env::set_var("TAMA_EMERGENCY_STATE", &emergency_path);
    let context = SessionContext {
        agent_id: "omp".to_string(),
        session_id: "session-1".to_string(),
        control_key: "control-key".to_string(),
        cwd: root.display().to_string(),
    };
    fs::write(
        control_root.join("control-key.override.json"),
        serde_json::to_string(&json!({
            "schema": SESSION_CONTROL_SCHEMA,
            "agentId": "omp",
            "sessionId": "session-1",
            "controlKey": "control-key",
            "enabledHookIds": ["beta"],
            "disabledHookIds": ["alpha"]
        }))
        .unwrap(),
    )
    .expect("write session override");
    let known: HashSet<String> = ["alpha", "beta", "gamma"]
        .into_iter()
        .map(str::to_string)
        .collect();

    assert!(hook_enforces(&only, "alpha", Some(&context), Some(&known)));
    assert!(hook_enforces(&only, "beta", Some(&context), Some(&known)));
    assert!(!hook_enforces(&only, "gamma", Some(&context), Some(&known)));

    fs::write(
        &emergency_path,
        r#"{"schema":"ai.wisent.tama.hook-emergency-state.v1","disabled":true}"#,
    )
    .expect("write emergency state");
    assert!(!hook_enforces(&only, "alpha", Some(&context), Some(&known)));
    assert!(hook_enforces(&only, "beta", Some(&context), Some(&known)));

    std::env::remove_var("TAMA_SESSION_CONTROL_ROOT");
    std::env::remove_var("TAMA_EMERGENCY_STATE");
    fs::remove_dir_all(root).expect("remove scratch root");
}
