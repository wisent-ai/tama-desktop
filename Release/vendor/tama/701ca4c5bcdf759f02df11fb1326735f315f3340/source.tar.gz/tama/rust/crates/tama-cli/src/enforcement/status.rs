//! What the machine's hook selection is, and how it is reported.
//!
//! The selection itself is durable state owned by `tama-hooks`; this module
//! reads it, counts it against the installed catalogue, and prints it for the
//! command, the session summary and the HTTP route alike.

use std::collections::BTreeSet;
use std::path::Path;

use serde::Serialize;
use tama_core::catalog::load_registry;
use tama_hooks::enforcement::{
    enforcement_state_path_for_home, read_enforcement_selection, read_enforcement_selection_at,
    EnforcementMode, EnforcementRead, EnforcementSelection,
};
use tama_hooks::session_control::{hooks_globally_disabled, hooks_globally_disabled_at};

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub(crate) struct EnforcementStatus {
    pub mode: String,
    pub enabled: Vec<String>,
    pub selected_hook_count: usize,
    pub installed_hook_count: usize,
    pub emergency_disabled: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub read_error: Option<String>,
}

pub(crate) fn installed_hook_ids(root: &Path) -> Result<Vec<String>, String> {
    let registry = load_registry(root).map_err(|error| error.to_string())?;
    let catalog = registry
        .extra
        .get("catalog")
        .and_then(serde_json::Value::as_object);
    let mut ids = BTreeSet::new();
    for key in ["agentHooks", "gitHooks"] {
        for hook in catalog
            .and_then(|value| value.get(key))
            .and_then(serde_json::Value::as_array)
            .into_iter()
            .flatten()
        {
            if let Some(id) = hook.get("id").and_then(serde_json::Value::as_str) {
                if !id.is_empty() {
                    ids.insert(id.to_string());
                }
            }
        }
    }
    Ok(ids.into_iter().collect())
}

fn build_status(
    read: EnforcementRead,
    installed: &[String],
    emergency_disabled: bool,
) -> EnforcementStatus {
    let selected_hook_count = match read.selection.mode {
        EnforcementMode::All => installed.len(),
        EnforcementMode::Only => read
            .selection
            .enabled
            .iter()
            .filter(|id| installed.binary_search(id).is_ok())
            .count(),
    };
    EnforcementStatus {
        mode: read.selection.mode.as_str().to_string(),
        enabled: read.selection.enabled,
        selected_hook_count,
        installed_hook_count: installed.len(),
        emergency_disabled,
        read_error: read.error,
    }
}

pub(crate) fn status(root: &Path) -> Result<EnforcementStatus, String> {
    let installed = installed_hook_ids(root)?;
    Ok(build_status(
        read_enforcement_selection(),
        &installed,
        hooks_globally_disabled(),
    ))
}

pub(crate) fn status_for_home(root: &Path, home: &Path) -> Result<EnforcementStatus, String> {
    let installed = installed_hook_ids(root)?;
    let state_path = enforcement_state_path_for_home(home);
    let emergency_path = state_path.with_file_name("hook-emergency-state.json");
    Ok(build_status(
        read_enforcement_selection_at(&state_path),
        &installed,
        hooks_globally_disabled_at(&emergency_path),
    ))
}

pub(crate) fn status_after_write(
    selection: EnforcementSelection,
    installed: &[String],
) -> EnforcementStatus {
    build_status(
        EnforcementRead {
            selection,
            error: None,
        },
        installed,
        hooks_globally_disabled(),
    )
}

pub(crate) fn print_status(status: &EnforcementStatus) {
    println!("mode: {}", status.mode);
    println!(
        "selected hooks: {}/{} installed",
        status.selected_hook_count, status.installed_hook_count
    );
    if status.mode == "all" {
        println!("selected ids: all installed hooks");
    } else {
        println!("selected ids: {}", status.enabled.join(", "));
    }
    println!("emergency disabled: {}", status.emergency_disabled);
}

pub(crate) fn session_summary(status: &EnforcementStatus) -> String {
    let ids = if status.mode == "all" {
        "all installed hooks".to_string()
    } else {
        status.enabled.join(", ")
    };
    format!(
        "machine enforcement\tmode={}\tselected={}/{}\tids={}\temergency-disabled={}",
        status.mode,
        status.selected_hook_count,
        status.installed_hook_count,
        ids,
        status.emergency_disabled
    )
}

pub(crate) fn report_read_error(status: &EnforcementStatus) {
    if let Some(error) = &status.read_error {
        eprintln!(
            "Tama could not read the machine enforcement selection: {error}. Falling back to all hooks."
        );
    }
}
