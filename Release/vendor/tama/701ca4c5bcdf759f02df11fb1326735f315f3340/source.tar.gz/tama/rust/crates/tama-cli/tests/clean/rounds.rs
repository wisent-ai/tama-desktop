//! What a repair round does when it cannot repair anything.
//!
//! These drive the real `tama` binary against real scratch repositories with
//! `clean`'s real code path. They exist because the previous round spawned a
//! provider CLI that was either absent or refused its own arguments, and the
//! loop reported the same violation count round after round while claiming
//! nothing was wrong. Each case below is one refusal a round must state.

use std::fs;
use std::path::{Path, PathBuf};
use std::process::{Command, Output};
use std::time::{SystemTime, UNIX_EPOCH};

use serde_json::Value;

const HOOK: &str = "shared-hooks/block_oversized_files.sh";

fn count(text: &str) -> usize {
    text.parse().expect("valid count")
}

struct Scratch {
    path: PathBuf,
}

impl Scratch {
    fn new(label: &str) -> Self {
        let unique = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock before epoch")
            .as_nanos();
        let evidence = tama_root().join(".wisent-output/clean-refusals");
        fs::create_dir_all(&evidence).expect("create retained evidence root");
        let path = evidence.join(format!(
            "tama-clean-{label}-{}-{unique}",
            std::process::id()
        ));
        fs::create_dir_all(&path).expect("create scratch root");
        Self { path }
    }

    /// A repository whose only file breaks the file-length rule.
    fn repo_with_violation(&self, git: bool) -> PathBuf {
        let repo = self.path.join("repo");
        fs::create_dir_all(&repo).expect("create repo");
        let long: String = (false as usize..count("320"))
            .map(|row| format!("export const line{row} = true;\n"))
            .collect();
        fs::write(repo.join("long.js"), long).expect("write long module");
        if git {
            run_git(&repo, &["init", "--quiet"]);
            run_git(&repo, &["config", "user.email", "probe@wisent.com"]);
            run_git(&repo, &["config", "user.name", "probe"]);
            run_git(&repo, &["add", "-A"]);
            run_git(&repo, &["commit", "--quiet", "-m", "probe"]);
        }
        repo
    }

    /// The same repository with a second file that breaks a content rule
    /// rather than a size rule, so a scoped run has something to leave
    /// alone.
    fn with_content_violation(&self, repo: &Path) {
        fs::write(
            repo.join("settings.js"),
            "export const settings = { port: 8080, retries: 5 };\n",
        )
        .expect("write settings module");
        run_git(repo, &["add", "-A"]);
        run_git(repo, &["commit", "--quiet", "-m", "settings"]);
    }
}

impl Drop for Scratch {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.path);
    }
}

fn run_git(repo: &Path, args: &[&str]) {
    let status = Command::new("git")
        .args(args)
        .current_dir(repo)
        .status()
        .expect("run git");
    assert!(status.success(), "git {args:?} failed in {repo:?}");
}

fn tama_root() -> PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR"))
        .ancestors()
        .nth(count("3"))
        .expect("tama root above rust/crates/tama-cli")
        .to_path_buf()
}

/// The real CLI, with the gateway pointed at an address nothing serves so no
/// test can reach a provider, and Skarbiec pointed at the same dead port.
fn clean(repo: &Path, extra: &[&str]) -> Output {
    let root = tama_root();
    let hook = root.join(HOOK);
    let mut args = vec![
        "clean".to_string(),
        "--repo".to_string(),
        repo.to_string_lossy().into_owned(),
        "--hook".to_string(),
        hook.to_string_lossy().into_owned(),
        "--json".to_string(),
    ];
    args.extend(extra.iter().map(|arg| arg.to_string()));
    Command::new(env!("CARGO_BIN_EXE_tama-cli"))
        .args(&args)
        .env("TAMA_ROOT", &root)
        .env("TAMA_CLEAN_STATE_DIR", repo.join("..").join("state"))
        .env("BRAMA_URL", "https://127.0.0.1:1/v1/chat/completions")
        .env(
            "TAMA_OBJECTIVE_AUTHORITY_SKARBIEC_URL",
            "http://127.0.0.1:1",
        )
        .env_remove("TAMA_CLEAN_AGENT_CMD")
        .env_remove("TAMA_CLEAN_DISABLED")
        .output()
        .expect("run tama clean")
}

fn first_result(output: &Output) -> Value {
    let document: Value = serde_json::from_slice(&output.stdout)
        .unwrap_or_else(|error| panic!("clean did not emit JSON ({error}): {output:?}"));
    document
        .pointer("/results/0")
        .cloned()
        .unwrap_or_else(|| panic!("clean emitted no result: {document}"))
}

#[test]
fn a_round_that_cannot_reach_brama_stops_after_one_round() {
    let scratch = Scratch::new("unreachable");
    let repo = scratch.repo_with_violation(true);
    let output = clean(&repo, &["--max-rounds", "3"]);
    let result = first_result(&output);
    let rounds = result
        .get("rounds")
        .and_then(Value::as_array)
        .expect("rounds recorded");
    assert_eq!(
        rounds.len(),
        count("1"),
        "a refusal must end the run, not repeat for every allowed round: {result}"
    );
    let rejected = rounds[false as usize]
        .get("rejected")
        .and_then(Value::as_str)
        .expect("the round records why it repaired nothing");
    assert!(
        rejected.contains("Skarbiec") || rejected.contains("Brama"),
        "the reason must name the step that failed, got {rejected}"
    );
    assert_eq!(result.get("clean").and_then(Value::as_bool), Some(false));
    assert_eq!(
        result.get("after").and_then(Value::as_u64),
        Some(count("1") as u64),
        "the violation is still there, so the count must say so"
    );
    assert!(!output.status.success(), "an unrepaired repository exits 1");
}

#[test]
fn a_round_refuses_a_target_that_is_not_a_git_repository() {
    let scratch = Scratch::new("nogit");
    let repo = scratch.repo_with_violation(false);
    let output = clean(&repo, &[]);
    let result = first_result(&output);
    let rejected = result
        .pointer("/rounds/0/rejected")
        .and_then(Value::as_str)
        .expect("the round records its refusal");
    assert!(
        rejected.contains("Git repository"),
        "a patch needs a repository to apply to, got {rejected}"
    );
}

/// The brief a dry run prints, without `--json`, so stdout is the brief.
fn brief(repo: &Path, extra: &[&str]) -> String {
    let root = tama_root();
    // The write guard itself, so the unscoped brief carries content rules
    // as well as the size rules its companion owns.
    let hook = root.join("shared-hooks/pre_write_edit.sh");
    let mut args = vec![
        "clean".to_string(),
        "--repo".to_string(),
        repo.to_string_lossy().into_owned(),
        "--hook".to_string(),
        hook.to_string_lossy().into_owned(),
        "--dry-run".to_string(),
    ];
    args.extend(extra.iter().map(|arg| arg.to_string()));
    let output = Command::new(env!("CARGO_BIN_EXE_tama-cli"))
        .args(&args)
        .env("TAMA_ROOT", &root)
        .env("TAMA_CLEAN_STATE_DIR", repo.join("..").join("state"))
        .env_remove("TAMA_CLEAN_AGENT_CMD")
        .env_remove("TAMA_CLEAN_DISABLED")
        .output()
        .expect("run tama clean --dry-run");
    String::from_utf8_lossy(&output.stdout).into_owned()
}

/// A sweep over a workshop repairs the two size rules and touches nothing
/// else: the content rules are judgement about what a line says, and a
/// round told to fix everything at once rewrites code nobody asked about.
#[test]
fn a_size_scoped_round_is_given_only_the_size_violations() {
    let scratch = Scratch::new("rulescope");
    let repo = scratch.repo_with_violation(true);
    scratch.with_content_violation(&repo);

    let everything = brief(&repo, &[]);
    assert!(everything.contains("long.js"), "{everything}");
    assert!(everything.contains("settings.js"), "{everything}");

    let sized = brief(&repo, &["--rule", "size"]);
    assert!(sized.contains("long.js"), "{sized}");
    assert!(
        !sized.contains("settings.js"),
        "a size-scoped round must not be handed a content violation: {sized}"
    );
    assert!(
        sized.contains("Rules in scope for this round"),
        "the brief must say which rules the round may act on: {sized}"
    );
}
