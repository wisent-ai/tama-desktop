//! Logic for `tama-pre-bash`, registry hook `pre-bash`: the consolidated gate
//! every shell command passes.
//!
//! Four families, in the order the shell asked them: the product boundaries
//! (`boundaries`), the guards on the hooks and the history (`guards`), the
//! throwaway programs and files (`inline`), and the trajectory run counter
//! (`trajectory`). Last comes the constants gate, which reads the command for
//! a remote write that would inject a number nobody measured.
//!
//! The incident rules the drafter pipeline used to splice into the bottom of
//! the script are data now, in `pre_write_edit::auto_rules`, with `command`
//! as a target: the chromium ban, the ad-hoc node ban, the cookie-store ban
//! and the mac-mini ssh rule were folded into `inline` and `boundaries`
//! because they are the same question those files already ask, and anything
//! added from here on is a row in the registry rather than an edit to a
//! protected file.

mod boundaries;
mod guards;
mod inline;
mod trajectory;

use std::path::PathBuf;

use serde_json::Value;
use tama_hooks::session_record::{deny_tool_use, read_payload};

use crate::ports::auto_rules;
use crate::ports::check_unsubstantiated_constants;
use crate::ports::pyvalue::first_truthy_py_str;

const INPUT_KEY: &str = "tool_input";
const COMMAND_KEYS: &[&str] = &["command", "cmd"];
const WORKDIR_KEYS: &[&str] = &["workdir", "cwd"];
const TRANSCRIPT_KEY: &str = "transcript_path";
const CONSTANTS_HEAD: &str = "BLOCKED: unsubstantiated constant injection detected:";
const CONSTANTS_TAIL: &str = concat!(
    "Add a justification marker '# justify: <reason>' to the command, or move the constant to a ",
    "tracked config/constants file.",
);

/// The command, its working directory and the session transcript, read the
/// way the shell read them: from the tool input first, then the payload.
fn fields(payload: &Value) -> (String, String, String) {
    let empty = Value::Object(Default::default());
    let input = payload.get(INPUT_KEY).unwrap_or(&empty);
    let command = match first_truthy_py_str(input, COMMAND_KEYS) {
        found if !found.is_empty() => found,
        _ => first_truthy_py_str(payload, COMMAND_KEYS),
    };
    let workdir = match first_truthy_py_str(input, WORKDIR_KEYS) {
        found if !found.is_empty() => found,
        _ => first_truthy_py_str(payload, WORKDIR_KEYS),
    };
    let transcript = first_truthy_py_str(payload, &[TRANSCRIPT_KEY]);
    (command, workdir, transcript)
}

fn constants_refusal(command: &str) -> Option<String> {
    let found = check_unsubstantiated_constants::bash_violations(command);
    if found.is_empty() {
        return None;
    }
    let listed = found
        .iter()
        .map(|item| format!("  - {item}"))
        .collect::<Vec<_>>()
        .join("\n");
    Some(format!("{CONSTANTS_HEAD}\n{listed}\n{CONSTANTS_TAIL}"))
}

/// The refusal this command earns, if any. The trajectory counter is skipped
/// here and run by `check`, because counting is a side effect and a caller
/// that only wants an answer should not raise a counter.
pub fn refusal_without_counting(command: &str, workdir: &str) -> Option<String> {
    if command.is_empty() {
        return None;
    }
    boundaries::refusal(command, workdir)
        .or_else(|| guards::refusal(command))
        .or_else(|| inline::refusal(command))
        .or_else(|| auto_rules::command_refusal(command))
        .or_else(|| constants_refusal(command))
}

/// The refusal this payload earns, counting the run if it is a trajectory.
pub fn check(payload: &Value) -> Option<String> {
    let (command, workdir, transcript) = fields(payload);
    if command.is_empty() {
        return None;
    }
    if let Some(found) = refusal_without_counting(&command, &workdir) {
        return Some(found);
    }
    let repo = match workdir.is_empty() {
        false => PathBuf::from(&workdir),
        true => std::env::current_dir().unwrap_or_else(|_| PathBuf::from(".")),
    };
    trajectory::refusal(&repo, &command, &transcript)
}

pub fn run() {
    if let Some(refusal) = check(&read_payload()) {
        deny_tool_use(&refusal);
    }
}

#[cfg(test)]
mod tests {
    use super::{fields, refusal_without_counting};
    use serde_json::json;

    fn bash(command: &str) -> serde_json::Value {
        json!({ "tool_name": "bash", "tool_input": { "command": command } })
    }

    /// The families are asked in order, so a command that offends twice earns
    /// the boundary refusal first.
    #[test]
    fn the_boundaries_are_asked_before_the_throwaway_rules() {
        let found = refusal_without_counting("supabase db push; bash -c 'ls'", "")
            .expect("both a boundary and an inline program");
        assert!(found.contains("Supabase CLI is forbidden"), "{found}");
    }

    #[test]
    fn an_empty_command_is_not_judged() {
        assert_eq!(refusal_without_counting("", ""), None);
        assert_eq!(fields(&json!({})).0, "");
    }

    /// The command, the working directory and the transcript are read from
    /// the payload the way the shell read them.
    #[test]
    fn the_fields_come_from_the_tool_input_then_the_payload() {
        let payload = json!({
            "tool_input": { "cmd": "git status", "workdir": "/repo" },
            "transcript_path": "/transcripts/s.jsonl"
        });
        let (command, workdir, transcript) = fields(&payload);
        assert_eq!(command, "git status");
        assert_eq!(workdir, "/repo");
        assert_eq!(transcript, "/transcripts/s.jsonl");
        let (command, _, _) = fields(&bash("ls"));
        assert_eq!(command, "ls");
    }

    /// A remote write that would put a number on a host without passing a
    /// local gate is refused with its marker named.
    #[test]
    fn a_remote_constant_injection_is_refused() {
        let command = "ssh host \"cp local.py /usr/lib/python3/site-packages/worker.py\"";
        let found = refusal_without_counting(command, "").expect("a remote write");
        assert!(found.contains("justify:"), "{found}");
    }

    #[test]
    fn an_ordinary_command_passes() {
        assert_eq!(refusal_without_counting("cargo build --release", ""), None);
    }
}
