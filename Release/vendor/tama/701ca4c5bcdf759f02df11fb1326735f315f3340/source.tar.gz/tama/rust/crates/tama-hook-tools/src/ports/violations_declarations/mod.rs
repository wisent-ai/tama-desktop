//! What a repository has declared to the audit, read by the write guards.
//!
//! `tama find-violations` lets a repository declare, with a reason written
//! beside it, that a path's shape is not a module-discipline question: a
//! registry a loader reads whole, a folder of generated output, a published
//! package's import surface, or a repository root whose files are fixed by
//! pip, npm, git and GitHub.
//!
//! Until this module the declaration was read by the scanner alone, so every
//! declared folder stayed unwritable and every declared oversized file stayed
//! uneditable: cntrlai's root is eleven files by npm's, Poetry's and GitHub's
//! demands, it is declared for exactly that reason, and adding the
//! `.gitignore` that root was missing was still refused with "Folder already
//! has 12 files (max 5)". A declaration the guards do not read is not a
//! decision, it is a note.
//!
//! One reader, used by both the guards and the scanner, so the two cannot
//! drift: one path per line, `#` comments ignored.
//!
//! The spelling decides how much is declared, and the difference matters.
//! `assets` exempts that folder's own file count and nothing else, so the
//! files inside it are still read by every other rule. `assets/` exempts
//! everything below it as well, which is what a folder of data or generated
//! output wants and what a folder of modules does not. `.` is the repository
//! root's own file count, the only way to declare a root whose files are
//! fixed by pip, npm, git and GitHub.

use std::path::{Path, PathBuf};

/// The two names a declaration file has had. The folded form came second in
/// history but is the one to write: a root nearly always holds five files
/// already, so a repository could not add a root-level declaration at all.
const DECLARATION_PATHS: &[&str] = &[".tama/violations-ignore", ".tama-violations-ignore"];

/// One repository's declarations, and the root they are relative to.
pub struct Declarations {
    root: PathBuf,
    entries: Vec<String>,
}

impl Declarations {
    /// The declarations governing `path`, found by walking up from it.
    ///
    /// The walk stops at the repository the path belongs to: a checkout that
    /// declared nothing does not inherit the declarations of a checkout it
    /// happens to sit inside. `None` is the common case and costs one read
    /// attempt per level.
    pub fn nearest(path: &Path) -> Option<Self> {
        let start = match path.is_dir() {
            true => path,
            false => path.parent()?,
        };
        for ancestor in start.ancestors() {
            let entries = read_entries(ancestor);
            if !entries.is_empty() {
                return Some(Self {
                    root: ancestor.to_path_buf(),
                    entries,
                });
            }
            if ancestor.join(".git").exists() {
                return None;
            }
        }
        None
    }

    /// Whether this file is declared, itself or through a folder above it.
    pub fn declares_file(&self, path: &Path) -> bool {
        match relative(&self.root, path) {
            Some(rel) => is_declared(&rel, &self.entries),
            None => false,
        }
    }

    /// Whether this folder's own file count is declared.
    ///
    /// A crowded folder's path is a directory, so `assets/`, `assets` and -
    /// for the repository root - `.` all have to answer yes, which is what
    /// the scanner does when it reports a folder.
    pub fn declares_folder(&self, dir: &Path) -> bool {
        let Some(rel) = relative(&self.root, dir) else {
            return false;
        };
        let named = match rel.is_empty() {
            true => ".".to_string(),
            false => rel,
        };
        let as_directory = format!("{named}/");
        is_declared(&named, &self.entries)
            || self.entries.iter().any(|entry| *entry == as_directory)
    }
}

/// Whether the file at this absolute path is declared by its repository.
pub fn file_is_declared(path: &str) -> bool {
    let path = Path::new(path);
    Declarations::nearest(path).is_some_and(|declarations| declarations.declares_file(path))
}

/// Whether the folder at this absolute path is declared by its repository.
pub fn folder_is_declared(dir: &str) -> bool {
    let dir = Path::new(dir);
    Declarations::nearest(dir).is_some_and(|declarations| declarations.declares_folder(dir))
}

/// Per-repo audit exclusions: one exact relative path per line, directories
/// with a trailing slash, `#` comments. A missing or unreadable file yields
/// no entries.
pub fn read_entries(root: &Path) -> Vec<String> {
    for name in DECLARATION_PATHS {
        let Ok(text) = std::fs::read_to_string(root.join(name)) else {
            continue;
        };
        return parse_entries(&text);
    }
    Vec::new()
}

/// The lines of a declaration file that name a path.
pub fn parse_entries(text: &str) -> Vec<String> {
    text.split('\n')
        .map(|raw| raw.trim())
        .filter(|line| !line.is_empty() && !line.starts_with('#'))
        .map(|line| line.to_string())
        .collect()
}

/// Whether this repository-relative path is named by the entries.
///
/// A directory covers everything below it, with or without the trailing
/// slash its writer may have left off. Requiring the slash is how
/// `applications/feng-sciezka-smart/source` — a declaration that reads
/// exactly right, sits in the file the documentation names, and was written
/// for the published grant sources underneath it — excluded nothing at all,
/// silently, while the audit went on ordering somebody to split a document
/// the funding body published.
pub fn is_declared(rel_path: &str, entries: &[String]) -> bool {
    entries.iter().any(|entry| {
        let entry = entry.trim_end_matches('/');
        rel_path == entry || rel_path.starts_with(&format!("{entry}/"))
    })
}

/// `path` relative to `root`, with forward slashes, or `None` when `path` is
/// not below `root`.
fn relative(root: &Path, path: &Path) -> Option<String> {
    let relative = path.strip_prefix(root).ok()?;
    Some(relative.to_string_lossy().replace('\\', "/"))
}

#[cfg(test)]
mod tests;
