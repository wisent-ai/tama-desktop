//! `tama-block-wait-polling`, driven as the real binary with real payloads on
//! stdin and a scratch session-control root.
//!
//! The operator's rule: a ten-second wait repeated is no different from
//! waiting an hour, only louder. A shell call that only sleeps is refused;
//! the third identical look at the same hub subject inside the window is
//! refused; real work, a different subject, and a call outside any session
//! pass.

use std::fs;
use std::io::Write as _;
use std::path::PathBuf;
use std::process::{Command, Output, Stdio};
use std::time::{SystemTime, UNIX_EPOCH};

use serde_json::{json, Value};

const EXIT_PASS: i32 = false as i32;
const EXIT_REFUSED: i32 = true as i32 + true as i32;
const GUARD: &str = env!("CARGO_BIN_EXE_tama-block-wait-polling");
const SESSION: &str = "wait-polling-guard-session";

/// The refusal a sleep-only line earns, verbatim.
const SLEEP_REFUSAL: &str = "BLOCKED: this call only passes time. A wait is not work: the \
    process you are waiting for reports its own exit; do other work until it does, or wait \
    once for that exit (`hub wait` with `for: exit` and a timeout that covers it) instead of \
    sleeping in slices.";

/// A session-control root of this test's own, under the crate's
/// `CARGO_TARGET_TMPDIR`: never the OS temp directory and never the
/// operator's live session-control root.
fn scratch() -> PathBuf {
    let nonce = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .expect("clock after epoch")
        .as_nanos();
    let thread = format!("{:?}", std::thread::current().id()).replace(['(', ')'], "-");
    let path = PathBuf::from(env!("CARGO_TARGET_TMPDIR"))
        .join(format!("tama-wait-polling-{thread}{nonce}"));
    fs::create_dir_all(&path).expect("create scratch root");
    path
}

fn drive(root: &std::path::Path, payload: &Value) -> Output {
    let mut child = Command::new(GUARD)
        .env("TAMA_SESSION_CONTROL_ROOT", root)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .unwrap_or_else(|error| panic!("spawn the guard: {error}"));
    child
        .stdin
        .as_mut()
        .expect("guard stdin")
        .write_all(payload.to_string().as_bytes())
        .expect("write payload");
    child.wait_with_output().expect("guard output")
}

fn bash(command: &str) -> Value {
    json!({ "session_id": SESSION, "tool_name": "Bash", "tool_input": { "command": command } })
}

fn hub_wait(name: &str) -> Value {
    json!({ "session_id": SESSION, "tool_name": "hub",
        "tool_input": { "op": "wait", "name": name, "for": "exit" } })
}

fn code(output: &Output) -> i32 {
    output.status.code().expect("an exit code")
}

fn stderr(output: &Output) -> String {
    String::from_utf8_lossy(&output.stderr)
        .trim_end()
        .to_string()
}

#[test]
fn a_line_that_only_sleeps_is_refused_with_the_sentence() {
    let root = scratch();
    let output = drive(&root, &bash("sleep 9; echo"));
    assert_eq!(code(&output), EXIT_REFUSED, "{}", stderr(&output));
    assert_eq!(stderr(&output), SLEEP_REFUSAL);
}

#[test]
fn a_sleep_beside_real_work_passes() {
    let root = scratch();
    let output = drive(&root, &bash("sleep 2; curl -s -K probe.curl | cut -c1-80"));
    assert_eq!(code(&output), EXIT_PASS, "{}", stderr(&output));
}

#[test]
fn an_echo_alone_passes() {
    let root = scratch();
    let output = drive(&root, &bash("echo ok"));
    assert_eq!(code(&output), EXIT_PASS, "{}", stderr(&output));
}

#[test]
fn the_third_identical_look_inside_the_window_is_refused() {
    let root = scratch();
    let first = drive(&root, &hub_wait("stado-build"));
    assert_eq!(code(&first), EXIT_PASS, "{}", stderr(&first));
    let second = drive(&root, &hub_wait("stado-build"));
    assert_eq!(code(&second), EXIT_PASS, "{}", stderr(&second));
    let third = drive(&root, &hub_wait("stado-build"));
    assert_eq!(code(&third), EXIT_REFUSED, "{}", stderr(&third));
    let refusal = stderr(&third);
    assert!(
        refusal.starts_with("BLOCKED: this is look number 3"),
        "{refusal}"
    );
    assert!(
        refusal.contains("hub:wait name=\"stado-build\""),
        "{refusal}"
    );
}

#[test]
fn a_look_at_a_different_subject_is_not_counted_against_the_first() {
    let root = scratch();
    drive(&root, &hub_wait("stado-build"));
    drive(&root, &hub_wait("stado-build"));
    let other = drive(&root, &hub_wait("brama-build"));
    assert_eq!(code(&other), EXIT_PASS, "{}", stderr(&other));
}

#[test]
fn a_look_outside_any_session_is_never_counted() {
    let root = scratch();
    let payload = json!({ "tool_name": "hub", "tool_input": { "op": "wait", "name": "x" } });
    for _ in [(); 4] {
        let output = drive(&root, &payload);
        assert_eq!(code(&output), EXIT_PASS, "{}", stderr(&output));
    }
}
