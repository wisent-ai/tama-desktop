//! Reading committed evidence out of the transcript lake: the cursor
//! store, the segment outputs it names, and the digest each one has to
//! match.
//!
//! Split out of `doctor/evidence.rs`, which had grown past the
//! three-hundred-line limit.

use std::collections::HashSet;
use std::fs;
use std::path::PathBuf;

use sha2::{Digest, Sha256};

use super::{canonical_evidence, object, Canon};
use crate::util::home_dir;

pub(super) fn read_lake_evidence() -> Result<(Vec<serde_json::Value>, HashSet<String>), String> {
    let lake_root = std::env::var("LAKE_DATA")
        .ok()
        .filter(|v| !v.is_empty())
        .map(PathBuf::from)
        .unwrap_or_else(|| home_dir().join(".transcript-lake"));
    let cursor_path = lake_root.join("cursors.json");
    let cursor_store = if cursor_path.exists() {
        let parsed =
            object(&fs::read_to_string(&cursor_path).map_err(|e| format!("Error: {}", e))?)?;
        if parsed.is_object() {
            Some(parsed)
        } else {
            None
        }
    } else {
        None
    };
    let Some(cursor_store) = cursor_store else {
        return Ok((Vec::new(), HashSet::new()));
    };
    let hooks_dir = lake_root.join("events").join("runtime=hooks");
    let mut rows = Vec::new();
    let mut segment_ids = HashSet::new();
    let entries = cursor_store.as_object().cloned().unwrap_or_default();
    for (key, commit) in entries {
        if !key.starts_with("hooks:") {
            continue;
        }
        if commit.get("kind").and_then(|v| v.as_str()) != Some("closed-segment")
            || commit.get("state").and_then(|v| v.as_str()) != Some("committed")
        {
            continue;
        }
        let segment_id = key["hooks:".len()..].to_string();
        let outputs = commit
            .get("outputs")
            .and_then(|v| v.as_array())
            .cloned()
            .unwrap_or_default();
        if segment_id.is_empty()
            || commit.get("segmentId").and_then(|v| v.as_str()) != Some(segment_id.as_str())
            || outputs.is_empty()
        {
            continue;
        }
        let mut segment_rows = Vec::new();
        let mut seen_paths = HashSet::new();
        let mut valid = true;
        for output in &outputs {
            let path_str = output.get("path").and_then(|v| v.as_str());
            let sha = output.get("sha256").and_then(|v| v.as_str());
            let (Some(path_str), Some(sha)) = (path_str, sha) else {
                valid = false;
                break;
            };
            let file_path = resolve_path(path_str);
            let relative = file_path.strip_prefix(&hooks_dir).unwrap_or(&file_path);
            let parts: Vec<String> = relative
                .components()
                .map(|c| c.as_os_str().to_string_lossy().to_string())
                .collect();
            let expected_name = format!("segment-{}.ndjson", segment_id);
            let date_ok = parts.first().map(|p| is_lake_date(p)).unwrap_or(false);
            if parts.len() != 2
                || !date_ok
                || parts.get(1).map(|p| p.as_str()) != Some(expected_name.as_str())
                || file_path
                    .file_name()
                    .map(|n| n.to_string_lossy().to_string())
                    .as_deref()
                    != Some(expected_name.as_str())
                || seen_paths.contains(&file_path)
            {
                valid = false;
                break;
            }
            seen_paths.insert(file_path.clone());
            let source = fs::read_to_string(&file_path).map_err(|e| format!("Error: {}", e))?;
            if !source.ends_with('\n') || format!("{:x}", Sha256::digest(source.as_bytes())) != sha
            {
                valid = false;
                break;
            }
            for text in source[..source.len() - 1].split('\n') {
                let row = object(text)?;
                match canonical_evidence(&row, &segment_id) {
                    Canon::Invalid => {
                        valid = false;
                        break;
                    }
                    Canon::Skip => {}
                    Canon::Row(evidence) => segment_rows.push(evidence),
                }
            }
            if !valid {
                break;
            }
        }
        if !valid {
            continue;
        }
        segment_ids.insert(segment_id);
        rows.extend(segment_rows);
    }
    Ok((rows, segment_ids))
}

fn resolve_path(path: &str) -> PathBuf {
    let p = PathBuf::from(path);
    if p.is_absolute() {
        p
    } else {
        std::env::current_dir().unwrap_or_default().join(p)
    }
}

/// `^date=[0-9]{4}-[0-9]{2}-[0-9]{2}$`
fn is_lake_date(part: &str) -> bool {
    let Some(date) = part.strip_prefix("date=") else {
        return false;
    };
    let segs: Vec<&str> = date.split('-').collect();
    segs.len() == 3
        && segs[0].len() == 4
        && segs[1].len() == 2
        && segs[2].len() == 2
        && segs
            .iter()
            .all(|s| s.bytes().all(|b| b.is_ascii_digit()) && !s.is_empty())
}
