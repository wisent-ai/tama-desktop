//! `tama serve` — loopback HTTP/JSON backend for the desktop app.
//!
//! The desktop spawns this once (`tama serve --port 0 --root <release>`) and
//! talks to it over 127.0.0.1 HTTP — it never builds argv for the other
//! commands. On bind, exactly one line lands on stdout:
//!
//!   {"ready":true,"port":<number>}
//!
//! After that, stdout carries no protocol traffic; every failure is an HTTP
//! response. All endpoints live under /v1 and reuse the exact functions the
//! CLI commands use (runtime, install, scan_repos, clean) — no parallel
//! implementation.
//!
//! Errors are non-2xx with body {"error": "<one sentence>"} — the product's
//! own refusal sentence, verbatim from the underlying failure.
//!
//! Long-running jobs (violation scan / clean) stream NDJSON:
//!   {"type":"log","stream":"stdout"|"stderr","chunk":"..."}  (zero or more)
//!   {"type":"result","status":<exit-code>,"json":{...}}      (exactly one, last)
//! where `json` is the same document the command prints and `status` mirrors
//! its exit code.

mod builds;
mod copies;
mod http;
mod jobs;
mod justifications;
mod routes;

use std::io::Write;
use std::net::{Ipv4Addr, TcpListener};
use std::path::Path;

use serde_json::json;

use crate::EXIT_USAGE;

pub fn main(args: &[String], root: &Path) -> i32 {
    let mut port: u16 = 0;
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "--port" => {
                let Some(value) = args.get(i + 1) else {
                    eprintln!("missing value for --port");
                    return EXIT_USAGE;
                };
                match value.parse() {
                    Ok(parsed) => port = parsed,
                    Err(_) => {
                        eprintln!("invalid --port: {value}");
                        return EXIT_USAGE;
                    }
                }
                i += 2;
            }
            // `--root` is already resolved by the caller; it stays in argv.
            "--root" => {
                if args.get(i + 1).is_none() {
                    eprintln!("missing value for --root");
                    return EXIT_USAGE;
                }
                i += 2;
            }
            other => {
                eprintln!("unknown serve option: {other}");
                return EXIT_USAGE;
            }
        }
    }
    let listener = match TcpListener::bind((Ipv4Addr::LOCALHOST, port)) {
        Ok(listener) => listener,
        Err(error) => {
            eprintln!("{error}");
            return 1;
        }
    };
    let bound = listener
        .local_addr()
        .map(|address| address.port())
        .unwrap_or(port);
    // The ready line is the only stdout write: after it, stdout is
    // protocol-clean and every failure is an HTTP response or a stderr log.
    println!("{}", json!({ "ready": true, "port": bound }));
    let _ = std::io::stdout().flush();

    for stream in listener.incoming() {
        if let Ok(stream) = stream {
            let root = root.to_path_buf();
            std::thread::spawn(move || http::handle(stream, root));
        }
    }
    0
}
