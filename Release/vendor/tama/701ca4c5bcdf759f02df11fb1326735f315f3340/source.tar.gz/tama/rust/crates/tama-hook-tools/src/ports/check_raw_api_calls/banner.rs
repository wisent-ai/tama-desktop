//! The refusal this guard prints: the hits it lists, the rule it quotes and
//! the ways through it names.
//!
//! Split out of `check_raw_api_calls/mod.rs`, which had grown past the
//! three-hundred-line limit; the scanning stays there.

use super::{max_reported, report_line_chars, Violation, ALLOWLISTED_PATH_FRAGMENTS};
use crate::ports::pystr;
use tama_hooks::session_record::deny_tool_use;

pub(super) fn report(target: &str, violations: &[Violation]) -> ! {
    let target = if target.is_empty() {
        "<bash command>"
    } else {
        target
    };
    let mut banner =
        format!("BLOCKED: raw HTTP call to bot-classified site detected\n  in: {target}\n\n");
    let chars = report_line_chars();
    for hit in violations.iter().take(max_reported()) {
        banner.push_str(&format!("  line {}: {}\n", hit.line_no, hit.reason));
        banner.push_str(&format!("    > {}\n", pystr::head_chars(&hit.line, chars)));
    }
    banner.push_str(RULE_HEAD);
    for fragment in ALLOWLISTED_PATH_FRAGMENTS {
        banner.push_str(&format!("  - {fragment}\n"));
    }
    banner.truncate(banner.len() - "\n".len());
    banner.push_str(RULE_TAIL);
    deny_tool_use(&banner)
}

const RULE_HEAD: &str = concat!(
    "\nRule (CLAUDE.md auto-added 2026-05-09): 'Never use raw Playwright ",
    "APIs in any scrape/harvest/visit script targeting a bot-classified ",
    "site — always use the humanized atoms.' Raw fetch() against ",
    "/api/voyager/graphql endpoints is the same anti-pattern — the ",
    "missing SPA headers (X-Super-Properties, X-Discord-Locale, ",
    "Sec-CH-UA-*) are an immediate bot signal.\n",
    "\nLegitimate paths:\n",
    "  - drive the SPA via WSession + humanized atoms (humanClick/Fill/Type)\n",
    "  - or use s.page.context().request.get/post (routes through the\n",
    "    authenticated browser context's cookie jar + fingerprint)\n",
    "\nAllowlisted directories (these may make raw bot-host calls):\n",
);

/// `deny_tool_use` supplies the newline `print` would have added.
const RULE_TAIL: &str = concat!(
    "\n\nPer-line bypass: append `// allow-raw-api: <reason>` on the same\n",
    "line as the call. No env-var blanket bypass — closed loophole.\n",
);
