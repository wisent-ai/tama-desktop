//! Port of `shared-hooks/hook-exec.mjs`: command tokenization with shell word
//! semantics and the "crash is a malfunction, not a policy decision" detector.

use crate::jsutil::is_js_whitespace;

/// Port of `tokenizeCommand`.
///
/// Quoted and unquoted runs not separated by whitespace belong to the SAME
/// argument, e.g. `node '/path with spaces'/hooks/entry.mjs` tokenizes to
/// `["node", "/path with spaces/hooks/entry.mjs"]`. Backslash escapes any
/// character except inside single quotes, where it is literal.
pub fn tokenize_command(command: &str) -> Vec<String> {
    let mut tokens = Vec::new();
    let mut current = String::new();
    let mut started = false;
    let mut quote: Option<char> = None;
    let mut escaped = false;
    for ch in command.chars() {
        if escaped {
            current.push(ch);
            escaped = false;
            continue;
        }
        if quote != Some('\'') && ch == '\\' {
            escaped = true;
            started = true;
            continue;
        }
        if quote.is_none() && (ch == '"' || ch == '\'') {
            quote = Some(ch);
            started = true;
            continue;
        }
        if quote.is_some() && Some(ch) == quote {
            quote = None;
            continue;
        }
        if quote.is_none() && is_js_whitespace(ch) {
            if started {
                tokens.push(std::mem::take(&mut current));
                started = false;
            }
            continue;
        }
        current.push(ch);
        started = true;
    }
    if started {
        tokens.push(current);
    }
    tokens
}

/// Line-oriented equivalent of `MALFUNCTION_RE` (`/m` flag: `^`/`$` anchor at
/// line boundaries). Returns true if any line matches one of the alternatives.
pub fn looks_like_malfunction_text(text: &str) -> bool {
    text.split('\n').any(is_malfunction_line)
}

/// The marker a hook prints when it could not reach the service it needs.
///
/// The catalogue promises that credential, transport, timeout and HTTP
/// failures are reported as infrastructure failures rather than policy
/// decisions. Nothing implemented that promise: a hook that exited non-zero
/// after printing this marker fell through to "non-zero exit on a blocking
/// event" and its stderr became the refusal. On 2026-09-11
/// `block-objective-substitution` could not authenticate to Brama on this
/// machine, and every tool call an agent made — down to `true` — was refused
/// with that credential error as the reason, including the command that would
/// have taken the hook back out of the selection.
pub const INFRASTRUCTURE_MARKER: &str = "TAMA_HOOK_INFRASTRUCTURE:";

/// A hook saying, in one word, that it did not decide anything.
fn infrastructure_line(line: &str) -> bool {
    line.trim_start_matches(is_js_whitespace)
        .starts_with(INFRASTRUCTURE_MARKER)
}

/// Matches a single line against:
/// ```text
/// ^\s*(?:Traceback \(most recent call last\):|File ".*", line |at [^\s]+ \(.*\)$
///      |(?:ModuleNotFound|Import|Syntax|Indentation|Tab)Error:|node:internal/
///      |[^\s:]*: (?:command not found|No such file or directory)$)
/// ```
/// or the infrastructure marker, which is not a crash but is equally not a
/// verdict, and the runtime has to treat both the same way.
fn is_malfunction_line(line: &str) -> bool {
    if infrastructure_line(line) {
        return true;
    }
    let rest = line.trim_start_matches(is_js_whitespace);

    if rest.starts_with("Traceback (most recent call last):") {
        return true;
    }
    // File ".*", line
    if let Some(after) = rest.strip_prefix("File \"") {
        if after.contains("\", line ") {
            return true;
        }
    }
    // at [^\s]+ \(.*\)$
    if matches_at_frame(rest) {
        return true;
    }
    for prefix in [
        "ModuleNotFoundError:",
        "ImportError:",
        "SyntaxError:",
        "IndentationError:",
        "TabError:",
    ] {
        if rest.starts_with(prefix) {
            return true;
        }
    }
    if rest.starts_with("node:internal/") {
        return true;
    }
    // [^\s:]*: (?:command not found|No such file or directory)$
    if let Some(colon) = rest.find(':') {
        let (head, tail) = (&rest[..colon], &rest[colon..]);
        if !head.chars().any(is_js_whitespace)
            && (tail == ": command not found" || tail == ": No such file or directory")
        {
            return true;
        }
    }
    false
}

/// `at [^\s]+ \(.*\)$` — a stack frame line. `[^\s]+` is greedy but cannot
/// cross whitespace, so the literal ` (` must immediately follow the first
/// whitespace after the non-space run, and the line must end with `)`.
fn matches_at_frame(rest: &str) -> bool {
    let Some(body) = rest.strip_prefix("at ") else {
        return false;
    };
    let mut end = 0;
    for (idx, c) in body.char_indices() {
        if is_js_whitespace(c) {
            break;
        }
        end = idx + c.len_utf8();
    }
    if end == 0 {
        return false;
    }
    let after = &body[end..];
    after.starts_with(" (") && after.ends_with(')')
}

/// Outcome of a spawned hook command, mirroring the shape `looksLikeMalfunction`
/// expects (`{ spawnError, stdout, stderr }`).
#[derive(Debug, Clone, Default)]
pub struct CommandResult {
    pub spawn_error: bool,
    pub stdout: Option<String>,
    pub stderr: Option<String>,
}

impl CommandResult {
    pub fn from_output(output: &std::process::Output) -> Self {
        CommandResult {
            spawn_error: false,
            stdout: Some(String::from_utf8_lossy(&output.stdout).into_owned()),
            stderr: Some(String::from_utf8_lossy(&output.stderr).into_owned()),
        }
    }

    pub fn spawn_error(error: &std::io::Error) -> Self {
        CommandResult {
            spawn_error: true,
            stdout: None,
            stderr: Some(error.to_string()),
        }
    }
}

/// Port of `looksLikeMalfunction`.
pub fn looks_like_malfunction(result: &CommandResult) -> bool {
    if result.spawn_error {
        return true;
    }
    looks_like_malfunction_text(result.stderr.as_deref().unwrap_or(""))
        || looks_like_malfunction_text(result.stdout.as_deref().unwrap_or(""))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn tokenizes_shell_words() {
        assert_eq!(
            tokenize_command("node '/path with spaces'/hooks/entry.mjs"),
            vec!["node", "/path with spaces/hooks/entry.mjs"]
        );
        assert_eq!(tokenize_command("a \"b c\" d"), vec!["a", "b c", "d"]);
        assert_eq!(tokenize_command("a\\ b"), vec!["a b"]);
        // Backslash is literal inside single quotes.
        assert_eq!(tokenize_command("'a\\b'"), vec!["a\\b"]);
        // Empty quotes still produce an argument.
        assert_eq!(tokenize_command("x '' y"), vec!["x", "", "y"]);
        assert_eq!(tokenize_command(""), Vec::<String>::new());
        assert_eq!(tokenize_command("  \t "), Vec::<String>::new());
        // Unterminated quote: rest of the string is one argument.
        assert_eq!(tokenize_command("a 'b c"), vec!["a", "b c"]);
        // U+FEFF counts as whitespace in JS.
        assert_eq!(tokenize_command("a\u{feff}b"), vec!["a", "b"]);
    }

    #[test]
    fn detects_malfunctions() {
        assert!(looks_like_malfunction_text(
            "Traceback (most recent call last):"
        ));
        assert!(looks_like_malfunction_text(
            "  File \"/x/y.py\", line 3, in <module>"
        ));
        assert!(looks_like_malfunction_text("    at foo (/x.js:1:1)"));
        assert!(looks_like_malfunction_text("SyntaxError: Unexpected token"));
        assert!(looks_like_malfunction_text(
            "node:internal/modules/cjs/loader:123"
        ));
        assert!(looks_like_malfunction_text("foo: command not found"));
        assert!(looks_like_malfunction_text(
            "bar: No such file or directory"
        ));
        assert!(!looks_like_malfunction_text("all good"));
        assert!(!looks_like_malfunction_text("deny: policy violation"));
        // [^\s:]* cannot span a colon, so the two-colon shell form does NOT
        // match — this mirrors the JS regex exactly.
        assert!(!looks_like_malfunction_text("bash: foo: command not found"));
        // A trailing \r keeps `$` from matching, just like the JS regex.
        assert!(!looks_like_malfunction_text("foo: command not found\r"));
    }

    #[test]
    fn malfunction_result() {
        assert!(looks_like_malfunction(&CommandResult {
            spawn_error: true,
            ..Default::default()
        }));
        assert!(looks_like_malfunction(&CommandResult {
            spawn_error: false,
            stdout: Some("ImportError: no module".into()),
            stderr: None,
        }));
        assert!(!looks_like_malfunction(&CommandResult::default()));
    }
}
