//! Ordered JSON value with `JSON.parse` / `JSON.stringify` semantics.
//!
//! `serde_json::Map` (without `preserve_order`) sorts object keys, while JS
//! objects preserve insertion/document order and that order is observable in
//! the harness output (`console.error(JSON.stringify(..., null, 2))`). This
//! module therefore implements its own value type, parser (document order
//! preserved) and serializers (compact and 2-space pretty) that reproduce
//! `JSON.stringify` byte-for-byte for the data handled here.

mod coerce;
mod parse;
mod write;

pub use coerce::{
    js_number_to_string, js_number_value, js_or2, js_or3, js_string_opt, js_string_or_empty,
};
pub use parse::parse;
use write::{write_compact, write_pretty};

/// JSON value. Numbers are stored preformatted in JS `Number#toString` form.
#[derive(Debug, Clone, PartialEq)]
pub enum Json {
    Null,
    Bool(bool),
    Num(String),
    Str(String),
    Arr(Vec<Json>),
    Obj(Vec<(String, Json)>),
}

impl Json {
    pub fn num_i64(value: i64) -> Json {
        Json::Num(value.to_string())
    }

    pub fn num_usize(value: usize) -> Json {
        Json::Num(value.to_string())
    }

    /// `JSON.stringify` number semantics: non-finite values become `null`.
    pub fn num_f64(value: f64) -> Json {
        Json::Num(js_number_to_string(value))
    }

    pub fn obj(entries: Vec<(String, Json)>) -> Json {
        Json::Obj(entries)
    }

    pub fn arr(values: Vec<Json>) -> Json {
        Json::Arr(values)
    }

    pub fn str(value: impl Into<String>) -> Json {
        Json::Str(value.into())
    }

    /// `value?.[key]` — `None` models JS `undefined`.
    pub fn get(&self, key: &str) -> Option<&Json> {
        match self {
            Json::Obj(entries) => entries.iter().find(|(k, _)| k == key).map(|(_, v)| v),
            _ => None,
        }
    }

    /// `value?.[index]`.
    pub fn at(&self, index: usize) -> Option<&Json> {
        match self {
            Json::Arr(items) => items.get(index),
            _ => None,
        }
    }

    pub fn as_str(&self) -> Option<&str> {
        match self {
            Json::Str(s) => Some(s),
            _ => None,
        }
    }

    pub fn as_array(&self) -> Option<&[Json]> {
        match self {
            Json::Arr(items) => Some(items),
            _ => None,
        }
    }

    pub fn as_object(&self) -> Option<&[(String, Json)]> {
        match self {
            Json::Obj(entries) => Some(entries),
            _ => None,
        }
    }

    /// Number value; strings are NOT coerced (use [`js_number_value`]).
    pub fn as_f64(&self) -> Option<f64> {
        match self {
            Json::Num(text) => text.parse::<f64>().ok(),
            _ => None,
        }
    }

    /// JS truthiness.
    pub fn truthy(&self) -> bool {
        match self {
            Json::Null => false,
            Json::Bool(b) => *b,
            Json::Num(text) => text.parse::<f64>().map(|f| f != 0.0).unwrap_or(true),
            Json::Str(s) => !s.is_empty(),
            Json::Arr(_) | Json::Obj(_) => true,
        }
    }

    /// JS `String(value)` for a present value.
    pub fn js_string(&self) -> String {
        match self {
            Json::Null => "null".to_string(),
            Json::Bool(b) => b.to_string(),
            Json::Num(text) => text.clone(),
            Json::Str(s) => s.clone(),
            Json::Arr(items) => items
                .iter()
                .map(|item| match item {
                    Json::Null => String::new(),
                    other => other.js_string(),
                })
                .collect::<Vec<_>>()
                .join(","),
            Json::Obj(_) => "[object Object]".to_string(),
        }
    }

    /// Object key assignment with JS `{...obj, key: value}` spread semantics:
    /// an existing key keeps its position and gets the new value; a new key is
    /// appended.
    pub fn set(&mut self, key: &str, value: Json) {
        if let Json::Obj(entries) = self {
            if let Some(entry) = entries.iter_mut().find(|(k, _)| k == key) {
                entry.1 = value;
            } else {
                entries.push((key.to_string(), value));
            }
        }
    }

    /// Remove an object key (models a spread assigning `undefined`, which
    /// behaves like an absent key for lookups and `JSON.stringify`).
    pub fn remove(&mut self, key: &str) {
        if let Json::Obj(entries) = self {
            entries.retain(|(k, _)| k != key);
        }
    }

    /// `JSON.stringify(value)` (compact).
    pub fn to_compact(&self) -> String {
        let mut out = String::new();
        write_compact(self, &mut out);
        out
    }

    /// `JSON.stringify(value, null, 2)`.
    pub fn to_pretty2(&self) -> String {
        let mut out = String::new();
        write_pretty(self, 0, &mut out);
        out
    }
}

/// Convert a `serde_json::Value` (from the tama-core boundary) into `Json`.
/// Object key order is whatever the `serde_json::Map` holds (sorted without
/// `preserve_order`); only used for values whose order is not observable.
pub fn from_serde(value: &serde_json::Value) -> Json {
    match value {
        serde_json::Value::Null => Json::Null,
        serde_json::Value::Bool(b) => Json::Bool(*b),
        serde_json::Value::Number(n) => {
            Json::Num(js_number_to_string(n.as_f64().unwrap_or(f64::NAN)))
        }
        serde_json::Value::String(s) => Json::Str(s.clone()),
        serde_json::Value::Array(items) => Json::Arr(items.iter().map(from_serde).collect()),
        serde_json::Value::Object(map) => Json::Obj(
            map.iter()
                .map(|(k, v)| (k.clone(), from_serde(v)))
                .collect(),
        ),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn roundtrip_preserves_order() {
        let parsed = parse("{\"b\":1,\"a\":[\"x\",null,true,1.5]}").unwrap();
        assert_eq!(parsed.to_compact(), "{\"b\":1,\"a\":[\"x\",null,true,1.5]}");
    }

    #[test]
    fn pretty_matches_json_stringify() {
        let value = Json::obj(vec![
            ("ok".to_string(), Json::Bool(true)),
            ("empty".to_string(), Json::obj(vec![])),
            ("arr".to_string(), Json::arr(vec![Json::num_i64(1)])),
        ]);
        assert_eq!(
            value.to_pretty2(),
            "{\n  \"ok\": true,\n  \"empty\": {},\n  \"arr\": [\n    1\n  ]\n}"
        );
    }

    #[test]
    fn numbers_match_js() {
        assert_eq!(js_number_to_string(0.0), "0");
        assert_eq!(js_number_to_string(45.0), "45");
        assert_eq!(js_number_to_string(1e21), "1e+21");
        assert_eq!(js_number_to_string(1.5e-7), "1.5e-7");
        assert_eq!(js_number_to_string(0.1), "0.1");
    }
}
