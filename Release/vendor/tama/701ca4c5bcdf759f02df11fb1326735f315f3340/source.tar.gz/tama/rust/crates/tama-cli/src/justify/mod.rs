//! `tama justify` — record, read and remove justification registry entries.
//!
//! The authorization gates require a justification before a new file or a new
//! test is written, and they read it from a registry keyed by absolute path.
//! Writing that registry by hand is refused by three separate gates, all of
//! which are right to protect the hook directory; what was missing is the
//! product surface for the data inside it. This command is that surface, and
//! it enforces exactly what the gates enforce, so a recorded entry is never
//! one the gate will reject: fifty words, and for a test the operator's own
//! request quoted verbatim inside the justification and verified against the
//! stored transcripts by the same checker the hook runs.

pub(crate) mod api;
pub(crate) mod cua;
pub(crate) mod registry;

use std::path::PathBuf;

use serde_json::{json, Map, Value};

use registry::Kind;

const USAGE: &str = "usage: tama justify <record|show|remove|move|list> [--file <path>] \
[--to <path>] [--justification <text>] [--kind file|test|cua] [--quote <text>] [--expires-at <iso>] \
[--home <path>] [--json]\n       tama justify move --file <old path> --to <new path> [--kind file|test]\n       \
tama justify record --kind cua --quote <the operator's sentence> \
--app <name> --actions <a,b,c> --session <id>\n       \
tama justify record --kind cua --quote-match <text in the user message> --app <name> \
--actions <a,b,c> --session <id>\n       tama justify remove --kind cua --quote <the sentence>";
/// Both gates count words with `wc -w` and refuse fewer than fifty.
const MINIMUM_WORDS: usize = 50;

fn option(argv: &[String], name: &str) -> Option<String> {
    argv.iter()
        .position(|item| item == name)
        .and_then(|index| argv.get(index + 1))
        .cloned()
}

fn word_count(text: &str) -> usize {
    text.split_whitespace().count()
}
/// The same check the test gate runs, so this command cannot record a quote
/// the gate will then refuse: both call
/// `tama_hook_tools::ports::check_numeric_literals_provenance::quote_in_user_msg`.
/// It used to be a `python3` subprocess over
/// `~/.shared-hooks/check_numeric_literals.py`, which meant this command
/// refused every quote on a machine where that file was absent and disagreed
/// with the compiled gate the moment the two drifted.
fn quote_is_real(quote: &str) -> Result<(), String> {
    if tama_hook_tools::ports::check_numeric_literals_provenance::quote_in_user_msg(quote) {
        return Ok(());
    }
    // The check reads a transcript index that nothing refreshes on its own,
    // so a quote from the session being worked in fails until that session's
    // transcript is indexed. Saying only "not verbatim" sent one agent looking
    // for a wording mistake that was never there; the refusal names its own
    // precondition instead.
    Err(
        "the quote is not a verbatim message from any stored user turn; the checker reads Oko's \
transcript index, which nothing refreshes on its own, so index this session first with \
`oko-cli transcripts reindex --path <session transcript>`"
            .to_string(),
    )
}

struct Request {
    kind: Kind,
    home: PathBuf,
    json: bool,
    file: Option<String>,
}

fn request(argv: &[String]) -> Result<Request, String> {
    let kind = match option(argv, "--kind") {
        Some(value) => Kind::parse(&value).ok_or_else(|| format!("unknown kind {value}"))?,
        None => Kind::File,
    };
    let home = match option(argv, "--home") {
        Some(value) => PathBuf::from(value),
        None => std::env::var_os("HOME")
            .map(PathBuf::from)
            .ok_or_else(|| "HOME is not set, so no registry location is known".to_string())?,
    };
    Ok(Request {
        kind,
        home,
        json: argv.iter().any(|item| item == "--json"),
        file: option(argv, "--file"),
    })
}

fn absolute(file: &str) -> Result<String, String> {
    if !file.starts_with('/') {
        return Err(format!(
            "the registry is keyed by absolute paths, and {file} is relative"
        ));
    }
    Ok(file.to_string())
}

fn entry(argv: &[String], request: &Request, key: &str) -> Result<Value, String> {
    let justification =
        option(argv, "--justification").ok_or_else(|| "--justification is required".to_string())?;
    let words = word_count(&justification);
    if words < MINIMUM_WORDS {
        return Err(format!(
            "the justification is {words} words and the registry requires {MINIMUM_WORDS}"
        ));
    }
    let mut document = Map::new();
    document.insert("justification".to_string(), json!(justification));
    if let Some(expires) = option(argv, "--expires-at") {
        document.insert("expires_at".to_string(), json!(expires));
    }
    if request.kind == Kind::Test {
        let quote = option(argv, "--quote").ok_or_else(|| {
            format!("a test justification needs --quote, copied verbatim from the request that asked for {key}")
        })?;
        if !justification.contains(&quote) {
            return Err(
                "the justification must contain the quote verbatim, because the gate checks that"
                    .to_string(),
            );
        }
        quote_is_real(&quote)?;
        document.insert("user_request_quote".to_string(), json!(quote));
    }
    Ok(Value::Object(document))
}

fn report(request: &Request, message: &str, payload: Value) -> i32 {
    if request.json {
        println!(
            "{}",
            serde_json::to_string_pretty(&payload).unwrap_or_default()
        );
    } else {
        println!("{message}");
    }
    0
}

fn refuse(message: &str) -> i32 {
    eprintln!("{message}");
    1
}

pub fn main(argv: &[String]) -> i32 {
    let action = argv.first().map(String::as_str).unwrap_or("");
    if action.is_empty() || action == "--help" || action == "-h" || action == "help" {
        println!("{USAGE}");
        return if action.is_empty() { 2 } else { 0 };
    }
    let request = match request(argv) {
        Ok(request) => request,
        Err(message) => return refuse(&message),
    };
    let path = registry::registry_path(&request.home, request.kind);
    if request.kind == Kind::Cua {
        return cua::main(action, argv, &request);
    }

    match action {
        "record" => {
            let Some(file) = request.file.clone() else {
                return refuse("--file is required");
            };
            let key = match absolute(&file) {
                Ok(key) => key,
                Err(message) => return refuse(&message),
            };
            let document = match entry(argv, &request, &key) {
                Ok(document) => document,
                Err(message) => return refuse(&message),
            };
            match registry::record(&path, &key, document) {
                Ok(()) => report(
                    &request,
                    &format!(
                        "recorded the {} justification for {key}",
                        request.kind.label()
                    ),
                    json!({"recorded": key, "kind": request.kind.label(), "registry": path}),
                ),
                Err(message) => refuse(&message),
            }
        }
        "show" => {
            let Some(file) = request.file.clone() else {
                return refuse("--file is required");
            };
            let entries = match registry::load(&path) {
                Ok(entries) => entries,
                Err(message) => return refuse(&message),
            };
            match entries.get(&file) {
                Some(found) => report(
                    &request,
                    &serde_json::to_string_pretty(found).unwrap_or_default(),
                    found.clone(),
                ),
                None => refuse(&format!(
                    "no {} justification is recorded for {file}",
                    request.kind.label()
                )),
            }
        }
        "remove" => {
            let Some(file) = request.file.clone() else {
                return refuse("--file is required");
            };
            match registry::forget(&path, &file) {
                Ok(()) => report(
                    &request,
                    &format!(
                        "removed the {} justification for {file}",
                        request.kind.label()
                    ),
                    json!({"removed": file, "kind": request.kind.label(), "registry": path}),
                ),
                Err(message) => refuse(&message),
            }
        }
        "move" => {
            let Some(file) = request.file.clone() else {
                return refuse("--file is required");
            };
            let Some(to) = option(argv, "--to") else {
                return refuse("--to is required: the path the file now has");
            };
            let to = match absolute(&to) {
                Ok(to) => to,
                Err(message) => return refuse(&message),
            };
            match registry::rename(&path, &file, &to) {
                Ok(()) => report(
                    &request,
                    &format!(
                        "moved the {} justification for {file} to {to}",
                        request.kind.label()
                    ),
                    json!({"moved": file, "to": to, "kind": request.kind.label(), "registry": path}),
                ),
                Err(message) => refuse(&message),
            }
        }
        "list" => {
            let entries = match registry::load(&path) {
                Ok(entries) => entries,
                Err(message) => return refuse(&message),
            };
            let keys: Vec<&String> = entries.keys().collect();
            if request.json {
                println!(
                    "{}",
                    serde_json::to_string_pretty(&json!({
                        "kind": request.kind.label(),
                        "registry": path,
                        "paths": keys,
                    }))
                    .unwrap_or_default()
                );
            } else {
                for key in keys {
                    println!("{key}");
                }
            }
            0
        }
        other => {
            eprintln!("unknown action {other}\n{USAGE}");
            2
        }
    }
}
