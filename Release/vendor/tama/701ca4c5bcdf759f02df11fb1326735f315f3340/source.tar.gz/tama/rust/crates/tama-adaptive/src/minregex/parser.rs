//! Reading a pattern into the tree the matcher walks.
//!
//! Split out of `minregex/mod.rs`, which had grown past the
//! three-hundred-line limit; the match itself stays there.

use super::{Ast, Atom, ClassItem, Set, UNLIMITED};

pub(super) struct Parser<'a> {
    pub(super) chars: &'a [char],
    pub(super) pos: usize,
}

impl<'a> Parser<'a> {
    fn peek(&self) -> Option<char> {
        self.chars.get(self.pos).copied()
    }

    fn next(&mut self) -> Option<char> {
        let c = self.peek();
        if c.is_some() {
            self.pos += 1;
        }
        c
    }

    fn expect(&mut self, c: char) -> Result<(), String> {
        if self.next() == Some(c) {
            Ok(())
        } else {
            Err(format!("expected '{}'", c))
        }
    }

    pub(super) fn parse_alt(&mut self) -> Result<Ast, String> {
        let mut alts = vec![self.parse_seq()?];
        while self.peek() == Some('|') {
            self.pos += 1;
            alts.push(self.parse_seq()?);
        }
        if alts.len() == 1 {
            Ok(alts.pop().unwrap())
        } else {
            Ok(Ast::Alt(alts))
        }
    }

    fn parse_seq(&mut self) -> Result<Ast, String> {
        let mut nodes = Vec::new();
        while let Some(c) = self.peek() {
            if c == '|' || c == ')' {
                break;
            }
            nodes.push(self.parse_piece()?);
        }
        Ok(Ast::Seq(nodes))
    }

    fn parse_piece(&mut self) -> Result<Ast, String> {
        let atom = self.parse_atom()?;
        let (min, max) = match self.peek() {
            Some('?') => {
                self.pos += 1;
                (0, 1)
            }
            Some('*') => {
                self.pos += 1;
                (0, UNLIMITED)
            }
            Some('+') => {
                self.pos += 1;
                (1, UNLIMITED)
            }
            Some('{') => match self.parse_braces()? {
                Some(bounds) => bounds,
                None => return Ok(atom),
            },
            _ => return Ok(atom),
        };
        // Lazy suffix accepted and treated as greedy (unused by our sources).
        if self.peek() == Some('?') {
            self.pos += 1;
        }
        Ok(Ast::Repeat(Box::new(atom), min, max))
    }

    fn parse_braces(&mut self) -> Result<Option<(u32, u32)>, String> {
        let saved = self.pos;
        self.pos += 1; // '{'
        let mut min = String::new();
        while let Some(c) = self.peek() {
            if c.is_ascii_digit() {
                min.push(c);
                self.pos += 1;
            } else {
                break;
            }
        }
        if min.is_empty() {
            self.pos = saved;
            return Ok(None);
        }
        let min: u32 = min.parse().map_err(|_| "bad repeat".to_string())?;
        let max = match self.peek() {
            Some('}') => {
                self.pos += 1;
                min
            }
            Some(',') => {
                self.pos += 1;
                let mut max = String::new();
                while let Some(c) = self.peek() {
                    if c.is_ascii_digit() {
                        max.push(c);
                        self.pos += 1;
                    } else {
                        break;
                    }
                }
                self.expect('}')?;
                if max.is_empty() {
                    UNLIMITED
                } else {
                    max.parse().map_err(|_| "bad repeat".to_string())?
                }
            }
            _ => {
                self.pos = saved;
                return Ok(None);
            }
        };
        Ok(Some((min, max)))
    }

    fn parse_atom(&mut self) -> Result<Ast, String> {
        let c = self.next().ok_or("unexpected end of pattern")?;
        match c {
            '(' => {
                // Non-capturing groups parse like plain groups here.
                if self.peek() == Some('?') {
                    self.pos += 1;
                    self.expect(':')?;
                }
                let inner = self.parse_alt()?;
                self.expect(')')?;
                Ok(inner)
            }
            '[' => self.parse_class(),
            '.' => Ok(Ast::Atom(Atom::Any)),
            '^' => Ok(Ast::Atom(Atom::Start)),
            '$' => Ok(Ast::Atom(Atom::End)),
            '\\' => {
                let escaped = self.parse_escape()?;
                Ok(match escaped {
                    Escaped::Atom(atom) => Ast::Atom(atom),
                    Escaped::Char(ch) => Ast::Atom(Atom::Char(ch)),
                })
            }
            other => Ok(Ast::Atom(Atom::Char(other))),
        }
    }

    fn parse_class(&mut self) -> Result<Ast, String> {
        let negated = if self.peek() == Some('^') {
            self.pos += 1;
            true
        } else {
            false
        };
        let mut items = Vec::new();
        let mut first = true;
        loop {
            let c = self.next().ok_or("unterminated character class")?;
            if c == ']' && !first {
                break;
            }
            first = false;
            let lo = match c {
                '\\' => match self.parse_escape()? {
                    Escaped::Atom(Atom::Set(set)) => {
                        items.push(ClassItem::Set(set));
                        continue;
                    }
                    Escaped::Atom(_) => return Err("unsupported escape in class".to_string()),
                    Escaped::Char(ch) => ch,
                },
                other => other,
            };
            if self.peek() == Some('-')
                && self
                    .chars
                    .get(self.pos + 1)
                    .copied()
                    .map(|c| c != ']')
                    .unwrap_or(false)
            {
                self.pos += 1;
                let hi = self.next().ok_or("unterminated range")?;
                let hi = if hi == '\\' {
                    match self.parse_escape()? {
                        Escaped::Char(ch) => ch,
                        Escaped::Atom(_) => return Err("bad range end".to_string()),
                    }
                } else {
                    hi
                };
                items.push(ClassItem::Range(lo, hi));
            } else {
                items.push(ClassItem::Range(lo, lo));
            }
        }
        Ok(Ast::Atom(Atom::Class { negated, items }))
    }

    fn parse_escape(&mut self) -> Result<Escaped, String> {
        let c = self.next().ok_or("trailing backslash")?;
        Ok(match c {
            'b' => Escaped::Atom(Atom::WordBoundary),
            'B' => Escaped::Atom(Atom::NonWordBoundary),
            'w' => Escaped::Atom(Atom::Set(Set::Word)),
            'W' => Escaped::Atom(Atom::Set(Set::NonWord)),
            'd' => Escaped::Atom(Atom::Set(Set::Digit)),
            'D' => Escaped::Atom(Atom::Set(Set::NonDigit)),
            's' => Escaped::Atom(Atom::Set(Set::Space)),
            'S' => Escaped::Atom(Atom::Set(Set::NonSpace)),
            'n' => Escaped::Char('\n'),
            'r' => Escaped::Char('\r'),
            't' => Escaped::Char('\t'),
            'f' => Escaped::Char('\u{0c}'),
            'v' => Escaped::Char('\u{0b}'),
            '0' => Escaped::Char('\0'),
            'u' => {
                let mut code = 0u32;
                for _ in 0..4 {
                    let d = self.next().ok_or("bad \\u escape")?;
                    code = code * 16 + d.to_digit(16).ok_or("bad \\u escape")?;
                }
                Escaped::Char(char::from_u32(code).ok_or("bad \\u escape")?)
            }
            other => Escaped::Char(other),
        })
    }
}

enum Escaped {
    Atom(Atom),
    Char(char),
}
