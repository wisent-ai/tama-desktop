//! Where a failed Weles run leaves what a person has to look at.
//!
//! Three guards decide whether the agent actually inspected a failure, and
//! each built the same path pattern for itself — the run root, the run
//! label, the digest, and the three artefact suffixes. A recorder that
//! starts writing a fourth kind is invisible to all three, and a renamed
//! suffix is found by none.
//!
//! The suffixes and the run root are declared in
//! `vocabulary/failure-artefacts.json`; the patterns are built here.

/// The declaration compiled in from the vocabulary folder beside `ports`.
const DECLARED: &str = include_str!("../vocabulary/failure-artefacts.json");

fn declared() -> serde_json::Value {
    serde_json::from_str(DECLARED).expect("failure-artefacts.json beside this module is valid JSON")
}

/// The artefact suffixes, as one regex branch.
pub fn suffix_alternation() -> String {
    declared()["suffixes"]
        .as_array()
        .expect("failure-artefacts.json declares a suffixes array")
        .iter()
        .filter_map(|suffix| suffix.as_str())
        .collect::<Vec<_>>()
        .join("|")
}

/// Where a run's artefacts live, relative to the workspace.
pub fn run_root() -> String {
    declared()["run_root"]
        .as_str()
        .expect("failure-artefacts.json declares a run_root")
        .to_owned()
}

/// The exact failure snapshot of one run: `…/failure_state_<sha8>.<kind>`.
pub fn failure_state_pattern(label: &str, sha8: &str) -> String {
    format!(
        r"{}/{}/failure_state_{}\.(?:{})\n?\z",
        regex::escape(&run_root()),
        regex::escape(label),
        regex::escape(sha8),
        suffix_alternation(),
    )
}

/// Any frame or snapshot of one run, which is what counting distinct reads
/// needs: `…/frame_<sha8>_2.png` as well as the failure state itself.
pub fn any_frame_pattern(label: &str, sha8: &str) -> String {
    format!(
        r"{}/{}/(?:frame|failure_state)_{}_?[^\s'\x22]*\.(?:{})\n?\z",
        regex::escape(&run_root()),
        regex::escape(label),
        regex::escape(sha8),
        suffix_alternation(),
    )
}

#[cfg(test)]
mod tests {
    use super::{any_frame_pattern, failure_state_pattern, suffix_alternation};
    use regex::Regex;

    #[test]
    fn the_failure_snapshot_matches_every_declared_suffix() {
        let pattern = Regex::new(&failure_state_pattern("run-a", "0f1e2d3c")).expect("compiles");
        for suffix in suffix_alternation().split('|') {
            let path = format!(".weles/runs/run-a/failure_state_0f1e2d3c.{suffix}");
            assert!(pattern.is_match(&path), "{path}");
        }
        assert!(!pattern.is_match(".weles/runs/run-a/failure_state_0f1e2d3c.txt"));
    }

    /// Counting reads needs the numbered frames too, and must not count a
    /// different run's frame.
    #[test]
    fn any_frame_matches_numbered_frames_of_that_run_only() {
        let pattern = Regex::new(&any_frame_pattern("run-a", "0f1e2d3c")).expect("compiles");
        assert!(pattern.is_match(".weles/runs/run-a/frame_0f1e2d3c_2.png"));
        assert!(pattern.is_match(".weles/runs/run-a/failure_state_0f1e2d3c.html"));
        assert!(!pattern.is_match(".weles/runs/run-b/frame_0f1e2d3c_2.png"));
    }
}
