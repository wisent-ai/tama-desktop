//! One hook engine shared by one-shot and persistent harness adapters.

use std::path::{Path, PathBuf};
use std::time::{SystemTime, UNIX_EPOCH};

use serde_json::{json, Value};

use crate::{Decision, InvocationOptions};

mod snapshot;
use snapshot::Snapshot;

pub struct Runtime {
    path: PathBuf,
    snapshot: Snapshot,
    generation: u64,
    reload_count: u64,
    last_reload_at_ms: Option<u64>,
    last_error: Option<String>,
}

impl Runtime {
    pub fn load(path: &Path) -> Result<Self, String> {
        Ok(Self {
            path: path.to_owned(),
            snapshot: Snapshot::read(path)?,
            generation: 1,
            reload_count: 0,
            last_reload_at_ms: None,
            last_error: None,
        })
    }

    fn refresh(&mut self, explicit: bool) -> Result<bool, String> {
        let result: Result<bool, String> = (|| {
            let candidate = Snapshot::read(&self.path)?;
            let changed = candidate.checksum != self.snapshot.checksum;
            if changed || explicit {
                let now = SystemTime::now()
                    .duration_since(UNIX_EPOCH)
                    .map_err(|error| format!("recording hook reload time: {error}"))?;
                let at = u64::try_from(now.as_millis())
                    .map_err(|error| format!("recording hook reload time: {error}"))?;
                let generation = self
                    .generation
                    .checked_add(u64::from(changed))
                    .ok_or_else(|| "hook generation counter overflow".to_owned())?;
                let reload_count = self
                    .reload_count
                    .checked_add(1)
                    .ok_or_else(|| "hook reload counter overflow".to_owned())?;
                self.snapshot = candidate;
                self.generation = generation;
                self.reload_count = reload_count;
                self.last_reload_at_ms = Some(at);
            }
            Ok(changed)
        })();
        match &result {
            Ok(_) => self.last_error = None,
            Err(error) => self.last_error = Some(error.clone()),
        }
        result
    }

    /// Apply a complete replacement or retain the preceding usable snapshot.
    pub fn reload(&mut self) -> Result<bool, String> {
        self.refresh(true)
    }
    pub fn status(&self) -> Value {
        json!({
            "processId": std::process::id(),
            "generation": self.generation,
            "loadedReleaseId": self.snapshot.release_id,
            "catalogChecksum": self.snapshot.checksum,
            "registeredHookCount": self.snapshot.hook_ids.len(),
            "reloadCount": self.reload_count,
            "lastReloadAtMs": self.last_reload_at_ms,
            "lastReloadError": self.last_error,
        })
    }

    pub(crate) fn catalog_checksum(&self) -> &str {
        &self.snapshot.checksum
    }

    pub(crate) fn catalog(&self) -> &Value {
        &self.snapshot.registry
    }

    pub(crate) fn hook_ids(&self) -> &std::collections::HashSet<String> {
        &self.snapshot.hook_ids
    }

    pub(crate) fn first_hook_id(&self, event: &str) -> Option<&str> {
        self.snapshot
            .registry
            .get("events")?
            .get(event)?
            .get("hooks")?
            .as_array()?
            .first()?
            .get("id")?
            .as_str()
    }

    pub(crate) fn refresh_for_dispatch(&mut self) -> Result<(), String> {
        self.refresh(false).map(|_| ())
    }

    /// Canonical event API. Adapters translate their own event shapes before
    /// calling this method and translate its decision only after it returns.
    pub fn dispatch(
        &mut self,
        event: &str,
        agent_id: &str,
        options: &InvocationOptions,
        payload: &Value,
    ) -> Result<Decision, String> {
        self.refresh_for_dispatch()?;
        self.dispatch_loaded(event, agent_id, options, payload)
    }

    /// Evaluate the currently loaded generation. Every command starts afresh;
    /// executable/script code is never cached across hook invocations.
    pub(crate) fn dispatch_loaded(
        &self,
        event: &str,
        agent_id: &str,
        options: &InvocationOptions,
        payload: &Value,
    ) -> Result<Decision, String> {
        crate::flow::inner::evaluate(
            &self.snapshot.registry,
            &self.snapshot.hook_ids,
            &self.snapshot.checksum,
            event,
            agent_id,
            options,
            payload,
        )
    }
}
