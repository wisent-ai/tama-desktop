//! Port of `src/tests/live-runtime/support/runtime-test-support.mjs`
//! (plus the process-spawning primitives it re-exports from Node).

mod paths;
mod payloads;

pub use paths::{
    claude_live_model, codex_full_local_coverage, codex_router_coverage, dirname, exists,
    io_error_message, keep_artifacts, live_runtime_tmp_root, make_live_runtime_temp, mkdtemp,
    model_router_root, normalize_path, read, rm_force, root, scenario_filter, tmpdir, write_file,
    REAL_RUNNER,
};
pub use payloads::{
    attempt, coverage_key_opt, covered_keys_from_editor_outcomes,
    covered_keys_from_editor_watch_log, covered_keys_from_omp_payloads, make_recorder,
    omp_claimed_event, parse_json_lines, parse_json_lines_from_text, read_payloads, tail, tail_n,
    unique,
};

use std::io::Read;
use std::io::Write;
use std::path::{Path, PathBuf};
use std::process::{Child, Command, Stdio};
use std::time::{Duration, Instant};

// ---------------------------------------------------------------------------
// spawnSync equivalent
// ---------------------------------------------------------------------------

/// Result of a JS `spawnSync(..., { encoding: 'utf8' })` call.
#[derive(Debug, Clone)]
pub struct RunResult {
    /// Exit code (`null` when the child was signaled or failed to spawn).
    pub status: Option<i32>,
    /// Signal name such as `SIGTERM` (`null` on a normal exit).
    pub signal: Option<String>,
    pub stdout: String,
    pub stderr: String,
    /// `result.error?.code` (`ENOENT`, `EACCES`, ...).
    pub error_code: Option<String>,
}

/// Options for [`run`]. `env_overrides` reproduces `{...process.env, ...}`
/// (Command inherits the parent environment; overrides replace single keys).
#[derive(Default)]
pub struct RunOpts {
    pub cwd: Option<PathBuf>,
    pub env_overrides: Vec<(String, String)>,
    pub max_buffer: Option<usize>,
    pub input: Option<String>,
}

extern "C" {
    fn kill(pid: i32, sig: i32) -> i32;
}

const SIGTERM: i32 = 15;
const SIGKILL: i32 = 9;

fn send_signal(pid: u32, sig: i32) {
    unsafe {
        kill(pid as i32, sig);
    }
}

fn signal_name(number: i32) -> String {
    // macOS signal numbers (the platform this harness runs on).
    match number {
        1 => "SIGHUP",
        2 => "SIGINT",
        3 => "SIGQUIT",
        4 => "SIGILL",
        5 => "SIGTRAP",
        6 => "SIGABRT",
        7 => "SIGEMT",
        8 => "SIGFPE",
        9 => "SIGKILL",
        10 => "SIGBUS",
        11 => "SIGSEGV",
        12 => "SIGSYS",
        13 => "SIGPIPE",
        14 => "SIGALRM",
        15 => "SIGTERM",
        16 => "SIGURG",
        30 => "SIGUSR1",
        31 => "SIGUSR2",
        other => return format!("SIG{other}"),
    }
    .to_string()
}

/// JS `run(command, args, options)` = `spawnSync` with `encoding: 'utf8'`,
/// `timeout`, `maxBuffer`, `cwd`, `env` and `input` support.
pub fn run(command: &str, args: &[String], opts: &RunOpts) -> RunResult {
    let mut cmd = Command::new(command);
    cmd.args(args);
    if let Some(cwd) = &opts.cwd {
        cmd.current_dir(cwd);
    }
    for (key, value) in &opts.env_overrides {
        cmd.env(key, value);
    }
    cmd.stdin(if opts.input.is_some() {
        Stdio::piped()
    } else {
        Stdio::null()
    });
    cmd.stdout(Stdio::piped());
    cmd.stderr(Stdio::piped());

    let mut child = match cmd.spawn() {
        Ok(child) => child,
        Err(error) => {
            let code = match error.kind() {
                std::io::ErrorKind::NotFound => "ENOENT",
                std::io::ErrorKind::PermissionDenied => "EACCES",
                _ => "UNKNOWN",
            };
            return RunResult {
                status: None,
                signal: None,
                stdout: String::new(),
                stderr: String::new(),
                error_code: Some(code.to_string()),
            };
        }
    };

    let mut stdin = child.stdin.take();
    let input = opts.input.clone();
    let stdin_thread = std::thread::spawn(move || {
        if let (Some(mut stdin), Some(input)) = (stdin.take(), input) {
            let _ = stdin.write_all(input.as_bytes());
        }
    });

    let mut stdout_pipe = child.stdout.take();
    let stdout_thread = std::thread::spawn(move || {
        let mut buf = Vec::new();
        if let Some(mut pipe) = stdout_pipe.take() {
            let _ = pipe.read_to_end(&mut buf);
        }
        buf
    });
    let mut stderr_pipe = child.stderr.take();
    let stderr_thread = std::thread::spawn(move || {
        let mut buf = Vec::new();
        if let Some(mut pipe) = stderr_pipe.take() {
            let _ = pipe.read_to_end(&mut buf);
        }
        buf
    });

    // The command is waited for. A deadline here killed a live agent run
    // mid-answer and reported `ETIMEDOUT`, which reads as a product failure
    // the product never had; what a slow run costs belongs in its own report.
    let status = child.wait().ok();
    let _ = stdin_thread.join();
    let stdout_bytes = stdout_thread.join().unwrap_or_default();
    let stderr_bytes = stderr_thread.join().unwrap_or_default();

    // maxBuffer: Node kills the child once the buffer exceeds the limit; the
    // port reads fully and truncates (observably identical for outputs that
    // stay under the limit, which is the expected case here).
    let truncate = |mut buf: Vec<u8>| -> String {
        if let Some(max) = opts.max_buffer {
            if buf.len() > max {
                buf.truncate(max);
            }
        }
        String::from_utf8_lossy(&buf).into_owned()
    };

    use std::os::unix::process::ExitStatusExt;
    let (status_code, signal) = match status {
        Some(exit) => (exit.code(), exit.signal().map(signal_name)),
        None => (None, None),
    };
    RunResult {
        status: status_code,
        signal,
        stdout: truncate(stdout_bytes),
        stderr: truncate(stderr_bytes),
        error_code: None,
    }
}

/// Convenience wrapper matching `run(cmd, args, { cwd })` call sites.
pub fn run_in(cmd: &str, args: &[&str], cwd: &Path) -> RunResult {
    let owned: Vec<String> = args.iter().map(|a| a.to_string()).collect();
    run(
        cmd,
        &owned,
        &RunOpts {
            cwd: Some(cwd.to_path_buf()),
            ..RunOpts::default()
        },
    )
}

/// `spawn(command, args, { stdio: 'ignore', cwd, env })` — detached child for
/// the editor watcher. I/O is ignored like `stdio: 'ignore'`.
pub fn spawn_ignored(
    command: &str,
    args: &[String],
    cwd: &Path,
    env_overrides: &[(String, String)],
) -> Result<Child, String> {
    let mut cmd = Command::new(command);
    cmd.args(args)
        .current_dir(cwd)
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null());
    for (key, value) in env_overrides {
        cmd.env(key, value);
    }
    cmd.spawn()
        .map_err(|e| format!("failed to spawn {command}: {e}"))
}

/// `child.kill('SIGTERM')` followed by reaping (JS does not reap explicitly;
/// the port waits briefly so no zombie is left behind).
pub fn kill_sigterm(child: &mut Child) {
    send_signal(child.id(), SIGTERM);
    let deadline = Instant::now() + Duration::from_millis(2_000);
    loop {
        match child.try_wait() {
            Ok(Some(_)) => return,
            Ok(None) => {
                if Instant::now() >= deadline {
                    send_signal(child.id(), SIGKILL);
                    let _ = child.wait();
                    return;
                }
                std::thread::sleep(Duration::from_millis(20));
            }
            Err(_) => return,
        }
    }
}

/// `process.execPath` in the JS harness is the Node binary; resolve `node`
/// from `PATH` so spawned commands log an absolute path like the JS version.
pub fn node_exec_path() -> String {
    if let Some(path_var) = std::env::var_os("PATH") {
        for dir in std::env::split_paths(&path_var) {
            let candidate = dir.join("node");
            if candidate.is_file() {
                return candidate.to_string_lossy().into_owned();
            }
        }
    }
    "node".to_string()
}
