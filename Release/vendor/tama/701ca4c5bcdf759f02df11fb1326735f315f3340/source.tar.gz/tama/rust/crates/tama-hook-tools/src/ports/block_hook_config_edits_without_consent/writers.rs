//! Commands that write hook configuration without ever naming a protected
//! path.
//!
//! The gate beside this file decides by reading text: a protected path plus
//! something that looks like a write. A tool whose whole job is to write hook
//! configuration passes both halves unnoticed — the path is inside the tool,
//! and running a program is not a redirect or a copy. On 2026-09-15
//! `node shared-hooks/generate-configs.mjs --apply` rewrote this machine's
//! Claude and Codex hook configurations from inside an agent session, without
//! consent, and the guard saw nothing to refuse.
//!
//! So the writers are named here. A tool that only reports — `--check`,
//! `--preview`, a `generate-configs` run without `--apply`, `enforcement
//! status` — writes nothing and stays allowed, because a guard that refuses
//! reads teaches people to stop reading.

use crate::ports::python_stdlib::shell_tokens;
use crate::ports::shell_text;

use super::tables::{
    ALWAYS, APPLY_FLAG, CHECK_FLAG, ENFORCEMENT_READS, ENFORCEMENT_WORD, HOOKS_WORD, INSTALL_WORD,
    OKO_HOOKS_REASON, OKO_HOOK_WRITES, OKO_PROGRAM, PREVIEW_FLAG, TAMA_ENFORCEMENT_REASON,
    TAMA_INSTALL_REASON, TAMA_PROGRAMS, UNLESS_CHECK, WHEN_APPLY,
};

/// Does a command word of this call name the needle? A sentence handed to a
/// tool — an evidence message, a commit body — survives tokenizing as one
/// token with spaces in it, and naming a writer inside a sentence runs
/// nothing.
fn mentions(tokens: &[String], needle: &str) -> bool {
    tokens
        .iter()
        .any(|token| shell_text::command_word(token) && token.contains(needle))
}

fn flagged(tokens: &[String], flag: &str) -> bool {
    tokens.iter().any(|token| token == flag)
}

/// `tama … install`, `tama … enforcement only|all`, `oko-cli hooks
/// install|pull` — a subcommand rather than a file name, so it is read from
/// the program this command starts and the words it passes that program. An
/// interpreter never runs `tama` as a script argument, so reading the
/// program position here costs nothing and keeps a sentence that names the
/// command from counting as running it.
fn subcommand_writer(tokens: &[String]) -> Option<&'static str> {
    let name = shell_text::program(tokens)?;
    let words: Vec<&str> = tokens
        .iter()
        .filter(|token| shell_text::command_word(token))
        .map(String::as_str)
        .collect();
    if TAMA_PROGRAMS.contains(&name) {
        if words.contains(&INSTALL_WORD) {
            return Some(TAMA_INSTALL_REASON);
        }
        if words.contains(&ENFORCEMENT_WORD)
            && !words.iter().any(|word| ENFORCEMENT_READS.contains(word))
        {
            return Some(TAMA_ENFORCEMENT_REASON);
        }
    }
    if name == OKO_PROGRAM
        && words.contains(&HOOKS_WORD)
        && words.iter().any(|word| OKO_HOOK_WRITES.contains(word))
        && !flagged(tokens, PREVIEW_FLAG)
    {
        return Some(OKO_HOOKS_REASON);
    }
    None
}

/// Which hook-configuration writer one command runs, if it runs one.
fn command_writer(tokens: &[String]) -> Option<&'static str> {
    for (needle, reason) in ALWAYS {
        if mentions(tokens, needle) {
            return Some(reason);
        }
    }
    for (needle, reason) in UNLESS_CHECK {
        if mentions(tokens, needle) && !flagged(tokens, CHECK_FLAG) {
            return Some(reason);
        }
    }
    for (needle, reason) in WHEN_APPLY {
        if mentions(tokens, needle) && flagged(tokens, APPLY_FLAG) {
            return Some(reason);
        }
    }
    subcommand_writer(tokens)
}

/// Which hook-configuration writer this payload runs, if it runs one.
///
/// The cut into commands is quote-aware, so a separator inside a quoted
/// argument stays part of that argument, and an executor's quoted program is
/// read as a command in its own right.
pub(crate) fn runs_hook_config_writer(text: &str) -> Option<&'static str> {
    for segment in shell_text::commands(text) {
        let tokens = shell_tokens(segment);
        if tokens.is_empty() {
            continue;
        }
        if let Some(reason) = command_writer(&tokens) {
            return Some(reason);
        }
        if let Some(inner) = shell_text::inner_command(&tokens) {
            if let Some(reason) = runs_hook_config_writer(inner) {
                return Some(reason);
            }
        }
    }
    None
}

#[cfg(test)]
mod tests {
    use super::runs_hook_config_writer;

    /// The command that rewrote this machine's Claude and Codex hook
    /// configurations on 2026-09-15 without consent.
    #[test]
    fn the_command_that_slipped_through_is_named() {
        let reason = runs_hook_config_writer("node shared-hooks/generate-configs.mjs --apply");
        assert_eq!(
            reason,
            Some("generate-configs.mjs --apply rewrites the provider hook configurations")
        );
    }

    #[test]
    fn every_writer_is_refused_however_it_is_reached() {
        for command in [
            "node shared-hooks/register-hook.mjs some-hook pre_tool_use:bash /bin/true",
            "node /Users/x/Documents/CodingProjects/Wisent/tama/shared-hooks/prune-empty-catalog.mjs",
            "node shared-hooks/install_oko_trajectory_boundary_hook.mjs",
            "rust/target/release/tama-record-hook-metadata --category c shared-hooks/catalog-metadata.json an-id",
            "node shared-hooks/seal-registry.mjs shared-hooks/registry.json",
            "tama-reconcile-registry-sources shared-hooks/registry.json",
            "tama-cli install --set-git-config",
            "tama enforcement only block-browser-usage",
            "tama enforcement all",
            "oko-cli hooks install",
            "oko-cli hooks pull --org-id abc",
            "cd repo && node shared-hooks/register-hook.mjs a b c",
        ] {
            assert!(
                runs_hook_config_writer(command).is_some(),
                "{command} writes hook configuration and must be refused"
            );
        }
    }

    /// `add` and `remove` were added to `tama enforcement` on 2026-09-21
    /// while this guard knew only `only` and `all`, and a session turned a
    /// hook on without the owner approving it. The guard now refuses every
    /// enforcement verb that is not a read, whatever the program is called
    /// by, so the next verb is covered before it exists.
    #[test]
    fn a_selection_verb_this_guard_has_never_heard_of_is_still_a_selection_change() {
        for command in [
            "tama enforcement add block-off-task-work",
            "tama-cli enforcement remove block-browser-usage",
            "./rust/target/debug/tama-cli enforcement add block-off-task-work",
            "/Users/x/.local/bin/tama-cli enforcement reset",
        ] {
            assert!(
                runs_hook_config_writer(command).is_some(),
                "{command} changes which hooks this machine runs and must be refused"
            );
        }
        for reading in [
            "tama enforcement status",
            "tama-cli enforcement status --json",
            "tama enforcement preflight block-browser-usage --session 01a0",
        ] {
            assert!(
                runs_hook_config_writer(reading).is_none(),
                "{reading} only reads the selection"
            );
        }
    }

    /// A guard that refuses reading teaches people to stop reading.
    #[test]
    fn reporting_only_runs_stay_allowed() {
        for command in [
            "node shared-hooks/generate-configs.mjs",
            "node shared-hooks/seal-registry.mjs --check shared-hooks/registry.json",
            "tama-reconcile-registry-sources --check shared-hooks/registry.json",
            "tama enforcement status",
            "tama-cli list --json",
            "oko-cli hooks install --preview",
            "node shared-hooks/compare-registry-catalog.mjs",
            "wc -l shared-hooks/registry.json",
        ] {
            assert_eq!(
                runs_hook_config_writer(command),
                None,
                "{command} writes nothing and must stay allowed"
            );
        }
    }

    /// The refusal this gate produced on 2026-09-16, against the command that
    /// was recording evidence about that very refusal. The semicolon inside
    /// the quoted sentence used to cut the argument in half.
    #[test]
    fn a_sentence_that_names_a_writer_runs_nothing() {
        for command in [
            "oko-cli transcripts tasks evidence 01a08878 202 --commit \"the operator exports \
             DEVICE_HOOK_EDIT_APPROVED=1 and then runs 'tama-cli enforcement only <ids> \
             block-git-authorship'; the engine refuses that write from inside the session\"",
            "git commit -m \"chore: node shared-hooks/generate-configs.mjs --apply rewrote the \
             provider configurations on 2026-09-15 without consent\"",
            "oko-cli transcripts tasks evidence s 1 --commit \"tama install writes the \
             dispatchers; oko-cli hooks pull writes the files\"",
        ] {
            assert_eq!(
                runs_hook_config_writer(command),
                None,
                "{command} only names a writer and must stay allowed"
            );
        }
    }

    /// Naming it is one thing; handing it to a shell is another.
    #[test]
    fn a_writer_hidden_in_an_executors_argument_is_refused() {
        for command in [
            "bash -lc \"tama enforcement only block-browser-usage\"",
            "sh -c 'node shared-hooks/generate-configs.mjs --apply'",
            "echo \"before $(tama-cli install --set-git-config) after\"",
            "node 'shared-hooks/generate-configs.mjs' --apply",
            "env TAMA_HOME=/opt tama enforcement all",
        ] {
            assert!(
                runs_hook_config_writer(command).is_some(),
                "{command} runs a writer and must be refused"
            );
        }
    }
}
