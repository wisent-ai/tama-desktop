//! Port of `src/adaptive/bridge.mjs`: frustration-attribution bridge.
//! Advisory component: any failure finishes silently with a zero exit code.

use std::io::Read;
use std::process::Command;

use crate::engine::{load_engine, Engine};
use crate::minregex::Regex;
use crate::telemetry::{open_telemetry, Telemetry};
use crate::util::{home_dir, js_string, js_truthy};

mod dispatch;

pub use dispatch::dispatch;

const ACTIVE_FLAG: &str = "HOOKS_ADAPTIVE_BRIDGE_ACTIVE";

// (a) The one declaration in `tama_core::frustration`, in this engine's
// whitespace. The bridge, the frustration detector and the shell script
// they replaced each used to spell these words out for themselves.
pub fn base_source() -> String {
    tama_core::frustration::correction_pattern("\\s")
}

// (b) The Polish phrasings, from the same declaration; each is a prefix,
// so inflected forms match without listing them.
fn polish_sources() -> Vec<String> {
    tama_core::frustration::polish_patterns("\\s")
}

/// Only the phrasings that correct something already said: irritation on
/// its own does not attribute a rule.
pub fn explicit_correction() -> String {
    tama_core::frustration::explicit_correction_pattern("\\s")
}

extern "C" {
    fn isatty(fd: i32) -> i32;
}

fn escape_regex(text: &str) -> String {
    let mut out = String::with_capacity(text.len());
    for c in text.chars() {
        if matches!(
            c,
            '.' | '*' | '+' | '?' | '^' | '$' | '{' | '}' | '(' | ')' | '|' | '[' | ']' | '\\'
        ) {
            out.push('\\');
        }
        out.push(c);
    }
    out
}

/// (c) Dynamic per-owner terms from the Oko transcript index; any failure
/// falls back silently to the static sources.
fn dynamic_sources() -> Vec<String> {
    let attempt = || -> Option<Vec<String>> {
        let db = home_dir()
            .join("Library")
            .join("Application Support")
            .join("Oko")
            .join("transcript-index.sqlite");
        let output = Command::new("sqlite3")
            .args([
                "-readonly",
                "-json",
                &db.to_string_lossy(),
                "SELECT DISTINCT word FROM transcript_frustration_terms;",
            ])
            .output()
            .ok()?;
        if !output.status.success() {
            return None;
        }
        let body = String::from_utf8_lossy(&output.stdout).trim().to_string();
        if body.is_empty() {
            return Some(Vec::new());
        }
        let rows: serde_json::Value = serde_json::from_str(&body).ok()?;
        let rows = rows.as_array()?;
        let mut sources = Vec::new();
        for row in rows {
            let word = row
                .get("word")
                .and_then(|w| w.as_str())
                .map(str::trim)
                .unwrap_or("");
            if !word.is_empty() {
                sources.push(format!("\\b{}\\b", escape_regex(word)));
            }
        }
        Some(sources)
    };
    attempt().unwrap_or_default()
}

/// `matchTerms(prompt, sources)` — an unparseable dynamic term never
/// breaks detection.
fn match_terms(prompt: &str, sources: &[String]) -> Vec<String> {
    let mut terms: Vec<String> = Vec::new();
    for source in sources {
        let Ok(regex) = Regex::new(source, true) else {
            continue;
        };
        let Some(hit) = regex.find(prompt) else {
            continue;
        };
        if !hit.is_empty() && !terms.contains(&hit) {
            terms.push(hit);
        }
    }
    terms
}

fn read_stdin() -> String {
    if unsafe { isatty(0) } == 1 {
        return String::new();
    }
    let mut buffer = Vec::new();
    let _ = std::io::stdin().read_to_end(&mut buffer);
    String::from_utf8_lossy(&buffer).to_string()
}

fn candidate_ids(blocks: &[serde_json::Value]) -> Vec<serde_json::Value> {
    let mut ids: Vec<serde_json::Value> = Vec::new();
    for block in blocks {
        let Some(hook_id) = block.get("hookId") else {
            continue;
        };
        if js_truthy(hook_id) && !ids.contains(hook_id) {
            ids.push(hook_id.clone());
        }
    }
    ids
}

fn contested_ids(prompt: &str, ids: &[serde_json::Value]) -> Vec<serde_json::Value> {
    let named: Vec<serde_json::Value> = ids
        .iter()
        .filter(|id| prompt.contains(&js_string(id)))
        .cloned()
        .collect();
    if !named.is_empty() {
        return named;
    }
    if ids.len() == 1 {
        if let Ok(regex) = Regex::new(&explicit_correction(), true) {
            if regex.is_match(prompt) {
                return ids.to_vec();
            }
        }
    }
    Vec::new()
}

/// First truthy of the given keys on the object (JS `a || b || ...`).
fn first_truthy<'a>(object: &'a serde_json::Value, keys: &[&str]) -> Option<&'a serde_json::Value> {
    keys.iter()
        .find_map(|key| object.get(*key))
        .filter(|v| js_truthy(v))
}

fn body(engine: &Engine, telemetry: &Telemetry) -> Result<(), ()> {
    let raw = read_stdin();
    let mut payload = serde_json::from_str::<serde_json::Value>(&raw)
        .unwrap_or_else(|_| serde_json::json!({ "raw": raw }));
    if !payload.is_object() {
        payload = serde_json::json!({ "raw": raw });
    }
    let prompt = first_truthy(&payload, &["prompt", "user_message"])
        .map(js_string)
        .unwrap_or_default();
    let raw_event = payload
        .get("raw_event")
        .filter(|v| v.is_object())
        .cloned()
        .unwrap_or_else(|| serde_json::json!({}));
    let session_id = first_truthy(&payload, &["session_id", "sessionId"])
        .or_else(|| first_truthy(&raw_event, &["session_id", "sessionId"]))
        .cloned()
        .unwrap_or(serde_json::Value::Null);
    let episode_id = first_truthy(&payload, &["turn_id", "turnId"])
        .or_else(|| first_truthy(&raw_event, &["turn_id", "turnId"]))
        .cloned()
        .unwrap_or(serde_json::Value::Null);
    let session_key = if session_id.is_null() {
        None
    } else {
        Some(js_string(&session_id))
    };
    let blocks = engine.consume_latest_episode_blocks(session_key.as_deref());
    if prompt.trim().is_empty() {
        return Ok(());
    }
    let mut sources: Vec<String> = vec![base_source()];
    sources.extend(polish_sources());
    sources.extend(dynamic_sources());
    let terms = match_terms(&prompt, &sources);
    let ids = candidate_ids(&blocks);
    let contested = contested_ids(&prompt, &ids);
    // The vocabulary above used to be the only way in, so a calm correction was
    // thrown away: "okej to naprawmy block-browser-usage" — the words that
    // asked for a repair on 2026-09-10, naming the hook outright — matched no
    // frustration term, so nothing was labeled, queued or contested. That is
    // backwards from the contract this bridge implements: a direct correction
    // of the blocked action is what records a contested-block fact, while
    // frustration is recommendation evidence only. Naming the hook, or
    // correcting it in the documented words, is therefore its own way in.
    if terms.is_empty() && contested.is_empty() {
        return Ok(());
    }
    telemetry.frustration(&serde_json::json!({
        "terms": terms,
        "session_id": session_id,
        "episode_id": episode_id,
        "candidateHookIds": ids,
    }));
    for id in &ids {
        let block = blocks
            .iter()
            .find(|entry| entry.get("hookId") == Some(id))
            .cloned()
            .unwrap_or(serde_json::Value::Null);
        if contested.contains(id) {
            let transition = engine
                .record_contested_block(&js_string(id))
                .map_err(|_| ())?;
            telemetry.frustration(&serde_json::json!({
                "kind": "explicit_contest",
                "id": id,
                "session_id": session_id,
                "episode_id": episode_id,
                "adaptiveStatePersisted": transition.persisted,
            }));
            telemetry.corpus_label(
                id,
                &serde_json::json!({ "label": "fp-suspect", "source": "explicit-user-correction" }),
            );
            telemetry.queue_repair(&serde_json::json!({
                "id": id,
                "kind": "fp",
                "evidence": format!("corpus/{}.jsonl", js_string(id)),
            }));
        } else {
            let reason = block
                .get("reason")
                .filter(|r| js_truthy(r))
                .map(js_string)
                .unwrap_or_default();
            telemetry.frustration(&serde_json::json!({
                "kind": "recommendation",
                "id": id,
                "session_id": session_id,
                "episode_id": episode_id,
                "reason": reason,
            }));
        }
    }
    Ok(())
}

/// `main().then(finish, finish)` — always exits zero.
pub fn main() -> i32 {
    if std::env::var(ACTIVE_FLAG).ok().as_deref() == Some("1") {
        return 0;
    }
    let engine = load_engine();
    let telemetry = open_telemetry(&engine.state_dir);
    let _ = body(&engine, &telemetry);
    telemetry.close();
    0
}
