//! Logic for `tama-block-oversized-files`, registry hook
//! `block-oversized-files`: no source file over 300 lines.
//!
//! Two exemptions, both on the operator's instruction, both kept verbatim
//! from the shell this replaces:
//!
//!   * A registry is a list, not a module. `test_justifications.json` and
//!     `file_justifications.json` grow one entry per decision and the hooks
//!     themselves read them, so "split into smaller modules" is not an
//!     instruction anyone can follow: splitting a registry breaks its reader.
//!     Structured data is exempt from the line count ("wylacz limit dla
//!     plikow rejestrow", 2026-09-10). TOML is that same ruling read
//!     honestly: it is a data format with no modules to split into, and the
//!     fleet had already worked around its absence twice — rachuba's 2026
//!     state tax tables at 1130 and 607 lines, and this repository's own hook
//!     manifest, which had to be declared by hand in `.tama/violations-ignore`.
//!     YAML is the third reading of it: `wisent-products` keeps the product
//!     catalogue every other product reads in one `catalog/products.yml`, 1652
//!     lines of records with a loader that reads the document whole, and the
//!     copy the wheel ships is derived from it by the product's own command.
//!     Splitting either breaks its reader exactly as splitting a registry does.
//!   * A drawing is one picture, not a module tree. An `.svg` is markup a
//!     renderer wrote: the README banner every repository carries is
//!     rendered whole from `.github/banner.toml` on each run, and several
//!     repositories had to declare that one file by hand before this.
//!     "Split into smaller modules" is not an instruction anyone can follow
//!     for a picture.
//!   * A manuscript is one document, not a module tree. Its length is set by
//!     the venue, a person navigates it by `\section`, and the bibliography
//!     and style files beside it are data the venue supplies ("do it in a way
//!     where the 300-line and 5-files-per-folder hooks do not apply to .tex",
//!     2026-09-14).
//!   * A log is a recording of what a program did, one line per event, in
//!     the order the events happened. Nobody edits it and nothing imports
//!     it: `echo-web` carries five of them — `batch_classify.log`,
//!     `location-extraction.log`, `account-api-local.log` — and "split into
//!     smaller modules" would mean deciding which half of an afternoon to
//!     keep. Whether a log belongs in a repository at all is a different
//!     question, and it is not answered by the line count.
//!
//! A file the repository declared to the audit, with its reason beside it, is
//! exempt as well: a registry a loader reads whole stays editable, which it
//! was not while the declaration was read by the scanner alone.
//!
//! Every other rule still applies to those files: the folder file limit, the
//! new-file justification, the content gates.

use tama_hooks::session_record::{deny_tool_use, read_payload};

use crate::ports::violations_declarations::file_is_declared;
use crate::ports::write_payload::{echoed_lines, file_lines, WritePayload};

mod patch;

/// `MAX_LINES=300` in the shell.
const MAX_LINES_TEXT: &str = "300";
/// Structured data and the LaTeX family, matched case-insensitively. Public
/// because the fleet scanner's fast pass has to answer exactly as this hook
/// does, and a second copy of the list is a second answer waiting to drift.
pub const EXEMPT_SUFFIXES: &[&str] = &[
    ".json", ".jsonl", ".ndjson", ".toml", ".yml", ".yaml", ".lock", ".csv", ".tsv", ".svg",
    ".tex", ".bib", ".sty", ".bst", ".cls", ".log",
];

/// A migration is one statement of what was applied, kept by the name the
/// database recorded. Splitting one rewrites history that already ran:
/// `wisent-supabase-echo` carries a 5711-line baseline snapshot and
/// `trading-tools` a 331-line stock-context migration, and neither can be
/// two files without inventing a second applied revision. The folder rule
/// already leaves a migrations directory alone; this is the same ruling
/// about the documents inside it.
const EXEMPT_FOLDERS: &[&str] = &["/migrations/", "/supabase/migrations/"];

fn max_lines() -> usize {
    MAX_LINES_TEXT.parse().unwrap_or_default()
}

/// Whether the line count leaves this path alone.
pub fn exempt(path: &str) -> bool {
    let lowered = path.to_lowercase();
    EXEMPT_SUFFIXES
        .iter()
        .any(|suffix| lowered.ends_with(suffix))
        || EXEMPT_FOLDERS.iter().any(|part| lowered.contains(part))
}

/// The refusal this write earns, if any.
pub fn check(payload: &serde_json::Value) -> Option<String> {
    let write = WritePayload::read(payload)?;
    if write.is_system || exempt(&write.file_path) || file_is_declared(&write.file_path) {
        return None;
    }
    if write.writes_whole_file() && !write.content.is_empty() {
        let lines = echoed_lines(&write.content);
        if lines > max_lines() {
            return Some(format!(
                "BLOCKED: File would be {lines} lines (max {}). Split into smaller modules.",
                max_lines()
            ));
        }
        return None;
    }
    if write.edits_in_place() && std::path::Path::new(&write.file_path).is_file() {
        let current = file_lines(&write.file_path);
        let old = write.old_string();
        let new = write.new_string();
        // One editor sends the two strings; this harness sends a patch. With
        // neither read, the arithmetic said "removes nothing, adds nothing"
        // and every edit to an oversized file was refused, deletions first.
        let (removed, added) = match (old.is_empty(), new.is_empty()) {
            (true, true) => match patch::measure(&write.content, &write.file_path) {
                Some(measured) => (measured.removed, measured.added),
                // A block operation's extent only a parser knows. The gate
                // does not invent a number: the whole-file write path is
                // exact, and `tama find-violations` reads the result.
                None => return None,
            },
            _ => (echoed_lines(&old), echoed_lines(&new)),
        };
        let result = current as i64 - removed as i64 + added as i64;
        if result > max_lines() as i64 {
            return Some(format!(
                "BLOCKED: File would be ~{result} lines after edit (max {}). Split into smaller \
                 modules.",
                max_lines()
            ));
        }
    }
    None
}

pub fn run() {
    if let Some(refusal) = check(&read_payload()) {
        deny_tool_use(&refusal);
    }
}
#[cfg(test)]
mod tests {
    use super::check;
    use serde_json::json;

    fn write(path: &str, lines: usize) -> serde_json::Value {
        let content = vec!["x"; lines].join("\n");
        json!({ "tool_name": "Write", "tool_input": { "file_path": path, "content": content } })
    }

    #[test]
    fn a_file_over_the_limit_is_refused_and_the_count_is_named() {
        let refusal = check(&write("/repo/src/main.rs", 301)).expect("over the limit");
        assert!(refusal.contains("301 lines"), "{refusal}");
        assert!(refusal.contains("max 300"), "{refusal}");
    }

    #[test]
    fn the_limit_itself_still_passes() {
        assert_eq!(check(&write("/repo/src/main.rs", 300)), None);
    }

    /// A registry is a list its readers parse whole, and a manuscript is one
    /// document; both are exempt on the operator's instruction. A rate table
    /// and a package manifest are the same thing in TOML: the fleet held two
    /// of each and had to declare them by hand.
    #[test]
    fn registries_and_manuscripts_are_exempt() {
        for path in [
            "/repo/data/file_justifications.json",
            "/repo/data/rows.CSV",
            "/repo/paper/main.tex",
            "/repo/paper/refs.bib",
            "/repo/tables/state-CA-2026.toml",
            "/repo/rust/crates/tama-hook-tools/Cargo.toml",
            "/repo/catalog/products.yml",
            "/repo/deploy/compose.YAML",
            "/repo/migrations/005_stado_stock_context.sql",
            "/repo/supabase/migrations/20260101000000_baseline.sql",
            "/repo/assets/readme-banner.svg",
            "/repo/batch_classify.log",
        ] {
            assert_eq!(check(&write(path, 5000)), None, "{path}");
        }
    }

    /// The exemption is the format, not the name: source that merely mentions
    /// a data extension is still source.
    #[test]
    fn source_named_after_a_data_format_is_still_refused() {
        for path in [
            "/repo/src/toml_reader.rs",
            "/repo/src/read.toml.ts",
            "/repo/src/tex.py",
        ] {
            assert!(check(&write(path, 301)).is_some(), "{path}");
        }
    }

    #[test]
    fn a_vendored_path_is_exempt() {
        assert_eq!(check(&write("/repo/node_modules/big/index.js", 9000)), None);
    }

    /// An edit is judged on the file it would leave behind, not on the size of
    /// the change: a big deletion from a big file is how a file gets smaller.
    #[test]
    fn an_edit_is_judged_on_the_result() {
        let missing = json!({
            "tool_name": "Edit",
            "tool_input": {
                "file_path": "/nonexistent/file.rs",
                "old_string": "a",
                "new_string": "b"
            }
        });
        assert_eq!(
            check(&missing),
            None,
            "a file that is not there has no size"
        );
    }
}
