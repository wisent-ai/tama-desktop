use std::collections::BTreeSet;
use std::fs;
use std::path::{Path, PathBuf};
use std::process::{Command, Output};
use std::time::{SystemTime, UNIX_EPOCH};

use serde_json::{json, Value};

struct ScratchHome {
    path: PathBuf,
}

impl ScratchHome {
    fn new() -> Self {
        let unique = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock before epoch")
            .as_nanos();
        let path = std::env::temp_dir().join(format!(
            "tama-enforcement-cli-{}-{unique}",
            std::process::id()
        ));
        fs::create_dir_all(&path).expect("create scratch home");
        Self { path }
    }

    fn state_path(&self) -> PathBuf {
        self.path
            .join("Library")
            .join("Application Support")
            .join("Tama")
            .join("hook-enforcement.json")
    }

    fn run(&self, root: &Path, args: &[&str]) -> Output {
        Command::new(env!("CARGO_BIN_EXE_tama-cli"))
            .args(args)
            .env("HOME", &self.path)
            .env("TAMA_ROOT", root)
            .env_remove("TAMA_HOOK_ENFORCEMENT")
            .env_remove("TAMA_EMERGENCY_STATE")
            .output()
            .expect("run tama-cli")
    }
}

impl Drop for ScratchHome {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.path);
    }
}

fn stdout(output: &Output) -> String {
    String::from_utf8(output.stdout.clone()).expect("stdout is UTF-8")
}

fn stderr(output: &Output) -> String {
    String::from_utf8(output.stderr.clone()).expect("stderr is UTF-8")
}

fn installed_hook_count(root: &Path) -> usize {
    let registry: Value = serde_json::from_str(
        &fs::read_to_string(root.join("shared-hooks/registry.json"))
            .expect("read installed registry"),
    )
    .expect("parse installed registry");
    ["agentHooks", "gitHooks"]
        .into_iter()
        .flat_map(|key| {
            registry["catalog"][key]
                .as_array()
                .expect("catalog array")
                .iter()
        })
        .filter_map(|hook| hook["id"].as_str())
        .collect::<BTreeSet<_>>()
        .len()
}

fn read_state(path: &Path) -> Value {
    serde_json::from_str(&fs::read_to_string(path).expect("read enforcement state"))
        .expect("parse enforcement state")
}

fn assert_success(output: &Output) {
    assert!(
        output.status.success(),
        "command failed\nstdout:\n{}\nstderr:\n{}",
        stdout(output),
        stderr(output)
    );
}

#[test]
fn real_binary_controls_machine_enforcement_selection() {
    let root = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../../..");
    let home = ScratchHome::new();
    let state_path = home.state_path();
    let known_count = installed_hook_count(&root);

    let initial = home.run(&root, &["enforcement", "status"]);
    assert_success(&initial);
    assert_eq!(stderr(&initial), "");
    assert_eq!(
        stdout(&initial),
        format!(
            "mode: all\nselected hooks: {known_count}/{known_count} installed\nselected ids: all installed hooks\nemergency disabled: false\n"
        )
    );
    assert!(!state_path.exists(), "status must not create state");
    fs::create_dir_all(state_path.parent().expect("state parent")).expect("create state directory");
    fs::write(&state_path, b"{ malformed").expect("write malformed state");
    let malformed = home.run(&root, &["enforcement", "status"]);
    assert_eq!(malformed.status.code(), Some(1));
    assert_eq!(stdout(&malformed), stdout(&initial));
    assert!(stderr(&malformed)
        .starts_with("Tama could not read the machine enforcement selection: invalid "));
    assert!(stderr(&malformed).ends_with(". Falling back to all hooks.\n"));
    fs::remove_file(&state_path).expect("remove malformed state");

    let unknown_id = "not-an-installed-tama-hook";
    let unknown = home.run(&root, &["enforcement", "only", unknown_id]);
    assert_eq!(unknown.status.code(), Some(1));
    assert_eq!(stdout(&unknown), "");
    assert_eq!(
        stderr(&unknown),
        format!(
            "Unknown hook id '{unknown_id}'; the installed registry declares {known_count} hook ids, and the enforcement selection was not changed.\n"
        )
    );
    assert!(!state_path.exists(), "refusal must not write state");

    let selected = ["block-inline-execution", "pre-write-edit"];
    let chosen = selected.len();
    let only = home.run(&root, &["enforcement", "only", selected[0], selected[1]]);
    assert_success(&only);
    assert_eq!(stderr(&only), "");
    assert_eq!(
        stdout(&only),
        format!(
            "Machine enforcement selection saved.\nmode: only\nselected hooks: {chosen}/{known_count} installed\nselected ids: {}, {}\nemergency disabled: false\n",
            selected[0], selected[1]
        )
    );
    let only_state = read_state(&state_path);
    assert_eq!(only_state["schema"], "ai.wisent.tama.hook-enforcement.v1");
    assert_eq!(only_state["mode"], "only");
    assert_eq!(only_state["enabled"], json!(selected));
    assert_eq!(
        only_state["previous"],
        json!({ "mode": "all", "enabled": [] })
    );
    assert!(
        only_state["changedAt"]
            .as_str()
            .is_some_and(|value| !value.is_empty()),
        "only must record changedAt"
    );
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        assert_eq!(
            fs::metadata(&state_path)
                .expect("state metadata")
                .permissions()
                .mode()
                & 0o777,
            0o600
        );
    }

    let selected_status = home.run(&root, &["enforcement", "status", "--json"]);
    assert_success(&selected_status);
    assert_eq!(stderr(&selected_status), "");
    let selected_json: Value =
        serde_json::from_str(&stdout(&selected_status)).expect("parse status JSON");
    assert_eq!(
        selected_json,
        json!({
            "mode": "only",
            "enabled": selected,
            "selectedHookCount": chosen,
            "installedHookCount": known_count,
            "emergencyDisabled": false
        })
    );
    assert_eq!(
        read_state(&state_path),
        only_state,
        "status must not mutate state"
    );
    let emergency_path = state_path.with_file_name("hook-emergency-state.json");
    fs::write(
        &emergency_path,
        serde_json::to_vec(&json!({
            "schema": "ai.wisent.tama.hook-emergency-state.v1",
            "disabled": true,
            "changedAt": "2026-09-06T12:00:00.000000+00:00"
        }))
        .expect("serialize emergency state"),
    )
    .expect("write emergency state");
    let emergency_status = home.run(&root, &["enforcement", "status", "--json"]);
    assert_success(&emergency_status);
    let mut emergency_json = selected_json.clone();
    emergency_json["emergencyDisabled"] = json!(true);
    assert_eq!(
        serde_json::from_str::<Value>(&stdout(&emergency_status))
            .expect("parse emergency status JSON"),
        emergency_json
    );

    let scratch_home = home.path.to_str().expect("scratch home is UTF-8");
    let sessions_json = home.run(&root, &["sessions", "--json", "--home", scratch_home]);
    assert_success(&sessions_json);
    assert_eq!(
        serde_json::from_str::<Value>(&stdout(&sessions_json)).expect("parse sessions JSON"),
        json!({
            "machineEnforcement": emergency_json,
            "sessions": []
        })
    );
    let sessions_text = home.run(&root, &["sessions", "--home", scratch_home]);
    assert_success(&sessions_text);
    assert_eq!(
        stdout(&sessions_text),
        format!(
            "machine enforcement\tmode=only\tselected={chosen}/{known_count}\tids={}, {}\temergency-disabled=true\nsession records\t0\trunning=0\tgone=0\tno-usable-pid=0\tno-runtime-report=0\n",
            selected[0], selected[1]
        )
    );
    fs::remove_file(&emergency_path).expect("remove emergency state");
    assert_eq!(
        read_state(&state_path),
        only_state,
        "inspection must not mutate state"
    );

    let all = home.run(&root, &["enforcement", "all"]);
    assert_success(&all);
    assert_eq!(stderr(&all), "");
    assert_eq!(
        stdout(&all),
        format!(
            "Machine enforcement selection cleared; all {known_count} installed hooks are selected.\nmode: all\nselected hooks: {known_count}/{known_count} installed\nselected ids: all installed hooks\nemergency disabled: false\n"
        )
    );
    let all_state = read_state(&state_path);
    assert_eq!(all_state["schema"], "ai.wisent.tama.hook-enforcement.v1");
    assert_eq!(all_state["mode"], "all");
    assert_eq!(all_state["enabled"], json!([]));
    assert_eq!(
        all_state["previous"],
        json!({ "mode": "only", "enabled": selected })
    );
    assert!(
        all_state["changedAt"]
            .as_str()
            .is_some_and(|value| !value.is_empty()),
        "all must record changedAt"
    );
}

/// Reading a listing through `head` is how an operator reads one. Rust ignores
/// `SIGPIPE`, so the first write after the reader closed panicked and printed a
/// Rust panic plus a backtrace note over the answer - observed on 2026-09-11
/// while reading a status through `head`. The reader here exits before the
/// listing is even loaded, which is the same closed pipe with no timing in it.
#[test]
fn a_reader_that_closes_early_gets_no_panic() {
    let home = ScratchHome::new();
    let root = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../../..");

    let piped = Command::new("sh")
        .arg("-c")
        .arg(format!(
            "{} list | true",
            shell_quoted(env!("CARGO_BIN_EXE_tama-cli"))
        ))
        .env("HOME", &home.path)
        .env("TAMA_ROOT", &root)
        .output()
        .expect("run tama-cli through a closing reader");

    let said = stderr(&piped);
    assert!(
        !said.contains("panicked") && !said.contains("backtrace"),
        "a closed reader is not a crash: {said}"
    );
    assert_eq!(
        stdout(&piped),
        "",
        "the reader took nothing, so nothing reaches this side"
    );
}

fn shell_quoted(path: &str) -> String {
    format!("'{}'", path.replace('\'', "'\\''"))
}
