//! Select original user text, never an assistant quote or a tool result.

use std::fs::{self, File};
use std::io::{BufRead, BufReader};
use std::path::PathBuf;

use serde_json::Value;
use tama_hook_tools::ports::transport_common;

pub(super) fn select(session: &str, needle: &str) -> Result<String, String> {
    let root = transport_common::session_root();
    let mut matches = Vec::new();
    for path in paths(session)? {
        let file = File::open(&path)
            .map_err(|error| format!("cannot read {}: {error}", path.display()))?;
        for line in BufReader::new(file).lines() {
            let line = line.map_err(|error| format!("cannot read {}: {error}", path.display()))?;
            let Ok(value) = serde_json::from_str::<Value>(&line) else {
                continue;
            };
            let message = if value.get("type").and_then(Value::as_str) == Some("message") {
                value.get("message").unwrap_or(&Value::Null)
            } else {
                &value
            };
            if message.get("role").and_then(Value::as_str) != Some("user") {
                continue;
            }
            let text = match message.get("content") {
                Some(Value::String(text)) => text.clone(),
                Some(Value::Array(blocks)) => blocks
                    .iter()
                    .filter(|block| block.get("type").and_then(Value::as_str) == Some("text"))
                    .filter_map(|block| block.get("text").and_then(Value::as_str))
                    .collect::<Vec<_>>()
                    .join("\n"),
                _ => continue,
            };
            if text.contains(needle) && !matches.contains(&text) {
                matches.push(text);
            }
        }
    }
    match matches.len() {
        0 => Err(format!("no direct user message matches {needle:?} in OMP session {session} under {}", root.display())),
        1 => Ok(matches.remove(0)),
        count => Err(format!("{count} distinct user messages match {needle:?} in OMP session {session}; use a more specific quoteMatch or an exact quote")),
    }
}

fn paths(session: &str) -> Result<Vec<PathBuf>, String> {
    let mut pending = vec![transport_common::session_root()];
    let mut found = Vec::new();
    while let Some(directory) = pending.pop() {
        let entries = fs::read_dir(&directory).map_err(|error| {
            format!(
                "cannot read session directory {}: {error}",
                directory.display()
            )
        })?;
        for entry in entries {
            let entry =
                entry.map_err(|error| format!("cannot read {}: {error}", directory.display()))?;
            let kind = entry.file_type().map_err(|error| error.to_string())?;
            if kind.is_dir() {
                pending.push(entry.path());
            } else if kind.is_file() {
                let name = entry.file_name();
                let name = name.to_string_lossy();
                if name.contains(session) && name.ends_with(".jsonl") {
                    found.push(entry.path());
                }
            }
        }
    }
    Ok(found)
}
