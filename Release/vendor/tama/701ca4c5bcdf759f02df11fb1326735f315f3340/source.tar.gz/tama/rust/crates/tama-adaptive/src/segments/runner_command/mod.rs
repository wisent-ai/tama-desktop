//! Port of `src/adaptive/segments/runner-command.mjs`: payload parsing and
//! the `/bin/sh -lc` command runner, which waits for what it started.

mod verdict;

pub use verdict::{crash_reason, decision_from_output, extname, js_number_string};

use std::io::{Read, Write};
use std::os::unix::process::CommandExt;
use std::process::{Command, Stdio};
use std::sync::{Arc, Mutex};
use std::time::Instant;

use crate::util::home_dir;

extern "C" {
    fn setsid() -> i32;
}

/// A registry hook as the runner helpers see it (`hook.id/.command`).
#[derive(Debug, Clone)]
pub struct HookSpec {
    /// Raw `id` JSON value (kept verbatim for result frames); `Null` when the
    /// key is absent, matching `undefined` in JS result objects.
    pub id: serde_json::Value,
    pub command: String,
}

impl HookSpec {
    /// Template-literal rendering of `hook.id` (`${hook.id}`).
    pub fn id_text(&self) -> String {
        if self.id.is_null() {
            "undefined".to_string()
        } else {
            crate::util::js_string(&self.id)
        }
    }
}

/// `expandHome(command)`: `~` before `/` or end, plus every `$HOME`.
pub fn expand_home(command: &str) -> String {
    let home = home_dir().to_string_lossy().to_string();
    let mut out = String::with_capacity(command.len());
    let chars: Vec<char> = command.chars().collect();
    let mut index = 0;
    while index < chars.len() {
        let c = chars[index];
        if c == '~' && (index + 1 == chars.len() || chars[index + 1] == '/') {
            out.push_str(&home);
            index += 1;
        } else if c == '$' && chars[index..].starts_with(&['$', 'H', 'O', 'M', 'E']) {
            out.push_str(&home);
            index += 5;
        } else {
            out.push(c);
            index += 1;
        }
    }
    out
}

/// `stdinText()` — all of stdin as utf8.
pub fn stdin_text() -> String {
    let mut buffer = Vec::new();
    let _ = std::io::stdin().read_to_end(&mut buffer);
    String::from_utf8_lossy(&buffer).to_string()
}

/// `parsePayload(text)`.
pub fn parse_payload(text: &str) -> serde_json::Value {
    if text.trim().is_empty() {
        return serde_json::json!({});
    }
    match serde_json::from_str::<serde_json::Value>(text) {
        Ok(value) => value,
        Err(_) => serde_json::json!({ "raw": text }),
    }
}

/// Result of `runCommand`.
#[derive(Debug, Clone)]
pub struct CommandResult {
    pub ms: u64,
    pub code: Option<i32>,
    pub signal: Option<String>,
    pub stdout: String,
    pub stderr: String,
    pub spawn_error: Option<String>,
}

/// Run one hook command under `/bin/sh -lc` and wait for it.
///
/// It used to be killed when a per-hook budget ran out — SIGTERM to the
/// process group, a grace, SIGKILL — and the event was then decided as if
/// the hook had refused. The budget was a guess; the hook's own answer is
/// not. What a run costs is reported in `ms`, and that is what a slow gate is
/// found by.
pub fn run_command(command: &str, input: &str) -> CommandResult {
    let started = Instant::now();
    let elapsed_ms = move || started.elapsed().as_millis() as u64;
    let expanded = expand_home(command);
    let spawned = unsafe {
        Command::new("/bin/sh")
            .args(["-lc", &expanded])
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .pre_exec(|| {
                // `detached: true` — own process group for group kills.
                setsid();
                Ok(())
            })
            .spawn()
    };
    let mut child = match spawned {
        Ok(child) => child,
        Err(error) => {
            return CommandResult {
                ms: elapsed_ms(),
                code: None,
                signal: None,
                stdout: String::new(),
                stderr: String::new(),
                spawn_error: Some(format!("Error: {}", error)),
            }
        }
    };
    if let Some(mut stdin) = child.stdin.take() {
        let input = input.to_string();
        std::thread::spawn(move || {
            let _ = stdin.write_all(input.as_bytes());
        });
    }
    let stdout_buf = Arc::new(Mutex::new(String::new()));
    let stderr_buf = Arc::new(Mutex::new(String::new()));
    fn spawn_reader(
        mut pipe: impl Read + Send + 'static,
        buf: Arc<Mutex<String>>,
    ) -> std::thread::JoinHandle<()> {
        std::thread::spawn(move || {
            let mut chunk = [0u8; 8192];
            loop {
                match pipe.read(&mut chunk) {
                    Ok(0) | Err(_) => break,
                    Ok(n) => {
                        buf.lock()
                            .unwrap()
                            .push_str(&String::from_utf8_lossy(&chunk[..n]));
                    }
                }
            }
        })
    }
    let mut readers = Vec::new();
    if let Some(pipe) = child.stdout.take() {
        readers.push(spawn_reader(pipe, Arc::clone(&stdout_buf)));
    }
    if let Some(pipe) = child.stderr.take() {
        readers.push(spawn_reader(pipe, Arc::clone(&stderr_buf)));
    }
    let status = child.wait().ok();
    let snapshot = |buf: &Arc<Mutex<String>>| buf.lock().unwrap().clone();
    for reader in readers {
        let _ = reader.join();
    }
    let (code, signal) = match status {
        Some(exit) => decode_exit(exit),
        None => (None, None),
    };
    CommandResult {
        ms: elapsed_ms(),
        code,
        signal,
        stdout: snapshot(&stdout_buf),
        stderr: snapshot(&stderr_buf),
        spawn_error: None,
    }
}

/// Decode an exit status into (code, signal-name) like Node's `close`.
fn decode_exit(exit: std::process::ExitStatus) -> (Option<i32>, Option<String>) {
    use std::os::unix::process::ExitStatusExt;
    if let Some(code) = exit.code() {
        return (Some(code), None);
    }
    let name = exit.signal().map(|sig| match sig {
        1 => "SIGHUP".to_string(),
        2 => "SIGINT".to_string(),
        3 => "SIGQUIT".to_string(),
        6 => "SIGABRT".to_string(),
        9 => "SIGKILL".to_string(),
        13 => "SIGPIPE".to_string(),
        14 => "SIGALRM".to_string(),
        15 => "SIGTERM".to_string(),
        other => format!("SIG{}", other),
    });
    (None, name)
}
