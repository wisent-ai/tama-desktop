//! JS `buildRequiredCoverage(root)` and `summarizeCoverage(...)`: the
//! mappings a live run must exercise, and what a run passed or missed.
//!
//! Moved verbatim out of the single runtime file; the adapter reading now
//! comes from the [`crate::runtime::adapter_config`] module.

use std::collections::{BTreeMap, HashSet};
use std::path::Path;

use serde::Serialize;
use serde_json::Value;

use crate::registry::OrderedMap;
use crate::runtime::adapter_config::{adapter_command_index, AdapterCommandIndex};
use crate::runtime::claims::{
    claimed_runtime_specs_for_event, coverage_key, runtime_actually_installs_hook,
};
use crate::runtime::{js_str, js_truthy, load_registry};
use crate::Result;

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct RuntimeCoverage {
    pub runtime: String,
    pub event: String,
    pub runtime_event: String,
    pub hook_id: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub command: Option<String>,
    pub coverage_key: String,
}

/// Git entry of `buildRequiredCoverage`. Optional fields use
/// `Option<Value>`: a key present with JSON `null` is kept as `null`
/// (as `JSON.stringify` would), only an absent key is dropped.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct GitCoverage {
    pub runtime: String,
    pub event: String,
    pub hook_id: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub source: Option<Value>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub repo: Option<Value>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub hooks_path: Option<Value>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub scope: Option<Value>,
    pub coverage_key: String,
}

/// One entry of JS `buildRequiredCoverage(root)` (untagged: the two variants
/// have different key sets, exactly as in JS).
#[derive(Debug, Clone, Serialize)]
#[serde(untagged)]
pub enum RequiredCoverage {
    Runtime(RuntimeCoverage),
    Git(GitCoverage),
}

impl RequiredCoverage {
    pub fn coverage_key(&self) -> &str {
        match self {
            RequiredCoverage::Runtime(entry) => &entry.coverage_key,
            RequiredCoverage::Git(entry) => &entry.coverage_key,
        }
    }

    pub fn runtime(&self) -> &str {
        match self {
            RequiredCoverage::Runtime(entry) => &entry.runtime,
            RequiredCoverage::Git(entry) => &entry.runtime,
        }
    }

    pub fn event(&self) -> &str {
        match self {
            RequiredCoverage::Runtime(entry) => &entry.event,
            RequiredCoverage::Git(entry) => &entry.event,
        }
    }
}

/// JS `buildRequiredCoverage(root)`, sorted by `coverageKey`.
pub fn build_required_coverage(root: &Path) -> Result<Vec<RequiredCoverage>> {
    let registry = load_registry(root)?;
    let mut adapter_commands: BTreeMap<String, AdapterCommandIndex> = BTreeMap::new();
    adapter_commands.insert(
        "codex".to_string(),
        adapter_command_index(&registry, "codex")?,
    );
    adapter_commands.insert(
        "claude".to_string(),
        adapter_command_index(&registry, "claude")?,
    );
    let mut required: Vec<RequiredCoverage> = Vec::new();
    for (event, config) in &registry.events {
        for hook in &config.hooks {
            for spec in claimed_runtime_specs_for_event(event, Some(&registry)) {
                if !runtime_actually_installs_hook(
                    &adapter_commands,
                    &spec,
                    &hook.id,
                    hook.command.as_deref(),
                    Some(&registry),
                ) {
                    continue;
                }
                let runtime_event = spec.runtime_event.clone().unwrap_or_default();
                required.push(RequiredCoverage::Runtime(RuntimeCoverage {
                    runtime: spec.runtime.clone(),
                    event: event.clone(),
                    runtime_event: runtime_event.clone(),
                    hook_id: hook.id.clone(),
                    command: hook.command.clone(),
                    coverage_key: coverage_key(&spec.runtime, event, &hook.id, &runtime_event),
                }));
            }
        }
    }
    let empty: Vec<Value> = Vec::new();
    let git_hooks = registry
        .extra
        .get("catalog")
        .and_then(|c| c.get("gitHooks"))
        .and_then(Value::as_array)
        .unwrap_or(&empty);
    for hook in git_hooks {
        // JS: `hook.event || hook.id`
        let raw_event = hook.get("event");
        let event = if js_truthy(raw_event) {
            js_str(raw_event)
        } else {
            js_str(hook.get("id"))
        };
        let hook_id = js_str(hook.get("id"));
        required.push(RequiredCoverage::Git(GitCoverage {
            runtime: "git".to_string(),
            event: event.clone(),
            hook_id: hook_id.clone(),
            source: hook.get("source").cloned(),
            repo: hook.get("repo").cloned(),
            hooks_path: hook.get("hooksPath").cloned(),
            scope: hook.get("scope").cloned(),
            coverage_key: format!("git:{event}:{hook_id}"),
        }));
    }
    // JS `.sort((a, b) => a.coverageKey.localeCompare(b.coverageKey))` is a
    // stable sort; `sort_by` is stable too.
    required.sort_by(|a, b| a.coverage_key().cmp(b.coverage_key()));
    Ok(required)
}

/// Result of JS `summarizeCoverage(required, passedCoverageKeys)`.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CoverageSummary {
    pub required_count: usize,
    pub passed_count: usize,
    pub missing_count: usize,
    pub missing_by_runtime: OrderedMap<usize>,
    pub missing_by_event: OrderedMap<usize>,
    pub missing: Vec<RequiredCoverage>,
}

/// JS `summarizeCoverage(required, passedCoverageKeys)`. The `countBy` maps
/// preserve first-seen key order like JS objects.
pub fn summarize_coverage(
    required: &[RequiredCoverage],
    passed_coverage_keys: &[String],
) -> CoverageSummary {
    let passed: HashSet<&str> = passed_coverage_keys.iter().map(String::as_str).collect();
    let missing: Vec<RequiredCoverage> = required
        .iter()
        .filter(|item| !passed.contains(item.coverage_key()))
        .cloned()
        .collect();
    let mut missing_by_runtime = OrderedMap::new();
    let mut missing_by_event = OrderedMap::new();
    for item in &missing {
        // JS `countBy`: `item[key] || '<unknown>'`; runtime/event are always
        // non-empty strings in these entries.
        missing_by_runtime.increment(item.runtime());
        missing_by_event.increment(item.event());
    }
    CoverageSummary {
        required_count: required.len(),
        passed_count: required.len() - missing.len(),
        missing_count: missing.len(),
        missing_by_runtime,
        missing_by_event,
        missing,
    }
}
