//! `tama-block-keyword-literals`, driven as the real binary with a write
//! payload on stdin under a scratch home. The operator, 2026-09-19: "to dodaj
//! do tamy hook ktory blokuje jakikolweik uzycie keywordsow albo czegokolwiek
//! hardcodowanego". A list of words in code is refused naming the words; the
//! same list passes once a `keyword-provenance.json` above the file declares
//! them; prose files are not judged; a provenance file whose quote no real
//! operator message contains is refused.

use std::fs;
use std::io::Write;
use std::path::{Path, PathBuf};
use std::process::{Command, Output, Stdio};
use std::time::{SystemTime, UNIX_EPOCH};

use serde_json::json;

const GUARD: &str = env!("CARGO_BIN_EXE_tama-block-keyword-literals");
const WORD_LIST: &str = "static ACKS: &[&str] = &[\"ok\", \"okej\", \"zrobione\"];\n";

fn scratch() -> PathBuf {
    let nonce = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .expect("clock after epoch")
        .as_nanos();
    let thread = format!("{:?}", std::thread::current().id()).replace(['(', ')'], "-");
    let home =
        PathBuf::from(env!("CARGO_TARGET_TMPDIR")).join(format!("tama-keywords-{thread}{nonce}"));
    fs::create_dir_all(home.join("repo/src")).expect("create the scratch repository");
    home
}

fn drive(home: &Path, path: &Path, content: &str) -> Output {
    let payload =
        json!({ "tool_name": "write", "tool_input": { "path": path, "content": content } });
    let mut child = Command::new(GUARD)
        .env("HOME", home)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .unwrap_or_else(|error| panic!("spawn the guard: {error}"));
    child
        .stdin
        .as_mut()
        .expect("guard stdin")
        .write_all(payload.to_string().as_bytes())
        .expect("write payload");
    child.wait_with_output().expect("guard output")
}

/// A PreToolUse denial is the banner on stderr with a non-zero exit;
/// `None` when the write was let through.
fn refusal(output: &Output) -> Option<String> {
    if output.status.success() {
        return None;
    }
    Some(String::from_utf8_lossy(&output.stderr).into_owned())
}

#[test]
fn a_list_of_words_in_a_code_file_is_refused_naming_the_words() {
    let home = scratch();
    let output = drive(&home, &home.join("repo/src/words.rs"), WORD_LIST);
    let reason = refusal(&output).expect("refused");
    assert!(
        reason.contains("keyword list is a classifier nobody asked for"),
        "{reason}"
    );
    assert!(
        reason.contains("undeclared: \"ok\", \"okej\", \"zrobione\""),
        "{reason}"
    );
    assert!(reason.contains("words.rs:"), "{reason}");
}

#[test]
fn the_same_list_passes_once_the_repository_declares_the_words() {
    let home = scratch();
    let words: Vec<&str> = "ok okej zrobione".split(' ').collect();
    fs::write(
        home.join("repo/keyword-provenance.json"),
        json!({ "acks": { "words": words,
            "user_said": "ok, okej albo zrobione znaczy, ze zadanie jest przyjete" } })
        .to_string(),
    )
    .expect("write the provenance");
    let output = drive(&home, &home.join("repo/src/words.rs"), WORD_LIST);
    assert_eq!(
        refusal(&output),
        None,
        "{}",
        String::from_utf8_lossy(&output.stdout)
    );
}

#[test]
fn a_prose_file_with_the_same_words_is_not_judged() {
    let home = scratch();
    let output = drive(&home, &home.join("repo/README.md"), WORD_LIST);
    assert_eq!(
        refusal(&output),
        None,
        "{}",
        String::from_utf8_lossy(&output.stdout)
    );
}

#[test]
fn code_that_came_from_somewhere_else_is_not_ours_to_judge() {
    let home = scratch();
    for borrowed in [
        "repo/vendor/axe-core/axe.js",
        "repo/node_modules/left-pad/index.js",
        "repo/vendor/axe-core/axe.min.js",
    ] {
        let path = home.join(borrowed);
        fs::create_dir_all(path.parent().expect("a parent directory"))
            .expect("create the borrowed tree");
        let output = drive(&home, &path, WORD_LIST);
        assert_eq!(
            refusal(&output),
            None,
            "{borrowed}: {}",
            String::from_utf8_lossy(&output.stdout)
        );
    }
}

#[test]
fn a_swift_function_returning_a_command_line_is_not_a_classifier() {
    let home = scratch();
    let output = drive(
        &home,
        &home.join("repo/src/HostPaths.swift"),
        "    nonisolated static func listArguments(host: String) -> [String] {\n\
         \x20       [\"registry\", \"host\", \"path\", \"list\", host, \"--json\"]\n    }\n",
    );
    assert_eq!(
        refusal(&output),
        None,
        "{}",
        String::from_utf8_lossy(&output.stdout)
    );
}

#[test]
fn words_handed_to_a_call_are_that_call_s_arguments_not_a_classifier() {
    let home = scratch();
    let output = drive(
        &home,
        &home.join("repo/src/journey.rs"),
        "let out = run(&[\"transcripts\", \"tasks\", \"show\"]);\n",
    );
    assert_eq!(
        refusal(&output),
        None,
        "{}",
        String::from_utf8_lossy(&output.stdout)
    );
}

#[test]
fn words_inside_an_options_object_of_a_call_are_arguments_too() {
    let home = scratch();
    let output = drive(
        &home,
        &home.join("repo/src/spawn.ts"),
        "const child = spawn(bin, args, { stdio: ['ignore', 'pipe', 'pipe'] });\n",
    );
    assert_eq!(
        refusal(&output),
        None,
        "{}",
        String::from_utf8_lossy(&output.stdout)
    );
}

#[test]
fn a_table_of_words_in_an_object_the_program_keeps_is_still_refused() {
    let home = scratch();
    let output = drive(
        &home,
        &home.join("repo/src/table.ts"),
        "const MARKERS = { name: 'acks', words: ['ok', 'okej', 'zrobione'] };\n",
    );
    let reason = refusal(&output).expect("refused");
    assert!(
        reason.contains("undeclared: \"ok\", \"okej\", \"zrobione\""),
        "{reason}"
    );
}

#[test]
fn a_command_line_a_function_hands_back_is_not_a_classifier() {
    let home = scratch();
    let output = drive(
        &home,
        &home.join("repo/src/arguments.rs"),
        "fn list_arguments(host: &str) -> Vec<String> {\n    \
         vec![\"registry\".into(), \"host\".into(), \"path\".into(), \"list\".into()]\n}\n",
    );
    assert_eq!(
        refusal(&output),
        None,
        "{}",
        String::from_utf8_lossy(&output.stdout)
    );
}

#[test]
fn a_table_bound_inside_a_function_is_still_refused() {
    let home = scratch();
    let output = drive(
        &home,
        &home.join("repo/src/inside.rs"),
        "fn accepts(reply: &str) -> bool {\n    let markers = [\"ok\", \"okej\", \"zrobione\"];\n    \
         markers.contains(&reply)\n}\n",
    );
    let reason = refusal(&output).expect("refused");
    assert!(
        reason.contains("undeclared: \"ok\", \"okej\", \"zrobione\""),
        "{reason}"
    );
}

#[test]
fn words_asked_a_question_where_they_stand_are_still_refused() {
    let home = scratch();
    let output = drive(
        &home,
        &home.join("repo/src/inline.rs"),
        "if [\"ok\", \"okej\", \"zrobione\"].contains(&reply) { accept(); }\n",
    );
    let reason = refusal(&output).expect("refused");
    assert!(
        reason.contains("undeclared: \"ok\", \"okej\", \"zrobione\""),
        "{reason}"
    );
}

#[test]
fn a_provenance_file_whose_quote_no_operator_message_holds_is_refused() {
    let home = scratch();
    let document =
        json!({ "acks": { "words": ["ok"], "user_said": "a sentence nobody ever typed here" } });
    let output = drive(
        &home,
        &home.join("repo/keyword-provenance.json"),
        &document.to_string(),
    );
    let reason = refusal(&output).expect("refused");
    assert!(
        reason.contains("quote not found in any real user message"),
        "{reason}"
    );
}
