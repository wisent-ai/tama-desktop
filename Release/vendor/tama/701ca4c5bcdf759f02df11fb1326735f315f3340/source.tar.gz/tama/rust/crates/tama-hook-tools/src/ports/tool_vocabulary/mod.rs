//! The harness payload's own vocabulary, declared once.
//!
//! A guard reads a tool call out of a JSON payload, and the names of the
//! fields it reads are the harness's, not English: `command`, `cmd`,
//! `tool_input`, `bash`, `functions.bash`. Until 2026-09-19 each guard
//! carried its own copy — thirteen of `["command", "cmd"]`, four of the
//! bash/eval/hub triple — so a harness that renamed a field would leave
//! some guards reading it and some blind, with nothing to say which.
//!
//! The operator asked that day where keyword logic decides things and how
//! it should be repaired. This is the answer for the half that is not
//! language at all: one declaration, read by every guard, so the set is a
//! fact about the harness rather than thirteen opinions about it.
//!
//! Only the spellings that were already identical everywhere live here. A
//! guard whose list differs on purpose — `block_unauthorized_ssh_detect`
//! also reads `code`, because an eval payload carries its program there —
//! keeps its own and says why.

/// Where a shell line sits in a payload, in both spellings the harnesses use.
pub const COMMAND_KEYS: &[&str] = &["command", "cmd"];

/// Where the arguments of a tool call sit.
pub const INPUT_KEYS: &[&str] = &["tool_input", "input"];

/// The arguments key on its own, for a payload shape that has only one.
pub const TOOL_INPUT_KEY: &str = "tool_input";

/// The shell tool, plainly and through the function bridge.
pub const BASH_TOOLS: &[&str] = &["bash", "functions.bash"];

/// The evaluation tools: the harness's own, the bridge, and the REPL device
/// that runs the same text.
pub const EVAL_TOOLS: &[&str] = &["eval", "functions.eval", "mcp__node_repl_js"];

/// The process-control tool, which starts programs.
pub const HUB_TOOLS: &[&str] = &["hub", "functions.hub"];
