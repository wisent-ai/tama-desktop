//! What was already spent.
//!
//! The registry holds authorizations that are open right now, and `close`
//! removes them; a ration cannot be counted from a file that forgets. So every
//! recorded intent is also appended here, and this is what the day's count is
//! read from. Closing an entry ends the authorization and does not give the
//! build back.

use std::path::{Path, PathBuf};

use serde_json::{json, Value};

pub const FILE: &str = "build_restart_ledger.json";
/// Retention for ordinary intents. Approved exceptions remain as audit evidence
/// and prevent the same captured message from granting another exception.
const KEEP_SECONDS: u64 = 30 * 24 * 60 * 60;
const RECORDED: &str = "recorded";
const AT: &str = "recorded_at_epoch";

pub fn file(home: &Path) -> PathBuf {
    home.join(".shared-hooks").join(FILE)
}

fn rows(path: &Path) -> Result<Vec<Value>, String> {
    let text = match std::fs::read_to_string(path) {
        Ok(text) => text,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(Vec::new()),
        Err(error) => return Err(format!("{} cannot be read: {error}", path.display())),
    };
    if text.trim().is_empty() {
        return Ok(Vec::new());
    }
    let document: Value = serde_json::from_str(&text)
        .map_err(|error| format!("{} is not a readable ledger: {error}", path.display()))?;
    match document.get(RECORDED).and_then(Value::as_array) {
        Some(rows) => Ok(rows.clone()),
        None => Err(format!(
            "{} carries no {RECORDED} list, so nothing here says what was spent",
            path.display()
        )),
    }
}

fn moment(row: &Value) -> u64 {
    row.get(AT).and_then(Value::as_u64).unwrap_or_default()
}

/// Every intent of this kind recorded inside the window ending now.
pub fn spent(path: &Path, kind: &str, at: u64, window: u64) -> Result<Vec<Value>, String> {
    let since = at.saturating_sub(window);
    Ok(rows(path)?
        .into_iter()
        .filter(|row| row.get("kind").and_then(Value::as_str) == Some(kind))
        .filter(|row| moment(row) >= since)
        .collect())
}

/// The revision the last recorded build of this target carried, which is what
/// the next build's change is measured against.
pub fn last_revision(path: &Path, target: &str) -> Result<Option<String>, String> {
    let mut mine: Vec<Value> = rows(path)?
        .into_iter()
        .filter(|row| row.get("kind").and_then(Value::as_str) == Some("build"))
        .filter(|row| row.get("target").and_then(Value::as_str) == Some(target))
        .collect();
    mine.sort_by_key(moment);
    Ok(mine
        .last()
        .and_then(|row| row.get("revision"))
        .and_then(Value::as_str)
        .map(str::to_string))
}

/// One operator message may authorize a batch, but never a second build of
/// the same product. Closing the open registry entry does not erase consent use.
pub fn approval_used(path: &Path, approval: &Value) -> Result<bool, String> {
    Ok(rows(path)?.iter().any(|row| {
        row.get("user_approval").is_some_and(|used| {
            used.get("session_id") == approval.get("session_id")
                && used.get("turn_digest") == approval.get("turn_digest")
                && used.get("target") == approval.get("target")
        })
    }))
}

pub fn approvals(path: &Path) -> Result<Vec<Value>, String> {
    Ok(rows(path)?
        .into_iter()
        .filter(|row| row.get("user_approval").is_some())
        .collect())
}

/// Appends one spent intent and drops rows past the keeping period.
pub fn append(path: &Path, entry: &Value) -> Result<(), String> {
    let at = moment(entry);
    let mut kept: Vec<Value> = rows(path)?
        .into_iter()
        .filter(|row| row.get("user_approval").is_some() || moment(row) + KEEP_SECONDS >= at)
        .collect();
    kept.push(entry.clone());
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)
            .map_err(|error| format!("{} cannot be created: {error}", parent.display()))?;
    }
    let document = json!({ RECORDED: kept });
    let text = serde_json::to_string_pretty(&document)
        .map_err(|error| format!("cannot serialize build ledger: {error}"))?;
    crate::justify::registry::write_atomically(path, &format!("{text}\n"))
}

/// When enough recorded intents have left the inclusive window to admit one
/// more. A lowered limit or approved exceptions can leave more than the limit
/// in the window; expiration of only the oldest entry then frees no slot.
pub fn frees_in_minutes(spent: &mut [Value], allowed: u64, at: u64, window: u64) -> Option<u64> {
    if allowed == 0 {
        return None;
    }
    if (spent.len() as u64) < allowed {
        return Some(0);
    }
    let index = spent.len() - allowed as usize;
    let (_, last_to_expire, _) = spent.select_nth_unstable_by_key(index, moment);
    let available_at = moment(last_to_expire)
        .saturating_add(window)
        .saturating_add(1);
    Some(available_at.saturating_sub(at).div_ceil(60))
}

#[cfg(test)]
#[path = "../../../../../../tests/builds/ledger.rs"]
mod tests;
