//! The build and restart policy: how many builds a day, and how big a change
//! has to be to deserve one.
//!
//! The registry alone only asked for an intent to be written down, and an
//! agent writes one in a second. What produced ten releases in one evening was
//! not missing paperwork, it was a build per minimal change: edit two lines,
//! submit, wait forty minutes in the builder queue, read the failure, edit two
//! more. So the ration lives here, as data an operator owns, and the writer
//! refuses past it.
//!
//! Every limit has a value in code, so a machine with no policy file is still
//! rationed. Tightening a limit needs nothing. Loosening one — more builds a
//! day, a smaller change, a longer window — is a change to what the machine
//! permits, so it needs the same device approval every other hook
//! configuration needs.

pub use super::policy_revision::revise;
use std::path::{Path, PathBuf};

use serde_json::{json, Value};

pub const FILE: &str = "build_restart_policy.json";
/// The operator's number: three builds in a rolling day.
pub const DEFAULT_BUILDS_PER_DAY: u64 = 3;
/// A restart is cheaper than a build but not free: it drops work in flight.
pub const DEFAULT_RESTARTS_PER_DAY: u64 = 10;
/// Below this many changed lines a build is not a serious change. Two typos
/// and a version bump are under it; the identity kind that went into Skarbiec
/// 0.3.11 was eight hundred over it.
pub const DEFAULT_MINIMUM_CHANGED_LINES: u64 = 30;
/// How long one recorded intent authorizes, in minutes.
pub const DEFAULT_WINDOW_MINUTES: u64 = 60;
/// The ration window. A rolling day, not a calendar day, so the count cannot
/// be reset by waiting for midnight.
pub const WINDOW_SECONDS: u64 = 24 * 60 * 60;

pub const CONSENT_ENV: &str = "DEVICE_HOOK_EDIT_APPROVED";
pub const CONSENT_VALUE: &str = "1";

const BUILDS: &str = "builds_per_day";
const RESTARTS: &str = "restarts_per_day";
const LINES: &str = "minimum_changed_lines";
const WINDOW: &str = "window_minutes";

/// A limit, its value, and which direction is a loosening.
pub(super) struct Limit {
    pub(super) field: &'static str,
    pub(super) option: &'static str,
    pub(super) default: u64,
    /// `true` when a larger number permits more work.
    pub(super) larger_permits_more: bool,
}

pub(super) const LIMITS: [Limit; 4] = [
    Limit {
        field: BUILDS,
        option: "--builds-per-day",
        default: DEFAULT_BUILDS_PER_DAY,
        larger_permits_more: true,
    },
    Limit {
        field: RESTARTS,
        option: "--restarts-per-day",
        default: DEFAULT_RESTARTS_PER_DAY,
        larger_permits_more: true,
    },
    Limit {
        field: LINES,
        option: "--minimum-changed-lines",
        default: DEFAULT_MINIMUM_CHANGED_LINES,
        larger_permits_more: false,
    },
    Limit {
        field: WINDOW,
        option: "--window-minutes",
        default: DEFAULT_WINDOW_MINUTES,
        larger_permits_more: true,
    },
];

#[derive(Clone, Copy, Debug)]
pub struct Policy {
    pub builds_per_day: u64,
    pub restarts_per_day: u64,
    pub minimum_changed_lines: u64,
    pub window_minutes: u64,
}

impl Default for Policy {
    fn default() -> Self {
        Self {
            builds_per_day: DEFAULT_BUILDS_PER_DAY,
            restarts_per_day: DEFAULT_RESTARTS_PER_DAY,
            minimum_changed_lines: DEFAULT_MINIMUM_CHANGED_LINES,
            window_minutes: DEFAULT_WINDOW_MINUTES,
        }
    }
}

impl Policy {
    pub fn per_day(&self, kind: &str) -> u64 {
        if kind == "restart" {
            self.restarts_per_day
        } else {
            self.builds_per_day
        }
    }

    pub fn document(&self) -> Value {
        json!({
            BUILDS: self.builds_per_day,
            RESTARTS: self.restarts_per_day,
            LINES: self.minimum_changed_lines,
            WINDOW: self.window_minutes,
        })
    }

    pub fn sentence(&self) -> String {
        format!(
            "{} builds and {} restarts in any 24 hours; a build carries at least {} changed \
             lines; one recorded intent authorizes {} minutes",
            self.builds_per_day,
            self.restarts_per_day,
            self.minimum_changed_lines,
            self.window_minutes
        )
    }
}

pub fn file(home: &Path) -> PathBuf {
    home.join(".shared-hooks").join(FILE)
}

/// Reads the policy. A field the file does not carry keeps the limit written
/// in code, so the ration holds on a machine that has never been configured. A
/// malformed file is refused and named: a policy nobody can read is not a
/// policy, and running the limits in code while the operator's own numbers are
/// unreadable would hide that they are gone.
pub fn load(path: &Path) -> Result<Policy, String> {
    let text = match std::fs::read_to_string(path) {
        Ok(text) => text,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(Policy::default()),
        Err(error) => return Err(format!("{} cannot be read: {error}", path.display())),
    };
    if text.trim().is_empty() {
        return Ok(Policy::default());
    }
    let document: Value = serde_json::from_str(&text)
        .map_err(|error| format!("{} is not readable policy: {error}", path.display()))?;
    let read = |field: &str, in_code: u64| {
        document
            .get(field)
            .and_then(Value::as_u64)
            .unwrap_or(in_code)
    };
    let policy = Policy {
        builds_per_day: read(BUILDS, DEFAULT_BUILDS_PER_DAY),
        restarts_per_day: read(RESTARTS, DEFAULT_RESTARTS_PER_DAY),
        minimum_changed_lines: read(LINES, DEFAULT_MINIMUM_CHANGED_LINES),
        window_minutes: read(WINDOW, DEFAULT_WINDOW_MINUTES),
    };
    if policy.window_minutes == 0 {
        return Err(format!(
            "{} sets {WINDOW} to zero, which authorizes nothing",
            path.display()
        ));
    }
    Ok(policy)
}
#[cfg(test)]
mod tests {
    use super::{load, revise, Policy, DEFAULT_BUILDS_PER_DAY};

    fn scratch(label: &str) -> std::path::PathBuf {
        let unique = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .expect("the clock follows the epoch")
            .as_nanos();
        // Throwaway state belongs in this checkout's ignored target
        // directory, never in a system temporary directory.
        let scratch = concat!(env!("CARGO_MANIFEST_DIR"), "/../../target/scratch");
        let path = std::path::Path::new(scratch).join(format!("tama-policy-{label}-{unique:x}"));
        std::fs::create_dir_all(&path).expect("a scratch directory");
        path.join("policy.json")
    }

    #[test]
    fn a_machine_with_no_policy_file_is_still_rationed() {
        let path = scratch("absent");
        let policy = load(&path).expect("the limits in code");
        assert_eq!(policy.builds_per_day, DEFAULT_BUILDS_PER_DAY);
        assert_eq!(policy.per_day("build"), DEFAULT_BUILDS_PER_DAY);
        assert_eq!(
            policy.per_day("restart"),
            Policy::default().restarts_per_day
        );
    }

    #[test]
    fn a_malformed_policy_is_refused_and_named() {
        let path = scratch("malformed");
        std::fs::write(&path, "{ builds").expect("write");
        let refusal = load(&path).expect_err("a refusal");
        assert!(refusal.contains("not readable policy"), "{refusal}");
    }

    #[test]
    fn tightening_needs_no_approval_and_loosening_is_refused_by_name() {
        let path = scratch("revise");
        let tighter = revise(
            &path,
            &[String::from("--builds-per-day"), String::from("1")],
        )
        .expect("tightening");
        assert_eq!(tighter.0.builds_per_day, 1);
        assert_eq!(
            tighter.1,
            vec![String::from("builds_per_day tightened 3 -> 1")]
        );

        let refusal = revise(
            &path,
            &[String::from("--builds-per-day"), String::from("9")],
        )
        .expect_err("a refusal");
        assert!(refusal.contains("DEVICE_HOOK_EDIT_APPROVED=1"), "{refusal}");
        assert_eq!(load(&path).expect("unchanged").builds_per_day, 1);
    }

    #[test]
    fn a_smaller_minimum_change_is_a_loosening_too() {
        let path = scratch("lines");
        let refusal = revise(
            &path,
            &[String::from("--minimum-changed-lines"), String::from("1")],
        )
        .expect_err("a refusal");
        assert!(
            refusal.contains("--minimum-changed-lines from 30 to 1"),
            "{refusal}"
        );
    }
}
