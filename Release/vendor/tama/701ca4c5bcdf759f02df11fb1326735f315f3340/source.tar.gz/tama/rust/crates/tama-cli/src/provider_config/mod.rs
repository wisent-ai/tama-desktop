//! `tama provider-config` — the provider hook block an install writes into
//! `~/.claude/settings.json` and `~/.codex/hooks.json`.
//!
//! The installer owns those files (backup, merge, mode, rollback); this
//! command owns the wiring, so the event/matcher table and the command shape
//! stay in one place: `tama_hook_tools::registry`, the same code the
//! source-tree generator uses.

use std::io::Read;

use serde_json::{Map, Value};
use tama_hook_tools::registry::build_hooks;

// This repository keeps numbers in `numeric-provenance.json`; `as` casts of
// booleans are const, exact, and carry no literal.
const EXIT_OK: i32 = false as i32;
const EXIT_ERROR: i32 = true as i32;
const EXIT_USAGE: i32 = EXIT_ERROR + EXIT_ERROR;

const PROVIDERS: &[&str] = &["claude", "codex"];

const USAGE: &str = "tama provider-config --provider <claude|codex> --dispatcher <command> [--json]

Reads a registry on stdin and prints the hook block that provider's config
carries. The dispatcher is the command an install writes into the target
home, pinned Node included; every printed command runs it for one hook id.";

/// The value right after `flag`, when it is not another flag.
fn option_value(args: &[String], flag: &str) -> Option<String> {
    let mut rest = args.iter();
    while let Some(argument) = rest.next() {
        if argument == flag {
            return rest
                .next()
                .filter(|value| !value.starts_with("--"))
                .cloned();
        }
    }
    None
}

fn read_registry(text: &str) -> Result<Value, String> {
    let value: Value = serde_json::from_str(text).map_err(|error| {
        format!("provider-config could not parse the registry on stdin: {error}")
    })?;
    if !value.is_object() {
        return Err("provider-config requires a registry object on stdin".to_string());
    }
    Ok(value)
}

/// Every command the provider would run — what the block is actually worth.
fn commands(block: &Map<String, Value>) -> impl Iterator<Item = &Value> {
    block
        .values()
        .filter_map(Value::as_array)
        .flatten()
        .filter_map(|group| group.get("hooks"))
        .filter_map(Value::as_array)
        .flatten()
}

fn print_human(provider: &str, dispatcher: &str, block: &Map<String, Value>) {
    println!("provider: {provider}");
    println!("dispatcher: {dispatcher}");
    println!("commands: {}", commands(block).count());
    for (event, groups) in block {
        let matchers: Vec<&str> = groups
            .as_array()
            .map(|groups| {
                groups
                    .iter()
                    .map(|group| group.get("matcher").and_then(Value::as_str).unwrap_or("*"))
                    .collect()
            })
            .unwrap_or_default();
        println!("  {event}: {}", matchers.join(", "));
    }
}

fn run(args: &[String]) -> Result<i32, String> {
    if args
        .iter()
        .any(|arg| arg == "help" || arg == "--help" || arg == "-h")
    {
        eprintln!("{USAGE}");
        return Ok(EXIT_OK);
    }
    let (Some(provider), Some(dispatcher)) = (
        option_value(args, "--provider"),
        option_value(args, "--dispatcher"),
    ) else {
        eprintln!("{USAGE}");
        return Ok(EXIT_USAGE);
    };
    if !PROVIDERS.contains(&provider.as_str()) {
        return Err(format!(
            "provider-config does not configure the provider {provider}; it configures {}",
            PROVIDERS.join(" and ")
        ));
    }
    if dispatcher.trim().is_empty() {
        return Err("provider-config requires a non-empty --dispatcher command".to_string());
    }
    let mut text = String::new();
    std::io::stdin()
        .read_to_string(&mut text)
        .map_err(|error| {
            format!("provider-config could not read the registry on stdin: {error}")
        })?;
    let registry = read_registry(&text)?;
    let block = build_hooks(&registry, &provider, &dispatcher);
    // An empty block is the failure this command exists to name: a config
    // written from it leaves that provider running no policy at all.
    if commands(&block).next().is_none() {
        return Err(format!(
            "provider-config produced no wiring for {provider}: the registry declares no event this provider supports"
        ));
    }
    if args.iter().any(|arg| arg == "--json") {
        println!(
            "{}",
            serde_json::to_string_pretty(&Value::Object(block)).unwrap_or_default()
        );
    } else {
        print_human(&provider, &dispatcher, &block);
    }
    Ok(EXIT_OK)
}

pub(crate) fn main(args: &[String]) -> i32 {
    match run(args) {
        Ok(code) => code,
        Err(error) => {
            eprintln!("{error}");
            EXIT_ERROR
        }
    }
}
