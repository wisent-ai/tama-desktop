//! Scaffolding the ration's cases share: a disposable home, a real throwaway
//! repository, and the real `tama-cli` beside the gate binary.
//!
//! Throwaway state lives in this checkout's ignored target directory. A system
//! temporary directory is not used: this workshop has lost hundreds of
//! gigabytes to state left outside the checkout it belonged to.

use std::path::{Path, PathBuf};
use std::process::{Command, Output};

const SCRATCH: &str = concat!(env!("CARGO_MANIFEST_DIR"), "/../../target/scratch");

pub struct Scratch {
    path: PathBuf,
}

impl Scratch {
    pub fn new(label: &str) -> Self {
        let unique = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .expect("the clock follows the epoch")
            .as_nanos();
        let path = Path::new(SCRATCH).join(format!("ration-{label}-{unique:x}"));
        std::fs::create_dir_all(path.join("home/.shared-hooks")).expect("a disposable home");
        Self { path }
    }

    pub fn home(&self) -> String {
        self.path.join("home").display().to_string()
    }

    pub fn hooks(&self) -> PathBuf {
        self.path.join("home").join(".shared-hooks")
    }

    /// A real repository with real commits, because the size of a change is
    /// measured with git rather than asserted.
    pub fn repository(&self) -> PathBuf {
        let repository = self.path.join("product");
        std::fs::create_dir_all(&repository).expect("a repository directory");
        for arguments in [
            vec!["init", "--quiet"],
            vec!["config", "user.email", "ration@example.invalid"],
            vec!["config", "user.name", "Ration"],
        ] {
            let done = git(&repository, &arguments);
            assert!(done.status.success(), "git {arguments:?}");
        }
        repository
    }
}

impl Drop for Scratch {
    fn drop(&mut self) {
        std::fs::remove_dir_all(&self.path).ok();
    }
}

fn git(repository: &Path, arguments: &[&str]) -> Output {
    Command::new("git")
        .arg("-C")
        .arg(repository)
        .args(arguments)
        .output()
        .expect("git runs")
}

/// Writes `lines` numbered lines, commits them, and returns the revision.
pub fn commit(repository: &Path, lines: usize, message: &str) -> String {
    let body: String = (0..lines).map(|line| format!("line {line}\n")).collect();
    std::fs::write(repository.join("source.txt"), body).expect("write the source");
    for arguments in [vec!["add", "-A"], vec!["commit", "--quiet", "-m", message]] {
        let done = git(repository, &arguments);
        assert!(
            done.status.success(),
            "git {arguments:?}: {}",
            String::from_utf8_lossy(&done.stderr)
        );
    }
    String::from_utf8_lossy(&git(repository, &["rev-parse", "HEAD"]).stdout)
        .trim()
        .to_string()
}

pub fn cli() -> PathBuf {
    Path::new(env!(
        "CARGO_BIN_EXE_tama-block-unregistered-build-or-restart"
    ))
    .parent()
    .expect("the gate has a directory")
    .join("tama-cli")
}

/// Runs `tama-cli build` against the disposable home, with device approval
/// explicitly absent so a case that needs it has to ask for it.
pub fn build(scratch: &Scratch, arguments: &[&str]) -> Output {
    Command::new(cli())
        .arg("build")
        .args(arguments)
        .args(["--home", &scratch.home()])
        .env_remove("DEVICE_HOOK_EDIT_APPROVED")
        .output()
        .expect("tama-cli build runs")
}

pub fn said(output: &Output) -> String {
    format!(
        "{}{}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    )
}
