use super::provenance;
use crate::ports::{
    python_stdlib::{expanduser, shell_tokens},
    shell_text,
};
use serde_json::Value;
use std::path::{Path, PathBuf};

const READ_ONLY_GIT: &[&str] = &[
    "status",
    "diff",
    "log",
    "show",
    "ls-files",
    "ls-tree",
    "rev-parse",
    "rev-list",
    "check-ignore",
    "describe",
    "for-each-ref",
    "cat-file",
];
const PATH_MUTATORS: &[&str] = &[
    "rm", "mv", "cp", "install", "touch", "truncate", "chmod", "chown", "tee", "mkdir",
];
const SCRIPT_RUNNERS: &[&str] = &[
    "node", "bun", "python", "python3", "ruby", "perl", "sh", "bash", "zsh",
];

fn target(token: &str, cwd: &Path) -> Option<String> {
    if token.contains(['$', '*', '?', '`']) {
        return Some(format!("BLOCKED: mutation target {token} is not a concrete path; source ownership cannot be established"));
    }
    provenance::refusal(Path::new(&expanduser(token)), cwd)
}

fn git(words: &[String], cwd: &Path) -> Option<String> {
    let mut directory = cwd.to_path_buf();
    let mut extra_targets = Vec::new();
    let mut arguments = words.iter();
    let operation = loop {
        let word = arguments.next()?;
        if word == "-C" {
            directory = directory.join(expanduser(arguments.next()?));
        } else if word == "-c" {
            arguments.next()?;
        } else if word == "--git-dir" || word == "--work-tree" {
            extra_targets.push(arguments.next()?.as_str());
        } else if let Some(path) = word
            .strip_prefix("--git-dir=")
            .or_else(|| word.strip_prefix("--work-tree="))
        {
            extra_targets.push(path);
        } else if !word.starts_with('-') {
            break word.as_str();
        }
    };
    let rest: Vec<_> = arguments.map(String::as_str).collect();
    if READ_ONLY_GIT.contains(&operation)
        || operation == "remote" && (rest.is_empty() || ["get-url", "-v"].contains(&rest[0]))
        || operation == "config"
            && rest
                .iter()
                .any(|word| ["--get", "--get-all", "--get-regexp", "--list", "-l"].contains(word))
    {
        return None;
    }
    for path in extra_targets {
        if let Some(reason) = target(path, &directory) {
            return Some(reason);
        }
    }
    if let Some(reason) = provenance::refusal(&directory, &directory) {
        return Some(reason);
    }
    if rest.contains(&"--unsafe-paths") {
        return Some("BLOCKED: git --unsafe-paths can mutate source outside its verified owner; use explicit file edits instead".into());
    }
    None
}

pub(super) fn refusal(input: &Value, initial_cwd: &Path) -> Option<String> {
    let command = input
        .get("command")
        .or_else(|| input.get("cmd"))
        .and_then(Value::as_str)
        .or_else(|| input.as_str())?;
    let mut cwd: PathBuf = initial_cwd.to_owned();
    for segment in shell_text::commands(command) {
        let tokens = shell_tokens(segment);
        if let Some(inner) = shell_text::inner_command(&tokens) {
            if let Some(reason) = refusal(&Value::String(inner.to_owned()), &cwd) {
                return Some(reason);
            }
        }
        let Some(program) = shell_text::program(&tokens) else {
            continue;
        };
        let Some(position) = tokens.iter().position(|word| {
            Path::new(word).file_name().and_then(|name| name.to_str()) == Some(program)
        }) else {
            continue;
        };
        let words = &tokens[position + usize::from(true)..];
        if program == "cd" {
            if let Some(path) = words.first() {
                cwd = cwd.join(expanduser(path));
            }
        } else if program == "git" {
            if let Some(reason) = git(words, &cwd) {
                return Some(reason);
            }
        } else if PATH_MUTATORS.contains(&program) {
            let operands: Vec<_> = words.iter().filter(|word| !word.starts_with('-')).collect();
            let written: &[&String] = if ["cp", "install"].contains(&program) {
                operands
                    .last()
                    .map(std::slice::from_ref)
                    .unwrap_or_default()
            } else {
                &operands
            };
            for path in written {
                if let Some(reason) = target(path, &cwd) {
                    return Some(reason);
                }
            }
        } else if ["sed", "perl"].contains(&program)
            && words.iter().any(|word| word.starts_with("-i"))
        {
            for path in words.iter().filter(|word| !word.starts_with('-')) {
                if let Some(reason) = target(path, &cwd) {
                    return Some(reason);
                }
            }
        } else if SCRIPT_RUNNERS.contains(&program) {
            // Running a script from an external checkout must not become a way
            // to patch that checkout while hiding the destination in the script.
            if program == "bun" && words.first().is_some_and(|word| word == "unlink") {
                continue;
            }
            if let Some(reason) = provenance::refusal(&cwd, &cwd) {
                return Some(reason);
            }
        }
        for (index, token) in tokens.iter().enumerate() {
            if [">", ">>", "1>", "2>"].contains(&token.as_str()) {
                if let Some(path) = tokens.get(index + usize::from(true)) {
                    if let Some(reason) = target(path, &cwd) {
                        return Some(reason);
                    }
                }
            } else if let Some(path) = token.strip_prefix(">>").or_else(|| token.strip_prefix('>'))
            {
                if !path.is_empty() {
                    if let Some(reason) = target(path, &cwd) {
                        return Some(reason);
                    }
                }
            }
        }
    }
    None
}
