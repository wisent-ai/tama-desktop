//! The shapes the runner writes and reads: the decision it prints, one
//! result entry, the normalized payload, and the registry views.
//!
//! Split out of `runner/mod.rs`, which had grown past the
//! three-hundred-line limit. Both the adaptive path and the kill-switch
//! path use these, so they sit beside them rather than inside either.

use std::io::Write;

use crate::segments::runner_command::HookSpec;
use crate::util::js_string;

pub(super) fn usage() -> &'static str {
    "Usage: runner.mjs <event>\nExample: runner.mjs stop\n"
}

pub(super) fn json(value: &serde_json::Value) -> String {
    serde_json::to_string(value).unwrap_or_default()
}

/// `emit(decision)` — ordered top-level keys exactly like the JS object
/// literals (`JSON.stringify` keeps insertion order).
pub(super) fn emit(fields: &[(&str, String)]) {
    let body: Vec<String> = fields
        .iter()
        .map(|(key, value)| {
            format!(
                "{}:{}",
                json(&serde_json::Value::String(key.to_string())),
                value
            )
        })
        .collect();
    let _ = write!(std::io::stdout(), "{{{}}}", body.join(","));
    let _ = std::io::stdout().flush();
}

pub(super) fn result_entry(hook: &HookSpec, code: Option<i32>) -> String {
    let mut parts = Vec::new();
    // `{ id, code }` — the id key is dropped when absent in JS.
    if !hook.id.is_null() {
        parts.push(format!("\"id\":{}", json(&hook.id)));
    }
    let code_value = code
        .map(serde_json::Value::from)
        .unwrap_or(serde_json::Value::Null);
    parts.push(format!("\"code\":{}", json(&code_value)));
    format!("{{{}}}", parts.join(","))
}

pub(super) fn results_array(results: &[String]) -> String {
    format!("[{}]", results.join(","))
}

/// `{ ...payload, agent_hook_event: event }` — object spread; a string
/// payload spreads its characters under index keys, other primitives
/// contribute nothing.
pub(super) fn normalized_payload(payload: &serde_json::Value, event: &str) -> String {
    let mut map = serde_json::Map::new();
    match payload {
        serde_json::Value::Object(entries) => {
            for (key, value) in entries {
                map.insert(key.clone(), value.clone());
            }
        }
        serde_json::Value::String(text) => {
            for (index, ch) in text.chars().enumerate() {
                map.insert(index.to_string(), serde_json::Value::String(ch.to_string()));
            }
        }
        _ => {}
    }
    map.insert("agent_hook_event".to_string(), event.into());
    json(&serde_json::Value::Object(map))
}

/// Build the raw `HookSpec` view of a registry hook entry.
pub(super) fn hook_spec(hook: &serde_json::Value) -> HookSpec {
    HookSpec {
        id: hook.get("id").cloned().unwrap_or(serde_json::Value::Null),
        command: hook
            .get("command")
            .map(js_string)
            .unwrap_or_else(|| "undefined".to_string()),
    }
}

pub(super) fn blocking(entry: &serde_json::Value) -> bool {
    // `entry.blocking !== false`
    entry.get("blocking").and_then(|v| v.as_bool()) != Some(false)
}

pub(super) fn hooks_of(entry: &serde_json::Value) -> Vec<serde_json::Value> {
    entry
        .get("hooks")
        .and_then(|h| h.as_array())
        .cloned()
        .unwrap_or_default()
}
