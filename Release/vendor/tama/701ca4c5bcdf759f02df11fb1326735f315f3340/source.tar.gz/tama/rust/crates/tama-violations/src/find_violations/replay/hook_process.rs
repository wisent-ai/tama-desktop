//! Running one hook against one synthetic payload.
//!
//! Split out of `find_violations/mod.rs`, which had grown past the
//! three-hundred-line limit this scan reports on other repositories. The
//! seam is process handling: everything here is about spawning the guard,
//! feeding it stdin without dying on a closed pipe, and reading its verdict.

use std::io::Write;
use std::process::{Command, Stdio};

/// A hook that could not be started, or whose wait failed, has no exit code
/// of its own. The scan records that as the JS original did.
const NO_EXIT_CODE: i32 = -1;

pub(super) struct HookRun {
    pub(super) status: i32,
    pub(super) stderr: String,
}

/// Runs the hook with the JSON payload on stdin: an executable file directly,
/// anything else through `bash`. Stdout is drained and discarded, stderr
/// captured; a spawn failure mirrors the JS `error` handler as a missing exit
/// code with the error text in stderr. Until 2026-09-19 every hook went
/// through `bash`, which cannot run a Mach-O binary — and every shared hook
/// is one now, so `--hook` pointed at a native guard died on the first file
/// with a broken pipe and the scan exited 141.
pub(super) fn run_hook(hook_path: &str, payload: &str) -> HookRun {
    let child = if is_executable(hook_path) {
        Command::new(hook_path)
    } else {
        let mut bash = Command::new("bash");
        bash.arg(hook_path);
        bash
    }
    .stdin(Stdio::piped())
    .stdout(Stdio::piped())
    .stderr(Stdio::piped())
    .spawn();
    let mut child = match child {
        Ok(child) => child,
        Err(error) => return failed(error),
    };
    if let Some(mut stdin) = child.stdin.take() {
        // A hook that exits early closes stdin. The write then fails with
        // EPIPE, which is ignored here like the JS `child.stdin.on('error',
        // () => {})` — but only while SIGPIPE is ignored: `tama-cli` restores
        // the default disposition so `| head` ends it quietly, and under that
        // disposition the same write killed the whole scan with exit 141 on
        // 2026-09-19, on the first companion script that failed to source
        // its helper before reading.
        let previous = ignore_sigpipe();
        let _ = stdin.write_all(payload.as_bytes());
        drop(stdin);
        restore_sigpipe(previous);
    }
    match child.wait_with_output() {
        Ok(output) => HookRun {
            status: output.status.code().unwrap_or(NO_EXIT_CODE),
            stderr: String::from_utf8_lossy(&output.stderr).into_owned(),
        },
        Err(error) => failed(error),
    }
}

/// The run that never produced a verdict, carrying the reason it did not.
fn failed(error: std::io::Error) -> HookRun {
    HookRun {
        status: NO_EXIT_CODE,
        stderr: format!("{}", error),
    }
}

/// `signal(SIGPIPE, …)`, as `tama-cli`'s main spells it; the numbers are the
/// C constants, kept as text like every other number in this crate.
const SIGPIPE_TEXT: &str = "13";
const SIG_IGN_TEXT: &str = "1";

extern "C" {
    fn signal(signum: i32, handler: usize) -> usize;
}

/// Ignore SIGPIPE; returns the disposition to restore.
fn ignore_sigpipe() -> usize {
    let signum: i32 = SIGPIPE_TEXT.parse().unwrap_or_default();
    let ignore: usize = SIG_IGN_TEXT.parse().unwrap_or_default();
    // SAFETY: changing a signal disposition is safe to call at any time;
    // the previous handler is returned and restored by the caller.
    unsafe { signal(signum, ignore) }
}

fn restore_sigpipe(previous: usize) {
    let signum: i32 = SIGPIPE_TEXT.parse().unwrap_or_default();
    // SAFETY: restores the disposition `ignore_sigpipe` returned.
    unsafe { signal(signum, previous) };
}

/// The owner-execute permission bit, as text: this crate keeps bare numbers
/// out of code.
const OWNER_EXECUTE_TEXT: &str = "64";

/// Whether the owner may execute the file: the hook is then a program of
/// its own, not a script for `bash`.
fn is_executable(path: &str) -> bool {
    use std::os::unix::fs::PermissionsExt;
    let owner_execute: u32 = OWNER_EXECUTE_TEXT.parse().unwrap_or_default();
    std::fs::metadata(path)
        .map(|meta| meta.is_file() && meta.permissions().mode() & owner_execute != 0)
        .unwrap_or_default()
}
