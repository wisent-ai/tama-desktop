//! Common hook execution. Harness formatting is outside this loop.
//!
//! A hook is waited for, not timed. Each binding used to carry a number of
//! seconds and the runtime killed the hook at it, defaulting to ten when the
//! registry said nothing. The number was a guess: on 2026-09-20 a gate whose
//! binary answers in four milliseconds once warm was killed at ten seconds
//! while its first run after installation paid the operating system's
//! signature assessment, and the turn was blocked by a refusal no hook had
//! written. What a slow hook needs is to be found and made fast —
//! `tama hooks warm` pays the first-run cost outside a live event and reports
//! what each binary cost, and the elapsed time of every execution is
//! recorded — so nothing here counts seconds.

use std::collections::HashSet;

use serde_json::Value;
use tama_hooks::enforcement::{
    read_enforcement_selection, selection_enforces_hook, EnforcementMode,
};
use tama_hooks::hook_exec::{looks_like_malfunction, CommandResult};
use tama_hooks::session_control::{
    hooks_globally_disabled, read_session_override, session_context,
};

use super::normalized_payload;
use crate::emit::{
    block_json, decision_from_output, pass_with_reason_json, pass_with_results_json, write_stderr,
    Record,
};
use crate::exec::run_command;
use crate::jssem::{js_to_string_opt, trim_js};
use crate::{Decision, InvocationOptions};

pub(crate) fn evaluate(
    registry: &Value,
    known_hook_ids: &HashSet<String>,
    catalog_checksum: &str,
    event: &str,
    agent_id: &str,
    options: &InvocationOptions,
    payload: &Value,
) -> Result<Decision, String> {
    if event.is_empty() {
        return Err("hook event is required".to_owned());
    }
    let context = session_context(agent_id, Some(payload));
    let session_override = read_session_override(context.as_ref(), Some(known_hook_ids));
    // Grants belong to the session and the loaded policy generation, not
    // merely to whichever record happened to be on disk before a reload.
    let session_capability = session_override.capability.filter(|capability| {
        context.as_ref().is_some_and(|context| {
            capability.get("controlKey").and_then(Value::as_str)
                == Some(context.control_key.as_str())
        }) && capability.get("catalogChecksum").and_then(Value::as_str) == Some(catalog_checksum)
            && registry
                .get("releaseId")
                .and_then(Value::as_str)
                .is_some_and(|release| {
                    capability.get("releaseId").and_then(Value::as_str) == Some(release)
                })
    });
    let enforcement = read_enforcement_selection();
    if let Some(error) = enforcement.error.as_deref() {
        write_stderr(&format!("hook enforcement state warning: {error}\n"));
    }
    let globally_disabled = hooks_globally_disabled();

    let entry = registry.get("events").and_then(|events| events.get(event));
    let Some(entry) = entry else {
        return Ok(Decision::pass(pass_with_reason_json(&format!(
            "no hooks for {event}"
        ))));
    };
    if payload.is_null() {
        return Err("Cannot read properties of null (reading 'raw_event')".to_owned());
    }
    let normalized = normalized_payload(payload, event);
    let mut results = Vec::new();
    let hooks = match entry.get("hooks") {
        Some(hooks) => hooks
            .as_array()
            .ok_or("event hooks must be an array")?
            .as_slice(),
        None => &[],
    };
    for hook in hooks {
        let id_value = hook.get("id").cloned();
        let id_str = hook.get("id").and_then(Value::as_str);
        let id_display = js_to_string_opt(hook.get("id"));
        let machine_enabled = match id_str {
            Some(id) => selection_enforces_hook(
                &enforcement.selection,
                globally_disabled,
                id,
                &session_override.enabled_hook_ids,
            ),
            None => !globally_disabled && enforcement.selection.mode == EnforcementMode::All,
        };
        if (!options.only_hook_id.is_empty() && id_str != Some(options.only_hook_id.as_str()))
            || id_str.is_some_and(|id| options.disabled_hook_ids.contains(id))
            || options
                .enabled_hook_ids
                .as_ref()
                .is_some_and(|ids| !id_str.is_some_and(|id| ids.contains(id)))
            || !machine_enabled
        {
            results.push(Record::Skipped(id_value));
            continue;
        }

        let command = js_to_string_opt(hook.get("command"));
        let result = run_command(&command, &normalized, session_capability.as_ref());
        results.push(Record::Exec {
            id: id_value.clone(),
            code: result.code,
            ms: result.elapsed_ms,
            failed: false,
        });

        let block_reason =
            decision_from_output(&result.stdout).or_else(|| decision_from_output(&result.stderr));
        if let Some(block_reason) = block_reason {
            let reason = format!("{id_display}: {block_reason}");
            crate::observation::block(event, id_value.as_ref(), &reason, payload);
            return Ok(Decision::block(block_json(
                &reason,
                id_value.as_ref(),
                &results,
            )));
        }
        let malfunction_check = CommandResult {
            spawn_error: result.spawn_error,
            stdout: Some(result.stdout.clone()),
            stderr: Some(result.stderr.clone()),
        };
        if result.spawn_error
            || (result.code.is_some_and(|code| code != 0)
                && looks_like_malfunction(&malfunction_check))
        {
            let detail = if !result.stderr.is_empty() {
                &result.stderr
            } else {
                &result.stdout
            };
            write_stderr(&format!(
                "hook {id_display} malfunctioned: {}\n",
                trim_js(detail)
            ));
            if let Some(Record::Exec { failed, .. }) = results.last_mut() {
                *failed = true;
            }
            continue;
        }
        if result.code.is_some_and(|code| code != 0)
            && entry.get("blocking") != Some(&Value::Bool(false))
        {
            let exit_label = format!("exit {}", result.code.unwrap_or(0));
            let reason_source = if !result.stderr.is_empty() {
                &result.stderr
            } else if !result.stdout.is_empty() {
                &result.stdout
            } else {
                &exit_label
            };
            let reason = format!("{id_display}: {}", trim_js(reason_source));
            crate::observation::block(event, id_value.as_ref(), &reason, payload);
            return Ok(Decision::block(block_json(
                &reason,
                id_value.as_ref(),
                &results,
            )));
        }
    }
    Ok(Decision::pass(pass_with_results_json(&results)))
}
