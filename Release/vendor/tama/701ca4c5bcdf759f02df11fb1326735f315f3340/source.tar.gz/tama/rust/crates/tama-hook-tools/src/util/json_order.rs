//! Insertion-order JSON helpers.
//!
//! serde_json maps are BTreeMaps (sorted), but `JSON.stringify` preserves
//! the parse/insertion order; for byte-identical output the order has to be
//! recovered from the raw text or given explicitly.
//!
//! Split out of `util/mod.rs`, which had grown past the three-hundred-line
//! limit.

use serde_json::Value;

fn json_skip_ws(bytes: &[u8], mut i: usize) -> usize {
    while i < bytes.len() && bytes[i].is_ascii_whitespace() {
        i += 1;
    }
    i
}

fn json_skip_string(bytes: &[u8], mut i: usize) -> usize {
    // bytes[i] == '"'
    i += 1;
    while i < bytes.len() {
        match bytes[i] {
            b'\\' => i += 2,
            b'"' => return i + 1,
            _ => i += 1,
        }
    }
    i
}

fn json_skip_value(bytes: &[u8], mut i: usize) -> usize {
    i = json_skip_ws(bytes, i);
    if i >= bytes.len() {
        return i;
    }
    match bytes[i] {
        b'"' => json_skip_string(bytes, i),
        b'{' | b'[' => {
            let mut depth = 0usize;
            while i < bytes.len() {
                match bytes[i] {
                    b'"' => i = json_skip_string(bytes, i),
                    b'{' | b'[' => {
                        depth += 1;
                        i += 1;
                    }
                    b'}' | b']' => {
                        depth -= 1;
                        i += 1;
                        if depth == 0 {
                            return i;
                        }
                    }
                    _ => i += 1,
                }
            }
            i
        }
        _ => {
            while i < bytes.len() && !matches!(bytes[i], b',' | b'}' | b']') {
                i += 1;
            }
            i
        }
    }
}

/// Iterate the top-level entries of the JSON object starting at `start`
/// (which must point at `{`), calling `visit(key, value_start)` in file order.
fn json_object_entries(text: &str, start: usize, visit: &mut dyn FnMut(&str, usize)) {
    let bytes = text.as_bytes();
    let mut i = json_skip_ws(bytes, start);
    if i >= bytes.len() || bytes[i] != b'{' {
        return;
    }
    i += 1;
    loop {
        i = json_skip_ws(bytes, i);
        if i >= bytes.len() || bytes[i] == b'}' {
            return;
        }
        if bytes[i] != b'"' {
            return;
        }
        let key_end = json_skip_string(bytes, i);
        let key = &text[i + 1..key_end - 1];
        i = json_skip_ws(bytes, key_end);
        if i >= bytes.len() || bytes[i] != b':' {
            return;
        }
        let value_start = json_skip_ws(bytes, i + 1);
        visit(key, value_start);
        i = json_skip_value(bytes, value_start);
        i = json_skip_ws(bytes, i);
        if i >= bytes.len() {
            return;
        }
        match bytes[i] {
            b',' => i += 1,
            b'}' => return,
            _ => return,
        }
    }
}

/// Top-level key order of the object at `path` (e.g. `["events"]`) in raw
/// JSON text. Keys are returned raw (no unescaping — registry keys are plain
/// ASCII). Empty when the path does not resolve to an object.
pub fn ordered_object_keys(text: &str, path: &[&str]) -> Vec<String> {
    let mut start = 0usize;
    for segment in path {
        let mut found = None;
        json_object_entries(text, start, &mut |key, value_start| {
            if found.is_none() && key == *segment {
                found = Some(value_start);
            }
        });
        match found {
            Some(value_start) => start = value_start,
            None => return Vec::new(),
        }
    }
    let mut keys = Vec::new();
    json_object_entries(text, start, &mut |key, _| keys.push(key.to_string()));
    keys
}

/// `JSON.stringify(object, null, 2)` with an explicit key order — the pairs
/// are emitted in the given sequence, values use the standard 2-space pretty
/// printer (nested content re-indented like `JSON.stringify`).
pub fn stringify_pretty_ordered(pairs: &[(&str, Value)]) -> String {
    if pairs.is_empty() {
        return "{}".to_string();
    }
    let mut out = String::from("{\n");
    for (index, (key, value)) in pairs.iter().enumerate() {
        out.push_str("  ");
        out.push_str(&serde_json::to_string(key).unwrap_or_default());
        out.push_str(": ");
        let rendered = serde_json::to_string_pretty(value).unwrap_or_default();
        out.push_str(&rendered.replace('\n', "\n  "));
        if index + 1 < pairs.len() {
            out.push(',');
        }
        out.push('\n');
    }
    out.push('}');
    out
}
