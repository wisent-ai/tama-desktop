//! Hook-payload accessors: stdin payload reading, id/name/input extraction,
//! deny banners, and the two denial channels the runners understand.

use std::io::Read;

use serde_json::Value;

use super::types::{max_hook_id_len, SESSION_ID_KEYS};

/// The leading `<hook-id>:` token of a deny banner, if the text has one.
pub fn deny_banner_id(text: &str) -> Option<String> {
    let head = text.trim_start();
    let (candidate, _) = head.split_once(':')?;
    let ok = !candidate.is_empty()
        && candidate.len() <= max_hook_id_len()
        && candidate.starts_with(|c: char| c.is_ascii_lowercase())
        && candidate
            .chars()
            .all(|c| c.is_ascii_lowercase() || c.is_ascii_digit() || c == '-');
    ok.then(|| candidate.to_string())
}

/// Payload delivered on stdin; an unreadable payload is an empty object.
pub fn read_payload() -> Value {
    let mut raw = String::new();
    if std::io::stdin().read_to_string(&mut raw).is_err() {
        return Value::Object(Default::default());
    }
    serde_json::from_str(&raw).unwrap_or_else(|_| Value::Object(Default::default()))
}

pub fn session_id_of(payload: &Value) -> String {
    for key in SESSION_ID_KEYS {
        if let Some(text) = payload.get(key).and_then(Value::as_str) {
            if !text.is_empty() {
                return text.to_string();
            }
        }
    }
    String::new()
}

/// Tool name from a `PreToolUse`-shaped payload, lowercased.
pub fn tool_name_of(payload: &Value) -> String {
    let direct = payload
        .get("tool_name")
        .or_else(|| payload.get("name"))
        .or_else(|| payload.get("tool"));
    match direct {
        Some(Value::String(text)) => text.trim().to_lowercase(),
        Some(Value::Object(map)) => map
            .get("name")
            .or_else(|| map.get("tool_name"))
            .and_then(Value::as_str)
            .unwrap_or_default()
            .trim()
            .to_lowercase(),
        _ => String::new(),
    }
}

/// Tool arguments from a `PreToolUse`-shaped payload.
pub fn tool_input_of(payload: &Value) -> Value {
    payload
        .get("tool_input")
        .or_else(|| payload.get("input"))
        .cloned()
        .unwrap_or(Value::Null)
}

/// The final assistant message, when the payload carries one.
pub fn last_assistant_message(payload: &Value) -> Option<&str> {
    payload
        .get("last_assistant_message")
        .and_then(Value::as_str)
}

/// Every string inside a JSON tree, in document order.
pub fn all_strings(value: &Value) -> Vec<String> {
    let mut found = Vec::new();
    collect_strings(value, &mut found);
    found
}

fn collect_strings(value: &Value, found: &mut Vec<String>) {
    match value {
        Value::String(text) => found.push(text.clone()),
        Value::Array(items) => items.iter().for_each(|item| collect_strings(item, found)),
        Value::Object(map) => map.values().for_each(|item| collect_strings(item, found)),
        _ => {}
    }
}

/// A `PreToolUse` denial: banner on stderr, exit code 2.
pub fn deny_tool_use(reason: &str) -> ! {
    eprintln!("{reason}");
    std::process::exit("2".parse().unwrap_or_default())
}

/// A `Stop` decision the runner understands.
pub fn deny(reason: String) {
    let decision = serde_json::json!({ "decision": "block", "reason": reason });
    println!("{decision}");
}
