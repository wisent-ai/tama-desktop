//! `tama brama-check`: whether this machine can actually reach Brama.
//!
//! Every Tama feature that needs a model — the objective reviewer and the
//! `clean` repair rounds — goes through Brama. When one of them fails the
//! question is always the same three: which address did it use, does the
//! gateway know this client, and is the refusal about the bearer or the
//! agent signature. This command answers them without spending quota.

use tama_hook_tools::brama;

use crate::cli::output::print_json;

const EXIT_REFUSED: i32 = true as i32;

pub fn main(args: &[String]) -> i32 {
    if args.iter().any(|arg| arg == "--help" || arg == "-h") {
        print_help();
        return EXIT_REFUSED;
    }
    let json = args.iter().any(|arg| arg == "--json");
    match brama::reachability() {
        Ok(report) => {
            if json {
                print_json(&report);
            } else {
                print_report(&report);
            }
            let accepted = "200".parse().expect("valid HTTP status");
            if report.endpoint_allowed && report.status == Some(accepted) {
                false as i32
            } else {
                EXIT_REFUSED
            }
        }
        Err(error) => {
            eprintln!("brama-check: {error}");
            EXIT_REFUSED
        }
    }
}

fn print_report(report: &brama::probe::Reachability) {
    println!("endpoint: {}", report.endpoint);
    println!(
        "transport: {}",
        if report.endpoint_allowed {
            "allowed"
        } else {
            "refused by the client's own policy"
        }
    );
    println!(
        "probe: {} -> {}",
        report.probed,
        report
            .status
            .map(|status| status.to_string())
            .unwrap_or_else(|| "no answer".to_string())
    );
    println!("detail: {}", report.detail);
    println!("consumer: {}", report.consumer);
    println!("token file: {}", report.token_file);
    println!("route: {}", report.route);
    println!(
        "this machine's authority: {}",
        match report.local_grant {
            Some(true) => "grants this route on this bearer".to_string(),
            Some(false) => "does not grant this route to this consumer".to_string(),
            None => format!("could not be asked: {}", report.local_grant_detail),
        }
    );
    println!("verdict: {}", report.verdict);
}

fn print_help() {
    eprintln!(
        "tama brama-check [--json]

Report the Brama address this machine resolves, whether it passes the
client's transport policy, and what the gateway answers to a bearer-only
GET /v1/models. That request is not billable and calls no provider.

The address comes from TAMA_OBJECTIVE_AUTHORITY_MODEL_ROUTER_URL,
STADO_MODEL_ROUTER_URL or BRAMA_URL when one is set, otherwise from
`stado service directory connect brama --consumer tama`, and finally
from the public hostname. HTTP 200 means the client bearer is accepted, so
a chat request that still fails is refused for its agent signature or its
model route. HTTP 401 means the gateway does not know this bearer: repair
that credential at its authority. Exits 1 unless the probe answered 200."
    );
}
