//! Port of `src/adaptive/doctor/repair.mjs`: corpus-driven candidate
//! validation and consent-gated application of validated hook patches.
//! Also carries the minimal `src/core/catalog.mjs` surface the doctor
//! needs (`commandSourcePath`, catalog hook listing, `findHook`).

mod catalog;
mod corpus;
mod proposal;
mod spawn;

pub use catalog::{build_catalog_hooks, command_source_path, find_hook, CatalogHook};
pub use proposal::{apply_proposal, build_brief, propose, validate_candidate, Brief};
pub use spawn::{spawn_sync_capture, SpawnOutcome};

pub use super::evidence::{live_script_path, read_closed_telemetry_events};

/// How many payloads a brief shows, and how much of each.
const SAMPLE_LIMIT: usize = 5;
const SAMPLE_CHARS: usize = 2000;
