//! Reading the session transcript for evidence that somebody looked.
//!
//! The transcript path from the hook payload wins outright. Guessing was
//! tried and it made the gate unsatisfiable under concurrent sessions: the
//! largest recent file belonged to another session, so every read done in the
//! live one was invisible. When no path is given, the most recently modified
//! transcript for this project directory is used, because the active session
//! is the one being appended to at hook time.

use std::path::{Path, PathBuf};
use std::sync::LazyLock;
use std::time::UNIX_EPOCH;

use regex::Regex;
use serde_json::Value;

use crate::ports::python_stdlib::expanduser;
use crate::ports::transport_common as common;
use crate::util::sha256_hex;

const PROJECTS_DIR: &str = "~/.claude/projects";
const TRANSCRIPT_ENV: &str = "CLAUDE_TRANSCRIPT_PATH";
const JSONL_SUFFIX: &str = ".jsonl";
const TOOL_USE: &str = "tool_use";
const READ_TOOL: &str = "Read";
const BASH_TOOL: &str = "Bash";
/// `lines[-1200:]`: the tail of the session, not the whole file.
const LOOKBACK_TEXT: &str = "1200";
/// `bcmd[:80]` in the evidence line.
const SHOWN_COMMAND_TEXT: &str = "80";

static ESCAPE: LazyLock<Regex> = LazyLock::new(|| common::compile("[.^$*+?()\\[\\]{}|\\\\]"));

fn lookback() -> usize {
    LOOKBACK_TEXT.parse().unwrap_or_default()
}

fn quoted(label: &str) -> String {
    ESCAPE.replace_all(label, "\\$0").to_string()
}

fn modified(path: &Path) -> u64 {
    std::fs::metadata(path)
        .and_then(|meta| meta.modified())
        .map(|time| {
            time.duration_since(UNIX_EPOCH)
                .map(|value| value.as_secs())
                .unwrap_or_default()
        })
        .unwrap_or_default()
}

/// The session transcript to read: the given one, or the freshest for this
/// project directory.
pub(crate) fn session_path(repo: &Path, given: &str) -> Option<PathBuf> {
    let explicit = match given.is_empty() {
        false => Some(given.to_string()),
        true => std::env::var(TRANSCRIPT_ENV).ok(),
    };
    if let Some(path) = explicit.map(PathBuf::from).filter(|path| path.is_file()) {
        return Some(path);
    }
    // Claude Code encodes the project directory by replacing `/` with `-`,
    // and an absolute path already starts with one.
    let encoded = repo.to_string_lossy().replace('/', "-");
    let folder = PathBuf::from(expanduser(PROJECTS_DIR)).join(encoded);
    let entries = std::fs::read_dir(folder).ok()?;
    entries
        .flatten()
        .map(|entry| entry.path())
        .filter(|path| path.to_string_lossy().ends_with(JSONL_SUFFIX))
        .max_by_key(|path| modified(path))
}

fn tool_uses(line: &str) -> Vec<(String, Value)> {
    let Ok(entry) = serde_json::from_str::<Value>(line) else {
        return Vec::new();
    };
    let Some(Value::Array(content)) = entry
        .get("message")
        .and_then(|message| message.get("content"))
    else {
        return Vec::new();
    };
    content
        .iter()
        .filter(|block| block.get("type").and_then(Value::as_str) == Some(TOOL_USE))
        .filter_map(|block| {
            let name = block.get("name").and_then(Value::as_str)?.to_string();
            let input = block.get("input").cloned().unwrap_or(Value::Null);
            Some((name, input))
        })
        .collect()
}

fn tail(path: &Path) -> Vec<String> {
    let Ok(text) = std::fs::read_to_string(path) else {
        return Vec::new();
    };
    let lines: Vec<String> = text.lines().map(str::to_string).collect();
    let start = lines.len().saturating_sub(lookback());
    lines[start..].to_vec()
}

fn text_of(input: &Value, key: &str) -> String {
    input
        .get(key)
        .and_then(Value::as_str)
        .unwrap_or_default()
        .to_string()
}

/// Whether the session shows a frame of this recording being read, with the
/// frame's current content still matching what the marker recorded.
pub(crate) fn shows_frame_read(
    repo: &Path,
    label: &str,
    sha8: &str,
    given: &str,
    frames: &[(String, String)],
) -> bool {
    let Some(path) = session_path(repo, given) else {
        return false;
    };
    let pattern = common::compile(&format!(
        "\\.work/{}/frame_{}_[^[:space:]\\x27\\x22]*\\.(png|jpg)$",
        quoted(label),
        quoted(sha8)
    ));
    for line in tail(&path) {
        for (name, input) in tool_uses(&line) {
            if name != READ_TOOL {
                continue;
            }
            let read = text_of(&input, "file_path");
            if !pattern.is_match(&read) {
                continue;
            }
            // The marker is already digest-validated against the recording,
            // so the only remaining spoof is replacing the frame's content
            // after the marker was written.
            let claimed = frames
                .iter()
                .find(|(frame, _)| *frame == read)
                .map(|(_, digest)| digest.clone());
            match claimed {
                Some(digest) => {
                    let actual = std::fs::read(&read).map(|bytes| sha256_hex(&bytes));
                    if actual.ok().as_deref() != Some(digest.as_str()) {
                        continue;
                    }
                }
                None => {}
            }
            return true;
        }
    }
    false
}

/// Evidence in the session that somebody opened an artifact of this label.
pub(crate) fn shows_label_inspection(repo: &Path, label: &str, given: &str) -> Vec<String> {
    let Some(path) = session_path(repo, given) else {
        return Vec::new();
    };
    let escaped = quoted(label);
    let artifact_patterns: Vec<Regex> = [
        format!("(^|/)recordings/{escaped}/[^[:space:]\\x27\\x22]*\\.(webm|mp4|png|jpg|gif)$"),
        format!("\\.work/{escaped}/[^[:space:]\\x27\\x22]*\\.(png|jpg|html|htm|json|md)$"),
        format!("\\.work/{escaped}/frame[_0-9]*\\.(png|jpg)$"),
        format!("\\.work/[^[:space:]\\x27\\x22]*{escaped}[^[:space:]\\x27\\x22]*outerHTML[^[:space:]\\x27\\x22]*"),
        format!(
            "\\.work/[^[:space:]\\x27\\x22]*{escaped}[^[:space:]\\x27\\x22]*-diag/[^[:space:]\\x27\\x22]*\\.(json|html|png)$"
        ),
    ]
    .iter()
    .map(|pattern| common::compile(pattern))
    .collect();
    let command_patterns: Vec<Regex> = [
        format!("ffmpeg\\b[^|;&]*{escaped}[^|;&]*\\.webm"),
        format!("ffprobe\\b[^|;&]*{escaped}[^|;&]*\\.webm"),
        format!("jq\\b[^|;&]*\\.work/{escaped}/"),
    ]
    .iter()
    .map(|pattern| common::compile(pattern))
    .collect();
    let shown: usize = SHOWN_COMMAND_TEXT.parse().unwrap_or_default();
    let mut evidence: Vec<String> = Vec::new();
    for line in tail(&path) {
        for (name, input) in tool_uses(&line) {
            if name == READ_TOOL {
                let read = text_of(&input, "file_path");
                if artifact_patterns.iter().any(|p| p.is_match(&read)) {
                    evidence.push(format!("Read {read}"));
                }
                continue;
            }
            if name == BASH_TOOL {
                let command = text_of(&input, "command");
                if command_patterns.iter().any(|p| p.is_match(&command)) {
                    let head: String = command.chars().take(shown).collect();
                    evidence.push(format!("Bash {head}"));
                }
            }
        }
    }
    evidence
}

#[cfg(test)]
mod tests {
    use super::{session_path, shows_label_inspection, tool_uses};
    use serde_json::json;
    use std::path::{Path, PathBuf};

    fn scratch(name: &str) -> PathBuf {
        let dir = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../target/tmp")
            .join(format!("tama-transcript-{name}"));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).expect("a folder for the fixture");
        dir
    }

    /// The path from the payload wins; guessing was what broke this gate.
    #[test]
    fn the_given_transcript_wins() {
        let dir = scratch("given");
        let given = dir.join("session.jsonl");
        std::fs::write(&given, "").expect("a transcript");
        assert_eq!(
            session_path(Path::new("/repo"), &given.to_string_lossy()),
            Some(given.clone())
        );
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn only_tool_use_blocks_are_read() {
        let line = json!({
            "message": { "content": [
                { "type": "text", "text": "hello" },
                { "type": "tool_use", "name": "Read", "input": { "file_path": "/x/a.png" } }
            ] }
        })
        .to_string();
        let found = tool_uses(&line);
        assert_eq!(found.len(), true as usize);
        assert_eq!(found[0].0, "Read");
    }

    /// A read of the label's own artifact counts; a read of something else
    /// does not, which is what pins the evidence to the label.
    #[test]
    fn the_evidence_is_pinned_to_the_label() {
        let dir = scratch("evidence");
        let transcript = dir.join("session.jsonl");
        let lines = [
            json!({ "message": { "content": [
                { "type": "tool_use", "name": "Read",
                  "input": { "file_path": "/repo/.work/linkedin/frame_1.png" } }
            ] } })
            .to_string(),
            json!({ "message": { "content": [
                { "type": "tool_use", "name": "Read",
                  "input": { "file_path": "/repo/.work/tiktok/frame_1.png" } }
            ] } })
            .to_string(),
        ];
        std::fs::write(&transcript, lines.join("\n")).expect("a transcript");
        let evidence = shows_label_inspection(
            Path::new("/repo"),
            "linkedin",
            &transcript.to_string_lossy(),
        );
        assert_eq!(evidence.len(), true as usize, "{evidence:?}");
        assert!(evidence[0].contains("linkedin"), "{evidence:?}");
        let _ = std::fs::remove_dir_all(&dir);
    }
}
