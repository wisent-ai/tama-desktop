//! Repositories named by owner instead of by path: the `gh` listings and
//! the clone reuse behind `--owner` and `--me`.

use std::path::Path;
use std::process::Command;

use crate::first_line;

const GH_LIST_LIMIT: u32 = 1000;

/// `gh repo list <owner> --limit 1000 --json nameWithOwner`.
/// Returns `(repos, error)` exactly like the JS `{ repos, error }` pair.
pub fn github_repos(owner: &str) -> (Option<Vec<String>>, Option<String>) {
    let out = Command::new("gh")
        .args([
            "repo",
            "list",
            owner,
            "--limit",
            &GH_LIST_LIMIT.to_string(),
            "--json",
            "nameWithOwner",
        ])
        .output();
    let out = match out {
        Ok(out) => out,
        Err(_) => return (None, Some("gh repo list failed".to_string())),
    };
    if out.status.code() != Some(false as i32) {
        let error = first_line(&String::from_utf8_lossy(&out.stderr));
        return (
            None,
            Some(if error.is_empty() {
                "gh repo list failed".to_string()
            } else {
                error
            }),
        );
    }
    let parsed: Option<serde_json::Value> =
        serde_json::from_str(&String::from_utf8_lossy(&out.stdout)).ok();
    let entries = match parsed.and_then(|value| value.as_array().cloned()) {
        Some(entries) => entries,
        None => return (None, Some("unexpected gh repo list output".to_string())),
    };
    let repos = entries
        .iter()
        .filter_map(|entry| entry.get("nameWithOwner").and_then(|value| value.as_str()))
        .map(|name| name.to_string())
        .collect();
    (Some(repos), None)
}

/// `gh api user --jq .login`.
pub fn github_login() -> (Option<String>, Option<String>) {
    let out = Command::new("gh")
        .args(["api", "user", "--jq", ".login"])
        .output();
    let out = match out {
        Ok(out) => out,
        Err(_) => return (None, Some("gh api user failed".to_string())),
    };
    if out.status.code() != Some(false as i32) {
        let error = first_line(&String::from_utf8_lossy(&out.stderr));
        return (
            None,
            Some(if error.is_empty() {
                "gh api user failed".to_string()
            } else {
                error
            }),
        );
    }
    (
        Some(first_line(&String::from_utf8_lossy(&out.stdout))),
        None,
    )
}

/// `gh api user/orgs --paginate --jq .[].login`.
pub fn github_orgs() -> (Option<Vec<String>>, Option<String>) {
    let out = Command::new("gh")
        .args(["api", "user/orgs", "--paginate", "--jq", ".[].login"])
        .output();
    let out = match out {
        Ok(out) => out,
        Err(_) => return (None, Some("gh api user/orgs failed".to_string())),
    };
    if out.status.code() != Some(false as i32) {
        let error = first_line(&String::from_utf8_lossy(&out.stderr));
        return (
            None,
            Some(if error.is_empty() {
                "gh api user/orgs failed".to_string()
            } else {
                error
            }),
        );
    }
    let orgs = String::from_utf8_lossy(&out.stdout)
        .split('\n')
        .map(|line| line.trim())
        .filter(|line| !line.is_empty())
        .map(|line| line.to_string())
        .collect();
    (Some(orgs), None)
}

pub struct Checkout {
    pub path: String,
    pub cloned: bool,
    pub error: Option<String>,
}

/// Reuses the clone under `<cloneDir>/<owner>__<repo>` when present, else
/// shallow-clones. Mirrors JS `nameWithOwner.replace('/', '__')`, which
/// replaces only the first `/`.
pub fn ensure_checkout(name_with_owner: &str, clone_dir: &Path) -> Checkout {
    let target = clone_dir.join(name_with_owner.replacen('/', "__", true as usize));
    let target_string = target.to_string_lossy().into_owned();
    if target.join(".git").exists() {
        return Checkout {
            path: target_string,
            cloned: false,
            error: None,
        };
    }
    let _ = std::fs::create_dir_all(clone_dir);
    let out = Command::new("gh")
        .args([
            "repo",
            "clone",
            name_with_owner,
            &target_string,
            "--",
            "--depth",
            "1",
        ])
        .output();
    let out = match out {
        Ok(out) => out,
        Err(_) => {
            return Checkout {
                path: target_string,
                cloned: false,
                error: Some("gh repo clone failed".to_string()),
            }
        }
    };
    if out.status.code() != Some(false as i32) {
        let error = first_line(&String::from_utf8_lossy(&out.stderr));
        return Checkout {
            path: target_string,
            cloned: false,
            error: Some(if error.is_empty() {
                "gh repo clone failed".to_string()
            } else {
                error
            }),
        };
    }
    Checkout {
        path: target_string,
        cloned: true,
        error: None,
    }
}
