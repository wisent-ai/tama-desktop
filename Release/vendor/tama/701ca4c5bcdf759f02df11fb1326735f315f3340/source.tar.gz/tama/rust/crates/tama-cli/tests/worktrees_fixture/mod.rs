//! The throwaway repository the `tama worktrees` tests drive.
//!
//! Split out of `worktrees_cli.rs` when that file crossed the three-hundred
//! line limit `block-oversized-files` enforces. This module holds the fixture
//! and nothing that asserts; the assertions stay beside it in the test file.
//! A `mod.rs` in a subdirectory of `tests/` is not compiled as its own test
//! binary, so the crate's `[[test]]` entry keeps working unchanged.

use std::fs;
use std::path::{Path, PathBuf};
use std::process::{Command, Output};
use std::time::{SystemTime, UNIX_EPOCH};

/// The `schemaVersion` the worktree documents are fixed at by the contract
/// the CLI, the loopback routes and the docs page share.
pub const SCHEMA_VERSION: u32 = 1;

pub struct Fixture {
    pub base: PathBuf,
}

impl Fixture {
    /// `base/tree/repo` with one commit, plus `base/tree/worktrees/{wt-a,wt-b}`
    /// added by git. A command whose only job is removing linked worktrees
    /// cannot be proven without a linked worktree to remove, so the fixture
    /// makes real ones — inside its own throwaway repository, never a real
    /// checkout, and under the crate's own `CARGO_TARGET_TMPDIR` inside
    /// `target/`, which is the one place this workshop allows throwaway
    /// state: not `/tmp`, which is swept on sight here, and not
    /// `~/.stado/work`, which belongs to Stado. `base` is canonicalised
    /// first, because git reports the real path of a worktree and these
    /// assertions compare paths.
    pub fn new(label: &str) -> Self {
        let unique = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock before epoch")
            .as_nanos();
        let base = PathBuf::from(env!("CARGO_TARGET_TMPDIR")).join(format!(
            "tama-worktrees-cli-{label}-{}-{unique}",
            std::process::id()
        ));
        fs::create_dir_all(base.join("home")).expect("create scratch home");
        fs::create_dir_all(base.join("tree/repo")).expect("create scratch repo");
        fs::create_dir_all(base.join("tree/worktrees")).expect("create worktree parent");
        let fixture = Self {
            base: fs::canonicalize(&base).expect("canonicalise scratch base"),
        };
        let repo = fixture.repo();
        fixture.git(&repo, &["init", "-q"]);
        fs::write(repo.join("file.txt"), "one\n").expect("write tracked file");
        fixture.git(&repo, &["add", "file.txt"]);
        fixture.git(&repo, &["commit", "-q", "-m", "init"]);
        for name in ["wt-a", "wt-b"] {
            let path = fixture.worktree(name);
            let path = path.to_str().expect("worktree path is UTF-8");
            fixture.git(&repo, &["worktree", "add", "-q", "-b", name, path]);
        }
        fixture
    }

    pub fn root(&self) -> String {
        text(self.base.join("tree"))
    }

    pub fn repo(&self) -> PathBuf {
        self.base.join("tree/repo")
    }

    pub fn worktree(&self, name: &str) -> PathBuf {
        self.base.join("tree/worktrees").join(name)
    }

    /// The scratch home, an empty global config and no system config, so this
    /// machine's git configuration — a `core.hooksPath` included — can neither
    /// change the fixture nor be changed by it.
    pub fn env<'a>(&self, command: &'a mut Command) -> &'a mut Command {
        command
            .env("HOME", self.base.join("home"))
            .env("GIT_CONFIG_GLOBAL", self.base.join("home/.gitconfig"))
            .env("GIT_CONFIG_NOSYSTEM", "1")
            .env("GIT_AUTHOR_NAME", "Tama Test")
            .env("GIT_AUTHOR_EMAIL", "test@example.invalid")
            .env("GIT_COMMITTER_NAME", "Tama Test")
            .env("GIT_COMMITTER_EMAIL", "test@example.invalid")
    }

    pub fn git(&self, dir: &Path, args: &[&str]) -> Output {
        let mut command = Command::new("git");
        command.arg("-C").arg(dir).args(args);
        let output = self.env(&mut command).output().expect("run git");
        assert!(
            output.status.success(),
            "git {args:?} failed: {}",
            stderr(&output)
        );
        output
    }

    pub fn tama(&self, args: &[&str]) -> Output {
        let mut command = Command::new(env!("CARGO_BIN_EXE_tama-cli"));
        command
            .args(args)
            .env_remove("TAMA_ROOT")
            .env_remove("TAMA_HOOK_ENFORCEMENT")
            .env_remove("TAMA_EMERGENCY_STATE");
        self.env(&mut command).output().expect("run tama-cli")
    }

    /// What git itself says the repository's worktrees are, main one first.
    pub fn git_worktrees(&self) -> Vec<String> {
        stdout(&self.git(&self.repo(), &["worktree", "list", "--porcelain"]))
            .lines()
            .filter_map(|line| line.strip_prefix("worktree ").map(str::to_string))
            .collect()
    }

    /// The main worktree plus the two the fixture added.
    pub fn all_three(&self) -> Vec<String> {
        vec![
            text(self.repo()),
            text(self.worktree("wt-a")),
            text(self.worktree("wt-b")),
        ]
    }

    pub fn head(&self) -> String {
        stdout(&self.git(&self.repo(), &["rev-parse", "HEAD"]))
            .trim()
            .to_string()
    }
}

/// The whole root goes, worktrees and repository together, so no fixture
/// survives the run. A failing assertion unwinds through this drop just as a
/// passing case falls out of it, so the cleanup is not conditional on
/// success.
impl Drop for Fixture {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.base);
    }
}

pub fn text(path: PathBuf) -> String {
    path.to_string_lossy().into_owned()
}

pub fn stdout(output: &Output) -> String {
    String::from_utf8(output.stdout.clone()).expect("stdout is UTF-8")
}

pub fn stderr(output: &Output) -> String {
    String::from_utf8(output.stderr.clone()).expect("stderr is UTF-8")
}
