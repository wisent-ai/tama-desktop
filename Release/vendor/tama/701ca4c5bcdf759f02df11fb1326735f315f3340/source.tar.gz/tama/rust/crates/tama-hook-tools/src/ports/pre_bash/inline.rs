//! Throwaway programs, throwaway files, and the two shapes that were used to
//! walk around the write gates.
//!
//! On 2026-05-17 an oversized module was grown past the line limit twice:
//! once through a versioned full-path Python interpreter reading its program
//! from standard input, and once through a shell redirection writing the
//! source file directly. The Edit and Write tools are where source changes
//! go, because that is where the limits and the justifications run.
//!
//! The searcher ban came from the operator on the same theme: reading the
//! actual code is the work, and grepping for keywords across a tree is what
//! an agent does instead of reading it.

use std::sync::LazyLock;

use regex::Regex;

use crate::ports::transport_common as common;

static SCRATCH_WRITE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        "(>>?|cp |mv |tee )[[:space:]]*/tmp/[^[:space:];|&]+\\.({})",
        crate::ports::shell_text::source_extension_alternation()
    ))
});
static SCRATCH_HEREDOC: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        "cat[[:space:]]*>[[:space:]]*/tmp/[^[:space:];|&]+\\.({})",
        crate::ports::shell_text::source_extension_alternation()
    ))
});
static SCRATCH_RUN: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        "(^|[;&|`(]|[[:space:]])(python[0-9.]?|{}|{}|{})[[:space:]]+/tmp/",
        crate::ports::shell_text::javascript_runtime_alternation(),
        crate::ports::shell_text::scripting_alternation(),
        crate::ports::shell_text::shell_alternation()
    ))
});
static REVIEW_FOLDER_WRITE: LazyLock<Regex> =
    LazyLock::new(|| common::compile("(?i)(>|cp |mv |tee ).*/to_check/"));
static INLINE_SHELL: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        "(^|[;&|][[:space:]]*)({})[[:space:]]+-c[[:space:]]",
        crate::ports::shell_text::shell_alternation()
    ))
});
/// Any interpreter, any path, any version, given its program on the command
/// line or on standard input. `python[0-9.]?` allowed one character, so
/// `python3.11 - <<'EOF'` walked through both older rules.
static INLINE_PYTHON: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(^|[;&|`(]|/|[[:space:]])python([0-9]+(\\.[0-9]+)*)?",
        "([[:space:]]+(-c|--command|-)([[:space:]]|$)|[[:space:]]*<<)",
    ))
});
static INLINE_NODE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile("(^|[;&|][[:space:]]*)(node|npx)[[:space:]]+(-e|--eval|-p|--print)")
});
static ADHOC_NODE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile("(^|[;&|[:space:]])node[[:space:]]+(-e|--eval|-p[[:space:]]|/tmp/|\\$TMPDIR)")
});
static INLINE_RUBY_OR_PERL: LazyLock<Regex> =
    LazyLock::new(|| common::compile("(^|[;&|][[:space:]]*)(ruby|perl)[[:space:]]+(-e|--execute)"));
static SOURCE_WRITE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(>>?|[[:space:]]tee[[:space:]]|sed[[:space:]]+-i|dd[[:space:]]+[^|;&]*of=)[[:space:]]*",
        "[^[:space:];|&]*\\.(py|js|ts|tsx|jsx|mjs|cjs|rb|go|rs|java|kt|c|cc|cpp|h|hpp|sh)\\b",
    ))
});
static SEARCHER: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(^|[;&|`(]|[[:space:]])(grep|egrep|fgrep|rg|ag|ack|ack-grep|ugrep|pcregrep)",
        "([[:space:]]|$)",
    ))
});
static GIT_SEARCHER: LazyLock<Regex> =
    LazyLock::new(|| common::compile("(^|[;&|`(]|[[:space:]])git[[:space:]]+grep([[:space:]]|$)"));
static COOKIE_STORE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(
        "(Cookies|cookies\\.sqlite|Cookies\\.binarycookies|com\\.apple\\.Safari/Data/Library/Cookies)",
    )
});
static BROWSER_ENGINE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(
        "([Cc]hromium|chrome-headless|puppeteer|playwright[^a-z]|chromedriver|--headless=new|chrome --headless)",
    )
});
static MAC_MINI_SSH: LazyLock<Regex> =
    LazyLock::new(|| common::compile("ssh .*charles@charless-mac-mini"));
static MAC_MINI_GRANT: LazyLock<Regex> =
    LazyLock::new(|| common::compile("MAC_MINI_SSH_AUTHORIZED=1"));

const REVIEW_REFUSAL: &str = "BLOCKED: NEVER write to to_check folders.";
const SCRATCH_WRITE_REFUSAL: &str = "BLOCKED: Don't write scratch script files to /tmp/.";
const SCRATCH_HEREDOC_REFUSAL: &str = "BLOCKED: No 'cat > /tmp/file.py <<EOF'.";
const SCRATCH_RUN_REFUSAL: &str = "BLOCKED: Don't execute scripts under /tmp/.";
const INLINE_SHELL_REFUSAL: &str = "BLOCKED: No inline shell scripts.";
const INLINE_NODE_REFUSAL: &str = "BLOCKED: No inline node scripts.";
const INLINE_RUBY_REFUSAL: &str = "BLOCKED: No inline ruby/perl scripts.";
const INLINE_PYTHON_REFUSAL: &str = concat!(
    "BLOCKED: inline python (any path/version, via -c/--command/stdin/heredoc) is forbidden. It ",
    "was used to bypass the Edit/Write 300-line guard. Edit source through the Edit or Write ",
    "tool so the line-limit and justification hooks run; do not pipe code into a python ",
    "interpreter.",
);
const SOURCE_WRITE_REFUSAL: &str = concat!(
    "BLOCKED: writing/modifying a source file via bash redirection/tee/sed -i/dd is forbidden — ",
    "it bypasses the Edit/Write 300-line + justification guard. Use the Edit or Write tool.",
);
const ADHOC_NODE_REFUSAL: &str = concat!(
    "BLOCKED: BLOCKED: ad-hoc/inline node scripts are forbidden — use the existing CLI commands ",
    "or proper checked-in script files, never throwaway node code.",
);
const SEARCHER_REFUSAL: &str = concat!(
    "DO NOT GREP FOR RANDOM KEYWORDS. THIS IS AN ANTI PATTERN. READ THE ACTUAL FUCKING CODE AND ",
    "UNDERSTAND IT.",
);
const COOKIE_REFUSAL: &str = concat!(
    "BLOCKED: Browser cookie access is forbidden — do not read cookie stores for auth flows. ",
    "Ask the user before any cookie-based approach.",
);
const MAC_MINI_REFUSAL: &str = concat!(
    "BLOCKED: Blocked: do not SSH into the mac mini to start/manage daemons or jobs. Explain ",
    "what needs to happen and let the owner run it. (Override per-turn with ",
    "MAC_MINI_SSH_AUTHORIZED=1 prefix when explicitly authorized.)",
);
const BANNER_RULE: &str = "####################################################################################################";

/// The shouting banner the operator asked for, kept exactly.
fn browser_refusal() -> String {
    let shout = "YOU FUCKING RETARD. DO NOT USE CHROMIUM. DO NOT USE CHROMIUM. USE WELES";
    [
        "",
        BANNER_RULE,
        BANNER_RULE,
        BANNER_RULE,
        "",
        shout,
        shout,
        shout,
        "",
        BANNER_RULE,
        BANNER_RULE,
        BANNER_RULE,
        "",
        "BLOCKED: Chromium/Chrome/browser automation command detected. Use Weles.",
    ]
    .join("\n")
}

/// The refusal this command earns for being throwaway, if any.
pub(crate) fn refusal(command: &str) -> Option<String> {
    if REVIEW_FOLDER_WRITE.is_match(command) {
        return Some(REVIEW_REFUSAL.to_string());
    }
    if SCRATCH_WRITE.is_match(command) {
        return Some(SCRATCH_WRITE_REFUSAL.to_string());
    }
    if SCRATCH_HEREDOC.is_match(command) {
        return Some(SCRATCH_HEREDOC_REFUSAL.to_string());
    }
    if SCRATCH_RUN.is_match(command) {
        return Some(SCRATCH_RUN_REFUSAL.to_string());
    }
    if INLINE_SHELL.is_match(command) {
        return Some(INLINE_SHELL_REFUSAL.to_string());
    }
    if INLINE_PYTHON.is_match(command) {
        return Some(INLINE_PYTHON_REFUSAL.to_string());
    }
    if INLINE_NODE.is_match(command) {
        return Some(INLINE_NODE_REFUSAL.to_string());
    }
    if INLINE_RUBY_OR_PERL.is_match(command) {
        return Some(INLINE_RUBY_REFUSAL.to_string());
    }
    if SOURCE_WRITE.is_match(command) {
        return Some(SOURCE_WRITE_REFUSAL.to_string());
    }
    if ADHOC_NODE.is_match(command) {
        return Some(ADHOC_NODE_REFUSAL.to_string());
    }
    if BROWSER_ENGINE.is_match(command) {
        return Some(browser_refusal());
    }
    if MAC_MINI_SSH.is_match(command) && !MAC_MINI_GRANT.is_match(command) {
        return Some(MAC_MINI_REFUSAL.to_string());
    }
    if COOKIE_STORE.is_match(command) {
        return Some(COOKIE_REFUSAL.to_string());
    }
    match SEARCHER.is_match(command) || GIT_SEARCHER.is_match(command) {
        true => Some(SEARCHER_REFUSAL.to_string()),
        false => None,
    }
}

#[cfg(test)]
mod tests {
    use super::refusal;

    #[test]
    fn a_program_on_the_command_line_is_refused_whatever_the_interpreter() {
        for command in [
            "bash -c 'ls'",
            "python3 -c 'print(1)'",
            "/opt/homebrew/opt/python@3.11/bin/python3.11 - <<'EOF'",
            "node -e 'x'",
            "perl -e 'print 1'",
        ] {
            assert!(refusal(command).is_some(), "{command}");
        }
    }

    /// The two shapes that grew a file past the line limit. The rule reads
    /// the verb and the path next to each other, so `sed -i '' -e … file.py`
    /// — the spelling this platform's sed requires — is not caught here; it
    /// is recorded rather than quietly widened, because widening it would
    /// also refuse the ordinary in-place edits this workshop relies on.
    #[test]
    fn the_write_gate_bypasses_are_refused() {
        let redirect = refusal("cat build.txt > src/worker.py").expect("a source write");
        assert!(redirect.contains("Edit or Write tool"), "{redirect}");
        let piped = refusal("printf x | tee src/worker.py").expect("a source write");
        assert!(piped.contains("Edit or Write tool"), "{piped}");
        assert_eq!(refusal("sed -i '' -e 's/a/b/' src/worker.py"), None);
    }

    #[test]
    fn throwaway_files_under_the_temporary_directory_are_refused() {
        assert!(refusal("printf 'x' > /tmp/probe.py").is_some());
        assert!(refusal("python3 /tmp/probe.py").is_some());
    }

    #[test]
    fn a_searcher_is_refused_in_the_operators_words() {
        let found = refusal("grep -rn needle src/").expect("a searcher");
        assert!(found.contains("READ THE ACTUAL"), "{found}");
        assert!(refusal("git grep needle").is_some());
    }

    #[test]
    fn a_browser_engine_and_a_cookie_store_are_refused() {
        let browser = refusal("chromium --headless https://x").expect("an engine");
        assert!(browser.contains("USE WELES"), "{browser}");
        assert!(refusal("cat ~/Library/Cookies/Cookies.binarycookies").is_some());
    }

    /// The per-turn grant the operator added, read from the command itself.
    #[test]
    fn the_mac_mini_grant_is_read_from_the_command() {
        assert!(refusal("ssh charles@charless-mac-mini 'launchctl list'").is_some());
        assert_eq!(
            refusal("MAC_MINI_SSH_AUTHORIZED=1 ssh charles@charless-mac-mini 'launchctl list'"),
            None
        );
    }

    #[test]
    fn ordinary_commands_pass() {
        for command in [
            "cargo build --release",
            "npm run test:hook-consent",
            "git status --short",
        ] {
            assert_eq!(refusal(command), None, "{command}");
        }
    }
}
