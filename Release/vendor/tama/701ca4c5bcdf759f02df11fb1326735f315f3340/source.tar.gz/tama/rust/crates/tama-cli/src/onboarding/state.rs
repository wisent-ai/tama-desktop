//! Onboarding state persistence: where the state file lives, how a stored
//! state is validated or started fresh, and how writes stay atomic.

use serde_json::{json, Value};
use std::fs;
use std::path::{Path, PathBuf};

use super::screens::screen_by_id;
use super::{JOURNEY_ID, JOURNEY_VERSION, PRODUCT_ID, STATE_SCHEMA};

pub(super) fn load_or_start_state(definition: &Value, path: &Path) -> Result<Value, String> {
    if path.exists() {
        let state: Value = serde_json::from_str(
            &fs::read_to_string(path)
                .map_err(|error| format!("could not read {}: {error}", path.display()))?,
        )
        .map_err(|error| format!("could not parse {}: {error}", path.display()))?;
        if state.get("schema").and_then(Value::as_str) != Some(STATE_SCHEMA)
            || state.get("product_id").and_then(Value::as_str) != Some(PRODUCT_ID)
            || state.get("journey_id").and_then(Value::as_str) != Some(JOURNEY_ID)
            || state.get("journey_version").and_then(Value::as_str) != Some(JOURNEY_VERSION)
        {
            return Err("stored Tama onboarding state is incompatible; use --reset".to_string());
        }
        let current_screen_id = state
            .get("current_screen_id")
            .and_then(Value::as_str)
            .ok_or_else(|| "stored Tama onboarding state has no current screen".to_string())?;
        screen_by_id(definition, current_screen_id)?;
        return Ok(state);
    }

    let entry_screen_id = definition
        .get("entry_screen_id")
        .and_then(Value::as_str)
        .ok_or_else(|| "Tama onboarding definition has no entry screen".to_string())?;
    let state = json!({
        "schema": STATE_SCHEMA,
        "product_id": PRODUCT_ID,
        "journey_id": JOURNEY_ID,
        "journey_version": JOURNEY_VERSION,
        "source_revision": definition.get("source_revision").cloned().unwrap_or(Value::Null),
        "current_screen_id": entry_screen_id,
        "status": "in_progress",
        "evidence": {}
    });
    save_state(path, &state)?;
    Ok(state)
}

pub(super) fn save_state(path: &Path, state: &Value) -> Result<(), String> {
    let parent = path
        .parent()
        .ok_or_else(|| "Tama onboarding state path has no parent".to_string())?;
    fs::create_dir_all(parent)
        .map_err(|error| format!("could not create {}: {error}", parent.display()))?;
    let temporary = path.with_extension(format!("json.tmp-{}", std::process::id()));
    let body = serde_json::to_string_pretty(state)
        .map_err(|error| format!("could not encode Tama onboarding state: {error}"))?;
    fs::write(&temporary, format!("{body}\n"))
        .map_err(|error| format!("could not write {}: {error}", temporary.display()))?;
    fs::rename(&temporary, path)
        .map_err(|error| format!("could not replace {}: {error}", path.display()))?;
    Ok(())
}

pub(super) fn state_path() -> PathBuf {
    if let Some(path) = std::env::var_os("XDG_STATE_HOME") {
        return PathBuf::from(path).join("tama/onboarding.json");
    }
    if let Some(home) = std::env::var_os("HOME") {
        return PathBuf::from(home).join(".local/state/tama/onboarding.json");
    }
    std::env::temp_dir().join("tama/onboarding.json")
}
