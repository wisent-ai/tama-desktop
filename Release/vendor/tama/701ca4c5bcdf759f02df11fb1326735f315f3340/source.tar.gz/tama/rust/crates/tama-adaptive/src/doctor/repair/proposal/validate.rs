//! Running a candidate against the labelled corpus: everything that must
//! block still blocks, everything that must pass passes, and an empty
//! payload does not crash it.
//!
//! Split out of `doctor/repair.rs`, which had grown past the
//! three-hundred-line limit.

use std::fs;

use super::super::corpus::{hook_paths, split_corpus};
use super::super::spawn::{block_verdict, spawn_sync_capture, SpawnOutcome};
use crate::engine::load_engine;
use crate::segments::runner_command::extname;

/// A report that never ran anything says so with this count.
const NOTHING_CHECKED: u64 = 0;

fn interpreter_for(ext: &str) -> Option<&'static str> {
    match ext {
        ".py" => Some("python3"),
        ".sh" => Some("bash"),
        ".mjs" => Some("node"),
        _ => None,
    }
}

/// `validateCandidate(hookId, candidateFilePath)` — returns the JS report
/// object shape (`{ ok, checked, failures, staged? }`).
pub fn validate_candidate(
    hook_id: &str,
    candidate_file_path: &str,
) -> Result<serde_json::Value, String> {
    let core = load_engine();
    let paths = hook_paths(hook_id, &core);
    let mut ext = extname(candidate_file_path);
    if ext.is_empty() {
        if let Some(live) = &paths.live {
            ext = extname(live);
        }
    }
    let Some(interpreter) = interpreter_for(&ext) else {
        return Ok(serde_json::json!({
            "ok": false,
            "checked": NOTHING_CHECKED,
            "failures": [{ "kind": "setup", "detail": format!("no interpreter for extension \"{}\"", ext) }],
        }));
    };
    let corpus = split_corpus(&core.state_dir, hook_id)?;
    if corpus.labeled_count == 0 {
        return Ok(serde_json::json!({
            "ok": false,
            "checked": NOTHING_CHECKED,
            "failures": [{ "kind": "insufficient-evidence", "detail": "no labeled corpus cases in validated closed telemetry segments" }],
        }));
    }
    let tmp_dir = core.state_dir.join("tmp");
    fs::create_dir_all(&tmp_dir).map_err(|e| format!("Error: {}", e))?;
    let staged = tmp_dir.join(format!("{}-under-test{}", hook_id, ext));
    fs::copy(candidate_file_path, &staged).map_err(|e| format!("Error: {}", e))?;
    let staged_text = staged.to_string_lossy().to_string();
    let run = |payload: &serde_json::Value| -> SpawnOutcome {
        let input = serde_json::to_string(payload).unwrap_or_else(|_| "{}".to_string());
        spawn_sync_capture(interpreter, &[staged_text.clone()], &input)
    };
    let mut failures: Vec<serde_json::Value> = Vec::new();
    let mut checked = NOTHING_CHECKED;
    for row in &corpus.must_block {
        checked += 1;
        let result = run(row.get("payload").unwrap_or(&serde_json::Value::Null));
        let blocked = block_verdict(&result) || result.status != Some(0);
        if !blocked {
            failures.push(serde_json::json!({
                "kind": "must-block",
                "ts": row.get("ts").cloned().unwrap_or(serde_json::Value::Null),
                "detail": "payload that must block passed",
            }));
        }
    }
    for row in &corpus.must_pass {
        checked += 1;
        let result = run(row.get("payload").unwrap_or(&serde_json::Value::Null));
        let clean = result.status == Some(0)
            && result.error.is_none()
            && result.signal.is_none()
            && !block_verdict(&result);
        if !clean {
            let detail = if let Some(error) = &result.error {
                error.clone()
            } else if block_verdict(&result) {
                "explicit block verdict".to_string()
            } else {
                let what = result
                    .status
                    .map(|s| s.to_string())
                    .or_else(|| result.signal.clone())
                    .unwrap_or_else(|| "null".to_string());
                format!("exit {}", what)
            };
            failures.push(serde_json::json!({
                "kind": "must-pass",
                "ts": row.get("ts").cloned().unwrap_or(serde_json::Value::Null),
                "detail": detail,
            }));
        }
    }
    checked += 1; // smoke run: an empty object payload must not crash the script
    let smoke = run(&serde_json::json!({}));
    if smoke.error.is_some() || smoke.signal.is_some() {
        let what = smoke
            .error
            .clone()
            .or(smoke.signal.clone())
            .unwrap_or_default();
        failures.push(serde_json::json!({
            "kind": "smoke",
            "detail": format!("crashed on empty payload: {}", what),
        }));
    }
    Ok(serde_json::json!({
        "ok": failures.is_empty(),
        "checked": checked,
        "failures": failures,
        "staged": staged_text,
    }))
}
