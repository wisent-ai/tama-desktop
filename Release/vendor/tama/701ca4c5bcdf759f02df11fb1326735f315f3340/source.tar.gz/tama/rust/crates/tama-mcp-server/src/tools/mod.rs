//! tools/call handlers (mcp-server.mjs), split out of `main.rs`.

pub mod rawjson;

use serde_json::Value;
use std::path::Path;

use crate::protocol::jsvalues::{js_template, js_truthy};
use rawjson::{load_raw_requirements, HookOut};
use tama_core::catalog::{build_catalog, find_hook, validate_catalog};
use tama_violations::find_violations::scan_repo;

pub fn call_tool(root: &Path, params: &Value) -> Result<String, String> {
    let object = params.as_object().ok_or("params is not an object")?;
    let name = object
        .get("name")
        .and_then(|v| v.as_str())
        .ok_or("params.name is not a string")?;
    let args = object.get("arguments").and_then(|v| v.as_object());
    let arg = |key: &str| args.and_then(|a| a.get(key));
    match name {
        "list_hooks" => {
            let catalog = build_catalog(root).map_err(|e| e.to_string())?;
            let hooks = if js_truthy(arg("blockingOnly")) {
                catalog
                    .hooks
                    .into_iter()
                    .filter(|hook| hook.events.iter().any(|ev| ev.blocking))
                    .collect::<Vec<_>>()
            } else {
                catalog.hooks
            };
            let raw_reqs = load_raw_requirements(root);
            let out: Vec<HookOut> = hooks
                .iter()
                .map(|hook| HookOut {
                    hook,
                    raw_reqs: raw_reqs.get(&hook.id).map(Vec::as_slice),
                })
                .collect();
            serde_json::to_string_pretty(&out).map_err(|e| e.to_string())
        }
        "show_hook" => {
            let id = arg("id");
            let hook = match id {
                Some(Value::String(id)) => find_hook(id, root).map_err(|e| e.to_string())?,
                _ => None,
            };
            let hook = hook.ok_or_else(|| format!("hook not found: {}", js_template(id)))?;
            let raw_reqs = load_raw_requirements(root);
            let out = HookOut {
                hook: &hook,
                raw_reqs: raw_reqs.get(&hook.id).map(Vec::as_slice),
            };
            serde_json::to_string_pretty(&out).map_err(|e| e.to_string())
        }
        "read_hook_source" => {
            let id = arg("id");
            let hook = match id {
                Some(Value::String(id)) => find_hook(id, root).map_err(|e| e.to_string())?,
                _ => None,
            };
            let source_path = hook
                .and_then(|h| h.source_path)
                .filter(|p| !p.is_empty())
                .ok_or_else(|| format!("hook source not found: {}", js_template(id)))?;
            let path = root.join(&source_path);
            let bytes = std::fs::read(&path).map_err(|e| {
                if e.kind() == std::io::ErrorKind::NotFound {
                    // Node readFileSync error message, reproduced literally.
                    format!(
                        "ENOENT: no such file or directory, open '{}'",
                        path.to_string_lossy()
                    )
                } else {
                    e.to_string()
                }
            })?;
            Ok(String::from_utf8_lossy(&bytes).into_owned())
        }
        "validate_hooks" => {
            let result = validate_catalog(root).map_err(|e| e.to_string())?;
            serde_json::to_string_pretty(&result).map_err(|e| e.to_string())
        }
        "find_violations" => {
            let repo = arg("repo");
            // JS: `if (!args.repo || !existsSync(args.repo))` — a truthy
            // non-string makes existsSync return false (no throw).
            let exists = match repo {
                Some(Value::String(path)) => !path.is_empty() && Path::new(path).exists(),
                _ => false,
            };
            if !js_truthy(repo) || !exists {
                let shown = match repo {
                    None | Some(Value::Null) => "(missing)".to_string(),
                    other => js_template(other),
                };
                return Err(format!("repo not found: {}", shown));
            }
            let repo = match repo {
                Some(Value::String(path)) => path.clone(),
                _ => unreachable!("repo checked above"),
            };
            let hook_path = match arg("hookPath") {
                Some(Value::String(path)) if !path.is_empty() => path.clone(),
                other if js_truthy(other) => js_template(other),
                _ => root
                    .join("shared-hooks")
                    .join("pre_write_edit.sh")
                    .to_string_lossy()
                    .into_owned(),
            };
            let report = scan_repo(Path::new(&repo), Path::new(&hook_path));
            serde_json::to_string_pretty(&report).map_err(|e| e.to_string())
        }
        other => Err(format!("unknown tool: {}", other)),
    }
}
