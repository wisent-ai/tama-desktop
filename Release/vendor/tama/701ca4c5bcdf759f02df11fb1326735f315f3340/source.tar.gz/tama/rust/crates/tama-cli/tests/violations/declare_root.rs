//! Declaring a repository root the folder rule cannot reach.
//!
//! Six files fixed at a root by npm, cargo, git, GitHub and the release
//! tooling already exceed the limit of five, so the audit's own answer is
//! the `.` entry. These cases drive the real command: what it refuses, what
//! it writes, and that a second run changes nothing.

use std::fs;

use crate::fixture::Fixture;

const DECLARATION: &str = ".tama/violations-ignore";

fn tool_fixed_root(f: &Fixture) {
    for name in [
        "README.md",
        "LICENSE",
        "package.json",
        "package-lock.json",
        ".gitignore",
        ".wisent-release.json",
    ] {
        fs::write(f.repo.join(name), "{}\n").unwrap();
    }
}

/// A root of nothing but other people's tooling is declared, and the
/// declaration says which tool holds which file there.
#[test]
fn a_root_of_tool_fixed_files_is_declared_with_its_reasons() {
    let f = Fixture::new();
    tool_fixed_root(&f);
    let out = f.run("declare-root-apply", "declare-root", &["--apply", "--json"]);
    let stderr = String::from_utf8_lossy(&out.stderr).into_owned();
    assert_eq!(out.status.code(), Some(0), "{stderr}");
    let report: serde_json::Value = serde_json::from_slice(&out.stdout).unwrap();
    assert_eq!(report[0]["declared"], true, "{report}");
    let written = fs::read_to_string(f.repo.join(DECLARATION)).unwrap();
    assert!(written.lines().any(|line| line.trim() == "."), "{written}");
    assert!(written.contains("package.json — npm"), "{written}");
    assert!(written.contains(".gitignore — git"), "{written}");

    // The scan is the consumer: the root stops being reported.
    let scan = f.run(
        "declare-root-scan",
        "find-violations",
        &["--json", "--size-only"],
    );
    let scanned: serde_json::Value = serde_json::from_slice(&scan.stdout).unwrap();
    let hits = scanned["repos"][0]["violations"].as_array().unwrap();
    assert!(!hits.iter().any(|hit| hit["path"] == "."), "{scanned}");
}

/// A file somebody could move is not a reason to declare a root. The
/// command names it and writes nothing, so the declaration can never
/// launder ordinary clutter.
#[test]
fn a_movable_file_at_the_root_is_refused_by_name() {
    let f = Fixture::new();
    tool_fixed_root(&f);
    fs::write(f.repo.join("helper.mjs"), "export const helper = true\n").unwrap();
    let out = f.run(
        "declare-root-refused",
        "declare-root",
        &["--apply", "--json"],
    );
    assert_eq!(out.status.code(), Some(1));
    let report: serde_json::Value = serde_json::from_slice(&out.stdout).unwrap();
    assert_eq!(report[0]["declared"], false, "{report}");
    assert!(
        report[0]["reason"]
            .as_str()
            .unwrap_or_default()
            .contains("helper.mjs"),
        "{report}"
    );
    assert!(!f.repo.join(DECLARATION).exists(), "nothing was written");
}

/// Running it twice leaves one declaration, so a sweep over a workshop can
/// be repeated without growing the file it writes.
#[test]
fn a_second_run_declares_nothing_new() {
    let f = Fixture::new();
    tool_fixed_root(&f);
    f.run("declare-root-first", "declare-root", &["--apply"]);
    let first = fs::read_to_string(f.repo.join(DECLARATION)).unwrap();
    let out = f.run(
        "declare-root-second",
        "declare-root",
        &["--apply", "--json"],
    );
    assert_eq!(out.status.code(), Some(0));
    let report: serde_json::Value = serde_json::from_slice(&out.stdout).unwrap();
    assert_eq!(
        report[0]["reason"], "the root is already declared",
        "{report}"
    );
    assert_eq!(fs::read_to_string(f.repo.join(DECLARATION)).unwrap(), first);
}

/// Without `--apply` the command is a report: it says what it would do and
/// leaves the repository as it found it.
#[test]
fn without_apply_the_root_is_only_reported() {
    let f = Fixture::new();
    tool_fixed_root(&f);
    let out = f.run("declare-root-preview", "declare-root", &["--json"]);
    assert_eq!(out.status.code(), Some(1));
    let report: serde_json::Value = serde_json::from_slice(&out.stdout).unwrap();
    assert_eq!(report[0]["reason"], "would declare the root", "{report}");
    assert!(!f.repo.join(DECLARATION).exists());
}

/// A declaration only in a working tree is one the next clone does not
/// have, so the sweep can carry it into history — including a file an
/// earlier run wrote and left uncommitted.
#[test]
fn the_declaration_can_be_carried_into_history() {
    let f = Fixture::new();
    tool_fixed_root(&f);
    f.run("declare-root-written", "declare-root", &["--apply"]);
    let out = f.run(
        "declare-root-committed",
        "declare-root",
        &["--apply", "--commit", "--json"],
    );
    let stderr = String::from_utf8_lossy(&out.stderr).into_owned();
    assert_eq!(out.status.code(), Some(0), "{stderr}");
    let report: serde_json::Value = serde_json::from_slice(&out.stdout).unwrap();
    assert_eq!(
        report[0]["reason"], "the declaration was committed",
        "{report}"
    );
    let committed = std::process::Command::new("git")
        .args(["show", "--name-only", "--pretty=format:", "HEAD"])
        .current_dir(&f.repo)
        .output()
        .unwrap();
    let names = String::from_utf8_lossy(&committed.stdout).into_owned();
    assert!(names.contains(DECLARATION), "{names}");
    let dirty = std::process::Command::new("git")
        .args(["status", "--porcelain", "--", DECLARATION])
        .current_dir(&f.repo)
        .output()
        .unwrap();
    assert!(dirty.stdout.is_empty(), "the declaration is still dirty");
}

/// A Swift toolchain leaves its output beside the code it read, and `oko`
/// had four such files committed at its root next to `.swiftlint.yml`,
/// which SwiftLint really does read from there. The declaration takes the
/// configuration and the tidy pass removes the output, whatever stem the
/// compiler happened to use.
#[test]
fn a_swift_root_keeps_its_configuration_and_loses_its_build_output() {
    let f = Fixture::new();
    tool_fixed_root(&f);
    fs::write(f.repo.join(".swiftlint.yml"), "disabled_rules: []\n").unwrap();
    for name in [
        "EmbeddedOnboardingDefinition.generated-2.swiftmodule",
        "EmbeddedOnboardingDefinition.generated-2.swiftdeps",
        "EmbeddedOnboardingDefinition.generated-2.dia",
    ] {
        fs::write(f.repo.join(name), "compiler output\n").unwrap();
    }
    let out = f.run(
        "declare-root-swift",
        "declare-root",
        &["--apply", "--tidy", "--json"],
    );
    let stderr = String::from_utf8_lossy(&out.stderr).into_owned();
    assert_eq!(out.status.code(), Some(0), "{stderr}");
    assert!(f.repo.join(".swiftlint.yml").exists(), "SwiftLint reads it");
    assert!(
        !f.repo
            .join("EmbeddedOnboardingDefinition.generated-2.swiftmodule")
            .exists(),
        "the compiler's own output is not a root file"
    );
    let ignored = fs::read_to_string(f.repo.join(".gitignore")).unwrap_or_default();
    assert!(
        ignored.contains("EmbeddedOnboardingDefinition.generated-2.dia"),
        "it comes back on the next build unless it is ignored: {ignored}"
    );
    let declaration = fs::read_to_string(f.repo.join(DECLARATION)).unwrap();
    assert!(declaration.contains(".swiftlint.yml"), "{declaration}");
}
