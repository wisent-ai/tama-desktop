//! Where a hook's files are, and the labelled corpus a candidate has to
//! satisfy: what must pass and what must block.
//!
//! Split out of `doctor/repair.rs`, which had grown past the
//! three-hundred-line limit.

use std::collections::HashMap;
use std::path::{Path, PathBuf};

use super::catalog::{command_source_path, find_hook};
use crate::doctor::evidence::{live_script_path, read_closed_telemetry_events};
use crate::util::repo_root;

pub(super) struct HookPaths {
    pub(super) command: Option<String>,
    pub(super) live: Option<String>,
    pub(super) archive: Option<PathBuf>,
}

fn registry_command(hook_id: &str, core: &crate::engine::Engine) -> Option<String> {
    for event in core.registry.events.values() {
        for entry in &event.hooks {
            if entry.id == hook_id {
                if let Some(command) = &entry.command {
                    if !command.is_empty() {
                        return Some(command.clone());
                    }
                }
            }
        }
    }
    None
}

pub(super) fn hook_paths(hook_id: &str, core: &crate::engine::Engine) -> HookPaths {
    let root = repo_root();
    let catalog_hook = find_hook(hook_id, &root);
    // `registryCommand(...) ?? catalogHook?.command ?? null` — nullish
    // coalescing keeps an empty-string command.
    let command = registry_command(hook_id, core)
        .or_else(|| catalog_hook.as_ref().map(|h| h.command.clone()));
    let live = command
        .as_deref()
        .filter(|c| !c.is_empty())
        .and_then(live_script_path);
    let archive_rel = catalog_hook
        .and_then(|h| h.source_path)
        .or_else(|| command.as_deref().and_then(command_source_path));
    let archive = archive_rel.map(|rel| root.join(rel));
    HookPaths {
        command,
        live,
        archive,
    }
}

pub(super) struct Corpus {
    pub(super) must_pass: Vec<serde_json::Value>,
    pub(super) must_block: Vec<serde_json::Value>,
    pub(super) labeled_count: usize,
}

/// `splitCorpus(stateDir, hookId)` — the latest label targeting a payload
/// wins; without `payloadTs` a label applies to the newest payload.
pub(super) fn split_corpus(state_dir: &Path, hook_id: &str) -> Result<Corpus, String> {
    let rows = read_closed_telemetry_events(state_dir)?;
    let mut payloads: Vec<serde_json::Value> = Vec::new();
    let mut labels: HashMap<usize, serde_json::Value> = HashMap::new();
    for row in &rows {
        if row.get("id") != Some(&serde_json::Value::String(hook_id.to_string())) {
            continue;
        }
        let row_type = row.get("type").and_then(|v| v.as_str()).unwrap_or("");
        if row_type == "corpus_add" {
            payloads.push(row.clone());
            let index = payloads.len() - 1;
            if let Some(label) = row.get("label") {
                if crate::util::js_truthy(label) && label.as_str() != Some("unlabeled") {
                    labels.insert(index, label.clone());
                }
            }
            continue;
        }
        if row_type != "corpus_label" {
            continue;
        }
        let mut target: Option<usize> = None;
        if let Some(payload_ts) = row.get("payloadTs") {
            for index in (0..payloads.len()).rev() {
                if payloads[index].get("ts") == Some(payload_ts) {
                    target = Some(index);
                    break;
                }
            }
        } else if !payloads.is_empty() {
            target = Some(payloads.len() - 1);
        }
        if let Some(index) = target {
            let label = row.get("label").cloned().unwrap_or(serde_json::Value::Null);
            let label = if label.is_null() {
                serde_json::Value::String("unlabeled".to_string())
            } else {
                label
            };
            labels.insert(index, label);
        }
    }
    let mut must_pass = Vec::new();
    let mut must_block = Vec::new();
    for (index, row) in payloads.into_iter().enumerate() {
        let label = labels
            .get(&index)
            .cloned()
            .unwrap_or(serde_json::Value::String("unlabeled".to_string()));
        if label.as_str() == Some("unlabeled") {
            continue;
        }
        if label.as_str() == Some("fp") || label.as_str() == Some("fp-suspect") {
            must_pass.push(row);
        } else {
            must_block.push(row);
        }
    }
    let labeled_count = must_pass.len() + must_block.len();
    Ok(Corpus {
        must_pass,
        must_block,
        labeled_count,
    })
}
