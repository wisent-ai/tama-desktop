//! The three-part report the communication contract asks for — what was
//! done, blockers, next steps — read back as sections, the repositories of
//! this workshop that a blocker names, and the next step that is not a next
//! step: a decision handed back, or the agent's own work announced.
//!
//! A heading is a line that is nothing but one of the known titles, with any
//! markdown dressing (`##`, `**`, `_`, a trailing colon) stripped. A section
//! runs to the next heading. The contract is bilingual, so the titles are.

use std::path::{Path, PathBuf};

use super::titles::{
    checkouts, title_of, work_in_repo, Title, ANNOUNCED, HANDED_BACK, LINE_JOIN, MONEY, NONE,
};
use crate::ports::transport_common as common;

/// The report's blockers and next steps, when the message has those headings.
#[derive(Debug, Default, PartialEq, Eq)]
pub struct Report {
    pub blockers: Option<String>,
    pub next_steps: Option<String>,
}

impl Report {
    pub fn parse(message: &str) -> Report {
        let mut report = Report::default();
        let mut current: Option<Title> = None;
        let mut body: Vec<&str> = Vec::new();
        let close = |current: Option<Title>, body: &mut Vec<&str>, report: &mut Report| {
            let text = body.join(LINE_JOIN).trim().to_owned();
            match current {
                Some(Title::Blockers) => report.blockers = Some(text),
                Some(Title::NextSteps) => report.next_steps = Some(text),
                _ => {}
            }
            body.clear();
        };
        for line in message.lines() {
            if let Some(title) = title_of(line) {
                close(current, &mut body, &mut report);
                current = Some(title);
            } else if current.is_some() {
                body.push(line);
            }
        }
        close(current, &mut body, &mut report);
        report
    }

    /// True when the report says there is nothing for anyone outside to do:
    /// the heading is there and its body is empty or "none".
    pub fn next_steps_are_none(&self) -> bool {
        match &self.next_steps {
            Some(text) => text.is_empty() || NONE.is_match(text),
            None => false,
        }
    }

    /// The first line under Następne kroki that is not a step for the
    /// operator: a decision or go-ahead handed back, or the agent's own work
    /// announced. A line that names a cost is the operator's, whatever else
    /// it says.
    pub fn next_step_that_is_the_agent_s(&self) -> Option<NotAStep<'_>> {
        let text = self.next_steps.as_deref()?;
        text.lines()
            .map(str::trim)
            .filter(|line| !line.is_empty() && !MONEY.is_match(line))
            .find_map(|line| {
                if HANDED_BACK.is_match(line) {
                    Some(NotAStep::HandedBack(line))
                } else if ANNOUNCED.is_match(line) {
                    Some(NotAStep::Announced(line))
                } else {
                    None
                }
            })
    }
}

/// Why a line under Następne kroki is the agent's own work.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum NotAStep<'a> {
    /// A decision, choice or permission the line hands to the operator.
    HandedBack(&'a str),
    /// The agent's own future work, announced instead of done.
    Announced(&'a str),
}

/// Every repository checked out under the workshop root of this home.
pub fn checkout_root(home: &Path) -> PathBuf {
    checkouts()
        .iter()
        .fold(home.to_path_buf(), |path, part| path.join(part))
}

pub fn checked_out_repositories(home: &Path) -> Vec<String> {
    let Ok(entries) = std::fs::read_dir(checkout_root(home)) else {
        return Vec::new();
    };
    let mut names: Vec<String> = entries
        .filter_map(Result::ok)
        .filter(|entry| entry.path().is_dir())
        .filter_map(|entry| entry.file_name().into_string().ok())
        .filter(|name| !name.starts_with('.'))
        .collect();
    names.sort();
    names
}

/// The checked-out repositories a piece of text names as a place of work:
/// as a path (`skarbiec/src/…`, `Wisent/stado`) or after a work word
/// ("zmiana w stado-rs"). A bare name is not enough — `jeden` and `most`
/// are also words.
pub fn repositories_named(text: &str, repositories: &[String]) -> Vec<String> {
    let work_word = work_in_repo();
    repositories
        .iter()
        .filter(|name| {
            let escaped = regex::escape(name);
            let as_path =
                common::compile(&format!("(?i)(^|[\\s`'\"(\\[]|Wisent/){escaped}(/|\\b)"));
            let path_like = as_path
                .find_iter(text)
                .any(|found| found.as_str().ends_with('/') || found.as_str().contains("Wisent/"));
            let after_work_word =
                common::compile(&format!("{work_word}{escaped}\\b")).is_match(text);
            path_like || after_work_word
        })
        .cloned()
        .collect()
}

#[cfg(test)]
mod tests {
    use super::{repositories_named, NotAStep, Report};

    const REPORT: &str = "## Co zostało zrobione\nZrobione A.\n\n## Blokery\n- Wydanie: HTTP 403. \
        Warunek wznowienia: to zmiana w wisent-compute/stado-rs.\n\n## Następne kroki\n\nŻadnych.\n";

    #[test]
    fn the_three_sections_are_read_back() {
        let report = Report::parse(REPORT);
        assert!(report
            .blockers
            .as_deref()
            .unwrap_or_default()
            .contains("HTTP 403"));
        assert!(report.next_steps_are_none());
    }

    #[test]
    fn a_named_next_step_is_not_none() {
        let report = Report::parse(
            "Blokery\nX.\n\nNastępne kroki\nWyeksportuj DEVICE_HOOK_EDIT_APPROVED=1.",
        );
        assert!(!report.next_steps_are_none());
    }

    fn next_steps(body: &str) -> Report {
        Report::parse(&format!("## Następne kroki\n{body}"))
    }

    #[test]
    fn a_decision_or_a_go_ahead_under_next_steps_is_the_agent_s() {
        for line in [
            "Decyzja, czy budować te trzy zmiany.",
            "Czy mam wdrożyć to na mini?",
            "Potwierdź, że mogę scalić.",
            "Whether to build the breaker in omp as well.",
            "Let me know if you want the GUI screen too.",
        ] {
            assert_eq!(
                next_steps(line).next_step_that_is_the_agent_s(),
                Some(NotAStep::HandedBack(line)),
                "{line}"
            );
        }
    }

    #[test]
    fn the_agent_s_own_future_work_under_next_steps_is_the_agent_s() {
        assert_eq!(
            next_steps("Zbuduję kontrakt wydania w Stado.").next_step_that_is_the_agent_s(),
            Some(NotAStep::Announced("Zbuduję kontrakt wydania w Stado."))
        );
        assert_eq!(
            next_steps("Next I will wire the GUI.").next_step_that_is_the_agent_s(),
            Some(NotAStep::Announced("Next I will wire the GUI."))
        );
    }

    #[test]
    fn the_operator_s_own_step_and_a_cost_pass() {
        for line in [
            "Żadnych.",
            "Poza sesją wyeksportuj DEVICE_HOOK_EDIT_APPROVED=1 i uruchom plik hand-over; odmowa: BLOCKED.",
            "Decyzja o podniesieniu limitu wydatków Brama do 200 USD miesięcznie.",
            "Approve the USD 40 Apple Developer renewal; the build stops at the expired certificate.",
        ] {
            assert_eq!(next_steps(line).next_step_that_is_the_agent_s(), None, "{line}");
        }
        assert_eq!(
            Report::parse("Zrobione.").next_step_that_is_the_agent_s(),
            None
        );
    }

    #[test]
    fn a_report_without_headings_has_no_sections() {
        assert_eq!(Report::parse("Zrobione."), Report::default());
    }

    #[test]
    fn a_repository_is_named_as_a_path_or_after_a_work_word() {
        let repos = vec![
            "wisent-compute".to_owned(),
            "skarbiec".to_owned(),
            "jeden".to_owned(),
        ];
        assert_eq!(
            repositories_named(
                "to zmiana w wisent-compute/stado-rs, oraz skarbiec/src/access",
                &repos
            ),
            vec!["wisent-compute".to_owned(), "skarbiec".to_owned()]
        );
        assert_eq!(
            repositories_named("a fix in skarbiec", &repos),
            vec!["skarbiec".to_owned()]
        );
        assert_eq!(
            repositories_named("jeden z trzech hostów odpowiada", &repos),
            Vec::<String>::new(),
            "the number one is not the repository"
        );
        assert_eq!(
            repositories_named("~/Documents/CodingProjects/Wisent/jeden", &repos),
            vec!["jeden".to_owned()]
        );
    }
}
