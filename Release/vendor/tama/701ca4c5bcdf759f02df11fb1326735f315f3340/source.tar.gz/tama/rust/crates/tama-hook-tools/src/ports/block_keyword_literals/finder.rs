//! Finding word lists in code: a run of quoted words, an alternation
//! inside one literal, and the question of whether the program keeps it.
//!
//! Split out of `block_keyword_literals/mod.rs`, which had grown past the
//! three-hundred-line limit; which file is read at all is in `text.rs`.

use std::sync::LazyLock;

use regex::Regex;

use super::super::transport_common as common;
use super::list_min;

/// One quoted literal, in the quoting a code file may use.
static LITERAL: LazyLock<Regex> =
    LazyLock::new(|| common::compile("r?#?\"((?:[^\"\\\\]|\\\\.)*)\"#?|'((?:[^'\\\\]|\\\\.)*)'"));
/// Between two members of one collection: a comma and whitespace, nothing else.
static SEPARATOR: LazyLock<Regex> = LazyLock::new(|| common::compile("^\\s*,\\s*$"));
/// Regex syntax that carries no letters of its own: quantifiers, escapes,
/// classes, anchors. Stripped before an alternative is read as a word. A
/// source file spells an escape with one backslash or, inside a string
/// literal, two, so both are read.
static REGEX_SYNTAX: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(
        "\\\\\\\\?[wsdbBAz]\\*?|\\\\\\\\?.|\\[[^\\]]*\\]|[?*+^$]|\\{[^}]*\\}|\\(\\?[a-z]+\\)",
    )
});
/// A word: letters, or several separated by single spaces.
static WORD: LazyLock<Regex> = LazyLock::new(|| common::compile("^\\p{L}{2,}( \\p{L}+)*$"));

/// A method call on the collection itself, whatever the language calls it.
static QUESTION: LazyLock<Regex> = LazyLock::new(|| common::compile("^[.\\?]\\s*\\p{L}+\\s*\\("));

/// True when the literal reads as a natural-language word or phrase.
fn is_word(text: &str) -> bool {
    WORD.is_match(text.trim())
}

/// Every collection of quoted words in `text`, as (line, words): quoted
/// literals separated only by commas and whitespace, `list_min()` or more of
/// them, every one a word.
pub(super) fn word_collections(text: &str) -> Vec<(usize, Vec<String>)> {
    let mut found = Vec::new();
    let mut run: Vec<String> = Vec::new();
    let mut run_line = usize::default();
    let mut run_start = usize::default();
    let mut previous_end = usize::default();
    let close = |run: &mut Vec<String>,
                 line: usize,
                 start: usize,
                 end: usize,
                 found: &mut Vec<(usize, Vec<String>)>| {
        if run.len() >= list_min()
            && run.iter().all(|word| is_word(word))
            && kept_or_consulted(text, start, end)
        {
            found.push((line, std::mem::take(run)));
        }
        run.clear();
    };
    for literal in LITERAL.find_iter(text) {
        let body = LITERAL
            .captures(literal.as_str())
            .and_then(|c| c.get(1).or_else(|| c.get(2)))
            .map(|m| m.as_str().to_owned())
            .unwrap_or_default();
        let gap = &text[previous_end..literal.start()];
        if run.is_empty() || !SEPARATOR.is_match(gap) {
            close(&mut run, run_line, run_start, previous_end, &mut found);
            run_line = line_of(text, literal.start());
            run_start = literal.start();
        }
        run.push(body);
        previous_end = literal.end();
    }
    close(&mut run, run_line, run_start, previous_end, &mut found);
    found
}

/// Does the program keep this run of words, or consult it where it stands?
///
/// A classifier needs its words later: it binds them to a name, iterates
/// them, or asks the collection a question on the spot. Words handed to a
/// call are that call's data — the arguments of a command a test runs, the
/// three file descriptors in `spawn(cmd, { stdio: ['ignore', 'pipe',
/// 'pipe'] })` — and judging those made the guard cry wolf over
/// `runCLI(["transcripts", "tasks", "show"])` in every journey there is.
///
/// The walk leaves the collection outwards through its brackets, braces and
/// property keys, and stops at the first character that says what this text
/// is: `(` or `,` means an argument; a binding, a `for … in`, or the start
/// of a statement means the program keeps it.
fn kept_or_consulted(text: &str, start: usize, end: usize) -> bool {
    let before = text[..start].trim_end();
    // A binding keeps the run; `for … in` iterates it. Both are the shape
    // of a table the program consults.
    if before.ends_with('=') || before.ends_with(" in") {
        return true;
    }
    // Walk backwards out of whatever holds the collection. A closed group
    // in a sibling value — another call, another list, an arithmetic
    // expression — is skipped whole; an unclosed `[` or `{` is the
    // container this run sits in, so the walk steps out of it and keeps
    // going. What decides is `(`, which makes this an argument, the body
    // of a function, which makes it a value the function produces, or a
    // statement boundary, which makes it something the program keeps.
    let mut depth = usize::MIN;
    let mut handed_over = false;
    let mut seen: usize = usize::MIN;
    for character in before.chars().rev() {
        seen += character.len_utf8();
        match character {
            ')' | ']' | '}' => depth += 1,
            '(' if depth == usize::MIN => {
                handed_over = true;
                break;
            }
            '{' if depth == usize::MIN => {
                // `func … -> [String] { ["registry", "host", …] }` and
                // `return [...]` inside one: a command line a function
                // hands back, not a table it keeps. The brace of a
                // function body follows its parameter list or its return
                // type — and a return type that is itself an array ends in
                // `]`, which is how Swift and TypeScript spell the very
                // function that builds a command line.
                let outside = before[..before.len() - seen].trim_end();
                if outside.ends_with(')') || outside.ends_with('>') || outside.ends_with(']') {
                    handed_over = true;
                    break;
                }
                continue;
            }
            '[' if depth == usize::MIN => continue,
            '(' | '[' | '{' => depth -= 1,
            ';' | '=' if depth == usize::MIN => break,
            _ => {}
        }
    }
    if !handed_over {
        return true;
    }
    let after = text[end..].trim_start();
    let after = after.strip_prefix(']').unwrap_or(after).trim_start();
    // `["a", "b", "c"].contains(x)` asks the collection a question where it
    // stands, so it is a classifier even inside an argument list.
    QUESTION.is_match(after)
}

/// Every alternation of words inside a quoted literal, as (line, words):
/// `(a|b|c)` groups and bare `a|b|c` literals, `list_min()` or more
/// alternatives, every one a word once regex syntax is stripped.
pub(super) fn word_alternations(text: &str) -> Vec<(usize, Vec<String>)> {
    let mut found = Vec::new();
    for literal in LITERAL.find_iter(text) {
        let body = literal.as_str();
        if !body.contains('|') {
            continue;
        }
        let line = line_of(text, literal.start());
        for group in alternation_groups(body) {
            let words: Vec<String> = group
                .split('|')
                .map(|alternative| REGEX_SYNTAX.replace_all(alternative, " ").trim().to_owned())
                .map(|alternative| alternative.split_whitespace().collect::<Vec<_>>().join(" "))
                .collect();
            if words.len() >= list_min() && words.iter().all(|word| is_word(word)) {
                found.push((line, words));
            }
        }
    }
    found
}

/// The innermost parenthesised groups of `body` that contain `|`, and the
/// whole body when it has no groups at all.
fn alternation_groups(body: &str) -> Vec<String> {
    let mut groups = Vec::new();
    let mut stack: Vec<usize> = Vec::new();
    let bytes: Vec<char> = body.chars().collect();
    let mut escaped = false;
    for (index, ch) in bytes.iter().enumerate() {
        if escaped {
            escaped = false;
            continue;
        }
        match ch {
            '\\' => escaped = true,
            '(' => stack.push(index),
            ')' => {
                if let Some(start) = stack.pop() {
                    let inner: String = bytes[start + usize::from(true)..index].iter().collect();
                    let inner = inner.trim_start_matches("?:").trim_start_matches("?i:");
                    if inner.contains('|') && !inner.contains('(') {
                        groups.push(inner.to_owned());
                    }
                }
            }
            _ => {}
        }
    }
    if groups.is_empty() {
        groups.push(
            body.trim_matches(|c| c == '"' || c == '\'' || c == 'r' || c == '#')
                .to_owned(),
        );
    }
    groups
}

pub(super) fn line_of(text: &str, offset: usize) -> usize {
    text[..offset].matches('\n').count() + usize::from(true)
}
