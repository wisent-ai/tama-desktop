//! Logic for `tama-check-humanized-actions`, registry hook
//! `check-humanized-actions`: browser-driving code uses the humanized atoms,
//! never raw driver actions.
//!
//! Why: bot classifiers (LinkedIn, TikTok, reCAPTCHA Enterprise, Arkose,
//! hCaptcha) read `event.isTrusted`, scroll cadence and click timing. A raw
//! `page.click(...)` emits `isTrusted=false`; a `waitForTimeout` emits a fixed
//! cadence. Either is a classified bot, and the account is the cost.
//!
//! Scope is deliberately inclusive: any `.mjs`, `.ts`, `.js` or notebook
//! under a `weles/` path, or under the content platform's `.work/` and
//! `scripts/` trees. Out-of-scope code that trips a rule carries the opt-out.

mod message;
mod rules;

use serde_json::Value;
use tama_hooks::session_record::{deny_tool_use, read_payload};

use crate::ports::pyvalue::first_truthy_py_str;

const TOOL_KEY: &str = "tool_name";
const INPUT_KEY: &str = "tool_input";
const PATH_KEYS: &[&str] = &["file_path", "notebook_path"];
const BYPASS_ENV: &str = "HOOK_RAW_PLAYWRIGHT_AUTHORIZED";
const BYPASS_VALUE: &str = "1";
const OPT_OUT: &str = "allow-raw-playwright";
const DRIVING_SUFFIXES: &[&str] = &[".mjs", ".ts", ".js", ".ipynb"];
const WATCHED_ROOTS: &[&str] = &[
    "/weles/",
    "/content-platform/.work/",
    "/content-platform/scripts/",
];
const WHOLE_FILE_TOOLS: &[&str] = &["Write", "NotebookEdit"];
const EDIT_TOOLS: &[&str] = &["Edit"];
const PATCH_TOOLS: &[&str] = &["Create", "ApplyPatch"];
const WHOLE_FILE_KEYS: &[&str] = &["content", "new_source"];
const EDIT_KEYS: &[&str] = &["new_string"];
const PATCH_KEYS: &[&str] = &["new_string", "content", "patch"];

fn in_scope(path: &str) -> bool {
    DRIVING_SUFFIXES.iter().any(|suffix| path.ends_with(suffix))
        && WATCHED_ROOTS.iter().any(|root| path.contains(root))
}

fn content_of(tool: &str, input: &Value) -> String {
    let keys: &[&str] = match () {
        _ if WHOLE_FILE_TOOLS.contains(&tool) => WHOLE_FILE_KEYS,
        _ if EDIT_TOOLS.contains(&tool) => EDIT_KEYS,
        _ if PATCH_TOOLS.contains(&tool) => PATCH_KEYS,
        _ => return String::new(),
    };
    first_truthy_py_str(input, keys)
}

/// `grep -v allow-raw-playwright`: a line that carries its own reason is not
/// judged at all.
fn without_opt_outs(content: &str) -> String {
    content
        .lines()
        .filter(|line| !line.contains(OPT_OUT))
        .collect::<Vec<_>>()
        .join("\n")
}

/// `tr -s ' \t'`: runs of blanks collapse, newlines stay, because some shapes
/// are only visible across lines.
fn squashed(text: &str) -> String {
    let mut out = String::with_capacity(text.len());
    let mut blank = false;
    for character in text.chars() {
        let is_blank = character == ' ' || character == '\t';
        if is_blank && blank {
            continue;
        }
        blank = is_blank;
        out.push(character);
    }
    out
}

/// Every raw-driver shape this content carries.
pub fn violations(content: &str) -> Vec<String> {
    let judged = without_opt_outs(content);
    let collapsed = squashed(&judged);
    let one_line = judged.replace('\n', " ");
    let mut found: Vec<String> = Vec::new();
    for rule in rules::RULES.iter() {
        let text = match rule.one_line {
            true => &one_line,
            false => &collapsed,
        };
        if rule.pattern.is_match(text) {
            found.push(rule.complaint.clone());
        }
    }
    if rules::EVALUATE_CALL.is_match(&one_line) && rules::DOM_INTERACTION.is_match(&one_line) {
        found.push(rules::CO_OCCURRENCE.to_string());
    }
    found
}

/// The refusal this write earns, if any.
pub fn check(payload: &Value) -> Option<String> {
    if std::env::var(BYPASS_ENV).ok().as_deref() == Some(BYPASS_VALUE) {
        return None;
    }
    let empty = Value::Object(Default::default());
    let input = payload.get(INPUT_KEY).unwrap_or(&empty);
    let path = first_truthy_py_str(input, PATH_KEYS);
    if path.is_empty() || !in_scope(&path) {
        return None;
    }
    let tool = payload
        .get(TOOL_KEY)
        .and_then(Value::as_str)
        .unwrap_or_default();
    let content = content_of(tool, input);
    if content.is_empty() {
        return None;
    }
    let found = violations(&content);
    match found.is_empty() {
        true => None,
        false => Some(message::refusal(&path, &found)),
    }
}

pub fn run() {
    if let Some(refusal) = check(&read_payload()) {
        deny_tool_use(&refusal);
    }
}

#[cfg(test)]
mod tests {
    use super::{check, violations};
    use serde_json::json;

    const DRIVING: &str = "/repo/weles/scripts/trajectories/run.mjs";

    fn write(path: &str, content: &str) -> serde_json::Value {
        json!({ "tool_name": "Write", "tool_input": { "file_path": path, "content": content } })
    }

    #[test]
    fn a_raw_click_is_refused_and_the_atom_is_named() {
        let refusal = check(&write(DRIVING, "await page.click('#login');")).expect("raw click");
        assert!(refusal.contains("humanClick"), "{refusal}");
        assert!(refusal.contains(DRIVING), "{refusal}");
    }

    /// The red-team shapes: every one of these reaches the same driver.
    #[test]
    fn the_evasions_are_refused_too() {
        for content in [
            "await page [ \"click\" ] ('#a');",
            "await page  ?.  click('#a');",
            "await page['cl' + 'ick']('#a');",
            "const c = page.click; await c.call(page, '#a');",
            "await new Promise(r => setTimeout(r, 400));",
            "await page.evaluate(\"window.scrollTo(0, 400)\");",
            "await page.keyboard.type('hello');",
            "spawnSync('osascript', ['-e', 'x']);",
        ] {
            assert!(!violations(content).is_empty(), "{content}");
        }
    }

    /// A line that carries its own reason is not judged.
    #[test]
    fn the_per_line_opt_out_is_honoured() {
        let content =
            "await page.click('#a'); // allow-raw-playwright: the login form has no locator";
        assert!(violations(content).is_empty());
    }

    #[test]
    fn humanized_code_passes() {
        let content = "await humanClickLocator(page, locator);\nawait humanIdlePause('short');";
        assert!(violations(content).is_empty());
        assert_eq!(check(&write(DRIVING, content)), None);
    }

    /// A file outside the watched trees is not this gate's business, whatever
    /// it contains.
    #[test]
    fn an_out_of_scope_file_passes() {
        assert_eq!(
            check(&write("/repo/src/app/page.ts", "await page.click('#a');")),
            None
        );
    }

    /// The co-occurrence check is conservative by design.
    #[test]
    fn an_evaluate_beside_a_dom_interaction_is_refused() {
        let content = "const rows = await page.evaluate(() => read());\n// button.click() later";
        assert!(violations(content)
            .iter()
            .any(|found| found.contains("co-occurs")));
    }
}
