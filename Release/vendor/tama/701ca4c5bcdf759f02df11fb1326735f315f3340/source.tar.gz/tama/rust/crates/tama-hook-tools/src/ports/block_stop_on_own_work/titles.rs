//! The contract's own words, and the headings a report is read by.
//!
//! Split out of `sections.rs`, which had grown past the three-hundred-line
//! limit. Reading the sections and judging them stays there; the
//! declaration and the heading vocabulary are here.

use std::sync::LazyLock;

use regex::Regex;

use crate::ports::transport_common as common;

/// The contract's own words, declared in `vocabulary/report-sections.json`
/// beside this file: the headings, the ways of writing "nothing", the next
/// step that is not one, the boundary that stays with the operator, and the
/// phrasing that turns a repository name into a place work is owed.
static DECLARED: LazyLock<serde_json::Value> = LazyLock::new(|| {
    serde_json::from_str(include_str!("vocabulary/report-sections.json"))
        .expect("report-sections.json in the vocabulary folder is valid JSON")
});

pub(super) fn declared_words(key: &str) -> Vec<String> {
    DECLARED[key]
        .as_array()
        .unwrap_or_else(|| panic!("report-sections.json declares no {key} array"))
        .iter()
        .filter_map(|word| word.as_str().map(str::to_owned))
        .collect()
}

fn declared_regex(key: &str) -> Regex {
    common::compile(
        DECLARED[key]
            .as_str()
            .unwrap_or_else(|| panic!("report-sections.json declares no {key}")),
    )
}

pub(super) fn checkouts() -> Vec<String> {
    declared_words("checkouts")
}

const HEADING_DRESSING: &[char] = &['#', '*', '_', ':', '.', ' ', '\t'];
pub(super) const LINE_JOIN: &str = "\n";

pub(super) static NONE: LazyLock<Regex> = LazyLock::new(|| declared_regex("none"));
pub(super) static HANDED_BACK: LazyLock<Regex> = LazyLock::new(|| declared_regex("handed_back"));
pub(super) static ANNOUNCED: LazyLock<Regex> = LazyLock::new(|| declared_regex("announced"));
pub(super) static MONEY: LazyLock<Regex> = LazyLock::new(|| declared_regex("money"));

pub(super) fn work_in_repo() -> String {
    DECLARED["work_in_repo"]
        .as_str()
        .expect("report-sections.json declares work_in_repo")
        .to_owned()
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(super) enum Title {
    Done,
    Blockers,
    NextSteps,
}

pub(super) fn title_of(line: &str) -> Option<Title> {
    let bare = line.trim_matches(HEADING_DRESSING).to_lowercase();
    if bare.is_empty() {
        return None;
    }
    let matches = |key: &str| declared_words(key).iter().any(|title| *title == bare);
    if matches("blockers_titles") {
        Some(Title::Blockers)
    } else if matches("next_steps_titles") {
        Some(Title::NextSteps)
    } else if matches("done_titles") {
        Some(Title::Done)
    } else {
        None
    }
}
