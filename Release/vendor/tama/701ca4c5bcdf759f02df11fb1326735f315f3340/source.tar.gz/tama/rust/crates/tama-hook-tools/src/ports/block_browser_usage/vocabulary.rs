//! The words this guard reads a payload with: the keys it looks under, the
//! runtimes it recognises, the Weles placement it allows, and the refusal.
//!
//! Split out of `block_browser_usage/mod.rs`, which had grown past the
//! three-hundred-line limit; the decision itself stays there.

use std::sync::LazyLock;

use regex::Regex;

use crate::ports::transport_common as common;

pub(super) const TOOL_KEYS: &[&str] = &["tool_name", "name"];
pub(super) const PATH_KEY: &str = "path";
pub(super) const OPERATION_KEYS: &[&str] = &["op", "action"];
pub(super) const CODE_KEY: &str = "code";
pub(super) const APPLICATION_KEY: &str = "application";
pub(super) const ARGS_KEY: &str = "args";
pub(super) const START_OPERATION: &str = "start";
pub(super) const WRITE_TOOLS: &[&str] = &["write", "functions.write"];
pub(super) const NEUTRAL_NAME: &str = "${1}weles-browser-sources";
pub(super) const REFUSAL: &[&str] = &[
    "BLOCKED: direct browser use is forbidden.",
    "Use the Weles API/trajectory; its browser runtime must execute on a Stado target carrying a \
     Weles placement policy.",
    "Approved Weles targets are read from ~/.stado/local-storage/registry.json.",
];
/// `false` in the shell.
const REFUSAL_STATUS_TEXT: &str = "1";

pub(super) static BROWSER_TOOL: LazyLock<Regex> =
    LazyLock::new(|| common::compile("(^|[._-])browser([._-]|$)"));
pub(super) static BROWSER_DEVICE: LazyLock<Regex> =
    LazyLock::new(|| common::compile("^xd://(mcp__)?browser([/_-]|$)"));
pub(super) static REPL_DEVICE: LazyLock<Regex> =
    LazyLock::new(|| common::compile("^xd://mcp__node_repl_js($|[/_-])"));

/// One built-in Git operation, with at most a `-C <dir>`, and nothing that
/// could chain a second command onto it.
pub(super) static SAFE_GIT: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "^[[:space:]]*git([[:space:]]+-C[[:space:]]+[^[:space:]]+)?[[:space:]]+",
        "(status|diff|log|show|branch|remote|fetch|pull|rebase|add|rm|restore|commit|push",
        "|rev-parse|ls-files)([[:space:]]|$)",
    ))
});
pub(super) static COMPOUND: LazyLock<Regex> = LazyLock::new(|| common::compile("[;&|`]|[$][(]"));

/// The checkouts holding Weles's patched browser sources.
pub(super) static BROWSER_SOURCE_REPOSITORIES: LazyLock<Regex> =
    LazyLock::new(|| common::compile("(^|[^[:alnum:]])weles-(chromium|firefox)"));

pub(super) static BROWSER_RUNTIME: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "chromium|google[[:space:]]+chrome|chrome-mac|com\\.google\\.chrome|org\\.chromium",
        "|firefox|safari(\\.app)?|webkit|playwright|puppeteer|selenium|connectovercdp",
        "|remote-debugging-port|browser[[:space:]_-]*plugin",
        "|(^|[^[:alnum:]_])(tab|page|browser)\\.[a-z_][a-z0-9_]*[[:space:]]*\\(",
    ))
});

pub(super) static WELES_RUNTIME: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(^|[/[:space:]\\x22\\x27])weles([/[:space:]\\x22\\x27]|$)",
        "|scripts/(trajectories|worker|_shared/keeper)|wsession",
    ))
});

pub(super) fn refusal_status() -> i32 {
    REFUSAL_STATUS_TEXT.parse().unwrap_or_default()
}
