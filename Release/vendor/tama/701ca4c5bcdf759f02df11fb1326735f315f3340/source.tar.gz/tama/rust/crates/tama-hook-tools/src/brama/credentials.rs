//! Who Tama is to Brama, and where Brama answers for this machine.
//!
//! This file used to name four things in the vault: the item holding a
//! bearer, the field inside it, the consumer allowed to read it, and the
//! token file that read grant needs. Four names for one relationship, none
//! of them verifiable from here: a rename or a rotation anywhere else turned
//! into an unexplained 401, and the code could not say which of the four was
//! wrong.
//!
//! Brama does not want a stored secret. It introspects the presented bearer
//! at Skarbiec and reads the answer: `consumer` is the client, `audience` the
//! agent, and the `call:brama#<route>` grants are the routes that client may
//! ask for. So the durable identity is the consumer, and the credential is a
//! Skarbiec-issued token for it — minted, expiring, revocable at the
//! authority, and carrying its own permissions. Two facts live here now: our
//! consumer name, and which local adapter carries the hop.

use std::path::PathBuf;
use std::process::{Command, Stdio};

/// Our identity at the gateway. Skarbiec mints the token for this consumer
/// and Brama learns the client id from introspecting it.
const DEFAULT_CONSUMER: &str = "tama";
/// Which declared resolver adapter carries the local hop. The fleet declares
/// one adapter per consumer, and a consumer reads its own: until 2026-09-14
/// this named `operator`, so Tama dialled the address declared for a person
/// at a keyboard, and a fleet that moved or withdrew the operator's adapter
/// would have moved Tama with it without a word in Tama's own declaration.
const DEFAULT_ADAPTER_CONSUMER: &str = DEFAULT_CONSUMER;
const DEFAULT_MODEL_ROUTER_URL: &str = "https://brama.wisent.com";
/// The route the reviewer asks Brama for. `best` is Brama's own selector: the
/// gateway picks the strongest subscription-backed model behind it.
///
/// This read `-best` until 2026-09-11, and a leading dash is not a Brama
/// route. The fleet then granted `call:brama#-best` to match the code, so both
/// halves agreed on a route the gateway does not serve, and every refusal
/// looked like a credential problem.
const DEFAULT_MODEL_ROUTE: &str = "best";
const MAX_ROUTE_CHARS: usize = 160;

pub struct Credentials {
    pub endpoint: String,
    pub bearer: String,
}

impl Drop for Credentials {
    fn drop(&mut self) {
        // Zero the byte buffer, not a copy of it.
        let bytes = unsafe { self.bearer.as_bytes_mut() };
        bytes.fill(0);
    }
}

fn home_dir() -> PathBuf {
    std::env::var("HOME").map(PathBuf::from).unwrap_or_default()
}

pub fn consumer() -> String {
    std::env::var("TAMA_BRAMA_CONSUMER")
        .ok()
        .filter(|value| !value.is_empty())
        .unwrap_or_else(|| DEFAULT_CONSUMER.to_string())
}

/// Which Brama route this machine asks for, and whether the name is one a
/// gateway could serve at all.
pub fn model_route() -> Result<String, String> {
    let route = std::env::var("TAMA_OBJECTIVE_AUTHORITY_MODEL_ROUTE")
        .ok()
        .filter(|value| !value.is_empty())
        .unwrap_or_else(|| DEFAULT_MODEL_ROUTE.to_string());
    if route.len() > MAX_ROUTE_CHARS || route.chars().any(char::is_whitespace) {
        return Err(format!("{route:?} is not a usable Brama route"));
    }
    Ok(route)
}

/// What this machine's own authority says about our token: does the consumer
/// hold `call:brama#<route>` on the bearer in the token file.
///
/// This is the half that can be answered locally, and it is the half that
/// separates a missing grant here from a gateway that asks a different
/// authority. Nothing else on this machine made that distinction, so one
/// unexplained `401` stood for both.
pub fn local_grant(route: &str) -> Result<bool, String> {
    let skarbiec = home_dir().join(".local").join("bin").join("skarbiec");
    let output = Command::new(skarbiec)
        .args(["grant", "verify", &consumer(), "brama"])
        .args(["--action", "call", "--field", route])
        .arg("--token-file")
        .arg(token_path())
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .output()
        .map_err(|error| format!("cannot ask this machine's authority: {error}"))?;
    let text = String::from_utf8_lossy(&output.stdout).to_string();
    let answer: serde_json::Value = serde_json::from_str(&text).map_err(|_| {
        let refusal = String::from_utf8_lossy(&output.stderr).trim().to_string();
        if refusal.is_empty() {
            "this machine's authority gave no answer".to_string()
        } else {
            refusal
        }
    })?;
    Ok(answer
        .get("allowed")
        .and_then(serde_json::Value::as_bool)
        .unwrap_or(false))
}

/// The owner-only file holding this consumer's Skarbiec token. The path is
/// the fleet's own convention, derived from the consumer, so nothing has to
/// be configured twice.
pub fn token_path() -> PathBuf {
    if let Ok(path) = std::env::var("TAMA_BRAMA_TOKEN_FILE") {
        if !path.is_empty() {
            return PathBuf::from(path);
        }
    }
    home_dir()
        .join(".stado")
        .join(format!("{}-skarbiec-token", consumer()))
}

/// A chat endpoint we will post to: no query, no fragment, no embedded
/// credentials, and plaintext only on loopback.
pub fn allowed_endpoint(endpoint: &str) -> bool {
    if endpoint.contains(['?', '#']) {
        return false;
    }
    let Some((scheme, remainder)) = endpoint.split_once("://") else {
        return false;
    };
    let Some((authority, path)) = remainder.split_once('/') else {
        return false;
    };
    if authority.is_empty() || authority.contains('@') || path != "v1/chat/completions" {
        return false;
    }
    if scheme == "https" {
        return true;
    }
    if scheme != "http" {
        return false;
    }
    let host = authority
        .rsplit_once(':')
        .map(|(host, _)| host)
        .unwrap_or(authority);
    matches!(host, "127.0.0.1" | "localhost" | "[::1]")
}

/// Reads the token, and refuses with the exact repair when it is not there:
/// the consumer, the path, and the command that mints one.
fn read_token() -> Result<String, String> {
    let path = token_path();
    let consumer = consumer();
    let shown = path.display();
    let Ok(text) = std::fs::read_to_string(&path) else {
        return Err(format!(
            "no Brama token for consumer {consumer} at {shown}; \
             mint one with `skarbiec token-mint {consumer} --capabilities call:brama#<route>`"
        ));
    };
    let token = text.trim().to_string();
    if token.is_empty() {
        return Err(format!(
            "the Brama token file for consumer {consumer} at {shown} is empty"
        ));
    }
    if token.chars().any(|character| {
        character.is_whitespace() || character.is_control() || !character.is_ascii()
    }) {
        return Err(format!(
            "the Brama token file for consumer {consumer} at {shown} does not hold one token"
        ));
    }
    Ok(token)
}

/// Where Brama answers for this machine.
///
/// The env overrides come first, then the fleet's own answer, and only then
/// the public hostname. Asking Stado is the documented contract: Brama binds
/// loopback on the host it is placed on, every other machine reaches it
/// through a declared resolver adapter, and the address is therefore
/// different on every machine.
fn model_router_endpoint() -> Result<String, String> {
    let base = [
        "TAMA_OBJECTIVE_AUTHORITY_MODEL_ROUTER_URL",
        "STADO_MODEL_ROUTER_URL",
        "BRAMA_URL",
    ]
    .into_iter()
    .find_map(|name| std::env::var(name).ok().filter(|value| !value.is_empty()))
    .or_else(fleet_route)
    .unwrap_or_else(|| DEFAULT_MODEL_ROUTER_URL.to_string());
    let remainder = base
        .strip_prefix("https://")
        .or_else(|| base.strip_prefix("http://"))
        .ok_or_else(|| "Brama URL must be HTTP or HTTPS".to_string())?;
    let authority = remainder.split('/').next().unwrap_or_default();
    if authority.is_empty() || authority.contains('@') || base.contains(['?', '#']) {
        return Err("Brama URL must not contain credentials, a query, or a fragment".to_string());
    }
    let base = base.trim_end_matches('/');
    if base.ends_with("/v1/chat/completions") {
        Ok(base.to_string())
    } else {
        Ok(format!("{base}/v1/chat/completions"))
    }
}

/// The adapter that carries the hop from this machine, named by the fleet.
pub fn adapter_consumer() -> String {
    std::env::var("TAMA_BRAMA_ADAPTER_CONSUMER")
        .ok()
        .filter(|value| !value.is_empty())
        .unwrap_or_else(|| DEFAULT_ADAPTER_CONSUMER.to_string())
}

/// `stado service directory connect brama --consumer <adapter> --json`: the
/// fleet works out the address from where Brama is placed and who is asking,
/// and proves something answers there before returning it.
fn fleet_route() -> Option<String> {
    let stado = home_dir().join(".local").join("bin").join("stado");
    let output = Command::new(stado)
        .args(["service", "directory", "connect", "brama"])
        .args(["--consumer", &adapter_consumer(), "--json"])
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::null())
        .output()
        .ok()?;
    if !output.status.success() {
        return None;
    }
    let route: serde_json::Value = serde_json::from_slice(&output.stdout).ok()?;
    route
        .get("url")
        .and_then(serde_json::Value::as_str)
        .filter(|url| !url.is_empty())
        .map(str::to_string)
}

/// The endpoint and the token, read fresh on every call so a rotated or
/// re-minted token is picked up without a restart.
pub fn read() -> Result<Credentials, String> {
    Ok(Credentials {
        endpoint: model_router_endpoint()?,
        bearer: read_token()?,
    })
}
