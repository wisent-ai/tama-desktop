//! Transcript internals backing `Turn::for_path`: transcript discovery under
//! the sessions root, tracker-state retention across user messages, tool-call
//! collection, and path-token extraction from argument trees.

use std::path::{Path, PathBuf};

use serde_json::Value;

use super::types::{ToolCall, ToolResult};

const SHORTEST_PATH: &str = "a/b";

fn sessions_root() -> PathBuf {
    if let Ok(custom) = std::env::var("TAMA_OMP_SESSION_ROOT") {
        if !custom.is_empty() {
            return PathBuf::from(custom);
        }
    }
    home_dir().join(".omp").join("agent").join("sessions")
}

fn home_dir() -> PathBuf {
    std::env::var("HOME").map(PathBuf::from).unwrap_or_default()
}

/// Where the harnesses write live sessions, and how many directory levels a
/// session file sits below each root: OMP and Claude keep
/// `<root>/<project>/<file>` (one), Codex `<root>/<year>/<month>/<day>/<file>`
/// (three). Beside every OMP transcript sits an artifact folder of the same
/// name; on 2026-09-16 those held 52,000 files, and walking them cost every
/// guard that looked a session up by id seconds of its ten-second budget. A
/// session file never sits in one, so the search does not enter them.
fn live_roots() -> [(PathBuf, usize); 3] {
    let one: usize = "1".parse().unwrap_or_default();
    let three: usize = "3".parse().unwrap_or_default();
    [
        (sessions_root(), one),
        (home_dir().join(".claude").join("projects"), one),
        (home_dir().join(".codex").join("sessions"), three),
    ]
}

/// The newest live transcript of one session, by name, across the harnesses.
pub fn transcript_path(session: &str) -> Option<PathBuf> {
    if session.is_empty() {
        return None;
    }
    let suffix = format!("{session}.jsonl");
    let mut newest: Option<(std::time::SystemTime, PathBuf)> = None;
    for (root, levels) in live_roots() {
        collect_transcripts(&root, levels, &suffix, &mut newest);
    }
    newest.map(|(_, path)| path)
}

/// `below`: how many directory levels under `directory` may still be entered.
fn collect_transcripts(
    directory: &Path,
    below: usize,
    suffix: &str,
    newest: &mut Option<(std::time::SystemTime, PathBuf)>,
) {
    let Ok(entries) = std::fs::read_dir(directory) else {
        return;
    };
    for entry in entries.flatten() {
        let path = entry.path();
        if path.is_dir() {
            if let Some(remaining) = below.checked_sub(usize::from(true)) {
                collect_transcripts(&path, remaining, suffix, newest);
            }
            continue;
        }
        if !path
            .file_name()
            .and_then(|name| name.to_str())
            .is_some_and(|name| name.ends_with(suffix))
        {
            continue;
        }
        let modified = entry
            .metadata()
            .and_then(|meta| meta.modified())
            .unwrap_or(std::time::UNIX_EPOCH);
        if newest.as_ref().map_or(true, |(seen, _)| modified > *seen) {
            *newest = Some((modified, path));
        }
    }
}

pub(super) fn retain_tracker_state(
    calls: &mut Vec<(usize, ToolCall)>,
    results: &mut Vec<ToolResult>,
) {
    let snapshot_position = results.iter().rev().find_map(|result| {
        (result.tool_name == "todo"
            && !result.is_error
            && result
                .details
                .get("phases")
                .and_then(Value::as_array)
                .is_some())
        .then_some(result.position)
    });
    calls.retain(|(position, call)| {
        is_tracker_tool(&call.name)
            && snapshot_position
                .map(|snapshot| *position > snapshot)
                .unwrap_or(true)
            && results
                .iter()
                .any(|result| result.call_id == call.id && !result.is_error)
    });
    results.retain(|result| {
        !result.is_error
            && is_tracker_tool(&result.tool_name)
            && snapshot_position
                .map(|snapshot| result.position >= snapshot)
                .unwrap_or(true)
    });
}

pub(super) fn is_tracker_tool(name: &str) -> bool {
    name == "todo" || name == "update_plan" || name.ends_with("__update_plan")
}

pub(super) fn collect_tool_calls(
    position: usize,
    message: &Value,
    calls: &mut Vec<(usize, ToolCall)>,
) {
    if message.get("type").and_then(Value::as_str) == Some("function_call") {
        calls.push((
            position,
            ToolCall {
                id: string_at(message, "id"),
                name: string_at(message, "name").to_lowercase(),
                arguments: arguments_of(message),
            },
        ));
        return;
    }
    if message.get("role").and_then(Value::as_str) != Some("assistant") {
        return;
    }
    for item in content_items(message) {
        if item.get("type").and_then(Value::as_str) != Some("toolCall") {
            continue;
        }
        calls.push((
            position,
            ToolCall {
                id: string_at(item, "id"),
                name: string_at(item, "name").to_lowercase(),
                arguments: arguments_of(item),
            },
        ));
    }
}

fn content_items(message: &Value) -> Vec<&Value> {
    message
        .get("content")
        .and_then(Value::as_array)
        .map(|items| items.iter().filter(|item| item.is_object()).collect())
        .unwrap_or_default()
}

pub(super) fn is_error_result(message: &Value) -> bool {
    message.get("role").and_then(Value::as_str) == Some("toolResult")
        && message.get("isError").and_then(Value::as_bool) == Some(true)
}

pub(super) fn result_text(message: &Value) -> String {
    content_items(message)
        .into_iter()
        .filter(|item| item.get("type").and_then(Value::as_str) == Some("text"))
        .filter_map(|item| item.get("text").and_then(Value::as_str))
        .collect::<Vec<_>>()
        .join("\n")
}

/// The text the operator typed in a user record. OMP marks harness-injected
/// user-role records (todo reminders, hook continuations) with
/// `attribution: "agent"`; those are not the operator speaking. Codex carries
/// the words in `message` or `text`.
pub(super) fn operator_text(message: &Value) -> Option<String> {
    if message.get("attribution").and_then(Value::as_str) == Some("agent") {
        return None;
    }
    let text = match message.get("content") {
        Some(Value::Array(_)) => result_text(message),
        Some(Value::String(text)) => text.clone(),
        _ => ["message", "text"]
            .iter()
            .find_map(|key| message.get(*key).and_then(Value::as_str))
            .unwrap_or_default()
            .to_string(),
    };
    (!text.trim().is_empty()).then_some(text)
}

pub(super) fn string_at(value: &Value, key: &str) -> String {
    value
        .get(key)
        .and_then(Value::as_str)
        .unwrap_or_default()
        .to_string()
}

fn arguments_of(call: &Value) -> Value {
    match call.get("arguments") {
        Some(Value::String(text)) => serde_json::from_str(text).unwrap_or(Value::Null),
        Some(value) => value.clone(),
        None => Value::Null,
    }
}

/// Path-looking tokens inside an argument tree: anything containing a slash,
/// once shell redirection operators are stripped and device nodes dropped.
/// `2>/dev/null` names no work: on 2026-07-30 and again on 2026-09-18 a
/// denied bash line recorded it as the denied target, and the stop guard
/// then demanded a later call "touching" `/dev/null`.
pub fn path_tokens(value: &Value) -> Vec<String> {
    let mut found = Vec::new();
    collect_paths(value, &mut found);
    found
}

/// The redirection operators a token may start with, longest first.
const REDIRECTIONS: &[&str] = &["&>>", "&>", "2>>", "2>", ">>", ">", "<"];
const DEVICE_ROOT: &str = "/dev/";

fn without_redirection(token: &str) -> &str {
    REDIRECTIONS
        .iter()
        .find_map(|operator| token.strip_prefix(operator))
        .unwrap_or(token)
}

fn collect_paths(value: &Value, found: &mut Vec<String>) {
    match value {
        Value::String(text) => {
            for token in text.split(|c: char| c.is_whitespace() || c == '"' || c == '\'') {
                let trimmed = without_redirection(
                    token.trim_matches(|c: char| c == ',' || c == ';' || c == ')' || c == '('),
                );
                if trimmed.contains('/')
                    && trimmed.len() > SHORTEST_PATH.len()
                    && !trimmed.starts_with(DEVICE_ROOT)
                {
                    found.push(trimmed.to_string());
                }
            }
        }
        Value::Array(items) => items.iter().for_each(|item| collect_paths(item, found)),
        Value::Object(map) => map.values().for_each(|item| collect_paths(item, found)),
        _ => {}
    }
}

#[cfg(test)]
mod path_token_tests {
    use super::path_tokens;
    use serde_json::json;

    #[test]
    fn a_redirection_to_a_device_is_not_a_target_and_a_redirected_file_is() {
        let tokens = path_tokens(&json!({
            "command": "timeout 90 brama subscriptions list --json 2>/dev/null >rust/target/pool.json"
        }));
        assert_eq!(tokens, vec!["rust/target/pool.json".to_owned()]);
    }

    #[test]
    fn a_plain_path_and_a_home_path_are_targets() {
        let mut tokens =
            path_tokens(&json!({ "path": "~/Documents/x/y.rs", "note": "see src/lib.rs" }));
        tokens.sort();
        assert_eq!(
            tokens,
            vec!["src/lib.rs".to_owned(), "~/Documents/x/y.rs".to_owned()]
        );
    }
}
