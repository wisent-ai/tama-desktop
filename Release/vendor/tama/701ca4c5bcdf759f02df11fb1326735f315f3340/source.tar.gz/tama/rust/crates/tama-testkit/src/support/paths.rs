//! Where the live-runtime tests find the repository, which environment
//! switches they read, and the file operations they do it with.
//!
//! Split out of `support/mod.rs`, which had grown past the three-hundred-line
//! limit; running a command stays there.

use std::io::Read;
use std::path::{Component, Path, PathBuf};

/// JS `realRunner` — absolute device path, verbatim from the JS source.
pub const REAL_RUNNER: &str = "/Users/lukaszbartoszcze/.shared-hooks/run-hook.mjs";

/// Node `mkdtempSync` appends six random characters, and gives up rather
/// than spin forever when every candidate name is taken.
const SUFFIX_LEN: usize = 6;
const NAME_ATTEMPTS: usize = 100;

/// JS `root` = repo root. The Rust port resolves `TAMA_ROOT` first (repo
/// convention shared with the other crates), then falls back to the crate
/// location (`rust/crates/tama-testkit` -> three levels up).
pub fn root() -> PathBuf {
    if let Some(root) = std::env::var_os("TAMA_ROOT") {
        return PathBuf::from(root);
    }
    normalize_path(
        Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../..")
            .as_path(),
    )
}

/// JS `modelRouterRoot = join(dirname(root), 'model-router')`.
pub fn model_router_root() -> PathBuf {
    root()
        .parent()
        .unwrap_or(Path::new("/"))
        .join("model-router")
}

/// Lexical normalization of `.` / `..` (like Node `path.resolve` on an
/// already-absolute path).
pub fn normalize_path(path: &Path) -> PathBuf {
    let mut out = PathBuf::new();
    for component in path.components() {
        match component {
            Component::CurDir => {}
            Component::ParentDir => {
                out.pop();
            }
            other => out.push(other.as_os_str()),
        }
    }
    out
}

/// JS `keepArtifacts`.
pub fn keep_artifacts() -> bool {
    std::env::var("KEEP_LIVE_TEST_ARTIFACTS").as_deref() == Ok("1")
}

/// JS `codexRouterCoverage`.
pub fn codex_router_coverage() -> bool {
    std::env::var("CODEX_LIVE_RUNTIME_VIA_MODEL_ROUTER").as_deref() == Ok("1")
}

/// JS `codexFullLocalCoverage`.
pub fn codex_full_local_coverage() -> bool {
    std::env::var("MODEL_ROUTER_CODEX_COVERAGE_HOOKS").as_deref() == Ok("full-local")
}

/// JS `claudeLiveModel` (`process.env.CLAUDE_LIVE_MODEL || 'claude-opus-4-8'`).
pub fn claude_live_model() -> String {
    std::env::var("CLAUDE_LIVE_MODEL")
        .ok()
        .filter(|v| !v.is_empty())
        .unwrap_or_else(|| "claude-opus-4-8".to_string())
}

/// JS `scenarioFilter` (`process.env.LIVE_SCENARIO_FILTER || ''`).
pub fn scenario_filter() -> String {
    std::env::var("LIVE_SCENARIO_FILTER").unwrap_or_default()
}

/// JS `liveRuntimeTmpRoot`.
pub fn live_runtime_tmp_root() -> PathBuf {
    root().join(".live-runtime-tmp")
}

/// Node `os.tmpdir()`.
pub fn tmpdir() -> PathBuf {
    std::env::temp_dir()
}

/// Node `path.dirname` (POSIX).
pub fn dirname(path: &str) -> String {
    let trimmed = path.trim_end_matches('/');
    if trimmed.is_empty() {
        return "/".to_string();
    }
    match trimmed.rfind('/') {
        None => ".".to_string(),
        Some(0) => "/".to_string(),
        Some(index) => trimmed[..index].to_string(),
    }
}

/// JS `makeLiveRuntimeTemp(prefix)`.
pub fn make_live_runtime_temp(prefix: &str) -> Result<PathBuf, String> {
    let root_dir = live_runtime_tmp_root();
    std::fs::create_dir_all(&root_dir).map_err(|e| io_error_message("mkdir", &root_dir, &e))?;
    mkdtemp(&root_dir.join(prefix))
}

/// Node `mkdtempSync(prefix)`: appends 6 random characters.
pub fn mkdtemp(prefix: &Path) -> Result<PathBuf, String> {
    const CHARSET: &[u8] = b"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    for _ in 0..NAME_ATTEMPTS {
        let random = random_bytes(SUFFIX_LEN);
        let suffix: String = random
            .iter()
            .map(|b| CHARSET[(*b as usize) % CHARSET.len()] as char)
            .collect();
        let candidate = PathBuf::from(format!("{}{suffix}", prefix.display()));
        match std::fs::create_dir(&candidate) {
            Ok(()) => return Ok(candidate),
            Err(e) if e.kind() == std::io::ErrorKind::AlreadyExists => continue,
            Err(e) => return Err(io_error_message("mkdtemp", &candidate, &e)),
        }
    }
    Err(format!(
        "mkdtemp: could not create a unique directory for {}",
        prefix.display()
    ))
}

fn random_bytes(n: usize) -> Vec<u8> {
    let mut buf = vec![0u8; n];
    if std::fs::File::open("/dev/urandom")
        .and_then(|mut f| f.read_exact(&mut buf))
        .is_err()
    {
        let nanos = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_nanos())
            .unwrap_or(0);
        for (i, b) in buf.iter_mut().enumerate() {
            *b = (nanos >> ((i % 16) * 8)) as u8 ^ (std::process::id() as u8);
        }
    }
    buf
}

/// Node-style I/O error message for `readFileSync`/`writeFileSync` failures.
pub fn io_error_message(op: &str, path: &Path, error: &std::io::Error) -> String {
    if error.kind() == std::io::ErrorKind::NotFound {
        let verb = if op == "mkdir" || op == "mkdtemp" {
            op
        } else {
            "open"
        };
        format!(
            "ENOENT: no such file or directory, {verb} '{}'",
            path.display()
        )
    } else {
        format!("{error}")
    }
}

/// JS `read(path)` = `readFileSync(path, 'utf8')` (throws on error).
pub fn read(path: &Path) -> Result<String, String> {
    std::fs::read_to_string(path).map_err(|e| io_error_message("open", path, &e))
}

/// JS `writeFileSync(path, content)` (throws on error).
pub fn write_file(path: &Path, content: &str) -> Result<(), String> {
    std::fs::write(path, content).map_err(|e| io_error_message("open", path, &e))
}

pub fn exists(path: &Path) -> bool {
    path.exists()
}

/// JS `rmSync(path, { recursive: true, force: true })` — errors ignored.
pub fn rm_force(path: &Path) {
    if path.is_dir() {
        let _ = std::fs::remove_dir_all(path);
    } else {
        let _ = std::fs::remove_file(path);
    }
}
