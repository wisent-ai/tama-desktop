//! Rust port of `src/violations/find-violations.mjs`.
//! Scans a repository for existing violations of the content rules enforced by
//! the shared pre-write hook by replaying the real hook script against every
//! enumerated file (synthetic Write payloads), plus the max-files-per-folder
//! rule checked directly. Read-only: target files are never written.

use serde::Serialize;
use std::collections::HashSet;
use std::path::Path;

use crate::{basename, extname, first_line, locale_compare, relative_path, resolve_path};

pub(crate) mod files;
mod gaming;
mod line_limit;
mod replay;

pub use files::{enumerate_files, is_vendor_path, Enumeration};
pub use gaming::detect_gaming;
pub use line_limit::exempt_from_line_limit;
pub use replay::{folder_violations, scan_repo, scan_repo_sizes};

pub const HOOK_ID: &str = "pre-write-edit";
const MAX_BYTES: u64 = 524_288;
const BINARY_SNIFF_BYTES: usize = 8_192;
const FOLDER_FILE_LIMIT: u64 = 5;
// Mirrors `block_oversized_files.sh`, which compares `echo "$CONTENT" | wc -l`
// against 300. Only `--size-only` reads this constant; the default scan still
// runs that script, and `size_only_matches_hook_replay` fails if the two ever
// disagree about the same file.
const FILE_LINE_LIMIT: u64 = 300;

// Mirrors the IS_SYSTEM gate in pre_write_edit.sh. The JS original is the
// regex /node_modules|\.git\/|\.github\/workflows\/|\/scripts\/worker\/deploy\/
// |\.next|__pycache__|\/\.claude\/|\/\.factory\/|\/\.codex\/|\/\.shared-hooks\/
// |\/chromium-build\// — every alternative is a literal substring, so plain
// `contains` checks reproduce it exactly (no regex crate available).
const SYSTEM_PATH_FRAGMENTS: [&str; 11] = [
    "node_modules",
    ".git/",
    ".github/workflows/",
    "/scripts/worker/deploy/",
    ".next",
    "__pycache__",
    "/.claude/",
    "/.factory/",
    "/.codex/",
    "/.shared-hooks/",
    "/chromium-build/",
];
const SYSTEM_DIR_NAMES: [&str; 5] = [
    "node_modules",
    ".git",
    ".next",
    "__pycache__",
    "chromium-build",
];
// Beyond the hook's IS_SYSTEM list: third-party vendored and build-output
// trees. The hook gates new agent writes; a repo audit should not flag
// code the project did not author.
//
// Only where no source root stands above them. The same words are ordinary
// product code inside a source tree: `stado-rs/src/coverage` is the coverage
// orchestrator and `src/cli/space/coverage` is the command that prints it,
// and reading those as build output silently exempted thirty-one hand-written
// modules from both size rules.
const VENDOR_DIR_NAMES: [&str; 7] = [
    "dist", "build", "vendor", "target", ".venv", "venv", "coverage",
];
// A tree whose contents a person writes, whatever is nested inside it.
const SOURCE_ROOT_DIR_NAMES: [&str; 2] = ["src", "crates"];
// Mirrors the folder-density case exemptions the write guard applies:
// a database's own directories are ordered documents named by the database,
// not modules a person arranges.
const FOLDER_EXEMPT_FRAGMENTS: [&str; 7] = [
    "/supabase/migrations",
    "/supabase/seeds",
    "/node_modules",
    "/.git",
    "/__pycache__",
    "/tests",
    "/migrations",
];

const MODULE_EXTENSIONS: [&str; 17] = [
    ".js", ".mjs", ".cjs", ".ts", ".tsx", ".py", ".sh", ".json", ".md", ".txt", ".yml", ".yaml",
    ".toml", ".sql", ".swift", ".css", ".html",
];
// Rule-gaming content patterns: /data:text/javascript/ and /globalThis\.__/
// (both literal substrings; the JS original concatenates the first one to
// dodge the hook's own scan).
const GAMING_CONTENT: [&str; 2] = ["data:text/javascript", "globalThis.__"];

#[derive(Debug, Clone, Serialize)]
pub struct Violation {
    pub hook: String,
    pub rule: String,
    pub path: String,
    pub message: String,
}

/// The hook that owns the line limit; the folder limit is reported by the
/// pre-write guard itself, under a rule label that starts with this text.
pub const LINE_LIMIT_HOOK: &str = "block-oversized-files";
const FOLDER_RULE_PREFIX: &str = "Folder has";

/// Whether this finding is one of the two size rules — a file over the line
/// limit or a folder over the file limit — rather than a content rule.
/// A repair can be pointed at exactly these, which is what a sweep across
/// many repositories needs: the size rules are mechanical, the content rules
/// are judgement about what a line of code says.
pub fn is_size_rule(violation: &Violation) -> bool {
    violation.hook == LINE_LIMIT_HOOK || violation.rule.starts_with(FOLDER_RULE_PREFIX)
}

#[derive(Debug, Clone, Serialize)]
pub struct SkippedFile {
    pub path: String,
    pub reason: String,
}

#[derive(Debug, Clone, Serialize)]
pub struct ScanError {
    pub path: String,
    pub message: String,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ScanReport {
    pub repo: String,
    pub hook: String,
    pub mode: String,
    pub scanned_files: usize,
    pub skipped_files: Vec<SkippedFile>,
    pub violations: Vec<Violation>,
    pub errors: Vec<ScanError>,
    /// Added by the multi-target orchestration (`scan-repos`), absent from a
    /// bare `scanRepo` result — mirrors `{ ...report, via }`.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub via: Option<String>,
}

#[derive(Debug, Clone, Serialize)]
pub struct Finding {
    pub kind: String,
    pub path: String,
}

#[derive(Debug, Clone, Serialize)]
pub struct GamingResult {
    pub skipped: bool,
    pub findings: Vec<Finding>,
}

#[derive(Serialize)]
struct HookPayload<'a> {
    tool_name: &'a str,
    tool_input: ToolInput<'a>,
}

#[derive(Serialize)]
struct ToolInput<'a> {
    file_path: &'a str,
    content: &'a str,
}

fn is_system_path(path: &str) -> bool {
    SYSTEM_PATH_FRAGMENTS
        .iter()
        .any(|fragment| path.contains(fragment))
}

/// Mirrors `ruleKey`: first stderr line minus the BLOCKED: prefix, every
/// number (optionally signed) replaced by `N`, cut to 72 characters.
fn rule_key(stderr: &str) -> String {
    let line = first_line(stderr);
    let clean = match line.strip_prefix("BLOCKED:") {
        Some(rest) => rest.trim_start().to_string(),
        None => line,
    };
    let mut keyed = String::new();
    let chars: Vec<char> = clean.chars().collect();
    let mut i = 0;
    while i < chars.len() {
        let c = chars[i];
        if c.is_ascii_digit() || (c == '-' && i + 1 < chars.len() && chars[i + 1].is_ascii_digit())
        {
            keyed.push('N');
            if c == '-' {
                i += 1;
            }
            while i < chars.len() && chars[i].is_ascii_digit() {
                i += 1;
            }
        } else {
            keyed.push(c);
            i += 1;
        }
    }
    let keyed: String = keyed.chars().take(72).collect();
    if keyed.is_empty() {
        "unknown-rule".to_string()
    } else {
        keyed
    }
}

enum Probe {
    Skip(&'static str),
    SkipOwned(String),
    Content(Vec<u8>),
}

fn probe_file(path: &str) -> Probe {
    let info = match std::fs::metadata(path) {
        Ok(info) => info,
        Err(_) => return Probe::Skip("unreadable"),
    };
    if !info.is_file() {
        return Probe::Skip("not a regular file");
    }
    if info.len() > MAX_BYTES {
        return Probe::SkipOwned(format!("larger than {} bytes", MAX_BYTES));
    }
    let buffer = match std::fs::read(path) {
        Ok(buffer) => buffer,
        Err(_) => return Probe::Skip("unreadable"),
    };
    if buffer
        .iter()
        .take(BINARY_SNIFF_BYTES)
        .any(|byte| *byte == 0)
    {
        return Probe::Skip("binary content");
    }
    Probe::Content(buffer)
}

/// Per-repo audit exclusions, read by the same code the write guards read
/// them with: one exact relative path per line, directories with a trailing
/// slash, `#` comments. A directory entry also excludes that folder's own
/// crowding, and `.` excludes the repository root's, which is the only way
/// to declare a root whose files are fixed by pip, git or GitHub.
///
/// The reader lives in `tama-hook-tools` because both the guards and this
/// scan have to answer identically, and a second copy of the parser is a
/// second answer waiting to drift. `.tama/violations-ignore` is read first,
/// then the original root-level `.tama-violations-ignore`.
pub fn read_ignore_file(repo: &str) -> Vec<String> {
    tama_hook_tools::ports::violations_declarations::read_entries(Path::new(repo))
}

pub fn is_ignored(rel_path: &str, entries: &[String]) -> bool {
    tama_hook_tools::ports::violations_declarations::is_declared(rel_path, entries)
}
