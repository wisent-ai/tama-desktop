//! The provenance-file contract of `check_numeric_literals.py`
//! (hook `block-numeric-literals`).
//!
//! `numeric-provenance.json` is the one file where a number may live, and it is
//! not scanned for literals — it is validated instead. Every entry must be
//! exactly `{"value": <n>, "user_said": "<verbatim quote>"}`, the quote must
//! appear verbatim in a real `role=user` transcript message, and it must declare
//! that value. The hook certifies that the owner said the number, not that the
//! number is right.

mod index;

use serde_json::Value;

use super::check_numeric_literals_scan::declares;
use super::{pystr, python_stdlib, pyvalue};

const VALUE_KEY: &str = "value";
const QUOTE_KEY: &str = "user_said";

const INVALID_JSON: &str = "numeric-provenance.json is not valid JSON: ";
const NOT_OBJECT: &str = "numeric-provenance.json must be an object: name -> {value,user_said}";
const ENTRY_SHAPE: &str = "\": entry must be exactly {value,user_said}";
const VALUE_SHAPE: &str = "\": value must be a number";
const QUOTE_SHAPE: &str = "\": user_said must be a non-empty verbatim quote";
const QUOTE_MISSING: &str = "\": quote not found in any real user message: \"";
const VALUE_UNDECLARED: &str = "\": user quote does not declare value ";

const USER_ROLE: &str = "user";

/// Text-mode iteration in Python is universal-newline: `\r\n` and `\r` become
/// `\n` and nothing else is a boundary, so this is not `str.splitlines`.
fn universal_lines(text: &str) -> Vec<String> {
    text.replace("\r\n", "\n")
        .replace('\r', "\n")
        .split('\n')
        .map(str::to_string)
        .collect()
}

/// `role` is read from the nested `message` first, then the record. An empty
/// `message` object is falsy in Python, so it is the record that speaks.
fn record_texts(record: &Value) -> Vec<String> {
    let message = record
        .get("message")
        .filter(|value| value.is_object() && pyvalue::truthy(value));
    let role = message
        .and_then(|value| value.get("role"))
        .filter(|value| pyvalue::truthy(value))
        .or_else(|| record.get("role"));
    if role.and_then(Value::as_str) != Some(USER_ROLE) {
        return Vec::new();
    }
    let content = message.unwrap_or(record).get("content");
    match content {
        Some(Value::String(text)) => vec![text.clone()],
        Some(Value::Array(items)) => items
            .iter()
            .filter(|item| item.is_object())
            .map(|item| {
                item.get("text")
                    .and_then(Value::as_str)
                    .unwrap_or_default()
                    .to_string()
            })
            .collect(),
        _ => Vec::new(),
    }
}

/// The quote has to be in a real `role=user` message. `index` only picks which
/// session files to open; the verbatim test is done on the file.
pub fn quote_in_user_msg(quote: &str) -> bool {
    let needle = pystr::strip(quote);
    if needle.is_empty() {
        return false;
    }
    index::session_paths(needle)
        .iter()
        .any(|path| quote_in_transcript(std::path::Path::new(path), needle))
}

/// Whether one transcript file holds the quote in a real `role=user` message.
pub fn quote_in_transcript(path: &std::path::Path, quote: &str) -> bool {
    let needle = pystr::strip(quote);
    if needle.is_empty() {
        return false;
    }
    let Ok(bytes) = std::fs::read(path) else {
        return false;
    };
    let body = String::from_utf8_lossy(&bytes);
    for line in universal_lines(&body) {
        if !line.contains(needle) {
            continue;
        }
        let Ok(record) = serde_json::from_str::<Value>(&line) else {
            continue;
        };
        if record_texts(&record)
            .iter()
            .any(|text| text.contains(needle))
        {
            return true;
        }
    }
    false
}

/// `str(val)` for a JSON number: an integer prints without a fraction, a float
/// with one.
fn number_text(number: &serde_json::Number) -> String {
    if let Some(value) = number.as_i64() {
        return value.to_string();
    }
    if let Some(value) = number.as_u64() {
        return value.to_string();
    }
    match number.as_f64() {
        Some(value) => format!("{value:?}"),
        None => number.to_string(),
    }
}

/// `serde_json`'s map is sorted; the Python reports one message per entry in
/// file order. Only the top-level keys are needed to recover that order, and a
/// key this misses still gets its message, just later.
fn key_order(text: &str) -> Vec<String> {
    let step = python_stdlib::one();
    let mut order: Vec<String> = Vec::new();
    let mut depth = usize::MIN;
    let mut chars = text.chars().peekable();
    let mut current: Option<String> = None;
    while let Some(c) = chars.next() {
        match c {
            '{' | '[' => depth += step,
            '}' | ']' => depth = depth.saturating_sub(step),
            '"' => {
                let mut collected = String::new();
                while let Some(inner) = chars.next() {
                    if inner == '\\' {
                        if let Some(escaped) = chars.next() {
                            collected.push(escaped);
                        }
                        continue;
                    }
                    if inner == '"' {
                        break;
                    }
                    collected.push(inner);
                }
                current = Some(collected);
            }
            ':' if depth == step => {
                if let Some(key) = current.take() {
                    if !order.contains(&key) {
                        order.push(key);
                    }
                }
            }
            _ => (),
        }
    }
    order
}

fn ordered_names(text: &str, doc: &serde_json::Map<String, Value>) -> Vec<String> {
    let mut names: Vec<String> = key_order(text)
        .into_iter()
        .filter(|k| doc.contains_key(k))
        .collect();
    for name in doc.keys() {
        if !names.contains(name) {
            names.push(name.clone());
        }
    }
    names
}

fn entry_message(name: &str, entry: &Value) -> Option<String> {
    let head = format!("\"{name}");
    let fields = entry.as_object().filter(|fields| {
        fields.len() == [VALUE_KEY, QUOTE_KEY].len()
            && fields.contains_key(VALUE_KEY)
            && fields.contains_key(QUOTE_KEY)
    });
    let Some(fields) = fields else {
        return Some(format!("{head}{ENTRY_SHAPE}"));
    };
    let Some(number) = fields.get(VALUE_KEY).and_then(Value::as_number) else {
        return Some(format!("{head}{VALUE_SHAPE}"));
    };
    let quote = fields
        .get(QUOTE_KEY)
        .and_then(Value::as_str)
        .unwrap_or_default();
    if pystr::strip(quote).is_empty() {
        return Some(format!("{head}{QUOTE_SHAPE}"));
    }
    if !quote_in_user_msg(quote) {
        return Some(format!("{head}{QUOTE_MISSING}{quote}\""));
    }
    let value = number_text(number);
    if !declares(quote, &value) {
        return Some(format!("{head}{VALUE_UNDECLARED}{value}: \"{quote}\""));
    }
    None
}

pub fn check_provenance(text: &str) -> Vec<String> {
    let doc: Value = match serde_json::from_str(text) {
        Ok(value) => value,
        Err(error) => return vec![format!("{INVALID_JSON}{error}")],
    };
    let Some(entries) = doc.as_object() else {
        return vec![NOT_OBJECT.to_string()];
    };
    let mut out = Vec::new();
    for name in ordered_names(text, entries) {
        let Some(entry) = entries.get(&name) else {
            continue;
        };
        if let Some(message) = entry_message(&name, entry) {
            out.push(message);
        }
    }
    out
}
