//! Port of `src/adaptive/engine.mjs`: threshold-free adaptive engine.
//! Projections persist independently from telemetry.

mod identity;
mod lookup;
mod startup;

use startup::{invalid_observation, snapshot_hook};
pub use startup::{load_engine, load_engine_with};

use lookup::policy_entry;

use std::path::PathBuf;

use tama_core::registry::Registry;

use crate::state::projections::{
    project_contested_block, project_outcome, IdentityFacts, Projection,
};
use crate::state::{
    EpisodeBlockInput, EpisodeWriteResult, HookState, StateStore, TransitionResult,
};

const INTERPRETERS: [&str; 12] = [
    "bash", "bun", "deno", "env", "node", "perl", "php", "python", "python3", "ruby", "sh", "zsh",
];

/// `SAFE_TIER` / a resolved policy tier.
#[derive(Debug, Clone)]
pub struct Tier {
    pub name: String,
    pub enforce_verdict: bool,
    pub on_infra_failure: String,
    pub demotable: bool,
}

impl Tier {
    fn safe() -> Self {
        Tier {
            name: "integrity".to_string(),
            enforce_verdict: true,
            on_infra_failure: "warn".to_string(),
            demotable: false,
        }
    }
}

/// `SourceIdentity` from `engine.mjs`.
#[derive(Debug, Clone)]
pub struct SourceIdentity {
    pub hook_id: String,
    pub command: Option<String>,
    pub source_path: Option<String>,
    pub digest: Option<String>,
    pub verifiable: bool,
}

impl SourceIdentity {
    pub fn to_value(&self) -> serde_json::Value {
        serde_json::json!({
            "hookId": self.hook_id,
            "command": self.command,
            "sourcePath": self.source_path,
            "digest": self.digest,
            "verifiable": self.verifiable,
        })
    }

    fn facts(&self) -> IdentityFacts {
        IdentityFacts {
            verifiable: self.verifiable,
            digest: self.digest.clone(),
        }
    }
}

/// `OutcomeObservation` — fields may be missing like a partial JS object.
#[derive(Debug, Clone, Default)]
pub struct OutcomeObservation {
    pub hook_id: Option<String>,
    pub outcome: Option<String>,
}

pub struct Engine {
    pub state_dir: PathBuf,
    pub registry_path: PathBuf,
    pub policy: serde_json::Value,
    pub registry: Registry,
    /// Raw registry JSON, kept for insertion-order-faithful iteration where
    /// JS uses `Object.values(registry.events)`.
    registry_value: serde_json::Value,
    store: StateStore,
}

impl Engine {
    /// `tierOf(hookId)`.
    pub fn tier_of(&self, hook_id: &str) -> Tier {
        let empty = serde_json::Map::new();
        let hooks = self
            .policy
            .get("hooks")
            .and_then(|v| v.as_object())
            .unwrap_or(&empty);
        let tiers = self
            .policy
            .get("tiers")
            .and_then(|v| v.as_object())
            .unwrap_or(&empty);
        let entry = policy_entry(hook_id, hooks);
        let mut name = self
            .policy
            .get("defaults")
            .and_then(|d| d.get("tier"))
            .and_then(|t| t.as_str())
            .map(str::to_string);
        if let Some(entry) = entry {
            if let Some(tier) = entry.get("tier").and_then(|t| t.as_str()) {
                if !tier.is_empty() {
                    name = Some(tier.to_string());
                }
            }
        }
        let name = name
            .filter(|n| !n.is_empty())
            .unwrap_or_else(|| "integrity".to_string());
        if name == "integrity" {
            return Tier::safe();
        }
        let definition = tiers.get(&name);
        let Some(definition) = definition.and_then(|d| d.as_object()) else {
            return Tier::safe();
        };
        let demotable = name == "etiquette";
        Tier {
            name,
            enforce_verdict: definition
                .get("enforceVerdict")
                .map(|v| v.as_bool().unwrap_or(true))
                .unwrap_or(true),
            on_infra_failure: definition
                .get("onInfraFailure")
                .and_then(|v| v.as_str())
                .filter(|s| !s.is_empty())
                .unwrap_or("warn")
                .to_string(),
            demotable,
        }
    }

    /// `finish(hookId, result)` — computes the mode on persisted results.
    fn finish(&self, hook_id: &str, mut result: TransitionResult) -> TransitionResult {
        result.mode = if result.persisted {
            self.effective_mode(hook_id).to_string()
        } else {
            "enforce".to_string()
        };
        result
    }

    /// `recordOutcome(observation)`. Lock-acquisition I/O errors propagate
    /// like the JS throw outside `update`'s `try` block.
    pub fn record_outcome(
        &self,
        observation: Option<&OutcomeObservation>,
    ) -> std::io::Result<TransitionResult> {
        let Some(observation) = observation else {
            let state = snapshot_hook(&self.store, "");
            return Ok(self.finish("", invalid_observation(state)));
        };
        let hook_id = observation.hook_id.clone().unwrap_or_default();
        let outcome = observation.outcome.clone().unwrap_or_default();
        if hook_id.is_empty() || !matches!(outcome.as_str(), "pass" | "infra_failure" | "block") {
            let state = snapshot_hook(&self.store, &hook_id);
            return Ok(self.finish(&hook_id, invalid_observation(state)));
        }
        let tier = self.tier_of(&hook_id);
        let identity = self.source_identity(&hook_id);
        let facts = identity.facts();
        let outcome_for_projection = outcome.clone();
        let tier_name = tier.name.clone();
        let result = self.store.update(
            &hook_id,
            move |prior: &HookState, fact: &serde_json::Value| -> Projection {
                let event_id = fact.get("id").and_then(|v| v.as_str()).unwrap_or("");
                project_outcome(prior, &outcome_for_projection, &tier_name, &facts, event_id)
            },
            Some(serde_json::json!({
                "kind": "outcome",
                "outcome": outcome,
                "tier": tier.name,
                "identity": identity.to_value(),
            })),
        )?;
        Ok(self.finish(&hook_id, result))
    }

    /// `recordContestedBlock(observation)` — `hook_id` empty models the JS
    /// missing-observation case.
    pub fn record_contested_block(&self, hook_id: &str) -> std::io::Result<TransitionResult> {
        if hook_id.is_empty() {
            let state = snapshot_hook(&self.store, "");
            return Ok(self.finish("", invalid_observation(state)));
        }
        let tier = self.tier_of(hook_id);
        let identity = self.source_identity(hook_id);
        let facts = identity.facts();
        let tier_name = tier.name.clone();
        let result = self.store.update(
            hook_id,
            move |prior: &HookState, fact: &serde_json::Value| -> Projection {
                let event_id = fact.get("id").and_then(|v| v.as_str()).unwrap_or("");
                project_contested_block(prior, &tier_name, &facts, event_id)
            },
            Some(serde_json::json!({
                "kind": "contested-block",
                "tier": tier.name,
                "identity": identity.to_value(),
            })),
        )?;
        Ok(self.finish(hook_id, result))
    }

    /// `recordEpisodeBlock(observation)`.
    pub fn record_episode_block(&self, input: &EpisodeBlockInput) -> EpisodeWriteResult {
        self.store.record_episode_block(input)
    }

    /// `consumeLatestEpisodeBlocks(sessionId)`.
    pub fn consume_latest_episode_blocks(
        &self,
        session_id: Option<&str>,
    ) -> Vec<serde_json::Value> {
        self.store.consume_latest_episode_blocks(session_id)
    }

    /// `engine.registry?.events?.[event]` — raw entry JSON (falsy entries
    /// behave like missing ones, as in the runner checks).
    pub fn registry_event(&self, event: &str) -> Option<serde_json::Value> {
        let entry = self.registry_value.get("events")?.get(event)?.clone();
        if crate::util::js_truthy(&entry) {
            Some(entry)
        } else {
            None
        }
    }

    /// `stateSnapshot(hookId?)`.
    pub fn state_snapshot(&self, hook_id: Option<&str>) -> serde_json::Value {
        if let Some(hook_id) = hook_id {
            return self.store.snapshot(Some(hook_id));
        }
        let mut states = self.store.snapshot(None);
        if let (Some(states_map), Some(events)) = (
            states.as_object_mut(),
            self.registry_value
                .get("events")
                .and_then(|e| e.as_object()),
        ) {
            for config in events.values() {
                let hooks = config.get("hooks").and_then(|h| h.as_array());
                let Some(hooks) = hooks else { continue };
                for hook in hooks {
                    if let Some(id) = hook.get("id").and_then(|v| v.as_str()) {
                        if !id.is_empty() {
                            states_map.insert(id.to_string(), self.store.snapshot(Some(id)));
                        }
                    }
                }
            }
        }
        states
    }
}
