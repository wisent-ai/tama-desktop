//! JS semantic helpers (local copies; `tama_hooks::jsutil` is crate-private).

use serde_json::Value;

/// JS `\s` / `String#trim` whitespace: Unicode `White_Space` plus U+FEFF.
pub(crate) fn is_js_whitespace(c: char) -> bool {
    c.is_whitespace() || c == '\u{feff}'
}

pub(crate) fn trim_js(s: &str) -> &str {
    s.trim_matches(is_js_whitespace)
}

/// JS truthiness of a JSON value (absent/`undefined` is falsy).
pub(crate) fn js_truthy(v: Option<&Value>) -> bool {
    match v {
        None | Some(Value::Null) => false,
        Some(Value::Bool(b)) => *b,
        Some(Value::Number(n)) => n.as_f64().is_some_and(|f| f != 0.0),
        Some(Value::String(s)) => !s.is_empty(),
        Some(_) => true,
    }
}

/// Approximation of JS `Number#toString` for JSON numbers.
pub(crate) fn js_number_to_string(n: &serde_json::Number) -> String {
    if let Some(i) = n.as_i64() {
        return i.to_string();
    }
    if let Some(u) = n.as_u64() {
        return u.to_string();
    }
    let f = n.as_f64().unwrap_or(f64::NAN);
    if f == 0.0 {
        return "0".to_string(); // also covers -0
    }
    let a = f.abs();
    if f.fract() == 0.0 && a < 1e21 {
        return format!("{f:.0}");
    }
    if a >= 1e21 || a < 1e-6 {
        // Rust prints "1.5e21"; JS prints "1.5e+21".
        let s = format!("{f:e}");
        return match s.split_once('e') {
            Some((m, e)) if !e.starts_with('-') => format!("{m}e+{e}"),
            _ => s,
        };
    }
    format!("{f}")
}

/// JS `String(value)` for a JSON value.
pub(crate) fn js_to_string(v: &Value) -> String {
    match v {
        Value::Null => "null".to_string(),
        Value::Bool(b) => if *b { "true" } else { "false" }.to_string(),
        Value::Number(n) => js_number_to_string(n),
        Value::String(s) => s.clone(),
        // Array#toString joins with commas; null/undefined become empty.
        Value::Array(items) => items
            .iter()
            .map(|i| match i {
                Value::Null => String::new(),
                other => js_to_string(other),
            })
            .collect::<Vec<_>>()
            .join(","),
        Value::Object(_) => "[object Object]".to_string(),
    }
}

/// JS `String(value)` where the value may be absent (`undefined`).
pub(crate) fn js_to_string_opt(v: Option<&Value>) -> String {
    match v {
        None => "undefined".to_string(),
        Some(v) => js_to_string(v),
    }
}
