//! Which files the line limit is about.
//!
//! The rule leaves structured data untouched by the line count on the
//! operator's instruction ("wylacz limit dla plikow rejestrow", 2026-09-10):
//! a registry is read whole by the code that loads it, so "split into smaller
//! modules" is not an instruction anybody can follow there. The manuscript
//! sources a thesis is written in were added the same way on 2026-09-14.
//!
//! This file used to carry its own copy of that list, kept honest by a test
//! that read the shipped shell hook. Two copies is two answers waiting to
//! drift, and the shell copy is frozen behind the consent gate while the hook
//! that actually runs is Rust, so the copy could not track it any more. The
//! hook's own list is the answer now.
//!
//! Only the line rule is relaxed. The folder-file limit, the new-file
//! justification and the content gates still apply to a registry.

pub use tama_hook_tools::ports::block_oversized_files::exempt as exempt_from_line_limit;

#[cfg(test)]
mod tests {
    use super::exempt_from_line_limit;

    /// A registry, a manifest and a manuscript are data; source is source.
    #[test]
    fn the_scan_answers_as_the_hook_does() {
        for path in [
            "/repo/.shared-hooks/file_justifications.json",
            "/repo/tables/state-CA-2026.toml",
            "/repo/rust/crates/tama-hook-tools/Cargo.toml",
            "/repo/data/rows.CSV",
            "/repo/paper/main.tex",
        ] {
            assert!(exempt_from_line_limit(path), "{path}");
        }
        for path in [
            "/repo/src/main.rs",
            "/repo/src/toml_reader.rs",
            "/repo/README.md",
        ] {
            assert!(!exempt_from_line_limit(path), "{path}");
        }
    }
}
