//! Code that replaces a missing value with a stand-in instead of letting the
//! miss travel.
//!
//! The stand-in set is the "lie about state" set: zero, minus one, NaN,
//! undefined, null, an empty array or object, an empty string, and the words
//! unknown, none and n/a. Assigning one of those where a read failed makes
//! the caller unable to tell a miss from a real value, and that is how a
//! scraped balance of nothing became a balance of zero.
//!
//! Each shape is narrow on purpose. Ordinary input validation — `if (!x)
//! throw`, `return null` — assigns nothing and passes.
//!
//! One mechanical note, and it applies to the tests below as well: the shapes
//! this gate matches are shapes it refuses to see written into any file, so
//! its pattern text, its messages and its test fixtures are assembled from
//! fragments. A source file that spelled them out could not be written while
//! the gate was running.

use std::sync::LazyLock;

use regex::Regex;

use crate::ports::transport_common as common;

/// The values a read is quietly replaced with.
const SENTINEL: &str = concat!(
    "(0(\\.0+)?|-1|NaN|undefined|null|\\[\\]|\\{\\}|\\x27\\x27|\\x22\\x22",
    "|\\x27(unknown|none|n/a)\\x27|\\x22(unknown|none|n/a)\\x22)",
);
const NAME: &str = "[a-zA-Z_][a-zA-Z0-9_.]*";
const QUIET: &str = concat!("Silent-", "default");
const PROPAGATE: &str = "Propagate or throw -- don't lie about state.";

/// One shape, its pattern, and the complaint it earns.
struct Rule {
    pattern: Regex,
    complaint: String,
}

fn rule(pattern: String, complaint: String) -> Rule {
    Rule {
        pattern: common::compile(&pattern),
        complaint,
    }
}

/// `if (x == null) { … }` and `if (!x) { … }`, with the body captured so the
/// assignment inside it can be checked against the very name that was tested.
/// Python writes this as a backreference; the Rust engine has none, so the
/// name is compared instead of re-matched.
static TESTED_NULL: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        "(?i)if[[:space:]]*\\([[:space:]]*(?P<name>{NAME})[[:space:]]*(==|===)[[:space:]]*\
         (null|undefined)[[:space:]]*\\)[[:space:]]*\\{{(?P<body>[^}}]*)"
    ))
});

static TESTED_FALSY: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        "(?i)if[[:space:]]*\\([[:space:]]*![[:space:]]*(?P<name>{NAME})[[:space:]]*\\)\
         [[:space:]]*\\{{(?P<body>[^}}]*)"
    ))
});

static ASSIGNS_SENTINEL: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        "(?i)(?P<name>{NAME})[[:space:]]*=[[:space:]]*{SENTINEL}"
    ))
});

/// Whether the body of a guard assigns a stand-in to the very name the guard
/// tested.
fn body_reassigns(body: &str, name: &str) -> bool {
    ASSIGNS_SENTINEL
        .captures_iter(body)
        .filter_map(|caps| caps.name("name"))
        .any(|found| found.as_str() == name)
}

fn guarded_reassignment(text: &str, guard: &Regex) -> bool {
    for caps in guard.captures_iter(text) {
        let Some(name) = caps.name("name") else {
            continue;
        };
        let Some(body) = caps.name("body") else {
            continue;
        };
        if body_reassigns(body.as_str(), name.as_str()) {
            return true;
        }
    }
    false
}

/// The shapes that need no name comparison.
static RULES: LazyLock<Vec<Rule>> = LazyLock::new(|| {
    vec![
        rule(
            format!(
                "(?i)catch[[:space:]]*(\\([^)]*\\))?[[:space:]]*\\{{[^}}]{{0,200}}=[[:space:]]*{SENTINEL}[[:space:]]*[;}}]"
            ),
            "BLOCKED: catch{} that absorbs the error into a sentinel. Propagate the error or \
             re-throw with context -- don't lie about state."
                .to_string(),
        ),
        rule(
            format!(
                "(?i)\\.catch[[:space:]]*\\([[:space:]]*\\([^)]*\\)[[:space:]]*=>[[:space:]]*{SENTINEL}[[:space:]]*\\)"
            ),
            "BLOCKED: .catch(() => sentinel). Caller can't distinguish miss from real value -- \
             propagate the error."
                .to_string(),
        ),
        rule(
            format!(
                "(?i)(parse|scrape|extract|fetch|read|get)[a-zA-Z_]*\\([^)]*\\)[[:space:]]*(\\|\\||\\?\\?)[[:space:]]*{SENTINEL}"
            ),
            "BLOCKED: parse/scrape/get(...) || sentinel. The miss is unrecoverable -- surface it \
             instead of pretending."
                .to_string(),
        ),
        rule(
            format!(
                "(?i)({NAME})[[:space:]]*(==|===)[[:space:]]*(null|undefined)[[:space:]]*\\?[[:space:]]*{SENTINEL}[[:space:]]*:"
            ),
            "BLOCKED: Ternary stand-in (x == null ? sentinel : x). Propagate the null."
                .to_string(),
        ),
        rule(
            format!(
                "(?i){NAME}[[:space:]]*(\\|\\|=|\\?\\?=)[[:space:]]*{SENTINEL}[[:space:]]*[;,)}}]"
            ),
            "BLOCKED: ||=/??= stand-in (x ||= sentinel). Compound-assign to a sentinel hides \
             whether the read failed."
                .to_string(),
        ),
        rule(
            format!(
                "(?i)if[[:space:]]*\\([[:space:]]*{NAME}[[:space:]]*(==|===)[[:space:]]*(null|undefined)[[:space:]]*\\)[[:space:]]*\\{{[^}}]*{NAME}[[:space:]]*=[[:space:]]*{SENTINEL}"
            ),
            "BLOCKED: if (x==null) { y = sentinel } -- a stand-in on another path. Propagate or \
             throw."
                .to_string(),
        ),
        rule(
            format!(
                "(?i)if[[:space:]]*\\([[:space:]]*{NAME}[[:space:]]*(==|===)[[:space:]]*(null|undefined)[[:space:]]*\\)[[:space:]]*\\{{[^}}]*{NAME}\\([[:space:]]*{SENTINEL}[[:space:]]*\\)"
            ),
            "BLOCKED: if (x==null) { setX(sentinel) } -- a stand-in through a setter call. \
             Propagate or throw."
                .to_string(),
        ),
        rule(
            format!("(?i)else[[:space:]]*\\{{[^}}]*{NAME}[[:space:]]*=[[:space:]]*{SENTINEL}"),
            "BLOCKED: else { x = sentinel } -- the same lie in the else branch. Throw or return \
             null."
                .to_string(),
        ),
        rule(
            format!(
                "(?i)switch[[:space:]]*\\([^)]*\\)[[:space:]]*\\{{[^}}]*default[[:space:]]*:[^}}]*{NAME}[[:space:]]*=[[:space:]]*{SENTINEL}"
            ),
            "BLOCKED: switch default arm assigning sentinel -- the same lie in the default arm."
                .to_string(),
        ),
        rule(
            format!(
                "(?i)function[^(]*\\([^)]*\\{{[^}}]*[a-zA-Z_][a-zA-Z0-9_]*[[:space:]]*=[[:space:]]*{SENTINEL}[[:space:]]*[,}}]"
            ),
            "BLOCKED: param destructuring stand-in. Throw on missing or accept the undefined."
                .to_string(),
        ),
    ]
});

/// The complaint this content earns, if it substitutes a stand-in for a miss.
pub(crate) fn complaint(flat: &str) -> Option<String> {
    if guarded_reassignment(flat, &TESTED_NULL) {
        return Some(format!(
            "BLOCKED: {QUIET} branch (if x==null {{ x = sentinel }}). {PROPAGATE}"
        ));
    }
    if guarded_reassignment(flat, &TESTED_FALSY) {
        return Some(format!(
            "BLOCKED: {QUIET} branch (if !x {{ x = sentinel }}). {PROPAGATE}"
        ));
    }
    RULES
        .iter()
        .find(|rule| rule.pattern.is_match(flat))
        .map(|rule| rule.complaint.clone())
}

#[cfg(test)]
mod tests {
    use super::complaint;

    const ZERO: &str = "0";
    const NULL: &str = "null";
    const MINUS_ONE: &str = "-1";
    const NOT_A_NUMBER: &str = "NaN";

    /// The body has to reassign the very name the guard tested, which is what
    /// keeps `if (x == null) { y = 7 }` out of this first rule.
    #[test]
    fn a_guard_that_reassigns_its_own_name_is_refused() {
        let code = format!("if (balance == null) {{ balance = {ZERO}; }}");
        let found = complaint(&code).expect("a stand-in");
        assert!(found.contains("if x==null"), "{found}");
        assert!(complaint("if (balance == null) { other = 7; }").is_none());
    }

    #[test]
    fn a_falsy_guard_that_reassigns_its_own_name_is_refused() {
        let code = format!("if (!count) {{ count = {MINUS_ONE} }}");
        let found = complaint(&code).expect("a stand-in");
        assert!(found.contains("if !x"), "{found}");
    }

    #[test]
    fn the_other_shapes_are_refused_too() {
        for code in [
            format!("try {{ x() }} catch (e) {{ value = {NULL}; }}"),
            format!("await load().catch(() => {NULL})"),
            format!("const n = parseBalance(html) || {ZERO}"),
            format!("const v = raw == null ? {ZERO} : raw"),
            format!("count ??= {ZERO};"),
            format!("if (raw == null) {{ state.balance = {ZERO} }}"),
            format!("if (raw == null) {{ setBalance({ZERO}) }}"),
            format!("else {{ total = {NOT_A_NUMBER} }}"),
            format!("switch (kind) {{ default: total = {ZERO} }}"),
            format!("function f({{ balance = {ZERO} }} = {{}}) {{}}"),
        ] {
            assert!(complaint(&code).is_some(), "{code}");
        }
    }

    /// Validation that throws or returns assigns nothing, and stays legal.
    #[test]
    fn validation_that_propagates_passes() {
        for code in [
            "if (!x) throw new Error('missing x');",
            "if (value == null) return null;",
            "const n = parseBalance(html); if (n == null) throw new Error('no balance');",
            "if (count == 0) { count = 1 }",
        ] {
            assert!(complaint(code).is_none(), "{code}");
        }
    }
}
