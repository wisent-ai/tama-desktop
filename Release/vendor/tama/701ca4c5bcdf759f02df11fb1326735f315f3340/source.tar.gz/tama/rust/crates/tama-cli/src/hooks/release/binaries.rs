//! Which binaries a release builds, and how one lands in `~/.local/bin`.
//!
//! Split out of `hooks/release.rs`, which had grown past the
//! three-hundred-line limit; the release run itself stays there.

use std::collections::BTreeMap;
use std::path::{Path, PathBuf};

use sha2::{Digest, Sha256};

use super::super::declare::run;
use super::super::warm;

/// Every `tama-…` binary the registry names, in registry order, whichever way
/// the entry spells the directory it lives in. The registry is read once, by
/// `hooks warm`, so the list this builds and the list that gets warmed and
/// measured afterwards cannot drift apart.
pub(super) fn hook_binaries(registry: &Path) -> Vec<String> {
    let mut names: Vec<String> = Vec::new();
    for hook in warm::registry_hooks(registry) {
        let Some(name) = hook
            .path
            .file_name()
            .and_then(|name| name.to_str())
            .map(str::to_string)
        else {
            continue;
        };
        if !names.contains(&name) {
            names.push(name);
        }
    }
    names
}

pub(super) fn install(built: &Path, target: &Path) -> Result<(), String> {
    if let Some(parent) = target.parent() {
        std::fs::create_dir_all(parent)
            .map_err(|error| format!("cannot create {}: {error}", parent.display()))?;
    }
    std::fs::copy(built, target)
        .map_err(|error| format!("cannot install {}: {error}", target.display()))?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        let mode = std::fs::Permissions::from_mode(0o755);
        std::fs::set_permissions(target, mode)
            .map_err(|error| format!("cannot make {} executable: {error}", target.display()))?;
    }
    Ok(())
}

/// Whether a built program still has to be installed: this machine has no
/// copy of it, or the copy it has came from a different build.
pub fn needs_install(
    recorded: &BTreeMap<String, String>,
    name: &str,
    digest: &str,
    installed: bool,
) -> bool {
    !installed || recorded.get(name).map(String::as_str) != Some(digest)
}

/// The workshop's signing command, and the product these binaries belong to.
const SIGNING_PROGRAM: &str = "wisent-products";
const SIGNING_PRODUCT: &str = "tama";

/// Where a release records the build each installed binary came from.
///
/// Signing is not byte-stable — two signatures over the same code differ —
/// so the installed copy can no longer be compared against the freshly built
/// one. What identifies a build is the unsigned binary, and that is what is
/// written here, beside the checkout the install came from.
pub(super) const BUILD_DIGESTS_FILE: &str = ".tama/installed-binaries.json";

/// The digest of a built, still unsigned binary.
pub(super) fn build_digest(path: &Path) -> Option<String> {
    let bytes = std::fs::read(path).ok()?;
    Some(format!("{:x}", Sha256::digest(bytes)))
}

/// What the last release installed: binary name to unsigned build digest.
pub(super) fn installed_digests(home: &Path) -> BTreeMap<String, String> {
    std::fs::read_to_string(home.join(BUILD_DIGESTS_FILE))
        .ok()
        .and_then(|text| serde_json::from_str(&text).ok())
        .unwrap_or_default()
}

/// Record what this release installed, so the next one can leave it alone.
pub(super) fn record_digests(
    home: &Path,
    digests: &BTreeMap<String, String>,
) -> Result<(), String> {
    let path = home.join(BUILD_DIGESTS_FILE);
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)
            .map_err(|error| format!("cannot create {}: {error}", parent.display()))?;
    }
    let text = serde_json::to_string_pretty(digests)
        .map_err(|error| format!("cannot describe what was installed: {error}"))?;
    std::fs::write(&path, format!("{text}\n"))
        .map_err(|error| format!("cannot write {}: {error}", path.display()))
}

/// Sign the given installed programs with the product identity.
///
/// `cargo` leaves an ad-hoc, linker-signed Mach-O, and macOS kills such a
/// copy the moment a session runs it: on 2026-09-21 a release put 73 of them
/// in `~/.local/bin`, every hook died with signal 9 before it could read its
/// event, and `tama-cli` — the program that installs hooks — died the same
/// way, so the product could not repair the machine it had just broken.
///
/// Signing happens after the copy, at the path the binary will be run from.
/// Signing the build and copying the result produced a file the kernel
/// rejected page by page (`CODE SIGNING: rejecting invalid page … sending
/// SIGKILL`) even though `codesign -v` called it valid on disk.
pub(super) fn sign_built(root: &Path, paths: &[PathBuf]) -> Result<usize, String> {
    if paths.is_empty() {
        return Ok(0);
    }
    let mut argv = vec![
        SIGNING_PROGRAM.to_string(),
        "signing".to_string(),
        "sign".to_string(),
        "--product".to_string(),
        SIGNING_PRODUCT.to_string(),
    ];
    argv.extend(paths.iter().map(|path| path.display().to_string()));
    run(Path::new("/usr/bin/env"), &argv, root).map_err(|error| {
        format!(
            "cannot sign the built binaries with the {SIGNING_PRODUCT} identity: {error}\n\
             An unsigned copy is killed by the operating system on first run, so installing \
             them would leave this machine without working hooks and without a working CLI. \
             `{SIGNING_PROGRAM} signing sign --product {SIGNING_PRODUCT} <path>` is what signs \
             them; `{SIGNING_PROGRAM} signing residue` lists what is still ad-hoc."
        )
    })?;
    Ok(paths.len())
}

pub(super) fn python(root: &Path, script: &str, args: &[String]) -> Result<String, String> {
    let scripts = root
        .parent()
        .map(|parent| parent.join("tama-desktop/Scripts"))
        .unwrap_or_default();
    let path = scripts.join(script);
    if !path.is_file() {
        return Err(format!(
            "{} is missing; the live release is staged by tama-desktop, which has to be checked \
             out beside this repository",
            path.display()
        ));
    }
    let mut all = vec![path.display().to_string()];
    all.extend_from_slice(args);
    run(
        Path::new("/usr/bin/env"),
        &[vec!["python3".to_string()], all].concat(),
        root,
    )
}
