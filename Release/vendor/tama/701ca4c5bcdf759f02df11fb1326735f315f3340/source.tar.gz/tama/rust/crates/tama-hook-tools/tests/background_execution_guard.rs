//! `tama-block-background-execution`, driven as the real binary with a real
//! payload on stdin.
//!
//! The operator's rule is that work stays where he can see it. Two `find`
//! passes over his whole home directory had run in the background without him
//! being told, and he learned of them only by asking what I was doing.
//!
//! Each case holds one command to its own exit status and, when refused, to
//! the exact refusal sentence. The quoted-ampersand cases are the ones that
//! matter most: `shlex` renders `grep '&' file` and `sleep 5 &` with the same
//! bare `&` token, so a guard built on tokens would refuse ordinary data, and
//! these pin the difference.

use std::io::Write as _;
use std::process::{Command, Output, Stdio};

use serde_json::json;

const EXIT_PASS: i32 = false as i32;
const EXIT_REFUSED: i32 = true as i32 + true as i32;

const GUARD: &str = env!("CARGO_BIN_EXE_tama-block-background-execution");

const ASYNC_REFUSAL: &str = "BLOCKED: background execution is forbidden. Run it in the \
                             foreground so its output is seen. Detected: the call asked for the \
                             background.";

fn token_refusal(token: &str) -> String {
    format!(
        "BLOCKED: background execution is forbidden. Run it in the foreground so its output is \
         seen. Detected: '{token}' puts the command in the background."
    )
}

fn drive(payload: &serde_json::Value) -> Output {
    let mut child = Command::new(GUARD)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .unwrap_or_else(|error| panic!("spawn the guard: {error}"));
    child
        .stdin
        .as_mut()
        .expect("guard stdin")
        .write_all(payload.to_string().as_bytes())
        .expect("write payload");
    child.wait_with_output().expect("guard output")
}

fn run(command: &str) -> Output {
    drive(&json!({ "tool_name": "Bash", "tool_input": { "command": command } }))
}

fn refuses(command: &str, sentence: &str) {
    let output = run(command);
    let stderr = String::from_utf8_lossy(&output.stderr).into_owned();
    assert_eq!(
        output.status.code(),
        Some(EXIT_REFUSED),
        "{command} should be refused; stderr: {stderr}"
    );
    assert_eq!(
        stderr.trim_end(),
        sentence,
        "refusal sentence for {command}"
    );
}

fn passes(command: &str) {
    let output = run(command);
    let stderr = String::from_utf8_lossy(&output.stderr).into_owned();
    assert_eq!(
        output.status.code(),
        Some(EXIT_PASS),
        "{command} should pass; stderr: {stderr}"
    );
    assert!(stderr.is_empty(), "a passing call prints nothing: {stderr}");
}

#[test]
fn a_call_that_asks_for_the_background_is_refused() {
    let payload = json!({
        "tool_name": "Bash",
        "tool_input": { "command": "sleep 5", "async": true },
    });
    let output = drive(&payload);
    let stderr = String::from_utf8_lossy(&output.stderr).into_owned();
    assert_eq!(output.status.code(), Some(EXIT_REFUSED), "stderr: {stderr}");
    assert_eq!(stderr.trim_end(), ASYNC_REFUSAL);
}

#[test]
fn a_call_that_declines_the_background_passes() {
    let payload = json!({
        "tool_name": "Bash",
        "tool_input": { "command": "sleep 5", "async": false },
    });
    let output = drive(&payload);
    assert_eq!(output.status.code(), Some(EXIT_PASS), "async false passes");
}

#[test]
fn a_trailing_ampersand_is_refused() {
    refuses("sleep 5 &", &token_refusal("&"));
}

#[test]
fn a_second_segment_that_backgrounds_is_refused() {
    refuses("echo start; sleep 5 &", &token_refusal("&"));
}

#[test]
fn a_doubled_ampersand_passes() {
    passes("echo one && echo two");
}

#[test]
fn a_quoted_ampersand_is_data_and_passes() {
    passes("grep '&' Cargo.toml");
    passes("echo \"a & b\"");
}

/// A report that names a detaching program starts nothing. The gate used to
/// cut the payload on separators before reading its quotes, so a sentence
/// with a semicolon in it arrived as command words.
#[test]
fn a_sentence_that_names_a_detaching_program_passes() {
    passes("git commit -m \"chore: stop using nohup for the sync; it hid the failure\"");
    passes("oko-cli transcripts tasks evidence s 1 --commit \"setsid was refused; disown too\"");
}

#[test]
fn nohup_is_refused() {
    refuses("nohup sleep 5", &token_refusal("nohup"));
}

#[test]
fn disown_is_refused() {
    refuses("disown", &token_refusal("disown"));
}

#[test]
fn setsid_is_refused() {
    refuses("setsid sleep 5", &token_refusal("setsid"));
}

#[test]
fn a_detached_multiplexer_is_refused() {
    refuses("screen -dm foo", &token_refusal("-dm"));
    refuses("tmux new-session -d", &token_refusal("-d"));
}

#[test]
fn an_ordinary_multiplexer_call_passes() {
    passes("tmux ls");
    passes("screen -ls");
}

#[test]
fn an_inner_shell_that_backgrounds_is_refused() {
    refuses("bash -c 'sleep 5 &'", &token_refusal("&"));
    refuses("sh -c \"nohup sleep 5\"", &token_refusal("nohup"));
}

#[test]
fn an_ordinary_foreground_command_passes() {
    passes("cargo build --quiet");
    passes("git status --porcelain");
}

/// The false refusal this guard shipped with, in the shapes that hit it.
///
/// `2>&1` duplicates a file descriptor; `&>` redirects both streams. Neither
/// starts anything, and on 2026-09-09 the guard refused every ordinary
/// `... 2>&1 | sed` call on this machine — a ban on hidden work had turned
/// into a ban on reading stderr.
#[test]
fn a_redirection_that_carries_an_ampersand_passes() {
    passes("echo probe 2>&1");
    passes("cargo build --quiet 2>&1 | sed -n '1,2p'");
    passes("printf hi 1>&2");
    passes("cargo build --quiet &> build.log");
}

/// The ban still holds where it should, including beside a redirection.
#[test]
fn a_background_ampersand_beside_a_redirection_is_still_refused() {
    refuses("cargo build --quiet 2>&1 &", &token_refusal("&"));
    refuses("sleep 5 > out.log &", &token_refusal("&"));
}
