//! Whether one ending is the same report as another, said again.
//!
//! Two reports about the same task share vocabulary even when the second
//! carries real news, so single words are not compared; runs of three words
//! are. A report re-issued with a sentence changed keeps most of its runs; a
//! report that says what changed since the refusal does not.

use std::collections::HashSet;

/// Words per run. Text: this file is not allowed a bare number.
const RUN_WORDS_TEXT: &str = "3";
/// Fraction of shared runs at which two endings are one ending.
const SAME_AT_TEXT: &str = "0.6";
/// Shorter endings than this are not compared: a one-line answer repeated is
/// an answer, not a loop.
const MIN_WORDS_TEXT: &str = "40";
const PERCENT_TEXT: &str = "100";

fn run_words() -> usize {
    RUN_WORDS_TEXT.parse().unwrap_or_default()
}

fn same_at() -> f64 {
    SAME_AT_TEXT.parse().unwrap_or_default()
}

fn min_words() -> usize {
    MIN_WORDS_TEXT.parse().unwrap_or_default()
}

fn words(text: &str) -> Vec<String> {
    text.split(|c: char| !c.is_alphanumeric())
        .filter(|word| !word.is_empty())
        .map(str::to_lowercase)
        .collect()
}

fn runs(words: &[String]) -> HashSet<String> {
    words
        .windows(run_words())
        .map(|window| window.join(" "))
        .collect()
}

/// The share of word runs the two texts have in common (Jaccard), or `None`
/// when either is too short to be a report.
pub fn shared_runs(one: &str, other: &str) -> Option<f64> {
    let (first, second) = (words(one), words(other));
    if first.len() < min_words() || second.len() < min_words() {
        return None;
    }
    let (a, b) = (runs(&first), runs(&second));
    let union = a.union(&b).count();
    if union == usize::MIN {
        return None;
    }
    Some(a.intersection(&b).count() as f64 / union as f64)
}

/// The earlier ending this one repeats, with the share as a whole percentage.
pub fn repeated<'a>(ending: &str, earlier: &'a [String]) -> Option<(&'a str, u32)> {
    earlier
        .iter()
        .filter_map(|previous| {
            shared_runs(ending, previous).map(|share| (previous.as_str(), share))
        })
        .filter(|(_, share)| *share >= same_at())
        .max_by(|(_, a), (_, b)| a.total_cmp(b))
        .map(|(previous, share)| {
            let percent: f64 = PERCENT_TEXT.parse().unwrap_or_default();
            (previous, (share * percent).round() as u32)
        })
}

#[cfg(test)]
mod tests {
    use super::repeated;

    const FIRST: &str = "Co zostało zrobione. Sprawdziłem, dlaczego grant ensure dodało zdolność, \
        której potem nie było. Na odizolowanym skarbcu ta operacja działa: nowy realny test robi \
        ensure na przedmiot, którego konsument nigdy nie miał, i sprawdza plik skarbca oraz grant \
        verify. Na Twojej maszynie zapis zniknął, bo skarbiec został nadpisany przez sync-daemon. \
        Blokery. Wydanie jeden-desktop przez Stado: HTTP 403. Następne kroki. Żadnych.";

    #[test]
    fn the_same_report_with_one_new_sentence_is_a_repeat() {
        let again = FIRST.replace(
            "Następne kroki. Żadnych.",
            "Dostarczone dziś: tagi. Następne kroki. Żadnych.",
        );
        let earlier = [FIRST.to_owned()];
        let (previous, percent) = repeated(&again, &earlier).expect("a repeat");
        assert_eq!(previous, FIRST);
        assert!(
            percent >= "60".parse::<u32>().unwrap_or_default(),
            "{percent}%"
        );
    }

    #[test]
    fn a_report_that_says_what_changed_is_not_a_repeat() {
        let news = "Co zostało zrobione. Zbudowałem nadawanie grantów wydawcy w Stado: katalog \
            wydań nadaje stado-release-client odczyt przedmiotu wydawcy na skarbcu właściciela przy \
            każdym submit. Test tests/release/publisher_grant.rs tworzy odizolowany skarbiec, \
            rejestruje produkt, wysyła wydanie i sprawdza grant w pliku. Przeszedł, commit a1b2c3d \
            wypchnięty. Wydanie jeden-desktop 0.1.4 opublikowane. Blokery. Żadnych. Następne kroki. Żadnych.";
        assert_eq!(repeated(news, &[FIRST.to_owned()]), None);
    }

    #[test]
    fn a_short_answer_repeated_is_not_a_loop() {
        let short = "Nie. Sesje nie pracują na innych hostach.";
        assert_eq!(repeated(short, &[short.to_owned()]), None);
    }
}
