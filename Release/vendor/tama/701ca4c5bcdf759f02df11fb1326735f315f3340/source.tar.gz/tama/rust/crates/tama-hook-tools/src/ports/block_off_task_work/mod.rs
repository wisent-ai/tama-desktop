//! Decision half of `tama-block-off-task-work` (registry hook
//! `block-off-task-work`).
//!
//! On 2026-09-21 a session was asked for one thing — a gate against one-off
//! commands — delivered it, and then spent the next hour repairing an
//! installer, a gateway, a credential pool and a provider sign-in, none of
//! which anybody had asked for. Each repair was of something really broken,
//! which is what makes the drift hard to see from inside: the work looks
//! like work. The operator, reading the queue of builds it had also started:
//! "dlaczego pracujesz nad czyms co nie jest Twoim zadaniem".
//!
//! Relatedness cannot be guessed by a gate, and a gate that guessed it would
//! be wrong in both directions. So it is declared: a session states, in the
//! operator's own words, what it was asked for and which repositories that
//! touches (`tama task scope set`). Every mutation is then checked against
//! that declaration:
//!
//!   * nothing declared — the first write is refused until the session says
//!     what it is working on, which costs one command and makes the answer
//!     to "what is your task" a thing the machine holds, not a memory;
//!   * a repository outside the declaration — refused, naming what was
//!     declared and the instruction that authorised it, so widening the
//!     scope means quoting the operator asking for it.
//!
//! The scope is per session and lives beside the other hook state under
//! `~/.tama/task-scope/<session>.json`. Reads are never refused: reading the
//! fleet to answer a question is how a session learns it has drifted.

use std::path::PathBuf;

use serde_json::Value;

use crate::ports::python_stdlib::expanduser;

mod registers;
mod scope;
pub mod scope_cli;

pub(crate) use scope::{now_utc, SCOPE_HOME_RELATIVE};
pub use scope::{refusal, repository_of, TaskScope};

/// The tools that change a file, and the shell programs that deliver one.
const WRITE_TOOLS: [&str; 6] = [
    "write",
    "edit",
    "refactor",
    "apply_patch",
    "patch",
    "notebook",
];
const SHELL_TOOLS: [&str; 4] = ["bash", "shell", "exec", "run_command"];
/// `git commit` and `git push` publish work; a build or a read inside a
/// repository is how a session learns anything and is never refused here.
const DELIVERY_VERBS: [&str; 2] = ["commit", "push"];
const PATH_KEYS: [&str; 5] = ["file_path", "path", "file", "destination", "new_path"];

/// Every path a payload would write.
fn written_paths(tool: &str, input: &Value) -> Vec<String> {
    let mut paths = Vec::new();
    if WRITE_TOOLS.contains(&tool) {
        for key in PATH_KEYS {
            if let Some(path) = input.get(key).and_then(Value::as_str) {
                paths.push(path.to_string());
            }
        }
        if let Some(patch) = input.get("input").and_then(Value::as_str) {
            paths.extend(hunk_paths(patch));
        }
        if let Some(patch) = input.as_str() {
            paths.extend(hunk_paths(patch));
        }
    }
    paths
}

/// The files a hash-line patch names, read from its `[path#TAG]` headers.
fn hunk_paths(patch: &str) -> Vec<String> {
    patch
        .lines()
        .filter_map(|line| {
            let header = line.trim().strip_prefix('[')?.strip_suffix(']')?;
            let (path, tag) = header.rsplit_once('#')?;
            (!tag.is_empty() && tag.chars().all(|value| value.is_ascii_hexdigit()))
                .then(|| path.to_string())
        })
        .collect()
}

/// Why this payload is work outside the session's declared task, if it is.
pub fn evaluate(payload: &Value) -> Option<String> {
    let home = PathBuf::from(expanduser("~"));
    let session = tama_hooks::session_record::session_id_of(payload);
    let tool = tama_hooks::session_record::tool_name_of(payload);
    let input = payload.get("tool_input").unwrap_or(&Value::Null);
    let mut paths = written_paths(&tool, input);
    if SHELL_TOOLS.contains(&tool.as_str()) {
        if let Some(command) = input.get("command").and_then(Value::as_str) {
            paths.extend(delivery_paths(command, input));
        }
    }
    // Tama captures the operator's prompt verbatim per session; the digest
    // of the current one is what a scope has to be declared against, so a
    // scope written for the previous instruction stops authorising work the
    // moment a new one arrives.
    let instruction = crate::assignment::load(&session)
        .ok()
        .flatten()
        .map(|assignment| assignment.turn_digest)
        .unwrap_or_default();
    paths
        .into_iter()
        .filter_map(|path| repository_of(&path, &home))
        .find_map(|repository| refusal(&repository, &session, &instruction, &home))
}

/// The repository a shell command would publish from: the working directory
/// of a `git commit` or `git push`, which is where off-task work leaves the
/// machine.
fn delivery_paths(command: &str, input: &Value) -> Vec<String> {
    let words: Vec<&str> = command.split_whitespace().collect();
    let publishes =
        words.contains(&"git") && words.iter().any(|word| DELIVERY_VERBS.contains(word));
    if !publishes {
        return Vec::new();
    }
    input
        .get("cwd")
        .and_then(Value::as_str)
        .map(|cwd| vec![cwd.to_string()])
        .unwrap_or_else(|| {
            std::env::current_dir()
                .map(|cwd| vec![cwd.to_string_lossy().to_string()])
                .unwrap_or_default()
        })
}

#[cfg(test)]
mod tests {
    use super::scope::WORKSPACE_HOME_RELATIVE;
    use super::*;
    use serde_json::json;
    use std::path::Path;

    /// A home under the build tree, the way every other port's fixture is
    /// made here: nothing this repository writes goes to a temporary path.
    fn scratch(name: &str) -> PathBuf {
        let home = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../target/tmp")
            .join(format!("tama-task-scope-{name}"));
        let _ = std::fs::remove_dir_all(&home);
        std::fs::create_dir_all(&home).expect("a home for the fixture");
        home
    }

    fn home_with(name: &str, session: &str, scope: Value) -> PathBuf {
        let home = scratch(name);
        let directory = home.join(SCOPE_HOME_RELATIVE);
        std::fs::create_dir_all(&directory).expect("the scope directory");
        std::fs::write(
            directory.join(format!("{session}.json")),
            serde_json::to_string(&scope).expect("scope json"),
        )
        .expect("the scope file");
        home
    }

    #[test]
    fn a_repository_the_instruction_named_passes_and_another_is_refused() {
        let home = home_with(
            "named",
            "01a0",
            json!({
                "turn_digest": "d1",
                "task": "add a hook in Tama that blocks one-off commands",
                "repositories": ["tama", "tama-landing"],
                "defect": "df0d9346",
            }),
        );
        assert!(refusal("tama", "01a0", "d1", &home).is_none());
        assert!(refusal("tama-landing", "01a0", "d1", &home).is_none());

        let refused = refusal("brama", "01a0", "d1", &home).expect("brama is outside the task");
        assert!(refused.contains("defect df0d9346"), "{refused}");
        assert!(refused.contains("add a hook in Tama"), "{refused}");
        assert!(refused.contains("tama, tama-landing"), "{refused}");
        assert!(refused.contains("oko-cli defects record"), "{refused}");
    }

    /// A repository is not a subject. Until the scope names the defect or
    /// the task the change belongs to, nothing says the change is part of
    /// anything, which is what the operator asked to block.
    #[test]
    fn a_scope_that_names_no_defect_and_no_task_authorises_nothing() {
        let home = home_with(
            "entryless",
            "01a0",
            json!({
                "turn_digest": "d1",
                "task": "dodaj blokade",
                "repositories": ["tama"],
            }),
        );
        let refused =
            refusal("tama", "01a0", "d1", &home).expect("a repository alone authorises nothing");
        assert!(refused.contains("names no defect and no task"), "{refused}");
        assert!(refused.contains("oko-cli defects record"), "{refused}");
    }

    /// A task in Oko's task register stands for the work just as a defect
    /// does; the refusal names whichever the session declared.
    #[test]
    fn a_task_stands_for_the_work_as_a_defect_does() {
        let home = home_with(
            "task",
            "01a0",
            json!({
                "turn_digest": "d1",
                "task": "dodaj blokade",
                "repositories": ["tama"],
                "task_id": "task-0d468fb998d4df51",
            }),
        );
        assert!(refusal("tama", "01a0", "d1", &home).is_none());
        let refused = refusal("oko", "01a0", "d1", &home).expect("oko is outside the work");
        assert!(refused.contains("task task-0d468fb998d4df51"), "{refused}");
    }

    /// The drift this gate exists for arrives between instructions: work
    /// declared for one prompt continuing under the next.
    #[test]
    fn a_scope_declared_for_an_earlier_instruction_authorises_nothing() {
        let home = home_with(
            "superseded",
            "01a0",
            json!({
                "turn_digest": "d1",
                "task": "add a hook in Tama that blocks one-off commands",
                "repositories": ["tama"],
                "defect": "df0d9346",
            }),
        );
        let refused = refusal("tama", "01a0", "d2", &home)
            .expect("the instruction changed, so the scope no longer speaks for it");
        assert!(
            refused.contains("has not said which defect or task"),
            "{refused}"
        );
    }

    #[test]
    fn a_session_that_declared_nothing_is_asked_what_it_is_working_on() {
        let home = scratch("undeclared");
        let refused = refusal("stado", "01a0", "d1", &home).expect("nothing is declared");
        assert!(
            refused.contains("has not said which defect or task"),
            "{refused}"
        );
        assert!(refused.contains("tama task scope set"), "{refused}");
    }

    #[test]
    fn only_paths_inside_the_workspace_name_a_repository() {
        let home = scratch("workspace");
        let inside = home.join(WORKSPACE_HOME_RELATIVE).join("weles/src/cli.ts");
        assert_eq!(
            repository_of(inside.to_str().expect("a path"), &home).as_deref(),
            Some("weles")
        );
        assert_eq!(
            repository_of("/usr/local/bin/stado", &home),
            None,
            "an installed program is another gate's subject"
        );
    }
}
