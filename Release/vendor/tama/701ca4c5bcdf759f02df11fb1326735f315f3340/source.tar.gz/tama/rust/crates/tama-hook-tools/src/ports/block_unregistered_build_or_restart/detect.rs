//! Which commands in one payload build something and which restart something.
//!
//! Read the way a shell reads them: cut at separators outside quotes, quoted
//! text blanked, wrappers stepped over, so a command line that merely mentions
//! `cargo build` is not one. The verbs and the programs are data in
//! `vocabulary.json` beside this file — what each program accepts, not a guess
//! at what anybody meant.

use std::sync::LazyLock;

use serde::Deserialize;

use crate::ports::python_stdlib::shell_tokens;
use crate::ports::shell_text;

const PATH_SEPARATOR: char = '/';
const FLAG_PREFIX: char = '-';
/// A verb ending in this matches every word that starts with what precedes it.
const VERB_PREFIX_MARK: char = '*';
/// What a build or restart is called when the command names no target of its
/// own: the repository it runs in.
const TARGET_FROM_REPOSITORY: &str = "repository";
/// The first word after the verbs, when that word is a positional. A flag
/// there means the command names no target of its own: `stado release submit
/// --source .` takes its product from the manifest, and reading `.` — the
/// value of `--source` — as the target is how the first draft of this gate
/// refused a build that had just been recorded.
const TARGET_FROM_NEXT_WORD: &str = "next";
/// The last positional, which is where an init system puts the unit:
/// `launchctl kickstart -k gui/501/com.wisent.always-on.brama`.
const TARGET_FROM_LAST_WORD: &str = "last";

/// A build spends a builder; a restart spends a running service.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Kind {
    Build,
    Restart,
}

impl Kind {
    pub fn label(self) -> &'static str {
        match self {
            Self::Build => "build",
            Self::Restart => "restart",
        }
    }

    pub fn verb(self) -> &'static str {
        match self {
            Self::Build => "build",
            Self::Restart => "restart",
        }
    }

    pub fn parse(value: &str) -> Option<Self> {
        match value {
            "build" => Some(Self::Build),
            "restart" => Some(Self::Restart),
            _ => None,
        }
    }
}

/// One command in a payload that would build or restart something.
pub struct Intent {
    pub kind: Kind,
    pub target: String,
    pub command: String,
}

#[derive(Deserialize)]
struct Shape {
    program: String,
    verbs: Vec<String>,
    target: String,
}

#[derive(Deserialize)]
struct Vocabulary {
    builds: Vec<Shape>,
    restarts: Vec<Shape>,
}

static VOCABULARY: LazyLock<Vocabulary> = LazyLock::new(|| {
    serde_json::from_str(include_str!("vocabulary.json"))
        .expect("build and restart vocabulary is valid JSON")
});

fn basename(token: &str) -> &str {
    token.rsplit(PATH_SEPARATOR).next().unwrap_or(token)
}

fn is_flag(word: &str) -> bool {
    word.starts_with(FLAG_PREFIX)
}

/// The repository this command runs in, as its directory name, or the working
/// directory's name when it is not in one.
fn repository_target() -> String {
    let current = std::env::current_dir().unwrap_or_default();
    for directory in current.ancestors() {
        if directory.join(".git").exists() {
            if let Some(name) = directory.file_name().and_then(|name| name.to_str()) {
                return name.to_string();
            }
        }
    }
    current
        .file_name()
        .and_then(|name| name.to_str())
        .unwrap_or("unnamed-directory")
        .to_string()
}

/// Whether one word is the verb a shape declares. A trailing `*` declares a
/// prefix, because the script that compiles a product is called `build` in
/// one repository, `build:rust` in the next and `build-release` in a third,
/// and a ration that only knew the bare word was spent by the other two
/// without ever refusing them.
fn is_verb(word: &str, verb: &str) -> bool {
    match verb.strip_suffix(VERB_PREFIX_MARK) {
        Some(prefix) => word.starts_with(prefix),
        None => word == verb,
    }
}

fn matches_verbs(args: &[String], verbs: &[String]) -> Option<usize> {
    let mut index = 0usize;
    for verb in verbs {
        loop {
            let word = args.get(index)?;
            index += 1;
            if is_flag(word) {
                continue;
            }
            if is_verb(word, verb) {
                break;
            }
            return None;
        }
    }
    Some(index)
}

/// The word right after the verbs, when it is a positional. A flag there
/// means the command carries no target of its own.
fn next_positional(args: &[String], from: usize) -> Option<String> {
    args.get(from)
        .filter(|word| !is_flag(word))
        .map(|word| word.to_string())
}

/// The last positional on the line, which is where an init system puts the
/// unit it acts on.
fn last_positional(args: &[String], from: usize) -> Option<String> {
    args.iter()
        .skip(from)
        .rfind(|word| !is_flag(word))
        .map(|word| word.to_string())
}

fn intent_of(
    shape: &Shape,
    kind: Kind,
    program: &str,
    args: &[String],
    command: &str,
) -> Option<Intent> {
    if basename(program) != shape.program {
        return None;
    }
    let after = matches_verbs(args, &shape.verbs)?;
    let target = match shape.target.as_str() {
        TARGET_FROM_NEXT_WORD => next_positional(args, after).unwrap_or_else(repository_target),
        TARGET_FROM_LAST_WORD => last_positional(args, after).unwrap_or_else(repository_target),
        TARGET_FROM_REPOSITORY => repository_target(),
        other => other.to_string(),
    };
    Some(Intent {
        kind,
        target,
        command: command.trim().to_string(),
    })
}

/// Every build or restart one payload's command line would perform.
pub fn intents(command: &str) -> Vec<Intent> {
    let acting = shell_text::effective_command(command);
    shell_text::commands(&acting)
        .into_iter()
        .filter_map(|one| {
            let tokens = shell_tokens(one);
            let program = shell_text::program(&tokens)?;
            let start = tokens.iter().position(|token| basename(token) == program)?;
            let args = &tokens[start + 1..];
            VOCABULARY
                .builds
                .iter()
                .find_map(|shape| intent_of(shape, Kind::Build, program, args, one))
                .or_else(|| {
                    VOCABULARY
                        .restarts
                        .iter()
                        .find_map(|shape| intent_of(shape, Kind::Restart, program, args, one))
                })
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::{intents, Kind};

    #[test]
    fn a_release_submit_is_a_build_of_the_product_it_names() {
        let found = intents("stado release submit --source . --version 0.3.11");
        assert_eq!(found.len(), 1);
        assert_eq!(found[0].kind, Kind::Build);
        // `submit` takes its product from the manifest, so the next word is a
        // flag and the target falls back to the repository this runs in.
        assert!(!found[0].target.is_empty());
    }

    #[test]
    fn a_service_restart_names_the_unit() {
        let found = intents("stado service restart brama-grant-sync --host lukasz-macbook");
        assert_eq!(found.len(), 1);
        assert_eq!(found[0].kind, Kind::Restart);
        assert_eq!(found[0].target, "brama-grant-sync");
    }

    #[test]
    fn launchctl_kickstart_is_a_restart_of_the_label() {
        let found = intents("launchctl kickstart -k gui/501/com.wisent.always-on.brama");
        assert_eq!(found.len(), 1);
        assert_eq!(found[0].kind, Kind::Restart);
        assert_eq!(found[0].target, "gui/501/com.wisent.always-on.brama");
    }

    /// A command that only mentions a build is not one, and a read is not a
    /// restart.
    #[test]
    fn mentions_and_reads_are_not_intents() {
        assert!(intents("grep 'cargo build' notes.md").is_empty());
        assert!(intents("stado service list --unowned").is_empty());
        assert!(intents("cargo test --test identities").is_empty());
        assert!(intents("cargo fmt --check").is_empty());
    }

    /// Two commands on one line are two intents.
    #[test]
    fn a_pipeline_of_two_intents_reports_both() {
        let found = intents("cargo build --release && stado service restart web");
        assert_eq!(found.len(), 2);
        assert_eq!(found[0].kind, Kind::Build);
        assert_eq!(found[1].kind, Kind::Restart);
        assert_eq!(found[1].target, "web");
    }
}
