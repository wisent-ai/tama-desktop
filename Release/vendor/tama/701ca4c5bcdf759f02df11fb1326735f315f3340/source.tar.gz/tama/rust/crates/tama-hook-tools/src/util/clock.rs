//! Time, the way JavaScript spells it: `Date.now()`, `toISOString()` and
//! `Date.parse` over ISO-8601 input, with the civil-date arithmetic both
//! need.
//!
//! Split out of `util/mod.rs`, which had grown past the three-hundred-line
//! limit.

/// Milliseconds since the unix epoch (JS `Date.now()`).
pub fn now_millis() -> f64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_millis() as f64)
        .unwrap_or(0.0)
}

fn civil_from_days(z: i64) -> (i64, u32, u32) {
    let z = z + 719468;
    let era = if z >= 0 { z } else { z - 146096 } / 146097;
    let doe = (z - era * 146097) as u64;
    let yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    let y = yoe as i64 + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = (doy - (153 * mp + 2) / 5 + 1) as u32;
    let m = if mp < 10 { mp + 3 } else { mp - 9 } as u32;
    (if m <= 2 { y + 1 } else { y }, m, d)
}

fn days_from_civil(y: i64, m: u32, d: u32) -> i64 {
    let y = if m <= 2 { y - 1 } else { y };
    let era = if y >= 0 { y } else { y - 399 } / 400;
    let yoe = (y - era * 400) as u64;
    let mp = if m > 2 { m - 3 } else { m + 9 } as u64;
    let doy = (153 * mp + 2) / 5 + d as u64 - 1;
    let doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    era * 146097 + doe as i64 - 719468
}

/// JS `new Date(ms).toISOString()` — `YYYY-MM-DDTHH:MM:SS.sssZ`.
pub fn iso_from_millis(ms: f64) -> String {
    let total = ms.trunc() as i64;
    let days = total.div_euclid(86_400_000);
    let day_ms = total.rem_euclid(86_400_000);
    let (year, month, day) = civil_from_days(days);
    let hour = day_ms / 3_600_000;
    let minute = (day_ms % 3_600_000) / 60_000;
    let second = (day_ms % 60_000) / 1000;
    let millis = day_ms % 1000;
    format!(
        "{:04}-{:02}-{:02}T{:02}:{:02}:{:02}.{:03}Z",
        year, month, day, hour, minute, second, millis
    )
}

/// JS `new Date().toISOString()`.
pub fn iso_now() -> String {
    iso_from_millis(now_millis())
}

/// JS `Date.parse` restricted to ISO-8601 input (`YYYY-MM-DD[THH:MM[:SS[.sss]]][Z|±hh:mm]`).
/// Returns NaN when the input does not parse, like `Date.parse`.
/// Note: JS parses timezone-less date-times as *local* time; this port treats
/// them as UTC (no timezone database in std).
pub fn parse_iso_millis(input: &str) -> f64 {
    let text = input.trim();
    let bytes = text.as_bytes();
    let mut pos = 0usize;
    let take = |pos: &mut usize, n: usize| -> Option<i64> {
        if *pos + n > bytes.len() {
            return None;
        }
        let slice = &text[*pos..*pos + n];
        if !slice.bytes().all(|b| b.is_ascii_digit()) {
            return None;
        }
        *pos += n;
        slice.parse::<i64>().ok()
    };
    let year = match take(&mut pos, 4) {
        Some(v) => v,
        None => return f64::NAN,
    };
    let sep = |pos: &mut usize, c: u8| -> bool {
        if pos.checked_add(0).is_some() && *pos < bytes.len() && bytes[*pos] == c {
            *pos += 1;
            true
        } else {
            false
        }
    };
    if !sep(&mut pos, b'-') {
        return f64::NAN;
    }
    let month = match take(&mut pos, 2) {
        Some(v) if (1..=12).contains(&v) => v as u32,
        _ => return f64::NAN,
    };
    if !sep(&mut pos, b'-') {
        return f64::NAN;
    }
    let day = match take(&mut pos, 2) {
        Some(v) if (1..=31).contains(&v) => v as u32,
        _ => return f64::NAN,
    };
    let mut millis = days_from_civil(year, month, day) * 86_400_000;
    if pos >= bytes.len() {
        return millis as f64;
    }
    if !(sep(&mut pos, b'T') || sep(&mut pos, b' ')) {
        return f64::NAN;
    }
    let hour = match take(&mut pos, 2) {
        Some(v) if v <= 24 => v,
        _ => return f64::NAN,
    };
    if !sep(&mut pos, b':') {
        return f64::NAN;
    }
    let minute = match take(&mut pos, 2) {
        Some(v) if v < 60 => v,
        _ => return f64::NAN,
    };
    let mut second = 0i64;
    let mut frac = 0i64;
    if sep(&mut pos, b':') {
        second = match take(&mut pos, 2) {
            Some(v) if v < 62 => v,
            _ => return f64::NAN,
        };
        if sep(&mut pos, b'.') {
            let start = pos;
            while pos < bytes.len() && bytes[pos].is_ascii_digit() {
                pos += 1;
            }
            let digits = &text[start..pos];
            if digits.is_empty() {
                return f64::NAN;
            }
            let mut scaled = digits[..digits.len().min(3)].to_string();
            while scaled.len() < 3 {
                scaled.push('0');
            }
            frac = scaled.parse::<i64>().unwrap_or(0);
        }
    }
    let mut offset = 0i64;
    if pos < bytes.len() {
        if sep(&mut pos, b'Z') {
            // UTC
        } else {
            let sign = if sep(&mut pos, b'+') {
                1
            } else if sep(&mut pos, b'-') {
                -1
            } else {
                return f64::NAN;
            };
            let oh = match take(&mut pos, 2) {
                Some(v) => v,
                None => return f64::NAN,
            };
            let _ = sep(&mut pos, b':');
            let om = match take(&mut pos, 2) {
                Some(v) => v,
                None => return f64::NAN,
            };
            offset = sign * (oh * 60 + om) * 60_000;
        }
    }
    if pos != bytes.len() {
        return f64::NAN;
    }
    millis += (hour * 3_600_000) + (minute * 60_000) + (second * 1000) + frac - offset;
    millis as f64
}
