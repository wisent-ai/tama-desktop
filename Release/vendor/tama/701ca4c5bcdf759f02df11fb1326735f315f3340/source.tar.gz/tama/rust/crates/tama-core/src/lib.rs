//! tama-core: registry types, catalog building/validation, install planning.
//! Rust port of `src/core/` from the tama Node.js codebase.

pub mod catalog;
pub mod frustration;
pub mod install;
pub mod policy_bundle;
pub mod registry;
pub mod runtime;

/// Shared result type for filesystem/JSON/git operations. JS throws on I/O and
/// JSON parse errors; the Rust port propagates them through this type instead.
pub type Result<T> = std::result::Result<T, Box<dyn std::error::Error>>;

pub(crate) fn err(msg: impl Into<String>) -> Box<dyn std::error::Error> {
    std::io::Error::new(std::io::ErrorKind::Other, msg.into()).into()
}
