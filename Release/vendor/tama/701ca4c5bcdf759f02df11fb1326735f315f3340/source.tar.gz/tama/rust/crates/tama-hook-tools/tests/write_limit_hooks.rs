//! The three hooks split out of `pre_write_edit.sh`, each driven as the real
//! script with a real payload on stdin: the file-line limit, the folder-file
//! limit, and the new-file justification requirement.
//!
//! They used to be one hook, so an operator could not keep the two limits
//! without the justification rule. These tests hold each one to its own exit
//! code and its own refusal sentence, so a later consolidation cannot pass
//! unnoticed.

use std::fs;
use std::io::Write as _;
use std::path::{Path, PathBuf};
use std::process::{Command, Output, Stdio};
use std::time::{SystemTime, UNIX_EPOCH};

use serde_json::json;

const EXIT_PASS: i32 = false as i32;
const EXIT_REFUSED: i32 = true as i32 + true as i32;

/// The hook scripts in the source tree this crate belongs to.
fn shared_hooks() -> PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("..")
        .join("..")
        .join("..")
        .join("shared-hooks")
}

fn scratch(label: &str) -> PathBuf {
    let nonce = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .expect("clock after epoch")
        .as_nanos();
    let thread = format!("{:?}", std::thread::current().id()).replace(['(', ')'], "-");
    let path = std::env::temp_dir().join(format!("tama-write-limits-{label}-{thread}{nonce}"));
    fs::create_dir_all(&path).expect("create scratch root");
    path
}

/// Runs one hook script with `payload` on stdin, in a home of its own.
fn run(script: &str, home: &Path, payload: &serde_json::Value) -> Output {
    let mut child = Command::new(shared_hooks().join(script))
        .env("HOME", home)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .unwrap_or_else(|error| panic!("spawn {script}: {error}"));
    child
        .stdin
        .as_mut()
        .expect("hook stdin")
        .write_all(payload.to_string().as_bytes())
        .expect("write payload");
    child.wait_with_output().expect("hook output")
}

fn stderr(output: &Output) -> String {
    String::from_utf8_lossy(&output.stderr).into_owned()
}

fn write_payload(path: &Path, content: &str) -> serde_json::Value {
    json!({
        "tool_name": "Write",
        "tool_input": { "file_path": path.display().to_string(), "content": content }
    })
}

/// The highest line count the limit still allows, taken from the hook's own
/// refusal sentence rather than written here: this repository keeps numbers
/// in `numeric-provenance.json`.
fn allowed_line_count() -> usize {
    let source = fs::read_to_string(shared_hooks().join("block_oversized_files.sh"))
        .expect("read the line-limit hook");
    let marker = "-gt ";
    let start = source.find(marker).expect("the hook compares a line count") + marker.len();
    let rest = &source[start..];
    let end = rest
        .find(|c: char| !c.is_ascii_digit())
        .unwrap_or(rest.len());
    rest[..end].parse().expect("the compared value is a number")
}

#[test]
fn oversized_files_are_refused_by_line_count() {
    let root = scratch("lines");
    let target = root.join("module.rs");
    let allowed = "// line\n".repeat(allowed_line_count());
    let refused = format!("{allowed}// one line too many\n");

    let pass = run(
        "block_oversized_files.sh",
        &root,
        &write_payload(&target, &allowed),
    );
    assert_eq!(pass.status.code(), Some(EXIT_PASS), "{}", stderr(&pass));

    let block = run(
        "block_oversized_files.sh",
        &root,
        &write_payload(&target, &refused),
    );
    assert_eq!(block.status.code(), Some(EXIT_REFUSED));
    assert!(
        stderr(&block).contains("lines (max 300). Split into smaller modules."),
        "{}",
        stderr(&block)
    );

    // An edit is judged on the file it would leave behind, not on its own size.
    fs::write(&target, &refused).expect("seed an oversized file");
    let edit = run(
        "block_oversized_files.sh",
        &root,
        &json!({
            "tool_name": "Edit",
            "tool_input": {
                "file_path": target.display().to_string(),
                "old_string": "// line\n",
                "new_string": "// line\n"
            }
        }),
    );
    assert_eq!(edit.status.code(), Some(EXIT_REFUSED));
    assert!(
        stderr(&edit).contains("lines after edit (max 300)"),
        "{}",
        stderr(&edit)
    );

    fs::remove_dir_all(root).expect("remove scratch root");
}

#[test]
fn crowded_folders_refuse_another_new_file() {
    let root = scratch("folders");
    let roomy = root.join("roomy");
    let crowded = root.join("crowded");
    fs::create_dir_all(&roomy).expect("create roomy folder");
    fs::create_dir_all(&crowded).expect("create crowded folder");
    for name in ["one", "two", "three", "four", "five"] {
        fs::write(crowded.join(format!("{name}.txt")), "seed\n").expect("seed crowded folder");
    }

    let pass = run(
        "block_crowded_folders.sh",
        &root,
        &write_payload(&roomy.join("fresh.txt"), "fresh\n"),
    );
    assert_eq!(pass.status.code(), Some(EXIT_PASS), "{}", stderr(&pass));

    let block = run(
        "block_crowded_folders.sh",
        &root,
        &write_payload(&crowded.join("sixth.txt"), "sixth\n"),
    );
    assert_eq!(block.status.code(), Some(EXIT_REFUSED));
    assert!(
        stderr(&block).contains("files (max 5). Move files into sub-folders or consolidate."),
        "{}",
        stderr(&block)
    );

    // The limit is about new files: rewriting one that is already there does
    // not crowd the folder further.
    let existing = crowded.join("one.txt");
    let rewrite = run(
        "block_crowded_folders.sh",
        &root,
        &write_payload(&existing, "again\n"),
    );
    assert_eq!(
        rewrite.status.code(),
        Some(EXIT_PASS),
        "{}",
        stderr(&rewrite)
    );

    fs::remove_dir_all(root).expect("remove scratch root");
}

#[test]
fn new_file_justification_reads_the_registry_it_names() {
    let root = scratch("justification");
    let home = root.join("home");
    fs::create_dir_all(home.join(".shared-hooks")).expect("create scratch home");
    let target = root.join("new-module.rs");
    let payload = write_payload(&target, "// fresh\n");
    let registry = home.join(".shared-hooks").join("file_justifications.json");

    let missing = run("require_new_file_justification.sh", &home, &payload);
    assert_eq!(missing.status.code(), Some(EXIT_REFUSED));
    assert!(
        stderr(&missing).contains("Need 50+ word justification"),
        "{}",
        stderr(&missing)
    );

    fs::write(&registry, json!({}).to_string()).expect("write empty registry");
    assert_eq!(
        run("require_new_file_justification.sh", &home, &payload)
            .status
            .code(),
        Some(EXIT_REFUSED)
    );

    let short = json!({ target.display().to_string(): { "justification": "too short" } });
    fs::write(&registry, short.to_string()).expect("write short justification");
    assert_eq!(
        run("require_new_file_justification.sh", &home, &payload)
            .status
            .code(),
        Some(EXIT_REFUSED)
    );

    let words = "word ".repeat(usize::from(u8::MAX));
    let full = json!({ target.display().to_string(): { "justification": words } });
    fs::write(&registry, full.to_string()).expect("write full justification");
    let pass = run("require_new_file_justification.sh", &home, &payload);
    assert_eq!(pass.status.code(), Some(EXIT_PASS), "{}", stderr(&pass));

    // An existing file is not a new file, so the rule does not apply.
    fs::write(&target, "// already here\n").expect("seed the target");
    fs::write(&registry, json!({}).to_string()).expect("empty the registry again");
    let existing = run("require_new_file_justification.sh", &home, &payload);
    assert_eq!(
        existing.status.code(),
        Some(EXIT_PASS),
        "{}",
        stderr(&existing)
    );

    fs::remove_dir_all(root).expect("remove scratch root");
}
