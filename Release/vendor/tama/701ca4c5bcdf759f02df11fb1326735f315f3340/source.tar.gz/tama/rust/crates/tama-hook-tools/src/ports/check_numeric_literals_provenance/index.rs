//! Which stored sessions to open when looking for a verbatim user quote.
//!
//! Oko's transcript index is a shortlist, never the answer: it says which
//! session files are worth reading, and the verbatim test is then done on the
//! file itself. Two sources of candidates, and both are always used.
//!
//! The full-text query alone is not enough, and this cost a real refusal on
//! 2026-09-15: a justification quoting the operator's own words, `swietnie. to
//! napraw to`, was rejected because the index answered the terms `swietnie`
//! and `napraw` with twenty-five older sessions that happen to contain those
//! ordinary Polish words, while the session the operator had just typed them
//! into was not among them — its full-text row did not yet carry the newest
//! messages. The recent-session list was consulted only when the query
//! returned nothing at all, so a popular word kept it from ever being
//! consulted. Both lists are now merged, query hits first, so a stale or
//! oversubscribed index can delay the answer but not deny it.
//!
//! The path the index records is not always the file the operator is typing
//! into either. On 2026-09-16 it named the lake's export of the current
//! session, rewritten on the lake's clock and forty minutes behind the live
//! file, so a quote the operator had just written was "not a verbatim quote
//! from a real role=user transcript message". Each candidate session's live
//! harness file is now read beside the recorded path.

use std::process::Command;

use regex::Regex;
use serde_json::Value;
use tama_hooks::session_record::transcript_path;

use crate::ports::python_stdlib;

/// `limit_sessions=25`, per source.
const SESSION_LIMIT_TEXT: &str = "25";
/// `re.findall(...)[:8]` — the full-text query takes at most eight terms.
const MAX_TOKENS_TEXT: &str = "8";
const TOKEN_PATTERN: &str = "[A-Za-z0-9]{3,}";
const PATH_COLUMN: &str = "path";
const SESSION_COLUMN: &str = "sessionId";
const DB_PARTS: &[&str] = &[
    "Library",
    "Application Support",
    "Oko",
    "transcript-index.sqlite",
];
const SQLITE: &str = "sqlite3";
const SQLITE_ARGS: &[&str] = &["-readonly", "-json"];

fn session_limit() -> String {
    SESSION_LIMIT_TEXT.to_string()
}

fn max_tokens() -> usize {
    MAX_TOKENS_TEXT.parse().unwrap_or_default()
}

fn database() -> std::path::PathBuf {
    let mut path = std::path::PathBuf::from(python_stdlib::expanduser("~"));
    for part in DB_PARTS {
        path.push(part);
    }
    path
}

/// The index is read through `sqlite3`: this workspace has no SQLite binding.
/// Each row is the recorded path plus the live harness file for that session,
/// when one exists.
fn query(db: &std::path::Path, sql: &str) -> Option<Vec<String>> {
    let output = Command::new(SQLITE)
        .args(SQLITE_ARGS)
        .arg(db.as_os_str())
        .arg(sql)
        .output()
        .ok()?;
    if !output.status.success() {
        return None;
    }
    let text = String::from_utf8_lossy(&output.stdout);
    let rows: Value = serde_json::from_str(text.trim()).ok()?;
    let mut paths = Vec::new();
    for row in rows.as_array()? {
        if let Some(path) = row.get(PATH_COLUMN).and_then(Value::as_str) {
            paths.push(path.to_string());
        }
        if let Some(live) = row
            .get(SESSION_COLUMN)
            .and_then(Value::as_str)
            .and_then(transcript_path)
        {
            paths.push(live.to_string_lossy().into_owned());
        }
    }
    Some(paths)
}

fn fts_sql(match_expr: &str) -> String {
    format!(
        "SELECT s.path, s.sessionId FROM sessions_fts f JOIN sessions s ON s.sessionId=f.sessionId \
WHERE sessions_fts MATCH '{match_expr}' LIMIT {}",
        session_limit()
    )
}

fn recent_sql() -> String {
    format!(
        "SELECT path, sessionId FROM sessions ORDER BY COALESCE(last_activity,mtime) DESC LIMIT {}",
        session_limit()
    )
}

fn terms(quote: &str) -> Vec<String> {
    Regex::new(TOKEN_PATTERN)
        .expect(TOKEN_PATTERN)
        .find_iter(quote)
        .take(max_tokens())
        .map(|hit| format!("\"{}\"", hit.as_str()))
        .collect()
}

/// Session transcript paths to search for this quote: full-text hits first,
/// then the most recently active sessions, each path once.
pub(crate) fn session_paths(quote: &str) -> Vec<String> {
    let db = database();
    if !db.is_file() {
        return Vec::new();
    }
    let matched = terms(quote);
    let mut paths: Vec<String> = match matched.is_empty() {
        true => Vec::new(),
        false => query(&db, &fts_sql(&matched.join(" "))).unwrap_or_default(),
    };
    for path in query(&db, &recent_sql()).unwrap_or_default() {
        if !paths.contains(&path) {
            paths.push(path);
        }
    }
    paths
}

#[cfg(test)]
mod tests {
    use super::{fts_sql, recent_sql, session_paths, terms};

    #[test]
    fn short_words_and_punctuation_are_not_search_terms() {
        assert_eq!(
            terms("swietnie. to napraw to"),
            vec!["\"swietnie\"", "\"napraw\""]
        );
    }

    #[test]
    fn at_most_eight_terms_reach_the_query() {
        let quote = "alfa beta gamma delta epsilon zeta eta theta iota kappa";
        assert_eq!(terms(quote).len(), 8);
    }

    #[test]
    fn both_queries_are_bounded_by_the_session_limit() {
        assert!(
            fts_sql("\"x\"").contains("LIMIT 25"),
            "{}",
            fts_sql("\"x\"")
        );
        assert!(recent_sql().contains("LIMIT 25"), "{}", recent_sql());
    }

    /// The recent list is consulted even when the full-text query answers, so
    /// an ordinary word cannot crowd out the session the quote was typed into.
    #[test]
    fn the_recent_sessions_are_always_among_the_candidates() {
        let popular = session_paths("napraw to");
        let unmatchable = session_paths("zzzqqqxxx");
        match unmatchable.is_empty() {
            true => assert!(popular.is_empty(), "no index on this machine"),
            false => assert!(
                unmatchable.iter().all(|path| popular.contains(path)),
                "recent sessions missing from a query that matched"
            ),
        }
    }
}
