//! The operator's turn order to stop acting, and whether it is still in force.
//!
//! On 2026-09-16 an agent told "nie koduj" answered forty turns with the same
//! three lines. Every Stop guard demanded a tool call to release the turn —
//! finish the tracker, read the ledger, treat a denial — and the operator had
//! forbidden every tool call. The harness fed each refusal back as a new turn,
//! its own reminder cap reset with it, and the loop had no exit that obeyed
//! the operator. His verdict: "caly czas sie powtarzasz. to jest
//! nieracjonalne. w innych sesjach tez sie krecisz w kolko."
//!
//! A stop order is the honest-no branch the completion guards lacked: while
//! it stands, ending the turn is what the operator asked for, so no guard that
//! can only be satisfied by acting may refuse it. It stands from the operator's
//! newest such message until the operator gives a new task — a message Oko
//! records in the ledger. Questions, remarks and further stop orders in
//! between do not lift it; the ledger, not the agent, decides what a task is.
//! Without a readable ledger only the newest operator message counts, so an
//! unreadable Oko cannot revive a lifted order.

use serde_json::Value;
use tama_hooks::session_record::Turn;

use super::rules::TaskLedger;

/// Orders that forbid acting, matched as whole words after folding case and
/// Polish diacritics. The list is the operator's own vocabulary; extend it in a
/// commit that quotes the message that needed the new form.
const STOP_PHRASES: &[&str] = &[
    "nie koduj",
    "nie programuj",
    "nic nie rob",
    "nie rob nic",
    "nie rob niczego",
    "nie ruszaj niczego",
    "przestan kodowac",
    "przestan pracowac",
    "do not code",
    "don't code",
    "dont code",
    "stop coding",
    "stop working",
    "do nothing",
    "do not do anything",
    "don't do anything",
    "dont do anything",
];

/// A bare word that is an order only when it is the whole message.
const WHOLE_MESSAGE_ORDERS: &[&str] = &["stop", "przestan", "zatrzymaj sie"];

fn fold(text: &str) -> String {
    let mut folded = String::with_capacity(text.len());
    for character in text.chars().flat_map(char::to_lowercase) {
        folded.push(match character {
            'ą' => 'a',
            'ć' => 'c',
            'ę' => 'e',
            'ł' => 'l',
            'ń' => 'n',
            'ó' => 'o',
            'ś' => 's',
            'ź' | 'ż' => 'z',
            other if other.is_whitespace() => ' ',
            other => other,
        });
    }
    folded
        .split(' ')
        .filter(|word| !word.is_empty())
        .collect::<Vec<_>>()
        .join(" ")
}

fn is_word_boundary(text: &str, index: usize) -> bool {
    text[..index]
        .chars()
        .next_back()
        .map_or(true, |character| !character.is_alphanumeric())
}

fn contains_phrase(text: &str, phrase: &str) -> bool {
    text.match_indices(phrase).any(|(start, _)| {
        is_word_boundary(text, start)
            && text[start + phrase.len()..]
                .chars()
                .next()
                .map_or(true, |character| !character.is_alphanumeric())
    })
}

/// Whether one operator message is an order to stop acting.
pub fn is_stop_order(text: &str) -> bool {
    let folded = fold(text);
    let whole = folded.trim_matches(|character: char| !character.is_alphanumeric());
    WHOLE_MESSAGE_ORDERS.contains(&whole)
        || STOP_PHRASES
            .iter()
            .any(|phrase| contains_phrase(&folded, phrase))
}

fn ledger_tasks(ledger: &TaskLedger) -> Vec<&str> {
    ledger.value["tasks"]
        .as_array()
        .map(|tasks| {
            tasks
                .iter()
                .filter_map(|task| task["text"].as_str())
                .map(str::trim)
                .collect()
        })
        .unwrap_or_default()
}

/// The stop order in force for this transcript, in the operator's words.
/// `None` ledger: the newest operator message alone decides.
pub fn in_force(turn: &Turn, ledger: Option<&TaskLedger>) -> Option<String> {
    let tasks = ledger.map(ledger_tasks).unwrap_or_default();
    for message in turn.operator_messages().iter().rev() {
        if is_stop_order(message) {
            return Some(message.clone());
        }
        if ledger.is_none() || tasks.contains(&message.trim()) {
            return None;
        }
    }
    None
}

/// The stop order in force for the session a Stop payload names, reading the
/// transcript the payload points at and the ledger Oko holds for it.
pub fn standing(payload: &Value, session: &str) -> Option<String> {
    let turn = Turn::for_payload(payload)?;
    in_force_for(session, &turn)
}

/// Whether any operator message in the transcript is a stop order; only then
/// is the ledger worth reading for this question.
pub fn wanted(turn: &Turn) -> bool {
    turn.operator_messages()
        .iter()
        .any(|message| is_stop_order(message))
}

/// The stop order in force for an already parsed transcript, reading the
/// ledger only when some operator message is a stop order at all. A guard
/// that reads the ledger for its own question passes it to `in_force`
/// instead; one Oko read per Stop is what the ten-second budget affords.
pub fn in_force_for(session: &str, turn: &Turn) -> Option<String> {
    if !wanted(turn) {
        return None;
    }
    let ledger = super::rules::task_ledger(session).ok();
    in_force(turn, ledger.as_ref())
}

/// What a guard prints on stderr when it stands down. Silence would hide the
/// reason the turn was let through.
pub fn notice(hook: &str, order: &str) -> String {
    format!(
        "{hook}: the operator's stop order stands ({:?}); ending the turn obeys it, so this guard does not refuse it.",
        order.trim()
    )
}
