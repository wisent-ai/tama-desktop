//! Reading the key order of one top-level object straight out of the
//! registry text.
//!
//! Moved verbatim out of the single catalogue file during a split by
//! responsibility.

/// Extract the insertion order of keys of the object stored at top-level
/// `key` in raw JSON text. `serde_json` without `preserve_order` sorts map
/// keys, but JS `JSON.parse` preserves insertion order and the catalog output
/// depends on it. Returns an empty vector when the key or its object value is
/// absent or the text is malformed.
pub(crate) fn top_level_object_key_order(text: &str, key: &str) -> Vec<String> {
    let mut scanner = Scanner::new(text);
    scanner.skip_ws();
    if scanner.peek() != Some(b'{') {
        return Vec::new();
    }
    scanner.advance(ONE);
    loop {
        scanner.skip_ws();
        match scanner.peek() {
            Some(b'}') | None => return Vec::new(),
            Some(b',') => {
                scanner.advance(ONE);
                continue;
            }
            _ => {}
        }
        let entry_key = match scanner.read_string() {
            Some(k) => k,
            None => return Vec::new(),
        };
        scanner.skip_ws();
        if scanner.peek() == Some(b':') {
            scanner.advance(ONE);
        }
        scanner.skip_ws();
        if entry_key == key && scanner.peek() == Some(b'{') {
            scanner.advance(ONE);
            let mut keys = Vec::new();
            loop {
                scanner.skip_ws();
                match scanner.peek() {
                    Some(b'}') | None => return keys,
                    Some(b',') => {
                        scanner.advance(ONE);
                        continue;
                    }
                    _ => {}
                }
                match scanner.read_string() {
                    Some(k) => keys.push(k),
                    None => return keys,
                }
                scanner.skip_ws();
                if scanner.peek() == Some(b':') {
                    scanner.advance(ONE);
                }
                scanner.skip_value();
            }
        }
        scanner.skip_value();
    }
}

/// One byte, the step this scanner takes over a delimiter it has just read.
const ONE: usize = true as usize;
/// The four hexadecimal digits of a `\u` escape.
const HEX_DIGITS: usize = "0000".len();

struct Scanner<'a> {
    bytes: &'a [u8],
    pos: usize,
}

impl<'a> Scanner<'a> {
    fn new(text: &'a str) -> Self {
        Self {
            bytes: text.as_bytes(),
            pos: 0,
        }
    }

    fn peek(&self) -> Option<u8> {
        self.bytes.get(self.pos).copied()
    }

    fn advance(&mut self, n: usize) {
        self.pos += n;
    }

    fn skip_ws(&mut self) {
        while matches!(self.peek(), Some(b' ' | b'\t' | b'\n' | b'\r')) {
            self.pos += ONE;
        }
    }

    fn skip_string(&mut self) {
        // assumes the cursor is on the opening quote
        self.pos += ONE;
        while let Some(byte) = self.peek() {
            match byte {
                b'\\' => self.pos += ONE + ONE,
                b'"' => {
                    self.pos += ONE;
                    return;
                }
                _ => self.pos += ONE,
            }
        }
    }

    /// Read a JSON string at the cursor, decoding standard escapes.
    fn read_string(&mut self) -> Option<String> {
        if self.peek() != Some(b'"') {
            return None;
        }
        self.pos += ONE;
        let mut out = String::new();
        while self.pos < self.bytes.len() {
            match self.bytes[self.pos] {
                b'"' => {
                    self.pos += ONE;
                    return Some(out);
                }
                b'\\' => {
                    self.pos += ONE;
                    let escaped = *self.bytes.get(self.pos)?;
                    self.pos += ONE;
                    match escaped {
                        b'"' => out.push('"'),
                        b'\\' => out.push('\\'),
                        b'/' => out.push('/'),
                        b'b' => out.push('\u{8}'),
                        b'f' => out.push('\u{c}'),
                        b'n' => out.push('\n'),
                        b'r' => out.push('\r'),
                        b't' => out.push('\t'),
                        b'u' => {
                            let hex = self.bytes.get(self.pos..self.pos + HEX_DIGITS)?;
                            let radix = u32::try_from(HEX_DIGITS * (ONE + ONE + ONE + ONE)).ok()?;
                            let code =
                                u32::from_str_radix(std::str::from_utf8(hex).ok()?, radix).ok()?;
                            self.pos += HEX_DIGITS;
                            out.push(char::from_u32(code).unwrap_or('\u{fffd}'));
                        }
                        other => out.push(other as char),
                    }
                }
                _ => {
                    // copy one UTF-8 encoded char verbatim
                    let start = self.pos;
                    self.pos += ONE;
                    while self.pos < self.bytes.len() && (self.bytes[self.pos] & 0xC0) == 0x80 {
                        self.pos += ONE;
                    }
                    out.push_str(std::str::from_utf8(&self.bytes[start..self.pos]).ok()?);
                }
            }
        }
        None
    }

    fn skip_value(&mut self) {
        self.skip_ws();
        match self.peek() {
            Some(b'"') => self.skip_string(),
            Some(b'{' | b'[') => {
                let mut depth = 0i32;
                while let Some(byte) = self.peek() {
                    match byte {
                        b'"' => self.skip_string(),
                        b'{' | b'[' => {
                            depth += 1;
                            self.pos += ONE;
                        }
                        b'}' | b']' => {
                            depth -= 1;
                            self.pos += ONE;
                            if depth == 0 {
                                return;
                            }
                        }
                        _ => self.pos += ONE,
                    }
                }
            }
            _ => {
                while let Some(byte) = self.peek() {
                    if matches!(byte, b',' | b'}' | b']' | b' ' | b'\t' | b'\n' | b'\r') {
                        return;
                    }
                    self.pos += ONE;
                }
            }
        }
    }
}
