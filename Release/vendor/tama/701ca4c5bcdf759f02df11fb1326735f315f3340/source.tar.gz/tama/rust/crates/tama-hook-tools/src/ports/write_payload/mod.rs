//! The three facts every write-limit gate needs about a PreToolUse payload.
//!
//! This is the Rust of `shared-hooks/write_payload_env.sh`, which the file
//! line limit, the folder file limit and the new-file justification all
//! sourced. Their shell versions each spawned `jq` three or four times per
//! call; here the payload is parsed once.
//!
//! Line counting keeps the shell's arithmetic exactly, because the limits are
//! stated in those numbers: `echo "$CONTENT" | wc -l` counts the newlines in
//! the content plus the one `echo` adds, while `wc -l < file` counts only the
//! newlines in the file. A gate that silently switched to "lines a person
//! would count" would move every boundary by one.

use serde_json::Value;

use crate::ports::transport_common as common;

const TOOL_KEY: &str = "tool_name";
const INPUT_KEY: &str = "tool_input";
const FILE_PATH_KEY: &str = "file_path";
const CONTENT_KEY: &str = "content";
const NEW_STRING_KEY: &str = "new_string";
const OLD_STRING_KEY: &str = "old_string";
const PATCH_KEY: &str = "patch";
/// `Write`/`Create` carry whole content; `Edit`/`apply_patch` carry a change.
const WHOLE_FILE_TOOLS: &[&str] = &["Write", "Create"];
const PARTIAL_TOOLS: &[&str] = &["Edit", "apply_patch"];
/// Paths whose content these gates never judge: vendored trees, generated
/// trees, and the machine's own tool directories.
const SYSTEM_PATTERN: &str = concat!(
    "(node_modules|\\.git/|\\.github/workflows/|/scripts/worker/deploy/|\\.next|__pycache__",
    "|/\\.claude/|/\\.factory/|/\\.codex/|/\\.shared-hooks/|/chromium-build/)",
);

/// What a write-limit gate reads from the payload.
pub struct WritePayload {
    pub tool: String,
    pub file_path: String,
    pub content: String,
    pub is_system: bool,
    input: Value,
}

fn text(value: &Value, key: &str) -> String {
    value
        .get(key)
        .and_then(Value::as_str)
        .unwrap_or_default()
        .to_string()
}

impl WritePayload {
    /// `None` when the payload names no file, which is the shell's clean exit.
    pub fn read(payload: &Value) -> Option<Self> {
        let tool = text(payload, TOOL_KEY);
        let input = payload
            .get(INPUT_KEY)
            .filter(|value| value.is_object())
            .cloned()
            .unwrap_or_else(|| Value::Object(Default::default()));
        let file_path = text(&input, FILE_PATH_KEY);
        if file_path.is_empty() {
            return None;
        }
        let content = match () {
            _ if WHOLE_FILE_TOOLS.contains(&tool.as_str()) => text(&input, CONTENT_KEY),
            _ if PARTIAL_TOOLS.contains(&tool.as_str()) => match text(&input, NEW_STRING_KEY) {
                empty if empty.is_empty() => text(&input, PATCH_KEY),
                found => found,
            },
            _ => String::new(),
        };
        let is_system = common::compile(SYSTEM_PATTERN).is_match(&file_path);
        Some(Self {
            tool,
            file_path,
            content,
            is_system,
            input,
        })
    }

    pub fn writes_whole_file(&self) -> bool {
        WHOLE_FILE_TOOLS.contains(&self.tool.as_str())
    }

    pub fn edits_in_place(&self) -> bool {
        PARTIAL_TOOLS.contains(&self.tool.as_str())
    }

    pub fn old_string(&self) -> String {
        text(&self.input, OLD_STRING_KEY)
    }

    pub fn new_string(&self) -> String {
        text(&self.input, NEW_STRING_KEY)
    }
}

/// `echo "$TEXT" | wc -l`: the newlines in the text, plus the one `echo` adds.
pub fn echoed_lines(text: &str) -> usize {
    text.matches('\n').count() + 1
}

/// `wc -l < path`: the newlines in the file, and nothing added.
pub fn file_lines(path: &str) -> usize {
    match std::fs::read(path) {
        Ok(bytes) => bytes.iter().filter(|byte| **byte == b'\n').count(),
        Err(_) => 0,
    }
}

#[cfg(test)]
mod tests {
    use super::{echoed_lines, file_lines, WritePayload};
    use serde_json::json;

    #[test]
    fn a_payload_naming_no_file_is_not_read() {
        assert!(WritePayload::read(&json!({ "tool_name": "Write" })).is_none());
    }

    #[test]
    fn a_write_carries_whole_content_and_an_edit_carries_the_change() {
        let write = WritePayload::read(&json!({
            "tool_name": "Write",
            "tool_input": { "file_path": "/repo/src/a.rs", "content": "one\ntwo" }
        }))
        .expect("a file is named");
        assert_eq!(write.content, "one\ntwo");
        assert!(write.writes_whole_file());

        let edit = WritePayload::read(&json!({
            "tool_name": "Edit",
            "tool_input": { "file_path": "/repo/src/a.rs", "new_string": "two", "old_string": "one" }
        }))
        .expect("a file is named");
        assert_eq!(edit.content, "two");
        assert_eq!(edit.old_string(), "one");
        assert!(edit.edits_in_place());
    }

    /// A vendored or generated path is exempt from the content limits.
    #[test]
    fn a_system_path_is_recognised() {
        let paths = [
            "/repo/node_modules/x/index.js",
            "/repo/.git/config",
            "/Users/someone/.shared-hooks/registry.json",
        ];
        for path in paths {
            let payload = WritePayload::read(&json!({
                "tool_name": "Write",
                "tool_input": { "file_path": path, "content": "x" }
            }))
            .expect("a file is named");
            assert!(payload.is_system, "{path}");
        }
        let ordinary = WritePayload::read(&json!({
            "tool_name": "Write",
            "tool_input": { "file_path": "/repo/src/main.rs", "content": "x" }
        }))
        .expect("a file is named");
        assert!(!ordinary.is_system);
    }

    /// The shell's two counts differ by one, and the limits are written in
    /// those numbers.
    #[test]
    fn the_shell_line_counts_are_preserved() {
        assert_eq!(echoed_lines(""), 1);
        assert_eq!(echoed_lines("one"), 1);
        assert_eq!(echoed_lines("one\ntwo"), 2);
        assert_eq!(echoed_lines("one\ntwo\n"), 3);
        assert_eq!(file_lines("/nonexistent/path"), 0);
    }
}
