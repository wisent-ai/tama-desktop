//! Shared scaffolding for the codex API-boundary guards ported from Python:
//! `codex-hooks/block_overleaf_api.py` (hook `block-overleaf-api`) and
//! `codex-hooks/block_direct_lsi_api.py` (hook `block-direct-lsi-api`).
//!
//! Both Python hooks read the same payload shape, tokenize a shell command
//! with `shlex.split`, resolve the script a runner is about to execute and
//! scan that source. The parts they share live here so each port carries only
//! its own patterns, allowlist and deny text. Python semantics come from
//! `super::python_stdlib` and `super::pyvalue`; nothing is re-implemented.

use std::path::{Path, PathBuf};

use serde_json::Value;

use super::python_stdlib::{expanduser, one, shell_tokens};
use super::pyvalue::truthy;

pub const SHELL_TOOLS: &[&str] = &["Bash", "exec_command", "functions.exec_command"];

pub const EDIT_TOOLS: &[&str] = &[
    "Write",
    "Edit",
    "apply_patch",
    "functions.apply_patch",
    "NotebookEdit",
];

pub const SCRIPT_SUFFIXES: &[&str] = &[".py", ".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx", ".sh"];

pub const SCRIPT_RUNNERS: &[&str] = &[
    "python", "python3", "node", "tsx", "bun", "deno", "ts-node", "npx", "bash", "sh", "zsh",
    "dash",
];

/// `a.get(k1) or a.get(k2) or ...` across the two mappings a payload offers,
/// keeping the value rather than its rendering: the callers need to tell a
/// truthy string from a truthy non-string. A lookup on a non-object yields
/// nothing, where Python would raise `AttributeError`; neither blocks.
pub fn first_truthy<'a>(sources: &[(&'a Value, &str)]) -> Option<&'a Value> {
    sources
        .iter()
        .filter_map(|(value, key)| value.get(key))
        .find(|found| truthy(found))
}

/// `Path(token).name`.
pub fn basename(token: &str) -> String {
    Path::new(token)
        .file_name()
        .map(|name| name.to_string_lossy().into_owned())
        .unwrap_or_default()
}

/// `Path(path).suffix`: the trailing extension with its dot, or empty.
pub fn suffix_of(path: &Path) -> String {
    match path.extension() {
        Some(extension) => format!(".{}", extension.to_string_lossy()),
        None => String::new(),
    }
}

/// A token names a runner when its basename is one, or merely *starts with*
/// one. That prefix rule is the Python's, and it is loose on purpose there —
/// `shellcheck` starts with `sh` — so the port keeps it.
fn is_runner(name: &str) -> bool {
    SCRIPT_RUNNERS.contains(&name) || SCRIPT_RUNNERS.iter().any(|runner| name.starts_with(runner))
}

/// `resolve_script_paths`: for every runner token, the first following token
/// that looks like a script, resolved against `cwd` and kept when it is a real
/// file. `window` is how many tokens the Python slice inspects; that count is
/// the only difference between the two hooks.
pub fn resolve_script_paths(command: &str, cwd: &Path, window: usize) -> Vec<PathBuf> {
    let parts = shell_tokens(command);
    let mut paths: Vec<PathBuf> = Vec::new();
    for (index, token) in parts.iter().enumerate() {
        if !is_runner(&basename(token)) {
            continue;
        }
        for candidate in parts.iter().skip(index + one()).take(window) {
            if candidate == "run" || candidate == "--" || candidate.starts_with('-') {
                continue;
            }
            let mut resolved = PathBuf::from(expanduser(candidate));
            if !SCRIPT_SUFFIXES.contains(&suffix_of(&resolved).as_str()) {
                continue;
            }
            if !resolved.is_absolute() && !cwd.as_os_str().is_empty() {
                resolved = cwd.join(resolved);
            }
            if resolved.is_file() {
                paths.push(resolved);
            }
            break;
        }
    }
    paths
}

/// `first_executable`: the basename of the command's first token.
pub fn first_executable(command: &str) -> String {
    shell_tokens(command)
        .first()
        .map(|token| basename(token))
        .unwrap_or_default()
}

/// The working directory a shell tool call would run in.
pub fn working_dir(data: &Value, tool_input: &Value) -> PathBuf {
    first_truthy(&[(tool_input, "workdir"), (tool_input, "cwd"), (data, "cwd")])
        .and_then(Value::as_str)
        .map(PathBuf::from)
        .unwrap_or_else(|| std::env::current_dir().unwrap_or_default())
}

pub fn is_allowlisted(path: &str, fragments: &[&str]) -> bool {
    fragments.iter().any(|fragment| path.contains(fragment))
}

/// `path.read_text(encoding="utf-8", errors="replace")`, `None` on `OSError`.
pub fn read_source(path: &Path) -> Option<String> {
    std::fs::read(path)
        .ok()
        .map(|bytes| String::from_utf8_lossy(&bytes).into_owned())
}

/// `', '.join(sorted(set(hits)))` — the shape both reports print.
pub fn matched_list(hits: &[String]) -> String {
    let mut reasons: Vec<&str> = hits.iter().map(String::as_str).collect();
    reasons.sort_unstable();
    reasons.dedup();
    reasons.join(", ")
}
