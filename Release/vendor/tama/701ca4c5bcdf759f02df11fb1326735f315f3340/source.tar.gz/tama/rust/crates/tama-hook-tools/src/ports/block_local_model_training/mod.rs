//! Refuse model training, and whole-set model runs, on the operator's own
//! workstation.
//!
//! On 2026-09-17 an agent started a LoRA training of a 1.7B checkpoint on
//! this Mac — first on the CPU for six and a half minutes, then again on the
//! GPU — because the checkpoint was in the local cache and the binary was
//! already built. It took the machine from every other job the operator had
//! open. His words: "wylacz ten trening natychmiast", then "zablokuj takie
//! debilizmy na przyszlosc. to jest krytyczny blad. rozpierdoliles cala inna
//! prace na tym komputerze".
//!
//! The rule was already written: heavy work goes through Stado onto a host
//! the fleet places it on, and the queue is how the operator sees what a
//! machine is doing. This gate is the half no configuration covers — the
//! command that trains, or reads a whole labelled set through a model, typed
//! as if the workstation were a training host.
//!
//! What it refuses, per command segment, one shell level down as well:
//!
//!   * `ster tune …`, `ster train`, `ster optimize`, `ster calibrate` and
//!     `ster decisions benchmark`: the Ster commands that train, or map a
//!     checkpoint and run a whole set through it.
//!   * The trainer launchers: `torchrun`, `accelerate launch`, `deepspeed`,
//!     `axolotl`, `llamafactory-cli train`, and `python -m mlx_lm.lora` or
//!     `-m torch.distributed.run`.
//!   * A Python script named like a trainer — `train.py`, `train_*.py`,
//!     `finetune.py`, `fine_tune.py`, `pretrain.py` — run by an interpreter.
//!
//! What passes: a command whose program is `stado`, because `stado submit`
//! is the route the rule names; `--help` and `-h`, which run nothing; and a
//! session in which the operator, outside the agent, exported
//! `LOCAL_MODEL_TRAINING_APPROVED=1` — the same shape the hook-edit gate
//! uses, so the key is never inside the agent's reach.

use std::path::Path;

use serde_json::Value;

use crate::ports::python_stdlib::shell_tokens;
use crate::ports::pyvalue::{first_truthy_py_str, py_str, truthy};
use crate::ports::shell_text;
use crate::ports::tool_vocabulary::{
    BASH_TOOLS, COMMAND_KEYS, EVAL_TOOLS, HUB_TOOLS, TOOL_INPUT_KEY,
};

const TOOL_KEYS: &[&str] = &["tool_name", "name"];
const CODE_KEY: &str = "code";
const OPERATION_KEYS: &[&str] = &["op", "action"];
const APPLICATION_KEY: &str = "application";
const ARGS_KEY: &str = "args";
const START_OPERATION: &str = "start";

/// Set by the operator outside the agent session; never by an agent.
pub const APPROVAL_VARIABLE: &str = "LOCAL_MODEL_TRAINING_APPROVED";
const APPROVED: &str = "1";

/// The fleet's own placement command; anything it wraps runs elsewhere.
const FLEET_PROGRAM: &str = "stado";
const HELP_FLAGS: &[&str] = &["--help", "-h"];

const STER: &str = "ster";
const STER_TUNE: &str = "tune";
/// `ster` subcommands that train or run a whole set through a checkpoint.
const STER_HEAVY: &[&str] = &[STER_TUNE, "train", "optimize", "calibrate"];
const STER_DECISIONS: &str = "decisions";
const STER_BENCHMARK: &str = "benchmark";

/// Programs whose whole purpose is launching a training run.
const TRAINER_PROGRAMS: &[&str] = &["torchrun", "deepspeed", "axolotl"];
const ACCELERATE: &str = "accelerate";
const ACCELERATE_LAUNCH: &str = "launch";
const LLAMAFACTORY: &str = "llamafactory-cli";
const LLAMAFACTORY_TRAIN: &str = "train";
const INTERPRETERS: &[&str] = &["python", "python3", "uv"];
const MODULE_FLAG: &str = "-m";
const TRAINER_MODULES: &[&str] = &[
    "mlx_lm.lora",
    "mlx_lm.fuse",
    "torch.distributed.run",
    "torch.distributed.launch",
    "axolotl.cli.train",
];
const TRAINER_SCRIPT_PREFIXES: &[&str] = &["train", "finetune", "fine_tune", "pretrain"];
const PYTHON_SUFFIX: &str = ".py";

fn refusal(detected: &str) -> String {
    format!(
        "BLOCKED: model training and whole-set model runs are forbidden on this workstation. On \
         2026-09-17 a local LoRA training took the machine from every other job the operator had \
         open. Submit it to the fleet instead — `stado submit` places it on a training host and \
         the queue shows it. Only the operator, outside the agent session, may allow a local run \
         by exporting {APPROVAL_VARIABLE}={APPROVED}. Detected: {detected}"
    )
}

fn program_is(token: &str, program: &str) -> bool {
    Path::new(token).file_name().and_then(|name| name.to_str()) == Some(program)
}

/// `train.py`, `train_dagger.py`, `finetune.py`, wherever it sits.
fn is_trainer_script(token: &str) -> bool {
    let Some(name) = Path::new(token).file_name().and_then(|name| name.to_str()) else {
        return false;
    };
    let Some(stem) = name.strip_suffix(PYTHON_SUFFIX) else {
        return false;
    };
    TRAINER_SCRIPT_PREFIXES.iter().any(|prefix| {
        stem == *prefix
            || stem
                .strip_prefix(prefix)
                .is_some_and(|rest| rest.starts_with(['_', '-']))
    })
}

/// What one command segment is doing, when it is a thing this gate refuses.
fn segment_detection(segment: &str) -> Option<String> {
    let tokens = shell_tokens(segment);
    let Some(program) = tokens.first() else {
        return None;
    };
    if program_is(program, FLEET_PROGRAM) {
        return None;
    }
    if tokens
        .iter()
        .any(|token| HELP_FLAGS.contains(&token.as_str()))
    {
        return None;
    }
    let rest: Vec<&str> = tokens.iter().skip(1).map(String::as_str).collect();
    if program_is(program, STER) {
        match rest.as_slice() {
            [sub, objective, ..] if *sub == STER_TUNE && !objective.starts_with('-') => {
                return Some(format!("`ster {sub} {objective}` on this machine"));
            }
            [sub, ..] if STER_HEAVY.contains(sub) => {
                return Some(format!("`ster {sub}` on this machine"))
            }
            [sub, next, ..] if *sub == STER_DECISIONS && *next == STER_BENCHMARK => {
                return Some(format!("`ster {sub} {next}` on this machine"));
            }
            _ => return None,
        }
    }
    if TRAINER_PROGRAMS
        .iter()
        .any(|trainer| program_is(program, trainer))
    {
        return Some(format!("`{program}` on this machine"));
    }
    if program_is(program, ACCELERATE) && rest.first() == Some(&ACCELERATE_LAUNCH) {
        return Some(format!(
            "`{ACCELERATE} {ACCELERATE_LAUNCH}` on this machine"
        ));
    }
    if program_is(program, LLAMAFACTORY) && rest.first() == Some(&LLAMAFACTORY_TRAIN) {
        return Some(format!(
            "`{LLAMAFACTORY} {LLAMAFACTORY_TRAIN}` on this machine"
        ));
    }
    if INTERPRETERS
        .iter()
        .any(|interpreter| program_is(program, interpreter))
    {
        if let Some(position) = rest.iter().position(|token| *token == MODULE_FLAG) {
            if let Some(module) = rest.get(position + 1) {
                if TRAINER_MODULES.contains(module) {
                    return Some(format!("`{program} -m {module}` on this machine"));
                }
            }
        }
        if let Some(script) = rest.iter().find(|token| is_trainer_script(token)) {
            return Some(format!("`{script}` run by `{program}` on this machine"));
        }
    }
    None
}

/// The refusal a command earns, looking one shell level down.
fn command_detection(command: &str) -> Option<String> {
    let effective = shell_text::effective_command(command);
    shell_text::commands(&effective)
        .into_iter()
        .find_map(segment_detection)
}

/// `[.application, (.args // [])[]]` joined by spaces.
fn process_text(input: &Value) -> String {
    let mut parts: Vec<String> = Vec::new();
    if let Some(Value::String(application)) = input.get(APPLICATION_KEY) {
        parts.push(application.clone());
    }
    if let Some(Value::Array(args)) = input.get(ARGS_KEY) {
        parts.extend(args.iter().filter_map(Value::as_str).map(str::to_owned));
    }
    parts.join(" ")
}

/// The executable text this call carries, by tool.
fn executable_text(payload: &Value) -> String {
    let tool = first_truthy_py_str(payload, TOOL_KEYS).to_lowercase();
    let Some(input) = payload.get(TOOL_INPUT_KEY).filter(|value| truthy(value)) else {
        return String::new();
    };
    if !input.is_object() {
        return match BASH_TOOLS.contains(&tool.as_str()) {
            true => py_str(input),
            false => String::new(),
        };
    }
    match tool.as_str() {
        found if BASH_TOOLS.contains(&found) => first_truthy_py_str(input, COMMAND_KEYS),
        found if EVAL_TOOLS.contains(&found) => first_truthy_py_str(input, &[CODE_KEY]),
        found if HUB_TOOLS.contains(&found) => {
            match first_truthy_py_str(input, OPERATION_KEYS).to_lowercase() == START_OPERATION {
                true => process_text(input),
                false => String::new(),
            }
        }
        _ => String::new(),
    }
}

/// The refusal this call earns, or `None` when it passes.
pub fn evaluate(payload: &Value, approval: Option<&str>) -> Option<String> {
    if approval.map(str::trim) == Some(APPROVED) {
        return None;
    }
    let text = executable_text(payload);
    if text.trim().is_empty() {
        return None;
    }
    command_detection(&text).map(|detected| refusal(&detected))
}
