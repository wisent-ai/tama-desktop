//! Record types: one tool invocation, one tool result, one hook denial, and
//! the key lists used to read them out of payloads and arguments.

use serde_json::Value;

use super::transcript::path_tokens;

/// Registry hook ids are kebab-case and short; this bound rejects a prose
/// sentence that merely happens to contain a colon.
const MAX_HOOK_ID_TEXT: &str = "64";

pub(super) const SESSION_ID_KEYS: &[&str] = &[
    "session_id",
    "sessionId",
    "conversation_id",
    "conversationId",
];
const PATH_KEYS: &[&str] = &["path", "file", "file_path", "filename", "target"];

pub(super) fn max_hook_id_len() -> usize {
    MAX_HOOK_ID_TEXT.parse().unwrap_or_default()
}

/// One recorded tool invocation.
#[derive(Clone)]
pub struct ToolCall {
    pub id: String,
    pub name: String,
    pub arguments: Value,
}

impl ToolCall {
    /// The first path-like argument, preserving URI schemes and removing only file selectors.
    pub fn target(&self) -> Option<String> {
        for key in PATH_KEYS {
            if let Some(text) = self.arguments.get(key).and_then(Value::as_str) {
                if !text.is_empty() {
                    return Some(if text.contains("://") {
                        text.to_string()
                    } else {
                        text.split(':').next().unwrap_or(text).to_string()
                    });
                }
            }
        }
        path_tokens(&self.arguments).into_iter().next()
    }

    /// Every path-looking token anywhere in the arguments.
    pub fn paths(&self) -> Vec<String> {
        path_tokens(&self.arguments)
    }
}

/// One recorded tool result.
#[derive(Clone)]
pub struct ToolResult {
    pub position: usize,
    pub call_id: String,
    pub tool_name: String,
    pub details: Value,
    pub is_error: bool,
    pub text: String,
}

/// One errored tool result carrying a hook's deny text.
pub struct Denial {
    pub position: usize,
    pub call_id: String,
    pub tool_name: String,
    pub text: String,
}
