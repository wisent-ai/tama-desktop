//! Turning one frustrated message into one rule, with a model's help.
//!
//! Two questions, both through Brama, because that is where this workshop's
//! model calls go: is this message frustration with the assistant's
//! behaviour, and if so what rule would have prevented it. The shell asked
//! the `claude` command-line tool, which meant the drafter depended on a
//! provider login rather than on the product's own gateway.
//!
//! The draft has to name a target the gates can actually read — a command, a
//! path, or file content — and a pattern that compiles. A draft that names a
//! script file, as the Python version's prompt did, is refused: rules are
//! rows now, not edits to a script.

use serde_json::Value;

use super::record;

/// `FRUSTRATION_CONF_MIN` default in the shell.
const CONFIDENCE_ENV: &str = "FRUSTRATION_CONF_MIN";
const CONFIDENCE_DEFAULT: &str = "0.6";
const CLASSIFY_TOKENS_TEXT: &str = "8";
const DRAFT_TOKENS_TEXT: &str = "400";
const CLASSIFY_DEADLINE_TEXT: &str = "25";
const DRAFT_DEADLINE_TEXT: &str = "45";
const YES: &str = "YES";
const FENCE: &str = "```";

const CLASSIFY_SYSTEM: &str = concat!(
    "Decide whether the user message below is expressing frustration with or correction of the ",
    "assistant's recent behavior. Examples of YES: telling the assistant to stop doing ",
    "something, complaining about a previous response, profanity directed at the assistant, 'I ",
    "told you', 'why did you', \"that's not what I asked\". Examples of NO: a normal task ",
    "request, a calm question, satisfaction, cursing at unrelated infrastructure, casual ",
    "filler. Reply with exactly one of these and nothing else: YES or NO",
);

const DRAFT_SYSTEM: &str = concat!(
    "You translate user frustration into one hook rule for the Tama policy runtime. A rule is a ",
    "row in a registry, never an edit to a script. Pick the most specific target:\n",
    "  command  - a regular expression read against a shell command\n",
    "  path     - a regular expression read against the path a write targets\n",
    "  content  - a regular expression read against the content a write would leave\n",
    "Respond ONLY with a JSON object on a single line, no prose, no markdown fence:\n",
    "  {\"summary\":str, \"target\":\"command\"|\"path\"|\"content\", \"pattern\":str, ",
    "\"message\":str, \"confidence\":float}\n",
    "The pattern must be a POSIX-style regular expression the Rust regex crate accepts: no ",
    "lookahead, no lookbehind, no backreferences. The message is the one-line refusal the agent ",
    "will read, and it starts with BLOCKED:. Set confidence below 0.5 if the frustration is not ",
    "about the assistant's behaviour.",
);

fn confidence_floor() -> f64 {
    match std::env::var(CONFIDENCE_ENV) {
        Ok(value) if !value.is_empty() => value.parse().unwrap_or_default(),
        _ => CONFIDENCE_DEFAULT.parse().unwrap_or_default(),
    }
}

fn tokens(text: &str) -> u32 {
    text.parse().unwrap_or_default()
}

/// What a usable draft carries.
#[derive(Debug)]
pub(crate) struct Draft {
    pub(crate) summary: String,
    pub(crate) target: String,
    pub(crate) pattern: String,
    pub(crate) message: String,
    pub(crate) confidence: f64,
}

/// `sed -E '/^```/d'`: a model that fences its JSON anyway.
fn unfenced(text: &str) -> String {
    text.lines()
        .filter(|line| !line.trim_start().starts_with(FENCE))
        .collect::<Vec<_>>()
        .join("\n")
}

/// The draft a model answered with, if it answered with one.
pub(crate) fn parse(answer: &str) -> Result<Draft, String> {
    let body = unfenced(answer);
    let doc: Value = serde_json::from_str(body.trim())
        .map_err(|error| format!("the draft is not JSON: {error}"))?;
    let text = |key: &str| {
        doc.get(key)
            .and_then(Value::as_str)
            .unwrap_or_default()
            .to_string()
    };
    let confidence = doc
        .get("confidence")
        .and_then(Value::as_f64)
        .unwrap_or_default();
    let draft = Draft {
        summary: text("summary"),
        target: text("target"),
        pattern: text("pattern"),
        message: text("message"),
        confidence,
    };
    if !record::TARGETS.contains(&draft.target.as_str()) {
        return Err(format!(
            "the draft names {} , which is not a subject a gate can read",
            draft.target
        ));
    }
    if !record::pattern_compiles(&draft.pattern) {
        return Err(format!(
            "the drafted pattern does not compile: {}",
            draft.pattern
        ));
    }
    Ok(draft)
}

/// Whether this draft is confident enough to become a rule.
pub(crate) fn confident(draft: &Draft) -> bool {
    draft.confidence >= confidence_floor()
}

/// Ask whether the message is frustration with the assistant.
pub(crate) fn classify(prompt: &str) -> Result<bool, String> {
    let route = crate::brama::credentials::model_route()?;
    let answer = crate::brama::chat(
        &route,
        CLASSIFY_SYSTEM,
        prompt,
        tokens(CLASSIFY_TOKENS_TEXT),
        tokens(CLASSIFY_DEADLINE_TEXT),
    )?;
    Ok(answer.trim().eq_ignore_ascii_case(YES))
}

/// Ask for the rule that would have prevented it.
pub(crate) fn draft(prompt: &str, prior_turn: &str) -> Result<Draft, String> {
    let route = crate::brama::credentials::model_route()?;
    let user = format!("USER (frustrated): {prompt}\n\nPRIOR ASSISTANT TURN: {prior_turn}");
    let answer = crate::brama::chat(
        &route,
        DRAFT_SYSTEM,
        &user,
        tokens(DRAFT_TOKENS_TEXT),
        tokens(DRAFT_DEADLINE_TEXT),
    )?;
    parse(&answer)
}

#[cfg(test)]
mod tests {
    use super::{confident, parse};

    const GOOD: &str = concat!(
        "{\"summary\":\"The operator objected to ad-hoc node programs\",",
        "\"target\":\"command\",\"pattern\":\"\\\\bnode[[:space:]]+-e\\\\b\",",
        "\"message\":\"BLOCKED: no throwaway node programs.\",\"confidence\":0.82}",
    );

    #[test]
    fn a_usable_draft_is_read_whole() {
        let draft = parse(GOOD).expect("a usable draft");
        assert_eq!(draft.target, "command");
        assert!(draft.message.starts_with("BLOCKED:"));
        assert!(confident(&draft));
    }

    /// A fenced answer is still an answer.
    #[test]
    fn a_fenced_draft_is_read() {
        let fenced = format!("```json\n{GOOD}\n```");
        assert!(parse(&fenced).is_ok());
    }

    /// The old prompt asked for a script file as the target; a rule is a row
    /// now, so that answer is refused rather than half-applied.
    #[test]
    fn a_draft_naming_a_script_is_refused() {
        let answer = GOOD.replace("\"command\"", "\"pre_bash.sh\"");
        let error = parse(&answer).expect_err("not a subject a gate reads");
        assert!(error.contains("not a subject"), "{error}");
    }

    #[test]
    fn a_draft_whose_pattern_cannot_compile_is_refused() {
        let answer = GOOD.replace("\\\\bnode[[:space:]]+-e\\\\b", "([unclosed");
        assert!(parse(&answer).is_err());
    }

    /// Below the floor the draft is logged and dropped, which is what keeps a
    /// guess from becoming a gate.
    #[test]
    fn a_low_confidence_draft_is_not_confident() {
        let answer = GOOD.replace("0.82", "0.2");
        let draft = parse(&answer).expect("a readable draft");
        assert!(!confident(&draft));
    }

    #[test]
    fn prose_instead_of_json_is_refused() {
        assert!(parse("I think you should stop doing that.").is_err());
    }
}
