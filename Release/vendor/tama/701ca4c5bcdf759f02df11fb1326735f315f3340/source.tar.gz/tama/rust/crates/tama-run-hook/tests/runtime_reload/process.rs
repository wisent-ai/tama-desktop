use std::fs::{self, File};
use std::io::{BufRead, BufReader, Read, Write};
use std::path::{Path, PathBuf};
use std::process::{Child, ChildStdin, Command, Stdio};
use std::sync::mpsc::{self, Receiver};
use std::thread::JoinHandle;
use std::time::Duration;

use serde_json::{json, Value};
use tama_hooks::sha256::sha256_hex;

pub fn record_run(root: &Path, commands: Value) {
    let reports = root.join("reports");
    fs::create_dir_all(&reports).unwrap();
    let binary = env!("CARGO_BIN_EXE_tama-run-hook");
    let revision = Command::new("git")
        .args(["rev-parse", "HEAD"])
        .current_dir(env!("CARGO_MANIFEST_DIR"))
        .output()
        .unwrap();
    assert!(revision.status.success());
    fs::write(
        reports.join("run.json"),
        serde_json::to_vec_pretty(&json!({
            "sourceRevision": String::from_utf8(revision.stdout).unwrap().trim(),
            "binary": binary,
            "binarySha256": sha256_hex(&fs::read(binary).unwrap()),
            "arguments": commands,
            "registry": root.join("registry.json"),
        }))
        .unwrap(),
    )
    .unwrap();
}

pub struct RuntimeProcess {
    child: Child,
    input: Option<ChildStdin>,
    frames: Receiver<String>,
    readers: Vec<JoinHandle<()>>,
    input_log: File,
    reports: PathBuf,
    finished: bool,
}

impl RuntimeProcess {
    pub fn start(root: &Path, agent: &str) -> (Self, Value) {
        let reports = root.join("reports");
        let binary = env!("CARGO_BIN_EXE_tama-run-hook");
        record_run(root, json!([["--serve", agent]]));
        let mut child = Command::new(binary)
            .args(["--serve", agent])
            .current_dir(root)
            .env("HOME", root)
            .env("AGENT_HOOK_REGISTRY", root.join("registry.json"))
            .env("TAMA_HOOK_ENFORCEMENT", root.join("enforcement.json"))
            .env("TAMA_EMERGENCY_STATE", root.join("emergency.json"))
            .env("TAMA_SESSION_CONTROL_ROOT", root.join("sessions"))
            .env_remove("TAMA_PROVIDER")
            .env_remove("TAMA_ONLY_HOOK_ID")
            .env_remove("TAMA_ENABLED_HOOKS")
            .env_remove("TAMA_DISABLED_HOOKS")
            .env_remove("AGENT_STRUCTURED_CAPABILITY")
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .spawn()
            .unwrap();
        let input = child.stdin.take();
        let stdout = child.stdout.take().unwrap();
        let mut stderr = child.stderr.take().unwrap();
        let (send, frames) = mpsc::channel();
        let mut output_log = File::create(reports.join("stdout.jsonl")).unwrap();
        let stdout_reader = std::thread::spawn(move || {
            for line in BufReader::new(stdout).lines() {
                let line = line.unwrap();
                writeln!(output_log, "{line}").unwrap();
                output_log.flush().unwrap();
                if send.send(line).is_err() {
                    break;
                }
            }
        });
        let errors = reports.join("stderr.log");
        let stderr_reader = std::thread::spawn(move || {
            let mut bytes = Vec::new();
            stderr.read_to_end(&mut bytes).unwrap();
            fs::write(errors, bytes).unwrap();
        });
        let mut process = Self {
            child,
            input,
            frames,
            readers: vec![stdout_reader, stderr_reader],
            input_log: File::create(reports.join("stdin.jsonl")).unwrap(),
            reports,
            finished: false,
        };
        let ready = process.receive();
        assert_eq!(ready["type"], "ready");
        assert_eq!(ready["state"]["processId"], process.child.id());
        (process, ready)
    }

    fn receive(&mut self) -> Value {
        let line = self
            .frames
            .recv_timeout(Duration::from_secs(30))
            .expect("the real runtime must answer; see retained stdout/stderr");
        serde_json::from_str(&line).expect("native JSON response")
    }

    pub fn request(&mut self, request: Value) -> Value {
        let wire = serde_json::to_string(&request).unwrap();
        writeln!(self.input_log, "{wire}").unwrap();
        self.input_log.flush().unwrap();
        writeln!(self.input.as_mut().unwrap(), "{wire}").unwrap();
        self.input.as_mut().unwrap().flush().unwrap();
        let response = self.receive();
        assert_eq!(response["id"], request["id"]);
        response
    }

    pub fn finish(&mut self) {
        drop(self.input.take());
        let status = self.child.wait().unwrap();
        for reader in self.readers.drain(..) {
            reader.join().unwrap();
        }
        fs::write(
            self.reports.join("exit.json"),
            json!({ "exitCode": status.code() }).to_string(),
        )
        .unwrap();
        self.finished = true;
        assert!(status.success(), "native runtime exit: {status}");
        println!("retained runtime evidence: {}", self.reports.display());
    }
}

impl Drop for RuntimeProcess {
    fn drop(&mut self) {
        if !self.finished {
            let _ = self.child.kill();
            let status = self.child.wait();
            for reader in self.readers.drain(..) {
                let _ = reader.join();
            }
            let _ = fs::write(self.reports.join("exit.json"), format!("{status:?}"));
        }
    }
}

#[test]
fn shared_engine_preserves_harness_state_and_rejects_stale_capabilities() {
    let root = super::root("session");
    fs::write(root.join("data/input"), "authorized hook ran").unwrap();
    let mut document = super::registry(&root, "release-a", "/bin/cp", "input");
    document["events"]["pre_tool_use:read"]["hooks"]
        .as_array_mut()
        .unwrap()
        .insert(
            0,
            json!({
                "id": "requires-capability",
                "command": "/usr/bin/printenv AGENT_STRUCTURED_CAPABILITY",
            }),
        );
    document.as_object_mut().unwrap().remove("catalogChecksum");
    document["catalogChecksum"] = json!(sha256_hex(&serde_json::to_vec(&document).unwrap()));
    super::publish(&root, &document);
    let key = sha256_hex(b"omp\0isolated-reload-session");
    let sessions = root.join("sessions");
    fs::create_dir_all(&sessions).unwrap();
    let record = sessions.join(format!("{key}.session.json"));
    let owner_state = json!({
        "pid": std::process::id(), "runtime": { "owner": "real-test-harness" },
    })
    .to_string();
    fs::write(&record, &owner_state).unwrap();
    let (mut process, ready) = RuntimeProcess::start(&root, "omp");
    let mut override_value = json!({
        "schema": tama_hooks::session_control::SESSION_CONTROL_SCHEMA,
        "agentId": "omp", "sessionId": "isolated-reload-session", "controlKey": key,
        "capability": {
            "schemaVersion": tama_hooks::session_capability::CAPABILITY_SCHEMA_VERSION,
            "issuedBy": "isolated-test", "nonce": "session-regression",
            "sessionId": "isolated-reload-session", "controlKey": key,
            "releaseId": document["releaseId"], "catalogChecksum": document["catalogChecksum"],
            "lifetime": "current-session", "grants": [{ "tool": "read" }],
        },
    });
    let override_path = sessions.join(format!("{key}.override.json"));
    fs::write(&override_path, override_value.to_string()).unwrap();
    assert_eq!(
        super::dispatch(&mut process, "authorized")["result"]["decision"],
        "pass"
    );
    assert_eq!(
        fs::read_to_string(root.join("data/observation")).unwrap(),
        "authorized hook ran"
    );
    assert_eq!(fs::read_to_string(&record).unwrap(), owner_state);

    document["releaseId"] = json!("release-b");
    document.as_object_mut().unwrap().remove("catalogChecksum");
    document["catalogChecksum"] = json!(sha256_hex(&serde_json::to_vec(&document).unwrap()));
    super::publish(&root, &document);
    fs::remove_file(root.join("data/observation")).unwrap();
    let stale = super::dispatch(&mut process, "stale");
    assert_eq!(stale["result"]["blockedHookId"], "requires-capability");
    assert!(!root.join("data/observation").exists());
    assert_eq!(stale["state"]["processId"], ready["state"]["processId"]);

    // The consumer rebinds from the actual core response, not a second disk read.
    override_value["capability"]["releaseId"] = stale["catalog"]["releaseId"].clone();
    override_value["capability"]["catalogChecksum"] = stale["catalog"]["catalogChecksum"].clone();
    fs::write(&override_path, override_value.to_string()).unwrap();
    assert_eq!(
        super::dispatch(&mut process, "rebound")["result"]["decision"],
        "pass"
    );
    assert_eq!(
        fs::read_to_string(root.join("data/observation")).unwrap(),
        "authorized hook ran"
    );
    fs::remove_file(root.join("data/observation")).unwrap();
    override_value["capability"]["controlKey"] = json!("a-different-session-key");
    fs::write(&override_path, override_value.to_string()).unwrap();
    let wrong_session = super::dispatch(&mut process, "wrong-session");
    assert_eq!(
        wrong_session["result"]["blockedHookId"],
        "requires-capability"
    );
    assert!(!root.join("data/observation").exists());
    override_value["capability"]["controlKey"] = json!(key);
    override_value["enabledHookIds"] = json!(["requires-capability", "persist-observation"]);
    override_value["emergencyChangedAt"] = json!("emergency-a");
    fs::write(&override_path, override_value.to_string()).unwrap();
    let mut emergency = json!({
        "schema": tama_hooks::session_control::EMERGENCY_STATE_SCHEMA,
        "disabled": true, "changedAt": "emergency-a",
    });
    fs::write(root.join("emergency.json"), emergency.to_string()).unwrap();
    super::dispatch(&mut process, "current-emergency");
    assert_eq!(
        fs::read_to_string(root.join("data/observation")).unwrap(),
        "authorized hook ran"
    );
    fs::remove_file(root.join("data/observation")).unwrap();
    emergency["changedAt"] = json!("emergency-b");
    fs::write(root.join("emergency.json"), emergency.to_string()).unwrap();
    super::dispatch(&mut process, "expired-emergency");
    assert!(
        !root.join("data/observation").exists(),
        "a new emergency generation must invalidate the previous hook grants"
    );
    override_value["emergencyChangedAt"] = emergency["changedAt"].clone();
    fs::write(&override_path, override_value.to_string()).unwrap();
    super::dispatch(&mut process, "rebound-emergency");
    assert_eq!(
        fs::read_to_string(root.join("data/observation")).unwrap(),
        "authorized hook ran"
    );
    assert_eq!(fs::read_to_string(record).unwrap(), owner_state);
    process.finish();
}
