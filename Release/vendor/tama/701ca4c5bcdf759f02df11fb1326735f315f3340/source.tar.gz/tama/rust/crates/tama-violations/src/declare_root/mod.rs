//! `tama declare-root`: declaring a repository root whose files are fixed
//! by somebody else's tooling.
//!
//! The folder-file rule holds everywhere a person decides the layout. A
//! repository root is not such a place: npm reads `package.json` there,
//! Cargo reads `Cargo.toml` there, git reads `.gitignore` there, GitHub
//! shows `README.md` from there, and the release tooling reads
//! `.wisent-release.json` from there. Six files nobody may move already
//! exceeds the limit of five, so the audit's own answer is the declaration
//! `.` in `.tama/violations-ignore` — and writing that by hand, once per
//! repository, is the one-off repair this workshop refuses to accept.
//!
//! This command is the repeatable form. It reads what the root actually
//! holds, checks every file against the table below, and refuses when the
//! root carries anything a person could move into a folder: those get moved,
//! not declared. Only a root that is entirely other people's tooling is
//! declared, and the declaration says which tool fixes which file.

mod cli;
mod report;
mod table;
mod tidy;

pub use cli::{main, print_usage};

use report::{
    already_declared, declaration_path, declaration_text, fixed_by, uncommitted, FixedFile,
    RootReport,
};
use table::{is_junk, junk_reason};

use std::fs;
use std::path::Path;


use tidy::tidy as tidy_root;

/// Read one repository's root and decide what to say about it. `commit`
/// and `push` carry the written declaration into the repository's history.
pub fn inspect(
    repo: &Path,
    apply: bool,
    tidy: bool,
    commit: bool,
    push: bool,
) -> Result<RootReport, String> {
    let entries = fs::read_dir(repo).map_err(|error| format!("{}: {error}", repo.display()))?;
    let mut fixed = Vec::new();
    let mut movable = Vec::new();
    let mut junk = Vec::new();
    for entry in entries.flatten() {
        if !entry
            .file_type()
            .map(|kind| kind.is_file())
            .unwrap_or_default()
        {
            continue;
        }
        let name = entry.file_name().to_string_lossy().into_owned();
        if is_junk(&name) {
            junk.push(name);
            continue;
        }
        match fixed_by(&name) {
            Some(tool) => fixed.push(FixedFile {
                name,
                fixed_by: tool.to_string(),
            }),
            None => movable.push(name),
        }
    }
    fixed.sort_by(|left, right| left.name.cmp(&right.name));
    movable.sort();
    junk.sort();
    let path = declaration_path(repo);
    let mut report = RootReport {
        repo: repo.display().to_string(),
        fixed,
        movable,
        junk,
        declared: false,
        declaration: path.display().to_string(),
        reason: String::new(),
        tidied: Vec::new(),
        revision: String::new(),
    };
    if already_declared(&path) {
        report.declared = true;
        report.reason = "the root is already declared".to_string();
        // A declaration written by an earlier run and never committed is
        // not a declaration the next clone has. A --commit sweep finishes
        // that job instead of walking past it.
        if commit && uncommitted(repo, &path) {
            report.revision = record(repo, &path, push)?;
            report.reason = if push {
                "the declaration was committed and pushed".to_string()
            } else {
                "the declaration was committed".to_string()
            };
        }
        return Ok(report);
    }
    if !report.junk.is_empty() && tidy {
        let done = tidy_root(repo, &report.junk)?;
        report.tidied = done.removed;
        report.junk = Vec::new();
    }
    if !report.junk.is_empty() {
        report.reason = format!(
            "the root holds {} file(s) that do not belong in it; --tidy removes them: {}",
            report.junk.len(),
            report.junk.join(", ")
        );
        return Ok(report);
    }
    if !report.movable.is_empty() {
        report.reason = format!(
            "the root still holds {} file(s) a person can move into a folder: {}",
            report.movable.len(),
            report.movable.join(", ")
        );
        return Ok(report);
    }
    if !apply {
        report.reason = "would declare the root".to_string();
        return Ok(report);
    }
    let text = declaration_text(&report.fixed);
    let existing = fs::read_to_string(&path).unwrap_or_default();
    let body = if existing.is_empty() || existing.ends_with('\n') {
        format!("{existing}{}", text.trim_start_matches('\n'))
    } else {
        format!("{existing}\n{}", text.trim_start_matches('\n'))
    };
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent).map_err(|error| format!("{}: {error}", parent.display()))?;
    }
    fs::write(&path, body).map_err(|error| format!("{}: {error}", path.display()))?;
    report.declared = true;
    report.reason = "declared".to_string();
    if commit {
        let revision = record(repo, &path, push)?;
        report.revision = revision;
        report.reason = if push {
            "declared, committed and pushed".to_string()
        } else {
            "declared and committed".to_string()
        };
    }
    Ok(report)
}

/// Commit the declaration in the repository that received it, and push it
/// when asked. A declaration that lives only in a working tree is a
/// declaration the next clone does not have.
fn record(repo: &Path, declaration: &Path, push: bool) -> Result<String, String> {
    let subject = "docs: declare the tool-fixed repository root to the audit";
    let body = "Every file at this root is read from the root by npm, cargo, git, GitHub or \
the release tooling, so the five-files-per-folder rule cannot be met here. Written by \
`tama declare-root`, which refuses while anything movable is still there.";
    let run = |arguments: &[&str]| -> Result<String, String> {
        let output = std::process::Command::new("git")
            .args(arguments)
            .current_dir(repo)
            .output()
            .map_err(|error| format!("cannot run git in {}: {error}", repo.display()))?;
        if !output.status.success() {
            return Err(format!(
                "git {} failed in {}: {}",
                arguments.join(" "),
                repo.display(),
                String::from_utf8_lossy(&output.stderr).trim()
            ));
        }
        Ok(String::from_utf8_lossy(&output.stdout).trim().to_string())
    };
    let relative = declaration
        .strip_prefix(repo)
        .unwrap_or(declaration)
        .to_string_lossy()
        .into_owned();
    run(&["add", "--", &relative])?;
    run(&["commit", "--quiet", "-m", subject, "-m", body])?;
    if push {
        run(&["push", "--quiet"])?;
    }
    run(&["rev-parse", "--short", "HEAD"])
}
