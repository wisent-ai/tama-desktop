//! Transcript access for the `check-failure-inspection` port of
//! `shared-hooks/check_failure_inspection.py` (registry id
//! `check-failure-inspection`).
//!
//! Ports `find_session_jsonl()` and the `read_text().splitlines()` /
//! `Read`-block walk that its three scanning helpers repeat.
//!
//! The Claude Code transcript store (`~/.claude/projects/<encoded-cwd>/*.jsonl`,
//! or the exact `transcript_path` the Stop payload carries) is kept verbatim
//! rather than swapped for `tama_hooks::session_record::Turn`: `Turn` reads
//! `~/.omp/agent/sessions`, a different store with a different message shape,
//! so switching would change which Reads satisfy the gate.
//!
//! Lines come from `pystr::splitlines`, not `str::lines`: a raw U+2028 or
//! U+0085 inside a JSON string is a line boundary to Python, which splits the
//! record into two unparseable halves and drops the Reads it carried.

use super::pystr::splitlines;
use serde_json::Value;
use std::path::{Path, PathBuf};

/// This session's transcript, read once.
///
/// The Python re-reads the file inside every helper. Its content cannot change
/// within one hook run, so a single read is equivalent; an unreadable or
/// missing transcript yields no lines, which is what each Python helper's
/// `except`/`if not jsonl` branch degrades to.
pub struct Transcript {
    lines: Vec<String>,
}

impl Transcript {
    /// `find_session_jsonl()`: the payload's `transcript_path` when it names an
    /// existing file, otherwise the newest `*.jsonl` under the encoded project
    /// directory. A payload path that is not a file falls through to the glob,
    /// exactly as the Python does.
    pub fn locate(home: &Path, cwd: &Path, payload_transcript: &str) -> Self {
        let lines = session_jsonl(home, cwd, payload_transcript)
            .and_then(|path| std::fs::read_to_string(path).ok())
            .map(|text| splitlines(&text).into_iter().map(str::to_string).collect())
            .unwrap_or_default();
        Self { lines }
    }

    /// Python's `lines[-count:]`.
    pub fn tail(&self, count: usize) -> &[String] {
        &self.lines[self.lines.len().saturating_sub(count)..]
    }
}

fn session_jsonl(home: &Path, cwd: &Path, payload_transcript: &str) -> Option<PathBuf> {
    if !payload_transcript.is_empty() {
        let pinned = PathBuf::from(payload_transcript);
        if pinned.is_file() {
            return Some(pinned);
        }
    }
    let encoded = cwd.display().to_string().replace('/', "-");
    let project = home.join(".claude").join("projects").join(encoded);
    if !project.is_dir() {
        return None;
    }
    let mut candidates: Vec<(std::time::SystemTime, PathBuf)> = std::fs::read_dir(project)
        .ok()?
        .flatten()
        .filter(|entry| glob_match(&entry.file_name().to_string_lossy(), "", ".jsonl"))
        .filter_map(|entry| {
            let modified = entry.metadata().ok()?.modified().ok()?;
            Some((modified, entry.path()))
        })
        .collect();
    // `sorted(..., key=mtime, reverse=True)[0]`; the secondary sort by path
    // replaces the arbitrary `glob()` order the Python inherits on ties.
    candidates.sort_by(|left, right| right.cmp(left));
    candidates.into_iter().next().map(|(_, path)| path)
}

/// Python's `Path.glob("<prefix>*<suffix>")` for a single directory level:
/// `*` never matches a leading dot.
pub fn glob_match(name: &str, prefix: &str, suffix: &str) -> bool {
    !name.starts_with('.')
        && name.len() >= prefix.len().saturating_add(suffix.len())
        && name.starts_with(prefix)
        && name.ends_with(suffix)
}

/// The `file_path` of every `Read` tool_use block in `lines`, in order.
///
/// Mirrors the identical inner loop of `session_log_reads_imply_labels`,
/// `count_distinct_frame_reads` and the legacy path in `main`: an unparseable
/// line is skipped, a non-list `message.content` is skipped, and a block only
/// counts when it is an object with `type == "tool_use"` and `name == "Read"`.
pub fn read_file_paths(lines: &[String]) -> Vec<String> {
    let mut paths = Vec::new();
    for raw in lines {
        let Ok(entry) = serde_json::from_str::<Value>(raw) else {
            continue;
        };
        let Some(blocks) = entry
            .get("message")
            .and_then(|message| message.get("content"))
            .and_then(Value::as_array)
        else {
            continue;
        };
        for block in blocks {
            if !block.is_object()
                || block.get("type").and_then(Value::as_str) != Some("tool_use")
                || block.get("name").and_then(Value::as_str) != Some("Read")
            {
                continue;
            }
            paths.push(
                block
                    .get("input")
                    .and_then(|input| input.get("file_path"))
                    .and_then(Value::as_str)
                    .unwrap_or_default()
                    .to_string(),
            );
        }
    }
    paths
}

/// Lines after the last `type == "user"` entry inside the lookback window —
/// the turn boundary `session_log_reads_imply_labels` scans backwards for.
pub fn since_last_user(transcript: &Transcript, lookback: usize) -> &[String] {
    let window = transcript.tail(lookback);
    match window.iter().rposition(is_user_entry) {
        Some(index) => window[index..]
            .split_first()
            .map(|(_, rest)| rest)
            .unwrap_or_default(),
        None => window,
    }
}

fn is_user_entry(raw: &String) -> bool {
    serde_json::from_str::<Value>(raw)
        .ok()
        .and_then(|entry| {
            entry
                .get("type")
                .and_then(Value::as_str)
                .map(str::to_string)
        })
        .as_deref()
        == Some("user")
}
