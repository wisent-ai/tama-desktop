//! The marker `inspect_trajectory.sh` leaves, and what makes it count.
//!
//! Six conditions, each written after a way round the previous version: the
//! marker must exist and not be empty, it must name a recording, that
//! recording must exist, its recorded digest must match a recomputation, the
//! recording it names must be the newest one on disk for the label, and the
//! session must show a frame of that recording actually being read. Without
//! the digest a `touch` was enough; without the newest-recording test one old
//! inspection covered every later run; without the frame read the agent ran
//! the inspector and walked away.

use std::path::{Path, PathBuf};
use std::sync::LazyLock;

use regex::Regex;

use crate::ports::transport_common as common;
use crate::util::sha256_hex;

use super::artifacts;
use super::transcript;

const MARKER_DIR: &str = ".work/.artifact_inspected";
/// `claimed_sha[:8]` and `[:12]` in the report.
const SHA8_TEXT: &str = "8";
const SHA12_TEXT: &str = "12";

static RECORDING_LINE: LazyLock<Regex> =
    LazyLock::new(|| common::compile("(?m)^recording:[[:space:]]*(?P<path>.+)$"));
static DIGEST_LINE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile("(?m)^recording_sha256:[[:space:]]*(?P<digest>[0-9a-f]{64})$")
});
static FRAME_PATH_LINE: LazyLock<Regex> =
    LazyLock::new(|| common::compile("^[[:space:]]*-[[:space:]]*path:[[:space:]]*(?P<path>.+)$"));
static FRAME_DIGEST_LINE: LazyLock<Regex> =
    LazyLock::new(|| common::compile("^[[:space:]]*sha256:[[:space:]]*(?P<digest>[0-9a-f]{64})$"));

fn prefix(text: &str, length: &str) -> String {
    text.chars()
        .take(length.parse().unwrap_or_default())
        .collect()
}

fn digest_of(path: &Path) -> String {
    match std::fs::read(path) {
        Ok(bytes) => sha256_hex(&bytes),
        Err(_) => String::new(),
    }
}

pub(crate) fn marker_path(repo: &Path, label: &str) -> PathBuf {
    repo.join(MARKER_DIR).join(label)
}

/// The per-frame digests the marker records, as (path, digest).
pub(crate) fn frame_digests(repo: &Path, label: &str) -> Vec<(String, String)> {
    let Ok(text) = std::fs::read_to_string(marker_path(repo, label)) else {
        return Vec::new();
    };
    let mut found: Vec<(String, String)> = Vec::new();
    let mut pending: Option<String> = None;
    for line in text.lines() {
        if let Some(caps) = FRAME_PATH_LINE.captures(line) {
            pending = caps
                .name("path")
                .map(|found| found.as_str().trim().to_string());
            continue;
        }
        if let Some(caps) = FRAME_DIGEST_LINE.captures(line) {
            if let (Some(path), Some(digest)) = (pending.take(), caps.name("digest")) {
                found.push((path, digest.as_str().to_string()));
            }
        }
    }
    found
}

/// Whether the marker for this label validates, and why it does not.
pub(crate) fn validates(repo: &Path, label: &str, transcript_path: &str) -> (bool, String) {
    let marker = marker_path(repo, label);
    let Ok(metadata) = std::fs::metadata(&marker) else {
        return (false, "no marker (or empty)".to_string());
    };
    if metadata.len() == 0 {
        return (false, "no marker (or empty)".to_string());
    }
    let Ok(text) = std::fs::read_to_string(&marker) else {
        return (false, "unreadable marker".to_string());
    };
    let recording = RECORDING_LINE
        .captures(&text)
        .and_then(|caps| caps.name("path"))
        .map(|found| PathBuf::from(found.as_str().trim()));
    let claimed = DIGEST_LINE
        .captures(&text)
        .and_then(|caps| caps.name("digest"))
        .map(|found| found.as_str().to_string());
    let (Some(recording), Some(claimed)) = (recording, claimed) else {
        return (
            false,
            "marker missing recording: or recording_sha256: lines".to_string(),
        );
    };
    if !recording.exists() {
        return (
            false,
            format!(
                "recording referenced by marker does not exist: {}",
                recording.display()
            ),
        );
    }
    let actual = digest_of(&recording);
    if actual != claimed {
        return (
            false,
            format!(
                "sha256 mismatch (marker claimed {}…, actual {}…)",
                prefix(&claimed, SHA12_TEXT),
                prefix(&actual, SHA12_TEXT)
            ),
        );
    }
    let all = artifacts::recordings(repo, label);
    if let Some(latest) = all.first() {
        let same = std::fs::canonicalize(latest).ok() == std::fs::canonicalize(&recording).ok();
        if !same {
            return (
                false,
                format!(
                    "marker references {} but latest recording is {}",
                    recording
                        .file_name()
                        .map(|name| name.to_string_lossy().to_string())
                        .unwrap_or_default(),
                    latest
                        .file_name()
                        .map(|name| name.to_string_lossy().to_string())
                        .unwrap_or_default()
                ),
            );
        }
    }
    let sha8 = prefix(&claimed, SHA8_TEXT);
    let frames = frame_digests(repo, label);
    if !transcript::shows_frame_read(repo, label, &sha8, transcript_path, &frames) {
        return (
            false,
            format!(
                "no Read on sha8={sha8} frame in session — run inspect_trajectory.sh on the \
                 latest recording AND Read at least one frame_{sha8}_*.png"
            ),
        );
    }
    (
        true,
        "marker verified + sha8 frame Read observed".to_string(),
    )
}

#[cfg(test)]
mod tests {
    use super::{frame_digests, marker_path, validates};
    use std::path::{Path, PathBuf};

    fn scratch(name: &str) -> PathBuf {
        let dir = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../target/tmp")
            .join(format!("tama-marker-{name}"));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(dir.join(".work/.artifact_inspected")).expect("a marker directory");
        dir
    }

    #[test]
    fn a_missing_marker_says_so() {
        let repo = scratch("absent");
        let (ok, why) = validates(&repo, "linkedin", "");
        assert!(!ok);
        assert!(why.contains("no marker"), "{why}");
        let _ = std::fs::remove_dir_all(&repo);
    }

    /// A marker that names no recording cannot be checked against anything.
    #[test]
    fn a_marker_without_the_two_lines_is_refused() {
        let repo = scratch("bare");
        std::fs::write(marker_path(&repo, "linkedin"), "inspected: yes\n").expect("a marker file");
        let (ok, why) = validates(&repo, "linkedin", "");
        assert!(!ok);
        assert!(why.contains("missing recording:"), "{why}");
        let _ = std::fs::remove_dir_all(&repo);
    }

    /// A digest that does not match the recording is the `touch` bypass.
    #[test]
    fn a_wrong_digest_is_refused() {
        let repo = scratch("digest");
        let recording = repo.join("take.webm");
        std::fs::write(&recording, b"frames").expect("a recording");
        let body = format!(
            "recording: {}\nrecording_sha256: {}\n",
            recording.display(),
            "0".repeat(64)
        );
        std::fs::write(marker_path(&repo, "linkedin"), body).expect("a marker file");
        let (ok, why) = validates(&repo, "linkedin", "");
        assert!(!ok);
        assert!(why.contains("sha256 mismatch"), "{why}");
        let _ = std::fs::remove_dir_all(&repo);
    }

    #[test]
    fn the_per_frame_digests_are_read_in_pairs() {
        let repo = scratch("frames");
        let body = concat!(
            "recording: /x/take.webm\n",
            "frames:\n",
            "  - path: /x/.work/l/frame_aabbccdd_first.png\n",
            "    sha256: ",
        );
        let digest = "a".repeat(64);
        std::fs::write(marker_path(&repo, "linkedin"), format!("{body}{digest}\n"))
            .expect("a marker file");
        let found = frame_digests(&repo, "linkedin");
        assert_eq!(found.len(), true as usize, "{found:?}");
        assert_eq!(found[0].1, digest);
        let _ = std::fs::remove_dir_all(&repo);
    }
}
