//! What the store keeps on disk and how two writers stay out of each
//! other's way: the fact journal and the lock taken around one transition.
//!
//! Split out of `state/`, which held seven files where five are allowed.

pub mod journal;
pub mod lock;
