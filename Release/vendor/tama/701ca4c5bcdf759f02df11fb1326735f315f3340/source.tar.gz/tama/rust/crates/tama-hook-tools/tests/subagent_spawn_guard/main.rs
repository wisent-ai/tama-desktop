//! `tama-block-subagent-spawn`, driven as the real binary with real payloads
//! on stdin.
//!
//! The operator stopped seven subagents mid-work and forbade the shape:
//! "usun cala prace ktora zrobili do tej pory Ci subagenci. zablokuj ta
//! funkcjonalnosc". A session reaches another agent three ways — the
//! delegation tool, a kernel payload calling the spawn helpers, and an agent
//! command line run headless — so each has a case here, together with the
//! ordinary calls that must keep working: a shell command that merely
//! mentions an agent, an interactive `omp` with no instruction, and a kernel
//! payload that reads a file.
//!
//! Each case holds one call to its own exit status and, when refused, to the
//! exact sentence, because that sentence is the contract a session reads.

use std::io::Write as _;
use std::process::{Command, Output, Stdio};

use serde_json::{json, Value};

const EXIT_PASS: i32 = false as i32;
const EXIT_REFUSED: i32 = true as i32 + true as i32;

const GUARD: &str = env!("CARGO_BIN_EXE_tama-block-subagent-spawn");

const APPROVAL_ENV: &str = "DEVICE_SUBAGENT_SPAWN_APPROVED";
const APPROVAL_VALUE: &str = "1";

const BANNER: &str = "BLOCKED: launching a subagent is forbidden on this machine.";
const ESCAPE: &str = "Do the work in the session that was asked for it. The operator re-allows \
                      delegation by exporting DEVICE_SUBAGENT_SPAWN_APPROVED=1 outside the agent \
                      session.";

fn sentence(detected: &str) -> String {
    format!("{BANNER} Detected: {detected}. {ESCAPE}")
}

fn run(payload: Value, approved: bool) -> Output {
    let mut command = Command::new(GUARD);
    command
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped());
    match approved {
        true => command.env(APPROVAL_ENV, APPROVAL_VALUE),
        false => command.env_remove(APPROVAL_ENV),
    };
    let mut child = command
        .spawn()
        .unwrap_or_else(|error| panic!("spawn the guard: {error}"));
    child
        .stdin
        .as_mut()
        .expect("guard stdin")
        .write_all(payload.to_string().as_bytes())
        .expect("write payload");
    child.wait_with_output().expect("guard output")
}

fn refuses(payload: Value, detected: &str) {
    let output = run(payload.clone(), false);
    let stderr = String::from_utf8_lossy(&output.stderr).into_owned();
    assert_eq!(
        output.status.code(),
        Some(EXIT_REFUSED),
        "{payload} should be refused; stderr: {stderr}"
    );
    assert_eq!(
        stderr.trim_end(),
        sentence(detected),
        "sentence for {payload}"
    );
}

fn passes(payload: Value) {
    let output = run(payload.clone(), false);
    let stderr = String::from_utf8_lossy(&output.stderr).into_owned();
    assert_eq!(
        output.status.code(),
        Some(EXIT_PASS),
        "{payload} should pass; stderr: {stderr}"
    );
    assert!(stderr.is_empty(), "a passing call prints nothing: {stderr}");
}

fn shell(command: &str) -> Value {
    json!({ "tool_name": "Bash", "tool_input": { "command": command } })
}

fn kernel(code: &str) -> Value {
    json!({ "tool_name": "eval", "tool_input": { "language": "py", "code": code } })
}

#[test]
fn the_delegation_tool_is_refused() {
    let payload = json!({
        "tool_name": "Task",
        "tool_input": { "tasks": [{ "task": "split the oversized files", "agent": "task" }] },
    });
    refuses(payload, "the Task tool starts one");
}

#[test]
fn the_lowercase_spelling_of_the_delegation_tool_is_refused() {
    refuses(json!({ "tool_name": "task" }), "the task tool starts one");
}

#[test]
fn the_bridged_spelling_of_the_delegation_tool_is_refused() {
    refuses(
        json!({ "tool_name": "functions.task" }),
        "the functions.task tool starts one",
    );
}

#[test]
fn a_kernel_payload_that_spawns_an_agent_is_refused() {
    refuses(
        kernel("h = agent('read the corpus', agent='scout')"),
        "this payload calls agent(...)",
    );
}

#[test]
fn a_kernel_payload_that_opens_a_work_pool_is_refused() {
    refuses(
        kernel("pool = workpool(agent='sonic', name='splits')"),
        "this payload calls workpool(...)",
    );
}

#[test]
fn a_kernel_payload_that_reaches_the_delegation_tool_through_the_bridge_is_refused() {
    refuses(
        kernel("await tool.task({'tasks': [{'task': 'do it'}]})"),
        "this payload calls tool.task(...)",
    );
}

#[test]
fn an_agent_command_line_run_headless_is_refused() {
    refuses(
        shell("claude -p 'split the oversized files'"),
        "this command runs claude -p",
    );
}

#[test]
fn an_agent_command_line_behind_its_absolute_path_is_refused() {
    refuses(
        shell("/opt/homebrew/bin/codex exec 'fix the tests'"),
        "this command runs codex exec",
    );
}

#[test]
fn an_agent_command_line_in_a_later_segment_is_refused() {
    refuses(
        shell("cd /var/folders && omp --prompt='review this'"),
        "this command runs omp --prompt",
    );
}

#[test]
fn an_approved_machine_lets_the_delegation_tool_through() {
    let output = run(json!({ "tool_name": "Task" }), true);
    let stderr = String::from_utf8_lossy(&output.stderr).into_owned();
    assert_eq!(output.status.code(), Some(EXIT_PASS), "stderr: {stderr}");
    assert!(
        stderr.is_empty(),
        "an approved call prints nothing: {stderr}"
    );
}

#[test]
fn an_interactive_agent_command_line_passes() {
    passes(shell("omp config set extensions"));
}

#[test]
fn a_command_that_only_mentions_an_agent_passes() {
    passes(shell("git log --oneline --grep 'claude'"));
}

/// A sentence that names a headless agent run starts nothing. The gate used
/// to cut the payload on `;`, `&` and `|` before reading its quotes, so a
/// report with a semicolon in it arrived as command words.
#[test]
fn a_sentence_that_names_a_headless_run_passes() {
    passes(shell(
        "git commit -m \"chore: the batch used codex exec once; it is gone now\"",
    ));
}

/// Naming it is one thing; handing it to a shell is another.
#[test]
fn an_agent_command_line_inside_an_executors_argument_is_refused() {
    refuses(
        shell("bash -lc \"codex exec 'do the work'\""),
        "this command runs codex exec",
    );
}

#[test]
fn a_kernel_payload_that_reads_a_file_passes() {
    passes(kernel("display(read('package.json'))"));
}

#[test]
fn a_kernel_payload_naming_a_function_that_ends_in_agent_passes() {
    passes(kernel("rows = subagent_rows(catalog)"));
}

#[test]
fn an_ordinary_tool_call_passes() {
    passes(json!({ "tool_name": "Read", "tool_input": { "path": "src/lib.rs" } }));
}
