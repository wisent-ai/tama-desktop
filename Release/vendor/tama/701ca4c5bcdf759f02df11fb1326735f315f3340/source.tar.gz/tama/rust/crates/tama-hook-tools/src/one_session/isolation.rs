//! The private CODEX_HOME a one-session run gets, so the session it starts
//! cannot see or change the operator's own Codex configuration.
//!
//! Split out of `one_session/mod.rs`, which had grown past the
//! three-hundred-line limit.

use crate::registry::provider_hooks;
use crate::util::{home_dir, random_uuid};
use serde_json::{json, Value};
use std::path::PathBuf;

use super::catalog::{run_hook_path, work_root};

/// The isolated directory belongs to its owner alone; the documents inside
/// it are the owner's to read and write and nobody else's.
pub(super) const OWNER_ONLY_DIR: u32 = 0o700;
pub(super) const OWNER_ONLY_FILE: u32 = 0o600;

/// Port of `isolatedCodexHome`.
pub fn isolated_codex_home(
    registry: &Value,
    hook_id: &str,
    cwd: &str,
    provider: &str,
) -> Result<PathBuf, String> {
    use std::os::unix::fs::PermissionsExt;
    let source = std::env::var_os("CODEX_HOME")
        .map(PathBuf::from)
        .unwrap_or_else(|| home_dir().join(".codex"));
    let path = work_root().join(format!("codex-{}", random_uuid()));
    std::fs::create_dir_all(&path).map_err(|e| e.to_string())?;
    std::fs::set_permissions(&path, std::fs::Permissions::from_mode(OWNER_ONLY_DIR))
        .map_err(|e| e.to_string())?;
    let excluded = [
        "config.toml",
        "hooks.json",
        "plugins",
        "requirements.toml",
        "tmp",
        ".tmp",
    ];
    let entries = std::fs::read_dir(&source).map_err(|e| {
        if e.kind() == std::io::ErrorKind::NotFound {
            format!(
                "ENOENT: no such file or directory, scandir '{}'",
                source.display()
            )
        } else {
            e.to_string()
        }
    })?;
    for entry in entries {
        let entry = entry.map_err(|e| e.to_string())?;
        let name = entry.file_name().to_string_lossy().into_owned();
        if excluded.contains(&name.as_str()) {
            continue;
        }
        let from = source.join(&name);
        let to = path.join(&name);
        std::os::unix::fs::symlink(&from, &to).map_err(|e| e.to_string())?;
    }
    let hooks = provider_hooks(registry, hook_id, provider, &run_hook_path())?;
    let hooks_path = path.join("hooks.json");
    std::fs::write(
        &hooks_path,
        format!(
            "{}\n",
            serde_json::to_string_pretty(&json!({ "hooks": hooks })).unwrap_or_default()
        ),
    )
    .map_err(|e| e.to_string())?;
    std::fs::set_permissions(
        &hooks_path,
        std::fs::Permissions::from_mode(OWNER_ONLY_FILE),
    )
    .map_err(|e| e.to_string())?;
    let config_path = path.join("config.toml");
    let cwd_json = serde_json::to_string(&json!(cwd)).unwrap_or_default();
    std::fs::write(
        &config_path,
        format!(
            "[features]\nhooks = true\n\n[projects.{}]\ntrust_level = \"untrusted\"\n",
            cwd_json
        ),
    )
    .map_err(|e| e.to_string())?;
    std::fs::set_permissions(
        &config_path,
        std::fs::Permissions::from_mode(OWNER_ONLY_FILE),
    )
    .map_err(|e| e.to_string())?;
    Ok(path)
}
