//! The audit journal and the per-repository lock `tama clean` keeps.

use std::path::{Path, PathBuf};

use serde::Serialize;
use sha2::{Digest, Sha256};

use crate::find_violations::Finding;

/// JS `stateDir()` = `process.env.TAMA_CLEAN_STATE_DIR || join(repoRoot(),
/// 'state')`: the desktop backend serves from a read-only release directory,
/// so journals and locks must honor the override.
pub fn state_dir(root: &Path) -> PathBuf {
    if let Ok(dir) = std::env::var("TAMA_CLEAN_STATE_DIR") {
        if !dir.is_empty() {
            return PathBuf::from(dir);
        }
    }
    root.join("state")
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct JournalRound<'a> {
    pub at: String,
    pub repo: &'a str,
    pub round: i64,
    pub model: &'a str,
    pub agent_exit: Option<i32>,
    pub agent_signal: Option<String>,
    pub violations: usize,
    pub gaming: &'a [Finding],
}

#[derive(Serialize)]
pub struct JournalDone<'a> {
    pub at: String,
    pub repo: &'a str,
    pub done: bool,
    pub clean: bool,
    pub before: usize,
    pub after: usize,
}

pub fn journal(root: &Path, entry: &impl Serialize) {
    let dir = state_dir(root);
    let _ = std::fs::create_dir_all(&dir);
    if let Ok(mut file) = std::fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(dir.join("clean-journal.jsonl"))
    {
        use std::io::Write;
        let _ = writeln!(file, "{}", serde_json::to_string(entry).unwrap_or_default());
    }
}

pub fn lock_path_for(root: &Path, repo: &str) -> PathBuf {
    let digest = Sha256::digest(repo.as_bytes());
    let hex: String = digest.iter().map(|byte| format!("{:02x}", byte)).collect();
    state_dir(root).join("clean-locks").join(&hex[..16])
}
