//! How a patch names the file it touches.
//!
//! Three guards read the same three envelopes to find out which file a
//! write is aimed at — the anchored bracket header the edit tool writes,
//! the `*** Add File:` header of an apply-patch payload, and the `---`/
//! `+++` headers of a unified diff — and each spelled all three out for
//! itself, verbs included. A guard that learns a fourth envelope, or a
//! payload format that renames a verb, leaves the other two blind to the
//! same write.
//!
//! The verbs live in `vocabulary/patch-verbs.json`, because they are the
//! payload format's words rather than this product's, and the patterns are
//! built from them here.

/// The declaration compiled in from the vocabulary folder beside `ports`.
const DECLARED: &str = include_str!("../vocabulary/patch-verbs.json");

/// The verbs an apply-patch header may carry, as one regex branch.
pub fn verb_alternation() -> String {
    let document: serde_json::Value =
        serde_json::from_str(DECLARED).expect("patch-verbs.json beside this module is valid JSON");
    document["verbs"]
        .as_array()
        .expect("patch-verbs.json declares a verbs array")
        .iter()
        .filter_map(|verb| verb.as_str())
        .collect::<Vec<_>>()
        .join("|")
}

/// `*** Add File: <path>`, anchored, with the target captured as `target`.
pub fn file_header() -> String {
    format!(
        r"^\*\*\* (?:{}) File: (?P<target>.+)\n?\z",
        verb_alternation()
    )
}

/// The same header inside a multi-line payload, with the target as the
/// pattern's second group, for a guard that scans a whole command.
pub fn file_header_in_text() -> String {
    format!(r"\*\*\* (?:{}) File: (.+)", verb_alternation())
}

/// `[path#TAG]`, the edit tool's own envelope, with the target captured.
pub const BRACKET_HEADER: &str = r"^\[(?P<target>[^#\]\n]+)#";

/// `--- a/<path>` and `+++ b/<path>`, with the target captured.
pub const DIFF_HEADER: &str = r"^(?:---|\+\+\+) [ab]/(?P<target>.+)\n?\z";

/// The programs that apply a patch without naming the file in a payload a
/// guard can read: `git apply`, `patch`, and the line editors. A guard
/// that refuses opaque edits matches these.
pub fn applier_pattern() -> String {
    let document: serde_json::Value =
        serde_json::from_str(DECLARED).expect("patch-verbs.json beside this module is valid JSON");
    let appliers = document["appliers"]
        .as_array()
        .expect("patch-verbs.json declares an appliers array")
        .iter()
        .filter_map(|name| name.as_str())
        .collect::<Vec<_>>()
        .join("|");
    format!(r"(?i)\b({appliers})\b")
}

#[cfg(test)]
mod tests {
    use super::{file_header, file_header_in_text, verb_alternation};

    #[test]
    fn every_declared_verb_is_in_the_header_pattern() {
        let header = file_header();
        for verb in verb_alternation().split('|') {
            assert!(header.contains(verb), "{verb} is missing from {header}");
        }
        assert!(header.contains("(?P<target>"), "{header}");
    }

    /// The scanning variant has no anchors, so a header found in the middle
    /// of a command still names its file.
    #[test]
    fn the_scanning_variant_is_not_anchored() {
        let scanning = file_header_in_text();
        assert!(!scanning.starts_with('^'), "{scanning}");
        assert!(!scanning.ends_with("\\z"), "{scanning}");
    }
}
