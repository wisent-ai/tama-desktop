//! Enumerating repository-owned files for the shared scanner.
use std::process::{Command, Stdio};

use super::*;
/// Whether the enclosing repository refuses to own this directory.
///
/// `ls-files --exclude-standard` run inside an ignored directory answers with
/// nothing, and nothing is indistinguishable from a clean target: on
/// 2026-09-10 `.wisent-output/` became ignored in this repository and every
/// scan of a directory under it reported zero files and a clean result, while
/// the files were sitting right there. A directory its owner ignores is not
/// that repository's content, so the files themselves are what a caller asking
/// about that directory means, and the filesystem walk is what answers.
fn ignored_by_enclosing_repository(repo: &str) -> bool {
    Command::new("git")
        .args(["check-ignore", "--quiet", "."])
        .current_dir(repo)
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .status()
        .map(|status| status.success())
        .unwrap_or(false)
}

fn git_files(repo: &str) -> Option<Vec<String>> {
    if ignored_by_enclosing_repository(repo) {
        return None;
    }
    let out = Command::new("git")
        .args([
            "ls-files",
            "-z",
            "--cached",
            "--others",
            "--exclude-standard",
        ])
        .current_dir(repo)
        .output()
        .ok()?;
    if out.status.code() != Some(0) {
        return None;
    }
    let stdout = String::from_utf8_lossy(&out.stdout);
    let mut seen: HashSet<String> = HashSet::new();
    let mut files = Vec::new();
    for entry in stdout.split('\0') {
        if entry.is_empty() {
            continue;
        }
        let full = resolve_path(&[Path::new(repo), Path::new(entry)]);
        let full = full.to_string_lossy().into_owned();
        if !seen.insert(full.clone()) {
            continue;
        }
        files.push(full);
    }
    Some(files)
}

fn walk_files(root_dir: &str) -> Vec<String> {
    let mut files = Vec::new();
    fn visit(dir: &str, under_source: bool, files: &mut Vec<String>) {
        let entries = match std::fs::read_dir(dir) {
            Ok(entries) => entries,
            Err(_) => return,
        };
        // Node `readdirSync` returns entries sorted by name.
        let mut entries: Vec<_> = entries.flatten().collect();
        entries.sort_by_key(|e| e.file_name());
        for entry in entries {
            let name = entry.file_name().to_string_lossy().into_owned();
            let full = Path::new(dir).join(&name).to_string_lossy().into_owned();
            let file_type = match entry.file_type() {
                Ok(file_type) => file_type,
                Err(_) => continue,
            };
            if file_type.is_dir() {
                let source = under_source || SOURCE_ROOT_DIR_NAMES.contains(&name.as_str());
                // Below a source root the build-output names are modules a
                // person wrote, so the walk keeps going.
                let skip = SYSTEM_DIR_NAMES.contains(&name.as_str())
                    || (!under_source && VENDOR_DIR_NAMES.contains(&name.as_str()));
                if !skip {
                    visit(&full, source, files);
                }
            } else if file_type.is_file() {
                files.push(full);
            }
        }
    }
    visit(root_dir, false, &mut files);
    files
}

/// Is this repository-relative path inside a vendored or build-output tree?
///
/// The path must be relative to the repository: an absolute one carries the
/// operator's own home, and a checkout that happens to live under a folder
/// named `build` is not a build directory.
pub fn is_vendor_path(rel: &str) -> bool {
    let mut under_source = false;
    for segment in rel.split('/') {
        if SOURCE_ROOT_DIR_NAMES.contains(&segment) {
            under_source = true;
            continue;
        }
        if !under_source && VENDOR_DIR_NAMES.contains(&segment) {
            return true;
        }
    }
    false
}

pub struct Enumeration {
    pub files: Vec<String>,
    pub mode: &'static str,
}

pub fn enumerate_files(repo: &str) -> Enumeration {
    if let Some(tracked) = git_files(repo) {
        return Enumeration {
            files: tracked,
            mode: "git",
        };
    }
    Enumeration {
        files: walk_files(repo),
        mode: "walk",
    }
}
