//! The loopback handlers for the copies command group.
//!
//! Split out of `routes.rs` when adding them pushed that file past the
//! three-hundred-line limit `block-oversized-files` enforces. The seam is
//! meaningful rather than arithmetic: everything here reads a request body for
//! one command group and answers with that group's document, and the dispatch
//! beside it only chooses handlers.
//!
//! Both handlers answer with exactly the document the command prints under
//! `--json`, refusals included: the desktop screen and the terminal must not
//! be able to disagree about what a pass would do.

use std::net::TcpStream;

use serde_json::Value;

use crate::copies::CommandError;

use super::http::{json_body, send_error, send_json, Request};

fn send_command_error(writer: &mut TcpStream, error: CommandError) {
    let status = match &error {
        CommandError::MissingRoot
        | CommandError::UnknownExcept(_)
        | CommandError::UnknownOnly(_) => 400,
        CommandError::Refused(_) | CommandError::Operational(_) => 500,
    };
    send_error(writer, status, &error.to_string());
}

/// The `roots` array both endpoints take, with the copies command's own
/// missing-root sentence: the two checkout groups name different commands, so
/// a client is told which one refused it.
fn roots_of(body: &Value) -> Result<Vec<String>, String> {
    let roots = string_array(body, "roots");
    if roots.is_empty() {
        return Err(crate::copies::MISSING_ROOT.to_string());
    }
    Ok(roots)
}

/// Every non-empty string of one array field, or an empty list when the field
/// is absent: a client built before a field existed keeps working.
fn string_array(body: &Value, name: &str) -> Vec<String> {
    body.get(name)
        .and_then(Value::as_array)
        .map(|values| {
            values
                .iter()
                .filter_map(Value::as_str)
                .filter(|value| !value.is_empty())
                .map(str::to_string)
                .collect()
        })
        .unwrap_or_default()
}

/// `tama copies list --root <PATH>... --json` over the loopback: the desktop
/// screen shows which second full checkouts exist before offering to remove
/// them.
pub(super) fn list(request: Request, writer: &mut TcpStream) {
    let body = match json_body(&request) {
        Ok(body) => body,
        Err((status, message)) => return send_error(writer, status, &message),
    };
    let roots = match roots_of(&body) {
        Ok(roots) => roots,
        Err(message) => return send_error(writer, 400, &message),
    };
    match crate::copies::list_document(&roots, &[]) {
        Ok(document) => send_json(
            writer,
            200,
            &serde_json::to_value(document).unwrap_or_default(),
        ),
        Err(error) => send_command_error(writer, error),
    }
}

/// `tama copies remove ... --json`. A refused pass is not a transport
/// failure: the document carries `applied: false` plus every refusal, exactly
/// as the command reports them.
pub(super) fn remove(request: Request, writer: &mut TcpStream) {
    let body = match json_body(&request) {
        Ok(body) => body,
        Err((status, message)) => return send_error(writer, status, &message),
    };
    let roots = match roots_of(&body) {
        Ok(roots) => roots,
        Err(message) => return send_error(writer, 400, &message),
    };
    let flag = |name: &str| body.get(name).and_then(Value::as_bool).unwrap_or(false);
    let except = string_array(&body, "except");
    let only = string_array(&body, "only");
    // Sparing paths and narrowing to paths are two answers to one question,
    // exactly as on the command line, so a body carrying both is refused
    // rather than silently resolved one way.
    if !except.is_empty() && !only.is_empty() {
        return send_error(
            writer,
            400,
            "except and only cannot be combined: narrow the pass or spare paths in it, not both",
        );
    }
    match crate::copies::remove_document(&roots, &except, &only, flag("apply"), flag("force")) {
        Ok(document) => send_json(
            writer,
            200,
            &serde_json::to_value(document).unwrap_or_default(),
        ),
        Err(error) => send_command_error(writer, error),
    }
}
