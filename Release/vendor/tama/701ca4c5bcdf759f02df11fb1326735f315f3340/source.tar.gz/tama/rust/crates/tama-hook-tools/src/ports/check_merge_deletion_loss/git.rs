//! The Git questions this gate asks, and nothing else.
//!
//! Each one is a single `git` call in a given working directory. The line
//! count deliberately goes through `git show <rev>:<path>` and counts
//! newlines itself: the shell had to pipe through `awk` because `wc` is
//! shadowed by another tool on this machine, and a count that depends on
//! `PATH` is not a count.

use std::path::Path;
use std::process::Command;

const GIT: &str = "git";

fn run(dir: &Path, args: &[&str]) -> Option<String> {
    let output = Command::new(GIT)
        .current_dir(dir)
        .args(args)
        .output()
        .ok()?;
    match output.status.success() {
        true => Some(
            String::from_utf8_lossy(&output.stdout)
                .trim_end()
                .to_string(),
        ),
        false => None,
    }
}

pub(crate) fn inside_work_tree(dir: &Path) -> bool {
    run(dir, &["rev-parse", "--is-inside-work-tree"]).as_deref() == Some("true")
}

/// Local history that is on no remote: the commits about to leave the machine.
pub(crate) fn unpushed(dir: &Path) -> Vec<String> {
    run(dir, &["rev-list", "HEAD", "--not", "--remotes"])
        .unwrap_or_default()
        .lines()
        .map(str::to_string)
        .filter(|line| !line.is_empty())
        .collect()
}

pub(crate) fn resolve(dir: &Path, rev: &str) -> Option<String> {
    run(dir, &["rev-parse", "-q", "--verify", rev]).filter(|found| !found.is_empty())
}

pub(crate) fn short(dir: &Path, rev: &str) -> String {
    run(dir, &["rev-parse", "--short", rev]).unwrap_or_else(|| rev.to_string())
}

pub(crate) fn merge_base(dir: &Path, first: &str, second: &str) -> Option<String> {
    run(dir, &["merge-base", first, second]).filter(|found| !found.is_empty())
}

pub(crate) fn changed_files(dir: &Path, from: &str, to: &str) -> Vec<String> {
    run(dir, &["diff", "--name-only", from, to])
        .unwrap_or_default()
        .lines()
        .map(str::to_string)
        .filter(|line| !line.is_empty())
        .collect()
}

/// Lines of `<rev>:<path>`, and zero when the path is absent at that revision.
pub(crate) fn lines_at(dir: &Path, rev: &str, path: &str) -> i64 {
    let Some(text) = run(dir, &["show", &format!("{rev}:{path}")]) else {
        return 0;
    };
    if text.is_empty() {
        return 0;
    }
    // `awk 'END{print NR+0}'` counts records, so a file with no trailing
    // newline still has its last line counted.
    text.lines().count() as i64
}
