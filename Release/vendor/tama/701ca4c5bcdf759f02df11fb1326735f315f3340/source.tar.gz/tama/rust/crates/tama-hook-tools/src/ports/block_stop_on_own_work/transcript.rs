//! What the guard reads out of a Stop payload: the message the turn ends on,
//! everything the assistant said or thought since the operator last spoke,
//! the operator's last words, and every earlier ending a stop guard refused.
//!
//! The OMP transcript is one JSON object per line. A spoken or thought turn
//! is `{"type":"message","message":{"role":"assistant","content":[{"type":
//! "text","text":…},{"type":"thinking","thinking":…}]}}`; the operator is
//! `role: "user"` with text blocks; and a stop guard's refusal comes back as
//! `{"type":"custom_message","customType":"session-stop-continuation",
//! "content":"<banner>"}`. That last record is how a refused ending is told
//! apart from any other assistant message: it is the prose that immediately
//! preceded a continuation.

use serde_json::Value;

const TRANSCRIPT_KEYS: &[&str] = &["transcript", "messages", "events", "transcript_path"];
const MESSAGE_KEYS: &[&str] = &["final_message", "assistant_message", "response"];
const MESSAGE_KEY: &str = "message";
const CONTENT_KEY: &str = "content";
const ROLE_KEY: &str = "role";
const ATTRIBUTION_KEY: &str = "attribution";
const AGENT_ATTRIBUTION: &str = "agent";
const TYPE_KEY: &str = "type";
const TEXT_KEY: &str = "text";
const THINKING_KEY: &str = "thinking";
const CUSTOM_TYPE_KEY: &str = "customType";
const ASSISTANT_ROLE: &str = "assistant";
const USER_ROLE: &str = "user";
const TEXT_BLOCK: &str = "text";
const THINKING_BLOCK: &str = "thinking";
const CUSTOM_MESSAGE: &str = "custom_message";
const STOP_CONTINUATION: &str = "session-stop-continuation";
const LINE_JOIN: &str = "\n";

/// The transcript as the guard sees it, folded once from the payload.
#[derive(Debug, Default, PartialEq, Eq)]
pub struct Transcript {
    /// The prose the turn ends on.
    pub final_message: String,
    /// Text and thinking the assistant produced after the operator's last
    /// message, the final message included.
    pub ending_turn: String,
    /// The operator's newest message.
    pub last_operator_message: String,
    /// Every assistant prose that a stop guard then refused, oldest first.
    pub refused_endings: Vec<String>,
}

impl Transcript {
    pub fn from_payload(payload: &Value) -> Transcript {
        let mut transcript = fold(&records(payload));
        if let Some(inline) = inline_final_message(payload) {
            if transcript.ending_turn.is_empty() {
                transcript.ending_turn = inline.clone();
            }
            transcript.final_message = inline;
        }
        transcript
    }
}

/// An explicit final message in the payload wins over the transcript.
fn inline_final_message(payload: &Value) -> Option<String> {
    MESSAGE_KEYS.iter().find_map(|key| match payload.get(*key) {
        Some(Value::String(text)) if !text.trim().is_empty() => Some(text.clone()),
        Some(value) if value.is_object() => blocks_text(value.get(CONTENT_KEY)?, TEXT_BLOCK),
        _ => None,
    })
}

/// Every record the payload carries inline or names by path, in order.
fn records(payload: &Value) -> Vec<Value> {
    let mut found = Vec::new();
    for key in TRANSCRIPT_KEYS {
        match payload.get(*key) {
            Some(Value::Array(items)) => {
                found.extend(items.iter().filter(|item| item.is_object()).cloned());
            }
            Some(Value::String(path)) => {
                let Ok(text) = std::fs::read_to_string(path) else {
                    continue;
                };
                found.extend(
                    text.lines()
                        .filter_map(|line| serde_json::from_str::<Value>(line).ok()),
                );
            }
            _ => {}
        }
    }
    found
}

/// The text of every block of one kind, or of a bare string content.
fn blocks_text(content: &Value, kind: &str) -> Option<String> {
    let text = match content {
        Value::String(text) if kind == TEXT_BLOCK => text.clone(),
        Value::Array(blocks) => blocks
            .iter()
            .filter(|block| block.get(TYPE_KEY).and_then(Value::as_str) == Some(kind))
            .filter_map(|block| {
                block
                    .get(if kind == THINKING_BLOCK {
                        THINKING_KEY
                    } else {
                        TEXT_KEY
                    })
                    .and_then(Value::as_str)
            })
            .collect::<Vec<_>>()
            .join(LINE_JOIN),
        _ => return None,
    };
    let trimmed = text.trim();
    (!trimmed.is_empty()).then(|| trimmed.to_owned())
}

fn fold(records: &[Value]) -> Transcript {
    let mut transcript = Transcript::default();
    let mut last_prose = String::new();
    let mut ending_turn: Vec<String> = Vec::new();
    for record in records {
        if record.get(TYPE_KEY).and_then(Value::as_str) == Some(CUSTOM_MESSAGE) {
            if record.get(CUSTOM_TYPE_KEY).and_then(Value::as_str) == Some(STOP_CONTINUATION) {
                if !last_prose.is_empty() {
                    transcript
                        .refused_endings
                        .push(std::mem::take(&mut last_prose));
                }
                // The refused attempt has been judged; what the agent says and
                // thinks after the refusal is the next attempt, judged on its
                // own. Otherwise one sentence in a refused attempt would refuse
                // every attempt after it until the operator spoke — a gate whose
                // key is out of reach (~/agents/policy.md). Seen 2026-09-18 on
                // this guard's own first live turn.
                ending_turn.clear();
            }
            continue;
        }
        let message = match record.get(MESSAGE_KEY).filter(|value| value.is_object()) {
            Some(message) => message,
            None if record.get(ROLE_KEY).is_some() => record,
            None => continue,
        };
        let Some(content) = message.get(CONTENT_KEY) else {
            continue;
        };
        match message.get(ROLE_KEY).and_then(Value::as_str) {
            // OMP marks harness-injected user-role records (todo reminders, hook
            // continuations) with `attribution: "agent"`; the operator did not
            // speak, so the ending turn goes on. Missing this is why a first
            // replay on the incident transcript saw no "remaining session
            // capacity": a reminder had cut the turn in two.
            Some(USER_ROLE)
                if message.get(ATTRIBUTION_KEY).and_then(Value::as_str)
                    == Some(AGENT_ATTRIBUTION) => {}
            Some(USER_ROLE) => {
                if let Some(text) = blocks_text(content, TEXT_BLOCK) {
                    transcript.last_operator_message = text;
                }
                ending_turn.clear();
                last_prose.clear();
            }
            Some(ASSISTANT_ROLE) => {
                if let Some(thought) = blocks_text(content, THINKING_BLOCK) {
                    ending_turn.push(thought);
                }
                if let Some(spoken) = blocks_text(content, TEXT_BLOCK) {
                    ending_turn.push(spoken.clone());
                    transcript.final_message = spoken.clone();
                    last_prose = spoken;
                }
            }
            _ => {}
        }
    }
    transcript.ending_turn = ending_turn.join(LINE_JOIN);
    transcript
}

#[cfg(test)]
mod tests {
    use super::Transcript;
    use serde_json::json;

    fn user(text: &str) -> serde_json::Value {
        json!({ "type": "message", "message": { "role": "user",
            "content": [{ "type": "text", "text": text }] } })
    }

    fn assistant(thought: &str, text: &str) -> serde_json::Value {
        json!({ "type": "message", "message": { "role": "assistant", "content": [
            { "type": "thinking", "thinking": thought }, { "type": "text", "text": text } ] } })
    }

    fn refusal(banner: &str) -> serde_json::Value {
        json!({ "type": "custom_message", "customType": "session-stop-continuation",
            "content": banner })
    }

    #[test]
    fn a_refused_ending_is_the_prose_before_the_continuation() {
        let payload = json!({ "messages": [
            user("napraw to"),
            assistant("plan", "Raport pierwszy."),
            refusal("block-x: BLOCKED"),
            assistant("jeszcze raz", "Raport drugi."),
        ] });
        let transcript = Transcript::from_payload(&payload);
        assert_eq!(
            transcript.refused_endings,
            vec!["Raport pierwszy.".to_owned()]
        );
        assert_eq!(transcript.final_message, "Raport drugi.");
        assert_eq!(transcript.last_operator_message, "napraw to");
        assert!(
            !transcript.ending_turn.contains("plan"),
            "the refused attempt is judged already"
        );
        assert!(
            transcript.ending_turn.contains("jeszcze raz"),
            "the new attempt is the ending turn"
        );
    }

    #[test]
    fn the_operator_speaking_again_starts_a_new_ending_turn() {
        let payload = json!({ "messages": [
            user("pierwsze"), assistant("stara mysl", "stara odpowiedz"),
            user("drugie"), assistant("nowa mysl", "nowa odpowiedz"),
        ] });
        let transcript = Transcript::from_payload(&payload);
        assert!(!transcript.ending_turn.contains("stara mysl"));
        assert_eq!(transcript.last_operator_message, "drugie");
    }

    /// A todo reminder the harness injects under the user role is not the
    /// operator speaking: the ending turn runs on through it.
    #[test]
    fn a_harness_reminder_does_not_cut_the_ending_turn() {
        let payload = json!({ "messages": [
            user("napraw to"),
            assistant("Given remaining session capacity I stop.", "Raport."),
            { "type": "message", "message": { "role": "user", "attribution": "agent",
                "content": [{ "type": "text", "text": "9 incomplete todos - reminder 1/3" }] } },
            assistant("jeszcze grep", "Raport."),
        ] });
        let transcript = Transcript::from_payload(&payload);
        assert!(transcript
            .ending_turn
            .contains("remaining session capacity"));
        assert_eq!(transcript.last_operator_message, "napraw to");
    }
}
