use std::fmt;
use std::path::Path;

use tama_hooks::enforcement::{write_enforcement_selection, EnforcementMode};

mod preflight;
pub(crate) mod status;

pub(crate) use status::{
    installed_hook_ids, report_read_error, session_summary, status, status_for_home,
    EnforcementStatus,
};
use status::{print_status, status_after_write};

const EXIT_USAGE: i32 = 2;
const USAGE: &str = "tama enforcement <command>

Commands:
  status [--json]       Show the machine selection and emergency bypass state
  only <hook-id>...     Enforce only the selected installed hooks
  add <hook-id>...      Enforce these as well, keeping the current selection
  remove <hook-id>...   Stop enforcing these, keeping the rest
  preflight <hook-id> [--session ID]   Ask one hook against an exact session
  all                   Clear the selection and enforce every installed hook";

#[derive(Debug)]
pub(crate) enum CommandError {
    UnknownHook { id: String, known_count: usize },
    Operational(String),
    Unusable { id: String, reason: String },
}

impl fmt::Display for CommandError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::UnknownHook { id, known_count } => write!(
                formatter,
                "Unknown hook id '{id}'; the installed registry declares {known_count} hook ids, and the enforcement selection was not changed."
            ),
            Self::Operational(error) => formatter.write_str(error),
            Self::Unusable { id, reason } => write!(
                formatter,
                "Hook '{id}' cannot run on this machine, so nothing was selected and the enforcement selection was not changed. It answered: {reason}"
            ),
        }
    }
}

pub(crate) fn set_only(
    root: &Path,
    requested: &[String],
) -> Result<EnforcementStatus, CommandError> {
    let installed = installed_hook_ids(root).map_err(CommandError::Operational)?;
    for id in requested {
        if installed.binary_search(id).is_err() {
            return Err(CommandError::UnknownHook {
                id: id.clone(),
                known_count: installed.len(),
            });
        }
    }
    // A hook that cannot work here must not become the machine's policy: the
    // session path asks first, and until now this one did not.
    for id in requested {
        let unusable = preflight::hook_command(root, id)
            .as_deref()
            .and_then(|command| preflight::probe(command, None))
            .and_then(|probe| probe.failure());
        if let Some(reason) = unusable {
            return Err(CommandError::Unusable {
                id: id.clone(),
                reason,
            });
        }
    }
    let selection = write_enforcement_selection(EnforcementMode::Only, requested)
        .map_err(|error| CommandError::Operational(error.to_string()))?;
    Ok(status_after_write(selection, &installed))
}

/// Add hooks to the machine's selection, keeping the ones already chosen.
///
/// `only` takes the whole list, which is right when the selection is being
/// decided and wrong when one gate is being turned on: on 2026-09-21 turning
/// a newly installed hook on meant retyping twenty-three ids, where one
/// mistyped or forgotten id silently switches a gate off. The selection
/// after an `add` is the union, in the same order `status` prints.
pub(crate) fn add(root: &Path, requested: &[String]) -> Result<EnforcementStatus, CommandError> {
    let selected = status(root).map_err(CommandError::Operational)?.enabled;
    let mut union: Vec<String> = selected;
    for id in requested {
        if !union.iter().any(|held| held == id) {
            union.push(id.clone());
        }
    }
    union.sort();
    set_only(root, &union)
}

/// Take hooks out of the machine's selection, keeping the rest.
///
/// The same asymmetry in the other direction: turning one gate off by
/// retyping every other one is how the other twenty-two get turned off by
/// accident. An id that is not selected is reported rather than ignored,
/// because a silent no-op reads as a gate that was switched off.
pub(crate) fn remove(root: &Path, requested: &[String]) -> Result<EnforcementStatus, CommandError> {
    let selected = status(root).map_err(CommandError::Operational)?.enabled;
    for id in requested {
        if !selected.iter().any(|held| held == id) {
            return Err(CommandError::Operational(format!(
                "Hook '{id}' is not in this machine's selection, so nothing was changed; \
                 `tama enforcement status` prints the {} that are.",
                selected.len()
            )));
        }
    }
    let kept: Vec<String> = selected
        .into_iter()
        .filter(|held| !requested.iter().any(|id| id == held))
        .collect();
    set_only(root, &kept)
}

pub(crate) fn set_all(root: &Path) -> Result<EnforcementStatus, CommandError> {
    let installed = installed_hook_ids(root).map_err(CommandError::Operational)?;
    let selection = write_enforcement_selection(EnforcementMode::All, &[])
        .map_err(|error| CommandError::Operational(error.to_string()))?;
    Ok(status_after_write(selection, &installed))
}

fn usage(code: i32) -> i32 {
    eprintln!("{USAGE}");
    code
}

fn run(args: &[String], root: &Path) -> Result<i32, CommandError> {
    let command = args.first().map(String::as_str);
    let rest = args.get(1..).unwrap_or_default();
    match command {
        Some("help" | "--help" | "-h") => Ok(usage(0)),
        Some("status") if rest.is_empty() || rest == ["--json"] => {
            let result = status(root).map_err(CommandError::Operational)?;
            if rest == ["--json"] {
                println!(
                    "{}",
                    serde_json::to_string_pretty(&result).unwrap_or_default()
                );
            } else {
                print_status(&result);
            }
            report_read_error(&result);
            Ok(if result.read_error.is_some() { 1 } else { 0 })
        }
        Some("only") if !rest.is_empty() && rest.iter().all(|id| !id.starts_with('-')) => {
            let result = set_only(root, rest)?;
            println!("Machine enforcement selection saved.");
            print_status(&result);
            Ok(0)
        }
        Some("add") if !rest.is_empty() && rest.iter().all(|id| !id.starts_with('-')) => {
            let result = add(root, rest)?;
            println!("Machine enforcement selection saved.");
            print_status(&result);
            Ok(0)
        }
        Some("remove") if !rest.is_empty() && rest.iter().all(|id| !id.starts_with('-')) => {
            let result = remove(root, rest)?;
            println!("Machine enforcement selection saved.");
            print_status(&result);
            Ok(0)
        }
        Some("preflight")
            if rest.len() == 1
                || (rest.len() == 3
                    && rest[1] == "--session"
                    && !rest[2].is_empty()
                    && !rest[2].starts_with('-')) =>
        {
            let installed = installed_hook_ids(root).map_err(CommandError::Operational)?;
            Ok(preflight::report(
                root,
                &rest[0],
                &installed,
                rest.get(2).map(String::as_str),
            ))
        }
        Some("all") if rest.is_empty() => {
            let result = set_all(root)?;
            println!(
                "Machine enforcement selection cleared; all {} installed hooks are selected.",
                result.installed_hook_count
            );
            print_status(&result);
            Ok(0)
        }
        _ => Ok(usage(EXIT_USAGE)),
    }
}

pub(crate) fn main(args: &[String], root: &Path) -> i32 {
    match run(args, root) {
        Ok(code) => code,
        Err(error @ CommandError::UnknownHook { .. }) => {
            eprintln!("{error}");
            1
        }
        Err(error @ CommandError::Unusable { .. }) => {
            eprintln!("{error}");
            1
        }
        Err(CommandError::Operational(error)) => {
            eprintln!("enforcement: {error}");
            1
        }
    }
}
