//! Port of `runCommand`: spawn one hook command and capture its result.

use std::io::{Read, Write};
use std::process::{Command, Stdio};

use serde_json::Value;

use tama_hooks::hook_exec::tokenize_command;
use tama_hooks::session_capability::capability_environment;

use super::{expand_home, spawn_error_message, RunResult};

/// Port of `runCommand`: argv spawn (no shell) with the capability
/// environment and the normalized payload on stdin.
///
/// The command is waited for. It used to be killed after a configured number
/// of seconds, which is a guess about how long an answer may take: the same
/// number covered a hook stuck in a loop and a freshly installed binary
/// paying the operating system's signature assessment, and a gate killed
/// mid-answer was then reported as a refusal nobody wrote. A hook that is
/// slow is a hook to make fast, and the elapsed time this returns is what
/// says which one it is.
pub(crate) fn run_command(command: &str, input: &str, capability: Option<&Value>) -> RunResult {
    let tokens = tokenize_command(&expand_home(command));
    let (program, args) = match tokens.split_first() {
        Some((program, args)) if !program.is_empty() => (program.clone(), args.to_vec()),
        _ => {
            return RunResult {
                stderr: "empty hook command".to_string(),
                spawn_error: true,
                ..Default::default()
            }
        }
    };
    let mut cmd = Command::new(&program);
    cmd.args(&args)
        // `spawn(program, args, { env })` replaces the whole environment.
        .env_clear()
        .envs(capability_environment(capability, &[]))
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped());
    let mut child = match cmd.spawn() {
        Ok(child) => child,
        Err(error) => {
            return RunResult {
                stderr: spawn_error_message(&program, &error),
                spawn_error: true,
                ..Default::default()
            }
        }
    };
    // The clock starts when the child exists, so what is measured is the
    // command's whole life: the operating system's first-run assessment as
    // much as the work the hook does.
    let start = std::time::Instant::now();
    let mut stdout_handle = child.stdout.take();
    let mut stderr_handle = child.stderr.take();
    let stdout_thread = std::thread::spawn(move || -> Vec<u8> {
        let mut buf = Vec::new();
        if let Some(mut out) = stdout_handle.take() {
            let _ = out.read_to_end(&mut buf);
        }
        buf
    });
    let stderr_thread = std::thread::spawn(move || -> Vec<u8> {
        let mut buf = Vec::new();
        if let Some(mut err) = stderr_handle.take() {
            let _ = err.read_to_end(&mut buf);
        }
        buf
    });
    // The payload is written from its own thread, so a hook that never reads
    // stdin and a payload larger than the pipe buffer cannot leave the
    // runtime blocked in `write_all`.
    let mut stdin_handle = child.stdin.take();
    let payload = input.to_string();
    let stdin_thread = std::thread::spawn(move || -> Option<String> {
        let mut stdin = stdin_handle.take()?;
        match stdin.write_all(payload.as_bytes()) {
            Ok(()) => None,
            // `child.stdin.on('error', ...)` appends the message to stderr.
            Err(error) if error.kind() == std::io::ErrorKind::BrokenPipe => {
                Some("write EPIPE".to_string())
            }
            Err(error) => Some(error.to_string()),
        }
        // Dropping stdin closes it, like `child.stdin.end(input)`.
    });
    let status = child.wait().ok();
    let stdout_bytes = stdout_thread.join().unwrap_or_default();
    let stderr_bytes = stderr_thread.join().unwrap_or_default();
    // The child is gone by now, so the writer is unblocked either way.
    let stdin_error = stdin_thread.join().unwrap_or_default();
    let mut stderr = String::from_utf8_lossy(&stderr_bytes).into_owned();
    if let Some(message) = stdin_error {
        stderr.push_str(&message);
    }
    RunResult {
        code: status.and_then(|s| s.code()),
        stdout: String::from_utf8_lossy(&stdout_bytes).into_owned(),
        stderr,
        spawn_error: false,
        elapsed_ms: start.elapsed().as_millis(),
    }
}
