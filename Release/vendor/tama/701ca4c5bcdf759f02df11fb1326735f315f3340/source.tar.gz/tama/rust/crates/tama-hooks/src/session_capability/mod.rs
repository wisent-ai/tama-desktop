//! Port of `shared-hooks/session-capability.mjs`: structured capability grant
//! normalization and the `AGENT_STRUCTURED_CAPABILITY` environment contract.

mod capability;
mod grants;
#[cfg(test)]
mod tests;

pub use capability::{capability_environment, normalized_capability, CapabilityIdentity};
pub use grants::normalize_capability_grants;

pub const CAPABILITY_SCHEMA_VERSION: u64 = 2;
pub const CAPABILITY_ENV: &str = "AGENT_STRUCTURED_CAPABILITY";
pub const CAPABILITY_LIFETIMES: [&str; 3] = ["single-use", "expires-at", "current-session"];
