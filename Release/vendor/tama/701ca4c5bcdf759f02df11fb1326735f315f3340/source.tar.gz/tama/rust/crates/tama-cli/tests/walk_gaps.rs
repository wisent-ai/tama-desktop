//! What both removal passes say when they could not read the whole tree.
//!
//! On 2026-09-12 `tama worktrees list --root ~/Documents/CodingProjects
//! --json` reported no repositories, no worktrees and nothing unreadable,
//! while every `read_dir` under that root was refused with `Operation not
//! permitted`. The answer was then quoted as proof that this machine holds no
//! second checkouts. The walk had swallowed the error and returned an empty
//! list, and a clean answer from a pass that could not look is worse than no
//! answer at all.
//!
//! Both cases below make the same state for real — a directory under the root
//! the operating system refuses to list — drive the built binary over it, and
//! read the document, the stderr sentence, the exit code, and the filesystem
//! afterwards.

mod copies_fixture;
mod worktrees_fixture;

use std::fs;
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};

use serde_json::Value;

/// A directory this process cannot list, restored on drop so the fixture's own
/// cleanup can remove it whether the case passed or failed.
struct Sealed {
    path: PathBuf,
}

impl Sealed {
    fn new(path: PathBuf) -> Self {
        fs::create_dir_all(&path).expect("create the directory to seal");
        seal(&path);
        Self { path }
    }
}

impl Drop for Sealed {
    fn drop(&mut self) {
        let _ = fs::set_permissions(&self.path, fs::Permissions::from_mode(0o755));
    }
}

/// Owner-less permissions: the walk's `read_dir` is refused by the kernel,
/// which is the state a sandbox, a mounted volume that went away and another
/// account's directory all produce.
fn seal(path: &Path) {
    fs::set_permissions(path, fs::Permissions::from_mode(0o000)).expect("seal the directory");
}

fn gaps(document: &Value) -> Vec<(String, String)> {
    document["unreadableDirectories"]
        .as_array()
        .expect("the document carries unreadableDirectories")
        .iter()
        .map(|entry| {
            (
                entry["path"].as_str().unwrap_or_default().to_owned(),
                entry["reason"].as_str().unwrap_or_default().to_owned(),
            )
        })
        .collect()
}

#[test]
fn a_worktrees_pass_that_could_not_read_a_directory_says_so_and_removes_nothing() {
    let fixture = worktrees_fixture::Fixture::new("sealed");
    let sealed = Sealed::new(PathBuf::from(fixture.root()).join("sealed"));

    let listed = fixture.tama(&["worktrees", "list", "--root", &fixture.root(), "--json"]);
    let document: Value = serde_json::from_str(&worktrees_fixture::stdout(&listed))
        .expect("the list document is JSON");
    let named = gaps(&document);
    assert_eq!(
        named
            .iter()
            .map(|(path, _)| path.as_str())
            .collect::<Vec<_>>(),
        vec![sealed.path.to_string_lossy().as_ref()],
        "the sealed directory is the one the pass could not read: {document}"
    );
    assert_eq!(
        listed.status.code(),
        Some(1),
        "a pass that could not read a directory must not exit clean: {}",
        worktrees_fixture::stderr(&listed)
    );

    // The worktrees are real and removable; only the gap in the walk stops
    // the pass, so this is the case where the product has to choose between
    // deleting with incomplete knowledge and refusing.
    let applied = fixture.tama(&[
        "worktrees",
        "remove",
        "--root",
        &fixture.root(),
        "--apply",
        "--json",
    ]);
    let receipt: Value = serde_json::from_str(&worktrees_fixture::stdout(&applied))
        .expect("the remove document is JSON");
    assert_eq!(receipt["applied"], Value::Bool(false), "{receipt}");
    assert_eq!(receipt["removed"], Value::Array(Vec::new()), "{receipt}");
    assert_eq!(applied.status.code(), Some(1), "{receipt}");
    assert_eq!(
        fixture.git_worktrees(),
        fixture.all_three(),
        "git still reports every worktree, so nothing was removed"
    );
}

#[test]
fn a_copies_pass_that_could_not_read_a_directory_says_so_and_removes_nothing() {
    let fixture = copies_fixture::Fixture::new("sealed");
    let sealed = Sealed::new(PathBuf::from(fixture.root()).join("sealed"));

    let listed = fixture.tama(&["copies", "list", "--root", &fixture.root(), "--json"]);
    let document: Value =
        serde_json::from_str(&copies_fixture::stdout(&listed)).expect("the list document is JSON");
    assert_eq!(
        gaps(&document)
            .iter()
            .map(|(path, _)| path.as_str())
            .collect::<Vec<_>>(),
        vec![sealed.path.to_string_lossy().as_ref()],
        "the sealed directory is the one the pass could not read: {document}"
    );
    assert_eq!(
        listed.status.code(),
        Some(1),
        "a copies pass that could not read a directory must not exit clean: {}",
        copies_fixture::stderr(&listed)
    );

    let copy = fixture.copy();
    let applied = fixture.tama(&[
        "copies",
        "remove",
        "--root",
        &fixture.root(),
        "--apply",
        "--json",
    ]);
    let receipt: Value = serde_json::from_str(&copies_fixture::stdout(&applied))
        .expect("the remove document is JSON");
    assert_eq!(receipt["applied"], Value::Bool(false), "{receipt}");
    assert_eq!(receipt["removed"], Value::Array(Vec::new()), "{receipt}");
    assert_eq!(applied.status.code(), Some(1), "{receipt}");
    assert!(
        copy.is_dir(),
        "the nested copy is still on disk at {}",
        copy.display()
    );
}

#[test]
fn named_copy_removal_does_not_walk_unrelated_subtrees() {
    let fixture = copies_fixture::Fixture::new("selected-scope");
    let copy = fixture.copy();
    let sealed = Sealed::new(copy.with_file_name("copy-unrelated"));
    let path = copies_fixture::text(copy.clone());
    let preview = fixture.tama(&[
        "copies",
        "remove",
        "--root",
        &fixture.root(),
        "--only",
        &path,
        "--json",
    ]);
    assert_eq!(
        preview.status.code(),
        Some(0),
        "{}",
        copies_fixture::stderr(&preview)
    );
    assert!(copy.is_dir(), "a preview must preserve the selected copy");

    let applied = fixture.tama(&[
        "copies",
        "remove",
        "--root",
        &fixture.root(),
        "--only",
        &path,
        "--apply",
    ]);
    assert_eq!(
        applied.status.code(),
        Some(0),
        "{}",
        copies_fixture::stderr(&applied)
    );
    assert!(!copy.exists(), "the selected copy must be removed");
    assert!(sealed.path.is_dir(), "the unrelated subtree must remain");
    assert!(fixture.lone().is_dir(), "unselected copies must remain");
    assert_eq!(
        fs::read_to_string(fixture.checkout().join("file.txt")).unwrap(),
        "one\n",
        "the canonical checkout must remain unchanged"
    );
}

#[test]
fn named_copy_removal_still_refuses_an_unreadable_selected_subtree() {
    let fixture = copies_fixture::Fixture::new("selected-gap");
    let copy = fixture.copy();
    let sealed = Sealed::new(copy.join("protected"));
    let applied = fixture.tama(&[
        "copies",
        "remove",
        "--root",
        &fixture.root(),
        "--only",
        &copies_fixture::text(copy.clone()),
        "--apply",
        "--force",
        "--json",
    ]);
    let receipt: Value = serde_json::from_str(&copies_fixture::stdout(&applied))
        .expect("the removal receipt is JSON");
    assert_eq!(applied.status.code(), Some(1), "{receipt}");
    assert_eq!(receipt["applied"], Value::Bool(false), "{receipt}");
    assert_eq!(
        gaps(&receipt)
            .iter()
            .map(|(path, _)| path.as_str())
            .collect::<Vec<_>>(),
        vec![sealed.path.to_string_lossy().as_ref()]
    );
    assert_eq!(
        fs::read_to_string(copy.join("file.txt")).unwrap(),
        "one\n",
        "an unreadable selected subtree must refuse before deleting any files"
    );
    assert!(sealed.path.is_dir());
}
