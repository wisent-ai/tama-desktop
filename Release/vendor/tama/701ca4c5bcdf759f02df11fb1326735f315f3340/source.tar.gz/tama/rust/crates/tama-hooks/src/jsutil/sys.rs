//! System-facing JavaScript ports: `os.homedir()`, Node `path.basename`, and
//! the random token used for temporary file names.

use std::env;
use std::path::PathBuf;
use std::time::{SystemTime, UNIX_EPOCH};

/// `os.homedir()`: `$HOME` on POSIX, with a passwd-database lookup through
/// the shell when `$HOME` is unset; `USERPROFILE` / `HOMEDRIVE`+`HOMEPATH`
/// on Windows.
pub fn home_dir() -> PathBuf {
    #[cfg(unix)]
    {
        if let Some(h) = env::var_os("HOME").filter(|v| !v.is_empty()) {
            return PathBuf::from(h);
        }
        if let Ok(out) = std::process::Command::new("sh")
            .args(["-c", "printf %s ~"])
            .output()
        {
            if out.status.success() && !out.stdout.is_empty() {
                use std::os::unix::ffi::OsStringExt;
                return PathBuf::from(std::ffi::OsString::from_vec(out.stdout));
            }
        }
        PathBuf::from("/")
    }
    #[cfg(windows)]
    {
        if let Some(p) = env::var_os("USERPROFILE").filter(|v| !v.is_empty()) {
            return PathBuf::from(p);
        }
        let drive = env::var_os("HOMEDRIVE").unwrap_or_default();
        let path = env::var_os("HOMEPATH").unwrap_or_default();
        if !drive.is_empty() || !path.is_empty() {
            let mut p = drive;
            p.push(&path);
            return PathBuf::from(p);
        }
        PathBuf::from(".")
    }
}

/// Node `path.basename` (POSIX semantics on non-Windows).
pub fn js_basename(path: &str) -> String {
    #[cfg(windows)]
    {
        let trimmed = path.trim_end_matches(['/', '\\']);
        if trimmed.is_empty() {
            return String::new();
        }
        trimmed
            .rsplit(['/', '\\'])
            .next()
            .unwrap_or_default()
            .to_string()
    }
    #[cfg(not(windows))]
    {
        let trimmed = path.trim_end_matches('/');
        if trimmed.is_empty() {
            return String::new();
        }
        trimmed.rsplit('/').next().unwrap_or_default().to_string()
    }
}

/// Random hex token for temporary file names (replaces `randomUUID()`; the
/// name only needs uniqueness, it never survives the atomic rename).
pub fn random_token() -> String {
    use std::io::Read;
    let mut buf = [0u8; 16];
    if let Ok(mut f) = std::fs::File::open("/dev/urandom") {
        if f.read_exact(&mut buf).is_ok() {
            return buf.iter().map(|b| format!("{b:02x}")).collect();
        }
    }
    let nanos = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_nanos())
        .unwrap_or(0);
    format!("{nanos:032x}")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn basename() {
        assert_eq!(js_basename("/a/b/c.jsonl"), "c.jsonl");
        assert_eq!(js_basename("/a/b/"), "b");
        assert_eq!(js_basename(""), "");
        assert_eq!(js_basename("/"), "");
    }
}
