//! Where a repair round gets its model, and how its edits land.
//!
//! Every Wisent component that needs a model calls Brama, the authenticated
//! provider-neutral gateway. This one used to spawn `codex exec` or
//! `kimi -p <brief> --yolo` instead: two vendor CLIs nobody chose for this
//! product, one of them not installed here and the other refusing that exact
//! argument pair, so each round exited immediately and the repair changed
//! nothing. The round now asks Brama for a patch and applies it with `git
//! apply`, so the model choice is a Brama route and the credentials stay in
//! Skarbiec.
//!
//! `TAMA_CLEAN_AGENT_CMD` still replaces the whole step, which is how a
//! caller points a round at a local agent harness or a test double.

use std::io::Read;
use std::path::Path;
use std::process::{Command, Stdio};
use std::time::{Duration, Instant};

/// One hour, the budget a repair round gets.
const AGENT_BUDGET_MS: u64 = 3_600_000;
/// Enough for a patch over several files; Brama refuses anything larger.
const PATCH_MAX_TOKENS: u32 = 8192;
/// Seconds Brama may take to answer with a patch. A round is allowed to
/// think: this is a diff over a whole repository report, not one word.
const PATCH_DEADLINE_SECONDS: u32 = 900;

const SYSTEM_PROMPT: &str = "You repair a Git repository so it passes enforced hook rules. \
Answer with one unified diff and nothing else: no prose, no fences, no commentary. \
Use paths relative to the repository root with the a/ and b/ prefixes git apply expects. \
Create files with new file mode and delete files with deleted file mode. \
Preserve behaviour: move code, never drop it, and keep every new module reachable from its parent.";

pub struct AgentRun {
    pub status: Option<i32>,
    pub signal: Option<String>,
    /// Why the round could not run or its patch did not apply. A round that
    /// cannot act is a failure to report, not an empty round.
    pub error: Option<String>,
    /// The diff this round applied, kept so a round that made the repository
    /// worse can be undone exactly, touching nothing it did not write.
    pub patch: Option<String>,
}

impl AgentRun {
    fn applied(patch: String) -> Self {
        AgentRun {
            status: Some(false as i32),
            signal: None,
            error: None,
            patch: Some(patch),
        }
    }

    fn seam(status: Option<i32>, signal: Option<String>, error: Option<String>) -> Self {
        AgentRun {
            status,
            signal,
            error,
            patch: None,
        }
    }

    fn failed(error: String) -> Self {
        AgentRun {
            status: None,
            signal: None,
            error: Some(error),
            patch: None,
        }
    }
}

fn signal_name(signal: i32) -> String {
    match signal {
        1 => "SIGHUP",
        2 => "SIGINT",
        3 => "SIGQUIT",
        6 => "SIGABRT",
        9 => "SIGKILL",
        11 => "SIGSEGV",
        13 => "SIGPIPE",
        15 => "SIGTERM",
        other => return format!("SIG{}", other),
    }
    .to_string()
}

/// Runs the seam command with the round budget, draining both pipes so a
/// chatty command cannot fill one and stall.
fn run_with_budget(cmd: &mut Command) -> AgentRun {
    cmd.stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped());
    let mut child = match cmd.spawn() {
        Ok(child) => child,
        Err(error) => return AgentRun::failed(format!("agent command did not start: {error}")),
    };
    fn drain<R: Read + Send + 'static>(
        pipe: Option<R>,
    ) -> Option<std::thread::JoinHandle<Vec<u8>>> {
        pipe.map(|mut reader| {
            std::thread::spawn(move || {
                let mut buffer = Vec::new();
                let _ = reader.read_to_end(&mut buffer);
                buffer
            })
        })
    }
    let out = drain(child.stdout.take());
    let err = drain(child.stderr.take());
    let budget = Duration::from_millis(AGENT_BUDGET_MS);
    let start = Instant::now();
    let mut timed_out = false;
    let status = loop {
        match child.try_wait() {
            Ok(Some(status)) => break Some(status),
            Ok(None) => {
                if start.elapsed() >= budget {
                    timed_out = true;
                    let _ = child.kill();
                    break child.wait().ok();
                }
                std::thread::sleep(Duration::from_millis(50));
            }
            Err(_) => break None,
        }
    };
    for handle in [out, err].into_iter().flatten() {
        let _ = handle.join();
    }
    if timed_out {
        return AgentRun::seam(
            None,
            Some("SIGTERM".to_string()),
            Some("agent command exceeded its round budget".to_string()),
        );
    }
    match status {
        Some(status) => match status.code() {
            Some(code) => AgentRun::seam(Some(code), None, None),
            None => {
                #[cfg(unix)]
                {
                    use std::os::unix::process::ExitStatusExt;
                    AgentRun::seam(
                        None,
                        status.signal().map(signal_name),
                        Some("agent command was signalled".to_string()),
                    )
                }
                #[cfg(not(unix))]
                {
                    AgentRun::failed("agent command reported no exit status".to_string())
                }
            }
        },
        None => AgentRun::failed("agent command reported no exit status".to_string()),
    }
}

/// Runs `git apply` in `repo`, forward or reversed. Returns the git error
/// when the diff does not apply, so the round records why and the next
/// brief can say so.
fn run_apply(repo: &str, patch: &str, reverse: bool) -> Result<(), String> {
    let mut args = vec!["apply", "--whitespace=nowarn"];
    if reverse {
        args.push("--reverse");
    }
    args.push("-");
    apply_with(repo, patch, &args)
}

/// Undoes exactly the diff a round applied, touching nothing it did not
/// write, so a round that made the repository worse leaves it as found.
pub fn revert_patch(repo: &str, patch: &str) -> Result<(), String> {
    run_apply(repo, patch, true)
}

fn apply_patch(repo: &str, patch: &str) -> Result<(), String> {
    run_apply(repo, patch, false)
}

fn apply_with(repo: &str, patch: &str, args: &[&str]) -> Result<(), String> {
    if patch.trim().is_empty() {
        return Err("Brama returned an empty patch".to_string());
    }
    let mut child = Command::new("git")
        .args(args)
        .current_dir(repo)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .map_err(|error| format!("cannot start git apply: {error}"))?;
    {
        use std::io::Write;
        child
            .stdin
            .as_mut()
            .ok_or_else(|| "git apply has no input pipe".to_string())?
            .write_all(patch.as_bytes())
            .map_err(|error| format!("cannot write the patch: {error}"))?;
    }
    let output = child
        .wait_with_output()
        .map_err(|error| format!("git apply did not complete: {error}"))?;
    if output.status.success() {
        return Ok(());
    }
    Err(format!(
        "git apply refused the patch: {}",
        String::from_utf8_lossy(&output.stderr).trim()
    ))
}

/// One repair round: the seam when set, otherwise Brama.
pub fn spawn_agent(model: &str, brief: &str, repo: &str) -> AgentRun {
    if let Ok(seam) = std::env::var("TAMA_CLEAN_AGENT_CMD") {
        if !seam.is_empty() {
            let mut cmd = Command::new("/bin/sh");
            cmd.args(["-c", seam.as_str()])
                .current_dir(repo)
                .env("TAMA_CLEAN_BRIEF", brief);
            return run_with_budget(&mut cmd);
        }
    }
    if !Path::new(repo).join(".git").exists() {
        return AgentRun::failed(
            "a Brama repair round applies a patch, so the target must be a Git repository"
                .to_string(),
        );
    }
    let patch = match tama_hook_tools::brama::chat(
        model,
        SYSTEM_PROMPT,
        brief,
        PATCH_MAX_TOKENS,
        PATCH_DEADLINE_SECONDS,
    ) {
        Ok(patch) => patch,
        Err(error) => return AgentRun::failed(error),
    };
    match apply_patch(repo, &patch) {
        Ok(()) => AgentRun::applied(patch),
        Err(error) => AgentRun::failed(error),
    }
}
