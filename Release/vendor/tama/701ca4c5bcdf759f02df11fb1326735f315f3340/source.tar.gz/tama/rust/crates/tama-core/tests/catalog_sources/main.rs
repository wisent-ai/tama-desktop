//! How a recorded hook source is mapped back to a file in the archive.
//!
//! The operator's sentence was "wyglada na to ze mamy do czynienia z
//! bledem", and the report he was reading carried sixty-three lines saying a
//! hook source could not be mapped from its command. Each of those hooks
//! named its source in the registry, repo-relative, because that is how
//! `tama-reconcile-registry-sources` repairs an entry once the registry
//! became portable. The reader only ever matched absolute prefixes, so it
//! answered that it could not find files that were right there — and a source
//! that maps to nothing is a source whose existence nothing checks.
//!
//! These cases drive the real reading against real files.

use std::fs;
use std::path::PathBuf;
use std::time::{SystemTime, UNIX_EPOCH};

use tama_core::catalog::command_source_path;

const RELATIVE_SOURCE: &str = "rust/crates/tama-hook-tools/src/bin/block/spawn/hook.rs";
const MANAGED_SOURCE: &str = "shared-hooks/pre_write_edit.sh";

/// Fixtures live under the crate's own `CARGO_TARGET_TMPDIR` inside
/// `target/`, never the OS temp directory this machine sweeps and never
/// `~/.stado/work`, which belongs to Stado.
fn archive(label: &str) -> PathBuf {
    let nonce = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .expect("clock after epoch")
        .as_nanos();
    let thread = format!("{:?}", std::thread::current().id()).replace(['(', ')'], "-");
    let root = PathBuf::from(env!("CARGO_TARGET_TMPDIR"))
        .join(format!("tama-catalog-sources-{label}-{thread}{nonce}"));
    fs::create_dir_all(&root).expect("create archive root");
    root
}

fn write_source(root: &PathBuf, relative: &str) -> PathBuf {
    let path = root.join(relative);
    fs::create_dir_all(path.parent().expect("source has a parent")).expect("create source dir");
    fs::write(&path, "// a hook source\n").expect("write source");
    path
}

/// The repair: the spelling the reconciler writes is understood, so the
/// catalogue can name the file and validation can check that it exists.
#[test]
fn a_repo_relative_source_that_exists_is_mapped() {
    let root = archive("relative");
    write_source(&root, RELATIVE_SOURCE);
    assert_eq!(
        command_source_path(Some(RELATIVE_SOURCE), &root).as_deref(),
        Some(RELATIVE_SOURCE)
    );
}

/// A recorded source that is not there stays unmapped, so the report keeps
/// warning about it instead of claiming a file it never found.
#[test]
fn a_repo_relative_source_that_is_absent_is_not_mapped() {
    let root = archive("absent");
    assert_eq!(command_source_path(Some(RELATIVE_SOURCE), &root), None);
}

/// The absolute spelling under a managed hook directory keeps working, which
/// is how every unported hook still records its source.
#[test]
fn an_absolute_managed_source_is_still_mapped() {
    let root = archive("absolute");
    let absolute = write_source(&root, MANAGED_SOURCE);
    let home = std::env::var("HOME").expect("HOME is set");
    let installed = format!("{home}/.shared-hooks/pre_write_edit.sh");
    assert_eq!(
        command_source_path(Some(&installed), &root).as_deref(),
        Some(MANAGED_SOURCE)
    );
    assert!(absolute.is_file(), "the fixture source exists");
}

/// A command line is not a path: an executable with arguments maps to
/// nothing rather than to a file named after its first word.
#[test]
fn a_command_line_with_arguments_is_not_taken_for_a_source() {
    let root = archive("command");
    assert_eq!(
        command_source_path(
            Some("node run-hook.mjs 'pre_tool_use:task' 'claude'"),
            &root
        ),
        None
    );
}
