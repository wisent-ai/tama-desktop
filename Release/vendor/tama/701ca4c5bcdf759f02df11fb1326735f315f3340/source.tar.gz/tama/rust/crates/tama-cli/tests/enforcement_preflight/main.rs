#![cfg(unix)]

//! Selecting a hook that cannot work on this machine, through the real
//! command.
//!
//! On 2026-09-11 `tama enforcement only` accepted `block-objective-substitution`
//! on a machine where Brama refuses that consumer. From the next tool call
//! onward every command an agent ran - including `true`, and including this
//! very command, which was the only way back - was refused with that
//! credential error. The session path had guarded against exactly this for
//! months: the adapter runs a declared hook once with a preflight payload and
//! refuses to activate it when the answer is not an acceptance. The machine
//! selection asked nothing.
//!
//! A hook whose binary is absent is a different thing and stays allowed: it is
//! not installed yet, it will not be dispatched, and refusing it would stop an
//! operator from selecting a hook before its release lands.

use std::fs;
use std::path::{Path, PathBuf};
use std::process::{Command, Output};
use std::time::{SystemTime, UNIX_EPOCH};

fn fixture(label: &str) -> PathBuf {
    let nonce = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .expect("clock before epoch")
        .as_nanos();
    let root = PathBuf::from(env!("CARGO_TARGET_TMPDIR")).join(format!(
        "enforcement-{label}-{}-{nonce}",
        std::process::id()
    ));
    fs::create_dir_all(root.join("shared-hooks")).expect("create the fixture root");
    script(&root.join("healthy.sh"), "#!/bin/sh\nexit 0\n");
    script(
        &root.join("unreachable.sh"),
        "#!/bin/sh\nprintf '%s\\n' 'TAMA_HOOK_INFRASTRUCTURE: Brama rejected the request from consumer tama with HTTP 401' >&2\nexit 70\n",
    );
    // The machine's own registry writes the home directory as a literal
    // `$HOME`, which the runtime expands before spawning.
    fs::create_dir_all(root.join("home")).expect("create the fixture home");
    script(
        &root.join("home").join("unreachable-under-home.sh"),
        "#!/bin/sh\nprintf '%s\\n' 'TAMA_HOOK_INFRASTRUCTURE: Brama rejected the request from consumer tama with HTTP 401' >&2\nexit 70\n",
    );
    let registry = serde_json::json!({
        "events": {},
        "catalog": {
            "agentHooks": [
                { "id": "fixture-healthy", "command": root.join("healthy.sh").to_string_lossy() },
                { "id": "fixture-unreachable", "command": root.join("unreachable.sh").to_string_lossy() },
                { "id": "fixture-not-installed", "command": root.join("absent-binary").to_string_lossy() },
                { "id": "fixture-home-relative", "command": "$HOME/unreachable-under-home.sh" },
                { "id": "fixture-precedence", "command": root.join("healthy.sh").to_string_lossy() },
            ]
        }
    });
    fs::write(
        root.join("shared-hooks").join("registry.json"),
        serde_json::to_vec(&registry).expect("serialize the fixture registry"),
    )
    .expect("publish the fixture registry");
    // The installed catalogue, which is where the machine's own pinned
    // commands live and therefore what the check has to read first.
    fs::create_dir_all(root.join("home").join(".shared-hooks"))
        .expect("create the installed catalogue directory");
    script(
        &root.join("home").join("pinned-unreachable.sh"),
        "#!/bin/sh\nprintf '%s\\n' 'TAMA_HOOK_INFRASTRUCTURE: Brama rejected the request from consumer tama with HTTP 403' >&2\nexit 70\n",
    );
    let installed = serde_json::json!({
        "events": {},
        "catalog": {
            "agentHooks": [
                { "id": "fixture-pinned", "command": root.join("home").join("pinned-unreachable.sh").to_string_lossy() },
                { "id": "fixture-precedence", "command": root.join("home").join("pinned-unreachable.sh").to_string_lossy() },
            ]
        }
    });
    fs::write(
        root.join("home")
            .join(".shared-hooks")
            .join("registry.json"),
        serde_json::to_vec(&installed).expect("serialize the installed catalogue"),
    )
    .expect("publish the installed catalogue");
    root
}

fn script(path: &Path, body: &str) {
    fs::write(path, body).expect("write the fixture hook");
    let mut permissions = fs::metadata(path)
        .expect("stat the fixture hook")
        .permissions();
    std::os::unix::fs::PermissionsExt::set_mode(&mut permissions, 0o755);
    fs::set_permissions(path, permissions).expect("make the fixture hook executable");
}

fn select(root: &Path, ids: &[&str]) -> Output {
    Command::new(env!("CARGO_BIN_EXE_tama-cli"))
        .args(["enforcement", "only"])
        .args(ids)
        // The fixture catalogue and the fixture selection file, so the suite
        // never reads or writes the machine's own.
        .env("TAMA_ROOT", root)
        .env("TAMA_HOOK_ENFORCEMENT", root.join("enforcement.json"))
        // The fixture's own home, because the command above is written the way
        // the registry writes it.
        .env("HOME", root.join("home"))
        .output()
        .expect("run tama enforcement only")
}

fn preflight(root: &Path, id: &str) -> Output {
    Command::new(env!("CARGO_BIN_EXE_tama-cli"))
        .args(["enforcement", "preflight", id])
        .env("TAMA_ROOT", root)
        .env("TAMA_HOOK_ENFORCEMENT", root.join("enforcement.json"))
        .env("HOME", root.join("home"))
        .output()
        .expect("run tama enforcement preflight")
}

fn selection(root: &Path) -> String {
    fs::read_to_string(root.join("enforcement.json")).unwrap_or_default()
}

#[test]
fn a_hook_that_reports_an_infrastructure_failure_is_not_selected() {
    let root = fixture("unreachable");
    let accepted = select(&root, &["fixture-healthy"]);
    assert!(accepted.status.success(), "the healthy hook is selectable");
    let before = selection(&root);

    let refused = select(&root, &["fixture-healthy", "fixture-unreachable"]);

    assert!(
        !refused.status.success(),
        "a hook that cannot run here must not become the machine's policy"
    );
    let said = String::from_utf8_lossy(&refused.stderr).to_string();
    assert!(
        said.contains("fixture-unreachable") && said.contains("HTTP 401"),
        "the refusal has to name the hook and repeat what it answered: {said}"
    );
    assert_eq!(
        selection(&root),
        before,
        "a refused selection must leave the previous one exactly as it was"
    );
}

#[test]
fn a_hook_whose_binary_is_absent_stays_selectable() {
    let root = fixture("absent");

    let output = select(&root, &["fixture-not-installed"]);

    assert!(
        output.status.success(),
        "a hook that is not installed yet is not a failing hook: {}",
        String::from_utf8_lossy(&output.stderr)
    );
    assert!(
        selection(&root).contains("fixture-not-installed"),
        "the selection has to hold the id that was asked for: {}",
        selection(&root)
    );
}

#[test]
fn a_command_written_with_a_literal_home_is_still_probed() {
    let root = fixture("home-relative");
    let accepted = select(&root, &["fixture-healthy"]);
    assert!(accepted.status.success(), "the healthy hook is selectable");
    let before = selection(&root);

    let refused = select(&root, &["fixture-home-relative"]);

    assert!(
        !refused.status.success(),
        "an unexpanded home in the command is not evidence that the hook is absent: {}",
        String::from_utf8_lossy(&refused.stderr)
    );
    assert_eq!(
        selection(&root),
        before,
        "a refused selection must leave the previous one exactly as it was"
    );
}

#[test]
fn the_diagnostic_reports_what_the_hook_answered() {
    let root = fixture("diagnostic");

    let unreachable = preflight(&root, "fixture-unreachable");
    let said = String::from_utf8_lossy(&unreachable.stdout).to_string();
    assert_eq!(
        unreachable.status.code(),
        Some(1),
        "an unusable hook is a nonzero answer: {said}"
    );
    assert!(
        said.contains("exit: 70")
            && said.contains("HTTP 401")
            && said.contains("verdict: unusable"),
        "the report has to carry the exit code, the answer and the verdict: {said}"
    );

    let healthy = preflight(&root, "fixture-healthy");
    let healthy_said = String::from_utf8_lossy(&healthy.stdout).to_string();
    assert_eq!(
        healthy.status.code(),
        Some(0),
        "a working hook is a zero answer: {healthy_said}"
    );
    assert!(
        healthy_said.contains("verdict: usable"),
        "the report has to name the verdict: {healthy_said}"
    );

    let absent = preflight(&root, "fixture-not-installed");
    let absent_said = String::from_utf8_lossy(&absent.stdout).to_string();
    assert!(
        absent_said.contains("spawn:") && absent_said.contains("not installed on this machine"),
        "an absent binary has to be reported as absent, not as a failure: {absent_said}"
    );
}

/// What the machine runs is what has to be asked. The installed catalogue
/// pins each command to the installed release; a checkout's catalogue still
/// names the unpinned `$HOME/.local/bin` copy. On 2026-09-11 this check read
/// the checkout's, ran a binary left in that directory in August, and reported
/// its long-dead credential path as the live hook's answer.
#[test]
fn the_installed_catalogue_decides_which_binary_is_asked() {
    let root = fixture("precedence");

    let output = preflight(&root, "fixture-precedence");
    let said = String::from_utf8_lossy(&output.stdout).to_string();

    assert!(
        said.contains("HTTP 403") && said.contains("verdict: unusable"),
        "the installed command has to win over the checkout's: {said}"
    );
    assert!(
        said.contains("pinned-unreachable.sh"),
        "the report has to name the program it actually ran: {said}"
    );
}
