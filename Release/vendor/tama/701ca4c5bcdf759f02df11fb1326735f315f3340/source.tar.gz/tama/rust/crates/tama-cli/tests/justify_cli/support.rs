//! The isolated home each case runs against, the prose it records, and
//! the two ways a case reads the command's output.
//!
//! Split out of `tests/justify_cli.rs`, which had grown past the
//! three-hundred-line limit; the cases are in `main.rs`.

use std::fs;
use std::path::PathBuf;
use std::process::{Command, Output};

use serde_json::Value;

/// Fifty words of prose, which is what both registries require.
pub const JUSTIFICATION: &str =
    "This entry exists because the test suite records one and then reads it \
back out of the registry document, which is the only way to know that the command wrote what the \
authorization gate will later look up. It names an absolute path, carries prose well past the \
declared minimum length, and is removed again by the case that recorded it so nothing accumulates \
in the temporary home this test owns.";

pub struct Home {
    path: PathBuf,
}

impl Home {
    pub fn new(area: &str) -> Self {
        // The crate's own `CARGO_TARGET_TMPDIR` inside `target/`, never
        // `/tmp`: this workshop keeps a run's throwaway state in the
        // checkout's ignored build tree, where the janitor can find it.
        let path = PathBuf::from(env!("CARGO_TARGET_TMPDIR")).join(format!(
            "tama-justify-{area}-{}-{}",
            std::process::id(),
            area.len()
        ));
        let _ = fs::remove_dir_all(&path);
        fs::create_dir_all(&path).expect("create the isolated home");
        Self { path }
    }

    pub fn run(&self, args: &[&str]) -> Output {
        Command::new(env!("CARGO_BIN_EXE_tama-cli"))
            .arg("justify")
            .args(args)
            .arg("--home")
            .arg(&self.path)
            .output()
            .expect("run the justify command")
    }

    pub fn registry(&self, kind: &str) -> PathBuf {
        self.path
            .join(".shared-hooks")
            .join(format!("{kind}_justifications.json"))
    }

    /// The stored document, or `None` when the command wrote no registry.
    pub fn document(&self, kind: &str) -> Option<Value> {
        let path = self.registry(kind);
        if !path.is_file() {
            return None;
        }
        Some(
            serde_json::from_str(&fs::read_to_string(path).expect("read the registry"))
                .expect("valid JSON"),
        )
    }
}

impl Drop for Home {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.path);
    }
}

pub fn stderr(output: &Output) -> String {
    String::from_utf8_lossy(&output.stderr).trim().to_string()
}

pub fn stdout(output: &Output) -> String {
    String::from_utf8_lossy(&output.stdout).trim().to_string()
}
