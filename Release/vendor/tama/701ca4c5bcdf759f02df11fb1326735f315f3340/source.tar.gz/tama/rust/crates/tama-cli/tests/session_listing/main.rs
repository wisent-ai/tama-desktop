#![cfg(unix)]

//! What `tama sessions` says about a session's hook state, through the real
//! command.
//!
//! Every record whose runtime had not published its hook state printed
//! `?/?` — a hundred and two of them on this machine on 2026-09-16 — which
//! reads as a broken session and does not say whether the session ended, or
//! is running and has not reported. The row now names the process state and
//! says `no runtime report` when that is what happened.
//!
//! The process probe is `kill(pid, 0)`, and an identifier that cannot be a
//! process id used to answer "running": cast down to `-1` it asks the kernel
//! about every process the caller may signal, which succeeds. A record like
//! that now reads `no usable pid`.

use std::fs;
use std::path::{Path, PathBuf};
use std::process::{Command, Output};
use std::time::{SystemTime, UNIX_EPOCH};

use serde_json::{json, Value};

/// A home of this run's own, so the operator's session records are neither
/// read nor changed.
struct ScratchHome {
    path: PathBuf,
}

impl ScratchHome {
    fn new() -> Self {
        let unique = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock before epoch")
            .as_nanos();
        let path = std::env::temp_dir().join(format!(
            "tama-session-listing-{}-{unique}",
            std::process::id()
        ));
        fs::create_dir_all(&path).expect("create scratch home");
        Self { path }
    }

    fn control_dir(&self) -> PathBuf {
        self.path
            .join("Library")
            .join("Application Support")
            .join("Tama")
            .join("session-control")
    }

    fn write_record(&self, name: &str, record: Value) {
        let dir = self.control_dir();
        fs::create_dir_all(&dir).expect("create session-control dir");
        fs::write(dir.join(name), record.to_string()).expect("write session record");
    }

    fn run(&self, root: &Path, args: &[&str]) -> Output {
        Command::new(env!("CARGO_BIN_EXE_tama-cli"))
            .args(args)
            .env("HOME", &self.path)
            .env("TAMA_ROOT", root)
            .env_remove("TAMA_HOOK_ENFORCEMENT")
            .env_remove("TAMA_EMERGENCY_STATE")
            .output()
            .expect("run tama-cli")
    }
}

impl Drop for ScratchHome {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.path);
    }
}

fn stdout(output: &Output) -> String {
    String::from_utf8(output.stdout.clone()).expect("stdout is UTF-8")
}

fn stderr(output: &Output) -> String {
    String::from_utf8(output.stderr.clone()).expect("stderr is UTF-8")
}

/// The hook counts this fixture publishes, as the live runtime published them
/// on 2026-09-16: nineteen machine-selected hooks, one more enabled for the
/// session, out of sixty-eight registered.
fn counts(loaded: u64) -> Value {
    json!({
        "globallyDisabled": false,
        "loadedHookCount": loaded,
        "registeredHookCount": REGISTERED,
    })
}

const REGISTERED: u64 = 68;
const MACHINE_SELECTED: u64 = 19;
const WITH_SESSION_HOOK: u64 = MACHINE_SELECTED + 1;

fn record(agent: &str, session: &str, pid: u32, runtime: Option<Value>) -> Value {
    let mut value = json!({
        "schema": "ai.wisent.tama.session-control.v2",
        "agentId": agent,
        "sessionId": session,
        "pid": pid,
        "livenessMode": "process",
    });
    if let Some(runtime) = runtime {
        value["runtime"] = runtime;
    }
    value
}

fn workshop_root() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../../..")
}

fn scratch_path(home: &ScratchHome) -> String {
    home.path
        .to_str()
        .expect("scratch home is UTF-8")
        .to_string()
}

#[test]
fn the_listing_names_the_process_state_and_the_reported_hook_state() {
    let root = workshop_root();
    let home = ScratchHome::new();
    let scratch = scratch_path(&home);
    let mine = std::process::id();

    home.write_record(
        "aaaa.session.json",
        record(
            "omp",
            "01a08878-8727-7610",
            mine,
            Some(counts(WITH_SESSION_HOOK)),
        ),
    );
    home.write_record(
        "bbbb.session.json",
        record("claude", "ea8adf1e-95f0-4a", mine, None),
    );
    home.write_record(
        "cccc.session.json",
        record(
            "kimi",
            "session_d62b0000",
            u32::MAX,
            Some(counts(MACHINE_SELECTED)),
        ),
    );

    let listing = home.run(&root, &["sessions", "--home", &scratch]);
    assert!(
        listing.status.success(),
        "sessions failed\nstdout:\n{}\nstderr:\n{}",
        stdout(&listing),
        stderr(&listing)
    );
    let text = stdout(&listing);

    assert!(
        text.contains(&format!(
            "omp\t01a08878-872\trunning\t{WITH_SESSION_HOOK}/{REGISTERED}\n"
        )),
        "a reported record names its hook counts: {text}"
    );
    assert!(
        text.contains("claude\tea8adf1e-95f\trunning\tno runtime report\n"),
        "a record without a runtime block says so: {text}"
    );
    assert!(
        text.contains(&format!(
            "kimi\tsession_d62b\tno usable pid\t{MACHINE_SELECTED}/{REGISTERED}\n"
        )),
        "an impossible process id is not a running session: {text}"
    );
    assert!(
        text.contains(
            "session records\t3\trunning=2\tgone=0\tno-usable-pid=1\tno-runtime-report=1\n"
        ),
        "the footer counts what was read: {text}"
    );
}

#[test]
fn the_json_carries_the_same_facts() {
    let root = workshop_root();
    let home = ScratchHome::new();
    let scratch = scratch_path(&home);
    let mut runtime = counts(WITH_SESSION_HOOK);
    runtime["enabledHookIds"] = json!(["block-git-authorship"]);

    home.write_record(
        "aaaa.session.json",
        record(
            "omp",
            "01a08878-8727-7610",
            std::process::id(),
            Some(runtime),
        ),
    );
    home.write_record(
        "bbbb.session.json",
        record("kimi", "session_d62b0000", u32::MAX, None),
    );

    let output = home.run(&root, &["sessions", "--json", "--home", &scratch]);
    assert!(
        output.status.success(),
        "sessions --json failed: {}",
        stderr(&output)
    );
    let parsed: Value = serde_json::from_str(&stdout(&output)).expect("parse sessions JSON");
    let rows = parsed["sessions"].as_array().expect("sessions array");

    assert_eq!(rows.len(), 2);
    assert_eq!(rows[0]["runtimeReported"], json!(true));
    assert_eq!(rows[0]["processAlive"], json!(true));
    assert_eq!(rows[0]["enabledHookIds"], json!(["block-git-authorship"]));
    assert_eq!(rows[1]["runtimeReported"], json!(false));
    assert_eq!(
        rows[1]["processAlive"],
        Value::Null,
        "an unusable process id is not reported as a state"
    );
}

/// A home with no records at all still answers, and says so.
#[test]
fn an_empty_machine_is_not_a_silent_answer() {
    let root = workshop_root();
    let home = ScratchHome::new();
    let scratch = scratch_path(&home);

    let listing = home.run(&root, &["sessions", "--home", &scratch]);

    assert!(listing.status.success(), "{}", stderr(&listing));
    assert!(
        stdout(&listing).contains(
            "session records\t0\trunning=0\tgone=0\tno-usable-pid=0\tno-runtime-report=0\n"
        ),
        "the footer is printed even with nothing to list: {}",
        stdout(&listing)
    );
}
