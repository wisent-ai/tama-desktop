//! Building the engine: where its state, registry and policy come from,
//! and the two small helpers the transitions need.
//!
//! Split out of `engine/mod.rs`, which had grown past the
//! three-hundred-line limit.

use std::fs::{self, OpenOptions};
use std::io::Write;
use std::path::PathBuf;

use tama_core::registry::Registry;

use super::lookup::{load_object, load_registry};
use super::Engine;
use crate::state::{open_state_store, HookState, StateStore, TransitionResult, Warn};
use crate::util::{home_dir, iso8601, now_ms, repo_root};

pub(super) fn invalid_observation(state: HookState) -> TransitionResult {
    TransitionResult {
        ok: false,
        persisted: false,
        mode: String::new(),
        transition: None,
        reason: Some("invalid-observation".to_string()),
        state,
    }
}

pub(super) fn snapshot_hook(store: &StateStore, hook_id: &str) -> HookState {
    let value = store.snapshot(Some(hook_id));
    serde_json::from_value::<HookState>(value).unwrap_or_else(|_| HookState::initial(hook_id))
}

/// `loadEngine(env = process.env)`.
pub fn load_engine() -> Engine {
    load_engine_with(|key| std::env::var(key).ok())
}

/// `loadEngine(env)` with an explicit environment lookup.
pub fn load_engine_with(env: impl Fn(&str) -> Option<String>) -> Engine {
    let state_dir = env("HOOKS_ADAPTIVE_STATE")
        .filter(|v| !v.is_empty())
        .map(PathBuf::from)
        .unwrap_or_else(|| home_dir().join(".hooks-adaptive"));
    let registry_path = env("AGENT_HOOK_REGISTRY")
        .filter(|v| !v.is_empty())
        .map(PathBuf::from)
        .unwrap_or_else(|| home_dir().join(".shared-hooks").join("registry.json"));
    let policy_path = repo_root().join("adaptive").join("policy.json");
    let policy = load_object(
        &policy_path,
        serde_json::json!({ "defaults": { "tier": "integrity" }, "tiers": {}, "hooks": {} }),
    );
    let registry_value = load_registry(&registry_path);
    let registry: Registry = serde_json::from_value(registry_value.clone()).unwrap_or_default();

    let warn: Warn = {
        let state_dir = state_dir.clone();
        std::sync::Arc::new(move |text: &str| {
            let attempt = (|| -> std::io::Result<()> {
                fs::create_dir_all(&state_dir)?;
                let mut file = OpenOptions::new()
                    .append(true)
                    .create(true)
                    .open(state_dir.join("warnings.log"))?;
                file.write_all(format!("{} {}\n", iso8601(now_ms()), text).as_bytes())?;
                Ok(())
            })();
            let _ = attempt;
        })
    };

    let store = open_state_store(&state_dir, warn);
    store.quarantine_legacy();
    Engine {
        state_dir,
        registry_path,
        policy,
        registry,
        registry_value,
        store,
    }
}
