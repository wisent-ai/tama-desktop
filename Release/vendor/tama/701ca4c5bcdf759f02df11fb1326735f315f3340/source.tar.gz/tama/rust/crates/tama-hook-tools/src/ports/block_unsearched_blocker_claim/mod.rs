//! Logic for `tama-block-unsearched-blocker-claim`, registry hook id
//! `block-unsearched-blocker-claim`.
//!
//! A Stop gate. It refuses a final message that says it does not know a value,
//! or asks the user to confirm one, when the session never searched the stored
//! transcripts.
//!
//! Why: on 2026-08-05 the agent invented an email address, built a write-once
//! mechanism around it, declared itself blocked on that address and asked the
//! user to confirm it three times over two hours. The answer was in the stored
//! transcripts the whole time — the genuine address appeared 7763 times, the
//! invention 119, all inside the authoring session. One search would have
//! settled it in eleven seconds, and it was never run.
//!
//! Both halves of the condition are in the payload: blocker language in the
//! final message, and no transcript search among the session's tool calls. The
//! gate does not judge whether the claim is true; it refuses to let "I do not
//! know" stand while the cheapest lookup is untried.
//!
//! `transcript_path` is in the key list because that is what the OMP adapter
//! supplies on a stop event: the lifecycle payload carries the event, the
//! runtime, the session id, the project directory and the raw event, and the
//! path is lifted out of the raw event. A stop hook that reads only inline
//! message keys inspects nothing in this runtime and passes — which is how a
//! whole family of stop gates never fired.

use std::sync::LazyLock;

use regex::Regex;
use serde_json::Value;
use tama_hooks::session_record::{deny_tool_use, read_payload};

use crate::ports::transport_common as common;

/// Blocker language, in both languages the workshop speaks.
static CLAIM: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(?i)(",
        "nie wiem|nie mam pewno|nie jest potwierdz|niepotwierdzon|potrzebuj\\w* potwierdz",
        "|czy to jest|ktor\\w+ z nich|musisz mi powiedzie|powiedz mi czy",
        "|i do not know|i am not sure|cannot confirm|unconfirmed|needs confirmation",
        "|please confirm|which of the two|only you can tell",
        ")",
    ))
});

/// A search of the stored transcripts, however it is spelled.
static SEARCHED: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(?i)(",
        "\\.omp[/\\\\]agent[/\\\\]sessions",
        "|transcript-index\\.sqlite",
        "|sessions_fts",
        "|history://",
        ")",
    ))
});

const TRANSCRIPT_KEYS: &[&str] = &[
    "transcript",
    "messages",
    "session",
    "events",
    "transcript_path",
];
const MESSAGE_KEYS: &[&str] = &["final_message", "message", "assistant_message", "response"];
const TEXT_KEYS: &[&str] = &["text", "command", "pattern", "path", "input", "code"];
const RECORD_KEYS: &[&str] = &["command", "pattern", "path", "code", "input"];
const MESSAGE_KEY: &str = "message";
const CONTENT_KEY: &str = "content";
const ROLE_KEY: &str = "role";
const ASSISTANT_ROLE: &str = "assistant";
const TEXT_KEY: &str = "text";

/// Every message-like record the stop payload carries, in order: the inline
/// lists, and the lines of a transcript the payload only names by path.
fn records(payload: &Value) -> Vec<Value> {
    let mut found: Vec<Value> = Vec::new();
    for key in TRANSCRIPT_KEYS {
        match payload.get(*key) {
            Some(Value::Array(items)) => {
                found.extend(items.iter().filter(|item| item.is_object()).cloned());
            }
            Some(Value::String(path)) => {
                let Ok(text) = std::fs::read_to_string(path) else {
                    continue;
                };
                for line in text.lines() {
                    if let Ok(record) = serde_json::from_str::<Value>(line) {
                        found.push(record);
                    }
                }
            }
            _ => {}
        }
    }
    found
}

fn nested_message(record: &Value) -> Option<&Value> {
    record.get(MESSAGE_KEY).filter(|value| value.is_object())
}

/// Everything a record says: its content, and the fields a tool call carries.
fn text_of(record: &Value) -> String {
    let mut parts: Vec<String> = Vec::new();
    let holder = nested_message(record).unwrap_or(record);
    match holder.get(CONTENT_KEY) {
        Some(Value::String(text)) => parts.push(text.clone()),
        Some(Value::Array(entries)) => {
            for entry in entries.iter().filter(|entry| entry.is_object()) {
                for key in TEXT_KEYS {
                    match entry.get(*key) {
                        Some(Value::String(text)) => parts.push(text.clone()),
                        Some(value) if value.is_object() => parts.push(value.to_string()),
                        _ => {}
                    }
                }
            }
        }
        _ => {}
    }
    for key in RECORD_KEYS {
        match record.get(*key) {
            Some(Value::String(text)) => parts.push(text.clone()),
            Some(value) if value.is_object() => parts.push(value.to_string()),
            _ => {}
        }
    }
    parts.join("\n")
}

fn content_text(value: &Value) -> Option<String> {
    match value.get(CONTENT_KEY) {
        Some(Value::String(text)) => Some(text.clone()),
        Some(Value::Array(parts)) => Some(
            parts
                .iter()
                .filter(|part| part.is_object())
                .map(|part| match part.get(TEXT_KEY) {
                    Some(Value::String(text)) => text.as_str(),
                    _ => "",
                })
                .collect::<Vec<_>>()
                .join("\n"),
        ),
        _ => None,
    }
}

/// The message this turn ended on. Only a record that actually carries prose
/// may replace the candidate: an assistant turn is usually a tool call with
/// thinking blocks and no text, and taking the last record unconditionally
/// overwrote the real reply with an empty string — which made every message
/// look like it claimed nothing.
pub(crate) fn final_message(payload: &Value) -> String {
    for key in MESSAGE_KEYS {
        match payload.get(*key) {
            Some(Value::String(text)) if !text.trim().is_empty() => return text.clone(),
            Some(value) if value.is_object() => {
                if let Some(text) = content_text(value) {
                    return text;
                }
            }
            _ => {}
        }
    }
    let mut last = String::new();
    for record in records(payload) {
        let role = nested_message(&record)
            .and_then(|message| message.get(ROLE_KEY))
            .or_else(|| record.get(ROLE_KEY))
            .and_then(Value::as_str)
            .unwrap_or_default();
        if role != ASSISTANT_ROLE {
            continue;
        }
        let spoken = text_of(&record);
        if !spoken.trim().is_empty() {
            last = spoken;
        }
    }
    last
}

fn searched(payload: &Value) -> bool {
    records(payload)
        .iter()
        .any(|record| SEARCHED.is_match(&text_of(record)))
}

/// The refusal, or nothing when the message claims no blocker or the session
/// did search.
pub fn check(payload: &Value) -> Option<String> {
    let message = final_message(payload);
    if message.is_empty() {
        return None;
    }
    let claim = CLAIM.find(&message)?;
    if searched(payload) {
        return None;
    }
    Some(format!(
        "block-unsearched-blocker-claim: this message says \"{}\" but the session never searched \
         the stored transcripts. Run a search over ~/.omp/agent/sessions before calling a value \
         unknown — the answer to the last identity the agent called unconfirmed was sitting there \
         7763 times while it asked the user three times instead. A value you have not looked for \
         is an unchecked lookup, not a blocker.",
        claim.as_str()
    ))
}

pub fn run() {
    let payload = read_payload();
    if let Some(problem) = check(&payload) {
        deny_tool_use(&problem);
    }
}

#[cfg(test)]
mod tests {
    use super::check;
    use serde_json::json;

    #[test]
    fn a_blocker_claim_without_a_search_is_refused() {
        let refusal = check(&json!({
            "final_message": "Nie wiem ktory adres jest prawdziwy, musisz mi powiedziec."
        }));
        let message = refusal.expect("a claim with no search must be refused");
        assert!(
            message.contains("Nie wiem"),
            "the refusal quotes the claim: {message}"
        );
        assert!(
            message.contains("~/.omp/agent/sessions"),
            "it names where to look: {message}"
        );
    }

    #[test]
    fn the_same_claim_passes_once_the_session_searched() {
        let payload = json!({
            "final_message": "I do not know which address is real.",
            "messages": [
                { "role": "assistant", "command": "rg needle ~/.omp/agent/sessions" }
            ]
        });
        assert_eq!(check(&payload), None);
    }

    #[test]
    fn a_message_that_claims_nothing_passes() {
        assert_eq!(
            check(&json!({ "final_message": "Zrobione, wszystko dziala." })),
            None
        );
    }

    /// An assistant turn is usually a tool call with no prose; taking the last
    /// record unconditionally used to overwrite the real reply with an empty
    /// string, and then every message looked like it claimed nothing.
    #[test]
    fn the_last_record_that_speaks_is_the_final_message() {
        let payload = json!({
            "messages": [
                { "role": "assistant", "content": "I am not sure which one it is." },
                { "role": "assistant", "content": [{ "type": "thinking", "thinking": "..." }] }
            ]
        });
        assert!(
            check(&payload).is_some(),
            "the spoken turn must still be judged"
        );
    }
}
