//! The ration, driven as the real `tama-cli` against a disposable home and a
//! real repository.
//!
//! The registry alone only asked for an intent, and an agent writes one in a
//! second. What the operator objected to on 2026-09-21 is the shape
//! underneath: a minimal change, a submission, forty minutes of waiting,
//! another minimal change. So a build is rationed — three in a rolling day,
//! and at least thirty changed lines against the revision the last recorded
//! build carried — and these cases hold each refusal to its exit status.

mod common;

use common::{build, commit, said, Scratch};

#[test]
fn the_days_allowance_is_spent_and_the_refusal_says_when_the_next_one_frees() {
    let scratch = Scratch::new("allowance");
    let tightened = build(&scratch, &["policy", "--builds-per-day", "1"]);
    assert!(tightened.status.success(), "{}", said(&tightened));
    assert!(
        said(&tightened).contains("builds_per_day tightened 3 -> 1"),
        "{}",
        said(&tightened)
    );

    let first = build(
        &scratch,
        &[
            "record",
            "--kind",
            "build",
            "--target",
            "skarbiec",
            "--reason",
            "the identity kind and the duplicate refusal go out together",
            "--revision",
            "45a5c678042147f76241adf76fb7cf217e121ca6",
        ],
    );
    assert!(first.status.success(), "{}", said(&first));
    assert!(
        said(&first).contains("1 of 1 builds in this 24 hours"),
        "{}",
        said(&first)
    );

    let second = build(
        &scratch,
        &[
            "record",
            "--kind",
            "build",
            "--target",
            "brama",
            "--reason",
            "the gateway needs the disown route in the same evening",
            "--revision",
            "c9aaf4f0c9aaf4f0c9aaf4f0c9aaf4f0c9aaf4f0",
        ],
    );
    assert_eq!(second.status.code(), Some(1), "{}", said(&second));
    let refusal = said(&second);
    assert!(refusal.contains("spent all 1 (skarbiec)"), "{refusal}");
    assert!(refusal.contains("authorized in 1440 min"), "{refusal}");
    assert!(
        refusal.contains("Gather the work into one build"),
        "{refusal}"
    );

    // A restart is counted separately, so a spent build allowance does not
    // hold back a service that has to come back.
    let restart = build(
        &scratch,
        &[
            "record",
            "--kind",
            "restart",
            "--target",
            "brama-desktop-model-router",
            "--reason",
            "the router reads its credential once at start and holds a revoked one",
        ],
    );
    assert!(restart.status.success(), "{}", said(&restart));
}

#[test]
fn a_small_change_is_refused_and_a_serious_one_is_recorded() {
    let scratch = Scratch::new("serious");
    let repository = scratch.repository();
    let path = repository.display().to_string();
    let one_line = commit(&repository, 1, "the first shipped revision");
    let three_lines = commit(&repository, 3, "two more lines");
    let hundred = commit(&repository, 100, "the work that deserves a builder");

    // Nothing has been built for this target yet, so there is nothing to
    // measure against and the first build is recorded.
    let first = build(
        &scratch,
        &[
            "record",
            "--kind",
            "build",
            "--target",
            "product",
            "--reason",
            "the first recorded build of this target carries the whole source",
            "--revision",
            &one_line,
            "--repository",
            &path,
        ],
    );
    assert!(first.status.success(), "{}", said(&first));

    let trivial = build(
        &scratch,
        &[
            "record",
            "--kind",
            "build",
            "--target",
            "product",
            "--reason",
            "two more lines that could travel with the next serious change",
            "--revision",
            &three_lines,
            "--repository",
            &path,
        ],
    );
    assert_eq!(trivial.status.code(), Some(1), "{}", said(&trivial));
    let refusal = said(&trivial);
    assert!(refusal.contains("carries 2 changed lines"), "{refusal}");
    assert!(refusal.contains("serious at 30 lines"), "{refusal}");

    let serious = build(
        &scratch,
        &[
            "record",
            "--kind",
            "build",
            "--target",
            "product",
            "--reason",
            "ninety-seven lines of work that a builder is worth spending on",
            "--revision",
            &hundred,
            "--repository",
            &path,
        ],
    );
    assert!(serious.status.success(), "{}", said(&serious));
    assert!(
        said(&serious).contains("2 of 3 builds in this 24 hours"),
        "{}",
        said(&serious)
    );

    // The same revision again is a build of nothing.
    let again = build(
        &scratch,
        &[
            "record",
            "--kind",
            "build",
            "--target",
            "product",
            "--reason",
            "resubmitting the revision that was already recorded once today",
            "--revision",
            &hundred,
            "--repository",
            &path,
        ],
    );
    assert_eq!(again.status.code(), Some(1), "{}", said(&again));
    assert!(
        said(&again).contains("carries no change at all"),
        "{}",
        said(&again)
    );
}
