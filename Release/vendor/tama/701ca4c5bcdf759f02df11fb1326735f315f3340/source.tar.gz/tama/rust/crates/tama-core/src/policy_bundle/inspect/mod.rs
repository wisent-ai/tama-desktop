//! What a candidate bundle contains, and every reason it would be refused.
//!
//! Split out of `policy_bundle.rs`, which had grown past the
//! three-hundred-line limit; copying an accepted bundle stays in the
//! module root.

use sha2::{Digest, Sha256};
use std::collections::HashSet;
use std::fs;
use std::path::Path;

use crate::catalog::build_catalog;
use crate::registry::Registry;
use crate::{err, Result};

use super::records::{SelectedFile, Selection};
use super::{file_mode, hex, sha256, POLICY_ROOTS, ROOT_METADATA};

pub(super) mod scan;
mod sources;

pub(super) use scan::{file_state, files_in_existing_bundle};

use scan::{ignored_top_level, walk_files};
use sources::{policy_source_relative, ExternalSourceManifest, HookReleaseManifest};

/// A digest of a file list separates its fields with a zero byte, so a name
/// ending where the next one begins cannot collide with it.
const FIELD_SEPARATOR: [u8; 1] = [0];

pub(super) fn inspect(source: &Path) -> Result<Selection> {
    let registry_path = source.join("shared-hooks/registry.json");
    let registry_metadata = fs::symlink_metadata(&registry_path).map_err(|_| {
        err(format!(
            "policy bundle has no shared-hooks/registry.json: {}",
            source.display()
        ))
    })?;
    if registry_metadata.file_type().is_symlink() || !registry_metadata.is_file() {
        return Err(err(format!(
            "policy registry is not a regular file: {}",
            registry_path.display()
        )));
    }

    let registry: Registry = serde_json::from_slice(&fs::read(&registry_path)?)?;
    let mut rejections = Vec::new();
    let mut identifiers = HashSet::new();
    for (event, configuration) in &registry.events {
        for hook in &configuration.hooks {
            if hook.id.trim().is_empty() {
                rejections.push(format!("{event}: hook id is empty"));
            } else {
                identifiers.insert(hook.id.clone());
            }
        }
    }
    if identifiers.is_empty() {
        rejections.push("policy registry contains no hooks".to_string());
    }

    let mut files = Vec::new();
    for root in POLICY_ROOTS {
        let relative = Path::new(root);
        if source.join(relative).exists() {
            walk_files(source, relative, &mut files)?;
        }
    }
    for metadata in ROOT_METADATA {
        let path = source.join(metadata);
        if !path.exists() {
            continue;
        }
        let stat = fs::symlink_metadata(&path)?;
        if stat.file_type().is_symlink() || !stat.is_file() {
            return Err(err(format!(
                "bundle metadata is not a regular file: {}",
                path.display()
            )));
        }
        let bytes = fs::read(&path)?;
        files.push(SelectedFile {
            relative: metadata.to_string(),
            sha256: sha256(&bytes),
            mode: file_mode(&stat),
            bytes,
        });
    }
    files.sort_by(|left, right| left.relative.cmp(&right.relative));
    let external_mappings = if source.join("external-sources.json").exists() {
        let manifest: ExternalSourceManifest =
            serde_json::from_slice(&fs::read(source.join("external-sources.json"))?)?;
        if manifest.schema != "ai.wisent.tama.external-hook-sources.v1" {
            rejections.push("unsupported external-sources.json schema".to_string());
        }
        manifest.mappings
    } else {
        Vec::new()
    };
    if source.join("release.json").exists() {
        let release: HookReleaseManifest =
            serde_json::from_slice(&fs::read(source.join("release.json"))?)?;
        if release.schema != "ai.wisent.tama.hook-release.v1" {
            rejections.push("unsupported release.json schema".to_string());
        } else {
            let mut digest = Sha256::new();
            for file in files.iter().filter(|file| file.relative != "release.json") {
                digest.update((file.relative.len() as u64).to_be_bytes());
                digest.update(file.relative.as_bytes());
                digest.update(file.mode.to_be_bytes());
                digest.update((file.bytes.len() as u64).to_be_bytes());
                digest.update(&file.bytes);
            }
            let actual = hex(&digest.finalize());
            if actual != release.release_id {
                rejections.push(format!(
                    "release.json identity mismatch: expected {}, got {actual}",
                    release.release_id
                ));
            }
        }
    }
    let selected: HashSet<&str> = files.iter().map(|file| file.relative.as_str()).collect();

    match build_catalog(source) {
        Ok(catalog) => {
            for hook in &catalog.hooks {
                if hook.events.is_empty() {
                    rejections.push(format!("{}: no events", hook.id));
                }
            }
        }
        Err(error) => rejections.push(error.to_string()),
    }
    for (event, configuration) in &registry.events {
        for hook in &configuration.hooks {
            let declared = hook
                .source
                .as_deref()
                .filter(|value| !value.is_empty())
                .or(hook.command.as_deref());
            match declared.and_then(|value| {
                policy_source_relative(value, source, &external_mappings)
            }) {
                Some(relative) if selected.contains(relative.as_str()) => {}
                Some(relative) => rejections.push(format!(
                    "{} ({event}): source file is outside the supported bundle roots or missing: {relative}",
                    hook.id
                )),
                None => rejections.push(format!(
                    "{} ({event}): source path could not be mapped into the policy bundle",
                    hook.id
                )),
            }
        }
    }
    if let Some(agent_hooks) = registry
        .extra
        .get("catalog")
        .and_then(|catalog| catalog.get("agentHooks"))
        .and_then(serde_json::Value::as_array)
    {
        for hook in agent_hooks {
            let id = hook
                .get("id")
                .and_then(serde_json::Value::as_str)
                .unwrap_or("<catalog hook>");
            let declared = hook.get("source").and_then(serde_json::Value::as_str);
            match declared.and_then(|value| {
                policy_source_relative(value, source, &external_mappings)
            }) {
                Some(relative) if selected.contains(relative.as_str()) => {}
                Some(relative) => rejections.push(format!(
                    "{id} (catalog): source file is outside the supported bundle roots or missing: {relative}"
                )),
                None => rejections.push(format!(
                    "{id} (catalog): source path could not be mapped into the policy bundle"
                )),
            }
        }
    }
    if !rejections.is_empty() {
        return Err(err(rejections.join("; ")));
    }

    let mut digest = Sha256::new();
    for file in &files {
        digest.update(file.relative.as_bytes());
        digest.update(FIELD_SEPARATOR);
        digest.update(file.sha256.as_bytes());
        digest.update(FIELD_SEPARATOR);
        digest.update(file.mode.to_string().as_bytes());
        digest.update(FIELD_SEPARATOR);
    }
    Ok(Selection {
        files,
        digest: hex(&digest.finalize()),
        hook_count: identifiers.len(),
        ignored_paths: ignored_top_level(source)?,
    })
}
