//! The summary a proposal is read from: what failed, where the hook lives,
//! and the command that applies it.
//!
//! Split out of `doctor/repair.rs`, which had grown past the
//! three-hundred-line limit.

use crate::util::js_string;

/// `summaryText(report)`.
pub(super) fn summary_text(report: &serde_json::Value) -> String {
    let failures = report.get("failures").and_then(|v| v.as_array());
    let fail_lines: Vec<String> = match failures {
        Some(list) if !list.is_empty() => list
            .iter()
            .map(|failure| {
                format!(
                    "- {}: {}",
                    failure.get("kind").map(js_string).unwrap_or_default(),
                    failure.get("detail").map(js_string).unwrap_or_default()
                )
            })
            .collect(),
        _ => vec!["- none".to_string()],
    };
    // `absent` is the word printed when the report does not carry the key.
    let render = |key: &str, absent: &str| {
        report
            .get(key)
            .filter(|v| !v.is_null())
            .map(js_string)
            .unwrap_or_else(|| absent.to_string())
    };
    let mut lines = vec![
        format!("# Repair proposal: {}", render("hookId", "undefined")),
        String::new(),
        format!("Live path: {}", render("livePath", "unknown")),
        format!("Archive path: {}", render("archivePath", "not archived")),
        format!("Corpus runs: {}", render("checked", "undefined")),
        String::new(),
        "## Validation failures".to_string(),
    ];
    lines.extend(fail_lines);
    lines.push(String::new());
    lines.push(format!(
        "Apply with: doctor apply {}",
        render("proposalDir", "undefined")
    ));
    lines.push(
        "Requires DEVICE_HOOK_EDIT_APPROVED set by the owner outside the session.".to_string(),
    );
    lines.push(String::new());
    lines.join("\n")
}
