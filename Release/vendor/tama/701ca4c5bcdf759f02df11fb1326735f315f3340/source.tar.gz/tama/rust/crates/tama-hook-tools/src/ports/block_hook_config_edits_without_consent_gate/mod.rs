//! Detection half of the consent guard (registry hook
//! `block-hook-config-edits-without-consent`): which paths count as hook
//! sources or configs, and which command text can reach them.
//!
//! The deliberate behaviour changes are listed in the sibling
//! `block_hook_config_edits_without_consent.rs`; `matches_protected` here is
//! the one that resolves a relative path under the payload's `cwd`.

use regex::Regex;
use serde_json::Value;

use super::block_hook_config_edits_without_consent::{recovery, writers, writes};
use super::block_hook_config_edits_without_consent_patterns::Patterns;
use super::pystr;
use super::python_stdlib::{join_under, one, shell_tokens};
use super::shell_text;

const CWD_KEY: &str = "cwd";
const EDITS_KEY: &str = "edits";
const TARGET_GROUP: &str = "target";
const PATH_KEYS: &[&str] = &["file_path", "path", "notebook_path"];
const PATCH_KEYS: &[&str] = &["input", "patch"];
/// Justification registries under `.shared-hooks/` are exempt: they are data
/// the authorization gates require an agent to write, so protecting them
/// deadlocks the gate that asks for them. The exemption is now a name shape
/// (`*justification.json`, `*justifications.json`) recognised in both the raw
/// and the cwd-resolved spelling, and the same paths are exempt inside command
/// text. Before that it was a two-entry list of absolute suffixes, so
/// `test_justifications.json` was refused, `cua_justifications.json` was
/// refused, and a relative spelling of either exempt file was refused too.
/// Quote and bracket noise stripped off a shell token before it is judged
/// (`token.strip()` with an explicit character set).
const TOKEN_TRIM: &[char] = &['"', '\'', '[', ']', '{', '}', ':', ','];
/// `git` options that consume the argument after them.
const GIT_VALUE_OPTIONS: &[&str] = &["-C", "--git-dir", "--work-tree", "-c"];
const GIT_SUBCOMMAND: &str = "config";
const GIT_CONFIG_KEY: &str = "core.hookspath";
const GIT_PROGRAM: &str = "git";

/// `execution_text` is truncated to this many characters (`[:250_000]`).
const MAX_EXECUTION_CHARS_TEXT: &str = "250000";

fn max_execution_chars() -> usize {
    MAX_EXECUTION_CHARS_TEXT.parse().unwrap_or_default()
}

/// Every string in the payload, in the order the Python's stack walk produced
/// them, joined and truncated. Order is load-bearing: it decides both what
/// survives the truncation and what a regex can match across a newline join.
fn execution_text(payload: &Value) -> String {
    let mut strings: Vec<&str> = Vec::new();
    let mut stack: Vec<&Value> = vec![payload];
    while let Some(value) = stack.pop() {
        match value {
            Value::String(text) => strings.push(text),
            Value::Object(map) => stack.extend(map.values()),
            Value::Array(items) => stack.extend(items),
            _ => {}
        }
    }
    pystr::head_chars(&strings.join("\n"), max_execution_chars()).to_string()
}

pub struct Gate {
    patterns: Patterns,
    cwd: String,
}

impl Gate {
    pub fn new(payload: &Value) -> Self {
        let declared = payload
            .get(CWD_KEY)
            .and_then(Value::as_str)
            .unwrap_or_default();
        let cwd = if declared.is_empty() {
            std::env::current_dir()
                .unwrap_or_default()
                .to_string_lossy()
                .into_owned()
        } else {
            declared.to_string()
        };
        Self {
            patterns: Patterns::compile(),
            cwd,
        }
    }

    /// The fix: the Python matched the raw text, so `shared-hooks/x.py` typed
    /// from the repository root walked past a gate that caught the absolute
    /// spelling of the same file. A candidate is protected if its text matches
    /// or if the place it resolves to does.
    fn matches_protected(&self, normalized: &str) -> bool {
        self.patterns.protected_path.is_match(normalized)
            || self
                .patterns
                .protected_path
                .is_match(&join_under(&self.cwd, normalized))
    }

    /// A registry is exempt however it is spelled: the raw text, or the place
    /// it resolves to under the payload's `cwd`.
    fn justification_registry(&self, normalized: &str) -> bool {
        self.patterns
            .justification_registry_path
            .is_match(normalized)
            || self
                .patterns
                .justification_registry_path
                .is_match(&join_under(&self.cwd, normalized))
    }

    pub fn protected_path(&self, path: &str) -> bool {
        let normalized = path.replace('\\', "/");
        if self.justification_registry(&normalized) {
            return false;
        }
        self.matches_protected(&normalized)
    }

    pub fn git_config_path(&self, path: &str) -> bool {
        let normalized = path.replace('\\', "/");
        self.patterns.git_config_path.is_match(&normalized)
            || self
                .patterns
                .git_config_path
                .is_match(&join_under(&self.cwd, &normalized))
    }

    /// The whole-text match is taken after every justification-registry path is
    /// removed, so a shell write to one of those files is not refused merely
    /// because `.shared-hooks/` appears in the command. Every other mention of
    /// a protected directory still matches, and the token scan below judges
    /// each argument on its own.
    pub fn command_mentions_protected_path(&self, command: &str) -> bool {
        let normalized = command.replace('\\', "/");
        let scrubbed = self
            .patterns
            .justification_registry_in_command
            .replace_all(&normalized, " ");
        if self.patterns.protected_path.is_match(&scrubbed) {
            return true;
        }
        self.patterns
            .command_token_split
            .split(&normalized)
            .any(|token| {
                let stripped = token.trim_matches(TOKEN_TRIM);
                !stripped.is_empty() && self.protected_path(stripped)
            })
    }

    /// `git [-c x] [-C dir] … config … core.hooksPath`, per command. The cut
    /// is quote-aware, so a sentence that quotes the setting is text.
    fn git_configures_hookspath(&self, command: &str) -> bool {
        for segment in shell_text::commands(command) {
            let tokens = shell_tokens(segment);
            for (index, token) in tokens.iter().enumerate() {
                if token != GIT_PROGRAM {
                    continue;
                }
                let mut cursor = index + one();
                while cursor < tokens.len() && tokens[cursor].starts_with('-') {
                    let option = tokens[cursor].as_str();
                    cursor += one();
                    if GIT_VALUE_OPTIONS.contains(&option) && cursor < tokens.len() {
                        cursor += one();
                    }
                }
                if cursor < tokens.len()
                    && tokens[cursor] == GIT_SUBCOMMAND
                    && tokens[cursor + one()..]
                        .iter()
                        .any(|item| item.to_lowercase() == GIT_CONFIG_KEY)
                {
                    return true;
                }
            }
        }
        false
    }

    /// Which hook-configuration writer this call runs, if it runs one. The
    /// test below reads the text for a path and a write; a tool that writes
    /// hook configuration by itself shows neither.
    pub fn execution_runs_hook_config_writer(&self, payload: &Value) -> Option<&'static str> {
        let text = execution_text(payload).replace('\\', "/");
        match text.is_empty() {
            true => None,
            false => writers::runs_hook_config_writer(&text),
        }
    }

    pub fn execution_targets_hook_modification(&self, payload: &Value) -> bool {
        let text = execution_text(payload).replace('\\', "/");
        if text.is_empty() {
            return false;
        }
        if self.patterns.git_hookspath.is_match(&text) || self.git_configures_hookspath(&text) {
            return true;
        }
        self.command_mentions_protected_path(&text)
            && (writes::writes_to_protected_path(&self.patterns, &text, &|path| {
                self.protected_path(path)
            }) || self.patterns.opaque_patch.is_match(&text))
    }

    /// Whether a write tool aims at one of the operator's break-glass files.
    pub fn operator_recovery_write_target(&self, input: &Value) -> bool {
        let mut paths: Vec<String> = Vec::new();
        self.candidate_paths(input, &mut paths);
        recovery::write_tool_target(&self.patterns, &paths)
    }

    /// Whether an execution payload drives one of the break-glass controls.
    pub fn operator_recovery_execution_target(&self, payload: &Value) -> bool {
        recovery::execution_target(&self.patterns, &execution_text(payload))
    }

    fn captured(pattern: &Regex, line: &str) -> Option<String> {
        pattern.captures(line).and_then(|caps| {
            caps.name(TARGET_GROUP)
                .map(|found| found.as_str().to_string())
        })
    }

    /// Paths named by a patch body: hashline headers, `*** Add File:` headers
    /// and unified-diff headers. The hashline target is taken unstripped, the
    /// other two stripped — exactly as the Python does.
    fn patch_candidate_paths(&self, text: &str, found: &mut Vec<String>) {
        for raw_line in pystr::splitlines(text) {
            let line = pystr::strip(raw_line);
            if let Some(target) = Self::captured(&self.patterns.patch_bracket, line) {
                found.push(target);
                continue;
            }
            if let Some(target) = Self::captured(&self.patterns.patch_file_header, line) {
                found.push(pystr::strip(&target).to_string());
                continue;
            }
            if let Some(target) = Self::captured(&self.patterns.patch_diff_header, line) {
                found.push(pystr::strip(&target).to_string());
            }
        }
    }

    pub fn candidate_paths(&self, value: &Value, found: &mut Vec<String>) {
        match value {
            Value::String(text) => found.push(text.clone()),
            Value::Object(map) => {
                for key in PATH_KEYS {
                    if let Some(Value::String(text)) = map.get(*key) {
                        found.push(text.clone());
                    }
                }
                for key in PATCH_KEYS {
                    if let Some(Value::String(text)) = map.get(*key) {
                        self.patch_candidate_paths(text, found);
                    }
                }
                if let Some(Value::Array(edits)) = map.get(EDITS_KEY) {
                    for edit in edits {
                        self.candidate_paths(edit, found);
                    }
                }
            }
            Value::Array(items) => {
                for item in items {
                    self.candidate_paths(item, found);
                }
            }
            _ => {}
        }
    }
}
