//! Session overrides and publication: reading `<controlKey>.override.json`,
//! deciding per-hook enablement, and publishing the session snapshot.

use std::collections::HashSet;
use std::io;

use serde_json::{json, Value};

use super::context::{numeric_environment, process_is_alive, session_resume_argv, SessionContext};
use super::paths::{emergency_state_path, session_control_root};
use super::store::{atomic_write_json, hooks_globally_disabled, load_json};
use super::{DEFAULT_HEARTBEAT_TTL_SECONDS, EMERGENCY_STATE_SCHEMA, SESSION_CONTROL_SCHEMA};
use crate::jsutil;
use crate::session_capability::{normalized_capability, CapabilityIdentity};

/// `cleanHookIds`: stringify + trim, drop empties and unknown ids, dedupe,
/// sort (byte order, matching JS default sort for ASCII).
fn clean_hook_ids(value: Option<&Value>, known_hook_ids: Option<&HashSet<String>>) -> Vec<String> {
    let mut out: Vec<String> = Vec::new();
    if let Some(Value::Array(items)) = value {
        for id in items {
            let s = jsutil::trim_js(&jsutil::js_to_string(id)).to_string();
            if !s.is_empty() && known_hook_ids.is_none_or(|k| k.contains(&s)) && !out.contains(&s) {
                out.push(s);
            }
        }
    }
    out.sort();
    out
}

/// Result of `readSessionOverride`.
#[derive(Debug, Clone, Default)]
pub struct SessionOverride {
    pub enabled_hook_ids: Vec<String>,
    pub capability: Option<Value>,
}

/// Port of `readSessionOverride`: schema/agent/session/key must all match,
/// otherwise the empty override is returned.
pub fn read_session_override(
    context: Option<&SessionContext>,
    known_hook_ids: Option<&HashSet<String>>,
) -> SessionOverride {
    let empty = SessionOverride::default();
    let Some(ctx) = context else {
        return empty;
    };
    let path = session_control_root().join(format!("{}.override.json", ctx.control_key));
    let value = load_json(&path);
    let valid = value.get("schema").and_then(Value::as_str) == Some(SESSION_CONTROL_SCHEMA)
        && value.get("agentId").and_then(Value::as_str) == Some(ctx.agent_id.as_str())
        && value.get("sessionId").and_then(Value::as_str) == Some(ctx.session_id.as_str())
        && value.get("controlKey").and_then(Value::as_str) == Some(ctx.control_key.as_str());
    if !valid {
        return empty;
    }
    let emergency = load_json(&emergency_state_path());
    if emergency.get("schema").and_then(Value::as_str) == Some(EMERGENCY_STATE_SCHEMA)
        && emergency.get("disabled") == Some(&Value::Bool(true))
    {
        let generation = emergency
            .get("changedAt")
            .and_then(Value::as_str)
            .filter(|value| !value.trim().is_empty());
        if generation.is_none()
            || value.get("emergencyChangedAt").and_then(Value::as_str) != generation
        {
            return empty;
        }
    }
    SessionOverride {
        enabled_hook_ids: clean_hook_ids(value.get("enabledHookIds"), known_hook_ids),
        capability: normalized_capability(
            value.get("capability").unwrap_or(&Value::Null),
            &ctx.session_id,
            jsutil::now_millis(),
            &CapabilityIdentity::default(),
        ),
    }
}

/// Port of `isSessionHookEnabled`.
pub fn is_session_hook_enabled(
    context: Option<&SessionContext>,
    hook_id: &str,
    known_hook_ids: Option<&HashSet<String>>,
) -> bool {
    if !hooks_globally_disabled() {
        return true;
    }
    read_session_override(context, known_hook_ids)
        .enabled_hook_ids
        .iter()
        .any(|id| id == hook_id)
}

/// Port of `publishSession`: snapshot the session state, atomically write
/// `<sessionControlRoot>/<controlKey>.session.json`, return the state.
/// IO errors propagate (`Err`), as the JS `*Sync` calls throw.
pub fn publish_session(
    context: Option<&SessionContext>,
    known_hook_ids: Option<&HashSet<String>>,
    payload: Option<&Value>,
) -> io::Result<Option<Value>> {
    let Some(ctx) = context else {
        return Ok(None);
    };
    let overrides = read_session_override(Some(ctx), known_hook_ids);
    let owner_pid = numeric_environment("TAMA_SESSION_OWNER_PID");
    let has_live_owner = owner_pid.is_some_and(process_is_alive);
    let heartbeat_ttl_seconds = numeric_environment("TAMA_SESSION_HEARTBEAT_TTL_SECONDS")
        .unwrap_or(DEFAULT_HEARTBEAT_TTL_SECONDS);
    let resume_argv = session_resume_argv(payload);

    let mut state = json!({
        "schema": SESSION_CONTROL_SCHEMA,
        "agentId": ctx.agent_id,
        "sessionId": ctx.session_id,
        "controlKey": ctx.control_key,
        "pid": if has_live_owner { owner_pid.unwrap_or(0) } else { 0 },
        "cwd": ctx.cwd,
        "livenessMode": if has_live_owner { "process" } else { "heartbeat" },
        "heartbeatTTLSeconds": heartbeat_ttl_seconds,
        "globallyDisabled": hooks_globally_disabled(),
        "disabledHookIds": [],
        "enabledHookIds": overrides.enabled_hook_ids,
        "capability": overrides.capability,
        "updatedAt": jsutil::to_iso_string(jsutil::now_millis()),
    });
    if let Some(p) = payload {
        if let Some(sr) = p.get("semantic_runtime") {
            if jsutil::js_truthy(Some(sr)) {
                state["semanticRuntime"] = sr.clone();
            }
        }
        if let Some(sp) = p.get("system_policy") {
            if sp.is_object() {
                state["systemPolicy"] = sp.clone();
            }
        }
    }
    if let Some(r) = resume_argv {
        state["resumeArgv"] = json!(r);
    }

    let path = session_control_root().join(format!("{}.session.json", ctx.control_key));
    atomic_write_json(&path, &state)?;
    Ok(Some(state))
}
