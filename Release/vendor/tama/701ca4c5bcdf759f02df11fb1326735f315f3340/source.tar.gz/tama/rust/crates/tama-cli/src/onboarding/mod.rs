//! The `tama onboarding` first-use walkthrough, split into focused parts:
//! `definition` (journey JSON validation), `screens` (navigation/rendering),
//! and `state` (persistence). This root keeps the shared identity constants
//! and the `run` entry point.

mod definition;
mod screens;
mod state;

use serde_json::{json, Value};
use std::fs;
use std::io::ErrorKind;
use std::path::Path;
use tama_core::policy_bundle::PolicyBundleImportResult;

use definition::canonical_definition;
use screens::{evidence_satisfied, next_screen_id, render, screen_by_id};
use state::{load_or_start_state, save_state, state_path};

const PRODUCT_ID: &str = "tama-cli";
const JOURNEY_ID: &str = "first-use";
const JOURNEY_VERSION: &str = "2026-09-03.2";
const FIRST_SUCCESS_FACT: &str = "hook_catalog_listed";
const STATE_SCHEMA: &str = "tama-cli.onboarding-state.v1";

pub fn run(
    root: &Path,
    reset: bool,
    imported: Option<&PolicyBundleImportResult>,
) -> Result<(), String> {
    let definition = canonical_definition()?;
    let path = state_path();

    if reset {
        match fs::remove_file(&path) {
            Ok(()) => {}
            Err(error) if error.kind() == ErrorKind::NotFound => {}
            Err(error) => {
                return Err(format!(
                    "could not reset Tama onboarding state {}: {error}",
                    path.display()
                ));
            }
        }
        println!(
            "Tama first-use journey reset: recorded progress and evidence discarded; showing it again now."
        );
        println!();
    }

    let mut state = load_or_start_state(&definition, &path)?;
    if let Some(imported) = imported {
        let object = state
            .as_object_mut()
            .ok_or_else(|| "Tama onboarding state is not an object".to_string())?;
        let evidence = object
            .entry("evidence")
            .or_insert_with(|| json!({}))
            .as_object_mut()
            .ok_or_else(|| "Tama onboarding evidence is not an object".to_string())?;
        evidence.insert("policy_bundle_imported".to_string(), Value::Bool(true));
        object.insert(
            "policy_bundle".to_string(),
            json!({
                "sourcePath": imported.source_path,
                "sourceDigest": imported.source_digest,
                "bundlePath": imported.bundle_path,
                "activation": "inactive"
            }),
        );
        save_state(&path, &state)?;
    }
    if state.get("status").and_then(Value::as_str) == Some("completed") {
        println!(
            "Tama first-use journey is already complete: a hook catalog was read successfully."
        );
        println!("Run `tama onboarding --reset` to show the walkthrough again.");
        return Ok(());
    }

    loop {
        let screen_id = state
            .get("current_screen_id")
            .and_then(Value::as_str)
            .ok_or_else(|| "Tama onboarding state has no current screen; use --reset".to_string())?
            .to_string();
        let screen = screen_by_id(&definition, &screen_id)?.clone();
        render(&screen)?;

        let Some(next) = next_screen_id(&screen)? else {
            println!();
            let hook_count = crate::cli::commands::list_hooks(root, false)
                .map_err(|error| format!("Tama could not read its hook catalog: {error}"))?;
            if hook_count == 0 {
                return Err(
                    "Tama read the catalog but found no hooks; onboarding remains in progress"
                        .to_string(),
                );
            }

            if !evidence_satisfied(&screen, FIRST_SUCCESS_FACT)? {
                return Err("Tama onboarding first-success evidence is invalid".to_string());
            }
            let object = state
                .as_object_mut()
                .ok_or_else(|| "Tama onboarding state is not an object".to_string())?;
            object.insert("status".to_string(), Value::String("completed".to_string()));
            let evidence = object
                .entry("evidence")
                .or_insert_with(|| json!({}))
                .as_object_mut()
                .ok_or_else(|| "Tama onboarding evidence is not an object".to_string())?;
            evidence.insert(FIRST_SUCCESS_FACT.to_string(), Value::Bool(true));
            object.insert("hook_count".to_string(), json!(hook_count));
            save_state(&path, &state)?;

            println!();
            println!(
                "First-use complete: Tama observed {FIRST_SUCCESS_FACT} from the {hook_count} hooks listed above."
            );
            return Ok(());
        };

        screen_by_id(&definition, &next)?;
        let object = state
            .as_object_mut()
            .ok_or_else(|| "Tama onboarding state is not an object".to_string())?;
        object.insert("current_screen_id".to_string(), Value::String(next));
        save_state(&path, &state)?;
        println!();
    }
}
