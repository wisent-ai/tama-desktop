//! One chat completion through Brama, with the bearer and nothing else.
//!
//! There used to be an agent HMAC here: a second vault item, a hex encoder,
//! an HMAC implementation and three `x-agent-*` headers. Brama's own
//! contract says a generic model call authorizes on the bearer alone, and
//! the signature only binds caller-scoped subscription operations, which
//! Tama does not make. Worse, the signed agent had to match the identity the
//! bearer resolves to, so signing as one product with another product's
//! token was a 403 waiting to happen. The token carries the identity now.

use std::io::Write;
use std::process::{Command, Stdio};

use serde_json::Value;

use super::credentials::{allowed_endpoint, read};

/// How much of a rejected response body is quoted back in the error.
fn error_body_chars() -> usize {
    "2000".parse().expect("valid error body limit")
}

/// Seconds curl may spend reaching Brama, unchanged from the reviewer's
/// original request: the gateway is either answering or it is not.
fn connect_seconds() -> u32 {
    "3".parse().expect("valid connect deadline")
}

fn curl_config_value(value: &str) -> String {
    let mut escaped = String::with_capacity(value.len());
    for character in value.chars() {
        match character {
            '\\' => escaped.push_str("\\\\"),
            '"' => escaped.push_str("\\\""),
            '\n' => escaped.push_str("\\n"),
            '\r' => escaped.push_str("\\r"),
            '\t' => escaped.push_str("\\t"),
            character => escaped.push(character),
        }
    }
    escaped
}

fn bounded(value: &str, limit: usize) -> String {
    let mut collapsed = value.split_whitespace().collect::<Vec<_>>().join(" ");
    if collapsed.chars().count() > limit {
        collapsed = collapsed.chars().take(limit).collect();
    }
    collapsed
}

/// One chat completion through Brama. `route` is a Brama route, not a
/// provider model name: Brama decides which provider answers it, and the
/// token's own `call:brama#<route>` grants decide whether this caller may
/// ask for it. `deadline` is the seconds the whole exchange may take, so a
/// caller waiting for a patch can wait longer than one waiting for a word.
pub fn chat(
    route: &str,
    system_prompt: &str,
    user_prompt: &str,
    max_tokens: u32,
    deadline: u32,
) -> Result<String, String> {
    let credentials = read()?;
    if !allowed_endpoint(&credentials.endpoint) {
        return Err(format!(
            "this client refuses the resolved Brama endpoint {}: a bearer is never posted in the \
             clear off loopback, and the path must be the chat completions path",
            credentials.endpoint
        ));
    }
    // Dynamic routes can resolve to models that reject explicit sampling options.
    // Leave temperature absent so Brama preserves the provider's supported default.
    let request = serde_json::json!({
        "model": route,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        "max_tokens": max_tokens,
    });
    let body = serde_json::to_string(&request).map_err(|_| "request serialization failed")?;
    let config = format!(
        "url = \"{}\"\nrequest = \"POST\"\nheader = \"Authorization: Bearer {}\"\nheader = \"Content-Type: application/json\"\nheader = \"Accept: application/json\"\ndata-binary = \"{}\"\nconnect-timeout = {}\nmax-time = {}\nsilent\nshow-error\nwrite-out = \"\\n%{{http_code}}\"\n",
        curl_config_value(&credentials.endpoint),
        curl_config_value(&credentials.bearer),
        curl_config_value(&body),
        connect_seconds(),
        deadline
    );
    let mut child = Command::new("/usr/bin/curl")
        .args(["--config", "-"])
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .map_err(|error| format!("cannot start Brama HTTP client: {error}"))?;
    child
        .stdin
        .take()
        .ok_or_else(|| "Brama HTTP client has no input pipe".to_string())?
        .write_all(config.as_bytes())
        .map_err(|error| format!("cannot write Brama request: {error}"))?;
    let output = child
        .wait_with_output()
        .map_err(|error| format!("Brama request did not complete: {error}"))?;
    if !output.status.success() {
        return Err(format!(
            "Brama request failed ({}): {}",
            output.status,
            String::from_utf8_lossy(&output.stderr).trim()
        ));
    }
    let response =
        String::from_utf8(output.stdout).map_err(|_| "Brama returned a non-text response")?;
    let (body, status) = response
        .rsplit_once('\n')
        .ok_or_else(|| "Brama response omitted its HTTP status".to_string())?;
    if status.trim() != "200" {
        return Err(format!(
            "Brama rejected the request from consumer {} with HTTP {}: {}",
            super::credentials::consumer(),
            status.trim(),
            bounded(body, error_body_chars())
        ));
    }
    let decoded: Value =
        serde_json::from_str(body).map_err(|_| "Brama returned invalid response JSON")?;
    Ok(decoded
        .pointer("/choices/0/message/content")
        .and_then(Value::as_str)
        .unwrap_or_default()
        .trim()
        .to_string())
}
