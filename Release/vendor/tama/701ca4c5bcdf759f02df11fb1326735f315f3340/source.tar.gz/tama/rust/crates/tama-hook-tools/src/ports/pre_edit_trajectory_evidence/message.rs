//! The refusals this gate prints, kept verbatim from the shell.
//!
//! They are long because each one has to be actionable on its own: the reader
//! is about to edit a trajectory and needs to know which registry field to
//! fill, what counts as a passing source, what counts as a failing one, and
//! which artifact paths are accepted. A short refusal here produced guesses.

pub(crate) const BYPASS: &str = "Bypass for one invocation: TRAJECTORY_EVIDENCE_DISABLED=1";

pub(crate) fn missing_justification(path: &str, words: usize) -> String {
    format!(
        "BLOCKED: trajectory/keeper/routine edit needs evidence-based justification.\n\n\
         Path: {path}\n\
         Word count: {words} (need 50+)\n\n\
         Add a 'trajectory_evidence_justification' field for this file in\n\
         ~/.claude/file_justifications.json with >= 50 words that cites BOTH:\n\
         \x20 - A PASSING/REFERENCE source: '.work/inst/chrome_<platform>_*.json'\n\
         \x20   (human-driven reference capture), or a passing trajectory inst file,\n\
         \x20   or 'keeper_completed' / 'status=completed' / 'li_at=yes', or an\n\
         \x20   account_action_logs row UUID closed completed.\n\
         \x20 - A NON-PASSING source: '.work/inst/<trajectory>_*.json' with the FAIL,\n\
         \x20   'failing run', 'FAIL', 'DETECTION', 'challengeUrl', 'status=failed',\n\
         \x20   'rejected', or 'silent kill' marker.\n\
         AND at least one concrete artifact path:\n\
         \x20 - .work/inst/<file>.json (byte-level network capture -- THE GROUND TRUTH)\n\
         \x20 - .work/runs/<file>.log (trajectory stdout)\n\
         \x20 - recordings/<id>.webm\n\
         \x20 - account_action_logs row <uuid8-prefix>\n\
         \x20 - commit <sha7>\n\n\
         The byte-level corpus at .work/inst/ (chrome refs + trajectory captures +\n\
         diff outputs) is the canonical evidence. Run the diff harness first:\n\
         scripts/debug/diff_trajectory.mjs <trajectory.mjs> writes a\n\
         .work/inst/diff_*.json with the explicit pass-vs-fail delta.\n\n\
         {BYPASS}"
    )
}

pub(crate) const MISSING_PASSING: &str = concat!(
    "BLOCKED: trajectory_evidence_justification missing PASSING/REFERENCE source (need one of: ",
    "'.work/inst/chrome_<platform>_*.json' human reference, 'passing run', 'keeper_completed', ",
    "'status=completed', 'li_at=yes', 'human reference', or a row UUID with completed status). ",
    "Bypass: TRAJECTORY_EVIDENCE_DISABLED=1",
);

pub(crate) const MISSING_FAILING: &str = concat!(
    "BLOCKED: trajectory_evidence_justification missing NON-PASSING source (need one of: ",
    "'.work/inst/<trajectory>_*.json' FAIL capture, 'failing run', 'FAIL', 'DETECTION', ",
    "'challengeUrl', 'status=failed', 'rejected', or 'silent kill'). ",
    "Bypass: TRAJECTORY_EVIDENCE_DISABLED=1",
);

pub(crate) const MISSING_ARTIFACT: &str = concat!(
    "BLOCKED: trajectory_evidence_justification missing concrete artifact path (need one of: ",
    "'.work/inst/<file>.json' byte-level capture, '.work/runs/<file>.log' trajectory log, ",
    "'recordings/<id>.webm', 'account_action_logs row <uuid8>', or 'commit <sha7>'). ",
    "Bypass: TRAJECTORY_EVIDENCE_DISABLED=1",
);
