//! `tama task scope`: what the operator's current instruction touches.
//!
//! The gate beside this file refuses a change to a repository the session
//! never said the instruction touches. This is where the session says it,
//! once per instruction: the task text is copied from Tama's own verbatim
//! capture of the operator's prompt, never retyped from memory, and the
//! declaration is bound to that prompt's digest so the next instruction
//! needs its own.

use std::io::Write;
use std::path::PathBuf;

use serde_json::json;

use crate::assignment;
use crate::ports::python_stdlib::expanduser;

use super::registers::{known_task, open_defect};
use super::{now_utc, TaskScope, SCOPE_HOME_RELATIVE};

const USAGE: &str = "usage: tama-cli task scope show|set|clear --session ID \
                     [--repository NAME]… [--defect ID] [--task ID] [--json]";
const USAGE_EXIT: i32 = 2;

/// `tama task scope …`.
pub fn cli_main(args: &[String]) -> i32 {
    let mut args = args.iter();
    if args.next().map(String::as_str) != Some("scope") {
        eprintln!("{USAGE}");
        return USAGE_EXIT;
    }
    let Some(verb) = args.next().map(String::as_str).map(str::to_owned) else {
        eprintln!("{USAGE}");
        return USAGE_EXIT;
    };
    let mut session: Option<String> = None;
    let mut repositories: Vec<String> = Vec::new();
    let mut defect: Option<String> = None;
    let mut task: Option<String> = None;
    let mut json = false;
    while let Some(argument) = args.next() {
        match argument.as_str() {
            "--session" => match args.next() {
                Some(value) if !value.starts_with("--") => session = Some(value.clone()),
                _ => {
                    eprintln!("{USAGE}");
                    return USAGE_EXIT;
                }
            },
            "--repository" => match args.next() {
                Some(value) if !value.starts_with("--") => repositories.push(value.clone()),
                _ => {
                    eprintln!("{USAGE}");
                    return USAGE_EXIT;
                }
            },
            "--defect" => match args.next() {
                Some(value) if !value.starts_with("--") => defect = Some(value.clone()),
                _ => {
                    eprintln!("{USAGE}");
                    return USAGE_EXIT;
                }
            },
            "--task" => match args.next() {
                Some(value) if !value.starts_with("--") => task = Some(value.clone()),
                _ => {
                    eprintln!("{USAGE}");
                    return USAGE_EXIT;
                }
            },
            "--json" => json = true,
            _ => {
                eprintln!("{USAGE}");
                return USAGE_EXIT;
            }
        }
    }
    let Some(session) = session else {
        eprintln!(
            "task scope requires --session ID: a scope belongs to one session's instruction, \
             and no other session's instruction stands in for it"
        );
        return USAGE_EXIT;
    };
    match verb.as_str() {
        "show" => show(&session, json),
        "set" => set(
            &session,
            &repositories,
            defect.as_ref(),
            task.as_ref(),
            json,
        ),
        "clear" => clear(&session),
        _ => {
            eprintln!("{USAGE}");
            USAGE_EXIT
        }
    }
}

fn scope_path(session: &str) -> PathBuf {
    PathBuf::from(expanduser("~"))
        .join(SCOPE_HOME_RELATIVE)
        .join(format!("{session}.json"))
}

fn show(session: &str, json: bool) -> i32 {
    let home = PathBuf::from(expanduser("~"));
    let Some(scope) = TaskScope::read(session, &home) else {
        eprintln!(
            "session {session} has declared no task scope; declare it with \
             `tama task scope set --session {session} --repository <NAME>`"
        );
        return 1;
    };
    let current = assignment::load(session)
        .ok()
        .flatten()
        .map(|instruction| instruction.turn_digest)
        .unwrap_or_default();
    let serves_current = !current.is_empty() && current == scope.turn_digest;
    // The binding the gate enforces has to be visible to whoever reads a
    // session's scope; otherwise a session can claim one entry and be
    // checked against another without anyone seeing it.
    let entry = match (scope.defect.trim(), scope.task_id.trim()) {
        ("", "") => "nothing — this scope authorises no change".to_string(),
        (defect, "") => format!("defect {defect}"),
        ("", task) => format!("task {task}"),
        (defect, task) => format!("defect {defect} and task {task}"),
    };
    if json {
        println!(
            "{}",
            json!({
                "session": session,
                "turn_digest": scope.turn_digest,
                "task": scope.task,
                "repositories": scope.repositories,
                "defect": scope.defect,
                "task_id": scope.task_id,
                "serves_current_instruction": serves_current,
            })
        );
        return 0;
    }
    println!("working  {entry}");
    println!("task     {}", scope.task.trim());
    println!("touches  {}", scope.repositories.join(", "));
    println!(
        "current  {}",
        if serves_current {
            "yes — this scope was declared for the instruction being served"
        } else {
            "no — the operator has spoken since; declare the scope of the new instruction"
        }
    );
    0
}

fn set(
    session: &str,
    repositories: &[String],
    defect: Option<&String>,
    task: Option<&String>,
    json: bool,
) -> i32 {
    if repositories.is_empty() {
        eprintln!(
            "task scope set requires at least one --repository: work that touches nothing \
             changes nothing"
        );
        return USAGE_EXIT;
    }
    if defect.is_none() && task.is_none() {
        eprintln!(
            "task scope set requires --defect <ID> or --task <ID>: every change belongs to a \
             defect in Oko's register or a task in its task register, and a change that belongs \
             to neither is the drift this gate exists to stop"
        );
        return USAGE_EXIT;
    }
    let defect = match defect.map(|id| open_defect(id)).transpose() {
        Ok(defect) => defect.unwrap_or_default(),
        Err(error) => {
            eprintln!("{error}");
            return 1;
        }
    };
    let task_id = match task.map(|id| known_task(id)).transpose() {
        Ok(task) => task.unwrap_or_default(),
        Err(error) => {
            eprintln!("{error}");
            return 1;
        }
    };
    let instruction = match assignment::load(session) {
        Ok(Some(instruction)) => instruction,
        Ok(None) => {
            eprintln!(
                "no operator instruction is recorded for session {session}, so there is nothing \
                 to declare a scope for; the capture hook records it when the operator writes"
            );
            return 1;
        }
        Err(error) => {
            eprintln!("cannot read the instruction for session {session}: {error}");
            return 1;
        }
    };
    let path = scope_path(session);
    if let Some(parent) = path.parent() {
        if let Err(error) = std::fs::create_dir_all(parent) {
            eprintln!("cannot create {}: {error}", parent.display());
            return 1;
        }
    }
    let document = json!({
        "session": session,
        "turn_digest": instruction.turn_digest,
        "task": instruction.text,
        "repositories": repositories,
        "defect": defect,
        "task_id": task_id,
        "declared_at": now_utc(),
    });
    let mut file = match std::fs::File::create(&path) {
        Ok(file) => file,
        Err(error) => {
            eprintln!("cannot write {}: {error}", path.display());
            return 1;
        }
    };
    if let Err(error) = writeln!(file, "{document}") {
        eprintln!("cannot write {}: {error}", path.display());
        return 1;
    }
    if json {
        println!("{document}");
        return 0;
    }
    println!(
        "task scope for session {session}: {} for {}",
        repositories.join(", "),
        match (defect.as_str(), task_id.as_str()) {
            ("", task) => format!("task {task}"),
            (defect, "") => format!("defect {defect}"),
            (defect, task) => format!("defect {defect} and task {task}"),
        }
    );
    println!("instruction: {}", instruction.text.trim());
    0
}

fn clear(session: &str) -> i32 {
    let path = scope_path(session);
    match std::fs::remove_file(&path) {
        Ok(()) => {
            println!("task scope cleared for session {session}");
            0
        }
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
            println!("session {session} had no task scope");
            0
        }
        Err(error) => {
            eprintln!("cannot remove {}: {error}", path.display());
            1
        }
    }
}
