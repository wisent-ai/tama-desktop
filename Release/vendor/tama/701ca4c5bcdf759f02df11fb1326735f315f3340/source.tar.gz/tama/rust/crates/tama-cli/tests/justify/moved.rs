//! `tama justify move`, through the real CLI: a justification follows the
//! file it justifies when the file moves.
//!
//! The registries are keyed by absolute path, so `git mv` leaves the entry
//! behind and the next write to the moved file is refused for want of one.
//! On 2026-09-18 four `sed -i` runs over the two registries renamed keys by
//! hand, each refused once by the consent gate first. A move is the product
//! surface for that edit, with the same read-back check `record` and
//! `remove` make.

use std::fs;
use std::path::{Path, PathBuf};
use std::process::{Command, Output};
use std::time::{SystemTime, UNIX_EPOCH};

use serde_json::Value;

/// A registry root of this test's own, inside the crate's build directory.
fn registry_root(label: &str) -> PathBuf {
    let unique = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .expect("clock before epoch")
        .as_nanos();
    let path = Path::new(env!("CARGO_TARGET_TMPDIR")).join(format!(
        "justify-move-{label}-{}-{unique}",
        std::process::id()
    ));
    fs::create_dir_all(path.join(".shared-hooks")).expect("create the registry root");
    path
}

/// Fifty words, which is what the registry requires of an entry.
fn justification(key: &str) -> String {
    format!(
        "The file {key} is recorded here so the move case can watch its entry travel: the \
         command must carry this exact text to the new key, leave the neighbouring entry where \
         it is, and refuse a move that would land on an entry somebody else recorded or start \
         from a path that has none. Nothing here is read by any gate outside this test."
    )
}

fn run(home: &Path, args: &[&str]) -> Output {
    Command::new(env!("CARGO_BIN_EXE_tama-cli"))
        .arg("justify")
        .args(args)
        .arg("--home")
        .arg(home)
        .output()
        .expect("run the justify command")
}

fn document(home: &Path) -> Value {
    let path = home.join(".shared-hooks").join("file_justifications.json");
    serde_json::from_str(&fs::read_to_string(path).expect("read the registry")).expect("valid JSON")
}

fn stderr(output: &Output) -> String {
    String::from_utf8_lossy(&output.stderr).trim().to_string()
}

#[test]
fn the_entry_follows_the_file_and_its_neighbour_stays() {
    let home = registry_root("follows");
    let old = "/private/tmp/tama-justify-move/zwiad/figures/overview.py";
    let new = "/private/tmp/tama-justify-move/zwiad/plots/overview.py";
    let neighbour = "/private/tmp/tama-justify-move/zwiad/figures/analysis.py";
    for key in [old, neighbour] {
        let recorded = run(
            &home,
            &[
                "record",
                "--file",
                key,
                "--justification",
                &justification(key),
            ],
        );
        assert!(recorded.status.success(), "{}", stderr(&recorded));
    }

    let moved = run(&home, &["move", "--file", old, "--to", new]);
    assert!(moved.status.success(), "{}", stderr(&moved));
    assert_eq!(
        String::from_utf8_lossy(&moved.stdout).trim(),
        format!("moved the file justification for {old} to {new}")
    );

    let registry = document(&home);
    let entries = registry.as_object().expect("a JSON object");
    assert!(entries.get(old).is_none(), "the old key is gone");
    assert_eq!(
        entries.get(new).map(|entry| &entry["justification"]),
        Some(&Value::String(justification(old))),
        "the entry travelled byte for byte"
    );
    assert_eq!(
        entries.get(neighbour).map(|entry| &entry["justification"]),
        Some(&Value::String(justification(neighbour))),
        "the neighbour is untouched"
    );
    assert_eq!(entries.len(), 2, "no entry was invented or lost");
    fs::remove_dir_all(&home).expect("remove the registry root");
}

#[test]
fn a_move_from_nothing_onto_an_entry_or_to_a_relative_path_is_refused() {
    let home = registry_root("refusals");
    let taken = "/private/tmp/tama-justify-move/taken.rs";
    let source = "/private/tmp/tama-justify-move/source.rs";
    for key in [taken, source] {
        let recorded = run(
            &home,
            &[
                "record",
                "--file",
                key,
                "--justification",
                &justification(key),
            ],
        );
        assert!(recorded.status.success(), "{}", stderr(&recorded));
    }
    let before = fs::read_to_string(home.join(".shared-hooks").join("file_justifications.json"))
        .expect("read the registry");

    let absent = run(
        &home,
        &[
            "move",
            "--file",
            "/private/tmp/tama-justify-move/none.rs",
            "--to",
            "/private/tmp/x.rs",
        ],
    );
    assert!(!absent.status.success());
    assert_eq!(
        stderr(&absent),
        "no justification is recorded for /private/tmp/tama-justify-move/none.rs"
    );

    let collision = run(&home, &["move", "--file", source, "--to", taken]);
    assert!(!collision.status.success());
    assert_eq!(
        stderr(&collision),
        format!("a justification is already recorded for {taken}; remove one of the two first")
    );

    let relative = run(
        &home,
        &["move", "--file", source, "--to", "plots/source.rs"],
    );
    assert!(!relative.status.success());
    assert_eq!(
        stderr(&relative),
        "the registry is keyed by absolute paths, and plots/source.rs is relative"
    );

    let missing_to = run(&home, &["move", "--file", source]);
    assert!(!missing_to.status.success());
    assert_eq!(
        stderr(&missing_to),
        "--to is required: the path the file now has"
    );

    let after = fs::read_to_string(home.join(".shared-hooks").join("file_justifications.json"))
        .expect("read the registry");
    assert_eq!(before, after, "a refusal writes nothing");
    fs::remove_dir_all(&home).expect("remove the registry root");
}
