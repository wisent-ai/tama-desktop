//! Logic for `tama-recall-after-compaction`, registry hook
//! `recall-after-compaction`: after a compaction, point the resuming agent at
//! the full transcript it just lost.
//!
//! The compaction summary is auto-generated and drops things: the failure this
//! hook exists for is a background process the agent launched before the
//! compaction and never mentioned again, because the summary did not carry it.
//!
//! The full text is written to a stable path and only a short pointer is
//! injected. `SessionStart` additional context is capped at ten thousand
//! characters and an oversize string is silently replaced by a file, so
//! fighting the cap would mean losing the text with no sign of it.

use std::path::{Path, PathBuf};
use std::process::Command;

use serde_json::{json, Value};
use tama_hooks::session_record::read_payload;

use crate::ports::python_stdlib::expanduser;
use crate::util::iso_now;

const SOURCE_KEY: &str = "source";
const SESSION_KEY: &str = "session_id";
const CWD_KEY: &str = "cwd";
const TRANSCRIPT_KEY: &str = "transcript_path";
const COMPACT_SOURCE: &str = "compact";
const RECALL_TOOL: &str = "~/.claude/scratch/recall_conversation.sh";
const RECALL_CWD_ENV: &str = "RECALL_CWD";
const DUMP_DIR: &str = "~/.shared-hooks/recall_dumps";
const LOG_PATH: &str = "~/.shared-hooks/recall_after_compaction.log";
const DUMP_SUFFIX: &str = ".txt";
const JSONL_SUFFIX: &str = ".jsonl";
const EVENT_NAME: &str = "SessionStart";

fn log(line: &str) {
    let path = PathBuf::from(expanduser(LOG_PATH));
    if let Some(parent) = path.parent() {
        let _ = std::fs::create_dir_all(parent);
    }
    let Ok(mut file) = std::fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(&path)
    else {
        return;
    };
    use std::io::Write;
    let _ = writeln!(file, "{} | {line}", iso_now());
}

/// The recall tool's own output for this session, if the tool is there.
fn recalled(uuid: &str, cwd: &str) -> String {
    let tool = PathBuf::from(expanduser(RECALL_TOOL));
    if !tool.is_file() {
        log(&format!("NO_RECALL_TOOL at {}", tool.display()));
        return String::new();
    }
    let mut command = Command::new(&tool);
    command.env(RECALL_CWD_ENV, cwd);
    // The tool takes a uuid or a basename, never an absolute path; with none
    // it picks the latest transcript for the working directory.
    if !uuid.is_empty() {
        command.arg(uuid);
    }
    let Ok(output) = command.output() else {
        return String::new();
    };
    String::from_utf8_lossy(&output.stdout).to_string()
}

/// `basename "$TRANSCRIPT" .jsonl`.
fn uuid_of(transcript: &str) -> String {
    let path = Path::new(transcript);
    if !path.is_file() {
        return String::new();
    }
    path.file_name()
        .map(|name| name.to_string_lossy().to_string())
        .map(|name| name.trim_end_matches(JSONL_SUFFIX).to_string())
        .unwrap_or_default()
}

fn dump_path(session: &str) -> PathBuf {
    let dir = PathBuf::from(expanduser(DUMP_DIR));
    let _ = std::fs::create_dir_all(&dir);
    let stamp = iso_now().replace([':', '-', '.'], "");
    dir.join(format!("{session}_{stamp}{DUMP_SUFFIX}"))
}

/// The pointer injected into the resuming session.
pub fn pointer(source: &str, dump: &Path, chars: usize) -> String {
    format!(
        "# Pre-compaction transcript pointer (recall-after-compaction)\n\
         # Source JSONL: {source}\n\
         # Full text-only transcript: {}\n\
         # Total chars: {chars}\n\
         #\n\
         # The compaction summary you just received was auto-generated and may be\n\
         # wrong or incomplete. Read {} with the Read tool -- in full or\n\
         # in offset/limit slices for very large transcripts -- when you need\n\
         # pre-compaction context the summary lost (background jobs, prior\n\
         # decisions, user directives, exact tool outputs). Do not rely on the\n\
         # summary alone for any non-trivial recall.",
        dump.display(),
        dump.display(),
    )
}

pub fn run() {
    let payload = read_payload();
    let text = |key: &str| {
        payload
            .get(key)
            .and_then(Value::as_str)
            .unwrap_or_default()
            .to_string()
    };
    // Startup and a manual resume are no-ops: only a compaction loses context.
    if text(SOURCE_KEY) != COMPACT_SOURCE {
        return;
    }
    let session = text(SESSION_KEY);
    let cwd = text(CWD_KEY);
    let transcript = text(TRANSCRIPT_KEY);
    let uuid = uuid_of(&transcript);
    let body = recalled(&uuid, &cwd);
    if body.is_empty() {
        log(&format!("EMPTY_RECALL session={session} cwd={cwd}"));
        return;
    }
    let dump = dump_path(&session);
    if std::fs::write(&dump, &body).is_err() {
        log(&format!(
            "DUMP_FAILED session={session} at {}",
            dump.display()
        ));
        return;
    }
    let chars = body.chars().count();
    log(&format!(
        "RECALLED chars={chars} dump={} session={session}",
        dump.display()
    ));
    let source = match transcript.is_empty() {
        true => uuid,
        false => transcript,
    };
    let payload = json!({
        "hookSpecificOutput": {
            "hookEventName": EVENT_NAME,
            "additionalContext": pointer(&source, &dump, chars),
        }
    });
    println!("{payload}");
}

#[cfg(test)]
mod tests {
    use super::{pointer, uuid_of};

    /// The pointer has to fit the additional-context cap with room to spare,
    /// and it has to name the file and the reason to read it.
    #[test]
    fn the_pointer_is_short_and_names_the_dump() {
        let dump = std::path::Path::new("/Users/someone/.shared-hooks/recall_dumps/s_1.txt");
        let text = pointer("/transcripts/s.jsonl", dump, 1_234_567);
        assert!(text.contains("/Users/someone/.shared-hooks/recall_dumps/s_1.txt"));
        assert!(text.contains("/transcripts/s.jsonl"));
        assert!(text.contains("1234567"));
        assert!(text.len() < 10_000, "length {}", text.len());
    }

    #[test]
    fn a_missing_transcript_has_no_uuid() {
        assert_eq!(uuid_of("/nonexistent/s.jsonl"), "");
        assert_eq!(uuid_of(""), "");
    }
}
