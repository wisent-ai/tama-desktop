//! Session context: payload interpretation (ids, cwd, resume argv), env
//! parsing, process liveness, and the `sessionContext` port.

use std::env;

use serde_json::Value;

use crate::jsutil;
use crate::sha256::sha256_hex;

/// `/^[a-z][a-z0-9-]{0,31}$/` on the trimmed, lowercased input.
fn normalized_agent_id(value: &str) -> Option<String> {
    let id = jsutil::trim_js(value).to_lowercase();
    let b = id.as_bytes();
    if b.is_empty() || b.len() > 32 || !b[0].is_ascii_lowercase() {
        return None;
    }
    if !b[1..]
        .iter()
        .all(|&c| c.is_ascii_lowercase() || c.is_ascii_digit() || c == b'-')
    {
        return None;
    }
    Some(id)
}

/// `[payload, payload?.raw_event, payload?.session]` filtered to plain objects.
fn nested_values(payload: Option<&Value>) -> Vec<&Value> {
    let mut out = Vec::new();
    if let Some(p) = payload {
        if p.is_object() {
            out.push(p);
            for key in ["raw_event", "session"] {
                if let Some(v) = p.get(key) {
                    if v.is_object() {
                        out.push(v);
                    }
                }
            }
        }
    }
    out
}

/// First truthy value among `keys`, implementing the JS `a || b || c` chain
/// (falsy values — null, false, 0, "" — are skipped; empty arrays/objects are
/// truthy).
fn first_truthy<'a>(obj: &'a Value, keys: &[&str]) -> Option<&'a Value> {
    keys.iter()
        .map(|k| obj.get(*k))
        .find(|v| jsutil::js_truthy(*v))
        .flatten()
}

/// `normalizedResumeArgv`: a JSON-string form is parsed first; the result must
/// be a non-empty array of non-empty strings.
fn normalized_resume_argv(value: Option<&Value>) -> Option<Vec<String>> {
    match value {
        Some(Value::String(s)) => {
            normalized_resume_argv(serde_json::from_str::<Value>(s).ok().as_ref())
        }
        Some(Value::Array(items)) => {
            if items.is_empty()
                || !items
                    .iter()
                    .all(|i| i.as_str().is_some_and(|s| !s.is_empty()))
            {
                return None;
            }
            Some(
                items
                    .iter()
                    .map(|i| i.as_str().unwrap_or_default().to_string())
                    .collect(),
            )
        }
        _ => None,
    }
}

/// Port of `sessionResumeArgv`: resume argv from the payload (any nesting
/// level, snake/camel `resume`/`restart` spellings), else from
/// `TAMA_SESSION_RESUME_ARGV_JSON`.
pub fn session_resume_argv(payload: Option<&Value>) -> Option<Vec<String>> {
    for value in nested_values(payload) {
        let candidate = first_truthy(
            value,
            &["resume_argv", "resumeArgv", "restart_argv", "restartArgv"],
        );
        if let Some(normalized) = normalized_resume_argv(candidate) {
            return Some(normalized);
        }
    }
    let env_value = env::var("TAMA_SESSION_RESUME_ARGV_JSON")
        .ok()
        .map(Value::String);
    normalized_resume_argv(env_value.as_ref())
}

/// `[0-9a-f]{8}-…-[0-9a-f]{12}$` (case-insensitive) at the end of `name`.
fn match_trailing_uuid(name: &str) -> Option<String> {
    let tail = name.get(name.len().checked_sub(36)?..)?;
    let b = tail.as_bytes();
    for &dash in &[8usize, 13, 18, 23] {
        if b[dash] != b'-' {
            return None;
        }
    }
    for &(start, len) in &[(0usize, 8usize), (9, 4), (14, 4), (19, 4), (24, 12)] {
        if !b[start..start + len].iter().all(u8::is_ascii_hexdigit) {
            return None;
        }
    }
    Some(tail.to_string())
}

fn session_id_from_payload(payload: Option<&Value>) -> Option<String> {
    for value in nested_values(payload) {
        if let Some(explicit) = first_truthy(
            value,
            &[
                "session_id",
                "sessionId",
                "conversation_id",
                "conversationId",
                "thread_id",
                "threadId",
                "id",
            ],
        ) {
            return Some(jsutil::trim_js(&jsutil::js_to_string(explicit)).to_string());
        }
    }
    for value in nested_values(payload) {
        if let Some(transcript) = first_truthy(value, &["transcript_path", "transcriptPath"]) {
            let name = jsutil::js_basename(&jsutil::js_to_string(transcript));
            let name = name.strip_suffix(".jsonl").unwrap_or(&name);
            if let Some(m) = match_trailing_uuid(name) {
                return Some(m);
            }
        }
    }
    None
}

fn cwd_from_payload(payload: Option<&Value>) -> String {
    for value in nested_values(payload) {
        if let Some(cwd) = first_truthy(value, &["cwd", "project_dir", "projectDir"]) {
            return jsutil::js_to_string(cwd);
        }
    }
    env::current_dir()
        .map(|p| p.to_string_lossy().into_owned())
        .unwrap_or_default()
}

/// `Number(env || '')`, kept only when a positive safe integer.
pub(super) fn numeric_environment(name: &str) -> Option<i64> {
    let raw = env::var(name).unwrap_or_default();
    jsutil::js_safe_integer_positive(&raw)
}

/// `process.kill(pid, 0)`: alive on success or EPERM.
///
/// Implemented via the shell (`kill -0`) because only std is available; EPERM
/// is recognized from the error message.
pub(super) fn process_is_alive(pid: i64) -> bool {
    match std::process::Command::new("bash")
        .args(["-c", &format!("kill -0 {pid}")])
        .output()
    {
        Ok(o) if o.status.success() => true,
        Ok(o) => String::from_utf8_lossy(&o.stderr)
            .to_lowercase()
            .contains("operation not permitted"),
        Err(_) => false,
    }
}

/// Result of `sessionContext`.
#[derive(Debug, Clone)]
pub struct SessionContext {
    pub agent_id: String,
    pub session_id: String,
    pub control_key: String,
    pub cwd: String,
}

/// Port of `sessionContext`: both ids required, `controlKey` is
/// `sha256("${agentId}\0${sessionId}")` hex.
pub fn session_context(agent_id_value: &str, payload: Option<&Value>) -> Option<SessionContext> {
    let agent_id = normalized_agent_id(agent_id_value)?;
    let session_id = session_id_from_payload(payload)?;
    if agent_id.is_empty() || session_id.is_empty() {
        return None;
    }
    Some(SessionContext {
        control_key: sha256_hex(format!("{agent_id}\0{session_id}").as_bytes()),
        cwd: cwd_from_payload(payload),
        agent_id,
        session_id,
    })
}
