//! Reading a candidate bundle off disk: which files a policy root holds,
//! what the store already holds, and what neither of them accepts.
//!
//! Split out of `policy_bundle.rs`, which had grown past the
//! three-hundred-line limit.

use std::collections::HashSet;
use std::fs;
use std::path::Path;

use crate::{err, Result};

use super::super::records::SelectedFile;
use super::super::{file_mode, path_string, sha256, POLICY_ROOTS, ROOT_METADATA};

/// A path the store cannot copy back has no readable mode of its own.
const NO_MODE: u32 = 0;

pub(in crate::policy_bundle) fn walk_files(
    root: &Path,
    relative_root: &Path,
    output: &mut Vec<SelectedFile>,
) -> Result<()> {
    let start = root.join(relative_root);
    let metadata = fs::symlink_metadata(&start)?;
    if metadata.file_type().is_symlink() || !metadata.is_dir() {
        return Err(err(format!(
            "policy root is not a regular directory: {}",
            start.display()
        )));
    }
    let mut entries = fs::read_dir(&start)?.collect::<std::io::Result<Vec<_>>>()?;
    entries.sort_by_key(|entry| entry.file_name());
    for entry in entries {
        let relative = relative_root.join(entry.file_name());
        let path = entry.path();
        let metadata = fs::symlink_metadata(&path)?;
        if metadata.file_type().is_symlink() {
            return Err(err(format!(
                "policy bundle must not contain symlinks: {}",
                path.display()
            )));
        }
        if metadata.is_dir() {
            walk_files(root, &relative, output)?;
        } else if metadata.is_file() {
            let bytes = fs::read(&path)?;
            output.push(SelectedFile {
                relative: path_string(&relative),
                sha256: sha256(&bytes),
                mode: file_mode(&metadata),
                bytes,
            });
        } else {
            return Err(err(format!(
                "policy bundle contains an unsupported filesystem entry: {}",
                path.display()
            )));
        }
    }
    Ok(())
}

pub(in crate::policy_bundle) fn ignored_top_level(source: &Path) -> Result<Vec<String>> {
    let accepted: HashSet<&str> = POLICY_ROOTS
        .iter()
        .chain(ROOT_METADATA.iter())
        .copied()
        .collect();
    let mut ignored = Vec::new();
    let mut entries = fs::read_dir(source)?.collect::<std::io::Result<Vec<_>>>()?;
    entries.sort_by_key(|entry| entry.file_name());
    for entry in entries {
        let name = entry.file_name().to_string_lossy().to_string();
        if name == ".git" || accepted.contains(name.as_str()) {
            continue;
        }
        let suffix = if entry.file_type()?.is_dir() { "/" } else { "" };
        ignored.push(format!("{name}{suffix}"));
    }
    Ok(ignored)
}

pub(in crate::policy_bundle) fn file_state(path: &Path) -> Result<Option<(String, u32)>> {
    if !path.exists() {
        return Ok(None);
    }
    let metadata = fs::symlink_metadata(path)?;
    if metadata.file_type().is_symlink() || !metadata.is_file() {
        return Ok(Some(("unsupported".to_string(), NO_MODE)));
    }
    Ok(Some((sha256(&fs::read(path)?), file_mode(&metadata))))
}

pub(in crate::policy_bundle) fn files_in_existing_bundle(root: &Path) -> Result<Vec<String>> {
    if !root.exists() {
        return Ok(Vec::new());
    }
    let metadata = fs::symlink_metadata(root)?;
    if metadata.file_type().is_symlink() || !metadata.is_dir() {
        return Err(err(format!(
            "stored policy bundle is not a directory: {}",
            root.display()
        )));
    }
    let mut files = Vec::new();
    fn visit(root: &Path, current: &Path, output: &mut Vec<String>) -> Result<()> {
        let mut entries = fs::read_dir(current)?.collect::<std::io::Result<Vec<_>>>()?;
        entries.sort_by_key(|entry| entry.file_name());
        for entry in entries {
            let path = entry.path();
            let metadata = fs::symlink_metadata(&path)?;
            if metadata.file_type().is_symlink() {
                return Err(err(format!(
                    "stored policy bundle contains a symlink: {}",
                    path.display()
                )));
            }
            if metadata.is_dir() {
                visit(root, &path, output)?;
            } else if metadata.is_file() {
                output.push(path_string(path.strip_prefix(root)?));
            } else {
                return Err(err(format!(
                    "stored policy bundle contains an unsupported entry: {}",
                    path.display()
                )));
            }
        }
        Ok(())
    }
    visit(root, root, &mut files)?;
    files.sort();
    Ok(files)
}
