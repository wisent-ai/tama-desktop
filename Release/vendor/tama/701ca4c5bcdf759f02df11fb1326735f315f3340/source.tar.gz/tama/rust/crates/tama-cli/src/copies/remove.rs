//! Deleting the copies a pass judged removable, and deciding whether it may.
//!
//! Split from [`super::discovery`] when one file carrying both halves crossed
//! the three-hundred-line limit `block-oversized-files` enforces. The seam is
//! meaningful rather than arithmetic: everything here mutates the filesystem
//! or decides whether it may be mutated, and nothing here walks a tree or
//! asks git about a candidate.

use std::collections::BTreeSet;
use std::fs;
use std::path::Path;

use super::discovery::{list_document, Copy, ListDocument, Refusal, RemoveDocument};
use super::CommandError;
use crate::gitcmd::canonical;

/// Drops every `--except` copy from the pass before anything judges it: an
/// excepted copy that is dirty must not be able to refuse a pass it is not
/// part of. A value matching nothing is a usage error rather than a no-op,
/// because a pass the operator believed narrowed would otherwise remove
/// everything.
fn withhold(listed: &mut ListDocument, except: &[String]) -> Result<Vec<String>, CommandError> {
    if except.is_empty() {
        return Ok(Vec::new());
    }
    let mut excepted: BTreeSet<String> = BTreeSet::new();
    for wanted in except {
        let real = canonical(Path::new(wanted));
        let matched = listed
            .copies
            .iter()
            .any(|copy| canonical(Path::new(&copy.path)) == real);
        if !matched {
            return Err(CommandError::UnknownExcept(wanted.clone()));
        }
        excepted.insert(real.to_string_lossy().into_owned());
    }
    listed.copies.retain(|copy| {
        !excepted.contains(canonical(Path::new(&copy.path)).to_string_lossy().as_ref())
    });
    listed.copy_count = listed.copies.len();
    listed.bytes = listed.copies.iter().map(|copy| copy.bytes).sum();
    Ok(excepted.into_iter().collect())
}

/// Narrows the pass to exactly the paths `--only` names, and marks them as
/// named. A directory that is the sole checkout of its repository here is
/// refused by default because the pass cannot tell whether losing it loses
/// anything; an operator naming it answers exactly that question, and
/// nothing else — dirty, unpushed, origin-less and worktree-owning copies
/// are refused whether they were named or not.
fn narrow(listed: &mut ListDocument, only: &[String]) -> Result<(), CommandError> {
    if only.is_empty() {
        return Ok(());
    }
    let mut named: BTreeSet<String> = BTreeSet::new();
    for wanted in only {
        let real = canonical(Path::new(wanted));
        let matched = listed
            .copies
            .iter()
            .any(|copy| canonical(Path::new(&copy.path)) == real);
        if !matched {
            return Err(CommandError::UnknownOnly(wanted.clone()));
        }
        named.insert(real.to_string_lossy().into_owned());
    }
    listed.copies.retain_mut(|copy| {
        let hit = named.contains(canonical(Path::new(&copy.path)).to_string_lossy().as_ref());
        copy.named = hit;
        hit
    });
    listed.copy_count = listed.copies.len();
    listed.bytes = listed.copies.iter().map(|copy| copy.bytes).sum();
    Ok(())
}

/// The last checks before a directory is deleted, made against the
/// filesystem rather than the document: the reads behind that document are
/// minutes old by the time an operator types `--apply`.
fn remove_one(copy: &Copy, roots: &[String], force: bool) -> Result<(), CommandError> {
    let path = Path::new(&copy.path);
    let metadata = fs::symlink_metadata(path)
        .map_err(|error| CommandError::Operational(format!("{}: {error}", copy.path)))?;
    if metadata.file_type().is_symlink() {
        return Err(CommandError::Operational(format!(
            "{} is a symlink; this pass deletes directories, never links",
            copy.path
        )));
    }
    let real = canonical(path);
    if !roots
        .iter()
        .any(|root| real.starts_with(canonical(Path::new(root))))
    {
        return Err(CommandError::Operational(format!(
            "{} left the roots this pass was given",
            copy.path
        )));
    }
    if !force {
        crate::gitcmd::verify_repository(path).map_err(CommandError::Operational)?;
        if super::state::origin(path) != copy.origin
            || super::state::dirty(path).map_err(CommandError::Operational)?
            || super::state::owns_worktrees(path)
        {
            return Err(CommandError::Operational(format!(
                "{} changed after inventory; no further copy was removed",
                copy.path
            )));
        }
        let witness = copy
            .history_retained_by
            .as_deref()
            .or(copy.owner.as_deref());
        let (unpublished, retained) = super::state::history(path, witness, witness.into_iter())
            .map_err(CommandError::Operational)?;
        if (unpublished || copy.origin.is_none()) && retained.is_none() {
            return Err(CommandError::Operational(format!(
                "{} no longer has a Git history retention proof; no further copy was removed",
                copy.path
            )));
        }
    }
    fs::remove_dir_all(path)
        .map_err(|error| CommandError::Operational(format!("{}: {error}", copy.path)))
}

/// Plan the whole pass while every Git object store still exists. A shared
/// checkout must be revalidated and removed before its selected object provider.
fn removal_order(copies: &[Copy]) -> Result<Vec<&Copy>, CommandError> {
    let paths: Vec<_> = copies
        .iter()
        .map(|copy| canonical(Path::new(&copy.path)))
        .collect();
    let mut alternates = Vec::with_capacity(copies.len());
    for copy in copies {
        let counts = crate::gitcmd::git(Path::new(&copy.path), &["count-objects", "-v"])
            .map_err(CommandError::Operational)?;
        alternates.push(
            counts
                .lines()
                .filter_map(|line| line.strip_prefix("alternate: "))
                .map(|path| canonical(Path::new(path)))
                .collect::<Vec<_>>(),
        );
    }
    let mut remaining: Vec<_> = (0..copies.len()).collect();
    let mut ordered = Vec::with_capacity(copies.len());
    while !remaining.is_empty() {
        let position = remaining.iter().rposition(|&provider| {
            !remaining.iter().any(|&consumer| {
                consumer != provider
                    && (paths[consumer].starts_with(&paths[provider])
                        || alternates[consumer].iter()
                            .any(|objects| objects.starts_with(&paths[provider])))
            })
        }).ok_or_else(|| CommandError::Operational(
            "selected copies have cyclic directory or Git object-store dependencies; nothing was removed".into()
        ))?;
        ordered.push(&copies[remaining.remove(position)]);
    }
    Ok(ordered)
}

/// Every selected copy is checked before deletion begins. An unrestricted
/// pass must read the whole tree; `--only` inspects canonical repository
/// headers and the named subtrees, never unrelated subtrees.
pub(crate) fn remove_document(
    roots: &[String],
    except: &[String],
    only: &[String],
    apply: bool,
    force: bool,
) -> Result<RemoveDocument, CommandError> {
    let mut listed = list_document(roots, only)?;
    let excepted = withhold(&mut listed, except)?;
    narrow(&mut listed, only)?;
    let refused = refusals(&listed, force);
    let applied = apply && refused.is_empty() && listed.unreadable_directories.is_empty();
    let mut removed: Vec<String> = Vec::new();
    if applied {
        for copy in removal_order(&listed.copies)? {
            remove_one(copy, &listed.roots, force)?;
            removed.push(copy.path.clone());
        }
    }
    Ok(RemoveDocument {
        schema_version: listed.schema_version,
        roots: listed.roots,
        copies: listed.copies,
        copy_count: listed.copy_count,
        bytes: listed.bytes,
        linked_worktrees: listed.linked_worktrees,
        twins: listed.twins,
        unreadable: listed.unreadable,
        unreadable_directories: listed.unreadable_directories,
        excepted,
        applied,
        removed,
        refused,
    })
}
/// Every copy the pass would have to refuse, one sentence each. `--force`
/// refuses nothing, exactly as it does for worktrees.
fn refusals(document: &ListDocument, force: bool) -> Vec<Refusal> {
    if force {
        return Vec::new();
    }
    let mut refusals = Vec::new();
    for copy in &document.copies {
        // Ordered by what the operator has to act on first: work that exists
        // nowhere else, then an identity the pass could not establish, then
        // git records that deleting would orphan.
        let reason = if copy.inspection_error.is_some() {
            "unreadable-git-state"
        } else if copy.dirty == Some(true) {
            "uncommitted-changes"
        } else if copy.unpublished == Some(true) && copy.history_retained_by.is_none() {
            "commits-not-on-remote"
        } else if copy.origin.is_none() && copy.history_retained_by.is_none() {
            "no-origin-remote"
        } else if copy.owner.is_none() && !copy.named {
            "no-canonical-checkout"
        } else if copy.owns_worktrees {
            "owns-linked-worktrees"
        } else {
            continue;
        };
        refusals.push(Refusal {
            path: copy.path.clone(),
            reason,
        });
    }
    refusals
}
