//! Running one candidate against one payload: the spawn, and reading a block
//! verdict out of what it printed.
//!
//! Split out of `doctor/repair.rs`, which had grown past the
//! three-hundred-line limit.

use std::io::Write;
use std::process::{Command, Stdio};

/// What one candidate run produced.
pub struct SpawnOutcome {
    pub status: Option<i32>,
    pub signal: Option<String>,
    pub error: Option<String>,
    pub stdout: String,
    pub stderr: String,
}

/// Spawn with stdin input and wait for the answer. Nothing is killed at a
/// number of milliseconds: a candidate that is slow is reported by what it
/// costs, not replaced by a verdict it never gave.
pub fn spawn_sync_capture(program: &str, args: &[String], input: &str) -> SpawnOutcome {
    let spawned = Command::new(program)
        .args(args)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn();
    let mut child = match spawned {
        Ok(child) => child,
        Err(error) => {
            let code = match error.kind() {
                std::io::ErrorKind::NotFound => "ENOENT",
                std::io::ErrorKind::PermissionDenied => "EACCES",
                _ => "EIO",
            };
            return SpawnOutcome {
                status: None,
                signal: None,
                error: Some(format!("Error: spawnSync {} {}", program, code)),
                stdout: String::new(),
                stderr: String::new(),
            };
        }
    };
    if let Some(mut stdin) = child.stdin.take() {
        let input = input.to_string();
        std::thread::spawn(move || {
            let _ = stdin.write_all(input.as_bytes());
        });
    }
    if let Err(error) = child.wait() {
        return SpawnOutcome {
            status: None,
            signal: None,
            error: Some(format!("Error: {}", error)),
            stdout: String::new(),
            stderr: String::new(),
        };
    }
    let output = collect_output(&mut child);
    let status = child.try_wait().ok().flatten();
    let (code, signal) = match status {
        Some(exit) => decode_exit(exit),
        None => (None, None),
    };
    SpawnOutcome {
        status: code,
        signal,
        error: None,
        stdout: output.0,
        stderr: output.1,
    }
}

fn collect_output(child: &mut std::process::Child) -> (String, String) {
    use std::io::Read;
    let mut stdout = String::new();
    let mut stderr = String::new();
    if let Some(mut out) = child.stdout.take() {
        let _ = out.read_to_string(&mut stdout);
    }
    if let Some(mut err) = child.stderr.take() {
        let _ = err.read_to_string(&mut stderr);
    }
    (stdout, stderr)
}

fn decode_exit(exit: std::process::ExitStatus) -> (Option<i32>, Option<String>) {
    use std::os::unix::process::ExitStatusExt;
    if let Some(code) = exit.code() {
        return (Some(code), None);
    }
    (None, exit.signal().map(|sig| format!("SIG{}", sig)))
}

/// `blockVerdict(result)`.
pub(super) fn block_verdict(result: &SpawnOutcome) -> bool {
    for stream in [&result.stdout, &result.stderr] {
        let text = stream.trim();
        if text.is_empty() {
            continue;
        }
        let mut pieces = vec![text];
        pieces.extend(text.split('\n'));
        for piece in pieces {
            let line = piece.trim();
            if line.starts_with("BLOCKED:") {
                return true;
            }
            if !line.starts_with('{') {
                continue;
            }
            if let Ok(parsed) = serde_json::from_str::<serde_json::Value>(line) {
                if parsed.get("decision").and_then(|v| v.as_str()) == Some("block") {
                    return true;
                }
            }
        }
    }
    false
}
