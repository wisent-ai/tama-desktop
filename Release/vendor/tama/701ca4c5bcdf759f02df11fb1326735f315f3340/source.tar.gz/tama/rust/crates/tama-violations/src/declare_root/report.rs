//! What one root's inspection reports, where its declaration lives, and
//! the paragraph written above the entry.
//!
//! Split out of `declare_root/mod.rs`, which had grown past the
//! three-hundred-line limit.

use std::fs;
use std::path::{Path, PathBuf};

use serde::Serialize;

use super::table::FIXED_AT_ROOT;

/// The file a repository declares its audit exclusions in, and the older
/// root-level form the scan still reads.
const DECLARATION_DIR: &str = ".tama";
const DECLARATION_FILE: &str = "violations-ignore";
const LEGACY_DECLARATION: &str = ".tama-violations-ignore";
/// What a declaration of the repository root looks like in that file.
pub(super) const ROOT_ENTRY: &str = ".";

/// What one repository's root holds and what this command did about it.
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct RootReport {
    pub repo: String,
    /// Files at the root, with the tool that fixes each one there.
    pub fixed: Vec<FixedFile>,
    /// Files a person can move into a folder. While any of these are here,
    /// the root is not declared.
    pub movable: Vec<String>,
    /// Files nothing reads, left behind by Finder or Explorer. They are
    /// deleted rather than moved, and they block a declaration too.
    pub junk: Vec<String>,
    pub declared: bool,
    pub declaration: String,
    pub reason: String,
    /// Files this run removed from the root because nothing should read
    /// them there: Finder metadata, a build's own cache.
    #[serde(skip_serializing_if = "Vec::is_empty")]
    pub tidied: Vec<String>,
    /// The commit that carries the declaration, when one was made.
    #[serde(skip_serializing_if = "String::is_empty")]
    pub revision: String,
}

#[derive(Serialize)]
pub struct FixedFile {
    pub name: String,
    pub fixed_by: String,
}

pub(super) fn fixed_by(name: &str) -> Option<&'static str> {
    FIXED_AT_ROOT
        .iter()
        .find(|(known, _)| *known == name)
        .map(|(_, tool)| *tool)
}

/// The declaration file this repository uses, preferring the folded form
/// the write guard allows a full root to create.
pub(super) fn declaration_path(repo: &Path) -> PathBuf {
    let legacy = repo.join(LEGACY_DECLARATION);
    if legacy.is_file() {
        return legacy;
    }
    repo.join(DECLARATION_DIR).join(DECLARATION_FILE)
}

pub(super) fn already_declared(path: &Path) -> bool {
    fs::read_to_string(path)
        .map(|text| {
            text.lines()
                .any(|line| line.split('#').next().unwrap_or_default().trim() == ROOT_ENTRY)
        })
        .unwrap_or_default()
}

/// The paragraph written above the entry: every file, and who fixes it.
pub(super) fn declaration_text(fixed: &[FixedFile]) -> String {
    let mut lines = vec![
        String::new(),
        "# The repository root. Every file below is read from the root by the".to_string(),
        "# tool named beside it, so none of them can move into a folder and the".to_string(),
        "# five-files-per-folder rule cannot be met here. Written by".to_string(),
        "# `tama declare-root`, which refuses to write this while the root still".to_string(),
        "# holds a file somebody could move.".to_string(),
    ];
    for file in fixed {
        lines.push(format!("#   {} — {}", file.name, file.fixed_by));
    }
    lines.push(format!("{ROOT_ENTRY}\n"));
    lines.join("\n")
}

/// Whether the declaration file differs from what this repository's
/// history holds — untracked or modified, both of which `git status`
/// reports as a line of its own.
pub(super) fn uncommitted(repo: &Path, declaration: &Path) -> bool {
    let relative = declaration
        .strip_prefix(repo)
        .unwrap_or(declaration)
        .to_string_lossy()
        .into_owned();
    std::process::Command::new("git")
        .args(["status", "--porcelain", "--", &relative])
        .current_dir(repo)
        .output()
        .map(|output| !output.stdout.is_empty())
        .unwrap_or_default()
}
