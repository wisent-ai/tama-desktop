//! What a provider adapter config says, read from real files on disk.
//!
//! The operator's sentence was "wyglada na to ze mamy do czynienia z
//! bledem", and it covered two errors that printed as one word. The registry
//! spells every path with a home variable so the document can be installed
//! anywhere; the reader passed that text to the filesystem, so both provider
//! configs read as absent and the drift report refused with "adapter config
//! unreadable". The same word covered a registry that declares no adapter at
//! all, which is how every installed registry is stamped.
//!
//! Each case below writes real files, drives the real reader, and holds the
//! answer to the exact sentence a report prints, because that sentence is
//! what an operator acts on.

use std::fs;
use std::path::{Path, PathBuf};
use std::time::{SystemTime, UNIX_EPOCH};

use serde_json::json;
use tama_core::registry::Registry;
use tama_core::runtime::adapter_config::{
    adapter_command_index_result, expand_home_path, AdapterConfigProblem,
};
use tama_core::runtime::detect_runtime_install_drift;

const HOOK_ID: &str = "block-subagent-spawn";
const HOOK_COMMAND: &str = "$HOME/.local/bin/tama-block-subagent-spawn";
const EVENT: &str = "pre_tool_use:task";
const CLAUDE_MATCHER: &str = "Task";
const OTHER_HOOK_ID: &str = "block-browser-usage";
const UNINSTALLED_REASON: &str =
    "registry catalog declares this hook for the event but the runtime adapter does not install it";

/// Fixtures live under the crate's own `CARGO_TARGET_TMPDIR` inside
/// `target/`, never the OS temp directory this machine sweeps and never
/// `~/.stado/work`, which belongs to Stado: a fixture that vanishes mid-run
/// fails a test for a reason that has nothing to do with the reader.
fn scratch(label: &str) -> PathBuf {
    let nonce = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .expect("clock after epoch")
        .as_nanos();
    let thread = format!("{:?}", std::thread::current().id()).replace(['(', ')'], "-");
    let path = PathBuf::from(env!("CARGO_TARGET_TMPDIR"))
        .join(format!("tama-adapter-config-{label}-{thread}{nonce}"));
    fs::create_dir_all(&path).expect("create scratch root");
    path
}

fn home() -> String {
    std::env::var("HOME").expect("HOME is set")
}

/// A provider config in the shape the installer writes: one event block whose
/// hook command is the dispatcher carrying the hook id.
fn provider_config(hook_id: &str) -> serde_json::Value {
    json!({
        "hooks": {
            "PreToolUse": [{
                "matcher": CLAUDE_MATCHER,
                "hooks": [{
                    "type": "command",
                    "command": format!(
                        "env TAMA_ONLY_HOOK_ID='{hook_id}' node run-hook.mjs '{EVENT}' 'claude'"
                    ),
                }],
            }],
        },
    })
}

/// A registry root: `<root>/shared-hooks/registry.json`, with the adapter
/// paths written the way the caller asks for them.
fn registry_root(label: &str, claude_path: Option<&str>, codex_path: Option<&str>) -> PathBuf {
    let root = scratch(label);
    let shared = root.join("shared-hooks");
    fs::create_dir_all(&shared).expect("create shared-hooks");
    let mut adapters = serde_json::Map::new();
    if let Some(path) = claude_path {
        adapters.insert("claude".to_string(), json!({ "path": path }));
    }
    if let Some(path) = codex_path {
        adapters.insert("codex".to_string(), json!({ "path": path }));
    }
    let registry = json!({
        "adapters": adapters,
        "events": {
            EVENT: {
                "blocking": true,
                "hooks": [{ "id": HOOK_ID, "type": "command", "command": HOOK_COMMAND }],
            },
        },
    });
    fs::write(
        shared.join("registry.json"),
        serde_json::to_string_pretty(&registry).expect("registry json"),
    )
    .expect("write registry");
    root
}

fn registry_at(root: &Path) -> Registry {
    let text = fs::read_to_string(root.join("shared-hooks/registry.json")).expect("read registry");
    serde_json::from_str(&text).expect("parse registry")
}

/// The home-relative spelling of a path under the scratch root.
fn portable(path: &Path, prefix: &str) -> String {
    let text = path.to_string_lossy().into_owned();
    let home = home();
    let rest = text
        .strip_prefix(&home)
        .expect("fixture path is under the home directory")
        .trim_start_matches('/')
        .to_string();
    format!("{prefix}/{rest}")
}

fn write_config(path: &Path, hook_id: &str) {
    fs::write(
        path,
        serde_json::to_string_pretty(&provider_config(hook_id)).expect("config json"),
    )
    .expect("write config");
}

#[test]
fn a_home_variable_names_the_home_directory() {
    let home = home();
    assert_eq!(
        expand_home_path("$HOME/.claude/settings.json"),
        format!("{home}/.claude/settings.json")
    );
    assert_eq!(
        expand_home_path("${HOME}/.codex/hooks.json"),
        format!("{home}/.codex/hooks.json")
    );
    assert_eq!(
        expand_home_path("~/.claude/settings.json"),
        format!("{home}/.claude/settings.json")
    );
    assert_eq!(expand_home_path("$HOME"), home);
    assert_eq!(expand_home_path("/etc/hosts"), "/etc/hosts");
}

/// The defect itself: a config declared the portable way was never read, so
/// the reader answered that a present file was missing.
#[test]
fn a_config_declared_with_a_home_variable_is_read() {
    let fixtures = scratch("declared");
    let config_path = fixtures.join("settings.json");
    write_config(&config_path, HOOK_ID);
    let root = registry_root(
        "declared-registry",
        Some(&portable(&config_path, "$HOME")),
        None,
    );
    let index = adapter_command_index_result(&registry_at(&root), "claude")
        .expect("a declared config that exists is readable");
    let commands = index.get(EVENT).expect("the event the matcher names");
    assert!(
        commands
            .iter()
            .any(|command| command.contains(&format!("TAMA_ONLY_HOOK_ID='{HOOK_ID}'"))),
        "the indexed command carries the hook id: {commands:?}"
    );
}

#[test]
fn an_undeclared_adapter_is_named_as_undeclared() {
    let root = registry_root("undeclared", None, None);
    let problem =
        adapter_command_index_result(&registry_at(&root), "claude").expect_err("no path declared");
    assert!(matches!(problem, AdapterConfigProblem::Undeclared { .. }));
    assert_eq!(
        problem.reason(),
        "this registry declares no claude adapter path, so what that runtime installs was not \
         compared"
    );
}

#[test]
fn a_declared_path_with_nothing_behind_it_is_named_missing() {
    let fixtures = scratch("missing");
    let absent = fixtures.join("settings.json");
    let root = registry_root("missing-registry", Some(&portable(&absent, "$HOME")), None);
    let problem = adapter_command_index_result(&registry_at(&root), "claude")
        .expect_err("the declared file is absent");
    assert_eq!(
        problem.reason(),
        format!(
            "the claude adapter config declared at {} is not on this machine",
            absent.display()
        )
    );
}

#[test]
fn a_config_that_will_not_parse_is_named_unreadable() {
    let fixtures = scratch("unparsed");
    let config_path = fixtures.join("settings.json");
    fs::write(&config_path, "{ this is not json").expect("write config");
    let root = registry_root(
        "unparsed-registry",
        Some(&portable(&config_path, "${HOME}")),
        None,
    );
    let problem = adapter_command_index_result(&registry_at(&root), "claude")
        .expect_err("the declared file will not parse");
    let reason = problem.reason();
    assert!(
        reason.starts_with(&format!(
            "the claude adapter config at {} could not be read:",
            config_path.display()
        )),
        "the reason names the path and the cause: {reason}"
    );
}

/// An installed registry carries no adapter block at all. That is its normal
/// state, so the report says what it did not compare and does not refuse.
#[test]
fn an_installed_registry_without_adapters_does_not_refuse() {
    let root = registry_root("installed", None, None);
    let drift = detect_runtime_install_drift(&root).expect("drift report");
    assert!(
        drift.iter().all(|entry| !entry.material),
        "no entry is material: {drift:?}"
    );
    for runtime in ["claude", "codex"] {
        let entry = drift
            .iter()
            .find(|entry| entry.runtime == runtime && entry.hook_id.is_none())
            .unwrap_or_else(|| panic!("an adapter-level entry for {runtime}"));
        assert_eq!(
            entry.reason,
            format!(
                "this registry declares no {runtime} adapter path, so what that runtime installs \
                 was not compared"
            )
        );
    }
}

/// A declared config that really installs the catalogued hook leaves no
/// entry for it. Before the repair this state was indistinguishable from a
/// provider that installs nothing.
#[test]
fn a_config_that_installs_the_hook_leaves_no_drift() {
    let fixtures = scratch("installs");
    let claude = fixtures.join("settings.json");
    let codex = fixtures.join("hooks.json");
    write_config(&claude, HOOK_ID);
    write_config(&codex, HOOK_ID);
    let root = registry_root(
        "installs-registry",
        Some(&portable(&claude, "$HOME")),
        Some(&portable(&codex, "$HOME")),
    );
    let drift = detect_runtime_install_drift(&root).expect("drift report");
    assert!(
        drift.is_empty(),
        "a provider that installs the hook has no drift: {drift:?}"
    );
}

/// A declared config that installs some other hook is real drift, and it is
/// the state the check exists to catch.
#[test]
fn a_config_missing_the_hook_is_material_drift() {
    let fixtures = scratch("elsewhere");
    let claude = fixtures.join("settings.json");
    let codex = fixtures.join("hooks.json");
    write_config(&claude, OTHER_HOOK_ID);
    write_config(&codex, OTHER_HOOK_ID);
    let root = registry_root(
        "elsewhere-registry",
        Some(&portable(&claude, "$HOME")),
        Some(&portable(&codex, "$HOME")),
    );
    let drift = detect_runtime_install_drift(&root).expect("drift report");
    assert!(
        drift.iter().any(|entry| entry.material
            && entry.hook_id.as_deref() == Some(HOOK_ID)
            && entry.reason == UNINSTALLED_REASON),
        "the uninstalled hook is reported as material drift: {drift:?}"
    );
}
