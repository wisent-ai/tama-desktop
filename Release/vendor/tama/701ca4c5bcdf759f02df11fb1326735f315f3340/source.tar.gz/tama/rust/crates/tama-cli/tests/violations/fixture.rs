//! The throwaway checkout every violations test drives the real CLI against.
//!
//! Split out of `main.rs` when the hook-resolution cases arrived: the file
//! would have passed the repository's own three-hundred-line limit, which is
//! one of the two rules these tests defend.

use std::fs;
use std::path::{Path, PathBuf};
use std::process::{Command, Output};
use std::sync::atomic::{AtomicU64, Ordering};

pub const LIMIT: usize = 300;
static FIXTURE_SEQUENCE: AtomicU64 = AtomicU64::new(0);

pub struct Fixture {
    pub root: PathBuf,
    pub repo: PathBuf,
    pub tama: PathBuf,
}

impl Fixture {
    pub fn new() -> Self {
        let tama = Path::new(env!("CARGO_MANIFEST_DIR"))
            .ancestors()
            .nth(3)
            .unwrap()
            .to_path_buf();
        let evidence = tama.join(".wisent-output/violations");
        fs::create_dir_all(&evidence).unwrap();
        let root = evidence.join(format!(
            "{}-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos(),
            FIXTURE_SEQUENCE.fetch_add(1, Ordering::Relaxed)
        ));
        fs::create_dir(&root).unwrap();
        let repo = root.join("repo");
        fs::create_dir_all(&repo).unwrap();
        assert!(Command::new("git")
            .args(["init", "--quiet"])
            .arg(&repo)
            .status()
            .unwrap()
            .success());
        let revision = Command::new("git")
            .args(["rev-parse", "HEAD"])
            .current_dir(&tama)
            .output()
            .unwrap();
        fs::write(root.join("revision.txt"), revision.stdout).unwrap();
        Self { root, repo, tama }
    }

    pub fn run(&self, step: &str, command: &str, extra: &[&str]) -> Output {
        let mut process = Command::new(env!("CARGO_BIN_EXE_tama-cli"));
        process
            .args([command, "--repo"])
            .arg(&self.repo)
            .args(extra)
            .env("TAMA_ROOT", &self.tama)
            .env("TAMA_CLEAN_STATE_DIR", self.root.join("state"));
        self.record(step, process.output().unwrap())
    }

    /// The same command with the environment the caller states instead of
    /// this repository's own: the hook-resolution cases are about what the
    /// CLI finds when `TAMA_ROOT` and `HOME` hold no hook tree.
    pub fn run_in(
        &self,
        step: &str,
        command: &str,
        extra: &[&str],
        env: &[(&str, &Path)],
    ) -> Output {
        let mut process = Command::new(env!("CARGO_BIN_EXE_tama-cli"));
        process
            .args([command, "--repo"])
            .arg(&self.repo)
            .args(extra)
            .env("TAMA_CLEAN_STATE_DIR", self.root.join("state"));
        for (name, value) in env {
            process.env(name, value);
        }
        self.record(step, process.output().unwrap())
    }

    /// Every run leaves its stdout, stderr and exit status beside the
    /// fixture, so a failure is read from the run that produced it.
    fn record(&self, step: &str, out: Output) -> Output {
        fs::write(self.root.join(format!("{step}.stdout")), &out.stdout).unwrap();
        fs::write(self.root.join(format!("{step}.stderr")), &out.stderr).unwrap();
        fs::write(
            self.root.join(format!("{step}.exit")),
            format!("{:?}", out.status.code()),
        )
        .unwrap();
        out
    }
}

impl Drop for Fixture {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.repo);
    }
}
