//! Logic for `tama-block-supabase-cli`, registry hook `block-supabase-cli`:
//! the Supabase CLI is not invoked from an agent session.
//!
//! Only fields that can start a process are inspected, so documentation and
//! source that merely mention the command stay writable. Quoted prose is
//! dropped before the match — unless a shell wrapper or `ssh` is there to run
//! the quote, which is the one place a quoted string executes.
//!
//! The refusal names no exception on purpose: not a subcommand, not
//! `--help`, not a read-only query, not a local instance, not a session
//! capability. The owning repository and its reviewed deployment path are the
//! route.
//!
//! The shell printed the refusal on stdout and failed with `false`, so that
//! is kept: exit 1 with the three lines on stdout. The channel is part of
//! what the operator has been reading in his sessions.

use std::sync::LazyLock;

use regex::Regex;
use serde_json::Value;
use tama_hooks::session_record::read_payload;

use crate::ports::check_numeric_literals_payload::path_texts;
use crate::ports::pyvalue::first_truthy_py_str;
use crate::ports::transport_common as common;

use crate::ports::tool_vocabulary::{BASH_TOOLS, COMMAND_KEYS, EVAL_TOOLS, HUB_TOOLS, INPUT_KEYS};

const TOOL_KEYS: &[&str] = &["tool_name", "name"];
const PATH_KEY: &str = "path";
const OPERATION_KEYS: &[&str] = &["op", "action"];
const CODE_KEY: &str = "code";
const APPLICATION_KEY: &str = "application";
const ARGS_KEY: &str = "args";
const START_OPERATION: &str = "start";
const WRITE_TOOLS: &[&str] = &["write", "functions.write"];
const REFUSAL: &[&str] = &[
    "BLOCKED: Supabase CLI use is forbidden in agent sessions.",
    "Use the owning repository and its reviewed deployment path instead of invoking supabase \
     directly.",
    "This hook has no command, subcommand, read-only, local, help, version, or session-capability \
     exception.",
];
/// `false` in the shell.
const REFUSAL_STATUS_TEXT: &str = "1";

/// The device that routes a write into the JavaScript kernel: a payload aimed
/// there executes its text.
static REPL_DEVICE: LazyLock<Regex> =
    LazyLock::new(|| common::compile("^xd://mcp__node_repl_js($|[/_-])"));

/// A shell wrapper or `ssh`: the one place quoted text runs.
static RUNS_A_QUOTE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile("(^|[[:space:]])(ssh|(ba|z|d)?sh[[:space:]]+-[a-z]*c)([[:space:]]|$)")
});

static QUOTED: LazyLock<Regex> =
    LazyLock::new(|| common::compile("'[^']*'|[\\x22][^\\x22]*[\\x22]"));

/// The binary through a bare or absolute path, an environment prefix, a
/// package runner, a pipeline, a command list, a substitution, or a wrapped
/// shell command.
static SUPABASE_INVOCATION: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(^|[|;&`(\\x27\\x22]|&&|\\|\\||[[:space:]])",
        "([a-z_][a-z0-9_]*=[^[:space:]]*[[:space:]]+)*",
        "((npx|bunx|pnpm[[:space:]]+dlx|yarn[[:space:]]+dlx)[[:space:]]+(--[a-z-]+[[:space:]]+)*)?",
        "([^[:space:]|;&\\x22\\x27]*/)?supabase([[:space:]]|$)",
    ))
});

fn refusal_status() -> i32 {
    REFUSAL_STATUS_TEXT.parse().unwrap_or_default()
}

fn input_of(payload: &Value) -> Value {
    INPUT_KEYS
        .iter()
        .filter_map(|key| payload.get(*key))
        .find(|value| value.is_object())
        .cloned()
        .unwrap_or_else(|| Value::Object(Default::default()))
}

/// `[.. | strings] | join("\n")` over the tool input.
fn every_string(input: &Value) -> String {
    path_texts(input)
        .into_iter()
        .map(|(_, text)| text)
        .collect::<Vec<_>>()
        .join("\n")
}

/// `[.application, (.args // [])[]] | join(" ")`.
fn process_text(input: &Value) -> String {
    let mut parts: Vec<String> = Vec::new();
    if let Some(Value::String(application)) = input.get(APPLICATION_KEY) {
        parts.push(application.clone());
    }
    if let Some(Value::Array(args)) = input.get(ARGS_KEY) {
        for arg in args {
            if let Value::String(text) = arg {
                parts.push(text.clone());
            }
        }
    }
    parts.join(" ")
}

/// The part of this payload that can start a process, lowercased.
fn executable_text(payload: &Value) -> String {
    let tool = first_truthy_py_str(payload, TOOL_KEYS).to_lowercase();
    let input = input_of(payload);
    match tool.as_str() {
        found if BASH_TOOLS.contains(&found) => {
            first_truthy_py_str(&input, COMMAND_KEYS).to_lowercase()
        }
        found if EVAL_TOOLS.contains(&found) => {
            first_truthy_py_str(&input, &[CODE_KEY]).to_lowercase()
        }
        found if HUB_TOOLS.contains(&found) => {
            match first_truthy_py_str(&input, OPERATION_KEYS).to_lowercase() == START_OPERATION {
                true => process_text(&input).to_lowercase(),
                false => String::new(),
            }
        }
        found if WRITE_TOOLS.contains(&found) => {
            let path = first_truthy_py_str(&input, &[PATH_KEY]).to_lowercase();
            match REPL_DEVICE.is_match(&path) {
                true => every_string(&input).to_lowercase(),
                false => String::new(),
            }
        }
        _ => String::new(),
    }
}

/// Whether this payload invokes the Supabase CLI.
pub fn invokes_supabase(payload: &Value) -> bool {
    let text = executable_text(payload);
    if text.is_empty() {
        return false;
    }
    let judged = match RUNS_A_QUOTE.is_match(&text) {
        true => text,
        false => QUOTED.replace_all(&text, " ").into_owned(),
    };
    SUPABASE_INVOCATION.is_match(&judged)
}

pub fn run() {
    if invokes_supabase(&read_payload()) {
        for line in REFUSAL {
            println!("{line}");
        }
        std::process::exit(refusal_status());
    }
}

#[cfg(test)]
mod tests {
    use super::invokes_supabase;
    use serde_json::json;

    fn bash(command: &str) -> serde_json::Value {
        json!({ "tool_name": "bash", "tool_input": { "command": command } })
    }

    #[test]
    fn the_command_is_refused_however_it_is_reached() {
        for command in [
            "supabase db push",
            "npx supabase status",
            "SUPABASE_ACCESS_TOKEN=x supabase link",
            "/opt/homebrew/bin/supabase migration up",
            "true && supabase start",
            "echo hi | supabase db lint",
            "bunx --yes supabase db diff",
        ] {
            assert!(invokes_supabase(&bash(command)), "{command}");
        }
    }

    /// Prose that mentions the command changes nothing, so it stays writable.
    #[test]
    fn a_mention_in_quoted_prose_passes() {
        assert!(!invokes_supabase(&bash(
            "echo 'supabase is forbidden here'"
        )));
        assert!(!invokes_supabase(&json!({
            "tool_name": "write",
            "tool_input": { "path": "docs/deploy.md", "content": "run supabase db push" }
        })));
    }

    /// Unless a wrapper is there to run the quote.
    #[test]
    fn a_quote_a_shell_would_run_is_refused() {
        assert!(invokes_supabase(&bash("bash -lc 'supabase db push'")));
        assert!(invokes_supabase(&bash(
            "ssh host 'supabase functions deploy'"
        )));
    }

    #[test]
    fn a_supervised_process_and_a_kernel_write_are_read() {
        assert!(invokes_supabase(&json!({
            "tool_name": "hub",
            "tool_input": { "op": "start", "application": "supabase", "args": ["start"] }
        })));
        assert!(invokes_supabase(&json!({
            "tool_name": "write",
            "tool_input": {
                "path": "xd://mcp__node_repl_js",
                "content": "await $`supabase db push`"
            }
        })));
    }

    /// A word that merely begins with the name is not the binary.
    #[test]
    fn a_longer_name_is_not_the_command() {
        assert!(!invokes_supabase(&bash("supabasement --help")));
        assert!(!invokes_supabase(&bash("cat supabase-notes.md")));
    }
}
