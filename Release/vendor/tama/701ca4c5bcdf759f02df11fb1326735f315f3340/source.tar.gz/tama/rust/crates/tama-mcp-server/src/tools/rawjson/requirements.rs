//! Raw `justificationRequirements` loading and the JS-key-order `HookOut`
//! serializer, split out of `main.rs`.

use serde::ser::{SerializeSeq, SerializeStruct, Serializer};
use serde::Serialize;
use std::collections::HashMap;
use std::path::Path;

use super::{JParser, JVal};
use tama_core::catalog::CatalogHook;

/// Per-hook-id raw `justificationRequirements` arrays, recovered from
/// `shared-hooks/catalog-metadata.json` and `shared-hooks/registry.json` with
/// buildCatalog's merge priority. Missing/unparseable files yield an empty
/// map (callers then serialize the typed requirements instead).
pub fn load_raw_requirements(root: &Path) -> HashMap<String, Vec<JVal>> {
    let mut map: HashMap<String, Vec<JVal>> = HashMap::new();
    // docs.justificationRequirements (metadata wins, even when empty).
    if let Ok(text) =
        std::fs::read_to_string(root.join("shared-hooks").join("catalog-metadata.json"))
    {
        if let Some(JVal::Obj(entries)) = JParser::new(&text).value() {
            for (id, docs) in entries {
                if let Some(JVal::Arr(items)) = docs.get("justificationRequirements") {
                    map.insert(id, items.clone());
                }
            }
        }
    }
    // hook.justificationRequirements from the hook's first registry
    // occurrence (events in source order); absent/null means [].
    if let Ok(text) = std::fs::read_to_string(root.join("shared-hooks").join("registry.json")) {
        if let Some(registry) = JParser::new(&text).value() {
            if let Some(JVal::Obj(events)) = registry.get("events").cloned() {
                for (_, config) in events {
                    if let Some(hooks) = config.get("hooks").and_then(JVal::as_array) {
                        for hook in hooks {
                            let id = match hook.get("id").and_then(JVal::as_str) {
                                Some(id) => id.to_string(),
                                None => continue,
                            };
                            if map.contains_key(&id) {
                                continue;
                            }
                            let reqs = match hook.get("justificationRequirements") {
                                Some(JVal::Arr(items)) => items.clone(),
                                _ => Vec::new(),
                            };
                            map.insert(id, reqs);
                        }
                    }
                }
            }
        }
    }
    map
}

/// Serializes a [`CatalogHook`] in the JS object key order, with
/// `justificationRequirements` taken from the raw source JSON when available
/// (the typed struct is serialized otherwise).
pub struct HookOut<'a> {
    pub hook: &'a CatalogHook,
    pub raw_reqs: Option<&'a [JVal]>,
}

impl Serialize for HookOut<'_> {
    fn serialize<S: Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        let hook = self.hook;
        let mut st = serializer.serialize_struct("CatalogHook", 11)?;
        st.serialize_field("id", &hook.id)?;
        st.serialize_field("type", &hook.hook_type)?;
        st.serialize_field("command", &hook.command)?;
        st.serialize_field("sourcePath", &hook.source_path)?;
        st.serialize_field("category", &hook.category)?;
        st.serialize_field("status", &hook.status)?;
        st.serialize_field("description", &hook.description)?;
        st.serialize_field("why", &hook.why)?;
        st.serialize_field("sideEffects", &hook.side_effects)?;
        st.serialize_field("events", &hook.events)?;
        match self.raw_reqs {
            Some(reqs) => st.serialize_field("justificationRequirements", &RawReqs(reqs))?,
            None => st.serialize_field(
                "justificationRequirements",
                &hook.justification_requirements,
            )?,
        }
        st.end()
    }
}

struct RawReqs<'a>(&'a [JVal]);

impl Serialize for RawReqs<'_> {
    fn serialize<S: Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        let mut seq = serializer.serialize_seq(Some(self.0.len()))?;
        for item in self.0 {
            seq.serialize_element(item)?;
        }
        seq.end()
    }
}
