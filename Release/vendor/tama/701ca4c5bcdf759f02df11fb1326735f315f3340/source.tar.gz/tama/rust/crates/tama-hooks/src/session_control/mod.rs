//! Port of `shared-hooks/session-control.mjs`: session-scoped hook control
//! state under the platform state directory, atomic JSON writes, and the
//! global emergency-disable switch.

mod context;
mod overrides;
mod paths;
mod store;

pub use context::{session_context, session_resume_argv, SessionContext};
pub use overrides::{
    is_session_hook_enabled, publish_session, read_session_override, SessionOverride,
};
pub use paths::{emergency_state_path, session_control_root, tama_state_root};
pub use store::{hooks_globally_disabled, hooks_globally_disabled_at};

pub const SESSION_CONTROL_SCHEMA: &str = "ai.wisent.tama.session-control.v2";
pub const EMERGENCY_STATE_SCHEMA: &str = "ai.wisent.tama.hook-emergency-state.v1";
pub const DEFAULT_HEARTBEAT_TTL_SECONDS: i64 = 900;
