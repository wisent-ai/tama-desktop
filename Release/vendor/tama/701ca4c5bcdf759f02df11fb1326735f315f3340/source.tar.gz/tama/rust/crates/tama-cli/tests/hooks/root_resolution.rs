//! Which checkout a `tama hooks` command reads, through the real CLI.
//!
//! `repo_root()` is compiled in from `CARGO_MANIFEST_DIR`. The installed CLI
//! is built inside the release's export tree, and the release deletes that
//! tree when the build finishes, so the installed copy's default root is a
//! directory that does not exist. On 2026-09-20, minutes after a release
//! installed it, `tama hooks release --dry-run` and `tama hooks warm` both
//! refused with "names no hook binary of ours" against
//! `rust/target/hook-release-src/shared-hooks/registry.json`.
//!
//! So the working directory decides before the compiled-in path does, and
//! this drives that from a fixture checkout whose registry names one hook
//! nothing else does.

use std::fs;
use std::path::{Path, PathBuf};
use std::process::{Command, Output};

/// The CLI as built, beside this test binary.
fn cli() -> PathBuf {
    let mut path = std::env::current_exe().expect("test binary path");
    path.pop();
    if path.ends_with("deps") {
        path.pop();
    }
    path.join("tama-cli")
}

fn run_in(directory: &Path, args: &[&str]) -> Output {
    Command::new(cli())
        .args(args)
        .current_dir(directory)
        .env_remove("DEVICE_HOOK_EDIT_APPROVED")
        .env_remove("TAMA_ROOT")
        .output()
        .expect("run tama-cli")
}

fn text(output: &Output) -> String {
    format!(
        "{}{}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    )
}

/// A checkout with one registry naming one binary no real registry names.
/// The binding carries no timeout, so the default one applies.
fn fixture(label: &str) -> PathBuf {
    let root = PathBuf::from(env!("CARGO_TARGET_TMPDIR")).join(label);
    let hooks = root.join("shared-hooks");
    fs::create_dir_all(&hooks).expect("create the fixture checkout");
    fs::write(
        hooks.join("registry.json"),
        r#"{"catalog":{"agentHooks":[{"id":"fixture-only-hook",
            "command":"$HOME/.local/bin/tama-fixture-only-hook",
            "occurrences":[{"event":"pre_tool_use:bash"}]}]}}"#,
    )
    .expect("write the fixture registry");
    root
}

#[test]
fn the_plan_reads_the_checkout_the_command_runs_in() {
    let root = fixture("hooks-root-plan");

    let output = run_in(&root, &["hooks", "release", "--dry-run"]);

    let said = text(&output);
    assert!(output.status.success(), "the plan failed: {said}");
    assert!(
        said.contains("tama-fixture-only-hook"),
        "the plan read another checkout's registry: {said}"
    );
}

#[test]
fn warming_reads_the_checkout_the_command_runs_in() {
    let root = fixture("hooks-root-warm");

    let output = run_in(&root, &["hooks", "warm", "--only", "fixture-only-hook"]);

    let said = text(&output);
    assert!(
        said.contains("fixture-only-hook"),
        "warming read another checkout's registry: {said}"
    );
    // The fixture names a binary nobody installs, so the run says so instead
    // of claiming a measurement.
    assert_ne!(
        output.status.code(),
        Some(0),
        "an uninstallable hook must not report success: {said}"
    );
}

/// An explicit root still wins over the working directory.
#[test]
fn an_explicit_root_overrides_the_working_directory() {
    let root = fixture("hooks-root-explicit");
    let checkout = Path::new(env!("CARGO_MANIFEST_DIR"))
        .ancestors()
        .nth(3)
        .expect("the checkout above rust/crates/tama-cli")
        .to_path_buf();

    let output = run_in(
        &root,
        &[
            "hooks",
            "release",
            "--dry-run",
            "--root",
            checkout.to_str().expect("path"),
        ],
    );

    let said = text(&output);
    assert!(output.status.success(), "the plan failed: {said}");
    assert!(
        !said.contains("tama-fixture-only-hook"),
        "the explicit root was ignored: {said}"
    );
}
