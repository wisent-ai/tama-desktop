//! Native harness adapter for Tama's shared hook runtime.

use std::collections::HashSet;
use std::io::Read;

use tama_run_hook::{default_registry_path, InvocationOptions};

fn run() -> Result<i32, String> {
    let args: Vec<String> = std::env::args_os()
        .map(|argument| argument.to_string_lossy().into_owned())
        .collect();
    let event = args.get(1).map(String::as_str).unwrap_or("");
    if matches!(event, "--help" | "-h") {
        print!("{}", tama_run_hook::usage());
        return Ok(0);
    }
    // The feedback bridge is spawned as `<this binary> adaptive-bridge` by
    // `bridge::dispatch`, so this runtime has to route it the way the CLI does.
    // Intentionally absent from usage: nothing else calls it.
    if event == "adaptive-bridge" {
        return Ok(tama_adaptive::bridge::main());
    }
    if event.is_empty() {
        eprint!("{}", tama_run_hook::usage());
        return Ok(2);
    }
    let agent_id = match args.get(2).filter(|argument| !argument.is_empty()) {
        Some(argument) => argument.clone(),
        None => std::env::var("TAMA_AGENT_ID").unwrap_or_default(),
    }
    .trim()
    .to_lowercase();
    let provider = match std::env::var("TAMA_PROVIDER") {
        Ok(provider) if !provider.is_empty() => provider.trim().to_lowercase(),
        _ => agent_id.clone(),
    };
    let split_ids = |name: &str| -> HashSet<String> {
        std::env::var(name)
            .unwrap_or_default()
            .split(',')
            .map(str::trim)
            .filter(|id| !id.is_empty())
            .map(str::to_owned)
            .collect()
    };
    let options = InvocationOptions {
        only_hook_id: std::env::var("TAMA_ONLY_HOOK_ID")
            .unwrap_or_default()
            .trim()
            .to_owned(),
        disabled_hook_ids: split_ids("TAMA_DISABLED_HOOKS"),
        enabled_hook_ids: std::env::var_os("TAMA_ENABLED_HOOKS")
            .map(|_| split_ids("TAMA_ENABLED_HOOKS")),
    };
    let registry = default_registry_path();
    if event == "--serve" {
        tama_run_hook::serve(&registry, &agent_id, &provider, &options)?;
        return Ok(0);
    }
    let mut input = Vec::new();
    std::io::stdin()
        .lock()
        .read_to_end(&mut input)
        .map_err(|error| error.to_string())?;
    let decision = tama_run_hook::run_once(
        &registry,
        event,
        &agent_id,
        &provider,
        &options,
        &String::from_utf8_lossy(&input),
    )?;
    Ok(tama_run_hook::emit(&provider, &decision))
}

fn main() {
    match run() {
        Ok(code) => std::process::exit(code),
        Err(error) => {
            eprintln!("TAMA_HOOK_INFRASTRUCTURE: {error}");
            std::process::exit(1);
        }
    }
}
