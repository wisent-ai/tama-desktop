//! The rounds themselves: hand the agent a brief, rescan, and stop when
//! the repository is clean or the round budget is spent.
//!
//! Split out of `clean/rounds/mod.rs`, which had grown past the
//! three-hundred-line limit; the lock and the result shape stay there.

use std::path::Path;

use crate::find_violations::{detect_gaming, Violation};
use crate::js_num;

use super::agent::{revert_patch, spawn_agent};
use super::brief::{build_brief, BriefParams};
use super::journal::{journal, JournalDone, JournalRound};
use super::{actionable_of, rescan, CleanParams, CleanResult, Round, FIRST_ROUND};


pub(super) fn run_rounds(
    params: &CleanParams,
    ignore_entries: &[String],
    report: &mut crate::find_violations::ScanReport,
    actionable: &mut Vec<Violation>,
    before_count: usize,
) -> CleanResult {
    let mut rounds: Vec<Round> = Vec::new();
    let mut feedback: Vec<String> = Vec::new();
    let mut round = FIRST_ROUND - FIRST_ROUND;
    let note_fires = params.note.map(|note| !note.is_empty()).unwrap_or(false);
    while (!actionable.is_empty()
        || (note_fires && round == FIRST_ROUND - FIRST_ROUND)
        || !feedback.is_empty())
        && (round as f64) < params.max_rounds
    {
        round += FIRST_ROUND;
        let before_round = actionable.len();
        let brief = build_brief(&BriefParams {
            repo: params.repo,
            violations: actionable,
            round,
            max_rounds: params.max_rounds,
            skip: params.skip,
            note: params.note,
            size_only: params.size_only,
            feedback: &feedback,
        });
        eprintln!(
            "[clean] {} round {}/{}: {} violation(s), route={}",
            params.repo,
            round,
            js_num(params.max_rounds),
            actionable.len(),
            params.model
        );
        let run = spawn_agent(params.model, &brief, params.repo);
        if let Some(error) = &run.error {
            eprintln!(
                "[clean] {} round {round} repaired nothing: {error}",
                params.repo
            );
        }
        let gaming = detect_gaming(Path::new(params.repo));
        journal(
            params.root,
            &JournalRound {
                at: crate::iso_now(),
                repo: params.repo,
                round,
                model: params.model,
                agent_exit: run.status,
                agent_signal: run.signal.clone(),
                violations: actionable.len(),
                gaming: &gaming.findings,
            },
        );
        *report = rescan(params);
        *actionable = actionable_of(report, params, ignore_entries);
        // A round that could not act ends the run: repeating it spends the
        // same minutes on the same failure.
        if let Some(error) = run.error {
            rounds.push(Round {
                round,
                agent_exit: run.status,
                rejected: Some(error),
                remaining: actionable.len(),
            });
            break;
        }
        // A round that left more to fix than it found is not progress. On
        // 2026-09-07 one such round wrote ten modules no crate declared, so
        // the compiler never saw them, the build stayed green, and the count
        // went from 54 to 62 while the run reported success. Its own patch is
        // undone exactly, and the next brief is told what happened.
        if actionable.len() > before_round {
            let raised = format!(
                "the round raised the violation count from {before_round} to {}",
                actionable.len()
            );
            let undone = match run.patch.as_deref() {
                Some(patch) => match revert_patch(params.repo, patch) {
                    Ok(()) => {
                        *report = rescan(params);
                        *actionable = actionable_of(report, params, ignore_entries);
                        "; its patch was undone"
                    }
                    Err(_) => "; its patch could not be undone",
                },
                None => "",
            };
            eprintln!(
                "[clean] {} round {round} rejected: {raised}{undone}",
                params.repo
            );
            feedback = vec![format!(
                "- {raised}{undone}. Fix the rules named above without adding files that break them, \
                 and keep every new module reachable from its parent."
            )];
            rounds.push(Round {
                round,
                agent_exit: run.status,
                rejected: Some(format!("{raised}{undone}")),
                remaining: actionable.len(),
            });
            continue;
        }
        if !gaming.findings.is_empty() {
            feedback = gaming
                .findings
                .iter()
                .map(|finding| format!("- {}: {}", finding.kind, finding.path))
                .collect();
            rounds.push(Round {
                round,
                agent_exit: run.status,
                rejected: Some("rule-gaming".to_string()),
                remaining: actionable.len(),
            });
            continue;
        }
        feedback = Vec::new();
        rounds.push(Round {
            round,
            agent_exit: run.status,
            rejected: None,
            remaining: actionable.len(),
        });
    }
    let last_round = rounds.last();
    let clean = actionable.is_empty() && !matches!(last_round, Some(r) if r.rejected.is_some());
    journal(
        params.root,
        &JournalDone {
            at: crate::iso_now(),
            repo: params.repo,
            done: true,
            clean,
            before: before_count,
            after: report.violations.len(),
        },
    );
    CleanResult {
        repo: params.repo.to_string(),
        clean: Some(clean),
        before: Some(before_count),
        after: Some(report.violations.len()),
        remaining: Some(actionable.clone()),
        rounds: Some(rounds),
        ..Default::default()
    }
}
