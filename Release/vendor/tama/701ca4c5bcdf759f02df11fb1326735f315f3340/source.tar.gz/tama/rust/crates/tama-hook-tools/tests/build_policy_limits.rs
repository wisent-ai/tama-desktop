//! Who owns the limits, and what happens when the ledger they are counted
//! from cannot be read.
//!
//! An agent that could raise its own build allowance has no allowance, so
//! loosening a limit needs the same device approval every other hook
//! configuration needs, while tightening one needs nothing.

mod common;

use std::process::Command;

use common::{build, cli, said, Scratch};

#[test]
fn the_limits_can_be_tightened_freely_and_raised_only_with_device_approval() {
    let scratch = Scratch::new("limits");
    let refused = build(&scratch, &["policy", "--builds-per-day", "9"]);
    assert_eq!(refused.status.code(), Some(1), "{}", said(&refused));
    assert!(
        said(&refused).contains("DEVICE_HOOK_EDIT_APPROVED=1"),
        "{}",
        said(&refused)
    );

    let tightened = build(&scratch, &["policy", "--minimum-changed-lines", "80"]);
    assert!(tightened.status.success(), "{}", said(&tightened));
    assert!(
        said(&tightened).contains("minimum_changed_lines tightened 30 -> 80"),
        "{}",
        said(&tightened)
    );

    let approved = Command::new(cli())
        .args(["build", "policy", "--builds-per-day", "9"])
        .args(["--home", &scratch.home()])
        .env("DEVICE_HOOK_EDIT_APPROVED", "1")
        .output()
        .expect("tama-cli build runs");
    assert!(approved.status.success(), "{}", said(&approved));
    assert!(
        said(&approved).contains("builds_per_day loosened 3 -> 9"),
        "{}",
        said(&approved)
    );

    let shown = build(&scratch, &["policy"]);
    assert!(
        said(&shown).contains("9 builds and 10 restarts in any 24 hours"),
        "{}",
        said(&shown)
    );
    assert!(
        said(&shown).contains("at least 80 changed lines"),
        "{}",
        said(&shown)
    );
}

/// A ledger that cannot be read refuses the build. Counting an unreadable
/// ledger as an unspent day is how a ration quietly stops being one.
#[test]
fn a_ledger_that_cannot_be_read_refuses_the_build() {
    let scratch = Scratch::new("ledger");
    std::fs::write(scratch.hooks().join("build_restart_ledger.json"), "[1,2,3]")
        .expect("write a ledger nothing can count");
    let refused = build(
        &scratch,
        &[
            "record",
            "--kind",
            "build",
            "--target",
            "skarbiec",
            "--reason",
            "a build recorded while the ledger on this machine is unreadable",
            "--revision",
            "45a5c678042147f76241adf76fb7cf217e121ca6",
        ],
    );
    assert_eq!(refused.status.code(), Some(1), "{}", said(&refused));
    assert!(
        said(&refused).contains("carries no recorded list"),
        "{}",
        said(&refused)
    );
}

/// A policy file nobody can parse is refused too, and named.
#[test]
fn an_unreadable_policy_is_refused_and_named() {
    let scratch = Scratch::new("policy");
    std::fs::write(
        scratch.hooks().join("build_restart_policy.json"),
        "{ builds",
    )
    .expect("write a policy nothing can read");
    let refused = build(&scratch, &["list"]);
    assert_eq!(refused.status.code(), Some(1), "{}", said(&refused));
    assert!(
        said(&refused).contains("is not readable policy"),
        "{}",
        said(&refused)
    );
}
