//! Where a session's recent looks are counted: one small JSON file per
//! session under the session-control root, holding the last looks with the
//! second they were taken. Looks older than the window fall off on every
//! write, so the file never grows past what one window can hold.

use std::path::{Path, PathBuf};

use serde_json::{json, Value};
use tama_hooks::session_control::session_control_root;

/// How many looks one file keeps at most; older ones fall off first.
const KEEP: usize = 64;
const LOOKS_KEY: &str = "looks";
const AT_KEY: &str = "at";
const LOOK_KEY: &str = "look";

/// `<session-control>/<session>.looks.json`, the session id made safe as a
/// file name.
pub fn path_for(session: &str) -> PathBuf {
    let safe: String = session
        .chars()
        .map(|c| {
            if c.is_ascii_alphanumeric() || c == '-' || c == '_' {
                c
            } else {
                '_'
            }
        })
        .collect();
    session_control_root().join(format!("{safe}.looks.json"))
}

fn read(path: &Path) -> Vec<(u64, String)> {
    let Ok(text) = std::fs::read_to_string(path) else {
        return Vec::new();
    };
    let Ok(document) = serde_json::from_str::<Value>(&text) else {
        return Vec::new();
    };
    document
        .get(LOOKS_KEY)
        .and_then(Value::as_array)
        .map(|looks| {
            looks
                .iter()
                .filter_map(|entry| {
                    Some((
                        entry.get(AT_KEY)?.as_u64()?,
                        entry.get(LOOK_KEY)?.as_str()?.to_string(),
                    ))
                })
                .collect()
        })
        .unwrap_or_default()
}

fn write(path: &Path, looks: &[(u64, String)]) {
    let document = json!({
        LOOKS_KEY: looks
            .iter()
            .map(|(at, look)| json!({ AT_KEY: at, LOOK_KEY: look }))
            .collect::<Vec<_>>(),
    });
    if let Some(parent) = path.parent() {
        let _ = std::fs::create_dir_all(parent);
    }
    let staged = path.with_extension("json.tmp");
    if std::fs::write(&staged, document.to_string()).is_ok() {
        let _ = std::fs::rename(&staged, path);
    }
}

/// Record one look at `fingerprint` taken at `now`, and return how many
/// looks at the same fingerprint the file now holds inside `window`
/// seconds, this one included.
pub fn record_look(path: &Path, fingerprint: &str, now: u64, window: u64) -> usize {
    let oldest = now.saturating_sub(window);
    let mut looks: Vec<(u64, String)> = read(path)
        .into_iter()
        .filter(|(at, _)| *at >= oldest)
        .collect();
    looks.push((now, fingerprint.to_string()));
    if looks.len() > KEEP {
        let excess = looks.len() - KEEP;
        looks.drain(..excess);
    }
    write(path, &looks);
    looks.iter().filter(|(_, look)| look == fingerprint).count()
}
