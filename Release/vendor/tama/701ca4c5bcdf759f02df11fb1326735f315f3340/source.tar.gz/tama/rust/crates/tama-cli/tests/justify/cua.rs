//! Real session consent and installed macOS app; no fabricated transcript.
use serde_json::{json, Value};
use std::{
    fs,
    io::{BufRead, BufReader, Read, Write},
    net::TcpStream,
    path::{Path, PathBuf},
    process::{Child, Command, Output, Stdio},
    time::{SystemTime, UNIX_EPOCH},
};

struct Run {
    root: PathBuf,
    home: PathBuf,
    session: String,
    app: String,
    needle: String,
    actions: String,
}
impl Run {
    fn new(label: &str) -> Self {
        let input = |key| {
            std::env::var(key).unwrap_or_else(|_| panic!("{key} requires real consent input"))
        };
        let root = Path::new(env!("CARGO_TARGET_TMPDIR")).join(format!(
            "cua-{label}-{}",
            SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let home = root.join("home");
        fs::create_dir_all(&home).unwrap();
        let revision = Command::new("git")
            .args(["rev-parse", "HEAD"])
            .output()
            .unwrap();
        assert!(revision.status.success());
        fs::write(root.join("revision.txt"), revision.stdout).unwrap();
        Self {
            root,
            home,
            session: input("TAMA_TEST_CUA_SESSION"),
            app: input("TAMA_TEST_CUA_APP"),
            needle: input("TAMA_TEST_CUA_MATCH"),
            actions: input("TAMA_TEST_CUA_ACTIONS"),
        }
    }
    fn call(&self, label: &str, args: &[&str]) -> Output {
        let mut command = Command::new(env!("CARGO_BIN_EXE_tama-cli"));
        command
            .args(["justify", args[0], "--kind", "cua", "--home"])
            .arg(&self.home)
            .arg("--json")
            .args(&args[1..]);
        let output = command.output().unwrap();
        fs::write(self.root.join(format!("{label}.json")), serde_json::to_vec_pretty(&json!({
            "command": format!("{command:?}"), "status": output.status.code(),
            "stdout": String::from_utf8_lossy(&output.stdout), "stderr": String::from_utf8_lossy(&output.stderr)
        })).unwrap()).unwrap();
        output
    }
    fn record(&self, label: &str, actions: &str, session: &str) -> Output {
        self.call(
            label,
            &[
                "record",
                "--session",
                session,
                "--app",
                &self.app,
                "--actions",
                actions,
                "--quote-match",
                &self.needle,
            ],
        )
    }
    fn path(&self) -> PathBuf {
        self.home.join(".shared-hooks/cua_justifications.json")
    }
    fn bytes(&self) -> Vec<u8> {
        fs::read(self.path()).unwrap()
    }
    fn state(&self) -> Value {
        serde_json::from_slice(&self.bytes()).unwrap()
    }
}
impl Drop for Run {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.home);
        println!("Consent evidence: {}", self.root.display());
    }
}
fn success(output: Output) -> Value {
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
    serde_json::from_slice(&output.stdout).unwrap()
}

#[test]
#[ignore = "requires real user consent and installed application"]
fn cli_records_replaces_refuses_and_removes_real_consent() {
    let run = Run::new("cli");
    let result = success(run.record("record", &run.actions, &run.session));
    let quote = result["authorization"]["userRequestQuote"]
        .as_str()
        .unwrap();
    assert!(run.state()["authorizations"]
        .as_array()
        .unwrap()
        .iter()
        .any(|entry| entry["userRequestQuote"] == quote));
    success(run.record("repeat", &run.actions, &run.session));
    assert_eq!(run.state()["authorizations"].as_array().unwrap().len(), 1);
    let before = run.bytes();
    assert_eq!(
        run.record("ungranted", "never_authorized_action", &run.session)
            .status
            .code(),
        Some(1)
    );
    assert_eq!(run.bytes(), before);
    assert_eq!(
        run.record("other-session", &run.actions, "absent-session")
            .status
            .code(),
        Some(1)
    );
    assert_eq!(run.bytes(), before);
    assert_eq!(
        success(run.call("show", &["show", "--quote", quote]))["authorizations"],
        run.state()["authorizations"]
    );
    fs::write(run.root.join("recorded-state.json"), &before).unwrap();
    success(run.call("remove", &["remove", "--quote", quote]));
    assert_eq!(run.state()["authorizations"], json!([]));
    let removed = run.bytes();
    assert_eq!(
        run.call("remove-absent", &["remove", "--quote", quote])
            .status
            .code(),
        Some(1)
    );
    assert_eq!(run.bytes(), removed);
    fs::write(run.root.join("final-state.json"), removed).unwrap();
    let malformed =
        json!({"schema": "ai.wisent.tama.cua-justifications.vTwo", "authorizations": "broken"});
    fs::write(run.path(), serde_json::to_vec(&malformed).unwrap()).unwrap();
    assert_eq!(
        run.record("broken-registry", &run.actions, &run.session)
            .status
            .code(),
        Some(1)
    );
    assert_eq!(run.state(), malformed);
}

struct Server(Child, u16);
impl Drop for Server {
    fn drop(&mut self) {
        let _ = self.0.kill();
        let _ = self.0.wait();
    }
}
fn server(run: &Run) -> Server {
    let transcripts = std::env::var_os("TAMA_OMP_SESSION_ROOT")
        .map(PathBuf::from)
        .unwrap_or_else(|| {
            PathBuf::from(std::env::var_os("HOME").unwrap()).join(".omp/agent/sessions")
        });
    let mut child = Command::new(env!("CARGO_BIN_EXE_tama-cli"))
        .args(["serve", "--port", "0"])
        .env("HOME", &run.home)
        .env("TAMA_OMP_SESSION_ROOT", transcripts)
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .unwrap();
    let mut line = String::new();
    BufReader::new(child.stdout.take().unwrap())
        .read_line(&mut line)
        .unwrap();
    let ready: Value = serde_json::from_str(&line).expect("backend ready line");
    fs::write(run.root.join("server.json"), &line).unwrap();
    Server(child, ready["port"].as_u64().unwrap().try_into().unwrap())
}
fn http(
    run: &Run,
    server: &Server,
    label: &str,
    method: &str,
    path: &str,
    body: Value,
) -> (u16, Value) {
    let mut stream = TcpStream::connect(("127.0.0.1", server.1)).unwrap();
    let body = serde_json::to_vec(&body).unwrap();
    write!(stream, "{method} {path} HTTP/1.1\r\nHost: 127.0.0.1\r\nContent-Type: application/json\r\nContent-Length: {}\r\nConnection: close\r\n\r\n", body.len()).unwrap();
    stream.write_all(&body).unwrap();
    let mut response = String::new();
    stream.read_to_string(&mut response).unwrap();
    fs::write(run.root.join(format!("{label}.http")), &response).unwrap();
    let status = response.split_whitespace().nth(1).unwrap().parse().unwrap();
    let document = serde_json::from_str(response.split_once("\r\n\r\n").unwrap().1).unwrap();
    (status, document)
}
#[test]
#[ignore = "requires real user consent and installed application"]
fn backend_records_real_consent_refuses_expansion_and_removes_it() {
    let run = Run::new("api");
    let server = server(&run);
    let input = json!({"sessionId": run.session, "app": run.app,
        "actions": run.actions.split(',').collect::<Vec<_>>(), "quoteMatch": run.needle});
    let (status, result) = http(
        &run,
        &server,
        "record",
        "POST",
        "/v1/justifications/cua/record",
        input.clone(),
    );
    assert_eq!(status, 200, "{result}");
    let quote = &result["authorization"]["userRequestQuote"];
    assert!(run.state()["authorizations"]
        .as_array()
        .unwrap()
        .iter()
        .any(|entry| &entry["userRequestQuote"] == quote));
    let before = run.bytes();
    let mut invalid = input.clone();
    invalid["actions"] = json!(["never_authorized_action"]);
    assert_eq!(
        http(
            &run,
            &server,
            "ungranted",
            "POST",
            "/v1/justifications/cua/record",
            invalid
        )
        .0,
        400
    );
    assert_eq!(run.bytes(), before);
    let mut override_home = input;
    override_home["home"] = json!(run.root);
    assert_eq!(
        http(
            &run,
            &server,
            "home-refused",
            "POST",
            "/v1/justifications/cua/record",
            override_home
        )
        .0,
        400
    );
    assert_eq!(run.bytes(), before);
    let (status, listed) = http(
        &run,
        &server,
        "list",
        "GET",
        "/v1/justifications/cua",
        Value::Null,
    );
    assert_eq!(status, 200);
    assert_eq!(listed["authorizations"], run.state()["authorizations"]);
    fs::write(run.root.join("recorded-state.json"), &before).unwrap();
    assert_eq!(
        http(
            &run,
            &server,
            "remove",
            "POST",
            "/v1/justifications/cua/remove",
            json!({"quote": quote})
        )
        .0,
        200
    );
    assert_eq!(run.state()["authorizations"], json!([]));
    fs::write(run.root.join("final-state.json"), run.bytes()).unwrap();
}
