//! Minimal backtracking regex engine (std-only) supporting the subset used
//! by `bridge.mjs` frustration patterns: literals, `.`, character classes,
//! `\b \w \W \s \S \d \D` escapes, groups `(…)`/`(?:…)`, alternation,
//! greedy quantifiers `? * + {n,m}` (lazy suffix accepted, treated greedy),
//! anchors `^ $`, and a case-insensitive flag. Leftmost-first match
//! semantics like JavaScript's `RegExp`.

mod parser;

use parser::Parser;
#[derive(Debug, Clone)]
enum Ast {
    Alt(Vec<Ast>),
    Seq(Vec<Ast>),
    Repeat(Box<Ast>, u32, u32),
    Atom(Atom),
}

#[derive(Debug, Clone)]
enum Atom {
    Char(char),
    Any,
    Class {
        negated: bool,
        items: Vec<ClassItem>,
    },
    Set(Set),
    WordBoundary,
    NonWordBoundary,
    Start,
    End,
}

#[derive(Debug, Clone)]
enum ClassItem {
    Range(char, char),
    Set(Set),
}

#[derive(Debug, Clone, Copy)]
enum Set {
    Word,
    NonWord,
    Digit,
    NonDigit,
    Space,
    NonSpace,
}

const UNLIMITED: u32 = u32::MAX;

pub struct Regex {
    ast: Ast,
    ignore_case: bool,
}

impl Regex {
    /// `new RegExp(source, 'i')` — `Err` for unparseable sources.
    pub fn new(source: &str, ignore_case: bool) -> Result<Regex, String> {
        let chars: Vec<char> = source.chars().collect();
        let mut parser = Parser {
            chars: &chars,
            pos: 0,
        };
        let ast = parser.parse_alt()?;
        if parser.pos != chars.len() {
            return Err(format!("unexpected character at {}", parser.pos));
        }
        Ok(Regex { ast, ignore_case })
    }

    /// `regex.test(text)`.
    pub fn is_match(&self, text: &str) -> bool {
        self.find(text).is_some()
    }

    /// `text.match(regex)` — the first match's text, if any.
    pub fn find(&self, text: &str) -> Option<String> {
        let chars: Vec<char> = text.chars().collect();
        for start in 0..=chars.len() {
            let mut end = None;
            let found = self.matches(&self.ast, &chars, start, &mut |p| {
                end = Some(p);
                true
            });
            if found {
                let end = end.unwrap_or(start);
                return Some(chars[start..end].iter().collect());
            }
        }
        None
    }

    fn atom_matches(&self, atom: &Atom, chars: &[char], p: usize) -> Option<usize> {
        match atom {
            Atom::Start => {
                if p == 0 {
                    Some(p)
                } else {
                    None
                }
            }
            Atom::End => {
                if p == chars.len() {
                    Some(p)
                } else {
                    None
                }
            }
            Atom::WordBoundary => {
                if is_boundary(chars, p) {
                    Some(p)
                } else {
                    None
                }
            }
            Atom::NonWordBoundary => {
                if !is_boundary(chars, p) {
                    Some(p)
                } else {
                    None
                }
            }
            Atom::Char(expected) => {
                let c = *chars.get(p)?;
                if self.char_eq(c, *expected) {
                    Some(p + 1)
                } else {
                    None
                }
            }
            Atom::Any => {
                let c = *chars.get(p)?;
                if c != '\n' {
                    Some(p + 1)
                } else {
                    None
                }
            }
            Atom::Set(set) => {
                let c = *chars.get(p)?;
                if self.set_matches(*set, c) {
                    Some(p + 1)
                } else {
                    None
                }
            }
            Atom::Class { negated, items } => {
                let c = *chars.get(p)?;
                let inside = items.iter().any(|item| match item {
                    ClassItem::Range(lo, hi) => self.in_range(c, *lo, *hi),
                    ClassItem::Set(set) => self.set_matches(*set, c),
                });
                if inside != *negated {
                    Some(p + 1)
                } else {
                    None
                }
            }
        }
    }

    fn char_eq(&self, a: char, b: char) -> bool {
        if a == b {
            return true;
        }
        if !self.ignore_case {
            return false;
        }
        fold(a) == fold(b)
    }

    fn in_range(&self, c: char, lo: char, hi: char) -> bool {
        if lo <= c && c <= hi {
            return true;
        }
        if !self.ignore_case {
            return false;
        }
        let folded = fold(c);
        (lo <= folded && folded <= hi) || (lo <= fold_upper(c) && fold_upper(c) <= hi)
    }

    fn set_matches(&self, set: Set, c: char) -> bool {
        match set {
            Set::Word => is_word_char(c),
            Set::NonWord => !is_word_char(c),
            Set::Digit => c.is_ascii_digit(),
            Set::NonDigit => !c.is_ascii_digit(),
            Set::Space => is_js_space(c),
            Set::NonSpace => !is_js_space(c),
        }
    }

    fn matches(
        &self,
        ast: &Ast,
        chars: &[char],
        p: usize,
        k: &mut dyn FnMut(usize) -> bool,
    ) -> bool {
        match ast {
            Ast::Atom(atom) => match self.atom_matches(atom, chars, p) {
                Some(next) => k(next),
                None => false,
            },
            Ast::Seq(nodes) => self.matches_seq(nodes, 0, chars, p, k),
            Ast::Alt(alts) => alts.iter().any(|alt| self.matches(alt, chars, p, k)),
            Ast::Repeat(node, min, max) => self.matches_repeat(node, *min, *max, 0, chars, p, k),
        }
    }

    fn matches_seq(
        &self,
        nodes: &[Ast],
        index: usize,
        chars: &[char],
        p: usize,
        k: &mut dyn FnMut(usize) -> bool,
    ) -> bool {
        if index == nodes.len() {
            return k(p);
        }
        self.matches(&nodes[index], chars, p, &mut |next| {
            self.matches_seq(nodes, index + 1, chars, next, k)
        })
    }

    #[allow(clippy::too_many_arguments)]
    fn matches_repeat(
        &self,
        node: &Ast,
        min: u32,
        max: u32,
        count: u32,
        chars: &[char],
        p: usize,
        k: &mut dyn FnMut(usize) -> bool,
    ) -> bool {
        if count < min {
            return self.matches(node, chars, p, &mut |next| {
                self.matches_repeat(node, min, max, count + 1, chars, next, k)
            });
        }
        if count < max {
            let grown = self.matches(node, chars, p, &mut |next| {
                next != p && self.matches_repeat(node, min, max, count + 1, chars, next, k)
            });
            if grown {
                return true;
            }
        }
        k(p)
    }
}

fn fold(c: char) -> char {
    c.to_lowercase().next().unwrap_or(c)
}

fn fold_upper(c: char) -> char {
    c.to_uppercase().next().unwrap_or(c)
}

fn is_word_char(c: char) -> bool {
    c.is_ascii_alphanumeric() || c == '_'
}

fn is_js_space(c: char) -> bool {
    c.is_whitespace() || c == '\u{feff}'
}

fn is_boundary(chars: &[char], p: usize) -> bool {
    let before = p > 0 && is_word_char(chars[p - 1]);
    let after = p < chars.len() && is_word_char(chars[p]);
    before != after
}
