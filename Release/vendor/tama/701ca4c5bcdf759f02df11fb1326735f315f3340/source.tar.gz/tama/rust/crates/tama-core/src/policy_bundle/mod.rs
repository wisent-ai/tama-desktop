//! Durable, inactive policy-bundle adoption for Tama CLI and Desktop.
//!
//! A bundle is an existing self-contained Tama policy directory or sealed
//! release. Import copies the established policy roots into Tama's editable
//! data store, records source identity, and never changes the active runtime or
//! installs a hook.
//!
//! The work is split by question: `records` is what a bundle is once stored,
//! `store` is where it lives, `inspect` is whether a candidate is acceptable,
//! and `import` is the copy itself.

mod import;
mod inspect;
mod records;
mod store;

pub use import::import_policy_bundle;
pub use records::{
    BundleFileRecord, ImportPolicyBundleOptions, PolicyBundleConflict, PolicyBundleImportResult,
    PolicyBundleList, PolicyBundleRecord, PolicyBundleSummary,
};
pub use store::{list_policy_bundles, policy_bundle_store};

use records::PolicyBundleIndex;

use crate::{err, Result};
use sha2::{Digest, Sha256};
use std::fs;
use std::path::{Path, PathBuf};

const INDEX_SCHEMA: &str = "ai.wisent.tama.policy-bundles.v1";
const RESULT_SCHEMA: &str = "ai.wisent.tama.policy-bundle-import-result.v1";
/// An import never activates what it copied; that is a separate decision.
const INACTIVE: &str = "inactive";
const POLICY_ROOTS: &[&str] = &[
    "shared-hooks",
    "claude-hooks",
    "codex-hooks",
    "repo-githooks",
    "adaptive",
    "external-hooks",
    "bin",
];
const RUNTIME_POLICY_ROOTS: &[(&str, &str)] = &[
    (".shared-hooks", "shared-hooks"),
    (".claude/hooks", "claude-hooks"),
    (".codex/hooks", "codex-hooks"),
];
const ROOT_METADATA: &[&str] = &[
    "package.json",
    "release.json",
    "external-sources.json",
    ".wisent-release.json",
    "README.md",
    "LICENSE",
];

fn hex(bytes: &[u8]) -> String {
    let mut output = String::with_capacity(bytes.len() * 2);
    for byte in bytes {
        use std::fmt::Write as _;
        let _ = write!(&mut output, "{byte:02x}");
    }
    output
}

fn sha256(bytes: &[u8]) -> String {
    hex(&Sha256::digest(bytes))
}

fn path_string(path: &Path) -> String {
    path.components()
        .map(|component| component.as_os_str().to_string_lossy())
        .collect::<Vec<_>>()
        .join("/")
}

fn safe_join(root: &Path, relative: &str) -> Result<PathBuf> {
    let relative = Path::new(relative);
    if relative.is_absolute()
        || relative.components().any(|component| {
            matches!(
                component,
                std::path::Component::ParentDir
                    | std::path::Component::RootDir
                    | std::path::Component::Prefix(_)
            )
        })
    {
        return Err(err("policy bundle index contains an unsafe file path"));
    }
    Ok(root.join(relative))
}

#[cfg(unix)]
fn file_mode(metadata: &fs::Metadata) -> u32 {
    use std::os::unix::fs::PermissionsExt;
    metadata.permissions().mode() & 0o777
}

#[cfg(not(unix))]
fn file_mode(_metadata: &fs::Metadata) -> u32 {
    0o600
}

#[cfg(unix)]
fn set_mode(path: &Path, mode: u32) -> Result<()> {
    use std::os::unix::fs::PermissionsExt;
    fs::set_permissions(path, fs::Permissions::from_mode(mode))?;
    Ok(())
}

#[cfg(not(unix))]
fn set_mode(_path: &Path, _mode: u32) -> Result<()> {
    Ok(())
}
