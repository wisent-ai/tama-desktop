//! `tama worktrees` — find and remove linked git worktrees.
//!
//! Why this command exists: a linked worktree is a second checkout of a
//! repository this machine already has. On this machine
//! `~/Documents/CodingProjects/Wisent/.worktrees/brama-stub-purge/.git` is a
//! file reading `gitdir: /Users/lukaszbartoszcze/Documents/CodingProjects/
//! Wisent/brama/.git/worktrees/brama-stub-purge` — the same code as
//! `Wisent/brama`, stored twice on a boot volume with 12.4 GiB free out of
//! 1.8 TB. This command removes that second checkout.
//!
//! `discovery` holds what exists and what removing it does, `render` the
//! printed shapes; this module is the argument surface: the leaves, the exact
//! usage refusals and the exit codes.

use std::fmt;

mod discovery;
mod porcelain;
mod render;

use discovery::Refusal;
pub(crate) use discovery::{list_document, remove_document};
use render::{
    incomplete_walk_sentence, print_json, print_list, print_remove, print_unreadable_directories,
    refusal_sentence,
};

const EXIT_USAGE: i32 = 2;
const USAGE: &str = "tama worktrees <command>

Commands:
  list   [--root <PATH>]... [--json]                     Every linked git worktree under the roots
  remove [--root <PATH>]... [--except <PATH>]... [--apply] [--force] [--json]  Remove them; previews unless --apply

  --except <PATH>  Leave that one linked worktree alone: it is neither removed
                   nor able to refuse the pass. Repeatable, remove only.";

/// Emitted on both leaves when no `--root` was given. There is deliberately
/// no default root: the tree holding the worktrees on this machine
/// (`~/Documents/CodingProjects/Wisent`, 519 GB) sits beside trees Tama does
/// not own, so the operator names the tree.
pub(crate) const MISSING_ROOT: &str = "tama worktrees needs at least one --root; a machine-wide default would walk directories Tama does not own.";

/// An `--except` value naming nothing the pass would otherwise consider. The
/// operator asked to spare a specific worktree; sparing nothing instead would
/// let a pass they believed narrowed remove everything.
pub(crate) fn unknown_except_sentence(path: &str) -> String {
    format!(
        "tama worktrees does not know the worktree {path}; --except takes the path of a worktree this pass would otherwise remove."
    )
}

#[derive(Debug)]
pub(crate) enum CommandError {
    MissingRoot,
    /// The `--except` value, exactly as the operator spelled it.
    UnknownExcept(String),
    /// Every dirty or locked worktree of the pass, so the operator sees all
    /// of them at once instead of one per re-run.
    Refused(Vec<Refusal>),
    Operational(String),
}

impl fmt::Display for CommandError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::MissingRoot => formatter.write_str(MISSING_ROOT),
            Self::UnknownExcept(path) => formatter.write_str(&unknown_except_sentence(path)),
            Self::Refused(refusals) => {
                let sentences: Vec<String> = refusals.iter().map(refusal_sentence).collect();
                formatter.write_str(&sentences.join("\n"))
            }
            Self::Operational(error) => formatter.write_str(error),
        }
    }
}

struct Options {
    roots: Vec<String>,
    except: Vec<String>,
    apply: bool,
    force: bool,
    json: bool,
}

/// `--root` and `--except` are repeatable and take a value; `--apply` and
/// `--force` are flags. Anything else is a usage error, an empty value
/// included.
fn parse(args: &[String]) -> Option<Options> {
    let mut options = Options {
        roots: Vec::new(),
        except: Vec::new(),
        apply: false,
        force: false,
        json: false,
    };
    let mut index = 0;
    while index < args.len() {
        match args[index].as_str() {
            "--json" => options.json = true,
            "--apply" => options.apply = true,
            "--force" => options.force = true,
            name @ ("--root" | "--except") => {
                let value = args.get(index + 1)?;
                if value.is_empty() {
                    return None;
                }
                if name == "--root" {
                    options.roots.push(value.clone());
                } else {
                    options.except.push(value.clone());
                }
                index += 2;
                continue;
            }
            _ => return None,
        }
        index += 1;
    }
    Some(options)
}

fn usage(code: i32) -> i32 {
    eprintln!("{USAGE}");
    code
}

fn list(rest: &[String]) -> Result<i32, CommandError> {
    let Some(options) = parse(rest) else {
        return Ok(usage(EXIT_USAGE));
    };
    // `list` mutates nothing, so the removal flags — `--except` among them,
    // since there is nothing to be spared from — are not its vocabulary.
    if options.apply || options.force || !options.except.is_empty() {
        return Ok(usage(EXIT_USAGE));
    }
    let document = list_document(&options.roots)?;
    if options.json {
        print_json(&document);
        if !document.unreadable_directories.is_empty() {
            print_unreadable_directories(&document.unreadable_directories);
        }
    } else {
        print_list(&document);
    }
    // A tree this pass could not read can hold exactly what it was asked
    // about, so the answer is incomplete and the exit code says so. Reported
    // clean, it was read as proof that this machine holds no second checkouts.
    if document.unreadable_directories.is_empty() {
        Ok(0)
    } else {
        Ok(1)
    }
}

fn remove(rest: &[String]) -> Result<i32, CommandError> {
    let Some(options) = parse(rest) else {
        return Ok(usage(EXIT_USAGE));
    };
    let document = remove_document(
        &options.roots,
        &options.except,
        options.apply,
        options.force,
    )?;
    if options.json {
        print_json(&document);
    } else {
        print_remove(&document, options.apply);
    }
    // A preview mutates nothing and is never a failure; only an --apply pass
    // that had to be refused is. A walk that could not read a directory ends
    // both, because neither answer covers the tree the operator named.
    if !document.unreadable_directories.is_empty() {
        // The sentence goes to stderr in both shapes: a caller reading the
        // JSON gets the document, and a caller reading the terminal gets the
        // reason its removal did nothing.
        if options.json {
            print_unreadable_directories(&document.unreadable_directories);
        } else {
            eprintln!(
                "{}",
                incomplete_walk_sentence(&document.unreadable_directories)
            );
        }
        return Ok(1);
    }
    if document.refused.is_empty() || !options.apply {
        return Ok(0);
    }
    if options.json {
        return Ok(1);
    }
    Err(CommandError::Refused(document.refused))
}

fn run(args: &[String]) -> Result<i32, CommandError> {
    let rest = args.get(1..).unwrap_or_default();
    match args.first().map(String::as_str) {
        Some("help" | "--help" | "-h") | None => Ok(usage(0)),
        Some("list") => list(rest),
        Some("remove") => remove(rest),
        _ => Ok(usage(EXIT_USAGE)),
    }
}

pub(crate) fn main(args: &[String]) -> i32 {
    match run(args) {
        Ok(code) => code,
        Err(CommandError::MissingRoot) => {
            eprintln!("{MISSING_ROOT}");
            usage(EXIT_USAGE)
        }
        // One sentence and no usage block: the flag was spelled correctly and
        // the operator needs the path they got wrong, not the whole grammar.
        Err(error @ CommandError::UnknownExcept(_)) => {
            eprintln!("{error}");
            EXIT_USAGE
        }
        Err(error @ CommandError::Refused(_)) => {
            eprintln!("{error}");
            1
        }
        Err(CommandError::Operational(error)) => {
            eprintln!("worktrees: {error}");
            1
        }
    }
}
