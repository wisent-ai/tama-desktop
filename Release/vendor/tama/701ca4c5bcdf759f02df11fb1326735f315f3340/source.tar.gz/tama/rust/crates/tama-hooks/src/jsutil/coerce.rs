//! JavaScript value coercion: the `\s` whitespace class, truthiness, and the
//! `String()` / `Number()` conversions the ported modules rely on.

use serde_json::Value;

/// JS `\s` / `String#trim` whitespace: Unicode `White_Space` plus U+FEFF,
/// which Rust's `char::is_whitespace` does not include.
pub fn is_js_whitespace(c: char) -> bool {
    c.is_whitespace() || c == '\u{feff}'
}

pub fn trim_js(s: &str) -> &str {
    s.trim_matches(is_js_whitespace)
}

/// JS truthiness of a JSON value (`undefined`/`None` is falsy).
pub fn js_truthy(v: Option<&Value>) -> bool {
    match v {
        None | Some(Value::Null) => false,
        Some(Value::Bool(b)) => *b,
        Some(Value::Number(n)) => n.as_f64().is_some_and(|f| f != 0.0),
        Some(Value::String(s)) => !s.is_empty(),
        // Arrays (even empty) and objects are always truthy in JS.
        Some(_) => true,
    }
}

/// JS `String(value)` for a JSON value.
pub fn js_to_string(v: &Value) -> String {
    match v {
        Value::Null => "null".to_string(),
        Value::Bool(b) => if *b { "true" } else { "false" }.to_string(),
        Value::Number(n) => js_number_to_string(n),
        Value::String(s) => s.clone(),
        // Array#toString joins with commas; null/undefined become empty.
        Value::Array(items) => items
            .iter()
            .map(|i| match i {
                Value::Null => String::new(),
                other => js_to_string(other),
            })
            .collect::<Vec<_>>()
            .join(","),
        Value::Object(_) => "[object Object]".to_string(),
    }
}

/// JS `String(value)` where the value may be absent (`undefined`).
pub fn js_to_string_opt(v: Option<&Value>) -> String {
    match v {
        None => "undefined".to_string(),
        Some(v) => js_to_string(v),
    }
}

/// JS `String(value || '')`.
pub fn js_string_or_empty(v: Option<&Value>) -> String {
    match v {
        Some(v) if js_truthy(Some(v)) => js_to_string(v),
        _ => String::new(),
    }
}

/// Approximation of JS `Number#toString` for JSON numbers.
pub fn js_number_to_string(n: &serde_json::Number) -> String {
    if let Some(i) = n.as_i64() {
        return i.to_string();
    }
    if let Some(u) = n.as_u64() {
        return u.to_string();
    }
    let f = n.as_f64().unwrap_or(f64::NAN);
    if f == 0.0 {
        return "0".to_string(); // also covers -0
    }
    let a = f.abs();
    if f.fract() == 0.0 && a < 1e21 {
        return format!("{f:.0}");
    }
    if a >= 1e21 || a < 1e-6 {
        // Rust prints "1.5e21"; JS prints "1.5e+21".
        let s = format!("{f:e}");
        return match s.split_once('e') {
            Some((m, e)) if !e.starts_with('-') => format!("{m}e+{e}"),
            _ => s,
        };
    }
    format!("{f}")
}

/// JS `Number(string)` coercion for the subset relevant to numeric env vars.
pub fn js_number(s: &str) -> f64 {
    let t = trim_js(s);
    if t.is_empty() {
        return 0.0;
    }
    match t {
        "Infinity" | "+Infinity" => return f64::INFINITY,
        "-Infinity" => return f64::NEG_INFINITY,
        _ => {}
    }
    // Hex / octal / binary integer literals (unsigned, per the JS grammar).
    for (prefix, radix) in [
        ("0x", 16u32),
        ("0X", 16),
        ("0o", 8),
        ("0O", 8),
        ("0b", 2),
        ("0B", 2),
    ] {
        if let Some(rest) = t.strip_prefix(prefix) {
            if rest.is_empty() {
                return f64::NAN;
            }
            let mut v = 0f64;
            for c in rest.chars() {
                match c.to_digit(radix) {
                    Some(d) => v = v * radix as f64 + d as f64,
                    None => return f64::NAN,
                }
            }
            return v;
        }
    }
    if !is_js_decimal(t) {
        return f64::NAN;
    }
    t.parse::<f64>().unwrap_or(f64::NAN)
}

fn is_js_decimal(t: &str) -> bool {
    let b = t.as_bytes();
    let mut i = 0;
    if i < b.len() && (b[i] == b'+' || b[i] == b'-') {
        i += 1;
    }
    let mut int_digits = 0;
    while i < b.len() && b[i].is_ascii_digit() {
        i += 1;
        int_digits += 1;
    }
    let mut frac_digits = 0;
    if i < b.len() && b[i] == b'.' {
        i += 1;
        while i < b.len() && b[i].is_ascii_digit() {
            i += 1;
            frac_digits += 1;
        }
    }
    if int_digits == 0 && frac_digits == 0 {
        return false;
    }
    if i < b.len() && (b[i] == b'e' || b[i] == b'E') {
        i += 1;
        if i < b.len() && (b[i] == b'+' || b[i] == b'-') {
            i += 1;
        }
        let mut exp_digits = 0;
        while i < b.len() && b[i].is_ascii_digit() {
            i += 1;
            exp_digits += 1;
        }
        if exp_digits == 0 {
            return false;
        }
    }
    i == b.len()
}

/// `Number.isSafeInteger(value) && value > 0 ? value : null`.
pub fn js_safe_integer_positive(s: &str) -> Option<i64> {
    let v = js_number(s);
    if v.is_finite() && v > 0.0 && v.fract() == 0.0 && v <= 9_007_199_254_740_991.0 {
        Some(v as i64)
    } else {
        None
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn number_coercion() {
        assert_eq!(js_safe_integer_positive("42"), Some(42));
        assert_eq!(js_safe_integer_positive(" 7 "), Some(7));
        assert_eq!(js_safe_integer_positive(""), None); // Number('') === 0
        assert_eq!(js_safe_integer_positive("0"), None);
        assert_eq!(js_safe_integer_positive("-3"), None);
        assert_eq!(js_safe_integer_positive("1.5"), None);
        assert_eq!(js_safe_integer_positive("abc"), None);
        assert_eq!(js_safe_integer_positive("0x10"), Some(16));
        assert_eq!(js_safe_integer_positive("9007199254740992"), None);
    }
}
