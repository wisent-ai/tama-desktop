//! `tama vocabulary-report` — every keyword list still in a repository,
//! grouped by the words themselves.
//!
//! `find-violations` answers "which files break a rule", one finding per
//! file, which is the right shape for a gate and the wrong shape for a
//! repair: the same six words live in four files, and fixing them one file
//! at a time is how they drifted apart in the first place. This report
//! groups every flagged run by its word set and shows each set with all of
//! its sites, the most-repeated first, so a vocabulary is declared once and
//! every site that shares it is changed in the same edit.
//!
//! It reads the same declarations `block-keyword-literals` reads, so a word
//! already declared in `keyword-provenance.json` is not reported here
//! either. Nothing is written.

use std::collections::BTreeMap;
use std::path::Path;

use tama_hook_tools::ports::block_keyword_literals;

use crate::find_violations::files::enumerate_files;

/// One word set and the places it is written.
struct Group {
    words: Vec<String>,
    sites: Vec<String>,
}

fn usage() -> String {
    [
        "tama vocabulary-report --repo <path> [--repo <path>...] [--json]",
        "",
        "Every keyword list still written into code, grouped by its words.",
        "A set written in more than one place is listed first: those are the",
        "copies that drift. Declared words (keyword-provenance.json) are not",
        "reported. The report writes nothing.",
    ]
    .join("\n")
}

fn repositories(argv: &[String]) -> Vec<String> {
    let mut repos = Vec::new();
    let mut index = usize::MIN;
    while index < argv.len() {
        if argv[index] == "--repo" {
            if let Some(path) = argv.get(index + 1) {
                repos.push(path.clone());
            }
            index += 2;
            continue;
        }
        index += 1;
    }
    repos
}

/// The flagged vocabularies of one file, as (words, site) pairs.
fn file_findings(repo: &str, relative: &str) -> Vec<(Vec<String>, String)> {
    let path = Path::new(repo).join(relative);
    let Ok(raw) = std::fs::read_to_string(&path) else {
        return Vec::new();
    };
    let Some(text) = block_keyword_literals::judged_text(relative, &raw) else {
        return Vec::new();
    };
    let declared = block_keyword_literals::declared_words(&path.to_string_lossy());
    block_keyword_literals::vocabularies(&text, &declared)
        .into_iter()
        .map(|(line, _, words)| (words, format!("{relative}:{line}")))
        .collect()
}

fn groups(repos: &[String]) -> Vec<Group> {
    let mut found: BTreeMap<Vec<String>, Vec<String>> = BTreeMap::new();
    for repo in repos {
        let enumeration = enumerate_files(repo);
        for relative in enumeration.files {
            for (words, site) in file_findings(repo, &relative) {
                let mut key = words.clone();
                key.sort();
                found.entry(key).or_default().push(site);
            }
        }
    }
    let mut groups: Vec<Group> = found
        .into_iter()
        .map(|(words, sites)| Group { words, sites })
        .collect();
    // Most-copied first, then the widest vocabulary: both are what a repair
    // should reach for before a one-off list in one file.
    groups.sort_by(|left, right| {
        right
            .sites
            .len()
            .cmp(&left.sites.len())
            .then(right.words.len().cmp(&left.words.len()))
            .then(left.words.cmp(&right.words))
    });
    groups
}

fn as_json(groups: &[Group]) -> serde_json::Value {
    serde_json::json!({
        "vocabularies": groups
            .iter()
            .map(|group| serde_json::json!({
                "words": group.words,
                "sites": group.sites,
                "copies": group.sites.len(),
            }))
            .collect::<Vec<_>>(),
        "vocabularyCount": groups.len(),
        "siteCount": groups.iter().map(|group| group.sites.len()).sum::<usize>(),
    })
}

fn print_text(groups: &[Group]) {
    for group in groups {
        println!(
            "{} site(s): {}",
            group.sites.len(),
            group
                .words
                .iter()
                .map(|word| format!("\"{word}\""))
                .collect::<Vec<_>>()
                .join(", ")
        );
        for site in &group.sites {
            println!("    {site}");
        }
    }
    println!(
        "\nvocabularies: {}, sites: {}",
        groups.len(),
        groups.iter().map(|group| group.sites.len()).sum::<usize>()
    );
}

pub fn main(argv: &[String]) -> i32 {
    if argv.iter().any(|argument| argument == "--help") {
        println!("{}", usage());
        return i32::default();
    }
    let repos = repositories(argv);
    if repos.is_empty() {
        eprintln!("{}", usage());
        return "2".parse().unwrap_or_default();
    }
    let groups = groups(&repos);
    if argv.iter().any(|argument| argument == "--json") {
        println!(
            "{}",
            serde_json::to_string_pretty(&as_json(&groups)).unwrap_or_default()
        );
    } else {
        print_text(&groups);
    }
    i32::default()
}
