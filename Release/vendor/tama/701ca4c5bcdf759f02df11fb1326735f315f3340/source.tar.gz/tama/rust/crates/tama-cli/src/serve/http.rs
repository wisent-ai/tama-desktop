//! Minimal HTTP transport for the serve backend: request parsing under a
//! body-size cap, JSON responses, and the NDJSON job stream. No endpoint
//! logic lives here — see `routes` and `jobs`.

use std::io::{BufRead, BufReader, Read, Write};
use std::net::{Shutdown, TcpStream};
use std::path::PathBuf;
use std::sync::Mutex;

use serde_json::{json, Value};

const MAX_BODY_BYTES: usize = 1024 * 1024;

/// Streamed jobs patch no shared state, but one cleanup mutates one working
/// tree at a time and each job's log events belong on their own response, so
/// jobs run one at a time.
static JOB_LOCK: Mutex<()> = Mutex::new(());

pub(super) struct Request {
    pub method: String,
    pub path: String,
    pub body: Vec<u8>,
}

/// Reads one request: request line, headers, then exactly Content-Length
/// body bytes. Returns None on a closed or unreadable connection — there is
/// no one to report to.
fn read_request(reader: &mut BufReader<TcpStream>) -> std::io::Result<Option<Request>> {
    let mut request_line = String::new();
    if reader.read_line(&mut request_line)? == 0 {
        return Ok(None);
    }
    let mut parts = request_line.split_whitespace();
    let (Some(method), Some(target), _) = (parts.next(), parts.next(), parts.next()) else {
        return Ok(None);
    };
    let mut content_length = 0usize;
    loop {
        let mut line = String::new();
        if reader.read_line(&mut line)? == 0 {
            return Ok(None);
        }
        let trimmed = line.trim();
        if trimmed.is_empty() {
            break;
        }
        if let Some((name, value)) = trimmed.split_once(':') {
            if name.eq_ignore_ascii_case("content-length") {
                content_length = value.trim().parse().unwrap_or(0);
            }
        }
    }
    if content_length > MAX_BODY_BYTES {
        return Ok(Some(Request {
            method: method.to_string(),
            path: "/__body-too-large__".to_string(),
            body: Vec::new(),
        }));
    }
    let mut body = vec![0u8; content_length];
    reader.read_exact(&mut body)?;
    Ok(Some(Request {
        method: method.to_string(),
        path: target.to_string(),
        body,
    }))
}

pub(super) fn handle(stream: TcpStream, root: PathBuf) {
    let Ok(mut writer) = stream.try_clone() else {
        return;
    };
    let mut reader = BufReader::new(stream);
    match read_request(&mut reader) {
        Ok(Some(request)) => super::routes::dispatch(request, &root, &mut writer),
        Ok(None) | Err(_) => {}
    }
}

fn reason(status: u16) -> &'static str {
    match status {
        200 => "OK",
        400 => "Bad Request",
        403 => "Forbidden",
        404 => "Not Found",
        500 => "Internal Server Error",
        _ => "Error",
    }
}

pub(super) fn send_json(writer: &mut TcpStream, status: u16, document: &Value) {
    let body = serde_json::to_vec(document).unwrap_or_default();
    let _ = write!(
        writer,
        "HTTP/1.1 {status} {}\r\ncontent-type: application/json\r\ncontent-length: {}\r\nconnection: close\r\n\r\n",
        reason(status),
        body.len()
    );
    let _ = writer.write_all(&body);
    let _ = writer.shutdown(Shutdown::Both);
}

pub(super) fn send_error(writer: &mut TcpStream, status: u16, message: &str) {
    send_json(writer, status, &json!({ "error": message }));
}

/// The parsed JSON body, or the (status, sentence) of the refusal.
pub(super) fn json_body(request: &Request) -> Result<Value, (u16, String)> {
    let text = String::from_utf8_lossy(&request.body);
    let trimmed = text.trim();
    if trimmed.is_empty() {
        return Ok(json!({}));
    }
    serde_json::from_str(trimmed).map_err(|_| (400, "request body is not valid JSON".to_string()))
}

fn write_event(writer: &mut TcpStream, event: &Value) {
    let mut line = serde_json::to_vec(event).unwrap_or_default();
    line.push(b'\n');
    let _ = writer.write_all(&line);
    let _ = writer.flush();
}

/// Streams one job as NDJSON after a 200 header, mirroring the command:
/// log events in the job's own order, then exactly one result event whose
/// status mirrors the exit code and whose json is the command's document.
pub(super) fn stream_job(
    writer: &mut TcpStream,
    job: impl FnOnce(&mut dyn FnMut(&str, &str)) -> (i32, Value),
) {
    let _ = write!(
        writer,
        "HTTP/1.1 200 OK\r\ncontent-type: application/x-ndjson\r\ncache-control: no-cache\r\nconnection: close\r\n\r\n"
    );
    let _ = writer.flush();
    let _guard = JOB_LOCK.lock();
    {
        let mut emit = |stream: &str, chunk: &str| {
            write_event(
                writer,
                &json!({ "type": "log", "stream": stream, "chunk": chunk }),
            );
        };
        let (status, document) = job(&mut emit);
        write_event(
            writer,
            &json!({ "type": "result", "status": status, "json": document }),
        );
    }
    let _ = writer.shutdown(Shutdown::Both);
}
