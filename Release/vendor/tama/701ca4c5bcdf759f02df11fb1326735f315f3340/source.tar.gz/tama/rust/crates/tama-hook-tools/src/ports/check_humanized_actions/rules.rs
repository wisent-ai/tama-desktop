//! The raw-driver shapes this gate refuses, and the complaint each earns.
//!
//! Hardened on 2026-05-09 after a red-team pass that got past the first
//! version with bracket access, whitespace padding, optional chaining, string
//! concatenation, aliasing, `bind`/`call`/`apply`, a `setTimeout` wait shim
//! and a split-string `evaluate`. Each of those is a row here.

use std::sync::LazyLock;

use regex::Regex;

use crate::ports::transport_common as common;

/// `page` with optional chaining and whitespace on either side of the dot.
const DOTTED: &str = "page[[:space:]]*\\??\\.[[:space:]]*";
/// The Playwright methods a humanized atom exists for, from
/// `methods.json` beside this module. Every rule composes its branch from
/// one of these families, so a method added there is refused in each
/// shape at once — the plain call, the alias, the bracket and the
/// located form — instead of in whichever shape someone remembered.
fn methods(family: &str) -> Vec<String> {
    let document: serde_json::Value = serde_json::from_str(include_str!("methods.json"))
        .expect("methods.json beside this module is valid JSON");
    document[family]
        .as_array()
        .unwrap_or_else(|| panic!("methods.json declares no {family} array"))
        .iter()
        .filter_map(|name| name.as_str().map(str::to_owned))
        .collect()
}

/// `click|fill|type|…` for one family.
fn branch(family: &str) -> String {
    methods(family).join("|")
}

/// One refusable shape: the compiled pattern, whether it is read against the
/// whitespace-collapsed text or the one-line join, and what to say about it.
pub(crate) struct Rule {
    pub(crate) pattern: Regex,
    pub(crate) one_line: bool,
    pub(crate) complaint: String,
}

fn rule(pattern: String, complaint: String) -> Rule {
    Rule {
        pattern: common::compile(&pattern),
        one_line: false,
        complaint,
    }
}

fn joined(pattern: String, complaint: String) -> Rule {
    Rule {
        pattern: common::compile(&pattern),
        one_line: true,
        complaint,
    }
}

fn direct() -> Vec<Rule> {
    methods("direct")
        .iter()
        .map(|method| {
            rule(
                format!("{DOTTED}{method}[[:space:]]*\\("),
                format!(
                    "page.{method}(...) -- use humanized atom (humanClick/humanFill/humanType)"
                ),
            )
        })
        .collect()
}

fn bracketed() -> Vec<Rule> {
    methods("bracket")
        .iter()
        .map(|method| {
            rule(
                format!(
                    "page[[:space:]]*\\[[[:space:]]*[\\x27\\x22]{method}[\\x27\\x22][[:space:]]*\\][[:space:]]*\\("
                ),
                format!("page[\"{method}\"](...) -- use humanized atom"),
            )
        })
        .collect()
}

fn located() -> Vec<Rule> {
    methods("locator")
        .iter()
        .map(|method| {
            rule(
                format!("\\.locator\\([^)]*\\)[[:space:]]*\\.[[:space:]]*{method}[[:space:]]*\\("),
                format!("locator(...).{method}(...) -- use humanized atom"),
            )
        })
        .collect()
}

/// Every rule, in the order the shell checked them.
pub(crate) static RULES: LazyLock<Vec<Rule>> = LazyLock::new(|| {
    let mut rules = direct();
    rules.extend(bracketed());
    rules.push(rule(
        "page[[:space:]]*\\[[^]]*\\+[^]]*\\][[:space:]]*\\(".to_string(),
        "page[<concatenated string>](...) -- string-concat method access; use humanized atom"
            .to_string(),
    ));
    rules.extend(located());
    rules.push(rule(
        format!(
            "({})[[:space:]]+[A-Za-z_$][A-Za-z0-9_$]*[[:space:]]*=[[:space:]]*{DOTTED}({})",
            branch("bindings"),
            branch("bracket")
        ),
        "Aliasing page.click via const/let/var -- bot signal still emitted; use humanized atom"
            .to_string(),
    ));
    rules.push(rule(
        format!(
            "{DOTTED}({})[[:space:]]*\\.[[:space:]]*({})[[:space:]]*\\(",
            branch("bracket"),
            branch("rebinds")
        ),
        "page.click.bind/.call/.apply -- use humanized atom".to_string(),
    ));
    rules.push(rule(
        format!("{DOTTED}waitForTimeout[[:space:]]*\\("),
        "page.waitForTimeout(...) -- use humanIdlePause".to_string(),
    ));
    rules.push(rule(
        "new[[:space:]]+Promise[[:space:]]*\\([^)]*setTimeout".to_string(),
        "new Promise(r => setTimeout(r, N)) -- fixed-cadence sleep; use humanIdlePause".to_string(),
    ));
    rules.push(joined(
        "page[[:space:]]*\\??\\.[[:space:]]*evaluate[[:space:]]*\\([[:space:]]*[\\x27\\x22`]"
            .to_string(),
        "page.evaluate(string) -- string-form invites concat-bypass; use evaluate(() => ...) and \
         humanized atoms instead"
            .to_string(),
    ));
    rules.push(rule(
        "dispatchEvent[[:space:]]*\\([[:space:]]*new[[:space:]]+(MouseEvent|PointerEvent|KeyboardEvent)"
            .to_string(),
        "dispatchEvent(new MouseEvent/PointerEvent/KeyboardEvent) -- isTrusted=false; use \
         humanized atom"
            .to_string(),
    ));
    rules.push(joined(
        "page[[:space:]]*\\.[[:space:]]*evaluate[[:space:]]*\\([^)]*dispatchEvent".to_string(),
        "dispatchEvent inside page.evaluate -- isTrusted=false; use humanized atom".to_string(),
    ));
    rules.push(rule(
        format!("{DOTTED}keyboard[[:space:]]*\\.[[:space:]]*type[[:space:]]*\\("),
        "page.keyboard.type(...) -- use humanType".to_string(),
    ));
    rules.push(rule(
        "(eval|new[[:space:]]+Function)[[:space:]]*\\([^)]*page[[:space:]]*\\.".to_string(),
        "eval/new Function constructing page.* call -- forbidden indirection".to_string(),
    ));
    rules.push(rule(
        "spawn(Sync)?[[:space:]]*\\([^)]*[\\x27\\x22]osascript[\\x27\\x22]".to_string(),
        "spawn osascript for browser automation -- use weles humanized atoms".to_string(),
    ));
    rules.push(rule(
        "[\\x27\\x22]cliclick[\\x27\\x22]".to_string(),
        "cliclick reference -- forbidden".to_string(),
    ));
    rules
});

/// `page.evaluate(` anywhere together with a DOM interaction anywhere is the
/// co-occurrence check: conservative on purpose, because for a gate that
/// decides whether a classifier sees a bot, a false positive costs a comment
/// and a false negative costs the account.
pub(crate) static EVALUATE_CALL: LazyLock<Regex> =
    LazyLock::new(|| common::compile("page[[:space:]]*\\??\\.[[:space:]]*evaluate[[:space:]]*\\("));

pub(crate) static DOM_INTERACTION: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(
        "(\\.click\\(\\)|\\.dispatchEvent|scrollTo|\\.submit\\(\\)|\\.focus\\(\\)|\\.blur\\(\\))",
    )
});

pub(crate) const CO_OCCURRENCE: &str = concat!(
    "page.evaluate(...) co-occurs with .click()/.dispatchEvent/scrollTo/.submit/.focus/.blur ",
    "-- likely a DOM-interaction bypass; use humanClick/humanScroll/humanType",
);
