//! Port of `src/adaptive/state.mjs`: durable per-hook projection store with
//! fact-journal replay, episode block persistence, and legacy quarantine.

mod episodes;
mod durable;
pub mod projections;
mod update;
mod valid;

pub use valid::{valid_state, TransitionResult};

use std::fs::{self, OpenOptions};
use std::io::Write;
use std::path::{Path, PathBuf};

pub use durable::{journal, lock};

use journal::{key_of, FactJournal};
use lock::LockStore;
pub use projections::{
    project_contested_block, project_outcome, HookState, IdentityFacts, Projection,
};

use crate::util::{pretty_json_line, uuid_v4};

const LEGACY_NAMES: [&str; 3] = [
    "overrides.json",
    "provenance-pending.json",
    "numeric-provenance.json",
];
/// The three phases a hook's adaptive state moves through, named here so
/// the words exist once. They were written out again at every transition —
/// `state.phase = "enforcing".to_string()` in four places, `phase ==
/// "warning"` in three — which is a state machine spelled by hand.
pub mod phase {
    /// Watching, refusing nothing.
    pub const OBSERVING: &str = "observing";
    /// Refusing.
    pub const WARNING: &str = "warning";
    /// Refusing and counted against the hook's own record.
    pub const ENFORCING: &str = "enforcing";

    /// Every phase a stored state may name.
    pub const ALL: [&str; 3] = [OBSERVING, ENFORCING, WARNING];
}

/// Shared warn sink (`warn(text)`); failures inside it are swallowed by callers.
pub type Warn = std::sync::Arc<dyn Fn(&str) + Send + Sync>;

pub struct StateStore {
    state_dir: PathBuf,
    projection_dir: PathBuf,
    tmp_dir: PathBuf,
    quarantine_dir: PathBuf,
    episode_dir: PathBuf,
    journal: FactJournal,
    locks: LockStore,
    warn: Warn,
}

impl StateStore {
    fn path_for(&self, hook_id: &str) -> PathBuf {
        self.projection_dir
            .join(format!("{}.json", key_of(hook_id)))
    }

    /// `readState(hookId, requireHealthy)`.
    fn read_state(&self, hook_id: &str, require_healthy: bool) -> Result<HookState, String> {
        let facts = match self.journal.read(hook_id) {
            Some(facts) => facts,
            None => {
                if require_healthy {
                    return Err("adaptive fact journal requires repair".to_string());
                }
                let mut enforced = HookState::initial(hook_id);
                enforced.phase = phase::ENFORCING.to_string();
                return Ok(enforced);
            }
        };
        let checked = fs::read_to_string(self.path_for(hook_id))
            .ok()
            .and_then(|text| serde_json::from_str::<serde_json::Value>(&text).ok())
            .and_then(|parsed| valid_state(&parsed, hook_id));
        if let Some(checked) = &checked {
            if checked.journal_count == facts.len() as i64 {
                return Ok(checked.clone());
            }
        }
        let mut rebuilt = HookState::initial(hook_id);
        for fact in &facts {
            let kind = fact.get("kind").and_then(|v| v.as_str()).unwrap_or("");
            let identity = identity_facts_from(fact.get("identity"));
            let event_id = fact.get("id").and_then(|v| v.as_str()).unwrap_or("");
            let tier = fact.get("tier").and_then(|v| v.as_str()).unwrap_or("");
            let result = match kind {
                "outcome" => {
                    let outcome = fact.get("outcome").and_then(|v| v.as_str()).unwrap_or("");
                    Some(project_outcome(
                        &rebuilt, outcome, tier, &identity, event_id,
                    ))
                }
                "contested-block" => {
                    Some(project_contested_block(&rebuilt, tier, &identity, event_id))
                }
                _ => None,
            };
            match result {
                Some(projection) => {
                    if projection.changed {
                        rebuilt = projection.state;
                    }
                }
                None => {
                    (self.warn)(&format!(
                        "adaptive fact journal contains an unknown fact for {}",
                        hook_id
                    ));
                    return Ok(HookState::initial(hook_id));
                }
            }
        }
        rebuilt.journal_count = facts.len() as i64;
        Ok(
            valid_state(&rebuilt.to_value(), hook_id)
                .unwrap_or_else(|| HookState::initial(hook_id)),
        )
    }

    /// `persist(hookId, state)` — write tmp with `wx`, fsync-free rename.
    fn persist(&self, hook_id: &str, state: &HookState) -> std::io::Result<()> {
        fs::create_dir_all(&self.projection_dir)?;
        fs::create_dir_all(&self.tmp_dir)?;
        let temporary = self.tmp_dir.join(format!("projection-{}.json", uuid_v4()));
        {
            let mut file = OpenOptions::new()
                .write(true)
                .create_new(true)
                .open(&temporary)?;
            file.write_all(pretty_json_line(&state.to_value()).as_bytes())?;
        }
        fs::rename(&temporary, self.path_for(hook_id))?;
        Ok(())
    }

    /// `snapshot(hookId?)` — a single hook state or a map of all states.
    pub fn snapshot(&self, hook_id: Option<&str>) -> serde_json::Value {
        if let Some(hook_id) = hook_id {
            let state = self
                .read_state(hook_id, false)
                .unwrap_or_else(|_| HookState::initial(hook_id));
            return state.to_value();
        }
        let mut states = serde_json::Map::new();
        if let Ok(entries) = fs::read_dir(&self.projection_dir) {
            for entry in entries.flatten() {
                let name = entry.file_name().to_string_lossy().to_string();
                if !name.ends_with(".json") {
                    continue;
                }
                let Ok(text) = fs::read_to_string(entry.path()) else {
                    continue;
                };
                let Ok(parsed) = serde_json::from_str::<serde_json::Value>(&text) else {
                    continue;
                };
                let Some(id) = parsed.get("hookId").and_then(|v| v.as_str()) else {
                    continue;
                };
                let replayed = self
                    .read_state(id, false)
                    .unwrap_or_else(|_| HookState::initial(id));
                states.insert(replayed.hook_id.clone(), replayed.to_value());
            }
        }
        serde_json::Value::Object(states)
    }

    /// `quarantineLegacy()` — move legacy artifacts aside, silently.
    pub fn quarantine_legacy(&self) {
        for name in LEGACY_NAMES {
            let source = self.state_dir.join(name);
            let attempt = (|| -> std::io::Result<()> {
                fs::create_dir_all(&self.quarantine_dir)?;
                fs::rename(
                    &source,
                    self.quarantine_dir.join(format!("{}-{}", name, uuid_v4())),
                )?;
                Ok(())
            })();
            if attempt.is_ok() {
                (self.warn)(&format!("quarantined legacy adaptive artifact {}", name));
            }
        }
    }
}

/// Input to `record_episode_block` (JS observation object).
#[derive(Debug, Clone, Default)]
pub struct EpisodeBlockInput {
    pub session_id: Option<String>,
    pub episode_id: Option<String>,
    pub hook_id: Option<String>,
    pub reason: Option<String>,
}

#[derive(Debug, Clone)]
pub struct EpisodeWriteResult {
    pub persisted: bool,
    pub reason: Option<String>,
}

/// `openStateStore(stateDir, warn)`.
pub fn open_state_store(state_dir: &Path, warn: Warn) -> StateStore {
    StateStore {
        state_dir: state_dir.to_path_buf(),
        projection_dir: state_dir.join("projections"),
        tmp_dir: state_dir.join("tmp"),
        quarantine_dir: state_dir.join("quarantine"),
        episode_dir: state_dir.join("episodes"),
        journal: FactJournal::open(state_dir, warn.clone()),
        locks: LockStore::open(state_dir, warn.clone()),
        warn,
    }
}

/// Extract `IdentityFacts` from a fact's `identity` JSON (lenient).
fn identity_facts_from(value: Option<&serde_json::Value>) -> IdentityFacts {
    let Some(value) = value else {
        return IdentityFacts::default();
    };
    IdentityFacts {
        verifiable: value
            .get("verifiable")
            .and_then(|v| v.as_bool())
            .unwrap_or(false),
        digest: value
            .get("digest")
            .and_then(|v| v.as_str())
            .map(str::to_string),
    }
}
