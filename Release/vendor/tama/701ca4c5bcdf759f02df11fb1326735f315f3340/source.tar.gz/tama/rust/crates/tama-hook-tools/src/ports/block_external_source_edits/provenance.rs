use serde_json::Value;
use std::path::{Path, PathBuf};
use std::process::Command;

const OUR_ORGANIZATION: &str = "wisent-ai";
const GITHUB_REPOSITORY_API: &str = "repos";
// GitHub's fork provenance is stable; gh's bounded cache avoids a network call on every edit.
const PROVENANCE_CACHE: &str = "1h";
const DEPENDENCY_DIRECTORIES: &[&str] = &["node_modules", "site-packages", "Pods", "vendor"];

fn resolve(path: &Path, cwd: &Path) -> Result<PathBuf, String> {
    let absolute = if path.is_absolute() {
        path.to_path_buf()
    } else {
        cwd.join(path)
    };
    let mut existing = absolute.as_path();
    let mut suffix = Vec::new();
    while std::fs::symlink_metadata(existing).is_err() {
        suffix.push(
            existing
                .file_name()
                .ok_or("mutation path has no existing ancestor")?
                .to_owned(),
        );
        existing = existing
            .parent()
            .ok_or("mutation path has no existing ancestor")?;
    }
    let mut resolved = existing
        .canonicalize()
        .map_err(|error| format!("cannot resolve {}: {error}", existing.display()))?;
    for component in suffix.into_iter().rev() {
        resolved.push(component);
    }
    Ok(resolved)
}

fn github_repository(remote: &str) -> Option<&str> {
    let repository = remote
        .strip_prefix("https://github.com/")
        .or_else(|| remote.strip_prefix("ssh://git@github.com/"))
        .or_else(|| remote.strip_prefix("git@github.com:"))?;
    let repository = repository.trim_end_matches('/').trim_end_matches(".git");
    let mut parts = repository.split('/');
    let owner = parts.next()?;
    let name = parts.next()?;
    (!owner.is_empty()
        && !name.is_empty()
        && parts.next().is_none()
        && repository
            .chars()
            .all(|value| value.is_ascii_alphanumeric() || "-_/ .".contains(value))
        && !repository.contains(' '))
    .then_some(repository)
}

fn source_owner(repository: &str) -> Result<Option<String>, String> {
    if !repository
        .split('/')
        .next()
        .is_some_and(|owner| owner.eq_ignore_ascii_case(OUR_ORGANIZATION))
    {
        return Ok(Some(repository.to_owned()));
    }
    let endpoint = format!("{GITHUB_REPOSITORY_API}/{repository}");
    let result = Command::new("gh")
        .args(["api", "--cache", PROVENANCE_CACHE, &endpoint])
        .output()
        .map_err(|error| format!("cannot read GitHub provenance for {repository}: {error}"))?;
    if !result.status.success() {
        return Err(format!(
            "GitHub provenance for {repository} failed: {}",
            String::from_utf8_lossy(&result.stderr).trim()
        ));
    }
    let data: Value = serde_json::from_slice(&result.stdout)
        .map_err(|error| format!("invalid GitHub provenance for {repository}: {error}"))?;
    let owner = data
        .pointer("/owner/login")
        .and_then(Value::as_str)
        .ok_or("GitHub provenance has no repository owner")?;
    if !owner.eq_ignore_ascii_case(OUR_ORGANIZATION) {
        return Ok(Some(
            data["full_name"].as_str().unwrap_or(repository).to_owned(),
        ));
    }
    match data["fork"].as_bool() {
        Some(false) => Ok(None),
        Some(true) => {
            let source = data
                .pointer("/source/full_name")
                .or_else(|| data.pointer("/parent/full_name"))
                .and_then(Value::as_str)
                .ok_or("GitHub fork provenance has no upstream repository")?;
            if source
                .split('/')
                .next()
                .is_some_and(|owner| owner.eq_ignore_ascii_case(OUR_ORGANIZATION))
            {
                Ok(None)
            } else {
                Ok(Some(source.to_owned()))
            }
        }
        None => Err("GitHub provenance has no fork status".into()),
    }
}

pub(super) fn refusal(path: &Path, cwd: &Path) -> Option<String> {
    match inspect(path, cwd) {
        Ok(None) => None,
        Ok(Some(reason)) => Some(format!("BLOCKED: {reason}. Do not patch externally owned source or installed dependencies. Use documented configuration, APIs or separately owned extensions; repair our integration instead. Use Jeden when the requirement would require changing OMP.")),
        Err(error) => Some(format!("BLOCKED: cannot establish source ownership for {}: {error}; no mutation was authorized", path.display())),
    }
}

fn inspect(path: &Path, cwd: &Path) -> Result<Option<String>, String> {
    let resolved = resolve(path, cwd)?;
    let text = resolved.to_string_lossy();
    if resolved.components().any(|part| {
        part.as_os_str()
            .to_str()
            .is_some_and(|name| DEPENDENCY_DIRECTORIES.contains(&name))
    }) || text.contains("/.cargo/registry/")
        || text.contains("/.build/checkouts/")
        || text.contains("/Carthage/Checkouts/")
    {
        return Ok(Some(format!(
            "{} resolves to installed dependency source {}",
            path.display(),
            resolved.display()
        )));
    }
    let Some(root) = resolved
        .ancestors()
        .find(|ancestor| ancestor.join(".git").exists())
    else {
        return Ok(None);
    };
    for name in ["upstream", "origin"] {
        let output = Command::new("git")
            .arg("-C")
            .arg(root)
            .args(["remote", "get-url", name])
            .output()
            .map_err(|error| format!("cannot read {name} at {}: {error}", root.display()))?;
        if !output.status.success() {
            let error = String::from_utf8_lossy(&output.stderr);
            if error.contains("No such remote") {
                continue;
            }
            return Err(format!(
                "reading {name} at {} failed: {}",
                root.display(),
                error.trim()
            ));
        }
        let remote = String::from_utf8_lossy(&output.stdout);
        let remote = remote.trim();
        let repository = github_repository(remote).ok_or_else(|| {
            format!(
                "unsupported ownership provenance {name}={remote} at {}",
                root.display()
            )
        })?;
        if let Some(owner) = source_owner(repository)? {
            return Ok(Some(format!(
                "writing {} would modify {owner}, resolved through {name}={remote} at {}",
                resolved.display(),
                root.display()
            )));
        }
    }
    // An unpublished local repository has no third-party provenance. Ordinary
    // workspace and filesystem permissions still apply; no ownership is invented.
    Ok(None)
}
