//! Whether a new test file was actually asked for.
//!
//! Split out of `pre_write_edit/mod.rs`, which had grown past the
//! three-hundred-line limit. The gate's order of questions stays there; the
//! registry entry, the fifty words, the quote and the transcript check are
//! here.

use std::sync::LazyLock;

use regex::Regex;
use serde_json::Value;
use tama_hooks::session_record::{session_id_of, transcript_path};

use crate::ports::check_numeric_literals_provenance::{quote_in_transcript, quote_in_user_msg};
use crate::ports::python_stdlib::expanduser;
use crate::ports::transport_common as common;

const TEST_REGISTRY: &str = "~/.shared-hooks/test_justifications.json";
const SHOWN_REGISTRY: &str = "~/.shared-hooks/test_justifications.json";
const JUSTIFICATION_KEY: &str = "justification";
const QUOTE_KEY: &str = "user_request_quote";
/// `-lt 50` in the shell.
const MIN_WORDS_TEXT: &str = "50";

static TEST_PATH: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(?i)(/(test|tests|__tests__)/|(^|/)[^/]+\\.(test|spec)\\.[^/]+$",
        "|(^|/)(test_[^/]+|[^/]+_test)\\.py$|(^|/)[^/]+Tests?\\.swift$)",
    ))
});

fn min_words() -> usize {
    MIN_WORDS_TEXT.parse().unwrap_or_default()
}

fn entry(registry: &str, path: &str, key: &str) -> String {
    let Ok(text) = std::fs::read_to_string(registry) else {
        return String::new();
    };
    let Ok(doc) = serde_json::from_str::<Value>(&text) else {
        return String::new();
    };
    doc.get(path)
        .and_then(|found| found.get(key))
        .and_then(Value::as_str)
        .unwrap_or_default()
        .to_string()
}

/// Whether a new test was actually asked for: fifty words of reason, a quote
/// copied from the request, the quote inside the reason, and the quote found
/// in a real user message.
///
/// `verify` is injectable so a test can exercise the four refusals without
/// reading this machine's transcript index.
pub fn test_refusal_with(
    registry: &str,
    path: &str,
    verify: &dyn Fn(&str) -> bool,
) -> Option<String> {
    if !TEST_PATH.is_match(path) || std::path::Path::new(path).exists() {
        return None;
    }
    let reason = entry(registry, path, JUSTIFICATION_KEY);
    if reason.split_whitespace().count() < min_words() {
        return Some(format!(
            "BLOCKED: Need {}+ word justification in {SHOWN_REGISTRY} for new test: {path}",
            min_words()
        ));
    }
    let quote = entry(registry, path, QUOTE_KEY);
    if quote.is_empty() {
        return Some(format!(
            "BLOCKED: Need user_request_quote copied verbatim from the user's direct test \
             request for new test: {path}"
        ));
    }
    if !reason.contains(&quote) {
        return Some(format!(
            "BLOCKED: justification must contain user_request_quote verbatim for new test: {path}"
        ));
    }
    match verify(&quote) {
        true => None,
        false => Some(format!(
            "BLOCKED: user_request_quote is not a verbatim quote from a real role=user \
             transcript message for new test: {path}"
        )),
    }
}

/// A path spelled with `~` names the same file as its expansion; judging the
/// spelling instead of the file called every edit of an existing test a new
/// test whose registry entry, keyed by the expanded path, could not be found.
///
/// The quote is looked for in this session's own transcript first. The
/// index shortlist is twenty-five recent sessions, and on 2026-09-17 every
/// one of them was a Jeden ledger Oko's own handovers had just written, so
/// the words the operator had typed minutes earlier into the session the
/// hook was running for were "not a verbatim quote". The session the write
/// comes from is named in every hook payload and is never off the list.
pub(super) fn test_refusal(payload: &Value, path: &str, is_system: bool) -> Option<String> {
    if is_system {
        return None;
    }
    let own = own_transcript(payload);
    test_refusal_with(&expanduser(TEST_REGISTRY), &expanduser(path), &|quote| {
        own.as_deref()
            .is_some_and(|transcript| quote_in_transcript(transcript, quote))
            || quote_in_user_msg(quote)
    })
}

/// The transcript of the session this hook runs for: the exact path when
/// the runtime supplies one, otherwise the session id's live file.
fn own_transcript(payload: &Value) -> Option<std::path::PathBuf> {
    if let Some(path) = payload.get("transcript_path").and_then(Value::as_str) {
        if !path.is_empty() {
            return Some(std::path::PathBuf::from(path));
        }
    }
    transcript_path(&session_id_of(payload))
}
