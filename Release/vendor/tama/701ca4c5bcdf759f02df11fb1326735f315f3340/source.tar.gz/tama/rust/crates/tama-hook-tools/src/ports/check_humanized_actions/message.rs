//! The refusal, kept verbatim from the shell.
//!
//! It names the atoms because a refusal that only says "use the humanized
//! atoms" sends the reader looking for them, and it names both bypasses
//! because the gate is inclusive on purpose and out-of-scope code has to be
//! able to say so.

const WHY: &str = concat!(
    "Why: bot classifiers (LinkedIn, TikTok, reCAPTCHA Enterprise, Arkose, hCaptcha)\n",
    "read event.isTrusted, scroll cadence, and click timing. Raw page.* actions emit\n",
    "isTrusted=false or fixed cadence and get classified as bot.",
);

const ATOMS: &str = concat!(
    "Use the humanized atoms from weles/src/human/:\n",
    "  humanClick(page, x, y) / humanClickLocator(page, locator)\n",
    "  humanFill(page, locator, text)\n",
    "  humanType(page, text)\n",
    "  humanScroll(page, deltaY, bursts)\n",
    "  humanIdlePause('short' | 'deliberate' | 'long')\n",
    "  humanMove(page, x, y)",
);

const BYPASS: &str = concat!(
    "Per-call bypass: append '// allow-raw-playwright: <reason>' on the same line.\n",
    "Whole-call bypass: HOOK_RAW_PLAYWRIGHT_AUTHORIZED=1.",
);

pub(crate) fn refusal(path: &str, found: &[String]) -> String {
    let listed = found
        .iter()
        .map(|item| format!("  - {item}"))
        .collect::<Vec<_>>()
        .join("\n");
    format!(
        "BLOCKED: raw Playwright / non-humanized browser action in {path}\n\n{listed}\n\n{WHY}\n\n\
         {ATOMS}\n\n{BYPASS}"
    )
}
