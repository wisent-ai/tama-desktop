//! Decision half of `tama-block-broken-judge` (registry hook
//! `block-broken-judge`).
//!
//! On 2026-09-21 a session ran `oko-cli transcripts tasks verify
//! --before-stop` six times in a row. Every run spent about a minute reading
//! the transcript, asked Brama, and printed `judged 0 task(s)` with the
//! gateway's refusal under it: `HTTP 429 subscription_unavailable`, because
//! the one usable codex credential was inside a weekly quota block. Nothing
//! was judged and nothing could be. The operator, watching the seventh:
//! "skoro sedzia nie dziala. to dlaczego tego uzywasz idioto. dodaj nowego
//! hooka ktory blokuje to polecenie i pisze SEDZIA NIE DZIALA. NIE UZYWAJ
//! TEGO DOPOKI USTERKA NIE BEDZIE NAPRAWIONA".
//!
//! So the refusal is his sentence, and it stands exactly while Oko's own
//! record of the judge says the judge does not answer. That record is
//! `judge-health.json` beside the transcript index: every verification pass
//! writes it, and `oko-cli transcripts tasks judge --probe` writes it from
//! one cheap question. When the probe sees the judge answer, this gate stops
//! refusing on its own - nobody edits a hook to lift it.
//!
//! Nothing is classified here. The gate reads the command the way a shell
//! does ([`crate::ports::shell_text`]), matches the product's own command
//! path from `vocabulary.json`, and then asks Oko's file what the judge did
//! last time anybody asked it.

use std::path::PathBuf;
use std::sync::LazyLock;

use serde::Deserialize;
use serde_json::Value;

use crate::ports::python_stdlib::shell_tokens;
use crate::ports::pyvalue::{first_truthy_py_str, py_str, truthy};
use crate::ports::shell_text;
use crate::ports::tool_vocabulary::{COMMAND_KEYS, TOOL_INPUT_KEY};

/// The operator's sentence, verbatim. It opens the refusal because it is the
/// refusal; everything after it is what to do about it.
const SENTENCE: &str = "SEDZIA NIE DZIALA. NIE UZYWAJ TEGO DOPOKI USTERKA NIE BEDZIE NAPRAWIONA";
const BANNER: &str = "BLOCKED: ";
const HELP_FLAG: &str = "--help";
const FLAG_PREFIX: char = '-';
const PATH_SEPARATOR: char = '/';
/// Where Oko writes what it last saw of the judge, and the variable that
/// moves it for a test.
const HEALTH_ENV: &str = "OKO_JUDGE_HEALTH_PATH";
const HEALTH_HOME_PATH: &str = "Library/Application Support/Oko/judge-health.json";
const HOME_ENV: &str = "HOME";
const PROBE: &str = "oko-cli transcripts tasks judge --probe";

/// The command this gate is about: the product's own path to it, as data
/// rather than a guess about what anyone meant.
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Vocabulary {
    #[allow(dead_code)]
    why: String,
    /// The program that judges tasks.
    program: String,
    /// The words after it that reach the judge, in order.
    path: Vec<String>,
}

static VOCABULARY: LazyLock<Vocabulary> = LazyLock::new(|| {
    serde_json::from_str(include_str!("vocabulary.json"))
        .expect("block_broken_judge/vocabulary.json is the gate's own data and must parse")
});

/// What Oko recorded about the judge, spelled as Oko writes it. Only the
/// three fields this gate reads are named; Oko may write more.
#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
struct JudgeHealth {
    answering: bool,
    #[serde(default)]
    detail: String,
    #[serde(default)]
    checked_at: Option<String>,
}

fn command_from(payload: &Value) -> String {
    let Some(raw) = payload.get(TOOL_INPUT_KEY).filter(|value| truthy(value)) else {
        return String::new();
    };
    if raw.is_object() {
        let named = first_truthy_py_str(raw, COMMAND_KEYS);
        if !named.is_empty() {
            return named;
        }
    }
    py_str(raw)
}

fn basename(token: &str) -> &str {
    token.rsplit(PATH_SEPARATOR).next().unwrap_or(token)
}

/// The program a command runs and the words after it, with wrappers stepped
/// over and the program's directory dropped.
fn program_and_args(tokens: &[String]) -> Option<(&str, &[String])> {
    let program = shell_text::program(tokens)?;
    let start = tokens.iter().position(|token| basename(token) == program)?;
    Some((program, &tokens[start + 1..]))
}

/// Whether these words run the judge: the declared path in order, ignoring
/// flags, and never a request for help.
fn asks_for_a_verdict(program: &str, args: &[String]) -> bool {
    let words = &*VOCABULARY;
    if program != words.program || args.iter().any(|arg| arg == HELP_FLAG) {
        return false;
    }
    let mut plain = args
        .iter()
        .map(String::as_str)
        .filter(|arg| !arg.starts_with(FLAG_PREFIX));
    words.path.iter().all(|step| plain.next() == Some(step))
}

/// Oko's record of the judge, read where Oko keeps it.
fn health_path() -> Option<PathBuf> {
    if let Ok(configured) = std::env::var(HEALTH_ENV) {
        let trimmed = configured.trim();
        if !trimmed.is_empty() {
            return Some(PathBuf::from(trimmed));
        }
    }
    let home = std::env::var(HOME_ENV).ok()?;
    Some(PathBuf::from(home).join(HEALTH_HOME_PATH))
}

fn recorded_health() -> Option<JudgeHealth> {
    let text = std::fs::read_to_string(health_path()?).ok()?;
    serde_json::from_str(&text).ok()
}

/// Why this command is refused, if it is.
///
/// A judge that answered is not refused. A judge nobody has ever asked on
/// this machine is refused too: the gate is about spending a minute to learn
/// something the probe answers in a second, and an unread state is exactly
/// that question.
pub fn evaluate(payload: &Value) -> Option<String> {
    let command = command_from(payload);
    if command.trim().is_empty() {
        return None;
    }
    let acting = shell_text::effective_command(&command);
    shell_text::commands(&acting)
        .into_iter()
        .map(shell_tokens)
        .find_map(|tokens| {
            let (program, args) = program_and_args(&tokens)?;
            if !asks_for_a_verdict(program, args) {
                return None;
            }
            match recorded_health() {
                Some(health) if health.answering => None,
                Some(health) => Some(format!(
                    "{BANNER}{SENTENCE}. Oko last saw the judge refuse{}: {}. Nothing here is judged until \
                     that is repaired; `{PROBE}` asks it one question and lifts this by itself when the \
                     judge answers.",
                    health
                        .checked_at
                        .map(|at| format!(" at {at}"))
                        .unwrap_or_default(),
                    health.detail
                )),
                None => Some(format!(
                    "{BANNER}{SENTENCE}. Nothing on this machine has observed the judge, so a pass would \
                     spend a minute to find out what `{PROBE}` answers in one question; run that first."
                )),
            }
        })
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;
    use std::sync::Mutex;

    /// The environment is process-wide; the cases that move the health file
    /// take turns.
    static ENVIRONMENT: Mutex<()> = Mutex::new(());

    fn payload(command: &str) -> Value {
        json!({ "tool_input": { "command": command } })
    }

    /// The state a case writes lives in the crate's own build directory:
    /// nothing this repository runs writes outside its checkout.
    fn scratch() -> PathBuf {
        PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .join("../../target/block-broken-judge")
    }

    fn with_health(state: Option<&str>, body: impl FnOnce()) {
        let guard = ENVIRONMENT.lock().unwrap_or_else(|held| held.into_inner());
        let directory = scratch();
        std::fs::create_dir_all(&directory).expect("the crate's build directory is writable");
        let file = directory.join(format!("judge-health-{}.json", std::process::id()));
        match state {
            Some(text) => std::fs::write(&file, text).expect("the case writes its own state"),
            None => {
                let _ = std::fs::remove_file(&file);
            }
        }
        std::env::set_var(HEALTH_ENV, &file);
        body();
        std::env::remove_var(HEALTH_ENV);
        let _ = std::fs::remove_file(&file);
        drop(guard);
    }

    #[test]
    fn refuses_a_verification_pass_while_the_judge_refuses() {
        with_health(
            Some(r#"{"answering":false,"checkedAt":"2026-09-21T22:13:40Z","detail":"Brama answered HTTP 429","observedBy":"transcripts tasks verify"}"#),
            || {
                let refusal = evaluate(&payload(
                    "oko-cli transcripts tasks verify --before-stop --session 01a0c266",
                ))
                .expect("a refusing judge refuses the pass");
                assert!(refusal.contains(SENTENCE), "{refusal}");
                assert!(refusal.contains("Brama answered HTTP 429"), "{refusal}");
                assert!(refusal.contains(PROBE), "{refusal}");
            },
        );
    }

    #[test]
    fn passes_while_the_judge_answers() {
        with_health(
            Some(r#"{"answering":true,"checkedAt":"2026-09-21T22:13:40Z","detail":"answered by openrouter/openai/gpt-4.1-mini","observedBy":"transcripts tasks judge --probe"}"#),
            || {
                assert_eq!(
                    evaluate(&payload("oko-cli transcripts tasks verify --open")),
                    None
                );
            },
        );
    }

    #[test]
    fn refuses_when_nothing_has_observed_the_judge() {
        with_health(None, || {
            let refusal = evaluate(&payload("oko-cli transcripts tasks verify --open"))
                .expect("an unobserved judge is not a working one");
            assert!(refusal.contains(SENTENCE), "{refusal}");
            assert!(refusal.contains(PROBE), "{refusal}");
        });
    }

    #[test]
    fn leaves_the_probe_and_the_other_reads_alone() {
        with_health(Some(r#"{"answering":false,"detail":"HTTP 429"}"#), || {
            for command in [
                "oko-cli transcripts tasks judge --probe",
                "oko-cli transcripts tasks --session 01a0c266 --json",
                "oko-cli transcripts tasks verify --help",
                "echo oko-cli transcripts tasks verify",
            ] {
                assert_eq!(evaluate(&payload(command)), None, "{command}");
            }
        });
    }

    #[test]
    fn reads_the_command_the_way_a_shell_does() {
        with_health(Some(r#"{"answering":false,"detail":"HTTP 429"}"#), || {
            let refusal = evaluate(&payload(
                "cd ~/oko && /Users/x/.local/bin/oko-cli transcripts tasks verify --open",
            ));
            assert!(refusal.is_some(), "a path and a wrapper are the same command");
        });
    }
}
