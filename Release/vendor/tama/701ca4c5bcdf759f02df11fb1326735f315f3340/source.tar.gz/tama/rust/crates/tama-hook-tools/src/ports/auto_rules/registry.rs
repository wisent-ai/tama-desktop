//! The rules themselves: the rows the shell carried, and the rows the
//! registry file adds.
//!
//! Split out of `auto_rules/mod.rs`, which had grown past the
//! three-hundred-line limit. Matching a rule against a write or a command
//! stays there; what a rule is, and where the list comes from, is here.

use serde_json::Value;

use super::{Rule, Target};
use crate::ports::python_stdlib::expanduser;

const REGISTRY_PATH: &str = "~/.shared-hooks/auto_rules.json";
const RULES_KEY: &str = "rules";
const ID_KEY: &str = "id";
const TARGET_KEY: &str = "target";
const PATTERN_KEY: &str = "pattern";
const MESSAGE_KEY: &str = "message";
const PATH_TARGET: &str = "path";
const CONTENT_TARGET: &str = "content";
const COMMAND_TARGET: &str = "command";

/// The rules the shell carried, each with the incident that produced it.
pub(crate) const DEFAULTS: &[Rule] = &[
    Rule {
        id: "registry-as-markdown",
        added: "2026-06-09",
        target: Target::Path,
        pattern: "[Rr][Ee][Gg][Ii][Ss][Tt][Rr][Yy][^/]*\\.md$",
        message: "BLOCKED: Registries must be structured data (.json), never .md — write the \
                  registry as JSON instead.",
        why: "The operator found a registry stored as Markdown prose. A registry is read by \
              tools, so it is machine-readable data or it is not a registry.",
    },
    Rule {
        id: "page-limited-manuscript",
        added: "2026-05-17",
        target: Target::Path,
        pattern: "paper_revised_35pageslimit\\.(tex|pdf)",
        message: "BLOCKED: Blocked: paper_revised_35pageslimit is a page-limited shared \
                  artifact. Verify page count vs the 35-page limit and confirm with the user \
                  before writing/merging.",
        why: "A stale long branch was merged over the operator's condensation, inflating a \
              35-page submission to 38 pages, and it was committed and pushed.",
    },
    Rule {
        id: "pseudo-extension-source",
        added: "2026-07-19",
        target: Target::Path,
        pattern: "\\.source$",
        message: "BLOCKED: pseudo-extension .source is forbidden. Write real modules \
                  (.js/.mjs/.ts/.py/...) with ordinary imports/exports, not source fragments \
                  glued back at runtime.",
        why: "A clean-gate agent split an oversized module into 01-*.source pseudo-files and \
              glued them back with a runtime import, dodging the line limit in spirit.",
    },
];

pub(super) fn registry_path() -> String {
    expanduser(REGISTRY_PATH)
}

fn target_of(value: &Value) -> Option<Target> {
    match value.get(TARGET_KEY).and_then(Value::as_str)? {
        PATH_TARGET => Some(Target::Path),
        CONTENT_TARGET => Some(Target::Content),
        COMMAND_TARGET => Some(Target::Command),
        _ => None,
    }
}

/// The rows the registry adds, as (id, target, pattern, message).
pub(super) fn recorded(path: &str) -> Vec<(String, Target, String, String)> {
    let Ok(text) = std::fs::read_to_string(path) else {
        return Vec::new();
    };
    let Ok(doc) = serde_json::from_str::<Value>(&text) else {
        return Vec::new();
    };
    let Some(Value::Array(rows)) = doc.get(RULES_KEY) else {
        return Vec::new();
    };
    rows.iter()
        .filter_map(|row| {
            let id = row.get(ID_KEY).and_then(Value::as_str).unwrap_or_default();
            let target = target_of(row)?;
            let pattern = row.get(PATTERN_KEY).and_then(Value::as_str)?;
            let message = row.get(MESSAGE_KEY).and_then(Value::as_str)?;
            Some((
                id.to_string(),
                target,
                pattern.to_string(),
                message.to_string(),
            ))
        })
        .collect()
}
