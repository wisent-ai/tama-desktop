//! Endpoint dispatch and the non-streamed handlers: the `/v1` route match,
//! enforcement updates, and policy-bundle imports with their exact refusal
//! sentences. Streamed scan/clean jobs live in the sibling `jobs` module.

use std::net::TcpStream;
use std::path::Path;

use serde_json::{json, Value};
use tama_core::install::level_plan;
use tama_core::policy_bundle::{
    import_policy_bundle, list_policy_bundles, ImportPolicyBundleOptions,
};
use tama_core::runtime::declared_provider_coverage;

use super::http::{json_body, send_error, send_json, Request};
use crate::mcp_config;

pub(super) fn dispatch(request: Request, root: &Path, writer: &mut TcpStream) {
    let path = request.path.split('?').next().unwrap_or("");
    match (request.method.as_str(), path) {
        ("GET", "/v1/health") => send_json(writer, 200, &json!({ "status": "ok" })),
        ("GET", "/v1/enforcement") => match crate::enforcement::status(root) {
            Ok(status) => send_json(
                writer,
                200,
                &serde_json::to_value(status).unwrap_or_default(),
            ),
            Err(error) => send_error(writer, 500, &error),
        },
        ("GET", "/v1/coverage") => match declared_provider_coverage(root) {
            Ok(coverage) => send_json(
                writer,
                200,
                &serde_json::to_value(coverage).unwrap_or_default(),
            ),
            Err(error) => send_error(writer, 500, &error.to_string()),
        },
        ("GET", "/v1/install-plan") => send_json(
            writer,
            200,
            &serde_json::to_value(level_plan(root, None, None)).unwrap_or_default(),
        ),
        ("GET", "/v1/mcp-config") => send_json(
            writer,
            200,
            &serde_json::to_value(mcp_config()).unwrap_or_default(),
        ),
        ("GET", "/v1/policy-bundles") => match list_policy_bundles(None) {
            Ok(bundles) => send_json(
                writer,
                200,
                &serde_json::to_value(bundles).unwrap_or_default(),
            ),
            Err(error) => send_error(writer, 500, &error.to_string()),
        },
        ("POST", "/v1/enforcement") => enforcement_update(request, root, writer),
        ("POST", "/v1/hooks/warm") => hooks_warm(request, root, writer),
        ("POST", "/v1/policy-bundles/import") => policy_import(request, writer),
        ("POST", "/v1/violations/scan") => super::jobs::scan_job(request, root, writer),
        ("POST", "/v1/violations/clean") => super::jobs::clean_job(request, root, writer),
        ("POST", "/v1/worktrees/list") => worktrees_list(request, writer),
        ("POST", "/v1/worktrees/remove") => worktrees_remove(request, writer),
        ("POST", "/v1/copies/list") => super::copies::list(request, writer),
        ("POST", "/v1/copies/remove") => super::copies::remove(request, writer),
        ("GET", "/v1/builds") | ("POST", "/v1/builds/record") | ("POST", "/v1/builds/close") => {
            super::builds::handle(request, writer)
        }
        ("GET", "/v1/justifications/cua")
        | ("POST", "/v1/justifications/cua/record")
        | ("POST", "/v1/justifications/cua/remove")
        | ("POST", "/v1/justifications/record") => super::justifications::handle(request, writer),
        (_, "/__body-too-large__") => send_error(writer, 400, "request body too large"),
        _ => send_error(
            writer,
            404,
            &format!("unknown endpoint: {} {path}", request.method),
        ),
    }
}

/// Warming from the screen, with the answer the command prints. A machine
/// whose gates have never run pays the operating system's first-run
/// assessment inside the next live event, where everybody waits it out; the
/// desktop needs the same way out as the terminal.
fn hooks_warm(request: Request, root: &Path, writer: &mut TcpStream) {
    let only: Vec<String> = match json_body(&request) {
        Ok(body) => body
            .get("only")
            .and_then(Value::as_array)
            .map(|ids| {
                ids.iter()
                    .filter_map(Value::as_str)
                    .map(str::to_string)
                    .collect()
            })
            .unwrap_or_default(),
        // An empty body means every hook, which is the ordinary request.
        Err(_) => Vec::new(),
    };
    match crate::hooks::warm::select(root, &only) {
        Ok(selected) => {
            let warmed = crate::hooks::warm::warm_hooks(root, &selected);
            send_json(writer, 200, &crate::hooks::warm::report_value(&warmed))
        }
        Err(error) => send_error(writer, 400, &error),
    }
}

fn enforcement_update(request: Request, root: &Path, writer: &mut TcpStream) {
    let body = match json_body(&request) {
        Ok(body) => body,
        Err((status, message)) => return send_error(writer, status, &message),
    };
    let Some(mode) = body.get("mode").and_then(Value::as_str) else {
        return send_error(writer, 400, "mode must be \"all\" or \"only\"");
    };
    let result = match mode {
        "all" => {
            let has_enabled = body
                .get("enabled")
                .and_then(Value::as_array)
                .is_some_and(|ids| !ids.is_empty());
            if has_enabled {
                return send_error(writer, 400, "enabled must be empty when mode is \"all\"");
            }
            crate::enforcement::set_all(root)
        }
        "only" => {
            let Some(values) = body.get("enabled").and_then(Value::as_array) else {
                return send_error(
                    writer,
                    400,
                    "enabled must be a non-empty array for mode \"only\"",
                );
            };
            let Some(enabled) = values.iter().map(Value::as_str).collect::<Option<Vec<_>>>() else {
                return send_error(writer, 400, "enabled must contain only hook id strings");
            };
            if enabled.is_empty() {
                return send_error(
                    writer,
                    400,
                    "enabled must be a non-empty array for mode \"only\"",
                );
            }
            let enabled: Vec<String> = enabled.into_iter().map(str::to_string).collect();
            crate::enforcement::set_only(root, &enabled)
        }
        _ => return send_error(writer, 400, "mode must be \"all\" or \"only\""),
    };
    match result {
        Ok(status) => send_json(
            writer,
            200,
            &serde_json::to_value(status).unwrap_or_default(),
        ),
        // A hook the machine cannot run is a refusal the caller can act on,
        // the same as an unknown id, so the app shows the sentence rather than
        // an internal failure.
        Err(
            error @ (crate::enforcement::CommandError::UnknownHook { .. }
            | crate::enforcement::CommandError::Unusable { .. }),
        ) => send_error(writer, 400, &error.to_string()),
        Err(error) => send_error(writer, 500, &error.to_string()),
    }
}

fn policy_import(request: Request, writer: &mut TcpStream) {
    let body = match json_body(&request) {
        Ok(body) => body,
        Err((status, message)) => {
            send_error(writer, status, &message);
            return;
        }
    };
    let Some(source) = body.get("sourcePath").and_then(Value::as_str) else {
        send_error(writer, 400, "sourcePath is required");
        return;
    };
    if source.trim().is_empty() {
        send_error(writer, 400, "sourcePath is required");
        return;
    }
    let replace = body
        .get("replace")
        .and_then(Value::as_bool)
        .unwrap_or(false);
    match import_policy_bundle(ImportPolicyBundleOptions {
        source: Path::new(source),
        home: None,
        replace,
    }) {
        Ok(result) => send_json(
            writer,
            200,
            &serde_json::to_value(result).unwrap_or_default(),
        ),
        Err(error) => send_error(writer, 400, &error.to_string()),
    }
}

/// The `roots` array both worktree endpoints take. Missing or empty is the
/// command's own usage refusal, sentence included, as a 400.
fn worktree_roots(body: &Value) -> Result<Vec<String>, String> {
    let roots: Vec<String> = body
        .get("roots")
        .and_then(Value::as_array)
        .map(|values| {
            values
                .iter()
                .filter_map(Value::as_str)
                .filter(|root| !root.is_empty())
                .map(str::to_string)
                .collect()
        })
        .unwrap_or_default();
    if roots.is_empty() {
        return Err(crate::worktrees::MISSING_ROOT.to_string());
    }
    Ok(roots)
}

/// `tama worktrees list --root <PATH>... --json` over the loopback: the
/// desktop screen shows which second checkouts exist before offering to
/// remove them.
fn worktrees_list(request: Request, writer: &mut TcpStream) {
    let body = match json_body(&request) {
        Ok(body) => body,
        Err((status, message)) => return send_error(writer, status, &message),
    };
    let roots = match worktree_roots(&body) {
        Ok(roots) => roots,
        Err(message) => return send_error(writer, 400, &message),
    };
    match crate::worktrees::list_document(&roots) {
        Ok(document) => send_json(
            writer,
            200,
            &serde_json::to_value(document).unwrap_or_default(),
        ),
        Err(error) => send_error(writer, 500, &error.to_string()),
    }
}

/// `tama worktrees remove ... --json`. A refused pass is not a transport
/// failure: the document carries `applied: false` plus every refusal, exactly
/// as the command reports them.
fn worktrees_remove(request: Request, writer: &mut TcpStream) {
    let body = match json_body(&request) {
        Ok(body) => body,
        Err((status, message)) => return send_error(writer, status, &message),
    };
    let roots = match worktree_roots(&body) {
        Ok(roots) => roots,
        Err(message) => return send_error(writer, 400, &message),
    };
    let flag = |name: &str| body.get(name).and_then(Value::as_bool).unwrap_or(false);
    // Optional, empty when absent: a client built before `--except` existed
    // keeps sending three fields and keeps getting the same pass.
    let except: Vec<String> = body
        .get("except")
        .and_then(Value::as_array)
        .map(|values| {
            values
                .iter()
                .filter_map(Value::as_str)
                .filter(|path| !path.is_empty())
                .map(str::to_string)
                .collect()
        })
        .unwrap_or_default();
    match crate::worktrees::remove_document(&roots, &except, flag("apply"), flag("force")) {
        Ok(document) => send_json(
            writer,
            200,
            &serde_json::to_value(document).unwrap_or_default(),
        ),
        Err(error) => send_error(writer, 500, &error.to_string()),
    }
}
