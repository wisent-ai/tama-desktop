//! Logic for `tama-check-artifact-inspection`: a trajectory may not run
//! again until somebody has looked at what the last run produced.
//!
//! Three ways to satisfy it, in order: a first run with either the operator's
//! explicit permission or two hundred characters of human-written notes; a
//! marker that validates against the newest recording and a frame read in
//! this session; or evidence in the transcript that an artifact of this label
//! was opened.
//!
//! "First run is free" was removed on purpose: an agent that invents a new
//! file name for every run would otherwise have an unlimited supply of free
//! first runs, and the recordings on disk already prove the label has run.

mod artifacts;
mod marker;
mod transcript;

use std::path::{Path, PathBuf};

const FIRST_RUN_ENV: &str = "WELES_FIRST_RUN";
const FIRST_RUN_VALUE: &str = "1";
const FIRST_RUN_REASON: &str = concat!(
    "first-run requires WELES_FIRST_RUN=1 env or 200+ char ",
    ".work/<label>/inspection.md",
);
const RULE: &str = "============================================================";
/// A refusal is exit 2, as every other gate on this machine.
const REFUSAL_STATUS_TEXT: &str = "2";

fn refusal_status() -> i32 {
    REFUSAL_STATUS_TEXT.parse().unwrap_or_default()
}

/// The refusal, in the shape the operator reads in his terminal.
fn refusal(repo: &Path, label: &str, runs: i64, why: &str) -> String {
    let mut lines: Vec<String> = vec![
        RULE.to_string(),
        format!(
            "  BLOCKED: trajectory '{label}' run #{} without inspection",
            runs + 1
        ),
        format!("  reason: {why}"),
        RULE.to_string(),
        String::new(),
    ];
    let candidates = artifacts::candidates(repo, label);
    if !candidates.is_empty() {
        lines.push("Candidate artifacts on disk for this label:".to_string());
        lines.extend(candidates);
    }
    lines.push(String::new());
    lines.push("Unblock by ONE of:".to_string());
    lines.push(format!(
        "  (a) $HOME/.shared-hooks/inspect_trajectory.sh {label}"
    ));
    lines.push("      writes a sha256-validating marker the hook can verify.".to_string());
    lines.push(format!(
        "  (b) Read tool on .work/{label}/ frames or recordings/{label}/"
    ));
    lines.push("      paths in this session — transcript scanner is label-pinned.".to_string());
    lines.join("\n")
}

/// Whether this trajectory may run, and the refusal if it may not.
pub fn verdict(repo: &Path, label: &str, transcript_path: &str) -> Result<(), String> {
    if label.is_empty() {
        return Ok(());
    }
    let runs = artifacts::runs_since_inspection(label);
    let recordings = artifacts::recordings(repo, label);
    if runs == 0 && recordings.is_empty() {
        let permitted = std::env::var(FIRST_RUN_ENV).ok().as_deref() == Some(FIRST_RUN_VALUE);
        let notes = artifacts::notes(repo, label);
        let written = std::fs::metadata(&notes)
            .map(|meta| meta.len() >= artifacts::notes_min_bytes())
            .unwrap_or_default();
        return match permitted || written {
            true => Ok(()),
            false => Err(refusal(repo, label, runs, FIRST_RUN_REASON)),
        };
    }
    let (validated, why) = marker::validates(repo, label, transcript_path);
    if validated {
        return Ok(());
    }
    if !transcript::shows_label_inspection(repo, label, transcript_path).is_empty() {
        return Ok(());
    }
    Err(refusal(repo, label, runs, &why))
}

/// `check_artifact_inspection.py <label> <command> <transcript>`.
pub fn run() {
    let args: Vec<String> = std::env::args().skip(true as usize).collect();
    let label = args.first().cloned().unwrap_or_default();
    let transcript_path = args
        .get(true as usize + true as usize)
        .cloned()
        .unwrap_or_default();
    let repo = std::env::current_dir().unwrap_or_else(|_| PathBuf::from("."));
    if let Err(refusal) = verdict(&repo, &label, &transcript_path) {
        eprintln!("{refusal}");
        std::process::exit(refusal_status());
    }
}

#[cfg(test)]
mod tests {
    use super::verdict;
    use std::path::{Path, PathBuf};

    fn scratch(name: &str) -> PathBuf {
        let dir = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../target/tmp")
            .join(format!("tama-inspection-{name}"));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).expect("a folder for the fixture");
        dir
    }

    #[test]
    fn a_label_nobody_named_is_not_this_gates_business() {
        assert!(verdict(Path::new("/repo"), "", "").is_ok());
    }

    /// A first run with nothing on disk and nothing written is refused, and
    /// the refusal says which two keys open it.
    #[test]
    fn a_first_run_needs_permission_or_notes() {
        let repo = scratch("first-run");
        let refusal = verdict(&repo, "tama-unknown-label", "").expect_err("nothing to look at");
        assert!(refusal.contains("without inspection"), "{refusal}");
        assert!(refusal.contains("WELES_FIRST_RUN=1"), "{refusal}");
        assert!(refusal.contains("inspect_trajectory.sh"), "{refusal}");
        let _ = std::fs::remove_dir_all(&repo);
    }

    /// Two hundred characters of human-written notes is the other key.
    #[test]
    fn written_notes_open_the_first_run() {
        let repo = scratch("notes");
        let label = "tama-unknown-label";
        let work = repo.join(".work").join(label);
        std::fs::create_dir_all(&work).expect("a work directory");
        std::fs::write(work.join("inspection.md"), "x".repeat(200)).expect("the notes");
        assert!(verdict(&repo, label, "").is_ok());
        let _ = std::fs::remove_dir_all(&repo);
    }
}
