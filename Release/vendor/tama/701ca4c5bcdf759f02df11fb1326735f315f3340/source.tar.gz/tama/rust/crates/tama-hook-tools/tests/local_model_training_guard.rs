//! `tama-block-local-model-training`, driven as the real binary with a real
//! payload on stdin.
//!
//! The operator's rule is that training runs on a fleet host through Stado,
//! never on his workstation. On 2026-09-17 a LoRA training of a 1.7B
//! checkpoint ran here twice and took the machine from every other job he
//! had open: "zablokuj takie debilizmy na przyszlosc. to jest krytyczny
//! blad." Each case holds one command to its exit status and, when refused,
//! to the exact refusal sentence.

use std::io::Write as _;
use std::process::{Command, Output, Stdio};

use serde_json::json;

const EXIT_PASS: i32 = false as i32;
const EXIT_REFUSED: i32 = true as i32 + true as i32;

const GUARD: &str = env!("CARGO_BIN_EXE_tama-block-local-model-training");
const APPROVAL_VARIABLE: &str = "LOCAL_MODEL_TRAINING_APPROVED";

fn refusal(detected: &str) -> String {
    format!(
        "BLOCKED: model training and whole-set model runs are forbidden on this workstation. On \
         2026-09-17 a local LoRA training took the machine from every other job the operator had \
         open. Submit it to the fleet instead — `stado submit` places it on a training host and \
         the queue shows it. Only the operator, outside the agent session, may allow a local run \
         by exporting LOCAL_MODEL_TRAINING_APPROVED=1. Detected: {detected}"
    )
}

fn drive(payload: &serde_json::Value, approval: Option<&str>) -> Output {
    let mut command = Command::new(GUARD);
    command.env_remove(APPROVAL_VARIABLE);
    if let Some(value) = approval {
        command.env(APPROVAL_VARIABLE, value);
    }
    let mut child = command
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .unwrap_or_else(|error| panic!("spawn the guard: {error}"));
    child
        .stdin
        .as_mut()
        .expect("guard stdin")
        .write_all(payload.to_string().as_bytes())
        .expect("write payload");
    child.wait_with_output().expect("guard output")
}

fn bash(command: &str) -> serde_json::Value {
    json!({ "tool_name": "Bash", "tool_input": { "command": command } })
}

fn refuses(payload: &serde_json::Value, sentence: &str) {
    let output = drive(payload, None);
    let stderr = String::from_utf8_lossy(&output.stderr).into_owned();
    assert_eq!(
        output.status.code(),
        Some(EXIT_REFUSED),
        "{payload} should be refused; stderr: {stderr}"
    );
    assert_eq!(
        stderr.trim_end(),
        sentence,
        "refusal sentence for {payload}"
    );
}

fn passes(payload: &serde_json::Value) {
    let output = drive(payload, None);
    let stderr = String::from_utf8_lossy(&output.stderr).into_owned();
    assert_eq!(
        output.status.code(),
        Some(EXIT_PASS),
        "{payload} should pass; stderr: {stderr}"
    );
    assert!(stderr.is_empty(), "a passing call prints nothing: {stderr}");
}

#[test]
fn ster_training_and_whole_set_runs_are_refused() {
    refuses(
        &bash("./target/release/ster tune decide --model HuggingFaceTB/SmolLM2-1.7B-Instruct --examples train.json --output adapter.safetensors"),
        &refusal("`ster tune decide` on this machine"),
    );
    refuses(
        &bash("ster tune sft --model m --examples e.json --output a.safetensors"),
        &refusal("`ster tune sft` on this machine"),
    );
    refuses(
        &bash("ster train --model m --pairs p.json --output v.json"),
        &refusal("`ster train` on this machine"),
    );
    refuses(
        &bash("ster calibrate --model m --examples e.json --output c.json"),
        &refusal("`ster calibrate` on this machine"),
    );
    refuses(
        &bash("cd ster && ./target/release/ster decisions benchmark --model m --examples h.json --output b.json"),
        &refusal("`ster decisions benchmark` on this machine"),
    );
}

#[test]
fn trainer_launchers_and_trainer_scripts_are_refused() {
    refuses(
        &bash("torchrun --nproc_per_node 1 train.py"),
        &refusal("`torchrun` on this machine"),
    );
    refuses(
        &bash("accelerate launch train.py --config c.yaml"),
        &refusal("`accelerate launch` on this machine"),
    );
    refuses(
        &bash("python -m mlx_lm.lora --model m --train"),
        &refusal("`python -m mlx_lm.lora` on this machine"),
    );
    refuses(
        &bash("python3 examples/doom/train_dagger.py --epochs 3"),
        &refusal("`examples/doom/train_dagger.py` run by `python3` on this machine"),
    );
    refuses(
        &bash("uv run finetune.py"),
        &refusal("`finetune.py` run by `uv` on this machine"),
    );
}

#[test]
fn the_fleet_route_help_and_ordinary_work_pass() {
    passes(&bash("stado submit --profile rtx -- ster tune decide --model m --examples e.json --output a.safetensors"));
    passes(&bash("ster tune decide --help"));
    passes(&bash("ster decide --model m --request r.json"));
    passes(&bash("ster decisions fetch --dataset fancyzhx/ag_news --instructions q --count 10 --output d.json"));
    passes(&bash(
        "ster decisions split --examples d.json --train-output t.json --holdout-output h.json",
    ));
    passes(&bash("cargo build --release"));
    passes(&bash(
        "git commit -m 'ster tune decide: calibrated decisions'",
    ));
    passes(&bash("python3 -m pytest tests/"));
    passes(&bash("python3 trainer_docs.py"));
}

#[test]
fn a_training_hidden_one_shell_level_down_is_still_refused() {
    refuses(
        &bash("bash -c 'ster tune decide --model m --examples e.json --output a.safetensors'"),
        &refusal("`ster tune decide` on this machine"),
    );
    refuses(
        &json!({ "tool_name": "hub", "tool_input": { "op": "start", "name": "train", "application": "ster", "args": ["tune", "dpo", "--model", "m"] } }),
        &refusal("`ster tune dpo` on this machine"),
    );
    passes(&json!({ "tool_name": "hub", "tool_input": { "op": "logs", "name": "train" } }));
}

#[test]
fn the_operators_approval_outside_the_session_lets_a_run_through() {
    let payload = bash("ster tune decide --model m --examples e.json --output a.safetensors");
    let output = drive(&payload, Some("1"));
    assert_eq!(
        output.status.code(),
        Some(EXIT_PASS),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
    let output = drive(&payload, Some("yes"));
    assert_eq!(
        output.status.code(),
        Some(EXIT_REFUSED),
        "only the exact value 1 approves"
    );
}
