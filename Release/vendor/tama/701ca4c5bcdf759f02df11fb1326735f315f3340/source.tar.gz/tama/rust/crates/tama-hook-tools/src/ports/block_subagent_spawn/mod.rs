//! Refuse launching a subagent on this machine (hook `block-subagent-spawn`).
//!
//! On 2026-09-09 seven subagents were dividing oversized files in the Weles
//! checkout when the operator stopped them: "usun cala prace ktora zrobili do
//! tej pory Ci subagenci. zablokuj ta funkcjonalnosc". Their work was deleted
//! in the same turn, and the block was a sentence in a report. He tested that
//! sentence one turn later by asking whether a subagent could still be
//! launched here, and it could: nothing enforced it. This module is the
//! enforcement, so the answer to that question stops depending on which model
//! is reading its own promise.
//!
//! Three surfaces reach a subagent from inside a session, and each earns its
//! own refusal so the sentence names what was refused:
//!
//!   1. the delegation tools themselves, `task` and `agent`;
//!   2. a kernel payload that calls `agent(...)` or `workpool(...)`, or that
//!      reaches the delegation tool through the bridge as `tool.task(...)`;
//!   3. a shell command that starts an agent command line in headless mode,
//!      such as `claude -p`, `codex exec` or `omp --prompt`.
//!
//! The second and third surfaces carry as much weight as the first. A guard
//! that refused only the delegation tool would leave two working ways to
//! spawn the same worker while reading as settled, which is the exact shape
//! of the promise it replaces.
//!
//! The operator's escape is `DEVICE_SUBAGENT_SPAWN_APPROVED=1`, exported
//! outside the agent session — the shape the two consent gates in this crate
//! already use. A session cannot grant itself delegation, and the operator
//! re-allows it in one word without editing a hook.

use std::path::Path;
use std::sync::LazyLock;

use regex::Regex;
use serde_json::Value;

use crate::ports::python_stdlib::shell_tokens;
use crate::ports::pyvalue::py_str;
use crate::ports::shell_text;
use crate::ports::transport_common as common;

/// `tool_name` reads these keys in this order here, as the CUA gate does.
const TOOL_KEYS: &[&str] = &["tool_name", "tool", "name"];
const APPROVAL_ENV: &str = "DEVICE_SUBAGENT_SPAWN_APPROVED";
const APPROVAL_VALUE: &str = "1";

/// Tools whose whole purpose is handing work to another agent.
const SPAWN_TOOLS: &[&str] = &["task", "functions.task", "agent", "functions.agent"];
/// Tools that run code able to call the spawn helpers or a command line.
const KERNEL_TOOLS: &[&str] = &["eval", "functions.eval", "node_repl", "mcp__node_repl_js"];
/// Tools that run a shell command.
const EXECUTION_TOOLS: &[&str] = &["bash", "functions.bash", "shell", "functions.shell"];

/// Command lines that are themselves coding agents.
const AGENT_BINARIES: &[&str] = &["omp", "claude", "codex", "kimi"];
/// The arguments that turn one of those into a worker taking an instruction
/// instead of an interactive program the operator is watching.
const HEADLESS_ARGUMENTS: &[&str] = &["-p", "--print", "--prompt", "exec", "--headless", "--agent"];
/// `--prompt=…` and `--agent=…` carry the value in the same token.
const VALUE_JOINER: &str = "=";
/// Every pattern here carries exactly one capture group: the call's own name.
const NAME_GROUP_TEXT: &str = "1";

fn name_group() -> usize {
    NAME_GROUP_TEXT.parse().unwrap_or_default()
}

use crate::ports::tool_vocabulary::COMMAND_KEYS;

const BANNER: &str = "BLOCKED: launching a subagent is forbidden on this machine.";
const ESCAPE: &str = "Do the work in the session that was asked for it. The operator re-allows \
                      delegation by exporting DEVICE_SUBAGENT_SPAWN_APPROVED=1 outside the agent \
                      session.";

/// `agent(...)` and `workpool(...)` as the kernel prelude exposes them. The
/// leading class keeps `myagent(` and `subagent(` out: a spawn is the bare
/// name, or a property access on the tool bridge below.
static SPAWN_CALL_RE: LazyLock<Regex> =
    LazyLock::new(|| common::compile(r"(?i)(?:\A|[^\w.$])(agent|workpool)\s*\("));
/// The same spawn reached through the tool bridge, `tool.task({...})`.
static BRIDGE_CALL_RE: LazyLock<Regex> =
    LazyLock::new(|| common::compile(r"(?i)\btool\s*\.\s*(task|agent)\s*\("));

/// Exported outside the session, so a session cannot write itself a grant.
fn approved() -> bool {
    std::env::var(APPROVAL_ENV).ok().as_deref() == Some(APPROVAL_VALUE)
}

fn refusal(detected: &str) -> String {
    format!("{BANNER} Detected: {detected}. {ESCAPE}")
}

/// The shell command a payload carries: the named field, else every string in
/// the payload, which is the shape the neighbouring shell guards already use.
fn command_from(payload: &Value) -> String {
    let input = common::tool_input(payload);
    let named = py_str(&common::or_chain(&input, COMMAND_KEYS));
    if !named.is_empty() {
        return named;
    }
    common::strings(payload).join("\n")
}

/// The spawn helper this payload calls, named as the refusal will name it.
fn kernel_spawn_call(payload: &Value) -> Option<String> {
    let text = common::strings(payload).join("\n");
    if let Some(found) = SPAWN_CALL_RE.captures(&text) {
        let name = found.get(name_group())?.as_str().to_lowercase();
        return Some(format!("this payload calls {name}(...)"));
    }
    let found = BRIDGE_CALL_RE.captures(&text)?;
    let name = found.get(name_group())?.as_str().to_lowercase();
    Some(format!("this payload calls tool.{name}(...)"))
}

/// `Path(token).name`, so `/opt/homebrew/bin/claude` counts as `claude`.
fn program_name(token: &str) -> Option<&str> {
    Path::new(token).file_name().and_then(|name| name.to_str())
}

/// Is this argument one of the headless forms, in either spelling? A long
/// option may carry its value in the same token, `--prompt=do this`.
fn headless_argument(token: &str) -> Option<&'static str> {
    HEADLESS_ARGUMENTS.iter().copied().find(|argument| {
        token == *argument || token.starts_with(&format!("{argument}{VALUE_JOINER}"))
    })
}

/// One command segment that starts an agent command line as a worker.
fn headless_agent_segment(segment: &str) -> Option<String> {
    let tokens = shell_tokens(segment);
    let mut after_binary = tokens
        .iter()
        .skip_while(|token| !AGENT_BINARIES.contains(&program_name(token).unwrap_or_default()));
    let binary = program_name(after_binary.next()?)?.to_string();
    let argument = after_binary.find_map(|token| headless_argument(token))?;
    Some(format!("this command runs {binary} {argument}"))
}

/// The agent command line this payload would start, if it starts one.
///
/// The cut into commands is quote-aware, so a sentence that names `codex
/// exec` inside a quoted argument is not read as running it, and an
/// executor's quoted program is read as a command in its own right.
fn headless_agent_command(payload: &Value) -> Option<String> {
    let command = command_from(payload);
    for segment in shell_text::commands(&command) {
        if let Some(reason) = headless_agent_segment(segment) {
            return Some(reason);
        }
        let tokens = shell_tokens(segment);
        if let Some(inner) = shell_text::inner_command(&tokens) {
            if let Some(reason) = headless_agent_segment(inner) {
                return Some(reason);
            }
        }
    }
    None
}

/// The refusal this call earns, or `None` when it passes. The caller writes
/// the sentence to stderr and exits with the blocking status.
pub fn evaluate(payload: &Value) -> Option<String> {
    if approved() {
        return None;
    }
    let tool = common::tool_name(payload, TOOL_KEYS);
    // Providers spell the same tool `Task`, `task` and `functions.task`; the
    // refusal quotes the spelling the payload used.
    let matched = tool.to_lowercase();
    let name = matched.as_str();
    if SPAWN_TOOLS.contains(&name) {
        return Some(refusal(&format!("the {tool} tool starts one")));
    }
    if KERNEL_TOOLS.contains(&name) || EXECUTION_TOOLS.contains(&name) {
        if let Some(detected) = kernel_spawn_call(payload) {
            return Some(refusal(&detected));
        }
        if let Some(detected) = headless_agent_command(payload) {
            return Some(refusal(&detected));
        }
    }
    None
}
