//! Which file the guard reads at all, and what it reads of it: comments
//! become blanks, quoted text is left alone, borrowed code is skipped.
//!
//! Split out of `block_keyword_literals/mod.rs`, which had grown past the
//! three-hundred-line limit; the scanning itself is in `scan.rs`.

use super::super::check_numeric_literals_scan as scan;

/// Code that came from somewhere else. A vendored library, an installed
/// dependency, a package manager's checkout or a minified bundle is not
/// ours to name words in, and refusing a write to one would only teach the
/// writer to work around the guard. `weles/vendor/axe-core/axe.min.js`
/// alone accounted for six of the findings this guard reported, none of
/// them anything anybody here could fix.
pub(super) fn came_from_elsewhere(path: &str) -> bool {
    let borrowed = [
        "/vendor/",
        "/node_modules/",
        "/third_party/",
        "/third-party/",
        "/.build/checkouts/",
        "/site-packages/",
        "/dist/",
    ];
    let normalised = format!("/{}", path.trim_start_matches('/'));
    borrowed.iter().any(|part| normalised.contains(part)) || path.ends_with(".min.js")
}

/// One file's text, read the way the guard reads it: comments blanked, and
/// nothing at all for a path the guard does not judge.
pub fn judged_text(path: &str, text: &str) -> Option<String> {
    if came_from_elsewhere(path) {
        return None;
    }
    let lang = scan::lang_for(path)?;
    Some(without_comments(text, &lang))
}

/// Comments become spaces, newlines kept, so a list quoted in a doc comment
/// is a report about a classifier, not one, and line numbers stay true.
/// Quoted text is left alone: that is where a regex alternation lives.
pub(super) fn without_comments(text: &str, lang: &str) -> String {
    let hash_languages = matches!(lang, "py" | "sh" | "rb" | "toml" | "yaml" | "yml");
    let line_marker: &[char] = if hash_languages { &['#'] } else { &['/', '/'] };
    let chars: Vec<char> = text.chars().collect();
    let mut out = String::with_capacity(text.len());
    let mut index = usize::default();
    let mut quote: Option<char> = None;
    let starts = |at: usize, marker: &[char]| chars[at..].starts_with(marker);
    while index < chars.len() {
        let ch = chars[index];
        if let Some(open) = quote {
            out.push(ch);
            if ch == '\\' && index + usize::from(true) < chars.len() {
                out.push(chars[index + usize::from(true)]);
                index += usize::from(true);
            } else if ch == open {
                quote = None;
            }
            index += usize::from(true);
            continue;
        }
        if ch == '"' || ch == '\'' {
            quote = Some(ch);
            out.push(ch);
            index += usize::from(true);
            continue;
        }
        if starts(index, line_marker) {
            while index < chars.len() && chars[index] != '\n' {
                out.push(' ');
                index += usize::from(true);
            }
            continue;
        }
        if !hash_languages && starts(index, &['/', '*']) {
            while index < chars.len() && !starts(index, &['*', '/']) {
                out.push(if chars[index] == '\n' { '\n' } else { ' ' });
                index += usize::from(true);
            }
            let close = ['*', '/'].len().min(chars.len() - index);
            out.extend(std::iter::repeat_n(' ', close));
            index += close;
            continue;
        }
        out.push(ch);
        index += usize::from(true);
    }
    out
}
