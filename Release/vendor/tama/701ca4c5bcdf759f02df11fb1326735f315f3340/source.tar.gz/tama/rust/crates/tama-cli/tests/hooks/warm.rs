//! `tama hooks warm`, through the real CLI, the real registry and the real
//! installed binaries.
//!
//! On 2026-09-20 a stop hook's first execution after installation took 147
//! seconds against a 10-second timeout and blocked a finished turn: macOS
//! assesses a new executable's signature before running it. Warming pays
//! that cost deliberately, outside a live event, and reports what each
//! binary cost.
//!
//! Split from `declare_and_release.rs`, which had reached the three hundred
//! line limit this workshop enforces.

use std::fs;
use std::path::{Path, PathBuf};
use std::process::{Command, Output};

/// The CLI as built, beside this test binary.
fn cli() -> PathBuf {
    let mut path = std::env::current_exe().expect("test binary path");
    path.pop();
    if path.ends_with("deps") {
        path.pop();
    }
    path.join("tama-cli")
}

/// The checkout this test runs in: the crate, three levels up.
fn repo() -> PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR"))
        .ancestors()
        .nth(3)
        .expect("the checkout above rust/crates/tama-cli")
        .to_path_buf()
}

fn run(args: &[&str]) -> Output {
    Command::new(cli())
        .args(args)
        .current_dir(repo())
        .env_remove("DEVICE_HOOK_EDIT_APPROVED")
        .output()
        .expect("run tama-cli")
}

fn text(output: &Output) -> String {
    format!(
        "{}{}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    )
}

/// Standard output of a `--json` warm run, parsed. A reader that cannot parse
/// it whole has no machine surface at all, so this is part of the contract.
fn warm_report(output: &Output) -> serde_json::Value {
    let stdout = String::from_utf8_lossy(&output.stdout).into_owned();
    serde_json::from_str(&stdout).unwrap_or_else(|error| {
        panic!("the warm report is not one JSON document ({error}): {stdout}")
    })
}

/// Every binary the registry names has to be run and measured, or the next
/// event pays for the one that was skipped.
#[test]
fn warm_runs_and_measures_every_hook_binary_the_registry_names() {
    let output = run(&["hooks", "warm", "--json"]);
    let report = warm_report(&output);
    let rows = report["hooks"].as_array().expect("hooks array").clone();
    let registry =
        fs::read_to_string(repo().join("shared-hooks/registry.json")).expect("read the registry");
    for hook in ["tama-block-delegating-own-work", "tama-pre-write-edit"] {
        if registry.contains(hook) {
            assert!(
                rows.iter().any(|row| row["path"]
                    .as_str()
                    .is_some_and(|path| path.ends_with(hook))),
                "{hook} is registered and was not warmed: {rows:?}"
            );
        }
    }
    let unusable = report["unusable"].as_u64().expect("an unusable count");
    let warmed = report["warmed"].as_u64().expect("a warmed count");
    assert_eq!(
        warmed + unusable,
        rows.len() as u64,
        "the counts do not account for every hook: {report}"
    );
    for row in &rows {
        let path = row["path"].as_str().expect("a path");
        if !Path::new(path).is_file() {
            continue;
        }
        assert!(
            row["elapsedMs"].as_u64().is_some(),
            "an installed binary was reported without a measurement: {row}"
        );
        assert_eq!(
            row["state"].as_str(),
            Some("warm"),
            "an installed binary was not reported as run: {row}"
        );
    }
}

/// What the release installs must be usable immediately afterwards, and the
/// report has to name the binary that cost the most, because that is how a
/// slow gate is found now that nothing is killed for being slow.
#[test]
fn a_warm_pass_names_the_binary_that_cost_the_most() {
    let _first = run(&["hooks", "warm", "--json"]);
    let output = run(&["hooks", "warm", "--json"]);
    let report = warm_report(&output);
    let slowest = report["slowest"].as_str().expect("a slowest hook id");
    let slowest_ms = report["slowestMs"].as_u64().expect("its measurement");
    let rows = report["hooks"].as_array().expect("hooks array");
    let measured = rows
        .iter()
        .filter(|row| row["state"] == "warm")
        .filter_map(|row| row["elapsedMs"].as_u64())
        .max()
        .expect("at least one measured binary");
    assert_eq!(
        slowest_ms, measured,
        "the report names a cost no row carries: {report}"
    );
    assert!(
        rows.iter()
            .any(|row| row["id"] == slowest && row["elapsedMs"].as_u64() == Some(slowest_ms)),
        "the slowest hook named is not in the report: {report}"
    );
}

#[test]
fn warming_an_unknown_hook_is_refused_by_name() {
    let output = run(&["hooks", "warm", "--only", "block-nothing-at-all"]);
    assert_eq!(
        output.status.code(),
        Some(2),
        "expected a refusal: {}",
        text(&output)
    );
    assert!(
        text(&output).contains("names no hook called block-nothing-at-all"),
        "the refusal does not name the hook: {}",
        text(&output)
    );
}

/// The copies the engine actually executes.
///
/// A machine keeps two sets of hook binaries: the ones `~/.local/bin` holds,
/// which the registry names, and the sealed release under
/// `~/Library/Application Support/Tama/hooks-runtime/current/bin`, which the
/// engine runs. They are separate files and macOS assesses each of them the
/// first time it sees it. On 2026-09-21 a warm pass reported 74 binaries
/// warmed and minutes later `block-unprompted-topics` was killed at ten
/// seconds inside a live stop event, because the copy that ran was the
/// sealed one and nothing had ever run it (defect 359667bc).
#[test]
fn warm_runs_the_sealed_release_the_engine_executes() {
    let home = repo().join("rust/target/warm-sealed-home");
    let sealed = home.join("Library/Application Support/Tama/hooks-runtime/current/bin");
    fs::create_dir_all(&sealed).expect("a fixture release directory");
    let binary = sealed.join("tama-block-fixture");
    fs::copy("/bin/echo", &binary).expect("a real executable to warm");

    let output = Command::new(cli())
        .args(["hooks", "warm", "--json"])
        .current_dir(repo())
        .env("HOME", &home)
        .output()
        .expect("the CLI runs");
    let report = warm_report(&output);
    let row = report["hooks"]
        .as_array()
        .expect("hooks array")
        .iter()
        .find(|row| row["path"].as_str() == Some(&binary.display().to_string()))
        .cloned()
        .unwrap_or_else(|| panic!("the sealed release was never warmed: {report}"));
    assert_eq!(
        row["state"].as_str(),
        Some("warm"),
        "a sealed binary was reported without being run: {row}"
    );
    assert_eq!(row["id"].as_str(), Some("block-fixture"), "{row}");
    fs::remove_dir_all(&home).expect("the fixture is removed");
}
