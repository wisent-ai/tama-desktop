//! `tama vocabulary-report`, driven as the real binary over a scratch
//! repository under this crate's target directory.
//!
//! The repair of keyword logic is hundreds of sites, and the ones worth
//! reaching for first are the vocabularies written in more than one place:
//! those are the copies that drift. So the grouping and the order are the
//! contract — a set that is not grouped gets fixed once per file instead of
//! once, and an order that buries the repeated sets sends the work at
//! one-off lists.

use std::fs;
use std::path::PathBuf;
use std::process::Command;
use std::time::{SystemTime, UNIX_EPOCH};

const CLI: &str = env!("CARGO_BIN_EXE_tama-cli");
const SHARED: &str = "static WORDS: &[&str] = &[\"alpha\", \"beta\", \"gamma\"];\n";
const SINGLE: &str = "static OTHER: &[&str] = &[\"delta\", \"epsilon\", \"zeta\"];\n";
const SHARED_WORDS: &str = "alpha beta gamma";

fn scratch(story: &str) -> PathBuf {
    let nonce = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .expect("clock after epoch")
        .as_nanos();
    let root =
        PathBuf::from(env!("CARGO_TARGET_TMPDIR")).join(format!("vocabulary-{story}-{nonce}"));
    fs::create_dir_all(root.join("src")).expect("create the scratch repository");
    root
}

fn report(root: &PathBuf) -> String {
    let output = Command::new(CLI)
        .args(["vocabulary-report", "--repo"])
        .arg(root)
        .output()
        .expect("the report runs");
    assert!(output.status.success(), "{:?}", output.status);
    String::from_utf8_lossy(&output.stdout).to_string()
}

/// The first group's header and the sites listed under it.
fn first_group(text: &str) -> (&str, Vec<&str>) {
    let mut lines = text.lines();
    let header = lines.next().unwrap_or_default();
    let sites = lines
        .take_while(|line| line.starts_with("    "))
        .map(str::trim)
        .collect();
    (header, sites)
}

#[test]
fn a_vocabulary_written_twice_is_grouped_and_listed_first() {
    let root = scratch("grouped");
    fs::write(root.join("src/one.rs"), SHARED).expect("write the first copy");
    fs::write(root.join("src/two.rs"), SHARED).expect("write the second copy");
    fs::write(root.join("src/other.rs"), SINGLE).expect("write the single site");

    let text = report(&root);
    let (header, sites) = first_group(&text);
    for word in SHARED_WORDS.split(' ') {
        assert!(
            header.contains(word),
            "the repeated vocabulary is not first: {text}"
        );
    }
    assert_eq!(sites.len(), "2".parse::<usize>().unwrap(), "{text}");
    assert!(sites.iter().any(|site| site.contains("one.rs")), "{text}");
    assert!(sites.iter().any(|site| site.contains("two.rs")), "{text}");
    // The one-off list is reported too, after the repeated one.
    assert!(text.contains("epsilon"), "{text}");
    assert!(
        text.find("alpha").unwrap_or_default() < text.find("epsilon").unwrap_or_default(),
        "the one-off list is listed before the repeated one: {text}"
    );
}

#[test]
fn a_declared_vocabulary_is_not_reported() {
    let root = scratch("declared");
    fs::write(root.join("src/one.rs"), SHARED).expect("write the site");
    let words: Vec<&str> = SHARED_WORDS.split(' ').collect();
    fs::write(
        root.join("keyword-provenance.json"),
        serde_json::json!({
            "greek": {
                "words": words,
                "user_said": "alpha beta gamma are the three stages",
            }
        })
        .to_string(),
    )
    .expect("write the declaration");

    let text = report(&root);
    assert!(
        !text.contains("alpha"),
        "a declared vocabulary is reported: {text}"
    );
}
