//! A repair proposal: drafting a candidate, validating it against the
//! corpus, and writing the proposal directory a person reviews.
//!
//! Split out of `doctor/repair.rs`, which had grown past the
//! three-hundred-line limit.

mod apply;
mod brief;
mod summary;
mod validate;

pub use apply::apply_proposal;
pub use brief::{build_brief, Brief};
pub use validate::validate_candidate;

use summary::summary_text;

use std::fs;
use std::path::{Path, PathBuf};

use super::corpus::hook_paths;
use super::spawn::spawn_sync_capture;
use crate::engine::load_engine;
use crate::segments::runner_command::extname;
use crate::util::now_ms;

/// `unfence(text)`.
fn unfence(text: &str) -> String {
    let mut lines: Vec<&str> = text.split('\n').collect();
    if lines.first().map(|l| l.starts_with("```")).unwrap_or(false) {
        lines.remove(0);
    }
    if lines.last().map(|l| l.starts_with("```")).unwrap_or(false) {
        lines.pop();
    }
    lines.join("\n")
}

fn draft_with_claude(prompt: &str, out_path: &Path) -> Result<PathBuf, String> {
    if std::env::var("HOOKS_ADAPTIVE_NO_LLM").ok().as_deref() == Some("1") {
        return Err("LLM drafting disabled (HOOKS_ADAPTIVE_NO_LLM); pass --patch-file".to_string());
    }
    let probe = spawn_sync_capture("claude", &["--version".to_string()], "");
    if probe.error.is_some() {
        return Err("local claude CLI unavailable; pass --patch-file".to_string());
    }
    let result = spawn_sync_capture("claude", &["-p".to_string(), prompt.to_string()], "");
    let body = unfence(result.stdout.trim());
    if result.error.is_some() || result.status != Some(0) || body.is_empty() {
        return Err("claude draft did not produce content".to_string());
    }
    fs::write(out_path, format!("{}\n", body)).map_err(|e| format!("Error: {}", e))?;
    Ok(out_path.to_path_buf())
}

/// `propose(hookId, { patchFile })`.
pub fn propose(hook_id: &str, patch_file: Option<&str>) -> Result<serde_json::Value, String> {
    let core = load_engine();
    let paths = hook_paths(hook_id, &core);
    if paths.live.is_none() && paths.archive.is_none() {
        return Ok(serde_json::json!({
            "ok": false,
            "hookId": hook_id,
            "reason": format!("unknown hook or no script path: {}", hook_id),
        }));
    }
    let ext = match &paths.live {
        Some(live) => extname(live),
        None => extname(
            &paths
                .archive
                .as_ref()
                .map(|a| a.to_string_lossy().to_string())
                .unwrap_or_default(),
        ),
    };
    let tmp_dir = core.state_dir.join("tmp");
    fs::create_dir_all(&tmp_dir).map_err(|e| format!("Error: {}", e))?;
    let source_file = match patch_file {
        Some(file) => file.to_string(),
        None => {
            let brief = build_brief(hook_id)?;
            let draft_path = tmp_dir.join(format!("{}-draft{}", hook_id, ext));
            match draft_with_claude(&brief.text, &draft_path) {
                Ok(path) => path.to_string_lossy().to_string(),
                Err(reason) => {
                    return Ok(
                        serde_json::json!({ "ok": false, "hookId": hook_id, "reason": reason }),
                    );
                }
            }
        }
    };
    if !Path::new(&source_file).exists() {
        return Ok(serde_json::json!({
            "ok": false,
            "hookId": hook_id,
            "reason": format!("patch file not found: {}", source_file),
        }));
    }
    let report = validate_candidate(hook_id, &source_file)?;
    if report.get("ok").and_then(|v| v.as_bool()) != Some(true) {
        let mut merged = report.as_object().cloned().unwrap_or_default();
        merged.insert("hookId".into(), hook_id.into());
        merged.insert("patchFile".into(), source_file.into());
        merged.insert(
            "reason".into(),
            format!(
                "validation did not pass; artifacts left in {}",
                tmp_dir.display()
            )
            .into(),
        );
        return Ok(serde_json::Value::Object(merged));
    }
    let dir = core
        .state_dir
        .join("proposals")
        .join(format!("{}-{}", hook_id, now_ms()));
    fs::create_dir_all(&dir).map_err(|e| format!("Error: {}", e))?;
    let proposed = dir.join(format!("proposed{}", ext));
    fs::copy(&source_file, &proposed).map_err(|e| format!("Error: {}", e))?;
    let diff_stdout = paths.live.as_deref().map(|live| {
        spawn_sync_capture(
            "diff",
            &[
                "-u".to_string(),
                live.to_string(),
                proposed.to_string_lossy().to_string(),
            ],
            "",
        )
        .stdout
    });
    fs::write(dir.join("proposed.diff"), diff_stdout.unwrap_or_default())
        .map_err(|e| format!("Error: {}", e))?;
    let mut full = report.as_object().cloned().unwrap_or_default();
    full.insert("hookId".into(), hook_id.into());
    full.insert(
        "proposalDir".into(),
        dir.to_string_lossy().to_string().into(),
    );
    full.insert(
        "proposed".into(),
        proposed.to_string_lossy().to_string().into(),
    );
    full.insert(
        "livePath".into(),
        paths
            .live
            .clone()
            .map(Into::into)
            .unwrap_or(serde_json::Value::Null),
    );
    full.insert(
        "archivePath".into(),
        paths
            .archive
            .as_ref()
            .map(|a| a.to_string_lossy().to_string().into())
            .unwrap_or(serde_json::Value::Null),
    );
    let full = serde_json::Value::Object(full);
    fs::write(
        dir.join("report.json"),
        format!(
            "{}\n",
            serde_json::to_string_pretty(&full).unwrap_or_default()
        ),
    )
    .map_err(|e| format!("Error: {}", e))?;
    fs::write(dir.join("summary.md"), summary_text(&full)).map_err(|e| format!("Error: {}", e))?;
    Ok(full)
}
