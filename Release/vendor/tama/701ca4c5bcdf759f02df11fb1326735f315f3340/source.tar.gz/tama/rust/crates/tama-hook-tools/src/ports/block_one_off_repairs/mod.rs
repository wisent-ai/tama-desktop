//! Decision half of `tama-block-one-off-repairs` (registry hook
//! `block-one-off-repairs`).
//!
//! On 2026-09-19 Oko's one-off repair detector read the week's native harness
//! files: 243 commands that changed live machine state by hand instead of
//! through a product path, in 21 sessions. Three shapes had no gate at all:
//!
//!   * a running service cycled by hand — `launchctl kickstart|bootout|…`,
//!     `kill <pid>`, `pkill` — 12 times, when `stado service restart` and
//!     `stado service refresh-image` own that;
//!   * a grant or bearer written straight into a vault — `skarbiec grant
//!     ensure|issue`, `skarbiec token-mint` — past Stado, so nothing records
//!     it: the one on 2026-09-18 went to the replica the owner overwrites and
//!     was gone within the hour. `stado credentials token mint`, `stado
//!     service grant-sync` and `stado release catalog declare-publisher` are
//!     the product's route and pass;
//!   * a built binary copied over an installed one — `cp .build/debug/oko-cli
//!     ~/.stado/bin/oko-cli` nine times — when `oko-cli install` and
//!     `stado product update` own that.
//!
//! Each refusal names the product command, because a gate that refuses a
//! method without naming the outcome's route is worked around
//! (`~/agents/finishing.md`). The shape is [`crate::ports::block_repository_copies`]'s:
//! a pure [`evaluate`] over the payload returning the refusal, the binary under
//! `src/bin/block/` carrying it to the process boundary. The verbs and roots
//! it matches are data in `vocabulary.json` beside this file — what each
//! program accepts, not a classifier of what anyone meant.
//!
//! The command is read the way a shell reads it: cut at separators outside
//! quotes, quoted text blanked, wrappers stepped over
//! ([`crate::ports::shell_text`]), so `grep 'launchctl kickstart' notes.md`
//! and `skarbiec grant issue --help` pass.

use std::collections::BTreeMap;
use std::sync::LazyLock;

use serde::Deserialize;
use serde_json::Value;

use crate::ports::python_stdlib::shell_tokens;
use crate::ports::pyvalue::{first_truthy_py_str, py_str, truthy};
use crate::ports::shell_text;

use crate::ports::tool_vocabulary::{COMMAND_KEYS, TOOL_INPUT_KEY};

const HELP_FLAG: &str = "--help";
const FLAG_PREFIX: char = '-';
const PATH_SEPARATOR: char = '/';
/// The word a package manager puts its script name after, so the refusal can
/// quote `npm run test:context` rather than `npm run`.
const SCRIPT_RUNNER_VERB: &str = "run";
/// What names a tree even when the command line names no path: the long flag,
/// and the letters that mean the same inside a cluster such as `-rn`.
const RECURSIVE_LONG_FLAG: &str = "--recursive";
const RECURSIVE_LETTERS: [char; 2] = ['r', 'R'];
const LONG_FLAG_PREFIX: &str = "--";
const LAUNCHCTL: &str = "launchctl";
const SYSTEMCTL: &str = "systemctl";
const SKARBIEC: &str = "skarbiec";
const SKARBIEC_GRANT: &str = "grant";
const LINK_PROGRAM: &str = "ln";
const SYMLINK_FLAG_PREFIX: &str = "-s";
const USERS_PREFIX: &str = "/Users/";

const BANNER: &str = "BLOCKED: one-off repair by hand. ";
const SERVICE_ROUTE: &str = "the managed unit's own path is `stado service restart <NAME>` or `stado service refresh-image <LABEL> --if-needed`; a unit that must change is redeclared with `stado service deploy|update`.";
const BREW: &str = "brew";
const BREW_SERVICES: &str = "services";
const CODESIGN: &str = "codesign";
const ADHOC_SIGN_FLAG: &str = "-s";
const ADHOC_IDENTITY: &str = "-";

/// What the programs this gate reads accept, from `vocabulary.json`. A field
/// the file spells differently is refused at first use rather than read as
/// an empty list that matches nothing.
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Vocabulary {
    /// Prose for a reader of the file; the gate does not read it.
    #[allow(dead_code)]
    about: String,
    /// `launchctl` verbs that change what runs; `list`, `print`, `blame`
    /// only read.
    launchctl_cycle: Vec<String>,
    systemctl_cycle: Vec<String>,
    kill_programs: Vec<String>,
    /// `kill -0 <pid>` asks whether a process exists and `kill -l` lists
    /// signal names; every other invocation ends or changes a process.
    kill_read_flags: Vec<String>,
    /// `grant list`, `grant show` and `grant verify` read; these write.
    skarbiec_grant_writes: Vec<String>,
    skarbiec_writes: Vec<String>,
    copy_programs: Vec<String>,
    /// Where installed executables live. A copy whose last argument is under
    /// one of these replaces an installed program; one whose source is there
    /// copies it out, which is a read.
    install_roots: Vec<String>,
    home_prefixes: Vec<String>,
    /// Programs that change a file rather than read it. A hook's own file
    /// renamed, removed or made unexecutable from the shell is a gate turned
    /// off, whatever the intent.
    hook_write_programs: Vec<String>,
    /// Where the hooks this machine runs live: the shared sources, the
    /// installed runtime release, and the provider hook directories.
    hook_roots: Vec<String>,
    /// Database clients. Their statements arrive as a quoted argument, which
    /// the shell reading blanks, so the original command is consulted for
    /// them — and only once the parsed program is one of these.
    sql_programs: Vec<String>,
    /// Statements that change rows or shape. `select`, `explain`, `\dt` and
    /// `.schema` read.
    sql_write_statements: Vec<String>,
    /// `brew services <verb>` cycles a service the same way `launchctl` does;
    /// `brew services list` reads.
    brew_service_verbs: Vec<String>,
    /// Key-value stores whose command is a bare argument rather than a quoted
    /// statement, so the parsed words are enough to read them.
    store_programs: Vec<String>,
    /// Store commands that change what is held. `get`, `keys`, `info` read.
    store_write_commands: Vec<String>,
    /// Programs that change a machine setting: `defaults`, `plutil` and the
    /// rest read as well as write, so the verb decides.
    setting_programs: Vec<String>,
    setting_write_verbs: Vec<String>,
    /// A scratch directory made outside the repository's build tree.
    scratch_programs: Vec<String>,
    /// Where the operator's own state lives. A shell redirect that lands
    /// here rewrites it under the product that owns it.
    operator_state_roots: Vec<String>,
    /// Programs that pass time instead of observing an outcome.
    wait_programs: Vec<String>,
    /// Programs whose whole job is to kill another command at a guessed
    /// number of seconds. The shell reading steps over them to find what a
    /// line runs, so they are refused by name.
    deadline_wrappers: Vec<String>,
    /// Programs that search a tree from the shell. A search typed once
    /// answers the person typing it and leaves nothing any later reader or
    /// any product surface can use.
    search_programs: Vec<String>,
    /// The subset of those that read their input from a pipe when the command
    /// line names no path: `launchctl list | grep wisent` filters what the
    /// previous command printed and searches no tree at all.
    stream_search_programs: Vec<String>,
    /// The fleet's own CLI, whose subcommands are read as two words.
    fleet_program: String,
    /// Fleet commands that change one host once when a declaration owns the
    /// outcome, keyed by the two words that name them, valued by the route.
    fleet_one_off_commands: BTreeMap<String, String>,
    /// Drivers whose first word after the program says what it does:
    /// `cargo test`, `swift build`, `npm run build`. Keyed by the program,
    /// valued by the words that build or test with it.
    build_drivers: BTreeMap<String, Vec<String>>,
    /// Programs whose every invocation is a build, whatever the arguments.
    build_programs: Vec<String>,
    /// Where a build and its verdict belong instead.
    build_route: String,
    /// The Rust toolchain's own driver, whose subcommand is read as one word.
    toolchain_program: String,
    /// Toolchain commands that answer only the shell that typed them, keyed
    /// by the subcommand, valued by where the same answer is produced and
    /// kept for everyone.
    toolchain_one_off_commands: BTreeMap<String, String>,
}

static VOCABULARY: LazyLock<Vocabulary> = LazyLock::new(|| {
    serde_json::from_str(include_str!("vocabulary.json"))
        .expect("vocabulary.json is the gate's own data")
});

fn has(list: &[String], word: &str) -> bool {
    list.iter().any(|item| item == word)
}

fn command_from(payload: &Value) -> String {
    let Some(raw) = payload.get(TOOL_INPUT_KEY).filter(|value| truthy(value)) else {
        return String::new();
    };
    if raw.is_object() {
        let named = first_truthy_py_str(raw, COMMAND_KEYS);
        if !named.is_empty() {
            return named;
        }
    }
    py_str(raw)
}

fn basename(token: &str) -> &str {
    token.rsplit(PATH_SEPARATOR).next().unwrap_or(token)
}

/// The program one command runs and the words after it, with the program's
/// directory dropped and `env`, `sudo`, `nohup`, `timeout` stepped over.
fn program_and_args(tokens: &[String]) -> Option<(&str, &[String])> {
    let program = shell_text::program(tokens)?;
    let start = tokens.iter().position(|token| basename(token) == program)?;
    Some((program, &tokens[start + 1..]))
}

fn is_flag(word: &str) -> bool {
    word.starts_with(FLAG_PREFIX)
}

fn asks_for_help(args: &[String]) -> bool {
    args.iter().any(|arg| arg == HELP_FLAG)
}

/// A service restarted, stopped, unloaded or killed by hand.
fn service_cycle_refusal(program: &str, args: &[String]) -> Option<String> {
    let words = &*VOCABULARY;
    let verb = args.iter().map(String::as_str).find(|arg| !is_flag(arg));
    if program == LAUNCHCTL {
        let verb = verb.filter(|verb| has(&words.launchctl_cycle, verb))?;
        return Some(format!(
            "{BANNER}`launchctl {verb}` cycles a service on this machine once and records nothing; {SERVICE_ROUTE}"
        ));
    }
    if program == SYSTEMCTL {
        let verb = verb.filter(|verb| has(&words.systemctl_cycle, verb))?;
        return Some(format!(
            "{BANNER}`systemctl {verb}` cycles a service once and records nothing; {SERVICE_ROUTE}"
        ));
    }
    // `brew services restart postgresql@17` is the same repair with another
    // launcher, and Oko counted it in the same category from the start while
    // nothing refused it.
    if program == BREW {
        let mut plain = args.iter().map(String::as_str).filter(|arg| !is_flag(arg));
        if plain.next() == Some(BREW_SERVICES) {
            let verb = plain
                .next()
                .filter(|verb| has(&words.brew_service_verbs, verb))?;
            return Some(format!(
                "{BANNER}`brew services {verb}` cycles a service on this machine once and the \
                 declaration that put it there is unchanged; {SERVICE_ROUTE}"
            ));
        }
        return None;
    }
    if !has(&words.kill_programs, program) {
        return None;
    }
    let first = args.first().map(String::as_str)?;
    if has(&words.kill_read_flags, first) {
        return None;
    }
    Some(format!(
        "{BANNER}`{program}` ends a process by hand and launchd or Stado brings back the same fault; {SERVICE_ROUTE}"
    ))
}

/// A grant or bearer written straight into a vault with `skarbiec`, past
/// Stado. `stado credentials token mint` and `stado credentials grant` are
/// the product's own route - they record against the owner's vault and
/// `token sync` delivers the result - so they pass; Oko's detector still
/// lists them for the judge.
fn credential_refusal(program: &str, args: &[String]) -> Option<String> {
    if program != SKARBIEC || asks_for_help(args) {
        return None;
    }
    let words = &*VOCABULARY;
    let mut plain = args
        .iter()
        .map(String::as_str)
        .filter(|word| !is_flag(word));
    let first = plain.next()?;
    if first == SKARBIEC_GRANT {
        let verb = plain
            .next()
            .filter(|verb| has(&words.skarbiec_grant_writes, verb))?;
        return Some(format!(
            "{BANNER}`skarbiec grant {verb}` from the shell writes whichever vault the shell resolves - on 2026-09-18 the replica the owner overwrote within the hour. A consumer's grant goes through Stado, which records it against the owner's vault: `stado release catalog declare-publisher <PRODUCT> --owner <VAULT HOST> --client <HOST>` for a release publisher, `stado service grant-sync <SERVICE> --host <HOST> --consumer <CONSUMER> --capability <CAP> --token-file <PATH>` for a service, `stado credentials grant item-read --host <VAULT HOST> <CONSUMER> <ITEM> --field <FIELD> --token-file <PATH>` for one read."
        ));
    }
    if !has(&words.skarbiec_writes, first) {
        return None;
    }
    Some(format!(
        "{BANNER}`skarbiec {first}` from the shell mints a bearer nothing records; `stado credentials token mint <CONSUMER> --host <VAULT HOST> --capabilities <CAPS> --audience <AUD> --token-file-name <NAME>` records it against the owner's vault, and `stado credentials token sync` delivers it."
    ))
}

/// `~/x`, `$HOME/x` and `/Users/<name>/x` all name the same home; the roots
/// are compared without it.
fn without_home(path: &str) -> &str {
    if let Some(prefix) = VOCABULARY
        .home_prefixes
        .iter()
        .find(|prefix| path.starts_with(prefix.as_str()))
    {
        return &path[prefix.len()..];
    }
    if let Some(rest) = path.strip_prefix(USERS_PREFIX) {
        return rest
            .find(PATH_SEPARATOR)
            .map(|at| &rest[at..])
            .unwrap_or_default();
    }
    path
}

fn under_install_root(path: &str) -> bool {
    let relative = without_home(path);
    VOCABULARY.install_roots.iter().any(|root| {
        relative
            .strip_prefix(root.as_str())
            .is_some_and(|rest| rest.is_empty() || rest.starts_with(PATH_SEPARATOR))
    })
}

/// A binary signed with the ad-hoc identity, which is no identity.
///
/// `codesign -f -s - <binary>` makes a signature that says nothing about who
/// built it and that no notarised release carries. Oko counted it under
/// `binary-copy` from the start and nothing refused it: a locally re-signed
/// binary runs on the machine that signed it and on no other.
fn adhoc_signature_refusal(program: &str, args: &[String]) -> Option<String> {
    if program != CODESIGN || asks_for_help(args) {
        return None;
    }
    let at = args.iter().position(|arg| arg == ADHOC_SIGN_FLAG)?;
    if args.get(at + 1).map(String::as_str) != Some(ADHOC_IDENTITY) {
        return None;
    }
    Some(format!(
        "{BANNER}`codesign -s -` signs with the ad-hoc identity, which names nobody and travels \
         nowhere: the binary runs on the machine that signed it and is refused on every other. A \
         product's bytes are signed where they are released — `stado release prepare` and `stado \
         release submit` sign with the Developer ID and record the signature — and a local build \
         is installed with `stado release install-local` or the product's own installer."
    ))
}

/// A row in a key-value store changed by hand.
fn store_refusal(program: &str, args: &[String]) -> Option<String> {
    let words = &*VOCABULARY;
    if !has(&words.store_programs, program) || asks_for_help(args) {
        return None;
    }
    let command = args
        .iter()
        .map(|arg| arg.to_ascii_lowercase())
        .find(|arg| has(&words.store_write_commands, arg))?;
    Some(format!(
        "{BANNER}`{program} {command}` changes what a store holds by hand, and the product that \
         owns those keys neither wrote nor recorded it: the next write from the product meets \
         state it never agreed to. The command that owns the keys is the product's own, and a \
         change that has to outlive this machine belongs in its migration or its declaration."
    ))
}

/// A machine setting written by hand.
fn setting_refusal(program: &str, args: &[String]) -> Option<String> {
    let words = &*VOCABULARY;
    if !has(&words.setting_programs, program) || asks_for_help(args) {
        return None;
    }
    let verb = args
        .iter()
        .map(|arg| arg.to_ascii_lowercase())
        .find(|arg| has(&words.setting_write_verbs, arg))?;
    Some(format!(
        "{BANNER}`{program} {verb}` changes a setting on this machine and nothing declares it: the \
         next machine, the next image and this one after a reset do not have it. A setting a \
         product owns is declared where that product reads it — `stado registry set --path \
         <FIELD> --value <VALUE>` for the fleet's own declarations, the product's own command for \
         its runtime, and a browser policy through Weles — so every host that needs it gets it."
    ))
}

/// A scratch directory made outside the repository that asked for it.
fn scratch_refusal(program: &str, args: &[String]) -> Option<String> {
    if !has(&VOCABULARY.scratch_programs, program) || asks_for_help(args) {
        return None;
    }
    Some(format!(
        "{BANNER}`{program}` puts work where the operator's own cleanup removes it, and the next \
         reader of that path finds nothing. Work that has to survive until it is read belongs in \
         the repository's ignored build directory (`.build`, `rust/target`) or under \
         `~/.wisent-output`, both of which are still there on the next run."
    ))
}

/// Time passed by hand instead of an outcome observed.
///
/// `sleep 420 && stado release doctor …` guesses how long a fleet takes and
/// proves nothing about what happened in those seconds: too short and the
/// read is of the old state, too long and the session sat idle. Every
/// outcome this fleet produces has a read that reports it, and where one is
/// missing the missing read is the defect to build, not a longer sleep.
fn waiting_refusal(program: &str, args: &[String]) -> Option<String> {
    if !has(&VOCABULARY.wait_programs, program) || asks_for_help(args) {
        return None;
    }
    let interval = args.first().map(String::as_str).unwrap_or_default();
    Some(format!(
        "{BANNER}`{program} {interval}` waits a guessed interval and observes nothing: the state \
         read after it is as likely to be the old one. An outcome is waited for by the command \
         that owns it — `stado job watch <ID> --follow` to a terminal state, `stado release \
         doctor <PRODUCT> --target <HOST>` for one rollout verdict, `stado release status \
         <PRODUCT>` for the register of attempts, `stado space report <HOST>` for a host's own \
         reading. If the outcome has no such read, that missing read is the defect to build."
    ))
}

/// A tree searched from the shell.
///
/// `grep -rn … src` answers the person who typed it, once, and leaves
/// nothing behind: no product surface gained the answer, and the next
/// reader types it again. Reading a file is a read; searching a repository
/// from the shell is a step somebody has to repeat. The harness has its own
/// search that carries the result into the session, and a question asked of
/// a product is asked through that product's own read.
///
/// `launchctl list | grep wisent` is not that. `grep` with a pattern and no
/// path reads the previous command's output, which is the shape the fleet's
/// own reads are written in, and refusing it told sessions to stop using
/// commands the rule was never about — the test that says so had been red
/// since the rule was written.
fn search_refusal(program: &str, args: &[String]) -> Option<String> {
    if !has(&VOCABULARY.search_programs, program) || asks_for_help(args) {
        return None;
    }
    if has(&VOCABULARY.stream_search_programs, program) && !searches_a_tree(args) {
        return None;
    }
    Some(format!(
        "{BANNER}`{program}` searches a tree once for whoever typed it and leaves nothing a \
         later reader or a product surface can use. Read the file with the harness's own read, \
         search with its search, and ask a product what it holds through its own command — \
         `brama subscriptions`, `stado release status <PRODUCT>`, `oko-cli transcripts tasks \
         --session <ID>`. A question worth asking twice belongs in one of those, not in a \
         shell line."
    ))
}

/// Whether a stream search was pointed at files instead of a pipe: a path
/// after the pattern, or a recursive flag, which names a tree on its own.
/// The flag is read inside a cluster too, because `grep -rn PATTERN src` is
/// how a tree search is actually typed.
fn searches_a_tree(args: &[String]) -> bool {
    let recursive = args.iter().any(|arg| {
        arg == RECURSIVE_LONG_FLAG
            || (is_flag(arg)
                && !arg.starts_with(LONG_FLAG_PREFIX)
                && arg.chars().any(|letter| RECURSIVE_LETTERS.contains(&letter)))
    });
    let positionals = args.iter().filter(|arg| !is_flag(arg)).count();
    recursive || positionals > 1
}

/// A fleet command that repairs one host once where a declaration owns the
/// outcome. These are the product's own commands, which is what makes them
/// easy to keep typing: each leaves the host exactly as it was found the
/// next time the same pressure arrives.
fn fleet_one_off_refusal(program: &str, args: &[String]) -> Option<String> {
    let words = &*VOCABULARY;
    if program != words.fleet_program || asks_for_help(args) {
        return None;
    }
    let mut plain = args.iter().map(String::as_str).filter(|arg| !is_flag(arg));
    let command = format!("{} {}", plain.next()?, plain.next()?);
    let route = words.fleet_one_off_commands.get(&command)?;
    Some(format!(
        "{BANNER}`{} {command}` repairs one host once: {route}",
        words.fleet_program
    ))
}

/// A toolchain command that produces a verdict nobody but the shell sees.
///
/// The suite and the lint are not the problem — they are the product's own
/// quality gate, and the release worker runs both on every candidate. Typing
/// them here produces the same work with none of the record: no revision
/// bound to the result, no exit status the fleet keeps, and no refusal that
/// stops a bad build reaching a host.
fn toolchain_one_off_refusal(program: &str, args: &[String]) -> Option<String> {
    let words = &*VOCABULARY;
    if program != words.toolchain_program || asks_for_help(args) {
        return None;
    }
    let command = args
        .iter()
        .map(String::as_str)
        .find(|arg| !is_flag(arg))?
        .to_string();
    let route = words.toolchain_one_off_commands.get(&command)?;
    Some(format!(
        "{BANNER}`{} {command}` answers this shell and nothing else: {route}",
        words.toolchain_program
    ))
}

/// Any other build or suite run from a shell.
///
/// `cargo` has its own entry above; this is every other driver, because the
/// operator found a session running `swift build` and `swift test` all
/// afternoon while a gate that named only `cargo` watched it happen: "i jak
/// to jest mozliwe ze budujesz skoro nasz hook mial to blokowac. dodaj
/// swift test i jakiekolwiek komendy do budowania do listy zakazanych
/// zwrotow". A driver is read by the word after it (`swift test`,
/// `npm run build`); a program that only ever builds is refused by name.
fn build_one_off_refusal(program: &str, args: &[String]) -> Option<String> {
    let words = &*VOCABULARY;
    if asks_for_help(args) {
        return None;
    }
    let route = &words.build_route;
    if has(&words.build_programs, program) {
        return Some(format!("{BANNER}`{program}` builds from this working copy: {route}"));
    }
    let verbs = words.build_drivers.get(program)?;
    // `npm run build` names what it runs in the second word, so both are read,
    // and a script runner's script is read too: every `npm run <script>` in
    // these repositories compiles something — `test:context` builds the
    // release binary before it runs a single case — so the refusal names the
    // script it refused rather than the bare runner.
    let mut plain = args.iter().map(String::as_str).filter(|arg| !is_flag(arg));
    let first = plain.next()?;
    let verb = if has(verbs, first) {
        match plain.next() {
            Some(script) if first == SCRIPT_RUNNER_VERB => format!("{first} {script}"),
            _ => first.to_owned(),
        }
    } else {
        let second = plain.next().filter(|word| has(verbs, word))?;
        format!("{first} {second}")
    };
    Some(format!(
        "{BANNER}`{program} {verb}` builds or tests from this working copy: {route}"
    ))
}

/// A shell redirect that lands in the operator's own state.
fn operator_state_refusal(tokens: &[String]) -> Option<String> {
    let redirects = tokens.iter().any(|token| token.starts_with('>'));
    if !redirects {
        return None;
    }
    let landing = tokens
        .iter()
        .map(|token| token.trim_start_matches('>').to_string())
        .find(|token| {
            let relative = without_home(token);
            VOCABULARY
                .operator_state_roots
                .iter()
                .any(|root| relative.starts_with(root.as_str()))
        })?;
    Some(format!(
        "{BANNER}`> {landing}` writes the operator's own state from a shell: nothing records what \
         was put there, the product that reads it never agreed to it, and the next sync or \
         reinstall removes it. A bearer belongs to `stado credentials token mint <CONSUMER> \
         --host <VAULT HOST> --token-file-name <NAME>`, a fleet declaration to `stado registry \
         set --path <FIELD> --value <VALUE>`, and a product's own configuration to that product's \
         command."
    ))
}

/// A built executable copied over an installed one.
fn binary_copy_refusal(program: &str, args: &[String]) -> Option<String> {
    let is_copy = has(&VOCABULARY.copy_programs, program)
        || (program == LINK_PROGRAM && args.iter().any(|arg| arg.starts_with(SYMLINK_FLAG_PREFIX)));
    if !is_copy {
        return None;
    }
    let target = args
        .iter()
        .rev()
        .map(String::as_str)
        .find(|arg| !is_flag(arg))?;
    if !under_install_root(target) {
        return None;
    }
    Some(format!(
        "{BANNER}`{program} … {target}` replaces an installed program with a file nothing released, signed or recorded, and the units running the old image keep it. A product installs itself: `oko-cli install` for Oko, `stado product update <PRODUCT> --surface cli` for a catalogued product, `stado release install-local` for a delivered release, `stado host reconcile --apply` for a host behind its declaration."
    ))
}

/// A gate turned off by touching its own file.
///
/// Oko's catalogue holds the shape: on 2026-07-31 a session ran
/// `mv ~/.shared-hooks/block_browser_usage.sh ~/.shared-hooks/…​.paused`,
/// ran what the gate forbade, and moved the file back. The write gate sees
/// write and edit payloads, not a shell rename, so nothing refused it. What a
/// machine runs is decided by the selection and the installed release, not by
/// whether a file is still where the registry points.
fn hook_file_refusal(program: &str, args: &[String]) -> Option<String> {
    let words = &*VOCABULARY;
    let plain = || args.iter().map(String::as_str).filter(|arg| !is_flag(arg));
    // A copy or a rename is judged by where it lands: reading a registry out
    // of a hook root into a build directory is a read. A removal or a mode
    // change is judged by every path it names.
    let touched = if has(&words.copy_programs, program) || program == LINK_PROGRAM {
        plain().next_back().filter(|arg| under_hook_root(arg))?
    } else if has(&words.hook_write_programs, program) {
        plain().find(|arg| under_hook_root(arg))?
    } else {
        return None;
    };
    Some(format!(
        "{BANNER}`{program} … {touched}` changes a hook's own file, which turns a gate off for \
         every session on this machine until somebody notices. What this machine runs is chosen \
         with `tama enforcement only <hook-id>…` and `tama enforcement status`, a hook's source is \
         changed through `tama adaptive repair <hook-id> --patch-file <path>` and \
         `DEVICE_HOOK_EDIT_APPROVED=1 tama adaptive apply <proposal-dir>`, and the installed \
         release is rebuilt with `DEVICE_HOOK_EDIT_APPROVED=1 tama hooks release`."
    ))
}

fn under_hook_root(path: &str) -> bool {
    let relative = without_home(path);
    VOCABULARY
        .hook_roots
        .iter()
        .any(|root| relative.starts_with(root.as_str()))
}

/// The quoted arguments of the original command, in order.
///
/// The shell reading blanks quoted text so that a mention of a command is
/// never a command, and a database statement is exactly that: a quoted
/// argument. It is read here only after the parsed program is a database
/// client, so a sentence that contains the word `psql` still runs nothing.
fn quoted(raw: &str) -> Vec<String> {
    let mut out: Vec<String> = Vec::new();
    let mut current = String::new();
    let mut quote: Option<char> = None;
    for character in raw.chars() {
        match (quote, character) {
            (None, '\'') | (None, '"') => quote = Some(character),
            (Some(open), _) if character == open => {
                out.push(std::mem::take(&mut current));
                quote = None;
            }
            (Some(_), _) => current.push(character),
            (None, _) => {}
        }
    }
    out
}

/// A row or a table changed by hand through a database client.
fn sql_refusal(program: &str, raw: &str) -> Option<String> {
    let words = &*VOCABULARY;
    if !has(&words.sql_programs, program) {
        return None;
    }
    let statement = quoted(raw).into_iter().find_map(|argument| {
        let head = argument
            .split(|character: char| !character.is_ascii_alphabetic())
            .find(|word| !word.is_empty())?
            .to_ascii_lowercase();
        has(&words.sql_write_statements, &head).then_some(head)
    })?;
    Some(format!(
        "{BANNER}`{program} … {statement} …` changes rows or their shape by hand, and every check \
         the product keeps on them - validation, derived tables, the schema version - is skipped, \
         so the next product write meets data it never agreed to. The rows have an owner: for \
         Oko's catalogue `oko-cli transcripts reindex` and `oko-cli transcripts tasks …`, for a \
         service's own store that service's CLI, and a change of shape belongs in a migration \
         that ships with the product and runs on every host."
    ))
}

/// A deadline wrapped around somebody else's command.
///
/// The written-code gate refuses a deadline in a file, and this one refuses
/// it in a shell line, because the two are the same guess: a number nobody
/// measured, standing in for the answer the command was going to give. A
/// command killed at that number is reported as a failure it never had, and
/// the question of why it was slow is thrown away with it. The wrapper is
/// stepped over when the guard reads what a line actually runs, which is why
/// it has to be named here rather than left to the program table.
fn deadline_wrapper_refusal(tokens: &[String]) -> Option<String> {
    let words = &*VOCABULARY;
    // A duration has to follow, so `--field timeout` and a path that ends in
    // the word are left alone; `timeout 300 …`, `timeout 1.5m …` and
    // `timeout -k 5 20 …` are not.
    let wrapper = tokens.windows(2).find_map(|pair| {
        let name = basename(&pair[0]);
        let follows_a_duration = pair[1].starts_with('-')
            || pair[1]
                .trim_end_matches(['s', 'm', 'h', 'd'])
                .parse::<f64>()
                .is_ok();
        (has(&words.deadline_wrappers, name) && follows_a_duration).then_some(name)
    })?;
    Some(format!(
        "{BANNER}`{wrapper} <seconds> …` puts a guessed deadline in front of a command. Nobody \
         measured that number, and the command killed at it reports a failure it did not have — \
         a slow answer and a broken one read the same afterwards. Let the command answer and read \
         what it says; when an outcome genuinely has to be waited for, the product that owns it \
         waits: `stado job watch <ID> --follow`, `stado release status <PRODUCT>`, \
         `oko-cli transcripts tasks --session <ID>`."
    ))
}

/// Why this payload is a one-off repair, if it is one.
pub fn evaluate(payload: &Value) -> Option<String> {
    let command = command_from(payload);
    if command.trim().is_empty() {
        return None;
    }
    let acting = shell_text::effective_command(&command);
    shell_text::commands(&acting)
        .into_iter()
        .map(shell_tokens)
        .find_map(|tokens| {
            // A redirect has no program of its own: `printf … > ~/.stado/x`
            // runs `printf`, and where it lands is the repair.
            if let Some(refusal) = operator_state_refusal(&tokens) {
                return Some(refusal);
            }
            let (program, args) = program_and_args(&tokens)?;
            service_cycle_refusal(program, args)
                .or_else(|| credential_refusal(program, args))
                .or_else(|| binary_copy_refusal(program, args))
                .or_else(|| hook_file_refusal(program, args))
                .or_else(|| sql_refusal(program, &command))
                .or_else(|| adhoc_signature_refusal(program, args))
                .or_else(|| store_refusal(program, args))
                .or_else(|| setting_refusal(program, args))
                .or_else(|| scratch_refusal(program, args))
                .or_else(|| waiting_refusal(program, args))
                .or_else(|| search_refusal(program, args))
                .or_else(|| fleet_one_off_refusal(program, args))
                .or_else(|| toolchain_one_off_refusal(program, args))
                .or_else(|| build_one_off_refusal(program, args))
                .or_else(|| deadline_wrapper_refusal(&tokens))
        })
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    fn payload(command: &str) -> Value {
        json!({ "tool_name": "Bash", "tool_input": { "command": command } })
    }

    #[test]
    fn a_service_cycled_by_hand_is_refused_and_a_read_of_launchd_is_not() {
        assert!(evaluate(&payload(
            "launchctl kickstart -k gui/501/ai.wisent.oko.transcript-index"
        ))
        .is_some());
        assert!(evaluate(&payload(
            "sudo launchctl bootout system/com.wisent.stado.release-agent"
        ))
        .is_some());
        assert!(evaluate(&payload("kill -TERM 40080 || true")).is_some());
        assert!(evaluate(&payload("pkill -f 'next dev'")).is_some());
        assert!(evaluate(&payload("launchctl list")).is_none());
        assert!(evaluate(&payload(
            "launchctl print gui/501/ai.wisent.oko.transcript-index"
        ))
        .is_none());
        assert!(evaluate(&payload("kill -0 4610 && echo alive")).is_none());
        assert!(evaluate(&payload("kill -l")).is_none());
    }

    /// A deadline typed in front of a command is the same guess the product
    /// refuses in written code, and the guard used to step over it silently
    /// while reading what the line ran.
    #[test]
    fn a_command_wrapped_in_a_deadline_is_refused_and_a_plain_run_is_not() {
        let refusal =
            evaluate(&payload("timeout 300 tama-cli hooks warm --json")).expect("refused");
        assert!(refusal.contains("guessed deadline"), "{refusal}");
        assert!(evaluate(&payload("gtimeout 90 stado host gates")).is_some());
        assert!(evaluate(&payload("/usr/bin/timeout 5 ./script.sh")).is_some());
        assert!(evaluate(&payload("tama-cli hooks warm --json")).is_none());
        assert!(evaluate(&payload("stado job watch 1234 --follow")).is_none());
        assert!(evaluate(&payload("echo 'timeout 30 something'")).is_none());
    }

    #[test]
    fn a_vault_write_past_stado_is_refused_and_the_product_route_is_not() {
        let refusal = evaluate(&payload(
            "skarbiec grant ensure stado-release-client jeden-desktop-release-publisher --field token --token-file ~/.stado/t",
        ))
        .expect("refused");
        assert!(refusal.contains("declare-publisher"), "{refusal}");
        assert!(evaluate(&payload(
            "skarbiec token-mint --consumer oko --capabilities read:x#token"
        ))
        .is_some());
        assert!(evaluate(&payload(
            "stado credentials token mint oko --host mini --capabilities call:brama#best"
        ))
        .is_none());
        assert!(evaluate(&payload(
            "skarbiec grant verify stado-release-client jeden-release-publisher --action read"
        ))
        .is_none());
        assert!(evaluate(&payload("skarbiec grant list --json | head")).is_none());
        assert!(evaluate(&payload("skarbiec grant issue --help | head -5")).is_none());
        assert!(evaluate(&payload("echo 'skarbiec grant ensure someone'")).is_none());
        assert!(evaluate(&payload(
            "git commit -F - <<'EOF'\nA skarbiec grant ensure run by hand\nEOF"
        ))
        .is_none());
    }

    #[test]
    fn a_binary_copied_over_an_installed_one_is_refused_and_a_copy_out_is_not() {
        let refusal =
            evaluate(&payload("cp .build/debug/oko-cli ~/.stado/bin/oko-cli")).expect("refused");
        assert!(refusal.contains("oko-cli install"), "{refusal}");
        assert!(evaluate(&payload(
            "cd tama && cp rust/target/release/tama-x rust/target/release/tama-y ~/.local/bin/"
        ))
        .is_some());
        assert!(evaluate(&payload(
            "ln -sf /Users/me/.stado/bin/skarbiec /Users/me/.local/bin/skarbiec"
        ))
        .is_some());
        assert!(evaluate(&payload("cp ~/.stado/bin/oko-cli .build/oko-cli-backup")).is_none());
        assert!(evaluate(&payload("cp .build/release/oko-cli dist/oko-cli")).is_none());
        assert!(evaluate(&payload("ls -la ~/.stado/bin/oko-cli")).is_none());
    }

    #[test]
    fn a_hook_file_changed_from_the_shell_is_refused_and_a_read_of_one_is_not() {
        let refusal = evaluate(&payload(
            "mv ~/.shared-hooks/block_browser_usage.sh ~/.shared-hooks/block_browser_usage.sh.paused",
        ))
        .expect("refused");
        assert!(refusal.contains("tama enforcement only"), "{refusal}");
        assert!(evaluate(&payload("rm ~/.shared-hooks/file_justifications.json")).is_some());
        assert!(evaluate(&payload(
            "chmod -x ~/.shared-hooks/block_inline_execution.sh"
        ))
        .is_some());
        // A path carrying spaces is quoted, and quoted text is blanked before
        // any of this runs so that a mention of a command is never a command
        // (`crate::ports::shell_text`). The runtime release lives under such a
        // path; the roots a shell names without quoting are what this reads.
        assert!(evaluate(&payload("install -m 755 build/x ~/.config/tama/hooks/x")).is_some());
        assert!(evaluate(&payload("rm -rf ~/.claude/hooks")).is_some());
        assert!(evaluate(&payload("ls -la ~/.shared-hooks")).is_none());
        assert!(evaluate(&payload(
            "cp ~/.shared-hooks/registry.json .build/registry.json"
        ))
        .is_none());
        assert!(evaluate(&payload("tama enforcement status")).is_none());
    }

    #[test]
    fn a_row_written_by_hand_is_refused_and_a_query_is_not() {
        let refusal = evaluate(&payload(
            "sqlite3 ~/.oko/index.sqlite \"UPDATE tasks SET status = 'done' WHERE ordinal = 5\"",
        ))
        .expect("refused");
        assert!(refusal.contains("oko-cli transcripts reindex"), "{refusal}");
        assert!(evaluate(&payload(
            "psql -h db.example.co -U postgres -c 'delete from sessions where id = 7'"
        ))
        .is_some());
        assert!(evaluate(&payload("sqlite3 x.db 'DROP TABLE sessions'")).is_some());
        assert!(evaluate(&payload(
            "sqlite3 ~/.oko/index.sqlite \"SELECT COUNT(*) FROM operator_messages\""
        ))
        .is_none());
        assert!(evaluate(&payload("sqlite3 x.db .schema")).is_none());
        assert!(evaluate(&payload("psql --help | head -3")).is_none());
        assert!(evaluate(&payload("echo 'update the docs' >> notes.md")).is_none());
        assert!(evaluate(&payload(
            "git commit -m 'refuse a raw update against the catalogue'"
        ))
        .is_none());
    }

    #[test]
    fn a_wrapper_and_a_pipeline_are_read_through() {
        assert!(evaluate(&payload(
            "cd ~ && timeout 60 skarbiec grant issue oko --capabilities read:x#token"
        ))
        .is_some());
        assert!(evaluate(&payload("echo ok | tee log.txt")).is_none());
        assert!(evaluate(&json!({ "tool_name": "Read", "tool_input": { "path": "x" } })).is_none());
    }

    /// A guessed interval observes nothing. This session ran `sleep 420`
    /// before reading one rollout and `sleep 240` before retrying a
    /// publication, and both reads could as easily have returned the old
    /// state. The commands that report an outcome pass.
    #[test]
    fn time_passed_by_hand_is_refused_and_a_read_of_the_outcome_is_not() {
        assert!(evaluate(&payload("sleep 420")).is_some());
        assert!(evaluate(&payload(
            "sleep 240; stado release doctor skarbiec --target charless-mac-mini"
        ))
        .is_some());
        assert!(evaluate(&payload("stado job watch 5e0f --follow")).is_none());
        assert!(evaluate(&payload("stado release status stado")).is_none());
        assert!(evaluate(&payload("stado space report lukasz-macbook")).is_none());
    }

    /// A tree searched from the shell answers whoever typed it, once. The
    /// operator's rule: a search is a one-off like the rest, and the answer
    /// belongs in the harness's own read or in a product command that any
    /// later reader can run again.
    #[test]
    fn a_shell_search_is_refused_and_a_product_read_is_not() {
        let refusal =
            evaluate(&payload("grep -rn 'brama:account:' src")).expect("a shell search is refused");
        assert!(refusal.contains("searches a tree once"), "{refusal}");
        assert!(evaluate(&payload("rg --files-with-matches account src")).is_some());
        assert!(evaluate(&payload("brama subscriptions --json")).is_none());
        assert!(evaluate(&payload("oko-cli transcripts tasks --open")).is_none());
        assert!(evaluate(&payload("grep --help")).is_none());
    }

    /// Two fleet commands repair one host once where a declaration owns the
    /// outcome: a sweep this session ran three times in one day, and a
    /// release built from whatever the shell's working copy held. Their
    /// refusals name the declaration and the recipe; the reads beside them
    /// pass.
    #[test]
    fn a_fleet_command_that_repairs_one_host_once_is_refused_with_its_declaration() {
        let sweep = evaluate(&payload(
            "stado space reclaim lukasz-macbook --apply --reason 'builds filled the disk'",
        ))
        .expect("a sweep by hand is refused");
        assert!(sweep.contains("stado space cleaners"), "{sweep}");
        assert!(sweep.contains("stado space watermark"), "{sweep}");

        let release = evaluate(&payload(
            "stado release submit --source . --commit 6c9f32cb --version 0.21.49",
        ))
        .expect("a release typed by hand is refused");
        assert!(release.contains("tama build record"), "{release}");

        assert!(evaluate(&payload("stado space report lukasz-macbook")).is_none());
        assert!(evaluate(&payload("stado release status stado --json")).is_none());
        assert!(evaluate(&payload("stado release submit --help")).is_none());
        assert!(evaluate(&payload("stado queue budget")).is_none());
    }
}
