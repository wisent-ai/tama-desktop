//! Grant normalization: tool-name validation and the per-tool merge of
//! `{ tool }` / `{ tool, actions }` grant entries.

use serde_json::{json, Value};

use crate::jsutil;

/// `/^[a-z][a-z0-9:_-]{0,127}$/`
fn is_valid_tool_name(name: &str) -> bool {
    let b = name.as_bytes();
    !b.is_empty()
        && b.len() <= 128
        && b[0].is_ascii_lowercase()
        && b[1..].iter().all(|&c| {
            c.is_ascii_lowercase() || c.is_ascii_digit() || c == b':' || c == b'_' || c == b'-'
        })
}

/// Port of `normalizeCapabilityGrants`. Returns `None` for any invalid input,
/// otherwise a JSON array of `{ tool }` / `{ tool, actions }` objects with
/// grants merged per tool and sorted by tool name.
///
/// Deviation: JS sorts tools with `localeCompare`; we sort by byte order.
/// For plain ASCII tool names without punctuation these agree.
pub fn normalize_capability_grants(value: &Value) -> Option<Value> {
    let arr = value.as_array()?;
    if arr.is_empty() {
        return None;
    }
    // Insertion-ordered stand-in for the JS `Map` keyed by tool.
    let mut merged: Vec<(String, Option<Vec<String>>)> = Vec::new();
    for grant in arr {
        // `as_object` rejects arrays, matching the JS `!Array.isArray` check.
        let obj = grant.as_object()?;
        let tool = jsutil::trim_js(&jsutil::js_string_or_empty(obj.get("tool"))).to_lowercase();
        if !is_valid_tool_name(&tool) {
            return None;
        }
        let actions: Option<Vec<String>> = match obj.get("actions") {
            None | Some(Value::Null) => None,
            Some(v) => {
                let items = v.as_array()?;
                if items.is_empty() {
                    return None;
                }
                let mut dedup: Vec<String> = Vec::new();
                for item in items {
                    let a = jsutil::trim_js(&jsutil::js_string_or_empty(Some(item))).to_lowercase();
                    if !dedup.contains(&a) {
                        dedup.push(a);
                    }
                }
                if dedup.iter().any(|a| !is_valid_tool_name(a)) {
                    return None;
                }
                Some(dedup)
            }
        };
        match merged.iter_mut().find(|(t, _)| *t == tool) {
            Some(entry) => {
                entry.1 = match (entry.1.take(), actions) {
                    (Some(existing), Some(new_actions)) => {
                        let mut union = existing;
                        for a in new_actions {
                            if !union.contains(&a) {
                                union.push(a);
                            }
                        }
                        union.sort();
                        Some(union)
                    }
                    _ => None,
                };
            }
            None => {
                let actions = actions.map(|mut a| {
                    a.sort();
                    a
                });
                merged.push((tool, actions));
            }
        }
    }
    merged.sort_by(|a, b| a.0.cmp(&b.0));
    Some(Value::Array(
        merged
            .into_iter()
            .map(|(tool, actions)| match actions {
                None => json!({ "tool": tool }),
                Some(a) => json!({ "tool": tool, "actions": a }),
            })
            .collect(),
    ))
}
