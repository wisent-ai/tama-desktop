//! tama-hook-tools: Rust ports of the standalone tools in `shared-hooks/`:
//! `editor-save-guard.mjs`, `editor-watch.mjs`, `generate-configs.mjs`,
//! `run-one-session-hook.js` and
//! `install_oko_trajectory_boundary_hook.mjs`, plus the `ports` tree holding
//! the Rust ports of the registered Python hooks.

pub mod assignment;
pub mod brama;
pub mod capability;
pub mod evidence;
pub mod hook_exec;
pub mod objective_reviewer;
pub mod one_session;
pub mod ports;
pub mod registry;
pub mod tracker;
pub mod util;
