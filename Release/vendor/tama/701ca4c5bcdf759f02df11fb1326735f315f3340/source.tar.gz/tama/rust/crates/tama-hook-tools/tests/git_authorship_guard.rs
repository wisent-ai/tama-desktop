//! `tama-block-git-authorship`, driven as the real binary with real payloads.
//!
//! Each case feeds the hook the JSON a harness sends for one tool call and
//! holds it to its exit status and the words it printed. The refusal the
//! operator asked for is checked literally: a hook whose message drifts stops
//! saying what he wrote.

use std::io::Write;
use std::process::{Command, Output, Stdio};

const TOOL: &str = env!("CARGO_BIN_EXE_tama-block-git-authorship");

const ALLOWED: i32 = false as i32;
const REFUSED: i32 = true as i32 + true as i32;

const OPERATOR_LINE: &str = "SPRAWDZ TRANSKRYPTY DEBILU, GIT CI NIC NIE POWIE";

fn payload(json: &str) -> Output {
    let mut child = Command::new(TOOL)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .expect("hook runs");
    child
        .stdin
        .as_mut()
        .expect("stdin is piped")
        .write_all(json.as_bytes())
        .expect("payload is written");
    child.wait_with_output().expect("hook exits")
}

/// The hook, given the payload of one `bash` call.
fn bash(command: &str) -> Output {
    payload(&format!(
        r#"{{"tool_name":"bash","tool_input":{{"command":{}}}}}"#,
        serde_json::to_string(command).expect("command serialises")
    ))
}

fn refused(command: &str) -> String {
    let output = bash(command);
    assert_eq!(
        output.status.code(),
        Some(REFUSED),
        "{command} must be refused: {}",
        String::from_utf8_lossy(&output.stderr)
    );
    let message = String::from_utf8_lossy(&output.stderr).to_string();
    assert!(
        message.contains(OPERATOR_LINE),
        "the refusal must carry the operator's line, got: {message}"
    );
    assert!(
        message.contains("oko-cli transcripts"),
        "the refusal must name where the answer is, got: {message}"
    );
    message
}

fn allowed(command: &str) {
    let output = bash(command);
    assert_eq!(
        output.status.code(),
        Some(ALLOWED),
        "{command} must be allowed: {}",
        String::from_utf8_lossy(&output.stderr)
    );
    assert!(
        output.stderr.is_empty(),
        "an allowed command prints nothing: {}",
        String::from_utf8_lossy(&output.stderr)
    );
}

#[test]
fn the_commands_that_name_a_person_are_refused() {
    refused("git blame src/main.rs");
    refused("git annotate README.md");
    refused("git shortlog -sn");
    refused("git check-mailmap somebody@example.com");
}

#[test]
fn selecting_commits_by_who_made_them_is_refused() {
    refused("git log --author=somebody --oneline");
    refused("git log --committer somebody --oneline");
    refused("git log --use-mailmap --oneline");
}

#[test]
fn an_identity_placeholder_in_a_format_is_refused() {
    refused(r#"git log --format="%an %ae" -1"#);
    refused("git show --no-patch --format=%aN HEAD");
    refused("git for-each-ref --format=%(authorname) refs/heads");
    refused("git log --pretty=format:%cn -5");
}

#[test]
fn a_built_in_format_that_prints_the_author_is_refused() {
    refused("git log --pretty=fuller -1");
    refused("git show --format=raw HEAD");
}

#[test]
fn a_history_command_with_no_format_still_prints_the_author_so_it_is_refused() {
    let message = refused("git log -3");
    assert!(
        message.contains("unless a format says otherwise"),
        "the refusal must say why a bare log counts, got: {message}"
    );
    refused("git show HEAD");
    refused("cd repo && git log | head -20");
}

#[test]
fn a_formatted_history_without_an_identity_is_allowed() {
    allowed("git log --oneline -1");
    allowed("git log --format=%h -5");
    allowed("git show --no-patch --format=%s HEAD");
    allowed("git status --short");
    allowed("git diff --stat");
    allowed("git commit -q -F .git/MSG");
}

#[test]
fn a_command_that_is_not_git_is_allowed() {
    allowed("rg --files-with-matches author src");
    allowed("wc -l src/main.rs");
}

#[test]
fn the_gate_reads_the_command_a_supervised_process_would_run() {
    let output = payload(
        r#"{"tool_name":"hub","tool_input":{"op":"start","application":"git","args":["blame","src/main.rs"]}}"#,
    );
    assert_eq!(
        output.status.code(),
        Some(REFUSED),
        "a hub start must be read as the command it runs: {}",
        String::from_utf8_lossy(&output.stderr)
    );
}

#[test]
fn a_tool_that_cannot_execute_is_left_alone() {
    let output = payload(r#"{"tool_name":"read","tool_input":{"path":"git log --format=%an"}}"#);
    assert_eq!(output.status.code(), Some(ALLOWED));
    assert!(output.stderr.is_empty());
}
