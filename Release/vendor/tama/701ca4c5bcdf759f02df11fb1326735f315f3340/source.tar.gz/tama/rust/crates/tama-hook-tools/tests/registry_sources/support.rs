//! The scratch checkout each case runs against, the registry it writes
//! there, and the way the real binary is invoked.
//!
//! Split out of `tests/registry_sources.rs`, which had grown past the
//! three-hundred-line limit; the cases are in `main.rs`.

use std::fs;
use std::path::PathBuf;
use std::process::Command;
use std::time::{SystemTime, UNIX_EPOCH};

pub const TOOL: &str = env!("CARGO_BIN_EXE_tama-reconcile-registry-sources");

/// A process that did not report an exit code of its own.
const NO_CODE: i32 = -1;

pub fn fixture(label: &str) -> PathBuf {
    let nonce = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .expect("clock after epoch")
        .as_nanos();
    // The crate's own `CARGO_TARGET_TMPDIR` inside `target/`: not `/tmp`,
    // swept on sight here, and not `~/.stado/work`, which belongs to Stado.
    let root = PathBuf::from(env!("CARGO_TARGET_TMPDIR"))
        .join(format!("tama-registry-sources-{label}-{nonce}"));
    fs::create_dir_all(&root).expect("create scratch root");
    root
}

pub fn init_repo(root: &PathBuf, files: &[&str]) {
    Command::new("git")
        .arg("init")
        .current_dir(root)
        .output()
        .expect("git init");
    for file in files {
        let path = root.join(file);
        fs::create_dir_all(path.parent().unwrap()).expect("create parent dirs");
        fs::write(&path, "").expect("write file");
        Command::new("git")
            .args(["add", file])
            .current_dir(root)
            .output()
            .expect("git add");
    }
    Command::new("git")
        .args(["config", "user.email", "test@example.com"])
        .current_dir(root)
        .output()
        .expect("git config");
    Command::new("git")
        .args(["config", "user.name", "Test"])
        .current_dir(root)
        .output()
        .expect("git config");
    Command::new("git")
        .args(["commit", "-m", "init"])
        .current_dir(root)
        .output()
        .expect("git commit");
}

pub fn write_registry(path: &PathBuf, entries: &[(&str, &str)]) {
    let mut json = String::from("{\n");
    for (i, (name, source)) in entries.iter().enumerate() {
        if i > 0 {
            json.push_str(",\n");
        }
        json.push_str(&format!(
            "  \"{name}\": {{\n    \"source\": \"{source}\"\n  }}"
        ));
    }
    json.push_str("\n}\n");
    fs::write(path, json).expect("write registry");
}

pub fn read_registry(path: &PathBuf) -> String {
    fs::read_to_string(path).expect("read registry")
}

pub fn run(args: &[&str]) -> (i32, String, String) {
    let output = Command::new(TOOL)
        .args(args)
        .output()
        .expect("run reconciler");
    let code = output.status.code().unwrap_or(NO_CODE);
    let stdout = String::from_utf8_lossy(&output.stdout).to_string();
    let stderr = String::from_utf8_lossy(&output.stderr).to_string();
    (code, stdout, stderr)
}
