//! The provenance-file contract of `block-keyword-literals`.
//!
//! `keyword-provenance.json` is the one file where a word list may live, and
//! it is not scanned — it is validated. Every entry is exactly
//! `{"words": ["…", …], "user_said": "<verbatim quote>"}`; the quote must
//! appear verbatim in a real `role=user` transcript message, and every word
//! must appear in that quote. The hook certifies that the operator said the
//! words, not that the classifier built on them is right.
//!
//! The file is looked up from the written file's directory upward, so a
//! repository declares its words once at its root.

use std::collections::HashSet;
use std::path::Path;

use serde_json::Value;

use super::super::check_numeric_literals_provenance::quote_in_user_msg;

const FILE_NAME: &str = "keyword-provenance.json";
const WORDS_KEY: &str = "words";
const QUOTE_KEY: &str = "user_said";

const INVALID_JSON: &str = "keyword-provenance.json is not valid JSON: ";
const NOT_OBJECT: &str = "keyword-provenance.json must be an object: name -> {words,user_said}";
const ENTRY_SHAPE: &str = "\": entry must be exactly {words,user_said}";
const WORDS_SHAPE: &str = "\": words must be a non-empty array of non-empty strings";
const QUOTE_SHAPE: &str = "\": user_said must be a non-empty verbatim quote";
const QUOTE_MISSING: &str = "\": quote not found in any real user message: \"";
const WORD_UNDECLARED: &str = "\": user quote does not contain the word \"";

/// One declared entry: its name, its words, the operator's quote.
type Entry = (String, Vec<String>, String);

/// The entries of a document, or the sentences saying why it is not one.
fn entries(text: &str) -> Result<Vec<Entry>, Vec<String>> {
    let doc: Value =
        serde_json::from_str(text).map_err(|error| vec![format!("{INVALID_JSON}{error}")])?;
    let object = doc.as_object().ok_or_else(|| vec![NOT_OBJECT.to_owned()])?;
    let mut out = Vec::new();
    let mut problems = Vec::new();
    for (name, entry) in object {
        let Some(fields) = entry.as_object() else {
            problems.push(format!("\"{name}{ENTRY_SHAPE}"));
            continue;
        };
        let expected: HashSet<&str> = [WORDS_KEY, QUOTE_KEY].into_iter().collect();
        if fields.keys().map(String::as_str).collect::<HashSet<_>>() != expected {
            problems.push(format!("\"{name}{ENTRY_SHAPE}"));
            continue;
        }
        let words: Vec<String> = fields[WORDS_KEY]
            .as_array()
            .map(|items| {
                items
                    .iter()
                    .filter_map(Value::as_str)
                    .map(str::to_owned)
                    .collect()
            })
            .unwrap_or_default();
        let listed = fields[WORDS_KEY]
            .as_array()
            .map(Vec::len)
            .unwrap_or_default();
        if words.is_empty() || words.len() != listed || words.iter().any(|w| w.trim().is_empty()) {
            problems.push(format!("\"{name}{WORDS_SHAPE}"));
            continue;
        }
        let quote = fields[QUOTE_KEY]
            .as_str()
            .unwrap_or_default()
            .trim()
            .to_owned();
        if quote.is_empty() {
            problems.push(format!("\"{name}{QUOTE_SHAPE}"));
            continue;
        }
        out.push((name.clone(), words, quote));
    }
    if problems.is_empty() {
        Ok(out)
    } else {
        Err(problems)
    }
}

/// Validate a provenance document being written: shape, quote in a real
/// user message, every word inside that quote.
pub fn check(text: &str) -> Vec<String> {
    let entries = match entries(text) {
        Ok(entries) => entries,
        Err(problems) => return problems,
    };
    let mut out = Vec::new();
    for (name, words, quote) in entries {
        if !quote_in_user_msg(&quote) {
            out.push(format!("\"{name}{QUOTE_MISSING}{quote}\""));
            continue;
        }
        let folded = quote.to_lowercase();
        for word in words {
            if !folded.contains(&word.to_lowercase()) {
                out.push(format!("\"{name}{WORD_UNDECLARED}{word}\""));
            }
        }
    }
    out
}

/// Every word the nearest provenance file above `written` declares,
/// lower-cased. An unreadable or malformed file declares nothing: the
/// guard then refuses the list, and the file's own write reports why.
pub fn declared_words(written: &str) -> HashSet<String> {
    let mut dir = Path::new(written).parent();
    while let Some(directory) = dir {
        let candidate = directory.join(FILE_NAME);
        if let Ok(text) = std::fs::read_to_string(&candidate) {
            return entries(&text)
                .map(|entries| {
                    entries
                        .into_iter()
                        .flat_map(|(_, words, _)| words)
                        .map(|word| word.to_lowercase())
                        .collect()
                })
                .unwrap_or_default();
        }
        dir = directory.parent();
    }
    HashSet::new()
}

#[cfg(test)]
mod tests {
    use super::entries;

    #[test]
    fn an_entry_is_words_and_a_quote_and_nothing_else() {
        let ok = r#"{"acks": {"words": ["ok", "zrobione"], "user_said": "ok albo zrobione znaczy tak"}}"#;
        assert_eq!(entries(ok).map(|e| e.len()), Ok(usize::from(true)));
        let extra = r#"{"acks": {"words": ["ok"], "user_said": "ok", "note": "x"}}"#;
        assert!(entries(extra).is_err());
        let empty = r#"{"acks": {"words": [], "user_said": "ok"}}"#;
        assert!(entries(empty).is_err());
    }
}
