//! Harness-independent hook execution, with adapters at the process boundary.

use std::collections::HashSet;

mod emit;
mod exec;
mod flow;
mod jssem;
mod observation;
mod protocol;
mod runtime;

pub use flow::usage;
pub use runtime::Runtime;

/// Invocation filters do not replace the machine's enforcement selection.
#[derive(Clone, Debug, Default)]
pub struct InvocationOptions {
    pub only_hook_id: String,
    pub disabled_hook_ids: HashSet<String>,
    pub enabled_hook_ids: Option<HashSet<String>>,
}

/// The canonical decision before a harness formats it for its own protocol.
#[derive(Debug)]
pub struct Decision {
    pub blocked: bool,
    pub document: String,
}

impl Decision {
    pub(crate) fn pass(document: String) -> Self {
        Self {
            blocked: false,
            document,
        }
    }

    pub(crate) fn block(document: String) -> Self {
        Self {
            blocked: true,
            document,
        }
    }
}

pub fn run_once(
    registry_path: &std::path::Path,
    event: &str,
    agent_id: &str,
    provider: &str,
    options: &InvocationOptions,
    input: &str,
) -> Result<Decision, String> {
    let runtime = Runtime::load(registry_path)?;
    let payload = flow::parse_payload(input);
    // One-shot harness adapters publish their own session record. The
    // persistent engine must not overwrite an in-process adapter's record.
    let context = tama_hooks::session_control::session_context(agent_id, Some(&payload));
    tama_hooks::session_control::publish_session(
        context.as_ref(),
        Some(runtime.hook_ids()),
        Some(&payload),
    )
    .map_err(|error| error.to_string())?;
    flow::dispatch_loaded_for_provider(&runtime, event, agent_id, provider, options, &payload)
}

pub fn emit(provider: &str, decision: &Decision) -> i32 {
    emit::emit_decision(
        provider,
        if decision.blocked { "block" } else { "pass" },
        &decision.document,
    )
}

pub fn serve(
    registry_path: &std::path::Path,
    agent_id: &str,
    provider: &str,
    options: &InvocationOptions,
) -> Result<(), String> {
    protocol::serve(registry_path, agent_id, provider, options)
}

pub fn default_registry_path() -> std::path::PathBuf {
    std::env::var_os("AGENT_HOOK_REGISTRY")
        .filter(|path| !path.is_empty())
        .map(std::path::PathBuf::from)
        .unwrap_or_else(|| exec::home_dir().join(".shared-hooks").join("registry.json"))
}
