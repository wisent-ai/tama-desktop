//! JavaScript dates: `Date.now()` milliseconds, `Date#toISOString`, and the
//! ISO-8601 subset of `Date.parse`. Civil-date conversions use Howard
//! Hinnant's algorithms because no date/time crate may be added.

use std::time::{SystemTime, UNIX_EPOCH};

/// Milliseconds since the Unix epoch, like `Date.now()`.
pub fn now_millis() -> f64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as f64)
        .unwrap_or(0.0)
}

fn days_from_civil(y: i64, m: i64, d: i64) -> i64 {
    let y = if m <= 2 { y - 1 } else { y };
    let era = if y >= 0 { y } else { y - 399 } / 400;
    let yoe = y - era * 400; // [0, 399]
    let mp = (m + 9) % 12; // [0, 11]
    let doy = (153 * mp + 2) / 5 + d - 1;
    let doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    era * 146097 + doe - 719468
}

fn civil_from_days(z: i64) -> (i64, i64, i64) {
    let z = z + 719468;
    let era = if z >= 0 { z } else { z - 146096 } / 146097;
    let doe = z - era * 146097; // [0, 146096]
    let yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    let y = yoe + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = doy - (153 * mp + 2) / 5 + 1;
    let m = if mp < 10 { mp + 3 } else { mp - 9 };
    (if m <= 2 { y + 1 } else { y }, m, d)
}

fn is_leap_year(y: i64) -> bool {
    y % 4 == 0 && (y % 100 != 0 || y % 400 == 0)
}

fn days_in_month(y: i64, m: i64) -> i64 {
    match m {
        1 | 3 | 5 | 7 | 8 | 10 | 12 => 31,
        4 | 6 | 9 | 11 => 30,
        2 => {
            if is_leap_year(y) {
                29
            } else {
                28
            }
        }
        _ => 0,
    }
}

/// `new Date(ms).toISOString()` — always UTC, `YYYY-MM-DDTHH:mm:ss.sssZ`
/// (expanded signed six-digit year outside 0000..=9999).
pub fn to_iso_string(ms: f64) -> String {
    let ms = ms.trunc() as i64;
    let days = ms.div_euclid(86_400_000);
    let rem = ms.rem_euclid(86_400_000);
    let (y, mo, d) = civil_from_days(days);
    let (hh, mi, ss, mss) = (
        rem / 3_600_000,
        (rem / 60_000) % 60,
        (rem / 1_000) % 60,
        rem % 1_000,
    );
    let year = if (0..=9999).contains(&y) {
        format!("{:04}", y)
    } else if y > 9999 {
        format!("+{:06}", y)
    } else {
        format!("-{:06}", -y)
    };
    format!(
        "{}-{:02}-{:02}T{:02}:{:02}:{:02}.{:03}Z",
        year, mo, d, hh, mi, ss, mss
    )
}

fn take_digits(b: &[u8], i: &mut usize, n: usize) -> Option<i64> {
    if *i + n > b.len() {
        return None;
    }
    let mut v: i64 = 0;
    for k in 0..n {
        let c = b[*i + k];
        if !c.is_ascii_digit() {
            return None;
        }
        v = v * 10 + (c - b'0') as i64;
    }
    *i += n;
    Some(v)
}

/// Subset of `Date.parse(string)`: the ISO-8601 forms (`YYYY`, `YYYY-MM`,
/// `YYYY-MM-DD`, optional `THH:mm[:ss[.fff]]`, optional `Z`/`±hh[:mm]` zone).
/// Returns milliseconds since the epoch.
///
/// Deviation: a date-time without a zone is treated as UTC, whereas JS parses
/// it in the local timezone. Values in this codebase are produced by
/// `toISOString()` and always carry `Z`.
pub fn parse_date(s: &str) -> Option<f64> {
    let b = s.as_bytes();
    let mut i = 0usize;
    let (year, sign): (i64, i64) = if b.first() == Some(&b'+') {
        i = 1;
        (take_digits(b, &mut i, 6)?, 1)
    } else if b.first() == Some(&b'-') {
        i = 1;
        (take_digits(b, &mut i, 6)?, -1)
    } else {
        (take_digits(b, &mut i, 4)?, 1)
    };
    let year = year * sign;
    let mut month = 1i64;
    let mut day = 1i64;
    if i < b.len() && b[i] == b'-' {
        i += 1;
        month = take_digits(b, &mut i, 2)?;
        if i < b.len() && b[i] == b'-' {
            i += 1;
            day = take_digits(b, &mut i, 2)?;
        }
    }
    if !(1..=12).contains(&month) || day < 1 || day > days_in_month(year, month) {
        return None;
    }

    let mut hour = 0i64;
    let mut minute = 0i64;
    let mut second = 0i64;
    let mut millis = 0i64;
    let mut has_time = false;
    if i < b.len() && (b[i] == b'T' || b[i] == b' ') {
        has_time = true;
        i += 1;
        hour = take_digits(b, &mut i, 2)?;
        if i >= b.len() || b[i] != b':' {
            return None;
        }
        i += 1;
        minute = take_digits(b, &mut i, 2)?;
        if i < b.len() && b[i] == b':' {
            i += 1;
            second = take_digits(b, &mut i, 2)?;
            if i < b.len() && b[i] == b'.' {
                i += 1;
                let start = i;
                while i < b.len() && b[i].is_ascii_digit() {
                    i += 1;
                }
                if i == start {
                    return None;
                }
                let digits = &b[start..i];
                // First three digits, right-padded with zeros (".5" -> 500ms).
                millis = (0..3).fold(0i64, |a, k| {
                    a * 10 + digits.get(k).map_or(0, |c| (c - b'0') as i64)
                });
            }
        }
    }
    if hour > 23 || minute > 59 || second > 59 {
        return None;
    }

    let mut offset_minutes: i64 = 0;
    if has_time && i < b.len() {
        if b[i] == b'Z' {
            i += 1;
        } else if b[i] == b'+' || b[i] == b'-' {
            let sign: i64 = if b[i] == b'-' { -1 } else { 1 };
            i += 1;
            let oh = take_digits(b, &mut i, 2)?;
            let om = if i < b.len() && b[i] == b':' {
                i += 1;
                take_digits(b, &mut i, 2)?
            } else if i + 2 <= b.len() && b[i].is_ascii_digit() {
                take_digits(b, &mut i, 2)?
            } else {
                0
            };
            if oh > 23 || om > 59 {
                return None;
            }
            offset_minutes = sign * (oh * 60 + om);
        } else {
            return None;
        }
    }
    if i != b.len() {
        return None;
    }

    let days = days_from_civil(year, month, day);
    let ms = days * 86_400_000 + (hour * 3_600_000 + minute * 60_000 + second * 1_000 + millis)
        - offset_minutes * 60_000;
    if ms.unsigned_abs() > 8_640_000_000_000_000 {
        return None; // outside the JS Date range
    }
    Some(ms as f64)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn iso_roundtrip() {
        assert_eq!(to_iso_string(0.0), "1970-01-01T00:00:00.000Z");
        assert_eq!(
            to_iso_string(1_735_689_600_123.0),
            "2025-01-01T00:00:00.123Z"
        );
        assert_eq!(
            parse_date("2025-01-01T00:00:00.123Z"),
            Some(1_735_689_600_123.0)
        );
        assert_eq!(parse_date("1970-01-01"), Some(0.0));
        assert_eq!(
            parse_date("2025-01-01T02:00:00+02:00"),
            Some(1_735_689_600_000.0)
        );
        assert_eq!(parse_date("2025-13-01"), None);
        assert_eq!(parse_date("not a date"), None);
        // Roundtrip through to_iso_string.
        let ms = parse_date("2030-06-15T12:34:56.789Z").unwrap();
        assert_eq!(to_iso_string(ms), "2030-06-15T12:34:56.789Z");
    }
}
