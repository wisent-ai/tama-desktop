//! Logic for `tama-pre-edit-trajectory-evidence`, registry hook
//! `pre-edit-trajectory-evidence`: a trajectory, keeper or routine edit needs
//! measured evidence before it lands.
//!
//! On 2026-05-24 eight trajectory patches shipped in one session on
//! keeper-versus-trajectory diff hypotheses with no measured evidence. Seven
//! had to be reverted. So the next edit has to cite a passing-versus-failing
//! comparison from real logs, row ids or commits: fifty words in
//! `~/.claude/file_justifications.json` under
//! `trajectory_evidence_justification`, keyed by the file being edited,
//! naming a passing source, a non-passing source and a concrete artifact.

mod message;

use std::sync::LazyLock;

use regex::Regex;
use serde_json::Value;
use tama_hooks::session_record::{deny_tool_use, read_payload};

use crate::ports::python_stdlib::expanduser;
use crate::ports::transport_common as common;

const TOOL_KEY: &str = "tool_name";
const INPUT_KEY: &str = "tool_input";
const FILE_PATH_KEY: &str = "file_path";
const FIELD: &str = "trajectory_evidence_justification";
const REGISTRY_PATH: &str = "~/.claude/file_justifications.json";
const BYPASS_ENV: &str = "TRAJECTORY_EVIDENCE_DISABLED";
const BYPASS_VALUE: &str = "1";
const WRITE_TOOLS: &[&str] = &["Write", "Edit", "MultiEdit"];
/// `-lt 50` in the shell.
const MIN_WORDS_TEXT: &str = "50";

static SKIPPED_PATH: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(
        "(node_modules|\\.git/|\\.next|__pycache__|/\\.claude/|/chromium-build/|/dist/)",
    )
});

/// The paths this gate is about: Weles trajectories, the keeper, the worker,
/// and the platform routines they drive.
static GUARDED_PATH: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(weles/scripts/trajectories/|weles/scripts/_shared/keeper/|weles/scripts/worker/",
        "|src/lib/platform/_shared/.*routine|/api/cron/[^/]+-routine/)",
    ))
});

static PASSING: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(?i)\\b(passing|pass|completed|succeed|succeeded|li_at[ =]?yes|keeper_completed",
        "|status=completed|chrome[ _]reference|chrome[ _]capture|human[ -]?driven",
        "|human reference)\\b|\\.work/inst/chrome_",
    ))
});

static FAILING: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(?i)\\b(failing|failed|fail|detection|challengeurl|challenge_url|status=failed",
        "|rejected|silent[ _]kill)\\b",
    ))
});

static ARTIFACT: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(\\.work/inst/[^ ]+\\.json|\\.work/runs/[^ ]+\\.log|recordings/[^ ]+\\.webm",
        "|account_action_logs[^a-z][^ ]*[0-9a-f]{8}",
        "|\\b(commit|row|sha)[: ]*[0-9a-f]{7,40}\\b",
        "|\\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4})",
    ))
});

fn min_words() -> usize {
    MIN_WORDS_TEXT.parse().unwrap_or_default()
}

fn recorded(registry: &str, path: &str) -> String {
    let Ok(text) = std::fs::read_to_string(registry) else {
        return String::new();
    };
    let Ok(doc) = serde_json::from_str::<Value>(&text) else {
        return String::new();
    };
    doc.get(path)
        .and_then(|entry| entry.get(FIELD))
        .and_then(Value::as_str)
        .unwrap_or_default()
        .to_string()
}

/// The refusal this edit earns, if any. `registry` is injectable so a test
/// runs against a fixture instead of the machine's own registry.
pub fn check_with(payload: &Value, registry: &str) -> Option<String> {
    let tool = payload
        .get(TOOL_KEY)
        .and_then(Value::as_str)
        .unwrap_or_default();
    let path = payload
        .get(INPUT_KEY)
        .and_then(|input| input.get(FILE_PATH_KEY))
        .and_then(Value::as_str)
        .unwrap_or_default();
    if path.is_empty() || !WRITE_TOOLS.contains(&tool) {
        return None;
    }
    if std::env::var(BYPASS_ENV).ok().as_deref() == Some(BYPASS_VALUE) {
        return None;
    }
    if SKIPPED_PATH.is_match(path) || !GUARDED_PATH.is_match(path) {
        return None;
    }
    let reason = recorded(registry, path);
    let words = reason.split_whitespace().count();
    if reason.is_empty() || words < min_words() {
        return Some(message::missing_justification(path, words));
    }
    if !PASSING.is_match(&reason) {
        return Some(message::MISSING_PASSING.to_string());
    }
    if !FAILING.is_match(&reason) {
        return Some(message::MISSING_FAILING.to_string());
    }
    if !ARTIFACT.is_match(&reason) {
        return Some(message::MISSING_ARTIFACT.to_string());
    }
    None
}

pub fn check(payload: &Value) -> Option<String> {
    check_with(payload, &expanduser(REGISTRY_PATH))
}

pub fn run() {
    if let Some(refusal) = check(&read_payload()) {
        deny_tool_use(&refusal);
    }
}

#[cfg(test)]
mod tests {
    use super::check_with;
    use serde_json::json;

    const GUARDED: &str = "/repo/weles/scripts/trajectories/linkedin.mjs";

    const COMPLETE: &str = "The passing reference is .work/inst/chrome_macos_2026-05-20.json, a \
human-driven capture of the same flow, and it closes with status=completed after the keeper hands \
the session over. The failing run is .work/inst/linkedin_2026-05-24.json, which ends in DETECTION \
with a challengeUrl instead of the feed, and the delta between the two is the accept-language \
header order, recorded in commit 4f2ab19 and in .work/runs/linkedin_2026-05-24.log for anyone who \
wants to read the bytes.";

    fn edit(path: &str) -> serde_json::Value {
        json!({ "tool_name": "Edit", "tool_input": { "file_path": path } })
    }

    fn registry(name: &str, body: serde_json::Value) -> std::path::PathBuf {
        let dir = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../target/tmp")
            .join(format!("tama-trajectory-{name}"));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).expect("a folder for the fixture");
        let path = dir.join("file_justifications.json");
        std::fs::write(&path, body.to_string()).expect("a fixture registry");
        path
    }

    fn with(name: &str, reason: &str) -> Option<String> {
        let path = registry(
            name,
            json!({ GUARDED: { "trajectory_evidence_justification": reason } }),
        );
        let answer = check_with(&edit(GUARDED), &path.to_string_lossy());
        let _ = std::fs::remove_dir_all(path.parent().expect("a folder"));
        answer
    }

    #[test]
    fn an_unguarded_path_is_not_this_gates_business() {
        assert_eq!(
            check_with(&edit("/repo/src/main.rs"), "/nonexistent/registry.json"),
            None
        );
    }

    #[test]
    fn a_guarded_path_with_no_entry_is_refused_and_the_field_is_named() {
        let refusal =
            check_with(&edit(GUARDED), "/nonexistent/registry.json").expect("no evidence, no edit");
        assert!(
            refusal.contains("trajectory_evidence_justification"),
            "{refusal}"
        );
        assert!(refusal.contains(GUARDED), "{refusal}");
    }

    /// Fifty words of evidence that names both runs and an artifact is the
    /// whole contract, and it passes.
    #[test]
    fn a_complete_citation_lets_the_edit_land() {
        assert_eq!(with("complete", COMPLETE), None);
    }

    #[test]
    fn a_citation_missing_the_passing_run_is_refused() {
        let reason = COMPLETE
            .replace("status=completed", "status=unknown")
            .replace(
                ".work/inst/chrome_macos_2026-05-20.json",
                ".work/inst/other.json",
            )
            .replace("passing reference", "reference")
            .replace("human-driven", "scripted");
        let refusal = with("no-passing", &reason).expect("no passing source");
        assert!(
            refusal.contains("missing PASSING/REFERENCE source"),
            "{refusal}"
        );
    }

    #[test]
    fn a_citation_missing_the_failing_run_is_refused() {
        let reason = COMPLETE
            .replace("The failing run", "The second run")
            .replace("DETECTION", "a redirect")
            .replace("challengeUrl", "another url");
        let refusal = with("no-failing", &reason).expect("no failing source");
        assert!(refusal.contains("missing NON-PASSING source"), "{refusal}");
    }

    /// A story with no artifact path is a hypothesis, which is what the
    /// incident was made of.
    #[test]
    fn a_citation_with_no_artifact_is_refused() {
        let reason = COMPLETE
            .replace(
                ".work/inst/chrome_macos_2026-05-20.json",
                "a chrome capture",
            )
            .replace(".work/inst/linkedin_2026-05-24.json", "the trajectory run")
            .replace("commit 4f2ab19", "a commit")
            .replace(".work/runs/linkedin_2026-05-24.log", "the log");
        let refusal = with("no-artifact", &reason).expect("no artifact");
        assert!(
            refusal.contains("missing concrete artifact path"),
            "{refusal}"
        );
    }
}
