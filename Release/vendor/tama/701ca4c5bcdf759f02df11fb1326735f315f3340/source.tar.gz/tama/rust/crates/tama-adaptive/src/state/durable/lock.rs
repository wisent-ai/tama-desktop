//! Port of `src/adaptive/state/lock.mjs`: crash-recoverable directory-rename
//! locks with owner identity (`/bin/ps` start time) and abandoned-lock
//! recovery. Error handling mirrors the JS `try {} catch {}` blocks.

use std::fs::{self, OpenOptions};
use std::io::Write;
use std::path::PathBuf;
use std::process::Command;
use std::thread::sleep;
use std::time::Duration;

use super::journal::sync_directory;
use super::super::Warn;
use crate::util::uuid_v4;

const WAIT_MS: u64 = 10;

pub struct LockOwnership {
    pub lock_path: PathBuf,
    pub token: String,
}

pub struct LockStore {
    lock_dir: PathBuf,
    tmp_dir: PathBuf,
    warn: Warn,
}

/// `processIdentity(pid)` — `/bin/ps -o lstart= -p <pid>` trimmed, or null.
fn process_identity(pid: u32) -> Option<String> {
    let output = Command::new("/bin/ps")
        .args(["-o", "lstart=", "-p", &pid.to_string()])
        .output()
        .ok()?;
    if !output.status.success() {
        return None;
    }
    let text = String::from_utf8_lossy(&output.stdout).trim().to_string();
    if text.is_empty() {
        None
    } else {
        Some(text)
    }
}

fn hostname() -> String {
    // `os.hostname()` equivalent without extra dependencies.
    if let Ok(name) = std::env::var("HOSTNAME") {
        if !name.is_empty() {
            return name;
        }
    }
    if let Ok(output) = Command::new("/bin/hostname").output() {
        let name = String::from_utf8_lossy(&output.stdout).trim().to_string();
        if !name.is_empty() {
            return name;
        }
    }
    String::new()
}

/// `process.kill(pid, 0)` probe: `Ok(true)` signalable, `Ok(false)` ESRCH,
/// `Err(())` EPERM (exists but owned by someone else).
fn pid_probe(pid: u32) -> Result<bool, ()> {
    let alive = libc_kill(pid as i32, 0);
    if alive == 0 {
        return Ok(true);
    }
    match std::io::Error::last_os_error().raw_os_error() {
        Some(1) => Err(()),   // EPERM
        Some(3) => Ok(false), // ESRCH
        _ => Ok(false),
    }
}

extern "C" {
    fn kill(pid: i32, sig: i32) -> i32;
}

fn libc_kill(pid: i32, sig: i32) -> i32 {
    unsafe { kill(pid, sig) }
}

impl LockStore {
    pub fn open(state_dir: &std::path::Path, warn: Warn) -> Self {
        LockStore {
            lock_dir: state_dir.join("projection-locks"),
            tmp_dir: state_dir.join("tmp"),
            warn,
        }
    }

    fn alive(&self, owner: Option<&serde_json::Value>) -> bool {
        let Some(owner) = owner else { return false };
        let pid = match owner.get("pid").and_then(|v| v.as_i64()) {
            Some(pid) if pid > 0 && pid <= i64::from(u32::MAX) => pid as u32,
            // JS requires Number.isInteger; non-integer/non-number is dead.
            _ => return false,
        };
        let host = owner.get("host").and_then(|v| v.as_str()).unwrap_or("");
        if !host.is_empty() && host != hostname() {
            return true;
        }
        let identity = process_identity(pid);
        let started = owner.get("started").and_then(|v| v.as_str());
        if started.is_some() && identity.is_some() {
            return started == identity.as_deref();
        }
        match pid_probe(pid) {
            Ok(true) => {
                (self.warn)(
                    "adaptive lock process identity unavailable; retaining live pid ownership",
                );
                true
            }
            Ok(false) => false,
            Err(()) => true, // EPERM
        }
    }

    /// `acquire(name)`: spins until the lock is held, mirroring the JS loop.
    /// Returns `None` only when candidate creation or rename fails in a way
    /// the JS code would rethrow (the JS caller turns that into a caught
    /// error, which `update` reports as `persistence-failed`; here `acquire`
    /// itself surfaces it as `Err`).
    pub fn acquire(&self, name: &str) -> std::io::Result<LockOwnership> {
        let _ = fs::create_dir_all(&self.lock_dir);
        let _ = fs::create_dir_all(&self.tmp_dir);
        let lock_path = self.lock_dir.join(name);
        loop {
            if lock_path.exists() {
                let incumbent = fs::read_to_string(lock_path.join("owner.json"))
                    .ok()
                    .and_then(|text| serde_json::from_str::<serde_json::Value>(&text).ok());
                if self.alive(incumbent.as_ref()) {
                    sleep(Duration::from_millis(WAIT_MS));
                    continue;
                }
                let abandoned = self.tmp_dir.join(format!("abandoned-lock-{}", uuid_v4()));
                if fs::rename(&lock_path, &abandoned).is_ok() {
                    sync_directory(&self.lock_dir);
                }
                continue;
            }

            let token = uuid_v4();
            let candidate = self.tmp_dir.join(format!("lock-{}", token));
            fs::create_dir(&candidate)?;
            let owner = serde_json::json!({
                "host": hostname(),
                "pid": std::process::id(),
                "started": process_identity(std::process::id()),
                "token": token,
            });
            // `openSync(join(candidate, 'owner.json'), 'wx')` + write + fsync.
            let owner_path = candidate.join("owner.json");
            let mut descriptor = OpenOptions::new()
                .write(true)
                .create_new(true)
                .open(&owner_path)?;
            descriptor.write_all(serde_json::to_string(&owner).unwrap_or_default().as_bytes())?;
            descriptor.write_all(b"\n")?;
            descriptor.sync_all()?;
            drop(descriptor);
            sync_directory(&candidate);
            match fs::rename(&candidate, &lock_path) {
                Ok(()) => {
                    sync_directory(&self.lock_dir);
                    return Ok(LockOwnership { lock_path, token });
                }
                Err(error) => {
                    let _ = fs::remove_dir_all(&candidate);
                    if lock_path.exists()
                        || matches!(
                            error.raw_os_error(),
                            // EEXIST / ENOTEMPTY like the JS retry condition.
                            Some(17) | Some(66)
                        )
                    {
                        continue;
                    }
                    return Err(error);
                }
            }
        }
    }

    /// `release(ownership)` — only removes the lock when the token matches.
    pub fn release(&self, ownership: Option<LockOwnership>) {
        let Some(ownership) = ownership else { return };
        let owner = fs::read_to_string(ownership.lock_path.join("owner.json"))
            .ok()
            .and_then(|text| serde_json::from_str::<serde_json::Value>(&text).ok());
        let token_matches = owner
            .and_then(|o| o.get("token").and_then(|t| t.as_str()).map(str::to_string))
            .map(|token| token == ownership.token)
            .unwrap_or(false);
        if !token_matches {
            return;
        }
        if fs::remove_dir_all(&ownership.lock_path).is_ok() {
            sync_directory(&self.lock_dir);
        }
    }
}
