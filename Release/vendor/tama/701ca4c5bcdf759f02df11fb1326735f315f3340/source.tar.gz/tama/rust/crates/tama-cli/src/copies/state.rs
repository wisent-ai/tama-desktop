//! Git's answers about one candidate checkout. This file reads; the
//! classification in [`super::discovery`] decides.

use std::collections::HashSet;
use std::fs;
use std::path::Path;

use crate::gitcmd::git;

/// A linked worktree has a private Git directory and a distinct common Git
/// directory. A submodule also has a `.git` file, but owns its metadata and
/// remains a dependency checkout rather than a linked worktree.
pub(super) fn is_linked_worktree(dir: &Path) -> bool {
    if !dir.join(".git").is_file() {
        return false;
    }
    let Ok(paths) = git(
        dir,
        &[
            "rev-parse",
            "--path-format=absolute",
            "--git-dir",
            "--git-common-dir",
        ],
    ) else {
        return false;
    };
    let mut paths = paths.lines();
    matches!((paths.next(), paths.next()), (Some(private), Some(common)) if private != common)
}

/// Linked worktrees registered by a full checkout, including ones outside
/// the root being walked. Directly discovered entries are deduplicated later.
pub(super) fn linked_worktrees(dir: &Path) -> Vec<String> {
    let metadata = if dir.join(".git").is_dir() {
        dir.join(".git")
    } else if let Ok(path) = git(dir, &["rev-parse", "--absolute-git-dir"]) {
        std::path::PathBuf::from(path.trim())
    } else {
        return Vec::new();
    };
    let Ok(entries) = fs::read_dir(metadata.join("worktrees")) else {
        return Vec::new();
    };
    let mut paths = Vec::new();
    for entry in entries.flatten() {
        let Ok(text) = fs::read_to_string(entry.path().join("gitdir")) else {
            continue;
        };
        let recorded = text.trim();
        let path = recorded.strip_suffix("/.git").unwrap_or(recorded);
        if !path.is_empty() {
            paths.push(path.to_string());
        }
    }
    paths
}

pub(super) fn owns_worktrees(dir: &Path) -> bool {
    !linked_worktrees(dir).is_empty()
}

pub(super) fn dirty(dir: &Path) -> Result<bool, String> {
    if git(dir, &["rev-parse", "--is-bare-repository"])?.trim() == "true" {
        return Ok(false);
    }
    Ok(!git(dir, &["status", "--porcelain"])?.trim().is_empty())
}

/// Where this checkout came from. Two directories are the same repository
/// when they were cloned from the same place, so the origin URL is the
/// comparison, and a checkout with no `origin` cannot be compared at all.
pub(super) fn origin(dir: &Path) -> Option<String> {
    let url = git(dir, &["remote", "get-url", "origin"]).ok()?;
    let trimmed = url.trim();
    if trimmed.is_empty() {
        return None;
    }
    Some(trimmed.to_string())
}

/// `git@github.com:wisent-ai/lem.git`, `https://github.com/wisent-ai/lem.git`
/// and `https://github.com/wisent-ai/lem` name one repository to a reader and
/// three different strings to `==`. What is kept is the host and the path;
/// what is dropped is only spelling: the scheme, any user prefix, a `.git`
/// suffix and a trailing slash.
pub(super) fn normalize_origin(url: &str) -> String {
    let without_scheme = url.split_once("://").map_or(url, |(_, rest)| rest);
    let after_user = without_scheme
        .rsplit_once('@')
        .map_or(without_scheme, |(_, rest)| rest);
    let unified = after_user.replacen(':', "/", 1);
    let trimmed = unified.trim_end_matches('/');
    trimmed
        .strip_suffix(".git")
        .unwrap_or(trimmed)
        .to_lowercase()
}

/// An origin that names a directory on this filesystem rather than a server:
/// what `git clone /path/to/repo` and `git clone file:///path` write. The
/// answer is the path itself, so the caller can ask whether that path is one
/// of the canonical checkouts it already found.
pub(super) fn local_origin_path(url: &str) -> Option<String> {
    let path = match url.split_once("://") {
        Some(("file", rest)) => rest,
        Some(_) => return None,
        None => url,
    };
    // An scp-style `user@host:path` has a colon before any slash; a Windows
    // drive letter cannot occur on this machine.
    if let Some(colon) = path.find(':') {
        if path[..colon].find('/').is_none() {
            return None;
        }
    }
    let trimmed = path.trim_end_matches('/');
    let without_git = trimmed.strip_suffix("/.git").unwrap_or(trimmed);
    Some(without_git.to_string())
}

/// Account for every stored object, including dangling commits and annotated
/// tags. A canonical witness must retain the objects through its own refs and
/// storage, not through an alternate object directory that removal could lose.
pub(super) fn history<'a>(
    dir: &Path,
    owner: Option<&str>,
    canonicals: impl Iterator<Item = &'a str>,
) -> Result<(bool, Option<String>), String> {
    if git(dir, &["rev-parse", "--verify", "--quiet", "HEAD"]).is_err() {
        git(dir, &["symbolic-ref", "--quiet", "HEAD"])?;
    }
    let objects = git(
        dir,
        &[
            "--no-replace-objects",
            "cat-file",
            "--batch-all-objects",
            "--batch-check=%(objecttype) %(objectname)",
        ],
    )?;
    let remote = git(
        dir,
        &[
            "--no-replace-objects",
            "rev-list",
            "--objects",
            "--remotes",
            "--no-object-names",
            "--missing=print",
        ],
    )?;
    if remote.lines().any(|line| line.starts_with('?')) {
        return Err(format!(
            "{}: remote-tracking history has missing Git objects; no retention proof is available",
            dir.display()
        ));
    }
    let published: HashSet<_> = remote.lines().collect();
    let ids: Vec<_> = objects
        .lines()
        .filter_map(|line| line.split_once(' ').map(|(_, id)| id))
        .collect();
    let unpublished = ids.iter().any(|id| !published.contains(id));
    if !unpublished || ids.is_empty() {
        return Ok((unpublished, None));
    }
    for candidate in canonicals {
        if owner.is_some_and(|owner| owner != candidate) {
            continue;
        }
        let candidate = Path::new(candidate);
        let reachable = git(
            candidate,
            &[
                "--no-replace-objects",
                "rev-list",
                "--objects",
                "--all",
                "--no-object-names",
                "--missing=print",
            ],
        )?;
        if reachable.lines().any(|line| line.starts_with('?')) {
            continue;
        }
        let retained: HashSet<_> = reachable.lines().collect();
        if !ids.iter().all(|id| retained.contains(id)) {
            continue;
        }
        if !independent_objects(candidate)? {
            continue;
        }
        return Ok((unpublished, Some(candidate.to_string_lossy().into_owned())));
    }
    Ok((unpublished, None))
}

fn independent_objects(repository: &Path) -> Result<bool, String> {
    crate::gitcmd::verify_repository(repository)?;
    let git_directory = git(repository, &["rev-parse", "--absolute-git-dir"])?;
    let git_directory = Path::new(git_directory.trim());
    let physical = fs::canonicalize(git_directory)
        .map_err(|error| format!("{}: {error}", git_directory.display()))?;
    if physical != git_directory || !physical.starts_with(crate::gitcmd::canonical(repository)) {
        return Ok(false);
    }
    let counts = git(repository, &["count-objects", "-v"])?;
    if counts.lines().any(|line| line.starts_with("alternate:")) {
        return Ok(false);
    }
    object_storage_has_no_links(&git_directory.join("objects"))
}

fn object_storage_has_no_links(path: &Path) -> Result<bool, String> {
    let metadata =
        fs::symlink_metadata(path).map_err(|error| format!("{}: {error}", path.display()))?;
    if metadata.file_type().is_symlink() {
        return Ok(false);
    }
    if metadata.is_dir() {
        for entry in fs::read_dir(path).map_err(|error| format!("{}: {error}", path.display()))? {
            let entry = entry.map_err(|error| format!("{}: {error}", path.display()))?;
            if !object_storage_has_no_links(&entry.path())? {
                return Ok(false);
            }
        }
    }
    Ok(true)
}

/// Apparent size of the candidate, so the operator sees what a pass returns.
/// Symlinks are counted as links and never followed: a copy that links to
/// something outside itself must not have that thing's size attributed to it,
/// and must never have it walked.
pub(super) fn bytes(dir: &Path) -> u64 {
    let Ok(entries) = fs::read_dir(dir) else {
        return 0;
    };
    let mut total = 0u64;
    for entry in entries.flatten() {
        let Ok(kind) = entry.file_type() else {
            continue;
        };
        if kind.is_symlink() {
            continue;
        }
        if kind.is_dir() {
            total += bytes(&entry.path());
        } else if let Ok(metadata) = entry.metadata() {
            total += metadata.len();
        }
    }
    total
}
