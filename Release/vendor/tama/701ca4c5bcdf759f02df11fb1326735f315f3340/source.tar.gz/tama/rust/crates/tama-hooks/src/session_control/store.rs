//! Persistence: JSON file loading and the atomic temp-file-plus-rename write,
//! plus the global emergency-disable switch readers.

use std::fs;
use std::io;
use std::path::{Path, PathBuf};

use serde_json::Value;

use super::paths::{emergency_state_path, session_control_root};
use super::EMERGENCY_STATE_SCHEMA;
use crate::jsutil;

/// `loadJson`: parse the file, yielding null on any error.
pub(super) fn load_json(path: &Path) -> Value {
    fs::read_to_string(path)
        .ok()
        .and_then(|s| serde_json::from_str(&s).ok())
        .unwrap_or(Value::Null)
}

/// `atomicWriteJson`: ensure the session-control root (0700), write
/// `JSON.stringify(value) + "\n"` to a unique temp file (0600, `wx`), rename
/// into place, always remove the temp file. Errors propagate like the JS
/// `*Sync` calls do.
pub(super) fn atomic_write_json(path: &Path, value: &Value) -> io::Result<()> {
    let root = session_control_root();
    fs::create_dir_all(&root)?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        fs::set_permissions(&root, fs::Permissions::from_mode(0o700))?;
    }
    let mut tmp = path.as_os_str().to_owned();
    tmp.push(format!(
        ".{}.{}.tmp",
        std::process::id(),
        jsutil::random_token()
    ));
    let tmp = PathBuf::from(tmp);
    let payload = format!(
        "{}\n",
        serde_json::to_string(value).map_err(io::Error::other)?
    );
    let result = (|| -> io::Result<()> {
        let mut opts = fs::OpenOptions::new();
        opts.write(true).create_new(true);
        #[cfg(unix)]
        {
            use std::os::unix::fs::OpenOptionsExt;
            opts.mode(0o600);
        }
        let mut f = opts.open(&tmp)?;
        use std::io::Write;
        f.write_all(payload.as_bytes())?;
        drop(f);
        fs::rename(&tmp, path)?;
        Ok(())
    })();
    let _ = fs::remove_file(&tmp); // rmSync(temporary, { force: true })
    result
}

/// Read the emergency switch from an explicit state path.
pub fn hooks_globally_disabled_at(path: &Path) -> bool {
    let state = load_json(path);
    state.get("schema").and_then(Value::as_str) == Some(EMERGENCY_STATE_SCHEMA)
        && state.get("disabled") == Some(&Value::Bool(true))
}

/// Port of `hooksGloballyDisabled`.
pub fn hooks_globally_disabled() -> bool {
    hooks_globally_disabled_at(&emergency_state_path())
}
