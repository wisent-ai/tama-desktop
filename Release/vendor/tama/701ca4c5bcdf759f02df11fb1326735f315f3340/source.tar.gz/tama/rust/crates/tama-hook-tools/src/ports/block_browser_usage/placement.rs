//! Whether this host is allowed to run a Weles browser runtime.
//!
//! Weles may drive its patched browser, but only on a host the canonical Stado
//! registry selects for it. An API client on another machine is still allowed:
//! it launches no local browser. So the question is exactly "does a target in
//! the registry carry a Weles placement policy and name this host".

use serde_json::Value;

use crate::ports::python_stdlib::expanduser;

const REGISTRY_ENV: &str = "STADO_BROWSER_POLICY_REGISTRY";
const REGISTRY_DEFAULT: &str = "~/.stado/local-storage/registry.json";
const TARGETS_KEY: &str = "targets";
const WELES_KEY: &str = "weles";
const ENABLED_KEY: &str = "enabled";
const ACTIONS_KEY: &str = "actions";
const NAME_KEY: &str = "name";
const HOSTNAMES_KEY: &str = "hostnames";
const LOCAL_SUFFIX: &str = ".local";
const HOSTNAME_PROGRAM: &str = "hostname";
const HOSTNAME_ENV: &[&str] = &["HOSTNAME", "HOST"];

pub(crate) fn registry_path() -> String {
    match std::env::var(REGISTRY_ENV) {
        Ok(value) if !value.is_empty() => value,
        _ => expanduser(REGISTRY_DEFAULT),
    }
}

/// This machine's name, lowercased, the way the shell read it.
pub(crate) fn current_host() -> String {
    if let Ok(output) = std::process::Command::new(HOSTNAME_PROGRAM).output() {
        let text = String::from_utf8_lossy(&output.stdout)
            .trim()
            .to_lowercase();
        if !text.is_empty() {
            return text;
        }
    }
    HOSTNAME_ENV
        .iter()
        .filter_map(|key| std::env::var(key).ok())
        .find(|value| !value.is_empty())
        .unwrap_or_default()
        .to_lowercase()
}

fn short(host: &str) -> &str {
    host.strip_suffix(LOCAL_SUFFIX).unwrap_or(host)
}

fn carries_a_weles_policy(target: &Value) -> bool {
    let Some(weles) = target.get(WELES_KEY) else {
        return false;
    };
    if weles.get(ENABLED_KEY) == Some(&Value::Bool(true)) {
        return true;
    }
    match weles.get(ACTIONS_KEY) {
        Some(Value::Array(actions)) => !actions.is_empty(),
        _ => false,
    }
}

fn names_this_host(target: &Value, host: &str) -> bool {
    let mut names: Vec<String> = Vec::new();
    if let Some(Value::String(name)) = target.get(NAME_KEY) {
        names.push(name.clone());
    }
    if let Some(Value::Array(hostnames)) = target.get(HOSTNAMES_KEY) {
        for entry in hostnames {
            if let Value::String(name) = entry {
                names.push(name.clone());
            }
        }
    }
    names
        .iter()
        .map(|name| name.to_lowercase())
        .any(|name| name == host || short(&name) == short(host))
}

/// Whether the registry at `path` places a Weles browser runtime on `host`.
pub(crate) fn allows_weles_runtime(path: &str, host: &str) -> bool {
    let Ok(text) = std::fs::read_to_string(path) else {
        return false;
    };
    let Ok(doc) = serde_json::from_str::<Value>(&text) else {
        return false;
    };
    let Some(Value::Array(targets)) = doc.get(TARGETS_KEY) else {
        return false;
    };
    targets
        .iter()
        .any(|target| carries_a_weles_policy(target) && names_this_host(target, host))
}

#[cfg(test)]
mod tests {
    use super::{allows_weles_runtime, short};
    use serde_json::json;

    fn registry(name: &str, body: serde_json::Value) -> std::path::PathBuf {
        let dir = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../target/tmp")
            .join(format!("tama-placement-{name}"));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).expect("a folder for the fixture");
        let path = dir.join("registry.json");
        std::fs::write(&path, body.to_string()).expect("a fixture registry");
        path
    }

    #[test]
    fn a_target_with_the_policy_and_this_name_allows_the_runtime() {
        let path = registry(
            "enabled",
            json!({ "targets": [{ "name": "Bramastable", "weles": { "enabled": true } }] }),
        );
        assert!(allows_weles_runtime(&path.to_string_lossy(), "bramastable"));
        let _ = std::fs::remove_dir_all(path.parent().expect("a folder"));
    }

    /// A list of actions is a placement policy too; an empty list is not.
    #[test]
    fn actions_count_and_an_empty_list_does_not() {
        let allowed = registry(
            "actions",
            json!({ "targets": [{ "name": "host", "weles": { "actions": ["browse"] } }] }),
        );
        assert!(allows_weles_runtime(&allowed.to_string_lossy(), "host"));
        let _ = std::fs::remove_dir_all(allowed.parent().expect("a folder"));

        let empty = registry(
            "empty",
            json!({ "targets": [{ "name": "host", "weles": { "actions": [] } }] }),
        );
        assert!(!allows_weles_runtime(&empty.to_string_lossy(), "host"));
        let _ = std::fs::remove_dir_all(empty.parent().expect("a folder"));
    }

    /// A machine answers to both its long and its short name.
    #[test]
    fn the_local_suffix_does_not_decide() {
        let path = registry(
            "suffix",
            json!({ "targets": [{ "hostnames": ["Weles-Host.local"], "weles": { "enabled": true } }] }),
        );
        assert!(allows_weles_runtime(&path.to_string_lossy(), "weles-host"));
        assert!(allows_weles_runtime(
            &path.to_string_lossy(),
            "weles-host.local"
        ));
        assert_eq!(short("weles-host.local"), "weles-host");
        let _ = std::fs::remove_dir_all(path.parent().expect("a folder"));
    }

    #[test]
    fn another_machine_is_not_placed_and_a_missing_registry_places_nobody() {
        let path = registry(
            "other",
            json!({ "targets": [{ "name": "elsewhere", "weles": { "enabled": true } }] }),
        );
        assert!(!allows_weles_runtime(&path.to_string_lossy(), "here"));
        let _ = std::fs::remove_dir_all(path.parent().expect("a folder"));
        assert!(!allows_weles_runtime("/nonexistent/registry.json", "here"));
    }
}
