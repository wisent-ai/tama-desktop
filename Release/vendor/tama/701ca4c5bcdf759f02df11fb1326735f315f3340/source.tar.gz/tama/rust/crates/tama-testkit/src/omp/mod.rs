//! Port of `src/tests/live-runtime/runtimes/omp-runtime.mjs`.

use std::path::Path;

use crate::json::Json;
use crate::orchestration::Ctx;
use crate::scenarios::{AssertAfterCtx, OmpScenario};
use crate::support::{self, RunOpts};

fn init_repo(repo: &Path) -> Result<(), String> {
    std::fs::create_dir_all(repo).map_err(|e| support::io_error_message("mkdir", repo, &e))?;
    let init = support::run_in("git", &["init", "--quiet"], repo);
    if init.status != Some(0) {
        return Err(format!(
            "failed to initialize temp git repo: {}",
            init.stderr
        ));
    }
    Ok(())
}

fn run_omp(
    command: &[String],
    repo: &Path,
    env: Vec<(String, String)>,
) -> support::RunResult {
    support::run(
        &command[0],
        &command[1..],
        &RunOpts {
            cwd: Some(repo.to_path_buf()),
            env_overrides: env,
            max_buffer: Some(10_485_760),
            ..RunOpts::default()
        },
    )
}

fn opt_num(value: Option<i32>) -> Json {
    match value {
        Some(code) => Json::num_i64(code as i64),
        None => Json::Null,
    }
}

fn entry_argv0(entry: &Json) -> Option<&str> {
    entry
        .get("argv")
        .and_then(|argv| argv.at(0))
        .and_then(Json::as_str)
}

/// JS `runOmpHookConfigScenario(scenario)`.
pub fn run_omp_hook_config_scenario(scenario: &OmpScenario, ctx: &Ctx) -> Result<Json, String> {
    let tmp = support::mkdtemp(&support::tmpdir().join("tama-live-omp-"))?;
    let outcome = run_omp_hook_config_inner(&tmp, scenario, ctx);
    if !ctx.keep_artifacts {
        support::rm_force(&tmp);
    }
    outcome
}

fn run_omp_hook_config_inner(
    tmp: &Path,
    scenario: &OmpScenario,
    ctx: &Ctx,
) -> Result<Json, String> {
    let repo = tmp.join("repo");
    init_repo(&repo)?;

    // `const setup = scenario.setup?.(repo) || {}`
    let setup = match scenario.setup {
        Some(setup_fn) => setup_fn(&repo)?,
        None => Json::obj(vec![]),
    };
    let target_path = setup
        .get("targetPath")
        .and_then(Json::as_str)
        .map(str::to_string);
    let before = match &target_path {
        Some(path) if Path::new(path).exists() => Some(support::read(Path::new(path))?),
        _ => None,
    };
    let (payload_log, recorder) = support::make_recorder(tmp)?;

    let env = vec![
        (
            "OMP_SHARED_HOOK_RUNNER".to_string(),
            recorder.to_string_lossy().into_owned(),
        ),
        ("OMP_ENSURE_EDITOR_WATCHER".to_string(), "0".to_string()),
    ];
    let omp_command = vec![
        "omp".to_string(),
        "-p".to_string(),
        "--cwd".to_string(),
        repo.to_string_lossy().into_owned(),
        "--tools".to_string(),
        scenario.tools.to_string(),
        "--auto-approve".to_string(),
        "--no-session".to_string(),
        "--max-time".to_string(),
        scenario.omp_execution_window.unwrap_or("45").to_string(),
        scenario.prompt.unwrap_or("undefined").to_string(),
    ];
    let omp = run_omp(
        &omp_command,
        &repo,
        env,
    );

    let after = match &target_path {
        Some(path) if Path::new(path).exists() => Some(support::read(Path::new(path))?),
        _ => None,
    };
    let payloads = support::read_payloads(&payload_log);
    let captured_payload = scenario
        .payload_match
        .and_then(|matcher| payloads.iter().find(|entry| matcher(entry)));
    let hook_ran = captured_payload
        .and_then(|p| p.get("runner"))
        .and_then(|r| r.get("json"))
        .and_then(|j| j.get("results"))
        .and_then(Json::as_array)
        .map(|results| {
            results
                .iter()
                .any(|result| result.get("id").and_then(Json::as_str) == scenario.hook_id)
        })
        .unwrap_or(false);

    let combined_output = format!("{}\n{}", omp.stdout, omp.stderr);
    let blocked = combined_output
        .contains("BLOCKED: hook source/config changes are device-level protected")
        || captured_payload
            .and_then(|p| p.get("runner"))
            .and_then(|r| r.get("json"))
            .and_then(|j| j.get("decision"))
            .and_then(Json::as_str)
            == Some("block");

    if let Some(signal) = &omp.signal {
        return Err(format!(
            "real OMP runtime timed out or was terminated: {signal}"
        ));
    }
    if !hook_ran {
        let shown: Vec<Json> = payloads.iter().take(5).cloned().collect();
        return Err(format!(
            "real runner did not execute expected hook id {}; payloads={}; stdoutTail={}; stderrTail={}",
            scenario.hook_id.unwrap_or("undefined"),
            Json::arr(shown).to_compact(),
            support::tail(&omp.stdout),
            support::tail(&omp.stderr)
        ));
    }
    if !blocked {
        let runner = match captured_payload {
            Some(payload) => crate::json::js_or2(
                payload.get("runner").and_then(|r| r.get("json")),
                payload.get("runner"),
            ),
            None => None,
        };
        let runner_text = match runner {
            Some(value) => value.to_compact(),
            None => "undefined".to_string(),
        };
        return Err(format!(
            "real OMP runtime did not report the expected hook block; runner={}; stdoutTail={}; stderrTail={}",
            runner_text,
            support::tail(&omp.stdout),
            support::tail(&omp.stderr)
        ));
    }
    if before != after {
        return Err(
            "forbidden hook source/config side effect occurred; target changed".to_string(),
        );
    }

    let mut entries = vec![
        ("ok".to_string(), Json::Bool(true)),
        ("runtime".to_string(), Json::str("omp")),
        (
            "hook".to_string(),
            Json::str("block-hook-config-edits-without-consent"),
        ),
        ("coverageKey".to_string(), Json::str(scenario.coverage_key)),
        (
            "coveredKeys".to_string(),
            Json::arr(
                support::covered_keys_from_omp_payloads(&payloads)
                    .into_iter()
                    .map(Json::Str)
                    .collect(),
            ),
        ),
        ("tool".to_string(), Json::str(scenario.tool_name)),
        (
            "command".to_string(),
            Json::arr(omp_command.iter().cloned().map(Json::Str).collect()),
        ),
        (
            "artifactsRetained".to_string(),
            Json::Bool(ctx.keep_artifacts),
        ),
        (
            "artifactPaths".to_string(),
            if ctx.keep_artifacts {
                Json::obj(vec![
                    (
                        "recorder".to_string(),
                        Json::str(recorder.to_string_lossy().into_owned()),
                    ),
                    (
                        "payloadLog".to_string(),
                        Json::str(payload_log.to_string_lossy().into_owned()),
                    ),
                    (
                        "tempRepo".to_string(),
                        Json::str(repo.to_string_lossy().into_owned()),
                    ),
                ])
            } else {
                Json::Null
            },
        ),
    ];
    if let Some(forbidden_action) = scenario.forbidden_action {
        entries.push(("forbiddenAction".to_string(), Json::str(forbidden_action)));
    }
    entries.push(("runtimeExitStatus".to_string(), opt_num(omp.status)));
    entries.push(("payloadCaptured".to_string(), Json::Bool(true)));
    if let Some(captured) = captured_payload {
        entries.push(("capturedPayload".to_string(), captured.clone()));
    }
    if let Some(target) = &target_path {
        entries.push(("targetPath".to_string(), Json::str(target.clone())));
    }
    entries.push((
        "targetBefore".to_string(),
        match &before {
            Some(content) => Json::str(content.clone()),
            None => Json::Null,
        },
    ));
    entries.push((
        "targetAfter".to_string(),
        match &after {
            Some(content) => Json::str(content.clone()),
            None => Json::Null,
        },
    ));
    entries.push((
        "targetBeforeEqualsAfter".to_string(),
        Json::Bool(before == after),
    ));
    entries.push(("blocked".to_string(), Json::Bool(true)));
    Ok(Json::obj(entries))
}

/// JS `runOmpNeutralBashScenario(scenario)`.
pub fn run_omp_neutral_bash_scenario(scenario: &OmpScenario, ctx: &Ctx) -> Result<Json, String> {
    let tmp = support::mkdtemp(&support::tmpdir().join("tama-live-omp-pass-"))?;
    let outcome = run_omp_neutral_bash_inner(&tmp, scenario, ctx);
    if !ctx.keep_artifacts {
        support::rm_force(&tmp);
    }
    outcome
}

fn run_omp_neutral_bash_inner(
    tmp: &Path,
    scenario: &OmpScenario,
    ctx: &Ctx,
) -> Result<Json, String> {
    let repo = tmp.join("repo");
    init_repo(&repo)?;
    let (payload_log, recorder) = support::make_recorder(tmp)?;
    let omp_command = vec![
        "omp".to_string(),
        "-p".to_string(),
        "--cwd".to_string(),
        repo.to_string_lossy().into_owned(),
        "--tools".to_string(),
        "bash".to_string(),
        "--auto-approve".to_string(),
        "--no-session".to_string(),
        "--max-time".to_string(),
        "45".to_string(),
        "Use the bash tool to run exactly this command and nothing else: printf live-neutral"
            .to_string(),
    ];
    let omp = run_omp(
        &omp_command,
        &repo,
        vec![
            (
                "OMP_SHARED_HOOK_RUNNER".to_string(),
                recorder.to_string_lossy().into_owned(),
            ),
            ("OMP_ENSURE_EDITOR_WATCHER".to_string(), "0".to_string()),
        ],
    );
    let _ = ctx;
    let payloads = support::read_payloads(&payload_log);
    let pre = payloads
        .iter()
        .find(|entry| entry_argv0(entry) == Some("pre_tool_use:bash"));
    let post = payloads
        .iter()
        .find(|entry| entry_argv0(entry) == Some("post_tool_use:bash"));
    if let Some(signal) = &omp.signal {
        return Err(format!(
            "real OMP neutral runtime timed out or was terminated: {signal}"
        ));
    }
    let decision_is_pass = |entry: Option<&Json>| {
        entry
            .and_then(|p| p.get("runner"))
            .and_then(|r| r.get("json"))
            .and_then(|j| j.get("decision"))
            .and_then(Json::as_str)
            == Some("pass")
    };
    if !decision_is_pass(pre) {
        let shown: Vec<Json> = payloads.iter().take(5).cloned().collect();
        return Err(format!(
            "neutral OMP Bash did not pass pre_tool_use:bash; payloads={}",
            Json::arr(shown).to_compact()
        ));
    }
    if !decision_is_pass(post) {
        let shown: Vec<Json> = payloads.iter().take(5).cloned().collect();
        return Err(format!(
            "neutral OMP Bash did not pass post_tool_use:bash; payloads={}",
            Json::arr(shown).to_compact()
        ));
    }
    Ok(Json::obj(vec![
        ("ok".to_string(), Json::Bool(true)),
        ("runtime".to_string(), Json::str("omp")),
        ("hook".to_string(), Json::str("neutral-bash-pass-path")),
        ("coverageKey".to_string(), Json::str(scenario.coverage_key)),
        (
            "coveredKeys".to_string(),
            Json::arr(
                support::covered_keys_from_omp_payloads(&payloads)
                    .into_iter()
                    .map(Json::Str)
                    .collect(),
            ),
        ),
        ("tool".to_string(), Json::str("Bash")),
        (
            "command".to_string(),
            Json::arr(omp_command.iter().cloned().map(Json::Str).collect()),
        ),
        ("runtimeExitStatus".to_string(), opt_num(omp.status)),
        ("payloadCaptured".to_string(), Json::Bool(true)),
        ("blocked".to_string(), Json::Bool(false)),
    ]))
}

/// JS `runOmpCapturedToolScenario(scenario)`.
pub fn run_omp_captured_tool_scenario(scenario: &OmpScenario, ctx: &Ctx) -> Result<Json, String> {
    let tmp = support::make_live_runtime_temp("omp-tool-")?;
    let system_tmp = if scenario.system_tmp {
        Some(support::mkdtemp(&support::tmpdir().join("tama-omp-tool-"))?)
    } else {
        None
    };
    let outcome = run_omp_captured_inner(&tmp, system_tmp.as_deref(), scenario, ctx);
    if !ctx.keep_artifacts {
        support::rm_force(&tmp);
        if let Some(system_tmp) = &system_tmp {
            support::rm_force(system_tmp);
        }
    }
    outcome
}

fn run_omp_captured_inner(
    tmp: &Path,
    system_tmp: Option<&Path>,
    scenario: &OmpScenario,
    ctx: &Ctx,
) -> Result<Json, String> {
    let id = scenario.id.unwrap_or("undefined");
    let repo = tmp.join("repo");
    init_repo(&repo)?;
    // `const prepared = scenario.prepare?.(repo, systemTmp) || {}`
    let prepared = match scenario.prepare {
        Some(prepare_fn) => prepare_fn(&repo, system_tmp)?,
        None => Json::obj(vec![]),
    };
    let (payload_log, recorder) = support::make_recorder(tmp)?;
    let prompt = match scenario.prompt_fn {
        Some(prompt_fn) => prompt_fn(&prepared),
        None => scenario.prompt.unwrap_or("undefined").to_string(),
    };
    let adapter_env = if scenario.selective_adapter {
        vec![(
            "OMP_TAMA_EVIDENCE_LOG".to_string(),
            payload_log.to_string_lossy().into_owned(),
        )]
    } else {
        vec![(
            "OMP_SHARED_HOOK_RUNNER".to_string(),
            recorder.to_string_lossy().into_owned(),
        )]
    };
    let mut env = adapter_env;
    env.push(("OMP_ENSURE_EDITOR_WATCHER".to_string(), "0".to_string()));
    let omp_command = vec![
        "omp".to_string(),
        "-p".to_string(),
        "--cwd".to_string(),
        repo.to_string_lossy().into_owned(),
        "--tools".to_string(),
        scenario.tools.to_string(),
        "--auto-approve".to_string(),
        "--no-session".to_string(),
        "--max-time".to_string(),
        scenario.omp_execution_window.unwrap_or("45").to_string(),
        prompt,
    ];
    let omp = run_omp(
        &omp_command,
        &repo,
        env,
    );
    let payloads = support::read_payloads(&payload_log);
    let captured_payload = scenario
        .payload_match
        .and_then(|matcher| payloads.iter().find(|entry| matcher(entry)));
    if let Some(signal) = &omp.signal {
        return Err(format!(
            "real OMP {id} runtime timed out or was terminated: {signal}"
        ));
    }
    let captured_payload = match captured_payload {
        Some(payload) => payload,
        None => {
            let shown: Vec<Json> = payloads.iter().take(5).cloned().collect();
            return Err(format!(
                "real OMP {id} did not capture expected payload; payloads={}; stdoutTail={}; stderrTail={}",
                Json::arr(shown).to_compact(),
                support::tail(&omp.stdout),
                support::tail(&omp.stderr)
            ));
        }
    };
    let runner_text = || match crate::json::js_or2(
        captured_payload.get("runner").and_then(|r| r.get("json")),
        captured_payload.get("runner"),
    ) {
        Some(value) => value.to_compact(),
        None => "undefined".to_string(),
    };
    if let Some(expected_decision) = scenario.expected_decision {
        let actual = captured_payload
            .get("runner")
            .and_then(|r| r.get("json"))
            .and_then(|j| j.get("decision"))
            .and_then(Json::as_str);
        if actual != Some(expected_decision) {
            return Err(format!(
                "real OMP {id} expected {expected_decision} decision; runner={}",
                runner_text()
            ));
        }
    }
    if let Some(expected_hook_id) = scenario.expected_hook_id {
        let ran = captured_payload
            .get("runner")
            .and_then(|r| r.get("json"))
            .and_then(|j| j.get("results"))
            .and_then(Json::as_array)
            .map(|results| {
                results
                    .iter()
                    .any(|result| result.get("id").and_then(Json::as_str) == Some(expected_hook_id))
            })
            .unwrap_or(false);
        if !ran {
            return Err(format!(
                "real OMP {id} did not execute {expected_hook_id}; runner={}",
                runner_text()
            ));
        }
    }
    if let Some(assert_after) = scenario.assert_after {
        assert_after(&AssertAfterCtx {
            repo: &repo,
            system_tmp,
            prepared: &prepared,
            omp: &omp,
            payloads: &payloads,
            captured_payload: Some(captured_payload),
        })?;
    }
    let mut entries = vec![
        ("ok".to_string(), Json::Bool(true)),
        ("runtime".to_string(), Json::str("omp")),
        ("hook".to_string(), Json::str(id)),
        ("coverageKey".to_string(), Json::str(scenario.coverage_key)),
        (
            "coveredKeys".to_string(),
            Json::arr(
                support::covered_keys_from_omp_payloads(&payloads)
                    .into_iter()
                    .map(Json::Str)
                    .collect(),
            ),
        ),
        ("tool".to_string(), Json::str(scenario.tool_name)),
        (
            "command".to_string(),
            Json::arr(omp_command.iter().cloned().map(Json::Str).collect()),
        ),
        ("runtimeExitStatus".to_string(), opt_num(omp.status)),
        ("payloadCaptured".to_string(), Json::Bool(true)),
        ("capturedPayload".to_string(), captured_payload.clone()),
    ];
    if let Some(expected_behavior) = scenario.expected_behavior {
        entries.push(("expectedBehavior".to_string(), Json::str(expected_behavior)));
    }
    entries.push((
        "blocked".to_string(),
        Json::Bool(scenario.expected_decision == Some("block")),
    ));
    let _ = ctx;
    Ok(Json::obj(entries))
}
