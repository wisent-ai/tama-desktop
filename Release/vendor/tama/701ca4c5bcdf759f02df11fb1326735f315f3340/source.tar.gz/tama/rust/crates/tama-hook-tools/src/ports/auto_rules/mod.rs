//! Rules added after an incident, held as data instead of spliced into
//! source.
//!
//! The shell version of this gate ended with an "AUTO-ADDED RULES BELOW"
//! region, and a helper edited that region to append a new `if grep …; then
//! exit 2; fi` block whenever the operator's frustration produced a new rule.
//! That worked for a shell script and cannot work for a compiled binary, and
//! it was a poor idea for the shell too: the rule and the code that runs it
//! were the same text, so every new rule was an edit to a protected file, and
//! the only record of why it existed was a comment above it.
//!
//! A rule is now a row: an id, the date it was added, what it reads (the
//! path, the content or the command), the pattern, the refusal, and the
//! reason. The rows that already existed ship here as defaults so nothing is
//! lost; the drafter appends to `~/.shared-hooks/auto_rules.json`, which both
//! the write gate and the bash gate read on every call.

mod registry;

pub(crate) use registry::DEFAULTS;
use registry::{recorded, registry_path};

use crate::ports::transport_common as common;

/// What a rule reads.
#[derive(Clone, Copy, PartialEq)]
pub enum Target {
    Path,
    Content,
    Command,
}

/// One rule: what it reads, what it matches, and what it says.
pub struct Rule {
    pub id: &'static str,
    pub added: &'static str,
    pub target: Target,
    pub pattern: &'static str,
    pub message: &'static str,
    pub why: &'static str,
}

/// What a rule may read: the three subjects a gate can offer it.
#[derive(Default)]
pub struct Subjects<'a> {
    pub file_path: &'a str,
    pub content: &'a str,
    pub command: &'a str,
}

impl<'a> Subjects<'a> {
    fn of(&self, target: Target) -> &'a str {
        match target {
            Target::Path => self.file_path,
            Target::Content => self.content,
            Target::Command => self.command,
        }
    }
}

/// The refusal one of these rules earns, if any. `registry` is injectable so
/// a test runs against a fixture instead of the machine's own file. A gate
/// that offers no command only ever matches path and content rules, because
/// an empty subject matches nothing these patterns look for.
pub fn refusal_with(registry: &str, subjects: &Subjects) -> Option<String> {
    for rule in DEFAULTS {
        let subject = subjects.of(rule.target);
        if !subject.is_empty() && common::compile(rule.pattern).is_match(subject) {
            return Some(rule.message.to_string());
        }
    }
    for (_, target, pattern, message) in recorded(registry) {
        let subject = subjects.of(target);
        if !subject.is_empty() && common::compile(&pattern).is_match(subject) {
            return Some(message);
        }
    }
    None
}

/// The refusal for a write: its path and the content it would leave.
pub fn write_refusal(file_path: &str, content: &str) -> Option<String> {
    refusal_with(
        &registry_path(),
        &Subjects {
            file_path,
            content,
            command: "",
        },
    )
}

/// The refusal for a shell command.
pub fn command_refusal(command: &str) -> Option<String> {
    refusal_with(
        &registry_path(),
        &Subjects {
            command,
            ..Default::default()
        },
    )
}

#[cfg(test)]
mod tests {
    use super::{refusal_with, Subjects, DEFAULTS};
    use serde_json::json;

    const ABSENT: &str = "/nonexistent/auto_rules.json";

    fn fixture(name: &str, body: serde_json::Value) -> std::path::PathBuf {
        let dir = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../target/tmp")
            .join(format!("tama-auto-rules-{name}"));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).expect("a folder for the fixture");
        let path = dir.join("auto_rules.json");
        std::fs::write(&path, body.to_string()).expect("a fixture registry");
        path
    }

    /// Every default carries the incident that produced it, so a later reader
    /// can tell whether the rule still has a reason to exist.
    #[test]
    fn every_default_rule_records_why_it_exists() {
        for rule in DEFAULTS {
            assert!(!rule.id.is_empty());
            assert!(rule.why.split_whitespace().count() > 8, "{}", rule.id);
            assert!(rule.message.starts_with("BLOCKED:"), "{}", rule.id);
            assert!(!rule.added.is_empty(), "{}", rule.id);
        }
    }

    #[test]
    fn the_rules_the_shell_carried_still_refuse_their_shapes() {
        assert!(refusal_with(
            ABSENT,
            &Subjects {
                file_path: "/repo/docs/hook-registry.md",
                content: "",
                command: ""
            }
        )
        .is_some());
        assert!(refusal_with(
            ABSENT,
            &Subjects {
                file_path: "/repo/paper/paper_revised_35pageslimit.tex",
                content: "",
                command: ""
            }
        )
        .is_some());
        assert!(refusal_with(
            ABSENT,
            &Subjects {
                file_path: "/repo/src/01-head.source",
                content: "",
                command: ""
            }
        )
        .is_some());
        assert_eq!(
            refusal_with(
                ABSENT,
                &Subjects {
                    file_path: "/repo/src/main.rs",
                    content: "fn main() {}",
                    command: ""
                }
            ),
            None
        );
    }

    /// A rule added after the defaults were written is read from the registry,
    /// not spliced into this file.
    #[test]
    fn a_recorded_rule_is_applied() {
        let path = fixture(
            "recorded",
            json!({ "rules": [{
                "id": "no-screenshots-in-src",
                "added": "2026-09-15",
                "target": "path",
                "pattern": "/src/.*\\.png$",
                "message": "BLOCKED: screenshots belong in recordings/, not in src/.",
                "why": "recorded by the drafter pipeline"
            }] }),
        );
        let file_path = "/repo/src/shot.png";
        let found = refusal_with(
            &path.to_string_lossy(),
            &Subjects {
                file_path,
                ..Default::default()
            },
        )
        .expect("the recorded rule applies");
        assert!(found.contains("recordings/"), "{found}");
        assert_eq!(
            refusal_with(
                &path.to_string_lossy(),
                &Subjects {
                    file_path: "/repo/src/main.rs",
                    ..Default::default()
                }
            ),
            None
        );
        let _ = std::fs::remove_dir_all(path.parent().expect("a folder"));
    }

    /// A rule may read the content instead of the path.
    #[test]
    fn a_content_rule_reads_the_content() {
        let path = fixture(
            "content",
            json!({ "rules": [{
                "id": "no-print-debugging",
                "added": "2026-09-15",
                "target": "content",
                "pattern": "console\\.debug\\(",
                "message": "BLOCKED: leave no console.debug in a committed file.",
                "why": "recorded by the drafter pipeline"
            }] }),
        );
        assert!(refusal_with(
            &path.to_string_lossy(),
            &Subjects {
                file_path: "/repo/src/a.ts",
                content: "console.debug(x)",
                command: "",
            }
        )
        .is_some());
        let _ = std::fs::remove_dir_all(path.parent().expect("a folder"));
    }
}
