use serde_json::Value;

use super::super::{option, refuse, report, Request, USAGE};
use super::{list_document, record_request, remove_document, RecordRequest};

pub(in crate::justify) fn main(action: &str, argv: &[String], request: &Request) -> i32 {
    let result = execute(action, argv, request);
    match result {
        Ok(document) => report(
            request,
            &serde_json::to_string_pretty(&document).unwrap_or_default(),
            document,
        ),
        Err(message) => refuse(&message),
    }
}

fn execute(action: &str, argv: &[String], request: &Request) -> Result<Value, String> {
    for argument in argv.iter().filter(|arg| arg.starts_with("--")) {
        if ![
            "--kind",
            "--home",
            "--json",
            "--quote",
            "--quote-match",
            "--session",
            "--app",
            "--actions",
        ]
        .contains(&argument.as_str())
        {
            return Err(format!("unknown CUA option: {argument}"));
        }
    }
    let required = |flag| {
        option(argv, flag)
            .filter(|value| !value.starts_with("--"))
            .ok_or_else(|| format!("{flag} is required"))
    };
    match action {
        "record" => record_request(
            RecordRequest {
                session_id: required("--session")?,
                app: required("--app")?,
                actions: required("--actions")?
                    .split(',')
                    .map(str::to_string)
                    .collect(),
                quote: option(argv, "--quote"),
                quote_match: option(argv, "--quote-match"),
            },
            &request.home,
        ),
        "list" => list_document(&request.home),
        "show" => {
            let quote = required("--quote")?;
            let mut document = list_document(&request.home)?;
            let entries = document["authorizations"]
                .as_array_mut()
                .ok_or("authorizations is not an array")?;
            entries.retain(|entry| {
                entry.get("userRequestQuote").and_then(Value::as_str) == Some(&quote)
            });
            if entries.is_empty() {
                return Err("no CUA grant is recorded for that quote".into());
            }
            Ok(document)
        }
        "remove" => remove_document(&request.home, &required("--quote")?),
        other => Err(format!("unknown action {other}\n{USAGE}")),
    }
}
