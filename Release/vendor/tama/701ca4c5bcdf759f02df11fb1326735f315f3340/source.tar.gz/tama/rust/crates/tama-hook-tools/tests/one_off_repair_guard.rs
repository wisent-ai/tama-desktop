//! `tama-block-one-off-repairs`, driven as the real binary with a real
//! payload on stdin, the way the Tama engine drives it.
//!
//! Three repairs by hand are refused — a running service cycled, a grant or
//! bearer minted from the shell, a built binary copied over an installed one
//! — and each case holds one command to its exit status and, when refused,
//! to the route the refusal names, so a later rewrite cannot widen the gate
//! onto `launchctl list` or `skarbiec grant verify`, or narrow it off the
//! three repairs the week of 2026-09-12 counted.

use std::io::Write as _;
use std::process::{Command, Output, Stdio};

use serde_json::json;

const EXIT_PASS: i32 = false as i32;
const EXIT_REFUSED: i32 = true as i32 + true as i32;

const GUARD: &str = env!("CARGO_BIN_EXE_tama-block-one-off-repairs");
const BANNER: &str = "BLOCKED: one-off repair by hand. ";

fn run(command: &str) -> Output {
    let payload = json!({ "tool_name": "Bash", "tool_input": { "command": command } });
    let mut child = Command::new(GUARD)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .unwrap_or_else(|error| panic!("spawn the guard: {error}"));
    child
        .stdin
        .as_mut()
        .expect("guard stdin")
        .write_all(payload.to_string().as_bytes())
        .expect("write payload");
    child.wait_with_output().expect("guard output")
}

/// Refused, and the refusal names the product route.
fn refuses(command: &str, route: &str) {
    let output = run(command);
    let stderr = String::from_utf8_lossy(&output.stderr).into_owned();
    assert_eq!(
        output.status.code(),
        Some(EXIT_REFUSED),
        "{command} should be refused; stderr: {stderr}"
    );
    assert!(stderr.starts_with(BANNER), "banner for {command}: {stderr}");
    assert!(
        stderr.contains(route),
        "{command} must name `{route}`: {stderr}"
    );
}

fn passes(command: &str) {
    let output = run(command);
    let stderr = String::from_utf8_lossy(&output.stderr).into_owned();
    assert_eq!(
        output.status.code(),
        Some(EXIT_PASS),
        "{command} should pass; stderr: {stderr}"
    );
    assert!(stderr.is_empty(), "a passing call prints nothing: {stderr}");
}

#[test]
fn a_service_cycled_by_hand_is_refused_with_the_stado_route() {
    refuses(
        "launchctl kickstart -k gui/501/ai.wisent.oko.transcript-index",
        "stado service restart",
    );
    refuses(
        "sudo launchctl bootout system/com.wisent.compute.service.transcript-lake",
        "stado service restart",
    );
    refuses("kill -TERM 40080 || true", "stado service restart");
    refuses("pkill -f transcript-lake", "stado service restart");
}

#[test]
fn reading_launchd_and_probing_a_process_pass() {
    passes("launchctl list | grep wisent");
    passes("launchctl print gui/501/ai.wisent.oko.transcript-index");
    passes("kill -0 4610 && echo alive");
    passes("grep -rn 'launchctl kickstart' ~/agents/operations.md");
}

#[test]
fn a_vault_write_past_stado_is_refused_with_the_stado_route() {
    refuses(
        "skarbiec grant ensure stado-release-client jeden-desktop-release-publisher --field token --token-file ~/.stado/x",
        "stado release catalog declare-publisher",
    );
    refuses(
        "skarbiec token-mint --consumer oko --capabilities read:x#token",
        "stado credentials token mint",
    );
}

#[test]
fn the_product_route_a_read_of_a_grant_and_its_help_pass() {
    passes("stado credentials token mint oko-judge --host charless-mac-mini --capabilities call:brama#best --audience oko");
    passes("stado service grant-sync brama --host mini --consumer oko --capability call:brama#best --token-file ~/.stado/t");
    passes("skarbiec grant verify stado-release-client jeden-release-publisher --action read");
    passes("skarbiec grant list --json");
    passes("skarbiec grant issue --help");
    passes("git commit -m 'refuse skarbiec grant ensure from the shell'");
}

#[test]
fn a_binary_copied_over_an_installed_one_is_refused_with_the_installer_route() {
    refuses(
        "cp .build/debug/oko-cli ~/.stado/bin/oko-cli",
        "oko-cli install",
    );
    refuses(
        "cp rust/target/release/tama-block-one-off-repairs $HOME/.local/bin/",
        "stado product update",
    );
    refuses(
        "install -m 755 target/release/stado /usr/local/bin/stado",
        "stado release install-local",
    );
}

#[test]
fn a_copy_out_of_the_install_root_and_a_build_copy_pass() {
    passes("cp ~/.stado/bin/oko-cli .build/oko-cli-before");
    passes("cp .build/release/oko-cli .build/dist/oko-cli");
    passes("ls -la ~/.local/bin | head");
}

/// On 2026-07-31 a session renamed a gate's own file, ran what it forbade and
/// renamed it back. The write gate reads write and edit payloads, not a shell
/// rename, so nothing refused it.
#[test]
fn a_hook_file_changed_from_the_shell_is_refused_with_the_enforcement_route() {
    refuses(
        "mv ~/.shared-hooks/block_browser_usage.sh ~/.shared-hooks/block_browser_usage.sh.paused",
        "tama enforcement only",
    );
    refuses(
        "rm -f ~/.shared-hooks/block_inline_execution.sh",
        "tama adaptive repair",
    );
    refuses(
        "chmod -x ~/.shared-hooks/pre_write_edit.sh",
        "tama hooks release",
    );
}

#[test]
fn a_read_of_a_hook_root_and_a_copy_out_of_one_pass() {
    passes("cat ~/.shared-hooks/registry.json");
    passes("ls -la ~/.shared-hooks");
    passes("cp ~/.shared-hooks/registry.json rust/target/registry-before.json");
    passes("tama enforcement status");
}

/// The last category Oko's detector counted with no gate behind it: five raw
/// SQL writes, none refused, against stores a product owns.
#[test]
fn a_row_written_by_hand_is_refused_with_the_owning_command() {
    refuses(
        "sqlite3 ~/.oko/index.sqlite \"UPDATE operator_ledgers SET messages = 9\"",
        "oko-cli transcripts reindex",
    );
    refuses(
        "psql -h db.example.co -U postgres -c 'insert into sessions(id) values (1)'",
        "migration",
    );
}

#[test]
fn a_query_and_a_schema_read_pass() {
    passes("sqlite3 ~/.oko/index.sqlite \"SELECT COUNT(*) FROM sessions\"");
    passes("sqlite3 ~/.oko/index.sqlite .schema");
    passes("psql --help");
}

/// The shapes `oko-cli transcripts one-offs --gate-check` reported on
/// 2026-09-20 as counted by the detector and refused by nothing.
#[test]
fn a_brew_service_an_adhoc_signature_and_a_store_write_are_refused() {
    refuses(
        "brew services restart postgresql@17",
        "stado service restart",
    );
    refuses(
        "codesign -f -s - .build/release/oko-cli",
        "stado release prepare",
    );
    refuses("redis-cli SET session:42 open", "owns those keys");
}

#[test]
fn reading_a_service_a_signature_or_a_store_passes() {
    passes("brew services list");
    passes("codesign -dv --verbose=4 ~/.stado/bin/stado");
    passes("codesign -s 'Developer ID Application: Wisent' .build/release/oko-cli");
    passes("redis-cli GET session:42");
    passes("redis-cli --help");
}

/// The last three shapes `oko-cli transcripts one-offs --gate-check` still
/// reported as counted and refused by nothing, and the reads beside them.
#[test]
fn a_machine_setting_a_scratch_directory_and_a_write_into_operator_state_are_refused() {
    refuses(
        "defaults write com.google.Chrome AllowJavaScriptAppleEvents -bool true",
        "stado registry set",
    );
    refuses("work=$(mktemp -d)", "~/.wisent-output");
    refuses(
        "printf '%s' token > ~/.stado/release-client-token",
        "stado credentials token mint",
    );
    refuses(
        "echo '{}' >> $HOME/.config/wisent/settings.json",
        "stado registry set",
    );
}

#[test]
fn reading_a_setting_and_writing_into_a_build_directory_pass() {
    passes("defaults read com.google.Chrome AllowJavaScriptAppleEvents");
    passes("stado release status --json > rust/target/release.json");
    passes("cat ~/.stado/config.json");
    passes("defaults --help");
}

/// The binary this machine runs refuses a guessed wait and the two fleet
/// commands that repair one host once, and names what owns each outcome.
#[test]
fn a_guessed_wait_and_a_one_host_fleet_repair_are_refused_with_their_routes() {
    refuses("sleep 420", "stado job watch");
    refuses(
        "sleep 240; stado release doctor skarbiec --target charless-mac-mini",
        "stado release doctor",
    );
    refuses(
        "stado space reclaim lukasz-macbook --apply --reason 'the disk filled again'",
        "stado space cleaners",
    );
    refuses(
        "stado release submit --source . --commit 6c9f32cb --version 0.21.49 --channel stable",
        "never bound to every commit",
    );
}

#[test]
fn reading_a_host_watching_a_job_and_enqueueing_a_recipe_pass() {
    passes("stado space report lukasz-macbook");
    passes("stado job watch 5e0f --follow");
    passes("stado queue budget");
    passes("stado release resume 05e9e047");
    passes("stado release submit --help");
}

/// The suite, the lint and the check typed into a shell the minute an edit
/// landed. Writing the functionality ends with a commit and a push; the
/// build that carries the accumulated commits runs the suite once, and a
/// failure there reopens the task. Each refusal is held to the sentence that
/// says so, because that sentence is what a session reads instead of
/// reaching for a build of its own.
#[test]
fn a_suite_a_lint_and_a_build_run_by_hand_are_refused_with_the_rule_they_break() {
    refuses("cargo test --test publication", "commit and a push");
    refuses(
        "cd rust && cargo clippy --all-targets",
        "accumulated commits",
    );
    refuses("cargo check --all-targets", "not your step");
    refuses("cargo test", "stado queue budget");
    refuses(
        "cargo build --release --bin stado",
        "three times in a rolling day",
    );
}

/// `cargo install` is the one that leaves a mark: a session used it all
/// afternoon as a compiler check once `build` and `check` were refused, and
/// every pass replaced the installed CLI with a working copy nobody
/// published — "i kto Ci powiedzial zeby sprawdzac czy Rust sie kompiluje",
/// then "zablokuj cargo install".
#[test]
fn installing_a_working_copy_onto_this_machine_is_refused() {
    refuses(
        "cargo install --path crates/tama-cli --root \"$HOME/.local\" --force",
        "delivered release",
    );
    refuses(
        "cd rust && cargo install --path . --root target/verify",
        "nobody reviewed",
    );
}

/// Formatting by hand is the same private answer: a session ran it twice on
/// 2026-09-21 to get a quality gate to pass and swept other sessions'
/// unformatted files into its own commit — "zablokuj prosze cargo fmt tak jak
/// cargo install". Asking the toolchain for help still passes, because a
/// question runs nothing.
#[test]
fn formatting_by_hand_is_refused_and_asking_for_help_passes() {
    refuses("cargo fmt", "pre-commit dispatcher");
    refuses("cd rust && cargo fmt --all", "release build reads the same check");
    passes("cargo fmt --help");
    passes("cargo test --help");
}

/// Every other driver, because a gate that named only `cargo` watched a
/// session run `swift build` and `swift test` all afternoon: "i jak to jest
/// mozliwe ze budujesz skoro nasz hook mial to blokowac. dodaj swift test i
/// jakiekolwiek komendy do budowania do listy zakazanych zwrotow".
#[test]
fn a_build_or_a_suite_in_any_other_toolchain_is_refused_with_the_ration_route() {
    refuses(
        "swift test --filter JudgeHealthJourneyTests",
        "tama build record",
    );
    refuses(
        "cd oko && swift build --product oko-cli",
        "tama build record",
    );
    refuses(
        "xcodebuild -scheme Oko -configuration Release",
        "tama build record",
    );
    refuses("xcrun swift build", "tama build record");
    refuses("npm run build", "stado queue budget");
    refuses("make -j8 release", "tama build record");
    refuses("go test ./...", "tama build record");
}

/// Every script a package manager runs, because the word after `run` is not
/// evidence of anything: `npm run test:context` compiles the release binary
/// before it runs a case, `npm run dev` compiles it and keeps it running, and
/// this gate used to read `build` and let the rest through. The operator's
/// instruction on 2026-09-21: "dodaj npm run test, npm run build npm run dev
/// i inne tego typy komendy do zakazanych komend robiacych build".
#[test]
fn a_script_run_by_a_package_manager_is_refused_with_the_delivery_route() {
    refuses("npm run dev", "tama build record");
    refuses("npm run test:context", "tama build record");
    refuses("npm test", "tama build record");
    refuses("npm install", "tama build record");
    refuses("pnpm run lint", "tama build record");
    refuses("yarn test", "tama build record");
    refuses("bun run watch", "tama build record");
    refuses("npx tsc --noEmit", "tama build record");
}

#[test]
fn reading_a_package_and_asking_for_help_pass() {
    passes("swift package describe");
    passes("swift test --help");
    passes("npm run --help");
    passes("stado queue budget --limit 3");
}
