//! The managed Git dispatcher: the script it writes, where it writes it,
//! and the bypass that refuses the write.
//!
//! Split out of `install/mod.rs`, which had grown past the
//! three-hundred-line limit. The level plan stays there.

use serde::Serialize;
use std::fs;
use std::path::Path;

use super::MANAGED_HEADER;
use crate::{err, Result};

/// JS `dispatcherBody(root, hookName, backupPath)` — reproduced byte-for-byte.
fn dispatcher_body(root: &str, hook_name: &str, backup_path: &str) -> String {
    let json = |value: &str| serde_json::to_string(value).unwrap_or_else(|_| "\"\"".to_string());
    let repo_hook = format!("${{repo_root}}/.githooks/{hook_name}");
    let mut out = String::new();
    out.push_str("#!/bin/sh\n");
    out.push_str(MANAGED_HEADER);
    out.push('\n');
    out.push_str("set -eu\n");
    out.push_str("ROOT=");
    out.push_str(&json(root));
    out.push('\n');
    out.push_str("HOOK_NAME=");
    out.push_str(&json(hook_name));
    out.push('\n');
    out.push_str("BACKUP=");
    out.push_str(&json(backup_path));
    out.push('\n');
    out.push_str("INPUT_FILE=\"${TMPDIR:-/tmp}/tama-$HOOK_NAME-$$.stdin\"\n");
    out.push_str("cat > \"$INPUT_FILE\"\n");
    out.push_str("trap 'rm -f \"$INPUT_FILE\"' EXIT\n");
    out.push_str("repo_root=\"$(git rev-parse --show-toplevel 2>/dev/null || true)\"\n");
    out.push_str("archive_hook=''\n");
    out.push_str("if [ -n \"$repo_root\" ]; then\n");
    out.push_str("  repo_base=\"$(basename \"$repo_root\")\"\n");
    out.push_str("  archive_hook=\"$ROOT/repo-githooks/$repo_base/$HOOK_NAME\"\n");
    out.push_str("fi\n");
    out.push_str(&format!(
        "if [ -n \"$repo_root\" ] && [ -x \"{repo_hook}\" ]; then\n"
    ));
    out.push_str(&format!("  \"{repo_hook}\" \"$@\" < \"$INPUT_FILE\"\n"));
    out.push_str("elif [ -n \"$archive_hook\" ] && [ -x \"$archive_hook\" ]; then\n");
    out.push_str("  \"$archive_hook\" \"$@\" < \"$INPUT_FILE\"\n");
    out.push_str("fi\n");
    out.push_str("if [ -x \"$BACKUP\" ]; then\n");
    out.push_str("  \"$BACKUP\" \"$@\" < \"$INPUT_FILE\"\n");
    out.push_str("fi\n");
    out.push_str("exit 0\n");
    out
}

/// JS `expandHome(value, home)`.
pub(super) fn expand_home(value: &str, home: &str) -> String {
    if value.is_empty() {
        return value.to_string();
    }
    if value == "~" {
        return home.to_string();
    }
    if let Some(rest) = value.strip_prefix("~/") {
        return join_path(home, rest);
    }
    value.to_string()
}

/// Node `path.join(base, part)` for the simple cases used here.
pub(super) fn join_path(base: &str, part: &str) -> String {
    format!("{}/{}", base.trim_end_matches('/'), part)
}

/// Node `path.resolve(value)`: make absolute against the CWD and normalize
/// `.`/`..`/duplicate slashes, without resolving symlinks.
pub(super) fn resolve_path(value: &str) -> Result<String> {
    let absolute = if value.starts_with('/') {
        value.to_string()
    } else {
        let cwd = std::env::current_dir()?;
        format!("{}/{}", cwd.to_string_lossy().trim_end_matches('/'), value)
    };
    let mut parts: Vec<&str> = Vec::new();
    for segment in absolute.split('/') {
        match segment {
            "" | "." => {}
            ".." => {
                parts.pop();
            }
            segment => parts.push(segment),
        }
    }
    Ok(format!("/{}", parts.join("/")))
}

#[cfg(unix)]
fn chmod_755(path: &str) -> std::io::Result<()> {
    use std::os::unix::fs::PermissionsExt;
    fs::set_permissions(path, fs::Permissions::from_mode(0o755))
}

#[cfg(not(unix))]
fn chmod_755(_path: &str) -> std::io::Result<()> {
    Ok(())
}

/// One installed dispatcher: `{ target, backup }`.
#[derive(Debug, Clone, Serialize)]
pub struct InstalledHook {
    pub target: String,
    pub backup: Option<String>,
}

/// JS `installOne(root, hooksPath, hookName)`: back up a pre-existing
/// non-managed hook, then write the managed dispatcher (mode 0755).
pub(super) fn install_one(root: &str, hooks_path: &str, hook_name: &str) -> Result<InstalledHook> {
    let target = join_path(hooks_path, hook_name);
    let backup = join_path(hooks_path, &format!("{hook_name}.before-tama"));
    if Path::new(&target).exists() {
        let bytes = fs::read(&target)?;
        let text = String::from_utf8_lossy(&bytes);
        let mut lines = text.split('\n');
        let first = lines.next().unwrap_or("");
        let second = lines.next().unwrap_or("");
        let is_managed = first == "#!/bin/sh" && second == MANAGED_HEADER;
        if !is_managed && !Path::new(&backup).exists() {
            fs::copy(&target, &backup)?;
            chmod_755(&backup)?;
        }
    }
    fs::write(&target, dispatcher_body(root, hook_name, &backup))?;
    chmod_755(&target)?;
    Ok(InstalledHook {
        target,
        backup: if Path::new(&backup).exists() {
            Some(backup)
        } else {
            None
        },
    })
}

/// Where the bypass records that it is holding policy aside.
///
/// The path is the emergency controller's, and it is read rather than
/// inferred: a machine is bypassed only when this document says so.
fn emergency_state_path(home: &str) -> String {
    join_path(
        home,
        "Library/Application Support/Tama/hook-emergency-state.json",
    )
}

fn bypass_is_recorded(home: &str) -> bool {
    let Ok(body) = fs::read_to_string(emergency_state_path(home)) else {
        return false;
    };
    let Ok(state) = serde_json::from_str::<serde_json::Value>(&body) else {
        return false;
    };
    state.get("schema").and_then(serde_json::Value::as_str)
        == Some("ai.wisent.tama.hook-emergency-state.v1")
        && state.get("disabled") == Some(&serde_json::Value::Bool(true))
}

/// Refuse to write a dispatcher the bypass is holding aside.
///
/// The bypass moves an entrypoint to `<name>.tama-disabled` and records the
/// pair, and a re-enable restores it. Writing a fresh dispatcher at the same
/// path while both exist is what made this machine unrestorable on
/// 2026-08-24: the re-enable refuses that state, correctly, and the only way
/// out was deleting files by hand. So the install refuses first, and says
/// which file and what to do about it.
pub(super) fn refuse_install_during_bypass(
    home: &str,
    hooks_path: &str,
    hook_name: &str,
) -> Result<()> {
    if !bypass_is_recorded(home) {
        return Ok(());
    }
    let disabled = join_path(hooks_path, &format!("{hook_name}.tama-disabled"));
    if !Path::new(&disabled).exists() {
        return Ok(());
    }
    Err(err(format!(
        "Tama hooks are disabled and {disabled} is the entrypoint the bypass is holding. \
Installing {hook_name} here would leave both files in place, which a re-enable refuses. \
Re-enable policy first, then install."
    )))
}
