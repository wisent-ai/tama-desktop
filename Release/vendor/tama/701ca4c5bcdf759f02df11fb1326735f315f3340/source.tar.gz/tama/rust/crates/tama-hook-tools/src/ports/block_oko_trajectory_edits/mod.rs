//! Logic for `tama-block-oko-trajectory-edits`, registry hook
//! `block-oko-trajectory-edits`: the boundary between Oko and Weles.
//!
//! Oko may consume Slack tokens and APIs. Weles owns trajectories and
//! login/install automation, and a browser is only ever driven there. So a
//! trajectory, a Slack app install flow, a browser login or any other
//! Weles-owned automation must not be written inside the Oko checkout, and
//! this gate reads the write three ways: the path it targets, the content it
//! carries, and the command that would perform it.

use std::sync::LazyLock;

use regex::Regex;
use serde_json::Value;
use tama_hooks::session_record::{deny_tool_use, read_payload};

use crate::ports::pyvalue::first_truthy_py_str;
use crate::ports::transport_common as common;

use crate::ports::tool_vocabulary::{COMMAND_KEYS, TOOL_INPUT_KEY as INPUT_KEY};

const TOOL_KEYS: &[&str] = &["tool_name", "tool", "name"];
const PATH_KEYS: &[&str] = &["file_path", "path"];
const BODY_KEYS: &[&str] = &["patch", "content", "new_string"];
const PATCH_TOOL: &str = "apply_patch";
const BASH_TOOL: &str = "Bash";
/// The one checkout of Oko on this machine. Every repository in this workshop
/// has exactly one checkout, at `~/Documents/CodingProjects/Wisent/<repo>`, so
/// the boundary is a path and not a guess.
const OKO_ROOT: &str = "/Users/lukaszbartoszcze/Documents/CodingProjects/Wisent/oko";
const OKO_RELATIVE: &str = "/Documents/CodingProjects/Wisent/oko/";
const REFUSAL: &str = concat!(
    "BLOCKED: Do not put trajectories, Slack app install flows, browser login automation, or ",
    "Weles-owned automation inside Oko. Put it in ",
    "/Users/lukaszbartoszcze/Documents/CodingProjects/Wisent/weles/scripts/trajectories/ and ",
    "call it from there. Oko may consume Slack tokens and APIs; Weles owns trajectories and ",
    "login/install automation.",
);

/// The names a Slack or browser automation flow goes by, from
/// `vocabulary.json` beside this module. The path check, the patch header
/// check and the command check all read the same words now; they used to
/// carry three copies that could drift apart.
fn declared(key: &str) -> String {
    let document: serde_json::Value = serde_json::from_str(include_str!("vocabulary.json"))
        .expect("vocabulary.json beside this module is valid JSON");
    document[key]
        .as_array()
        .unwrap_or_else(|| panic!("vocabulary.json declares no {key} array"))
        .iter()
        .filter_map(serde_json::Value::as_str)
        .collect::<Vec<_>>()
        .join("|")
}

/// `slack-install…`, `browser_login…`, `install-automation…`: the file
/// names this boundary is about, whatever the extension.
fn flow_names() -> String {
    concat!(
        "slack[-_].*({slack})",
        "|slack.*({slack}).*\\.mjs",
        "|browser[-_].*({browser})|login[-_].*({kinds})",
        "|install[-_].*({kinds})"
    )
    .replace("{slack}", &declared("slack_flows"))
    .replace("{browser}", &declared("browser_flows"))
    .replace("{kinds}", &declared("automation_kinds"))
}

static TRAJECTORY_PATH: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        "(?i)(/scripts/trajector(y|ies)/|trajector(y|ies)|{})",
        flow_names()
    ))
});

static OKO_MENTION: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(?i)(/Users/lukaszbartoszcze/Documents/CodingProjects/Wisent/oko",
        "|Documents/CodingProjects/Wisent/oko|/oko/)",
    ))
});

static TRAJECTORY_CONTENT: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(?i)(WSession\\.start|humanClickLocator|humanIdlePause|googleSso",
        "|apps\\.manifest\\.(create|update|validate)|oauth/v2/authorize|install-on-team",
        "|window\\.boot_data|xoxc-|recordVideo|recordHar|browser login|Slack app install",
        "|Slack app permission|trajectory)",
    ))
});

static PATCH_HEADER: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        "(?im)^\\*\\*\\* (Add|Update) File: .*/oko/.*(trajector(y|ies)|{})",
        flow_names()
    ))
});

static COMMAND_WRITE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        "(?i)({}).*oko/.*(trajector(y|ies)|{})",
        writing_programs(),
        flow_names()
    ))
});

/// The ways a command writes a file: a redirection, a copying program, or
/// an interpreter running something that writes. The interpreters are the
/// product's declaration in `ports::shell_text`.
fn writing_programs() -> String {
    format!(
        ">|tee|cp|mv|install|{}|{}|sed -i",
        crate::ports::shell_text::javascript_runtime_alternation(),
        crate::ports::shell_text::scripting_alternation()
    )
}

fn inside_oko(value: &str) -> bool {
    value.starts_with(OKO_ROOT) || value.contains(OKO_RELATIVE)
}

/// Whether this payload crosses the boundary.
pub fn crosses_the_boundary(payload: &Value) -> bool {
    let empty = Value::Object(Default::default());
    let input = payload.get(INPUT_KEY).unwrap_or(&empty);
    let tool = first_truthy_py_str(payload, TOOL_KEYS);
    let path = first_truthy_py_str(input, PATH_KEYS);
    let body = first_truthy_py_str(input, BODY_KEYS);
    let command = match first_truthy_py_str(input, COMMAND_KEYS) {
        found if !found.is_empty() => found,
        _ => first_truthy_py_str(payload, COMMAND_KEYS),
    };

    if !path.is_empty() && inside_oko(&path) {
        if TRAJECTORY_PATH.is_match(&path) {
            return true;
        }
        if TRAJECTORY_CONTENT.is_match(&body) {
            return true;
        }
    }
    if tool == PATCH_TOOL && !body.is_empty() {
        if OKO_MENTION.is_match(&body) && TRAJECTORY_CONTENT.is_match(&body) {
            return true;
        }
        if PATCH_HEADER.is_match(&body) {
            return true;
        }
    }
    if tool == BASH_TOOL && !command.is_empty() {
        if OKO_MENTION.is_match(&command) && TRAJECTORY_CONTENT.is_match(&command) {
            return true;
        }
        if COMMAND_WRITE.is_match(&command) {
            return true;
        }
    }
    false
}

pub fn run() {
    if crosses_the_boundary(&read_payload()) {
        deny_tool_use(REFUSAL);
    }
}

#[cfg(test)]
mod tests {
    use super::{crosses_the_boundary, OKO_ROOT};
    use serde_json::json;

    #[test]
    fn a_trajectory_file_inside_oko_is_refused() {
        let payload = json!({
            "tool_name": "Write",
            "tool_input": {
                "file_path": format!("{OKO_ROOT}/Sources/scripts/trajectories/login.mjs"),
                "content": "x"
            }
        });
        assert!(crosses_the_boundary(&payload));
    }

    /// The path can look innocent; the content is read as well.
    #[test]
    fn trajectory_content_inside_oko_is_refused() {
        let payload = json!({
            "tool_name": "Write",
            "tool_input": {
                "file_path": format!("{OKO_ROOT}/Sources/OkoKit/Helper.swift"),
                "content": "await WSession.start({ humanClickLocator: true })"
            }
        });
        assert!(crosses_the_boundary(&payload));
    }

    #[test]
    fn a_command_that_writes_a_trajectory_into_oko_is_refused() {
        let payload = json!({
            "tool_name": "Bash",
            "tool_input": {
                "command": "cp login.mjs /Users/lukaszbartoszcze/Documents/CodingProjects/Wisent/oko/scripts/trajectories/login.mjs"
            }
        });
        assert!(crosses_the_boundary(&payload));
    }

    /// Weles is where this automation belongs, so the same file there passes.
    #[test]
    fn the_same_trajectory_in_weles_passes() {
        let payload = json!({
            "tool_name": "Write",
            "tool_input": {
                "file_path": "/Users/lukaszbartoszcze/Documents/CodingProjects/Wisent/weles/scripts/trajectories/login.mjs",
                "content": "await WSession.start({ humanClickLocator: true })"
            }
        });
        assert!(!crosses_the_boundary(&payload));
    }

    /// Oko may consume Slack tokens and APIs; that is not the boundary.
    #[test]
    fn ordinary_oko_work_passes() {
        let payload = json!({
            "tool_name": "Write",
            "tool_input": {
                "file_path": format!("{OKO_ROOT}/Sources/OkoKit/Slack/Tokens.swift"),
                "content": "let token = keychain.read(\"slack-bot-token\")"
            }
        });
        assert!(!crosses_the_boundary(&payload));
    }

    #[test]
    fn a_patch_header_naming_an_oko_trajectory_is_refused() {
        let payload = json!({
            "tool_name": "apply_patch",
            "tool_input": {
                "patch": "*** Add File: /Users/x/Documents/CodingProjects/Wisent/oko/scripts/trajectories/a.mjs\n+x\n"
            }
        });
        assert!(crosses_the_boundary(&payload));
    }
}
