//! Logic for `tama-clean-violations-gate`, registry hook
//! `clean-violations-gate`: after a session ends, offer to clean the
//! repository's violations.
//!
//! Non-blocking and opt-in. It spawns `tama clean` detached and returns at
//! once, so it never delays the stop event, and it fires at most once per
//! repository per hour — a throttle marker under `~/.shared-hooks/state/`
//! keyed by the repository path, because a session that stops five times in a
//! minute does not need five cleaners racing in the same checkout.
//!
//! `TAMA_CLEAN_GATE=1` turns it on; `TAMA_CLEAN_DISABLED=1` wins over
//! everything.

use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::time::{SystemTime, UNIX_EPOCH};

use serde_json::Value;
use tama_hooks::session_record::read_payload;

use crate::ports::python_stdlib::expanduser;
use crate::util::sha256_hex;

const CWD_KEY: &str = "cwd";
const ENABLE_ENV: &str = "TAMA_CLEAN_GATE";
const DISABLE_ENV: &str = "TAMA_CLEAN_DISABLED";
const ENABLED_VALUE: &str = "1";
const CLI_ENV: &str = "TAMA_CLEAN_CLI";
const CLI_DEFAULT: &str = "~/.local/bin/tama-cli";
const STATE_DIR: &str = "~/.shared-hooks/state";
const MARK_PREFIX: &str = "clean-gate-";
const LOG_NAME: &str = "clean-gate.log";
const GIT_DIR: &str = ".git";
/// One run per repository per hour.
const THROTTLE_SECONDS_TEXT: &str = "3600";

fn throttle_seconds() -> u64 {
    THROTTLE_SECONDS_TEXT.parse().unwrap_or_default()
}

fn now() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|value| value.as_secs())
        .unwrap_or_default()
}

fn enabled() -> bool {
    std::env::var(ENABLE_ENV).ok().as_deref() == Some(ENABLED_VALUE)
        && std::env::var(DISABLE_ENV).ok().as_deref() != Some(ENABLED_VALUE)
}

fn marker(state: &Path, repo: &str) -> PathBuf {
    state.join(format!("{MARK_PREFIX}{}", sha256_hex(repo.as_bytes())))
}

/// Whether this repository may be cleaned now, recording the attempt if so.
pub fn claim(state: &Path, repo: &str, at: u64) -> bool {
    let _ = std::fs::create_dir_all(state);
    let mark = marker(state, repo);
    let last: u64 = std::fs::read_to_string(&mark)
        .ok()
        .and_then(|text| text.trim().parse().ok())
        .unwrap_or_default();
    if at.saturating_sub(last) < throttle_seconds() {
        return false;
    }
    let _ = std::fs::write(&mark, at.to_string());
    true
}

fn cli_path() -> PathBuf {
    match std::env::var(CLI_ENV) {
        Ok(value) if !value.is_empty() => PathBuf::from(value),
        _ => PathBuf::from(expanduser(CLI_DEFAULT)),
    }
}

pub fn run() {
    if !enabled() {
        return;
    }
    let payload = read_payload();
    let Some(repo) = payload.get(CWD_KEY).and_then(Value::as_str) else {
        return;
    };
    if repo.is_empty() || !Path::new(repo).join(GIT_DIR).exists() {
        return;
    }
    let state = PathBuf::from(expanduser(STATE_DIR));
    if !claim(&state, repo, now()) {
        return;
    }
    let cli = cli_path();
    if !cli.is_file() {
        return;
    }
    let log = std::fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(state.join(LOG_NAME));
    let (out, err) = match log {
        Ok(file) => match file.try_clone() {
            Ok(clone) => (Stdio::from(file), Stdio::from(clone)),
            Err(_) => (Stdio::null(), Stdio::null()),
        },
        Err(_) => (Stdio::null(), Stdio::null()),
    };
    // Detached on purpose: the stop event must not wait for a cleaner.
    let _ = Command::new(cli)
        .args(["clean", "--repo", repo])
        .stdin(Stdio::null())
        .stdout(out)
        .stderr(err)
        .spawn();
}

#[cfg(test)]
mod tests {
    use super::{claim, throttle_seconds};

    fn state(name: &str) -> std::path::PathBuf {
        let dir = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../target/tmp")
            .join(format!("tama-clean-gate-{name}"));
        let _ = std::fs::remove_dir_all(&dir);
        dir
    }

    /// The first stop in an hour claims the repository; a second one does not.
    #[test]
    fn the_throttle_is_per_repository_and_hourly() {
        let dir = state("throttle");
        let at = throttle_seconds() * 1000;
        assert!(claim(&dir, "/repo/one", at));
        assert!(!claim(&dir, "/repo/one", at));
        assert!(claim(&dir, "/repo/two", at), "another repository is free");
        assert!(
            claim(&dir, "/repo/one", at + throttle_seconds()),
            "an hour later it is free again"
        );
        let _ = std::fs::remove_dir_all(&dir);
    }
}
