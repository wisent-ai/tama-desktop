//! Logic for `tama-require-new-file-justification`, registry hook
//! `require-new-file-justification`: a new file needs a fifty-word reason,
//! keyed by its absolute path, in `~/.shared-hooks/file_justifications.json`.
//!
//! It is its own hook so the operator can leave it out of a machine's
//! selection while the file-line and folder-file limits from the same shell
//! script stay enforced.
//!
//! The registry is read here, not written. `tama justify record --kind file`
//! is what writes it, and the gate that demands the entry must never be the
//! thing that refuses to let it be added: the consent guard exempts
//! `*justifications.json` by name shape for that reason.

use serde_json::Value;
use tama_hooks::session_record::{deny_tool_use, read_payload};

use crate::ports::python_stdlib::expanduser;
use crate::ports::write_payload::WritePayload;

/// `-lt 50` in the shell.
const MIN_WORDS_TEXT: &str = "50";
const REGISTRY_PATH: &str = "~/.shared-hooks/file_justifications.json";
const SHOWN_REGISTRY: &str = "~/.shared-hooks/file_justifications.json";
const JUSTIFICATION_KEY: &str = "justification";

fn min_words() -> usize {
    MIN_WORDS_TEXT.parse().unwrap_or_default()
}

fn refusal(path: &str) -> String {
    format!(
        "BLOCKED: Need {}+ word justification in {SHOWN_REGISTRY} for new file: {path}",
        min_words()
    )
}

/// The recorded reason for this exact absolute path, if the registry holds one.
fn recorded(registry: &str, path: &str) -> Option<String> {
    let text = std::fs::read_to_string(registry).ok()?;
    let doc: Value = serde_json::from_str(&text).ok()?;
    doc.get(path)?
        .get(JUSTIFICATION_KEY)?
        .as_str()
        .map(str::to_string)
}

/// The refusal this write earns, if any. `registry` is injectable so a test
/// runs against a fixture instead of the machine's own registry.
pub fn check_with(payload: &Value, registry: &str) -> Option<String> {
    let write = WritePayload::read(payload)?;
    if write.is_system || std::path::Path::new(&write.file_path).exists() {
        return None;
    }
    let words = recorded(registry, &write.file_path)
        .map(|reason| reason.split_whitespace().count())
        .unwrap_or_default();
    match words >= min_words() {
        true => None,
        false => Some(refusal(&write.file_path)),
    }
}

pub fn check(payload: &Value) -> Option<String> {
    check_with(payload, &expanduser(REGISTRY_PATH))
}

pub fn run() {
    if let Some(message) = check(&read_payload()) {
        deny_tool_use(&message);
    }
}

#[cfg(test)]
mod tests {
    use super::check_with;
    use serde_json::json;

    const FIFTY_WORDS: &str = "The operator asked for this file by name and said why it has to \
exist, which is the whole point of the entry: a reason long enough to be a reason, written before \
the file, so that a reader six months from now can see what it was for and whether the thing it \
was for still exists at all today.";

    fn scratch(name: &str) -> std::path::PathBuf {
        let dir = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../target/tmp")
            .join(format!("tama-justify-{name}"));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).expect("a folder for the fixture");
        dir
    }

    fn new_file(path: &str) -> serde_json::Value {
        json!({ "tool_name": "Write", "tool_input": { "file_path": path, "content": "x" } })
    }

    #[test]
    fn a_new_file_with_no_entry_is_refused_and_the_registry_is_named() {
        let dir = scratch("absent");
        let registry = dir.join("file_justifications.json");
        let message = check_with(&new_file("/repo/src/new.rs"), &registry.to_string_lossy())
            .expect("no registry, no new file");
        assert!(message.contains("50+ word justification"), "{message}");
        assert!(message.contains("/repo/src/new.rs"), "{message}");
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn a_short_reason_is_not_a_reason() {
        let dir = scratch("short");
        let registry = dir.join("file_justifications.json");
        std::fs::write(
            &registry,
            json!({ "/repo/src/new.rs": { "justification": "because" } }).to_string(),
        )
        .expect("a fixture registry");
        assert!(check_with(&new_file("/repo/src/new.rs"), &registry.to_string_lossy()).is_some());
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn a_recorded_reason_lets_the_file_be_written() {
        let dir = scratch("recorded");
        let registry = dir.join("file_justifications.json");
        std::fs::write(
            &registry,
            json!({ "/repo/src/new.rs": { "justification": FIFTY_WORDS } }).to_string(),
        )
        .expect("a fixture registry");
        assert_eq!(
            check_with(&new_file("/repo/src/new.rs"), &registry.to_string_lossy()),
            None
        );
        let _ = std::fs::remove_dir_all(&dir);
    }

    /// The entry is keyed by the absolute path, so a reason recorded for one
    /// file does not licence another.
    #[test]
    fn a_reason_for_another_file_does_not_count() {
        let dir = scratch("other");
        let registry = dir.join("file_justifications.json");
        std::fs::write(
            &registry,
            json!({ "/repo/src/other.rs": { "justification": FIFTY_WORDS } }).to_string(),
        )
        .expect("a fixture registry");
        assert!(check_with(&new_file("/repo/src/new.rs"), &registry.to_string_lossy()).is_some());
        let _ = std::fs::remove_dir_all(&dir);
    }

    /// An existing file is not a new file, whatever the registry says.
    #[test]
    fn an_existing_file_needs_no_entry() {
        let dir = scratch("existing");
        let registry = dir.join("file_justifications.json");
        let existing = dir.join("already.rs");
        std::fs::write(&existing, "x").expect("an existing file");
        assert_eq!(
            check_with(
                &new_file(&existing.to_string_lossy()),
                &registry.to_string_lossy()
            ),
            None
        );
        let _ = std::fs::remove_dir_all(&dir);
    }
}
