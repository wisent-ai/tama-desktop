//! Reading a stored projection back: what a valid state looks like, and
//! the result one transition returns.
//!
//! Split out of `state/mod.rs`, which had grown past the
//! three-hundred-line limit; the store itself stays there.

use std::collections::BTreeMap;

use super::{phase, projections, HookState};

/// `validState(value, hookId)` — lenient JSON validation like the JS code.
/// Returns `None` for invalid shapes; unknown keys are preserved via `extra`.
pub fn valid_state(value: &serde_json::Value, hook_id: &str) -> Option<HookState> {
    let object = value.as_object()?;
    if object.get("schema").and_then(|v| v.as_str()) != Some(projections::SCHEMA) {
        return None;
    }
    if object.get("hookId").and_then(|v| v.as_str()) != Some(hook_id) {
        return None;
    }
    let phase = object.get("phase").and_then(|v| v.as_str())?;
    if !phase::ALL.contains(&phase) {
        return None;
    }
    let active_run_value = object.get("activeRun")?.as_array()?;
    match object.get("activeRunSourceDigest") {
        Some(v) if !v.is_null() && !v.is_string() => return None,
        None => return None,
        _ => {}
    }
    match object.get("recoveredRecord") {
        Some(v) if !v.is_null() && !v.is_array() => return None,
        None => return None,
        _ => {}
    }
    if phase == phase::WARNING
        && !object
            .get("warningSourceDigest")
            .map(|v| v.is_string())
            .unwrap_or(false)
    {
        return None;
    }
    match object.get("journalCount") {
        Some(serde_json::Value::Number(n)) => {
            // Number.isInteger: integral doubles like 2.0 count as integers.
            let count = match n.as_i64() {
                Some(count) => count,
                None => match n.as_f64() {
                    Some(f) if f.is_finite() && f.fract() == 0.0 => f as i64,
                    _ => return None,
                },
            };
            if count < 0 {
                return None;
            }
        }
        _ => return None,
    }
    let recovered_record = match object.get("recoveredRecord") {
        Some(serde_json::Value::Array(items)) => Some(
            items
                .iter()
                .filter_map(|v| v.as_str().map(str::to_string))
                .collect(),
        ),
        _ => None,
    };
    let active_run: Vec<String> = active_run_value
        .iter()
        .filter_map(|v| v.as_str().map(str::to_string))
        .collect();
    // `{ ...initialState(hookId), ...value, activeRun, recoveredRecord }`:
    // start from defaults, overlay every key of the source value, then fix
    // the two filtered arrays.
    let mut state = HookState::initial(hook_id);
    if let Ok(mut parsed) = serde_json::from_value::<HookStateLenient>(value.clone()) {
        state.schema = std::mem::take(&mut parsed.schema).unwrap_or_else(|| state.schema.clone());
        state.hook_id =
            std::mem::take(&mut parsed.hook_id).unwrap_or_else(|| state.hook_id.clone());
        state.phase = std::mem::take(&mut parsed.phase).unwrap_or_else(|| state.phase.clone());
        state.recovered_record = recovered_record;
        state.active_run = active_run;
        state.active_run_source_digest = parsed.active_run_source_digest.take();
        state.warning_source_digest = parsed.warning_source_digest.take();
        state.contested_block_observed = parsed.contested_block_observed.unwrap_or(false);
        state.last_outcome = parsed.last_outcome.take();
        state.journal_count = parsed.journal_count.unwrap_or(0);
        state.extra = std::mem::take(&mut parsed.extra);
    }
    Some(state)
}

/// Lenient mirror of `HookState` where every field is optional so a partial
/// JSON object still overlays defaults, like the JS spread.
#[derive(Default, serde::Deserialize)]
#[serde(rename_all = "camelCase", default)]
struct HookStateLenient {
    schema: Option<String>,
    hook_id: Option<String>,
    phase: Option<String>,
    active_run_source_digest: Option<String>,
    warning_source_digest: Option<String>,
    contested_block_observed: Option<bool>,
    last_outcome: Option<String>,
    journal_count: Option<i64>,
    #[serde(flatten)]
    extra: BTreeMap<String, serde_json::Value>,
}

/// Result of `store.update` / engine `finish` (`TransitionResult` in JS).
#[derive(Debug, Clone)]
pub struct TransitionResult {
    pub ok: bool,
    pub persisted: bool,
    pub mode: String,
    pub transition: Option<String>,
    pub reason: Option<String>,
    pub state: HookState,
}

impl TransitionResult {
    pub fn to_value(&self) -> serde_json::Value {
        let mut map = serde_json::Map::new();
        map.insert("ok".into(), self.ok.into());
        map.insert("persisted".into(), self.persisted.into());
        map.insert("mode".into(), self.mode.clone().into());
        if let Some(transition) = &self.transition {
            map.insert("transition".into(), transition.clone().into());
        }
        if let Some(reason) = &self.reason {
            map.insert("reason".into(), reason.clone().into());
        }
        map.insert("state".into(), self.state.to_value());
        serde_json::Value::Object(map)
    }
}
