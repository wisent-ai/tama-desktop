//! Blanking comments and quoted text before the scan, so a number inside a
//! string or a comment is not read as a literal.
//!
//! Split out of `check_numeric_literals_scan/mod.rs`, which had grown past
//! the three-hundred-line limit; the literal detection stays there.

use super::{lookup, BLK, DEFAULT_LINE_COMMENT, LC};
use crate::ports::python_stdlib;

const PY_LANG: &str = "py";
const BLOCK_OPEN: &str = "/*";
const BLOCK_CLOSE: &str = "*/";
const TRIPLE_DOUBLE: &str = "\"\"\"";
const TRIPLE_SINGLE: &str = "'''";
const QUOTES: &[char] = &['"', '\'', '`'];
const NEWLINE: char = '\n';
const ESCAPE: char = '\\';
const BLANK: char = ' ';

fn find_seq(chars: &[char], needle: &[char], from: usize) -> Option<usize> {
    let step = python_stdlib::one();
    let mut index = from;
    while index + needle.len() <= chars.len() {
        if chars[index..index + needle.len()] == *needle {
            return Some(index);
        }
        index += step;
    }
    None
}

fn at(chars: &[char], index: usize, needle: &[char]) -> bool {
    index + needle.len() <= chars.len() && chars[index..index + needle.len()] == *needle
}

/// `strip_sc` — comments and quoted text become runs of spaces of the same
/// length. The blanking is why a number in a string is not a literal; it is also
/// why a line number after a multi-line comment can be short, since the newlines
/// inside the comment are blanked too. Both are the Python's behaviour.
pub fn strip_sc(src: &str, lang: &str) -> String {
    let chars: Vec<char> = src.chars().collect();
    let line_comment: Vec<char> = lookup(LC, lang)
        .unwrap_or_else(|| DEFAULT_LINE_COMMENT.to_string())
        .chars()
        .collect();
    let block_open: Vec<char> = BLOCK_OPEN.chars().collect();
    let block_close: Vec<char> = BLOCK_CLOSE.chars().collect();
    let triple_double: Vec<char> = TRIPLE_DOUBLE.chars().collect();
    let triple_single: Vec<char> = TRIPLE_SINGLE.chars().collect();
    let blocks = BLK.contains(&lang);
    let triples = lang == PY_LANG;
    let step = python_stdlib::one();
    let mut out = String::with_capacity(src.len());
    let mut i = usize::MIN;
    while i < chars.len() {
        let mut blank_to = None;
        if at(&chars, i, &line_comment) {
            blank_to = Some(find_seq(&chars, &[NEWLINE], i).unwrap_or(chars.len()));
        } else if blocks && at(&chars, i, &block_open) {
            blank_to = Some(match find_seq(&chars, &block_close, i + block_open.len()) {
                Some(found) => found + block_close.len(),
                None => chars.len(),
            });
        } else if triples && (at(&chars, i, &triple_double) || at(&chars, i, &triple_single)) {
            let quote = if at(&chars, i, &triple_double) {
                &triple_double
            } else {
                &triple_single
            };
            blank_to = Some(match find_seq(&chars, quote, i + quote.len()) {
                Some(found) => found + quote.len(),
                None => chars.len(),
            });
        } else if QUOTES.contains(&chars[i]) {
            blank_to = Some(scan_quoted(&chars, i));
        }
        match blank_to {
            Some(end) => {
                out.extend(std::iter::repeat(BLANK).take(end - i));
                i = end;
            }
            None => {
                out.push(chars[i]);
                i += step;
            }
        }
    }
    out
}

/// The single-quote scanner runs past the end of input on a trailing backslash,
/// so the blanked text can come out longer than the source. Ported as written.
fn scan_quoted(chars: &[char], open: usize) -> usize {
    let step = python_stdlib::one();
    let quote = chars[open];
    let mut j = open + step;
    while j < chars.len() {
        if chars[j] == ESCAPE {
            j += step + step;
            continue;
        }
        if chars[j] == quote {
            j += step;
            break;
        }
        j += step;
    }
    j
}
