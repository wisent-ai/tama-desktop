//! Port of `src/adaptive/state/projections.mjs`: pure projection transitions.
//! States are plain JSON objects in JS; here they are `HookState` with a
//! flattened `extra` map so unknown keys survive validation and persistence
//! exactly like the JS `{ ...initialState, ...value }` spread.

use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;

pub const SCHEMA: &str = "threshold-free-hook-projection";

/// The subset of the engine's source identity the projections inspect.
#[derive(Debug, Clone, Default)]
pub struct IdentityFacts {
    pub verifiable: bool,
    pub digest: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct HookState {
    pub schema: String,
    pub hook_id: String,
    pub phase: String,
    pub recovered_record: Option<Vec<String>>,
    pub active_run: Vec<String>,
    pub active_run_source_digest: Option<String>,
    pub warning_source_digest: Option<String>,
    pub contested_block_observed: bool,
    pub last_outcome: Option<String>,
    pub journal_count: i64,
    /// Preserve unknown keys like the JS object spread does.
    #[serde(flatten)]
    pub extra: BTreeMap<String, serde_json::Value>,
}

impl HookState {
    /// `initialState(hookId)` from `state.mjs`.
    pub fn initial(hook_id: &str) -> Self {
        HookState {
            schema: SCHEMA.to_string(),
            hook_id: hook_id.to_string(),
            phase: super::phase::OBSERVING.to_string(),
            recovered_record: None,
            active_run: Vec::new(),
            active_run_source_digest: None,
            warning_source_digest: None,
            contested_block_observed: false,
            last_outcome: None,
            journal_count: 0,
            extra: BTreeMap::new(),
        }
    }

    pub fn to_value(&self) -> serde_json::Value {
        serde_json::to_value(self).unwrap_or(serde_json::Value::Null)
    }
}

/// Result of a projection transition (`{ changed, transition, state }`).
pub struct Projection {
    pub changed: bool,
    pub transition: &'static str,
    pub state: HookState,
}

/// `projectOutcome(prior, outcome, tier, identity, eventId)`.
pub fn project_outcome(
    prior: &HookState,
    outcome: &str,
    tier: &str,
    identity: &IdentityFacts,
    event_id: &str,
) -> Projection {
    let mut state = prior.clone();
    let kind = outcome;
    if kind == "infra_failure" {
        let source_digest = if identity.verifiable {
            identity.digest.clone()
        } else {
            None
        };
        if source_digest.is_none() {
            state.active_run = Vec::new();
            state.active_run_source_digest = None;
            state.last_outcome = Some(kind.to_string());
            return Projection {
                changed: true,
                transition: "unverified-failure-observed",
                state,
            };
        }
        let source_digest = source_digest.unwrap();
        if let Some(active) = &state.active_run_source_digest {
            if *active != source_digest {
                state.active_run = Vec::new();
            }
        }
        state.active_run_source_digest = Some(source_digest);
        state.active_run.push(event_id.to_string());
        state.last_outcome = Some(kind.to_string());
        return Projection {
            changed: true,
            transition: "failure-observed",
            state,
        };
    }
    if kind == "block" {
        state.last_outcome = Some(kind.to_string());
        return Projection {
            changed: true,
            transition: "block-observed",
            state,
        };
    }
    if kind != "pass" {
        return Projection {
            changed: false,
            transition: "invalid-outcome",
            state,
        };
    }
    state.last_outcome = Some(kind.to_string());
    if state.phase == super::phase::WARNING {
        let changed_source = identity.verifiable
            && identity.digest.is_some()
            && identity.digest.as_deref() != state.warning_source_digest.as_deref();
        if changed_source {
            state.phase = super::phase::ENFORCING.to_string();
            state.warning_source_digest = None;
            state.active_run = Vec::new();
            state.active_run_source_digest = None;
            return Projection {
                changed: true,
                transition: "recovered-after-source-change",
                state,
            };
        }
        state.active_run = Vec::new();
        state.active_run_source_digest = None;
        return Projection {
            changed: true,
            transition: "recovery-refused",
            state,
        };
    }
    let completed = state.active_run.clone();
    let completed_source_digest = state.active_run_source_digest.clone();
    state.active_run = Vec::new();
    state.active_run_source_digest = None;
    let pass_source_digest = if identity.verifiable {
        identity.digest.clone()
    } else {
        None
    };
    if completed.is_empty()
        || completed_source_digest.is_none()
        || completed_source_digest != pass_source_digest
    {
        let transition = if completed.is_empty() {
            "pass-observed"
        } else {
            "source-change-reset"
        };
        return Projection {
            changed: true,
            transition,
            state,
        };
    }
    if state.recovered_record.is_none() {
        state.recovered_record = Some(completed);
        state.phase = super::phase::ENFORCING.to_string();
        return Projection {
            changed: true,
            transition: "baseline-established",
            state,
        };
    }
    let non_singleton = completed.len() > 1;
    let record_breaking = completed.len()
        > state
            .recovered_record
            .as_ref()
            .map(|r| r.len())
            .unwrap_or(0);
    let verifiable = identity.verifiable;
    if tier == "etiquette" && non_singleton && record_breaking && verifiable {
        state.recovered_record = Some(completed);
        state.phase = super::phase::WARNING.to_string();
        state.warning_source_digest = identity.digest.clone();
        return Projection {
            changed: true,
            transition: "etiquette-warning-derived",
            state,
        };
    }
    if record_breaking {
        state.recovered_record = Some(completed);
    }
    state.phase = super::phase::ENFORCING.to_string();
    Projection {
        changed: true,
        transition: "recovered-run-observed",
        state,
    }
}

/// `projectContestedBlock(prior, tier, identity, eventId)` — `tier` is unused
/// in JS beyond the signature and is kept for parity.
pub fn project_contested_block(
    prior: &HookState,
    _tier: &str,
    identity: &IdentityFacts,
    event_id: &str,
) -> Projection {
    let mut state = prior.clone();
    let source_digest = if identity.verifiable {
        identity.digest.clone()
    } else {
        None
    };
    if source_digest.is_none() {
        state.active_run = Vec::new();
        state.active_run_source_digest = None;
        state.last_outcome = Some("contested_block".to_string());
        return Projection {
            changed: true,
            transition: "unverified-contest-observed",
            state,
        };
    }
    let source_digest = source_digest.unwrap();
    if let Some(active) = &state.active_run_source_digest {
        if *active != source_digest {
            state.active_run = Vec::new();
        }
    }
    state.active_run_source_digest = Some(source_digest);
    state.active_run.push(event_id.to_string());
    state.contested_block_observed = true;
    state.last_outcome = Some("contested_block".to_string());
    Projection {
        changed: true,
        transition: "contested-failure-observed",
        state,
    }
}
