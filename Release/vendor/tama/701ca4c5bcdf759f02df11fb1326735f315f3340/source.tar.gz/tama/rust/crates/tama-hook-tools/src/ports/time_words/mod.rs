//! The words a time estimate is made of, declared as data.
//!
//! `check-time-estimates` decides by shape — a number followed by a unit —
//! and needs two vocabularies to do it: the units themselves, and the words
//! that mean the number and unit describe market data ("5 min bars", "3
//! days ago") rather than promise a schedule. Both used to sit inside the
//! guard as regex alternations, twenty-three words in one of them, where a
//! rename or an addition is found by nobody.

/// The declaration compiled in from the vocabulary folder beside `ports`.
const DECLARED: &str = include_str!("../vocabulary/time-words.json");

fn declared(key: &str) -> Vec<String> {
    let document: serde_json::Value =
        serde_json::from_str(DECLARED).expect("time-words.json beside this module is valid JSON");
    document[key]
        .as_array()
        .unwrap_or_else(|| panic!("time-words.json declares no {key} array"))
        .iter()
        .filter_map(|word| word.as_str().map(str::to_owned))
        .collect()
}

/// Every declared unit, as names.
pub fn units() -> Vec<String> {
    declared("units")
}

/// The units, as one regex branch, each allowed a plural `s`.
///
/// `sec(?:ond)?s?` in the original is spelled here as the two declared
/// names, `sec` and `second`, which reads the same to the engine.
pub fn unit_alternation() -> String {
    format!("(?:{})s?", units().join("|"))
}

/// The words that, following a number and a unit, mean market data.
pub fn chart_context_alternation() -> String {
    declared("chart_context").join("|")
}

/// The verbs that turn a duration into a promise: "takes 2 hours".
pub fn promise_verb_alternation() -> String {
    declared("promise_verbs")
        .iter()
        .map(|verb| verb.replace(' ', r"\s+"))
        .collect::<Vec<_>>()
        .join("|")
}

/// The verbs that make a duration an amount of work: "2 hours to ship".
pub fn work_verb_alternation() -> String {
    declared("work_verbs").join("|")
}

#[cfg(test)]
mod tests {
    use super::{chart_context_alternation, unit_alternation, units};

    #[test]
    fn the_units_read_as_one_optional_plural_branch() {
        let branch = unit_alternation();
        assert!(branch.starts_with("(?:"), "{branch}");
        assert!(branch.ends_with(")s?"), "{branch}");
        for unit in units() {
            assert!(branch.contains(&unit), "{unit} is missing from {branch}");
        }
    }

    #[test]
    fn the_chart_words_are_a_plain_branch() {
        let branch = chart_context_alternation();
        assert!(branch.contains('|'), "{branch}");
        assert!(!branch.contains("(?:"), "{branch}");
    }
}
