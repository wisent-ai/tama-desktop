//! One repository's repair: the lock, the rounds, and the verdict.

use std::path::Path;

use serde::Serialize;

mod rounds_loop;

pub mod agent;
pub mod brief;
pub mod journal;

use crate::find_violations::{
    is_size_rule, read_ignore_file, scan_repo, scan_repo_sizes, Violation,
};

use brief::{build_brief, is_actionable, BriefParams};
use journal::{lock_path_for, state_dir};
use rounds_loop::run_rounds;

/// A dry run prints the brief the first round would receive.
pub(super) const FIRST_ROUND: i64 = true as i64;

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Round {
    pub round: i64,
    /// Kept as an explicit JSON null on timeout/signal, like the JS
    /// `{ agentExit: run.status }` with `status === null`.
    pub agent_exit: Option<i32>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub rejected: Option<String>,
    pub remaining: usize,
}

/// Result of one `clean_repo` call: the dry-run, locked and full-run shapes.
#[derive(Debug, Clone, Default, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CleanResult {
    pub repo: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub dry_run: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub locked: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub clean: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub violations: Option<usize>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub actionable: Option<usize>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub before: Option<usize>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub after: Option<usize>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub remaining: Option<Vec<Violation>>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub rounds: Option<Vec<Round>>,
}

pub struct CleanParams<'a> {
    pub repo: &'a str,
    pub hook_path: &'a str,
    pub model: &'a str,
    pub max_rounds: f64,
    pub dry_run: bool,
    pub skip: &'a [String],
    /// Repair only the two size rules — one file too long, one folder too
    /// crowded — and leave the content rules alone. A sweep across a
    /// workshop needs that: the size rules are mechanical and reviewable,
    /// and the size pass that finds them needs no hook and no shell per file.
    pub size_only: bool,
    pub note: Option<&'a str>,
    pub root: &'a Path,
}

/// One look at the repository, through whichever pass the run was asked
/// for: the hook replay, or the in-process size pass that needs no hook.
pub(super) fn rescan(params: &CleanParams) -> crate::find_violations::ScanReport {
    if params.size_only {
        scan_repo_sizes(Path::new(params.repo))
    } else {
        scan_repo(Path::new(params.repo), Path::new(params.hook_path))
    }
}

/// What this run may hand a repair round: declared and generated paths are
/// out, `--skip` is out, and in a size-only run every content rule is out.
pub(super) fn actionable_of(
    report: &crate::find_violations::ScanReport,
    params: &CleanParams,
    ignore_entries: &[String],
) -> Vec<Violation> {
    report
        .violations
        .iter()
        .filter(|violation| is_actionable(violation, params.skip, ignore_entries))
        .filter(|violation| !params.size_only || is_size_rule(violation))
        .cloned()
        .collect()
}

/// The mkdir lock keeps two runs off one repository; it is removed on every
/// exit path.
pub fn clean_repo(params: &CleanParams) -> CleanResult {
    let mut report = rescan(params);
    let ignore_entries = read_ignore_file(params.repo);
    let before_count = report.violations.len();
    let mut actionable = actionable_of(&report, params, &ignore_entries);
    if params.dry_run {
        println!(
            "{}",
            build_brief(&BriefParams {
                repo: params.repo,
                violations: &actionable,
                round: FIRST_ROUND,
                max_rounds: params.max_rounds,
                skip: params.skip,
                note: params.note,
                size_only: params.size_only,
                feedback: &[],
            })
        );
        return CleanResult {
            repo: params.repo.to_string(),
            dry_run: Some(true),
            violations: Some(before_count),
            actionable: Some(actionable.len()),
            ..Default::default()
        };
    }
    let _ = std::fs::create_dir_all(state_dir(params.root).join("clean-locks"));
    let lock_path = lock_path_for(params.root, params.repo);
    let locked = std::fs::create_dir(&lock_path).is_err();
    if locked {
        return CleanResult {
            repo: params.repo.to_string(),
            locked: Some(true),
            violations: Some(before_count),
            actionable: Some(actionable.len()),
            ..Default::default()
        };
    }
    let result = run_rounds(
        params,
        &ignore_entries,
        &mut report,
        &mut actionable,
        before_count,
    );
    let _ = std::fs::remove_dir(&lock_path);
    result
}
