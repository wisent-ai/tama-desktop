//! The Brama client: the one authenticated, provider-neutral gateway every
//! Wisent component uses for model inference.
//!
//! It lived inside `objective_reviewer` while the reviewer was its only
//! caller. `tama clean` is the second caller, so the client sits on its own
//! here: credentials from Skarbiec, the signed HTTPS request, and a chat
//! completion. Nothing in this module knows what the answer is for.

pub mod credentials;
pub mod probe;
pub mod request;

pub use probe::reachability;
pub use request::chat;
