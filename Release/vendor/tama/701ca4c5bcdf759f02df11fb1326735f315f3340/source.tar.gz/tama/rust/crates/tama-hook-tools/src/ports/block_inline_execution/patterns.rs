//! What an inline program looks like in a shell command.
//!
//! Every pattern is anchored with the same prefix, so an interpreter reached
//! through `sudo`, `env`, a variable assignment, an absolute path, a pipeline
//! or a command substitution is the same interpreter.

use std::sync::LazyLock;

use regex::Regex;

use crate::ports::shell_text;
use crate::ports::transport_common as common;

/// `(?:^|[;&|`(]\s*)` plus the wrappers `ports::shell_text` declares,
/// environment assignments and an optional directory: the ways a program
/// gets named.
fn command_prefix() -> String {
    format!(
        concat!(
            "(?:^|[;&|`(][[:space:]]*)",
            "(?:(?:{}|exec)[[:space:]]+|[A-Za-z_][A-Za-z0-9_]*=[^[:space:]]+[[:space:]]+)*",
            "(?:[^[:space:];&|`()]+/)?",
        ),
        shell_text::wrapper_alternation()
    )
}

/// How each family is handed source on the command line. The program names
/// come from the product's declaration in `ports/shell_text`, so adding a
/// runtime is one edit to data rather than five edits to regexes.
fn inline_programs() -> Vec<String> {
    let shells = shell_text::shell_alternation();
    let javascript = shell_text::javascript_runtime_alternation();
    vec![
        format!(
            "(?:{shells})(?:[[:space:]]+(?:-c|--command)(?:[[:space:]]|=|$)\
             |[^;&|`]*<<|[^;&|`]*<\\()"
        ),
        "python(?:[0-9]+(?:\\.[0-9]+)*)?(?:[[:space:]]+(?:-c|--command|-)(?:[[:space:]]|$)\
         |[^;&|`]*<<|[^;&|`]*<\\(|[[:space:]]+/dev/stdin)"
            .to_owned(),
        format!(
            "(?:{javascript})(?:[[:space:]]+(?:run|exec))?[[:space:]]+\
             (?:-e|--eval|-p|--print|-)(?:[[:space:]]|$)"
        ),
        format!("(?:{javascript})(?:[^;&|`]*<<|[^;&|`]*<\\(|[[:space:]]+/dev/stdin)"),
        format!(
            "npx[[:space:]]+[^;&|`]*(?:{javascript})[[:space:]]+\
             (?:-e|--eval|-p|--print|-)(?:[[:space:]]|$)"
        ),
        format!(
            "(?:{})(?:[[:space:]]+(?:-e|--execute|-r|-)(?:[[:space:]]|$)\
             |[^;&|`]*<<|[^;&|`]*<\\(|[[:space:]]+/dev/stdin)",
            shell_text::scripting_alternation()
        ),
        format!(
            "(?:{})(?:[[:space:]]+--?[A-Za-z][^[:space:];&|]*)*[[:space:]]+\
             (?:-e|--eval|-c|-Command|-)(?:[[:space:]]|$)",
            shell_text::eval_flag_alternation()
        ),
        format!("(?:{})(?:[[:space:]]|$)", shell_text::awk_alternation()),
        "(?:source|\\.)[[:space:]]+<\\(".to_owned(),
        "eval(?:[[:space:]]|$)".to_owned(),
    ]
}

/// `jq` takes its filter program on the command line, which is the same
/// throwaway inline program as `python -c`: nobody can review it, rerun it or
/// diff it.
const JQ_CALL: &str = "jq(?:[[:space:]]|$)";
/// It stays allowed when the program comes from a checked-in file, and when
/// the invocation only asks jq about itself.
const JQ_EXEMPT_FLAGS: &[&str] = &[" -f ", " --from-file", " --version", " --help", " -h "];
const SEPARATORS: &[char] = &[';', '&', '|', '`', '\n'];

pub(crate) static PROGRAMS: LazyLock<Vec<Regex>> = LazyLock::new(|| {
    let prefix = command_prefix();
    inline_programs()
        .iter()
        .map(|pattern| common::compile(&format!("(?i){prefix}{pattern}")))
        .collect()
});

pub(crate) static JQ: LazyLock<Regex> =
    LazyLock::new(|| common::compile(&format!("(?i){}{JQ_CALL}", command_prefix())));

/// The shell's control-flow words, and a function definition. A loop is a
/// loop after a pipe, an `&&`, a subshell or a substitution as much as at
/// the start of a line: `ls | while read d; do …; done` ran 2026-09-18
/// because only `^` and `;` anchored the word.
pub(crate) static CONTROL_FLOW: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(?i)(?:^|[;\\n|&(`][[:space:]]*)(?:for|while|until|if|case|select|function)\\b",
        "|(?:^|[;\\n|&(`][[:space:]]*)[A-Za-z_][A-Za-z0-9_]*[[:space:]]*\\(\\)[[:space:]]*\\{",
    ))
});

/// Python spells this as a negative lookahead on the same pattern; the Rust
/// engine has none, so the segment after each `jq` is read explicitly. Same
/// question, and the answer is easier to check by eye: does this invocation
/// carry its program in a file, or ask jq about itself?
pub(crate) fn jq_runs_an_inline_program(command: &str) -> bool {
    for found in JQ.find_iter(command) {
        let rest = &command[found.end()..];
        let segment = match rest.find(SEPARATORS) {
            Some(cut) => &rest[..cut],
            None => rest,
        };
        let padded = format!(" {segment} ");
        if !JQ_EXEMPT_FLAGS.iter().any(|flag| padded.contains(flag)) {
            return true;
        }
    }
    false
}

#[cfg(test)]
mod tests {
    use super::{jq_runs_an_inline_program, CONTROL_FLOW, PROGRAMS};

    fn is_inline(command: &str) -> bool {
        PROGRAMS.iter().any(|pattern| pattern.is_match(command))
            || jq_runs_an_inline_program(command)
            || CONTROL_FLOW.is_match(command)
    }

    #[test]
    fn an_interpreter_given_a_program_on_the_command_line_is_inline() {
        for command in [
            "python3 -c 'print(1)'",
            "node -e \"console.log(1)\"",
            "bash -c 'ls'",
            "perl -e 'print 1'",
            "awk '{print $1}' file",
            "sudo python3 -c 'x'",
            "FOO=1 node --eval 'x'",
            "/usr/bin/python3 -c 'x'",
            "cat x | jq '.a'",
        ] {
            assert!(is_inline(command), "{command}");
        }
    }

    #[test]
    fn a_heredoc_and_a_process_substitution_are_inline() {
        assert!(is_inline("python3 <<'PY'\nprint(1)\nPY"));
        assert!(is_inline("source <(curl -s https://x)"));
    }

    #[test]
    fn shell_control_flow_is_inline() {
        assert!(is_inline("for f in *; do echo $f; done"));
        assert!(is_inline("if [ -f x ]; then echo y; fi"));
        assert!(is_inline("run() { echo x; }"));
        assert!(is_inline(
            "ls -d omp-* | while read d; do echo \"$d\"; done"
        ));
        assert!(is_inline("cd x && for f in a b; do cat $f; done"));
        assert!(is_inline("echo $(for f in a b; do cat $f; done)"));
        assert!(!is_inline("grep -n 'for the record' notes.md"));
        assert!(!is_inline("git log --format=%s | head"));
    }

    /// A checked-in program is reviewable, rerunnable and diffable, which is
    /// the whole point.
    #[test]
    fn a_program_from_a_file_is_not_inline() {
        assert!(!is_inline("python3 scripts/report.py --json"));
        assert!(!is_inline("node scripts/build.mjs"));
        assert!(!is_inline("jq -f filters/pick.jq data.json"));
        assert!(!is_inline("jq --version"));
    }

    #[test]
    fn ordinary_commands_pass() {
        for command in [
            "git status --short",
            "cargo test -p tama-hook-tools --lib",
            "wc -l src/main.rs",
            "cp a b",
        ] {
            assert!(!is_inline(command), "{command}");
        }
    }
}
