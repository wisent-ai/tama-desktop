//! JS coercions over a JSON value: `String(x)`, `x || y`, `Number(x)`.
//!
//! Split out of `json/mod.rs`, which had grown past the three-hundred-line
//! limit; the value type itself stays there.

use super::Json;

/// `Number('')` and `Number('   ')` are zero in JS, not NaN.
const NUMBER_OF_BLANK: f64 = 0.0;

/// `String(value)` where the value may be absent (`undefined`).
pub fn js_string_opt(value: Option<&Json>) -> String {
    match value {
        None => "undefined".to_string(),
        Some(v) => v.js_string(),
    }
}

/// `String(value || '')` where the value may be absent.
pub fn js_string_or_empty(value: Option<&Json>) -> String {
    match value {
        Some(v) if v.truthy() => v.js_string(),
        _ => String::new(),
    }
}

/// JS `a || b`: first truthy wins, otherwise the last operand.
pub fn js_or2<'a>(a: Option<&'a Json>, b: Option<&'a Json>) -> Option<&'a Json> {
    match a {
        Some(v) if v.truthy() => a,
        _ => b,
    }
}

/// JS `a || b || c`.
pub fn js_or3<'a>(
    a: Option<&'a Json>,
    b: Option<&'a Json>,
    c: Option<&'a Json>,
) -> Option<&'a Json> {
    js_or2(js_or2(a, b), c)
}

/// JS `Number(value)` for a JSON value (`undefined` -> NaN).
pub fn js_number_value(value: Option<&Json>) -> f64 {
    match value {
        None | Some(Json::Null) => {
            // Number(undefined) = NaN; Number(null) = 0.
            match value {
                None => f64::NAN,
                _ => 0.0,
            }
        }
        Some(Json::Bool(b)) => {
            if *b {
                1.0
            } else {
                0.0
            }
        }
        Some(Json::Num(text)) => text.parse::<f64>().unwrap_or(f64::NAN),
        Some(Json::Str(s)) => js_number_str(s),
        Some(Json::Arr(_)) | Some(Json::Obj(_)) => f64::NAN,
    }
}

/// JS `Number(string)` for the decimal subset relevant here.
fn js_number_str(s: &str) -> f64 {
    let t = s.trim();
    if t.is_empty() {
        return NUMBER_OF_BLANK;
    }
    match t {
        "Infinity" | "+Infinity" => f64::INFINITY,
        "-Infinity" => f64::NEG_INFINITY,
        _ => t.parse::<f64>().unwrap_or(f64::NAN),
    }
}

/// JS `Number#toString` / `JSON.stringify` for an f64. Non-finite values
/// stringify as `null` (matching `JSON.stringify`).
pub fn js_number_to_string(f: f64) -> String {
    if f.is_nan() || f.is_infinite() {
        return "null".to_string();
    }
    if f == 0.0 {
        return "0".to_string(); // also covers -0
    }
    let a = f.abs();
    if f.fract() == 0.0 && a < 1e21 {
        return format!("{f:.0}");
    }
    if a >= 1e21 || a < 1e-6 {
        // Rust prints "1.5e21"; JS prints "1.5e+21".
        let s = format!("{f:e}");
        return match s.split_once('e') {
            Some((m, e)) if !e.starts_with('-') => format!("{m}e+{e}"),
            _ => s,
        };
    }
    format!("{f}")
}
