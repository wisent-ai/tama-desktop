//! Port of `src/cli.mjs` — the main `tama` binary.
//!
//! Fidelity notes:
//! - `argv` here corresponds to JS `process.argv.slice(2)`: the node and
//!   script path entries never equal a flag, so `has`/`argAfter` over the
//!   remaining arguments behave identically.
//! - `N(x)` = `Number(x)`; exit codes are plain integers (`EXIT_USAGE` = 2).
//! - JS library errors propagate as thrown exceptions (exit 1 with the error
//!   text on stderr); here `Result` errors print the message and exit 1.
//!
//! The crate root stays slim: argument helpers, output helpers, and the
//! per-command handlers live under `cli/`; `main()` only resolves the root
//! and dispatches.

use std::path::{Path, PathBuf};

use serde::Serialize;

use tama_core::catalog::repo_root;

mod brama;
mod builds;
mod cli;
mod copies;
mod enforcement;
mod gitcmd;
mod hooks;
mod justify;
mod onboarding;
mod provider_config;
mod rules;
mod serve;
mod worktrees;

/// `EXIT_USAGE` from `src/adaptive/engine.mjs` (`N('2')`).
const EXIT_USAGE: i32 = 2;

#[derive(Serialize)]
struct McpConfig {
    #[serde(rename = "mcpServers")]
    mcp_servers: McpServers,
}

#[derive(Serialize)]
struct McpServers {
    tama: McpServerEntry,
}

#[derive(Serialize)]
struct McpServerEntry {
    command: String,
    args: Vec<String>,
}

/// The `mcp-config` document, shared with the serve backend: the native Rust
/// MCP server installed next to this binary, or its bare name when no such
/// sibling binary exists.
fn mcp_config() -> McpConfig {
    McpConfig {
        mcp_servers: McpServers {
            tama: McpServerEntry {
                command: std::env::current_exe()
                    .ok()
                    .and_then(|exe| exe.parent().map(|dir| dir.join("tama-mcp-server")))
                    .filter(|path| path.is_file())
                    .map(|path| path.display().to_string())
                    .unwrap_or_else(|| "tama-mcp-server".to_string()),
                args: vec![],
            },
        },
    }
}

/// Rust starts every program with `SIGPIPE` ignored, so a command whose reader
/// closes early - `tama enforcement status | head -2` - fails its next write
/// and panics inside `println!`, printing a Rust panic and a backtrace note
/// over the operator's terminal. Restoring the default disposition makes this
/// end the way every other Unix tool ends a closed pipe: quietly.
fn end_quietly_when_the_reader_closes() {
    const SIGPIPE: i32 = 13;
    const SIG_DFL: usize = 0;
    extern "C" {
        fn signal(signum: i32, handler: usize) -> usize;
    }
    unsafe { signal(SIGPIPE, SIG_DFL) };
}

/// The checkout the command is being run in.
///
/// `repo_root()` is compiled in from `CARGO_MANIFEST_DIR`, and the installed
/// CLI is built inside the release's export tree — a directory the release
/// deletes as soon as the build finishes. So every `tama hooks …` run
/// without `--root` read a registry that no longer exists and refused with
/// "names no hook binary of ours", on 2026-09-20, from the copy the release
/// had just installed. An explicit `--root` still wins, then `TAMA_ROOT`,
/// which `repo_root()` reads; only then does the working directory decide.
fn checkout_root_from_cwd() -> Option<PathBuf> {
    if std::env::var_os("TAMA_ROOT").is_some_and(|value| !value.is_empty()) {
        return None;
    }
    let cwd = std::env::current_dir().ok()?;
    cwd.ancestors()
        .find(|directory| directory.join("shared-hooks/registry.json").is_file())
        .map(Path::to_path_buf)
}

/// The checkout an installed copy belongs to, when the command is run from
/// somewhere else entirely.
///
/// `checkout_root_from_cwd` only answers inside a checkout, and
/// `repo_root()` is the build tree the release deleted. So from the
/// operator's home directory the installed CLI read a registry that is not
/// there and reported "0/0 installed": on 2026-09-21 the operator ran
/// `tama enforcement add block-off-task-work`, which a refusal had just
/// printed, from their own prompt, and the command could not see a single
/// installed hook. `tama hooks release` records the checkout it installed
/// from, and that recording is what answers here.
fn checkout_root_from_installed_release() -> Option<PathBuf> {
    let home = std::env::var_os("HOME").map(PathBuf::from)?;
    let recorded = std::fs::read_to_string(home.join(cli::INSTALLED_CHECKOUT_FILE)).ok()?;
    let root = PathBuf::from(recorded.trim());
    root.join("shared-hooks/registry.json")
        .is_file()
        .then_some(root)
}

fn main() {
    end_quietly_when_the_reader_closes();
    // JS `process.argv.slice(2)`.
    let argv: Vec<String> = std::env::args().skip(1).collect();

    // JS `selectedRoot()` = `optionValue('--root', repoRoot())`, with the
    // working directory consulted before the compiled-in path.
    let root: PathBuf = cli::args::option_value(&argv, "--root")
        .map(PathBuf::from)
        .or_else(checkout_root_from_cwd)
        .or_else(checkout_root_from_installed_release)
        .unwrap_or_else(repo_root);

    let cmd: &str = argv.first().map(String::as_str).unwrap_or("help");

    match cmd {
        "help" | "--help" | "-h" => {
            cli::output::usage();
            std::process::exit(0);
        }
        "onboarding" => std::process::exit(cli::commands::onboarding(&argv, &root)),
        "policy" => std::process::exit(cli::commands::policy(&argv)),
        "list" => std::process::exit(cli::commands::list(&argv, &root)),
        "show" => std::process::exit(cli::commands::show(&argv, &root)),
        "validate" => std::process::exit(cli::commands::validate(&argv, &root)),
        "install-plan" => std::process::exit(cli::commands::install_plan(&argv, &root)),
        "install" => std::process::exit(cli::commands::install(&argv, &root)),
        "verify" => std::process::exit(cli::commands::verify(&root)),
        "justify" => std::process::exit(justify::main(&argv[1..])),
        "build" => std::process::exit(builds::main(&argv[1..])),
        "hooks" => std::process::exit(hooks::main(&argv[1..], &root)),
        "rules" => std::process::exit(rules::main(&argv[1..])),
        "find-violations" => {
            std::process::exit(tama_violations::scan_repos::main(&argv[1..], &root))
        }
        "declare-root" => std::process::exit(tama_violations::declare_root::main(&argv[1..])),
        "vocabulary-report" => {
            std::process::exit(tama_violations::vocabulary_report::main(&argv[1..]))
        }
        "extract-patterns" => {
            std::process::exit(tama_violations::extract_patterns::main(&argv[1..]))
        }
        "clean" => std::process::exit(tama_violations::clean::main(&argv[1..])),
        "brama-check" => std::process::exit(brama::check::main(&argv[1..])),
        "mcp-config" => {
            cli::output::print_json(&mcp_config());
            std::process::exit(0);
        }
        "enforcement" => std::process::exit(enforcement::main(&argv[1..], &root)),
        "provider-config" => {
            let rest = argv.split_first().map(|(_, rest)| rest).unwrap_or_default();
            std::process::exit(provider_config::main(rest));
        }
        "serve" => std::process::exit(serve::main(&argv[1..], &root)),
        "adaptive" => std::process::exit(tama_adaptive::doctor::cli::main(&argv[1..])),
        "sessions" => std::process::exit(cli::sessions::main(&argv, &root)),
        "worktrees" => std::process::exit(worktrees::main(&argv[1..])),
        "copies" => std::process::exit(copies::main(&argv[1..])),
        "assignment" => std::process::exit(tama_hook_tools::assignment::cli_main(&argv[1..])),
        "task" => std::process::exit(
            tama_hook_tools::ports::block_off_task_work::scope_cli::cli_main(&argv[1..]),
        ),
        // Hidden entrypoint used by the installed adaptive runner shim.
        "adaptive-runner" => std::process::exit(tama_adaptive::runner::main(&argv)),
        // Hidden subcommand: spawned by `tama_adaptive::runner::dispatch_bridge`
        // as `<current exe> adaptive-bridge`; intentionally absent from usage.
        "adaptive-bridge" => std::process::exit(tama_adaptive::bridge::main()),
        _ => {
            cli::output::usage();
            std::process::exit(EXIT_USAGE);
        }
    }
}
