//! `JSON.stringify`, compact and two-space pretty, byte-for-byte.
//!
//! Split out of `json/mod.rs`, which had grown past the three-hundred-line
//! limit; the value type and the parser stay elsewhere.

use super::Json;

/// `JSON.stringify(value, null, 2)` indents by two spaces per level.
const PRETTY_STEP: usize = 2;

pub(super) fn write_json_string(s: &str, out: &mut String) {
    out.push('"');
    for c in s.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\u{8}' => out.push_str("\\b"),
            '\u{c}' => out.push_str("\\f"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            c if (c as u32) < 0x20 => {
                out.push_str(&format!("\\u{:04x}", c as u32));
            }
            c => out.push(c),
        }
    }
    out.push('"');
}

pub(super) fn write_compact(value: &Json, out: &mut String) {
    match value {
        Json::Null => out.push_str("null"),
        Json::Bool(b) => out.push_str(if *b { "true" } else { "false" }),
        Json::Num(text) => out.push_str(text),
        Json::Str(s) => write_json_string(s, out),
        Json::Arr(items) => {
            out.push('[');
            for (i, item) in items.iter().enumerate() {
                if i > 0 {
                    out.push(',');
                }
                write_compact(item, out);
            }
            out.push(']');
        }
        Json::Obj(entries) => {
            out.push('{');
            for (i, (key, val)) in entries.iter().enumerate() {
                if i > 0 {
                    out.push(',');
                }
                write_json_string(key, out);
                out.push(':');
                write_compact(val, out);
            }
            out.push('}');
        }
    }
}

fn push_indent(out: &mut String, indent: usize) {
    for _ in 0..indent {
        out.push(' ');
    }
}

pub(super) fn write_pretty(value: &Json, indent: usize, out: &mut String) {
    match value {
        Json::Arr(items) if !items.is_empty() => {
            out.push('[');
            for (i, item) in items.iter().enumerate() {
                if i > 0 {
                    out.push(',');
                }
                out.push('\n');
                push_indent(out, indent + PRETTY_STEP);
                write_pretty(item, indent + PRETTY_STEP, out);
            }
            out.push('\n');
            push_indent(out, indent);
            out.push(']');
        }
        Json::Obj(entries) if !entries.is_empty() => {
            out.push('{');
            for (i, (key, val)) in entries.iter().enumerate() {
                if i > 0 {
                    out.push(',');
                }
                out.push('\n');
                push_indent(out, indent + PRETTY_STEP);
                write_json_string(key, out);
                out.push_str(": ");
                write_pretty(val, indent + PRETTY_STEP, out);
            }
            out.push('\n');
            push_indent(out, indent);
            out.push('}');
        }
        other => write_compact(other, out),
    }
}
