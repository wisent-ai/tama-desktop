//! Reclaiming a ready segment once the lake has acknowledged it and every
//! decision in it is persisted.
//!
//! Split out of `segments/index/mod.rs`, which had grown past the
//! three-hundred-line limit; writing segments stays there.

use std::fs;
use std::path::PathBuf;

use super::validate::{decisions_persisted, validate_ack, validate_segment};
use super::{ack_name, safe_names, sync_directory, SegmentWriter};

pub(super) struct ReadyItem {
    pub(super) path: PathBuf,
    pub(super) ack_path: PathBuf,
    pub(super) reclaimable: bool,
}

impl SegmentWriter {
    pub(super) fn inspect_ready(&self, name: &str) -> Option<ReadyItem> {
        if !name.ends_with(".jsonl") {
            return None;
        }
        let path = self.ready_dir.join(name);
        let segment = validate_segment(&path)?;
        let ack_path = self.acked_dir.join(ack_name(&segment.segment_id));
        let ack = validate_ack(&ack_path, &segment);
        Some(ReadyItem {
            path,
            ack_path,
            reclaimable: ack.is_some() && decisions_persisted(&segment),
        })
    }

    /// `reclaimAcked()` — first error reports and aborts the sweep, like the
    /// single JS try/catch around the loop.
    pub fn reclaim_acked(&self) -> u64 {
        let mut reclaimed = 0u64;
        let result: std::io::Result<()> = (|| {
            for name in safe_names(&self.ready_dir) {
                let Some(item) = self.inspect_ready(&name) else {
                    continue;
                };
                if !item.reclaimable {
                    continue;
                }
                fs::remove_file(&item.path)?;
                sync_directory(&self.ready_dir);
                fs::remove_file(&item.ack_path)?;
                sync_directory(&self.acked_dir);
                reclaimed += 1;
            }
            Ok(())
        })();
        if let Err(error) = result {
            self.report(&error.to_string());
        }
        reclaimed
    }
}
