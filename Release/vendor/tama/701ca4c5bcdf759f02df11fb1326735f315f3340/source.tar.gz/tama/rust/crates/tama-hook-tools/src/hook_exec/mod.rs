//! Rust port of `shared-hooks/hook-exec.mjs` plus the child-process runner
//! shared by `omp-shared-hooks.js` and `run-one-session-hook.js`.
//!
//! Two invariants mirror the JS original:
//!   1. Hook commands are argv, never a shell string.
//!   2. A crashing hook is a malfunction, not a policy decision.

mod spawn;

pub use spawn::run_hook_command;

use serde_json::Value;

/// Result of one hook command execution, mirroring the JS result objects.
#[derive(Debug, Clone, Default)]
pub struct HookOutput {
    pub code: Option<i32>,
    pub signal: Option<i32>,
    pub stdout: String,
    pub stderr: String,
    pub spawn_error: bool,
}

/// Shell word semantics: quoted and unquoted runs that are not separated by
/// whitespace belong to the SAME argument.
pub fn tokenize_command(command: &str) -> Vec<String> {
    let mut tokens = Vec::new();
    let mut current = String::new();
    let mut started = false;
    let mut quote: Option<char> = None;
    let mut escaped = false;
    for ch in command.chars() {
        if escaped {
            current.push(ch);
            escaped = false;
            continue;
        }
        if quote != Some('\'') && ch == '\\' {
            escaped = true;
            started = true;
            continue;
        }
        if quote.is_none() && (ch == '"' || ch == '\'') {
            quote = Some(ch);
            started = true;
            continue;
        }
        if quote.is_some() && Some(ch) == quote {
            quote = None;
            continue;
        }
        if quote.is_none() && ch.is_whitespace() {
            if started {
                tokens.push(std::mem::take(&mut current));
                started = false;
            }
            continue;
        }
        current.push(ch);
        started = true;
    }
    if started {
        tokens.push(current);
    }
    tokens
}

fn line_matches_malfunction(s: &str) -> bool {
    if s.starts_with("Traceback (most recent call last):") {
        return true;
    }
    if s.starts_with("File \"") && s[6..].contains("\", line ") {
        return true;
    }
    if let Some(rest) = s.strip_prefix("at ") {
        let token_len = rest.find(char::is_whitespace).unwrap_or(rest.len());
        if token_len > 0 && rest[token_len..].starts_with(" (") && s.ends_with(')') {
            return true;
        }
    }
    for prefix in ["ModuleNotFound", "Import", "Syntax", "Indentation", "Tab"] {
        if s.starts_with(prefix) && s[prefix.len()..].starts_with("Error:") {
            return true;
        }
    }
    if s.starts_with("node:internal/") {
        return true;
    }
    for suffix in ["command not found", "No such file or directory"] {
        if let Some(head) = s.strip_suffix(suffix) {
            if let Some(head) = head.strip_suffix(": ") {
                if !head.chars().any(|c| c.is_whitespace() || c == ':') {
                    return true;
                }
            }
        }
    }
    false
}

/// Port of `MALFUNCTION_RE.test(...)`. The JS regex is multiline-anchored
/// (`^...$` with the `m` flag); `\s*` after `^` may itself consume newlines,
/// so every line-start position is probed.
pub fn malfunction_re_test(text: &str) -> bool {
    let mut rest = text;
    loop {
        let trimmed = rest.trim_start_matches(char::is_whitespace);
        let line_end = trimmed.find('\n').unwrap_or(trimmed.len());
        if line_matches_malfunction(&trimmed[..line_end]) {
            return true;
        }
        match rest.find('\n') {
            Some(index) => rest = &rest[index + 1..],
            None => return false,
        }
    }
}

/// Port of `looksLikeMalfunction`.
pub fn looks_like_malfunction(output: &HookOutput) -> bool {
    if output.spawn_error {
        return true;
    }
    malfunction_re_test(&output.stderr) || malfunction_re_test(&output.stdout)
}

/// Port of `decisionFromOutput` from omp-shared-hooks.js: the whole trimmed
/// output must be a JSON object with `decision === 'block'`.
pub fn decision_from_output(text: &str) -> Option<String> {
    let trimmed = text.trim();
    if trimmed.is_empty() {
        return None;
    }
    let parsed: Value = serde_json::from_str(trimmed).ok()?;
    if parsed.is_object() && parsed.get("decision").and_then(Value::as_str) == Some("block") {
        let reason = parsed.get("reason").and_then(Value::as_str);
        return Some(match reason {
            Some(r) if !r.is_empty() => r.to_string(),
            _ => "hook returned block decision".to_string(),
        });
    }
    None
}

/// Port of `outputBlockReason` from run-one-session-hook.js: only the last
/// non-empty line is considered.
pub fn output_block_reason(text: &str) -> Option<String> {
    let line = text
        .trim()
        .split('\n')
        .filter(|l| !l.is_empty())
        .next_back()?;
    let parsed: Value = serde_json::from_str(line).ok()?;
    if parsed.get("decision").and_then(Value::as_str) == Some("block") {
        let reason = parsed.get("reason").and_then(Value::as_str);
        return Some(match reason {
            Some(r) if !r.is_empty() => r.to_string(),
            _ => "Hook blocked the tool call.".to_string(),
        });
    }
    None
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Vectors generated with Node `tokenizeCommand` from hook-exec.mjs.
    #[test]
    fn tokenize_matches_node() {
        let cases: Vec<(&str, Vec<&str>)> = vec![
            ("python3 /x/y.py", vec!["python3", "/x/y.py"]),
            (
                "node '/path with spaces'/hooks/entry.mjs",
                vec!["node", "/path with spaces/hooks/entry.mjs"],
            ),
            (
                "env FOO=bar 'a'\"b\"c d",
                vec!["env", "FOO=bar", "abc", "d"],
            ),
            ("a\\ b c", vec!["a b", "c"]),
            ("echo \"it\\'s\"", vec!["echo", "it's"]),
            ("", vec![]),
            ("   ", vec![]),
            ("'\\x27", vec!["\\x27"]),
            ("cmd \"unclosed", vec!["cmd", "unclosed"]),
            ("trailing\\", vec!["trailing"]),
        ];
        for (input, expected) in cases {
            assert_eq!(tokenize_command(input), expected, "input: {:?}", input);
        }
    }

    /// Vectors generated with Node `looksLikeMalfunction` from hook-exec.mjs.
    #[test]
    fn malfunction_matches_node() {
        let cases: Vec<(&str, &str, bool)> = vec![
            (
                "",
                "Traceback (most recent call last):\n  File \"x\", line 1",
                true,
            ),
            ("", "  File \"/a/b.py\", line 12, in <module>", true),
            ("", "    at Object.<anonymous> (/x/y.js:1:1)", true),
            ("", "at foo (bar)", true),
            ("", "at foo(bar)", false),
            ("", "ModuleNotFoundError: No module named 'x'", true),
            ("", "ImportError: x", true),
            ("", "SyntaxError: x", true),
            ("", "node:internal/modules/cjs/loader:123", true),
            ("", "bash: foo: command not found", false),
            ("", "zsh: command not found: foo", false),
            (
                "",
                "python3: can't open file '/x/y.py': [Errno 2] No such file or directory",
                false,
            ),
            ("some normal output", "", false),
            ("", "IndentationError: unexpected indent", true),
            ("", "TabError: inconsistent use of tabs", true),
            ("x\n\nat foo (bar)", "", true),
        ];
        for (stdout, stderr, expected) in cases {
            let output = HookOutput {
                stdout: stdout.to_string(),
                stderr: stderr.to_string(),
                ..Default::default()
            };
            assert_eq!(
                looks_like_malfunction(&output),
                expected,
                "stderr: {:?}",
                stderr
            );
        }
    }
}
