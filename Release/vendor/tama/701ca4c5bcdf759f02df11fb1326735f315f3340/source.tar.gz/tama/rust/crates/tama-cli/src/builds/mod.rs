//! `tama build` — the registry of intended builds and restarts.
//!
//! `block-unregistered-build-or-restart` refuses a command that would build a
//! product or restart a service unless `~/.shared-hooks/build_restart_registry.json`
//! holds an open entry for it. This command is the way that entry is written,
//! for the same reason `tama justify` exists: every other path into
//! `.shared-hooks` is refused by the consent and write gates, and a registry
//! is data with an interface rather than a file somebody edits by hand.
//!
//! An entry states what the work is for, which revision a build carries, and
//! when the authorization stops. The window is part of the entry because an
//! authorization that never closed would make the first recorded build a
//! standing permission for every later one — which is the state that produced
//! ten submitted releases in one evening, several of them failing on a gate
//! that runs locally in a minute.

use serde_json::json;

pub(crate) mod api;
mod intent;
mod policy;
mod policy_revision;
mod ration;

use intent::{described, emit, home, now, refuse};

const USAGE: &str = "usage: tama build record --kind build|restart --target <name> \
--reason <text> [--revision <source revision>] [--repository <path>] [--minutes <1-240>] \
[--approval-session <id> --approval-quote <verbatim operator message>] [--home <path>] [--json]\n       \
tama build list [--home <path>] [--json]\n       \
tama build approval --target <name> --revision <source revision> [--home <path>] [--json]\n       \
tama build close --kind build|restart --target <name> [--home <path>] [--json]\n       \
tama build policy [--builds-per-day <n>] [--restarts-per-day <n>] \
[--minimum-changed-lines <n>] [--window-minutes <n>] [--home <path>] [--json]\n\n       \
A build uses the fleet's daily budget when available, otherwise a local allowance of three in \
24 hours. It carries at least thirty changed lines and one intent authorizes sixty minutes. \
Tightening a limit needs nothing; loosening one needs DEVICE_HOOK_EDIT_APPROVED=1 set outside \
the agent session. A verified operator message can instead authorize a recorded exception for \
one build of the named product without changing the policy.";
const REGISTRY_FILE: &str = "build_restart_registry.json";

pub fn main(argv: &[String]) -> i32 {
    let action = argv.first().map(String::as_str).unwrap_or("");
    if action.is_empty() || action == "help" || action == "--help" || action == "-h" {
        println!("{USAGE}");
        return if action.is_empty() { 2 } else { 0 };
    }
    let json = argv.iter().any(|item| item == "--json");
    let home = match home(argv) {
        Ok(home) => home,
        Err(message) => return refuse(&message),
    };
    let policy_file = policy::file(&home);
    if action == "policy" {
        let (policy, changes) = match policy::revise(&policy_file, argv) {
            Ok(result) => result,
            Err(message) => return refuse(&message),
        };
        let said = if changes.is_empty() {
            format!("{}\npolicy: {}", policy_file.display(), policy.sentence())
        } else {
            format!("{}\n{}", changes.join("\n"), policy.sentence())
        };
        emit(
            json,
            &said,
            &json!({"policy": policy.document(), "changed": changes, "file": policy_file}),
        );
        return 0;
    }
    match action {
        "record" => {
            let result = match api::record(argv, &home) {
                Ok(result) => result,
                Err(message) => return refuse(&message),
            };
            let key = result["recorded"].as_str().unwrap_or_default();
            emit(
                json,
                &format!(
                    "recorded {} ({} of {} intents in this 24 hours)",
                    described(key, &result["entry"], now()),
                    result["spent"],
                    result["allowed"]
                ),
                &result,
            );
            0
        }
        "list" => {
            let result = match api::list(&home) {
                Ok(result) => result,
                Err(message) => return refuse(&message),
            };
            let rows = result["entries"]
                .as_array()
                .expect("registry entries are an array");
            let said = if rows.is_empty() {
                "no build or restart entries".to_owned()
            } else {
                rows.iter()
                    .map(|row| {
                        described(
                            row["key"].as_str().unwrap_or_default(),
                            &row["entry"],
                            now(),
                        )
                    })
                    .collect::<Vec<_>>()
                    .join("\n")
            };
            let ration = result["ration"].as_array().expect("ration is an array");
            let counted = ration
                .iter()
                .map(|row| {
                    format!(
                        "{} of {} {}s spent in this 24 hours",
                        row["spent"],
                        row["allowed"],
                        row["kind"].as_str().unwrap_or_default()
                    )
                })
                .collect::<Vec<_>>()
                .join("; ");
            emit(json, &format!("{said}\n{counted}"), &result);
            0
        }
        "approval" => {
            let entry = match api::approval(argv, &home) {
                Ok(entry) => entry,
                Err(message) => return refuse(&message),
            };
            emit(json, &described("approved build", &entry, now()), &entry);
            0
        }
        "close" => {
            let result = match api::close(argv, &home) {
                Ok(result) => result,
                Err(message) => return refuse(&message),
            };
            emit(
                json,
                &format!("closed {}", result["closed"].as_str().unwrap_or_default()),
                &result,
            );
            0
        }
        other => refuse(&format!("unknown action {other}\n{USAGE}")),
    }
}
