//! Where imported bundles live, the index beside them, the lock that keeps
//! two imports apart, and the listing a caller reads back.
//!
//! Split out of `policy_bundle.rs`, which had grown past the
//! three-hundred-line limit; importing stays in the module root.

use std::fs::{self, OpenOptions};
use std::path::{Path, PathBuf};
use std::time::{SystemTime, UNIX_EPOCH};

use crate::{err, Result};

use super::records::{PolicyBundleIndex, PolicyBundleList, PolicyBundleSummary};
use super::INDEX_SCHEMA;

pub fn policy_bundle_store(home: Option<&Path>) -> Result<PathBuf> {
    if let Some(home) = home {
        if !home.is_dir() {
            return Err(err(format!(
                "Tama home is not a directory: {}",
                home.display()
            )));
        }
        #[cfg(target_os = "macos")]
        return Ok(home.join("Library/Application Support/Tama/policy-bundles"));
        #[cfg(target_os = "windows")]
        return Ok(home.join("AppData/Local/Tama/policy-bundles"));
        #[cfg(not(any(target_os = "macos", target_os = "windows")))]
        return Ok(home.join(".local/share/tama/policy-bundles"));
    }

    #[cfg(target_os = "windows")]
    if let Ok(root) = std::env::var("LOCALAPPDATA") {
        if !root.trim().is_empty() {
            return Ok(PathBuf::from(root).join("Tama/policy-bundles"));
        }
    }
    #[cfg(not(target_os = "windows"))]
    if let Ok(root) = std::env::var("XDG_DATA_HOME") {
        if !root.trim().is_empty() {
            return Ok(PathBuf::from(root).join("tama/policy-bundles"));
        }
    }
    let home = std::env::var("HOME")
        .map_err(|_| err("HOME is required to locate Tama's policy-bundle store"))?;
    policy_bundle_store(Some(Path::new(&home)))
}

pub(super) fn index_path(store: &Path) -> PathBuf {
    store.join("index.json")
}

pub(super) fn empty_index() -> PolicyBundleIndex {
    PolicyBundleIndex {
        schema: INDEX_SCHEMA.to_string(),
        bundles: Vec::new(),
    }
}

pub(super) fn read_index(store: &Path) -> Result<PolicyBundleIndex> {
    let path = index_path(store);
    if !path.exists() {
        return Ok(empty_index());
    }
    let metadata = fs::symlink_metadata(&path)?;
    if metadata.file_type().is_symlink() || !metadata.is_file() {
        return Err(err(format!(
            "Tama policy-bundle index is not a regular file: {}",
            path.display()
        )));
    }
    let index: PolicyBundleIndex = serde_json::from_slice(&fs::read(&path)?)?;
    if index.schema != INDEX_SCHEMA {
        return Err(err(format!(
            "unsupported Tama policy-bundle index: {}",
            path.display()
        )));
    }
    Ok(index)
}

pub(super) struct StoreLock(PathBuf);

impl Drop for StoreLock {
    fn drop(&mut self) {
        let _ = fs::remove_file(&self.0);
    }
}

pub(super) fn lock_store(store: &Path) -> Result<StoreLock> {
    fs::create_dir_all(store)?;
    let path = store.join(".import.lock");
    OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(&path)
        .map_err(|error| {
            err(format!(
                "another Tama policy-bundle import is active ({}): {error}",
                path.display()
            ))
        })?;
    Ok(StoreLock(path))
}

pub(super) fn timestamp() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}

pub(super) fn transaction_id() -> String {
    format!("{}-{}", std::process::id(), timestamp())
}

pub fn list_policy_bundles(home: Option<&Path>) -> Result<PolicyBundleList> {
    let store = policy_bundle_store(home)?;
    let index = read_index(&store)?;
    Ok(PolicyBundleList {
        schema: INDEX_SCHEMA.to_string(),
        store_path: store.display().to_string(),
        bundles: index
            .bundles
            .into_iter()
            .map(|bundle| PolicyBundleSummary {
                source_key: bundle.source_key,
                source_path: bundle.source_path,
                source_digest: bundle.source_digest,
                bundle_path: bundle.bundle_path,
                imported_at_unix: bundle.imported_at_unix,
                hook_count: bundle.hook_count,
                file_count: bundle.files.len(),
                activation: bundle.activation,
            })
            .collect(),
    })
}
