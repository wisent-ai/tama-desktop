//! Who Tama is to Brama, and where Brama answers for this machine.
//!
//! This file used to name four things in the vault: the item holding a
//! bearer, the field inside it, the consumer allowed to read it, and the
//! token file that read grant needs. Four names for one relationship, none
//! of them verifiable from here: a rename or a rotation anywhere else turned
//! into an unexplained 401, and the code could not say which of the four was
//! wrong.
//!
//! Brama does not want a stored secret. It introspects the presented bearer
//! at Skarbiec and reads the answer: `consumer` is the client, `audience` the
//! agent, and the `call:brama#<route>` grants are the routes that client may
//! ask for. So the durable identity is the consumer, and the credential is a
//! Skarbiec-issued token for it — minted, expiring, revocable at the
//! authority, and carrying its own permissions. Two facts live here now: our
//! consumer name, and which local adapter carries the hop.

use std::path::PathBuf;
use std::process::{Command, Stdio};

/// Our identity at the gateway. Skarbiec mints the token for this consumer
/// and Brama learns the client id from introspecting it.
const DEFAULT_CONSUMER: &str = "tama";
/// Which declared resolver adapter carries the local hop. The fleet declares
/// one adapter per consumer, and a consumer reads its own: reading the
/// adapter declared for a person at a keyboard would move Tama whenever the
/// fleet moved or withdrew that adapter, without a word in Tama's own
/// declaration.
const DEFAULT_ADAPTER_CONSUMER: &str = DEFAULT_CONSUMER;
/// The route the reviewer asks Brama for. `best` is Brama's own selector: the
/// gateway picks the strongest subscription-backed model behind it.
///
/// A route name is a bare word: a leading dash is not a Brama route, and a
/// grant minted to match a misspelt route makes both halves agree on a
/// route the gateway does not serve, so every refusal looks like a
/// credential problem.
const DEFAULT_MODEL_ROUTE: &str = "best";
/// The loopback name a plaintext chat endpoint may use; a loopback address
/// is recognised by the address itself.
const LOOPBACK_NAME: &str = "localhost";
/// The variables that override, in order, where Brama answers.
const ROUTER_URL_VARIABLES: &[&str] = &[
    "TAMA_OBJECTIVE_AUTHORITY_MODEL_ROUTER_URL",
    "STADO_MODEL_ROUTER_URL",
    "BRAMA_URL",
];

pub struct Credentials {
    pub endpoint: String,
    pub bearer: String,
    /// The relay this process owns when the endpoint is one it opened
    /// itself because this machine's resolver handed out no route; it ends
    /// when the credentials are dropped, after the request they served.
    pub relay: Option<super::relay::Relay>,
}

pub(super) fn home_dir() -> PathBuf {
    crate::util::home_dir()
}

/// Our consumer at Skarbiec and Brama: `TAMA_BRAMA_CONSUMER`, else the one
/// declared here. A variable that cannot be read is the error naming it.
pub fn consumer() -> Result<String, String> {
    tama_core::setting::or_declared("TAMA_BRAMA_CONSUMER", DEFAULT_CONSUMER)
}

/// Which Brama route this machine asks for, and whether the name is one a
/// gateway could serve at all.
pub fn model_route() -> Result<String, String> {
    if let Some(found) = super::declared::declared_provider()? {
        return Ok(found.model);
    }
    let route = tama_core::setting::or_declared(
        "TAMA_OBJECTIVE_AUTHORITY_MODEL_ROUTE",
        DEFAULT_MODEL_ROUTE,
    )?;
    if route.chars().any(char::is_whitespace) {
        return Err(format!("{route:?} is not a usable Brama route"));
    }
    Ok(route)
}

/// What this machine's own authority says about our token: does the consumer
/// hold `call:brama#<route>` on the bearer in the token file.
///
/// This is the half that can be answered locally, and it is the half that
/// separates a missing grant here from a gateway that asks a different
/// authority. Nothing else on this machine made that distinction, so one
/// unexplained `401` stood for both.
pub fn local_grant(route: &str) -> Result<bool, String> {
    let skarbiec = crate::assignment::rules::product_cli("skarbiec")?;
    let mut command = Command::new(skarbiec);
    command
        .args(["grant", "verify", &consumer()?, "brama"])
        .args(["--action", "call", "--field", route])
        .arg("--token-file")
        .arg(token_path()?)
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped());
    let output = stado_wait::output(&mut command)
        .map_err(|error| format!("cannot ask this machine's authority: {error}"))?;
    let text = String::from_utf8_lossy(&output.stdout).to_string();
    let answer: serde_json::Value = serde_json::from_str(&text).map_err(|error| {
        let refusal = String::from_utf8_lossy(&output.stderr).trim().to_string();
        if refusal.is_empty() {
            format!(
                "this machine's authority gave no answer ({}): {error}",
                output.status
            )
        } else {
            refusal
        }
    })?;
    // An answer without its verdict says nothing about the grant: read as a
    // refusal it sent the operator to mint a grant he may already hold.
    answer
        .get("allowed")
        .and_then(serde_json::Value::as_bool)
        .ok_or_else(|| format!("this machine's authority answered without saying whether the grant is allowed: {text}"))
}

/// The owner-only file holding this consumer's Skarbiec token. The path is
/// the fleet's own convention, derived from the consumer, so nothing has to
/// be configured twice.
pub fn token_path() -> Result<PathBuf, String> {
    if let Some(path) = tama_core::path_variable("TAMA_BRAMA_TOKEN_FILE") {
        return Ok(path);
    }
    Ok(home_dir()
        .join(".stado")
        .join(format!("{}-skarbiec-token", consumer()?)))
}

/// A chat endpoint we will post to: no query, no fragment, no embedded
/// credentials, and plaintext only on loopback.
pub fn allowed_endpoint(endpoint: &str) -> bool {
    if endpoint.contains(['?', '#']) {
        return false;
    }
    let Some((scheme, remainder)) = endpoint.split_once("://") else {
        return false;
    };
    let Some((authority, path)) = remainder.split_once('/') else {
        return false;
    };
    if authority.is_empty() || authority.contains('@') || path != "v1/chat/completions" {
        return false;
    }
    if scheme == "https" {
        return true;
    }
    if scheme != "http" {
        return false;
    }
    // The host is the bracketed address of an IPv6 authority, else what
    // stands before the port; plaintext is allowed only where the address
    // itself says loopback, or for the loopback name.
    let host = match authority.strip_prefix('[') {
        Some(bracketed) => match bracketed.split_once(']') {
            Some((host, _)) => host,
            None => return false,
        },
        None => match authority.split_once(':') {
            Some((host, _)) => host,
            None => authority,
        },
    };
    host == LOOPBACK_NAME
        || host
            .parse::<std::net::IpAddr>()
            .is_ok_and(|address| address.is_loopback())
}

/// Reads the token, and refuses with the exact repair when it is not there:
/// the consumer, the path, and the command that mints one.
fn read_token() -> Result<String, String> {
    let path = token_path()?;
    let consumer = consumer()?;
    let shown = path.display();
    let text = std::fs::read_to_string(&path).map_err(|error| {
        if error.kind() == std::io::ErrorKind::NotFound {
            format!(
                "no Brama token for consumer {consumer} at {shown}: {error}; \
                 issue one with `skarbiec grant issue {consumer} --capabilities call:brama#<route> --token-file {shown}`"
            )
        } else {
            format!("cannot read Brama token for consumer {consumer} at {shown}: {error}")
        }
    })?;
    let token = text.trim().to_string();
    if token.is_empty() {
        return Err(format!(
            "the Brama token file for consumer {consumer} at {shown} is empty"
        ));
    }
    if token.chars().any(|character| {
        character.is_whitespace() || character.is_control() || !character.is_ascii()
    }) {
        return Err(format!(
            "the Brama token file for consumer {consumer} at {shown} does not hold one token"
        ));
    }
    Ok(token)
}

/// Where Brama answers for this machine.
///
/// The env overrides come first, then the fleet's own answer. Asking Stado is
/// the documented contract: Brama binds loopback on the host it is placed on,
/// every other machine reaches it through a declared resolver adapter, and the
/// address is therefore different on every machine. No hostname is built in;
/// discovery failure preserves the actual operation and cause.
fn model_router_endpoint() -> Result<(String, Option<super::relay::Relay>), String> {
    let mut declared = None;
    for name in ROUTER_URL_VARIABLES {
        if let Some(value) = tama_core::setting::given(name)? {
            declared = Some(value);
            break;
        }
    }
    let (base, relay) = match declared {
        Some(base) => (base, None),
        None => super::route::fleet_route()?,
    };
    Ok((router_endpoint(&base)?, relay))
}

pub(super) fn router_endpoint(base: &str) -> Result<String, String> {
    let remainder = base
        .strip_prefix("https://")
        .or_else(|| base.strip_prefix("http://"))
        .ok_or_else(|| "Brama URL must be HTTP or HTTPS".to_string())?;
    let authority = match remainder.split_once('/') {
        Some((authority, _)) => authority,
        None => remainder,
    };
    if authority.is_empty() || authority.contains('@') || base.contains(['?', '#']) {
        return Err("Brama URL must not contain credentials, a query, or a fragment".to_string());
    }
    let base = base.trim_end_matches('/');
    if base.ends_with("/v1/chat/completions") {
        Ok(base.to_string())
    } else {
        Ok(format!("{base}/v1/chat/completions"))
    }
}

/// The adapter that carries the hop from this machine, named by the fleet:
/// `TAMA_BRAMA_ADAPTER_CONSUMER`, else the one declared here.
pub fn adapter_consumer() -> Result<String, String> {
    tama_core::setting::or_declared("TAMA_BRAMA_ADAPTER_CONSUMER", DEFAULT_ADAPTER_CONSUMER)
}

/// The endpoint and the token, read fresh on every call so a rotated or
/// re-minted token is picked up without a restart. A provider declared with
/// `tama model set` is asked instead of Brama, with its own key.
pub fn read() -> Result<Credentials, String> {
    if let Some(found) = super::declared::declared_provider()? {
        return Ok(Credentials {
            endpoint: format!("{}/v1/chat/completions", found.origin.trim_end_matches('/')),
            bearer: found.key,
            relay: None,
        });
    }
    let (endpoint, relay) = model_router_endpoint()?;
    Ok(Credentials {
        endpoint,
        bearer: read_token()?,
        relay,
    })
}
