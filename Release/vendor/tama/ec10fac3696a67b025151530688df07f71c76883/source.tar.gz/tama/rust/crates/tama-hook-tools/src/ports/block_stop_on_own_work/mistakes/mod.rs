//! What the turn did, read from the structure of the calls it made
//! (`transcript::calls`: a tool that changes files, a `git commit`, an `oko
//! defects record`), and the endings that are wrong by structure alone. What
//! the answer itself says is not read here: the answer carries its turn-end
//! attestation, which the gate reads word for word
//! (`task_attestation::verbatim`).
//!
//! * A turn that recorded a defect and changed no source: recording starts
//!   the repair instead of ending the work.
//! * An ending that restates an earlier answer, or a report the operator
//!   already saw in this turn.

use super::transcript::Transcript;

/// A defect recorded and no source changed for it.
pub(super) fn recorded_without_repair(transcript: &Transcript) -> Option<String> {
    if !transcript.recorded_defect || transcript.changed_source {
        return None;
    }
    Some(
        "block-stop-on-own-work: BLOCKED: this turn recorded a defect and changed no source for \
         it. Recording starts the repair: write the change, commit, push and hand it off before \
         answering."
            .to_string(),
    )
}

/// The status report an earlier answer already gave, given again word for
/// word by a turn that changed no source: the answer is the report, not the
/// work.
pub(super) fn restated_ending(transcript: &Transcript) -> Option<String> {
    if transcript.changed_source {
        return None;
    }
    super::repeat::repeated(&transcript.final_message, &transcript.earlier_endings)?;
    Some(
        "block-stop-on-own-work: BLOCKED: this ending restates, word for word, an answer \
         already given, and this turn changed no source. Take the next open task from \
         `oko tasks --session <ID>` and work on it; end only when it moved."
            .to_string(),
    )
}

/// A report the operator already saw in this turn — every ending a stop
/// guard refused was displayed before the refusal — given to him again. One
/// operator message gets one report; a refusal is answered with tool calls.
pub(super) fn report_shown_again(transcript: &Transcript) -> Option<String> {
    super::repeat::repeated(&transcript.final_message, &transcript.refused_endings)?;
    Some(
        "block-stop-on-own-work: BLOCKED: the operator already saw this report, word for word, \
         in this turn. Answer the refusal with work, not with another report; the one report \
         comes when the work it describes is done."
            .to_string(),
    )
}
