//! Logic for `tama hook block-idle-answer`, registry hook id
//! `block-idle-answer`.
//!
//! A Stop gate. When a stop gate refused the agent's ending and sent it back
//! to work, or the text gate cut its answer off and started the next turn,
//! the agent's next answer must come after work. An ending with no work in
//! between, whether it restates that nothing changed or carries only its own
//! reasoning ("Staying quiet for now"), is refused. Work is what the session's
//! look ledger (`block_wait_polling::repeat`) counts: a call that changes
//! files or commits, or a look not made since the last change. A call that
//! repeats a look already answered since then bought nothing and is not
//! work, so polling the same state cannot buy an ending.
//!
//! The decision is the transcript's shape, never its words: the newest
//! record that addressed the agent is the harness's stop continuation, and
//! no assistant record after it did work. An operator's own message resets
//! this, so a question he asks can still be answered in words.
//!
//! Transcript shape (`~/.omp/agent/sessions/**/*.jsonl`, one JSON object per
//! line): a message is `{ type: "message", message: { role, content: [...] } }`
//! and a tool call is a content item of type `toolCall` (OMP) or `tool_use`
//! (Claude Code); a stop gate's refusal is `{ type: "custom_message",
//! customType: "session-stop-continuation" }`, or a user-role message with
//! `attribution: "agent"`.

use std::path::PathBuf;

use serde_json::Value;
use tama_hooks::session_record::{
    deny, read_payload, refusal_once, session_id_of, transcript_path,
};

const TAG: &str = "block-idle-answer";
const TRANSCRIPT_PATH_KEY: &str = "transcript_path";
const MESSAGE_KEY: &str = "message";
const ROLE_KEY: &str = "role";
const CONTENT_KEY: &str = "content";
const TYPE_KEY: &str = "type";
/// Claude Code's block that carries a tool result back in a user record.
const TOOL_RESULT_BLOCK: &str = "tool_result";
const CUSTOM_TYPE_KEY: &str = "customType";
const STOP_CONTINUATION: &str = "session-stop-continuation";
/// The record the OMP adapter writes when the text gate cut an answer off
/// and started the next turn (`shared-hooks/omp/surface/handlers.mjs`,
/// `TEXT_CUT_TYPE`): it sends the agent back to work as a stop refusal does.
const TEXT_CUT: &str = "tama-text-cut";
const ATTRIBUTION_KEY: &str = "attribution";
const AGENT_ATTRIBUTION: &str = "agent";
const USER_ROLE: &str = "user";
const ASSISTANT_ROLE: &str = "assistant";

const REFUSAL: &str = "this answer comes straight after a stop gate sent you back to work, and \
no tool call happened in between: it reports that nothing changed instead of changing something. \
Delete it. Take the next open task or defect and work on it with tool calls; answer only with \
what that work produced.";
/// The one item named when the refusal is already held: the session's own
/// owed tasks, then the register of defects.
const NEXT: &str = "`oko tasks owed`, then `oko defects list`";

fn log(text: &str) {
    eprintln!("{TAG}: {text}");
}

/// The transcript the payload names, or the newest one of its session.
pub(crate) fn locate(payload: &Value) -> Option<PathBuf> {
    if let Some(path) = payload.get(TRANSCRIPT_PATH_KEY).and_then(Value::as_str) {
        if !path.is_empty() {
            return Some(PathBuf::from(path));
        }
    }
    transcript_path(&session_id_of(payload))
}

/// Whether the turn ending now did no work after a stop gate sent the agent
/// back: the newest record addressed to the agent is that refusal, and no
/// assistant record after it did work by the look ledger's count. A complete
/// line that is no record refuses the reading with its cause.
pub(crate) fn idle_after_refusal(raw: &str) -> Result<bool, String> {
    let mut ledger = crate::ports::block_wait_polling::repeat::Ledger::default();
    let mut sent_back = false;
    let mut worked = false;
    for record in tama_hooks::jsonl::records(raw)?.values {
        let custom = record.get(CUSTOM_TYPE_KEY).and_then(Value::as_str);
        if custom == Some(STOP_CONTINUATION) || custom == Some(TEXT_CUT) {
            sent_back = true;
            worked = false;
            continue;
        }
        let did = ledger.feed(&record);
        let Some(message) = record.get(MESSAGE_KEY) else {
            continue;
        };
        match message.get(ROLE_KEY).and_then(Value::as_str) {
            Some(USER_ROLE) if !carries_results(message) => {
                let attribution = message.get(ATTRIBUTION_KEY).and_then(Value::as_str);
                sent_back = attribution == Some(AGENT_ATTRIBUTION);
                worked = false;
            }
            Some(ASSISTANT_ROLE) if did => worked = true,
            _ => {}
        }
    }
    Ok(sent_back && !worked)
}

/// Whether a user-role record only carries tool results back (Claude Code's
/// shape), which nobody wrote to the agent.
fn carries_results(message: &Value) -> bool {
    message
        .get(CONTENT_KEY)
        .and_then(Value::as_array)
        .is_some_and(|items| {
            items
                .iter()
                .any(|item| item.get(TYPE_KEY).and_then(Value::as_str) == Some(TOOL_RESULT_BLOCK))
        })
}

/// The refusal, or nothing. An idle answer is admitted when Oko's register
/// answers that every open defect already carries a recorded repair: no item
/// is left to change in source, only the held build remains, and refusing
/// would loop the session against the gate forbidding text. A refusal the
/// session already holds since the operator's last message is given as one
/// line, so a session that ends idle again and again does not read, and the
/// operator does not see, the same paragraph every time; the turn stays held
/// for as long as the answer is idle.
pub fn check(payload: &Value) -> Option<String> {
    let Some(path) = locate(payload) else {
        log("no transcript for this session; nothing to judge");
        return None;
    };
    let judged = std::fs::read_to_string(&path)
        .map_err(|error| format!("cannot read {}: {error}", path.display()))
        .and_then(|raw| {
            idle_after_refusal(&raw)
                .map_err(|cause| format!("cannot read {} as records: {cause}", path.display()))
        });
    match judged {
        Ok(idle) => (idle && !crate::ports::block_stop_on_own_work::every_open_defect_repaired())
            .then(|| {
                refusal_once(
                    payload,
                    &session_id_of(payload),
                    format!("{TAG}: {REFUSAL}"),
                    NEXT,
                )
            }),
        Err(cause) => {
            log(&cause);
            None
        }
    }
}

pub fn run() {
    let payload = read_payload();
    if let Some(problem) = check(&payload) {
        deny(problem);
    }
}
