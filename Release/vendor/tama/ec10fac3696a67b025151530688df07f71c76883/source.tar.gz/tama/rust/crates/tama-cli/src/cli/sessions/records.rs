//! The session records `tama sessions` lists: one row per
//! `*.session.json` in the session-control directory.
//!
//! A directory that exists and cannot be listed is refused with its cause;
//! a record that cannot be read or parsed stays a row that carries the
//! cause, so one broken file neither hides the others nor disappears.

use std::path::{Path, PathBuf};

use serde_json::{json, Value};

/// Every record under `control_dir`, in path order. A missing directory
/// means no session has published itself, so it lists nothing.
pub(super) fn load(control_dir: &Path) -> Result<Vec<Value>, String> {
    let listed = match std::fs::read_dir(control_dir) {
        Ok(rd) => rd
            .map(|e| e.map(|e| e.path()))
            .collect::<Result<Vec<PathBuf>, _>>(),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(Vec::new()),
        Err(error) => Err(error),
    };
    let listed =
        listed.map_err(|error| format!("cannot list {}: {error}", control_dir.display()))?;
    let mut entries: Vec<PathBuf> = listed
        .into_iter()
        .filter(|p| p.to_string_lossy().ends_with(".session.json"))
        .collect();
    entries.sort();
    Ok(entries.iter().map(|path| row(path)).collect())
}

fn row(path: &Path) -> Value {
    let text = match std::fs::read_to_string(path) {
        Ok(text) => text,
        Err(error) => {
            return json!({ "sessionId": path.display().to_string(), "readError": error.to_string() })
        }
    };
    let raw = match serde_json::from_str::<Value>(&text) {
        Ok(raw) => raw,
        Err(error) => {
            return json!({ "sessionId": path.display().to_string(), "parseError": error.to_string() })
        }
    };
    let runtime = raw.get("runtime");
    let pid = raw.get("pid").and_then(Value::as_u64);
    // A pid whose process the kernel will not describe to this user is
    // another user's: the gates read the record as naming no live agent, and
    // the row says so instead of counting it a running session.
    let read = pid
        .map(|pid| Ok::<_, String>((super::running(pid)?, super::refused(pid)?)))
        .transpose();
    let (process_alive, process_refused) = match read {
        Ok(Some((alive, refused))) => (Some(alive), Some(refused)),
        Ok(None) => (None, None),
        Err(error) => {
            return json!({
                "sessionId": raw.get("sessionId"),
                "pid": pid,
                "readError": error,
            });
        }
    };
    json!({
        "sessionId": raw.get("sessionId"),
        "agentId": raw.get("agentId"),
        "cwd": raw.get("cwd"),
        "status": raw.get("status"),
        "pid": raw.get("pid"),
        "livenessMode": raw.get("livenessMode"),
        "processAlive": process_alive,
        "processRecordRefused": process_refused,
        "runtimeReported": runtime.is_some(),
        "globallyDisabled": runtime.and_then(|r| r.get("globallyDisabled")),
        "loadedHookCount": runtime.and_then(|r| r.get("loadedHookCount")),
        "registeredHookCount": runtime.and_then(|r| r.get("registeredHookCount")),
        "adapterDigest": runtime.and_then(|r| r.get("adapterDigest")),
        "adapterReloadSupported": runtime.and_then(|r| r.get("adapterReloadSupported")),
        "lastReloadError": runtime.and_then(|r| r.get("lastReloadError")),
        "enabledHookIds": runtime.and_then(|r| r.get("enabledHookIds")),
        "disabledHookIds": runtime.and_then(|r| r.get("disabledHookIds")),
        "updatedAt": raw.get("updatedAt"),
    })
}
