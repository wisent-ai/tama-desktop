//! The request handlers for the copies command group.
//!
//! Everything here reads a request body for one command group and answers
//! with that group's document; the dispatch in `routes.rs` only chooses
//! handlers. Statuses are HTTP's own (`http::StatusCode`).
//!
//! Both handlers answer with exactly the document the command prints under
//! `--json`, refusals included: the desktop screen and the terminal must not
//! be able to disagree about what a pass would do.

use http::StatusCode;
use serde_json::Value;

use crate::copies::CommandError;

use super::reply::{json_body, send_error, send_json, Reply, Request};

const OK: u16 = StatusCode::OK.as_u16();
const BAD_REQUEST: u16 = StatusCode::BAD_REQUEST.as_u16();
const SERVER_ERROR: u16 = StatusCode::INTERNAL_SERVER_ERROR.as_u16();

fn send_command_error(writer: &mut Reply, error: CommandError) {
    let status = match &error {
        CommandError::MissingRoot
        | CommandError::UnknownExcept(_)
        | CommandError::UnknownOnly(_) => BAD_REQUEST,
        CommandError::Refused(_) | CommandError::Operational(_) => SERVER_ERROR,
    };
    send_error(writer, status, &error.to_string());
}

/// The `roots` array both operations take, with the copies command's own
/// missing-root sentence: the two checkout groups name different commands, so
/// a client is told which one refused it.
fn roots_of(body: &Value) -> Result<Vec<String>, String> {
    let roots = string_array(body, "roots")?;
    if roots.is_empty() {
        return Err(crate::copies::MISSING_ROOT.to_string());
    }
    Ok(roots)
}

/// Every string of one array field; an absent field is an empty list, so a
/// client built before a field existed keeps working. A field that is not a
/// list of strings is refused naming it: read as empty, an `except` sent as
/// one string would spare nothing in a removal. An empty path is refused
/// too: dropped, the list acted on would not be the one the caller sent.
fn string_array(body: &Value, name: &str) -> Result<Vec<String>, String> {
    let Some(field) = body.get(name) else {
        return Ok(Vec::new());
    };
    let values = field
        .as_array()
        .ok_or_else(|| format!("{name} must be a list of paths, not {field}"))?;
    let mut found = Vec::new();
    for value in values {
        let text = value
            .as_str()
            .ok_or_else(|| format!("{name} must hold only paths as strings, not {value}"))?;
        if text.is_empty() {
            return Err(format!(
                "{name} holds an empty path, which names nothing to keep or remove"
            ));
        }
        found.push(text.to_string());
    }
    Ok(found)
}

/// A switch the request may set; absent is off, anything but a boolean is
/// refused naming it, since a `"true"` read as off would hide the request.
fn switch(body: &Value, name: &str) -> Result<bool, String> {
    match body.get(name) {
        None => Ok(false),
        Some(Value::Bool(set)) => Ok(*set),
        Some(other) => Err(format!("{name} must be true or false, not {other}")),
    }
}

/// `tama copies list --root <PATH>... --json` as a desktop request: the desktop
/// screen shows which second full checkouts exist before offering to remove
/// them.
pub(super) fn list(request: Request, writer: &mut Reply) {
    let body = match json_body(&request) {
        Ok(body) => body,
        Err((status, message)) => return send_error(writer, status, &message),
    };
    let roots = match roots_of(&body) {
        Ok(roots) => roots,
        Err(message) => return send_error(writer, BAD_REQUEST, &message),
    };
    match crate::copies::list_document(&roots, &[]) {
        Ok(document) => send_json(writer, OK, &tama_core::json::value(&document)),
        Err(error) => send_command_error(writer, error),
    }
}

/// `tama copies remove ... --json`. A refused pass is not a transport
/// failure: the document carries `applied: false` plus every refusal, exactly
/// as the command reports them.
pub(super) fn remove(request: Request, writer: &mut Reply) {
    let body = match json_body(&request) {
        Ok(body) => body,
        Err((status, message)) => return send_error(writer, status, &message),
    };
    let roots = match roots_of(&body) {
        Ok(roots) => roots,
        Err(message) => return send_error(writer, BAD_REQUEST, &message),
    };
    let fields = (|| -> Result<_, String> {
        Ok((
            string_array(&body, "except")?,
            string_array(&body, "only")?,
            switch(&body, "apply")?,
            switch(&body, "force")?,
        ))
    })();
    let (except, only, apply, force) = match fields {
        Ok(fields) => fields,
        Err(message) => return send_error(writer, BAD_REQUEST, &message),
    };
    // Sparing paths and narrowing to paths are two answers to one question,
    // exactly as on the command line, so a body carrying both is refused
    // rather than silently resolved one way.
    if !except.is_empty() && !only.is_empty() {
        return send_error(
            writer,
            BAD_REQUEST,
            "except and only cannot be combined: narrow the pass or spare paths in it, not both",
        );
    }
    match crate::copies::remove_document(&roots, &except, &only, apply, force) {
        Ok(document) => send_json(writer, OK, &tama_core::json::value(&document)),
        Err(error) => send_command_error(writer, error),
    }
}
