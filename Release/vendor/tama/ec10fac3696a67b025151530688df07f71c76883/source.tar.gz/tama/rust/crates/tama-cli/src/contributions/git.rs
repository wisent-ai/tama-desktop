//! What the reporter asks of other programs: git for the commits that reached
//! a remote branch and who wrote them, this Tama for whether a commit's
//! attestation stands, Stado for the reporter's bearer, and the HTTP client
//! Tama already uses for the ledger. Each answer that is not what was asked
//! for is refused with the program's own words.

use std::io::Write;
use std::path::Path;
use std::process::{Command, Stdio};

use serde_json::Value;

/// The commits reachable from `reference` and not from `since`, oldest first.
pub(super) fn reached(
    repository: &Path,
    reference: &str,
    since: Option<&str>,
) -> Result<Vec<String>, String> {
    let excluded = since.map(|since| format!("^{since}"));
    let mut arguments = vec!["rev-list", "--reverse", reference];
    if let Some(excluded) = &excluded {
        arguments.push(excluded);
    }
    let listed = crate::gitcmd::git(repository, &arguments)?;
    let mut commits = Vec::new();
    for line in listed.lines().map(str::trim) {
        if !line.is_empty() {
            commits.push(line.to_string());
        }
    }
    Ok(commits)
}

/// `tama attestation check` of `commit`, run as this very program so the
/// reporter reads the attestation exactly as review-push does.
pub(super) fn attestation(repository: &Path, commit: &str) -> Result<Value, String> {
    let program = match std::env::current_exe() {
        Ok(program) => program,
        Err(error) => return Err(format!("this Tama cannot name its own program: {error}")),
    };
    let mut command = Command::new(program);
    command
        .args(["attestation", "check", "--commit", commit])
        .arg("--repository")
        .arg(repository)
        .arg("--json")
        .stdin(Stdio::null());
    let output = stado_wait::output(&mut command)
        .map_err(|error| format!("tama attestation check of {commit}: {error}"))?;
    serde_json::from_slice(&output.stdout).map_err(|error| {
        format!(
            "tama attestation check of {commit} answered no JSON ({error}): {}",
            String::from_utf8_lossy(&output.stderr).trim()
        )
    })
}

/// The commit's author email and committer time.
pub(super) fn author(repository: &Path, commit: &str) -> Result<(String, String), String> {
    let shown = crate::gitcmd::git(repository, &["log", "-1", "--format=%ae%x00%cI", commit])?;
    match shown.trim().split_once('\0') {
        Some((email, time)) if !email.is_empty() && !time.is_empty() => {
            Ok((email.to_string(), time.to_string()))
        }
        Some(_) | None => Err(format!(
            "git names no author email or commit time for {commit}: {shown:?}"
        )),
    }
}

/// The reporter's bearer: the field of the item playing `role`, as
/// `stado credentials get` reads it.
pub(super) fn bearer(role: &str, field: &str) -> Result<String, String> {
    let mut command = Command::new("stado");
    command
        .args(["credentials", "get", "--role", role, "--field", field])
        .stdin(Stdio::null());
    let output = stado_wait::output(&mut command)
        .map_err(|error| format!("stado credentials get --role {role} --field {field}: {error}"))?;
    let value = String::from_utf8_lossy(&output.stdout).trim().to_string();
    if !output.status.success() || value.is_empty() {
        return Err(format!(
            "stado credentials get --role {role} --field {field} gave no bearer ({}): {}",
            output.status,
            String::from_utf8_lossy(&output.stderr).trim()
        ));
    }
    Ok(value)
}

/// A string as curl's configuration file quotes it.
fn quoted(text: &str) -> String {
    format!("\"{}\"", text.replace('\\', "\\\\").replace('"', "\\\""))
}

/// One request to the ledger: where it goes, as whom, and what it carries.
pub(super) struct Request<'a> {
    pub(super) client: &'a str,
    pub(super) ledger: &'a str,
    pub(super) route: &'a str,
    pub(super) bearer: &'a str,
    pub(super) product: &'a str,
}

/// The configuration the client reads on its standard input: the bearer and
/// the body never reach its command line, where every process on the
/// machine could read them.
fn configuration(request: &Request<'_>, target: &str, body: &Value) -> String {
    let authorization = format!("Authorization: Bearer {}", request.bearer);
    let reporter = format!("x-wisent-reporter: {}", request.product);
    let lines = [
        format!("url = {}", quoted(target)),
        "request = \"POST\"".to_string(),
        format!("header = {}", quoted(&authorization)),
        format!("header = {}", quoted(&reporter)),
        "header = \"Content-Type: application/json\"".to_string(),
        format!("data-binary = {}", quoted(&body.to_string())),
    ];
    lines.iter().map(|line| format!("{line}\n")).collect()
}

/// Why a POST did not answer a document: the ledger refused it, in its own
/// answer, or the request never got an answer the ledger gave.
pub(super) enum Unposted {
    /// The ledger answered with a refusal: its sentence.
    Refused(String),
    /// No answer of the ledger came back: what the request met.
    Unanswered(String),
}

impl std::fmt::Display for Unposted {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Unposted::Refused(sentence) | Unposted::Unanswered(sentence) => {
                formatter.write_str(sentence)
            }
        }
    }
}

/// POST `body` as `request` says. With `--fail-with-body` a refusal ends the
/// client unsuccessfully with the ledger's answer, whose sentence is the
/// refusal; every other way the request can end is no answer.
pub(super) fn post(request: &Request<'_>, body: &Value) -> Result<Value, Unposted> {
    let client = request.client;
    let target = format!("{}{}", request.ledger, request.route);
    let unanswered = Unposted::Unanswered;
    let mut child = Command::new(client)
        .args(["--disable", "--silent", "--show-error"])
        .args(["--fail-with-body", "--config", "-"])
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .map_err(|error| unanswered(format!("cannot start {client} for POST {target}: {error}")))?;
    let Some(mut input) = child.stdin.take() else {
        return Err(unanswered(format!("{client} took no standard input")));
    };
    input
        .write_all(configuration(request, &target, body).as_bytes())
        .map_err(|error| {
            unanswered(format!(
                "cannot hand {client} the request for POST {target}: {error}"
            ))
        })?;
    drop(input);
    let output = stado_wait::child_output(child, format!("POST {target}"))
        .map_err(|error| unanswered(format!("POST {target}: {error}")))?;
    let body = String::from_utf8_lossy(&output.stdout).to_string();
    let answer: Result<Value, _> = serde_json::from_str(&body);
    match (output.status.success(), answer) {
        (true, Ok(answer)) => Ok(answer),
        (true, Err(error)) => Err(unanswered(format!(
            "POST {target} answered no JSON ({error}): {body}"
        ))),
        (false, Ok(refusal)) => {
            let sentence = refusal.pointer("/error/message").and_then(Value::as_str);
            Err(Unposted::Refused(match sentence {
                Some(message) => message.to_string(),
                None => format!("POST {target} refused: {refusal}"),
            }))
        }
        (false, Err(_)) => Err(unanswered(format!(
            "POST {target} failed ({}): {} {body}",
            output.status,
            String::from_utf8_lossy(&output.stderr).trim()
        ))),
    }
}
