//! Finding word lists in code: a run of quoted words, an alternation
//! inside one literal, and the question of whether the program keeps it.
//!
//! Split out of `block_keyword_literals/mod.rs`, which had grown past the
//! three-hundred-line limit; which file is read at all is in `text.rs`.

use std::sync::LazyLock;

use regex::Regex;

use super::super::transport_common as common;
use super::is_list;

mod kept;
mod regex_literals;
mod selectors;

use kept::kept_or_consulted;

pub(super) use regex_literals::applies as is_script;

/// One quoted literal, in the quoting a code file may use; its content is the
/// `double` or `single` group.
static LITERAL: LazyLock<Regex> = LazyLock::new(|| {
    common::compile("r?#?\"(?P<double>(?:[^\"\\\\]|\\\\.)*)\"#?|'(?P<single>(?:[^'\\\\]|\\\\.)*)'")
});
/// Between two members of one collection: a comma and whitespace, nothing else.
static SEPARATOR: LazyLock<Regex> = LazyLock::new(|| common::compile("^\\s*,\\s*$"));
/// Regex syntax that carries no letters of its own: quantifiers, escapes,
/// classes, anchors. Stripped before an alternative is read as a word. A
/// source file spells an escape with one backslash or, inside a string
/// literal, two, so both are read.
static REGEX_SYNTAX: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(
        "\\\\\\\\?[wsdbBAz]\\*?|\\\\\\\\?.|\\[[^\\]]*\\]|[?*+^$]|\\{[^}]*\\}|\\(\\?[a-z]+\\)",
    )
});
/// A word: letters, or several separated by single spaces.
static WORD: LazyLock<Regex> = LazyLock::new(|| common::compile("^\\p{L}{2,}( \\p{L}+)*$"));

/// A JSON Schema `"required": [ … ]` array, quoted plainly or, inside a
/// string literal of code, with escaped quotes.
static SCHEMA_REQUIRED: LazyLock<Regex> =
    LazyLock::new(|| common::compile("\\\\?\"required\\\\?\"\\s*:\\s*\\[[^\\[\\]]*\\]"));

/// True when the literal reads as a natural-language word or phrase.
pub(super) fn is_word(text: &str) -> bool {
    WORD.is_match(text.trim())
}

/// `text` with every JSON Schema `required` array blanked. Such an array
/// names the properties an object must carry, and its words are field names
/// a validator checks for presence; it decides nothing about input by
/// keyword. Blanking keeps every newline, so the lines a refusal names stay
/// true.
pub(super) fn without_schema_required(text: &str) -> String {
    SCHEMA_REQUIRED
        .replace_all(text, |found: &regex::Captures| {
            found
                .get_match()
                .as_str()
                .chars()
                .map(|character| if character == '\n' { '\n' } else { ' ' })
                .collect::<String>()
        })
        .into_owned()
}

/// Every collection of quoted words in `text`, as (line, words): quoted
/// literals separated only by commas and whitespace, two or more of
/// them, every one a word, and kept or consulted by the program.
pub(super) fn word_collections(text: &str) -> Vec<(usize, Vec<String>)> {
    quoted_runs(&without_schema_required(text), true)
}

/// The same runs in a data file, where every list is read by some program:
/// there is no call whose arguments it could be, so each one counts.
pub(super) fn data_collections(text: &str) -> Vec<(usize, Vec<String>)> {
    quoted_runs(&without_schema_required(text), false)
}

/// Where an open run of quoted words starts: its line and its offset.
type RunStart = Option<(usize, usize)>;

fn quoted_runs(text: &str, judge_use: bool) -> Vec<(usize, Vec<String>)> {
    let mut found = Vec::new();
    let mut run: Vec<String> = Vec::new();
    let mut run_start: RunStart = None;
    // Where the previous literal ended; none before the first one.
    let mut previous_end: Option<usize> = None;
    let close = |run: &mut Vec<String>,
                 at: RunStart,
                 end: Option<usize>,
                 found: &mut Vec<(usize, Vec<String>)>| {
        if let (Some((line, start)), Some(end)) = (at, end) {
            if is_list(run)
                && run.iter().all(|word| is_word(word))
                && (!judge_use
                    || (kept_or_consulted(text, start, end)
                        && !super::argv::argument_vector(text, start, end)
                        && !selectors::field_selectors(text, start, end)))
            {
                found.push((line, std::mem::take(run)));
            }
        }
        run.clear();
    };
    for literal in LITERAL.captures_iter(text) {
        let whole = literal.get_match();
        let body = match (literal.name("double"), literal.name("single")) {
            (Some(content), _) | (_, Some(content)) => content.as_str().to_owned(),
            (None, None) => {
                unreachable!("a quoted literal matches through its double or single group")
            }
        };
        let gap = match previous_end {
            Some(end) => &text[end..whole.start()],
            None => &text[..whole.start()],
        };
        // A key of an object or struct literal, or the value written after
        // one, is a field of a record: `{"role": "user", "content": prompt}`
        // names two fields, it does not list two words. Such a literal ends
        // the run and joins none.
        let field =
            gap.trim_end().ends_with(':') || text[whole.end()..].trim_start().starts_with(':');
        if field {
            close(&mut run, run_start, previous_end, &mut found);
            previous_end = Some(whole.end());
            continue;
        }
        if run.is_empty() || !SEPARATOR.is_match(gap) {
            close(&mut run, run_start, previous_end, &mut found);
            run_start = Some((line_of(text, whole.start()), whole.start()));
        }
        run.push(body);
        previous_end = Some(whole.end());
    }
    close(&mut run, run_start, previous_end, &mut found);
    found
}

/// Every alternation of words inside a quoted literal, or inside a regex
/// literal of a script (`regex_literals.rs`), as (line, words): `(a|b|c)`
/// groups and bare `a|b|c` bodies, two or more alternatives, every one a word
/// once regex syntax is stripped.
pub(super) fn word_alternations(path: &str, text: &str) -> Vec<(usize, Vec<String>)> {
    let quoted = LITERAL.captures_iter(text).filter_map(|literal| {
        let body = literal.name("double").or_else(|| literal.name("single"))?;
        Some((body.start(), body.as_str().to_owned()))
    });
    let regexes = regex_literals::applies(path)
        .then(|| regex_literals::bodies(text))
        .into_iter()
        .flatten();
    let mut found = Vec::new();
    for (start, body) in quoted.chain(regexes) {
        if !body.contains('|') {
            continue;
        }
        let line = line_of(text, start);
        for group in alternation_groups(&body) {
            let words: Vec<String> = group
                .split('|')
                .map(|alternative| REGEX_SYNTAX.replace_all(alternative, " ").trim().to_owned())
                .map(|alternative| alternative.split_whitespace().collect::<Vec<_>>().join(" "))
                .collect();
            if is_list(&words) && words.iter().all(|word| is_word(word)) {
                found.push((line, words));
            }
        }
    }
    found
}

/// The innermost parenthesised groups of `body` (a literal's content, without
/// its quotes or slashes) that contain `|`, and the whole body when it has no
/// such group.
fn alternation_groups(body: &str) -> Vec<String> {
    let mut groups = Vec::new();
    let mut stack: Vec<usize> = Vec::new();
    let mut escaped = false;
    for (index, ch) in body.char_indices() {
        if escaped {
            escaped = false;
            continue;
        }
        match ch {
            '\\' => escaped = true,
            '(' => stack.push(index),
            ')' => {
                if let Some(start) = stack.pop() {
                    let inner = body[start..index].trim_start_matches('(');
                    let inner = inner.trim_start_matches("?:").trim_start_matches("?i:");
                    if inner.contains('|') && !inner.contains('(') {
                        groups.push(inner.to_owned());
                    }
                }
            }
            _ => {}
        }
    }
    if groups.is_empty() {
        groups.push(body.to_owned());
    }
    groups
}

/// The line `offset` falls on, counting the first line as line one: the
/// pieces a split on newlines yields up to it.
pub(super) fn line_of(text: &str, offset: usize) -> usize {
    text[..offset].split('\n').count()
}
