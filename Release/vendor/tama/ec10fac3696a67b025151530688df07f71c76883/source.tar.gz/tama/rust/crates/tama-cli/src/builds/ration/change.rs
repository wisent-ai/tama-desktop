//! How big the change a build carries is.
//!
//! "Serious change" is not a judgement the writer can be trusted to make about
//! its own work, so it is measured: the lines between the revision the last
//! recorded build of this target carried and the revision this one carries. A
//! version bump and a typo are a handful of lines; the work that deserves
//! forty minutes of a builder is not.

use std::path::{Path, PathBuf};

use crate::gitcmd::git;

/// Where the change is measured. `--repository` names it; without that option
/// it is the repository the command runs in.
pub fn repository(argv: &[String]) -> Result<PathBuf, String> {
    let mut words = argv.iter();
    if words.find(|item| *item == "--repository").is_some() {
        if let Some(named) = words.next() {
            return Ok(PathBuf::from(named));
        }
    }
    let here = std::env::current_dir()
        .map_err(|error| format!("this command has no working directory: {error}"))?;
    match tama_core::presence::checkout_root(&here).map_err(|error| error.to_string())? {
        Some(root) => Ok(root.to_path_buf()),
        None => Err(format!(
            "{} is in no repository, so a build's change cannot be measured; name one with \
             --repository <path>",
            here.display()
        )),
    }
}

/// What git's `--numstat` prints for a binary file's added and deleted lines.
const BINARY_COUNT: &str = "-";

/// Added plus deleted lines between two revisions. A revision the repository
/// does not know is refused with git's own words rather than guessed at, so a
/// build is never let through because the measurement failed. A binary file
/// has no line counts and adds none; any other count git prints that is not
/// a number refuses, naming the line, instead of counting as zero.
pub fn changed_lines(repository: &Path, from: &str, to: &str) -> Result<u64, String> {
    let numstat = git(repository, &["diff", "--numstat", from, to])?;
    let mut counts = Vec::new();
    for line in numstat.lines() {
        let mut fields = line.split('\t');
        let (Some(added), Some(deleted)) = (fields.next(), fields.next()) else {
            return Err(format!(
                "git diff --numstat {from} {to} printed `{line}`, which carries no added and deleted counts"
            ));
        };
        for count in [added, deleted] {
            if count == BINARY_COUNT {
                continue;
            }
            counts.push(count.parse::<u64>().map_err(|error| {
                format!("git diff --numstat {from} {to} printed `{line}`, whose count `{count}` is not a number: {error}")
            })?);
        }
    }
    Ok(counts.into_iter().sum())
}
