//! Logic for `tama hook block-internal-names`, registry hook id
//! `block-internal-names`.
//!
//! Refuses a write into a repository, or into an agent instruction file,
//! that adds internal details:
//!
//!   * a fleet host name, host address or account name, anywhere in the file;
//!   * a vault item id, anywhere in the file: a secret is asked for by its
//!     role (`role#field`, Skarbiec tag `stado:role:<role>`), never by the
//!     item that happens to hold it;
//!   * a date, or a commit, build, job or defect id, in prose — the shape of
//!     a story about one incident.
//!
//! Every repository is published or can be, and every instruction file is
//! copied by the agents that read it. What a reader needs is the behaviour
//! and the reason for it; which host, which day and which job belong in Oko.
//! Nothing here lists a name: [`names`] reads them from their owners.

pub mod names;
pub(crate) mod products;
pub mod segments;

use std::collections::BTreeSet;
use std::path::Path;

use serde_json::Value;
use tama_hooks::session_record::{deny_tool_use, read_payload};

use crate::ports::pre_write_edit::resulting;
use crate::ports::violations_declarations::file_is_declared;
use crate::ports::write_payload::{is_system_path, WritePayload};

pub const HOOK_ID: &str = "block-internal-names";
/// The line a gate prints when a source of names could not be read.
const INFRASTRUCTURE_PREFIX: &str = "TAMA_HOOK_INFRASTRUCTURE:";
const NAME_KIND: &str = "fleet host or account name";
const VAULT_KIND: &str = "vault item id";
const INSTRUCTIONS_DIR: &str = "agents";
const INSTRUCTION_EXTENSION: &str = "md";
const ADVICE: &str = "Repositories and instruction files are published and copied: \
    describe the behaviour and its reason, not the incident. No host, account or vault item \
    names: a program reads a host from the Stado registry at run time and asks for a secret \
    by its role (role#field), never by its item; and no dates or commit, \
    build, job or defect ids in comments, docs, changelogs or messages. Incident history \
    belongs in Oko (`oko defects`). A path whose content must carry such data is declared, \
    with its reason, in the repository's .tama/violations-ignore.";

/// One internal detail on one line.
#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord)]
pub struct Finding {
    /// One-based line number in the judged text.
    pub line: usize,
    pub kind: &'static str,
    pub text: String,
    /// The line as written, trimmed.
    pub context: String,
}

/// Every name this machine knows as internal.
pub fn load_names() -> names::Names {
    names::load()
}

/// Whether `name` occurs in `lower` as a whole identifier: no letter, digit,
/// `-` or `_` on either side, since `acme-cloud-agent` is another name than
/// `acme-cloud`, not a mention of it.
fn mentions(lower: &str, name: &str) -> bool {
    let joins = |c: char| c.is_ascii_alphanumeric() || c == '-' || c == '_';
    lower.match_indices(name).any(|(start, _)| {
        let before = lower[..start].chars().next_back();
        let after = lower[start + name.len()..].chars().next();
        !before.is_some_and(joins) && !after.is_some_and(joins)
    })
}

/// Every internal detail `content` carries, one finding per line and value.
pub fn findings(content: &str, names: &names::Names) -> Vec<Finding> {
    let mut found = BTreeSet::new();
    for (number, line) in tama_core::lines::numbered(content) {
        let mut hit = |kind: &'static str, text: &str| {
            found.insert(Finding {
                line: number,
                kind,
                text: text.to_string(),
                context: line.trim().to_string(),
            });
        };
        let lower = line.to_lowercase();
        for name in names
            .everywhere
            .iter()
            .filter(|name| mentions(&lower, name))
        {
            hit(NAME_KIND, name);
        }
        for item in names
            .vault_items
            .iter()
            .filter(|item| mentions(&lower, item))
        {
            hit(VAULT_KIND, item);
        }
        for segment in segments::prose_segments(line) {
            for (kind, text) in segments::narration(segment) {
                hit(kind, &text);
            }
        }
    }
    found.into_iter().collect()
}

/// Whether a write to this path is judged: a file inside a repository, or an
/// instruction file the agents read from the home directory. A declaration
/// file that cannot be read is refused naming it.
pub fn judged(file_path: &str) -> Result<bool, String> {
    let path = Path::new(file_path);
    if file_is_declared(file_path)? {
        return Ok(false);
    }
    let in_checkout = match path.parent() {
        Some(parent) => tama_core::presence::checkout_root(parent)
            .map_err(|error| error.to_string())?
            .is_some(),
        None => false,
    };
    if in_checkout {
        return Ok(true);
    }
    let home = crate::util::home_dir();
    let parent = path.parent();
    Ok(
        parent.is_some_and(|dir| dir.starts_with(home.join(INSTRUCTIONS_DIR)))
            || (parent == Some(home.as_path())
                && path
                    .extension()
                    .is_some_and(|ext| ext == INSTRUCTION_EXTENSION)),
    )
}

/// The refusal for these findings in `file_path`.
pub fn refusal(file_path: &str, found: &[Finding]) -> String {
    let listed = found
        .iter()
        .map(|finding| {
            format!(
                "  line {}: {} `{}` in: {}",
                finding.line, finding.kind, finding.text, finding.context
            )
        })
        .collect::<Vec<_>>()
        .join("\n");
    format!("{HOOK_ID}: BLOCKED: {file_path} would carry internal details:\n{listed}\n{ADVICE}")
}

/// The refusal this write earns: the whole file as the write leaves it is
/// judged, whoever wrote each line, so an internal detail a file already
/// held is refused on its next edit until it is removed. Each file a write
/// leaves is judged under its own path. A write whose file cannot be
/// rebuilt is refused with the cause.
pub fn check(payload: &Value) -> (Option<String>, Vec<String>) {
    let write = match WritePayload::read(payload) {
        Ok(write) => write,
        Err(error) => return (Some(error), Vec::new()),
    };
    if write.content.is_empty() {
        return (None, Vec::new());
    }
    let files = match resulting(payload, &write) {
        Ok(Some(files)) => files,
        Ok(None) => return (None, Vec::new()),
        Err(error) => {
            return (
                Some(format!(
                    "{HOOK_ID}: BLOCKED: the file this write leaves cannot be rebuilt to judge it: {error}"
                )),
                Vec::new(),
            )
        }
    };
    let names = load_names();
    for (path, text) in files.iter().filter(|(path, _)| !is_system_path(path)) {
        match judged(path) {
            Ok(true) => {}
            Ok(false) => continue,
            Err(error) => return (Some(format!("BLOCKED: {error}")), names.unread),
        }
        let found = findings(text, &names);
        if !found.is_empty() {
            return (Some(refusal(path, &found)), names.unread);
        }
    }
    (None, names.unread)
}

pub fn run() {
    let payload = read_payload();
    let (verdict, unread) = check(&payload);
    if !unread.is_empty() {
        for reason in unread {
            eprintln!("{INFRASTRUCTURE_PREFIX} {HOOK_ID} could not read {reason}");
        }
        std::process::exit(libc::EXIT_FAILURE);
    }
    if let Some(refusal) = verdict {
        deny_tool_use(&refusal);
    }
}
