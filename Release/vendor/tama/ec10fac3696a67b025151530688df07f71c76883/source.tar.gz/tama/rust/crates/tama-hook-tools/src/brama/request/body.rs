//! The request body on its own file, and what a refused `--config` document
//! held.
//!
//! curl reads a line of the config document on its standard input only up
//! to its own fixed length, and a stop hook's prompt carries the turn's
//! transcript: sent as one `data-binary` line of that document, the body
//! would outgrow the limit, curl would answer `cannot read config from -`
//! naming neither the line nor its length, and a judge outage would read as
//! Brama's own refusal. The body goes through a file under
//! `~/.tama/judge-requests/` that curl reads by path (`data-binary =
//! "@<path>"`), owned by the hook process and removed when its request
//! ends; the config keeps only the endpoint and headers.

use std::io::ErrorKind;
use std::path::{Path, PathBuf};
use std::time::{SystemTime, UNIX_EPOCH};

use super::super::credentials::home_dir;

fn directory() -> PathBuf {
    home_dir().join(".tama").join("judge-requests")
}

/// The body of one request in flight, on a file curl reads by path.
pub(super) struct BodyFile {
    path: PathBuf,
    bytes: usize,
}

impl BodyFile {
    /// Write `body` for the request this process is about to send.
    pub(super) fn write(body: &str) -> Result<BodyFile, String> {
        let nanos = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map_err(|error| format!("cannot date the judge request body: {error}"))?
            .as_nanos();
        let directory = directory();
        std::fs::create_dir_all(&directory).map_err(|error| {
            format!(
                "cannot create the judge request body directory {}: {error}",
                directory.display()
            )
        })?;
        let path = directory.join(format!("{}-{nanos}.json", std::process::id()));
        std::fs::write(&path, body).map_err(|error| {
            format!(
                "cannot write the judge request body {}: {error}",
                path.display()
            )
        })?;
        Ok(BodyFile {
            path,
            bytes: body.len(),
        })
    }

    pub(super) fn path(&self) -> &Path {
        &self.path
    }

    /// How the body is named in a refusal: its file and size.
    pub(super) fn described(&self) -> String {
        format!("{} ({} bytes)", self.path.display(), self.bytes)
    }
}

impl Drop for BodyFile {
    fn drop(&mut self) {
        if let Err(error) = std::fs::remove_file(&self.path) {
            if error.kind() != ErrorKind::NotFound {
                eprintln!(
                    "tama: the judge request body {} stays behind: {error}",
                    self.path.display()
                );
            }
        }
    }
}

/// One config line by its option and its length in bytes: a line `option =
/// "value"` is named by the option, a bare line (`silent`) by itself.
fn line_report(line: &str) -> String {
    let option = match line.split_once(" = ") {
        Some((option, _)) => option,
        None => line,
    };
    format!("{option} ({} bytes)", line.len())
}

/// Each line of the config document by its option and length in bytes, and
/// the body file, so a refused document is named without its values (the
/// bearer is one of them).
pub(super) fn config_report(config: &str, body: &BodyFile) -> String {
    let lines: Vec<String> = config.lines().map(line_report).collect();
    format!(
        "the config document curl read from standard input had the lines {}; the request body was \
         {}",
        lines.join(", "),
        body.described()
    )
}
