//! Internal helpers shared across the crate: repo root resolution, home
//! directory, and the shell-word splitter ported verbatim from
//! `engine.mjs`/`evidence.mjs`. Times are `tama_core::clock`'s and UUIDs
//! `tama_core::random`'s.

use std::path::{Path, PathBuf};

/// The Tama checkout the doctor tools compare installed hooks with, as
/// [`tama_core::checkout`] finds it, or why there is none.
pub fn repo_root() -> Result<PathBuf, String> {
    tama_core::checkout()
}

/// The user's home, from HOME through [`tama_core::home_dir`]: without HOME it
/// stops and names the variable; answering `/` read and wrote every per-user
/// Tama file at the root of the disk.
pub fn home_dir() -> PathBuf {
    tama_core::home_dir()
}

/// Split a command line into words honouring single and
/// double quotes and backslash escapes (a backslash inside single quotes is
/// literal). Unterminated escape keeps the backslash.
pub fn shell_words(command: &str) -> Vec<String> {
    let mut words = Vec::new();
    let mut word = String::new();
    let mut quote: Option<char> = None;
    let mut escaped = false;
    for character in command.chars() {
        if escaped {
            word.push(character);
            escaped = false;
        } else if character == '\\' && quote != Some('\'') {
            escaped = true;
        } else if let Some(q) = quote {
            if character == q {
                quote = None;
            } else {
                word.push(character);
            }
        } else if character == '\'' || character == '"' {
            quote = Some(character);
        } else if character.is_whitespace() {
            if !word.is_empty() {
                words.push(std::mem::take(&mut word));
            }
        } else {
            word.push(character);
        }
    }
    if escaped {
        word.push('\\');
    }
    if !word.is_empty() {
        words.push(word);
    }
    words
}

/// `JSON.stringify(value, null, 2)` plus trailing newline, matching the
/// on-disk projection/episode format. `serde_json` pretty printing uses the
/// same two-space indentation.
pub fn pretty_json_line(value: &serde_json::Value) -> String {
    // `{:#}` is a `Value`'s pretty JSON, two-space indented; it cannot fail,
    // where an empty text in place of a failure would have blanked the file.
    format!("{value:#}\n")
}

/// JS truthiness for JSON values (`x || y`, `if (x)`). A JSON number is
/// never infinite, so it is truthy exactly when it is neither zero nor NaN.
pub fn js_truthy(value: &serde_json::Value) -> bool {
    match value {
        serde_json::Value::Null => false,
        serde_json::Value::Bool(b) => *b,
        serde_json::Value::Number(n) => n
            .as_f64()
            .is_some_and(|f| f.is_normal() || f.is_subnormal()),
        serde_json::Value::String(s) => !s.is_empty(),
        _ => true,
    }
}

/// Coerce a serde value to a JS-style string for the few places JS calls
/// `String(x)` on possibly non-string JSON values.
pub fn js_string(value: &serde_json::Value) -> String {
    match value {
        serde_json::Value::String(s) => s.clone(),
        serde_json::Value::Null => "null".to_string(),
        serde_json::Value::Bool(b) => b.to_string(),
        other => other.to_string(),
    }
}

/// Node `path.extname`: the suffix from the last dot of the basename,
/// empty for dotfiles and names without a dot.
pub fn extname(path: &str) -> String {
    match Path::new(path).extension() {
        Some(extension) => format!(".{}", extension.to_string_lossy()),
        None => String::new(),
    }
}
