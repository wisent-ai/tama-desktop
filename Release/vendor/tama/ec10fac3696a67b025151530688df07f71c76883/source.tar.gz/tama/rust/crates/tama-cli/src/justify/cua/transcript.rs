//! Select original user text, never an assistant quote or a tool result.

use std::fs::{self, File};
use std::io::{BufRead, BufReader};
use std::path::PathBuf;

use serde_json::Value;
use tama_hook_tools::ports::transport_common;

pub(crate) fn select(session: &str, needle: &str) -> Result<String, String> {
    let root = transport_common::session_root();
    let files = paths(session)?;
    if files.is_empty() {
        return Err(format!(
            "no OMP transcript of session {session} is under {}",
            root.display()
        ));
    }
    let mut matches = Vec::new();
    // Lines that are not JSON (a line still being written) are named when
    // nothing matches, so a quote in them is not reported absent.
    let mut unreadable = Vec::new();
    for path in &files {
        let file =
            File::open(path).map_err(|error| format!("cannot read {}: {error}", path.display()))?;
        for line in BufReader::new(file).lines() {
            let line = line.map_err(|error| format!("cannot read {}: {error}", path.display()))?;
            let value = match serde_json::from_str::<Value>(&line) {
                Ok(value) => value,
                Err(error) => {
                    unreadable.push(format!("{}: {error}", path.display()));
                    continue;
                }
            };
            let message = match value.get("type").and_then(Value::as_str) {
                Some("message") => match value.get("message") {
                    Some(message) => message,
                    None => continue,
                },
                _ => &value,
            };
            if message.get("role").and_then(Value::as_str) != Some("user") {
                continue;
            }
            let text = match message.get("content") {
                Some(Value::String(text)) => text.clone(),
                Some(Value::Array(blocks)) => blocks
                    .iter()
                    .filter(|block| block.get("type").and_then(Value::as_str) == Some("text"))
                    .filter_map(|block| block.get("text").and_then(Value::as_str))
                    .collect::<Vec<_>>()
                    .join("\n"),
                _ => continue,
            };
            if text.contains(needle) && !matches.contains(&text) {
                matches.push(text);
            }
        }
    }
    if matches.is_empty() && !unreadable.is_empty() {
        return Err(format!(
            "no direct user message matches {needle:?} in OMP session {session} under {}; {} line(s) are not JSON and were not read: {}",
            root.display(),
            unreadable.len(),
            unreadable.join("; ")
        ));
    }
    match matches.len() {
        0 => Err(format!("no direct user message matches {needle:?} in OMP session {session} under {}", root.display())),
        1 => Ok(matches.remove(0)),
        count => Err(format!("{count} distinct user messages match {needle:?} in OMP session {session}; use a more specific quoteMatch or an exact quote")),
    }
}

fn paths(session: &str) -> Result<Vec<PathBuf>, String> {
    let mut pending = vec![transport_common::session_root()];
    let mut found = Vec::new();
    while let Some(directory) = pending.pop() {
        let entries = fs::read_dir(&directory).map_err(|error| {
            format!(
                "cannot read session directory {}: {error}",
                directory.display()
            )
        })?;
        for entry in entries {
            let entry =
                entry.map_err(|error| format!("cannot read {}: {error}", directory.display()))?;
            let kind = entry.file_type().map_err(|error| {
                format!(
                    "cannot read the kind of {}: {error}",
                    entry.path().display()
                )
            })?;
            if kind.is_dir() {
                pending.push(entry.path());
            } else if kind.is_file() {
                let name = entry.file_name();
                let name = name.to_string_lossy();
                if name.contains(session) && name.ends_with(".jsonl") {
                    found.push(entry.path());
                }
            }
        }
    }
    Ok(found)
}
