//! `block-unapproved-audits`.
//!
//! Block explicitly declared audit workflows without device-level approval;
//! a tool call that tries to write the approval policy from inside the
//! session is denied outright. A payload that is not a JSON object refuses
//! the call: read as empty, it would let any audit through unjudged.
//!
//! Consent state: see `block_unapproved_audits_state` — the approval file at
//! `~/.config/agent-policy/device_level_audits.json` (or
//! `$DEVICE_LEVEL_AUDITS_POLICY`).

use super::block_unapproved_audits_state as state;
use super::python_stdlib;
use super::pyvalue::{first_truthy_py_str, py_json_dumps};
use regex::Regex;
use serde_json::Value;
use std::path::Path;
use tama_hooks::session_record::read_payload;

use crate::ports::tool_vocabulary::{paths_in, Call, EDITS_KEY};
const AUDIT_PROGRAMS: &[&str] = &["bundle-audit", "cargo-audit", "osv-scanner", "pip-audit"];
/// The package managers whose `audit` subcommand audits dependencies.
const PACKAGE_AUDIT_PROGRAMS: &[&str] = &[BUN, NPM, PNPM, YARN];
const BUN: &str = "bun";
const NPM: &str = "npm";
const PNPM: &str = "pnpm";
const YARN: &str = "yarn";
const BUNDLE_PROGRAM: &str = "bundle";
const AUDIT_SUBCOMMAND: &str = "audit";

const EVENT_KEYS: &[&str] = &["agent_hook_event", "hook_event_name", "hook_event", "event"];
const USER_PROMPT_SUBMIT: &str = "userpromptsubmit";

/// The two envelopes a patch names its file in, from the one declaration
/// in [`super::patch_envelope`], as one multi-line pattern. The bracket
/// header is matched whole, tag and closing bracket included, with its path
/// as the first group: a path may hold square brackets.
fn patch_path_pattern() -> String {
    format!(
        "(?m)^(?:\\[([^#\\n]+)#[0-9A-Fa-f]{{4}}\\]\\s*|{})$",
        super::patch_envelope::file_header_in_text()
    )
}
const SEGMENT_PATTERN: &str = "(?:&&|\\|\\||[;\\n])";
const ASSIGNMENT_PATTERN: &str = "\\A[A-Za-z_][A-Za-z0-9_]*=.*\\z";

fn empty_object() -> Value {
    Value::Object(Default::default())
}

fn compile(pattern: &str) -> Regex {
    Regex::new(pattern).expect("hook pattern must compile")
}

/// The last component of `path`, or `None` for a path that names none
/// (`..`, `/`), which is no program and no policy file.
fn base_name(path: &str) -> Option<String> {
    Path::new(path)
        .file_name()
        .map(|name| name.to_string_lossy().to_lowercase())
}

/// Every path an edit's arguments name, its listed operations' included.
fn edit_paths(value: &Value, found: &mut Vec<String>) {
    found.extend(paths_in(value).into_iter().map(str::to_string));
    if let Some(Value::Array(edits)) = value.get(EDITS_KEY) {
        for edit in edits {
            edit_paths(edit, found);
        }
    }
}

/// Every file a writing call names: under its path keys, in its listed
/// operations, and in the headers of the patch it carries.
fn candidate_paths(call: &Call, patch_paths: &Regex) -> Result<Vec<String>, String> {
    let mut found = Vec::new();
    if let Some(input) = call.input() {
        edit_paths(input, &mut found);
    }
    if let Some(text) = call.patch() {
        let hashline = super::write_payload::hashline::touched_paths(text)?;
        if !hashline.is_empty() {
            found.extend(hashline);
            return Ok(found);
        }
        for captures in patch_paths.captures_iter(text) {
            // The whole match is not a path; the groups after it are.
            let mut groups = captures.iter();
            groups.next();
            if let Some(group) = groups.flatten().find(|group| !group.as_str().is_empty()) {
                found.push(group.as_str().to_string());
            }
        }
    }
    Ok(found)
}

fn approval_bypass_reason(payload: &Value, policy_name: &str) -> Option<String> {
    let call = Call::of(payload);
    let wanted = policy_name.to_lowercase();
    if call.changes_files() {
        let paths = match candidate_paths(&call, &compile(&patch_path_pattern())) {
            Ok(paths) => paths,
            Err(cause) => return Some(format!("audit-policy targets cannot be resolved: {cause}")),
        };
        for path in paths {
            if base_name(&path).as_deref() == Some(wanted.as_str()) {
                return Some(format!("attempted in-session audit policy write: {path}"));
            }
        }
        return None;
    }
    // Any other call that names the policy where the name can act — outside
    // a shell's quoted data, anywhere in other input — is a mutation attempt:
    // which program or call would write it is not read, because a writer
    // list let every writer it left out through, and the policy is read with
    // the harness's read tool.
    let acting = match (call.is_shell(), call.command()) {
        (true, Some(command)) => super::shell_text::effective_command(command),
        _ => match call.input() {
            Some(input) => py_json_dumps(input),
            None => py_json_dumps(&empty_object()),
        },
    };
    if acting.to_lowercase().contains(&wanted) {
        return Some(format!(
            "attempted in-session audit policy mutation: {policy_name}"
        ));
    }
    None
}

fn audit_command_reason(command: &str) -> Option<String> {
    let assignment = compile(ASSIGNMENT_PATTERN);
    let splitter = compile(SEGMENT_PATTERN);
    for segment in splitter.split(command) {
        let tokens = python_stdlib::shell_tokens(segment);
        if tokens.is_empty() {
            continue;
        }
        let mut words = tokens.iter().skip_while(|token| assignment.is_match(token));
        let Some(token) = words.next() else {
            continue;
        };
        let rest: Vec<&String> = words.collect();
        let Some(program) = base_name(token) else {
            continue;
        };
        let first_arg = rest.first().map(|arg| arg.to_lowercase());
        let subcommand = first_arg.as_deref() == Some(AUDIT_SUBCOMMAND);
        if AUDIT_PROGRAMS.contains(&program.as_str()) {
            return Some(format!("audit program: {program}"));
        }
        if PACKAGE_AUDIT_PROGRAMS.contains(&program.as_str()) && subcommand {
            return Some(format!("audit program: {program} audit"));
        }
        if program == BUNDLE_PROGRAM && subcommand {
            return Some(format!("audit program: {BUNDLE_PROGRAM} audit"));
        }
    }
    None
}

fn declared_audit_reason(payload: &Value) -> Option<String> {
    audit_command_reason(Call::of(payload).command()?)
}

fn block(reason: &str) -> ! {
    let approval = state::APPROVAL_ENV;
    let field = state::POLICY_FIELD;
    let policy = state::policy_path();
    tama_hooks::session_record::refuse(&format!(
        "BLOCKED: audit workflows require explicit user-controlled device \
approval. Set {approval}=1 outside the agent session or enable {field} in {}. \
Detected: {reason}",
        policy.display()
    ))
}

fn letters_only(text: &str) -> String {
    text.chars().filter(char::is_ascii_lowercase).collect()
}

pub fn run() {
    let payload = read_payload();
    if !payload.is_object() {
        tama_hooks::session_record::refuse(&format!(
            "TAMA_HOOK_INFRASTRUCTURE: block-unapproved-audits: the hook payload is not a JSON \
             object, so this call cannot be judged: {payload}"
        ));
    }
    let event = first_truthy_py_str(&payload, EVENT_KEYS);
    if letters_only(&event.to_lowercase()) == USER_PROMPT_SUBMIT {
        return;
    }
    if let Some(reason) = approval_bypass_reason(&payload, &state::policy_name()) {
        block(&reason);
    }
    let unreadable = match state::approved() {
        Ok(true) => return,
        Ok(false) => None,
        Err(cause) => Some(cause),
    };
    if let Some(reason) = declared_audit_reason(&payload) {
        match unreadable {
            Some(cause) => block(&format!(
                "{reason}; the audit approval could not be read, so none is known: {cause}"
            )),
            None => block(&reason),
        }
    }
}
