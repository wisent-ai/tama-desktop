//! `tama hooks release`: activate the hook release Tama's Stado release
//! carries, warm every hook it runs, and report what this machine now runs.
//!
//! A hook lands in three places. The registry and the catalogue are
//! repository documents (`tama hooks declare` writes them); what a machine
//! runs is a sealed release under `~/Library/Application Support/Tama/
//! hooks-runtime` and the `tama` program the registry points at. Both come
//! from one Stado release: the batch build compiles `tama`, assembles and
//! seals the hook release from the same commit (`release/build.sh`), and
//! `stado product install tama --surface cli` places them and runs this
//! command as its `after_install` step. This command builds nothing and
//! stages nothing from the working tree: a hook release assembled beside
//! Stado instead of through it is not the release Stado installed.
//!
//! Device-level protected: without the owner's consent ([`consented`]: his
//! shell variable, or his word in the conversation recorded as the session
//! capability `{"tool": "tama", "actions": ["hook-edit"]}`) this refuses
//! before changing anything, and so does the `stado product install` that
//! runs it.

mod binaries;
mod install;
mod retire;
mod support;

use std::path::{Path, PathBuf};

use super::declare::{consent_route, consented, refuse, CONSENT_ENV, CONSENT_VALUE};
use super::warm::{registry_hooks, separate_programs};
use install::{activate, installed_release};
use support::installed_provenance;

/// What this machine's sealed runtime was built from, when it holds one.
pub(super) fn provenance_line() -> Option<String> {
    installed_provenance(&tama_core::home_dir())
}

pub const USAGE: &str = "usage: tama hooks release [--dry-run] [--enforce <hook-id>[,<hook-id>…]]";

/// The one program a machine runs: every hook, the engine every provider
/// dispatcher executes, the MCP server and the CLI are its subcommands.
const PROGRAM: &str = tama_hooks::hook_exec::PROGRAM;
/// Names Tama's programs were installed under before they were one. A
/// release removes each, so no second program stays on the path answering
/// at whatever build it last was; every `tama-<hook>` a release recorded is
/// removed the same way.
const RETIRED_PROGRAMS: &[&str] = &[
    "tama-cli",
    "tama-cli.d",
    "tama-run-hook",
    "tama-run-hook.d",
    "tama-mcp-server",
    "tama-mcp-server.d",
    "tama-omp-hooks",
    "tama-omp-hooks.d",
];
/// The engine as a separate program, as a provider adapter used to launch it.
const SEPARATE_ENGINE: &str = "tama-run-hook";

/// Every line of a shipped adapter that still launches the engine as the
/// separate `tama-run-hook` program, as `file:line: text`. A release carries
/// only `tama`, so such an adapter would launch nothing and every hook event
/// would fail. An adapter directory or file that cannot be read is refused
/// naming it: skipped, the adapter it hid shipped unchecked.
fn separate_engine_launches(root: &Path) -> Result<Vec<String>, String> {
    let directory = root.join("shared-hooks");
    let entries = std::fs::read_dir(&directory).map_err(|error| {
        format!(
            "cannot list the adapters in {}: {error}",
            directory.display()
        )
    })?;
    let mut adapters: Vec<PathBuf> = entries
        .map(|entry| {
            entry.map(|entry| entry.path()).map_err(|error| {
                format!(
                    "cannot list the adapters in {}: {error}",
                    directory.display()
                )
            })
        })
        .collect::<Result<Vec<PathBuf>, String>>()?
        .into_iter()
        // Every JavaScript module extension a provider adapter is shipped
        // under (js, mjs, cjs) ends in `js`.
        .filter(|path| {
            path.extension()
                .and_then(|extension| extension.to_str())
                .is_some_and(|extension| extension.ends_with("js"))
        })
        .collect();
    adapters.sort();
    let mut found = Vec::new();
    for adapter in adapters {
        let text = std::fs::read_to_string(&adapter)
            .map_err(|error| format!("cannot read the adapter {}: {error}", adapter.display()))?;
        for line in text.lines() {
            if line.contains(SEPARATE_ENGINE) {
                found.push(format!("{}: {}", adapter.display(), line.trim()));
            }
        }
    }
    Ok(found)
}

pub fn main(argv: &[String], root: &Path) -> i32 {
    if argv.iter().any(|arg| arg == "--help" || arg == "-h") {
        println!("{USAGE}");
        return tama_core::exit::SUCCESS;
    }
    let dry_run = argv.iter().any(|arg| arg == "--dry-run");
    let enforce: Vec<String> = match crate::hooks::declare::option(argv, "--enforce") {
        Some(list) => list.split(',').map(|id| id.trim().to_string()).collect(),
        None => Vec::new(),
    };
    let home = match std::env::var_os("HOME").filter(|home| !home.is_empty()) {
        Some(home) => PathBuf::from(home),
        None => return refuse("HOME is not set, so the installed hook release cannot be located"),
    };
    let release = installed_release(&home);
    let registry = release.join("shared-hooks/registry.json");
    if !registry.is_file() {
        return refuse(&format!(
            "{} holds no hook release; `stado product install tama --surface cli` installs \
             Tama's release, which carries it",
            release.display()
        ));
    }
    let separate = match separate_programs(&registry) {
        Ok(separate) => separate,
        Err(error) => return refuse(&error),
    };
    if !separate.is_empty() {
        let listed: Vec<String> = separate
            .iter()
            .map(|(id, command)| format!("  {id}: {command}"))
            .collect();
        return refuse(&format!(
            "{} still runs {} hooks as separate programs, and Tama builds only `{PROGRAM}`:\n{}\n\
             Each command must run the hook through the one program, as \
             `$HOME/.local/bin/{PROGRAM} hook <id>`; nothing was built or installed. The \
             registry is device-protected, so its owner rewrites it outside any agent session:\n\n  \
             cd {}\n  {CONSENT_ENV}={CONSENT_VALUE} {PROGRAM} hook \
             migrate-registry-to-rust --registry shared-hooks/registry.json --apply\n  \
             node shared-hooks/seal-registry.mjs\n\n\
             and commits and pushes the result before releasing.",
            registry.display(),
            separate.len(),
            listed.join("\n"),
            root.display()
        ));
    }
    let launches = match separate_engine_launches(&release) {
        Ok(launches) => launches,
        Err(error) => return refuse(&error),
    };
    if !launches.is_empty() {
        return refuse(&format!(
            "these adapters still launch the engine as the separate program {SEPARATE_ENGINE}, and a \
             release carries only `{PROGRAM}`:\n  {}\nEach must launch `{PROGRAM} run-hook` from the \
             release's bin directory instead; nothing was built or installed",
            launches.join("\n  ")
        ));
    }
    let hooks = match registry_hooks(&registry) {
        Ok(hooks) => hooks,
        Err(error) => return refuse(&error),
    };
    if hooks.is_empty() {
        return refuse(&format!(
            "{} names no hook the {PROGRAM} program runs; there is nothing to release",
            registry.display()
        ));
    }
    // Gates that are each right can together refuse every step a session
    // has; a release that would install such a set is refused naming each
    // state left no step and the gates that close it (`tama hooks reach`).
    let catalogue = release.join("shared-hooks/catalog-metadata.json");
    match super::reach::stuck(root, &catalogue) {
        Ok(stuck) if stuck.is_empty() => {}
        Ok(stuck) => {
            return refuse(&format!(
                "the release's gates, as the declarations under {}/hook-declarations say, leave a session no step; nothing was installed:\n  {}",
                root.display(),
                stuck.join("\n  ")
            ))
        }
        Err(cause) => return refuse(&format!("whether the release's gates leave every session a step cannot be read: {cause}")),
    }
    if dry_run {
        println!(
            "would activate the hook release Stado installed at {}",
            release.display()
        );
        println!("would run {} hooks through it:", hooks.len());
        for hook in &hooks {
            println!("  {PROGRAM} {}", hook.args.join(" "));
        }
        println!(
            "would warm every hook through the installed {PROGRAM} and report what each one cost"
        );
        println!(
            "would retire every launch agent the registry marks installed-not-active that is still in ~/Library/LaunchAgents"
        );
        println!(
            "would remove the separate programs a release installed before: {} and every recorded tama-<hook>",
            RETIRED_PROGRAMS.join(" ")
        );
        println!("would install the sealed hook release into this machine's hook runtime");
        if enforce.is_empty() {
            println!("would leave this machine's hook selection as it is")
        } else {
            println!("would add to the selection: {}", enforce.join(" "))
        }
        if let Some(provenance) = provenance_line() {
            println!("{provenance}");
        }
        return tama_core::exit::SUCCESS;
    }
    let ruling = ruled_release();
    if let Err(withdrawn) = &ruling {
        return refuse(&format!(
            "BLOCKED: the operator's standing ruling withdraws releasing Tama's hooks: {withdrawn}"
        ));
    }
    if ruling != Ok(true) && !consented() {
        // The release is already installed (it was read above), so the
        // command that completes is this one again: an install through
        // Stado is a build the build rulings may refuse, and would spend
        // the owner's consent on a command that cannot run.
        let mut again = vec![
            "tama".to_string(),
            "hooks".to_string(),
            "release".to_string(),
        ];
        again.extend(
            argv.iter()
                .map(|arg| tama_hook_tools::registry::shell_quote(arg)),
        );
        return refuse(&format!(
            "BLOCKED: installing a hook release changes what every session on this machine runs. \
             It activates the hook release Stado installed at {}. {}",
            release.display(),
            consent_route(&again.join(" "))
        ));
    }
    activate(root, &enforce)
}

/// The product a hook release belongs to, as the operator's rulings name it.
const PRODUCT: &str = "tama";

/// What the operator's standing rulings say about releasing Tama's hooks for
/// the work of the session this command runs in (`oko admit release
/// --product tama --session <it>`: a consent to release, or to release for
/// an open build-first defect that session owns): `Ok(true)` when one
/// consents, said on stderr with the ruling it quotes; the ruling's words
/// when one withdraws it; `Ok(false)` when none decides, so the owner's own
/// consent is asked as before.
fn ruled_release() -> Result<bool, String> {
    use tama_hook_tools::capability::standing::{self, Ruled};
    let session = match tama_hook_tools::ports::owner_consent::recorded_session() {
        Ok((holder, _)) => holder.map(|(_, session)| session),
        Err(cause) => {
            eprintln!("which session runs this release could not be read, so no ruling scoped to its work is read: {cause}");
            None
        }
    };
    match standing::ruled(standing::RELEASE, Some(PRODUCT), session.as_deref()) {
        Ruled::Consented(reason) => {
            eprintln!("owner consent: {reason}");
            Ok(true)
        }
        Ruled::Forbidden(reason) => Err(reason),
        Ruled::Waiting(reason) | Ruled::Unread(reason) | Ruled::Undecidable(reason) => {
            eprintln!("no standing ruling admits this release: {reason}");
            Ok(false)
        }
        Ruled::Unruled => Ok(false),
    }
}
