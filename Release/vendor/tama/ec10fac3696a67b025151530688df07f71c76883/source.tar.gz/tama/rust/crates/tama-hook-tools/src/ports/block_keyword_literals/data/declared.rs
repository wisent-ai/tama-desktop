//! The names a data document declares, and whether a list only refers to
//! them.
//!
//! A document names its own entries: a Cargo `[features]` entry lists the
//! features and optional dependencies of the same manifest it switches on, a
//! JSON Schema's `required` lists the properties the same schema declares, a
//! registry lists the fields its own records carry. Such a list is the
//! document's structure, followed by whatever reads the document, and decides
//! nothing about input by keyword. A list with a word the document declares
//! nowhere is still judged. What a document declares is read from the parsed
//! document itself: every key of every table or object in it, at any depth.

use std::collections::BTreeSet;

use serde_json::Value;

/// Every key a parsed document declares.
pub(super) struct Declared(BTreeSet<String>);

impl Declared {
    /// The keys of a JSON document.
    pub(super) fn of_json(document: &Value) -> Self {
        let mut names = BTreeSet::new();
        json_keys(document, &mut names);
        Self(names)
    }

    /// The keys of a TOML document. A document that does not parse declares
    /// no entries, so each of its lists is judged as it is written, the
    /// strictest reading; the parse error is said on standard error so a
    /// refusal of its lists is not taken for one of a valid document.
    pub(super) fn of_toml(text: &str) -> Self {
        let mut names = BTreeSet::new();
        match toml::from_str::<toml::Value>(text) {
            Ok(document) => toml_keys(&document, &mut names),
            Err(error) => eprintln!(
                "block-keyword-literals: the TOML document written does not parse, so it declares \
                 no entries and each of its lists is judged as written: {error}"
            ),
        }
        Self(names)
    }

    /// Whether every item names an entry this document declares.
    pub(super) fn names_all(&self, items: &[String]) -> bool {
        !items.is_empty() && items.iter().all(|item| self.0.contains(item))
    }
}

fn json_keys(value: &Value, names: &mut BTreeSet<String>) {
    match value {
        Value::Object(fields) => {
            for (key, field) in fields {
                names.insert(key.clone());
                json_keys(field, names);
            }
        }
        Value::Array(items) => items.iter().for_each(|item| json_keys(item, names)),
        _ => {}
    }
}

fn toml_keys(value: &toml::Value, names: &mut BTreeSet<String>) {
    match value {
        toml::Value::Table(fields) => {
            for (key, field) in fields {
                names.insert(key.clone());
                toml_keys(field, names);
            }
        }
        toml::Value::Array(items) => items.iter().for_each(|item| toml_keys(item, names)),
        _ => {}
    }
}
