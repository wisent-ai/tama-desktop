//! `tama justify` — record, read and remove justification registry entries.
//!
//! The authorization gate requires a justification before a new file is
//! written, and reads it from a registry keyed by absolute path. Writing that
//! registry by hand is refused by three separate gates, all of which are right
//! to protect the hook directory; what was missing is the product surface for
//! the data inside it. This command is that surface, and it enforces exactly
//! what the gate enforces, so a recorded entry is never one the gate will
//! reject: a reason that holds text. Whether a test may be written is not a
//! justification: it is the operator's own approval, `tama tests approve`.

pub(crate) mod action;
pub(crate) mod api;
pub(crate) mod cua;
pub(crate) mod registry;
pub(crate) mod ssh;

use std::path::PathBuf;

use serde_json::{json, Map, Value};

use registry::Kind;

const USAGE: &str = "usage: tama justify <record|show|remove|move|list> [--file <path>] \
[--to <path>] [--justification <text>] [--trajectory-evidence <text>] [--kind file|cua|ssh|<action kind>] [--quote <text>] [--expires-at <iso>] \
[--home <path>] [--json]\n       tama justify move --file <old path> --to <new path> [--kind file]\n       \
tama justify record --kind cua --quote <the operator's sentence> \
--app <name> --actions <a,b,c> --session <id>\n       \
tama justify record --kind cua --quote-match <text in the user message> --app <name> \
--actions <a,b,c> --session <id>\n       \
tama justify <show|remove> --kind cua <--quote <the sentence> | --quote-match <fragment of one recorded quote>>\n       \
tama justify record --kind ssh <--quote <the operator's sentence> | --quote-match <text in the user message>> \
--session <id> --target <exact ssh destination>... --operation <read|write|exec|transfer|tunnel|git> \
<--path <exact ssh:// or sftp:// URL>... | --command <exact full command>...>\n       \
tama justify <list|show|remove> --kind ssh [<--quote <the sentence> | --quote-match <fragment of one recorded quote>>]\n       \
tama justify record --kind <action kind> --session <id> --quote <the operator's exact words> \
--subject <a word of the quote naming the target> --action <exact command, absolute path, id or model>... [--transcript <session transcript>]\n       \
tama justify <list|remove> --kind <action kind> [--quote <the recorded sentence>]";

/// The usage, naming every action kind the one table holds.
fn usage() -> String {
    format!("{USAGE}   (<action kind>: {})", registry::action_labels())
}

/// The word after the flag `name`, when the flag is given.
fn option(argv: &[String], name: &str) -> Option<String> {
    let mut words = argv.iter();
    words.find(|word| *word == name)?;
    words.next().cloned()
}

struct Request {
    kind: Kind,
    home: PathBuf,
    json: bool,
    file: Option<String>,
}

/// The request the flags name. A refusal carries its exit status: an unknown
/// --kind is a usage error, an unset HOME the environment's failure.
fn request(argv: &[String]) -> Result<Request, (i32, String)> {
    let kind = match option(argv, "--kind") {
        Some(value) => Kind::parse(&value)
            .ok_or_else(|| (tama_core::exit::USAGE, format!("unknown kind {value}")))?,
        None => Kind::File,
    };
    let home = match option(argv, "--home") {
        Some(value) => PathBuf::from(value),
        None => std::env::var_os("HOME").map(PathBuf::from).ok_or_else(|| {
            (
                tama_core::exit::FAILURE,
                "HOME is not set, so no registry location is known".to_string(),
            )
        })?,
    };
    Ok(Request {
        kind,
        home,
        json: argv.iter().any(|item| item == "--json"),
        file: option(argv, "--file"),
    })
}

fn absolute(file: &str) -> Result<String, String> {
    if !file.starts_with('/') {
        return Err(format!(
            "the registry is keyed by absolute paths, and {file} is relative"
        ));
    }
    Ok(file.to_string())
}

fn entry(argv: &[String]) -> Result<Value, String> {
    let justification =
        option(argv, "--justification").ok_or_else(|| "--justification is required".to_string())?;
    if justification.trim().is_empty() {
        return Err("the justification holds no text".to_string());
    }
    let mut document = Map::new();
    document.insert("justification".to_string(), json!(justification));
    if let Some(expires) = option(argv, "--expires-at") {
        document.insert("expires_at".to_string(), json!(expires));
    }
    // The evidence `pre-edit-trajectory-evidence` reads for a trajectory,
    // keeper or routine file lives in the same entry, so the one registry
    // holds the file's reason and its measured evidence together.
    if let Some(evidence) = option(argv, "--trajectory-evidence") {
        if evidence.trim().is_empty() {
            return Err("the trajectory evidence holds no text".to_string());
        }
        document.insert(
            "trajectory_evidence_justification".to_string(),
            json!(evidence),
        );
    }
    Ok(Value::Object(document))
}

fn report(request: &Request, message: &str, payload: Value) -> i32 {
    if request.json {
        match encoded(&payload) {
            Ok(text) => println!("{text}"),
            Err(message) => return refuse(&message),
        }
    } else {
        println!("{message}");
    }
    tama_core::exit::SUCCESS
}

/// `--json`: the document as text, or why it cannot be encoded, where an
/// empty line was printed and the command still succeeded.
fn encoded(document: &Value) -> Result<String, String> {
    serde_json::to_string_pretty(document)
        .map_err(|error| format!("the answer cannot be encoded as JSON: {error}"))
}

/// A document as a person reads it: one `key: value` line per field, a
/// string as itself, null as `(none)`, and a list one compact item per line under
/// its key. `--json` prints the document itself instead.
fn lines(document: &Value) -> String {
    let scalar = |value: &Value| match value {
        Value::String(text) => text.clone(),
        Value::Null => "(none)".to_string(),
        other => other.to_string(),
    };
    let Value::Object(fields) = document else {
        return scalar(document);
    };
    let mut out = Vec::with_capacity(fields.len());
    for (key, value) in fields {
        match value {
            Value::Array(items) if items.is_empty() => out.push(format!("{key}: none")),
            Value::Array(items) => {
                out.push(format!("{key}:"));
                out.extend(items.iter().map(|item| format!("  - {}", scalar(item))));
            }
            other => out.push(format!("{key}: {}", scalar(other))),
        }
    }
    out.join("\n")
}

fn refuse(message: &str) -> i32 {
    eprintln!("{message}");
    tama_core::exit::FAILURE
}

fn misused(message: &str) -> i32 {
    eprintln!("{message}\n{}", usage());
    tama_core::exit::USAGE
}

pub fn main(argv: &[String]) -> i32 {
    // No action is a usage refusal on stderr; asking for help is an answer.
    let Some(action) = argv.first().map(String::as_str) else {
        eprintln!("{}", usage());
        return tama_core::exit::USAGE;
    };
    if matches!(action, "--help" | "-h" | "help") {
        println!("{}", usage());
        return tama_core::exit::SUCCESS;
    }
    let request = match request(argv) {
        Ok(request) => request,
        Err((code, message)) => {
            eprintln!("{message}");
            return code;
        }
    };
    let path = registry::registry_path(&request.home, request.kind);
    if request.kind == Kind::Cua {
        return cua::main(action, argv, &request);
    }
    if request.kind == Kind::Ssh {
        return ssh::main(action, argv, &request);
    }
    if request.kind.is_action_grant() {
        return action::main(action, argv, &request);
    }

    match action {
        "record" => {
            let Some(file) = request.file.clone() else {
                return misused("--file is required");
            };
            let key = match absolute(&file) {
                Ok(key) => key,
                Err(message) => return misused(&message),
            };
            let document = match entry(argv) {
                Ok(document) => document,
                Err(message) => return misused(&message),
            };
            match registry::ledger::file_record(&path, &key, document) {
                Ok(()) => report(
                    &request,
                    &format!(
                        "recorded the {} justification for {key}",
                        request.kind.label()
                    ),
                    json!({"recorded": key, "kind": request.kind.label(), "registry": path}),
                ),
                Err(message) => refuse(&message),
            }
        }
        "show" => {
            let Some(file) = request.file.clone() else {
                return misused("--file is required");
            };
            let entries = match registry::load(&path) {
                Ok(entries) => entries,
                Err(message) => return refuse(&message),
            };
            match entries.get(&file) {
                Some(found) => report(&request, &lines(found), found.clone()),
                None => refuse(&format!(
                    "no {} justification is recorded for {file}",
                    request.kind.label()
                )),
            }
        }
        "remove" => {
            let Some(file) = request.file.clone() else {
                return misused("--file is required");
            };
            match registry::ledger::file_forget(&path, &file) {
                Ok(()) => report(
                    &request,
                    &format!(
                        "removed the {} justification for {file}",
                        request.kind.label()
                    ),
                    json!({"removed": file, "kind": request.kind.label(), "registry": path}),
                ),
                Err(message) => refuse(&message),
            }
        }
        "move" => {
            let Some(file) = request.file.clone() else {
                return misused("--file is required");
            };
            let Some(to) = option(argv, "--to") else {
                return misused("--to is required: the path the file now has");
            };
            let to = match absolute(&to) {
                Ok(to) => to,
                Err(message) => return misused(&message),
            };
            match registry::ledger::file_rename(&path, &file, &to) {
                Ok(()) => report(
                    &request,
                    &format!(
                        "moved the {} justification for {file} to {to}",
                        request.kind.label()
                    ),
                    json!({"moved": file, "to": to, "kind": request.kind.label(), "registry": path}),
                ),
                Err(message) => refuse(&message),
            }
        }
        "list" => {
            let entries = match registry::load(&path) {
                Ok(entries) => entries,
                Err(message) => return refuse(&message),
            };
            let keys: Vec<&String> = entries.keys().collect();
            if request.json {
                match encoded(&json!({
                    "kind": request.kind.label(),
                    "registry": path,
                    "paths": keys,
                })) {
                    Ok(text) => println!("{text}"),
                    Err(message) => return refuse(&message),
                }
            } else {
                for key in keys {
                    println!("{key}");
                }
            }
            tama_core::exit::SUCCESS
        }
        other => misused(&format!("unknown action {other}")),
    }
}
