//! Asking a hook, before it is selected, whether it can work on this machine.
//!
//! The session path already does this: the OMP adapter runs a declared hook
//! once with `tama_activation_preflight` and refuses to activate it when the
//! answer is not an acceptance. A machine-wide selection that does not can
//! select a hook on a machine where its credential consumer is refused, and
//! from that moment every tool call an agent makes is refused with that
//! credential error — including this very command, which is then the only
//! way back.
//!
//! A hook whose binary is absent is not a failure here: it is not installed
//! yet, it will not be dispatched, and refusing the selection for that would
//! stop an operator from selecting a hook before its release lands. Only a
//! hook that runs and answers with an infrastructure failure is refused.

use std::io::Write;
use std::path::Path;
use std::process::{Command, Stdio};

use tama_hooks::hook_exec::{tokenize_command, INFRASTRUCTURE_MARKER};

/// The probe payload the adapter uses, so a hook that already understands the
/// session preflight answers this one the same way.
const PROBE: &[u8] = br#"{"tama_activation_preflight":true}"#;

/// The registry stores a hook command with the home directory left as a
/// literal `$HOME` or `~`, and the runtime expands it before spawning. The
/// probe has to expand it too: a probe that tries to run a file whose name
/// begins with `$HOME` takes the spawn failure for "not installed yet" and
/// lets the very hook this check exists for back into the selection.
fn expanded(word: &str) -> String {
    let home = tama_core::home_dir().to_string_lossy().into_owned();
    for prefix in ["$HOME/", "${HOME}/", "~/"] {
        if let Some(rest) = word.strip_prefix(prefix) {
            return format!("{home}/{rest}");
        }
    }
    match word {
        "$HOME" | "${HOME}" | "~" => home,
        _ => word.to_string(),
    }
}

/// What asking one hook produced, so a refusal and a diagnostic report the
/// same observation instead of each deciding for itself.
pub(crate) struct Probe {
    pub(crate) command: String,
    pub(crate) program: String,
    pub(crate) spawned: Result<(), String>,
    pub(crate) exit: Option<i32>,
    pub(crate) answer: String,
}

impl Probe {
    /// The infrastructure line the hook printed, which is the only answer that
    /// keeps it out of the selection.
    pub(crate) fn failure(&self) -> Option<String> {
        self.answer
            .lines()
            .find(|line| line.trim_start().starts_with(INFRASTRUCTURE_MARKER))
            .map(|line| line.trim().to_string())
    }

    pub(crate) fn verdict(&self) -> &'static str {
        match (&self.spawned, self.failure()) {
            (Err(_), _) => "not installed on this machine",
            (Ok(()), Some(_)) => "unusable: the hook cannot reach the service it needs",
            (Ok(()), None) => "usable",
        }
    }
}

pub(crate) fn probe(command: &str, session: Option<&str>) -> Option<Probe> {
    let tokens = tokenize_command(command);
    let (program, arguments) = tokens.split_first()?;
    let program = expanded(program);
    let arguments: Vec<String> = arguments.iter().map(|word| expanded(word)).collect();
    let mut probe = Probe {
        command: command.to_string(),
        program: program.clone(),
        spawned: Ok(()),
        exit: None,
        answer: String::new(),
    };
    let child = Command::new(&program)
        .args(&arguments)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn();
    let mut child = match child {
        Ok(child) => child,
        Err(error) => {
            probe.spawned = Err(error.to_string());
            return Some(probe);
        }
    };
    if let Some(stdin) = child.stdin.as_mut() {
        // A hook that never received its payload judged nothing: said as the probe's failure.
        let written = match session {
            Some(session) => serde_json::to_writer(
                stdin,
                &serde_json::json!({"tama_activation_preflight": true, "session_id": session}),
            )
            .map_err(|error| error.to_string()),
            None => stdin.write_all(PROBE).map_err(|error| error.to_string()),
        };
        if let Err(error) = written {
            probe.spawned = Err(format!(
                "the probe payload could not be written to {program}: {error}"
            ));
        }
    }
    match stado_wait::child_output(child, format!("the activation probe of {program}")) {
        Ok(output) => {
            probe.exit = output.status.code();
            probe.answer = format!(
                "{}{}",
                String::from_utf8_lossy(&output.stdout),
                String::from_utf8_lossy(&output.stderr)
            );
        }
        Err(error) => probe.spawned = Err(error.to_string()),
    }
    Some(probe)
}

/// The command the machine would actually run for one hook id.
///
/// The installed catalogue is asked first. Its commands are pinned to the
/// installed release under `hooks-runtime/current/bin`, which is what a
/// provider event reaches; a checkout's catalogue still names the unpinned
/// `$HOME/.local/bin` copy. Probing that copy reports whatever binary was
/// left there as the live hook's answer — the opposite of what the check
/// exists for.
///
/// An installed catalogue that cannot be read is an error, never passed over
/// for the checkout's: that copy names the unpinned binary this check exists
/// to keep out.
pub(crate) fn hook_command(root: &Path, wanted: &str) -> Result<Option<String>, String> {
    let installed = tama_core::home_dir()
        .join(".shared-hooks")
        .join("registry.json");
    if installed.is_file() {
        if let Some(command) = catalogue_command(&installed, wanted)? {
            return Ok(Some(command));
        }
    }
    catalogue_command(&root.join("shared-hooks").join("registry.json"), wanted)
}

/// One catalogue document, read from the exact path that holds it: the
/// installed catalogue lives under `.shared-hooks`, a checkout's under
/// `shared-hooks`, and only the file itself says which commands are pinned.
/// A catalogue that does not exist records nothing; one that cannot be read
/// or parsed is an error naming it.
fn catalogue_command(path: &Path, wanted: &str) -> Result<Option<String>, String> {
    let text = match std::fs::read_to_string(path) {
        Ok(text) => text,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(None),
        Err(error) => {
            return Err(format!(
                "the hook catalogue {} cannot be read: {error}",
                path.display()
            ))
        }
    };
    let document: serde_json::Value = serde_json::from_str(&text)
        .map_err(|error| format!("the hook catalogue {} is not JSON: {error}", path.display()))?;
    let Some(catalog) = document
        .get("catalog")
        .and_then(serde_json::Value::as_object)
    else {
        return Ok(None);
    };
    let sections = catalog
        .get("agentHooks")
        .into_iter()
        .chain(catalog.get("gitHooks"));
    for hooks in sections.filter_map(serde_json::Value::as_array) {
        for hook in hooks {
            if hook.get("id").and_then(serde_json::Value::as_str) != Some(wanted) {
                continue;
            }
            // One entry naming the hook without a command is not the end of
            // the walk: the catalogue records the same hook under both keys.
            if let Some(command) = hook.get("command").and_then(serde_json::Value::as_str) {
                return Ok(Some(command.to_string()));
            }
        }
    }
    Ok(None)
}

/// The diagnostic behind `tama enforcement preflight`: what the catalogue
/// records, what was actually executed, and what the hook answered. Written
/// because reading the code could not tell an operator why a hook was accepted
/// or refused, and one wrong guess about that costs a machine its agent.
pub(super) fn report(root: &Path, id: &str, installed: &[String], session: Option<&str>) -> i32 {
    println!("hook: {id}");
    if let Some(session) = session {
        println!("session: {session}");
    }
    println!(
        "catalogue: {}",
        if installed.binary_search(&id.to_string()).is_ok() {
            "installed"
        } else {
            "unknown to the installed registry"
        }
    );
    let recorded = match hook_command(root, id) {
        Ok(recorded) => recorded,
        Err(error) => {
            println!("catalogue read: {error}");
            None
        }
    };
    let Some(command) = recorded else {
        println!("command: none recorded, so nothing can be asked");
        println!("verdict: unusable: the catalogue records no command for this hook");
        return 1;
    };
    let Some(probe) = probe(&command, session) else {
        println!("command: {command}");
        println!("verdict: unusable: the recorded command is empty");
        return 1;
    };
    println!("command: {}", probe.command);
    println!("program: {}", probe.program);
    match &probe.spawned {
        Ok(()) => println!("exit: {}", probe.exit.unwrap_or(-1)),
        Err(error) => println!("spawn: {error}"),
    }
    println!(
        "answer: {}",
        probe.answer.lines().next().unwrap_or("").trim()
    );
    println!("verdict: {}", probe.verdict());
    i32::from(probe.failure().is_some())
}
