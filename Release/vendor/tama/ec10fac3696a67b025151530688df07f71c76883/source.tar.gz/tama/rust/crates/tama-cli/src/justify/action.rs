//! Record, list and remove the operator's grants for an action a gate
//! refuses by default — each kind and its gate in
//! [`registry::ACTION_GRANTS`] — in the registry those gates read
//! ([`tama_hook_tools::ports::operator_grant`]).
//!
//! A recorded grant is one the gate admits: its quote is asked of the
//! operator's own messages (the session's, or for a subagent those of the
//! session its `parentSession` chain ends at) and its subject of the quote
//! and of every action, by the gate's own reading, before anything is kept.

use serde_json::{json, Value};
use tama_hook_tools::ports::operator_grant::{self, Request};

use super::registry::{self, Kind};
use super::{encoded, misused, option, refuse, report, Request as CliRequest};

/// Every value the flag `name` is given, in order.
fn options(argv: &[String], name: &str) -> Vec<String> {
    argv.windows(2)
        .filter(|pair| pair[0] == name)
        .map(|pair| pair[1].trim().to_string())
        .collect()
}

pub(super) fn main(action: &str, argv: &[String], request: &CliRequest) -> i32 {
    let Kind::Action(grant) = request.kind else {
        return misused(&format!(
            "--kind {} is no operator's grant for one action; use one of {}",
            request.kind.label(),
            registry::action_labels()
        ));
    };
    let path = registry::registry_path(&request.home, request.kind);
    let gate = grant.gate;
    match action {
        "record" => match recorded(argv, gate) {
            Ok(entry) => match keep(&path, entry.clone()) {
                Ok(()) => report(
                    request,
                    &format!(
                        "recorded the operator's {} grant for {gate}",
                        request.kind.label()
                    ),
                    json!({"kind": request.kind.label(), "registry": path, "grant": entry}),
                ),
                Err(message) => refuse(&message),
            },
            Err(message) => misused(&message),
        },
        "list" => match grants(&path) {
            Ok(all) => {
                let mine: Vec<Value> = all
                    .into_iter()
                    .filter(|entry| entry.get("gate").and_then(Value::as_str) == Some(gate))
                    .collect();
                let document =
                    json!({"kind": request.kind.label(), "registry": path, "grants": mine});
                match encoded(&document) {
                    Ok(text) => println!("{text}"),
                    Err(message) => return refuse(&message),
                }
                tama_core::exit::SUCCESS
            }
            Err(message) => refuse(&message),
        },
        "remove" => {
            let Some(quote) = option(argv, "--quote") else {
                return misused("--quote is required: the recorded sentence to remove");
            };
            match forget(&path, gate, &quote) {
                Ok(count) => report(
                    request,
                    &format!(
                        "removed {count} {} grant(s) for that quote",
                        request.kind.label()
                    ),
                    json!({"kind": request.kind.label(), "registry": path, "removed": quote, "count": count}),
                ),
                Err(message) => refuse(&message),
            }
        }
        other => misused(&format!(
            "unknown action {other} for --kind {}",
            request.kind.label()
        )),
    }
}

/// The entry the flags record, once the gate's own reading admits it.
fn recorded(argv: &[String], gate: &str) -> Result<Value, String> {
    let session = option(argv, "--session").ok_or("--session is required: this session's id")?;
    if session.is_empty()
        || !session
            .chars()
            .all(|c| c.is_ascii_alphanumeric() || c == '-')
    {
        return Err("--session must be the exact OMP session identifier".into());
    }
    let quote = option(argv, "--quote").filter(|quote| !quote.trim().is_empty());
    let quote = quote.ok_or("--quote is required: the operator's exact words")?;
    let subject = option(argv, "--subject").filter(|subject| !subject.trim().is_empty());
    let subject = subject.ok_or("--subject is required: a word of the quote naming the target")?;
    let actions = options(argv, "--action");
    if actions.is_empty() || actions.iter().any(String::is_empty) {
        return Err("--action is required, once per exact command or absolute path".into());
    }
    let mut payload = json!({ "session_id": session });
    if let Some(transcript) = option(argv, "--transcript") {
        payload["transcript_path"] = json!(transcript);
    }
    if !operator_grant::operator_said(&payload, &quote) {
        return Err(format!(
            "the quote is not word for word in an operator message of session {session} (for a \
             subagent, of the session its parentSession chain ends at); nothing was recorded"
        ));
    }
    let entry = json!({
        "gate": gate,
        "session": session,
        "userRequestQuote": quote,
        "subject": subject.trim(),
        "actions": actions,
        "recordedAt": tama_core::clock::iso_now(),
    });
    for action in &actions {
        let paths = [action.clone()];
        let asked = Request {
            gate,
            command: Some(action),
            paths: &paths,
        };
        if !operator_grant::covers(&entry, &asked, &session) {
            return Err(format!(
                "the gate would not admit `{action}` from this grant: the subject must be a word \
                 of the quote and of every action; nothing was recorded"
            ));
        }
    }
    Ok(entry)
}

fn checked(
    mut document: serde_json::Map<String, Value>,
) -> Result<serde_json::Map<String, Value>, String> {
    if document.is_empty() {
        document.insert("schema".into(), json!(operator_grant::SCHEMA));
        document.insert("grants".into(), json!([]));
    }
    if document.get("schema").and_then(Value::as_str) != Some(operator_grant::SCHEMA)
        || !document.get("grants").is_some_and(Value::is_array)
    {
        return Err(format!(
            "the registry is not a {} document; nothing was changed",
            operator_grant::SCHEMA
        ));
    }
    Ok(document)
}

fn grants(path: &std::path::Path) -> Result<Vec<Value>, String> {
    let document = checked(registry::load(path)?)?;
    Ok(document["grants"].as_array().cloned().unwrap_or_default())
}

/// Keep `entry`, newest first, replacing one recorded for the same gate,
/// session, quote and actions.
fn keep(path: &std::path::Path, entry: Value) -> Result<(), String> {
    registry::update(path, |document| {
        let mut document = checked(document)?;
        let entries = document["grants"]
            .as_array_mut()
            .ok_or("grants is not an array")?;
        let same = |existing: &Value| {
            ["gate", "session", "userRequestQuote", "actions"]
                .iter()
                .all(|key| existing.get(key) == entry.get(key))
        };
        entries.retain(|existing| !same(existing));
        entries.insert(0, entry.clone());
        Ok(document)
    })
}

/// Remove every grant of `gate` recorded for `quote`; how many there were.
fn forget(path: &std::path::Path, gate: &str, quote: &str) -> Result<usize, String> {
    let mut removed = 0;
    registry::update(path, |document| {
        let mut document = checked(document)?;
        let entries = document["grants"]
            .as_array_mut()
            .ok_or("grants is not an array")?;
        let before = entries.len();
        entries.retain(|entry| {
            !(entry.get("gate").and_then(Value::as_str) == Some(gate)
                && entry.get("userRequestQuote").and_then(Value::as_str) == Some(quote))
        });
        removed = before - entries.len();
        if removed == 0 {
            return Err("no grant of this kind is recorded for that quote".into());
        }
        Ok(document)
    })?;
    Ok(removed)
}
