//! What a shell line deletes: the operands of `rm`, `unlink`, `rmdir`,
//! `shred`, `srm` and `trash`, the paths `git rm` and `git clean` remove,
//! the starting points of a `find` that deletes, and what `rsync` removes
//! with `--delete` or `--remove-source-files`. Each command is read as the
//! shell runs it ([`command_path`]): every command of the line, through
//! wrappers and `sh -c`.

use std::path::{Path, PathBuf};

use serde_json::Value;

use super::Target;
use crate::ports::command_path::{self, computed, shown};

/// The programs whose operands are deleted.
pub(super) const DELETING: &[&str] = &["rm", "unlink", "rmdir", "shred", "srm", "trash"];
/// The programs that delete through a word of their own (`git clean`,
/// `find -delete`, `rsync --delete`, `xargs rm`).
const DELETING_THROUGH: &[&str] = &["git", "find", "rsync", "xargs"];
/// Words that mark such a command of an unreadable line as deleting.
const DELETION_WORDS: &[&str] = &[
    "rm",
    "unlink",
    "rmdir",
    "shred",
    "srm",
    "trash",
    "clean",
    "-delete",
    "--delete",
    "--remove-source-files",
];
/// Git's global options that carry their value in the next word (git(1)).
const GIT_VALUED: &[&str] = &[
    "-C",
    "-c",
    "--git-dir",
    "--work-tree",
    "--namespace",
    "--config-env",
];
/// `find` actions that run a program on each match (find(1)).
const FIND_RUNNERS: &[&str] = &["-exec", "-execdir", "-ok", "-okdir"];
/// rsync options that carry their value in the next word (rsync(1)).
const RSYNC_VALUED: &[&str] = &[
    "-e",
    "--rsh",
    "--exclude",
    "--include",
    "--filter",
    "-f",
    "--files-from",
    "--exclude-from",
    "--include-from",
    "--link-dest",
    "--compare-dest",
    "--copy-dest",
    "--backup-dir",
    "--chmod",
    "--log-file",
    "-T",
    "--temp-dir",
    "--partial-dir",
    "--suffix",
    "-B",
    "--block-size",
];

/// Every target the shell line in `payload` deletes, read against `cwd`.
pub(super) fn targets(payload: &Value, cwd: &Path, command: &str) -> Vec<Target> {
    let mut found = Vec::new();
    if let Err(cause) = collect(payload, cwd, &mut found) {
        // Only a deleting word the shell runs makes an unreadable line one
        // that may delete: quoted data (a prompt, a message) is no command.
        if mentions_deletion(&crate::ports::shell_text::effective_payload(
            payload, command,
        )) {
            found.push(Target::Unknown(cause));
        }
    }
    found
}

fn collect(payload: &Value, cwd: &Path, found: &mut Vec<Target>) -> Result<(), String> {
    let bases = bases(payload, cwd)?;
    let add = |words: Vec<String>, base: Option<PathBuf>, found: &mut Vec<Target>| {
        let own = base.map(|dir| vec![dir]);
        for word in words {
            found.push(target(word, own.as_deref().unwrap_or(&bases), cwd));
        }
    };
    // A deleting program with no operand deletes nothing the line names; the
    // reading that hides quoted words meets every quoted operand that way,
    // and operands handed over by `xargs` are refused below.
    for program in DELETING {
        for reached in command_path::reached(payload, &[program.to_string()])? {
            add(operands(&reached.args, &[]), None, found);
        }
    }
    for reached in command_path::reached(payload, &["git".to_string()])? {
        if let Some((words, base)) = git(&reached.args) {
            add(
                words,
                base.map(|dir| super::area::absolute(cwd, &dir)),
                found,
            );
        }
    }
    for reached in command_path::reached(payload, &["find".to_string()])? {
        if let Some(words) = find(&reached.args) {
            add(words, None, found);
        }
    }
    for reached in command_path::reached(payload, &["rsync".to_string()])? {
        add(rsync(&reached.args), None, found);
    }
    for reached in command_path::reached(payload, &["xargs".to_string()])? {
        if reached
            .args
            .iter()
            .any(|word| DELETING.contains(&basename(word)))
        {
            found.push(Target::Unknown(
                "`xargs` hands a deleting program its operands from standard input, which cannot be read".to_string(),
            ));
        }
    }
    Ok(())
}

/// The target one word names: an absolute word against nothing else, a
/// relative one against every folder the line may run it in.
fn target(word: String, bases: &[PathBuf], cwd: &Path) -> Target {
    if computed(&word) {
        return Target::Unknown(format!(
            "`{}` is a value the shell computes when it runs",
            shown(&word)
        ));
    }
    if word.starts_with('/') || word.starts_with('~') {
        return Target::Paths(vec![super::area::absolute(cwd, &word)]);
    }
    Target::Paths(bases.iter().map(|base| base.join(&word)).collect())
}

/// The folders a relative word may be read in: the call's own, and each one
/// a `cd` or `pushd` of the line moves to, since which of them a later
/// command runs in is the shell's to decide.
fn bases(payload: &Value, cwd: &Path) -> Result<Vec<PathBuf>, String> {
    let mut bases = vec![cwd.to_path_buf()];
    for program in ["cd", "pushd"] {
        for reached in command_path::reached(payload, &[program.to_string()])? {
            let words = operands(&reached.args, &[]);
            match words.first().map(String::as_str) {
                None => bases.push(crate::util::home_dir()),
                Some("-") => {
                    return Err(format!(
                        "`{program} -` moves to a folder the shell remembers"
                    ))
                }
                Some(word) if computed(word) => {
                    return Err(format!(
                        "`{program} {}` moves to a folder the shell computes",
                        shown(word)
                    ))
                }
                Some(word) => bases.push(super::area::absolute(cwd, word)),
            }
        }
    }
    Ok(bases)
}

/// The words of `args` that are no options; after `--` every word is one,
/// and the word after an option of `valued` is its value.
fn operands(args: &[String], valued: &[&str]) -> Vec<String> {
    let mut words = Vec::new();
    let mut ended = false;
    let mut skip = false;
    for word in args {
        if skip {
            skip = false;
        } else if ended || !word.starts_with('-') || word == "-" {
            words.push(word.clone());
        } else if word == "--" {
            ended = true;
        } else if valued.contains(&word.as_str()) {
            skip = true;
        }
    }
    words
}

/// What `git <args>` deletes from the working tree, and the folder `-C`
/// names: `git rm` (not `--cached`) its paths, `git clean` (not `-n`) its
/// paths, or the folder it runs in when it names none.
fn git(args: &[String]) -> Option<(Vec<String>, Option<String>)> {
    let mut base = None;
    let mut index = 0;
    while index < args.len() && args[index].starts_with('-') {
        if GIT_VALUED.contains(&args[index].as_str()) {
            if args[index] == "-C" {
                base = args.get(index + 1).cloned();
            }
            index += 1;
        }
        index += 1;
    }
    let (command, rest) = (args.get(index)?, &args[index + 1..]);
    match command.as_str() {
        "rm" if !rest.iter().any(|word| word == "--cached") => Some((operands(rest, &[]), base)),
        "clean" if !rest.iter().any(|word| word == "-n" || word == "--dry-run") => {
            let words = operands(rest, &["-e", "--exclude"]);
            Some((
                if words.is_empty() {
                    vec![".".to_string()]
                } else {
                    words
                },
                base,
            ))
        }
        _ => None,
    }
}

/// The starting points of a `find` that deletes what it matches, by
/// `-delete` or by running a deleting program on each match.
fn find(args: &[String]) -> Option<Vec<String>> {
    let deletes = args.iter().enumerate().any(|(index, word)| {
        word == "-delete"
            || (FIND_RUNNERS.contains(&word.as_str())
                && args
                    .get(index + 1)
                    .is_some_and(|program| DELETING.contains(&basename(program))))
    });
    if !deletes {
        return None;
    }
    let starts: Vec<String> = args
        .iter()
        .skip_while(|word| matches!(word.as_str(), "-H" | "-L" | "-P"))
        .take_while(|word| !word.starts_with('-') && *word != "(" && *word != "!")
        .cloned()
        .collect();
    Some(if starts.is_empty() {
        vec![".".to_string()]
    } else {
        starts
    })
}

/// What `rsync` removes on this machine: the destination of a `--delete`,
/// the sources of `--remove-source-files`; a remote side is the SSH gate's.
fn rsync(args: &[String]) -> Vec<String> {
    let words = operands(args, RSYNC_VALUED);
    let local = |word: &String| !remote(word);
    let mut removed = Vec::new();
    if args.iter().any(|word| word.starts_with("--delete")) {
        removed.extend(words.last().filter(|word| local(word)).cloned());
    }
    if args.iter().any(|word| word == "--remove-source-files") && words.len() > 1 {
        removed.extend(
            words[..words.len() - 1]
                .iter()
                .filter(|word| local(word))
                .cloned(),
        );
    }
    removed
}

/// Whether an rsync operand names another host: `host:path` or `rsync://`.
fn remote(word: &str) -> bool {
    word.contains("://")
        || word
            .split('/')
            .next()
            .is_some_and(|head| head.contains(':'))
}

fn basename(word: &str) -> &str {
    word.rsplit('/').next().unwrap_or(word)
}

/// Whether `command` holds a word that deletes, read as plain words.
fn mentions_deletion(command: &str) -> bool {
    crate::ports::operator_grant::segments::commands(command)
        .iter()
        .any(|words| match words.split_first() {
            Some((program, _)) if DELETING.contains(program) => true,
            Some((program, rest)) if DELETING_THROUGH.contains(program) => rest
                .iter()
                .any(|word| DELETION_WORDS.contains(&basename(word))),
            _ => false,
        })
}
