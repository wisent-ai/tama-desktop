//! A judge request waits only while Brama keeps declaring it serves.
//!
//! A request forwarded through the resolver to a Brama that never answers
//! sat in phase `answer` for hours: the client had no end, and the resolver
//! held the adapter for every later judge. Nothing here guesses how long an
//! answer may take. While the client waits, this watch asks Brama's own
//! readiness (`GET /readyz`) on the same adapter, naming the digest of the
//! answer it last read, and Brama answers when that answer changes: one
//! request per change, not one per answer. A Brama that stops declaring
//! itself ready, or an adapter that stops answering the readiness question
//! at all, ends the waiting client, and the request is refused with that
//! cause instead of waiting without end. A Brama that names no digest
//! cannot be waited on that way; the request is then not watched further,
//! and that is said on stderr. A resolver that forwards the readiness
//! question too and holds it unanswered leaves the watch waiting with the
//! client; what frees that is the resolver's own refusal of a forwarded
//! connection its remote never answers (Stado).

use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};
use std::thread::JoinHandle;

/// The watch over one waiting client.
pub(in crate::brama) struct Watch {
    ended: Arc<AtomicBool>,
    cause: Arc<Mutex<Option<String>>>,
    /// The readiness question standing now, ended when the watch is over.
    asking: Arc<Mutex<Option<u32>>>,
    thread: Option<JoinHandle<()>>,
}

impl Watch {
    /// Start watching the client `client_pid` runs for the request to
    /// `endpoint`. The readiness address is read from the endpoint; a
    /// request whose endpoint names no readiness address is not watched,
    /// and the cause is said on stderr so the gap is not silent.
    pub(in crate::brama) fn over(endpoint: &str, client_pid: u32) -> Watch {
        let ended = Arc::new(AtomicBool::new(false));
        let cause = Arc::new(Mutex::new(None));
        let asking = Arc::new(Mutex::new(None));
        let readiness = match super::readiness_url(endpoint) {
            Ok(readiness) => readiness,
            Err(error) => {
                eprintln!("tama: the judge request to {endpoint} is not watched for Brama's readiness: {error}");
                return Watch {
                    ended,
                    cause,
                    asking,
                    thread: None,
                };
            }
        };
        let endpoint = endpoint.to_owned();
        let thread = std::thread::spawn({
            let ended = Arc::clone(&ended);
            let cause = Arc::clone(&cause);
            let asking = Arc::clone(&asking);
            move || {
                let mut after: Option<String> = None;
                while !ended.load(Ordering::SeqCst) {
                    let answer =
                        super::ask_ready(&readiness, after.as_deref()).and_then(|client| {
                            set_asking(&asking, Some(client.id()));
                            // The watch ended before this question was recorded:
                            // `finish` saw none standing, so it is ended here.
                            if ended.load(Ordering::SeqCst) {
                                end_client(client.id());
                            }
                            super::readiness_answer(&endpoint, &readiness, client)
                        });
                    set_asking(&asking, None);
                    if ended.load(Ordering::SeqCst) {
                        return;
                    }
                    match answer {
                        Ok(Some(digest)) => after = Some(digest),
                        Ok(None) => {
                            eprintln!(
                                "tama: the judge request to {endpoint} is no longer watched: \
                                 Brama at {readiness} names no digest of its readiness answer, \
                                 so a change of it cannot be waited on"
                            );
                            return;
                        }
                        Err(refusal) => {
                            let said = format!(
                                "the judge request to {endpoint} was ended while it waited: \
                                 Brama no longer declares it serves ({refusal})"
                            );
                            if let Ok(mut held) = cause.lock() {
                                *held = Some(said);
                            }
                            end_client(client_pid);
                            return;
                        }
                    }
                }
            }
        });
        Watch {
            ended,
            cause,
            asking,
            thread: Some(thread),
        }
    }

    /// The watch is over: the client ended on its own. The cause the watch
    /// recorded, when it ended the client itself.
    pub(in crate::brama) fn finish(mut self) -> Option<String> {
        self.ended.store(true, Ordering::SeqCst);
        // The readiness question stands until Brama's answer changes; the
        // watch is over, so it is ended rather than waited for.
        let standing = match self.asking.lock() {
            Ok(held) => *held,
            Err(poisoned) => *poisoned.into_inner(),
        };
        if let Some(question) = standing {
            end_client(question);
        }
        if let Some(thread) = self.thread.take() {
            if thread.join().is_err() {
                eprintln!("tama: the readiness watch over a judge request ended in a panic");
            }
        }
        match self.cause.lock() {
            Ok(mut held) => held.take(),
            Err(poisoned) => poisoned.into_inner().take(),
        }
    }
}

/// Record the readiness question standing now, or that none stands.
fn set_asking(asking: &Mutex<Option<u32>>, question: Option<u32>) {
    match asking.lock() {
        Ok(mut held) => *held = question,
        Err(poisoned) => *poisoned.into_inner() = question,
    }
}

/// End the waiting client the way its owner would: the client is this
/// program's own curl, named by the pid the request recorded.
fn end_client(client_pid: u32) {
    let Ok(pid) = libc::pid_t::try_from(client_pid) else {
        eprintln!("tama: cannot end the judge client {client_pid}: not a process id here");
        return;
    };
    // SAFETY: a signal to one process id this program started; the kernel
    // refuses a pid that is not ours to signal.
    if unsafe { libc::kill(pid, libc::SIGTERM) }.is_negative() {
        eprintln!(
            "tama: cannot end the judge client {client_pid}: {}",
            std::io::Error::last_os_error()
        );
    }
}
