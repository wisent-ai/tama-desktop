//! Building the engine: where its state, registry and policy come from,
//! and the two small helpers the transitions need.
//!
//! Split out of `engine/mod.rs`, which had grown past the
//! three-hundred-line limit.

use std::fs::{self, OpenOptions};
use std::io::Write;
use std::path::PathBuf;

use tama_core::registry::Registry;

use super::lookup::load_registry;
use super::{Engine, Policy};
use crate::state::{open_state_store, HookState, StateStore, TransitionResult, Warn};
use crate::util::home_dir;

pub(super) fn invalid_observation(state: HookState) -> TransitionResult {
    TransitionResult {
        ok: false,
        persisted: false,
        mode: String::new(),
        transition: None,
        reason: Some("invalid-observation".to_string()),
        state,
    }
}

/// The hook's stored state, or why the store's snapshot of it is not one:
/// read as a fresh hook, a corrupt record restarted its counts unseen.
pub(super) fn snapshot_hook(store: &StateStore, hook_id: &str) -> Result<HookState, String> {
    let value = store.snapshot(Some(hook_id))?;
    serde_json::from_value::<HookState>(value)
        .map_err(|error| format!("the adaptive state of hook {hook_id:?} is not readable: {error}"))
}

/// The variable `key` when it is set; one that is set but not Unicode is
/// the error, never read as unset.
fn variable(key: &str) -> Result<Option<String>, String> {
    match std::env::var(key) {
        Ok(value) => Ok(Some(value)),
        Err(std::env::VarError::NotPresent) => Ok(None),
        Err(error) => Err(format!("{key} cannot be read: {error}")),
    }
}

/// `loadEngine(env = process.env)`; a policy or registry that cannot be read
/// is refused naming the file.
pub fn load_engine() -> Result<Engine, String> {
    load_engine_with(variable)
}

/// `loadEngine(env)` with an explicit environment lookup. The state lives
/// where HOOKS_ADAPTIVE_STATE names, or in `~/.hooks-adaptive`; the registry
/// is the one AGENT_HOOK_REGISTRY names, or the operator's own.
pub fn load_engine_with(
    env: impl Fn(&str) -> Result<Option<String>, String>,
) -> Result<Engine, String> {
    let named = |key: &str| -> Result<Option<PathBuf>, String> {
        Ok(env(key)?
            .filter(|value| !value.is_empty())
            .map(PathBuf::from))
    };
    let state_dir = match named("HOOKS_ADAPTIVE_STATE")? {
        Some(path) => path,
        None => home_dir().join(".hooks-adaptive"),
    };
    let registry_path = match named(tama_core::HOOK_REGISTRY_VARIABLE)? {
        Some(path) => path,
        None => home_dir().join(".shared-hooks").join("registry.json"),
    };
    let policy = Policy::declared()?;
    let registry_value = load_registry(&registry_path)?;
    let registry: Registry = serde_json::from_value(registry_value.clone()).map_err(|error| {
        format!(
            "{} does not hold a hook registry: {error}",
            registry_path.display()
        )
    })?;

    let warn: Warn = {
        let state_dir = state_dir.clone();
        std::sync::Arc::new(move |text: &str| {
            let log = state_dir.join("warnings.log");
            let attempt = (|| -> std::io::Result<()> {
                fs::create_dir_all(&state_dir)?;
                let mut file = OpenOptions::new().append(true).create(true).open(&log)?;
                file.write_all(format!("{} {}\n", tama_core::clock::iso_now(), text).as_bytes())?;
                Ok(())
            })();
            // A warning the log cannot take is said on stderr with why:
            // dropped, the store's trouble would go unrecorded.
            if let Err(error) = attempt {
                eprintln!(
                    "adaptive warning not logged to {}: {error}: {text}",
                    log.display()
                );
            }
        })
    };

    let store = open_state_store(&state_dir, warn);
    store.quarantine_legacy();
    Ok(Engine {
        state_dir,
        registry_path,
        policy,
        registry,
        registry_value,
        store,
    })
}
