//! Activating the hook release Tama's Stado release carries: the batch build
//! made the one program and the sealed hook release from one commit, and
//! `stado product install tama --surface cli` placed both, the program in
//! `~/.stado/bin` and the release under `~/.stado/share/tama`. Nothing is
//! built, staged or sealed on this machine.
//!
//! Kept apart from the command itself so that reading what `tama hooks
//! release` refuses is not the same as reading how a machine is brought up to
//! the release it should be running.

use std::path::{Path, PathBuf};

use super::super::declare::refuse;
use super::super::install::install_release;
use super::super::warm;
use super::binaries::{build_digest, installed_digests, record_digests};
use super::retire;
use super::support::enforce_selection;
use super::{provenance_line, PROGRAM, RETIRED_PROGRAMS};

/// Where `stado product install tama` places the release's `share/tama`.
pub(super) const INSTALLED_SHARE: &str = ".stado/share/tama";
/// The sealed hook release inside it.
pub(super) const HOOK_RELEASE: &str = "hook-release";
/// The registry of the hook release the engine currently runs.
const RUNTIME_REGISTRY: &str =
    "Library/Application Support/Tama/hooks-runtime/current/shared-hooks/registry.json";

/// The sealed hook release `stado product install tama` placed on this
/// machine.
pub(super) fn installed_release(home: &Path) -> PathBuf {
    home.join(INSTALLED_SHARE).join(HOOK_RELEASE)
}

pub(super) fn activate(root: &Path, enforce: &[String]) -> i32 {
    // The one HOME reader: read as the empty path, an unset or empty HOME
    // would activate into ./.local and ./Library of whatever directory the
    // command runs from.
    let home = tama_core::home_dir();
    let release = installed_release(&home);
    let recorded = match installed_digests(&home) {
        Ok(recorded) => recorded,
        Err(error) => return refuse(&error),
    };
    let target = home.join(".local/bin").join(PROGRAM);
    let digest = match build_digest(&target) {
        Ok(Some(digest)) => digest,
        Ok(None) => {
            return refuse(&format!(
                "{} is missing; `stado product install tama --surface cli` installs it",
                target.display()
            ))
        }
        Err(error) => return refuse(&error),
    };
    // Only the one program is recorded; every other name a release recorded
    // was a separate program and is removed from the path below.
    let digests = std::collections::BTreeMap::from([(PROGRAM.to_string(), digest)]);
    if let Err(error) = record_digests(&home, &digests) {
        return refuse(&error);
    }
    // An installed copy run from the operator's own prompt has no checkout
    // under it; without this it reports every hook as uninstalled.
    let checkout = home.join(tama_core::INSTALLED_CHECKOUT_FILE);
    if let Some(parent) = checkout.parent() {
        if let Err(error) = std::fs::create_dir_all(parent) {
            return refuse(&format!("cannot create {}: {error}", parent.display()));
        }
    }
    if let Err(error) = std::fs::write(&checkout, format!("{}\n", root.display())) {
        return refuse(&format!("cannot write {}: {error}", checkout.display()));
    }
    // A program nobody has run yet still owes the operating system its first
    // assessment; paid inside a live event it blocks the turn, so it is paid
    // here, and a cold or unusable hook is reported.
    let registry = release.join("shared-hooks/registry.json");
    let hooks = match warm::registry_hooks(&registry) {
        Ok(hooks) => hooks,
        Err(error) => return refuse(&error),
    };
    let mut to_warm = vec![warm::runtime_binary(PROGRAM, target)];
    to_warm.extend(hooks.iter().cloned());
    let warmed = warm::warm_hooks(root, &to_warm);
    // Reported and carried: the release is still activated, since the hooks
    // the engine runs now are no better, but the command ends failed so an
    // unusable hook binary is not read as a clean install.
    let checkout_warm = warm::report(&warmed, false);
    retire::inactive_launch_agents(&registry, &home);
    retire::renamed_programs(&home, RETIRED_PROGRAMS);
    retire::separate_hook_programs(&home, &recorded, PROGRAM);
    // The hooks the engine ran before this release, read before it is replaced,
    // so the hooks this release brings are named. A machine in mode `all`
    // enforces them at once; one in mode `only` enforces what its operator
    // selected and nothing a release brings, so each new hook is named with
    // the command that selects it. No runtime registry yet (a first install)
    // ran no hooks; one that exists and cannot be read is refused, never read
    // as "ran none".
    let runtime_registry = home.join(RUNTIME_REGISTRY);
    let before: std::collections::BTreeSet<String> = match std::fs::metadata(&runtime_registry) {
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Default::default(),
        _ => match warm::registry_hooks(&runtime_registry) {
            Ok(hooks) => hooks.into_iter().map(|hook| hook.id).collect(),
            Err(error) => return refuse(&error),
        },
    };
    match install_release(&release, &home, None, true) {
        Ok(said) => match said["installed"]["releaseId"].as_str() {
            Some(id) => println!("installed release: {id}"),
            None => {
                return refuse(&format!(
                    "the hook release was installed, but the install's answer names no installed.releaseId: {said}"
                ))
            }
        },
        Err(error) => return refuse(&format!("Tama hook release installation failed: {error}")),
    }
    // A session-control install rewrites only the dispatchers already Tama's.
    // Release activation reconnects all of them where Git runs Tama's
    // dispatchers: preserve any foreign hook (including Git LFS) and chain it
    // behind the managed dispatcher. Where the operator took Git's hooks path
    // away (`tama uninstall --unset-git-config`), a release keeps it away:
    // `tama install --set-git-config` is his to run again.
    let home_text = home.to_string_lossy().into_owned();
    match tama_core::install::current_global_hooks_path(Some(&home_text)) {
        Ok(None) => println!(
            "Git hooks left unconnected: core.hooksPath is unset; `tama install --set-git-config` connects them"
        ),
        Ok(Some(_)) => {
            let runtime = home.join("Library/Application Support/Tama/hooks-runtime/current");
            let git = tama_core::install::install_global_git(
                &runtime,
                &tama_core::install::InstallOptions {
                    home: Some(home_text.clone()),
                    hooks_path: None,
                    set_global_config: true,
                },
            );
            match git {
                Ok(installed) => {
                    println!("Git hooks connected at {}", installed.hooks_path);
                    let states = tama_core::install::dispatcher_states(
                        &installed.hooks_path,
                        &home_text,
                        &tama_core::install::GIT_HOOKS
                            .iter()
                            .map(|hook| (*hook).to_string())
                            .collect::<Vec<_>>(),
                    );
                    for state in states {
                        println!("{}", state.describe());
                    }
                }
                Err(error) => {
                    return refuse(&format!(
                        "Hook runtime installed, but Git dispatchers could not be connected: {error}"
                    ));
                }
            }
        }
        Err(error) => {
            return refuse(&format!(
                "Hook runtime installed, but whether Git runs its dispatchers cannot be read: {error}"
            ));
        }
    }
    // The release just installed is a second set of files, and the engine
    // runs those, not the ones warmed above, so they are warmed as well.
    let sealed = match warm::release_hooks(&home, &hooks) {
        Ok(sealed) => sealed,
        Err(cause) => {
            return refuse(&format!(
                "Hook runtime installed, but its release cannot be warmed: {cause}"
            ))
        }
    };
    let release_warm = if sealed.is_empty() {
        libc::EXIT_SUCCESS
    } else {
        warm::report(&warm::warm_hooks(root, &sealed), false)
    };
    if let Some(provenance) = provenance_line() {
        println!("{provenance}");
    }
    if !before.is_empty() {
        for hook in &hooks {
            if !before.contains(&hook.id) && !enforce.contains(&hook.id) {
                println!(
                    "new in this release: {}; a machine in mode `only` enforces it once its \
                     operator runs `tama enforcement add {}`",
                    hook.id, hook.id
                );
            }
        }
    }
    let enforced = enforce_selection(root, enforce);
    if enforced != libc::EXIT_SUCCESS {
        return enforced;
    }
    match [checkout_warm, release_warm]
        .into_iter()
        .find(|code| *code != libc::EXIT_SUCCESS)
    {
        Some(code) => {
            eprintln!(
                "the release is active, but the hook binaries named above are unusable; a live event refuses on each until `tama hooks warm` reports it warm"
            );
            code
        }
        None => libc::EXIT_SUCCESS,
    }
}
