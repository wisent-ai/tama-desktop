//! Word lists in data files. Moving a list out of code into JSON is not a
//! repair while the guard never opens a JSON file: a task vocabulary in a
//! data file takes more phrases without a refusal. Command declarations and
//! a table's header and rows (`table.rs`) are read structurally before the
//! remaining lists are judged.

mod declared;
mod table;
mod yaml;

use std::borrow::Cow;
use std::sync::LazyLock;

use regex::Regex;
use serde_json::Value;

use super::super::transport_common as common;
use super::finder::{data_collections, is_word, line_of};
use super::is_list;
use declared::Declared;

/// The data formats a program reads its lists from.
const DATA_SUFFIXES: &[&str] = &[".json", ".jsonc", ".json5", ".yaml", ".yml", ".toml"];
const JSON_SUFFIXES: &[&str] = &[".json", ".jsonc", ".json5"];
/// Stado's release manifest, whose promotion channels are release states.
const RELEASE_MANIFEST: &str = ".wisent-release.json";
/// The `promotion` field of a release manifest that names those states.
const CHANNELS_FIELD: &str = "channels";
/// Cargo's manifest, whose name arrays Cargo itself reads: a dependency's
/// `features` switch on that crate's own compile-time features, a
/// workspace's `members`, `default-members` and `exclude` name its crates,
/// a package's `include` and `exclude` name its files and its `keywords`
/// and `categories` are what crates.io lists it under. These keys are
/// Cargo's manifest schema, an identity of Cargo's format imposed from
/// outside, not a vocabulary of ours. A `[features]` entry needs no such
/// key: the features and dependencies it lists are declared by the same
/// manifest (`declared.rs`).
const CARGO_MANIFEST: &str = "Cargo.toml";
static CARGO_NAME_ARRAYS: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(
        "\\b(?:features|default-members|members|exclude|include|keywords|categories)\\s*=\\s*\\[[^\\[\\]]*\\]",
    )
});

/// One YAML block-sequence item: its indent and its scalar.
static YAML_ITEM: LazyLock<Regex> =
    LazyLock::new(|| common::compile("^(\\s*)-\\s+[\"']?([^\"'#]*?)[\"']?\\s*$"));
/// One YAML flow sequence written on one line.
static YAML_FLOW: LazyLock<Regex> = LazyLock::new(|| common::compile("\\[([^\\[\\]\\n]*)\\]"));
/// One JSON string literal that opens an array or follows a member of one:
/// `[` or `,`, then the literal.
static JSON_MEMBER: LazyLock<Regex> =
    LazyLock::new(|| common::compile("[\\[,]\\s*(?P<literal>\"(?:[^\"\\\\]|\\\\.)*\")"));

pub(super) fn is_data(path: &str) -> bool {
    DATA_SUFFIXES.iter().any(|suffix| path.ends_with(suffix))
}

/// Every list of words in one data file, as (line, words). A list whose
/// every word names an entry the same document declares is the document's
/// own structure and is left out (`declared.rs`).
pub(super) fn word_lists(path: &str, text: &str) -> Vec<(usize, Vec<String>)> {
    if JSON_SUFFIXES.iter().any(|suffix| path.ends_with(suffix)) {
        return json_lists(path, text);
    }
    let judged = if std::path::Path::new(path)
        .file_name()
        .and_then(|name| name.to_str())
        == Some(CARGO_MANIFEST)
    {
        Cow::Owned(without_cargo_name_arrays(text))
    } else if path.ends_with(".toml") {
        Cow::Borrowed(text)
    } else {
        yaml::without_commands(text)
    };
    let mut found = data_collections(judged.as_ref());
    if path.ends_with(".toml") {
        let declared = Declared::of_toml(text);
        found.retain(|(_, words)| !declared.names_all(words));
    } else {
        found.extend(yaml_blocks(judged.as_ref()));
        found.extend(yaml_flows(judged.as_ref()));
    }
    found.sort();
    found.dedup();
    found
}

/// A Cargo manifest with every name array Cargo reads blanked, newlines kept
/// so the lines a refusal names stay true. Blanked from the end, so an
/// earlier array's offsets still hold.
fn without_cargo_name_arrays(text: &str) -> String {
    let found: Vec<regex::Match> = CARGO_NAME_ARRAYS.find_iter(text).collect();
    let mut judged = text.to_owned();
    for array in found.iter().rev() {
        judged.replace_range(array.range(), &blank(array.as_str()));
    }
    judged
}

fn words_only(items: &[String]) -> bool {
    is_list(items) && items.iter().all(|item| is_word(item))
}

/// Arrays of word strings anywhere in a JSON document. Keys are not read:
/// an object's keys are its fields, and an array naming only keys the same
/// document declares — a JSON Schema's `required`, a record's field list —
/// is the document's structure (`declared.rs`). A document that does not
/// parse is scanned as quoted text, so a broken file cannot carry a list
/// past this; the arrays the document's structure exempts stay exempt there
/// too (see [`without_exempt_arrays`]).
/// A release manifest's promotion channels are release states, not words
/// consulted to classify input; exclude only that top-level schema field.
fn json_lists(path: &str, text: &str) -> Vec<(usize, Vec<String>)> {
    let Ok(mut document) = serde_json::from_str::<Value>(text) else {
        return data_collections(&without_exempt_arrays(path, text));
    };
    let declared = Declared::of_json(&document);
    if path.ends_with(RELEASE_MANIFEST) {
        if let Some(Value::Object(promotion)) = document.pointer_mut("/promotion") {
            promotion.remove(CHANNELS_FIELD);
        }
    }
    let mut arrays = Vec::new();
    collect_arrays(&document, &declared, &mut arrays);
    arrays
        .into_iter()
        .map(|items| (member_line(text, &items), items))
        .collect()
}

/// The line of the first array member in `text` whose literal decodes to
/// the list's first word, however the document spells it (`"ok"` or
/// `"\u006fk"`): a document that parsed holds every one of its strings as
/// such a literal, and a judged list has a first word.
fn member_line(text: &str, items: &[String]) -> usize {
    let word = items
        .first()
        .expect("a judged data list holds at least two words");
    let literal = JSON_MEMBER
        .captures_iter(text)
        .filter_map(|member| member.name("literal"))
        .find(|literal| serde_json::from_str::<String>(literal.as_str()).is_ok_and(|s| &s == word))
        .expect("a JSON document that parsed spells each array member as a literal of its text");
    line_of(text, literal.start())
}

/// The field whose array is a command vector: a program and its arguments,
/// run as written, never compared against input. Stado's release manifest
/// (`.wisent-release.json`) names every step so, and judging
/// `["stado", "web", "build"]` as a keyword list would leave no way to
/// declare the documented web-hosting shape. Other arrays are still
/// judged unless the release schema gives them a non-classifying role.
const COMMAND_FIELD: &str = "argv";

/// A JSON text that does not parse is usually a fragment: the body of an
/// edit, which starts and ends inside the document. Its quoted runs are
/// still judged, but an array written as the value of the command field —
/// or, in a release manifest, of the channels field, which a fragment cannot
/// place under `promotion` — is blanked first, because the same array in the
/// whole document is exempt. Blanking keeps every newline, so the lines the
/// refusal names stay true.
fn without_exempt_arrays(path: &str, text: &str) -> String {
    let mut fields = vec![COMMAND_FIELD];
    if path.ends_with(RELEASE_MANIFEST) {
        fields.push(CHANNELS_FIELD);
    }
    fields.into_iter().fold(text.to_owned(), |judged, field| {
        field_array(field)
            .replace_all(&judged, |found: &regex::Captures| blank(&found[0]))
            .into_owned()
    })
}

/// `"FIELD": [ … ]` for an array holding no array of its own.
fn field_array(field: &str) -> Regex {
    common::compile(&format!(
        "\"{}\"\\s*:\\s*\\[[^\\[\\]]*\\]",
        regex::escape(field)
    ))
}

/// `text` with every character but a newline turned into a space.
fn blank(text: &str) -> String {
    text.chars()
        .map(|character| if character == '\n' { '\n' } else { ' ' })
        .collect()
}

fn collect_arrays(value: &Value, declared: &Declared, out: &mut Vec<Vec<String>>) {
    match value {
        Value::Array(items) => {
            let strings: Vec<String> = items
                .iter()
                .filter_map(|item| item.as_str().map(str::to_owned))
                .collect();
            if strings.len() == items.len() && words_only(&strings) && !declared.names_all(&strings)
            {
                out.push(strings);
            }
            items
                .iter()
                .for_each(|item| collect_arrays(item, declared, out));
        }
        Value::Object(fields) => {
            let table = table::table_keys(fields);
            fields
                .iter()
                .filter(|(key, field)| !(key.as_str() == COMMAND_FIELD && field.is_array()))
                .for_each(|(key, field)| {
                    if table.contains(&key.as_str()) {
                        table::cells(field).for_each(|cell| collect_arrays(cell, declared, out));
                    } else {
                        collect_arrays(field, declared, out);
                    }
                });
        }
        _ => {}
    }
}

/// `- word` items at one indent, one after another.
fn yaml_blocks(text: &str) -> Vec<(usize, Vec<String>)> {
    let mut found = Vec::new();
    let mut run: Vec<String> = Vec::new();
    let mut run_indent = String::new();
    let mut run_line = line_of(text, text.len());
    let mut close = |run: &mut Vec<String>, line: usize| {
        if words_only(run) {
            found.push((line, std::mem::take(run)));
        }
        run.clear();
    };
    for line in text.lines() {
        // The line's number, from where it starts in the text.
        let number = line_of(text, line.as_ptr() as usize - text.as_ptr() as usize);
        match YAML_ITEM.captures(line) {
            Some(item) if run.is_empty() || item[1] == run_indent => {
                if run.is_empty() {
                    run_indent = item[1].to_owned();
                    run_line = number;
                }
                run.push(item[2].to_owned());
            }
            Some(item) => {
                close(&mut run, run_line);
                run_indent = item[1].to_owned();
                run_line = number;
                run.push(item[2].to_owned());
            }
            None => close(&mut run, run_line),
        }
    }
    close(&mut run, run_line);
    found
}

/// `[a, b]` written unquoted on one line.
fn yaml_flows(text: &str) -> Vec<(usize, Vec<String>)> {
    YAML_FLOW
        .captures_iter(text)
        .filter_map(|flow| {
            let whole = flow.get(usize::default())?;
            let items: Vec<String> = flow[1]
                .split(',')
                .map(|item| item.trim().trim_matches(['"', '\'']).to_owned())
                .collect();
            words_only(&items).then(|| (line_of(text, whole.start()), items))
        })
        .collect()
}
