//! Running one candidate against one payload: the spawn, and reading a block
//! verdict out of what it printed.
//!
//! Split out of `doctor/repair.rs`, which had grown past the
//! three-hundred-line limit.

use std::io::Write;
use std::os::unix::process::ExitStatusExt;
use std::process::{Command, ExitStatus, Stdio};

use serde_json::Value;

/// How a run ended: the status it exited with, or the signal that ended it.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Ended {
    Status(i32),
    Signal(i32),
}

impl Ended {
    fn of(exit: ExitStatus) -> Result<Self, String> {
        match (exit.code(), exit.signal()) {
            (Some(code), _) => Ok(Ended::Status(code)),
            (None, Some(signal)) => Ok(Ended::Signal(signal)),
            (None, None) => Err(format!(
                "the run ended as {exit}, with neither a status nor a signal"
            )),
        }
    }
}

impl std::fmt::Display for Ended {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Ended::Status(code) => write!(formatter, "exit {code}"),
            Ended::Signal(signal) => write!(formatter, "signal {signal}"),
        }
    }
}

/// What one run produced.
pub struct SpawnOutcome {
    pub ended: Ended,
    pub stdout: String,
    pub stderr: String,
}

/// Runs `program` with `args`, `input` on its stdin, and answers how it
/// ended and what it printed, or why it could not be run. Nothing is killed
/// at a number of milliseconds: a candidate that is slow is reported by
/// what it costs, not replaced by a verdict it never gave.
pub fn spawn_sync_capture(
    program: &str,
    args: &[String],
    input: &str,
) -> Result<SpawnOutcome, String> {
    let mut child = Command::new(program)
        .args(args)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .map_err(|error| format!("cannot start {program}: {error}"))?;
    // The writer's result is kept: a candidate judged on part of its payload
    // would give a verdict about something else.
    let writer = child.stdin.take().map(|mut stdin| {
        let input = input.to_string();
        std::thread::spawn(move || stdin.write_all(input.as_bytes()))
    });
    // Both pipes are read while the candidate runs, and the wait is said on
    // stderr: waited on before its pipes were read, a candidate that prints
    // more than a pipe holds would never exit.
    let output = stado_wait::child_output(child, format!("repair candidate {program}"))
        .map_err(|error| format!("{program} could not be waited on: {error}"))?;
    if let Some(handle) = writer {
        let written = handle
            .join()
            .map_err(|_| format!("the writer of {program}'s stdin panicked"))?;
        // A program that exits without reading all of its input closes the
        // pipe; that is its answer, not a failure to hand it the payload.
        if let Err(error) = written.filter_broken_pipe() {
            return Err(format!(
                "the payload could not be written to {program}: {error}"
            ));
        }
    }
    Ok(SpawnOutcome {
        ended: Ended::of(output.status)?,
        stdout: String::from_utf8_lossy(&output.stdout).into_owned(),
        stderr: String::from_utf8_lossy(&output.stderr).into_owned(),
    })
}

/// A write whose only failure was the reader closing its end counts as done.
trait BrokenPipe {
    fn filter_broken_pipe(self) -> std::io::Result<()>;
}

impl BrokenPipe for std::io::Result<()> {
    fn filter_broken_pipe(self) -> std::io::Result<()> {
        match self {
            Err(error) if error.kind() == std::io::ErrorKind::BrokenPipe => Ok(()),
            other => other,
        }
    }
}

/// `blockVerdict(result)`: the run printed a `BLOCKED:` line or a JSON line
/// whose `decision` is `block`.
pub(super) fn block_verdict(result: &SpawnOutcome) -> bool {
    let block_line = |line: &str| {
        let line = line.trim();
        line.starts_with("BLOCKED:")
            || (line.starts_with('{')
                && serde_json::from_str::<Value>(line).is_ok_and(|parsed| {
                    parsed.get("decision").and_then(Value::as_str) == Some("block")
                }))
    };
    [&result.stdout, &result.stderr].into_iter().any(|stream| {
        let text = stream.trim();
        !text.is_empty() && (block_line(text) || text.split('\n').any(block_line))
    })
}
