//! Which gates the hook registry runs: those it binds to at least one event
//! (`events.<event>.hooks[].id`, the shape `tama hooks declare` writes). A
//! gate the catalogue holds active but the registry binds nowhere runs for
//! no session, so it closes no step.

use std::collections::BTreeSet;
use std::path::Path;

use serde_json::Value;

/// The id of every hook the registry at `registry` binds to an event. A
/// registry that cannot be read or is not the registry's document is named
/// with its path and cause: read as binding nothing, every gate would look
/// as if it closed no step.
pub(super) fn bound(registry: &Path) -> Result<BTreeSet<String>, String> {
    let text = std::fs::read_to_string(registry).map_err(|error| {
        format!(
            "cannot read the hook registry {}: {error}",
            registry.display()
        )
    })?;
    let document: Value = serde_json::from_str(&text).map_err(|error| {
        format!(
            "the hook registry {} is not valid JSON: {error}",
            registry.display()
        )
    })?;
    let events = document["events"].as_object().ok_or_else(|| {
        format!(
            "the hook registry {} holds no events object",
            registry.display()
        )
    })?;
    let mut ids = BTreeSet::new();
    for (event, bindings) in events {
        let hooks = bindings["hooks"].as_array().ok_or_else(|| {
            format!(
                "the hook registry {} binds event {event} with no hooks array",
                registry.display()
            )
        })?;
        for hook in hooks {
            let id = hook["id"].as_str().ok_or_else(|| {
                format!(
                    "the hook registry {} binds a hook without an id to event {event}",
                    registry.display()
                )
            })?;
            ids.insert(id.to_string());
        }
    }
    Ok(ids)
}
