//! `tama hooks declared [--registry PATH] [--json]`: every hook declaration
//! committed under `hook-declarations/` in this checkout, and for each event
//! it binds whether the registry binds it — the installed one,
//! `~/.shared-hooks/registry.json`, unless `--registry` names another.
//!
//! A committed declaration is not the owner's consent, so nothing here
//! registers anything: a declaration whose events the registry does not bind
//! is a gate described and reviewed but enforced nowhere, and the report names
//! it with the one command that registers it under his consent
//! (`tama hooks declare --file <path>`). It exits with failure while any
//! declaration is unregistered or cannot be read as one, so a release check
//! or a session can tell "declared" from "running" without reading two files.
//!
//! A registered hook whose declaration says something its entry in the
//! checkout's catalogue (`shared-hooks/catalog-metadata.json`) does not is
//! reported stale with the same command, which refreshes the entry from the
//! declaration: `tama show` and the published catalogue read the entry, so a
//! declaration rewritten without it described the gate as it used to be. A
//! stale entry fails the report as an unregistered declaration does.

use std::path::{Path, PathBuf};

use serde_json::{json, Value};

use super::declare::{is_bound, option, refuse, Declaration};

pub const USAGE: &str = "usage: tama hooks declared [--registry PATH] [--json]";

pub(super) const DECLARATIONS: &str = "hook-declarations";
const INSTALLED_REGISTRY: &str = ".shared-hooks/registry.json";
const CATALOGUE: &str = "shared-hooks/catalog-metadata.json";

/// The catalogue fields a declaration writes, by their catalogue key.
fn catalogued(declaration: &Declaration) -> Vec<(&'static str, &str)> {
    vec![
        ("category", declaration.category.as_str()),
        ("description", declaration.description.as_str()),
        ("why", declaration.why.as_str()),
        ("sideEffects", declaration.side_effects.as_str()),
    ]
}
const DECLARATION_EXTENSION: &str = "json";

/// One event a declaration binds, and whether the registry binds it.
struct Event {
    event: String,
    bound: Result<bool, String>,
}

/// One declaration file as read against the registry.
enum Row {
    Unreadable {
        file: PathBuf,
        cause: String,
    },
    Read {
        file: PathBuf,
        id: String,
        events: Vec<Event>,
        /// The catalogue fields that do not say what the declaration says.
        stale: Vec<String>,
    },
}

impl Row {
    fn registered(&self) -> bool {
        match self {
            Row::Unreadable { .. } => false,
            Row::Read { events, .. } => events.iter().all(|event| event.bound == Ok(true)),
        }
    }

    fn current(&self) -> bool {
        match self {
            Row::Unreadable { .. } => false,
            Row::Read { stale, .. } => self.registered() && stale.is_empty(),
        }
    }

    fn json(&self) -> Value {
        match self {
            Row::Unreadable { file, cause } => json!({ "file": file, "unreadable": cause }),
            Row::Read {
                file,
                id,
                events,
                stale,
            } => {
                let events: Vec<Value> = events
                    .iter()
                    .map(|event| match &event.bound {
                        Ok(bound) => json!({ "event": event.event, "bound": bound }),
                        Err(cause) => json!({ "event": event.event, "unreadable": cause }),
                    })
                    .collect();
                json!({ "file": file, "id": id, "events": events, "registered": self.registered(), "stale": stale })
            }
        }
    }

    fn line(&self) -> String {
        match self {
            Row::Unreadable { file, cause } => format!("unreadable   {}: {cause}", file.display()),
            Row::Read { id, .. } if self.current() => format!("registered   {id}"),
            Row::Read { file, id, stale, .. } if self.registered() => format!(
                "stale        {id}: the catalogue's {} does not say what {} says; under the owner's consent: tama hooks declare --file {}",
                stale.join(", "),
                file.display(),
                file.display()
            ),
            Row::Read { file, id, events, .. } => {
                let missing: Vec<String> = events
                    .iter()
                    .filter_map(|event| match &event.bound {
                        Ok(true) => None,
                        Ok(false) => Some(event.event.clone()),
                        Err(cause) => Some(format!("{} ({cause})", event.event)),
                    })
                    .collect();
                format!(
                    "unregistered {id}: {} not bound; under the owner's consent: tama hooks declare --file {}",
                    missing.join(", "),
                    file.display()
                )
            }
        }
    }
}

/// Every declaration file under `relative` (a path inside `root`), at any
/// depth, in path order, each named relative to `root`.
pub(super) fn files(root: &Path, relative: &Path) -> Result<Vec<PathBuf>, String> {
    let directory = root.join(relative);
    let mut found = Vec::new();
    let entries = std::fs::read_dir(&directory)
        .map_err(|error| format!("cannot list {}: {error}", directory.display()))?;
    for entry in entries {
        let entry = entry
            .map_err(|error| format!("cannot read an entry of {}: {error}", directory.display()))?;
        let path = relative.join(entry.file_name());
        // An entry that cannot be examined is not a file: read as one, a
        // folder of declarations behind it would go unlisted.
        let full = root.join(&path);
        let metadata = std::fs::metadata(&full)
            .map_err(|error| format!("cannot examine {}: {error}", full.display()))?;
        if metadata.is_dir() {
            found.extend(files(root, &path)?);
        } else if path
            .extension()
            .is_some_and(|extension| extension == DECLARATION_EXTENSION)
        {
            found.push(path);
        }
    }
    found.sort();
    Ok(found)
}

/// The catalogue in the checkout, one entry per hook id.
fn catalogue(root: &Path) -> Result<Value, String> {
    let path = root.join(CATALOGUE);
    let text = std::fs::read_to_string(&path)
        .map_err(|error| format!("cannot read the catalogue {}: {error}", path.display()))?;
    serde_json::from_str(&text).map_err(|error| {
        format!(
            "the catalogue {} is not valid JSON: {error}",
            path.display()
        )
    })
}

/// The catalogue fields of `declaration`'s entry that differ from it; an
/// absent entry differs in every field.
fn stale(catalogue: &Value, declaration: &Declaration) -> Vec<String> {
    let entry = &catalogue[declaration.id.as_str()];
    catalogued(declaration)
        .into_iter()
        .filter(|(key, declared)| entry[*key].as_str() != Some(*declared))
        .map(|(key, _)| key.to_string())
        .collect()
}

/// One declaration file read against the registry and the catalogue.
fn judged(root: &Path, file: PathBuf, registry: &Path, catalogue: &Value) -> Row {
    let read = std::fs::read_to_string(root.join(&file))
        .map_err(|error| format!("cannot read it: {error}"))
        .and_then(|text| {
            serde_json::from_str::<Declaration>(&text)
                .map_err(|error| format!("it is not a hook declaration: {error}"))
        });
    match read {
        Err(cause) => Row::Unreadable { file, cause },
        Ok(declaration) => {
            let events = declaration
                .events
                .iter()
                .map(|binding| Event {
                    event: binding.event.clone(),
                    bound: is_bound(registry, &declaration.id, &binding.event),
                })
                .collect();
            let stale = stale(catalogue, &declaration);
            Row::Read {
                file,
                id: declaration.id,
                events,
                stale,
            }
        }
    }
}

pub fn main(argv: &[String], root: &Path) -> i32 {
    if argv.iter().any(|arg| arg == "--help" || arg == "-h") {
        println!("{USAGE}");
        return tama_core::exit::SUCCESS;
    }
    let registry = match option(argv, "--registry") {
        Some(path) => PathBuf::from(path),
        None => match std::env::var_os("HOME").filter(|home| !home.is_empty()) {
            Some(home) => PathBuf::from(home).join(INSTALLED_REGISTRY),
            None => {
                return refuse("HOME is not set, so the installed registry cannot be located; name it with --registry")
            }
        },
    };
    let declarations = match files(root, Path::new(DECLARATIONS)) {
        Ok(files) => files,
        Err(cause) => {
            return refuse(&format!(
                "the committed declarations cannot be listed: {cause}"
            ))
        }
    };
    let catalogue = match catalogue(root) {
        Ok(catalogue) => catalogue,
        Err(cause) => return refuse(&cause),
    };
    let rows: Vec<Row> = declarations
        .into_iter()
        .map(|file| judged(root, file, &registry, &catalogue))
        .collect();
    if argv.iter().any(|arg| arg == "--json") {
        let rows: Vec<Value> = rows.iter().map(Row::json).collect();
        println!("{}", json!({ "registry": registry, "declarations": rows }));
    } else {
        println!("declarations against {}", registry.display());
        rows.iter().for_each(|row| println!("{}", row.line()));
    }
    if rows.iter().all(Row::current) {
        tama_core::exit::SUCCESS
    } else {
        tama_core::exit::FAILURE
    }
}
