//! The text `tama hooks reach` prints: the gates read, those that declare
//! nothing, and what each role is left in each state of its work.

use std::path::Path;

use serde::Serialize;

use super::{State, Work};

/// The word a step, a role or a state is printed with: its serialised name.
fn named<T: Serialize>(value: &T) -> String {
    match serde_json::to_value(value) {
        Ok(serde_json::Value::String(name)) => name,
        Ok(other) => other.to_string(),
        Err(error) => format!("<unprintable: {error}>"),
    }
}

pub(super) fn report(catalogue: &Path, active: usize, undeclared: &[&str], states: &[State]) {
    println!(
        "reach: {active} active gate(s) in {}, {} declaring the steps they close",
        catalogue.display(),
        active - undeclared.len()
    );
    if !undeclared.is_empty() {
        println!(
            "reach: unknown while {} active gate(s) declare nothing they close (write `closes` in each gate's declaration under hook-declarations/): {}",
            undeclared.len(),
            undeclared.join(", ")
        );
    }
    for state in states {
        println!("{}", line(state));
    }
}

/// The line a state is printed as: the steps left to it, or, when none is,
/// the gates that close each step.
pub(super) fn line(state: &State) -> String {
    let work = match state.work {
        Work::Open => "with open work",
        Work::Held => "whose every open item waits on someone else",
        Work::Idle => "with no open work",
    };
    let role = named(&state.role);
    if state.admitted.is_empty() {
        let closers: Vec<String> = state
            .closed_by
            .iter()
            .map(|(step, gates)| format!("{} by {}", named(step), gates.join(", ")))
            .collect();
        return format!(
            "reach: a {role} session {work} has no step left: {}",
            closers.join("; ")
        );
    }
    let admitted: Vec<String> = state.admitted.iter().map(named).collect();
    format!(
        "reach: a {role} session {work} may still: {}",
        admitted.join(", ")
    )
}
