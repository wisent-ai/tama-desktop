//! Whether another session declares the defect this one is about to take.

use std::path::PathBuf;

use super::{TaskScope, SCOPE_HOME_RELATIVE};
use crate::ports::python_stdlib::expanduser;

/// Another session's live declaration of the same defect, as a notice. Two
/// sessions on one defect work on it together: the second reads what the
/// first recorded before it changes anything, instead of repairing the same
/// thing blind, and neither waits for the other.
pub(in super::super) fn working_elsewhere(session: &str, defect: &str) -> Option<String> {
    let defect = defect.trim();
    if defect.is_empty() {
        return None;
    }
    let home = PathBuf::from(expanduser("~"));
    let directory = home.join(SCOPE_HOME_RELATIVE);
    let entries = match std::fs::read_dir(&directory) {
        Ok(entries) => entries,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return None,
        Err(error) => {
            return Some(format!(
                "whether another session declares defect {defect} cannot be told: the task \
                 scopes in {} cannot be listed: {error}",
                directory.display()
            ))
        }
    };
    let mut unreadable: Vec<String> = Vec::new();
    for entry in entries {
        let path = match entry {
            Ok(entry) => entry.path(),
            Err(error) => {
                unreadable.push(format!(
                    "an entry of {} cannot be read: {error}",
                    directory.display()
                ));
                continue;
            }
        };
        let Some(other) = path
            .file_stem()
            .map(|stem| stem.to_string_lossy().to_string())
        else {
            continue;
        };
        if other == session {
            continue;
        }
        match TaskScope::read(&other, &home) {
            Ok(Some(scope)) if scope.defect.trim() == defect => {
                return Some(format!(
                    "defect {defect} is also declared by session {other}; work on it together: \
                     read its notes (`oko defects show {defect}`) and the uncommitted changes it \
                     holds, then build on them with anchored edits"
                ));
            }
            Ok(_) => {}
            Err(cause) => unreadable.push(cause),
        }
    }
    if unreadable.is_empty() {
        return None;
    }
    Some(format!(
        "whether another session declares defect {defect} cannot be told for every session: {}",
        unreadable.join("; ")
    ))
}
