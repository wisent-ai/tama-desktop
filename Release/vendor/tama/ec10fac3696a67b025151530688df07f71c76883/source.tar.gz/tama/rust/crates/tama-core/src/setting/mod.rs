//! One environment setting, read so that its absence and its failure are
//! told apart.
//!
//! `std::env::var(name).ok()` answers a value that is not Unicode as if the
//! variable were unset, so a setting the user did give is replaced by the
//! default without a word. Here a variable that is unset or empty is not
//! given, and one that cannot be read is the error naming it.

/// The value of `name`; none when it is unset or empty. A value that is not
/// Unicode is the error naming the variable and the cause.
pub fn given(name: &str) -> Result<Option<String>, String> {
    match std::env::var(name) {
        Ok(value) if !value.is_empty() => Ok(Some(value)),
        Ok(_) | Err(std::env::VarError::NotPresent) => Ok(None),
        Err(error) => Err(format!("{name} cannot be read: {error}")),
    }
}

/// The value of `name`, or `declared` when the variable is not given: the
/// default a caller declares beside the variable that overrides it. A value
/// that is not Unicode is the error naming the variable.
pub fn or_declared(name: &str, declared: &str) -> Result<String, String> {
    Ok(match given(name)? {
        Some(value) => value,
        None => declared.to_string(),
    })
}
