//! Replace only Tama-generated commands; retain the harness user's own hooks.

use serde_json::{Map, Value};
use tama_core::harnesses::Shape;
use tama_hook_tools::registry::shell_quote;

pub(super) fn hooks(
    existing: &mut Value,
    generated: Value,
    provider: &str,
    shape: Shape,
) -> Result<(), String> {
    let field = match shape {
        Shape::CopilotFlat => "bash",
        _ => "command",
    };
    let prefix = format!(
        "env TAMA_PROVIDER={} TAMA_ONLY_HOOK_ID=",
        shell_quote(provider)
    );
    let owned = |entry: &Value| {
        entry
            .get(field)
            .and_then(Value::as_str)
            .is_some_and(|command| command.starts_with(&prefix))
    };
    let events = existing
        .as_object_mut()
        .ok_or_else(|| String::from("existing hooks must be an event object"))?;
    for (event, value) in events.iter_mut() {
        let entries = value
            .as_array_mut()
            .ok_or_else(|| format!("existing hook event {event} must be an array"))?;
        for entry in entries.iter_mut() {
            if let Some(group) = entry.get_mut("hooks") {
                let commands = group.as_array_mut().ok_or_else(|| {
                    format!("existing hook event {event} has a non-array hooks group")
                })?;
                commands.retain(|command| !owned(command));
            }
        }
        entries.retain(|entry| {
            !owned(entry)
                && !entry
                    .get("hooks")
                    .and_then(Value::as_array)
                    .is_some_and(Vec::is_empty)
        });
    }
    let Value::Object(generated) = generated else {
        return Err(String::from("generated hooks must be an event object"));
    };
    for (event, value) in generated {
        let Value::Array(mut commands) = value else {
            return Err(format!("generated hook event {event} must be an array"));
        };
        match events
            .entry(event)
            .or_insert_with(|| Value::Array(Vec::new()))
        {
            Value::Array(entries) => entries.append(&mut commands),
            _ => unreachable!("existing event arrays were checked before merging"),
        }
    }
    Ok(())
}

pub(super) fn nested(
    config: &mut Value,
    generated: Value,
    provider: &str,
    shape: Shape,
) -> Result<(), String> {
    let object = config
        .as_object_mut()
        .ok_or_else(|| String::from("harness configuration must be an object"))?;
    hooks(
        object
            .entry("hooks")
            .or_insert_with(|| Value::Object(Map::new())),
        generated,
        provider,
        shape,
    )
}
