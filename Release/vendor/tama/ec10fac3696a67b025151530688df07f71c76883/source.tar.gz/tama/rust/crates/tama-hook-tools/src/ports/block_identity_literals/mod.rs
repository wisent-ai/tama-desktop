//! Logic for `tama-block-identity-literals`, registry hook id
//! `block-identity-literals`.
//!
//! Blocks an identity literal nobody issued, anywhere in the file a write
//! leaves (a hashline section or a string edit replayed on the file, a
//! written file's content), whoever wrote it. An identity is an email
//! address, a UUID, or an identifier
//! that flattens an address (`name-example-com` flattens the mailbox `name`
//! at the domain `example.com`, every separator a `-`). A
//! literal passes when one of these holds:
//!
//!   1. an artifact outside any conversation carries it — a token cache, a
//!      cloud profile, a machine registry, a config file;
//!   2. the user used it in more than one stored session;
//!   3. `identity_provenance.json` records a verbatim user quote declaring it,
//!      and that quote is found in a real `role=user` message.
//!
//! Why those three and not "the user said it once": an agent can invent an
//! address, write it into a credential contract in several repositories,
//! propagate it through its own subagent briefs, and ask the user to confirm
//! it until the user echoes the invented address back once. A rule keyed on
//! "the user said it" reads that echo as authority and blesses the invention.
//! A real address appears many times across stored sessions and mail, or is
//! bound to its object id by a local token cache; an invention exists in one
//! authoring session and in no artifact at all. That is the difference this
//! gate measures.
//!
//! Two discriminators were tried and rejected against real data, recorded so
//! they are not tried again: stripping strings before scanning, copied from
//! the numeric gate — an identity in code IS a string, so stripping removed
//! the only thing worth finding; and first-mention ordering (user before
//! assistant) — across months of history an assistant has eventually said
//! nearly every value, so it blocked both genuine accounts.

mod checkout;
mod mention_index;
pub mod sources;
mod transcript_tail;

use std::collections::{BTreeMap, BTreeSet};
use std::sync::LazyLock;

use regex::Regex;
use serde_json::Value;
use tama_hooks::session_record::{deny_tool_use, read_payload};

use crate::ports::tool_vocabulary::Call;

use crate::ports::check_numeric_literals_payload::path_texts;
use crate::ports::transport_common as common;

const EMAIL_KIND: &str = "email address";
const UUID_KIND: &str = "UUID";
const FLAT_KIND: &str = "address encoded in an identifier";
const PAYLOAD_LABEL: &str = "<payload>";
const TRIM: &[char] = &['.', ',', ';', ':', '"', '\'', ' ', '\t', '\n'];

static EMAIL: LazyLock<Regex> = LazyLock::new(|| {
    common::compile("[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(?:\\.[A-Za-z0-9-]+)*\\.[A-Za-z]{2,}")
});

static UUID: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(
        "\\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\\b",
    )
});

/// The top-level domain set is closed deliberately. An open one turns every
/// hyphenated name into an address claim. Python's trailing `(?![A-Za-z0-9])`
/// is not needed: `\b` after the group already refuses a following letter or
/// digit, and the Rust engine has no lookaround.
static FLAT: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(
        "\\b(?P<user>[A-Za-z0-9]+)-(?P<host>[A-Za-z0-9]+)-(?P<tld>com|ai|io|net|org|dev|co|app|eu|pl)\\b",
    )
});

static PLACEHOLDER: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(?i)(example|sample|placeholder|dummy|fixture|redacted|your-|<[a-z-]+>|xxx",
        "|test@|user@|foo|bar|localhost|nowhere)",
    ))
});

fn sanitize(value: &str) -> String {
    value.trim().trim_matches(TRIM).to_lowercase()
}

/// Every identity the text asserts, as (kind, value, as written).
fn identities(text: &str) -> Vec<(&'static str, String, String)> {
    let mut found: BTreeMap<String, (&'static str, String)> = BTreeMap::new();
    for found_match in EMAIL.find_iter(text) {
        found
            .entry(sanitize(found_match.as_str()))
            .or_insert((EMAIL_KIND, found_match.as_str().to_string()));
    }
    for found_match in UUID.find_iter(text) {
        found
            .entry(sanitize(found_match.as_str()))
            .or_insert((UUID_KIND, found_match.as_str().to_string()));
    }
    for caps in FLAT.captures_iter(text) {
        // The captures' first entry is the whole match.
        let Some(whole) = caps.iter().next().flatten() else {
            continue;
        };
        let address = format!(
            "{}@{}.{}",
            caps["user"].to_lowercase(),
            caps["host"].to_lowercase(),
            caps["tld"].to_lowercase(),
        );
        found.entry(address).or_insert((
            FLAT_KIND,
            enclosing(text, whole.start(), whole.end()).to_string(),
        ));
    }
    found
        .into_iter()
        .map(|(value, (kind, shown))| (kind, value, shown))
        .collect()
}

/// The matched identifier widened to the `<placeholder>` it is part of, if
/// it is part of one. A usage line's `<gh-user-or-org>` holds `user-or-org`,
/// which reads as the flattened address of the mailbox `user` at `or.org`; the angle brackets say it is the
/// name of an argument, and the placeholder test can only see them when they
/// travel with the match. Without them such a word sent the gate through
/// every stored transcript looking for an address nobody has, past the hook
/// runner's limit, so the edit was refused as a timeout.
fn enclosing(text: &str, start: usize, end: usize) -> &str {
    let word = |c: char| c.is_ascii_alphanumeric() || c == '-';
    let before = text[..start].trim_end_matches(word);
    let after = text[end..].trim_start_matches(word);
    match (before.strip_suffix('<'), after.strip_prefix('>')) {
        (Some(outside_left), Some(outside_right)) => {
            &text[outside_left.len()..text.len() - outside_right.len()]
        }
        _ => &text[start..end],
    }
}

/// Why an identity no cheaper source carries has no source, or `None` when
/// it has one. `said` are the stored sessions in which the user said it,
/// read for every such value of the written file in one walk of the index.
fn unsourced(
    said: &[std::path::PathBuf],
    value: &str,
    doc: &Value,
) -> Result<Option<&'static str>, String> {
    if matches!(said, [_, _, ..]) || sources::provenanced(value, doc, sanitize)? {
        return Ok(None);
    }
    Ok(Some(if matches!(said, [_]) {
        "no artifact outside the chat carries it and exactly one stored session has the \
         user saying it, which is what an invented value echoed back by the user looks like"
    } else {
        "no artifact carries it and no stored user message contains it"
    }))
}

/// Every identity the file this write leaves asserts without a source, one
/// complaint each, whoever wrote it: an identity a page already held is
/// refused on its next edit until it is sourced or removed. The values no
/// cheaper source carries are answered together from the shared
/// per-transcript index (`mention_index`): one walk of the stored sessions
/// per written file, each transcript's snapshot read once, so a long page no
/// longer walks the stores once per address it carries. A write whose file
/// cannot be rebuilt is one complaint naming the cause.
pub fn check(payload: &Value) -> Vec<String> {
    let call = Call::of(payload);
    let (doc, doc_error) = sources::load_provenance();
    let mut problems: Vec<String> = doc_error.into_iter().collect();
    let Some(input) = call.input() else {
        return problems;
    };
    let texts = match path_texts(input, call.session_cwd()) {
        Ok(texts) => texts,
        Err(error) => {
            problems.push(format!(
                "the file this write leaves cannot be rebuilt to judge it: {error}"
            ));
            return problems;
        }
    };
    let machine = sources::Machine::default();
    for (raw_path, text) in texts {
        // Strings are scanned, unlike the numeric gate: in code an identity is
        // a string literal, so stripping them removes the whole subject.
        let found: Vec<_> = identities(&text)
            .into_iter()
            .filter(|(_, _, shown)| !PLACEHOLDER.is_match(shown))
            .collect();
        // A checkout search that failed sources nothing; a value the other
        // sources do not settle is then the hook's own failure, never a
        // missing provenance: the search that could have sourced it never answered.
        let (tracked, checkout_failure) = match checkout::tracked_in_checkout(
            std::path::Path::new(&raw_path),
            found.iter().map(|(_, value, _)| value.as_str()),
        ) {
            Ok(tracked) => (tracked, None),
            Err(failure) => (std::collections::HashSet::new(), Some(failure)),
        };
        // Sources outside every conversation are asked first; the stored
        // sessions are read once for whatever none of them carries. An issuer
        // that could not be asked leaves an unsettled value the hook's own
        // failure, never an invention.
        let mut issuer_failure = None;
        let unsettled: BTreeSet<String> = found
            .iter()
            .filter(|(_, value, _)| match machine.settles(value, &tracked) {
                Ok(settled) => !settled,
                Err(failure) => {
                    issuer_failure = Some(failure);
                    true
                }
            })
            .map(|(_, value, _)| value.to_lowercase())
            .collect();
        let mentions = if unsettled.is_empty() {
            Ok(BTreeMap::new())
        } else {
            sources::user_sessions_mentioning(&unsettled)
        };
        for (kind, value, shown) in found {
            let key = value.to_lowercase();
            let answer = match (unsettled.contains(&key), &mentions) {
                (false, _) => Ok(None),
                (true, Err(error)) => Err(error.clone()),
                (true, Ok(map)) => {
                    let said: &[std::path::PathBuf] = match map.get(&key) {
                        Some(paths) => paths,
                        None => &[],
                    };
                    unsourced(said, &value, &doc)
                }
            };
            let reason = match (answer, &checkout_failure) {
                (Ok(None), _) => continue,
                (Ok(Some(_)), Some(failure)) => {
                    problems.push(format!(
                        "{raw_path}: cannot establish provenance for {shown}: the written file's \
                         checkout could not be searched: {failure}"
                    ));
                    continue;
                }
                (Ok(Some(reason)), None) => match &issuer_failure {
                    Some(failure) => {
                        problems.push(format!(
                            "{raw_path}: cannot establish provenance for {shown}: {failure}"
                        ));
                        continue;
                    }
                    None => reason,
                },
                (Err(error), _) => {
                    problems.push(format!(
                        "{raw_path}: cannot establish provenance for {shown}: {error}"
                    ));
                    continue;
                }
            };
            let label = if raw_path.is_empty() {
                PAYLOAD_LABEL
            } else {
                raw_path.as_str()
            };
            problems.push(format!(
                "{label}: the {kind} {shown} has no provenance -- {reason}. Search the stored \
                 transcripts and the machine for the value that was actually issued. An identity \
                 you cannot source is an invention, and an invention is not a question to ask the \
                 user."
            ));
        }
    }
    problems
}

/// The registry dispatches this hook on the write events alone
/// (`pre_tool_use:edit`, `multiedit`, `notebook`, `write`), so the payload it
/// reads is a write by construction and no tool name is re-judged here.
pub fn run() {
    let payload = read_payload();
    let problems = check(&payload);
    if problems.is_empty() {
        return;
    }
    let listed = problems
        .iter()
        .map(|problem| format!("  {problem}"))
        .collect::<Vec<_>>()
        .join("\n");
    deny_tool_use(&format!("block-identity-literals:\n{listed}"));
}
