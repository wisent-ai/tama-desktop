//! Decision half of `tama-block-repository-copies` (registry hook
//! `block-repository-copies`): pure payload evaluation returns a refusal.
//!
//! Each repository has one checkout and one line of work, `main`. Extra
//! checkouts duplicate source and build output and make it unclear which
//! tree owns a change; a branch or pull request ([`branches`]) parks work
//! beside `main` until a blind merge brings it back.
//!
//! A linked worktree has a `.git` file pointing into the owner's
//! `.git/worktrees/`. A full repository copy has its own `.git` directory.
//! `tama worktrees remove` handles the linked worktrees Git tracks.
//!
//! Everything that only reads or repairs an existing layout still passes:
//! `git worktree list`, `remove`, `prune`, `unlock`, `repair`, a clone from a
//! remote URL, and any copy that touches no repository.

use std::path::Path;

use serde_json::Value;

mod branches;
mod native;
mod stash;

use crate::ports::python_stdlib::shell_tokens;
use crate::ports::pyvalue::py_str;
use crate::ports::tool_vocabulary::Call;

/// Shell separators. A guard that reads only the first word of the payload
/// misses `cd repo && git worktree add ../copy`, so every segment is judged.
const SEGMENT_SPLIT: &[char] = &[';', '&', '|', '\n'];

const GIT_PROGRAM: &str = "git";
const WORKTREE: &str = "worktree";
const ADD: &str = "add";
const CLONE: &str = "clone";
const GIT_DIR: &str = ".git";
const END_OF_OPTIONS: &str = "--";
const SCHEME_MARK: &str = "://";
const FILE_SCHEME: &str = "file";

/// `git` options that consume the token after them, so the subcommand scan
/// does not read `<dir>` of `git -C <dir> worktree add` as the subcommand.
const GIT_VALUE_OPTIONS: &[&str] = &["-C", "-c", "--git-dir", "--work-tree", "--namespace"];

/// `git clone` options that consume the token after them, so the source is
/// the first real operand and not `--depth`'s argument.
const CLONE_VALUE_OPTIONS: &[&str] = &[
    "-o",
    "--origin",
    "-b",
    "--branch",
    "-u",
    "--upload-pack",
    "-c",
    "--config",
    "-j",
    "--jobs",
    "--reference",
    "--reference-if-able",
    "--separate-git-dir",
    "--depth",
    "--shallow-since",
    "--shallow-exclude",
    "--template",
    "--filter",
    "--server-option",
    "--bundle-uri",
];

/// Recursive copy programs. `cp` copies one file without `-r`, so it needs the
/// flag; `rsync` and `ditto` copy trees by nature.
const CP_PROGRAM: &str = "cp";
const COPY_PROGRAMS: &[&str] = &[CP_PROGRAM, "rsync", "ditto"];
const RECURSIVE_FLAGS: &[char] = &['r', 'R', 'a'];

/// Copy options that consume the token after them, so `rsync -e ssh repo dest`
/// does not offer `ssh` as a source path.
const COPY_VALUE_OPTIONS: &[&str] = &[
    "-e",
    "--rsh",
    "--exclude",
    "--include",
    "--exclude-from",
    "--include-from",
    "--files-from",
    "--filter",
    "--log-file",
    "--partial-dir",
    "--temp-dir",
];

const WORKTREE_REASON: &str = "BLOCKED: repository copies are forbidden. 'git worktree add' makes \
                               a second checkout; work in the existing checkout instead. Remove \
                               existing worktrees with 'tama worktrees remove --root <PATH> \
                               --apply'.";
const COPY_REASON: &str = "BLOCKED: recursively copying a git repository makes a copy of it. Work \
                           in the existing checkout instead.";

fn clone_reason(source: &str) -> String {
    format!(
        "BLOCKED: cloning a local repository makes a copy of it. Work in the existing checkout at \
         {source} instead."
    )
}

/// A copy whose source cannot be examined is refused, not waved through: the
/// guard cannot prove the source is not a checkout, and the whole point of
/// this hook is that a copy must not happen.
fn opaque_reason(source: &str) -> String {
    format!(
        "BLOCKED: cannot tell whether {source} is a git repository, because the path is not \
         literal. Pass the real path so the copy can be checked, or work in the existing \
         checkout instead."
    )
}

/// The shell command a payload carries: the named field, else the whole input
/// rendered as Python would render it — the shape the neighbouring shell
/// guards already use.
fn command_from(payload: &Value) -> String {
    let call = Call::of(payload);
    if let Some(command) = call.command() {
        return command.to_string();
    }
    match call.input() {
        Some(input) => py_str(input),
        None => String::new(),
    }
}

/// `Path(token).name`, so `/usr/bin/git` counts as `git`.
fn program_is(token: &str, program: &str) -> bool {
    Path::new(token).file_name().and_then(|name| name.to_str()) == Some(program)
}

/// The subcommand of a `git` invocation and the tokens after it, with the
/// global options — and the argument of those that take one — stepped over.
fn git_subcommand(tokens: &[String]) -> Option<(&str, &[String])> {
    let mut rest = tokens;
    while let Some((first, after)) = rest.split_first() {
        if !first.starts_with('-') {
            return Some((first.as_str(), after));
        }
        rest = match (
            GIT_VALUE_OPTIONS.contains(&first.as_str()),
            after.split_first(),
        ) {
            (true, Some((_, past_value))) => past_value,
            _ => after,
        };
    }
    None
}

/// The non-option arguments, with the argument of every value-taking option
/// stepped over. A lone `-` is an operand; `--` ends the options.
fn operands<'a>(tokens: &'a [String], value_options: &[&str]) -> Vec<&'a str> {
    let mut found: Vec<&str> = Vec::new();
    let mut skip_value = false;
    let mut options_done = false;
    for token in tokens {
        if skip_value {
            skip_value = false;
            continue;
        }
        if !options_done && token == END_OF_OPTIONS {
            options_done = true;
            continue;
        }
        if !options_done && token != "-" && token.starts_with('-') {
            skip_value = value_options.contains(&token.as_str());
            continue;
        }
        found.push(token.as_str());
    }
    found
}

/// A clone source is remote when it names a scheme other than `file`, or when
/// it is an `scp`-style `user@host:path` — a colon before the first slash.
/// Everything else is a path on this filesystem: absolute, relative, or
/// `file://`.
fn source_is_local(source: &str) -> bool {
    if let Some((scheme, _)) = source.split_once(SCHEME_MARK) {
        return scheme.eq_ignore_ascii_case(FILE_SCHEME);
    }
    match source.split_once(':') {
        Some((host, _)) => host.contains('/'),
        None => true,
    }
}

/// A source path is or contains a repository: a `.git` component names one
/// outright, and a directory holding `.git` is a checkout. A `.git` that
/// cannot be examined is the error: read as absent, the copy would pass.
fn holds_repository(path: &str) -> Result<bool, String> {
    let candidate = Path::new(path);
    if candidate
        .components()
        .any(|part| part.as_os_str() == GIT_DIR)
    {
        return Ok(true);
    }
    tama_core::presence::present(&candidate.join(GIT_DIR)).map_err(|error| error.to_string())
}

/// `-r`, `-R`, `-a`, and the same letters inside a bundle such as `-av`.
fn is_recursive_flag(token: &str) -> bool {
    token.starts_with('-')
        && !token.starts_with(END_OF_OPTIONS)
        && token.chars().any(|flag| RECURSIVE_FLAGS.contains(&flag))
}

fn git_refusal(tokens: &[String]) -> Option<String> {
    let mut rest = tokens;
    while let Some((token, after_program)) = rest.split_first() {
        rest = after_program;
        let opens = program_is(token, branches::GH_PROGRAM)
            .then(|| branches::pull_request_refusal(after_program));
        if let Some(Some(reason)) = opens {
            return Some(reason.to_string());
        }
        if !program_is(token, GIT_PROGRAM) {
            continue;
        }
        let Some((subcommand, arguments)) = git_subcommand(after_program) else {
            continue;
        };
        if subcommand == WORKTREE && operands(arguments, &[]).first() == Some(&ADD) {
            return Some(WORKTREE_REASON.to_string());
        }
        if let Some(reason) = stash::refusal(subcommand, arguments)
            .or_else(|| branches::refusal(subcommand, arguments))
        {
            return Some(reason.to_string());
        }
        if subcommand == CLONE {
            if let Some(source) = operands(arguments, CLONE_VALUE_OPTIONS).first() {
                if source_is_local(source) {
                    return Some(clone_reason(source));
                }
            }
        }
    }
    None
}

/// Does the token carry a shell expansion, so its real value is unknown here?
/// The hook sees the command text, not its expansion: `cp -r "$REPO" dest`
/// offers the literal `$REPO`, which stats as nothing, so failing open here
/// would let every copy through a variable while a literal path is refused.
fn is_unexpanded(token: &str) -> bool {
    token.contains('$') || token.contains('`')
}

fn copy_refusal(tokens: &[String]) -> Option<String> {
    let (program, arguments) = tokens.split_first()?;
    if !COPY_PROGRAMS
        .iter()
        .any(|candidate| program_is(program, candidate))
    {
        return None;
    }
    if program_is(program, CP_PROGRAM) && !arguments.iter().any(|token| is_recursive_flag(token)) {
        return None;
    }
    let paths = operands(arguments, COPY_VALUE_OPTIONS);
    let (_destination, sources) = paths.split_last()?;
    if let Some(source) = sources.iter().find(|source| is_unexpanded(source)) {
        return Some(opaque_reason(source));
    }
    for source in sources {
        match holds_repository(source) {
            Ok(true) => return Some(COPY_REASON.to_string()),
            Ok(false) => {}
            Err(cause) => {
                return Some(format!(
                    "whether the copy source {source} is a checkout cannot be told: {cause}"
                ))
            }
        }
    }
    None
}

/// The refusal this call earns, or `None` when it passes. The caller writes
/// the banner to stderr and exits 2.
pub fn evaluate(payload: &Value) -> Option<String> {
    if let Some(reason) = native::refusal(payload) {
        return Some(reason);
    }
    let command = command_from(payload);
    command
        .split(SEGMENT_SPLIT)
        .map(shell_tokens)
        .find_map(|tokens| git_refusal(&tokens).or_else(|| copy_refusal(&tokens)))
}
