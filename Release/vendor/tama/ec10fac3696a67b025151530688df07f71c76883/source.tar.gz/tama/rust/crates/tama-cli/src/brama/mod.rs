//! Tama's model-service commands. The client itself lives in
//! `tama_hook_tools::brama`; this is the operator surface over it: whether
//! Brama answers, which service Tama asks instead when there is no Brama, or
//! that this machine has no model, on the terminal and on the Desktop.

pub mod check;
pub(crate) mod desktop;
pub mod provider;
