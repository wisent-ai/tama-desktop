//! Logic for `tama-block-crowded-folders`, registry hook
//! `block-crowded-folders`: a new file may not land in a folder that already
//! holds five.
//!
//! Only new files are judged; editing a file in a crowded folder is how a
//! folder gets tidied. Four kinds of folder are exempt because their layout
//! is decided elsewhere: migration directories (one file per migration, in
//! order, named by a timestamp), vendored and generated trees, and test
//! directories. New LaTeX-family files are exempt because venue templates
//! keep a document, bibliography and style files side by side.
//!
//! A folder declared to the audit with a reason is also exempt. Toolchains
//! can require several configuration files at a repository root; that
//! layout is a declared constraint rather than an unexplained crowded folder.

use tama_hooks::session_record::{deny_tool_use, read_payload};

use crate::ports::violations_declarations::folder_is_declared;
use crate::ports::write_payload::WritePayload;

const EXEMPT_SUFFIXES: &[&str] = &[".tex", ".bib", ".sty", ".bst", ".cls"];
/// Suffixes of files nothing reads as lines: a screenshot, a recording, an
/// icon, a font, a drawing. A folder of them is not a layout a person chose
/// -- `spis` keeps one folder per journey holding the recording and the six
/// states it passed through, so the count is the number of states the
/// journey had, and "move files into sub-folders or consolidate" asks for
/// something that cannot be done to two screenshots. The same scan that
/// refuses to read these files for the line rule ("binary content") must
/// not count them for the folder rule either, or most of a journey
/// recorder's crowded folders are captures.
const CAPTURE_SUFFIXES: &[&str] = &[
    ".png",
    ".jpg",
    ".jpeg",
    ".gif",
    ".webp",
    ".bmp",
    ".tiff",
    ".heic",
    ".ico",
    ".icns",
    ".svg",
    ".mp4",
    ".mov",
    ".m4v",
    ".webm",
    ".mp3",
    ".wav",
    ".m4a",
    ".pdf",
    ".woff",
    ".woff2",
    ".ttf",
    ".otf",
    ".zip",
    ".gz",
    ".tar",
    ".jar",
    ".wasm",
    ".pt",
    ".bin",
    ".gguf",
    ".safetensors",
];
/// Folder shapes whose file count is not a module-discipline question. A
/// database's own directories - the migrations it applied, the seeds it
/// loads in name order - are documents it names, not modules a person
/// arranges: `wisent-supabase-echo` keeps eighteen numbered seeds that no
/// sub-folder can hold without renaming what the database loads.
const EXEMPT_FOLDERS: &[&str] = &[
    "/supabase/migrations",
    "/supabase/seeds",
    "/node_modules/",
    "/.git/",
    "/__pycache__/",
    "/tests",
    "/migrations",
];

/// The operator's own limit: `max_folder_files` in `numeric-provenance.json`.
/// A folder already holding that many files refuses another. A limit this
/// machine cannot count to is an error naming it: read as no limit, every
/// folder would pass.
pub fn max_files() -> Result<usize, String> {
    let stated = crate::ports::stated_numbers::stated("max_folder_files");
    usize::try_from(stated).map_err(|error| {
        format!("max_folder_files states {stated}, which this machine cannot count to: {error}")
    })
}

/// Whether the file at `path` is outside the limit: a LaTeX-family file or a
/// capture nothing reads as lines.
pub fn exempt_file(path: &str) -> bool {
    let lowered = path.to_lowercase();
    EXEMPT_SUFFIXES
        .iter()
        .any(|suffix| lowered.ends_with(suffix))
        || !counts_toward_folder_limit(path)
}

/// Whether this path is one of the files the five-per-folder limit is about:
/// a module somebody wrote and somebody else has to find again.
///
/// The audit asks the guard rather than keeping its own list, because two
/// answers to "is this a module" drift and then the scan reports folders the
/// guard would never refuse.
pub fn counts_toward_folder_limit(path: &str) -> bool {
    let lowered = path.to_lowercase();
    !CAPTURE_SUFFIXES
        .iter()
        .any(|suffix| lowered.ends_with(suffix))
}

/// The shell tested `case "$DIR" in */tests*|*/migrations*|…`, so a marker
/// anywhere in the folder path exempts it, and the trailing-slash forms only
/// match a parent directory.
pub fn exempt_folder(dir: &str) -> bool {
    EXEMPT_FOLDERS.iter().any(|marker| dir.contains(marker))
}

fn files_in(dir: &std::path::Path) -> Result<usize, String> {
    let mut entries = std::fs::read_dir(dir)
        .map_err(|error| format!("cannot read target folder {}: {error}", dir.display()))?;
    // Fallible count starts at the additive identity, not a configurable limit.
    // https://doc.rust-lang.org/std/iter/trait.Iterator.html#method.try_fold
    entries.try_fold(0usize, |count, entry| {
        let entry =
            entry.map_err(|error| format!("cannot read an entry in {}: {error}", dir.display()))?;
        let path = entry.path();
        // A folder that a running program writes and removes files in (a
        // runtime's in-flight records) lists entries that are gone by the
        // time they are read: such an entry is no file of the folder any more,
        // and refusing the write for it blocked every write beside them.
        let counted = match std::fs::metadata(&path) {
            Ok(metadata) => {
                metadata.is_file() && counts_toward_folder_limit(&path.to_string_lossy())
            }
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => false,
            Err(error) => return Err(format!("cannot inspect {}: {error}", path.display())),
        };
        Ok(count + usize::from(counted))
    })
}

/// The final paths a write leaves, each judged on its own. Hashline sections
/// select their last literal move destination when present, otherwise their
/// header path; no source content is needed to count a new target's folder.
/// A multi-file adapter may send the session directory as its own path, so
/// judging only that path would count the directory as a new file.
/// An `apply_patch` envelope uses the files its replay leaves, and a plain
/// write or edit the path it names. A malformed move or failed replay is the
/// causal refusal, never a reason to substitute the session directory.
fn written_paths(
    payload: &serde_json::Value,
    file_path: &str,
) -> Result<Vec<(String, &'static str)>, String> {
    use crate::ports::check_numeric_literals_payload::{hashline_paths, path_texts};
    let call = crate::ports::tool_vocabulary::Call::of(payload);
    let Some(input) = call.input() else {
        return Ok(vec![(file_path.to_string(), OWN_PATH)]);
    };
    let named = hashline_paths(input, call.session_cwd())?;
    if !named.is_empty() {
        return Ok(named
            .into_iter()
            .map(|path| (path, HASHLINE_HEADER))
            .collect());
    }
    let sections = path_texts(input, call.session_cwd())?;
    Ok(if sections.is_empty() {
        vec![(file_path.to_string(), OWN_PATH)]
    } else {
        sections
            .into_iter()
            .map(|(path, _)| (path, REPLAYED_SECTION))
            .collect()
    })
}

/// Where a judged path came from, said in the refusal so a wrong folder can
/// be traced to the header, the replay or the call's own path that named it.
const HASHLINE_HEADER: &str = "a hashline section's resulting target";
const REPLAYED_SECTION: &str = "a replayed edit section";
const OWN_PATH: &str = "the call's own file path";

/// The refusal this write earns, if any: the first path it names that
/// would land as a new file in a crowded folder.
pub fn check(payload: &serde_json::Value) -> Option<String> {
    let write = match WritePayload::read(payload) {
        Ok(write) => write,
        Err(error) => return Some(error),
    };
    if write.is_system {
        return None;
    }
    let cwd = crate::ports::tool_vocabulary::Call::of(payload)
        .session_cwd()
        .map(str::to_string);
    match written_paths(payload, &write.file_path) {
        Ok(paths) => paths
            .into_iter()
            .find_map(|(path, origin)| check_path(&path, origin, cwd.as_deref())),
        Err(error) => Some(format!(
            "BLOCKED: which files this write creates cannot be told, so their folders cannot be \
             counted: {error}"
        )),
    }
}

/// The refusal one written `file_path` earns, if any; `origin` says what named
/// the path and `cwd` the session directory a relative one was anchored to.
fn check_path(file_path: &str, origin: &str, cwd: Option<&str>) -> Option<String> {
    if exempt_file(file_path) {
        return None;
    }
    let target = std::path::Path::new(file_path);
    match std::fs::metadata(target) {
        Ok(metadata) if metadata.is_file() => return None,
        Ok(_) => return Some(format!(
            "BLOCKED: invalid write target {}: expected an actual file, not a directory or special object; the adapter must supply each actual edited path",
            target.display()
        )),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
        Err(error) => return Some(format!("BLOCKED: cannot inspect write target {}: {error}", target.display())),
    }
    let dir = target.parent()?;
    let shown = dir.to_string_lossy().to_string();
    if exempt_folder(&shown) {
        return None;
    }
    match folder_is_declared(&shown) {
        Ok(true) => return None,
        Ok(false) => {}
        Err(error) => return Some(format!("BLOCKED: {error}")),
    }
    match std::fs::metadata(dir) {
        Ok(metadata) if metadata.is_dir() => {}
        Ok(_) => {
            return Some(format!(
                "BLOCKED: write target parent {shown} is not a directory"
            ))
        }
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return None,
        Err(error) => {
            return Some(format!(
                "BLOCKED: cannot inspect target folder {shown}: {error}"
            ))
        }
    }
    let count = match files_in(dir) {
        Ok(count) => count,
        Err(error) => return Some(format!("BLOCKED: {error}")),
    };
    let limit = match max_files() {
        Ok(limit) => limit,
        Err(error) => return Some(format!("BLOCKED: {error}")),
    };
    if count >= limit {
        Some(format!(
            "BLOCKED: Folder '{shown}' already has {count} files (max {limit}): the write would \
             create '{}' there (the path named by {origin}; session cwd {}). Move files into \
             sub-folders or consolidate.",
            target.display(),
            cwd.unwrap_or("not sent")
        ))
    } else {
        None
    }
}

pub fn run() {
    if let Some(refusal) = check(&read_payload()) {
        deny_tool_use(&refusal);
    }
}
