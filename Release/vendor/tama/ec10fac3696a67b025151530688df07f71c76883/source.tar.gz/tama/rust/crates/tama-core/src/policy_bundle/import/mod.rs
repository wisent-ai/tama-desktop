//! `import_policy_bundle`: inspect a source, plan what it would change,
//! and copy it into Tama's editable store without touching the runtime.
//!
//! Split out of `policy_bundle.rs`, which had grown past the
//! three-hundred-line limit.

use std::fs;

use crate::{err, Result};

use super::inspect::inspect;
use super::records::{ImportPolicyBundleOptions, PolicyBundleConflict, PolicyBundleImportResult};
use super::store::{lock_store, policy_bundle_store, read_index};
use super::{sha256, INACTIVE, RESULT_SCHEMA};

mod commit;
mod plan;

use commit::commit;
use plan::plan;

pub fn import_policy_bundle(
    options: ImportPolicyBundleOptions<'_>,
) -> Result<PolicyBundleImportResult> {
    let source = fs::canonicalize(options.source).map_err(|error| {
        err(format!(
            "policy bundle source is not an existing directory: {}: {error}",
            options.source.display()
        ))
    })?;
    if !source.is_dir() {
        return Err(err(format!(
            "policy bundle source is not a directory: {}",
            source.display()
        )));
    }
    let store = policy_bundle_store(options.home)?;
    let selection = match inspect(&source) {
        Ok(selection) => selection,
        Err(error) => {
            // A refused source still names what it holds outside the policy
            // roots; when even that listing fails, its cause is reported
            // beside the refusal instead of an empty list.
            let mut errors = vec![error.to_string()];
            let ignored = match super::inspect::scan::ignored_top_level(&source) {
                Ok(ignored) => ignored,
                Err(scan) => {
                    errors.push(format!(
                        "the top-level entries of {} could not be listed to name what was ignored: {scan}",
                        source.display()
                    ));
                    Vec::new()
                }
            };
            return Ok(PolicyBundleImportResult::rejected(
                &source, &store, errors, ignored,
            ));
        }
    };
    if source.starts_with(&store) || store.starts_with(&source) {
        return Ok(PolicyBundleImportResult::rejected(
            &source,
            &store,
            vec!["policy bundle source and Tama's editable store must be separate".to_string()],
            selection.ignored_paths,
        ));
    }

    let mut index = read_index(&store)?;
    let source_key = sha256(source.to_string_lossy().as_bytes());
    let bundle_root = store.join("bundles").join(&source_key);
    let existing = index
        .bundles
        .iter()
        .find(|bundle| bundle.source_key == source_key)
        .cloned();
    let planned = plan(&selection, existing.as_ref(), &bundle_root, options.replace)?;

    if !planned.conflicts.is_empty() {
        return Ok(outcome(
            "conflict",
            &source,
            &store,
            &bundle_root,
            &selection,
            Default::default(),
            planned.unchanged,
            Default::default(),
            planned.conflicts,
        ));
    }

    if existing
        .as_ref()
        .is_some_and(|record| record.source_digest == selection.digest)
        && planned.imported == 0
        && planned.removed == 0
    {
        return Ok(outcome(
            "unchanged",
            &source,
            &store,
            &bundle_root,
            &selection,
            Default::default(),
            planned.unchanged,
            Default::default(),
            Vec::new(),
        ));
    }

    let _lock = lock_store(&store)?;
    index = read_index(&store)?;
    if index
        .bundles
        .iter()
        .find(|bundle| bundle.source_key == source_key)
        .map(|bundle| bundle.source_digest.as_str())
        != existing
            .as_ref()
            .map(|bundle| bundle.source_digest.as_str())
    {
        return Err(err(
            "Tama policy-bundle store changed while the import was being prepared; retry",
        ));
    }

    commit(
        &store,
        &bundle_root,
        &source,
        &source_key,
        &selection,
        &mut index,
    )?;

    Ok(outcome(
        if existing.is_some() {
            "replaced"
        } else {
            "imported"
        },
        &source,
        &store,
        &bundle_root,
        &selection,
        planned.imported,
        planned.unchanged,
        planned.removed,
        Vec::new(),
    ))
}

/// One shape for every answer this command gives: the same identity of the
/// source and the store, with the counts that outcome reached.
#[allow(clippy::too_many_arguments)]
fn outcome(
    status: &str,
    source: &std::path::Path,
    store: &std::path::Path,
    bundle_root: &std::path::Path,
    selection: &super::records::Selection,
    imported: usize,
    unchanged: usize,
    removed: usize,
    conflicts: Vec<PolicyBundleConflict>,
) -> PolicyBundleImportResult {
    // This command only imports: it rejects no file once planned, and installs
    // or enables no hook, which activation does later.
    let rejections = Vec::new();
    PolicyBundleImportResult {
        schema: RESULT_SCHEMA.to_string(),
        status: status.to_string(),
        source_path: source.display().to_string(),
        source_digest: Some(selection.digest.clone()),
        store_path: store.display().to_string(),
        bundle_path: Some(bundle_root.display().to_string()),
        hook_count: selection.hook_count,
        imported,
        unchanged,
        removed,
        conflicting: conflicts.len(),
        rejected: rejections.len(),
        conflicts,
        rejections,
        ignored_paths: selection.ignored_paths.clone(),
        activation: INACTIVE.to_string(),
        installed_hooks: Default::default(),
        enabled_hooks: Default::default(),
    }
}
