//! The build and restart policy: how many builds a day, and how big a change
//! has to be to deserve one.
//!
//! The registry alone only asked for an intent to be written down, and an
//! agent writes one in a second. What produced ten releases in one evening was
//! not missing paperwork, it was a build per minimal change: edit two lines,
//! submit, wait forty minutes in the builder queue, read the failure, edit two
//! more. So the ration lives here, as data an operator owns, and the writer
//! refuses past it.
//!
//! The builds a day are the operator's own number, `builds_per_day` in
//! `numeric-provenance.json`, unless the file states another. The restarts a
//! day, the smallest serious change and the intent window have no number in
//! code: until the file states them, recording an intent is refused with the
//! command that states them. Tightening a limit needs nothing. Setting one, or
//! loosening it — more builds a day, a smaller change, a longer window — is a
//! change to what the machine permits, so it needs the same consent every
//! other hook configuration change needs: the operator's word in the
//! conversation, or the device variable in his own shell.

pub use super::policy_revision::revise;
use std::path::{Path, PathBuf};

use serde_json::{json, Value};

pub const FILE: &str = "build_restart_policy.json";
/// The operator's number: "limit 3 buildow dziennie", `builds_per_day` in
/// `numeric-provenance.json` with his words.
fn stated_builds_per_day() -> u64 {
    tama_hook_tools::ports::stated_numbers::stated(BUILDS)
}
/// The ration window. A rolling day, not a calendar day, so the count cannot
/// be reset by waiting for midnight.
pub const WINDOW_SECONDS: u64 = 24 * 60 * 60;

const BUILDS: &str = "builds_per_day";
const RESTARTS: &str = "restarts_per_day";
const LINES: &str = "minimum_changed_lines";
const WINDOW: &str = "window_minutes";

/// A limit and which direction is a loosening.
pub(super) struct Limit {
    pub(super) field: &'static str,
    pub(super) option: &'static str,
    /// `true` when a larger number permits more work.
    pub(super) larger_permits_more: bool,
}

pub(super) const LIMITS: [Limit; 4] = [
    Limit {
        field: BUILDS,
        option: "--builds-per-day",
        larger_permits_more: true,
    },
    Limit {
        field: RESTARTS,
        option: "--restarts-per-day",
        larger_permits_more: true,
    },
    Limit {
        field: LINES,
        option: "--minimum-changed-lines",
        larger_permits_more: false,
    },
    Limit {
        field: WINDOW,
        option: "--window-minutes",
        larger_permits_more: true,
    },
];

/// What a ration counts: a build of a product, or a restart of a unit.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Kind {
    Build,
    Restart,
}

impl Kind {
    pub const ALL: &'static [Kind] = &[Kind::Build, Kind::Restart];

    /// The name `--kind` takes and the ledger records.
    pub fn as_str(self) -> &'static str {
        match self {
            Kind::Build => "build",
            Kind::Restart => "restart",
        }
    }

    pub fn parse(name: &str) -> Option<Kind> {
        Self::ALL.iter().copied().find(|kind| kind.as_str() == name)
    }
}

#[derive(Clone, Copy, Debug)]
pub struct Policy {
    pub builds_per_day: u64,
    pub restarts_per_day: u64,
    pub minimum_changed_lines: u64,
    pub window_minutes: u64,
}

impl Policy {
    pub fn per_day(&self, kind: &str) -> u64 {
        match Kind::parse(kind) {
            Some(Kind::Restart) => self.restarts_per_day,
            _ => self.builds_per_day,
        }
    }

    pub fn document(&self) -> Value {
        json!({
            BUILDS: self.builds_per_day,
            RESTARTS: self.restarts_per_day,
            LINES: self.minimum_changed_lines,
            WINDOW: self.window_minutes,
        })
    }

    pub fn sentence(&self) -> String {
        format!(
            "{} builds and {} restarts in any 24 hours; a build carries at least {} changed \
             lines; one recorded intent authorizes {} minutes",
            self.builds_per_day,
            self.restarts_per_day,
            self.minimum_changed_lines,
            self.window_minutes
        )
    }
}

pub fn file(home: &Path) -> PathBuf {
    home.join(".shared-hooks").join(FILE)
}

/// The stored policy document, or an empty one when the file is absent or
/// empty. A file that is not a JSON object is refused and named: a policy
/// nobody can read is not a policy.
pub(super) fn stored(path: &Path) -> Result<Value, String> {
    let text = match std::fs::read_to_string(path) {
        Ok(text) => text,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(json!({})),
        Err(error) => return Err(format!("{} cannot be read: {error}", path.display())),
    };
    if text.trim().is_empty() {
        return Ok(json!({}));
    }
    let document: Value = serde_json::from_str(&text)
        .map_err(|error| format!("{} is not readable policy: {error}", path.display()))?;
    if !document.is_object() {
        return Err(format!(
            "{} is not readable policy: not a JSON object",
            path.display()
        ));
    }
    Ok(document)
}

/// The value a limit has: the one the file stores, and for the builds a day
/// the operator's stated number when the file stores none. The other limits
/// have no number in code.
pub(super) fn in_effect(document: &Value, field: &str) -> Option<u64> {
    document
        .get(field)
        .and_then(Value::as_u64)
        .or_else(|| (field == BUILDS).then(stated_builds_per_day))
}

/// Reads the policy. A limit the file does not set is refused with the
/// command that sets it: a ration nobody stated is not applied from a number
/// written in code.
pub fn load(path: &Path) -> Result<Policy, String> {
    let document = stored(path)?;
    let read = |field: &str| {
        in_effect(&document, field).ok_or_else(|| {
            let option = LIMITS
                .iter()
                .find(|limit| limit.field == field)
                .map_or(field, |limit| limit.option);
            format!(
                "{} sets no {field}: the operator states it with `tama build policy {option} \
                 <n>`, which needs his consent. {}",
                path.display(),
                crate::hooks::declare::consent_route(&format!("tama build policy {option} <n>"))
            )
        })
    };
    let policy = Policy {
        builds_per_day: read(BUILDS)?,
        restarts_per_day: read(RESTARTS)?,
        minimum_changed_lines: read(LINES)?,
        window_minutes: read(WINDOW)?,
    };
    if policy.window_minutes == 0 {
        return Err(format!(
            "{} sets {WINDOW} to zero, which authorizes nothing",
            path.display()
        ));
    }
    Ok(policy)
}
