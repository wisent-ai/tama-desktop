//! `tama attestation unjudged [--repository PATH] [--json]`: the unpushed
//! commits of a checkout (those HEAD carries that no remote-tracking ref
//! holds) whose attestation does not stand, read in one pass
//! (`task_attestation::unjudged`), and whether work in it is refused: the
//! gates refuse an edit or a commit there while they number more than the
//! operator admits. Tama Desktop's `attestation/unjudged` answers the same.

use std::path::Path;

use serde_json::{json, Value};
use tama_hook_tools::ports::task_attestation::unjudged;

use crate::gitcmd::git;

/// `{repository, unpushed, admitted, count, stands, commits: [{commit,
/// subject, missing, findings}]}` for the checkout `repository` is in (the
/// current directory when none is named). `stands` is false while the
/// checkout holds more unjudged unpushed commits than admitted; `unpushed`
/// is null while HEAD names no commit yet.
pub(crate) fn unjudged(repository: Option<&Path>) -> Result<Value, String> {
    let here = match repository {
        Some(repository) => repository.to_path_buf(),
        None => std::env::current_dir().map_err(|error| {
            format!("unjudged reads the current directory's checkout, and the current directory cannot be read: {error}")
        })?,
    };
    let top = git(&here, &["rev-parse", "--show-toplevel"])?;
    let top = Path::new(top.trim());
    let admitted = unjudged::admitted();
    let (unpushed, found) = match unjudged::unjudged(top)? {
        Some(range) => (json!(range.unpushed), range.unjudged),
        None => (Value::Null, Vec::new()),
    };
    let count = found.len();
    let within = u64::try_from(count)
        .map_err(|error| format!("{count} unjudged commits are no count: {error}"))?
        <= admitted;
    let commits: Vec<Value> = found
        .into_iter()
        .map(|each| {
            json!({
                "commit": each.commit, "subject": each.subject,
                "missing": each.unmet.missing, "findings": each.unmet.findings,
            })
        })
        .collect();
    Ok(json!({
        "repository": top.display().to_string(), "unpushed": unpushed,
        "admitted": admitted, "count": count, "stands": within, "commits": commits,
    }))
}

/// A report field as a person reads it: a text without its JSON quotes,
/// anything else as JSON prints it.
fn shown(value: &Value) -> String {
    match value {
        Value::String(text) => text.clone(),
        other => other.to_string(),
    }
}

/// The report as a person reads it: the count against the operator's limit,
/// then each unjudged commit with what its attestation lacks.
pub(crate) fn print_unjudged(report: &Value) {
    let repository = shown(&report["repository"]);
    if report["unpushed"].is_null() {
        println!("attestation: {repository}: HEAD names no commit yet, so nothing is unpushed");
        return;
    }
    println!(
        "attestation: {repository}: {} unpushed commit(s), {} without a standing attestation; the operator admits {}",
        report["unpushed"], report["count"], report["admitted"]
    );
    for commit in report["commits"].as_array().into_iter().flatten() {
        println!(
            "attestation: {} {}",
            shown(&commit["commit"]),
            shown(&commit["subject"])
        );
        for missing in commit["missing"].as_array().into_iter().flatten() {
            println!("    missing: {}", shown(missing));
        }
        for finding in commit["findings"].as_array().into_iter().flatten() {
            println!("    finding: {}", shown(finding));
        }
    }
    if report["stands"] != Value::Bool(true) {
        let repository_arg = tama_hook_tools::registry::shell_quote(&repository);
        println!(
            "attestation: edits of files {repository} does not ignore, and commits there, are refused until these \
             stand or are pushed: `tama attestation attest --repository {repository_arg} --commit <sha> --file <attestation>`, then push \
             refs/notes/attestation with the branch"
        );
    }
}
