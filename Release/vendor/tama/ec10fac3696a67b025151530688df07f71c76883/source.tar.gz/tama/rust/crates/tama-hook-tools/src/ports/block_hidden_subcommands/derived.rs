//! The clap entry points a file declares without spelling their names: a
//! variant of a `#[derive(Subcommand)]` enum whose CamelCase name has more
//! than one word and carries no `#[command(name = …)]` attribute is given a
//! hyphen-joined name by clap's own kebab-casing (`GpuPowerLimit` becomes
//! `gpu-power-limit`), so the hyphen is in the command without being in the
//! source, and a gate reading only name attributes lets it through.

/// What such a variant is called in the gate's findings.
pub(super) const CONSTRUCT: &str =
    "clap subcommand whose CamelCase variant derives a hyphen-joined name (no name attribute)";

/// Where the scanner is in the file: before a `Subcommand` enum, or inside
/// one with the braces open below its own (a variant's fields) on a stack.
enum Place {
    Outside { derives_subcommand: bool },
    Inside { nested: Vec<char>, named: bool },
}

/// Every variant line of a `Subcommand` enum in `text` whose name clap would
/// join with a hyphen, in order.
pub(super) fn findings(text: &str) -> Vec<String> {
    let mut found = Vec::new();
    let mut place = Place::Outside {
        derives_subcommand: false,
    };
    for line in text.lines() {
        let trimmed = line.trim();
        place = match place {
            Place::Outside { derives_subcommand } => outside(trimmed, derives_subcommand),
            Place::Inside {
                mut nested,
                mut named,
            } => {
                if nested.is_empty() {
                    if trimmed.starts_with("#[command(") {
                        named = named || names_itself(trimmed);
                    } else if let Some(variant) = variant_name(trimmed) {
                        if !named && kebab_joins(variant) {
                            found.push(trimmed.to_string());
                        }
                        named = false;
                    }
                }
                // A comment's braces open nothing (`/// {unreadable}`).
                let mut closed = false;
                let braces = trimmed
                    .chars()
                    .filter(|c| !trimmed.starts_with("//") && (*c == '{' || *c == '}'));
                for brace in braces {
                    match brace {
                        '{' => nested.push(brace),
                        _ if nested.pop().is_none() => closed = true,
                        _ => {}
                    }
                }
                if closed {
                    Place::Outside {
                        derives_subcommand: false,
                    }
                } else {
                    Place::Inside { nested, named }
                }
            }
        };
    }
    found
}

/// The next place after `trimmed`, read outside any `Subcommand` enum: the
/// derive attribute is remembered across the attributes and doc comments
/// that may stand between it and the enum it decorates.
fn outside(trimmed: &str, derives_subcommand: bool) -> Place {
    if trimmed.starts_with("#[derive(") {
        return Place::Outside {
            derives_subcommand: derive_names_subcommand(trimmed),
        };
    }
    let declares_enum = trimmed.starts_with("enum ") || trimmed.contains(" enum ");
    if declares_enum && derives_subcommand && trimmed.ends_with('{') {
        return Place::Inside {
            nested: Vec::new(),
            named: false,
        };
    }
    let keeps_derive = trimmed.starts_with("#[") || trimmed.starts_with("///");
    Place::Outside {
        derives_subcommand: derives_subcommand && keeps_derive && !declares_enum,
    }
}

fn derive_names_subcommand(attribute: &str) -> bool {
    attribute
        .trim_start_matches("#[derive(")
        .trim_end_matches(")]")
        .split(',')
        .any(|derived| derived.trim().rsplit("::").next() == Some("Subcommand"))
}

/// Whether a `#[command(…)]` attribute spells the subcommand's own name.
fn names_itself(attribute: &str) -> bool {
    attribute
        .trim_start_matches("#[command(")
        .split(',')
        .any(|field| field.trim().starts_with("name") && field.contains('='))
}

/// The variant a line declares, when it declares one: its CamelCase name
/// before `(`, `{`, `,` or the end of the line.
fn variant_name(line: &str) -> Option<&str> {
    if !line.starts_with(|character: char| character.is_ascii_uppercase()) {
        return None;
    }
    let (name, rest) = match line.find(|character: char| !character.is_ascii_alphanumeric()) {
        Some(end) => line.split_at(end),
        None => (line, ""),
    };
    let rest = rest.trim_start();
    (rest.is_empty() || rest.starts_with('(') || rest.starts_with('{') || rest.starts_with(','))
        .then_some(name)
}

/// Whether clap's kebab-casing of `name` joins more than one word with a
/// hyphen: a word begins at a lowercase-to-uppercase step, or at an uppercase
/// letter followed by a lowercase one after another uppercase (`APIKey`).
fn kebab_joins(name: &str) -> bool {
    let mut previous: Option<char> = None;
    let mut characters = name.chars().peekable();
    while let Some(current) = characters.next() {
        let after = characters.peek().copied();
        if let Some(before) = previous {
            let steps_up = (before.is_ascii_lowercase() || before.is_ascii_digit())
                && current.is_ascii_uppercase();
            let acronym_ends = before.is_ascii_uppercase()
                && current.is_ascii_uppercase()
                && after.is_some_and(|next| next.is_ascii_lowercase());
            if steps_up || acronym_ends {
                return true;
            }
        }
        previous = Some(current);
    }
    false
}
