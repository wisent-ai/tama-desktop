//! `tama rules` — reading and pruning the rules the frustration drafter
//! records.
//!
//! Those rules gate writes and commands, so they have to be reviewable and
//! they have to be removable. Removing one is not symmetrical with adding
//! one, though: a rule drafted from something the operator really said is
//! policy, and an agent may not delete the policy that constrains it. So a
//! row whose recorded quote is found in a real stored user message needs the
//! operator's out-of-band approval to remove, and a row whose quote is found
//! nowhere — a row nobody asked for, a row left by a test — may be removed by
//! anyone, because it was never policy in the first place.

mod decisions;
mod digest;
mod drafter_status;
mod frustration;

use std::path::PathBuf;

use serde_json::Value;
use tama_core::learning_registry;
use tama_hook_tools::ports::auto_rules::reaches_every_subject;

use crate::hooks::declare::{CONSENT_ENV, CONSENT_VALUE};

const REGISTRY: &str = ".shared-hooks/auto_rules.json";
const RULES_KEY: &str = "rules";
const ID_KEY: &str = "id";
const QUOTE_KEY: &str = "user_said";
/// What a rule row says when it does not record a field the list prints.
const NOT_RECORDED: &str = "(not recorded)";
const USAGE: &str = concat!(
    "usage: tama rules list [--json]\n",
    "       tama rules remove --id <id>\n",
    "       tama rules digest [--json]\n",
    "       tama rules dismiss --id <proposal-id>\n",
    "\n",
    "A rule drafted from a real operator message needs DEVICE_HOOK_EDIT_APPROVED=1 to remove;\n",
    "dismissing a digest proposal always needs it.",
);

fn registry_path() -> PathBuf {
    tama_core::home_dir().join(REGISTRY)
}

/// The rule rows of the registry document read from `path`. A document whose
/// rules are not a list is refused naming the file, not read as no rules.
fn taken(doc: &mut Value, path: &std::path::Path) -> Result<Vec<Value>, String> {
    match doc[RULES_KEY].as_array_mut() {
        Some(rules) => Ok(std::mem::take(rules)),
        None => Err(format!("{} holds no {RULES_KEY} list", path.display())),
    }
}

fn rows() -> Result<Vec<Value>, String> {
    let path = registry_path();
    taken(&mut learning_registry::read(&path)?, &path)
}

/// The word after `name` on the command line, when `name` is given.
fn option(argv: &[String], name: &str) -> Option<String> {
    let mut words = argv.iter();
    words.find(|argument| *argument == name)?;
    words.next().cloned()
}

/// The text `key` of a rule row, when the row records one.
fn field<'a>(row: &'a Value, key: &str) -> Option<&'a str> {
    row.get(key).and_then(Value::as_str)
}

/// [`field`] as the list prints it: a field the row does not record is said.
fn shown<'a>(row: &'a Value, key: &str) -> &'a str {
    match field(row, key) {
        Some(text) => text,
        None => NOT_RECORDED,
    }
}

fn list(argv: &[String]) -> Result<(), String> {
    let rows = rows()?;
    if argv.iter().any(|argument| argument == "--json") {
        println!("{}", serde_json::json!({ RULES_KEY: rows }));
        return Ok(());
    }
    if rows.is_empty() {
        println!("no drafted rules are recorded");
        return Ok(());
    }
    for row in &rows {
        println!(
            "{}\n  added:   {}\n  reads:   {}\n  pattern: {}\n  says:    {}\n  because: {}\n  \
             quote:   {}",
            shown(row, ID_KEY),
            shown(row, "added"),
            shown(row, "target"),
            shown(row, "pattern"),
            shown(row, "message"),
            shown(row, "why"),
            shown(row, QUOTE_KEY),
        );
        // The gates do not apply a row whose pattern matches every subject;
        // the list is where such a row is found and removed.
        if field(row, "pattern").is_some_and(reaches_every_subject) {
            println!(
                "  reach:   matches every {} and names no incident, so no gate applies it; \
                 remove it with `tama rules remove --id {}`",
                shown(row, "target"),
                shown(row, ID_KEY)
            );
        }
    }
    Ok(())
}

fn remove(argv: &[String]) -> Result<(), String> {
    let id = option(argv, "--id").ok_or_else(|| USAGE.to_string())?;
    let path = registry_path();
    let _lock = learning_registry::Lock::acquire(&path)?;
    let mut doc = learning_registry::read(&path)?;
    let rows = taken(&mut doc, &path)?;
    let row = rows
        .iter()
        .find(|row| field(row, ID_KEY) == Some(id.as_str()))
        .ok_or_else(|| format!("no rule with id {id} is recorded"))?;
    let policy = match field(row, QUOTE_KEY) {
        Some(quote) if !quote.is_empty() => {
            tama_hook_tools::ports::check_numeric_literals_provenance::quote_in_user_msg(quote)?
        }
        Some(_) | None => false,
    };
    let approved = matches!(std::env::var(CONSENT_ENV), Ok(value) if value == CONSENT_VALUE);
    if policy && !approved {
        return Err(format!(
            "refusing to remove {id}: it was drafted from something the operator really said, \
             and that quote is in the stored transcripts. Set {CONSENT_ENV}={CONSENT_VALUE} outside the agent \
             session to remove it."
        ));
    }
    let kept: Vec<Value> = rows
        .into_iter()
        .filter(|row| field(row, ID_KEY) != Some(id.as_str()))
        .collect();
    doc["rules"] = Value::Array(kept);
    learning_registry::replace(&path, &doc)?;
    if policy {
        println!("removed {id} with the operator's approval")
    } else {
        println!("removed {id}: no stored user message carries its quote")
    }
    Ok(())
}

/// The digest as the desktop reads it, from the same reader the command uses.
pub fn digest_document() -> Result<Value, String> {
    let (rules, registry_error) = match rows() {
        Ok(rules) => (rules, None),
        Err(error) => (Vec::new(), Some(error)),
    };
    let mut document = digest::document(&rules)?;
    if let Some(error) = registry_error {
        unreadable(&mut document, "drafted-rules", error)?;
    }
    if let Some(error) = drafter_status::failure() {
        unreadable(&mut document, "frustration-drafter", error)?;
    }
    Ok(document)
}

/// Add a source the digest could not read to its `unreadable` list; a digest
/// without that list is refused rather than losing the source's error.
fn unreadable(document: &mut Value, source: &str, error: String) -> Result<(), String> {
    let Some(listed) = document["unreadable"].as_array_mut() else {
        return Err(format!(
            "the rules digest has no unreadable list to report {source}: {error}"
        ));
    };
    listed.push(serde_json::json!({"source": source, "error": error}));
    Ok(())
}

/// Dismiss one proposal, with the command's refusal as the error.
pub fn dismiss_proposal(id: &str) -> Result<String, String> {
    digest::dismiss(id, &rows()?)
}

fn dismiss(argv: &[String]) -> Result<(), String> {
    let id = option(argv, "--id").ok_or_else(|| USAGE.to_string())?;
    println!("{}", digest::dismiss(&id, &rows()?)?);
    Ok(())
}

/// `tama rules`: a refusal is printed and ends the command unsuccessfully.
pub fn main(argv: &[String]) -> std::process::ExitCode {
    // `tama rules` with no verb lists, as the usage's first line says.
    let outcome = match argv.first().map(String::as_str) {
        None | Some("list") => list(argv),
        Some("remove") => remove(argv),
        Some("digest") => digest_document().and_then(|doc| digest::digest(argv, &doc)),
        Some("dismiss") => dismiss(argv),
        Some(_) => Err(USAGE.to_string()),
    };
    match outcome {
        Ok(()) => std::process::ExitCode::SUCCESS,
        Err(message) => {
            eprintln!("{message}");
            std::process::ExitCode::FAILURE
        }
    }
}
