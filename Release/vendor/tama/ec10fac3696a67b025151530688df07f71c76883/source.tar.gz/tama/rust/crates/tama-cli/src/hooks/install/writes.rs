//! Every file an install writes into the managed hook trees: the release's
//! hook files, the registry, both provider configurations wired to the
//! dispatcher, and the hook file of every declared harness on this machine
//! (`harnesses`).

mod harnesses;
mod merge;

use std::collections::BTreeMap;
use std::io::Write;
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};

use serde_json::Value;
use tama_hook_tools::ports::python_stdlib::shlex_quote;

use super::super::package::identity::PRUNED_GENERATORS;
use super::super::package::load_object;

/// Target path to (bytes, mode).
pub(super) type Writes = BTreeMap<PathBuf, (Vec<u8>, u32)>;

/// A mode's permission bits (S_IRWXU | S_IRWXG | S_IRWXO), without the
/// file-type bits, and the mode of a file every user may read but only its
/// owner write (S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH):
// https://pubs.opengroup.org/onlinepubs/9699919799/basedefs/sys_stat.h.html
const MODE_BITS: u32 = 0o777;
// https://pubs.opengroup.org/onlinepubs/9699919799/basedefs/sys_stat.h.html
const SHARED_FILE: u32 = 0o644;

/// `value` as the pretty JSON written to `target`, or why it cannot be
/// encoded: an empty file in its place would be an installed registry or
/// configuration that says nothing.
fn pretty(value: &Value, target: &Path) -> Result<Vec<u8>, String> {
    serde_json::to_string_pretty(value)
        .map(|text| format!("{text}\n").into_bytes())
        .map_err(|error| {
            format!(
                "cannot encode {} for the install: {error}",
                target.display()
            )
        })
}

/// Every file under `root`. A release that does not carry `root` holds none;
/// a directory or entry that cannot be read is an error naming it: skipped,
/// the install wrote a release with those hooks missing and said nothing.
fn files_under(root: &Path, found: &mut Vec<PathBuf>) -> Result<(), String> {
    let entries = match std::fs::read_dir(root) {
        Ok(entries) => entries,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(()),
        Err(error) => return Err(format!("cannot list {}: {error}", root.display())),
    };
    for entry in entries {
        let entry = entry
            .map_err(|error| format!("cannot read an entry of {}: {error}", root.display()))?;
        let path = entry.path();
        if path.is_dir() {
            files_under(&path, found)?;
        } else if path.is_file() {
            found.push(path);
        }
    }
    Ok(())
}

/// The managed hook trees of the release, mapped onto this home, and the registry.
pub(super) fn release_file_map(
    release_root: &Path,
    home: &Path,
    registry: &Value,
) -> Result<Writes, String> {
    let mut writes = Writes::new();
    for (from, to) in [
        ("shared-hooks", ".shared-hooks"),
        ("claude-hooks", ".claude/hooks"),
        ("codex-hooks", ".codex/hooks"),
    ] {
        let source_root = release_root.join(from);
        let mut files = Vec::new();
        files_under(&source_root, &mut files)?;
        for source in files {
            let relative = source.strip_prefix(&source_root).map_err(|error| {
                format!(
                    "{} was listed under {} but does not lie in it: {error}",
                    source.display(),
                    source_root.display()
                )
            })?;
            let name = source
                .file_name()
                .ok_or_else(|| format!("{} names no file", source.display()))?
                .to_string_lossy();
            let generator = PRUNED_GENERATORS
                .iter()
                .any(|pruned| pruned.ends_with(&format!("/{name}")));
            if generator
                || name.ends_with(".pyc")
                || relative
                    .components()
                    .any(|c| c.as_os_str() == "__pycache__")
            {
                continue;
            }
            let bytes = std::fs::read(&source)
                .map_err(|error| format!("cannot read {}: {error}", source.display()))?;
            let mode = std::fs::metadata(&source)
                .map(|m| m.permissions().mode() & MODE_BITS)
                .map_err(|error| {
                    format!("cannot read the mode of {}: {error}", source.display())
                })?;
            writes.insert(home.join(to).join(relative), (bytes, mode));
        }
    }
    writes.insert(
        home.join(".shared-hooks/registry.json"),
        (
            pretty(registry, &home.join(".shared-hooks/registry.json"))?,
            SHARED_FILE,
        ),
    );
    Ok(writes)
}

/// The provider wiring the sealed CLI generates for `provider`.
fn provider_hook_block(
    release_root: &Path,
    registry: &Value,
    provider: &str,
    dispatcher: &str,
) -> Result<Value, String> {
    let cli = release_root.join("bin/tama");
    if !cli.is_file() {
        return Err("Approved hook release is missing the sealed Tama CLI".to_string());
    }
    let mut child = Command::new(&cli)
        .args(crate::provider_config::COMMAND.split(' '))
        .args(["--provider", provider, "--dispatcher", dispatcher, "--json"])
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .map_err(|error| format!("Provider config generation failed for {provider}: {error}"))?;
    // The generator reads the registry on stdin; a registry it never received
    // would generate wiring for no hooks, so a failed write is the failure.
    let sent = match child.stdin.take() {
        Some(mut stdin) => stdin.write_all(registry.to_string().as_bytes()),
        None => Err(std::io::Error::other(
            "the generator's stdin was not opened",
        )),
    };
    let output = stado_wait::child_output(child, format!("{} provider config", cli.display()))
        .map_err(|error| format!("Provider config generation failed for {provider}: {error}"))?;
    if let Err(error) = sent {
        return Err(format!(
            "Provider config generation failed for {provider}: the registry could not be written to it: {error}"
        ));
    }
    if !output.status.success() {
        let stderr = String::from_utf8_lossy(&output.stderr);
        let said = match stderr.trim().lines().last() {
            Some(last) => last.to_string(),
            None => format!("it exited {} and wrote nothing on stderr", output.status),
        };
        return Err(format!(
            "Provider config generation failed for {provider}: {said}"
        ));
    }
    let block: Value = serde_json::from_slice(&output.stdout).map_err(|error| {
        format!("Provider config generation failed for {provider}: unreadable block: {error}")
    })?;
    match block.as_object() {
        Some(object) if !object.is_empty() => Ok(block),
        _ => Err(format!(
            "Provider config generation failed for {provider}: empty hook block"
        )),
    }
}

/// A provider's configuration before this install: the saved copy when an
/// emergency disable emptied it, otherwise the file itself.
fn base_config(
    target: &Path,
    label: &str,
    manifest: &Value,
    backup: Option<&Path>,
    load: impl FnOnce(&Path) -> Result<Value, String>,
) -> Result<Value, String> {
    let configured = manifest["configs"].as_array().is_some_and(|c| {
        c.iter()
            .any(|p| p.as_str() == Some(target.display().to_string().as_str()))
    });
    let saved = backup
        .map(|root| root.join(label))
        .filter(|saved| configured && saved.is_file());
    let source = match saved {
        Some(saved) => saved,
        None => target.to_path_buf(),
    };
    if !source.is_file() {
        return Ok(Value::Object(Default::default()));
    }
    load(&source)
}

/// The Node.js program the dispatcher runs under and the preflight it loads first.
pub(super) struct Runtime<'a> {
    pub(super) node: &'a Path,
    pub(super) preflight: &'a Path,
}

/// Both provider configurations and every present harness's hook file,
/// wired to the installed dispatcher.
pub(super) fn provider_writes(
    writes: &mut Writes,
    release_root: &Path,
    home: &Path,
    registry: &Value,
    runtime: Runtime,
    manifest: &Value,
    backup: Option<&Path>,
) -> Result<(), String> {
    if !writes.contains_key(&home.join(".shared-hooks/omp-shared-hooks.js")) {
        return Err("Approved hook release is missing the OMP Tama adapter".to_string());
    }
    let dispatcher_target = home.join(".shared-hooks/run-hook.mjs");
    if !writes.contains_key(&dispatcher_target) {
        return Err("Approved hook release is missing the Tama hook dispatcher".to_string());
    }
    let dispatcher = format!(
        "{} --require {} {}",
        shlex_quote(&runtime.node.to_string_lossy()),
        shlex_quote(&runtime.preflight.to_string_lossy()),
        shlex_quote(&dispatcher_target.to_string_lossy())
    );
    for (provider, target, label) in [
        (
            "claude",
            home.join(".claude/settings.json"),
            "claude-settings.json",
        ),
        ("codex", home.join(".codex/hooks.json"), "codex-hooks.json"),
    ] {
        let mut config = base_config(&target, label, manifest, backup, load_object)?;
        config["hooks"] = provider_hook_block(release_root, registry, provider, &dispatcher)?;
        let bytes = pretty(&config, &target)?;
        writes.insert(target, (bytes, tama_core::OWNER_ONLY_FILE));
    }
    harnesses::harness_writes(
        writes,
        release_root,
        home,
        registry,
        &dispatcher,
        manifest,
        backup,
    )
}
