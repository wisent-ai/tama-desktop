//! Decision half of `tama hook block-unauthorized-deletion` (hook id
//! `block-unauthorized-deletion`): a call that deletes a file or folder
//! outside a checkout's Git-ignored `.build/` or `target/` folder is refused
//! unless the operator granted that exact deletion in his own words
//! ([`crate::ports::operator_grant`]). Every tracked file, every test file
//! among them, lies outside such a folder, so its deletion is refused too.
//!
//! What a call deletes is read without a model: a shell line's deleting
//! commands ([`shell`]), a hashline `REM` or patch `*** Delete File:`, and
//! the deleting calls of an evaluation's code ([`tools`]). A deletion whose
//! target cannot be read — a path the shell or the code computes, operands
//! handed over by `xargs` — is refused like one outside, and only a grant
//! naming the exact command lets it run.

mod area;
mod shell;
mod tools;

/// A path word read as the deletion gate reads it, shared with the gates
/// that judge where a write lands.
pub(crate) use area::absolute as absolute_path;

use std::path::{Path, PathBuf};

use serde_json::Value;

use crate::ports::operator_grant::{self, Request};
use crate::ports::tool_vocabulary::Call;

pub const HOOK_ID: &str = "block-unauthorized-deletion";
const GRANT_KIND: &str = "deletion";
const BANNER: &str = "BLOCKED: unauthorized deletion: ";

/// One thing a call deletes: the absolute paths its word may name (one per
/// folder the line may run it in), or a target that cannot be read, with why.
pub(crate) enum Target {
    Paths(Vec<PathBuf>),
    Unknown(String),
}

/// The refusal when the call deletes outside an ignored build folder with
/// no grant, `None` when it passes.
pub fn evaluate(payload: &Value) -> Option<String> {
    let call = Call::of(payload);
    let cwd = match call.working_dir() {
        Ok(cwd) => cwd,
        Err(cause) => return deletes(payload, Path::new("/")).then(|| format!("{BANNER}{cause}")),
    };
    let command = call.is_shell().then(|| call.command()).flatten();
    let targets = targets(payload, &call, &cwd, command);
    let mut outside: Vec<String> = Vec::new();
    let mut unknown: Vec<String> = Vec::new();
    for target in targets {
        match target {
            Target::Paths(paths) => {
                for path in paths {
                    if !area::inside(Path::new("/"), &path.to_string_lossy()) {
                        let shown = path.to_string_lossy().into_owned();
                        if !outside.contains(&shown) {
                            outside.push(shown);
                        }
                    }
                }
            }
            Target::Unknown(cause) => unknown.push(cause),
        }
    }
    if outside.is_empty() && unknown.is_empty() {
        return None;
    }
    let paths: Vec<String> = if unknown.is_empty() {
        outside.clone()
    } else {
        Vec::new()
    };
    let request = Request {
        gate: HOOK_ID,
        command,
        paths: &paths,
    };
    if operator_grant::granted(payload, &request) {
        return None;
    }
    let mut said = Vec::new();
    if !outside.is_empty() {
        said.push(format!(
            "this call deletes {} outside a checkout's Git-ignored .build/ or target/ folder",
            outside.join(", ")
        ));
    }
    if !unknown.is_empty() {
        said.push(format!(
            "what it deletes cannot be read: {}",
            unknown.join("; ")
        ));
    }
    Some(format!(
        "{BANNER}{}. A deletion outside build output needs the operator's grant for that exact \
         path or command. {}",
        said.join("; and "),
        operator_grant::how_to_grant(GRANT_KIND, HOOK_ID)
    ))
}

/// Everything the call deletes, whichever tool it is.
fn targets(payload: &Value, call: &Call, cwd: &Path, command: Option<&str>) -> Vec<Target> {
    let mut found = Vec::new();
    if let Some(command) = command {
        found.extend(shell::targets(payload, cwd, command));
    }
    if let Some(code) = call.code() {
        found.extend(tools::evaluated(payload, code, cwd));
    }
    found.extend(tools::patched(payload, cwd));
    found
}

/// Whether the call deletes anything at all, read against `cwd`; used only
/// where its own folder cannot be read.
fn deletes(payload: &Value, cwd: &Path) -> bool {
    let call = Call::of(payload);
    let command = call.is_shell().then(|| call.command()).flatten();
    !targets(payload, &call, cwd, command).is_empty()
}
