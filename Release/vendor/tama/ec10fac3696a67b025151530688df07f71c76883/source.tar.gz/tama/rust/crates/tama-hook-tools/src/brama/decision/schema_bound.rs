//! A typed decision asked of a service declared with `tama model-provider
//! set` instead of Brama: one chat completion bound to a strict JSON Schema
//! (`response_format: json_schema`, which every OpenAI-compatible service
//! documents), so a machine without Brama answers the same typed questions
//! Brama's `POST /v1/decisions` answers and no hook goes unread there.
//!
//! Each question is a property of the schema whose `choice` is one of the
//! criteria the question declares, so the service cannot answer outside
//! them; its reply is checked as a decision document, the same way Brama's
//! is.

use serde_json::{json, Map, Value};

use super::super::credentials::Credentials;
use super::super::request::exchange;
use super::CHOICE;

/// The protocol names of a schema-bound chat completion.
const RESPONSE_FORMAT: &str = "json_schema";
const SCHEMA_NAME: &str = "decision";
/// What the service is told it is asked.
const FRAME: &str = "You answer typed questions about the state the user message holds. The \
questions are given below as JSON, each under its key, with its instructions and the options \
it may take, each option described by what it means. Answer every question with the one \
option its instructions and the state support.";

/// The answers `model` at the declared service gives to `questions` about
/// `state`, keyed as asked, in the document shape Brama answers with. A
/// question that is not a choice, a reply without a message, or a message
/// that is not the bound document is the error, naming what the service sent.
pub(super) fn decide(
    model: &str,
    url: &str,
    credentials: &Credentials,
    state: &str,
    questions: &Map<String, Value>,
) -> Result<Value, String> {
    let request = json!({
        "model": model,
        "messages": [
            { "role": "system", "content": format!("{FRAME}\n\n{}", Value::Object(questions.clone())) },
            { "role": "user", "content": state },
        ],
        "response_format": {
            "type": RESPONSE_FORMAT,
            RESPONSE_FORMAT: { "name": SCHEMA_NAME, "strict": true, "schema": schema(questions)? },
        },
    });
    let reply = exchange(model, url, &request, credentials)?;
    let content = reply["choices"]
        .as_array()
        .and_then(|choices| choices.first())
        .and_then(|choice| choice.pointer("/message/content"))
        .and_then(Value::as_str)
        .ok_or_else(|| {
            format!(
                "the declared model service {url} answered the decision with no message: {reply}"
            )
        })?;
    let answers: Value = serde_json::from_str(content).map_err(|error| {
        format!(
            "the declared model service {url} answered the decision with a message that is not \
             the bound document ({error}): {content}"
        )
    })?;
    Ok(json!({ "answers": answers }))
}

/// The strict schema of the answers: one required object per question,
/// holding the `choice` among that question's criteria and nothing else.
fn schema(questions: &Map<String, Value>) -> Result<Value, String> {
    let mut properties = Map::new();
    for (key, question) in questions {
        if question["type"].as_str() != Some(CHOICE) {
            return Err(format!(
                "question `{key}` is not a {CHOICE}, the one kind a typed decision asks: {question}"
            ));
        }
        let options: Vec<&String> = question["criteria"]
            .as_object()
            .map(|criteria| criteria.keys().collect())
            .ok_or_else(|| {
                format!("question `{key}` declares no criteria to choose among: {question}")
            })?;
        properties.insert(
            key.clone(),
            json!({
                "type": "object",
                "properties": { CHOICE: { "type": "string", "enum": options } },
                "required": [CHOICE],
                "additionalProperties": false,
            }),
        );
    }
    let required: Vec<&String> = questions.keys().collect();
    Ok(json!({
        "type": "object",
        "properties": properties,
        "required": required,
        "additionalProperties": false,
    }))
}
