//! Where the provider catalog and the work root live, what a valid provider
//! entry looks like, and how its argument template expands. The registry is
//! the one `tama_core::hook_registry` names, as every Tama program reads it.
//!
//! Split out of `one_session/mod.rs`, which had grown past the
//! three-hundred-line limit; the launch itself is next door.

use crate::util::{js_string_or_empty, shared_hooks_root};
use serde_json::{Map, Value};
use std::path::{Path, PathBuf};

pub const PROVIDER_CATALOG_SCHEMA: &str = "ai.wisent.tama.providers.v1";

/// The hook registry a one-session run reads: the one every Tama program
/// reads, from `tama_core::hook_registry`.
pub fn registry_path() -> PathBuf {
    tama_core::hook_registry()
}

/// The provider catalog: the one `TAMA_PROVIDER_CATALOG` names, or the one
/// in the Tama checkout's hooks directory.
pub fn provider_catalog_path() -> Result<PathBuf, String> {
    match tama_core::path_variable("TAMA_PROVIDER_CATALOG") {
        Some(path) => Ok(path),
        None => Ok(shared_hooks_root()?.join("providers.json")),
    }
}

/// Where one-session hook runs keep their work: the directory
/// `TAMA_SESSION_HOOK_WORK_ROOT` names, or `.tama/one-session-hook` beside
/// the installed hooks' directory.
pub fn work_root() -> Result<PathBuf, String> {
    if let Some(path) = tama_core::path_variable("TAMA_SESSION_HOOK_WORK_ROOT") {
        return Ok(path);
    }
    let hooks = shared_hooks_root()?;
    match hooks.parent() {
        Some(parent) => Ok(parent.join(".tama").join("one-session-hook")),
        None => Err(format!(
            "the installed hooks' directory {} has no parent to keep one-session hook work beside; name one with TAMA_SESSION_HOOK_WORK_ROOT",
            hooks.display()
        )),
    }
}

/// `extensionPath` in JS is the run-one-session-hook script itself; OMP can
/// only load JS extensions, so the port keeps pointing at the JS file.
pub fn extension_path() -> Result<PathBuf, String> {
    Ok(shared_hooks_root()?.join("run-one-session-hook.js"))
}

pub fn run_hook_path() -> Result<PathBuf, String> {
    Ok(shared_hooks_root()?.join("run-hook.mjs"))
}

/// Read and validate the top-level provider catalog.
pub fn load_provider_catalog(path: &Path) -> Result<Map<String, Value>, String> {
    let text = std::fs::read_to_string(path).map_err(|e| {
        if e.kind() == std::io::ErrorKind::NotFound {
            format!(
                "ENOENT: no such file or directory, open '{}'",
                path.display()
            )
        } else {
            e.to_string()
        }
    })?;
    let catalog: Value = serde_json::from_str(&text).map_err(|e| format!("{}", e))?;
    let providers = catalog.get("providers").and_then(Value::as_object);
    match (catalog.get("schema").and_then(Value::as_str), providers) {
        (Some(PROVIDER_CATALOG_SCHEMA), Some(providers)) => Ok(providers.clone()),
        _ => Err(format!("Invalid Tama provider catalog: {}", path.display())),
    }
}

/// The provider's argument template with each `{name}` replaced by its value.
pub fn expand_arguments(
    template: &[Value],
    values: &Map<String, Value>,
) -> Result<Vec<String>, String> {
    let mut out = Vec::new();
    for argument in template {
        // Every argument the catalog declares is text; one that is not would
        // launch the provider one argument short, so it is refused.
        let Some(argument) = argument.as_str() else {
            return Err(format!(
                "Provider argument {argument} in the Tama provider catalog is not text"
            ));
        };
        if argument == "{session}" && values.get("session").is_none() {
            continue;
        }
        let Some(key) = argument
            .strip_prefix('{')
            .and_then(|rest| rest.strip_suffix('}'))
        else {
            out.push(argument.to_string());
            continue;
        };
        match values.get(key) {
            Some(value) => out.push(js_string_or_empty(Some(value))),
            None => {
                return Err(format!(
                    "Unknown provider argument placeholder: {}",
                    argument
                ))
            }
        }
    }
    Ok(out)
}

pub(super) fn validate_provider(provider: &Value) -> Result<(), String> {
    let text = |key: &str| provider.get(key).is_some_and(Value::is_string);
    let list = |key: &str| provider.get(key).is_some_and(Value::is_array);
    let ok = text("executable")
        && text("executableEnv")
        && text("hookTransport")
        && list("newArguments")
        && list("resumeArguments");
    if !ok {
        return Err("Invalid provider entry in Tama provider catalog.".to_string());
    }
    Ok(())
}
