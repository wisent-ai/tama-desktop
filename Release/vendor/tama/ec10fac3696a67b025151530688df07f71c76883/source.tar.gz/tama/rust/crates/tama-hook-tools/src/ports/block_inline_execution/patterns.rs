//! What an inline program looks like in a shell command.
//!
//! Whether a command carries a program — shell control flow written on the
//! command line, source handed to an interpreter through its execute flag, a
//! filter language program, a here-document or process substitution into an
//! interpreter — is what the command does; the program-family lists and
//! keyword alternations this module used to carry decided it by name. It is
//! read by a model through Oko's model call (`judge-prompt.md`), asked only
//! of a command whose syntax can carry source at all: a quoted argument, a
//! here-document, a process substitution, standard input named as a file, a
//! command list or group, or `eval`. A question the judge leaves unanswered
//! is the error: the refusal `model_judgement::unanswered` gives it.

use std::sync::LazyLock;

use regex::Regex;

use crate::ports::model_judgement;
use crate::ports::transport_common as common;

const TAG: &str = "block-inline-execution";
const PROMPT: &str = include_str!("judge-prompt.md");
const COMMAND_SLOT: &str = "{command}";
/// The schema the judge answers under and the two options it chooses from.
const JUDGEMENT: &str = "inline_program";
const PASS: &str = "PASS";
const BLOCK: &str = "BLOCK";

/// The shell syntax that can carry source to a program: quoting, a
/// here-document, a process substitution, standard input named as a file,
/// the separators and brackets that make a command list, loop, conditional
/// or function body, and the `eval` builtin.
const QUOTES: &[char] = &['\'', '"'];
const LIST_SYNTAX: &[char] = &[';', '\n', '{', '('];
const HERE_DOCUMENT: &str = "<<";
const PROCESS_SUBSTITUTION: &str = "<(";
const STANDARD_INPUT_FILE: &str = "/dev/stdin";
static EVAL_BUILTIN: LazyLock<Regex> =
    LazyLock::new(|| common::compile(r"(?:^|[;&|`(][[:space:]]*)eval(?:[[:space:]]|$)"));

/// Whether the command's syntax can hand source code to a program at all.
fn can_carry_source(command: &str) -> bool {
    command.contains(QUOTES)
        || command.contains(LIST_SYNTAX)
        || command.contains(HERE_DOCUMENT)
        || command.contains(PROCESS_SUBSTITUTION)
        || command.contains(STANDARD_INPUT_FILE)
        || EVAL_BUILTIN.is_match(command)
}

/// The inline program the model read in `command`; nothing when there is
/// none or its syntax cannot carry one. The error is the refusal of a
/// question the judge left unanswered (`model_judgement::unanswered`). The
/// model is never asked inside the hook, where every shell would wait on
/// it: a command not yet judged is refused naming `tama judgement ask`.
pub(crate) fn inline_program(command: &str) -> Result<Option<String>, String> {
    if !can_carry_source(command) {
        return Ok(None);
    }
    let prompt = PROMPT.replace(COMMAND_SLOT, command.trim());
    let judged = match model_judgement::Choice::review_deferred(&prompt, JUDGEMENT, &[PASS, BLOCK])
    {
        Ok(judged) => judged,
        Err(unanswered) => {
            return match model_judgement::unanswered::refusal(TAG, &unanswered, Some(command)) {
                Some(refusal) => Err(refusal),
                None => Ok(None),
            }
        }
    };
    Ok((judged.choice == BLOCK).then_some(judged.reason))
}
