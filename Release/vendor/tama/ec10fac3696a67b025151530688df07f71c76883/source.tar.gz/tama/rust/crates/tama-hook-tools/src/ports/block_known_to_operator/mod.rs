//! Logic for `tama-block-known-to-operator`, registry hook id
//! `block-known-to-operator`.
//!
//! A Stop gate. It refuses a final message that tells the operator what he
//! already knows: what this session already told him, or what he himself
//! decided — a refusal from his own hooks, a limit he set, a rule he stated
//! — handed back to him as a blocker, a limitation or news.
//!
//! Why: a refusal from the machine's own gates, a build ration the operator
//! set, or a fact the session already told him is known to him, and handing
//! it back gives him nothing: information already communicated, or that he
//! himself decided, is irrelevant to him by definition.
//!
//! Shape cannot decide this — whether a sentence restates an earlier answer,
//! or reports the operator's own decision back to him, is a reading of two
//! texts against a third — so the decider is a model. First Oko compares the
//! answer with every standing ruling of his, in every session
//! (`oko rulings check`, [`rulings`]); an answer Oko refuses, or could not
//! compare, does not reach him. Then the session's own memory: the
//! operator's messages and the agent's earlier answers are read out of the
//! live transcript and put before a model asked through Brama by
//! `ports::model_judgement`. Before any model, the answer carries this
//! hook's turn-end attestation (`task_attestation/standards/turn.json`) word
//! for word: the agent states that it asks the operator for nothing he
//! already answered, signing Brama in among them, and a missing claim refuses
//! the ending with no model asked. Before the model too, a sentence an
//! earlier answer of this session already said word for word is refused
//! from the transcript alone ([`repeated`]), so a repetition is refused
//! whether or not Brama answers. When the model gives no verdict, the
//! attestation and the transcript check decide and the cause goes to
//! stderr. A session that has said nothing yet is never asked about.
mod repeated;
mod rulings;
mod session;

use serde_json::Value;
use tama_hooks::session_record::{deny, read_payload};

use crate::ports::block_unsearched_blocker_claim::final_message;
use crate::ports::model_judgement;

const TAG: &str = "block-known-to-operator";
const STOP_HOOK_ACTIVE: &str = "stop_hook_active";
/// The schema the judge answers under and the two options it chooses from.
const JUDGEMENT: &str = "known_to_operator";
const PASS: &str = "PASS";
const BLOCK: &str = "BLOCK";

const PROMPT: &str = "You are a strict gate over the final message an AI coding agent is about to hand its operator. \
The operator's rule, in his words: \"the user does not need this information. this is intentional. \
a model should not be able to provide irrelevant information to the user. especially information that \
a. was already communicated before b. the user has decidedly asked for\".

Three texts follow. <operator> holds every message the operator wrote in this session, oldest first: \
his requests, his decisions, the rules and limits he stated. <told> holds every earlier answer the \
agent gave him in this session, oldest first. <answer> is the message about to be sent.

Refuse a sentence of <answer> that:
1. tells the operator something <told> already told him in substance — the same fact, the same \
failure, the same refusal, the same explanation, reworded or repeated; or
2. reports back to the operator something he himself decided, asked for or installed — a refusal \
by his own hooks, gates, guards or policy; a limit, quota, ration or rule he set; a choice he made in \
<operator> — presented as a blocker, a limitation, a reason the work stopped, or as news. What the \
operator decided is his intention, not an obstacle, and never needs telling.

Do not refuse: the results of the work he asked for; a direct answer to a question he asked; a \
defect identifier named in one clause; a failure outside his own decisions that <told> never mentioned; \
a sentence that only names what he must do or decide next without explaining his own policy to him.

Choose BLOCK when a sentence of <answer> is one to refuse, giving in the reason each offending sentence \
quoted verbatim, followed by one clause saying whether it was told before or is his own decision; \
choose PASS when none is, saying in the reason why.

<operator>
{operator}
</operator>

<told>
{told}
</told>

<answer>
{answer}
</answer>";

const OPERATOR_PLACEHOLDER: &str = "{operator}";
const TOLD_PLACEHOLDER: &str = "{told}";
const ANSWER_PLACEHOLDER: &str = "{answer}";
const VOICE_SEPARATOR: &str = "\n\n---\n\n";

fn log(text: &str) {
    eprintln!("{TAG}: {text}");
}

/// The prompt for one answer, every voice whole.
fn prompt(said: &session::Said, answer: &str) -> String {
    PROMPT
        .replace(OPERATOR_PLACEHOLDER, &said.operator.join(VOICE_SEPARATOR))
        .replace(TOLD_PLACEHOLDER, &said.told.join(VOICE_SEPARATOR))
        .replace(ANSWER_PLACEHOLDER, answer)
}

/// The refusal naming the sentences `said` quotes.
fn refusal(said: &str) -> String {
    let said = match said.trim() {
        "" => "the model named no sentence",
        said => said,
    };
    format!(
        "{TAG}: this answer tells the operator what he already knows: {said}. His rule: \"the user \
         does not need this information. this is intentional. a model should not be able to provide \
         irrelevant information to the user. especially information that a. was already communicated \
         before b. the user has decidedly asked for\". A gate of his that refused you is his decision, \
         not your blocker; what this session already told him is not news. Delete those sentences \
         and answer with the work."
    )
}

/// The refusal, or nothing: no answer to judge, nothing said yet in the
/// session, an attested answer the model passed or gave no verdict on.
pub fn check(payload: &Value) -> Option<String> {
    if payload.get(STOP_HOOK_ACTIVE) == Some(&Value::Bool(true)) {
        return None;
    }
    let answer = match final_message(payload) {
        Ok(answer) => answer,
        Err(error) => {
            return Some(format!(
                "{TAG}: TAMA_HOOK_INFRASTRUCTURE: this answer cannot be judged: {error}"
            ))
        }
    };
    if answer.trim().is_empty() {
        return None;
    }
    let Some(path) = session::locate(payload) else {
        log("no transcript for this session; nothing is known yet");
        return None;
    };
    let raw = match std::fs::read_to_string(&path) {
        Ok(raw) => raw,
        Err(error) => {
            return Some(format!(
                "{TAG}: TAMA_HOOK_INFRASTRUCTURE: the session transcript {} cannot be read: \
                 {error}",
                path.display()
            ))
        }
    };
    let said = match session::read(&raw, &answer) {
        Ok(said) => said,
        Err(error) => {
            return Some(format!(
                "{TAG}: TAMA_HOOK_INFRASTRUCTURE: the session transcript {} cannot be read: \
                 {error}",
                path.display()
            ))
        }
    };
    if said.is_empty() {
        return None;
    }
    // A sentence an earlier answer already said is found in the transcript
    // itself, before any model is asked, so a repetition is refused whether
    // or not Brama answers.
    let told = repeated::sentences_told(&said.told, &answer);
    if !told.is_empty() {
        return Some(refusal(&format!(
            "{} (each said word for word in an earlier answer of this session)",
            told.iter()
                .map(|sentence| format!("\"{sentence}\""))
                .collect::<Vec<_>>()
                .join(", ")
        )));
    }
    let session = tama_hooks::session_record::session_id_of(payload);
    if let Some(refused) = rulings::refusal(TAG, &session, &answer) {
        return Some(refused);
    }
    if let Some(missing) = crate::objective_reviewer::stop::unattested(TAG, payload) {
        return Some(format!(
            "{TAG}: BLOCKED: the answer this turn ends with does not carry its turn-end \
             attestation:\n{missing}\nCarry the claim word for word, and only when it is true; \
             take out what the operator already answered."
        ));
    }
    match model_judgement::choose(&prompt(&said, &answer), JUDGEMENT, &[PASS, BLOCK]) {
        Ok(judged) => (judged.choice == BLOCK).then(|| refusal(&judged.reason)),
        Err(unanswered) => model_judgement::unanswered::refusal(TAG, &unanswered, None),
    }
}

pub fn run() {
    let payload = read_payload();
    if let Some(problem) = check(&payload) {
        deny(problem);
    }
}
