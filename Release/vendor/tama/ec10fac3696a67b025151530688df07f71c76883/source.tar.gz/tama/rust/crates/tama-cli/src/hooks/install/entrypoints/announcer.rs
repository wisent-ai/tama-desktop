//! Tama's grant window is answered in the session's own window; the OMP
//! adapter only tells the operator through Oko where that is
//! (`oko asks ask --from tama`). Installing a release names Tama an
//! announcer in Oko (`oko asks announcers add tama`), so that ask is
//! recorded and delivered on its own and the grant is applied as soon as the
//! window answers, never held on Oko's channels. Oko is the program every
//! hook asks (`TAMA_OKO_CLI`, else `oko` on `PATH`). A machine without Oko,
//! or an Oko that refuses, keeps the install: the adapter's announcement
//! could not run there either. The install record and stderr say which it
//! was.

use std::process::Command;

use serde_json::{json, Value};
use tama_hook_tools::assignment::rules::{oko_cli, program_installed};

/// The name the OMP adapter asks as (`--from`).
const ASKER: &str = "tama";

/// Name Tama an announcer in Oko and answer what came of it for the
/// install record: `{named: true}`, or `{named: false, cause}`, where a
/// machine without Oko also carries `oko: "absent"`, told from an Oko that
/// did not name it.
pub(in super::super) fn name_in_oko() -> Value {
    let oko = oko_cli();
    let command = format!("{oko} asks announcers add {ASKER}");
    if !program_installed(&oko) {
        let cause = format!(
            "no Oko is installed here ({oko} is not an executable file or on PATH), so the OMP \
             adapter has no Oko to announce through either"
        );
        eprintln!("tama: Tama is not named an announcer in Oko: {cause}");
        return json!({ "named": false, "command": command, "oko": "absent", "cause": cause });
    }
    let mut asked = Command::new(&oko);
    asked.args(["asks", "announcers", "add", ASKER]);
    let cause = match stado_wait::output(&mut asked) {
        Err(error) => format!("{command} could not start: {error}"),
        Ok(output) if output.status.success() => {
            return json!({ "named": true, "command": command })
        }
        Ok(output) => format!(
            "{command} ended with {}: {}",
            output.status,
            String::from_utf8_lossy(&output.stderr).trim()
        ),
    };
    eprintln!(
        "tama: the operator's grant window will wait on Oko's channels until Tama is an announcer in Oko: {cause}"
    );
    json!({ "named": false, "command": command, "cause": cause })
}
