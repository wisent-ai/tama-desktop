//! Oko's open defects as Oko last wrote them: the snapshot it keeps beside
//! its defect register (`<register>.open.json`) and writes again at every
//! write of the register, in the shape `oko defects list --open --json`
//! prints. A gate reads this file in milliseconds; starting Oko inside the
//! hook ran past the harness's handler limit, and an abandoned gate decides
//! nothing.

use serde_json::Value;

/// The extension Oko gives the snapshot in place of the register's own.
const SNAPSHOT_EXTENSION: &str = "open.json";

/// Where Oko keeps the snapshot of open defects: beside its defect register,
/// located as Oko locates it.
pub(super) fn location() -> Result<std::path::PathBuf, String> {
    Ok(
        tama_core::oko_register("OKO_DEFECT_REGISTER", "defects.json")?
            .with_extension(SNAPSHOT_EXTENSION),
    )
}

/// The snapshot read whole. A missing snapshot is an error naming the
/// command that writes it, never an empty register: Oko writes it at every
/// write of the register, so its absence says only that this machine's
/// register was last written before snapshots existed.
pub(super) fn read() -> Result<Value, String> {
    let path = location()?;
    let bytes = std::fs::read(&path).map_err(|error| match error.kind() {
        std::io::ErrorKind::NotFound => format!(
            "Oko's open-defect snapshot {} does not exist; `oko defects snapshot` writes it, \
             and every write of the defect register keeps it current",
            path.display()
        ),
        _ => format!(
            "cannot read Oko's open-defect snapshot {}: {error}",
            path.display()
        ),
    })?;
    serde_json::from_slice(&bytes).map_err(|error| {
        format!(
            "Oko's open-defect snapshot {} is not JSON: {error}",
            path.display()
        )
    })
}
