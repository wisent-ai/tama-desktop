//! Whether one ending is the same report as another, said again: the same
//! words in the same order, whatever the punctuation, case or spacing.

fn words(text: &str) -> Vec<String> {
    text.split(|c: char| !c.is_alphanumeric())
        .filter(|word| !word.is_empty())
        .map(str::to_lowercase)
        .collect()
}

/// The earlier ending this one repeats word for word, if any.
pub fn repeated<'a>(ending: &str, earlier: &'a [String]) -> Option<&'a str> {
    let said = words(ending);
    if said.is_empty() {
        return None;
    }
    earlier
        .iter()
        .find(|previous| words(previous) == said)
        .map(String::as_str)
}
