//! `tama attestation revoke --kind KIND --subject SUBJECT`: one verb that
//! withdraws an attestation whichever registry keeps it, through that
//! registry's own removal, so the record `list` showed is gone and the gate
//! that read it no longer admits what it attested.
//!
//! An agent withdraws what it attested itself (a session record, a file
//! justification) and a CUA or SSH grant, as `tama justify remove` does; a
//! grant is found by the subject `list` names and removed by the operator's
//! sentence it cites. A test approval is the operator's own act from his
//! terminal (`tama tests revoke`) and a spent build consent records an
//! answer already used, so neither is withdrawn here: each is refused by
//! name.

use std::path::Path;

use serde_json::{json, Value};
use tama_hook_tools::ports::task_attestation::subject::Subject;

use super::{home, list, Kind, Record};
use crate::justify::{cua, registry, ssh};

/// Every record of `kind` naming `subject`, or the refusal saying none does.
fn named(kind: Kind, subject: &str) -> Result<Vec<Record>, String> {
    let found: Vec<Record> = list(Some(kind))?
        .into_iter()
        .filter(|record| record.subject == subject)
        .collect();
    if found.is_empty() {
        return Err(format!(
            "no {} attestation names {subject}; `tama attestation list --kind {}` lists them",
            kind.name(),
            kind.name()
        ));
    }
    Ok(found)
}

/// Remove each grant `found` holds by the sentence it cites.
fn grants(
    found: Vec<Record>,
    remove: impl Fn(&Path, &str) -> Result<Value, String>,
    home: &Path,
) -> Result<Vec<Value>, String> {
    found
        .iter()
        .map(|record| match record.statement.as_str() {
            Some(quote) => remove(home, quote),
            None => Err(format!(
                "the {} grant for {} cites no sentence to remove it by (read from {})",
                record.kind.name(),
                record.subject,
                record.store
            )),
        })
        .collect()
}

/// Withdraw the attestation of `kind` naming `subject`; what each registry
/// answered, or the refusal naming why nothing was withdrawn.
pub(crate) fn revoke(kind: Kind, subject: &str) -> Result<Value, String> {
    let home = home()?;
    let removed = match kind {
        Kind::Session => vec![Subject::session(subject)?.remove()?],
        Kind::File => {
            named(kind, subject)?;
            let store = registry::registry_path(&home, registry::Kind::File);
            registry::ledger::file_forget(&store, subject)?;
            vec![json!({ "removed": subject, "registry": store })]
        }
        Kind::Cua => grants(named(kind, subject)?, cua::remove_document, &home)?,
        Kind::Ssh => grants(named(kind, subject)?, ssh::remove_document, &home)?,
        Kind::Test => {
            return Err(format!(
                "the approval of {subject} is the operator's own act; he withdraws it from his terminal with `tama tests revoke {subject}`"
            ))
        }
        Kind::Build => {
            return Err(format!(
                "build consent {subject} records an answer a build already used; a spent consent is not withdrawn, and the next build needs the operator's next answer"
            ))
        }
    };
    Ok(json!({ "kind": kind, "subject": subject, "removed": removed }))
}
