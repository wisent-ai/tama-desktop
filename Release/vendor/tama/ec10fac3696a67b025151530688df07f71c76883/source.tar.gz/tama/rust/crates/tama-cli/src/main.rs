//! The main `tama` binary: it resolves the checkout a command reads and runs
//! the command [`cli::help::table`] names. Dispatch, the usage summary and
//! every group's verb help read that one table.

use std::path::PathBuf;
use std::process::ExitCode;

use serde::Serialize;

use cli::help::table::{self, Entry};
use tama_core::exit;

mod attestation;
mod brama;
mod builds;
mod cli;
mod contributions;
mod copies;
mod enforcement;
mod gitcmd;
mod hooks;
mod justify;
mod omp;
mod onboarding;
mod provider_config;
mod request;
mod reviews;
mod rules;
mod worktrees;

#[derive(Serialize)]
struct McpConfig {
    #[serde(rename = "mcpServers")]
    mcp_servers: McpServers,
}

#[derive(Serialize)]
struct McpServers {
    tama: McpServerEntry,
}

#[derive(Serialize)]
struct McpServerEntry {
    command: String,
    args: Vec<String>,
}

/// The `mcp config` document, shared with `tama request mcp/config`: this
/// same program, answering as the MCP server under `tama mcp`, or why the
/// running program cannot name its own path.
fn mcp_config() -> Result<McpConfig, String> {
    let command = std::env::current_exe()
        .map_err(|error| format!("the running tama cannot name its own path: {error}"))?;
    Ok(McpConfig {
        mcp_servers: McpServers {
            tama: McpServerEntry {
                command: command.display().to_string(),
                args: vec!["mcp".to_string()],
            },
        },
    })
}

/// An exit status as the operating system reads it: the low byte.
fn exit_code(code: i32) -> ExitCode {
    let [low, ..] = code.to_le_bytes();
    ExitCode::from(low)
}

/// The verb a group command names and the arguments after it:
/// `tama violations find --repo x` is (`find`, `--repo x`).
fn group_verb(argv: &[String]) -> (Option<&str>, &[String]) {
    match argv.split_first().and_then(|(_, rest)| rest.split_first()) {
        Some((verb, arguments)) => (Some(verb.as_str()), arguments),
        None => (None, &[]),
    }
}

/// Rust starts every program with `SIGPIPE` ignored, so a command whose reader
/// closes early - `tama enforcement status | head -2` - fails its next write
/// and panics inside `println!`, printing a Rust panic and a backtrace note
/// over the operator's terminal. Restoring the default disposition makes this
/// end the way every other Unix tool ends a closed pipe: quietly.
///
/// Only the operator's commands take it. The hook engine, the hooks and the
/// MCP server write payloads into child processes that may exit without
/// reading them; under the default disposition that write kills the engine
/// with no output, and the event it was deciding is left undecided. They were
/// separate programs with Rust's disposition, so they run before this.
fn end_quietly_when_the_reader_closes() {
    // SAFETY: setting a signal's disposition to its default touches no memory.
    unsafe { libc::signal(libc::SIGPIPE, libc::SIG_DFL) };
}

/// The marker a Tama checkout carries at its root.
const CHECKOUT_MARKER: &str = "shared-hooks/registry.json";

/// The checkout the command is being run in, or why the working directory
/// cannot be examined. When `TAMA_ROOT` is set it names the checkout, and
/// the working directory does not decide.
fn checkout_root_from_cwd() -> Result<Option<PathBuf>, String> {
    if std::env::var_os("TAMA_ROOT").is_some_and(|value| !value.is_empty()) {
        return Ok(None);
    }
    let cwd = std::env::current_dir()
        .map_err(|error| format!("the working directory cannot be read: {error}"))?;
    for directory in cwd.ancestors() {
        let marker = directory.join(CHECKOUT_MARKER);
        if tama_core::presence::present(&marker).map_err(|error| error.to_string())? {
            return Ok(Some(directory.to_path_buf()));
        }
    }
    Ok(None)
}

/// The checkout a command reads, in the order the documentation gives: an
/// explicit `--root`; the checkout the working directory is in; then
/// [`tama_core::checkout`]: `TAMA_ROOT`, asked before the installed
/// release's record because a `TAMA_ROOT=<fixture>` run must judge the
/// fixture, the checkout `tama hooks release` recorded installing from, and
/// the tree this program was built in while it still exists. The installed
/// CLI is built in the release's export tree, which the release deletes, so
/// with none of them the command is refused naming each.
fn checkout_root(argv: &[String]) -> Result<PathBuf, String> {
    if let Some(root) = cli::args::option_value(argv, "--root") {
        return Ok(PathBuf::from(root));
    }
    if let Some(root) = checkout_root_from_cwd()? {
        return Ok(root);
    }
    tama_core::checkout()
}

fn main() -> ExitCode {
    // The words after the program's own name.
    let words: Vec<String> = std::env::args().collect();
    let argv: &[String] = match words.split_first() {
        Some((_, argv)) => argv,
        None => &[],
    };
    // Per-user Tama state lives under HOME: without it, refuse before anything reads.
    if std::env::var_os("HOME").is_none_or(|home| home.is_empty()) {
        eprintln!("tama: HOME is not set, so per-user Tama state cannot be located; set HOME to your home directory and run the command again");
        return exit_code(exit::FAILURE);
    }
    let Some((name, rest)) = argv.split_first() else {
        cli::help::help();
        return exit_code(exit::SUCCESS);
    };
    let command = table::find(name);
    if let Some(Entry::Program(run)) = command.map(|command| &command.entry) {
        return run(rest);
    }
    end_quietly_when_the_reader_closes();
    let root = match checkout_root(argv) {
        Ok(root) => root,
        Err(cause) => {
            eprintln!("tama: the checkout to read cannot be found: {cause}");
            return exit_code(exit::FAILURE);
        }
    };
    cli::help::answer_if_asked(argv);
    if matches!(name.as_str(), "help" | "--help" | "-h") {
        cli::help::help();
        return exit_code(exit::SUCCESS);
    }
    match command.map(|command| &command.entry) {
        Some(Entry::Command(run)) => run(argv, &root),
        Some(Entry::Program(run)) => run(rest),
        None => {
            cli::help::usage();
            exit_code(exit::USAGE)
        }
    }
}
