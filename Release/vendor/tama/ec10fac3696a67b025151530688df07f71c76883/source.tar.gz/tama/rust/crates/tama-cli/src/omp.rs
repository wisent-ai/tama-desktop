//! Which OMP program Tama runs: the one the hook install registers its
//! adapter with, and the one a harsh-review run starts its reviewer in.

use std::path::Path;

/// The OMP program: `TAMA_OMP` when set, else `omp` on `PATH` or in
/// `~/.local/bin`; `None` on a machine without OMP. A `TAMA_OMP` that is set
/// but empty or not text is the error naming it: read as unset, another OMP
/// than the one the operator named would be run.
pub(crate) fn program(home: &Path) -> Result<Option<String>, String> {
    if let Some(configured) = std::env::var_os("TAMA_OMP") {
        let configured = configured.into_string().map_err(|value| {
            format!(
                "TAMA_OMP is set to {value:?}, which is not text a program path can be read from"
            )
        })?;
        if configured.is_empty() {
            return Err(
                "TAMA_OMP is set to nothing; name the omp program there or unset it".to_string(),
            );
        }
        return Ok(Some(configured));
    }
    // PATH as the operating system holds it: read as a string, a PATH that is
    // not UTF-8 would be taken for an empty one and OMP never found on it.
    let on_path = std::env::var_os("PATH")
        .iter()
        .flat_map(std::env::split_paths)
        .map(|d| d.join("omp"))
        .find(|p| p.is_file());
    Ok(on_path
        .or_else(|| Some(home.join(".local/bin/omp")).filter(|p| p.is_file()))
        .map(|p| p.display().to_string()))
}
