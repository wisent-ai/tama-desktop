//! The Brama adapter this host's resolver publishes, read from the state
//! Stado writes for programs on its host.

use std::fs::{File, TryLockError};
use std::io::{ErrorKind, Read};
use std::path::{Path, PathBuf};

use super::super::credentials::{adapter_consumer, home_dir};

/// The state file this host's `stado serve --resolver` publishes beside
/// its listeners: `STADO_RESOLVER_STATE_FILE` when set, as Stado itself
/// honours it, else `~/.stado/resolver-state.json`.
pub(in crate::brama) fn published_state_path() -> PathBuf {
    match std::env::var_os("STADO_RESOLVER_STATE_FILE").filter(|path| !path.is_empty()) {
        Some(path) => PathBuf::from(path),
        None => home_dir().join(".stado/resolver-state.json"),
    }
}

/// The Brama adapter this host's resolver publishes as bound and listening
/// for Tama's consumer, read from the state Stado writes for programs on
/// this host, so a route the resolver already serves costs no Stado child.
/// A state file that is absent, unreadable or lists no listening adapter
/// answers `None` with its cause on stderr; the search then asks Stado.
pub(super) fn published_adapter() -> Option<String> {
    let path = published_state_path();
    let text = match std::fs::read_to_string(&path) {
        Ok(text) => text,
        Err(error) if error.kind() == ErrorKind::NotFound => return None,
        Err(error) => {
            eprintln!(
                "tama: cannot read this host's published resolver state {}: {error}",
                path.display()
            );
            return None;
        }
    };
    let state: serde_json::Value = match serde_json::from_str(&text) {
        Ok(state) => state,
        Err(error) => {
            eprintln!(
                "tama: this host's published resolver state {} is not JSON: {error}",
                path.display()
            );
            return None;
        }
    };
    // The file outlives the resolver that wrote it: an adapter a process
    // that has exited published as listening is a port nobody holds.
    let Some(publisher) = state.get("pid").and_then(serde_json::Value::as_u64) else {
        eprintln!(
            "tama: this host's published resolver state {} names no publishing process",
            path.display()
        );
        return None;
    };
    match publisher_holds_lock(&path, publisher) {
        Ok(true) => {}
        Ok(false) => {
            eprintln!(
                "tama: the resolver that published this host's state {} (pid {publisher}) is not \
                 running; the search goes on to Stado",
                path.display()
            );
            return None;
        }
        Err(cause) => {
            eprintln!(
                "tama: whether the resolver that published {} runs cannot be read: {cause}; the \
                 search goes on to Stado",
                path.display()
            );
            return None;
        }
    }
    // Stado publishes `listening` for the process (it holds its listeners
    // bound) and, per adapter, `unserved` with the reason it does not serve
    // one; an adapter with no such reason is bound at its `bind`.
    match state.get("listening") {
        Some(serde_json::Value::Bool(true)) => {}
        Some(other) => {
            eprintln!(
                "tama: the resolver that published {} does not declare its listeners bound \
                 (listening: {other}); the search goes on to Stado",
                path.display()
            );
            return None;
        }
        None => {
            eprintln!(
                "tama: the resolver that published {} names no listening state; the search \
                 goes on to Stado",
                path.display()
            );
            return None;
        }
    }
    let consumer = match adapter_consumer() {
        Ok(consumer) => consumer,
        Err(error) => {
            eprintln!(
                "tama: the adapter consumer to look for in {} cannot be read: {error}; the \
                 search goes on to Stado",
                path.display()
            );
            return None;
        }
    };
    state
        .get("adapters")
        .and_then(serde_json::Value::as_array)
        .into_iter()
        .flatten()
        .find(|adapter| {
            adapter.get("service").and_then(serde_json::Value::as_str) == Some("brama")
                && adapter.get("consumer").and_then(serde_json::Value::as_str)
                    == Some(consumer.as_str())
                && adapter.get("unserved").is_none()
        })
        .and_then(|adapter| adapter.get("bind").and_then(serde_json::Value::as_str))
        .filter(|bind| !bind.trim().is_empty())
        .map(|bind| format!("http://{}", bind.trim()))
}

/// Whether the resolver whose pid is `publisher` holds the lifetime lock
/// Stado keeps beside `state` (`<state>.lock`) for as long as the resolver
/// runs. A pid alone outlives its process: the system hands the number to
/// another one, and asking whether it runs answered yes about a resolver
/// that was gone. A lock this reader can take means no resolver runs; a held
/// one counts only when the pid its holder recorded is `publisher`.
fn publisher_holds_lock(state: &Path, publisher: u64) -> Result<bool, String> {
    let path = state.with_extension("lock");
    let mut file = match File::open(&path) {
        Ok(file) => file,
        Err(error) if error.kind() == ErrorKind::NotFound => return Ok(false),
        Err(error) => return Err(format!("opening {}: {error}", path.display())),
    };
    match file.try_lock_shared() {
        Ok(()) => Ok(false),
        Err(TryLockError::WouldBlock) => {
            let mut holder = String::new();
            file.read_to_string(&mut holder).map_err(|error| {
                format!("reading the holder {} records: {error}", path.display())
            })?;
            Ok(holder.trim() == publisher.to_string())
        }
        Err(TryLockError::Error(error)) => Err(format!("locking {}: {error}", path.display())),
    }
}
