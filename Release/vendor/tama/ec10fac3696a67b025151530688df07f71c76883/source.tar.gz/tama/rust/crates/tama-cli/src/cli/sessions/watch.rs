//! Kernel directory and process notifications, armed before a control request.
use std::path::Path;

#[cfg(target_os = "macos")]
pub(super) struct DirectoryWatch {
    queue: std::os::fd::OwnedFd,
    _directory: std::os::fd::OwnedFd,
}
#[cfg(target_os = "macos")]
impl DirectoryWatch {
    pub(super) fn new(root: &Path, pid: u64) -> Result<Self, String> {
        use std::os::{
            fd::{AsRawFd, FromRawFd},
            unix::ffi::OsStrExt,
        };
        let path =
            std::ffi::CString::new(root.as_os_str().as_bytes()).map_err(|e| e.to_string())?;
        // SAFETY: each checked descriptor transfers to OwnedFd immediately;
        // all paths close it. The change slice lives throughout kevent.
        unsafe {
            let fd = libc::kqueue();
            if fd.is_negative() {
                return Err(std::io::Error::last_os_error().to_string());
            }
            let queue = std::os::fd::OwnedFd::from_raw_fd(fd);
            let fd = libc::open(path.as_ptr(), libc::O_EVTONLY | libc::O_CLOEXEC);
            if fd.is_negative() {
                return Err(std::io::Error::last_os_error().to_string());
            }
            let directory = std::os::fd::OwnedFd::from_raw_fd(fd);
            let mut directory_event: libc::kevent = std::mem::zeroed();
            directory_event.ident = directory.as_raw_fd() as usize;
            directory_event.filter = libc::EVFILT_VNODE;
            directory_event.flags = libc::EV_ADD | libc::EV_CLEAR;
            directory_event.fflags = libc::NOTE_WRITE | libc::NOTE_DELETE | libc::NOTE_RENAME;
            let mut process_event: libc::kevent = std::mem::zeroed();
            process_event.ident = pid as usize;
            process_event.filter = libc::EVFILT_PROC;
            process_event.flags = libc::EV_ADD | libc::EV_CLEAR;
            process_event.fflags = libc::NOTE_EXIT;
            let changes = [directory_event, process_event];
            let received = libc::kevent(
                queue.as_raw_fd(),
                changes.as_ptr(),
                changes.len() as i32,
                std::ptr::null_mut(),
                Default::default(),
                std::ptr::null(),
            );
            if received.is_negative() {
                return Err(std::io::Error::last_os_error().to_string());
            }
            Ok(Self {
                queue,
                _directory: directory,
            })
        }
    }

    pub(super) fn next(&mut self) -> Result<(), String> {
        use std::os::fd::AsRawFd;
        loop {
            // SAFETY: event is writable and self owns the queue descriptor.
            let mut event: libc::kevent = unsafe { std::mem::zeroed() };
            let events = std::slice::from_mut(&mut event);
            let count = unsafe {
                libc::kevent(
                    self.queue.as_raw_fd(),
                    std::ptr::null(),
                    Default::default(),
                    events.as_mut_ptr(),
                    events.len() as i32,
                    std::ptr::null(),
                )
            };
            if !count.is_negative() {
                if event.flags & libc::EV_ERROR == libc::EV_ERROR {
                    return Err(std::io::Error::from_raw_os_error(event.data as i32).to_string());
                }
                if event.filter == libc::EVFILT_VNODE
                    && (event.fflags & libc::NOTE_DELETE == libc::NOTE_DELETE
                        || event.fflags & libc::NOTE_RENAME == libc::NOTE_RENAME)
                {
                    return Err("session control directory was removed or replaced".into());
                }
                return Ok(());
            }
            let error = std::io::Error::last_os_error();
            if error.kind() != std::io::ErrorKind::Interrupted {
                return Err(error.to_string());
            }
        }
    }
}

#[cfg(not(target_os = "macos"))]
pub(super) struct DirectoryWatch;
#[cfg(not(target_os = "macos"))]
impl DirectoryWatch {
    pub(super) fn new(_: &Path, _: u64) -> Result<Self, String> {
        Err("live OMP adapter reload requires the macOS session-control transport".into())
    }
    pub(super) fn next(&mut self) -> Result<(), String> {
        Err("live OMP adapter reload requires the macOS session-control transport".into())
    }
}
