//! Process exit statuses every Tama program answers with, declared once, so
//! no command spells a status as a number and no crate keeps its own copy.

/// A command that did what it was asked exits with the status the C
/// standard declares `EXIT_SUCCESS`:
/// https://pubs.opengroup.org/onlinepubs/9799919799/functions/exit.html
pub const SUCCESS: i32 = 0;
/// A command that could not do it exits with the status the C library on
/// every platform Tama runs on declares `EXIT_FAILURE`:
/// https://pubs.opengroup.org/onlinepubs/9799919799/basedefs/stdlib.h.html
pub const FAILURE: i32 = 1;
/// A command called wrongly — a missing, unknown or malformed argument —
/// exits with the usage status the command-line convention gives it, the one
/// clap's own usage errors exit with:
/// https://docs.rs/clap/latest/clap/error/struct.Error.html#method.exit
pub const USAGE: i32 = 2;

/// [`USAGE`] as the `ExitCode` a `main` that returns one answers with.
pub fn usage() -> std::process::ExitCode {
    std::process::ExitCode::from(USAGE as u8)
}
