//! Decision half of `tama hook block-unauthorized-ssh` (hook id
//! `block-unauthorized-ssh`): block every SSH transport without a
//! transcript-backed, exact registry grant.
//!
//! `quote_authorizes_targets`, `command_targets`, `entry_matches` and
//! `quote_is_in_current_session` are the acceptance predicate: a grant counts
//! only when the operator's consent is recorded as the Tama session capability
//! `{ "tool": "ssh" }`, the user's own words name the target and are really in
//! this session's transcript, and a `ssh_justification.json` entry covers the
//! exact target, operation and path or command. They are public so a later
//! guard can reuse this one implementation instead of restating the policy.
//!
//! The two halves this module orchestrates are
//! [`crate::ports::block_unauthorized_ssh_detect`] (patterns and command
//! shape) and [`crate::ports::block_unauthorized_ssh_targets`] (target
//! extraction); both are re-exported here, so this module is the whole
//! port's surface.

mod command;
mod grants;

pub use grants::{authorized, entry_matches};
use std::collections::BTreeSet;

use serde_json::Value;

use crate::ports::block_unauthorized_ssh_detect as detect;
use crate::ports::block_unauthorized_ssh_targets as targets;
use crate::ports::shell_text;
use crate::ports::tool_vocabulary::{paths_in, Call};
use crate::ports::transport_common as common;

pub use crate::ports::block_unauthorized_ssh_detect::{
    command_operation, command_text, contains_ssh_command,
};
pub use crate::ports::block_unauthorized_ssh_targets::{canonical_target, targets_from_urls};
pub use crate::ports::transport_common::quote_is_in_current_session;

/// `SSH_OPTIONS_WITH_VALUE`: the scan steps over the option and its argument.
const SSH_OPTIONS_WITH_VALUE: &[&str] = &[
    "-b", "-c", "-D", "-E", "-e", "-F", "-I", "-i", "-J", "-L", "-l", "-m", "-O", "-o", "-p", "-Q",
    "-R", "-S", "-W", "-w",
];

/// The operations an SSH grant names, spelled by `OPERATION_NAMES`.
#[derive(serde::Deserialize, Clone, Copy, PartialEq)]
#[serde(rename_all = "lowercase")]
pub(crate) enum Operation {
    Read,
    Write,
    Exec,
    Transfer,
    Tunnel,
    Git,
}

/// Each operation by the name a payload or grant spells it, the grant
/// schema's own lowercase values.
const OPERATION_NAMES: &[(&str, Operation)] = &[
    ("read", Operation::Read),
    ("write", Operation::Write),
    ("exec", Operation::Exec),
    ("transfer", Operation::Transfer),
    ("tunnel", Operation::Tunnel),
    ("git", Operation::Git),
];

impl Operation {
    /// The operation a payload or grant spells `name`, if it is one.
    pub(crate) fn named(name: &str) -> Option<Self> {
        OPERATION_NAMES
            .iter()
            .find(|(spelled, _)| *spelled == name)
            .map(|(_, operation)| *operation)
    }

    /// Whether a grant for this operation names the paths it covers.
    pub(crate) fn names_paths(self) -> bool {
        matches!(self, Operation::Read | Operation::Write)
    }
}
const READ_OP: &str = "read";
const WRITE_OP: &str = "write";
const SSH_TOOL: &str = "ssh";
const SESSION_LIFETIME: &str = "current OMP session";
const SCHEMA: &str = "ai.wisent.tama.ssh-justification.v1";
/// The variable that moves the registry this gate reads; every writer and
/// reader of the registry honours it, so they read the same file.
pub const JUSTIFICATION_ENV: &str = "TAMA_SSH_JUSTIFICATION";
const JUSTIFICATION_FILE: &str = "ssh_justification.json";
const BANNER: &str = "BLOCKED: unauthorized SSH: ";

/// One SSH-carrying tool call, reduced to what a grant has to cover.
#[derive(Debug, Clone)]
pub struct SshRequest {
    pub operation: String,
    pub targets: Vec<String>,
    pub paths: Vec<String>,
    pub command: Option<String>,
}

/// The SSH grant registry under `home`, or the file `JUSTIFICATION_ENV`
/// names: what this gate reads and `tama justify` writes, lists and revokes.
pub fn justification_path_under(home: &std::path::Path) -> std::path::PathBuf {
    common::env_path(
        JUSTIFICATION_ENV,
        common::hook_registry(home, JUSTIFICATION_FILE),
    )
}

fn justification_path() -> std::path::PathBuf {
    justification_path_under(&common::home())
}

pub use command::command_targets;

/// `ssh_request`: the SSH request a payload carries, or `None` when the call
/// is not an SSH transport at all.
pub fn ssh_request(payload: &Value) -> Option<SshRequest> {
    let call = Call::of(payload);
    let name = call.kind().unwrap_or_default();
    let mut urls: Vec<String> = Vec::new();
    if let Some(input) = call.input() {
        for path in paths_in(input) {
            urls.extend(targets::ssh_urls(path));
        }
    }
    if !urls.is_empty() {
        let operation = if call.is_write() { WRITE_OP } else { READ_OP };
        let paths: BTreeSet<String> = urls.iter().cloned().collect();
        return Some(SshRequest {
            operation: operation.to_string(),
            targets: targets::targets_from_urls(&urls).into_iter().collect(),
            paths: paths.into_iter().collect(),
            command: None,
        });
    }
    let command = command_text(&call);
    let direct_tool = detect::SSH_TOOL_RE.is_match(&name);
    if !direct_tool && !call.runs() {
        return None;
    }
    let actionable = shell_text::effective_for_tool(&name, &command);
    if !direct_tool && !contains_ssh_command(&actionable) {
        return None;
    }
    let operation = match call
        .operation()
        .filter(|named| Operation::named(named).is_some())
    {
        Some(named) => named,
        None => {
            if command.is_empty() {
                detect::EXEC_OP.to_string()
            } else {
                command_operation(&actionable)
            }
        }
    };
    Some(SshRequest {
        operation,
        targets: command_targets(&command).into_iter().collect(),
        paths: Vec::new(),
        command: if command.is_empty() {
            None
        } else {
            Some(command)
        },
    })
}

/// `quote_authorizes_targets`: the user's own words name every target the
/// call would reach. Consent is not read from the words: it is the `ssh`
/// session capability ([`grants::authorized`]).
pub fn quote_authorizes_targets(quote: &str, requested: &[String]) -> bool {
    let lowered = quote.to_lowercase();
    for target in requested {
        let after_user = match target.rsplit_once('@') {
            Some((_, host)) => host,
            None => target.as_str(),
        };
        let host = match after_user.split_once(':') {
            Some((head, _)) => head,
            None => after_user,
        };
        if !lowered.contains(&target.to_lowercase()) && !lowered.contains(host) {
            return false;
        }
    }
    !requested.is_empty()
}

/// `evaluate_payload`: the deny banner when the call is refused, `None` when
/// it passes. The caller writes the banner to stderr and exits 2.
pub fn evaluate(payload: &Value) -> Option<String> {
    let request = ssh_request(payload)?;
    if request.targets.is_empty() {
        return Some(format!(
            "{BANNER}the operation uses SSH but its exact target could not be determined"
        ));
    }
    if !authorized(payload, &request) {
        return Some(format!(
            "{BANNER}an exact current-session user authorization and matching \
             ssh_justification.json entry are both required (this call reaches {}, \
             operation {})",
            request.targets.join(", "),
            request.operation
        ));
    }
    None
}
