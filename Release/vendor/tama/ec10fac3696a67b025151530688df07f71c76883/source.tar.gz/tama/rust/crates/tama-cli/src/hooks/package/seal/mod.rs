//! `tama hooks seal`: turn a staged hook release into the deployable state a
//! machine installs. The registry names its checkout with `$HOME` instead of
//! the build's job directory, every hook source outside the managed hook
//! directories is copied in with a manifest saying where, and `release.json`
//! records the tree's digest, which is the release's identity.

use std::path::{Path, PathBuf};

use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use tama_hook_tools::ports::python_stdlib::{expanduser, expandvars};
mod deployable;
mod source;

use deployable::{declared_checkout, state_the_deployable_root};
use source::release_source_identity;

use super::identity::verify_source_identity;
use super::{copy_tree, load_object, write_json};

pub(crate) const RELEASE_SCHEMA: &str = "ai.wisent.tama.hook-release.v1";
pub(crate) const EXTERNAL_SCHEMA: &str = "ai.wisent.tama.external-hook-sources.v1";
const MODE_BITS: u32 = (libc::S_IRWXU | libc::S_IRWXG | libc::S_IRWXO) as u32;

/// Every regular file under `root` except `release.json` and `bin/`, in path
/// order: `bin/` is signed after the seal, and its code signature vouches for it.
pub(crate) fn tree_digest(root: &Path) -> Result<String, String> {
    use std::os::unix::fs::PermissionsExt;
    let mut files: Vec<PathBuf> = Vec::new();
    let mut pending = vec![root.to_path_buf()];
    while let Some(directory) = pending.pop() {
        let entries = std::fs::read_dir(&directory)
            .map_err(|error| format!("cannot list {}: {error}", directory.display()))?;
        for entry in entries {
            let entry =
                entry.map_err(|error| format!("cannot list {}: {error}", directory.display()))?;
            let path = entry.path();
            let relative = path
                .strip_prefix(root)
                .map_err(|error| {
                    format!(
                        "{} is not under {}: {error}",
                        path.display(),
                        root.display()
                    )
                })?
                .to_path_buf();
            let is_link = entry
                .file_type()
                .map_err(|error| format!("cannot tell what {} is: {error}", path.display()))?
                .is_symlink();
            if path.is_dir() && !is_link {
                pending.push(path);
            } else if path.is_file()
                && relative != Path::new("release.json")
                && relative.components().next()
                    != Some(std::path::Component::Normal("bin".as_ref()))
            {
                files.push(relative);
            }
        }
    }
    files.sort();
    let mut digest = Sha256::new();
    for relative in files {
        let path = root.join(&relative);
        let name = relative.to_string_lossy();
        let bytes = std::fs::read(&path)
            .map_err(|error| format!("cannot read {}: {error}", path.display()))?;
        // The mode is part of the digest, so a file whose mode cannot be read
        // is refused rather than sealed with a mode it does not have.
        let mode = std::fs::metadata(&path)
            .map_err(|error| format!("cannot read the mode of {}: {error}", path.display()))?
            .permissions()
            .mode()
            & MODE_BITS;
        digest.update((name.len() as u64).to_be_bytes());
        digest.update(name.as_bytes());
        digest.update(mode.to_be_bytes());
        digest.update((bytes.len() as u64).to_be_bytes());
        digest.update(&bytes);
    }
    Ok(format!("{:x}", digest.finalize()))
}

/// Copy every hook source that lives outside the managed hook directories
/// into `external-hooks/`, with `external-sources.json` saying where.
fn package_external_sources(
    root: &Path,
    registry: &Value,
    source_root: &Path,
) -> Result<(), String> {
    // The hook home is read from the Codex adapter's path; a registry without
    // it is refused, since read as the empty path the hooks already under the
    // managed directories of that home would be copied again as external
    // sources.
    let Some(codex_path) = registry["adapters"]["codex"]["path"].as_str() else {
        return Err(
            "Hook registry names no adapters.codex.path, so the hook home is unknown".to_string(),
        );
    };
    let codex = PathBuf::from(expanduser(&expandvars(codex_path)));
    let Some(source_home) = codex.parent().and_then(Path::parent).map(Path::to_path_buf) else {
        return Err(format!(
            "adapters.codex.path {codex_path} has no home two directories above it"
        ));
    };
    let managed = [
        source_root.join("shared-hooks"),
        source_root.join("claude-hooks"),
        source_root.join("codex-hooks"),
        source_home.join(".shared-hooks"),
        source_home.join(".claude/hooks"),
        source_home.join(".codex/hooks"),
    ];
    let declared = declared_checkout()?;
    let declared = declared
        .as_deref()
        .map(|declared| declared.trim_end_matches('/'))
        .filter(|declared| !declared.is_empty());
    let mut mappings = std::collections::BTreeMap::new();
    for hook in registry["catalog"]["agentHooks"]
        .as_array()
        .into_iter()
        .flatten()
    {
        let Some(raw) = hook["source"].as_str().filter(|raw| !raw.is_empty()) else {
            continue;
        };
        let read_from =
            match declared.and_then(|declared| raw.strip_prefix(&format!("{declared}/"))) {
                Some(rest) => format!("{}/{rest}", source_root.display()),
                None => raw.to_string(),
            };
        let mut source = PathBuf::from(expanduser(&expandvars(&read_from)));
        if !source.is_absolute() {
            source = source_root.join(source);
        }
        if managed.iter().any(|root| source.starts_with(root)) {
            continue;
        }
        if !source.is_file() {
            return Err(format!(
                "External hook source is missing: {}\n  declared as: {raw}\n  resolved against source root: {}\n\
                 Pass --source-root <checkout> if that is the wrong checkout, or run \
                 tama-reconcile-registry-sources on the registry if the source moved.",
                source.display(),
                source_root.display()
            ));
        }
        let parent = source
            .parent()
            .ok_or_else(|| format!("external hook source {} has no folder", source.display()))?;
        let is_script_hook = parent.file_name() == Some("hooks".as_ref())
            && parent.parent().and_then(Path::file_name) == Some("scripts".as_ref());
        let unplaced = |what: &str| {
            format!(
                "external hook source {} (declared as {raw}) has no {what}, so the release has no place for it",
                source.display()
            )
        };
        if is_script_hook {
            let external = parent.parent().ok_or_else(|| unplaced("scripts folder"))?;
            let owner = external
                .parent()
                .and_then(Path::file_name)
                .ok_or_else(|| unplaced("owner folder above its scripts"))?;
            let destination = root.join("external-hooks").join(owner).join("scripts");
            for name in ["hooks", "lib"] {
                if external.join(name).is_dir() {
                    copy_tree(&external.join(name), &destination.join(name))?;
                }
            }
            mappings.insert(
                external.display().to_string(),
                release_path(root, &destination)?,
            );
        } else {
            let id = hook["id"]
                .as_str()
                .filter(|id| !id.is_empty())
                .ok_or_else(|| unplaced("hook id in the registry"))?;
            let destination = root
                .join("external-hooks")
                .join(id)
                .join(source.file_name().ok_or_else(|| unplaced("file name"))?);
            copy_tree(&source, &destination)?;
            mappings.insert(raw.to_string(), release_path(root, &destination)?);
        }
    }
    let mappings: Vec<Value> = mappings
        .into_iter()
        .map(|(source, release)| json!({ "sourcePrefix": source, "releasePath": release }))
        .collect();
    write_json(
        &root.join("external-sources.json"),
        &json!({ "schema": EXTERNAL_SCHEMA, "mappings": mappings }),
    )
}

/// Where `destination` stands inside the release at `root`.
fn release_path(root: &Path, destination: &Path) -> Result<String, String> {
    destination
        .strip_prefix(root)
        .map(|relative| relative.display().to_string())
        .map_err(|error| {
            format!(
                "{} is not inside the release {}: {error}",
                destination.display(),
                root.display()
            )
        })
}

/// Seal the staged release at `root`, made from `source_root`; returns its id.
pub(super) fn seal(root: &Path, source_root: &Path) -> Result<String, String> {
    let identity = release_source_identity(root, source_root)?;
    let package = load_object(&root.join("package.json"))?;
    let registry = state_the_deployable_root(root, source_root)?;
    package_external_sources(root, &registry, source_root)?;
    verify_source_identity(source_root, &identity)?;
    let catalog = &registry["catalog"];
    let release_id = tree_digest(root)?;
    // A release is named by what it holds: a package or catalogue without a
    // version is refused here instead of being sealed as "unknown".
    let stated = |document: &Value, key: &str, file: &str| {
        document
            .get(key)
            .filter(|value| !value.is_null())
            .cloned()
            .ok_or_else(|| format!("{file} in {} states no {key}", root.display()))
    };
    let release = json!({
        "schema": RELEASE_SCHEMA,
        "releaseId": release_id,
        "packageVersion": stated(&package, "version", "package.json")?,
        "catalogVersion": stated(catalog, "version", "the registry's catalog")?,
        "catalogUpdatedAt": stated(catalog, "updatedAt", "the registry's catalog")?,
        "sourceDirty": identity["dirty"],
        "sourceRevision": identity["revision"],
        "sealedAt": tama_core::clock::iso_now(),
    });
    write_json(&root.join("release.json"), &release)?;
    Ok(release_id)
}
