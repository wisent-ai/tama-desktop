//! Inspect native hook configuration without claiming live execution.
use super::{Adapter, Shape};
use serde_json::Value;
use std::{collections::BTreeMap, fs, path::Path};

pub fn read(adapter: &Adapter, path: &Path) -> Result<Value, String> {
    let text = fs::read_to_string(path).map_err(|error| {
        format!(
            "cannot read {} hook configuration {}: {error}",
            adapter.id,
            path.display()
        )
    })?;
    let config: Value = match adapter.shape {
        Shape::KimiToml => toml::from_str(&text).map_err(|error| {
            format!(
                "cannot parse {} hook configuration {} as TOML: {error}",
                adapter.id,
                path.display()
            )
        }),
        _ if adapter.jsonc => jsonc_parser::parse_to_serde_value(&text, &Default::default())
            .map_err(|error| {
                format!(
                    "cannot parse {} hook configuration {} as JSONC: {error}",
                    adapter.id,
                    path.display()
                )
            }),
        _ => serde_json::from_str(&text).map_err(|error| {
            format!(
                "cannot parse {} hook configuration {} as JSON: {error}",
                adapter.id,
                path.display()
            )
        }),
    }?;
    if !config.is_object() {
        return Err(format!(
            "{} hook configuration {} must be an object, observed {config}",
            adapter.id,
            path.display()
        ));
    }
    Ok(config)
}

fn string<'a>(entry: &'a Value, field: &str) -> Result<&'a str, String> {
    entry
        .get(field)
        .and_then(Value::as_str)
        .ok_or_else(|| format!("hook entry requires string {field}, observed {entry}"))
}

fn matcher(entry: &Value) -> Result<Option<&str>, String> {
    match entry.get("matcher") {
        None => Ok(None),
        Some(Value::String(value)) => Ok(Some(value)),
        Some(value) => Err(format!("hook matcher must be a string, observed {value}")),
    }
}

fn shell_quote(value: &str) -> String {
    format!("'{}'", value.replace('\'', "'\\''"))
}

pub fn index(adapter: &Adapter, config: &Value) -> Result<BTreeMap<String, Vec<String>>, String> {
    let mut found = BTreeMap::new();
    let targets: Vec<_> = adapter
        .events
        .iter()
        .map(|(event, target)| {
            let suffix = format!(" {} {}", shell_quote(event), shell_quote(&adapter.id));
            (event, target, suffix)
        })
        .collect();
    let mut entry = |native: &str, selector: Option<&str>, command: &str| {
        for (event, target, suffix) in &targets {
            if native == target.key
                && selector == target.matcher.as_deref()
                && command.ends_with(suffix.as_str())
            {
                found
                    .entry((*event).clone())
                    .or_insert_with(Vec::new)
                    .push(command.to_string());
            }
        }
    };
    if adapter.shape == Shape::KimiToml {
        let Some(hooks) = config.get("hooks") else {
            return Ok(found);
        };
        let hooks = hooks
            .as_array()
            .ok_or("hooks must be an array of TOML tables")?;
        for hook in hooks {
            entry(
                string(hook, "event")?,
                matcher(hook)?,
                string(hook, "command")?,
            );
        }
        return Ok(found);
    }
    let hooks = match adapter.shape {
        Shape::EventMap => config,
        _ => match config.get("hooks") {
            Some(hooks) => hooks,
            None => return Ok(found),
        },
    };
    for (event, hooks) in hooks
        .as_object()
        .ok_or("hooks must be an event-keyed object")?
    {
        for hook in hooks
            .as_array()
            .ok_or_else(|| format!("hooks.{event} must be an array"))?
        {
            let selector = matcher(hook)?;
            match adapter.shape {
                Shape::SettingsHooks | Shape::EventMap => {
                    for command in hook
                        .get("hooks")
                        .and_then(Value::as_array)
                        .ok_or_else(|| format!("hooks.{event} group requires a hooks array"))?
                    {
                        if command
                            .get("type")
                            .and_then(Value::as_str)
                            .is_some_and(|kind| kind != "command")
                        {
                            continue;
                        }
                        entry(event, selector, string(command, "command")?);
                    }
                }
                Shape::CopilotFlat => {
                    if let Some(command) = hook.get("bash").and_then(Value::as_str) {
                        entry(event, selector, command);
                    }
                }
                Shape::CursorFlat | Shape::WindsurfFlat => {
                    entry(event, selector, string(hook, "command")?)
                }
                Shape::KimiToml => unreachable!("TOML handled before JSON shapes"),
            }
        }
    }
    Ok(found)
}
