//! The one clock every Tama crate reads, and the one form its records keep
//! a time in: RFC 3339 in UTC with milliseconds (`2026-10-15T06:44:52.663Z`),
//! the form JavaScript's `toISOString` writes, so records the earlier
//! JavaScript hooks wrote read the same. The calendar is chrono's; each crate
//! once carried its own port of the civil-date arithmetic, and a clock set
//! before the epoch read as the epoch itself or as a parse failure read as no
//! date.

use chrono::{DateTime, NaiveDate, SecondsFormat, TimeDelta, Utc};

/// A calendar date as RFC 3339 writes one (`full-date`, `YYYY-MM-DD`).
const FULL_DATE: &str = "%Y-%m-%d";

/// Now, in UTC.
pub fn now() -> DateTime<Utc> {
    Utc::now()
}

/// `at` as every Tama record writes a time.
pub fn iso(at: DateTime<Utc>) -> String {
    at.to_rfc3339_opts(SecondsFormat::Millis, true)
}

/// Now as every Tama record writes a time.
pub fn iso_now() -> String {
    iso(now())
}

/// Now to the whole second, as `date -u +%Y-%m-%dT%H:%M:%SZ` writes it, for
/// a state file read by eye as often as by a tool.
pub fn iso_now_seconds() -> String {
    now().to_rfc3339_opts(SecondsFormat::Secs, true)
}

/// Milliseconds since the Unix epoch, negative before it.
pub fn now_millis() -> i64 {
    now().timestamp_millis()
}

/// Milliseconds since the Unix epoch for a record that keeps them unsigned,
/// or why a clock set before the epoch has none to give.
pub fn epoch_millis() -> Result<u64, String> {
    let millis = now_millis();
    u64::try_from(millis).map_err(|error| {
        format!(
            "the system clock reads {millis} ms, before the Unix epoch, so it has no time to \
             record: {error}"
        )
    })
}

/// Seconds since the Unix epoch for a record that keeps them unsigned, or
/// why a clock set before the epoch has none to give.
pub fn epoch_seconds() -> Result<u64, String> {
    let seconds = now().timestamp();
    u64::try_from(seconds).map_err(|error| {
        format!(
            "the system clock reads {seconds} s, before the Unix epoch, so it has no time to \
             record: {error}"
        )
    })
}

/// The instant `millis` since the epoch names, or why the calendar has none.
pub fn from_millis(millis: i64) -> Result<DateTime<Utc>, String> {
    DateTime::from_timestamp_millis(millis).ok_or_else(|| {
        format!("{millis} ms since the Unix epoch is outside the dates the calendar can write")
    })
}

/// The instant an RFC 3339 timestamp names, in UTC, or the parse error
/// naming the text it could not read.
pub fn parse(text: &str) -> Result<DateTime<Utc>, String> {
    DateTime::parse_from_rfc3339(text)
        .map(|at| at.with_timezone(&Utc))
        .map_err(|error| format!("`{text}` is not an RFC 3339 timestamp: {error}"))
}

/// The time from `from` to `to`, as a person reads it: whole hours, minutes
/// and seconds (`1 h 5 min 42 s`, `0 s`), each part taken off what remains,
/// so no unit's size is restated here. A `to` before `from` reads as the
/// same span written with a minus sign.
pub fn elapsed(from: DateTime<Utc>, to: DateTime<Utc>) -> String {
    let span = to - from;
    let (sign, span) = if span < TimeDelta::zero() {
        ("-", -span)
    } else {
        ("", span)
    };
    let hours = span.num_hours();
    let after_hours = span - TimeDelta::hours(hours);
    let minutes = after_hours.num_minutes();
    let seconds = (after_hours - TimeDelta::minutes(minutes)).num_seconds();
    let mut parts = Vec::new();
    if hours != 0 {
        parts.push(format!("{hours} h"));
    }
    if minutes != 0 {
        parts.push(format!("{minutes} min"));
    }
    if seconds != 0 || parts.is_empty() {
        parts.push(format!("{seconds} s"));
    }
    format!("{sign}{}", parts.join(" "))
}

/// The calendar date an RFC 3339 `full-date` names, written exactly that
/// way (four-digit year, two-digit month and day), or the parse error
/// naming the text.
pub fn parse_date(text: &str) -> Result<NaiveDate, String> {
    let date = NaiveDate::parse_from_str(text, FULL_DATE)
        .map_err(|error| format!("`{text}` is not an RFC 3339 full-date: {error}"))?;
    if date.format(FULL_DATE).to_string() != text {
        return Err(format!(
            "`{text}` is not written as the RFC 3339 full-date {date}"
        ));
    }
    Ok(date)
}
