//! Decision half of `tama hook block-unauthorized-rollback` (hook id
//! `block-unauthorized-rollback`): a shell line that puts an earlier version
//! back is refused unless the operator granted that exact command in his own
//! words ([`crate::ports::operator_grant`]).
//!
//! A rollback is read without a model, command by command as the shell runs
//! them ([`command_path`]):
//!
//! - an installed product or release put back: `stado product rollback`,
//!   `stado release rollback`, `stado release local restore`;
//! - committed work undone: `git revert` (but `--abort` and `--quit`, which
//!   end a revert), `git reset` with `--hard`, `--keep` or `--merge`, or onto
//!   a revision ([`git`]);
//! - files put back to an earlier version: `git checkout` of paths or of a
//!   revision, `git restore` of the working tree or from a `--source`,
//!   `git switch --detach` onto a revision;
//! - any of these handed to another host by `stado host exec`.
//!
//! The way on from a failed step is a forward repair at a new revision, so
//! nothing here admits a rollback on the agent's judgement.

mod git;

use serde_json::{json, Value};

use crate::ports::block_unauthorized_host_change::{remote_command, words};
use crate::ports::command_path;
use crate::ports::operator_grant::{self, Request};
use crate::ports::tool_vocabulary::Call;

pub const HOOK_ID: &str = "block-unauthorized-rollback";
const GRANT_KIND: &str = "rollback";
const BANNER: &str = "BLOCKED: unauthorized rollback: ";

/// Each Stado command path that puts an earlier installed version back.
const STADO: &[&[&str]] = &[
    &["stado", "product", "rollback"],
    &["stado", "release", "rollback"],
    &["stado", "release", "local", "restore"],
];
/// The programs a rollback runs through, for a line that cannot be read.
const PROGRAMS: &[&str] = &["git", "stado"];
/// The words that, beside one of [`PROGRAMS`], mark a line as a rollback
/// where it cannot be read.
const ROLLBACK_WORDS: &[&str] = &[
    "rollback", "revert", "reset", "restore", "checkout", "switch",
];

/// The refusal when the call rolls something back with no grant, `None` when
/// it passes.
pub fn evaluate(payload: &Value) -> Option<String> {
    let call = Call::of(payload);
    if !call.is_shell() {
        return None;
    }
    let command = call.command()?;
    let rollbacks = match rollbacks(payload) {
        Ok(rollbacks) => rollbacks,
        // Only words the shell runs make an unreadable line a rollback:
        // quoted data (a prompt, a message) is no command.
        Err(cause)
            if mentions_rollback(&crate::ports::shell_text::effective_payload(
                payload, command,
            )) =>
        {
            vec![format!("what it runs cannot be read: {cause}")]
        }
        Err(_) => Vec::new(),
    };
    if rollbacks.is_empty() {
        return None;
    }
    let request = Request {
        gate: HOOK_ID,
        command: Some(command),
        paths: &[],
    };
    if operator_grant::granted(payload, &request) {
        return None;
    }
    Some(format!(
        "{BANNER}{}. Putting an earlier version back undoes work already done and paid for; the \
         way on from a failed step is a forward repair committed at a new revision and installed \
         as that revision. {}",
        rollbacks.join("; "),
        operator_grant::how_to_grant(GRANT_KIND, HOOK_ID)
    ))
}

/// Every rollback the shell line in `payload` makes, each said once.
fn rollbacks(payload: &Value) -> Result<Vec<String>, String> {
    let mut found = Vec::new();
    let mut add = |rollback: String| {
        if !found.contains(&rollback) {
            found.push(rollback);
        }
    };
    for path in STADO {
        if command_path::reaches(payload, &words(path))? {
            add(format!("`{}` puts an earlier version back", path.join(" ")));
        }
    }
    for rollback in git::rollbacks(payload)? {
        add(rollback);
    }
    for reached in command_path::reached(payload, &words(&["stado", "host", "exec"]))? {
        if let Some(line) = remote_command(&reached.args) {
            let handed = json!({ "tool_name": "bash", "tool_input": { "command": line } });
            for rollback in rollbacks(&handed)? {
                add(format!("on another host, {rollback}"));
            }
        }
    }
    Ok(found)
}

/// Whether `command`, read as plain words, holds one command — a stretch
/// between `;`, `|`, `&`, parentheses, backquotes and line ends — whose
/// program word ([`PROGRAMS`]) is followed by a word of a rollback. A word
/// of a rollback elsewhere on the line, or before the program, is no
/// rollback, so a computed value elsewhere does not refuse the line.
fn mentions_rollback(command: &str) -> bool {
    command
        .split(|character: char| ";|&()`\n".contains(character))
        .any(|segment| {
            let mut after_program = false;
            segment
                .split(|character: char| character.is_whitespace() || "'\"".contains(character))
                .map(|word| word.rsplit('/').next().unwrap_or(word))
                .any(|word| {
                    let rollback = after_program && ROLLBACK_WORDS.contains(&word);
                    after_program |= PROGRAMS.contains(&word);
                    rollback
                })
        })
}
