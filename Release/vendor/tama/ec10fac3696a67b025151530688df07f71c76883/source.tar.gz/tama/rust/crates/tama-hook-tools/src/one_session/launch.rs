//! Turning a provider entry into a command line: which executable, which
//! arguments, and how the hooks reach the session it starts. A field the
//! entry does not carry in its declared shape, or an override variable that
//! cannot be read, is the error naming it.

use crate::registry::provider_hooks;
use crate::util::home_dir;
use serde_json::{json, Map, Value};
use std::path::PathBuf;

use super::catalog::{expand_arguments, extension_path, run_hook_path, validate_provider};
use super::isolated_omp_agent;
use super::isolation::isolated_codex_home;

/// A prepared provider launch.
pub struct LaunchPlan {
    pub executable: String,
    pub args: Vec<String>,
    pub env: Vec<(String, String)>,
    /// Temp directory to remove after the child exits.
    pub cleanup: Option<PathBuf>,
}

/// The text field `key` of a provider entry.
fn text<'a>(provider: &'a Value, key: &str) -> Result<&'a str, String> {
    provider
        .get(key)
        .and_then(Value::as_str)
        .ok_or_else(|| format!("the provider entry carries no text field {key}"))
}

/// The list field `key` of a provider entry.
fn list<'a>(provider: &'a Value, key: &str) -> Result<&'a [Value], String> {
    provider
        .get(key)
        .and_then(Value::as_array)
        .map(Vec::as_slice)
        .ok_or_else(|| format!("the provider entry carries no list field {key}"))
}

/// The command line, environment and cleanup for starting `provider_name`'s
/// session with `hook_id` dispatched into it.
pub fn launch_for_provider(
    registry: &Value,
    provider_name: &str,
    provider: &Value,
    hook_id: &str,
    mode: &str,
    session: Option<&str>,
    cwd: &str,
) -> Result<LaunchPlan, String> {
    validate_provider(provider)?;
    let mut env = vec![
        ("TAMA_ONE_SESSION_HOOK_ID".to_string(), hook_id.to_string()),
        (
            "TAMA_SESSION_OWNER_PID".to_string(),
            std::process::id().to_string(),
        ),
    ];
    let mut values = Map::new();
    values.insert("cwd".into(), json!(cwd));
    values.insert(
        "extensionPath".into(),
        json!(extension_path()?.display().to_string()),
    );
    if let Some(session) = session {
        values.insert("session".into(), json!(session));
    }
    let agent_dir = match tama_core::path_variable("PI_CODING_AGENT_DIR") {
        Some(directory) => directory,
        None => home_dir().join(".omp").join("agent"),
    };
    let session_dir = agent_dir.join("sessions");
    values.insert(
        "sessionDir".into(),
        json!(session_dir.display().to_string()),
    );
    let mut cleanup = None;

    match text(provider, "hookTransport")? {
        "inline-settings" => {
            let hooks = provider_hooks(registry, hook_id, provider_name, &run_hook_path()?)?;
            let hooks_json =
                serde_json::to_string(&json!({ "hooks": hooks })).map_err(|error| {
                    format!("the provider's hook settings cannot be written: {error}")
                })?;
            values.insert("hooksJson".into(), json!(hooks_json));
        }
        "isolated-codex-home" => {
            let isolated = isolated_codex_home(registry, hook_id, cwd, provider_name)?;
            env.push(("CODEX_HOME".to_string(), isolated.display().to_string()));
            cleanup = Some(isolated);
        }
        "omp-extension" => {
            let isolated = isolated_omp_agent()?;
            env.push((
                "PI_CODING_AGENT_DIR".to_string(),
                isolated.display().to_string(),
            ));
            cleanup = Some(isolated);
        }
        other => return Err(format!("Unsupported provider hook transport: {}", other)),
    }

    let template = if mode == "new" {
        list(provider, "newArguments")?
    } else {
        list(provider, "resumeArguments")?
    };
    let executable_env = text(provider, "executableEnv")?;
    let executable = match std::env::var(executable_env) {
        Ok(named) if !named.is_empty() => named,
        Ok(_) | Err(std::env::VarError::NotPresent) => text(provider, "executable")?.to_string(),
        Err(error) => {
            return Err(format!(
                "the variable {executable_env} naming the provider's executable cannot be read: {error}"
            ))
        }
    };
    Ok(LaunchPlan {
        executable,
        args: expand_arguments(template, &values)?,
        env,
        cleanup,
    })
}
