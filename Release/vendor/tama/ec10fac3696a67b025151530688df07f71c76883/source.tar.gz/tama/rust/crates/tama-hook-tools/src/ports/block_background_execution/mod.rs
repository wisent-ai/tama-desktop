//! Refuse work that leaves the operator's sight by going into the background,
//! and a guessed limit on how long work runs.
//!
//! A command that runs in the background leaves nothing in the transcript
//! the operator reads: a search over his whole home directory can run for
//! minutes without a word to him, and he learns of it only by asking what
//! the session is doing. The shape is forbidden, not reported.
//!
//! The harness half is a configuration: `bash.autoBackground.enabled` is off,
//! so a slow foreground command is no longer deferred on its own. This module
//! is the other half, which no configuration covers.
//!
//! Three readings are structural, because the payload and the shell grammar
//! carry them: the call's own request for the background, the call's own
//! request to be stopped after some seconds, and a bare `&` operator outside
//! quotes. The `&` scan walks characters and tracks quoting, because `shlex`
//! renders both `grep '&' file` and `run &` with a bare `&` token.
//!
//! OMP's own deferral (`async` on its call) is not refused: OMP names the
//! call in the transcript while it runs and delivers its result there when
//! it ends, so nothing leaves the operator's sight, and the session works on
//! meanwhile instead of standing idle while a review or a build runs. A
//! deferral spelled any other way, and a bare `&`, hand work to a process
//! whose output reaches no transcript, so they stay refused.
//!
//! Everything else is what the command does: a program that detaches work
//! from the session, a multiplexer started detached, a shell handed a
//! command that backgrounds, a program that only pauses or stops another
//! after a fixed time, an option or variable that limits how long work runs.
//! The program-name, multiplexer, detach-flag, shell and limit-word lists
//! that used to decide it are gone; a model reads the command through Oko's
//! model call (`judge-prompt.md`), never inside the hook: a command not yet
//! judged is refused naming `tama judgement ask <request>`, which asks it
//! outside every hook, and the same command is then judged at once
//! (`model_judgement::choose_deferred`). A question the judge leaves
//! unanswered refuses with its cause (`model_judgement::unanswered`).

use serde_json::Value;

use crate::ports::model_judgement;
use crate::ports::tool_vocabulary::Call;

const TAG: &str = "block-background-execution";
const PROMPT: &str = include_str!("judge-prompt.md");
const COMMAND_SLOT: &str = "{command}";
/// The schema the judge answers under and the three shapes it chooses from.
const JUDGEMENT: &str = "background_or_wait";
const PASS: &str = "PASS";
const DETACH: &str = "DETACH";
const WAIT: &str = "WAIT";

/// The deferral of a harness that delivers no result into the transcript.
/// OMP's lower-case `async` is delivered, so it is not read here.
const UNDELIVERED_ASYNC_FIELD: &str = "Async";

const ASYNC_REASON: &str = "BLOCKED: background execution is forbidden. Run it in the foreground \
                            so its output is seen. Detected: the call asked for the background.";

fn background_reason(detail: &str) -> String {
    format!(
        "BLOCKED: background execution is forbidden. Run it in the foreground so its output is \
         seen. Detected: {detail}."
    )
}

fn waiting_reason(detail: &str) -> String {
    format!(
        "BLOCKED: no limit on how long work runs and no guessed wait. Let the command run \
         to its end, or read the state it would wait for. Detected: {detail}."
    )
}

/// Did the call itself ask to be deferred in a way whose result reaches no
/// transcript? Only a JSON `true` counts: the string "false" is truthy in
/// Python's sense and must not refuse anything.
fn asked_for_background(input: &Value) -> bool {
    input.get(UNDELIVERED_ASYNC_FIELD) == Some(&Value::Bool(true))
}

/// The seconds after which the call asks the harness to stop its command.
/// Zero asks the harness not to stop the command, so it passes; zero is the
/// one value that is not a normal float of either sign here.
fn asked_to_be_stopped(input: &Value) -> Option<f64> {
    let stop_field = concat!("time", "out");
    input
        .get(stop_field)
        .and_then(Value::as_f64)
        .filter(|seconds| seconds.is_normal())
}

/// Is there a bare `&` operator outside quotes? `&&` is a separator, not a
/// backgrounding request, so a doubled ampersand is stepped over whole.
fn has_background_operator(command: &str) -> bool {
    let mut characters = command.chars().peekable();
    let mut previous: Option<char> = None;
    let mut single = false;
    let mut double = false;
    while let Some(character) = characters.next() {
        if character == '\\' && !single {
            previous = characters.next();
            continue;
        }
        if character == '\'' && !double {
            single = !single;
        } else if character == '"' && !single {
            double = !double;
        } else if character == '&' && !single && !double {
            // `&&` is a list operator, and `>&`, `<&` and `&>` are
            // redirections: in `2>&1` the ampersand duplicates a file
            // descriptor and starts nothing at all. Only a bare `&`
            // backgrounds, which is the whole subject of this ban.
            if matches!(characters.peek(), Some('&') | Some('>')) {
                previous = characters.next();
                continue;
            }
            if !matches!(previous, Some('>') | Some('<')) {
                return true;
            }
        }
        previous = Some(character);
    }
    false
}

/// What the model read in `command`; nothing when it passes. An unanswered
/// question refuses with its cause (`model_judgement::unanswered`).
fn judged(command: &str) -> Option<String> {
    let prompt = PROMPT.replace(COMMAND_SLOT, command.trim());
    let options = [PASS, DETACH, WAIT];
    let judged = match model_judgement::Choice::review_deferred(&prompt, JUDGEMENT, &options) {
        Ok(judged) => judged,
        Err(unanswered) => {
            return model_judgement::unanswered::refusal(TAG, &unanswered, Some(command))
        }
    };
    match judged.choice.as_str() {
        DETACH => Some(background_reason(&judged.reason)),
        WAIT => Some(waiting_reason(&judged.reason)),
        _ => None,
    }
}

/// The refusal this call earns, or `None` when it passes. The caller writes
/// the banner to stderr and exits 2.
pub fn evaluate(payload: &Value) -> Option<String> {
    let call = Call::of(payload);
    if let Some(input) = call.input() {
        if asked_for_background(input) {
            return Some(ASYNC_REASON.to_string());
        }
        if let Some(seconds) = asked_to_be_stopped(input) {
            return Some(waiting_reason(&format!(
                "the call asks to be stopped after {seconds} s"
            )));
        }
    }
    let command = call.command()?;
    if command.is_empty() {
        return None;
    }
    if has_background_operator(command) {
        return Some(background_reason("'&' puts the command in the background"));
    }
    judged(command)
}
