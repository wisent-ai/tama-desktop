//! Runtime rules and built-in defaults share the same matching engine.
//!
//! Each rule declares its identifier, publication date, subject, pattern,
//! refusal and reason. The drafter appends runtime rules to
//! `~/.shared-hooks/auto_rules.json`; the write and bash gates read that
//! registry on every call. Built-in defaults remain active independently
//! of the runtime registry.

mod registry;

use registry::{recorded, Learned};
pub(crate) use registry::{registry_path, DEFAULTS};

use crate::ports::transport_common as common;

/// What a rule reads. The registry spells it in lowercase, and the type is
/// the one list of subjects: the drafter and the gates both read a name
/// through [`Target::named`], so a subject no gate can offer is refused by
/// the same definition that matches it.
#[derive(Clone, Copy, PartialEq, serde::Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum Target {
    Path,
    Content,
    Command,
}

impl Target {
    /// The subject the registry spells `name`, if a gate can offer it. serde's
    /// refusal of a string can only say it is none of the variants, which is
    /// exactly what `None` says.
    pub fn named(name: &str) -> Option<Self> {
        serde_json::from_value(serde_json::Value::String(name.to_string())).ok()
    }

    /// The word the registry spells this subject with.
    pub fn word(self) -> &'static str {
        match self {
            Target::Path => "path",
            Target::Content => "content",
            Target::Command => "command",
        }
    }
}

/// The subjects no incident is: nothing at all, and a single letter. A
/// pattern that matches either matches every path, content or command a
/// gate offers it, so it names no failed operation.
const TRIVIAL_SUBJECTS: &[&str] = &["", "a"];

/// Whether `pattern` matches every subject a gate offers, read as matching
/// one of [`TRIVIAL_SUBJECTS`]. The drafter refuses to record such a rule
/// and the gates refuse to apply one; `tama rules list` names it. A pattern
/// that does not compile matches nothing.
pub fn reaches_every_subject(pattern: &str) -> bool {
    match regex::Regex::new(pattern) {
        Ok(regex) => TRIVIAL_SUBJECTS
            .iter()
            .any(|subject| regex.is_match(subject)),
        Err(_does_not_compile) => false,
    }
}

/// One rule: what it reads, what it matches, and what it says.
pub struct Rule {
    pub id: &'static str,
    pub added: &'static str,
    pub target: Target,
    pub pattern: &'static str,
    pub message: &'static str,
    pub why: &'static str,
}

/// What a rule may read: the three subjects a gate can offer it.
#[derive(Default)]
pub struct Subjects<'a> {
    pub file_path: &'a str,
    pub content: &'a str,
    pub command: &'a str,
}

impl<'a> Subjects<'a> {
    fn of(&self, target: Target) -> &'a str {
        match target {
            Target::Path => self.file_path,
            Target::Content => self.content,
            Target::Command => self.command,
        }
    }
}

/// The refusal one of these rules earns, if any. `registry` is injectable so
/// a test runs against a fixture instead of the machine's own file. A gate
/// that offers no command only ever matches path and content rules, because
/// an empty subject matches nothing these patterns look for.
pub fn refusal_with(registry: &str, subjects: &Subjects) -> Option<String> {
    for rule in DEFAULTS {
        let subject = subjects.of(rule.target);
        if !subject.is_empty() && common::compile(rule.pattern).is_match(subject) {
            return Some(rule.message.to_string());
        }
    }
    // Learned rules that cannot be read are not skipped: the refusal names
    // the file and the cause, so no rule the operator taught goes unenforced
    // without a word.
    let rules = match recorded(registry) {
        Ok(rules) => rules,
        Err(error) => return Some(format!("BLOCKED: {error}")),
    };
    for Learned {
        id,
        target,
        pattern,
        message,
    } in rules
    {
        let subject = subjects.of(target);
        if subject.is_empty() {
            continue;
        }
        // A learned rule matching every subject names no incident: applied,
        // one row stopped every shell command on the machine. It is not
        // applied, and every call says which row and how it goes.
        if reaches_every_subject(&pattern) {
            eprintln!(
                "tama: the learned rule {id} in {registry} matches every {} ({pattern}), so it \
                 names no incident and is not applied; remove it with `tama rules remove --id \
                 {id}` and record a pattern that names what went wrong",
                target.word()
            );
            continue;
        }
        if common::compile(&pattern).is_match(subject) {
            return Some(message);
        }
    }
    None
}

/// The refusal for a write: its path and the content it would leave.
pub fn write_refusal(file_path: &str, content: &str) -> Option<String> {
    refusal_with(
        &registry_path(),
        &Subjects {
            file_path,
            content,
            command: "",
        },
    )
}

/// The refusal for a shell command.
pub fn command_refusal(command: &str) -> Option<String> {
    refusal_with(
        &registry_path(),
        &Subjects {
            command,
            ..Default::default()
        },
    )
}

/// Where this machine keeps the rules recorded by the drafter.
pub fn machine_registry_path() -> String {
    registry_path()
}
