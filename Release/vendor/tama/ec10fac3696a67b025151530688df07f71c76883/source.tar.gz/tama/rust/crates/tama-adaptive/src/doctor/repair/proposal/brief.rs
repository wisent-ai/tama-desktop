//! The brief a repair candidate is drafted from: the hook, its script, and
//! samples of what must block and what must pass.
//!
//! Split out of `doctor/repair.rs`, which had grown past the
//! three-hundred-line limit.

use std::fs;
use std::path::{Path, PathBuf};

use super::super::corpus::{hook_paths, split_corpus};
use crate::engine::load_engine;

pub struct Brief {
    pub hook_id: String,
    pub command: Option<String>,
    pub live: Option<String>,
    pub archive: Option<PathBuf>,
    pub must_pass_count: usize,
    pub must_block_count: usize,
    pub text: String,
}

/// `buildBrief(hookId)`.
pub fn build_brief(hook_id: &str) -> Result<Brief, String> {
    let core = load_engine()?;
    let paths = hook_paths(hook_id, &core)?;
    let corpus = split_corpus(&core.state_dir, hook_id)?;
    // The patch is drafted against the live script, or the archived source
    // when the live one is gone; a brief without either would ask for a
    // repair of nothing.
    let present = |path: &Path| tama_core::presence::present(path).map_err(|e| e.to_string());
    let candidates = [
        paths.live.as_deref().map(Path::new),
        paths.archive.as_deref(),
    ];
    let mut script = None;
    for candidate in candidates.into_iter().flatten() {
        if present(candidate)? {
            script = Some(candidate);
            break;
        }
    }
    let Some(script) = script else {
        return Err(format!(
            "hook {hook_id} has no live or archived script to repair"
        ));
    };
    let source = fs::read_to_string(script).map_err(|error| {
        format!(
            "hook {hook_id} script {} cannot be read: {error}",
            script.display()
        )
    })?;
    // Every payload the candidate is validated against, whole, so it is
    // drafted from what it will be judged on.
    let sample = |rows: &[serde_json::Value]| -> Result<Vec<String>, String> {
        rows.iter()
            .map(|row| match row.get("payload") {
                Some(payload) => Ok(tama_core::json::compact(payload)),
                None => Err(format!(
                    "a corpus entry of hook {hook_id} carries no payload: {row}"
                )),
            })
            .collect()
    };
    let mut lines: Vec<String> = vec![format!("Hook under repair: {hook_id}")];
    lines.push(format!("Script under repair: {}", script.display()));
    if let Some(command) = &paths.command {
        lines.push(format!("Registry command: {command}"));
    }
    lines.extend([
        "Goal: produce a minimal patch of the script so that every MUST-BLOCK payload".to_string(),
        "still blocks (nonzero exit or {\"decision\":\"block\"} JSON) and every MUST-PASS"
            .to_string(),
        "payload passes cleanly (zero exit, no block JSON). It must not crash on {}.".to_string(),
        format!("--- MUST BLOCK payloads ({}) ---", corpus.must_block.len()),
    ]);
    lines.extend(sample(&corpus.must_block)?);
    lines.push(format!(
        "--- MUST PASS payloads ({}) ---",
        corpus.must_pass.len()
    ));
    lines.extend(sample(&corpus.must_pass)?);
    lines.push("--- CURRENT SOURCE ---".to_string());
    lines.push(source);
    lines.push(
        "Reply with the complete corrected file content only. No commentary, no markdown fences."
            .to_string(),
    );
    Ok(Brief {
        hook_id: hook_id.to_string(),
        command: paths.command,
        live: paths.live,
        archive: paths.archive,
        must_pass_count: corpus.must_pass.len(),
        must_block_count: corpus.must_block.len(),
        text: lines.join("\n"),
    })
}
