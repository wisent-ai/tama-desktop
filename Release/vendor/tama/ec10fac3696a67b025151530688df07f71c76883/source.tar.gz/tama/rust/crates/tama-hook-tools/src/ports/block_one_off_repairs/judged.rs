//! The one-off repairs a model reads.
//!
//! Whether a command cycles a service, writes a vault, a store or a setting,
//! replaces an installed program or a hook's file, waits instead of
//! working, searches a tree once, or puts an older version back is what the
//! command does, not which verb it spells: the verb lists this gate used to
//! carry were the keyword logic `block-keyword-literals` refuses everywhere
//! else, and missed every launcher and client nobody listed. The command is
//! read by a model through Oko's model call (`ports::model_judgement`) with
//! the operator's rule and each outcome's product route in the prompt
//! (`judge-prompt.md`), and the refusal is the model's sentence naming what
//! the command does by hand and the route that owns it. The model is never
//! asked inside the hook: a command not yet judged is refused naming `tama
//! judgement ask <request>`, which asks it outside every hook, and the same
//! command is then judged at once from the kept answer
//! (`model_judgement::choose_deferred`). Tama does not need Brama or any
//! model to hold a session to this rule: on a machine that declared no model
//! the structural refusals decide alone, and a command that only operates
//! the judge's own programs is never held behind the judge it repairs
//! (`unanswered::refusal`). The build hold also reads the toolchains' own
//! structure (`vocabulary`).

use crate::ports::model_judgement;

use super::vocabulary::BANNER;

const TAG: &str = "block-one-off-repairs";
const PROMPT: &str = include_str!("judge-prompt.md");
const COMMAND_SLOT: &str = "{command}";
/// The schema the judge answers under and the two options it chooses from.
const JUDGEMENT: &str = "one_off_repair";
const PASS: &str = "PASS";
const BLOCK: &str = "BLOCK";

/// The refusal the model's reading of `command` earns, or the refusal an
/// unanswered question earns; nothing when it passes.
pub(super) fn judged_refusal(command: &str) -> Option<String> {
    if model_judgement::unanswered::consumer::recognizes(command) {
        return None;
    }
    let prompt = PROMPT.replace(COMMAND_SLOT, command.trim());
    match model_judgement::Choice::review_deferred(&prompt, JUDGEMENT, &[PASS, BLOCK]) {
        Ok(judged) => (judged.choice == BLOCK).then(|| format!("{BANNER}{}", judged.reason)),
        Err(unanswered) => model_judgement::unanswered::refusal(TAG, &unanswered, Some(command)),
    }
}
