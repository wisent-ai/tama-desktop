//! The products a build command builds, read from the command itself.

use std::path::Path;
use std::process::Command;

use serde_json::Value;

/// Every product a build command builds, read only from the positions that
/// name them in that command, or `None` when the set cannot be established:
///   * `stado release submit|build submit … --source <checkout>` (each
///     `--source`): the product the checkout's release manifest declares,
///     else, for a checkout with no manifest, the checkout directory's name
///     (a manifest that cannot be read or names no product establishes
///     nothing), a relative path (`--source .`)
///     resolved against the directory the command runs in; a path that does
///     not resolve to an existing directory establishes nothing;
///   * `stado release submit … --build <id>`: the product of that build, as
///     the fleet's own build record (`stado build status <id> --json`) names
///     it; a build the fleet does not hold establishes nothing;
///   * `cargo …`: the product of the checkout the command builds in — the
///     checkout holding its `--manifest-path`, else the directory it runs in
///     — named as that checkout's release manifest names it, else, with no
///     manifest, by the checkout's directory. Every package a Cargo workspace builds belongs to
///     the checkout that holds it, so its `-p` selections are package names,
///     not products, and never decide which product is built; a command
///     outside any checkout, or naming two manifests, establishes nothing;
///   * `swift build|test|run …` and `stado product swift <operation> …`: the
///     product of the checkout holding its `--package-path`, else the
///     directory it runs in, named the same way;
///   * `stado product cargo …`: the product of the checkout it builds, read
///     as for `cargo` (Stado forwards `--manifest-path` and `-p` to Cargo
///     unchanged, so its `-p` selections are package names, not products);
///
/// Every other argument (`--target-dir`, a package selection) is an output
/// location or a part of the product, not a subject, and is never read.
pub(super) fn build_subjects(program: &str, args: &[String], cwd: &Path) -> Option<Vec<String>> {
    let words: Vec<&str> = args.iter().map(String::as_str).collect();
    let subjects: Vec<String> = match (program, words.as_slice()) {
        ("stado", ["release", "submit", rest @ ..]) => {
            let sources = option_values(rest, &["--source"]);
            if sources.is_empty() {
                option_values(rest, &["--build"])
                    .into_iter()
                    .map(built_product)
                    .collect::<Option<_>>()?
            } else {
                checkout_names(&sources, cwd)?
            }
        }
        ("stado", ["build", "submit", rest @ ..]) => {
            checkout_names(&option_values(rest, &["--source"]), cwd)?
        }
        ("stado", ["product", "install" | "update", product, ..]) if !product.starts_with('-') => {
            vec![product.to_string()]
        }
        ("stado", ["product", "cargo", rest @ ..]) => cargo_products(rest, cwd)?,
        ("stado", ["product", "swift", rest @ ..]) | ("swift", rest) => {
            package_products(rest, cwd)?
        }
        ("cargo", rest) => cargo_products(rest, cwd)?,
        _ => return None,
    };
    (!subjects.is_empty()).then_some(subjects)
}

/// The product a Cargo command builds: the checkout its manifest lies in
/// (`--manifest-path`, else the directory the command runs in), named as its
/// release manifest names it.
fn cargo_products(args: &[&str], cwd: &Path) -> Option<Vec<String>> {
    let start = match option_values(args, &["--manifest-path"]).as_slice() {
        [] => cwd.to_path_buf(),
        [manifest] => cwd.join(manifest).parent()?.to_path_buf(),
        _ => return None,
    };
    checkout_of(&start, cwd)
}

/// The product a Swift package command builds (`swift build|test|run`,
/// `stado product swift <operation>`): the checkout holding its
/// `--package-path`, else the directory it runs in, named as its release
/// manifest names it.
fn package_products(args: &[&str], cwd: &Path) -> Option<Vec<String>> {
    let start = match option_values(args, &["--package-path"]).as_slice() {
        [] => cwd.to_path_buf(),
        [package] => cwd.join(package),
        _ => return None,
    };
    checkout_of(&start, cwd)
}

/// The product of the checkout `start` lies in; `None` outside any checkout,
/// or when `start` cannot be resolved or an ancestor's `.git` cannot be
/// examined, with that cause on stderr.
fn checkout_of(start: &Path, cwd: &Path) -> Option<Vec<String>> {
    let start = match start.canonicalize() {
        Ok(start) => start,
        Err(error) => {
            eprintln!(
                "block-one-off-repairs: cannot resolve {}: {error}",
                start.display()
            );
            return None;
        }
    };
    let checkout = match tama_core::presence::checkout_root(&start) {
        Ok(Some(checkout)) => checkout,
        Ok(None) => return None,
        Err(error) => {
            eprintln!(
                "block-one-off-repairs: the checkout {} lies in cannot be told: {error}",
                start.display()
            );
            return None;
        }
    };
    checkout_names(&[checkout.to_str()?], cwd)
}

/// The product of every `--source` checkout, each resolved against `cwd`
/// when relative: the `product` its release manifest declares, which is the
/// name Stado builds it under and a capability grant can hold, else, for a
/// checkout with no manifest, the checkout directory's name. `None` when any
/// of them does not name an existing directory (`.` read as text names no
/// product), or has a manifest that cannot be read or names no product: the
/// directory's name standing in for it could match a grant for another
/// product. The cause is said on stderr.
fn checkout_names(sources: &[&str], cwd: &Path) -> Option<Vec<String>> {
    sources
        .iter()
        .map(|source| {
            let checkout = match cwd.join(source).canonicalize() {
                Ok(path) if path.is_dir() => path,
                Ok(path) => {
                    eprintln!(
                        "block-one-off-repairs: checkout {} is not a directory",
                        path.display()
                    );
                    return None;
                }
                Err(error) => {
                    eprintln!("block-one-off-repairs: cannot resolve checkout {source}: {error}");
                    return None;
                }
            };
            let manifest = checkout.join(".wisent-release.json");
            let text = match std::fs::read_to_string(&manifest) {
                Ok(text) => text,
                Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
                    return checkout.file_name()?.to_str().map(str::to_string);
                }
                Err(error) => {
                    eprintln!(
                        "block-one-off-repairs: cannot read {}: {error}",
                        manifest.display()
                    );
                    return None;
                }
            };
            let declared = serde_json::from_str::<Value>(&text)
                .map_err(|error| error.to_string())
                .and_then(
                    |document| match document.get("product").and_then(Value::as_str) {
                        Some(product) => Ok(product.to_string()),
                        None => Err("it names no product".to_string()),
                    },
                );
            match declared {
                Ok(product) => Some(product),
                Err(cause) => {
                    eprintln!(
                        "block-one-off-repairs: {} does not declare the product: {cause}",
                        manifest.display()
                    );
                    None
                }
            }
        })
        .collect()
}

/// The product of the build `id`, read from the fleet's build record. `None`
/// when Stado cannot answer or holds no such build, with the cause on
/// stderr: an unknown build is admitted only by a grant with no product list.
fn built_product(id: &str) -> Option<String> {
    let read = format!("stado build status {id} --json");
    let output = match stado_wait::output(
        Command::new("stado").args(["build", "status", id, "--json"]),
    ) {
        Ok(output) => output,
        Err(error) => {
            eprintln!("block-one-off-repairs: {read} could not run, so build {id} names no product: {error}");
            return None;
        }
    };
    if !output.status.success() {
        eprintln!(
            "block-one-off-repairs: {read} exited {}, so build {id} names no product: {}",
            output.status,
            String::from_utf8_lossy(&output.stderr).trim()
        );
        return None;
    }
    let record: Value = match serde_json::from_slice(&output.stdout) {
        Ok(record) => record,
        Err(error) => {
            eprintln!("block-one-off-repairs: {read} printed no JSON, so build {id} names no product: {error}");
            return None;
        }
    };
    let product = record
        .get("product")
        .and_then(Value::as_str)
        .filter(|product| !product.is_empty());
    if product.is_none() {
        eprintln!("block-one-off-repairs: {read} names no product for build {id}");
    }
    product.map(str::to_string)
}

/// Every value given to any of `flags`, as `flag <value>`, `flag=<value>`,
/// or, for a single-dash flag, `-p<value>`.
fn option_values<'a>(words: &[&'a str], flags: &[&str]) -> Vec<&'a str> {
    let mut values = Vec::new();
    let mut after = words.iter().copied();
    after.next();
    let following = after.map(Some).chain(std::iter::once(None));
    for (&word, next) in words.iter().zip(following) {
        for &flag in flags {
            if word == flag {
                if let Some(value) = next {
                    values.push(value);
                }
            } else if let Some(rest) = word.strip_prefix(flag) {
                if let Some(value) = rest.strip_prefix('=') {
                    values.push(value);
                } else if !flag.starts_with("--") && !rest.is_empty() {
                    values.push(rest);
                }
            }
        }
    }
    values
}
