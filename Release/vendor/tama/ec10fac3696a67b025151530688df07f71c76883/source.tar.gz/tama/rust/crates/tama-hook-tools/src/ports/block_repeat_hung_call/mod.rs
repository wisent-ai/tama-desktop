//! Decision half of `tama hook block-repeat-hung-call` (hook id
//! `block-repeat-hung-call`): a tool that already hung in this session is
//! not called again in it.
//!
//! A session asked the context advisor, the call ran for more than an hour
//! and ended without an answer, and the session asked it again; the
//! operator: to skoro wczesniej trwalo wiecej niz godzine. to czemu znow to
//! samo zrobiles. A tool that hung once hangs again on the same machine for
//! the same reason, and the way on is another route to the same answer —
//! a direct search of the code — not a second wait.
//!
//! A call hung when it ended in error (cancelled, interrupted, failed) after
//! running longer than every call this session completed without error: no
//! duration is set here, the session's own record is the measure, so a
//! quick failure is never mistaken for a hang. Only a tool that answers a
//! question is held to this — the context advisor, a web search, a lookup —
//! and not one that runs a program (a shell, an evaluation, a process),
//! whose next call is another program.
//!
//! No model, no network, no lock: the transcript is read once ([`calls`]).
//! A transcript that cannot be read passes, said on stderr. The operator's
//! own words for the call admit it (`tama justify record --kind
//! hung-call`).

mod calls;

use std::time::Duration;

use serde_json::Value;

use crate::ports::operator_grant::{self, Request};
use crate::ports::tool_vocabulary::Call;

pub const HOOK_ID: &str = "block-repeat-hung-call";
pub const GRANT_KIND: &str = "hung-call";

fn log(text: &str) {
    eprintln!("{HOOK_ID}: {text}");
}

/// The longest run of `tool` that ended in error after outlasting every call
/// the session completed, in milliseconds, if one did.
fn hung_for(finished: &[calls::Finished], tool: &str) -> Option<i64> {
    let longest_completed = finished
        .iter()
        .filter(|call| !call.failed)
        .map(|call| call.millis)
        .max();
    finished
        .iter()
        .filter(|call| call.failed && call.tool == tool)
        .map(|call| call.millis)
        .filter(|millis| match longest_completed {
            Some(longest) => *millis > longest,
            None => true,
        })
        .max()
}

/// The tool whose whole job is to block until something arrives: its long
/// run that ends interrupted is its purpose, not a hang.
const WAIT_TOOL: &str = "wait";

/// The refusal this call earns, or `None` when it passes.
pub fn evaluate(payload: &Value) -> Option<String> {
    let call = Call::of(payload);
    let runs_or_waits =
        call.is_shell() || call.is_eval() || call.is_process() || call.is(WAIT_TOOL);
    if runs_or_waits || call.changes_files() {
        return None;
    }
    let tool = call.kind()?;
    let path = crate::ports::block_idle_answer::locate(payload)?;
    let records = std::fs::read_to_string(&path)
        .map_err(|error| format!("cannot read {}: {error}", path.display()))
        .and_then(|raw| {
            tama_hooks::jsonl::records(&raw)
                .map_err(|cause| format!("cannot read {} as records: {cause}", path.display()))
        });
    let records = match records {
        Ok(records) => records.values,
        Err(cause) => {
            log(&cause);
            return None;
        }
    };
    let millis = hung_for(&calls::finished(&records), &tool)?;
    let request = Request {
        gate: HOOK_ID,
        command: Some(tool.as_str()),
        paths: &[],
    };
    if operator_grant::granted(payload, &request) {
        return None;
    }
    Some(format!(
        "BLOCKED: {HOOK_ID}: `{tool}` already hung in this session: a call of it ran {} s, longer \
         than any call this session completed, and ended without an answer. It will hang again \
         for the same reason; reach the same answer another way now (read the code directly with \
         the search and read tools) and repair the tool's hang as its own defect. {}",
        Duration::from_millis(millis.unsigned_abs()).as_secs(),
        operator_grant::how_to_grant(GRANT_KIND, HOOK_ID)
    ))
}
