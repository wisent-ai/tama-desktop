//! `enforcement/update`: the machine's hook selection changed from the
//! screen, with the refusals the command gives.

use std::path::Path;

use serde_json::Value;

use super::{body, failed, refused, respond, Refused};
use crate::request::reply::{Reply, Request};

pub(super) fn enforcement_update(request: Request, root: &Path, writer: &mut Reply) {
    let Some(body) = body(&request, writer) else {
        return;
    };
    respond(writer, enforcement_change(&body, root));
}

fn enforcement_change(body: &Value, root: &Path) -> Result<Value, Refused> {
    let result = match body.get("mode").and_then(Value::as_str) {
        Some("all") => {
            let has_enabled = body
                .get("enabled")
                .and_then(Value::as_array)
                .is_some_and(|ids| !ids.is_empty());
            if has_enabled {
                return Err(refused("enabled must be empty when mode is \"all\""));
            }
            crate::enforcement::set_all(root)
        }
        // `add` and `remove` change the named hooks against the selection as
        // it is when the change is written, so a screen that read the
        // selection a minute ago does not undo another session's change.
        Some(mode @ ("only" | "add" | "remove")) => {
            let non_empty = || {
                refused(format!(
                    "enabled must be a non-empty array for mode \"{mode}\""
                ))
            };
            let values = body
                .get("enabled")
                .and_then(Value::as_array)
                .ok_or_else(non_empty)?;
            let enabled = values
                .iter()
                .map(Value::as_str)
                .collect::<Option<Vec<_>>>()
                .ok_or_else(|| refused("enabled must contain only hook id strings"))?;
            if enabled.is_empty() {
                return Err(non_empty());
            }
            let enabled: Vec<String> = enabled.into_iter().map(str::to_string).collect();
            match mode {
                "add" => crate::enforcement::add(root, &enabled),
                "remove" => crate::enforcement::remove(root, &enabled),
                _ => crate::enforcement::set_only(root, &enabled),
            }
        }
        _ => Err(crate::enforcement::CommandError::Refused(MODES.to_string())),
    };
    match result {
        Ok(status) => serde_json::to_value(status).map_err(failed),
        // A hook the machine cannot run, an unknown id, an unknown mode and a
        // change that does not apply to the selection as it is are refusals
        // the caller can act on, so the app shows the sentence rather than an
        // internal failure.
        Err(
            error @ (crate::enforcement::CommandError::UnknownHook { .. }
            | crate::enforcement::CommandError::Unusable { .. }
            | crate::enforcement::CommandError::Refused(_)),
        ) => Err(refused(error)),
        Err(error) => Err(failed(error)),
    }
}

/// The modes `enforcement/update` takes, named when a request gives another.
const MODES: &str = "mode must be \"all\", \"only\", \"add\" or \"remove\"";
