//! A product install, update or sync from source run by a Stado that does
//! not carry the repairs Oko records against Stado or against that product.
//!
//! An install run by an installer whose failure the register already
//! describes ends exactly as described, and spends the build it was allowed.
//! Here every open defect of Stado or of the named product whose recorded
//! repair lives in Stado is compared with the running Stado's own revision,
//! and the install waits until Stado itself is updated. Updating Stado is
//! always let through, because it is the way out.
//!
//! Only a repair committed no later than the installed Stado's own revision
//! counts as missing. Such a repair existed when that Stado was cut, so the
//! installer was taken from older source than the register knew of. A repair
//! committed after it did not exist yet: the newest Stado that could be built
//! cannot carry it, and demanding it would refuse every install for as long
//! as Stado's main moves faster than one Stado build takes.

use std::collections::{HashMap, HashSet};
use std::path::{Path, PathBuf};
use std::process::Command;

use crate::assignment::open_defects::OpenDefect;
use tama_core::git::at as git;

use super::super::vocabulary::*;
use super::services::compile_named;

/// The fleet subcommand whose compiles run the product installer.
const PRODUCT_WORD: &str = "product";
/// Where `stado --version` names the source revision it was built from.
const REVISION_MARK: &str = "(rev ";

/// The revision the Stado on PATH was built from.
fn installed_revision(program: &str) -> Result<String, String> {
    let mut command = Command::new(program);
    command.arg("--version");
    let output = stado_wait::output(&mut command)
        .map_err(|error| format!("`{program} --version` could not start: {error}"))?;
    if !output.status.success() {
        return Err(format!(
            "`{program} --version` failed ({}): {}",
            output.status,
            String::from_utf8_lossy(&output.stderr).trim()
        ));
    }
    let text = String::from_utf8_lossy(&output.stdout);
    let start = text
        .find(REVISION_MARK)
        .ok_or_else(|| format!("`{program} --version` names no revision: {}", text.trim()))?
        + REVISION_MARK.len();
    let revision = match text[start..].split_once(')') {
        Some((revision, _)) => revision.trim(),
        None => {
            return Err(format!(
                "`{program} --version` leaves its revision unclosed: {}",
                text.trim()
            ))
        }
    };
    if revision.is_empty() {
        return Err(format!("`{program} --version` names an empty revision"));
    }
    Ok(revision.to_owned())
}

/// Every commit the installed Stado was built from, in one read. Asking git
/// once per recorded repair cost four processes a defect, and with Stado's
/// register that passed the harness's handler limit, so every product
/// command was refused by the harness before this gate answered.
fn ancestors(checkout: &Path, installed: &str) -> Result<HashSet<String>, String> {
    Ok(git(checkout, &["rev-list", installed])?
        .lines()
        .map(str::to_owned)
        .collect())
}

/// One `<full id> <committer time>` line `git show -s --format=%H %ct`
/// printed for `revision`.
fn parsed<'t>(line: &'t str, revision: &str) -> Result<(&'t str, i64), String> {
    let (full, time) = line
        .split_once(' ')
        .ok_or_else(|| format!("git named no commit for {revision}: {}", line.trim()))?;
    let time = time.trim().parse().map_err(|error| {
        format!(
            "git named no commit time for {revision} ({error}): {}",
            line.trim()
        )
    })?;
    Ok((full, time))
}

/// The full id and committer time (seconds since the epoch) of one revision.
fn commit(checkout: &Path, revision: &str) -> Result<(String, i64), String> {
    let text = git(checkout, &["show", "-s", "--format=%H %ct", revision])?;
    let line = text
        .lines()
        .next()
        .ok_or_else(|| format!("git show printed nothing for {revision}"))?;
    let (full, time) = parsed(line, revision)?;
    Ok((full.to_owned(), time))
}

/// Each revision's full id and committer time, or why it cannot be read.
type Known<'a> = HashMap<&'a str, Result<(String, i64), String>>;

/// The full id and committer time of every revision, read in one git call
/// when all of them resolve. Each answer is matched to the revision its id
/// begins with, whatever order git printed them in. When the call fails or
/// leaves a revision unmatched, each revision is read alone, so an error
/// names that revision and no other.
fn commits<'a>(checkout: &Path, revisions: &[&'a str]) -> Known<'a> {
    let mut args = vec!["show", "-s", "--format=%H %ct"];
    args.extend(revisions.iter().copied());
    if let Ok(text) = git(checkout, &args) {
        let answers: Result<Vec<(&str, i64)>, String> = text
            .lines()
            .map(|line| parsed(line, "one of the revisions read together"))
            .collect();
        // An unreadable line leaves the revisions to be read alone below,
        // where its error names the revision it belongs to.
        if let Ok(answers) = answers {
            let matched: Option<Known> = revisions
                .iter()
                .map(|revision| {
                    let (full, time) = answers.iter().find(|(full, _)| {
                        full.starts_with(revision.to_ascii_lowercase().as_str())
                    })?;
                    Some((*revision, Ok(((*full).to_owned(), *time))))
                })
                .collect();
            if let Some(matched) = matched {
                return matched;
            }
        }
    }
    revisions
        .iter()
        .map(|revision| (*revision, commit(checkout, revision)))
        .collect()
}

fn checkout(program: &str) -> PathBuf {
    crate::util::workshop_root().join(program)
}

/// The refusal, or `None` when the command is not a product install of
/// another product or every recorded Stado repair is already installed.
/// `defects` is read only for such an install.
pub(crate) fn installer_refusal(
    program: &str,
    args: &[String],
    defects: impl FnOnce() -> Result<Vec<OpenDefect>, String>,
) -> Option<String> {
    let words = &*VOCABULARY;
    if program != words.fleet_program {
        return None;
    }
    let name = compile_named(program, args)?;
    let mut plain = args.iter().map(String::as_str).filter(|arg| !is_flag(arg));
    if plain.next()? != PRODUCT_WORD {
        return None;
    }
    plain.next()?;
    // The product is one of the remaining words; a flag's value may sit among
    // them, which only widens the set of products whose defects are read.
    let named: Vec<&str> = plain.collect();
    if named.contains(&words.fleet_program.as_str()) {
        return None;
    }
    let installed = match installed_revision(program) {
        Ok(revision) => revision,
        Err(error) => {
            return Some(format!(
                "BLOCKED: `{name}` runs Stado's installer, and which Stado that is cannot be read ({error}); \
                 an unknown installer is not one known to carry the recorded repairs."
            ))
        }
    };
    let defects = match defects() {
        Ok(defects) => defects,
        Err(error) => {
            return Some(format!(
                "BLOCKED: `{name}` runs Stado's installer, and Oko's open defects cannot be read ({error}); \
                 an unreadable register is not an empty one."
            ))
        }
    };
    let stado = checkout(&words.fleet_program);
    // The repairs to compare: each open defect of Stado or of a named
    // product whose recorded repair is a Stado commit.
    let repairs: Vec<(&OpenDefect, &str, &str)> = defects
        .iter()
        .filter(|defect| {
            defect.product == words.fleet_program || named.contains(&defect.product.as_str())
        })
        .filter_map(|defect| {
            let revision = defect.repaired_in.as_deref()?;
            let (repository, commit) = revision.split_once('@')?;
            (repository == words.fleet_program).then_some((defect, revision, commit))
        })
        .collect();
    if repairs.is_empty() {
        return None;
    }
    let mut revisions: Vec<&str> = repairs.iter().map(|(_, _, commit)| *commit).collect();
    revisions.push(&installed);
    let known = commits(&stado, &revisions);
    let ancestry = ancestors(&stado, &installed);
    // Only a repair committed no later than the installed Stado and not
    // contained in it is missing.
    let missing = |commit: &str| -> Result<bool, String> {
        let (full, time) = known[commit].clone()?;
        if ancestry.as_ref().map_err(String::clone)?.contains(&full) {
            return Ok(false);
        }
        let (_, installed_time) = known[installed.as_str()].clone()?;
        Ok(time <= installed_time)
    };
    let pending: Vec<String> = repairs
        .iter()
        .filter_map(|(defect, revision, commit)| match missing(commit) {
            Ok(false) => None,
            Ok(true) => Some(format!("{} ({}): {} - repaired in {revision}", defect.id, defect.product, defect.title)),
            Err(error) => Some(format!(
                "{} ({}): {} - repaired in {revision}, which cannot be compared with the installed Stado ({error})",
                defect.id, defect.product, defect.title
            )),
        })
        .collect();
    if pending.is_empty() {
        return None;
    }
    Some(format!(
        "BLOCKED: `{name}` runs Stado's installer, rev {installed}, and it does not carry these recorded repairs:\n  {}\n\
         Update Stado first (`{} product update {} --surface cli`), then run this install; \
         the register already says how this one would end.",
        pending.join("\n  "),
        words.fleet_program,
        words.fleet_program
    ))
}
