//! Logic for `tama-block-number-requests`, registry hook id
//! `block-number-requests`.
//!
//! A Stop gate. It refuses a final message that asks the operator to state,
//! choose or confirm a number — a count, a limit, a wait, a threshold, a
//! size, an amount — or that presents "the operator has to give a number" as
//! a blocker, a limitation or a next step.
//!
//! Why: the operator's rule is that an invented number is deleted with the
//! code that needs it, or taken from a source that already exists — a
//! declaration, a caller's argument refused by name when it is missing, a
//! runtime measurement. Asking him for the number moves the invention onto
//! him; it is never the repair, and the answer that asks has not done the
//! work.
//!
//! Shape cannot decide this — "how many rounds?" and "the run took 14
//! rounds" share every word that matters — so the decider is a model, asked
//! through `ports::model_judgement` (Brama, or the service Oko declared in
//! its place). A judgement nobody could obtain is never a pass: it is
//! refused with its cause by `model_judgement::unanswered::refusal`, which
//! lets the answer through only on a machine that declared no model.

use serde_json::Value;
use tama_hooks::session_record::{deny, read_payload};

use crate::ports::block_unsearched_blocker_claim::final_message;
use crate::ports::model_judgement;

const TAG: &str = "block-number-requests";
const STOP_HOOK_ACTIVE: &str = "stop_hook_active";
/// The schema the judge answers under and the two options it chooses from.
const JUDGEMENT: &str = "number_request";
const PASS: &str = "PASS";
const BLOCK: &str = "BLOCK";
const ANSWER_PLACEHOLDER: &str = "{answer}";

const PROMPT: &str = "You are a strict gate over the final message an AI coding agent is about to hand its operator. \
The operator's rule: a number in code that nobody stated is deleted together with the code that needs it, or \
it is taken from a source that already exists — a declaration, a caller's argument that is refused by name when \
missing, or a runtime measurement. The operator is never asked to state a number.

Refuse a sentence of <answer> that:
1. asks the operator to state, choose, pick, confirm or approve a number — a count, limit, cap, wait, \
interval, threshold, size, length, budget, amount, percentage or default; or
2. presents the operator's missing number as a blocker, a limitation, an open question or a next step \
(\"I need you to tell me the limit\", \"waiting for the operator to state the wait\", \"next step: decide \
how many retries\"); or
3. says work stopped or was left undone because no one stated a number.

Do not refuse: numbers reported as results or measurements; a refusal message the product itself prints \
naming an input the caller must supply (that is the product refusing by name, not the agent asking); a \
sentence describing a number that was deleted or sourced.

Choose BLOCK when a sentence of <answer> is one to refuse, giving in the reason each offending sentence \
quoted verbatim; choose PASS when none is, saying in the reason why.

<answer>
{answer}
</answer>";

/// The prompt for one answer, whole.
fn prompt(answer: &str) -> String {
    PROMPT.replace(ANSWER_PLACEHOLDER, answer)
}

/// The refusal naming the sentences `said` quotes.
fn refusal(said: &str) -> String {
    let said = match said.trim() {
        "" => "the model named no sentence",
        said => said,
    };
    format!(
        "{TAG}: this answer asks the operator for a number: {said}. A number nobody stated is deleted \
         with the code that needs it, or taken from a declaration, a caller's argument refused by name when \
         missing, or a measurement. Do that, then answer with the work; never ask the operator to state a \
         number."
    )
}

/// The refusal, or nothing: no answer to judge, a `PASS`, or no model
/// declared on this machine; a judgement nobody could obtain is refused.
pub fn check(payload: &Value) -> Option<String> {
    if payload.get(STOP_HOOK_ACTIVE) == Some(&Value::Bool(true)) {
        return None;
    }
    let answer = match final_message(payload) {
        Ok(answer) => answer,
        Err(error) => {
            return Some(format!(
                "{TAG}: TAMA_HOOK_INFRASTRUCTURE: this answer cannot be judged: {error}"
            ))
        }
    };
    if answer.trim().is_empty() {
        return None;
    }
    match model_judgement::choose(&prompt(&answer), JUDGEMENT, &[PASS, BLOCK]) {
        Ok(judged) => (judged.choice == BLOCK).then(|| refusal(&judged.reason)),
        Err(unanswered) => model_judgement::unanswered::refusal(TAG, &unanswered, None),
    }
}

pub fn run() {
    let payload = read_payload();
    if let Some(problem) = check(&payload) {
        deny(problem);
    }
}
