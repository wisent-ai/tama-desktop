//! `tama attestation migrate`: bring every attestation the registries hold
//! into the one ledger, and the comparison `verify` makes between them.
//!
//! The registries were the stores until the ledger existed; each verb now
//! writes both, so what a registry holds from before is brought in once,
//! and again whenever a view gained a record outside the verbs. A record
//! already in the ledger is kept as it is, so migrating twice changes
//! nothing. Build consents stay in Oko and are not copied.

use serde_json::{json, Value};
use tama_hook_tools::attestation::{self as ledger, Attestation};

use super::{views, Kind, Record};

/// The ledger's form of a record a view holds.
fn attestation(record: &Record) -> Result<Attestation, String> {
    let named = |value: Value| match value {
        Value::String(name) => Ok(name),
        other => Err(format!(
            "an attestation record names {other} where a name belongs"
        )),
    };
    Ok(Attestation {
        kind: record.kind.name(),
        subject: record.subject.clone(),
        statement: record.statement.clone(),
        attester: named(json!(record.attester))?,
        scope: record.scope.clone(),
        lifetime: record.lifetime.clone(),
        verification: named(json!(record.verification))?,
        store: record.store.clone(),
        recorded_at: tama_core::clock::iso_now(),
    })
}

/// Whether the ledger already keeps `wanted` (the same claim, subject,
/// view and words).
fn kept(all: &[Attestation], wanted: &Attestation) -> bool {
    all.iter().any(|one| {
        one.kind == wanted.kind
            && one.subject == wanted.subject
            && one.store == wanted.store
            && one.statement == wanted.statement
    })
}

/// Every record a view holds that the ledger lacks, as the ledger would keep it.
fn missing(kind: Option<Kind>) -> Result<Vec<Attestation>, String> {
    let all = ledger::read(None)?;
    views(kind)?
        .iter()
        .filter(|record| record.kind != Kind::Build)
        .map(attestation)
        .filter(|result| !matches!(result, Ok(wanted) if kept(&all, wanted)))
        .collect()
}

/// Bring every record a view holds into the ledger; what was brought.
pub(crate) fn migrate() -> Result<Value, String> {
    ledger::ensure()?;
    let brought = missing(None)?;
    for each in &brought {
        ledger::attest(each.clone())?;
    }
    Ok(json!({ "ledger": ledger::path(), "brought": brought.len(), "attestations": brought }))
}

/// Where the views and the ledger disagree, each named: a record a view
/// holds that the ledger lacks, and a ledger record whose view no longer
/// holds it. Empty when they agree.
pub(crate) fn drift(kind: Option<Kind>) -> Result<Vec<String>, String> {
    let mut found: Vec<String> = missing(kind)?
        .iter()
        .map(|each| format!("{} holds the {} attestation of {} that the ledger lacks; `tama attestation migrate` brings it in", each.store, each.kind, each.subject))
        .collect();
    let in_views: Vec<Attestation> = views(kind)?
        .iter()
        .filter(|record| record.kind != Kind::Build)
        .map(attestation)
        .collect::<Result<_, String>>()?;
    for kept_one in ledger::read(kind.map(Kind::name).as_deref())? {
        if !kept(&in_views, &kept_one) {
            found.push(format!(
                "the ledger keeps the {} attestation of {} that {} no longer holds",
                kept_one.kind, kept_one.subject, kept_one.store
            ));
        }
    }
    Ok(found)
}
