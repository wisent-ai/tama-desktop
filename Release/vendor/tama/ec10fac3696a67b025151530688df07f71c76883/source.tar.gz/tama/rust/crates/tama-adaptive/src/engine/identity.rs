//! What a hook is, to the engine: the source it runs and the digest that
//! identifies it, and the mode its tier and phase put it in.
//!
//! Split out of `engine/mod.rs`, which had grown past the
//! three-hundred-line limit; the outcome recording stays there.

use std::fs;

use sha2::{Digest, Sha256};

use super::lookup::{command_for, source_for};
use super::{Engine, SourceIdentity};
use crate::util::shell_words;

/// A source the engine could not identify, and why.
fn unverifiable(hook_id: String, command: String, cause: String) -> SourceIdentity {
    SourceIdentity {
        hook_id,
        command: Some(command),
        source_path: None,
        digest: None,
        verifiable: false,
        unverifiable: Some(cause),
    }
}

impl Engine {
    pub fn source_identity(&self, hook_id: &str) -> SourceIdentity {
        let id = hook_id.to_string();
        let command = command_for(&self.registry_value, &id);
        let Some(command) = command else {
            return SourceIdentity {
                hook_id: id,
                command: None,
                source_path: None,
                digest: None,
                verifiable: false,
                unverifiable: Some("the registry names no command for this hook".to_string()),
            };
        };
        let source_path = match source_for(&command, &self.registry_path) {
            Ok(source_path) => source_path,
            Err(cause) => return unverifiable(id, command, cause),
        };
        let mut hasher = Sha256::new();
        hasher.update(command.as_bytes());
        if let Some(path) = &source_path {
            // A source that cannot be examined or read is unverifiable with
            // its cause; only one that does not exist falls to the command.
            match tama_core::presence::present(path) {
                Ok(true) => {
                    let bytes = match fs::read(path) {
                        Ok(bytes) => bytes,
                        Err(error) => {
                            let cause =
                                format!("source {} cannot be read: {error}", path.display());
                            return unverifiable(id, command, cause);
                        }
                    };
                    hasher.update(b"\0");
                    hasher.update(bytes);
                    return SourceIdentity {
                        hook_id: id,
                        command: Some(command),
                        source_path: Some(path.to_string_lossy().to_string()),
                        digest: Some(format!("{:x}", hasher.finalize())),
                        verifiable: true,
                        unverifiable: None,
                    };
                }
                Ok(false) => {}
                Err(error) => return unverifiable(id, command, error.to_string()),
            }
        }
        // An operand that names a file by its extension, and that no lookup
        // found, is a script the command needs and does not have.
        let missing_script = shell_words(&command)
            .iter()
            .any(|word| std::path::Path::new(word).extension().is_some());
        if missing_script {
            let cause = "the command names a script that is not there".to_string();
            return unverifiable(id, command, cause);
        }
        SourceIdentity {
            hook_id: id,
            command: Some(command),
            source_path: None,
            digest: Some(format!("{:x}", hasher.finalize())),
            verifiable: true,
            unverifiable: None,
        }
    }

    /// `effectiveMode(hookId)`: a tier that does not enforce its verdict
    /// warns; one that is not demotable enforces; a demotable one warns once
    /// its recovered record put it in the warning phase, and says why when
    /// that record cannot be read.
    pub fn effective_mode(&self, hook_id: &str) -> Result<&'static str, String> {
        let tier = self.tier_of(hook_id);
        if !tier.enforce_verdict {
            return Ok("warn");
        }
        if !tier.demotable {
            return Ok("enforce");
        }
        let snapshot = self.store.snapshot(Some(hook_id))?;
        Ok(
            match snapshot.get("phase").and_then(serde_json::Value::as_str) {
                Some(crate::state::phase::WARNING) => "warn",
                _ => "enforce",
            },
        )
    }
}
