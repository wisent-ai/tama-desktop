//! Logic for `tama-block-browser-usage`, registry hook
//! `block-browser-usage`: no browser is driven from an agent session.
//!
//! A browser runs through Weles, and its runtime executes on a Stado target
//! carrying a Weles placement policy. Everything else is direct use: a
//! browser tool, a mounted `xd://browser` device, or browser control hidden
//! inside a general execution tool. Closing or inspecting a direct-browser tab
//! is still direct use.
//!
//! Three exemptions, each written after a real refusal:
//!
//!   * One non-compound, built-in Git operation is repository maintenance,
//!     even when the repository path contains `weles` or `browser`.
//!   * `weles-chromium` and `weles-firefox` are repository names, not
//!     runtimes: the checkouts holding Weles's patched browser sources.
//!     Only the name is neutralised, so a path *into* one of them — a browser
//!     built under its output directory — is still refused. A path check
//!     alone refuses a compound `git -C <that repo> status` and a recorded
//!     test justification that merely quotes a request for this repair.
//!   * `tab.`, `page.` and `browser.` are a driver only when something is
//!     called on them. Matching them wherever a dot followed refuses every
//!     English sentence ending on one of those words and every file called
//!     `page.js` or `<name>-tab.json`, a commit message included.
//!   * A name inside a quoted argument or a here-document body is text, not a
//!     runtime: a declaration whose sentence names an upstream engine is not
//!     a call to it. The payload is read through the shared
//!     [`crate::ports::shell_text`] reader, which blanks quoted text, drops a
//!     body handed to a file, and keeps a body handed to an interpreter.
//!
//! Weles on this computer runs with the user's consent, given in the current
//! conversation and recorded as the Tama session capability
//! `{ "tool": "weles", "actions": ["local-browser"] }` (see [`consent`]).
//! Without it Weles runs only on a Stado-placed host, as before; the consent
//! never opens a browser tool or a direct engine.
//!
//! A direct engine runs on this computer only on the operator's own word for
//! one exact shell command (`tama justify record --kind browser`, read by
//! [`crate::ports::operator_grant`]): he lifted the Weles-only rule for the
//! LSI2 checks and told the agent to run Playwright here. A grant covers the
//! command it quotes and nothing else; a browser tool or device stays refused.
//!
//! The shell printed its refusal on stdout and failed with `false`; that is
//! kept, because it is the refusal the operator has been reading.

mod consent;
mod placement;
mod vocabulary;

use serde_json::Value;
use tama_hooks::session_record::read_payload;

use crate::ports::check_numeric_literals_payload::path_texts;
use crate::ports::operator_grant::{self, Request};
use crate::ports::shell_text;
use crate::ports::tool_vocabulary::{Call, BASH_TOOLS, EVAL_TOOLS, HUB_TOOLS, WHOLE_FILE_TOOLS};
use vocabulary::{
    APPLICATION_KEY, ARGS_KEY, BROWSER_DEVICE, BROWSER_RUNTIME, BROWSER_SOURCE_REPOSITORIES,
    BROWSER_TOOL, COMPOUND, NEUTRAL_NAME, REFUSAL, REPL_DEVICE, SAFE_GIT, START_OPERATION,
    WELES_RUNTIME,
};

pub const HOOK_ID: &str = "block-browser-usage";
pub const GRANT_KIND: &str = "browser";

fn every_string(input: &Value, cwd: Option<&str>) -> String {
    let texts = match path_texts(input, cwd) {
        Ok(texts) => texts,
        Err(error) => tama_hooks::session_record::refuse(&format!(
            "TAMA_HOOK_INFRASTRUCTURE: block-browser-usage: {error}"
        )),
    };
    texts
        .into_iter()
        .map(|(_, text)| text)
        .collect::<Vec<_>>()
        .join("\n")
}

/// `[.application, (.args // [])[]] | join("\n")`.
fn process_text(input: &Value) -> String {
    let mut parts: Vec<String> = Vec::new();
    if let Some(Value::String(application)) = input.get(APPLICATION_KEY) {
        parts.push(application.clone());
    }
    if let Some(Value::Array(args)) = input.get(ARGS_KEY) {
        for arg in args {
            if let Value::String(text) = arg {
                parts.push(text.clone());
            }
        }
    }
    parts.join("\n")
}

/// Whether this payload drives a browser outside Weles's placement.
pub fn is_direct_browser_use(payload: &Value) -> bool {
    judge(payload, consent::local_weles_consented())
}

/// The decision, with the user's consent to a local Weles browser given.
fn judge(payload: &Value, local_weles_consented: bool) -> bool {
    let call = Call::of(payload);
    let tool = call.kind().unwrap_or_default();
    let path = match call.path() {
        Some(path) => path.to_lowercase(),
        None => String::new(),
    };
    if BROWSER_TOOL.is_match(&tool) || BROWSER_DEVICE.is_match(&path) {
        return true;
    }

    // What the call can actually run: quoted text blanked, here-document
    // bodies dropped unless an interpreter receives them, and an
    // interpreter's quoted program read as a command of its own.
    let command = match call.command() {
        Some(command) => command.to_lowercase(),
        None => String::new(),
    };
    let executable = match (call.input(), tool.as_str()) {
        (None, _) => String::new(),
        (Some(_), found) if BASH_TOOLS.contains(&found) => shell_text::effective_command(&command),
        (Some(_), found) if EVAL_TOOLS.contains(&found) => match call.code() {
            Some(code) => shell_text::effective_code(&code.to_lowercase()),
            None => String::new(),
        },
        (Some(input), found) if HUB_TOOLS.contains(&found) => {
            if call.operation().as_deref() == Some(START_OPERATION) {
                process_text(input).to_lowercase()
            } else {
                String::new()
            }
        }
        (Some(input), found) if WHOLE_FILE_TOOLS.contains(&found) => {
            if REPL_DEVICE.is_match(&path) {
                every_string(input, call.session_cwd()).to_lowercase()
            } else {
                String::new()
            }
        }
        _ => String::new(),
    };
    if executable.is_empty() {
        return false;
    }

    let is_bash = BASH_TOOLS.contains(&tool.as_str());
    if is_bash && SAFE_GIT.is_match(&command) && !COMPOUND.is_match(&command) {
        return false;
    }

    let judged = BROWSER_SOURCE_REPOSITORIES
        .replace_all(&executable, NEUTRAL_NAME)
        .into_owned();
    if !BROWSER_RUNTIME.is_match(&judged) && !WELES_RUNTIME.is_match(&judged) {
        return false;
    }
    // A Weles run is allowed with consent or on a placed host; a direct
    // engine in the same command is not, whichever of the two holds.
    if BROWSER_RUNTIME.is_match(&judged) {
        return true;
    }
    if local_weles_consented {
        return false;
    }
    let placed = tama_hooks::host::name()
        .and_then(|host| placement::allows_weles_runtime(&placement::registry_path(), &host));
    match placed {
        Ok(placed) => !placed,
        Err(error) => tama_hooks::session_record::refuse(&format!(
            "TAMA_HOOK_INFRASTRUCTURE: block-browser-usage cannot tell whether this host may run \
             Weles: {error}"
        )),
    }
}

/// Whether the operator's recorded word covers this exact shell command.
fn operator_granted(payload: &Value) -> bool {
    let call = Call::of(payload);
    if !call.is_shell() {
        return false;
    }
    let Some(command) = call.command() else {
        return false;
    };
    let request = Request {
        gate: HOOK_ID,
        command: Some(command),
        paths: &[],
    };
    operator_grant::granted(payload, &request)
}

pub fn run() {
    let payload = read_payload();
    if is_direct_browser_use(&payload) && !operator_granted(&payload) {
        let mut refusal = REFUSAL.join("\n");
        refusal.push('\n');
        refusal.push_str(&operator_grant::how_to_grant(GRANT_KIND, HOOK_ID));
        tama_hooks::session_record::refuse(&refusal);
    }
}
