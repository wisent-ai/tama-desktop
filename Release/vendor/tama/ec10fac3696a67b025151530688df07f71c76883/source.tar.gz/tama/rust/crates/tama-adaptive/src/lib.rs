//! tama-adaptive: threshold-free adaptive engine, state store, doctor.

pub mod bridge;
pub mod doctor;
pub mod engine;
pub mod segments;
pub mod state;
pub mod telemetry;

mod util;
