//! What was already spent.
//!
//! The registry holds authorizations that are open right now, and `close`
//! removes them; a ration cannot be counted from a file that forgets. So every
//! recorded intent is also appended here, and this is what the day's count is
//! read from. Closing an entry ends the authorization and does not give the
//! build back.

use std::path::{Path, PathBuf};

use serde_json::{json, Value};

pub const FILE: &str = "build_restart_ledger.json";
/// Retention for ordinary intents. Approved exceptions remain as audit evidence
/// and prevent the same captured message from granting another exception.
const KEEP_SECONDS: u64 = 30 * 24 * 60 * 60;
const RECORDED: &str = "recorded";
const AT: &str = "recorded_at_epoch";
const NOT_STARTED: &str = "not_started";

pub fn file(home: &Path) -> PathBuf {
    home.join(".shared-hooks").join(FILE)
}

fn rows(path: &Path) -> Result<Vec<Value>, String> {
    let text = match std::fs::read_to_string(path) {
        Ok(text) => text,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(Vec::new()),
        Err(error) => return Err(format!("{} cannot be read: {error}", path.display())),
    };
    if text.trim().is_empty() {
        return Ok(Vec::new());
    }
    let document: Value = serde_json::from_str(&text)
        .map_err(|error| format!("{} is not a readable ledger: {error}", path.display()))?;
    let Some(rows) = document.get(RECORDED).and_then(Value::as_array) else {
        return Err(format!(
            "{} carries no {RECORDED} list, so nothing here says what was spent",
            path.display()
        ));
    };
    // A row without its moment cannot be placed in or out of a window: read
    // as the epoch, it fell outside every window and spent nothing.
    if let Some(row) = rows
        .iter()
        .find(|row| row.get(AT).and_then(Value::as_u64).is_none())
    {
        return Err(format!(
            "{} records an intent without a numeric {AT}, so it cannot be counted: {row}",
            path.display()
        ));
    }
    Ok(rows.clone())
}

/// When a row was recorded; [`rows`] refuses a ledger with a row lacking it.
fn moment(row: &Value) -> u64 {
    row.get(AT)
        .and_then(Value::as_u64)
        .expect("rows() refuses every row without a numeric moment")
}

/// Every intent of this kind recorded inside the window ending now.
pub fn spent(path: &Path, kind: &str, at: u64, window: u64) -> Result<Vec<Value>, String> {
    let since = at.saturating_sub(window);
    Ok(rows(path)?
        .into_iter()
        .filter(|row| row.get("kind").and_then(Value::as_str) == Some(kind))
        .filter(|row| moment(row) >= since)
        .collect())
}

/// The revision the last recorded build of this target carried, which is what
/// the next build's change is measured against. A build closed as never
/// started built nothing, so it is not that measure.
pub fn last_revision(path: &Path, target: &str) -> Result<Option<String>, String> {
    let mut mine: Vec<Value> = rows(path)?
        .into_iter()
        .filter(|row| row.get("kind").and_then(Value::as_str) == Some("build"))
        .filter(|row| row.get("target").and_then(Value::as_str) == Some(target))
        .filter(|row| row.get(NOT_STARTED).is_none())
        .collect();
    mine.sort_by_key(moment);
    Ok(mine
        .last()
        .and_then(|row| row.get("revision"))
        .and_then(Value::as_str)
        .map(str::to_string))
}

/// One operator message may authorize a batch, but never a second build of
/// the same product. Closing the open registry entry does not erase consent use.
pub fn approval_used(path: &Path, approval: &Value) -> Result<bool, String> {
    Ok(rows(path)?.iter().any(|row| {
        row.get("user_approval").is_some_and(|used| {
            used.get("session_id") == approval.get("session_id")
                && used.get("turn_digest") == approval.get("turn_digest")
                && used.get("target") == approval.get("target")
        })
    }))
}

pub fn approvals(path: &Path) -> Result<Vec<Value>, String> {
    Ok(rows(path)?
        .into_iter()
        .filter(|row| row.get("user_approval").is_some())
        .collect())
}

/// Marks the newest recorded build of this target as never started, with the
/// refusal that stopped it. The row stays, so the ration still counts it.
pub fn mark_not_started(path: &Path, target: &str, refusal: &str) -> Result<String, String> {
    let mut all = rows(path)?;
    let newest = all
        .iter_mut()
        .filter(|row| row.get("kind").and_then(Value::as_str) == Some("build"))
        .filter(|row| row.get("target").and_then(Value::as_str) == Some(target))
        .max_by_key(|row| moment(row))
        .ok_or_else(|| {
            format!("no build of {target} is recorded, so none can be closed as never started")
        })?;
    newest[NOT_STARTED] = json!(refusal);
    let revision = newest["revision"]
        .as_str()
        .ok_or_else(|| format!("the newest recorded build of {target} carries no revision"))?
        .to_string();
    let text = serde_json::to_string_pretty(&json!({ RECORDED: all }))
        .map_err(|error| format!("cannot serialize build ledger: {error}"))?;
    crate::justify::registry::write_atomically(path, &format!("{text}\n"))?;
    Ok(revision)
}

/// The revision the recorded build of this target before `revision` carried:
/// where the commits a build carried begin. A build closed as never started
/// built nothing and is skipped, like in [`last_revision`].
pub fn built_before(path: &Path, target: &str, revision: &str) -> Result<Option<String>, String> {
    let mut mine: Vec<Value> = rows(path)?
        .into_iter()
        .filter(|row| row.get("kind").and_then(Value::as_str) == Some("build"))
        .filter(|row| row.get("target").and_then(Value::as_str) == Some(target))
        .filter(|row| row.get(NOT_STARTED).is_none())
        .collect();
    mine.sort_by_key(moment);
    let carried = |row: &Value| row.get("revision").and_then(Value::as_str) == Some(revision);
    let before = mine.iter().position(carried).unwrap_or(mine.len());
    Ok(mine[..before]
        .iter()
        .rev()
        .filter_map(|row| row.get("revision").and_then(Value::as_str))
        .find(|earlier| *earlier != revision)
        .map(str::to_string))
}

/// Records on the build of this target that carried `revision` how it
/// failed. The row keeps counting against the ration; `false` when no build
/// of that revision is recorded.
pub fn mark_failed(
    path: &Path,
    target: &str,
    revision: &str,
    failure: &str,
) -> Result<bool, String> {
    let mut all = rows(path)?;
    let Some(row) = all
        .iter_mut()
        .filter(|row| row.get("kind").and_then(Value::as_str) == Some("build"))
        .filter(|row| row.get("target").and_then(Value::as_str) == Some(target))
        .filter(|row| row.get("revision").and_then(Value::as_str) == Some(revision))
        .max_by_key(|row| moment(row))
    else {
        return Ok(false);
    };
    row["failed"] = json!(failure);
    let text = serde_json::to_string_pretty(&json!({ RECORDED: all }))
        .map_err(|error| format!("cannot serialize build ledger: {error}"))?;
    crate::justify::registry::write_atomically(path, &format!("{text}\n"))?;
    Ok(true)
}

/// Appends one spent intent and drops rows past the keeping period.
pub fn append(path: &Path, entry: &Value) -> Result<(), String> {
    let at = entry
        .get(AT)
        .and_then(Value::as_u64)
        .ok_or_else(|| format!("an intent without a numeric {AT} cannot be recorded: {entry}"))?;
    let mut kept: Vec<Value> = rows(path)?
        .into_iter()
        .filter(|row| row.get("user_approval").is_some() || moment(row) + KEEP_SECONDS >= at)
        .collect();
    kept.push(entry.clone());
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)
            .map_err(|error| format!("{} cannot be created: {error}", parent.display()))?;
    }
    let document = json!({ RECORDED: kept });
    let text = serde_json::to_string_pretty(&document)
        .map_err(|error| format!("cannot serialize build ledger: {error}"))?;
    crate::justify::registry::write_atomically(path, &format!("{text}\n"))
}

/// When enough recorded intents have left the inclusive window to admit one
/// more. A lowered limit or approved exceptions can leave more than the limit
/// in the window; expiration of only the oldest entry then frees no slot.
pub fn frees_in_minutes(spent: &mut [Value], allowed: u64, at: u64, window: u64) -> Option<u64> {
    if allowed == 0 {
        return None;
    }
    if (spent.len() as u64) < allowed {
        return Some(0);
    }
    let index = spent.len() - allowed as usize;
    let (_, last_to_expire, _) = spent.select_nth_unstable_by_key(index, moment);
    let available_at = moment(last_to_expire)
        .saturating_add(window)
        .saturating_add(1);
    Some(available_at.saturating_sub(at).div_ceil(60))
}
