//! A stopped session's uncommitted work, staged by the session that took
//! over its item. When session B leads an Oko task session A held, and A no
//! longer runs, nobody but B can commit what A wrote: `tama stage --session B
//! --with A --task T` reads every path A edited, not only the paths B edited
//! too. Oko must show T claimed by B with A in its claim history, and no
//! recorded agent process of A may run; while A runs, its edits are its own
//! to commit or hand over, so the staging is refused naming its process.

use std::process::Command;

use serde::Deserialize;

use crate::assignment::rules::{oko_cli, oko_installed};
use crate::ports::owner_consent::{exists, recorded_holders};

#[derive(Deserialize)]
struct Shown {
    current: Current,
}

#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
struct Current {
    claimed_by: Option<String>,
    /// Absent while the task's claim never moved.
    claim_history: Option<Vec<Claim>>,
}

#[derive(Deserialize)]
struct Claim {
    from: String,
    to: String,
    at: String,
}

/// Which of `named` held `task` before `session`, which Oko shows leading
/// it now; refused when Oko cannot be read, another session leads the task,
/// or none of `named` held it.
pub(super) fn predecessors(
    task: &str,
    session: &str,
    named: &[String],
) -> Result<Vec<String>, String> {
    let program = oko_cli();
    if !oko_installed() {
        return Err(format!(
            "--task {task}: {program} is not installed, so who leads the task cannot be read"
        ));
    }
    let shown_command = format!("{program} tasks show {task} --json");
    let mut command = Command::new(&program);
    command.args(["tasks", "show", task, "--json"]);
    let output = stado_wait::output(&mut command)
        .map_err(|cause| format!("{shown_command} did not run: {cause}"))?;
    let shown: Shown = serde_json::from_slice(&output.stdout).map_err(|cause| {
        format!(
            "{shown_command} exited {} without a task ({cause}): {}",
            output.status,
            String::from_utf8_lossy(&output.stderr).trim()
        )
    })?;
    match shown.current.claimed_by.as_deref() {
        Some(leader) if leader == session => {}
        Some(leader) => {
            return Err(format!(
                "--task {task}: Oko shows the task claimed by {leader}, not by {session}; only the session leading it stages its predecessor's work"
            ))
        }
        None => return Err(format!("--task {task}: Oko shows the task claimed by nobody, not by {session}")),
    }
    let history = shown.current.claim_history.unwrap_or_default();
    let held: Vec<String> = named
        .iter()
        .filter(|author| history.iter().any(|claim| &claim.from == *author))
        .cloned()
        .collect();
    if held.is_empty() {
        let moves: Vec<String> = history
            .iter()
            .map(|claim| format!("{} -> {} at {}", claim.from, claim.to, claim.at))
            .collect();
        return Err(format!(
            "--task {task}: none of the sessions named with --with ({}) held the task; its claim history is [{}]",
            named.join(", "),
            moves.join("; ")
        ));
    }
    Ok(held)
}

/// Refused naming the process while any recorded agent process of `session`
/// runs: a running session's edits are its own.
pub(super) fn stopped(session: &str, task: &str) -> Result<(), String> {
    for (pid, (agent, holder)) in recorded_holders()? {
        if holder == session && exists(pid)? {
            return Err(format!(
                "--task {task}: session {session} still runs ({agent}, process {pid}); its edits are its own until it ends, so ask it to commit them or to hand them over"
            ));
        }
    }
    Ok(())
}
