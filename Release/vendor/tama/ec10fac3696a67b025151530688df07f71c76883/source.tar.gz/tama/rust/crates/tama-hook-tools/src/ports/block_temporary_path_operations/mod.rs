//! Decision half of `tama hook block-temporary-path-operations` (registry
//! hook `block-temporary-path-operations`).
//!
//! Refuses a read, edit, write, notebook change or save whose target lands in a
//! temporary directory. A path is judged three ways — as written, resolved
//! against the process directory, and with symlinks resolved — because `/tmp`
//! is a symlink into `/private/tmp` on this platform and either spelling has to
//! be caught. A write is also refused when it lands in a checkout's scratch
//! heap — an existing top-level directory holding no tracked file that git
//! does not ignore — naming the checkout's `.build/` instead ([`scratch_root`]).
//!
//! Translation notes: `re.IGNORECASE` is not used here, but Python's
//! non-multiline `$` accepts a single trailing newline, so each `$` is written
//! `\n?\z`. `str.casefold` has no std equivalent; `to_lowercase` stands in, and
//! the two differ only for characters that the `[^a-z]` filter drops anyway.

mod scratch_root;

use std::collections::BTreeSet;

use regex::Regex;
use serde_json::Value;
use tama_hooks::session_record::{deny_tool_use, read_payload};

use super::pystr;
use super::python_stdlib::{
    abspath, commonpath, expanduser, expandvars, normpath, realpath, urlsplit_parts,
};
use super::tool_vocabulary::Call;

/// The payload fields a tool names its target path in, case and separators
/// folded as the reader folds them: the harnesses' own field names.
const PATH_KEYS: &[&str] = &[
    PATH_KEY,
    FILE_PATH_KEY,
    NOTEBOOK_PATH_KEY,
    SAVE_PATH_KEY,
    OUTPUT_PATH_KEY,
    TARGET_PATH_KEY,
    DESTINATION_KEY,
    FILENAME_KEY,
];
const PATH_KEY: &str = "path";
const FILE_PATH_KEY: &str = "filepath";
const NOTEBOOK_PATH_KEY: &str = "notebookpath";
const SAVE_PATH_KEY: &str = "savepath";
const OUTPUT_PATH_KEY: &str = "outputpath";
const TARGET_PATH_KEY: &str = "targetpath";
const DESTINATION_KEY: &str = "destination";
const FILENAME_KEY: &str = "filename";
/// Where a patch tool's payload carries the patch text, in both spellings.
const PATCH_KEYS: &[&str] = &[INPUT_KEY, PATCH_KEY];
const INPUT_KEY: &str = "input";
const PATCH_KEY: &str = "patch";
/// The payload fields that hold a list of targets.
const COLLECTION_KEYS: &[&str] = &[EDITS_KEY, FILES_KEY, TARGETS_KEY, OPERATIONS_KEY];
const EDITS_KEY: &str = "edits";
const FILES_KEY: &str = "files";
const TARGETS_KEY: &str = "targets";
const OPERATIONS_KEY: &str = "operations";
/// The envelopes a patch names its file in, from the one declaration in
/// [`super::patch_envelope`], each read as a whole line.
fn patch_patterns() -> Vec<String> {
    vec![
        format!("{}\\n?\\z", super::patch_envelope::BRACKET_HEADER),
        super::patch_envelope::file_header(),
        super::patch_envelope::DIFF_HEADER.to_string(),
    ]
}
const FIXED_TEMP_ROOTS: &[&str] = &[
    "/tmp",
    "/private/tmp",
    "/var/tmp",
    "/private/var/tmp",
    "/var/folders",
    "/private/var/folders",
];
const TARGET_GROUP: &str = "target";
const TMPDIR_ENV: &str = "TMPDIR";
const FILE_SCHEME: &str = "file";
const LOCALHOST: &str = "localhost";
/// Any path component spelled `tmp` marks the path temporary, wherever it sits.
const TMP_PART: &str = "tmp";
/// An embedded NUL cannot reach the filesystem, so such a path is not judged.
const NUL: char = '\0';

/// `re.sub(r"[^a-z]", "", str(key).casefold())`.
fn normalized_key(key: &str) -> String {
    key.to_lowercase()
        .chars()
        .filter(char::is_ascii_lowercase)
        .collect()
}

fn patch_paths(patterns: &[Regex], text: &str, found: &mut Vec<String>) -> Result<(), String> {
    let hashline = super::write_payload::hashline::touched_paths(text)?;
    if !hashline.is_empty() {
        found.extend(hashline);
        return Ok(());
    }
    for raw_line in pystr::splitlines(text) {
        let line = pystr::strip(raw_line);
        for pattern in patterns {
            let Some(caps) = pattern.captures(line) else {
                continue;
            };
            if let Some(target) = caps.name(TARGET_GROUP) {
                found.push(pystr::strip(target.as_str()).to_string());
            }
            break;
        }
    }
    Ok(())
}

/// The `if / elif / elif` chain of the Python, kept in that order: a key that
/// names a path wins over one that names a patch, and anything else is only
/// descended into when the key names a collection or the value is one. A
/// collection that lists its targets as bare strings (`files: ["<path>"]`)
/// names each of them as a path.
fn candidate_paths(
    patterns: &[Regex],
    value: &Value,
    found: &mut Vec<String>,
) -> Result<(), String> {
    match value {
        Value::Object(map) => {
            for (key, item) in map {
                let name = normalized_key(key);
                let name = name.as_str();
                match item.as_str() {
                    Some(text) if PATH_KEYS.contains(&name) => found.push(text.to_string()),
                    Some(text) if PATCH_KEYS.contains(&name) => patch_paths(patterns, text, found)?,
                    _ if COLLECTION_KEYS.contains(&name) => {
                        if let Value::Array(items) = item {
                            found
                                .extend(items.iter().filter_map(Value::as_str).map(str::to_string));
                        }
                        candidate_paths(patterns, item, found)?
                    }
                    _ if item.is_object() || item.is_array() => {
                        candidate_paths(patterns, item, found)?
                    }
                    _ => {}
                }
            }
        }
        Value::Array(items) => {
            for item in items {
                candidate_paths(patterns, item, found)?;
            }
        }
        _ => {}
    }
    Ok(())
}

/// A local path, or `None` for a URL that does not name one.
fn filesystem_path(path: &str) -> Option<String> {
    let (scheme, netloc, parsed) = urlsplit_parts(path);
    if scheme.is_empty() {
        return Some(path.to_string());
    }
    if scheme != FILE_SCHEME || !(netloc.is_empty() || netloc == LOCALHOST) {
        return None;
    }
    Some(parsed)
}

/// The three spellings of one path the guard checks: as written, made absolute,
/// and with symlinks resolved. A relative path whose directory cannot be read
/// is an error naming it, not a path under `/`.
fn normalized_paths(path: &str) -> Result<Vec<String>, String> {
    let Some(local) = filesystem_path(path) else {
        return Ok(Vec::new());
    };
    if local.is_empty() || local.contains(NUL) {
        return Ok(Vec::new());
    }
    let expanded = expandvars(&expanduser(&local));
    let absolute = abspath(&expanded)?;
    Ok(vec![
        expanded.replace('\\', "/"),
        normpath(&absolute),
        realpath(&absolute)?,
    ])
}

fn roots() -> Result<Vec<String>, String> {
    let mut values: Vec<String> = FIXED_TEMP_ROOTS
        .iter()
        .map(|root| root.to_string())
        .collect();
    if let Ok(configured) = std::env::var(TMPDIR_ENV) {
        if !configured.is_empty() {
            values.extend(normalized_paths(&configured)?);
        }
    }
    let mut out: Vec<String> = Vec::new();
    for value in values {
        if value.is_empty() {
            continue;
        }
        let normalized = normpath(&value);
        if !out.contains(&normalized) {
            out.push(normalized);
        }
    }
    Ok(out)
}

/// `os.path.commonpath((path, root)) == root`, with the `ValueError` raised on
/// a mixed absolute/relative pair meaning "not under".
fn under(path: &str, root: &str) -> bool {
    commonpath(path, root).is_some_and(|common| common == root)
}

fn temporary(path: &str, temp_roots: &[String]) -> Result<bool, String> {
    for candidate in normalized_paths(path)? {
        let posix = candidate.replace('\\', "/");
        let named_tmp = posix
            .split('/')
            .filter(|part| !part.is_empty() && *part != ".")
            .any(|part| part.to_lowercase() == TMP_PART);
        if named_tmp {
            return Ok(true);
        }
        let normalized = normpath(&candidate);
        if temp_roots.iter().any(|root| under(&normalized, root)) {
            return Ok(true);
        }
    }
    Ok(false)
}

pub fn run() {
    let payload = read_payload();
    let call = Call::of(&payload);
    let Some(tool_input) = call.input() else {
        return;
    };

    let patterns: Vec<Regex> = patch_patterns()
        .iter()
        .map(|source| Regex::new(source).expect(source))
        .collect();
    let mut candidates: Vec<String> = Vec::new();
    if let Err(cause) = candidate_paths(&patterns, tool_input, &mut candidates) {
        deny_tool_use(&format!(
            "BLOCKED: temporary-path targets cannot be resolved: {cause}"
        ));
    }

    let temp_roots = match roots() {
        Ok(roots) => roots,
        Err(error) => deny_tool_use(&format!(
            "BLOCKED: the temporary directories cannot be resolved, so no target can be judged against them: {error}"
        )),
    };
    let mut blocked: BTreeSet<String> = BTreeSet::new();
    for path in &candidates {
        match temporary(path, &temp_roots) {
            Ok(true) => {
                blocked.insert(path.clone());
            }
            Ok(false) => {}
            Err(error) => deny_tool_use(&format!(
                "BLOCKED: {path} cannot be resolved, so whether it is a temporary path is not known: {error}"
            )),
        }
    }
    if !blocked.is_empty() {
        let listed = blocked.into_iter().collect::<Vec<_>>().join(" | ");
        deny_tool_use(&format!(
            "BLOCKED: Temporary-path Read/Edit/Write/Save operations are not allowed: {listed}"
        ));
    }
    if call.is_write() {
        scratch_root::refuse(&candidates);
    }
}
