//! The judge's verdict on each command a write declares.
//!
//! The judge answers one object under a strict JSON Schema
//! (`model_judgement::object`): a list of verdicts, each naming one of the
//! commands it was shown by its name, choosing PASS or BLOCK and giving its
//! reason. An answer that leaves a command without a verdict is no answer.

use serde::Deserialize;
use serde_json::json;

use super::{repository, Command, Verdict};
use crate::ports::model_judgement::{self, Judgement};

const PROMPT: &str = include_str!("judge-prompt.md");
/// The schema the judge answers under and the two options each command's
/// verdict chooses from.
const JUDGEMENT: &str = "command_generality";
const PASS: &str = "PASS";
const BLOCK: &str = "BLOCK";

/// The judge's verdict on one command, by the name it was given.
#[derive(Deserialize)]
struct Judged {
    name: String,
    choice: String,
    reason: String,
}

/// The judge's answer: one verdict per command it was shown.
#[derive(Deserialize)]
struct Judgements {
    verdicts: Vec<Judged>,
}

/// Why `answer` does not judge every one of `names` as PASS or BLOCK, if it
/// does not.
fn incomplete(answer: &Judgements, names: &[&str]) -> Result<(), String> {
    if let Some(judged) = answer
        .verdicts
        .iter()
        .find(|judged| judged.choice != PASS && judged.choice != BLOCK)
    {
        return Err(format!(
            "gives command {} the verdict {:?}, neither {PASS} nor {BLOCK}",
            judged.name, judged.choice
        ));
    }
    match names
        .iter()
        .find(|name| !answer.verdicts.iter().any(|judged| judged.name == **name))
    {
        Some(name) => Err(format!("gives no verdict for command {name}")),
        None => Ok(()),
    }
}

/// The judge's verdict on each command, or why there is none.
pub fn judge(file_path: &str, found: &[Command]) -> Result<Vec<Verdict>, String> {
    let listed = found
        .iter()
        .map(|command| {
            format!(
                "<command name=\"{}\">\n{}\n</command>",
                command.name, command.declaration
            )
        })
        .collect::<Vec<_>>()
        .join("\n");
    let prompt = PROMPT
        .replace("{path}", file_path)
        .replace("{repository}", &repository(file_path)?)
        .replace("{commands}", &listed);
    let names: Vec<&str> = found.iter().map(|command| command.name.as_str()).collect();
    let schema = json!({
        "type": "object",
        "properties": {
            "verdicts": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "name": { "type": "string", "enum": names },
                        "choice": { "type": "string", "enum": [PASS, BLOCK] },
                        "reason": { "type": "string" },
                    },
                    "required": ["name", "choice", "reason"],
                    "additionalProperties": false,
                },
            },
        },
        "required": ["verdicts"],
        "additionalProperties": false,
    });
    let check = |answer: &Judgements| incomplete(answer, &names);
    let answer = match model_judgement::object(&prompt, JUDGEMENT, &schema, check) {
        Ok(answer) => answer,
        Err(Judgement::Unavailable(reason) | Judgement::Deferred(reason)) => return Err(reason),
        Err(Judgement::Answered(answer)) => {
            return Err(format!("the judge's answer was not read: {answer}"))
        }
    };
    found
        .iter()
        .map(|command| {
            let judged = answer
                .verdicts
                .iter()
                .find(|judged| judged.name == command.name)
                .ok_or_else(|| format!("the judge gave no verdict for command {}", command.name))?;
            let reason = (judged.choice == BLOCK).then(|| judged.reason.clone());
            Ok((command.clone(), reason))
        })
        .collect()
}
