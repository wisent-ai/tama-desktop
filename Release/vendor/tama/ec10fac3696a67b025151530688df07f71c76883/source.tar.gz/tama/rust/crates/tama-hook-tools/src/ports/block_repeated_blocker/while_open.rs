//! While Oko holds any open task or defect, the answer tells the operator
//! nothing is stopping it: its blocker section and its next-steps section
//! say `brak` (or `none`).
//!
//! Why: the operator rules once on what stops the work - no build and no
//! bought credit before every task and defect is closed, a model judge that
//! is down - and an answer that reports the same judge, the same build or
//! the same request again hands him a decision he already made. With work
//! open, every entry of those sections is a reason offered for stopping,
//! and the work is to take the next open item instead.
//!
//! The rule reads structure, not words: the two sections the answer
//! contract reserves for what stops the work must be empty while Oko has
//! work open. What they would have said stays unsaid whatever its wording.

use serde_json::Value;

use crate::assignment::open_work;

/// The refusal when Oko has open work and the answer still hands the
/// operator a blocker or a step. `section` names the offending section. An
/// Oko that cannot be read refuses the section too, naming the cause: read
/// as no open work, it would let the blocker through.
pub fn refusal(payload: &Value, section: &str) -> Option<String> {
    let session = tama_hooks::session_record::session_id_of(payload);
    let work = match open_work::read(&session) {
        Ok(work) => work,
        Err(cause) => {
            return Some(format!(
                "block-repeated-blocker: this answer's {section} section is not `brak`, and \
                 whether Oko still holds open work cannot be read: {cause}"
            ))
        }
    };
    if work.is_empty() {
        return None;
    }
    let open = work.tasks.len() + work.defects.len();
    Some(format!(
        "block-repeated-blocker: Oko still holds {open} open tasks and defects, and this answer's \
         {section} section is not `brak`. The operator ordered: no talk about the Oko judge, \
         Stado, building or any other obstacle until every task and defect is done. While work \
         is open, write `brak` under Blokady and Następne kroki, take the next open item, repair \
         it and push the repair."
    ))
}
