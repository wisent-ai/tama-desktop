//! Decode Oko's open selection.
use serde::Deserialize;
use serde_json::Value;

use super::{short, OpenDefect};

/// Fields consumed from Oko's serialized Defect. Unknown fields remain Oko's.
#[derive(Deserialize)]
struct Record<'a> {
    id: &'a str,
    product: &'a str,
    title: &'a str,
    repair_plan: Option<&'a str>,
    repaired_in: Option<&'a str>,
    owner: Option<&'a str>,
}

pub(super) fn open_of(register: &Value) -> Result<Vec<OpenDefect>, String> {
    let rows = register
        .as_array()
        .ok_or_else(|| "Oko's open defect register is not an array".to_string())?;
    let records = rows
        .iter()
        .enumerate()
        .map(|(index, value)| {
            let record = Record::deserialize(value)
                .map_err(|error| format!("cannot decode Oko's open defect row {index}: {error}"))?;
            if record.id.trim().is_empty() {
                return Err(format!(
                    "Oko's open defect row {index} has no nonempty text id"
                ));
            }
            if record.product.trim().is_empty() {
                return Err(format!(
                    "Oko's open defect row {index} has no nonempty text product"
                ));
            }
            Ok(record)
        })
        .collect::<Result<Vec<_>, String>>()?;
    records
        .into_iter()
        .map(|record| {
            let repaired_in = record
                .repaired_in
                .filter(|revision| !revision.trim().is_empty());
            Ok(OpenDefect {
                id: short(record.id),
                product: record.product.to_owned(),
                title: record.title.to_owned(),
                // Oko explicitly permits an absent repair plan on an open record.
                repair: match record.repair_plan {
                    Some(plan) => plan.to_owned(),
                    None => String::new(),
                },
                repaired_in: repaired_in.map(str::to_owned),
                owner: record.owner.map(str::to_owned),
            })
        })
        .collect()
}
