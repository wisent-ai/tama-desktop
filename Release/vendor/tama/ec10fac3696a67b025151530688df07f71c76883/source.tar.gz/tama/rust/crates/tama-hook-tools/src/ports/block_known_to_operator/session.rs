//! What this session has already said: the operator's own words and every
//! earlier answer the agent gave him, read out of the live transcript.
//!
//! Split out of `mod.rs`, which keeps the judgement. Finding the file and
//! reducing its records to the two voices is here.
//!
//! Transcript shape (`~/.omp/agent/sessions/**/*.jsonl`, one JSON object per
//! line): `{ type, message: { role, content: [...] } }`. A user-role record
//! the harness injected — a todo reminder, a hook continuation — carries
//! `attribution: "agent"` and is not the operator speaking.

use std::path::PathBuf;

use serde_json::Value;
use tama_hooks::session_record::{session_id_of, transcript_path};

const TRANSCRIPT_PATH_KEY: &str = "transcript_path";
const MESSAGE_KEY: &str = "message";
const ROLE_KEY: &str = "role";
const CONTENT_KEY: &str = "content";
const TYPE_KEY: &str = "type";
const TEXT_KEY: &str = "text";
const ATTRIBUTION_KEY: &str = "attribution";
const AGENT_ATTRIBUTION: &str = "agent";
const USER_ROLE: &str = "user";
const ASSISTANT_ROLE: &str = "assistant";

/// The two voices of the session before the answer under judgement.
#[derive(Debug, Default, PartialEq, Eq)]
pub(crate) struct Said {
    /// The operator's messages, oldest first.
    pub operator: Vec<String>,
    /// The agent's earlier prose answers, oldest first, the final one
    /// excluded.
    pub told: Vec<String>,
}

impl Said {
    /// Nothing to compare an answer against: no words of the operator and
    /// nothing told before. Such a session cannot know anything yet.
    pub fn is_empty(&self) -> bool {
        self.operator.is_empty() && self.told.is_empty()
    }
}

/// The transcript the payload names, or the newest one of its session.
pub(crate) fn locate(payload: &Value) -> Option<PathBuf> {
    if let Some(path) = payload.get(TRANSCRIPT_PATH_KEY).and_then(Value::as_str) {
        if !path.is_empty() {
            return Some(PathBuf::from(path));
        }
    }
    transcript_path(&session_id_of(payload))
}

/// The prose of one record: its text parts, or its string content.
fn prose(message: &Value) -> String {
    match message.get(CONTENT_KEY) {
        Some(Value::String(text)) => text.clone(),
        Some(Value::Array(items)) => items
            .iter()
            .filter(|item| item.get(TYPE_KEY).and_then(Value::as_str) == Some(TEXT_KEY))
            .filter_map(|item| item.get(TEXT_KEY).and_then(Value::as_str))
            .collect::<Vec<_>>()
            .join("\n"),
        _ => String::new(),
    }
}

/// The two voices, read out of a transcript's text. `final_message` is the
/// answer under judgement: the last assistant record that says it is not
/// something told before, so it is left out of `told`. A complete line that
/// is not a JSON record is the error naming it: skipped, what it said would
/// be judged as never said. A last line its harness is still writing is set
/// aside, as the shared JSON Lines reader does.
pub(crate) fn read(raw: &str, final_message: &str) -> Result<Said, String> {
    let mut said = Said::default();
    let mut assistant: Vec<String> = Vec::new();
    let records = tama_hooks::jsonl::records(raw)
        .map_err(|cause| format!("the session transcript is not JSON records: {cause}"))?;
    for record in &records.values {
        // A record either carries its message nested (one harness's shape)
        // or is the message itself (the other's).
        let message = match record.get(MESSAGE_KEY) {
            Some(message) => message,
            None => record,
        };
        let role = message.get(ROLE_KEY).and_then(Value::as_str);
        let text = prose(message);
        if text.trim().is_empty() {
            continue;
        }
        if role == Some(USER_ROLE) {
            if message.get(ATTRIBUTION_KEY).and_then(Value::as_str) != Some(AGENT_ATTRIBUTION) {
                said.operator.push(text);
            }
        } else if role == Some(ASSISTANT_ROLE) {
            assistant.push(text);
        }
    }
    if assistant
        .last()
        .is_some_and(|last| last.trim() == final_message.trim())
    {
        assistant.pop();
    }
    said.told = assistant;
    Ok(said)
}
