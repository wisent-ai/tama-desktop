//! The command-line commands a source text declares, read by shape for the
//! argument frameworks the workshop's programs use: clap subcommand enums in
//! Rust, ArgumentParser commands in Swift, argparse sub-parsers and click or
//! typer commands in Python, commander and yargs commands in JavaScript.
//!
//! The whole file is read, and which framework a file uses is read from the
//! file itself — a `#[derive(Subcommand)]` enum, a `ParsableCommand` struct,
//! an `add_parser` call or command decorator, a `.command("name")` call —
//! never from a list of file extensions. Telling a command from a value enum
//! is the judge's work, not this reader's; reading one too many costs a
//! question, reading one too few lets a one-off command through.

use std::collections::BTreeSet;

use crate::ports::transport_common as common;

/// One declared command: what it is called, where it is declared, and the
/// text that declares it (its documentation, name and arguments).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Command {
    pub name: String,
    pub declaration: String,
}

const RUST_MARKER: &str = "Subcommand";
const RUST_VARIANT: &str = r"^(\s+)([A-Z][A-Za-z0-9]*)\s*(\{|\(|,|$)";
const RUST_NAME_ATTRIBUTE: &str = r#"name\s*=\s*"([^"]+)""#;
const SWIFT_COMMAND: &str = r"struct\s+([A-Za-z0-9_]+)\s*:[^{]*ParsableCommand";
const SWIFT_NAME: &str = r#"commandName:\s*"([^"]+)""#;
const PYTHON_SUBPARSER: &str = r#"add_parser\(\s*["']([^"']+)["']"#;
const PYTHON_DECORATOR: &str = r"@[A-Za-z0-9_.]+\.command\(";
const PYTHON_DEFINITION: &str = r"^\s*(?:async\s+)?def\s+([A-Za-z0-9_]+)";
const SCRIPT_COMMAND: &str = r#"\.command\(\s*["'`]([^"'`\s]+)"#;
const DOC_PREFIXES: [&str; 2] = ["///", "#["];

/// Whether `lines` declare a `#[derive(Subcommand)]` enum.
fn derives_subcommands(lines: &[&str]) -> bool {
    lines
        .iter()
        .any(|line| line.contains("#[derive(") && line.contains(RUST_MARKER))
}

/// `BuildFinancialModel` → `build-financial-model`, as clap names a variant.
fn kebab(identifier: &str) -> String {
    let mut out = String::new();
    for (index, ch) in identifier.chars().enumerate() {
        if ch.is_ascii_uppercase() && index > 0 {
            out.push('-');
        }
        out.push(ch.to_ascii_lowercase());
    }
    out
}

/// Braces opened minus closed on a line, outside string literals and
/// line comments.
fn depth_change(line: &str) -> i64 {
    let code = line.split("//").next().unwrap_or_default();
    let mut change = 0;
    let mut in_string = false;
    let mut escaped = false;
    for ch in code.chars() {
        match (in_string, escaped, ch) {
            (true, true, _) => escaped = false,
            (true, false, '\\') => escaped = true,
            (_, false, '"') => in_string = !in_string,
            (false, _, '{') => change += 1,
            (false, _, '}') => change -= 1,
            _ => {}
        }
    }
    change
}

/// The documentation and attributes right above line `at`, then the lines
/// from `at` until its braces close, as the declaration of one variant.
fn rust_declaration(lines: &[&str], at: usize) -> (String, Option<String>) {
    let mut start = at;
    while start > 0
        && DOC_PREFIXES
            .iter()
            .any(|prefix| lines[start - 1].trim_start().starts_with(prefix))
    {
        start -= 1;
    }
    let mut end = at;
    let mut depth = depth_change(lines[at]);
    while depth > 0 && end + 1 < lines.len() {
        end += 1;
        depth += depth_change(lines[end]);
    }
    let name = common::compile(RUST_NAME_ATTRIBUTE);
    let named = lines[start..at]
        .iter()
        .filter(|line| line.contains("command("))
        .find_map(|line| name.captures(line).map(|found| found[1].to_string()));
    (lines[start..=end].join("\n"), named)
}

/// The lines of `lines` that open a variant of a `#[derive(Subcommand)]`
/// enum, at the enum's own depth.
fn variant_lines(lines: &[&str]) -> Vec<usize> {
    let variant = common::compile(RUST_VARIANT);
    let opens = |line: &str| {
        variant.is_match(line) && !line.contains("=>") && !line.trim_end().ends_with(';')
    };
    let mut found = Vec::new();
    let (mut derived, mut depth, mut inside) = (false, 0i64, false);
    for (index, line) in lines.iter().enumerate() {
        let trimmed = line.trim_start();
        if trimmed.starts_with("#[derive(") {
            derived = line.contains(RUST_MARKER);
        } else if derived && !inside && trimmed.contains("enum ") && line.contains('{') {
            inside = true;
            depth = 0;
        }
        if inside && depth == 1 && opens(line) {
            found.push(index);
        }
        if inside {
            depth += depth_change(line);
            if depth <= 0 && line.contains('}') {
                inside = false;
                derived = false;
            }
        }
    }
    found
}

fn rust(text: &str) -> Vec<Command> {
    let lines: Vec<&str> = text.lines().collect();
    if !derives_subcommands(&lines) {
        return Vec::new();
    }
    let variant = common::compile(RUST_VARIANT);
    let mut found = Vec::new();
    for index in variant_lines(&lines) {
        let Some(captured) = variant.captures(lines[index]) else {
            continue;
        };
        let (declaration, named) = rust_declaration(&lines, index);
        found.push(Command {
            name: named.unwrap_or_else(|| kebab(&captured[2])),
            declaration,
        });
    }
    found
}

/// The match line and what follows it up to the next blank line.
fn paragraph(lines: &[&str], at: usize) -> String {
    let end = lines[at..]
        .iter()
        .position(|line| line.trim().is_empty())
        .map_or(lines.len(), |offset| at + offset);
    lines[at..end].join("\n")
}

fn by_pattern(text: &str, pattern: &str) -> Vec<Command> {
    let regex = common::compile(pattern);
    let lines: Vec<&str> = text.lines().collect();
    lines
        .iter()
        .enumerate()
        .filter_map(|(index, line)| {
            regex.captures(line).map(|found| Command {
                name: found[1].to_string(),
                declaration: paragraph(&lines, index),
            })
        })
        .collect()
}

fn swift(text: &str) -> Vec<Command> {
    let named = common::compile(SWIFT_NAME);
    by_pattern(text, SWIFT_COMMAND)
        .into_iter()
        .map(|mut command| {
            if let Some(found) = named.captures(&command.declaration) {
                command.name = found[1].to_string();
            } else {
                command.name = kebab(&command.name);
            }
            command
        })
        .collect()
}

fn python(text: &str) -> Vec<Command> {
    let mut found = by_pattern(text, PYTHON_SUBPARSER);
    let decorator = common::compile(PYTHON_DECORATOR);
    let definition = common::compile(PYTHON_DEFINITION);
    let lines: Vec<&str> = text.lines().collect();
    for (index, line) in lines.iter().enumerate() {
        if !decorator.is_match(line) {
            continue;
        }
        if let Some((offset, name)) =
            lines[index..]
                .iter()
                .enumerate()
                .find_map(|(offset, line)| {
                    definition
                        .captures(line)
                        .map(|found| (offset, found[1].replace('_', "-")))
                })
        {
            found.push(Command {
                name,
                declaration: paragraph(&lines, index)
                    .lines()
                    .take(offset + 1)
                    .collect::<Vec<_>>()
                    .join("\n"),
            });
        }
    }
    found
}

/// Every command `text`, a whole source file, declares, each name once,
/// by every framework whose shape the file holds.
pub fn declared(text: &str) -> Vec<Command> {
    let mut seen = BTreeSet::new();
    rust(text)
        .into_iter()
        .chain(swift(text))
        .chain(python(text))
        .chain(by_pattern(text, SCRIPT_COMMAND))
        .filter(|command| seen.insert(command.name.clone()))
        .collect()
}
