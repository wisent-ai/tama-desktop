//! Explicit repositories are honored; directory roots select only product checkouts.

use std::path::PathBuf;

use super::super::approvals;

/// The selected repositories and count of unmarked checkouts not selected.
pub(super) fn select(roots: &[String]) -> Result<(Vec<PathBuf>, usize), String> {
    let here = std::env::current_dir().map_err(|error| format!("current directory: {error}"))?;
    let roots: Vec<PathBuf> = if roots.is_empty() {
        vec![here.clone()]
    } else {
        roots
            .iter()
            .map(|root| approvals::absolute(root, &here))
            .collect()
    };
    let mut found = Vec::new();
    let mut excluded = 0;
    let checkout = |path: &std::path::Path| {
        tama_core::presence::present(&path.join(".git")).map_err(|error| error.to_string())
    };
    for root in roots {
        if checkout(&root)? {
            found.push(root);
            continue;
        }
        let entries = std::fs::read_dir(&root).map_err(|error| {
            format!(
                "{} is neither a repository nor a readable directory: {error}",
                root.display()
            )
        })?;
        // An entry that cannot be read refuses: dropped, the audit ran over
        // fewer repositories than the directory holds.
        let mut children: Vec<PathBuf> = Vec::new();
        for entry in entries {
            let path = entry
                .map_err(|error| format!("an entry of {} cannot be read: {error}", root.display()))?
                .path();
            if checkout(&path)? {
                children.push(path);
            }
        }
        let repositories_in_directory = children.len();
        children.retain(|path| path.join(".wisent-release.json").is_file());
        excluded += repositories_in_directory - children.len();
        if children.is_empty() {
            return Err(format!(
                "{} is not a repository and holds no product repository with .wisent-release.json",
                root.display()
            ));
        }
        children.sort();
        found.extend(children);
    }
    Ok((found, excluded))
}
