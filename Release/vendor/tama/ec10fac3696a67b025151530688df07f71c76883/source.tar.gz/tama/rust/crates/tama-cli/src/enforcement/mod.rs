use std::fmt;
use std::path::Path;

use tama_hooks::enforcement::{
    update_enforcement_selection, EnforcementMode, EnforcementRead, EnforcementSelection,
    SelectionChangeError,
};

mod preflight;
pub(crate) mod status;

pub(crate) use status::{
    installed_hook_ids, report_read_error, session_summary, status, status_for_home,
    EnforcementStatus,
};
use status::{print_status, status_after_write};

pub(crate) const USAGE: &str = "tama enforcement <command>

Commands:
  status [--json]       Show the machine selection and emergency bypass state
  only <hook-id>...     Enforce only the selected installed hooks
  add <hook-id>...      Enforce these as well, keeping the current selection
  remove <hook-id>...   Stop enforcing these, keeping the rest
  preflight <hook-id> [--session ID]   Ask one hook against an exact session
  all                   Clear the selection and enforce every installed hook";

#[derive(Debug)]
pub(crate) enum CommandError {
    UnknownHook {
        id: String,
        known_count: usize,
    },
    Operational(String),
    Unusable {
        id: String,
        reason: String,
    },
    /// The change does not apply to the selection as it is; its sentence says
    /// why and what does.
    Refused(String),
}

impl fmt::Display for CommandError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::UnknownHook { id, known_count } => write!(
                formatter,
                "Unknown hook id '{id}'; the installed registry declares {known_count} hook ids, and the enforcement selection was not changed."
            ),
            Self::Operational(error) | Self::Refused(error) => formatter.write_str(error),
            Self::Unusable { id, reason } => write!(
                formatter,
                "Hook '{id}' cannot run on this machine, so nothing was selected and the enforcement selection was not changed. It answered: {reason}"
            ),
        }
    }
}

/// Refuse an id the installed registry does not declare, or a hook that cannot
/// work on this machine; answer the installed ids.
fn admit(root: &Path, requested: &[String]) -> Result<Vec<String>, CommandError> {
    let installed = installed_hook_ids(root).map_err(CommandError::Operational)?;
    for id in requested {
        if installed.binary_search(id).is_err() {
            return Err(CommandError::UnknownHook {
                id: id.clone(),
                known_count: installed.len(),
            });
        }
    }
    // A hook that cannot work here must not become the machine's policy: the
    // session path asks first, and so does this one.
    for id in requested {
        let unusable = preflight::hook_command(root, id)
            .map_err(CommandError::Operational)?
            .as_deref()
            .and_then(|command| preflight::probe(command, None))
            .and_then(|probe| probe.failure());
        if let Some(reason) = unusable {
            return Err(CommandError::Unusable {
                id: id.clone(),
                reason,
            });
        }
    }
    Ok(installed)
}

/// Write one change of the selection, made from what the selection holds at
/// that moment (`update_enforcement_selection` orders concurrent writers).
fn change(
    installed: &[String],
    change: impl FnOnce(&EnforcementRead) -> Result<(EnforcementMode, Vec<String>), String>,
) -> Result<EnforcementStatus, CommandError> {
    let selection = update_enforcement_selection(change).map_err(|error| match error {
        SelectionChangeError::Refused(reason) => CommandError::Refused(reason),
        SelectionChangeError::Failed(reason) => CommandError::Operational(reason),
    })?;
    Ok(status_after_write(selection, installed))
}

/// The selection a change keeps the rest of. One that cannot be read is
/// refused, not taken for `all`: a change made from a guess would overwrite
/// the operator's selection with it.
fn current(read: &EnforcementRead) -> Result<&EnforcementSelection, String> {
    match &read.error {
        Some(error) => Err(format!(
            "The machine's selection cannot be read, so nothing was changed: {error}. \
             `tama enforcement only <hook-id>...` or `tama enforcement all` writes a whole \
             selection in its place."
        )),
        None => Ok(&read.selection),
    }
}

pub(crate) fn set_only(
    root: &Path,
    requested: &[String],
) -> Result<EnforcementStatus, CommandError> {
    let installed = admit(root, requested)?;
    change(&installed, |_| {
        Ok((EnforcementMode::Only, requested.to_vec()))
    })
}

/// Add hooks to the machine's selection, keeping the ones already chosen.
///
/// `only` takes the whole list, which is right when the selection is being
/// decided and wrong when one gate is being turned on: turning one newly
/// installed hook on would mean retyping every id, where one mistyped or
/// forgotten id silently switches a gate off. The selection after an `add`
/// is the union, in the same order `status` prints, of the requested hooks and
/// the selection as it is when the change is written, so a hook another
/// session added meanwhile stays. On a machine that enforces every installed
/// hook (mode all) the requested hooks are already enforced and the selection
/// stays `all`. Only the requested hooks are probed: the selected ones were
/// probed when they were turned on.
pub(crate) fn add(root: &Path, requested: &[String]) -> Result<EnforcementStatus, CommandError> {
    let installed = admit(root, requested)?;
    change(&installed, |read| {
        let current = current(read)?;
        if current.mode == EnforcementMode::All {
            return Ok((EnforcementMode::All, Vec::new()));
        }
        let mut union = current.enabled.clone();
        for id in requested {
            if !union.contains(id) {
                union.push(id.clone());
            }
        }
        union.sort();
        Ok((EnforcementMode::Only, union))
    })
}

/// Take hooks out of the machine's selection, keeping the rest.
///
/// The same asymmetry in the other direction: turning one gate off by
/// retyping every other one is how the other twenty-two get turned off by
/// accident. An id that is not selected is reported rather than ignored,
/// because a silent no-op reads as a gate that was switched off. On a
/// machine that enforces every installed hook (mode all) the selection
/// becomes every installed hook but the requested ones, computed when the
/// change is written like every other, so no caller builds that list from a
/// catalog it read earlier.
pub(crate) fn remove(root: &Path, requested: &[String]) -> Result<EnforcementStatus, CommandError> {
    let installed = installed_hook_ids(root).map_err(CommandError::Operational)?;
    change(&installed, |read| {
        let current = current(read)?;
        let held = match current.mode {
            EnforcementMode::All => &installed,
            EnforcementMode::Only => &current.enabled,
        };
        if let Some(id) = requested.iter().find(|id| !held.contains(id)) {
            return Err(match current.mode {
                EnforcementMode::All => format!(
                    "Hook '{id}' is not installed on this machine, so nothing was changed; \
                     `tama enforcement status` prints the {} that are.",
                    installed.len()
                ),
                EnforcementMode::Only => format!(
                    "Hook '{id}' is not in this machine's selection, so nothing was changed; \
                     `tama enforcement status` prints the {} that are.",
                    current.enabled.len()
                ),
            });
        }
        let mut kept = held.clone();
        kept.retain(|id| !requested.contains(id));
        if kept.is_empty() {
            return Err(
                "Removing these would leave no hook selected, so nothing was changed; \
                 `tama enforcement all` enforces every installed hook."
                    .to_string(),
            );
        }
        kept.sort();
        Ok((EnforcementMode::Only, kept))
    })
}

pub(crate) fn set_all(root: &Path) -> Result<EnforcementStatus, CommandError> {
    let installed = installed_hook_ids(root).map_err(CommandError::Operational)?;
    change(&installed, |_| Ok((EnforcementMode::All, Vec::new())))
}

fn usage(code: i32) -> i32 {
    eprintln!("{USAGE}");
    code
}

/// Hook ids as written: none of them a flag.
fn hook_ids(rest: &[String]) -> bool {
    !rest.is_empty() && rest.iter().all(|id| !id.starts_with('-'))
}

/// What `preflight` was asked for: one hook, with or without `--session
/// <id>`; none for anything else.
fn preflight_request(rest: &[String]) -> Option<(&str, Option<&str>)> {
    match rest {
        [hook] => Some((hook.as_str(), None)),
        [hook, flag, session]
            if flag == "--session" && !session.is_empty() && !session.starts_with('-') =>
        {
            Some((hook.as_str(), Some(session.as_str())))
        }
        _ => None,
    }
}

fn saved(result: &EnforcementStatus) -> i32 {
    println!("Machine enforcement selection saved.");
    print_status(result);
    tama_core::exit::SUCCESS
}

fn run(args: &[String], root: &Path) -> Result<i32, CommandError> {
    let (command, rest) = match args.split_first() {
        Some((command, rest)) => (Some(command.as_str()), rest),
        None => (None, args),
    };
    let json = rest == ["--json"];
    match command {
        Some("help" | "--help" | "-h") => Ok(usage(tama_core::exit::SUCCESS)),
        Some("status") if rest.is_empty() || json => {
            let result = status(root).map_err(CommandError::Operational)?;
            if json {
                println!("{}", tama_core::json::pretty(&result));
            } else {
                print_status(&result);
            }
            report_read_error(&result);
            Ok(match result.read_error {
                Some(_) => tama_core::exit::FAILURE,
                None => tama_core::exit::SUCCESS,
            })
        }
        Some("only") if hook_ids(rest) => Ok(saved(&set_only(root, rest)?)),
        Some("add") if hook_ids(rest) => Ok(saved(&add(root, rest)?)),
        Some("remove") if hook_ids(rest) => Ok(saved(&remove(root, rest)?)),
        Some("preflight") => match preflight_request(rest) {
            Some((hook, session)) => {
                let installed = installed_hook_ids(root).map_err(CommandError::Operational)?;
                Ok(preflight::report(root, hook, &installed, session))
            }
            None => Ok(usage(tama_core::exit::USAGE)),
        },
        Some("all") if rest.is_empty() => {
            let result = set_all(root)?;
            println!(
                "Machine enforcement selection cleared; all {} installed hooks are selected.",
                result.installed_hook_count
            );
            print_status(&result);
            Ok(tama_core::exit::SUCCESS)
        }
        _ => Ok(usage(tama_core::exit::USAGE)),
    }
}

pub(crate) fn main(args: &[String], root: &Path) -> i32 {
    match run(args, root) {
        Ok(code) => code,
        Err(
            error @ (CommandError::UnknownHook { .. }
            | CommandError::Unusable { .. }
            | CommandError::Refused(_)),
        ) => {
            eprintln!("{error}");
            tama_core::exit::FAILURE
        }
        Err(CommandError::Operational(error)) => {
            eprintln!("enforcement: {error}");
            tama_core::exit::FAILURE
        }
    }
}
