//! `tama hooks warm`: run every hook the registry names once through the
//! `tama` program, on purpose, so the operating system's first-execution
//! work is paid here instead of inside a live hook event.
//!
//! A newly installed copy answers an empty payload in milliseconds once it
//! has run; its first execution is another matter. macOS assesses an
//! executable the first time it sees its code directory, `syspolicyd` makes
//! a network round trip to do it and XProtect scans the image, which can
//! take minutes. The engine waits for a hook rather than killing it, so that
//! cost is not a refusal — but it is still minutes a person waits inside a
//! live event. Installing a binary and never running it is what leaves that
//! in front of the next real event, so `tama hooks release` warms what it
//! installs and this command warms a machine whose binaries arrived some
//! other way.

mod run;

use std::path::Path;

use serde_json::Value;

pub use run::{
    registry_hooks, release_hooks, runtime_binary, separate_programs, warm_hooks, HookBinary,
    State, Warmed,
};

pub const USAGE: &str = "usage: tama hooks warm [--only <hook-id>[,<hook-id>…]] [--json]";

/// The line a person reads for one hook.
fn line(warmed: &Warmed) -> String {
    format!(
        "{:<7} {:>7} ms  {}  ({})",
        warmed.state.text(),
        warmed.elapsed_ms,
        warmed.hook.id,
        warmed.hook.path.display()
    )
}

/// What a warm run observed, as one document: the desktop backend answers
/// with exactly this, and `--json` prints exactly this, so the screen and
/// the terminal cannot disagree about what a machine's gates cost.
pub fn report_value(results: &[Warmed]) -> Value {
    let rows: Vec<Value> = results
        .iter()
        .map(|warmed| {
            serde_json::json!({
                "id": warmed.hook.id,
                "command": warmed.hook.command,
                "path": warmed.hook.path.display().to_string(),
                "elapsedMs": warmed.elapsed_ms,
                "exitCode": warmed.code,
                "state": warmed.state.text(),
                "cause": warmed.cause,
            })
        })
        .collect();
    let unusable = results
        .iter()
        .filter(|warmed| warmed.state != State::Warm)
        .count();
    let slowest = results
        .iter()
        .filter(|warmed| warmed.state == State::Warm)
        .max_by_key(|warmed| warmed.elapsed_ms);
    serde_json::json!({
        "hooks": rows,
        "warmed": results.len() - unusable,
        "slowest": slowest.map(|warmed| warmed.hook.id.clone()),
        "slowestMs": slowest.map(|warmed| warmed.elapsed_ms),
        "unusable": unusable,
    })
}

/// The hooks a selection names, or the refusal that names what it got wrong.
/// Shared so the command and the desktop backend refuse identically.
pub fn select(root: &Path, only: &[String]) -> Result<Vec<HookBinary>, String> {
    let registry = root.join("shared-hooks/registry.json");
    // The one HOME reader: an empty HOME read as the empty path would look
    // for the sealed release under the working directory and warm none of it.
    let home = tama_core::home_dir();
    // A registry that cannot be read is refused with its cause here, so the
    // command and the desktop backend do not answer "names no hook" for it.
    let registry_run = registry_hooks(&registry)?;
    // The engine runs the sealed release, not the registry's copy: two
    // files, two first assessments, and warming the copy would pay only one.
    let sealed = release_hooks(&home, &registry_run)?;
    let mut all = registry_run;
    all.extend(sealed);
    if all.is_empty() {
        return Err(format!(
            "{} names no hook the tama program runs; there is nothing to warm",
            registry.display()
        ));
    }
    let unknown: Vec<&str> = only
        .iter()
        .filter(|id| !all.iter().any(|hook| &hook.id == *id))
        .map(String::as_str)
        .collect();
    if !unknown.is_empty() {
        return Err(format!(
            "{} names no hook called {}",
            registry.display(),
            unknown.join(", ")
        ));
    }
    Ok(if only.is_empty() {
        all
    } else {
        all.into_iter()
            .filter(|hook| only.contains(&hook.id))
            .collect()
    })
}

/// Print what a warm run observed and answer with its exit code. Shared by
/// this command and by `tama hooks release`, which warms what it installs.
pub fn report(results: &[Warmed], json: bool) -> i32 {
    let unusable: Vec<&Warmed> = results
        .iter()
        .filter(|warmed| warmed.state != State::Warm)
        .collect();
    let slowest = results
        .iter()
        .filter(|warmed| warmed.state == State::Warm)
        .max_by_key(|warmed| warmed.elapsed_ms);
    if json {
        match serde_json::to_string_pretty(&report_value(results)) {
            Ok(text) => println!("{text}"),
            Err(error) => {
                return refusal(&format!(
                    "the warm report cannot be encoded as JSON: {error}"
                ))
            }
        }
    } else {
        results
            .iter()
            .for_each(|warmed| println!("{}", line(warmed)));
        let cost = match slowest {
            Some(warmed) => format!("slowest {} at {} ms", warmed.hook.id, warmed.elapsed_ms),
            None => "nothing ran".to_string(),
        };
        println!(
            "hook binaries: {} warmed, {cost}, {} unusable",
            results.len() - unusable.len(),
            unusable.len()
        );
    }
    for warmed in &unusable {
        let cause = match &warmed.cause {
            Some(cause) => format!(" ({cause})"),
            None => String::new(),
        };
        eprintln!(
            "{} is {}{cause}: {} — a live event would refuse on it",
            warmed.hook.id,
            warmed.state.text(),
            warmed.hook.path.display()
        );
    }
    if unusable.is_empty() {
        crate::exit::SUCCESS
    } else {
        crate::exit::FAILURE
    }
}

fn refusal(message: &str) -> i32 {
    eprintln!("{message}");
    crate::exit::USAGE
}

pub fn main(argv: &[String], root: &Path) -> i32 {
    if argv.iter().any(|arg| arg == "--help" || arg == "-h") {
        println!("{USAGE}");
        return crate::exit::SUCCESS;
    }
    let json = argv.iter().any(|arg| arg == "--json");
    let only: Vec<String> = match crate::cli::args::arg_after(argv, "--only") {
        Some(list) => list.split(',').map(|id| id.trim().to_string()).collect(),
        None => Vec::new(),
    };
    match select(root, &only) {
        Ok(selected) => report(&warm_hooks(root, &selected), json),
        Err(error) => refusal(&error),
    }
}
