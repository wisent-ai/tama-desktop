//! The hook block a harness's file holds, rendered from the Claude Code
//! matcher groups `tama provider config` builds for every registry event.
//! Only a hook's command and the group's matcher reach another harness: the
//! other fields of a Claude Code hook mean other things, or nothing, there.

use serde_json::{json, Map, Value};

use super::{Adapter, Shape};

/// The first line of the region of `config.toml` Tama owns.
pub const TOML_BEGIN: &str =
    "# BEGIN tama hooks: written by `tama hooks install`; edits inside are replaced";
/// The last line of that region.
pub const TOML_END: &str = "# END tama hooks";

/// Every (event, matcher, command) the groups carry, in their order.
fn commands(groups: &Map<String, Value>) -> Vec<(String, Option<String>, String)> {
    let mut found = Vec::new();
    for (event, entries) in groups {
        for group in entries.as_array().into_iter().flatten() {
            let matcher = group
                .get("matcher")
                .and_then(Value::as_str)
                .map(str::to_string);
            for hook in group
                .get("hooks")
                .and_then(Value::as_array)
                .into_iter()
                .flatten()
            {
                if let Some(command) = hook.get("command").and_then(Value::as_str) {
                    found.push((event.clone(), matcher.clone(), command.to_string()));
                }
            }
        }
    }
    found
}

/// One entry of a flat shape, under its event.
fn flat(groups: &Map<String, Value>, entry: impl Fn(&str, Option<&str>) -> Value) -> Value {
    let mut out = Map::new();
    for (event, matcher, command) in commands(groups) {
        if let Value::Array(entries) = out.entry(event).or_insert_with(|| Value::Array(Vec::new()))
        {
            entries.push(entry(&command, matcher.as_deref()));
        }
    }
    Value::Object(out)
}

fn with_matcher(mut entry: Map<String, Value>, matcher: Option<&str>) -> Value {
    if let Some(matcher) = matcher {
        entry.insert("matcher".into(), json!(matcher));
    }
    Value::Object(entry)
}

/// The hook block `adapter`'s file holds for `groups`.
pub fn render(adapter: &Adapter, groups: &Map<String, Value>) -> Value {
    match adapter.shape {
        Shape::SettingsHooks | Shape::EventMap => {
            let mut out = Map::new();
            for (event, matcher, command) in commands(groups) {
                let mut group = Map::new();
                group.insert(
                    "hooks".into(),
                    json!([{ "type": "command", "command": command }]),
                );
                let group = with_matcher(group, matcher.as_deref());
                if let Value::Array(entries) =
                    out.entry(event).or_insert_with(|| Value::Array(Vec::new()))
                {
                    entries.push(group);
                }
            }
            Value::Object(out)
        }
        Shape::CursorFlat => flat(groups, |command, matcher| {
            let mut entry = Map::new();
            entry.insert("command".into(), json!(command));
            with_matcher(entry, matcher)
        }),
        Shape::CopilotFlat => flat(groups, |command, matcher| {
            let mut entry = Map::new();
            entry.insert("type".into(), json!("command"));
            entry.insert("bash".into(), json!(command));
            with_matcher(entry, matcher)
        }),
        Shape::WindsurfFlat => flat(groups, |command, _| json!({ "command": command })),
        Shape::KimiToml => json!({
            "hooks": commands(groups)
                .into_iter()
                .map(|(event, matcher, command)| {
                    let mut entry = Map::new();
                    entry.insert("event".into(), json!(event));
                    entry.insert("command".into(), json!(command));
                    with_matcher(entry, matcher.as_deref())
                })
                .collect::<Vec<Value>>(),
        }),
    }
}

/// A TOML basic string: JSON's string escapes are TOML's.
fn quoted(text: &str) -> String {
    Value::String(text.to_string()).to_string()
}

/// `existing` with Tama's region replaced by one `[[hooks]]` table for every
/// entry of `block`'s `hooks` (a rendered kimi-toml block), each carrying the
/// entry's fields; text outside the region is kept as it was.
pub fn merged_toml(existing: &str, block: &Value) -> Result<String, String> {
    let mut out = String::with_capacity(existing.len());
    let mut inside = false;
    for line in existing.split_inclusive('\n') {
        match line.trim_end_matches(['\r', '\n']) {
            TOML_BEGIN => {
                if inside {
                    return Err("nested Tama hook region: configuration left unchanged".into());
                }
                inside = true;
            }
            TOML_END => {
                if !inside {
                    return Err(
                        "Tama hook region ends without a beginning: configuration left unchanged"
                            .into(),
                    );
                }
                inside = false;
            }
            _ if !inside => out.push_str(line),
            _ => {}
        }
    }
    if inside {
        return Err("unterminated Tama hook region: configuration left unchanged".into());
    }
    if !out.is_empty() && !out.ends_with('\n') {
        out.push('\n');
    }
    out.push_str(TOML_BEGIN);
    out.push('\n');
    for entry in block
        .get("hooks")
        .and_then(Value::as_array)
        .into_iter()
        .flatten()
    {
        out.push_str("[[hooks]]\n");
        for (field, value) in entry.as_object().into_iter().flatten() {
            if let Some(text) = value.as_str() {
                out.push_str(&format!("{field} = {}\n", quoted(text)));
            }
        }
    }
    out.push_str(TOML_END);
    out.push('\n');
    Ok(out)
}
