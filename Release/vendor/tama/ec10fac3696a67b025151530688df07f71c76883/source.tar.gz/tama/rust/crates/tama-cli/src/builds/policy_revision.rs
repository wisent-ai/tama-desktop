//! Changing the build policy: what an option may do, and what needs the
//! operator's consent.
//!
//! Split out of `builds/policy.rs`, which had grown past the
//! three-hundred-line limit. The limits and how they are read stay there;
//! writing a new value is here, because that is where the consent belongs.
//! Loosening a limit is a change to what the machine permits, so it takes
//! the consent every hook configuration change takes
//! ([`crate::hooks::declare::consent`]): his word in the conversation,
//! recorded as the session's hook-edit capability, or the device variable
//! in his own shell.

use std::path::Path;

use serde_json::json;

use super::policy::{in_effect, load, stored, Policy, LIMITS};
use crate::hooks::declare::{consent_route, consented};

/// Applies the options present in `argv` to the stored policy. Returns the new
/// policy and the lines describing what changed; refuses a loosening, or a
/// first setting of a limit the file did not state, without the operator's consent,
/// naming the option and the direction.
pub fn revise(path: &Path, argv: &[String]) -> Result<(Policy, Vec<String>), String> {
    let mut document = stored(path)?;
    let mut changes = Vec::new();
    for limit in LIMITS.iter() {
        // The value is the argument after the option; an option given without
        // one is refused rather than skipped.
        let mut from_option = argv.iter().skip_while(|item| *item != limit.option);
        if from_option.next().is_none() {
            continue;
        }
        let Some(raw) = from_option.next() else {
            return Err(format!("{} needs a whole number after it", limit.option));
        };
        let value: u64 = raw
            .parse()
            .map_err(|error| format!("{} is a whole number, not {raw}: {error}", limit.option))?;
        let was = in_effect(&document, limit.field);
        if was == Some(value) {
            continue;
        }
        let loosens = match was {
            None => true,
            Some(was) if limit.larger_permits_more => value > was,
            Some(was) => value < was,
        };
        let from = match was {
            Some(was) => was.to_string(),
            None => "unset".to_string(),
        };
        if loosens && !consented() {
            return Err(format!(
                "{} from {from} to {value} permits more work than the operator's policy does, so \
                 it needs the operator's consent. Tightening a limit needs nothing. {}",
                limit.option,
                consent_route(&format!("tama build policy {} {value}", limit.option))
            ));
        }
        document[limit.field] = json!(value);
        let direction = if loosens { "loosened" } else { "tightened" };
        changes.push(format!("{} {direction} {from} -> {value}", limit.field));
    }
    if !changes.is_empty() {
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent)
                .map_err(|error| format!("{} cannot be created: {error}", parent.display()))?;
        }
        let text = serde_json::to_string_pretty(&document).map_err(|error| {
            format!(
                "the policy for {} cannot be written as JSON: {error}",
                path.display()
            )
        })?;
        std::fs::write(path, format!("{text}\n"))
            .map_err(|error| format!("{} cannot be written: {error}", path.display()))?;
    }
    Ok((load(path)?, changes))
}
