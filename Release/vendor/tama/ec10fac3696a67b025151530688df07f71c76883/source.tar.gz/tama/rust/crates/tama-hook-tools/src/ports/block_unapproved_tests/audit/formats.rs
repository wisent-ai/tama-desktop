//! Which repository files run as tests by their own contents: the source
//! formats whose test markers live inside the file, the JavaScript and
//! TypeScript formats a runner reads a test file of by its name, and the
//! directories runners collect a whole file from. Each is an identifier of
//! a language or a test runner's convention.

use std::path::Path;

use super::super::detect::carries_test_code;

/// Source formats whose test markers live inside the file.
pub(super) const INLINE_TEST_FORMATS: &[&str] = &[RUST_FORMAT, PYTHON_FORMAT, SWIFT_FORMAT];
const RUST_FORMAT: &str = "rs";
const PYTHON_FORMAT: &str = "py";
const SWIFT_FORMAT: &str = "swift";
/// The formats a runner reads a test file of by its `.test.`/`.spec.` name.
const NAMED_TEST_FORMATS: &[&str] = &[
    JS_FORMAT, MJS_FORMAT, CJS_FORMAT, TS_FORMAT, TSX_FORMAT, JSX_FORMAT, MTS_FORMAT, CTS_FORMAT,
];
const JS_FORMAT: &str = "js";
const MJS_FORMAT: &str = "mjs";
const CJS_FORMAT: &str = "cjs";
const TS_FORMAT: &str = "ts";
const TSX_FORMAT: &str = "tsx";
const JSX_FORMAT: &str = "jsx";
const MTS_FORMAT: &str = "mts";
const CTS_FORMAT: &str = "cts";
const TEST_NAME_MARKER: &str = ".test.";
const SPEC_NAME_MARKER: &str = ".spec.";
/// The directories test runners collect a whole file from.
const TEST_DIRECTORIES: &[&str] = &[TEST_DIRECTORY, TESTS_DIRECTORY, JEST_DIRECTORY];
const TEST_DIRECTORY: &str = "test";
const TESTS_DIRECTORY: &str = "tests";
const JEST_DIRECTORY: &str = "__tests__";
const PATH_SEPARATOR: char = '/';

/// The format a repository path is written in, by its extension.
pub(super) fn format_of(relative: &str) -> Option<&str> {
    Path::new(relative)
        .extension()
        .and_then(|extension| extension.to_str())
}

/// Only a dedicated test directory proves that a whole file is safe for
/// automatic removal. A `test_*.py` production route, `tests.rs` source
/// module, or `.test.ts` file elsewhere still needs human review even when
/// its name and contents resemble a runner's test.
pub(super) fn runs_as_test(relative: &str, path: &Path) -> bool {
    let in_test_directory = relative.split(PATH_SEPARATOR).any(|component| {
        TEST_DIRECTORIES
            .iter()
            .any(|name| component.eq_ignore_ascii_case(name))
    });
    if !in_test_directory {
        return false;
    }
    let name = match relative.rsplit_once(PATH_SEPARATOR) {
        Some((_, name)) => name,
        None => relative,
    };
    match format_of(name) {
        Some(format) if INLINE_TEST_FORMATS.contains(&format) => {
            std::fs::read_to_string(path).is_ok_and(|text| carries_test_code(&text))
        }
        Some(format) if NAMED_TEST_FORMATS.contains(&format) => {
            name.contains(TEST_NAME_MARKER) || name.contains(SPEC_NAME_MARKER)
        }
        _ => false,
    }
}
