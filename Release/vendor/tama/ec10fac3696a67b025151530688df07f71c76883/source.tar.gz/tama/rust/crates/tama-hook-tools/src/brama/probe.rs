//! What the model catalogue of the model service Tama asks says about this
//! machine's credential, without spending quota: Brama by default, or the
//! OpenAI-compatible service `tama model set` declared. A
//! successful GET is not evidence that chat works: a resolver can forward
//! chat to a different authority or a local proxy can require another
//! capability. The detached drafter records its actual POST outcome in the
//! learned-rules digest.

use std::io::Write;
use std::process::{Command, Stdio};

use serde::Serialize;

use super::credentials::{allowed_endpoint, read};
use super::declared::{declared_provider, provider_path};
use super::request::curl_config_value;

/// What the probe observed. No credential value ever enters this struct.
#[derive(Debug, Serialize)]
pub struct Reachability {
    /// The model service asked: `brama`, or the origin of the declared one.
    pub provider: String,
    /// The chat endpoint the client would post to.
    pub endpoint: String,
    /// Whether that endpoint passes the client's own transport policy.
    pub endpoint_allowed: bool,
    /// The models endpoint actually probed.
    pub probed: String,
    /// The HTTP status the service answered with, as curl reported it.
    pub status: Option<String>,
    /// Whether the service accepted the credential: curl, run with
    /// `fail-with-body`, succeeded on an answered request.
    pub accepted: bool,
    /// The service's own error body, or the model count when it answered.
    pub detail: String,
    /// Who this machine says it is, and where its credential lives.
    pub consumer: String,
    pub token_file: String,
    /// The route, or the declared service's model, the reviewer would ask for.
    pub route: String,
    /// Whether this machine's own authority grants that route to that
    /// consumer on the token in that file. Asked only of Brama: a declared
    /// service's key is not a Skarbiec grant.
    pub local_grant: Option<bool>,
    pub local_grant_detail: String,
    /// Which of the two halves is missing, in one sentence.
    pub verdict: String,
}

/// The sentence an operator acts on.
///
/// A refusal alone would mean "repair that credential at its authority",
/// which sends somebody into the vault while the bearer is valid there all
/// along and the gateway is the side deployed without the authority
/// variables that let it ask. These facts, read together, say which side
/// is wrong.
pub fn verdict(
    status: Option<&str>,
    accepted: bool,
    allowed: bool,
    local_grant: Option<bool>,
) -> String {
    if !allowed {
        return "the address this machine resolved is not one this client may use".to_string();
    }
    match (status, accepted, local_grant) {
        (None, _, _) => "nothing answered at that address".to_string(),
        (Some(_), true, _) => {
            "the model catalogue accepts this bearer; chat was not tested".to_string()
        }
        (Some(code), false, Some(true)) => format!(
            "this machine's authority grants the route on this bearer, and the gateway still \
             refuses it with {code}: the gateway is not asking this authority - check that its \
             deployment carries WC_SKARBIEC_URL, BRAMA_SKARBIEC_CONSUMER and \
             BRAMA_SKARBIEC_TOKEN_FILE"
        ),
        (Some(code), false, Some(false)) => format!(
            "the gateway refuses with {code} and this machine's authority does not grant this \
             route to this consumer: issue it with `skarbiec grant issue <consumer> \
             --capabilities call:brama#<route> --token-file <path>`"
        ),
        (Some(code), false, None) => format!(
            "the gateway refuses this bearer with {code} and this machine's authority could not \
             be asked"
        ),
    }
}

/// The model catalogue beside a chat endpoint. Every endpoint this client
/// posts to ends in the chat-completions path; one that does not names no
/// catalogue, and that is the error rather than probing the chat path.
fn models_url(chat_endpoint: &str) -> Result<String, String> {
    chat_endpoint
        .strip_suffix("/chat/completions")
        .map(|base| format!("{base}/models"))
        .ok_or_else(|| {
            format!("{chat_endpoint} is not a chat-completions endpoint, so it names no model catalogue")
        })
}

/// The sentence for a declared OpenAI-compatible service, which has no
/// Skarbiec side: its key is the whole credential.
fn declared_verdict(origin: &str, status: Option<&str>, accepted: bool, allowed: bool) -> String {
    if !allowed {
        return format!("{origin} is not an address this client may use");
    }
    match (status, accepted) {
        (None, _) => format!("nothing answered at {origin}"),
        (Some(_), true) => {
            format!("{origin}'s model catalogue accepts the declared key; chat was not tested")
        }
        (Some(code), false) => format!(
            "{origin} refuses the declared key with {code}: declare the service again with \
             `tama model set`, or return Tama to Brama with `tama model unset`"
        ),
    }
}

/// Presents the credential to `GET /v1/models` of the model service Tama
/// asks and reports what it answered. The headers reach curl through a
/// `--config` document on standard input, so the bearer never enters argv.
/// Errors name credential, transport policy, channel and client failures.
pub fn reachability() -> Result<Reachability, String> {
    let declared = declared_provider()?;
    let credentials = read()?;
    let endpoint = credentials.endpoint.clone();
    let allowed = allowed_endpoint(&endpoint);
    if !allowed {
        return Err(format!(
            "model catalogue request refused before sending credentials: endpoint {endpoint} \
             must use HTTPS or HTTP on loopback and the chat completions path"
        ));
    }
    super::channel::check_channel(&endpoint)?;
    let probed = models_url(&endpoint)?;
    let config = format!(
        "url = \"{}\"\nheader = \"Authorization: Bearer {}\"\nheader = \"Accept: application/json\"\nsilent\nshow-error\nfail-with-body\nwrite-out = \"\\n%{{http_code}}\"\n",
        curl_config_value(&probed),
        curl_config_value(&credentials.bearer),
    );
    let mut child = Command::new("/usr/bin/curl")
        .args(["--disable", "--config", "-"])
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .map_err(|error| format!("cannot start the model service HTTP client: {error}"))?;
    let written = child
        .stdin
        .take()
        .ok_or_else(|| "the model service HTTP client has no input pipe".to_string())
        .and_then(|mut input| {
            input
                .write_all(config.as_bytes())
                .map_err(|error| format!("cannot write the model catalogue request: {error}"))
        });
    if let Err(mut cause) = written {
        let termination = child.kill();
        let reaped = stado_wait::child_output(child, "model catalogue client after input failure");
        if let Err(error) = termination {
            cause.push_str(&format!(
                "; cannot terminate model catalogue client: {error}"
            ));
        }
        match reaped {
            Ok(output) => cause.push_str(&format!(
                "; model catalogue client ended with {}: {}",
                output.status,
                String::from_utf8_lossy(&output.stderr).trim()
            )),
            Err(error) => cause.push_str(&format!(
                "; cannot collect model catalogue client termination: {error}"
            )),
        }
        return Err(cause);
    }
    let output = stado_wait::child_output(child, "model catalogue response")
        .map_err(|error| format!("the model catalogue request did not complete: {error}"))?;
    let route = super::credentials::model_route()?;
    let (provider, consumer, token_file, local_grant, local_grant_detail) = match &declared {
        Some(found) => (
            found.origin.clone(),
            "the key declared with tama model set".to_string(),
            provider_path().display().to_string(),
            None,
            "a declared model service's key is not a Skarbiec grant".to_string(),
        ),
        None => {
            let (grant, detail) = match super::credentials::local_grant(&route) {
                Ok(granted) => (Some(granted), String::new()),
                Err(refusal) => (None, refusal),
            };
            (
                "brama".to_string(),
                super::credentials::consumer()?,
                super::credentials::token_path()?.display().to_string(),
                grant,
                detail,
            )
        }
    };
    let sentence = |status: Option<&str>, accepted: bool| match &declared {
        Some(found) => declared_verdict(&found.origin, status, accepted, allowed),
        None => verdict(status, accepted, allowed, local_grant),
    };
    let response = String::from_utf8_lossy(&output.stdout).to_string();
    // curl writes `000` when no HTTP response arrived at all.
    let answered = response
        .rsplit_once('\n')
        .map(|(body, code)| (body, code.trim()))
        .filter(|(_, code)| !code.is_empty() && !code.chars().all(|digit| digit == '0'));
    let Some((body, code)) = answered else {
        return Ok(Reachability {
            verdict: sentence(None, false),
            provider,
            endpoint_allowed: allowed,
            endpoint,
            probed,
            status: None,
            accepted: false,
            detail: String::from_utf8_lossy(&output.stderr).trim().to_string(),
            consumer,
            token_file,
            route,
            local_grant,
            local_grant_detail,
        });
    };
    let accepted = output.status.success();
    let detail = if accepted {
        model_count(body)
    } else {
        body.trim().to_string()
    };
    Ok(Reachability {
        verdict: sentence(Some(code), accepted),
        provider,
        endpoint_allowed: allowed,
        endpoint,
        probed,
        status: Some(code.to_string()),
        accepted,
        detail,
        consumer,
        token_file,
        route,
        local_grant,
        local_grant_detail,
    })
}

/// A successful answer is a model list; report its size rather than its
/// contents, which are long and not what the probe is asking about. An
/// answer that is not one is said, with the body it was.
fn model_count(body: &str) -> String {
    match serde_json::from_str::<serde_json::Value>(body) {
        Ok(decoded) => match decoded.get("data").and_then(serde_json::Value::as_array) {
            Some(models) => format!("{} models offered", models.len()),
            None => format!(
                "the catalogue answered without a data list: {}",
                body.trim()
            ),
        },
        Err(error) => format!(
            "the catalogue answered with no JSON ({error}): {}",
            body.trim()
        ),
    }
}
