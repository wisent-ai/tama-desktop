//! The completion refusal every Stop gate gives while Oko holds open work:
//! how much is open, how much this session carries, the one item to take now
//! and the commands that print the rest.
//!
//! The refusal is injected into the session after every Stop, and the
//! session reads it again on every later call until it compacts. A refusal
//! listing every open defect and task of every session would put tens of
//! thousands of tokens into each refused turn while the next step it names
//! is one item; the lists are the registers' to print, so the refusal names
//! the commands that print them instead of copying them. The operator's
//! answers to the excuses agents give and his rulings reach the session at
//! session start and after every compaction (`inject-operator-rules`); a
//! refusal repeats only the rulings on the item it selects.

use tama_hooks::sha256::sha256_hex;

use crate::registry::shell_quote;

use super::super::{rules, rulings};
use super::NOT_A_BLOCKER;

/// The command that prints the open tasks of every session.
pub const LIST_TASKS: &str = "oko tasks owed";
/// The command that prints every open defect with no pushed repair.
pub const LIST_UNREPAIRED: &str = "oko defects list --unrepaired";

/// The identity of the open set a refusal counts: every open task line and
/// defect id it was counted from, sorted and hashed. Two refusals naming one
/// digest counted one set; a changed digest says the set changed, without
/// copying a single identity into the session.
pub fn open_set_digest<'a>(items: impl IntoIterator<Item = &'a str>) -> String {
    let mut items: Vec<&str> = items.into_iter().collect();
    items.sort_unstable();
    sha256_hex(items.join("\n").as_bytes())
}

/// A selected register identity and its instruction travel together.
pub struct Action {
    pub subject: Option<String>,
    pub text: String,
}

/// What one refusal says.
pub struct Summary<'a> {
    pub session: &'a str,
    /// What Oko holds open, counted: `12 open tasks of every session and
    /// 1980 open defects of every product`.
    pub held: String,
    /// This session's own open tasks and defects; counted, not copied into
    /// the refusal, even when this session owns the whole register.
    pub own: Vec<String>,
    /// The selected identity comes from the register, never from its prose.
    pub next: &'a Action,
    /// Further lines the reading produced: counts outside the session's
    /// scope, an unreadable blocker register, the batch build.
    pub notes: Vec<String>,
    /// When Oko recorded that its judge cannot answer, if it did.
    pub judge_down: Option<String>,
}

/// The refusal for `summary`.
pub fn refusal(summary: &Summary) -> String {
    let own = summary.own.len();
    let session = shell_quote(summary.session);
    let mut out = format!(
        "BLOCKED (completion): Oko holds {}.\nThis session's own items: {own}.\nTake now: {}.\n\
         The lists are not copied here; read them with `{LIST_TASKS}`, `{LIST_UNREPAIRED}` and \
         `oko defects list --open --owner {session}`, and one item with `oko tasks show ID` or \
         `oko defects show ID`.",
        summary.held, summary.next.text
    );
    let subject = summary.next.subject.as_deref();
    let ruled = rulings::on_open_work(subject.as_slice(), &[]);
    if !ruled.is_empty() {
        out.push_str(&format!(
            "\nThe operator already ruled on these items; follow the ruling, and never ask him \
             again or list it as a blocker or a next step: {}.",
            ruled.join("; ")
        ));
    }
    for note in &summary.notes {
        out.push('\n');
        out.push_str(note);
    }
    out.push('\n');
    out.push_str(&check(summary.session, summary.judge_down.as_deref()));
    out.push(' ');
    out.push_str(NOT_A_BLOCKER);
    out
}

/// What closes a task: Oko's before-stop verdict, or, while its judge is
/// down, the recorded evidence and the repair of the judge.
fn check(session: &str, judge_down: Option<&str>) -> String {
    if let Some(at) = judge_down {
        return format!(
            "Oko recorded at {at} that its judge cannot answer, and the before-stop pass refuses \
             until it can, so do not run it now. Repairing the judge is work, not a wait: take \
             the defect that records its outage, or record one, and repair it. Record the \
             evidence of delivered work in Oko meanwhile."
        );
    }
    let mut verify = format!(
        "{} tasks verify --before-stop --session {}",
        shell_quote(&rules::oko_cli()),
        shell_quote(session)
    );
    if let Ok(database) = std::env::var("OKO_TRANSCRIPT_INDEX_PATH") {
        if !database.is_empty() {
            verify.push_str(&format!(" --db {}", shell_quote(&database)));
        }
    }
    format!(
        "After delivering and checking a task's real result, run {verify} and inspect the \
         verdict. A local plan cannot close Oko tasks."
    )
}

/// The sentence that sends the session to `task`, an Oko task line, when it
/// carries a task identity: the scope command that selects it.
pub fn take_task(session: &str, line: &str) -> Option<Action> {
    let id = line
        .split_once("(task-")
        .and_then(|(_, rest)| rest.split_once(')'))
        .map(|(id, _)| format!("task-{id}"))?;
    Some(Action {
        text: format!(
            "{line} — run `tama task scope set --session {} --task {id}` and do that task",
            shell_quote(session)
        ),
        subject: Some(id),
    })
}
