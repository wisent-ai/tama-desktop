//! The frustration-attribution bridge.
//!
//! An advisory component: it never changes a verdict and always exits zero.
//! Its dispatcher detaches it with stderr closed, so a failure is kept as a
//! warning frame in the run's adaptive telemetry segment (closed under
//! `telemetry-segments/ready/`), naming the operation and its cause.
//!
//! No word list decides anything here. A prompt that names a blocked hook
//! contests it; with one candidate block, a model reads whether the prompt
//! says that block was wrong; and whether the prompt shows frustration at all
//! is the same model reading the frustration detector uses.

use std::io::{IsTerminal, Read};

use serde_json::{json, Value};

use crate::engine::{load_engine, Engine};
use crate::telemetry::{open_telemetry, Telemetry};
use tama_core::exit;

mod dispatch;

pub use dispatch::dispatch;

/// The typed question asked about the user's next message after a block.
const DISPUTE_QUESTION: &str = "The state names a safety hook that blocked an AI assistant's \
    action, the reason it gave when it gave one, and the next message the user wrote. Does the \
    user's message say this block was wrong?";
const DISPUTED: &str = "the message says the block was wrong, should not have happened, or asks \
    for the hook to be repaired";
const NOT_DISPUTED: &str = "the message says nothing of the kind";

/// Whether Brama's typed decision reads `prompt` as saying the block by `id`
/// for `reason` was wrong, or why it could not be asked.
fn disputes(prompt: &str, id: &str, reason: Option<&str>) -> Result<bool, String> {
    let mut state = format!("HOOK: {id}\n");
    if let Some(reason) = reason {
        state.push_str(&format!("REASON: {reason}\n"));
    }
    state.push_str(&format!("USER: {prompt}"));
    tama_hook_tools::brama::decision::asks(&state, DISPUTE_QUESTION, DISPUTED, NOT_DISPUTED)
}

/// The prompt the dispatcher handed over on stdin.
fn read_stdin() -> Result<String, String> {
    let mut stdin = std::io::stdin();
    if stdin.is_terminal() {
        return Err("no prompt was handed over: stdin is a terminal".to_string());
    }
    let mut text = String::new();
    stdin
        .read_to_string(&mut text)
        .map_err(|error| format!("the handed prompt cannot be read from stdin: {error}"))?;
    Ok(text)
}

/// The non-empty string under the first of `keys` that holds one.
fn named<'a>(object: &'a Value, keys: &[&str]) -> Option<&'a str> {
    keys.iter()
        .filter_map(|key| object.get(*key).and_then(Value::as_str))
        .find(|text| !text.is_empty())
}

/// The hooks the session's latest episode blocked, each once, in order.
fn candidate_ids(blocks: &[Value]) -> Vec<&str> {
    let mut ids: Vec<&str> = Vec::new();
    for id in blocks.iter().filter_map(|block| named(block, &["hookId"])) {
        if !ids.contains(&id) {
            ids.push(id);
        }
    }
    ids
}

/// The reason the first block by `id` gave, when it gave one.
fn reason_of<'a>(blocks: &'a [Value], id: &str) -> Option<&'a str> {
    blocks
        .iter()
        .find(|block| named(block, &["hookId"]) == Some(id))
        .and_then(|block| named(block, &["reason"]))
}

/// The blocks the prompt contests: the ones it names, else the only one
/// when a model reads the prompt as saying it was wrong.
fn contested_ids<'a>(
    prompt: &str,
    ids: &[&'a str],
    blocks: &[Value],
) -> Result<Vec<&'a str>, String> {
    let named: Vec<&str> = ids
        .iter()
        .copied()
        .filter(|id| prompt.contains(id))
        .collect();
    if !named.is_empty() {
        return Ok(named);
    }
    match ids {
        [only] if disputes(prompt, only, reason_of(blocks, only))? => Ok(vec![*only]),
        _ => Ok(Vec::new()),
    }
}

fn body(engine: &Engine, telemetry: &Telemetry) -> Result<(), String> {
    let raw = read_stdin()?;
    let payload: Value = serde_json::from_str(&raw)
        .map_err(|error| format!("the handed prompt is not a JSON event: {error}"))?;
    let raw_event = payload.get("raw_event").filter(|event| event.is_object());
    let in_event = |keys: &[&str]| {
        named(&payload, keys).or_else(|| raw_event.and_then(|event| named(event, keys)))
    };
    let session_id = in_event(&["session_id", "sessionId"]);
    let episode_id = in_event(&["turn_id", "turnId"]);
    let blocks = engine.consume_latest_episode_blocks(session_id);
    let Some(prompt) = named(&payload, &["prompt", "user_message"]) else {
        return Ok(());
    };
    // A prompt the harness's own automation wrote corrects nothing the owner
    // saw: it neither contests a block nor counts as frustration.
    if prompt.trim().is_empty() || tama_core::frustration::written_by_automation(&payload) {
        return Ok(());
    }
    let ids = candidate_ids(&blocks);
    if ids.is_empty() {
        return Ok(());
    }
    // A judge Brama cannot reach costs only the readings that need it
    // (`~/agents/boundaries.md`, every product works on its own): a prompt
    // that names a blocked hook still contests it, and the warning names the
    // reading that was lost and why, instead of dropping the whole prompt.
    let contested = match contested_ids(prompt, &ids, &blocks) {
        Ok(contested) => contested,
        Err(cause) => {
            telemetry.warn(&format!(
                "adaptive bridge: whether the prompt disputes its only block was not read: {cause}"
            ));
            Vec::new()
        }
    };
    let frustrated = match tama_hook_tools::ports::detect_frustration::frustrated(prompt) {
        Ok(frustrated) => Some(frustrated),
        Err(cause) => {
            telemetry.warn(&format!(
                "adaptive bridge: whether the prompt shows frustration was not read: {cause}"
            ));
            None
        }
    };
    // A direct correction of the blocked action records a contested-block
    // fact; frustration is recommendation evidence only.
    if frustrated != Some(true) && contested.is_empty() {
        return Ok(());
    }
    telemetry.frustration(&json!({
        "frustrated": frustrated,
        "session_id": session_id,
        "episode_id": episode_id,
        "candidateHookIds": ids,
    }));
    for id in &ids {
        if !contested.contains(id) {
            telemetry.frustration(&json!({
                "kind": "recommendation",
                "id": id,
                "session_id": session_id,
                "episode_id": episode_id,
                "reason": reason_of(&blocks, id),
            }));
            continue;
        }
        let transition = engine
            .record_contested_block(id)
            .map_err(|error| format!("the contest of {id} cannot be recorded: {error}"))?;
        telemetry.frustration(&json!({
            "kind": "explicit_contest",
            "id": id,
            "session_id": session_id,
            "episode_id": episode_id,
            "adaptiveStatePersisted": transition.persisted,
        }));
        telemetry.corpus_label(
            &Value::from(*id),
            &json!({ "label": "fp-suspect", "source": "explicit-user-correction" }),
        );
        telemetry.queue_repair(&json!({
            "id": id,
            "kind": "fp",
            "evidence": format!("corpus/{id}.jsonl"),
        }));
    }
    Ok(())
}

/// `main().then(finish, finish)`: always exits zero; a failure is kept as a
/// telemetry warning when the engine loads, and said on stderr when not.
pub fn main() -> i32 {
    match load_engine() {
        Ok(engine) => {
            let telemetry = open_telemetry(&engine.state_dir);
            if let Err(cause) = body(&engine, &telemetry) {
                telemetry.warn(&format!(
                    "adaptive bridge: no attribution for this prompt: {cause}"
                ));
            }
            telemetry.close();
        }
        Err(error) => {
            eprintln!("adaptive bridge: no attribution, the engine cannot load: {error}")
        }
    }
    exit::SUCCESS
}
