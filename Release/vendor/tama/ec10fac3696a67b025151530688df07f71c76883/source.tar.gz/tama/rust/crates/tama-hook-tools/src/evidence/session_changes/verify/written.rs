//! When a staged path whose edits by a session do not replay carries nothing
//! of that session: none of its edits there was refused, HEAD holds the state
//! its newest edit left, the index holds none of the states its edits left,
//! and no mark any of its edits changed is a mark the staged change changes.
//!
//! A state's marks are its lines that name work and every pair of adjacent
//! lines. A mark is changed between two states where it occurs more often or
//! less often in one than in the other, whichever way: a second copy of a
//! line counts, and a moved or reordered line, or a moved bracket, changes
//! the pairs around it. A line holding nothing but blanks, brackets, `;` and
//! `,` is no mark alone, as it names no work of its own; it still counts
//! inside its pairs. An absent file holds no mark.
//!
//! A conflicted path's states are not renewed by a commit, so once HEAD moves
//! past the session's newest state the path is refused again for as long as
//! that session runs: a reading that cannot be renewed is never trusted.

use std::collections::{BTreeMap, BTreeSet};

use super::super::Change;

/// One mark: a line that names work, or two adjacent lines.
type Mark<'a> = Vec<&'a str>;
/// Every occurrence of each mark of a state; a mark a state does not hold
/// has no entry.
type Occurrences<'a> = BTreeMap<Mark<'a>, Vec<()>>;

/// Whether `owned`, the session's change of a path its edits do not replay
/// onto, leaves nothing of that session in `indexed`. `refused` says that one
/// of its edits there could not be established, which cut the states before
/// it out of `owned`, so what the session wrote there is no longer known.
pub(super) fn admits(
    owned: &Change,
    refused: bool,
    head: Option<&str>,
    indexed: Option<&str>,
) -> bool {
    let newest = owned.steps.last().map(|step| step.after.as_deref());
    if refused
        || newest != Some(head)
        || owned
            .steps
            .iter()
            .any(|step| step.after.as_deref() == indexed)
    {
        return false;
    }
    let staged = changed(&occurrences(head), &occurrences(indexed));
    owned.steps.iter().all(|step| {
        let before = occurrences(step.before.as_deref());
        changed(&before, &occurrences(step.after.as_deref())).is_disjoint(&staged)
    })
}

/// Each mark of `text` with every place it occurs.
fn occurrences(text: Option<&str>) -> Occurrences<'_> {
    let lines: Vec<&str> = text.into_iter().flat_map(str::lines).collect();
    let mut found = Occurrences::new();
    for line in lines.iter().filter(|line| names_work(line)) {
        found.entry(vec![*line]).or_default().push(());
    }
    let mut following = lines.iter();
    following.next();
    for (line, next) in lines.iter().zip(following) {
        found.entry(vec![*line, *next]).or_default().push(());
    }
    found
}

/// Whether `line` holds anything but blanks, brackets, `;` and `,`.
fn names_work(line: &str) -> bool {
    line.chars()
        .any(|c| !c.is_whitespace() && !"{}()[];,".contains(c))
}

/// The marks that occur a different number of times in `one` and `other`,
/// a mark one of them does not hold included.
fn changed<'a>(one: &Occurrences<'a>, other: &Occurrences<'a>) -> BTreeSet<Mark<'a>> {
    one.keys()
        .chain(other.keys())
        .filter(|mark| one.get(*mark).map(Vec::len) != other.get(*mark).map(Vec::len))
        .cloned()
        .collect()
}
