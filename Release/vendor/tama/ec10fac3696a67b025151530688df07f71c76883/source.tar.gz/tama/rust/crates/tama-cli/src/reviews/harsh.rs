//! `tama reviews harsh record|dispose|settle|show`: the rounds of a commit's
//! harsh review that `tama hook review-commit` reads (`ports::harsh_review`).
//!
//! A reviewer that is not the author reads `git diff --cached` and the
//! message the commit will carry, and records its round ([`super::round`]):
//! what it finds in the change and what the change suggests for the rest of
//! the codebase, each quoting the patch or the message, or none. The round is
//! kept, then every open entry of Oko's harsh-review queue that queues that
//! very candidate is marked reviewed; a failure after the round was kept
//! leaves it standing, and the same record run again keeps no second copy. A
//! finding the author records as an Oko defect instead of repairing it is
//! disposed naming that defect, which Oko must hold. A finding repaired on another
//! line while its quoted line stays staged is settled by a reviewer naming
//! where it was repaired. `show` lists the rounds of the
//! commit being made, the verdict they give the staged candidate now, and
//! Oko's harsh-review queue: the candidates waiting for a reviewer session
//! and who reviewed the rest. The verdict judges the candidate as made by the
//! session Oko's queue records for its staged tree, so a reviewer asking is
//! not taken for the author; only a tree no entry names is the invoker's,
//! and `author.source` says which. With `--queue <id>` a reviewer session reads
//! and records one queued candidate instead ([`super::queue`]); an entry
//! another round already answered is refused to `show` before its patch is
//! read, so no reviewer spends a round nobody can record.
//! With `--attestation <kind>:<session>` a reviewer records its round on a
//! session's recorded task or build attestation ([`super::attested`]).

use std::path::PathBuf;
use std::process::Command;

use tama_core::exit::{FAILURE, SUCCESS, USAGE as USAGE_STATUS};
use tama_hook_tools::assignment::rules::oko_cli;
use tama_hook_tools::ports::harsh_review::{
    append, digest, now_ms, owed_everywhere, queue, read, register, reviewer_here, staged_patch,
    staged_tree, verdict, Entry, Verdict,
};

const USAGE: &str =
    "tama reviews harsh record --findings <file> --improvements <file> (--message <file> [--tree <tree read>] | --queue <id>) \
[--repository <path>]\n\
tama reviews harsh record --findings <file> --improvements <file> --attestation (session|build):<session id>\n\
tama reviews harsh dispose --quote <text> --defect <oko defect id> [--repository <path>]\n\
tama reviews harsh settle --quote <text> --reason <where it was repaired> [--repository <path>]\n\
tama reviews harsh show [--message <file> | --queue <id>] [--repository <path>] [--json]\n\
tama reviews harsh request --message <file> [--item <id>] [--within-minutes <n>] [--repository <path>]\n\
tama reviews harsh run --message <file> (--defect <id> | --task <id>) [--repository <path>]";

/// The value after `name` in `args`.
pub(super) fn option<'a>(args: &'a [String], name: &str) -> Option<&'a str> {
    let mut rest = args.iter().skip_while(|arg| arg.as_str() != name);
    rest.next()?;
    rest.next().map(String::as_str)
}

pub(super) fn required<'a>(args: &'a [String], name: &str) -> Result<&'a str, String> {
    option(args, name).ok_or_else(|| format!("{name} is required\n{USAGE}"))
}

pub(super) fn repository(args: &[String]) -> Result<PathBuf, String> {
    match option(args, "--repository") {
        Some(path) => Ok(PathBuf::from(path)),
        None => std::env::current_dir()
            .map_err(|cause| format!("the current directory cannot be read: {cause}")),
    }
}

pub(super) fn text(path: &str) -> Result<String, String> {
    std::fs::read_to_string(path).map_err(|cause| format!("cannot read {path}: {cause}"))
}

/// Whether Oko holds `defect`.
fn registered(defect: &str) -> Result<(), String> {
    let program = oko_cli();
    let output =
        stado_wait::output(Command::new(&program).args(["defects", "show", defect, "--json"]))
            .map_err(|cause| format!("cannot run {program} defects show {defect}: {cause}"))?;
    if output.status.success() {
        return Ok(());
    }
    Err(format!(
        "{program} defects show {defect} refused ({}): {}",
        output.status,
        String::from_utf8_lossy(&output.stderr).trim()
    ))
}

fn dispose(args: &[String]) -> Result<String, String> {
    let repository = repository(args)?;
    let quote = required(args, "--quote")?;
    let defect = required(args, "--defect")?;
    let path = register(&repository)?;
    let found = read(&path)?.iter().any(|entry| match entry {
        Entry::Round { findings, .. } => findings.iter().any(|finding| finding.quote == quote),
        Entry::Disposed { .. } | Entry::Settled { .. } | Entry::Owed { .. } => false,
    });
    if !found {
        return Err(format!("no round in {} found {quote:?}", path.display()));
    }
    registered(defect)?;
    append(
        &path,
        &Entry::Disposed {
            quote: quote.to_string(),
            defect: defect.to_string(),
            at_ms: now_ms()?,
        },
    )?;
    Ok(format!(
        "recorded {quote:?} as defect {defect}, in {}",
        path.display()
    ))
}

/// A finding a reviewer settles as repaired although its quoted line stays
/// staged: the repair is elsewhere, and `--reason` says where. The quote must
/// be one a round found; who settles is read as a round's reviewer is, and
/// the verdict counts a settlement only by someone other than the author.
fn settle(args: &[String]) -> Result<String, String> {
    let repository = repository(args)?;
    let quote = required(args, "--quote")?;
    let reason = required(args, "--reason")?.trim();
    if reason.is_empty() {
        return Err(format!(
            "--reason must say where {quote:?} was repaired\n{USAGE}"
        ));
    }
    let path = register(&repository)?;
    let found = read(&path)?.iter().any(|entry| match entry {
        Entry::Round { findings, .. } => findings.iter().any(|finding| finding.quote == quote),
        Entry::Disposed { .. } | Entry::Settled { .. } | Entry::Owed { .. } => false,
    });
    if !found {
        return Err(format!("no round in {} found {quote:?}", path.display()));
    }
    let reviewer = reviewer_here()?;
    append(
        &path,
        &Entry::Settled {
            quote: quote.to_string(),
            reason: reason.to_string(),
            reviewer: reviewer.clone(),
            at_ms: now_ms()?,
        },
    )?;
    Ok(format!(
        "{} settled {quote:?} as repaired: {reason}, in {}",
        reviewer.named(),
        path.display()
    ))
}

/// The rounds of the commit `repository` is making, and, given the message
/// it will carry, the verdict they give the staged candidate now, beside
/// Oko's harsh-review queue: the document `show --json` prints and the
/// native `reviews/harsh` request returns. Without a message the rounds are
/// listed and no verdict is given.
pub(crate) fn rounds_document(
    repository: &std::path::Path,
    message: Option<&str>,
) -> Result<(serde_json::Value, bool), String> {
    let path = register(repository)?;
    let entries = read(&path)?;
    let tree = staged_tree(repository)?;
    let listed = queue::listed()?;
    let (admitted, said, author) = match message {
        Some(message) => {
            let patch = staged_patch(repository)?;
            let (author, source) = queue::author_of_tree(&tree, &listed, reviewer_here)?;
            let named = serde_json::json!({"author": queue::named(&author), "source": source});
            match verdict(&entries, &tree, &digest(message), &patch, &author) {
                Verdict::Admitted(trailer) => (Some(true), Some(trailer), named),
                Verdict::Unreviewed(reason) | Verdict::Refused(reason) => (
                    Some(false),
                    Some(format!("{reason} (author {source})")),
                    named,
                ),
            }
        }
        None => (None, None, serde_json::Value::Null),
    };
    // The model rounds a commit stood without, because the model did not
    // answer, in every register of the repository: an owed round stays in
    // the register of the commit it was owed for, whichever commit follows.
    let document = serde_json::json!({
        "register": path, "tree": tree, "entries": entries, "admitted": admitted, "verdict": said,
        "author": author, "owed": owed_everywhere(repository)?, "queue": listed,
    });
    Ok((document, admitted != Some(false)))
}

/// One line per queue entry: who staged which tree, and who reviews it.
fn queue_lines(listing: &serde_json::Value) -> Vec<String> {
    listing["entries"]
        .as_array()
        .into_iter()
        .flatten()
        .map(|entry| {
            format!(
                "queue {} {}: tree {} in {} by {}; reviewer {}",
                entry["id"],
                entry["state"],
                entry["tree"],
                entry["repository"],
                entry["author"],
                entry["reviewer"]
            )
        })
        .collect()
}

fn show(args: &[String]) -> Result<(String, bool), String> {
    let as_json = args.iter().any(|arg| arg == "--json");
    if let Some(id) = option(args, "--queue") {
        return super::queue::show(id, as_json).map(|said| (said, true));
    }
    let repository = repository(args)?;
    let message = match option(args, "--message") {
        Some(path) => Some(text(path)?),
        None => None,
    };
    let (document, passes) = rounds_document(&repository, message.as_deref())?;
    if as_json {
        return Ok((document.to_string(), passes));
    }
    let listed: Vec<String> = document["entries"]
        .as_array()
        .into_iter()
        .flatten()
        .map(serde_json::Value::to_string)
        .collect();
    let said = match document["verdict"].as_str() {
        Some(said) => said.to_string(),
        None => "no message given, so no verdict: pass --message <file>".to_string(),
    };
    Ok((
        format!(
            "{}\n{}\n{said}\n{}\n{}",
            document["register"],
            listed.join("\n"),
            Entry::owed_lines(&document["owed"]).join("\n"),
            queue_lines(&document["queue"]).join("\n")
        ),
        passes,
    ))
}

pub(crate) fn main(args: &[String]) -> i32 {
    let outcome = match args.first().map(String::as_str) {
        Some("record") => super::round::record(args).map(|said| (said, true)),
        Some("dispose") => dispose(args).map(|said| (said, true)),
        Some("settle") => settle(args).map(|said| (said, true)),
        Some("show") => show(args),
        Some("run") => super::run::run(args),
        Some("request") => super::queue::request(
            repository(args),
            option(args, "--message"),
            option(args, "--item"),
            option(args, "--within-minutes"),
        )
        .map(|said| (said, true)),
        _ => {
            eprintln!("{USAGE}");
            return USAGE_STATUS;
        }
    };
    match outcome {
        Ok((said, true)) => {
            println!("{said}");
            SUCCESS
        }
        Ok((said, false)) => {
            println!("{said}");
            FAILURE
        }
        Err(cause) => {
            eprintln!("reviews harsh: {cause}");
            FAILURE
        }
    }
}
