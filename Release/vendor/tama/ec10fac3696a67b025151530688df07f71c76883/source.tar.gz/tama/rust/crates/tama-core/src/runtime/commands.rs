//! Whether a command an adapter installs is the command the registry
//! declares for a hook.
//!
//! Every hook the registry declares runs as the one program, `tama hook
//! <id>`, and provider configs reach the engine through one process
//! transport. So a command is read by its structure: which program it runs
//! and, for `tama`, which subcommand and argument it names.

/// The file name of the process transport provider configs run, which hands
/// each hook event to `tama run-hook` (https://tama.wisent.com/docs/hook-system/runtime/adapters).
const ENGINE_ENTRYPOINT: &str = "run-hook.mjs";

/// One shell word with a single leading and trailing quote taken off.
fn unquoted(part: &str) -> &str {
    let part = match part.strip_prefix(['\'', '"']) {
        Some(inner) => inner,
        None => part,
    };
    match part.strip_suffix(['\'', '"']) {
        Some(inner) => inner,
        None => part,
    }
}

/// The file name a word names: its last path segment.
fn file_name(word: &str) -> &str {
    match word.rsplit_once('/') {
        Some((_, name)) => name,
        None => word,
    }
}

/// The subcommand and its first argument, when it has one, when `command`
/// runs the one `tama` program — `…/tama hook <name>` or `…/tama run-hook
/// <event>` — wherever the program token stands (an `env` prefix comes first
/// in adapters). An argument the command does not give stays absent, so a
/// bare `tama run-hook` is not read as one naming an empty event.
fn tama_subcommand(command: &str) -> Option<(String, Option<String>)> {
    let mut parts = command
        .split_whitespace()
        .map(unquoted)
        .skip_while(|part| file_name(part) != "tama");
    parts.next()?;
    let subcommand = parts.next()?;
    Some((subcommand.to_string(), parts.next().map(str::to_string)))
}

/// Whether `command` hands its event to the engine: it runs the engine's
/// process transport, or `tama run-hook` itself.
fn through_engine(command: &str, tama: Option<&(String, Option<String>)>) -> bool {
    command
        .split_whitespace()
        .map(unquoted)
        .any(|word| file_name(word) == ENGINE_ENTRYPOINT)
        || tama.is_some_and(|(subcommand, _)| subcommand == "run-hook")
}

/// JS `commandsMatch(adapterCommand, registryCommand, hookId)`.
pub(crate) fn commands_match(adapter_command: &str, registry_command: &str, hook_id: &str) -> bool {
    if adapter_command == registry_command {
        return true;
    }
    let adapter_tama = tama_subcommand(adapter_command);
    if !hook_id.is_empty()
        && (adapter_command.contains(&format!("TAMA_ONLY_HOOK_ID='{hook_id}'"))
            || adapter_command.contains(&format!("TAMA_ONLY_HOOK_ID=\"{hook_id}\"")))
        && through_engine(adapter_command, adapter_tama.as_ref())
    {
        return true;
    }
    // Two commands that each run `tama` are the same hook only when they name
    // the same subcommand and argument. A command that runs anything else is
    // a declared hook only when it is that command, compared above.
    match (adapter_tama, tama_subcommand(registry_command)) {
        (Some(adapter), Some(registry)) => adapter == registry,
        _ => false,
    }
}
