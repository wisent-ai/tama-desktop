//! `tama build` — the registry of intended builds and restarts.
//!
//! `block-unregistered-build-or-restart` refuses a command that would build a
//! product or restart a service unless `~/.shared-hooks/build_restart_registry.json`
//! holds an open entry for it. This command is the way that entry is written,
//! for the same reason `tama justify` exists: every other path into
//! `.shared-hooks` is refused by the consent and write gates, and a registry
//! is data with an interface rather than a file somebody edits by hand.
//!
//! A build entry states which whole task the agent says is finished, what the
//! build is for, which revision it carries, and when authorization stops.
//! The guard consumes it for one build attempt. A restart entry retains its
//! ordinary window. The statement is an auditable claim, not proof of completion.

use serde_json::{json, Value};
use tama_core::exit::{SUCCESS, USAGE as USAGE_STATUS};

pub(crate) mod api;
mod intent;
mod pending;
mod policy;
mod policy_revision;
mod ration;

use intent::{described, emit, home, now, refuse};

const USAGE: &str = "usage: tama build record --kind build|restart --target <name> \
--reason <text> [--revision <source revision>] [--completed-task <whole task finished>] \
[--repository <path>] [--minutes <1-240>] \
[--approval-session <id> --approval-quote <verbatim operator message>] [--home <path>] [--json]\n       \
tama build list [--home <path>] [--json]\n       \
tama build approval --target <name> --revision <source revision> [--home <path>] [--json]\n       \
tama build close --kind build|restart --target <name> [--not-started <refusal>] [--home <path>] [--json]\n       \
tama build pending --target <name> [--repository <path>] [--home <path>] [--json]\n       \
tama build fail --target <name> --revision <revision the failed build carried> --failure <what it answered> [--repository <path>] [--home <path>] [--json]\n       \
tama build policy [--builds-per-day <n>] [--restarts-per-day <n>] \
[--minimum-changed-lines <n>] [--window-minutes <n>] [--home <path>] [--json]\n\n       \
A build uses the fleet's daily budget when available, otherwise a local allowance of three in \
24 hours. It carries at least thirty changed lines and one intent authorizes sixty minutes. \
Tightening a limit needs nothing; loosening one needs the operator's consent: his word in the \
conversation recorded as the session capability {\"tool\": \"tama\", \"actions\": [\"hook-edit\"]}, \
or DEVICE_HOOK_EDIT_APPROVED=1 in his own shell. A verified operator message can instead authorize a recorded exception for \
one build of the named product without changing the policy.";
const REGISTRY_FILE: &str = "build_restart_registry.json";

/// A string field of a result this command produced, or the JSON value
/// itself when it is not a string, so nothing absent is shown as empty.
fn text(value: &Value) -> String {
    match value.as_str() {
        Some(text) => text.to_string(),
        None => value.to_string(),
    }
}

/// How many items a list field holds, or the JSON value itself when it is not
/// a list, so an absent list is not shown as none.
fn count(value: &Value) -> String {
    match value.as_array() {
        Some(items) => items.len().to_string(),
        None => value.to_string(),
    }
}

/// The arguments `action` cannot run without, read by the same readers the
/// action itself uses: one missing or malformed is a usage error, refused
/// before anything is read or changed.
fn arguments(action: &str, argv: &[String]) -> Result<(), String> {
    match action {
        "record" | "close" => {
            intent::kind_of(argv)?;
            intent::target_of(argv)?;
        }
        "approval" => {
            api::approval_arguments(argv)?;
        }
        "pending" => {
            intent::target_of(argv)?;
        }
        "fail" => {
            pending::fail_arguments(argv)?;
        }
        _ => {}
    }
    Ok(())
}

pub fn main(argv: &[String]) -> i32 {
    let Some(action) = argv.first().map(String::as_str) else {
        eprintln!("tama build needs an action\n{USAGE}");
        return USAGE_STATUS;
    };
    if action == "help" || action == "--help" || action == "-h" {
        println!("{USAGE}");
        return SUCCESS;
    }
    if let Err(message) = arguments(action, argv) {
        eprintln!("{message}\n{USAGE}");
        return USAGE_STATUS;
    }
    let json = argv.iter().any(|item| item == "--json");
    let home = match home(argv) {
        Ok(home) => home,
        Err(message) => return refuse(&message),
    };
    let policy_file = policy::file(&home);
    if action == "policy" {
        let (policy, changes) = match policy::revise(&policy_file, argv) {
            Ok(result) => result,
            Err(message) => return refuse(&message),
        };
        let said = if changes.is_empty() {
            format!("{}\npolicy: {}", policy_file.display(), policy.sentence())
        } else {
            format!("{}\n{}", changes.join("\n"), policy.sentence())
        };
        emit(
            json,
            &said,
            &json!({"policy": policy.document(), "changed": changes, "file": policy_file}),
        );
        return SUCCESS;
    }
    // Every sentence below says how long an entry still stands, judged at
    // one reading of the clock.
    let at = match now() {
        Ok(at) => at,
        Err(message) => return refuse(&message),
    };
    match action {
        "record" => {
            let result = match api::record(argv, &home) {
                Ok(result) => result,
                Err(message) => return refuse(&message),
            };
            let count = match result["fleet_remaining"].as_u64() {
                Some(left) => format!("the fleet has {left} build jobs left today"),
                None => format!(
                    "{} of {} intents in this 24 hours",
                    result["spent"], result["allowed"]
                ),
            };
            emit(
                json,
                &format!(
                    "recorded {} ({count})",
                    described(&text(&result["recorded"]), &result["entry"], at)
                ),
                &result,
            );
            SUCCESS
        }
        "list" => {
            let result = match api::list(&home) {
                Ok(result) => result,
                Err(message) => return refuse(&message),
            };
            let (Some(rows), Some(ration)) =
                (result["entries"].as_array(), result["ration"].as_array())
            else {
                return refuse(&format!(
                    "the build registry answered no entries or ration list: {result}"
                ));
            };
            let said = if rows.is_empty() {
                "no build or restart entries".to_owned()
            } else {
                rows.iter()
                    .map(|row| described(&text(&row["key"]), &row["entry"], at))
                    .collect::<Vec<_>>()
                    .join("\n")
            };
            let counted = ration
                .iter()
                .map(|row| match row["fleet_remaining"].as_u64() {
                    Some(left) => format!("the fleet has {left} build jobs left today"),
                    None => format!(
                        "{} of {} {}s spent in this 24 hours",
                        row["spent"],
                        row["allowed"],
                        text(&row["kind"])
                    ),
                })
                .collect::<Vec<_>>()
                .join("; ");
            emit(json, &format!("{said}\n{counted}"), &result);
            SUCCESS
        }
        "approval" => {
            let entry = match api::approval(argv, &home) {
                Ok(entry) => entry,
                Err(message) => return refuse(&message),
            };
            emit(json, &described("approved build", &entry, at), &entry);
            SUCCESS
        }
        "close" => {
            let result = match api::close(argv, &home) {
                Ok(result) => result,
                Err(message) => return refuse(&message),
            };
            let said = match result["not_started"]["revision"].as_str() {
                Some(revision) => format!(
                    "closed {}; revision {revision} never started, so the next build is measured \
                     against the last one that did",
                    text(&result["closed"])
                ),
                None => format!("closed {}", text(&result["closed"])),
            };
            emit(json, &said, &result);
            SUCCESS
        }
        "pending" => {
            let result = match pending::pending(argv, &home) {
                Ok(result) => result,
                Err(message) => return refuse(&message),
            };
            let built = match result["last_built"].as_str() {
                Some(built) => built.to_string(),
                None => "never recorded".to_string(),
            };
            let lines = match result["changed_lines"].as_u64() {
                Some(lines) => format!(
                    "{lines} changed lines against the minimum of {}",
                    result["minimum_changed_lines"]
                ),
                None => "no earlier build to measure against".to_string(),
            };
            let tasks: Vec<String> = result["tasks"]
                .as_array()
                .into_iter()
                .flatten()
                .map(|task| format!("  {} carried by {}", task["task"], task["commit"]))
                .collect();
            let said = format!(
                "{}: last built {built}, {} now; {} commit(s) waiting, {lines}; {}\n{}",
                text(&result["target"]),
                text(&result["tip"]),
                count(&result["commits"]),
                if result["due"].as_bool() == Some(true) {
                    "a build is due"
                } else {
                    "not enough change for a build yet"
                },
                tasks.join("\n"),
            );
            emit(json, said.trim_end(), &result);
            SUCCESS
        }
        "fail" => {
            let result = match pending::fail(argv, &home) {
                Ok(result) => result,
                Err(message) => return refuse(&message),
            };
            let said = format!(
                "the failed build of {} at {} carried {} commit(s); reopened {} task(s), {} refused",
                text(&result["target"]),
                text(&result["revision"]),
                count(&result["commits"]),
                count(&result["reopened"]),
                count(&result["refused"]),
            );
            emit(json, &said, &result);
            SUCCESS
        }
        other => {
            // An unknown action is a usage error: the usage and the usage status.
            eprintln!("unknown action {other}\n{USAGE}");
            USAGE_STATUS
        }
    }
}
