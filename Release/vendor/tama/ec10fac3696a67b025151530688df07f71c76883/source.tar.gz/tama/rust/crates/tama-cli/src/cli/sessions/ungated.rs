//! The OMP processes on this machine that run a session with no gates: a
//! process no session-control record names by its pid. Tama's adapter
//! writes that record when OMP loads it, and OMP loads an extension only
//! when it starts, so a process started before the adapter was declared or
//! released, or started without it, never writes one, and `tama sessions
//! reload` has nothing to reload in it. Such a session runs every call
//! ungated until it continues in a process that loads the adapter, which is
//! what `oko sessions resume` starts.

use std::path::Path;
use std::process::Command;

use serde::Serialize;

/// One OMP process whose session runs ungated.
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub(super) struct Ungated {
    pid: u32,
    /// The session whose transcript the process holds open, when it holds one.
    session: Option<String>,
    route: String,
}

impl Ungated {
    /// The row `tama sessions` prints for this process.
    pub(super) fn said(&self) -> String {
        let session = match &self.session {
            Some(session) => session.as_str(),
            None => "no session",
        };
        format!("omp\t{session}\tpid {}\tUNGATED: {}", self.pid, self.route)
    }
}

/// The file name OMP's executable runs under.
const OMP: &str = "omp";
/// What OMP's own worker processes carry in their arguments; they run no session.
const WORKER: &str = "__omp_worker";

/// The OMP processes on this machine, with their command line, from `ps`.
fn omp_processes() -> Result<Vec<u32>, String> {
    let mut command = Command::new("/bin/ps");
    command.args(["-A", "-o", "pid=,command="]);
    let output = stado_wait::output(&mut command)
        .map_err(|error| format!("ps could not run to list OMP processes: {error}"))?;
    if !output.status.success() {
        return Err(format!("ps refused ({})", output.status));
    }
    let mut found = Vec::new();
    for line in String::from_utf8_lossy(&output.stdout).lines() {
        let line = line.trim_start();
        let Some((pid, command)) = line.split_once(' ') else {
            continue;
        };
        // A process `ps` shows with no command line is not OMP.
        let Some(program) = command.split_whitespace().next() else {
            continue;
        };
        if Path::new(program)
            .file_name()
            .and_then(|name| name.to_str())
            != Some(OMP)
            || command.contains(WORKER)
        {
            continue;
        }
        let pid = pid
            .parse::<u32>()
            .map_err(|error| format!("ps printed a pid that is no pid ({pid}): {error}"))?;
        found.push(pid);
    }
    Ok(found)
}

/// The session whose transcript `pid` holds open under `sessions`, from `lsof`.
fn session_of(pid: u32, sessions: &Path) -> Result<Option<String>, String> {
    let mut command = Command::new("lsof");
    command.args(["-p", &pid.to_string(), "-Fn"]);
    let output = stado_wait::output(&mut command)
        .map_err(|error| format!("lsof could not run for pid {pid}: {error}"))?;
    let root = sessions.to_string_lossy();
    Ok(String::from_utf8_lossy(&output.stdout)
        .lines()
        .filter_map(|line| line.strip_prefix('n'))
        .filter(|path| path.starts_with(root.as_ref()) && path.ends_with(".jsonl"))
        .filter_map(|path| {
            Path::new(path)
                .file_stem()?
                .to_str()?
                .rsplit('_')
                .next()
                .map(str::to_string)
        })
        .next_back())
}

/// Every OMP process under `home` that no session-control record names by
/// its pid and the session it holds (`recorded`: each record's pid and
/// session). A record of the same pid for another session does not gate
/// it: OMP switches and resumes sessions in one process, and the session
/// it holds now is the one whose adapter record is missing.
pub(super) fn find(
    home: &Path,
    recorded: &[(u64, Option<String>)],
) -> Result<Vec<Ungated>, String> {
    let sessions = home.join(".omp/agent/sessions");
    let mut ungated = Vec::new();
    for pid in omp_processes()? {
        let session = session_of(pid, &sessions)?;
        let gated = recorded.iter().any(|(held, recorded_session)| {
            *held == u64::from(pid)
                && (session.is_none() || recorded_session.as_deref() == session.as_deref())
        });
        if gated {
            continue;
        }
        let route = match &session {
            Some(session) => format!(
                "its OMP never loaded Tama's adapter, so `tama sessions reload` cannot reach it; `oko sessions resume {session}` \
                 continues it in a process that loads the adapter"
            ),
            None => "its OMP holds no session transcript and never loaded Tama's adapter".to_string(),
        };
        ungated.push(Ungated {
            pid,
            session,
            route,
        });
    }
    Ok(ungated)
}
