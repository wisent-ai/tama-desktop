//! A build typed instead of registered, and a Python module or script run
//! where Python is not a route.

use super::super::vocabulary::*;

/// The compile a command line would start, spelled as the refusal names it:
/// `cargo test`, `swift build`, `npm run build`, `xcodebuild`, `stado host
/// build`, `stado product cargo`. `None` for everything else, including a
/// help request.
///
/// Every driver is read here: a gate that names only `cargo` watches a
/// session run `swift build` and `swift test` all afternoon, and a gate
/// that does not know the fleet's own compile commands lets `stado host
/// build` release compiles through one after another.
pub(crate) fn compile_named(program: &str, args: &[String]) -> Option<String> {
    let words = &*VOCABULARY;
    if asks_for_help(args) {
        return None;
    }
    let mut plain = args.iter().map(String::as_str).filter(|arg| !is_flag(arg));
    if program == words.fleet_program {
        let command = format!("{} {}", plain.next()?, plain.next()?);
        let compiles = has(&words.fleet_compile_commands, &command)
            && !args.iter().any(|arg| {
                let name = match arg.split_once('=') {
                    Some((name, _)) => name,
                    None => arg,
                };
                has(&words.fleet_non_compile_flags, name)
            });
        return compiles.then(|| format!("{} {command}", words.fleet_program));
    }
    if program == words.toolchain_program {
        let command = plain.next()?;
        return has(&words.toolchain_compile_commands, command)
            .then(|| format!("{} {command}", words.toolchain_program));
    }
    if has(&words.build_programs, program) {
        return Some(program.to_owned());
    }
    let verbs = words.build_drivers.get(program)?;
    // `npm run build` names what it runs in the second word, so both are read,
    // and a script runner's script is named too. Whether that script compiles
    // is read from `package.json` by `admission::runs_no_compile` before any
    // gate applies; here, without a checkout, every script counts as one.
    let first = plain.next()?;
    let verb = if has(verbs, first) {
        match plain.next() {
            Some(script) if first == SCRIPT_RUNNER_VERB => format!("{first} {script}"),
            _ => first.to_owned(),
        }
    } else {
        let second = plain.next().filter(|word| has(verbs, word))?;
        format!("{first} {second}")
    };
    Some(format!("{program} {verb}"))
}

/// A build, a compile or a test that Oko's admission refuses, named as the
/// toolchain spells it, with Oko's reason: the ruling that forbids it, the
/// open items it waits on, or why Oko could not be read.
pub(crate) fn compile_refusal(program: &str, args: &[String], refused: &str) -> String {
    let words = &*VOCABULARY;
    let name = match compile_named(program, args) {
        Some(name) => name,
        None => program.to_owned(),
    };
    format!(
        "{BANNER}`{name}` builds, compiles or tests, and Oko does not admit it: {refused}\n{}",
        words.compile_gate_route
    )
}

/// The interpreter family whose modules and scripts are not a route here.
const PYTHON_PROGRAM: &str = "python";
const PYTHON_MODULE_FLAG: &str = "-m";
const PYTHON_SCRIPT_SUFFIX: &str = ".py";

/// A module or a script handed to a python interpreter, whatever its path or
/// version: `python3 -m <module>`, `/opt/…/python3.14 tools/x.py`. The
/// operator's rule is that Python is not used here; a tool that only exists
/// in Python is a product command still to be built, not a route.
pub(crate) fn python_run_refusal(program: &str, args: &[String]) -> Option<String> {
    let name = std::path::Path::new(program).file_name()?.to_str()?;
    let version = name.strip_prefix(PYTHON_PROGRAM)?;
    if !version.chars().all(|c| c.is_ascii_digit() || c == '.') {
        return None;
    }
    let runs = args.iter().any(|arg| arg == PYTHON_MODULE_FLAG)
        || args
            .iter()
            .find(|arg| !is_flag(arg))
            .is_some_and(|arg| arg.ends_with(PYTHON_SCRIPT_SUFFIX));
    runs.then(|| {
        format!(
            "{BANNER}`{name}` runs a Python module or script. Python is not used in this \
             workshop: use the product command that does this job; when none exists, that \
             missing command is the product work to build, in the product's own language."
        )
    })
}
