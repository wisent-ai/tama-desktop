//! The operator's standing rulings compared with a final answer by Oko:
//! `oko rulings check --from <session> --text <answer> --json`, the gate every
//! channel to him runs (a session's final answer, a Slack reply, a message
//! composed on Oko Desktop). It refuses an answer that asks him again what he
//! already decided, quoting his words, and an answer no model compared,
//! writing his rulings to a file and asking the session to say how its
//! answer differs from each one that bears on it (`--differs`). Its exit
//! status is the decision: zero lets the answer go, anything else refuses it
//! with Oko's own sentence. An Oko that cannot be run compared nothing, and
//! no comparison is never a pass.

use std::process::Command;

use crate::assignment::rules::oko_cli;

/// The refusal Oko's comparison gives `answer` from `session`, or none when
/// it may go.
pub(super) fn refusal(tag: &str, session: &str, answer: &str) -> Option<String> {
    let program = oko_cli();
    let shown = format!("{program} rulings check --from {session} --text <the answer> --json");
    let mut command = Command::new(&program);
    command.args([
        "rulings", "check", "--from", session, "--text", answer, "--json",
    ]);
    let output = match stado_wait::output(&mut command) {
        Ok(output) => output,
        Err(error) => {
            return Some(format!(
                "{tag}: the operator's rulings were not compared with this answer, because {shown} \
                 cannot run: {error}; no comparison is never a pass, so nothing reaches him"
            ))
        }
    };
    if output.status.success() {
        return None;
    }
    let said = String::from_utf8_lossy(&output.stderr);
    Some(format!(
        "{tag}: Oko refused this answer: {} Read the file it names, then run `{program} rulings \
         check --from {session} --text '<this answer>' --differs '<how it differs from each ruling \
         that bears on it, by its id>'` yourself and end the turn with the same answer, or take out \
         what the operator already decided.",
        said.trim()
    ))
}
