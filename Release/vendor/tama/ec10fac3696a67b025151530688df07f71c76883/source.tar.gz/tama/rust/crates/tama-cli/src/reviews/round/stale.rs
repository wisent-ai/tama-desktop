//! A queued tree staged on a parent HEAD has since moved past keeps the
//! commits that landed in between, or it gets no round.
//!
//! A candidate is staged into its own index on the HEAD it was read on, and
//! a reviewer reads its patch against that parent, so the patch shows only
//! the author's change. When commits land on HEAD before the commit is made,
//! a tree that does not carry them takes them back, and nothing in its own
//! patch says so. So before a round is kept over a tree whose parent is no
//! longer HEAD, Git merges the commits since the parent onto the tree (`git
//! merge-tree` with the parent as the merge base): a tree that already holds
//! every one of them merges to itself. Any other tree is refused, naming each
//! path that differs and each commit since the parent that changed it, unless
//! the message reverts that commit in the words `git revert` writes,
//! `Revert "<subject>"`.

use std::path::Path;

use crate::gitcmd::git;

/// Git's answer, trimmed.
fn answer(repository: &Path, args: &[&str]) -> Result<String, String> {
    git(repository, args).map(|text| text.trim().to_string())
}

/// Refuse a round over `tree`, staged on `parent` in `repository` with
/// `message`, when it takes back a commit that landed on HEAD since `parent`.
pub(crate) fn taken_back(
    repository: &Path,
    parent: &str,
    tree: &str,
    message: &str,
) -> Result<(), String> {
    let head = answer(repository, &["rev-parse", "--verify", "HEAD^{commit}"])?;
    let base = answer(
        repository,
        &["rev-parse", "--verify", &format!("{parent}^{{commit}}")],
    )?;
    if base == head {
        return Ok(());
    }
    let moved = answer(
        repository,
        &["diff", "--name-only", "--no-renames", &base, &head],
    )?;
    if moved.is_empty() {
        return Ok(());
    }
    // `merge-tree` merges commits, so the tree is read as a commit on its
    // parent: an object Git writes and no ref names.
    let candidate = answer(
        repository,
        &[
            "commit-tree",
            tree,
            "-p",
            &base,
            "-m",
            "candidate read before its harsh-review round",
        ],
    )?;
    let merged = git(repository, &["merge-tree", "--write-tree", "--merge-base", &base, &head, &candidate])
        .map_err(|cause| {
            format!(
                "tree {tree} was staged on {parent}, HEAD has moved to {head} since, and the commits in between \
                 do not merge onto it ({cause}); stage the change again on HEAD and queue it again"
            )
        })?;
    let merged = merged
        .lines()
        .next()
        .map(|line| line.trim().to_string())
        .ok_or_else(|| {
            format!("git merge-tree printed no tree for {tree} merged with {base}..{head}")
        })?;
    let staged = answer(
        repository,
        &["rev-parse", "--verify", &format!("{tree}^{{tree}}")],
    )?;
    if merged == staged {
        return Ok(());
    }
    let paths = answer(
        repository,
        &["diff", "--name-only", "--no-renames", &staged, &merged],
    )?;
    let mut taken = Vec::new();
    for path in paths.lines() {
        let range = format!("{base}..{head}");
        let subjects = answer(repository, &["log", "--format=%s", &range, "--", path])?;
        let unreverted: Vec<&str> = subjects
            .lines()
            .filter(|subject| !message.contains(&format!("Revert \"{subject}\"")))
            .collect();
        if !unreverted.is_empty() {
            taken.push(format!("{path}: {}", unreverted.join("; ")));
        }
    }
    if taken.is_empty() {
        return Ok(());
    }
    Err(format!(
        "tree {tree} was staged on {parent} and HEAD has moved to {head} since; the tree does not carry what \
         these commits since its parent changed, so committing it would take them back:\n    {}\nstage the change \
         again on HEAD (or say Revert \"<subject>\" for each in its message when it reverts them) and queue it again",
        taken.join("\n    ")
    ))
}
