//! Filesystem primitives the catalogue reading needs.

use std::fs;
use std::io::Read;
use std::path::Path;

use crate::Result;

/// Path as a string without trailing slash (Node's `path.join` normalizes it away).
pub(crate) fn root_str(root: &Path) -> String {
    let s = root.to_string_lossy();
    let trimmed = s.trim_end_matches('/');
    if trimmed.is_empty() {
        "/".to_string()
    } else {
        trimmed.to_string()
    }
}

/// Node `path.join(base, part)` for the simple cases used here.
pub(crate) fn join_path(base: &str, part: &str) -> String {
    format!("{}/{}", base.trim_end_matches('/'), part)
}

/// Node `path.relative(root, path)` for a `path` under `root`; a path outside
/// it is the error, never handed back whole as if it were relative.
pub(crate) fn strip_root<'a>(root_s: &str, path: &'a str) -> Result<&'a str> {
    path.strip_prefix(root_s.trim_end_matches('/'))
        .and_then(|relative| relative.strip_prefix('/'))
        .ok_or_else(|| crate::err(format!("{path} is not under {root_s}")))
}

/// JS `walk(dir, out)`: recursive file listing, skipping
/// `.git`, `__pycache__`, `state`, `recall_dumps` directories. A `dir` that
/// is not there lists nothing; one that cannot be examined is the error.
///
/// Every failure names the operation and the path it failed on. A bare
/// `Operation not permitted (os error 1)` is what `tama validate` printed on
/// a build worker, and it says nothing about which directory refused the
/// read, which is the one fact needed to repair it.
pub(crate) fn walk(dir: &str, out: &mut Vec<String>) -> Result<()> {
    if !crate::presence::present(Path::new(dir)).map_err(|error| crate::err(error.to_string()))? {
        return Ok(());
    }
    let entries =
        fs::read_dir(dir).map_err(|error| crate::err(format!("reading {dir}: {error}")))?;
    for entry in entries {
        let entry = entry.map_err(|error| crate::err(format!("reading {dir}: {error}")))?;
        let name = entry.file_name().to_string_lossy().into_owned();
        let path = join_path(dir, &name);
        // JS `statSync` follows symlinks; so does `fs::metadata`.
        let st =
            fs::metadata(&path).map_err(|error| crate::err(format!("stat of {path}: {error}")))?;
        if st.is_dir() {
            if ![".git", "__pycache__", "state", "recall_dumps"].contains(&name.as_str()) {
                walk(&path, out)?;
            }
            continue;
        }
        out.push(path);
    }
    Ok(())
}

/// The two bytes a file that runs as its own program starts with, before the
/// interpreter it names (the `#!` line POSIX `execve` reads).
const INTERPRETER_MARK: &[u8] = b"#!";

/// Whether the file at `path` runs as a program of its own: it starts with
/// the line naming its interpreter. A module other programs import, or a
/// data file, does not. A file that cannot be opened or read is the error,
/// naming it.
pub fn names_interpreter(path: &str) -> Result<bool> {
    let file = fs::File::open(path).map_err(|error| {
        format!("cannot open {path} to read whether it names its interpreter: {error}")
    })?;
    let mut head = Vec::new();
    file.take(INTERPRETER_MARK.len() as u64)
        .read_to_end(&mut head)
        .map_err(|error| {
            format!("cannot read the first line of {path} to tell whether it names its interpreter: {error}")
        })?;
    Ok(head == INTERPRETER_MARK)
}

/// JS template-literal interpolation of a possibly-missing string, which
/// renders an absent one as "undefined".
pub(crate) fn js_opt(value: Option<&str>) -> &str {
    match value {
        Some(value) => value,
        None => "undefined",
    }
}

/// Node `path.extname`: suffix from the last `.` in the basename, or "" when
/// the basename has no `.` or only a leading one.
pub(crate) fn extname(path: &str) -> &str {
    let base = match path.rsplit_once('/') {
        Some((_, base)) => base,
        None => path,
    };
    match base.rsplit_once('.') {
        Some((stem, _)) if !stem.is_empty() => &base[stem.len()..],
        _ => "",
    }
}
