//! The judge's verdicts on command declarations, kept, and `tama commands
//! judge <request>`, which asks for them away from the write.
//!
//! Asking the judge inside the write made every write that declares a
//! command wait as long as the judge took (minutes on the local route) while
//! the harness gives a hook seconds, so the write was refused by the
//! harness's own limit whatever the judge would have said. Now a write is
//! decided by the verdicts already kept, by the hash of the file path,
//! command name and declaration. A command without one is still refused, never
//! let through: the write records a request and names the foreground operation
//! `tama commands judge <request>`. No judge child outlives the refusing hook.
//! That operation owns the model call, keeps its verdicts and prints them; the
//! next write of the same declarations is decided by those verdicts.

use std::collections::BTreeMap;
use std::fs::{File, OpenOptions};
use std::io::Write;
use std::path::{Path, PathBuf};

use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use tama_hooks::session_control::tama_state_root;

use super::{judge, Command, Verdict, HOOK_ID};

const DIRECTORY: &str = "command-verdicts";
const VERDICTS: &str = "verdicts.json";
const VERDICTS_ENV: &str = "TAMA_COMMAND_VERDICTS_DIR";

/// The kept verdicts' directory: `TAMA_COMMAND_VERDICTS_DIR`, or
/// `<Tama state>/command-verdicts`.
fn directory() -> PathBuf {
    match std::env::var_os(VERDICTS_ENV).filter(|value| !value.is_empty()) {
        Some(path) => PathBuf::from(path),
        None => tama_state_root().join(DIRECTORY),
    }
}

/// Bind a verdict to the same path and declaration that the judge reads.
pub fn key(file_path: &str, command: &Command) -> String {
    let mut hash = Sha256::new();
    hash.update(file_path.len().to_string());
    hash.update(":");
    hash.update(file_path.as_bytes());
    hash.update(command.name.as_bytes());
    hash.update("\n");
    hash.update(command.declaration.as_bytes());
    format!("{:x}", hash.finalize())
}

/// One kept verdict: `None` passed, `Some` is why the judge blocked it.
#[derive(Debug, Clone, Serialize, Deserialize)]
struct Kept {
    name: String,
    blocked: Option<String>,
}

/// A refused write's commands, waiting for the judge.
#[derive(Debug, Serialize, Deserialize)]
struct Request {
    file_path: String,
    commands: Vec<(String, String)>,
}

fn open(path: &Path) -> Result<File, String> {
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)
            .map_err(|error| format!("cannot create {}: {error}", parent.display()))?;
    }
    OpenOptions::new()
        .create(true)
        .write(true)
        .truncate(false)
        .open(path)
        .map_err(|error| format!("cannot open {}: {error}", path.display()))
}

fn kept() -> Result<BTreeMap<String, Kept>, String> {
    let path = directory().join(VERDICTS);
    match std::fs::read_to_string(&path) {
        Ok(text) => serde_json::from_str(&text)
            .map_err(|error| format!("{} is not a map of kept verdicts: {error}", path.display())),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(BTreeMap::new()),
        Err(error) => Err(format!("cannot read {}: {error}", path.display())),
    }
}

/// The kept verdict of every command in `found`, or `None` when one has
/// none yet.
pub fn known(file_path: &str, found: &[Command]) -> Result<Option<Vec<Verdict>>, String> {
    let kept = kept()?;
    Ok(found
        .iter()
        .map(|command| {
            kept.get(&key(file_path, command))
                .map(|verdict| (command.clone(), verdict.blocked.clone()))
        })
        .collect())
}

/// Merge `verdicts` into the kept ones as they stand now, under a lock.
fn keep(file_path: &str, verdicts: &[Verdict]) -> Result<(), String> {
    let lock = open(&directory().join("verdicts.lock"))?;
    lock.lock()
        .map_err(|error| format!("cannot lock the kept verdicts: {error}"))?;
    let mut all = kept()?;
    for (command, blocked) in verdicts {
        all.insert(
            key(file_path, command),
            Kept {
                name: command.name.clone(),
                blocked: blocked.clone(),
            },
        );
    }
    let path = directory().join(VERDICTS);
    let staged = path.with_extension("staged");
    let text = serde_json::to_string(&all).map_err(|error| error.to_string())?;
    std::fs::write(&staged, text)
        .and_then(|()| std::fs::rename(&staged, &path))
        .map_err(|error| format!("cannot keep the verdicts in {}: {error}", path.display()))
}

/// Publish the commands the foreground judge must read, without starting it.
pub fn request(file_path: &str, found: &[Command]) -> Result<String, String> {
    let mut hash = Sha256::new();
    found
        .iter()
        .for_each(|command| hash.update(key(file_path, command)));
    let id = format!("{:x}", hash.finalize());
    let requests = directory().join("requests");
    let lock = open(&requests.join(format!("{id}.lock")))?;
    match lock.try_lock() {
        Ok(()) => {}
        Err(std::fs::TryLockError::WouldBlock) => return Ok(id),
        Err(error) => return Err(format!("cannot lock request {id}: {error}")),
    }
    let record = Request {
        file_path: file_path.to_string(),
        commands: found
            .iter()
            .map(|command| (command.name.clone(), command.declaration.clone()))
            .collect(),
    };
    let text = serde_json::to_string(&record).map_err(|error| error.to_string())?;
    let path = requests.join(format!("{id}.json"));
    let staged = path.with_extension("staged");
    std::fs::create_dir_all(&requests)
        .and_then(|()| std::fs::write(&staged, text))
        .and_then(|()| std::fs::rename(&staged, &path))
        .map_err(|error| {
            format!(
                "cannot record the request in {}: {error}",
                requests.display()
            )
        })?;
    Ok(id)
}

/// Ask the judge about commands without a kept verdict. A concurrent reviewer
/// owns this request until it exits; refuse rather than start another call.
fn judge_request(id: &str) -> Result<(Vec<Verdict>, String), String> {
    let requests = directory().join("requests");
    let lock = open(&requests.join(format!("{id}.lock")))?;
    match lock.try_lock() {
        Ok(()) => {}
        Err(std::fs::TryLockError::WouldBlock) => {
            return Err(format!(
                "request {id} is already owned by a running review; read that operation's result"
            ));
        }
        Err(error) => return Err(format!("cannot lock request {id}: {error}")),
    }
    let path = requests.join(format!("{id}.json"));
    let text = std::fs::read_to_string(&path)
        .map_err(|error| format!("no request {id} in {}: {error}", requests.display()))?;
    let record: Request = serde_json::from_str(&text)
        .map_err(|error| format!("{} is not a request: {error}", path.display()))?;
    let found: Vec<Command> = record
        .commands
        .into_iter()
        .map(|(name, declaration)| Command { name, declaration })
        .collect();
    let verdicts = match known(&record.file_path, &found)? {
        Some(verdicts) => verdicts,
        None => {
            let verdicts = judge(&record.file_path, &found)?;
            keep(&record.file_path, &verdicts)?;
            verdicts
        }
    };
    Ok((verdicts, record.file_path))
}

/// `tama commands judge <request>`: prints `<name>: PASS` or `<name>: BLOCK:
/// <why>` per command and exits 0 when every command passed; a blocked
/// command or a judge that did not answer exits 1.
pub fn judge_cli(id: &str) -> i32 {
    match judge_request(id) {
        Ok((verdicts, file_path)) => {
            for (command, blocked) in &verdicts {
                match blocked {
                    None => println!("{}: PASS", command.name),
                    Some(reason) => println!("{}: BLOCK: {reason}", command.name),
                }
            }
            match super::refusal(&file_path, &verdicts) {
                None => libc::EXIT_SUCCESS,
                Some(_) => libc::EXIT_FAILURE,
            }
        }
        Err(reason) => {
            eprintln!("{HOOK_ID}: tama commands judge {id}: {reason}");
            let path = directory().join("judge.log");
            let message = format!("{HOOK_ID}: tama commands judge {id}: {reason}\n");
            if let Err(error) = OpenOptions::new()
                .create(true)
                .append(true)
                .open(&path)
                .and_then(|mut log| log.write_all(message.as_bytes()))
            {
                eprintln!(
                    "{HOOK_ID}: cannot retain the review failure in {}: {error}",
                    path.display()
                );
            }
            libc::EXIT_FAILURE
        }
    }
}
