//! Refuse operations on cloud instances without the operator's consent.
//!
//! The operator's rule: no operation on a cloud instance happens unless he
//! consented to it. He gives that consent in the conversation and the agent
//! records it as the Tama session capability `{ "tool": "cloud" }`
//! ([`CLOUD_INSTANCES`]); a capability an agent asks for is granted only when
//! the operator confirms it, and the session's capability file keeps that
//! confirmation for the lifetime he named. He may also allow cloud
//! operations in every session by a standing ruling, for as long as the
//! credits a provider bills them to stay above a floor he named: a program
//! whose provider has a billing variant Stado measures is then admitted on
//! that measurement ([`credits`]), and refused when it is at or under the
//! floor or cannot be measured.
//!
//! What is refused, per command segment and one shell level down: a shell
//! command whose program is a cloud provider's own command line, as declared
//! in `programs.json` beside this module with the reason they are there.
//! `--help` and `-h` pass, because they run nothing. Every call of such a
//! program waits for consent, listing included: the operator named any
//! operation on a cloud instance, and which call of a provider's command line
//! touches an instance is not decided by reading its words.

mod credits;

use std::sync::LazyLock;

use serde::Deserialize;
use serde_json::Value;

use crate::ports::owner_consent::CLOUD_INSTANCES;
use crate::ports::python_stdlib::shell_tokens;
use crate::ports::shell_text;
use crate::ports::tool_vocabulary::Call;

const HOOK: &str = "block-cloud-instances";
const HELP_FLAGS: &[&str] = &["--help", "-h"];

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Program {
    name: String,
    provider: String,
    /// The billing variant Stado measures this provider's credits under,
    /// when it measures them.
    billing: Option<String>,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Declared {
    #[allow(dead_code)]
    why: String,
    programs: Vec<Program>,
}

static PROGRAMS: LazyLock<Vec<Program>> = LazyLock::new(|| {
    let declared: Declared = serde_json::from_str(include_str!("programs.json"))
        .expect("block_cloud_instances/programs.json is the gate's own data and must parse");
    declared.programs
});

/// The declared provider program one command segment runs, when it does.
fn segment_program(segment: &str) -> Option<&'static Program> {
    let tokens = shell_tokens(segment);
    if let Some(inner) = shell_text::inner_command(&tokens) {
        if let Some(found) = command_program(&inner) {
            return Some(found);
        }
    }
    let program = shell_text::program(&tokens)?;
    if tokens
        .iter()
        .any(|token| HELP_FLAGS.contains(&token.as_str()))
    {
        return None;
    }
    PROGRAMS.iter().find(|declared| declared.name == program)
}

/// The first declared provider program a command line runs.
fn command_program(command: &str) -> Option<&'static Program> {
    shell_text::commands(&shell_text::effective_command(command))
        .into_iter()
        .find_map(segment_program)
}

/// The shell text this call runs, when it is a shell call.
fn shell_command(payload: &Value) -> Option<String> {
    let call = Call::of(payload);
    if !call.is_shell() {
        return None;
    }
    call.command().map(str::to_string)
}

/// Why this call is refused, or `None` when it passes.
pub fn evaluate(payload: &Value) -> Option<String> {
    let command = shell_command(payload)?;
    let program = command_program(&command)?;
    if CLOUD_INSTANCES.granted_to_hook() {
        return None;
    }
    let floor = match &program.billing {
        Some(billing) => credits::decide(billing),
        None => credits::Floor::Unruled,
    };
    match floor {
        credits::Floor::Admitted => return None,
        credits::Floor::Refused(why) => {
            return Some(format!(
                "{HOOK}: BLOCKED: `{}` operates on {} cloud instances: {why}. Without that, the \
                 operator's direct consent is the Tama session capability {}.",
                program.name,
                program.provider,
                CLOUD_INSTANCES.grant()
            ))
        }
        credits::Floor::Unruled => {}
    }
    Some(format!(
        "{HOOK}: BLOCKED: `{}` operates on {} cloud instances, and no operation on a cloud \
         instance runs without the operator's direct consent. He gives it in the conversation; \
         record it as the Tama session capability {} with the lifetime he names, which he \
         confirms, then run the command.",
        program.name,
        program.provider,
        CLOUD_INSTANCES.grant()
    ))
}
