//! Logic for `tama-block-oko-trajectory-edits`, registry hook
//! `block-oko-trajectory-edits`: the boundary between Oko and Weles.
//!
//! Oko may consume Slack tokens and APIs. Weles owns trajectories and
//! login/install automation, and a browser is only ever driven there. So a
//! trajectory, a Slack app install flow, a browser login or any other
//! Weles-owned automation must not be written inside the Oko checkout.
//!
//! Whether a write is inside Oko is structure: the path it targets, or the
//! Oko checkout named in the patch or command that performs it. Whether
//! what it writes is Weles-owned automation is what the content does, which
//! the words of a file name do not say: the word lists this gate used to
//! carry (`install`, `oauth`, `app`, `login`, `trajectory` …) refused any
//! file that happened to be named so and passed automation named otherwise.
//! A write that touches Oko is read by a model through Oko's model call
//! (`ports::model_judgement`) with the boundary in the prompt
//! (`judge-prompt.md`). A question the judge leaves unanswered refuses with
//! its cause, as for every model-judged gate (`model_judgement::unanswered`).

use std::sync::LazyLock;

use regex::Regex;
use serde_json::Value;
use tama_hooks::session_record::{deny_tool_use, read_payload};

use crate::ports::model_judgement;
use crate::ports::tool_vocabulary::Call;
use crate::ports::transport_common as common;

const TAG: &str = "block-oko-trajectory-edits";
const PROMPT: &str = include_str!("judge-prompt.md");
const WRITE_SLOT: &str = "{write}";
/// The schema the judge answers under and the two options it chooses from.
const JUDGEMENT: &str = "oko_automation";
const PASS: &str = "PASS";
const BLOCK: &str = "BLOCK";

/// The one checkout of Oko. Every repository in this workshop has exactly one
/// checkout, at `~/Documents/CodingProjects/Wisent/<repo>`, so the boundary is
/// a path and not a guess, whichever account the checkout lives under.
fn oko_relative() -> String {
    format!("/{}/oko/", crate::util::WORKSPACE_HOME_RELATIVE)
}
const REFUSAL: &str = concat!(
    "BLOCKED: Do not put trajectories, Slack app install flows, browser login automation, or ",
    "Weles-owned automation inside Oko. Put it in ",
    "~/Documents/CodingProjects/Wisent/weles/scripts/trajectories/ and ",
    "call it from there. Oko may consume Slack tokens and APIs; Weles owns trajectories and ",
    "login/install automation.",
);

static OKO_MENTION: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        "(?i)({}/oko|/oko/)",
        regex::escape(crate::util::WORKSPACE_HOME_RELATIVE)
    ))
});

fn inside_oko(value: &str) -> bool {
    let relative = oko_relative();
    value.contains(&relative) || value.ends_with(relative.trim_end_matches('/'))
}

/// The refusal the model's reading of `write` earns when it puts Weles-owned
/// automation into Oko, or the refusal an unanswered question earns
/// (`model_judgement::unanswered`, handed the shell `command` the write is,
/// if it is one); nothing when it passes.
fn automation_in(write: &str, command: Option<&str>) -> Option<String> {
    let prompt = PROMPT.replace(WRITE_SLOT, write.trim());
    match model_judgement::choose(&prompt, JUDGEMENT, &[PASS, BLOCK]) {
        Ok(judged) => {
            (judged.choice == BLOCK).then(|| format!("{REFUSAL} Detected: {}", judged.reason))
        }
        Err(unanswered) => model_judgement::unanswered::refusal(TAG, &unanswered, command),
    }
}

/// The write this payload makes inside Oko, as the judge reads it: the path
/// and content of a file write, a patch that names the Oko checkout, or a
/// command that does. Nothing for a payload that does not touch Oko.
fn write_inside_oko(payload: &Value) -> Option<String> {
    let call = Call::of(payload);
    call.input()?;
    let body = call.written();
    if let Some(path) = call.path().filter(|path| inside_oko(path)) {
        return Some(match body {
            Some(body) => format!("a file written at {path}:\n{body}"),
            None => format!("a file written at {path}, its text not in the call"),
        });
    }
    if call.is_patch() {
        if let Some(body) = body.filter(|body| OKO_MENTION.is_match(body)) {
            return Some(format!("a patch:\n{body}"));
        }
    }
    if call.is_shell() {
        if let Some(command) = call
            .command()
            .filter(|command| OKO_MENTION.is_match(command))
        {
            return Some(format!("a shell command:\n{command}"));
        }
    }
    None
}

/// The refusal this payload earns for crossing the boundary, or nothing.
pub fn crosses_the_boundary(payload: &Value) -> Option<String> {
    let write = write_inside_oko(payload)?;
    let call = Call::of(payload);
    let command = call.is_shell().then(|| call.command()).flatten();
    automation_in(&write, command)
}

pub fn run() {
    if let Some(refusal) = crosses_the_boundary(&read_payload()) {
        deny_tool_use(&refusal);
    }
}
