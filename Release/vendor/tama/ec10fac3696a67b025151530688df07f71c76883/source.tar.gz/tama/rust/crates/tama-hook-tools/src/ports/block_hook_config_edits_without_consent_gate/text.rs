//! The text the consent guard judges: what a call executes, the part of it
//! that can act, and whether it changes git's hooks path.

use serde_json::Value;

use super::super::python_stdlib::shell_tokens;
use super::super::shell_text;
use super::super::tool_vocabulary::Call;

const GIT_SUBCOMMAND: &str = "config";
const GIT_CONFIG_KEY: &str = "core.hookspath";
/// What every git config option that removes a setting carries in its name
/// (`--unset`, `--unset-all`): a change made without a value after the key.
const GIT_UNSET_OPTION_PART: &str = "unset";

/// Every string in the payload, in the order the Python's stack walk produced
/// them, joined. Order is load-bearing: it decides what a regex can match
/// across a newline join.
pub(super) fn execution_text(payload: &Value) -> String {
    let mut strings: Vec<&str> = Vec::new();
    let mut stack: Vec<&Value> = vec![payload];
    while let Some(value) = stack.pop() {
        match value {
            Value::String(text) => strings.push(text),
            Value::Object(map) => stack.extend(map.values()),
            Value::Array(items) => stack.extend(items),
            _ => {}
        }
    }
    strings.join("\n")
}

/// What a call executes: a shell call's command alone, any other call's
/// every string. Joined with the payload's other strings — its description,
/// its directory, the session's paths — an apostrophe in any of them opened a
/// quote the shell never sees and cut the command at the wrong place, so a
/// plain commit was read as naming a protected path.
pub(super) fn executed_text(payload: &Value) -> String {
    let call = Call::of(payload);
    match (call.is_shell(), call.command()) {
        (true, Some(command)) => command.to_string(),
        _ => execution_text(payload),
    }
}

/// The part of `text` that can act: a shell call's text with its quoted
/// data blanked, any other call's text whole, because in code a quote is
/// syntax and a path inside one is the path the code opens.
pub(super) fn acting_text(payload: &Value, text: &str) -> String {
    if Call::of(payload).is_shell() {
        shell_text::effective_command(text)
    } else {
        text.to_string()
    }
    .replace('\\', "/")
}

/// `git [-c x] [-C dir] … config … core.hooksPath <value>`, or the same
/// with an unset option, per command: a change of the hooks path. The cut
/// is quote-aware, so a sentence that quotes the setting is text. The key
/// with nothing after it and no unset option is a read of where the hooks
/// live, which needs no consent.
pub(super) fn git_configures_hookspath(command: &str) -> bool {
    for segment in shell_text::commands(command) {
        let tokens = shell_tokens(segment);
        for (index, token) in tokens.iter().enumerate() {
            if !crate::ports::git_invocation::is_git(token) {
                continue;
            }
            let Some((_, after_git)) = tokens[index..].split_first() else {
                continue;
            };
            let invocation = crate::ports::git_invocation::read(after_git);
            let Some((subcommand, rest)) = invocation
                .subcommand
                .and_then(|at| after_git[at..].split_first())
            else {
                continue;
            };
            if subcommand != GIT_SUBCOMMAND {
                continue;
            }
            let arguments: Vec<&String> = rest.iter().collect();
            let Some(key) = arguments
                .iter()
                .position(|item| item.to_lowercase() == GIT_CONFIG_KEY)
            else {
                continue;
            };
            let value_follows = arguments[key..]
                .split_first()
                .is_some_and(|(_, after)| !after.is_empty());
            let unsets = arguments
                .iter()
                .any(|item| item.starts_with('-') && item.contains(GIT_UNSET_OPTION_PART));
            if value_follows || unsets {
                return true;
            }
        }
    }
    false
}
