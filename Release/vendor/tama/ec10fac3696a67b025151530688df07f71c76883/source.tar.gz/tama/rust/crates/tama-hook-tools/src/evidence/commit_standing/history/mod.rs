//! Scoring commits an agent session made before the commit review scored
//! each one: every commit of a revision range is scored as the review would
//! have scored it, against the session that made it.
//!
//! The session is read from the harness transcripts, never guessed from an
//! author name: a commit belongs to the session one of whose shell calls
//! names `commit` and the repository, and was running when Git recorded the
//! commit, from the moment the call was made to the moment its result came
//! back. A commit no such call covers, or that several cover, is not scored
//! and is reported with that cause. Its files are checked as the commit
//! review checks staged ones, in the commit's own tree. A commit whose
//! tree the register already holds for that session is not scored twice.

use std::path::{Path, PathBuf};

use serde::Serialize;

use crate::programs::check_rust_format::unformatted_staged;
use tama_core::git::at as git;

mod transcripts;
use transcripts::{commit_calls, Call};

/// What became of one commit of the range.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Scored {
    pub commit: String,
    pub subject: String,
    pub session: Option<String>,
    pub unformatted: Vec<String>,
    /// Whether this run wrote it to the register.
    pub recorded: bool,
    /// Why it was not recorded, when it was not.
    pub cause: Option<String>,
}

/// The harness whose transcripts carry the record shape read here.
const AGENT: &str = "omp";

/// One `git log` line: commit, commit time and subject, tab-separated.
fn commit_line(line: &str) -> Result<(String, i64, String), String> {
    let unreadable = || format!("git log wrote an unreadable commit line: {line:?}");
    let (commit, rest) = line.split_once('\t').ok_or_else(unreadable)?;
    let (time, subject) = rest.split_once('\t').ok_or_else(unreadable)?;
    let time = time
        .parse()
        .map_err(|error| format!("commit {commit} has no readable time {time:?}: {error}"))?;
    Ok((commit.to_string(), time, subject.to_string()))
}

/// The files `commit` adds, changes or renames to; a root commit's are all it
/// holds.
fn changed_files(root: &Path, commit: &str) -> Result<Vec<String>, String> {
    let changed = git(
        root,
        &[
            "diff-tree",
            "--root",
            "--no-commit-id",
            "--name-only",
            "-r",
            "--diff-filter=AMR",
            "-z",
            commit,
        ],
    )?;
    Ok(changed
        .split('\0')
        .filter(|path| !path.is_empty())
        .map(str::to_owned)
        .collect())
}

/// Score every commit of `range` in the checkout at `root`.
pub fn score(root: &Path, range: &str) -> Result<Vec<Scored>, String> {
    let root = PathBuf::from(git(root, &["rev-parse", "--show-toplevel"])?.trim());
    let listed = git(
        &root,
        &[
            "log",
            "--no-merges",
            "--reverse",
            "--format=%H%x09%ct%x09%s",
            range,
        ],
    )?;
    let commits = listed
        .lines()
        .map(commit_line)
        .collect::<Result<Vec<_>, _>>()?;
    let Some(earliest) = commits.iter().map(|(_, time, _)| *time).min() else {
        return Ok(Vec::new());
    };
    let calls = commit_calls(&root, earliest)?;
    let repository = root.display().to_string();
    let mut scored = Vec::new();
    for (commit, time, subject) in commits {
        let mut entry = Scored {
            commit: commit.clone(),
            subject,
            session: None,
            unformatted: Vec::new(),
            recorded: false,
            cause: None,
        };
        let covering: Vec<&Call> = calls
            .iter()
            .filter(|call| call.started <= time && time <= call.answered)
            .collect();
        let call = match covering.as_slice() {
            [call] => *call,
            [] => {
                entry.cause = Some(
                    "no session's shell call naming commit and this repository was running when Git recorded it"
                        .into(),
                );
                scored.push(entry);
                continue;
            }
            several => {
                let sessions: Vec<&str> =
                    several.iter().map(|call| call.session.as_str()).collect();
                entry.cause = Some(format!(
                    "several sessions' commit calls were running when Git recorded it: {}",
                    sessions.join(", ")
                ));
                scored.push(entry);
                continue;
            }
        };
        entry.session = Some(call.session.clone());
        let tree = git(&root, &["rev-parse", &format!("{commit}^{{tree}}")])?
            .trim()
            .to_string();
        let held = super::document()?
            .commits
            .iter()
            .any(|known| known.session == call.session && known.tree == tree);
        if held {
            entry.cause =
                Some("the register already holds this commit's tree for this session".into());
            scored.push(entry);
            continue;
        }
        let files = changed_files(&root, &commit)?;
        entry.unformatted = unformatted_staged(&root, &commit, &files)?;
        super::record(
            &call.session,
            AGENT,
            &repository,
            &tree,
            entry.unformatted.clone(),
        )?;
        entry.recorded = true;
        scored.push(entry);
    }
    Ok(scored)
}
