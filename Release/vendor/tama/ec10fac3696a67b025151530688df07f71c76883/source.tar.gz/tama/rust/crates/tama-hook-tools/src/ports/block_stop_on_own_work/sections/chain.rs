//! The one command a begging report hands the operator, checked against the
//! programs it runs before he runs it.
//!
//! A clipboard plea is the last thing the agent may ask for, so a plea that
//! cannot succeed costs the operator a run and leaves the work where it was
//! (an install step in a begged chain was refused for its missing
//! `--source-commit`). Every step that runs a program Stado installed is asked
//! for its own usage line, and each option that line marks as required must be
//! in the step. Which programs are asked is not a list: it is whatever
//! `stado product install` placed in its install root, the one place whose
//! programs are clap CLIs of this workshop and answer `--help` without doing
//! their work.
//!
//! A step that builds a product from its checkout is also asked whether the
//! build would pass its formatting gate (a begged `stado product update
//! stado` stopped at the fmt gate of a file committed unformatted). Stado
//! answers that itself with `stado quality check`, so the plea carries the
//! same verdict the build would reach, without building.

use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};

/// The refusal for a begged command a step of which omits a required option,
/// is refused by its program's own `--check-arguments`, installs a release an
/// earlier step only queued, or builds a checkout its own quality gate
/// refuses, judged against the install root under `home`; `None` when every
/// step would get past all four.
pub fn unrunnable(command: &str, home: &Path) -> Option<String> {
    let root = install_root(home);
    let steps: Vec<Vec<String>> = steps(command)
        .iter()
        .map(|step| super::runnable::without_assignments(step))
        .filter(|step| !step.is_empty())
        .collect();
    if let Some(refusal) = super::runnable::installs_what_it_only_queued(&steps) {
        return Some(refusal);
    }
    steps.iter().find_map(|step| {
        let (program, help) = help_of(step, &root)?;
        let usage = usage_line(&help)?;
        let missing = missing_required(step, &usage);
        if !missing.is_empty() {
            return Some(format!(
                "`{}` omits {}, which its own usage requires ({usage}); run each step's --help \
                 and every part you can run yourself before begging with it",
                step.join(" "),
                missing.join(", ")
            ));
        }
        match super::runnable::refused_by_program(step, &program, &help) {
            Some(refusal) => Some(refusal),
            None => unformatted_source(step, &program, &help, home),
        }
    })
}

/// The manifest whose gates a source build runs.
const RELEASE_MANIFEST: &str = ".wisent-release.json";
/// The exit status clap gives a command line it does not accept, which a
/// Stado that predates `stado quality check` answers with:
/// https://docs.rs/clap/latest/clap/error/struct.Error.html#method.exit
const USAGE_ERROR: i32 = 2;

/// The refusal for a step that builds a product from source — a `stado
/// product` step without `--release-version` whose own `help` offers that
/// option, so it builds the checkout instead — whose checkout `stado quality
/// check` refuses; `None` when the step is not such a build, the product's
/// checkout is not `<workspace>/<product>`, or the installed Stado has no
/// `quality check` to ask. Which verbs build is Stado's to say, not a list
/// here. A check that cannot be run is the refusal, with its cause: the plea
/// would otherwise be handed over unchecked.
fn unformatted_source(step: &[String], stado: &Path, help: &str, home: &Path) -> Option<String> {
    let (product, pinned) = super::runnable::product_step(step)?;
    if pinned
        || stado.file_name()? != "stado"
        || !help
            .split_whitespace()
            .any(|word| word.starts_with(super::runnable::RELEASE_VERSION))
    {
        return None;
    }
    let checkout = home
        .join(crate::util::WORKSPACE_HOME_RELATIVE)
        .join(product);
    if !checkout.join(RELEASE_MANIFEST).is_file() {
        return None;
    }
    // The quality check runs build tools: unless Oko admits building the
    // product it is not run, and the step is judged without it.
    if crate::capability::standing::build_unadmitted_in(&checkout).is_some() {
        return None;
    }
    let mut check = Command::new(stado);
    check
        .args(["quality", "check", "--root"])
        .arg(&checkout)
        .stdin(Stdio::null());
    let output = match stado_wait::output(&mut check) {
        Ok(output) => output,
        Err(error) => {
            return Some(format!(
                "`{}` builds {product} from {}, and `stado quality check --root {}` could not \
                 run to say whether that build would pass its gate: {error}",
                step.join(" "),
                checkout.display(),
                checkout.display()
            ))
        }
    };
    if output.status.success() || output.status.code() == Some(USAGE_ERROR) {
        return None;
    }
    let said = String::from_utf8_lossy(&output.stdout).into_owned()
        + &String::from_utf8_lossy(&output.stderr);
    Some(format!(
        "`{}` builds {} from {}, and `stado quality check --root {}` refuses it, so the build \
         would stop at the same gate; repair the checkout before begging with it:\n{}",
        step.join(" "),
        product,
        checkout.display(),
        checkout.display(),
        said.trim_end()
    ))
}

/// Where `stado product install` places the programs it installs.
fn install_root(home: &Path) -> PathBuf {
    home.join(".stado").join("bin")
}

/// The command split into steps at `&&`, `||`, `|` and `;`, each step into
/// words, quotes removed.
pub fn steps(command: &str) -> Vec<Vec<String>> {
    let mut steps = Vec::new();
    let mut words = Vec::new();
    let mut word = String::new();
    let mut quote = None;
    for c in command.chars() {
        match (quote, c) {
            (Some(open), c) if c == open => quote = None,
            (Some(_), c) => word.push(c),
            (None, '\'' | '"') => quote = Some(c),
            (None, ';' | '&' | '|') => close_step(&mut steps, &mut words, &mut word),
            (None, c) if c.is_whitespace() => {
                if !word.is_empty() {
                    words.push(std::mem::take(&mut word));
                }
            }
            (None, c) => word.push(c),
        }
    }
    close_step(&mut steps, &mut words, &mut word);
    steps
}

fn close_step(steps: &mut Vec<Vec<String>>, words: &mut Vec<String>, word: &mut String) {
    if !word.is_empty() {
        words.push(std::mem::take(word));
    }
    if !words.is_empty() {
        steps.push(std::mem::take(words));
    }
}

/// `path` with every link followed; `None` when it does not exist, and said
/// on stderr when it exists and cannot be resolved.
fn canonical(path: &Path) -> Option<PathBuf> {
    match std::fs::canonicalize(path) {
        Ok(resolved) => Some(resolved),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => None,
        Err(error) => {
            eprintln!("tama: {} cannot be resolved: {error}", path.display());
            None
        }
    }
}

/// The program a step names, resolved through `PATH` when it has no
/// directory, with every link followed.
fn resolved(program: &str) -> Option<PathBuf> {
    let candidate = if program.contains('/') {
        PathBuf::from(program)
    } else {
        std::env::split_paths(&std::env::var_os("PATH")?)
            .map(|dir| dir.join(program))
            .find(|path| path.is_file())?
    };
    canonical(&candidate)
}

/// The program of `step`, when Stado installed it under `root`, and the help
/// it prints for the step's command path. A program whose help cannot be
/// read is said on stderr and its step is not judged.
fn help_of(step: &[String], root: &Path) -> Option<(PathBuf, String)> {
    let (first, rest) = step.split_first()?;
    let program = resolved(first)?;
    let root = canonical(root)?;
    if !program.starts_with(&root) {
        return None;
    }
    let path = rest.iter().take_while(|word| !word.starts_with('-'));
    let mut asked = Command::new(&program);
    asked.args(path).arg("--help").stdin(Stdio::null());
    match stado_wait::output(&mut asked) {
        Ok(output) => Some((
            program,
            String::from_utf8_lossy(&output.stdout).into_owned(),
        )),
        Err(error) => {
            eprintln!(
                "tama: {} --help could not run, so its step is not checked: {error}",
                program.display()
            );
            None
        }
    }
}

/// The usage line of a program's help.
fn usage_line(help: &str) -> Option<String> {
    help.lines().find_map(|line| {
        line.trim()
            .strip_prefix("Usage:")
            .map(|usage| usage.trim().to_owned())
    })
}

/// The options `usage` marks as required — outside every `[...]` and not one
/// of `<a|b>` alternatives — that `step` does not carry.
pub fn missing_required(step: &[String], usage: &str) -> Vec<String> {
    // The `[` brackets still open where a token starts.
    let mut open: Vec<char> = Vec::new();
    let mut missing = Vec::new();
    for token in usage.split_whitespace() {
        let outside = open.is_empty();
        open.extend(token.matches('[').flat_map(str::chars));
        for _ in token.matches(']') {
            open.pop();
        }
        if !outside || token.contains('[') || token.contains('|') || !token.starts_with("--") {
            continue;
        }
        let flag = token.trim_end_matches(|c: char| !c.is_alphanumeric() && c != '-');
        let with_value = format!("{flag}=");
        if !step
            .iter()
            .any(|word| word == flag || word.starts_with(&with_value))
        {
            missing.push(flag.to_owned());
        }
    }
    missing
}
