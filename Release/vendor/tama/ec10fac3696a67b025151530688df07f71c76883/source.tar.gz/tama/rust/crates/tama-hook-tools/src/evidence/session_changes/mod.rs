//! Session-owned text changes shared by staging and commit inspection.
//! Receipts authorize deltas, not every change in a file the session touched.
#[path = "scope/authors.rs"]
mod authors;
mod carry;
#[path = "history/committed.rs"]
mod committed;
mod git;
pub mod interface;
mod receipts;
#[path = "scope/selection.rs"]
mod selection;
mod staging;
#[path = "scope/takeover.rs"]
mod takeover;
mod verify;

pub use verify::index_carries;

/// The transcript `session`'s receipts are read from: the one its running
/// agent process writes now, else the one named after it; none when
/// neither exists.
pub fn session_transcript(session: &str) -> Result<Option<PathBuf>, String> {
    receipts::written(session)
}

/// Whether `session`'s harness moved it to a new transcript: a live
/// transcript names it at either end of the move.
pub fn session_moved(session: &str) -> Result<bool, String> {
    receipts::moved(session)
}

use std::collections::BTreeMap;
use std::fs;
use std::path::{Path, PathBuf};

use serde::Serialize;

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Report {
    pub session: String,
    pub repository: PathBuf,
    pub paths: Vec<PathBuf>,
    pub omitted: Vec<Omitted>,
    pub calls: Vec<String>,
    pub tree: String,
    pub applied: bool,
}

struct Change {
    base: Option<String>,
    owned: Option<String>,
    /// Why the session's edits of this path cannot be replayed: one of them
    /// overlaps a change another session made between two of its edits.
    conflict: Option<String>,
    /// The session's edits of this path since `base`, oldest first, so a
    /// newer run of them can be staged when an older one was undone
    /// (`staging`).
    steps: Vec<Step>,
}

/// One edit of a path: the bytes it saw (for a whole-file write, the state
/// the session's earlier edits left) and the bytes it left.
struct Step {
    call: String,
    before: Option<String>,
    after: Option<String>,
    whole: bool,
}

fn merge(
    area: &Path,
    current: &str,
    base: &str,
    changed: &str,
    path: &Path,
) -> Result<String, String> {
    if current == base || current == changed {
        return Ok(changed.to_owned());
    }
    if base == changed {
        return Ok(current.to_owned());
    }
    carry::carried(area, current, base, changed, path)
}

fn transition(
    area: &Path,
    current: Option<&str>,
    base: Option<&str>,
    changed: Option<&str>,
    path: &Path,
) -> Result<Option<String>, String> {
    if current == base || current == changed {
        return Ok(changed.map(str::to_owned));
    }
    if base == changed {
        return Ok(current.map(str::to_owned));
    }
    match (current, base, changed) {
        (Some(current), Some(base), Some(changed)) => {
            merge(area, current, base, changed, path).map(Some)
        }
        _ => {
            let held = |side: Option<&str>| match side {
                Some(text) => format!("{} bytes", text.len()),
                None => "no file".to_owned(),
            };
            Err(format!(
                "creation or deletion overlaps another change to {}: the state it is replayed onto holds {}, the \
                 edit found {} and left {}; the index and working tree are unchanged",
                path.display(),
                held(current),
                held(base),
                held(changed)
            ))
        }
    }
}

fn working_file(path: &Path) -> Result<Option<String>, String> {
    match fs::symlink_metadata(path) {
        Ok(metadata) => {
            if !metadata.is_file()
                || path
                    .canonicalize()
                    .map_err(|cause| format!("cannot resolve {}: {cause}", path.display()))?
                    != path
            {
                return Err(format!("{} is not a direct regular file", path.display()));
            }
            fs::read_to_string(path)
                .map(Some)
                .map_err(|cause| format!("cannot read {}: {cause}", path.display()))
        }
        Err(cause) if cause.kind() == std::io::ErrorKind::NotFound => Ok(None),
        Err(cause) => Err(format!("cannot inspect {}: {cause}", path.display())),
    }
}

/// Build and atomically publish an index containing only recorded text deltas.
/// Existing unrelated index entries remain; a path whose change cannot be
/// staged is left out and named with its cause (`Report::omitted`), and a
/// failure to read the session, its receipts or Git refuses the whole
/// operation. With `only` naming paths, only the session's edits of those
/// paths are staged ([`selection`]). With `with` naming the sessions that
/// wrote the session's paths together with it, their edits of those paths
/// are read into the same run ([`authors`]); with `task` taken over from a
/// stopped one of them, its every path ([`takeover`]). With `from_head` the
/// staging index is read from HEAD first, so a stale one carries only the
/// session's change. A published staging keeps them beside the index.
pub fn stage(
    directory: &Path,
    session: &str,
    apply: bool,
    only: &[PathBuf],
    with: &[String],
    task: Option<&str>,
    from_head: bool,
) -> Result<Report, String> {
    if session.trim().is_empty() {
        return Err("--session must name a recorded session".into());
    }
    let transaction = git::Transaction::begin(directory, apply)?;
    from_head.then(|| transaction.reset_to_head()).transpose()?;
    let shared = transaction.shared.clone();
    let transcript = receipts::transcript(session)?;
    let edits = receipts::read_at(&transaction.root, &transcript, Some(session))?;
    let edits = authors::merged(&transaction.root, session, with, task, edits)?;
    let edits = selection::select(&transaction.root, edits, only)?;
    let edits = verify::committable(&transaction.root, edits)?;
    let since = receipts::session_started(&transcript)?;
    let taken = committed::Committed::new(&transaction, since);
    // A whole-file write replaced what the file held in the shared index.
    let (changes, calls) = changes(
        edits,
        &transaction.area,
        |path| Ok(transaction.entry(path)?.map(|(_, text)| text)),
        |path, text| taken.took(path, text),
    )?;
    let report = staging::stage_changes(transaction, session, changes, calls, apply)?;
    if report.applied {
        authors::keep(&shared, session, with, task)?;
    }
    Ok(report)
}

/// The session's change of each path. A text edit carries the bytes it saw
/// and left; a whole-file write carries only what it left, so its base is
/// the session's own earlier state of that path, or, for the first touch,
/// what `prior` says the file held (the index when staging, HEAD when a
/// commit is read against the receipts). A state of the session's that a
/// commit already took (`committed`) is where its change of that path starts
/// again: the commit carries everything before it, and another session's
/// later commit to the same file is not merged against the session's
/// first base. A path whose edits cannot be replayed carries that cause
/// (`conflict`) instead of failing every other path, until a whole-file
/// write gives it a known state again: staging refuses it, a commit of its own
/// does when it stages it, and another session's reads it as `verify` says.
fn changes(
    edits: Vec<receipts::Edit>,
    area: &Path,
    prior: impl Fn(&Path) -> Result<Option<String>, String>,
    committed: impl Fn(&Path, &str) -> Result<bool, String>,
) -> Result<(BTreeMap<PathBuf, Change>, Vec<String>), String> {
    let mut changes: BTreeMap<PathBuf, Change> = BTreeMap::new();
    let mut calls = Vec::new();
    for edit in edits {
        let path = edit.path.clone();
        // An edit whose bytes cannot be established leaves its path in no
        // known state: that path carries the cause until a whole-file write
        // gives it one again, and every other path is read as before. No run
        // of edits crosses it: a newer run starts after it.
        if let Some(cause) = edit.refused {
            match changes.get_mut(&path) {
                Some(change) => {
                    change.conflict = Some(cause);
                    change.steps.clear();
                }
                None => {
                    let base = prior(&path)?;
                    changes.insert(
                        path,
                        Change {
                            owned: base.clone(),
                            base,
                            conflict: Some(cause),
                            steps: Vec::new(),
                        },
                    );
                }
            }
            calls.push(edit.call);
            continue;
        }
        match changes.get_mut(&edit.path) {
            Some(change) => {
                // A whole-file write saw what the session's earlier edits left.
                let before = if edit.whole {
                    change.owned.clone()
                } else {
                    edit.before.clone()
                };
                if edit.whole {
                    change.owned = edit.after.clone();
                    change.conflict = None;
                } else if change.conflict.is_none() {
                    match transition(
                        area,
                        change.owned.as_deref(),
                        edit.before.as_deref(),
                        edit.after.as_deref(),
                        &edit.path,
                    ) {
                        Ok(owned) => change.owned = owned,
                        Err(cause) => change.conflict = Some(cause),
                    }
                }
                change.steps.push(Step {
                    call: edit.call.clone(),
                    before,
                    after: edit.after,
                    whole: edit.whole,
                });
            }
            None => {
                let base = if edit.whole {
                    prior(&edit.path)?
                } else {
                    edit.before
                };
                let step = Step {
                    call: edit.call.clone(),
                    before: base.clone(),
                    after: edit.after.clone(),
                    whole: edit.whole,
                };
                changes.insert(
                    edit.path,
                    Change {
                        base,
                        owned: edit.after,
                        conflict: None,
                        steps: vec![step],
                    },
                );
            }
        }
        if let Some(change) = changes.get_mut(&path) {
            if let (None, Some(owned)) = (&change.conflict, change.owned.as_deref()) {
                if committed(&path, owned)? {
                    change.base = change.owned.clone();
                    change.steps.clear();
                }
            }
        }
        calls.push(edit.call);
    }
    Ok((changes, calls))
}

/// One recorded file a staging left out, and why.
#[derive(Debug, Serialize)]
pub struct Omitted {
    pub path: PathBuf,
    pub cause: String,
}
