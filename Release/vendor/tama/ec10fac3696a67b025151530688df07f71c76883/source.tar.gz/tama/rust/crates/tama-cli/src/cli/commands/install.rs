//! `tama install`, `tama install plan` and `tama uninstall`: the user-global
//! Git dispatcher and the plan of every level Tama can be installed at.

use std::path::Path;

use tama_core::install::{
    install_global_git, level_plan, uninstall_global_git, InstallOptions, UninstallOptions,
};

use super::super::args::{has, option_value};
use super::super::output::{print_json, unwrap_or_exit};

pub fn install_plan(argv: &[String], root: &Path) -> i32 {
    let plan = level_plan(
        root,
        option_value(argv, "--git-hooks-path").as_deref(),
        option_value(argv, "--home").as_deref(),
    );
    if has(argv, "--json") {
        print_json(&plan);
    } else {
        println!("archive: {}", plan.archive_root);
        println!("agent/app hooks: require native runtime configuration, not archive presence");
        for (provider, config) in &plan.levels.agent_app.runtime_targets.harness_configs {
            println!("  {provider}: {config} (declared target, not live enforcement)");
        }
        println!(
            "editor adapters: {} (not installed by archive alone)",
            plan.levels.editor.runtime_targets.editor_watch
        );
        println!("mcp server: {}", plan.levels.mcp.runtime_targets.server);
        match plan.levels.user_global_git.current_hooks_path.as_deref() {
            Some(path) => println!("user-global Git hooks: {path}"),
            None => println!("user-global Git hooks: not configured"),
        }
        for hook in &plan.levels.user_global_git.dispatcher_states {
            println!("  {}", hook.describe());
        }
        println!("repo/project Git hooks: {}", plan.levels.repo_project.note);
        println!("OS-level policy: outside Tama");
    }
    libc::EXIT_SUCCESS
}

pub fn install(argv: &[String], root: &Path) -> i32 {
    let result = unwrap_or_exit(install_global_git(
        root,
        &InstallOptions {
            hooks_path: option_value(argv, "--git-hooks-path"),
            set_global_config: has(argv, "--set-git-config") && !has(argv, "--no-git-config"),
            home: option_value(argv, "--home"),
        },
    ));
    if has(argv, "--json") {
        print_json(&result);
    } else {
        println!("hooksPath: {}", result.hooks_path);
        println!("pre-commit: {}", result.pre_commit.target);
        println!("pre-push: {}", result.pre_push.target);
        println!("commit-msg: {}", result.commit_msg.target);
        println!(
            "reference-transaction: {}",
            result.reference_transaction.target
        );
        println!("git global config updated: {}", result.set_global_config);
    }
    libc::EXIT_SUCCESS
}

/// `tama uninstall [--git-hooks-path <path>] [--home <path>] [--unset-git-config] [--json]`:
/// the reverse of `install`.
pub fn uninstall(argv: &[String]) -> i32 {
    let result = unwrap_or_exit(uninstall_global_git(&UninstallOptions {
        hooks_path: option_value(argv, "--git-hooks-path"),
        unset_global_config: has(argv, "--unset-git-config"),
        home: option_value(argv, "--home"),
    }));
    if has(argv, "--json") {
        print_json(&result);
    } else {
        println!("hooksPath: {}", result.hooks_path);
        println!(
            "pre-commit: {} ({})",
            result.pre_commit.target, result.pre_commit.outcome
        );
        println!(
            "pre-push: {} ({})",
            result.pre_push.target, result.pre_push.outcome
        );
        println!(
            "commit-msg: {} ({})",
            result.commit_msg.target, result.commit_msg.outcome
        );
        println!(
            "reference-transaction: {} ({})",
            result.reference_transaction.target, result.reference_transaction.outcome
        );
        println!("git global config unset: {}", result.unset_global_config);
    }
    libc::EXIT_SUCCESS
}
