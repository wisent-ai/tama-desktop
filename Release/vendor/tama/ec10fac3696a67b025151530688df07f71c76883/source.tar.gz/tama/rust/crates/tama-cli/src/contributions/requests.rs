//! `tama contributions` as desktop requests: `contributions/pending` and
//! `contributions/report`, whose JSON bodies carry the flags' fields and
//! whose answers are the documents `--json` prints.

use serde_json::Value;

use super::report::report_document;
use super::{pending_document, Arguments, Verb};

/// Why a request was not answered: a body the operation cannot read, or a
/// failure while it ran, each with its sentence.
pub(crate) enum Unanswered {
    Unreadable(String),
    Failed(String),
}

/// A text field of `body`: absent is `None`, anything but text is refused.
fn text<'a>(body: &'a Value, field: &str) -> Result<Option<&'a str>, Unanswered> {
    match body.get(field) {
        None | Some(Value::Null) => Ok(None),
        Some(Value::String(text)) => Ok(Some(text.as_str())),
        Some(other) => Err(Unanswered::Unreadable(format!(
            "{field} must be text, not {other}"
        ))),
    }
}

fn required<'a>(body: &'a Value, field: &str, names: &str) -> Result<&'a str, Unanswered> {
    text(body, field)?
        .filter(|value| !value.trim().is_empty())
        .ok_or_else(|| Unanswered::Unreadable(format!("{field} names {names}")))
}

fn range<'a>(body: &'a Value, verb: Verb) -> Result<Arguments<'a>, Unanswered> {
    Ok(Arguments {
        verb,
        repository: required(body, "repository", "the checkout")?,
        reference: required(body, "ref", "the remote branch the commits reached")?,
        since: text(body, "since")?,
        ledger: text(body, "ledger")?,
        json: true,
    })
}

/// Answer one `contributions/<verb>` request. A report is answered whole
/// once the ledger answered for every commit, the ones it refused included:
/// each refused commit carries the ledger's sentence as `refused`, so the
/// screen shows it on that commit's line, as the command prints one line
/// per commit before it exits unsuccessfully. A report in which the ledger
/// never answered for some commit fails naming those commits and carrying
/// the whole report, since nothing the ledger decided can be shown for them.
pub(crate) fn answer(operation: &str, body: &Value) -> Result<Value, Unanswered> {
    match operation {
        "contributions/pending" => {
            let arguments = range(body, Verb::Pending)?;
            pending_document(&arguments).map_err(Unanswered::Failed)
        }
        "contributions/report" => {
            let arguments = range(body, Verb::Report)?;
            let report = report_document(&arguments).map_err(Unanswered::Failed)?;
            if !report.unanswered.is_empty() {
                return Err(Unanswered::Failed(format!(
                    "the ledger did not answer for {}; the report: {}",
                    Value::from(report.unanswered),
                    report.document
                )));
            }
            Ok(report.document)
        }
        other => Err(Unanswered::Unreadable(format!(
            "{other} is not a contributions request"
        ))),
    }
}
