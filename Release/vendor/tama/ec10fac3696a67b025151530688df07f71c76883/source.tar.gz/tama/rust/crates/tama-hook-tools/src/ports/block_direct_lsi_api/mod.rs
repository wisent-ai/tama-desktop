//! `tama hook block-direct-lsi-api`.
//!
//! Direct server-side writes to the NCBR/LSI form damaged a section of the
//! application, so the allowed path for this system is the real UI flow. The
//! guard refuses shell commands carrying a direct API endpoint or helper,
//! runs of local scripts whose source calls one, and writes that leave such
//! a call in a source file, whoever wrote it: the whole file a write leaves
//! is judged, and a write whose file cannot be rebuilt is refused with the
//! cause. A local script a command names is judged by its source, whatever
//! program the command runs it with. A helper symbol is refused wherever it
//! is written; an endpoint in a source file only beside a request the file
//! sends itself, since a trajectory clicking the real save button names it
//! only to recognise the page's own answer.

use regex::Regex;
use tama_hooks::session_record::{deny_tool_use, read_payload};

use super::check_numeric_literals_payload::line_at;
use super::codex_api_guard as guard;
use super::pyvalue::truthy;
use super::tool_vocabulary::Call;

const SCAN_EDIT_SUFFIXES: &[&str] = &[
    ".py", ".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx", ".sh", ".ipynb",
];

const ALLOWLIST_PATH_FRAGMENTS: &[&str] = &[
    "/.codex/hooks/block_direct_lsi_api.py",
    "/.codex/hooks.json",
];

const SHELL_LABEL: &str = "<shell command>";
const EDIT_LABEL: &str = "<edit>";

type Patterns = [(String, Regex)];

fn compiled(reason: &str, pattern: &str) -> (String, Regex) {
    let expression = Regex::new(pattern).expect("forbidden LSI pattern must compile");
    (reason.to_string(), expression)
}

/// The funding APIs' endpoints. A command naming one calls it; a source file
/// naming one calls it only when it also sends a request itself
/// ([`sends_own_request`]): a trajectory that clicks the real save button
/// names the endpoint only to recognise the page's own answer.
fn endpoint_patterns() -> Vec<(String, Regex)> {
    vec![
        compiled(
            "direct LSI API URL",
            "(?i)https?://lsi2\\.ncbr\\.gov\\.pl/api/",
        ),
        compiled(
            "direct PARP API URL",
            "(?i)https?://(?:[^/\\s\"']+\\.)?parp\\.gov\\.pl/api/",
        ),
        compiled(
            "direct NCBR API URL",
            "(?i)https?://(?:[^/\\s\"']+\\.)?ncbr\\.gov\\.pl/api/",
        ),
        compiled(
            "project registry write/read endpoint",
            "(?i)/api/beneficiary/project(?:-versions|-sections)?/",
        ),
        compiled("registry values endpoint", "(?i)\\bproject-registries\\b"),
        compiled("registry values endpoint", "(?i)\\bregistries-values\\b"),
        compiled("registry values endpoint", "(?i)\\bcollection-objects\\b"),
    ]
}

/// The helpers that reach those APIs without the interface, refused wherever
/// they are written.
fn helper_patterns() -> Vec<(String, Regex)> {
    vec![
        // Spelled in two parts: whole, the name is what pre-write-edit's
        // funding-API rule refuses in any file, this guard's own included.
        compiled(
            "browser-authenticated API helper",
            concat!("(?i)\\bCDP", "Session\\b"),
        ),
        compiled(
            "browser-authenticated API helper",
            "(?i)\\bsession\\.fetch\\b",
        ),
        compiled(
            "browser-authenticated API helper",
            "(?is)\\bpage\\.evaluate\\([^)]*fetch\\b",
        ),
        compiled(
            "browser-authenticated API helper",
            "(?i)\\b(?:collection_save|scalar_save|registries_values|project_fields)_url\\b",
        ),
    ]
}

/// A request a file sends itself, never one it reads (`request.url()`,
/// `response.request()`): in JavaScript `fetch(`, a page's or context's
/// request client, a request context or XMLHttpRequest; in Python a
/// `requests`, `httpx`, `aiohttp` or session/client verb call or `urlopen(`;
/// in a shell script `curl` or `wget`. Both funding-API rules, this guard's
/// and pre-write-edit's, read a file's endpoints by it.
pub(crate) fn sends_own_request(text: &str) -> bool {
    static OWN_REQUEST: std::sync::LazyLock<Regex> = std::sync::LazyLock::new(|| {
        let shapes = [
            "\\bfetch[[:space:]]*\\(",
            "\\.request[[:space:]]*\\.[[:space:]]*\\w+[[:space:]]*\\(",
            "\\brequest[[:space:]]*\\.[[:space:]]*newContext\\b",
            "\\bXMLHttpRequest\\b",
            "\\b(requests|httpx|aiohttp|session|client)[[:space:]]*\\.[[:space:]]*(get|post|put|patch|delete|request)[[:space:]]*\\(",
            "\\burlopen[[:space:]]*\\(",
            "\\b(curl|wget)\\b",
        ];
        Regex::new(&format!("(?i){}", shapes.join("|"))).expect("own-request pattern must compile")
    });
    OWN_REQUEST.is_match(text)
}

/// What a source file at `label` holds: its helpers always, its endpoints
/// only when it sends a request itself.
fn source_hits(text: &str, label: &str) -> Vec<String> {
    let mut hits = Vec::new();
    if sends_own_request(text) {
        hits = scan_text(&endpoint_patterns(), text, label);
    }
    hits.extend(scan_text(&helper_patterns(), text, label));
    hits
}

/// Every forbidden pattern `text` holds, each with the line of each place it
/// matches, as `reason (line N: …; line M: …)`.
fn scan_text(patterns: &Patterns, text: &str, label: &str) -> Vec<String> {
    if guard::is_allowlisted(label, ALLOWLIST_PATH_FRAGMENTS) {
        return Vec::new();
    }
    patterns
        .iter()
        .filter_map(|(reason, pattern)| {
            let places: Vec<String> = pattern
                .find_iter(text)
                .map(|found| line_at(text, found.start()))
                .collect();
            (!places.is_empty()).then(|| format!("{reason} ({})", places.join("; ")))
        })
        .collect()
}

fn report(label: &str, hits: &[String]) -> ! {
    deny_tool_use(&format!(
        "BLOCKED: direct LSI/PARP/NCBR API usage is forbidden for this agent.\n  target: \
         {label}\n  matched: {}\n\nUse the real UI flow only. Do not call /api/beneficiary, \
         project-registries, registries-values, or collection-objects directly.",
        guard::matched_list(hits)
    ))
}

fn check_shell(call: &Call) {
    let Some(command) = call.command() else {
        return;
    };

    let every: Vec<(String, Regex)> = endpoint_patterns()
        .into_iter()
        .chain(helper_patterns())
        .collect();
    let hits = scan_text(&every, command, SHELL_LABEL);
    if !hits.is_empty() {
        report(SHELL_LABEL, &hits);
    }

    let cwd = match call.working_dir() {
        Ok(cwd) => cwd,
        Err(error) => deny_tool_use(&format!(
            "BLOCKED: the scripts this command runs cannot be found: {error}"
        )),
    };
    let scripts = guard::resolve_script_paths(command, &cwd);

    for path in scripts {
        let text = match guard::read_source(&path) {
            Ok(Some(text)) => text,
            Ok(None) => continue,
            Err(cause) => deny_tool_use(&format!("BLOCKED: {cause}")),
        };
        let shown = path.to_string_lossy().into_owned();
        let hits = source_hits(&text, &shown);
        if !hits.is_empty() {
            report(&shown, &hits);
        }
    }
}

fn check_edit(call: &Call) {
    let label = match call.path().or_else(|| call.name()) {
        Some(named) => named.to_string(),
        None => EDIT_LABEL.to_string(),
    };

    if guard::is_allowlisted(&label, ALLOWLIST_PATH_FRAGMENTS) {
        return;
    }
    let named_source = SCAN_EDIT_SUFFIXES
        .iter()
        .any(|suffix| label.ends_with(suffix));
    if !named_source && !call.is_patch() {
        return;
    }
    let Some(tool_input) = call.input() else {
        return;
    };

    // Each file the write leaves, whoever wrote each line. A write whose file
    // the replay cannot rebuild is refused with the cause: the text a patch
    // or notebook cell writes is not the file it leaves.
    let files = match super::check_numeric_literals_payload::path_texts(tool_input, call.cwd()) {
        Ok(files) => files,
        Err(cause) => deny_tool_use(&format!(
            "BLOCKED: block-direct-lsi-api: the file this write to {label} leaves cannot be rebuilt to judge it: {cause}"
        )),
    };
    for (path, text) in files {
        let hits = source_hits(&text, &path);
        if !hits.is_empty() {
            report(&path, &hits);
        }
    }
}

pub fn run() {
    let data = read_payload();
    if !truthy(&data) {
        return;
    }
    let call = Call::of(&data);
    if call.is_shell() {
        check_shell(&call);
    } else if call.is_write() {
        check_edit(&call);
    }
}
