//! What Oko's registers say about the entry a scope declaration names.
//!
//! Split out of `scope_cli.rs`, which had grown past the three-hundred-line
//! limit; the command itself stays there.
//!
//! On a machine with Tama and without the Oko CLI there is no register to
//! check an identifier against. The identifier the session names is then the
//! entry, the repositories it names are the scope, and nothing is written
//! back: the scope file is the only record, and the write gate still holds
//! every change to it.

use crate::assignment::rules::{oko_cli, oko_installed};

/// The open defect this identifier names, or why it is not one.
///
/// The register is the authority, not the session's memory of it: a defect
/// nobody recorded, or one already closed by a revision, authorises nothing.
pub(super) fn open_defect(id: &str) -> Result<String, String> {
    if !oko_installed() {
        return Ok(id.to_string());
    }
    let mut command = std::process::Command::new(oko_cli());
    command
        .args(["defects", "show", id, "--json"])
        .stdin(std::process::Stdio::null());
    let output = stado_wait::output(&mut command)
        .map_err(|error| format!("cannot run the Oko CLI for defect {id}: {error}"))?;
    if !output.status.success() {
        return Err(format!(
            "Oko's register holds no defect {id}: {}",
            String::from_utf8_lossy(&output.stderr).trim()
        ));
    }
    let shown: serde_json::Value = serde_json::from_slice(&output.stdout)
        .map_err(|error| format!("Oko's answer for defect {id} is not JSON: {error}"))?;
    // `oko defects show` prints one document for one id, or a list of them.
    let defect = match shown.as_array() {
        Some(listed) => listed
            .first()
            .ok_or_else(|| format!("Oko's answer for defect {id} lists no defect"))?,
        None => &shown,
    };
    let recorded = |field: &str| defect.get(field).is_some_and(|value| !value.is_null());
    if recorded("withdrawn_at") {
        return Err(format!(
            "defect {id} was withdrawn, so no work belongs to it; record what is wrong now with \
             `oko defects record`"
        ));
    }
    if recorded("fixed_at") {
        return Err(format!(
            "defect {id} is already closed, so no work belongs to it; record what is wrong now \
             with `oko defects record`"
        ));
    }
    Ok(id.to_string())
}

/// An earlier open task remains work of this session after a later, smaller
/// instruction has been served. Its own words, not the latest prompt, name it.
pub(super) fn known_task(id: &str) -> Result<(String, Vec<String>, String), String> {
    if !oko_installed() {
        return Ok((
            id.to_string(),
            Vec::new(),
            format!("task {id}, declared without an Oko register on this machine"),
        ));
    }
    let mut command = std::process::Command::new(oko_cli());
    command
        .args(["tasks", "show", id, "--json"])
        .stdin(std::process::Stdio::null());
    let output = stado_wait::output(&mut command)
        .map_err(|error| format!("cannot run the Oko CLI for task {id}: {error}"))?;
    if !output.status.success() {
        return Err(format!(
            "Oko's task register holds no task {id}: {}",
            String::from_utf8_lossy(&output.stderr).trim()
        ));
    }
    let detail: serde_json::Value = serde_json::from_slice(&output.stdout)
        .map_err(|error| format!("Oko's answer for task {id} is not JSON: {error}"))?;
    let current = detail
        .get("current")
        .ok_or_else(|| format!("Oko's answer for task {id} has no current state"))?;
    if current.get("status").and_then(serde_json::Value::as_str) != Some("not done") {
        return Err(format!(
            "task {id} is not open, so there is no work to resume"
        ));
    }
    let text = current
        .get("text")
        .and_then(serde_json::Value::as_str)
        .filter(|text| !text.trim().is_empty())
        .ok_or_else(|| format!("Oko's answer for task {id} has no operator instruction"))?;
    // A contract that states no scope names none; one that states it in
    // another shape is refused, not read as none.
    let scope = match current.pointer("/contract/terms/scope") {
        None | Some(serde_json::Value::Null) => Vec::new(),
        Some(serde_json::Value::Array(names)) => names
            .iter()
            .map(|name| {
                name.as_str().map(str::to_owned).ok_or_else(|| {
                    format!("task {id}'s contract names a scope entry that is not a name: {name}")
                })
            })
            .collect::<Result<Vec<String>, String>>()?,
        Some(other) => {
            return Err(format!(
                "task {id}'s contract scope is not a list of names: {other}"
            ))
        }
    };
    Ok((id.to_string(), scope, text.to_string()))
}

/// Write the repositories a session declared into the task's contract, so
/// the contract, not this session's file, is the record of the task's scope.
pub(super) fn record_task_scope(
    id: &str,
    repositories: &[String],
    session: &str,
) -> Result<(), String> {
    if !oko_installed() {
        return Ok(());
    }
    let mut args = vec!["tasks".to_owned(), "state".to_owned(), id.to_owned()];
    for repository in repositories {
        args.push("--scope".to_owned());
        args.push(repository.clone());
    }
    args.push("--by".to_owned());
    args.push(session.to_owned());
    let mut command = std::process::Command::new(oko_cli());
    command.args(&args).stdin(std::process::Stdio::null());
    let output = stado_wait::output(&mut command).map_err(|error| {
        format!("cannot run the Oko CLI to record the scope of task {id}: {error}")
    })?;
    if !output.status.success() {
        return Err(format!(
            "Oko refused the scope of task {id}: {}",
            String::from_utf8_lossy(&output.stderr).trim()
        ));
    }
    Ok(())
}

use crate::ports::block_repeated_blocker::unattended;

/// The refusal a scope declaration earns for a defect this session recorded
/// that has no fix and no repair plan yet. A defect found in a session is
/// that session's first work: choosing another scope before writing its plan
/// is how a recorded defect was left behind while the earlier work went on.
/// A register that cannot be read refuses too, naming why: passed unread, it
/// let the declaration through whatever the session had left behind.
pub(super) fn unplanned_defect(session: &str, chosen: &str) -> Option<String> {
    match first_unplanned(session, chosen) {
        Ok(refusal) => refusal,
        Err(error) => Some(format!(
            "whether this session left a recorded defect without a plan cannot be told: {error}"
        )),
    }
}

fn first_unplanned(session: &str, chosen: &str) -> Result<Option<String>, String> {
    if !oko_installed() {
        return Ok(None);
    }
    let mut command = std::process::Command::new(oko_cli());
    command
        .args(["defects", "list", "--open", "--json"])
        .stdin(std::process::Stdio::null());
    let output = stado_wait::output(&mut command)
        .map_err(|error| format!("cannot run the Oko CLI to list open defects: {error}"))?;
    if !output.status.success() {
        return Err(format!(
            "Oko refused to list open defects ({}): {}",
            output.status,
            String::from_utf8_lossy(&output.stderr).trim()
        ));
    }
    let defects: Vec<serde_json::Value> = serde_json::from_slice(&output.stdout)
        .map_err(|error| format!("Oko's open defect list is not JSON: {error}"))?;
    let chosen = chosen.to_ascii_lowercase();
    for defect in &defects {
        let text = |key: &str| defect.get(key).and_then(serde_json::Value::as_str);
        let id = text("id")
            .ok_or_else(|| format!("Oko listed an open defect without an id: {defect}"))?
            .to_ascii_lowercase();
        let own = unattended::found_in(defect, session);
        let is_chosen = !chosen.is_empty() && id.starts_with(&chosen);
        if !own || unattended::attended(defect) || is_chosen {
            continue;
        }
        let title =
            text("title").ok_or_else(|| format!("Oko listed defect {id} without a title"))?;
        // Oko's short id is the first group of the defect's UUID.
        let short = id
            .split('-')
            .next()
            .ok_or_else(|| format!("defect id {id} has no first group"))?;
        return Ok(Some(format!(
            "this session recorded defect {short} — \"{title}\" — and it has no fix and no \
             repair plan yet. It is this session's first work: write its plan with \
             `oko defects plan {short} --text <mechanism and sweep>` and take it up with \
             `tama task scope set --session {session} --defect {short} --repository <NAME>`, \
             then choose other work."
        )));
    }
    Ok(None)
}
