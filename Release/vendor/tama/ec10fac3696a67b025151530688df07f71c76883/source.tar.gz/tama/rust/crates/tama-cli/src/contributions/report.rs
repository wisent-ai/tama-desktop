//! `tama contributions report`: send the events the ledger does not hold yet
//! and say, per commit, what became of it. A commit the ledger answered is
//! recorded or refused in the ledger's own words; one whose request never
//! got an answer (the client could not run, the connection failed, the
//! ledger answered no JSON) is unanswered, with what the request met. The
//! two are never mixed: a refusal is the ledger's decision, an unanswered
//! commit is one it never decided.

use serde_json::{json, Value};

use super::git::{self, Unposted};
use super::{accepted_code, held, named_ledger, print, request, Arguments, DECLARED};

/// One report: the document `--json` prints and what became of the commits
/// the ledger did not hold.
pub(super) struct Report {
    /// `{"ledger", "events": [{commit, answer} | {commit, refused} |
    /// {commit, unanswered}], "held"}`.
    pub(super) document: Value,
    /// The commits the ledger refused.
    pub(super) refused: Vec<Value>,
    /// The commits whose request got no answer from the ledger.
    pub(super) unanswered: Vec<Value>,
}

impl Report {
    /// Why the command ends unsuccessfully, or `None` when every commit the
    /// ledger lacked is recorded.
    pub(super) fn failure(&self) -> Option<String> {
        match (self.refused.is_empty(), self.unanswered.is_empty()) {
            (true, true) => None,
            (false, true) => {
                Some("the ledger refused some commits; each is named above".to_string())
            }
            (true, false) | (false, false) => Some(format!(
                "the ledger did not answer for {} commit(s); each is named above",
                self.unanswered.len()
            )),
        }
    }
}

/// Send the events the ledger does not hold yet, one request each.
pub(super) fn report_document(arguments: &Arguments<'_>) -> Result<Report, String> {
    let Some(url) = named_ledger(arguments.ledger)? else {
        let variable = &DECLARED.ledger_env;
        return Err(format!(
            "no contribution ledger is named; pass --ledger URL or set {variable}"
        ));
    };
    let bearer = git::bearer(&DECLARED.role, &DECLARED.bearer_field)?;
    let events = accepted_code(arguments)?;
    let held = held(&url, &bearer, &events)?;
    let recording = request(&url, "/api/v1/contributions/events", &bearer);
    let mut outcomes = Vec::new();
    let (mut refused, mut unanswered) = (Vec::new(), Vec::new());
    for event in events
        .iter()
        .filter(|event| !held.contains(&event["source_event_id"]))
    {
        let commit = &event["source_event_id"];
        match git::post(&recording, event) {
            Ok(answer) => outcomes.push(json!({"commit": commit, "answer": answer})),
            Err(Unposted::Refused(cause)) => {
                refused.push(commit.clone());
                outcomes.push(json!({"commit": commit, "refused": cause}));
            }
            Err(Unposted::Unanswered(cause)) => {
                unanswered.push(commit.clone());
                outcomes.push(json!({"commit": commit, "unanswered": cause}));
            }
        }
    }
    let document = json!({"ledger": url, "events": outcomes, "held": held});
    Ok(Report {
        document,
        refused,
        unanswered,
    })
}

/// The report, printed one line per commit; why it failed, if it did.
pub(super) fn report(arguments: &Arguments<'_>) -> Result<Option<String>, String> {
    let report = report_document(arguments)?;
    if arguments.json {
        print(&report.document)?;
        return Ok(report.failure());
    }
    for outcome in report.document["events"].as_array().into_iter().flatten() {
        let commit = &outcome["commit"];
        match (outcome.get("refused"), outcome.get("unanswered")) {
            (Some(cause), _) => println!("{commit} refused: {}", text(cause)),
            (None, Some(cause)) => println!("{commit} not answered: {}", text(cause)),
            (None, None) => println!("{commit} recorded: {}", outcome["answer"]["recorded"]),
        }
    }
    println!("already held by the ledger: {}", report.document["held"]);
    Ok(report.failure())
}

/// A sentence the outcome carries, as it was written.
fn text(cause: &Value) -> String {
    match cause.as_str() {
        Some(sentence) => sentence.to_string(),
        None => cause.to_string(),
    }
}
