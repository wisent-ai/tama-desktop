//! Logic for `tama-block-keyword-literals`, registry hook id
//! `block-keyword-literals`.
//!
//! A hand-written list of words in a code file is a classifier nobody
//! asked for: `["ok", "okej", "zrobione"]` decides what an operator meant,
//! `(likely|probably|might)` decides what an agent claimed, `"cannot be
//! decrypted|spawn gpg"` decides why a release failed. Such lists existed in
//! several products, and the rule is that none may: no keyword logic and
//! nothing hard-coded.
//!
//! A run of two or more quoted words, or a regex alternation of two or more
//! words — inside a quoted literal, or a regex literal of a script
//! (`/a|b/`, `finder/regex_literals.rs`) — written into a code file, and any
//! list of two or more words in a data file (JSON, YAML, TOML), is refused; so
//! is the same vocabulary
//! written as a comparison — a chain of `==` against quoted words on one
//! line, or the arms of a `matches!`/`match` pattern joined with `|`
//! (`compared.rs`). Nothing declares a list
//! allowed: a provenance declaration that let a list through whenever its
//! words appeared in some operator message turned his own words into the
//! lists he forbade, and a data file left unopened was the other way
//! around the guard. A word here is letters only, possibly
//! several separated by spaces; `tool_name`, `/dev/null` and `--json` are
//! not words and are not judged. Words handed to a call are that call's
//! data, and a command line bound to a name before it is run — a collection
//! that also holds a computed value or an option such as `--json` — is the
//! process's arguments (`argv.rs`); a collection asked a question where it
//! stands (`[…].contains(x)`) is consulted, whatever else it holds.

mod argv;
mod compared;
mod data;
mod finder;
mod named;
mod text;

use compared::{word_comparisons, word_patterns};
use finder::{word_alternations, word_collections};
pub use named::{named_decisions, named_word_sets, word_bindings};
pub use text::judged_text;

use regex::Regex;
use serde_json::Value;
use tama_hooks::session_record::{deny_tool_use, read_payload};

use super::check_numeric_literals_payload as payload_shapes;
use super::tool_vocabulary::Call;

const HOOK: &str = "block-keyword-literals";
/// The retired declaration file: writing one is refused, never read.
const PROVENANCE_RE: &str = "(^|/)keyword-provenance\\.json\\n?\\z";
const NUL: char = '\0';
/// What a finding in a shell line is named by, in place of a file path.
const SHELL_LINE: &str = "the shell line";
const BANNER_JOIN: &str = "\n  ";
/// Whether `items` is a list: a choice between words needs at least a
/// second one.
fn is_list<T>(items: &[T]) -> bool {
    matches!(items, [_, _, ..])
}

/// Every flagged run in one judged text (see [`judged_text`]), as
/// `(line, kind, words)`. The guard turns these into refusals; `tama
/// vocabulary report` groups them by their words across repositories.
pub fn vocabularies(path: &str, text: &str) -> Vec<(usize, &'static str, Vec<String>)> {
    if data::is_data(path) {
        return data::word_lists(path, text)
            .into_iter()
            .map(|(line, words)| (line, "data list", words))
            .collect();
    }
    word_collections(text)
        .into_iter()
        .map(|(line, words)| (line, "list", words))
        .chain(
            word_alternations(path, text)
                .into_iter()
                .map(|(line, words)| (line, "alternation", words)),
        )
        .chain(
            word_patterns(text)
                .into_iter()
                .map(|(line, words)| (line, "pattern", words)),
        )
        .chain(
            word_comparisons(path, text)
                .into_iter()
                .map(|(line, words)| (line, "comparison", words)),
        )
        .collect()
}

fn worded(path: &str, found: Vec<(usize, &'static str, Vec<String>)>) -> Vec<String> {
    found
        .into_iter()
        .map(|(line, kind, words)| {
            let quoted: Vec<String> = words.iter().map(|w| format!("\"{w}\"")).collect();
            format!(
                "{path}:{line}: a {kind} of {} words decides something by keyword ({})",
                words.len(),
                quoted.join(", ")
            )
        })
        .collect()
}

fn check(payload: &Value) -> Vec<String> {
    let call = Call::of(payload);
    let Some(input) = call.input() else {
        return Vec::new();
    };
    let provenance_path = match Regex::new(PROVENANCE_RE) {
        Ok(pattern) => pattern,
        Err(error) => {
            return vec![format!(
                "TAMA_HOOK_INFRASTRUCTURE: the retired provenance file's pattern does not compile: {error}"
            )]
        }
    };
    let mut out = Vec::new();
    let texts = match payload_shapes::path_texts(input, call.session_cwd()) {
        Ok(texts) => texts,
        Err(error) => return vec![format!("TAMA_HOOK_INFRASTRUCTURE: {error}")],
    };
    for (raw_path, text) in texts {
        let Some(path) = payload_shapes::local_file_path(&raw_path) else {
            continue;
        };
        if path.is_empty() || text.is_empty() || text.contains(NUL) {
            continue;
        }
        if provenance_path.is_match(&path) {
            out.push(format!(
                "{path}: keyword-provenance.json no longer allows any word list; no file may \
                 declare one"
            ));
            continue;
        }
        if let Some(judged) = judged_text(&path, &text) {
            out.extend(worded(&path, vocabularies(&path, &judged)));
        }
    }
    out.extend(supervised_line(&call, payload));
    out
}

/// What the shell line handed by a session Oko records as a supervisor
/// decides by keyword. A supervisor reads registers and transcripts to
/// group, wait on and hand out work; a quoted alternation of words in its
/// line (`grep -E 'refused|blocked'`, a wait for one of several words)
/// decides that grouping or that wait by word match instead of by the
/// registers' fields or a judgement. The role is read only for a line that
/// holds such a run, and a role that cannot be read is said.
fn supervised_line(call: &Call, payload: &Value) -> Vec<String> {
    if !call.is_shell() {
        return Vec::new();
    }
    let Some(line) = call.command() else {
        return Vec::new();
    };
    let found: Vec<(usize, &'static str, Vec<String>)> = word_alternations(SHELL_LINE, line)
        .into_iter()
        .map(|(at, words)| (at, "alternation", words))
        .collect();
    if found.is_empty() {
        return Vec::new();
    }
    let session = tama_hooks::session_record::session_id_of(payload);
    match tama_hooks::supervisor_stop::is_supervisor(&session) {
        Ok(true) => worded(SHELL_LINE, found),
        Ok(false) => Vec::new(),
        Err(cause) => vec![format!(
            "TAMA_HOOK_INFRASTRUCTURE: whether this session supervises cannot be read, so its \
             shell line's word alternation cannot be judged: {cause}"
        )],
    }
}

/// A payload without written text — a read, a bash line — yields no
/// (path, text) pair from `path_texts`; only a supervisor's shell line is
/// read besides (`supervised_line`). That is also what keeps this guard
/// free of a list of tool names, which its own rule would refuse.
pub fn run() {
    let payload = read_payload();
    if !payload.is_object() {
        payload_shapes::crash();
    }
    let mut violations = check(&payload).into_iter();
    // The first line is what a scanner report and a harness card show, so it
    // carries the first finding; the rule and the way through come next.
    let Some(first) = violations.next() else {
        return;
    };
    let rest: String = violations
        .map(|violation| format!("{BANNER_JOIN}{violation}"))
        .collect();
    deny_tool_use(&format!(
        "{HOOK}: BLOCKED: {first}\n  a keyword list is a classifier nobody asked for, in code or \
         in a data file, and no declaration allows one. Decide with a model judgement through \
         Brama, or from the structure the input already carries (a field, a status code, an \
         exit code).{rest}"
    ));
}
