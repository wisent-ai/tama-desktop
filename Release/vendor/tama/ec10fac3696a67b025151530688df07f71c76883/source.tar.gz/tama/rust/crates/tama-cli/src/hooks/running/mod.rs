//! `tama hooks running [--json]`: the hooks the session runtimes are running
//! right now, and for how long, and how each session's last turn ended.
//!
//! A session's core runs each dispatch on its own thread, so a hook that does
//! not end holds only the tool call that started it. The core keeps one record
//! per running hook (`in-flight.<core pid>.<hook pid>.json` in the
//! session-control directory, `TAMA_SESSION_CONTROL_ROOT` or
//! `~/Library/Application Support/Tama/session-control`) and removes it when
//! the hook ends. This reads those records from any terminal or session: the
//! event, the hook id, the session it runs for, the hook's process id, how
//! long it has run, and whether the core that wrote the record is still alive
//! (a record whose core is gone is reported as such, not as a running hook).
//!
//! A hook that does not end is almost always waiting on a program it started:
//! the vault, a model gateway request, a fleet lookup. Each running hook's
//! child processes (`waitingOn`: pid and command line, from `ps`) are listed
//! with it, so the call it is stuck in is named, not guessed.
//!
//! Each session's last `stop` is listed too (`turn_ends`), so a turn that
//! ended while work was open says whether the stop gates let it end, refused
//! it after the harness had stopped waiting, or were never answered.

pub mod abandoned;
pub mod calls;
mod turn_ends;

use std::path::PathBuf;

use abandoned::plain;

fn root() -> PathBuf {
    match std::env::var_os("TAMA_SESSION_CONTROL_ROOT").filter(|root| !root.is_empty()) {
        Some(root) => PathBuf::from(root),
        None => tama_hook_tools::util::home_dir()
            .join("Library")
            .join("Application Support")
            .join("Tama")
            .join("session-control"),
    }
}

/// What a running-hook record says about its hook and its core.
fn state(record: &serde_json::Value) -> String {
    if let Some(state) = record["ownershipState"].as_str() {
        return state.to_string();
    }
    match (record["coreAlive"].as_bool(), record["hookAlive"].as_bool()) {
        (Some(true), Some(true)) => "running",
        (Some(true), _) => "hook process gone, core has not answered",
        (_, Some(true)) => "core gone; hook still running with nobody waiting for it",
        _ => "core and hook gone; record left behind (the next core to start removes it)",
    }
    .to_string()
}

pub fn main(argv: &[String]) -> i32 {
    let json_output = match argv {
        [] => false,
        [flag] if flag == "--json" => true,
        _ => {
            eprintln!("usage: tama hooks running [--json]");
            return libc::EXIT_FAILURE;
        }
    };
    let root = root();
    let mut report = match tama_run_hook::inspect_running_hooks(&root) {
        Ok(report) => report,
        Err(error) => {
            eprintln!("{error}");
            return libc::EXIT_FAILURE;
        }
    };
    let abandoned = match tama_run_hook::inspect_abandoned_dispatches(&root) {
        Ok(abandoned) => abandoned,
        Err(error) => {
            eprintln!("{error}");
            return libc::EXIT_FAILURE;
        }
    };
    let endings = match tama_run_hook::inspect_turn_ends(&root) {
        Ok(endings) => endings,
        Err(error) => {
            eprintln!("{error}");
            return libc::EXIT_FAILURE;
        }
    };
    report["abandoned"] = abandoned["abandoned"].clone();
    report["abandonedErrors"] = abandoned["errors"].clone();
    report["turnEnds"] = endings["turnEnds"].clone();
    report["turnEndErrors"] = endings["errors"].clone();
    let running = match report["running"].as_array() {
        Some(running) => running,
        None => {
            eprintln!("runtime inspection returned no running-hook list");
            return libc::EXIT_FAILURE;
        }
    };
    let unread =
        |errors: &serde_json::Value| errors.as_array().is_some_and(|errors| !errors.is_empty());
    let has_errors = unread(&report["errors"])
        || unread(&report["abandonedErrors"])
        || unread(&report["turnEndErrors"]);
    let failed = has_errors
        || running
            .iter()
            .any(|record| record["orphanTermination"]["sent"].as_bool() == Some(false));
    let exit = if failed {
        libc::EXIT_FAILURE
    } else {
        libc::EXIT_SUCCESS
    };
    if json_output {
        println!("{report}");
        return exit;
    }
    for error in report["errors"].as_array().into_iter().flatten() {
        eprintln!("runtime inspection: {error}");
    }
    for error in report["abandonedErrors"].as_array().into_iter().flatten() {
        eprintln!("abandoned-dispatch register: {error}");
    }
    for error in report["turnEndErrors"].as_array().into_iter().flatten() {
        eprintln!("turn-end register: {error}");
    }
    abandoned::print(&report["abandoned"]);
    turn_ends::print(&report["turnEnds"]);
    for ended in report["removed"].as_array().into_iter().flatten() {
        println!(
            "removed ended hook record {}: {}",
            plain(&ended["record"]),
            plain(&ended["reason"]),
        );
    }
    if running.is_empty() {
        println!("no running hook records were found ({})", root.display());
        return exit;
    }
    for record in running {
        println!(
            "{} {} of session {} for {} ms (hook pid {}, core pid {}): {}",
            plain(&record["event"]),
            plain(&record["hookId"]),
            plain(&record["sessionId"]),
            plain(&record["runningForMs"]),
            plain(&record["hookPid"]),
            plain(&record["corePid"]),
            state(record),
        );
        for child in record["waitingOn"].as_array().into_iter().flatten() {
            println!(
                "  waiting on pid {}: {}",
                plain(&child["pid"]),
                plain(&child["command"])
            );
        }
        if let Some(termination) = record.get("orphanTermination") {
            println!("  orphan termination: {termination}");
        }
    }
    exit
}
