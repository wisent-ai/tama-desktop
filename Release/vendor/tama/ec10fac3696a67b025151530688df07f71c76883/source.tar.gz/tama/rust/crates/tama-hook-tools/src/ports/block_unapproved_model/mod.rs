//! Decision half of `tama hook block-unapproved-model` (hook id
//! `block-unapproved-model`): which model does the work is the operator's
//! choice, never the agent's. A call is refused when it picks a model he did
//! not name:
//!
//! - a delegation tool (`task`, `agent`) given a `model`;
//! - a shell line that starts a coding agent's command line (`claude`,
//!   `codex`, `omp`, … as `models.json` declares them) with `--model` or
//!   `-m`;
//! - a write that leaves a file naming a model the file did not name before:
//!   a token of a declared family (`qwen`, `devstral`, `claude`, `gpt`, …)
//!   followed by its version, so `qwen2.5-coder` and `claude-opus-4-7` are
//!   model ids and the word Claude in a sentence is not.
//!
//! The operator's word admits it: `tama justify record --kind model` with
//! the model ids as actions and his own sentence naming the model as the
//! quote ([`crate::ports::operator_grant`]). No model, no network, no lock:
//! the payload, the files a write changes and, on a finding, the grant
//! registry and the session's transcript are read. A vocabulary that cannot
//! be read refuses nothing and says so.

use std::collections::BTreeSet;
use std::sync::LazyLock;

use serde::Deserialize;
use serde_json::Value;

use crate::ports::block_reserved_changes::command_starts;
use crate::ports::operator_grant::{self, Request};
use crate::ports::pre_write_edit::resulting;
use crate::ports::tool_vocabulary::Call;
use crate::ports::write_payload::WritePayload;

pub const HOOK_ID: &str = "block-unapproved-model";
pub const GRANT_KIND: &str = "model";

#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
struct Vocabulary {
    said: String,
    families: Vec<String>,
    agent_programs: Vec<String>,
    model_options: Vec<String>,
    spawn_tools: Vec<String>,
    spawn_keys: Vec<String>,
}

static VOCABULARY: LazyLock<Result<Vocabulary, String>> = LazyLock::new(|| {
    serde_json::from_str(include_str!("models.json"))
        .map_err(|error| format!("{HOOK_ID}: models.json cannot be read: {error}"))
});

/// The refusal for the call in `payload`, `None` when it chooses no model
/// or the operator named every model it chooses.
pub fn evaluate(payload: &Value) -> Option<String> {
    let vocabulary = match &*VOCABULARY {
        Ok(vocabulary) => vocabulary,
        Err(cause) => {
            eprintln!("{cause}; nothing is refused");
            return None;
        }
    };
    let call = Call::of(payload);
    let (chosen, how) = if call.is_shell() {
        (
            started(vocabulary, payload, call.command()?),
            "starts an agent on",
        )
    } else if vocabulary.spawn_tools.iter().any(|tool| call.is(tool)) {
        (delegated(vocabulary, &call), "delegates to")
    } else if call.changes_files() {
        (written(vocabulary, payload), "writes in")
    } else {
        return None;
    };
    if chosen.is_empty() {
        return None;
    }
    let models: Vec<String> = chosen.into_iter().collect();
    let request = Request {
        gate: HOOK_ID,
        command: call.command(),
        paths: &models,
    };
    if operator_grant::granted(payload, &request) {
        return None;
    }
    Some(format!(
        "BLOCKED ({HOOK_ID}): this call {how} a model the operator did not choose: {}. Which model \
         works is his choice (\"{}\"): keep the model he named, or the one already configured. {}",
        models.join(", "),
        vocabulary.said,
        operator_grant::how_to_grant(GRANT_KIND, HOOK_ID)
    ))
}

/// The models a shell line starts a coding agent on.
fn started(vocabulary: &Vocabulary, payload: &Value, command: &str) -> BTreeSet<String> {
    let mut chosen = BTreeSet::new();
    for start in command_starts(payload, command) {
        let Some((program, args)) = start.split_first() else {
            continue;
        };
        let name = last_segment(program);
        if !vocabulary.agent_programs.iter().any(|agent| agent == name) {
            continue;
        }
        let mut words = args.iter();
        while let Some(word) = words.next() {
            for option in &vocabulary.model_options {
                if word == option {
                    chosen.extend(words.next().cloned());
                } else if let Some(value) = word.strip_prefix(&format!("{option}=")) {
                    chosen.insert(value.to_string());
                }
            }
        }
    }
    chosen
}

/// The model a delegation tool is handed, at the top of its arguments or in
/// any task it lists.
fn delegated(vocabulary: &Vocabulary, call: &Call) -> BTreeSet<String> {
    let mut chosen = BTreeSet::new();
    let mut pending: Vec<&Value> = call.input().into_iter().collect();
    while let Some(value) = pending.pop() {
        match value {
            Value::Object(map) => {
                for (key, inner) in map {
                    match inner.as_str() {
                        Some(model)
                            if vocabulary.spawn_keys.contains(key) && !model.trim().is_empty() =>
                        {
                            chosen.insert(model.trim().to_string());
                        }
                        _ => pending.push(inner),
                    }
                }
            }
            Value::Array(items) => pending.extend(items),
            _ => {}
        }
    }
    chosen
}

/// The text after the last `/`, the whole text when it holds none.
fn last_segment(text: &str) -> &str {
    match text.rsplit_once('/') {
        Some((_, tail)) => tail,
        None => text,
    }
}

/// Whether `token` (lower-cased, its directory dropped) is a model id of
/// `family`: the family's name followed by its version.
fn of_family(token: &str, family: &str) -> bool {
    token.strip_prefix(family).is_some_and(|rest| {
        rest.chars()
            .next()
            .is_some_and(|next| next.is_ascii_digit() || "-.".contains(next))
            && rest.chars().any(|character| character.is_ascii_digit())
    })
}

/// The model ids of a declared family in `text`.
fn model_ids(vocabulary: &Vocabulary, text: &str) -> BTreeSet<String> {
    text.split(|character: char| !(character.is_alphanumeric() || "-._:/".contains(character)))
        .map(|token| {
            last_segment(token.trim_matches(|character: char| ".:/".contains(character)))
                .to_lowercase()
        })
        .filter(|token| {
            vocabulary
                .families
                .iter()
                .any(|family| of_family(token, family))
        })
        .collect()
}

/// The model ids the files a write leaves name that they did not name
/// before. A write whose files cannot be rebuilt, or a file whose earlier
/// text cannot be read, is left to the gates that judge the file itself.
fn written(vocabulary: &Vocabulary, payload: &Value) -> BTreeSet<String> {
    let Ok(write) = WritePayload::read(payload) else {
        return BTreeSet::new();
    };
    let Ok(Some(files)) = resulting(payload, &write) else {
        return BTreeSet::new();
    };
    let mut chosen = BTreeSet::new();
    for (path, after) in files {
        let before = match std::fs::read_to_string(&path) {
            Ok(text) => model_ids(vocabulary, &text),
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => BTreeSet::new(),
            Err(error) => {
                eprintln!(
                    "{HOOK_ID}: {path} cannot be read, so its models are not judged: {error}"
                );
                continue;
            }
        };
        chosen.extend(
            model_ids(vocabulary, &after)
                .into_iter()
                .filter(|id| !before.contains(id)),
        );
    }
    chosen
}
