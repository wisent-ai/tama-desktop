//! Installing a sealed hook release on this machine: `tama hooks
//! install-release`, and the same function `tama hooks release` calls for
//! the release Stado placed. A session-control install writes the managed
//! hook trees, the registry, both provider configurations and the Git
//! dispatchers already Tama's; a full install also restores the entrypoints
//! an emergency disable moved aside and writes every Git dispatcher.

mod apply;
mod entrypoints;
mod registry;
mod verify;
mod writes;

use std::collections::BTreeSet;
use std::path::{Path, PathBuf};

use serde_json::{json, Value};

use super::package::seal::{tree_digest, EXTERNAL_SCHEMA};
use super::package::{copy_tree, load_object};

/// The release's content-addressed copy under the runtime, verified after the copy.
fn copied_release(release_root: &Path, releases: &Path, id: &str) -> Result<PathBuf, String> {
    let installed = releases.join(id);
    let held = tama_core::presence::present(&installed).map_err(|error| error.to_string())?;
    if held && tree_digest(&installed)? != id {
        std::fs::remove_dir_all(&installed).map_err(|error| {
            format!(
                "cannot remove the altered release {}: {error}",
                installed.display()
            )
        })?;
    }
    if !tama_core::presence::present(&installed).map_err(|error| error.to_string())? {
        std::fs::create_dir_all(releases)
            .map_err(|error| format!("cannot create {}: {error}", releases.display()))?;
        let temporary = releases.join(format!(".{id}-{}", std::process::id()));
        match std::fs::remove_dir_all(&temporary) {
            Err(error) if error.kind() != std::io::ErrorKind::NotFound => {
                return Err(format!(
                    "cannot clear the stale copy {}: {error}",
                    temporary.display()
                ));
            }
            _ => {}
        }
        copy_tree(release_root, &temporary)?;
        if let Err(error) = std::fs::rename(&temporary, &installed) {
            let refused = format!(
                "cannot move {} to {}: {error}",
                temporary.display(),
                installed.display()
            );
            return Err(match std::fs::remove_dir_all(&temporary) {
                Err(left) if left.kind() != std::io::ErrorKind::NotFound => {
                    format!("{refused}; {} is left behind: {left}", temporary.display())
                }
                _ => refused,
            });
        }
    }
    if tree_digest(&installed)? != id {
        return Err("Installed Tama hook release failed its integrity check".to_string());
    }
    Ok(installed)
}

/// The managed files this install writes, and the previous install's that go.
fn source_file_changes(
    writes: &writes::Writes,
    previous: &Value,
    home: &Path,
) -> Result<(BTreeSet<String>, BTreeSet<PathBuf>), String> {
    let roots = [
        home.join(".shared-hooks"),
        home.join(".claude/hooks"),
        home.join(".codex/hooks"),
    ];
    let launchers = [
        home.join(".local/bin/tama-agent"),
        home.join(".local/bin/tama-omp"),
        home.join(".local/bin/tama-agent-supervisor"),
    ];
    let managed = |path: &Path| roots.iter().any(|root| path.starts_with(root));
    let new: BTreeSet<String> = writes
        .keys()
        .filter(|p| managed(p) || launchers.first() == Some(*p))
        .map(|p| p.display().to_string())
        .collect();
    let obsolete: BTreeSet<PathBuf> = previous["sourceFiles"]
        .as_array()
        .into_iter()
        .flatten()
        .filter_map(Value::as_str)
        .filter(|p| !new.contains(*p))
        .map(PathBuf::from)
        .collect();
    if let Some(outside) = obsolete
        .iter()
        .find(|p| !launchers.contains(*p) && !managed(p))
    {
        return Err(format!(
            "Refusing to remove an obsolete path outside managed roots: {}",
            outside.display()
        ));
    }
    Ok((new, obsolete))
}

/// Install the sealed release at `release_root` into `home`.
pub fn install_release(
    release_root: &Path,
    home: &Path,
    manifest_path: Option<&Path>,
    session_control_only: bool,
) -> Result<Value, String> {
    let release_root = std::fs::canonicalize(release_root)
        .map_err(|e| format!("cannot read {}: {e}", release_root.display()))?;
    let verified = verify::verified_release(&release_root)?;
    let (node, node_version) = registry::require_supported_node(&release_root)?;
    let runtime_root = home.join("Library/Application Support/Tama/hooks-runtime");
    let stable = runtime_root.join("current");
    let native = verify::declared_native_binaries(&release_root, &verified.registry)?;
    let external = load_object(&release_root.join("external-sources.json"))?;
    if external["schema"] != EXTERNAL_SCHEMA {
        return Err("Unsupported external hook source manifest".to_string());
    }
    let mappings: Vec<(String, String)> = external["mappings"]
        .as_array()
        .into_iter()
        .flatten()
        .map(|m| {
            Ok((
                text_field(m, "sourcePrefix", "external-sources.json mapping")?,
                text_field(m, "releasePath", "external-sources.json mapping")?,
            ))
        })
        .collect::<Result<_, String>>()?;
    verify::require_approved_sources(
        &verified.registry,
        &mappings,
        &release_root,
        &verified,
        home,
    )?;
    let (registry, preflight) = registry::installed_registry(
        &release_root,
        &verified,
        &mappings,
        home,
        &stable,
        &node,
        &native,
    )?;
    let installed_path = runtime_root.join("installed.json");
    let previous = if installed_path.is_file() {
        load_object(&installed_path)?
    } else {
        json!({})
    };
    let id = text_field(
        &verified.release,
        "releaseId",
        "the verified release record",
    )?;
    let installed_release = copied_release(&release_root, &runtime_root.join("releases"), &id)?;
    let (manifest, backup) = match (session_control_only, manifest_path) {
        (true, _) => (json!({}), None),
        (false, Some(path)) => (load_object(path)?, path.parent().map(Path::to_path_buf)),
        (false, None) => {
            return Err("Full hook installation requires an emergency manifest".to_string())
        }
    };
    let mut planned = writes::release_file_map(&release_root, home, &registry)?;
    writes::provider_writes(
        &mut planned,
        &release_root,
        home,
        &registry,
        writes::Runtime {
            node: &node,
            preflight: &preflight,
        },
        &manifest,
        backup.as_deref(),
    )?;
    let moved: Vec<(PathBuf, PathBuf)> = manifest["moved"]
        .as_array()
        .into_iter()
        .flatten()
        .map(|m| {
            Ok((
                PathBuf::from(text_field(
                    m,
                    "source",
                    "the emergency manifest's moved entry",
                )?),
                PathBuf::from(text_field(
                    m,
                    "disabled",
                    "the emergency manifest's moved entry",
                )?),
            ))
        })
        .collect::<Result<_, String>>()?;
    if !session_control_only {
        entrypoints::refuse_entrypoint_conflicts(&moved)?;
        entrypoints::add_git_hook_writes(
            &mut planned,
            home,
            &runtime_root,
            &release_root,
            &moved,
            &verified.old_root,
            &verified.old_home,
        )?;
    } else {
        entrypoints::add_managed_dispatcher_writes(&mut planned, home, &runtime_root)?;
    }
    let (new_files, obsolete) = source_file_changes(&planned, &previous, home)?;
    let release = &verified.release;
    let record = json!({
        "releaseId": id,
        "catalogChecksum": registry["catalogChecksum"],
        "packageVersion": release.get("packageVersion"),
        "catalogVersion": release.get("catalogVersion"),
        "catalogUpdatedAt": release.get("catalogUpdatedAt"),
        "previousReleaseId": previous.get("releaseId"),
        "sourceFiles": new_files,
        "nodeExecutable": node.display().to_string(),
        "nodeVersion": node_version,
    });
    let installed = apply::apply_install(apply::Plan {
        runtime_root: &runtime_root,
        installed_release: &installed_release,
        writes: &planned,
        obsolete: &obsolete,
        moved: &moved,
        home,
        record,
    })?;
    let previous = match previous.as_object() {
        Some(object) if object.is_empty() => Value::Null,
        _ => previous,
    };
    Ok(json!({
        "installed": installed,
        "previous": previous,
        "managedSourceFiles": new_files.len(),
        "restoredEntrypoints": moved.len(),
        "sessionControlOnly": session_control_only,
    }))
}

fn option(argv: &[String], flag: &str) -> Option<String> {
    let mut words = argv.iter();
    words.find(|word| *word == flag)?;
    words.next().cloned()
}

/// `tama hooks install-release --release <dir> --home <dir>
/// [--emergency-manifest <file>] [--session-control-only]`: one JSON result
/// on stdout, or `Tama hook release installation failed: <reason>` and exit 1.
/// A missing --release or --home is a usage error: the usage and exit 2.
pub fn main(argv: &[String]) -> i32 {
    let (Some(release), Some(home)) = (option(argv, "--release"), option(argv, "--home")) else {
        eprintln!("usage: tama hooks install-release --release <dir> --home <dir> [--emergency-manifest <file>] [--session-control-only]");
        return tama_core::exit::USAGE;
    };
    let manifest = option(argv, "--emergency-manifest").map(PathBuf::from);
    let session_only = argv.iter().any(|word| word == "--session-control-only");
    match install_release(
        Path::new(&release),
        Path::new(&home),
        manifest.as_deref(),
        session_only,
    ) {
        Ok(result) => {
            println!("{result}");
            libc::EXIT_SUCCESS
        }
        Err(error) => {
            eprintln!("Tama hook release installation failed: {error}");
            libc::EXIT_FAILURE
        }
    }
}

/// The text `field` of `record`, or an install error naming the field and
/// `what` record lacks it: an empty string in its place would install a
/// mapping, release or move that points nowhere.
fn text_field(record: &Value, field: &str, what: &str) -> Result<String, String> {
    record[field]
        .as_str()
        .map(str::to_string)
        .ok_or_else(|| format!("{what} carries no text {field}: {record}"))
}
