//! Who holds a file after one session's edit of it. Every edit is admitted;
//! the lease names the file's holder, the first session to edit it while it
//! held no uncommitted change, and no other session.
//!
//! Everything is read under the register's lock: the file's state against
//! `HEAD`, the blob `HEAD` holds at its path, and the lease. A lease is taken
//! in the pre-write hook, before the holder's write lands, so a file that
//! still reads as `HEAD` does not by that alone end a lease: the lease ends
//! once the file is what `HEAD` holds after the holder's edits were seen in
//! it, after a commit changed what `HEAD` holds at the path, after the holder
//! ended, or once the call the holder made on the file has its result in the
//! holder's transcript (another gate refused it, or the tool failed) while
//! the file is unchanged. Since other sessions' edits land on a held file
//! too, the file being changed is no evidence of the holder's edit: the
//! holder's edit is seen once its named call has a result that is no error
//! (read at the holder's next edit of the file or at another session's
//! edit). A holder whose call cannot be named (it has no transcript, or the
//! call is not in it) is seen writing when its own next edit finds the file
//! changed, the only evidence it leaves. On a changed file a holder never
//! seen writing keeps the lease only while it runs and its named call still
//! runs; otherwise another session's edit ends the lease, and the file then
//! holds only edits no lease names. The call is the one the holder's newest
//! assistant record makes on the file when its pre-write hook takes the
//! lease, read from the transcript the holder writes now
//! ([`super::transcript`]). A file that already differs from `HEAD` when no
//! lease names it carries edits of sessions nobody recorded; no lease is
//! taken on it, so no session becomes the holder of edits it did not make.

use std::path::Path;

use super::{change, checkout_of, transcript, unchanged, Checked, Lease};
use tama_core::git::Git;

/// The blob `HEAD` holds at the file's path, or `None` when `HEAD` holds no
/// file there.
pub(super) fn head_blob(checked: &Checked) -> Result<Option<String>, String> {
    let object = format!("HEAD:{}", checked.relative);
    let args = ["rev-parse", "--verify", "--quiet", object.as_str()];
    let output = Git::of(Some(&checked.root)).output(&args)?;
    match (output.status.success(), output.stderr.is_empty()) {
        (true, _) => Ok(Some(
            String::from_utf8_lossy(&output.stdout).trim().to_owned(),
        )),
        (false, true) => Ok(None),
        (false, false) => Err(format!(
            "git {} in {} failed: {}",
            args.join(" "),
            checked.root.display(),
            String::from_utf8_lossy(&output.stderr).trim()
        )),
    }
}

/// Whether `session`'s agent runs now.
pub(super) fn running(session: &str) -> Result<bool, String> {
    Ok(crate::ports::owner_consent::running_sessions()?
        .iter()
        .any(|(_, running)| running == session))
}

/// The call `session`'s newest assistant record makes on the file, read
/// from the transcript it writes now; none when it has no transcript or that
/// record names the file in no call.
fn call_on(session: &str, checked: &Checked) -> Result<Option<String>, String> {
    let Some(transcript) = transcript::of(session)? else {
        return Ok(None);
    };
    transcript::call_on(&transcript, &checked.root.join(&checked.relative))
}

/// Where the call the lease names stands in the holder's transcript; absent
/// when the lease names no call or the holder has no transcript. The harness
/// records a call before its pre-write hook runs and its result once the
/// call ends, refused or failed included.
fn call_state(lease: &Lease) -> Result<transcript::Call, String> {
    let Some(call) = &lease.call else {
        return Ok(transcript::Call::Absent);
    };
    let Some(transcript) = transcript::of(&lease.session)? else {
        return Ok(transcript::Call::Absent);
    };
    transcript::state(&transcript, call)
}

/// A new lease of `session` on a file whose `HEAD` blob is `head_blob`;
/// `written` when the file already holds the edits it passes on, `call` the
/// call that is writing it.
pub(super) fn taken(
    session: &str,
    head_blob: Option<String>,
    written: bool,
    call: Option<String>,
) -> Lease {
    Lease {
        session: session.to_owned(),
        since: tama_core::clock::iso_now_seconds(),
        head_blob,
        written,
        call,
    }
}

/// Keep the actual input of an admitted invocation, even for a dirty file
/// whose unrecorded edits give it no lease.
fn admitted_call(session: &str, checked: &Checked) -> Result<Option<String>, String> {
    let call = call_on(session, checked)?;
    if let Some(call) = &call {
        super::snapshot::capture(checked, session, call)?;
    }
    Ok(call)
}

/// Record an edit of `path` by `session`, which every lease admits: work in a
/// checkout belongs to no session alone, so another session's lease or
/// uncommitted edits never stop this one. The call making the edit is kept
/// (its snapshot is what the commit review reads the edit from). A file that
/// is what `HEAD` holds and that no live lease names leaves `session` holding
/// its lease. An edit of a file another session's lease names leaves that
/// holder holding it, `session` not named, unless the lease has ended as the
/// module says, which on a changed file leaves it with no lease.
pub fn record(path: &Path, session: &str) -> Result<(), String> {
    let Some(checked) = checkout_of(path)? else {
        return Ok(());
    };
    change(&checked.common, |register| {
        let clean = unchanged(&checked)?;
        let head = head_blob(&checked)?;
        let call = admitted_call(session, &checked)?;
        let holds = match register.leases.get_mut(&checked.relative) {
            Some(lease) if lease.session == session => {
                let state = call_state(lease)?;
                lease.written |= state == transcript::Call::Answered
                    || (state == transcript::Call::Absent && !clean);
                lease.call = call.clone();
                true
            }
            Some(lease) if !clean => {
                let state = call_state(lease)?;
                lease.written |= state == transcript::Call::Answered;
                lease.written || (state == transcript::Call::Running && running(&lease.session)?)
            }
            Some(lease) => {
                !(lease.written
                    || lease.head_blob != head
                    || !running(&lease.session)?
                    || call_state(lease)? != transcript::Call::Running)
            }
            None => false,
        };
        if holds {
            return Ok(());
        }
        if clean {
            let lease = taken(session, head, false, call);
            register.leases.insert(checked.relative.clone(), lease);
        } else {
            register.leases.remove(&checked.relative);
        }
        Ok(())
    })
}
