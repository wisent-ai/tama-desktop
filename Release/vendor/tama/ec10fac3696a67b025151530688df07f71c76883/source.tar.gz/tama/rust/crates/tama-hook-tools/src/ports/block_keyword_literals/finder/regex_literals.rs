//! The regex literals of a JavaScript or TypeScript file: `/Try again|Retry/i`
//! decides by keyword exactly as `'Try again|Retry'` does, and a guard that
//! read only quoted literals let every such classifier through.
//!
//! A `/` opens a regex where an operand is expected — after an operator, an
//! opening bracket, a separator, or at the start of the text — and is a
//! division after an operand (a name, a number, a closing bracket, a string).
//! After a name the source alone does not say which (`return /a|b/` against
//! `width / scale`), so there a literal counts only when its closing slash
//! and flags are followed by a method call on it (`.test(`, `.exec(`), which
//! no division is. Strings, template literals and comments are skipped, so a
//! URL or a sentence in a comment is never read as a regex.

use std::iter::Peekable;
use std::str::CharIndices;
use std::sync::LazyLock;

use regex::Regex;

use super::super::super::transport_common as common;

/// The files whose source has regex literals: `.js`, `.mjs`, `.cjs`, `.jsx`
/// and the TypeScript spellings of the same.
static SCRIPT: LazyLock<Regex> = LazyLock::new(|| common::compile("\\.[cm]?[jt]sx?$"));
/// Characters after which an operand, and so a regex, is expected.
const OPERAND_EXPECTED: &str = "(,=:[!&|?{};+-*%<>~^";
/// A literal's flags followed by a method call on it.
static CALLED: LazyLock<Regex> = LazyLock::new(|| common::compile("^[a-z]*\\."));
const SLASH: char = '/';

/// Whether `path` names a file whose source may hold regex literals: a
/// JavaScript or TypeScript source, which the comparison reader also parses.
pub(crate) fn applies(path: &str) -> bool {
    SCRIPT.is_match(path)
}

/// Every regex literal of `text`, as (byte offset of its opening slash, body
/// between the slashes).
pub(super) fn bodies(text: &str) -> Vec<(usize, String)> {
    let mut chars = text.char_indices().peekable();
    let mut found = Vec::new();
    let mut previous: Option<char> = None;
    while let Some((offset, ch)) = chars.next() {
        let next = chars.peek().map(|(_, c)| *c);
        match (ch, next) {
            (SLASH, Some(SLASH)) => {
                skip_line_comment(&mut chars);
                continue;
            }
            (SLASH, Some('*')) => {
                skip_block_comment(&mut chars);
                continue;
            }
            ('"' | '\'' | '`', _) => skip_string(&mut chars, ch),
            (SLASH, _) => {
                if let Some(end) = closing_slash(text, offset) {
                    if opens_regex(previous, text, end) {
                        found.push((offset, text[offset + SLASH.len_utf8()..end].to_owned()));
                        while chars.next_if(|(at, _)| *at <= end).is_some() {}
                    }
                }
            }
            _ => {}
        }
        if !ch.is_whitespace() {
            previous = Some(ch);
        }
    }
    found
}

/// Whether the slash whose literal closes at byte `end` opens a regex, judged
/// by the last significant character before it.
fn opens_regex(previous: Option<char>, text: &str, end: usize) -> bool {
    match previous {
        None => true,
        Some(c) if OPERAND_EXPECTED.contains(c) => true,
        Some(c) if c.is_alphabetic() || c == '_' || c == '$' => {
            CALLED.is_match(&text[end + SLASH.len_utf8()..])
        }
        Some(_) => false,
    }
}

/// The byte offset of the unescaped slash closing the literal that opens at
/// `open`, outside a character class and on the same line.
fn closing_slash(text: &str, open: usize) -> Option<usize> {
    let mut rest = text[open..].char_indices();
    rest.next();
    let mut escaped = false;
    let mut in_class = false;
    for (at, ch) in rest {
        match (ch, escaped, in_class) {
            ('\n', _, _) => return None,
            (_, true, _) => escaped = false,
            ('\\', false, _) => escaped = true,
            ('[', false, false) => in_class = true,
            (']', false, true) => in_class = false,
            (SLASH, false, false) => return Some(open + at),
            _ => {}
        }
    }
    None
}

/// Consumes the rest of a string opened by `quote`.
fn skip_string(chars: &mut Peekable<CharIndices>, quote: char) {
    let mut escaped = false;
    for (_, ch) in chars.by_ref() {
        match (ch, escaped) {
            (_, true) => escaped = false,
            ('\\', false) => escaped = true,
            (c, false) if c == quote => return,
            _ => {}
        }
    }
}

/// Consumes a `//` comment up to its newline.
fn skip_line_comment(chars: &mut Peekable<CharIndices>) {
    for (_, ch) in chars.by_ref() {
        if ch == '\n' {
            return;
        }
    }
}

/// Consumes a `/* … */` comment, the opening star included.
fn skip_block_comment(chars: &mut Peekable<CharIndices>) {
    chars.next();
    let mut star = false;
    for (_, ch) in chars.by_ref() {
        if star && ch == SLASH {
            return;
        }
        star = ch == '*';
    }
}
