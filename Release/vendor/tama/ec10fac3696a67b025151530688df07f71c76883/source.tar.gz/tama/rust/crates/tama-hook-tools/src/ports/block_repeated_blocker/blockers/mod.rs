//! Oko's blocker register as this gate reads it. The operator's rule: an
//! answer's blocker section is a list of blockers from the register - one that
//! is already there, or one the session has just added - and every one of
//! them is checked before it is told: does it still block, or can the agent
//! resolve it itself? One it can resolve is taken off the list with
//! `oko blockers check <id> --resolvable` and the work is done instead.
//!
//! So a line of the section passes only when it names an open blocker whose
//! latest check said it still blocks, and that check is recent. Prose, a
//! defect id alone, a resolved blocker or a blocker nobody re-checked is
//! refused with the command that fixes it.

use std::collections::BTreeMap;

use serde_json::Value;

use super::register::SHORT_ID_LENGTH;

const BLOCKERS_KEY: &str = "blockers";
const ID_KEY: &str = "id";
const BLOCKS_KEY: &str = "blocks";
const RESOLVED_KEY: &str = "resolvedAt";
const RECORDED_KEY: &str = "recordedAt";
const CHECKS_KEY: &str = "checks";
const CHECK_AT_KEY: &str = "at";
const STILL_BLOCKS_KEY: &str = "stillBlocks";

/// One registered blocker as the gate needs it.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(super) struct Blocker {
    pub(super) blocks: String,
    pub(super) resolved: bool,
    /// Seconds since the epoch of the newest still-blocks check, or of the
    /// recording itself when nobody has checked it since.
    pub(super) confirmed_at: i64,
    pub(super) latest_check_resolvable: bool,
}

/// Seconds since the epoch of the RFC 3339 instant `text`, as Oko writes
/// its register and the harness its transcript, read by Tama's one clock.
pub(super) fn epoch_seconds(text: &str) -> Result<i64, String> {
    tama_core::clock::parse(text).map(|at| at.timestamp())
}

/// The text field `key` of a register `record`, or an error naming it.
fn text_of<'a>(record: &'a Value, key: &str) -> Result<&'a str, String> {
    record
        .get(key)
        .and_then(Value::as_str)
        .ok_or_else(|| format!("the blocker register holds an entry without {key}: {record}"))
}

/// Every blocker in the register, keyed by the short id Oko prints. An
/// entry missing what the gate judges it by (its id, what it blocks, when
/// it was recorded or checked) is the error naming it: skipped, a blocker
/// the answer names would be refused as unregistered.
pub(super) fn blockers(document: &Value) -> Result<BTreeMap<String, Blocker>, String> {
    let mut found = BTreeMap::new();
    let list = match document.get(BLOCKERS_KEY) {
        None => return Ok(found),
        Some(Value::Array(list)) => list,
        Some(other) => {
            return Err(format!(
                "the blocker register's {BLOCKERS_KEY} is not a list: {other}"
            ))
        }
    };
    for entry in list {
        let id = text_of(entry, ID_KEY)?;
        let short = id.get(..SHORT_ID_LENGTH).ok_or_else(|| {
            format!("the blocker register holds an id shorter than Oko prints: {id}")
        })?;
        let checks: &[Value] = match entry.get(CHECKS_KEY) {
            None => &[],
            Some(Value::Array(checks)) => checks,
            Some(other) => {
                return Err(format!(
                    "blocker {id} carries checks that are not a list: {other}"
                ))
            }
        };
        let latest_check_resolvable = checks
            .last()
            .and_then(|check| check.get(STILL_BLOCKS_KEY))
            .and_then(Value::as_bool)
            == Some(false);
        let mut checked_at: Option<i64> = None;
        for check in checks {
            if check.get(STILL_BLOCKS_KEY).and_then(Value::as_bool) == Some(true) {
                let at = epoch_seconds(text_of(check, CHECK_AT_KEY)?)?;
                checked_at = checked_at.max(Some(at));
            }
        }
        let confirmed_at = match checked_at {
            Some(at) => at,
            None => epoch_seconds(text_of(entry, RECORDED_KEY)?)?,
        };
        found.insert(
            short.to_ascii_lowercase(),
            Blocker {
                blocks: text_of(entry, BLOCKS_KEY)?.to_string(),
                resolved: entry
                    .get(RESOLVED_KEY)
                    .is_some_and(|value| !value.is_null()),
                confirmed_at,
                latest_check_resolvable,
            },
        );
    }
    Ok(found)
}

/// The blocker register; a register that does not exist yet holds no
/// blockers. One that cannot be located, read or parsed is the error, so a
/// blocker section is refused for that cause instead of as unregistered.
pub(super) fn document() -> Result<Value, String> {
    let path = tama_core::oko_register("OKO_BLOCKER_REGISTER", "blockers.json")?;
    let text = match std::fs::read_to_string(&path) {
        Ok(text) => text,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(Value::Null),
        Err(error) => {
            return Err(format!(
                "the blocker register {} cannot be read: {error}",
                path.display()
            ))
        }
    };
    serde_json::from_str(&text).map_err(|error| {
        format!(
            "the blocker register {} is not JSON: {error}",
            path.display()
        )
    })
}

/// The eight-hex words a line carries, lowercased.
fn ids_in(line: &str) -> Vec<String> {
    line.split(|letter: char| !letter.is_ascii_alphanumeric())
        .filter(|word| word.len() == SHORT_ID_LENGTH && word.chars().all(|c| c.is_ascii_hexdigit()))
        .map(str::to_ascii_lowercase)
        .collect()
}

const RECORD: &str = "`oko blockers record --blocks <task or defect> --failed <the call as run> \
    --error <its exact answer> --tried <the other route and how it ended> --resumes-when <what has to \
    change> --session <SESSION>`";

/// The task and defect this session declared as its current work with
/// `tama task scope set`, lowercased; none when the session has no id or
/// declared nothing (`assignment::rulings::declared_work`). A scope file
/// that exists and cannot be read or parsed is the error: read as
/// undeclared, every blocker of other work would pass.
pub(super) fn current_work(session: Option<&str>) -> Result<Vec<String>, String> {
    match session {
        Some(session) => crate::assignment::rulings::declared_work(session),
        None => Ok(Vec::new()),
    }
}

/// The refusal for a blocker section — or for the section that hands the
/// operator a step, named `section` in the refusal — or nothing when every
/// line names an open blocker that was re-checked since the operator's
/// latest message (`turn_started`, seconds since the epoch, or why that time
/// is not known) and which carries `serving`, the work the operator's
/// current instruction is. A blocker of other work stops nothing he asked
/// for, and reading it under his answer only hides what does.
pub(super) fn refusal(
    section: &str,
    lines: &str,
    register: &BTreeMap<String, Blocker>,
    turn_started: &Result<i64, String>,
    serving: &[String],
) -> Option<String> {
    for line in lines.lines().map(str::trim).filter(|line| !line.is_empty()) {
        let named: Vec<(String, &Blocker)> = ids_in(line)
            .into_iter()
            .filter_map(|id| register.get(&id).map(|blocker| (id, blocker)))
            .collect();
        let Some((id, blocker)) = named.first() else {
            return Some(format!(
                "block-repeated-blocker: the {section} section says \"{line}\" and names no blocker from \
                 Oko's blocker register. A blocker is an entry in that list, not a sentence: name an \
                 existing one by its id (`oko blockers list`), or add it with {RECORD} and name \
                 the id it prints. If you can resolve it yourself, it is not a blocker: do the work."
            ));
        };
        if blocker.resolved || blocker.latest_check_resolvable {
            return Some(format!(
                "block-repeated-blocker: blocker {id} ({}) is off the list - its last check found it \
                 can be resolved. Do the work it named instead of reporting it.",
                blocker.blocks
            ));
        }
        let turn_started = match turn_started {
            Ok(turn_started) => *turn_started,
            Err(cause) => {
                return Some(format!(
                    "block-repeated-blocker: blocker {id} ({}) is named, but the time of the \
                     operator's latest message cannot be read ({cause}), so whether the blocker \
                     was re-checked since he wrote cannot be told. Re-check it and record the \
                     verdict: `oko blockers check {id} --still-blocks --reason <what you ran and \
                     what it answered>`.",
                    blocker.blocks
                ))
            }
        };
        let fresh = blocker.confirmed_at >= turn_started;
        if !fresh {
            return Some(format!(
                "block-repeated-blocker: blocker {id} ({}) has not been checked since the \
                 operator's latest message. Try again whether it still blocks, then record the \
                 verdict: `oko blockers check {id} --still-blocks --reason <what you ran and what \
                 it answered>`, or, when you can resolve it yourself, `oko blockers check {id} \
                 --resolvable --reason <how>` and do the work.",
                blocker.blocks
            ));
        }
        let carried = blocker.blocks.to_ascii_lowercase();
        if !serving.is_empty() && !serving.iter().any(|work| carried.contains(work)) {
            return Some(format!(
                "block-repeated-blocker: blocker {id} carries {}, and this answer serves {}. A \
                 blocker of other work stops nothing the operator asked for here: leave it out of \
                 the {section} section.",
                blocker.blocks,
                serving.join(", ")
            ));
        }
    }
    None
}
