//! Who made each commit review-commit admitted. Git keeps the author a
//! commit names, which every agent session on a machine shares, and the
//! harsh-review rounds say how a candidate was reviewed but not who committed
//! it. So review-commit keeps, when it admits a candidate, what it admitted
//! for the `git commit` process that asked: the staged tree, the committing
//! session (the agent session whose process runs the commit, or the one
//! running session whose recorded edits a commit started outside every
//! session carries; none when no one session can be named: the operator's
//! own commit, one carrying several running sessions' edits, or one whose
//! carried edits cannot be read) and the rounds line it let
//! the commit through with. Only once that same Git process has moved a
//! branch to a commit carrying that tree does the admission become the
//! commit's, kept under the commit's own id: a candidate that never became a
//! commit (refused by a later hook, or a failed write) is admitted to no
//! commit, and an amended commit is found under its own id and parent.
//! `tama reviews admitted --commit REV` answers who made it and on which
//! rounds; a commit made with no hook (a `--no-verify` commit, plumbing, one
//! made before the register existed) has no admission, and the reader says so.
//! The first admission in a repository also keeps where admissions start
//! ([`cutover`]), so review-push can tell a commit made before them from one
//! made around the gate since.

use std::path::{Path, PathBuf};

use serde::{Deserialize, Serialize};

mod cutover;
pub use cutover::{read as cutover, Cutover};

/// The register directory under the repository's common Git directory.
const DIRECTORY: &str = "tama-admissions";
/// Admitted candidates, one per running `git commit` process.
const PENDING: &str = "pending";
/// Admissions of commits Git made, one per commit id.
const COMMITS: &str = "commits";
const SUFFIX: &str = ".json";

/// The session that made an admitted commit.
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "camelCase")]
pub struct Committer {
    pub agent: String,
    pub session: String,
    /// The commit ran outside every session's process tree and was read as
    /// this session's because its index carried the session's edits.
    pub carried: bool,
}

/// A candidate review-commit admitted, waiting for its Git process to make
/// it a commit.
#[derive(Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
struct Candidate {
    tree: String,
    committer: Option<Committer>,
    rounds: Option<String>,
    admitted_at: String,
}

/// One admitted commit.
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Admission {
    pub commit: String,
    /// None for a root commit.
    pub parent: Option<String>,
    pub tree: String,
    /// None when no one agent session can be named for the commit: the
    /// operator's own, one carrying several running sessions' edits, or one
    /// whose carried edits cannot be read.
    pub committer: Option<Committer>,
    /// The `Harsh-Review-Rounds:` line the commit was let through with; none
    /// when the declared judge decides alone.
    pub rounds: Option<String>,
    pub admitted_at: String,
    /// When the Git process moved a branch to the commit.
    pub committed_at: String,
}

/// Git's answer in `repository`, trimmed, through the crate's one runner.
fn answer(repository: &Path, args: &[&str]) -> Result<String, String> {
    tama_core::git::at(repository, args).map(|answer| answer.trim().to_owned())
}

/// The admission register of `repository`, in its common Git directory.
fn directory(repository: &Path) -> Result<PathBuf, String> {
    let common = answer(
        repository,
        &["rev-parse", "--path-format=absolute", "--git-common-dir"],
    )?;
    Ok(PathBuf::from(common).join(DIRECTORY))
}

fn register(repository: &Path, part: &str, name: &str) -> Result<PathBuf, String> {
    Ok(directory(repository)?
        .join(part)
        .join(format!("{name}{SUFFIX}")))
}

fn write(path: &Path, value: &impl Serialize) -> Result<(), String> {
    if let Some(directory) = path.parent() {
        std::fs::create_dir_all(directory)
            .map_err(|cause| format!("cannot create {}: {cause}", directory.display()))?;
    }
    let text = serde_json::to_string(value)
        .map_err(|cause| format!("cannot encode the admission: {cause}"))?;
    std::fs::write(path, text).map_err(|cause| format!("cannot write {}: {cause}", path.display()))
}

/// Keep what review-commit admitted for the `git commit` process `git_pid`,
/// replacing what an earlier process with that id left unmade.
pub fn admit(
    repository: &Path,
    git_pid: i32,
    tree: &str,
    committer: Option<Committer>,
    rounds: Option<String>,
) -> Result<(), String> {
    cutover::start(repository)?;
    let candidate = Candidate {
        tree: tree.to_owned(),
        committer,
        rounds,
        admitted_at: tama_core::clock::iso_now(),
    };
    write(
        &register(repository, PENDING, &git_pid.to_string())?,
        &candidate,
    )
}

/// The Git process `git_pid` ended a ref transaction that moved refs to the
/// commits `moved`. Committed, the candidate it was admitted becomes the
/// admission of the moved commit carrying its tree; aborted, the candidate
/// is dropped. None when the process has no candidate, or moved no commit
/// carrying its tree (the candidate then waits for the move that does).
pub fn settle(
    repository: &Path,
    git_pid: i32,
    committed: bool,
    moved: &[String],
) -> Result<Option<Admission>, String> {
    let path = register(repository, PENDING, &git_pid.to_string())?;
    let text = match std::fs::read_to_string(&path) {
        Ok(text) => text,
        Err(cause) if cause.kind() == std::io::ErrorKind::NotFound => return Ok(None),
        Err(cause) => return Err(format!("cannot read {}: {cause}", path.display())),
    };
    let remove = || {
        std::fs::remove_file(&path)
            .map_err(|cause| format!("cannot remove {}: {cause}", path.display()))
    };
    if !committed {
        remove()?;
        return Ok(None);
    }
    let candidate: Candidate = serde_json::from_str(&text)
        .map_err(|cause| format!("{} holds no admitted candidate: {cause}", path.display()))?;
    for commit in moved {
        if answer(repository, &["rev-parse", &format!("{commit}^{{tree}}")])? != candidate.tree {
            continue;
        }
        let parents = answer(repository, &["log", "--max-count=1", "--format=%P", commit])?;
        let admission = Admission {
            commit: commit.clone(),
            parent: parents.split_whitespace().next().map(str::to_owned),
            tree: candidate.tree,
            committer: candidate.committer,
            rounds: candidate.rounds,
            admitted_at: candidate.admitted_at,
            committed_at: tama_core::clock::iso_now(),
        };
        write(&register(repository, COMMITS, commit)?, &admission)?;
        remove()?;
        return Ok(Some(admission));
    }
    Ok(None)
}

/// The admission of `commit` in `repository`, refused naming the commit
/// when review-commit admitted none that became it.
pub fn admitted(repository: &Path, commit: &str) -> Result<Admission, String> {
    let resolved = answer(
        repository,
        &["rev-parse", "--verify", &format!("{commit}^{{commit}}")],
    )?;
    if let Some(admission) = kept(repository, &resolved)? {
        return Ok(admission);
    }
    let tree = answer(repository, &["rev-parse", &format!("{resolved}^{{tree}}")])?;
    let parents = answer(
        repository,
        &["log", "--max-count=1", "--format=%P", &resolved],
    )?;
    Err(format!(
        "commit {resolved} (tree {tree}, parents [{parents}]) has no admission at {}: \
         review-commit admitted no candidate that this commit became (a commit made \
         before admissions were kept, with --no-verify or with plumbing runs no hook)",
        register(repository, COMMITS, &resolved)?.display()
    ))
}

/// The admission kept under the whole commit id `commit`, or none when
/// review-commit admitted no candidate that became it. The id is not
/// resolved, so a commit Git has since pruned is still answered.
pub fn kept(repository: &Path, commit: &str) -> Result<Option<Admission>, String> {
    let path = register(repository, COMMITS, commit)?;
    match std::fs::read_to_string(&path) {
        Ok(text) => serde_json::from_str(&text)
            .map(Some)
            .map_err(|cause| format!("{} holds no admission: {cause}", path.display())),
        Err(cause) if cause.kind() == std::io::ErrorKind::NotFound => Ok(None),
        Err(cause) => Err(format!("cannot read {}: {cause}", path.display())),
    }
}
