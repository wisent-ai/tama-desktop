//! Logic for `tama hook block-hook-scan-narrowing`, registry hook id
//! `block-hook-scan-narrowing`.
//!
//! A write gate on Tama's own source. Agents met a gate that named a
//! violation a file already held and, instead of removing it, edited the
//! gate: judge only the lines a write adds, count out what the file held
//! before, exempt a path. Each such edit left every old violation in place
//! for good. The operator's order is that such an edit is refused and the
//! violation cleaned, whoever left it.
//!
//! Whether an edit narrows what a gate judges is what the code does, not its
//! words: a list of phrases is the keyword logic `block-keyword-literals`
//! forbids, and a renamed variable would pass it. The file before the write
//! and the file after it are read by a model through Oko's model call
//! (`ports::model_judgement`) with the operator's words in the prompt
//! (`judge-prompt.md`). Tama's source is every file of the Tama checkout on
//! this machine (`tama_core::found_checkout`, `TAMA_ROOT` for a test), when
//! there is one, and of the installed hook root `~/.shared-hooks`; a write
//! anywhere else is not
//! judged. A file the edit does not change is not judged. A question the
//! judge leaves unanswered refuses with its cause, naming the file, as for
//! every model-judged gate (`model_judgement::unanswered`).

use std::path::{Path, PathBuf};

use serde_json::Value;
use tama_hooks::session_record::{deny_tool_use, read_payload};

use crate::ports::tool_vocabulary::Call;

use crate::ports::check_numeric_literals_payload::path_texts;
use crate::ports::model_judgement;

const TAG: &str = "block-hook-scan-narrowing";
/// The operator's words on an edit that narrows what a gate scans.
const ORDER: &str = "Edycja hookow czesto skupia sie na tym zeby ignorowac istniejace violation i skanowac \
                     tylko nowo dodany tekst ... Takie obchodzenie hookow ma byc zablokowane ... Jesli jest \
                     jakis hook violation ma byc wyczyszczony. To ze zrobila to inna sesja badz tak bylo \
                     wczesniej nie ma znaczenia.";
const PROMPT: &str = include_str!("judge-prompt.md");
/// The schema the judge answers under and the two options it chooses from.
const JUDGEMENT: &str = "hook_scan_narrowing";
const PASS: &str = "PASS";
const BLOCK: &str = "BLOCK";
/// The installed hook root under the home directory.
const INSTALLED_HOOKS: &str = ".shared-hooks";

fn log(text: &str) {
    eprintln!("{TAG}: {text}");
}

/// The roots whose files are Tama's source; a checkout that cannot be
/// examined is the error, since a write under it might narrow a gate.
fn roots() -> Result<Vec<PathBuf>, String> {
    let mut roots = Vec::new();
    if let Some(checkout) = tama_core::found_checkout()? {
        roots.push(checkout);
    }
    if let Some(home) = std::env::var_os("HOME") {
        roots.push(Path::new(&home).join(INSTALLED_HOOKS));
    }
    Ok(roots)
}

/// The file as it is before the write: empty for a file the write creates;
/// a file that exists and cannot be read is a refusal naming it, since a
/// gate that skipped it would let any edit of it through.
fn before(path: &str) -> Result<String, String> {
    match std::fs::read_to_string(path) {
        Ok(text) => Ok(text),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(String::new()),
        Err(error) => Err(format!(
            "{TAG}: {path} cannot be read to judge the edit of it: {error}"
        )),
    }
}

/// The refusal of one write, or nothing: the model read an edit of Tama's
/// source as narrowing what a gate judges.
pub fn check(payload: &Value) -> Option<String> {
    let call = Call::of(payload);
    let input = call.input()?;
    let texts = match path_texts(input, call.session_cwd()) {
        Ok(texts) => texts,
        Err(error) => {
            return Some(format!(
                "{TAG}: the write cannot be read to judge it: {error}"
            ))
        }
    };
    let roots = match roots() {
        Ok(roots) => roots,
        Err(cause) => {
            return Some(format!(
                "{TAG}: whether the write is Tama's source cannot be told: {cause}"
            ))
        }
    };
    for (path, after) in texts {
        if !roots.iter().any(|root| Path::new(&path).starts_with(root)) {
            continue;
        }
        let before = match before(&path) {
            Ok(before) => before,
            Err(refusal) => return Some(refusal),
        };
        if before == after {
            continue;
        }
        let prompt = PROMPT
            .replace("{path}", &path)
            .replace("{before}", &before)
            .replace("{after}", &after);
        let judged = match model_judgement::choose(&prompt, JUDGEMENT, &[PASS, BLOCK]) {
            Ok(judged) => judged,
            Err(unanswered) => match model_judgement::unanswered::refusal(TAG, &unanswered, None) {
                Some(refusal) => return Some(format!("{refusal} (judging {path})")),
                None => continue,
            },
        };
        if judged.choice == BLOCK {
            log(&judged.reason);
            return Some(format!(
                "{TAG}: BLOCKED: {path}: {}\n  The operator: \"{ORDER}\"\n  Remove the violation the gate names \
                 instead of narrowing the gate.",
                judged.reason
            ));
        }
    }
    None
}

pub fn run() {
    let payload = read_payload();
    if let Some(refusal) = check(&payload) {
        deny_tool_use(&refusal);
    }
}
