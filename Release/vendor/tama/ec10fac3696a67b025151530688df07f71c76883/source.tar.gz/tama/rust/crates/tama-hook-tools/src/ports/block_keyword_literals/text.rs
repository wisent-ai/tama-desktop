//! Which file the guard reads at all, and what it reads of it: comments
//! become blanks, quoted text is left alone, borrowed code is skipped.
//!
//! Split out of `block_keyword_literals/mod.rs`, which had grown past the
//! three-hundred-line limit; the scanning itself is in `scan.rs`.

use super::super::check_numeric_literals_scan as scan;

/// Code that came from somewhere else. A vendored library, an installed
/// dependency, a package manager's checkout or a minified bundle is not
/// ours to name words in, and refusing a write to one would only teach the
/// writer to work around the guard. `weles/vendor/axe-core/axe.min.js`
/// alone accounted for six of the findings this guard reported, none of
/// them anything anybody here could fix.
pub(super) fn came_from_elsewhere(path: &str) -> bool {
    let borrowed = [
        "/vendor/",
        "/node_modules/",
        "/third_party/",
        "/third-party/",
        "/.build/checkouts/",
        "/site-packages/",
        "/dist/",
    ];
    let normalised = format!("/{}", path.trim_start_matches('/'));
    borrowed.iter().any(|part| normalised.contains(part)) || path.ends_with(".min.js")
}

/// A site repository's documentation corpus: prose held as data, whose
/// table cells and page properties are quoted strings side by side. A row
/// of three cells reads as a run of words, but nothing matches input
/// against it: it is rendered, not consulted.
const PUBLIC_SITE_MARKER: &str = "-landing/";
const DOCUMENTATION_SEGMENT: &str = "/docs/";

pub(super) fn is_documentation(path: &str) -> bool {
    let normalised = format!("/{}", path.trim_start_matches('/'));
    normalised
        .split_once(PUBLIC_SITE_MARKER)
        .is_some_and(|(_, inside)| format!("/{inside}").contains(DOCUMENTATION_SEGMENT))
}

/// One file's text, read the way the guard reads it: a data file whole,
/// code with its comments blanked, and nothing at all for a path the guard
/// does not judge.
pub fn judged_text(path: &str, text: &str) -> Option<String> {
    if came_from_elsewhere(path) || is_documentation(path) {
        return None;
    }
    if super::data::is_data(path) {
        return Some(text.to_owned());
    }
    let lang = scan::lang_for(path)?;
    Some(without_comments(text, &lang))
}

/// Comments become spaces, newlines kept, so a list quoted in a doc comment
/// is a report about a classifier, not one, and line numbers stay true.
/// Quoted text is left alone: that is where a regex alternation lives.
pub(super) fn without_comments(text: &str, lang: &str) -> String {
    let hash_languages = matches!(lang, "py" | "sh" | "rb" | "toml" | "yaml" | "yml");
    let mut chars = text.chars().peekable();
    let mut out = String::with_capacity(text.len());
    let mut quote: Option<char> = None;
    while let Some(ch) = chars.next() {
        if let Some(open) = quote {
            out.push(ch);
            if ch == '\\' {
                if let Some(escaped) = chars.next() {
                    out.push(escaped);
                }
            } else if ch == open {
                quote = None;
            }
            continue;
        }
        if ch == '"' || ch == '\'' {
            quote = Some(ch);
            out.push(ch);
            continue;
        }
        let line_comment = if hash_languages {
            ch == '#'
        } else {
            ch == '/' && chars.peek() == Some(&'/')
        };
        if line_comment {
            out.push(' ');
            while chars.peek().is_some_and(|next| *next != '\n') {
                chars.next();
                out.push(' ');
            }
            continue;
        }
        if !hash_languages && ch == '/' && chars.peek() == Some(&'*') {
            out.push(' ');
            chars.next();
            out.push(' ');
            while let Some(inner) = chars.next() {
                if inner == '*' && chars.peek() == Some(&'/') {
                    chars.next();
                    out.push(' ');
                    out.push(' ');
                    break;
                }
                out.push(if inner == '\n' { '\n' } else { ' ' });
            }
            continue;
        }
        out.push(ch);
    }
    out
}
