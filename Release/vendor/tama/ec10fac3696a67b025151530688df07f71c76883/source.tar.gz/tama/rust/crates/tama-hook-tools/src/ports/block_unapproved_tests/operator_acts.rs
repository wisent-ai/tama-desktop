//! Commands that record the operator's own decision and run only in his
//! terminal. A session that runs one grants itself what only he may grant.
//!
//!   * `tama tests approve` — his approval of test code — and `tama tests
//!     restore`, which writes his record of approvals again, in either form
//!     (`tama request tests/approve|restore` is the same act);
//!   * `oko [transcripts] tasks close` — his own "done" for a task, the way a
//!     task closes without the judge or Brama;
//!   * any `oko` command given `--by operator` — a verdict, a relation, a
//!     message's reading or any other record in his name. Naming every verb
//!     that takes `--by` would let the next one through, as `oko tasks relate
//!     … --by operator` would sign a session's relation as his.
//!
//! Oko confirms the operator's own acts on the terminal they run from; this
//! refusal covers the session that would give itself a terminal to answer on.

use std::sync::LazyLock;

use regex::Regex;

use crate::ports::transport_common as common;

/// Where a program name starts in a shell command: the command's start, a
/// separator, a path's last slash, or a quote closing a quoted path.
const START: &str = r#"(^|[;&|`(\s/'"])"#;

/// One operator act: how it is reached and what the refusal says.
struct Act {
    shape: LazyLock<Regex>,
    says: &'static str,
}

static APPROVE_TESTS: Act = Act {
    shape: LazyLock::new(|| {
        common::compile(&format!(
            r#"{START}tama['"]?\s+(tests\s+|request\s+['"]?tests/)(approve|restore)\b"#
        ))
    }),
    says: "`tama tests approve` and `tama tests restore` (and their `tama request tests/…` \
           forms) write the operator's own record of approved test code",
};

static CLOSE_TASK: Act = Act {
    shape: LazyLock::new(|| {
        common::compile(&format!(r#"{START}oko(-cli)?['"]?\s+tasks\s+close\b"#))
    }),
    says: "`oko tasks close` records the operator's own decision that a task is done",
};

static SIGNED_AS_OPERATOR: Act = Act {
    shape: LazyLock::new(|| {
        common::compile(&format!(
            r#"{START}oko(-cli)?['"]?\s+[^;&|]*--by[\s=]+['"]?operator\b"#
        ))
    }),
    says: "an `oko` command given `--by operator` records its act in the operator's name",
};

/// Why `command`, run from a session, would act as the operator, if it would.
pub fn refusal(hook: &str, command: &str) -> Option<String> {
    [&APPROVE_TESTS, &CLOSE_TASK, &SIGNED_AS_OPERATOR]
        .into_iter()
        .find(|act| act.shape.is_match(command))
        .map(|act| {
            format!(
                "{hook}: BLOCKED: {} and runs only in his own terminal, never from a session. \
             Say in the answer what is ready for him to decide.",
                act.says
            )
        })
}
