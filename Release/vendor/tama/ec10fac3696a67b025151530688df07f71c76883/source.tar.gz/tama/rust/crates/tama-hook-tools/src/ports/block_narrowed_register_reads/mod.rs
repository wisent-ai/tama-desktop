//! Decision half of `tama hook block-narrowed-register-reads` (hook id
//! `block-narrowed-register-reads`): the open work an agent is asked to
//! check is the whole register, so a read of it is never narrowed to a
//! window or a count nobody asked for. `reads.json` beside this file
//! declares each register read (`oko tasks --open`, `oko tasks owed`, `oko
//! defects list`, `oko work next`) and the options that narrow it (`--hours`,
//! `--limit`), with the operator's sentence the rule stands on.
//!
//! A shell line is read by the words it runs
//! ([`crate::ports::block_reserved_changes::command_starts`]); an option
//! counts as `--hours N` and as `--hours=N`. When the operator himself asked
//! for the narrower set, he grants that exact command with `tama justify
//! record --kind narrowed-read` ([`crate::ports::operator_grant`]). No model,
//! no network, no lock; a declaration that cannot be read refuses nothing
//! and says so.

use std::sync::LazyLock;

use serde::Deserialize;
use serde_json::Value;

use crate::ports::block_reserved_changes::{command_starts, runs};
use crate::ports::operator_grant::{self, Request};
use crate::ports::tool_vocabulary::Call;

pub const HOOK_ID: &str = "block-narrowed-register-reads";
pub const GRANT_KIND: &str = "narrowed-read";

#[derive(Deserialize)]
struct Read {
    command: Vec<String>,
    narrowing: Vec<String>,
}

#[derive(Deserialize)]
struct Reads {
    said: String,
    reads: Vec<Read>,
}

static READS: LazyLock<Result<Reads, String>> = LazyLock::new(|| {
    serde_json::from_str(include_str!("reads.json"))
        .map_err(|error| format!("{HOOK_ID}: reads.json cannot be read: {error}"))
});

/// Whether `arg` is the option `flag`, alone or with its value joined by `=`.
fn is_option(arg: &str, flag: &str) -> bool {
    arg == flag
        || arg
            .strip_prefix(flag)
            .is_some_and(|rest| rest.starts_with('='))
}

/// The refusal for the shell call in `payload`, `None` when it narrows no
/// register read or the operator granted exactly this command.
pub fn evaluate(payload: &Value) -> Option<String> {
    let reads = match &*READS {
        Ok(reads) => reads,
        Err(cause) => {
            eprintln!("{cause}; nothing is refused");
            return None;
        }
    };
    let call = Call::of(payload);
    if !call.is_shell() {
        return None;
    }
    let command = call.command()?;
    let mut found = Vec::new();
    for start in command_starts(payload, command) {
        for read in reads
            .reads
            .iter()
            .filter(|read| runs(&read.command, &start))
        {
            for flag in &read.narrowing {
                if start.iter().any(|arg| is_option(arg, flag)) {
                    found.push(format!("`{}` narrowed by `{flag}`", read.command.join(" ")));
                }
            }
        }
    }
    if found.is_empty() {
        return None;
    }
    let request = Request {
        gate: HOOK_ID,
        command: Some(command),
        paths: &[],
    };
    if operator_grant::granted(payload, &request) {
        return None;
    }
    Some(format!(
        "BLOCKED ({HOOK_ID}): {}. The work to check is the whole register, every session's, as it \
         was asked; read it without the narrowing option (the operator: \"{}\"). {}",
        found.join("; "),
        reads.said,
        operator_grant::how_to_grant(GRANT_KIND, HOOK_ID)
    ))
}
