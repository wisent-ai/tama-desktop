//! The Cargo side of packaging: which binary targets the workspace declares,
//! building the selected ones, and where each artifact landed.

use std::collections::BTreeMap;
use std::path::{Path, PathBuf};
use std::process::Command;

use serde_json::{json, Value};

/// One binary target: its name, its package and its source file.
pub(super) struct Target {
    pub name: String,
    pub package: String,
    pub source: String,
}

pub(super) fn metadata(cargo: &Path, source_root: &Path) -> Result<Value, String> {
    let manifest = source_root.join("rust/Cargo.toml");
    let mut command = Command::new(cargo);
    command
        .args([
            "metadata",
            "--format-version",
            "1",
            "--no-deps",
            "--manifest-path",
        ])
        .arg(&manifest);
    let output = stado_wait::output(&mut command)
        .map_err(|error| format!("cannot run {}: {error}", cargo.display()))?;
    if !output.status.success() {
        return Err(format!(
            "Cargo metadata exited {}: {}",
            output.status,
            diagnostic(&output.stderr, &output.stdout)
        ));
    }
    let metadata: Value = serde_json::from_slice(&output.stdout)
        .map_err(|error| format!("Cargo metadata returned invalid JSON: {error}"))?;
    if !metadata.is_object() {
        return Err("Cargo metadata did not return an object".to_string());
    }
    Ok(metadata)
}

/// The text `field` of a Cargo metadata `record`, or an error naming the
/// field and `what` lacks it: an empty name or path in its place would build
/// from the wrong folder or package a binary with no source.
fn text_of<'a>(record: &'a Value, field: &str, what: &str) -> Result<&'a str, String> {
    record[field]
        .as_str()
        .ok_or_else(|| format!("Cargo metadata's {what} carries no text {field}"))
}

fn diagnostic(first: &[u8], second: &[u8]) -> String {
    let joined = [first, second]
        .iter()
        .map(|part| String::from_utf8_lossy(part).trim().to_string())
        .filter(|part| !part.is_empty())
        .collect::<Vec<_>>()
        .join("\n");
    if joined.is_empty() {
        "no diagnostic".to_string()
    } else {
        joined
    }
}

/// Every binary target by name; a name two packages declare is refused.
pub(super) fn binary_targets(metadata: &Value) -> Result<BTreeMap<String, Target>, String> {
    let mut targets = BTreeMap::new();
    let mut duplicates = Vec::new();
    for package in metadata["packages"].as_array().into_iter().flatten() {
        let package_name = text_of(package, "name", "package")?;
        for target in package["targets"].as_array().into_iter().flatten() {
            let is_bin = target["kind"]
                .as_array()
                .is_some_and(|kinds| kinds.iter().any(|kind| kind == "bin"));
            let Some(name) = target["name"].as_str().filter(|_| is_bin) else {
                continue;
            };
            if targets.contains_key(name) {
                duplicates.push(name.to_string());
                continue;
            }
            targets.insert(
                name.to_string(),
                Target {
                    name: name.to_string(),
                    package: package_name.to_string(),
                    source: text_of(target, "src_path", "binary target")?.to_string(),
                },
            );
        }
    }
    if !duplicates.is_empty() {
        duplicates.sort();
        return Err(format!(
            "Cargo workspace has ambiguous binary targets: {}",
            duplicates.join(", ")
        ));
    }
    Ok(targets)
}

/// Build the selected targets in release mode, one invocation per package,
/// and return where Cargo wrote each executable.
pub(super) fn build(
    cargo: &Path,
    metadata: &Value,
    selected: &[&Target],
) -> Result<BTreeMap<String, PathBuf>, String> {
    let workspace = PathBuf::from(text_of(metadata, "workspace_root", "workspace")?);
    let target_directory = PathBuf::from(text_of(metadata, "target_directory", "workspace")?);
    let mut by_package: BTreeMap<&str, Vec<&str>> = BTreeMap::new();
    for target in selected {
        by_package
            .entry(&target.package)
            .or_default()
            .push(&target.name);
    }
    let mut artifacts = BTreeMap::new();
    for (package, mut names) in by_package {
        names.sort();
        let mut command = Command::new(cargo);
        command
            .args(["build", "--release", "--manifest-path"])
            .arg(workspace.join("Cargo.toml"))
            .args([
                "--package",
                package,
                "--message-format=json-render-diagnostics",
            ]);
        for name in &names {
            command.args(["--bin", name]);
        }
        let output = stado_wait::output(&mut command)
            .map_err(|error| format!("cannot run {}: {error}", cargo.display()))?;
        let stdout = String::from_utf8_lossy(&output.stdout);
        let messages = tama_hooks::jsonl::records(&stdout)
            .map_err(|cause| {
                format!(
                    "Cargo build for {package} exited {} and printed a line that is no JSON \
                     message ({cause}): {}",
                    output.status,
                    diagnostic(&output.stderr, stdout.as_bytes())
                )
            })?
            .values;
        if !output.status.success() {
            let rendered = messages
                .iter()
                .filter(|item| item["reason"] == "compiler-message")
                .filter_map(|item| item["message"]["rendered"].as_str())
                .collect::<Vec<_>>()
                .join("\n");
            return Err(format!(
                "Cargo build for {package} exited {}: {}",
                output.status,
                diagnostic(&output.stderr, rendered.as_bytes())
            ));
        }
        for item in messages
            .iter()
            .filter(|item| item["reason"] == "compiler-artifact")
        {
            let (Some(name), Some(executable)) =
                (item["target"]["name"].as_str(), item["executable"].as_str())
            else {
                continue;
            };
            if !names.contains(&name) {
                continue;
            }
            let artifact = PathBuf::from(executable);
            if !artifact.starts_with(&target_directory) {
                return Err(format!(
                    "Cargo emitted {name} outside its metadata target directory"
                ));
            }
            artifacts.insert(name.to_string(), artifact);
        }
    }
    let missing: Vec<&str> = selected
        .iter()
        .map(|target| target.name.as_str())
        .filter(|name| !artifacts.contains_key(*name))
        .collect();
    if !missing.is_empty() {
        return Err(format!(
            "Cargo did not emit requested binaries: {}",
            missing.join(", ")
        ));
    }
    Ok(artifacts)
}

/// The manifest line for one target, its source relative to the workspace.
/// Cargo's metadata names every target of the workspace inside it, so a
/// source outside it is a metadata answer this packaging cannot describe.
pub(super) fn manifest_entry(target: &Target, workspace: &Path) -> Result<Value, String> {
    let relative = Path::new(&target.source)
        .strip_prefix(workspace)
        .map_err(|_| {
            format!(
                "the source {} of target {} is not inside the workspace {} cargo metadata names",
                target.source,
                target.name,
                workspace.display()
            )
        })?;
    Ok(json!({
        "name": target.name,
        "package": target.package,
        "source": relative.to_string_lossy(),
    }))
}
