//! Commands that write hook configuration without ever naming a protected
//! path.
//!
//! The gate beside this file decides by reading text: a protected path plus
//! something that looks like a write. A tool whose whole job is to write hook
//! configuration passes both halves unnoticed — the path is inside the tool,
//! and running a program is not a redirect or a copy. A
//! `tama hook generate-configs --apply` from inside an agent session
//! rewrites the machine's Claude and Codex hook configurations without
//! consent, and the text test sees nothing to refuse.
//!
//! So the writers are named here. A tool that only reports — `--check`,
//! `--preview`, a `generate-configs` run without `--apply`, `enforcement
//! status` — writes nothing and stays allowed, because a guard that refuses
//! reads teaches people to stop reading.

use crate::ports::python_stdlib::shell_tokens;
use crate::ports::shell_text;

use super::tables::{
    ALWAYS, APPLY_FLAG, CHECK_FLAG, ENFORCEMENT_READS, ENFORCEMENT_WORD, HOOKS_WORD, INSTALL_WORD,
    OKO_HOOKS_REASON, OKO_HOOK_WRITES, OKO_PROGRAM, PREVIEW_FLAG, TAMA_ENFORCEMENT_REASON,
    TAMA_INSTALL_REASON, TAMA_PROGRAM, UNLESS_CHECK, WHEN_APPLY,
};

/// The one `tama install` verb that only reads: `tama install plan` shows
/// the runtime scopes and target paths and creates no directory, writes no
/// configuration and activates no hook (its canonical reference says so).
/// Any other word after `install` is the installer, which writes the
/// machine's dispatchers, so a verb this file has never heard of is a write.
const INSTALL_READ: &str = "plan";

/// Whether the `tama install` in `words` is the read-only plan: the word
/// right after `install` is the verb, as the CLI reads it.
fn install_only_reads(words: &[&str]) -> bool {
    let mut after_install = words.iter().skip_while(|word| **word != INSTALL_WORD);
    let install = after_install.next();
    let verb = after_install.next();
    install.is_some() && verb.is_some_and(|verb| *verb == INSTALL_READ)
}

/// Does a command word of this call name the needle? A sentence handed to a
/// tool — an evidence message, a commit body — survives tokenizing as one
/// token with spaces in it, and naming a writer inside a sentence runs
/// nothing.
fn mentions(tokens: &[String], needle: &str) -> bool {
    tokens
        .iter()
        .any(|token| shell_text::command_word(token) && token.contains(needle))
}

fn flagged(tokens: &[String], flag: &str) -> bool {
    tokens.iter().any(|token| token == flag)
}

/// `tama … install`, `tama … enforcement only|all`, `oko hooks
/// install|pull` — a subcommand rather than a file name, so it is read from
/// the program this command starts and the words it passes that program. An
/// interpreter never runs `tama` as a script argument, so reading the
/// program position here costs nothing and keeps a sentence that names the
/// command from counting as running it.
fn subcommand_writer(tokens: &[String]) -> Option<&'static str> {
    let name = shell_text::program(tokens)?;
    let words: Vec<&str> = tokens
        .iter()
        .filter(|token| shell_text::command_word(token))
        .map(String::as_str)
        .collect();
    if name == TAMA_PROGRAM {
        if words.contains(&INSTALL_WORD) && !install_only_reads(&words) {
            return Some(TAMA_INSTALL_REASON);
        }
        if words.contains(&ENFORCEMENT_WORD)
            && !words.iter().any(|word| ENFORCEMENT_READS.contains(word))
        {
            return Some(TAMA_ENFORCEMENT_REASON);
        }
    }
    if name == OKO_PROGRAM
        && words.contains(&HOOKS_WORD)
        && words.iter().any(|word| OKO_HOOK_WRITES.contains(word))
        && !flagged(tokens, PREVIEW_FLAG)
    {
        return Some(OKO_HOOKS_REASON);
    }
    None
}

/// Which hook-configuration writer one command runs, if it runs one.
fn command_writer(tokens: &[String]) -> Option<&'static str> {
    for (needle, reason) in ALWAYS {
        if mentions(tokens, needle) {
            return Some(reason);
        }
    }
    for (needle, reason) in UNLESS_CHECK {
        if mentions(tokens, needle) && !flagged(tokens, CHECK_FLAG) {
            return Some(reason);
        }
    }
    for (needle, reason) in WHEN_APPLY {
        if mentions(tokens, needle) && flagged(tokens, APPLY_FLAG) {
            return Some(reason);
        }
    }
    subcommand_writer(tokens)
}

/// Which hook-configuration writer this payload runs, if it runs one.
///
/// The cut into commands is quote-aware, so a separator inside a quoted
/// argument stays part of that argument, and an executor's quoted program is
/// read as a command in its own right.
pub(crate) fn runs_hook_config_writer(text: &str) -> Option<&'static str> {
    for segment in shell_text::commands(text) {
        let tokens = shell_tokens(segment);
        if tokens.is_empty() {
            continue;
        }
        if let Some(reason) = command_writer(&tokens) {
            return Some(reason);
        }
        if let Some(inner) = shell_text::inner_command(&tokens) {
            if let Some(reason) = runs_hook_config_writer(&inner) {
                return Some(reason);
            }
        }
    }
    None
}
