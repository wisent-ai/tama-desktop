//! Reading a segment back and deciding whether it is intact: the header,
//! the frames, the footer's digest, and the acknowledgement beside it.
//! Every refusal names the file and the check it failed.
//!
//! Split out of `segments/index.rs`, which had grown past the
//! three-hundred-line limit; writing segments stays there.

use std::fs;
use std::path::Path;

use serde_json::Value;

use super::{
    ack_name, digest_bytes, is_hex_64, parse_object, segment_name, ValidSegment, ACK_PROTOCOL,
    PROTOCOL,
};

/// The non-empty string `object` holds under `key`, or what is wrong.
fn text<'a>(object: &'a Value, key: &str, part: &str) -> Result<&'a str, String> {
    match object.get(key).and_then(Value::as_str) {
        Some(text) if !text.is_empty() => Ok(text),
        _ => Err(format!("its {part} names no {key}")),
    }
}

/// That `object` holds `expected` under `key`.
fn holds(object: &Value, key: &str, expected: &str, part: &str) -> Result<(), String> {
    match object.get(key) {
        Some(Value::String(found)) if found == expected => Ok(()),
        Some(found) => Err(format!("its {part} {key} is {found}, not {expected:?}")),
        None => Err(format!(
            "its {part} has no {key}, which must be {expected:?}"
        )),
    }
}

/// The whole milliseconds `object` holds under `key`.
fn millis(object: &Value, key: &str, part: &str) -> Result<i64, String> {
    object
        .get(key)
        .and_then(Value::as_i64)
        .ok_or_else(|| format!("its {part} has no {key} in whole milliseconds"))
}

/// That `object` holds the count `expected` under `key`.
fn count(object: &Value, key: &str, expected: usize, part: &str) -> Result<(), String> {
    let counted = object.get(key).and_then(Value::as_u64).map(usize::try_from);
    match (counted, object.get(key)) {
        (Some(Ok(found)), _) if found == expected => Ok(()),
        (_, Some(found)) => Err(format!("its {part} {key} is {found}, not {expected}")),
        (_, None) => Err(format!("its {part} has no {key}, which must be {expected}")),
    }
}

/// `validateSegment(path)`: header, frames and footer, and the footer's
/// payload digest, or the check the segment failed.
pub fn validate_segment(path: &Path) -> Result<ValidSegment, String> {
    let shown = path.display();
    let source = fs::read_to_string(path)
        .map_err(|error| format!("the segment {shown} cannot be read: {error}"))?;
    check_segment(path, &source)
        .map_err(|cause| format!("the segment {shown} is not intact: {cause}"))
}

fn check_segment(path: &Path, source: &str) -> Result<ValidSegment, String> {
    let body = source
        .strip_suffix('\n')
        .ok_or("its last row is not terminated by a newline")?;
    let rows: Vec<&str> = body.split('\n').collect();
    let [header_row, frames @ .., footer_row] = rows.as_slice() else {
        return Err("it holds no header and footer pair".to_string());
    };
    let header = parse_object(header_row, "header")?;
    let footer = parse_object(footer_row, "footer")?;
    holds(&header, "kind", "segment_open", "header")?;
    holds(&header, "protocol", PROTOCOL, "header")?;
    let segment_id = text(&header, "segmentId", "header")?.to_string();
    let base = path.file_name().map(|name| name.to_string_lossy());
    if base.as_deref() != Some(segment_name(&segment_id).as_str()) {
        return Err(format!(
            "its file name is not {}",
            segment_name(&segment_id)
        ));
    }
    text(&header, "producerId", "header")?;
    text(&header, "invocationId", "header")?;
    let created_at = millis(&header, "createdAt", "header")?;
    let producer = header.get("source").ok_or("its header names no source")?;
    holds(producer, "producer", "tama", "header source")?;
    let mut events = Vec::new();
    for row in frames {
        let frame = parse_object(row, "event frame")?;
        holds(&frame, "kind", "event", "event frame")?;
        count(&frame, "sequence", events.len(), "event frame")?;
        match frame.get("event") {
            Some(event) if event.is_object() => events.push(event.clone()),
            _ => {
                return Err(format!(
                    "its event frame {} holds no event object",
                    events.len()
                ))
            }
        }
    }
    let mut payload = String::new();
    for row in std::iter::once(header_row).chain(frames) {
        payload.push_str(row);
        payload.push('\n');
    }
    let payload_sha256 = digest_bytes(payload.as_bytes());
    holds(&footer, "kind", "segment_close", "footer")?;
    holds(&footer, "protocol", PROTOCOL, "footer")?;
    holds(&footer, "segmentId", &segment_id, "footer")?;
    count(&footer, "eventCount", events.len(), "footer")?;
    holds(&footer, "payloadSha256", &payload_sha256, "footer")?;
    millis(&footer, "closedAt", "footer")?;
    Ok(ValidSegment {
        segment_id,
        created_at,
        event_count: events.len(),
        payload_sha256,
        source_sha256: digest_bytes(source.as_bytes()),
        source_size: source.len(),
        events,
    })
}

/// `validateAck(path, segment)`: none while the lake has not acknowledged
/// the segment, the acknowledgement when it proves the segment kept, or
/// the check it failed.
pub(super) fn validate_ack(path: &Path, segment: &ValidSegment) -> Result<Option<Value>, String> {
    let shown = path.display();
    let source = match fs::read_to_string(path) {
        Ok(source) => source,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(None),
        Err(error) => {
            return Err(format!(
                "the acknowledgement {shown} cannot be read: {error}"
            ))
        }
    };
    check_ack(path, &source, segment)
        .map(Some)
        .map_err(|cause| format!("the acknowledgement {shown} does not prove its segment: {cause}"))
}

fn check_ack(path: &Path, source: &str, segment: &ValidSegment) -> Result<Value, String> {
    let ack = parse_object(source, "body")?;
    let base = path.file_name().map(|name| name.to_string_lossy());
    if base.as_deref() != Some(ack_name(&segment.segment_id).as_str()) {
        return Err(format!(
            "its file name is not {}",
            ack_name(&segment.segment_id)
        ));
    }
    holds(&ack, "protocol", ACK_PROTOCOL, "body")?;
    holds(&ack, "segmentId", &segment.segment_id, "body")?;
    holds(&ack, "sourceSha256", &segment.source_sha256, "body")?;
    count(&ack, "sourceSize", segment.source_size, "body")?;
    count(&ack, "eventCount", segment.event_count, "body")?;
    holds(&ack, "payloadSha256", &segment.payload_sha256, "body")?;
    text(&ack, "lakeCommitId", "body")?;
    let outputs = match ack.get("outputs").and_then(Value::as_array) {
        Some(outputs) if !outputs.is_empty() => outputs,
        _ => return Err("it lists no outputs".to_string()),
    };
    for output in outputs {
        let output_path = text(output, "path", "output")?;
        let digest = text(output, "sha256", "output")?;
        if !is_hex_64(digest) {
            return Err(format!(
                "the digest of its output {output_path} is not a SHA-256"
            ));
        }
        let meta = fs::symlink_metadata(output_path)
            .map_err(|error| format!("its output {output_path} cannot be examined: {error}"))?;
        if !meta.is_file() {
            return Err(format!("its output {output_path} is not a regular file"));
        }
        let bytes = fs::read(output_path)
            .map_err(|error| format!("its output {output_path} cannot be read: {error}"))?;
        if digest_bytes(&bytes) != digest {
            return Err(format!(
                "its output {output_path} no longer has the digest it names"
            ));
        }
    }
    Ok(ack)
}

/// `decisionsPersisted(segment)`: every decision the segment carries was
/// kept in the adaptive state.
pub(super) fn decisions_persisted(segment: &ValidSegment) -> bool {
    segment.events.iter().all(|event| {
        event.get("type").and_then(Value::as_str) != Some("decision")
            || event.get("adaptiveStatePersisted").and_then(Value::as_bool) == Some(true)
    })
}
