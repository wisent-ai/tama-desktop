//! Detection half of the `shared-hooks/block_unauthorized_cua.py` port (hook
//! id `block-unauthorized-cua`): the patterns, `cua_action` and
//! `is_cua_operation`. Split from
//! [`crate::ports::block_unauthorized_cua`] to stay inside the 300-line limit.
//!
//! Python `re.I` becomes the inline `(?i)` flag. No pattern here needs
//! lookaround, so every pattern text is the Python text.

use std::sync::LazyLock;

use regex::Regex;
use serde_json::Value;

use crate::ports::tool_vocabulary::{Call, WHOLE_FILE_TOOLS};
use crate::ports::transport_common as common;

/// The REPL device a whole-file write to runs the written script.
const NODE_REPL_DEVICE: &str = "xd://mcp__node_repl_js";

/// The computer-use tool's names: the `cua` driver and the generic
/// `computer use` in any of its separators. These are the tool's identity,
/// as its tool and device names carry it.
const CUA_NAME: &str = "cua";
const COMPUTER_USE_NAME: &str = "computer[ _-]?use";
/// The driver's own command-line program.
const CUA_DRIVER: &str = "cua-driver";

fn cua_names() -> String {
    format!("(?:{CUA_NAME}|{COMPUTER_USE_NAME})")
}

/// `CUA_TOOL_RE`. Python's `$` also matches before one trailing newline and
/// the sibling branch `[._-]` cannot, so the alternative is spelled `\n?\z`.
fn tool_pattern() -> String {
    format!(r"(?i)(?:^|[._-]){}(?:[._-]|\n?\z)", cua_names())
}

fn cli_pattern() -> String {
    format!(r"(?i)(?:^|[/\s;&|]){CUA_DRIVER}\s+([a-z][a-z0-9_-]*)")
}

/// `CUA_DIRECT_TOOL_ACTION_RE`, with the same trailing-newline spelling. The
/// capture is unaffected: `[a-z0-9_-]*` is greedy and cannot match `\n`, so
/// the newline always falls to `\n?`.
fn direct_action_pattern() -> String {
    format!(r"(?i){}.*?__([a-z][a-z0-9_-]*)\n?\z", cua_names())
}

static CUA_TOOL_RE: LazyLock<Regex> = LazyLock::new(|| common::compile(&tool_pattern()));
static CUA_CLI_RE: LazyLock<Regex> = LazyLock::new(|| common::compile(&cli_pattern()));
static CUA_DIRECT_TOOL_ACTION_RE: LazyLock<Regex> =
    LazyLock::new(|| common::compile(&direct_action_pattern()));
pub static PID_RE: LazyLock<Regex> =
    LazyLock::new(|| common::compile("(?:\"pid\"\\s*:\\s*|--pid(?:=|\\s+))(\\d+)"));

/// `re.match(r"^xd://(?:mcp__)?(?:cua|computer[ _-]?use)", path, re.I)`:
/// `re.match` anchors at the start only, which `\A` states explicitly.
static XD_CUA_PATH_RE: LazyLock<Regex> =
    LazyLock::new(|| common::compile(&format!(r"(?i)\Axd://(?:mcp__)?{}", cua_names())));

/// The tool's name as the payload spells it, empty when it names none.
pub fn tool_name(payload: &Value) -> String {
    match Call::of(payload).name() {
        Some(name) => name.to_string(),
        None => String::new(),
    }
}

/// `match.group(1).replace("-", "_").lower()`.
fn captured_action(pattern: &Regex, text: &str) -> Option<String> {
    let captures = pattern.captures(text)?;
    let captured = common::first_group(&captures)?;
    Some(captured.as_str().replace('-', "_").to_lowercase())
}

/// `cua_action`: the action this call would drive — from the tool name, from
/// a device path, or from a `cua-driver <action>` command line.
pub fn cua_action(payload: &Value) -> Option<String> {
    let call = Call::of(payload);
    if let Some(action) = call
        .name()
        .and_then(|name| captured_action(&CUA_DIRECT_TOOL_ACTION_RE, name))
    {
        return Some(action);
    }
    if let Some(action) = call
        .path()
        .and_then(|path| captured_action(&CUA_DIRECT_TOOL_ACTION_RE, path))
    {
        return Some(action);
    }
    let input = call.input()?;
    captured_action(
        &CUA_CLI_RE,
        &format!(" {}", executed(payload, input, writes_repl(&call))),
    )
}

/// Whether the call writes a script to the REPL device, which runs it.
fn writes_repl(call: &Call) -> bool {
    call.is_one_of(WHOLE_FILE_TOOLS)
        && call
            .path()
            .is_some_and(|text| text.to_lowercase().starts_with(NODE_REPL_DEVICE))
}

/// The text of `input` that runs: for a call that runs a shell line or a
/// program, the command words `shell_text::effective_payload` keeps, so a
/// driver name inside a quoted argument of another program (a consent
/// sentence handed to `tama justify`, a commit message) is data and not a
/// driver call; for a script written to the REPL device, the script whole,
/// where the driver is started by name from code.
fn executed(payload: &Value, input: &Value, repl_script: bool) -> String {
    let text = common::strings(input).join("\n");
    if repl_script {
        text
    } else {
        crate::ports::shell_text::effective_payload(payload, &text)
    }
}

/// `is_cua_operation`: a direct CUA tool, a CUA device path, or a call that
/// runs something — a shell line, a program, a started process, or a script
/// written to the REPL device — carrying a `cua-driver` command line.
pub fn is_cua_operation(payload: &Value) -> bool {
    let call = Call::of(payload);
    if call.name().is_some_and(|name| CUA_TOOL_RE.is_match(name)) {
        return true;
    }
    let path = call.path();
    if path.is_some_and(|text| XD_CUA_PATH_RE.is_match(text)) {
        return true;
    }
    let repl_script = writes_repl(&call);
    let Some(input) = call.input() else {
        return false;
    };
    (call.runs() || repl_script)
        && CUA_CLI_RE.is_match(&format!(" {}", executed(payload, input, repl_script)))
}
