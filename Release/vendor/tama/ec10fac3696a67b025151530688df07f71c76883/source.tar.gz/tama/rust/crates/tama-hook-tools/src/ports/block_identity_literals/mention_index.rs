//! Per-transcript identity sets shared across hook processes. Only changed
//! transcripts are opened, and of a changed transcript only the records
//! appended since the snapshot was taken (`transcript_tail`); a file lock
//! gives each refresh a single reader.
use super::transcript_tail::{holds, identities_from, Mark};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use stado_wait::{blocking, Kind};
use std::collections::{BTreeMap, BTreeSet};
use std::fs::OpenOptions;
use std::os::unix::fs::MetadataExt;
use std::path::{Path, PathBuf};

#[derive(Serialize, Deserialize, PartialEq, Eq)]
struct Stamp {
    bytes: u64,
    modified_nanos: u128,
    device: u64,
    inode: u64,
    changed_seconds: i64,
    changed_nanos: i64,
}
#[derive(Serialize, Deserialize)]
struct Snapshot {
    stamp: Stamp,
    extractor: String,
    identities: BTreeSet<String>,
    /// How far the snapshot has read: the byte just past its last complete
    /// record. A snapshot written before offsets were kept has none and is
    /// read again from the start.
    consumed: Option<u64>,
    /// The last record it read, which the file must still hold for the
    /// snapshot to be continued instead of read again.
    last: Option<Mark>,
}

/// Where reading continues: the identities already read, the offset after
/// them and the mark of the last record, or nothing of them (from the start).
type Resumed = (BTreeSet<String>, Option<u64>, Option<Mark>);

impl Snapshot {
    /// Past this snapshot's records when `path` (stamped `now`) is the same
    /// file, only appended to since: it still holds the last record read
    /// where it was. Else from the start.
    fn resume(self, path: &Path, now: &Stamp, extractor: &str) -> Result<Resumed, String> {
        let fresh = (BTreeSet::new(), None, None);
        let Some(consumed) = self.consumed else {
            return Ok(fresh);
        };
        if self.extractor != extractor
            || self.stamp.device != now.device
            || self.stamp.inode != now.inode
            || consumed > now.bytes
        {
            return Ok(fresh);
        }
        if let Some(mark) = &self.last {
            if !holds(path, mark, consumed)? {
                return Ok(fresh);
            }
        }
        Ok((self.identities, Some(consumed), self.last))
    }
}

fn stamp(path: &Path) -> Result<Stamp, String> {
    let metadata = std::fs::metadata(path)
        .map_err(|error| format!("cannot inspect transcript {}: {error}", path.display()))?;
    let modified_nanos = metadata
        .modified()
        .map_err(|error| {
            format!(
                "cannot read modification time of {}: {error}",
                path.display()
            )
        })?
        .duration_since(std::time::UNIX_EPOCH)
        .map_err(|error| format!("invalid modification time of {}: {error}", path.display()))?
        .as_nanos();
    Ok(Stamp {
        bytes: metadata.len(),
        modified_nanos,
        device: metadata.dev(),
        inode: metadata.ino(),
        changed_seconds: metadata.ctime(),
        changed_nanos: metadata.ctime_nsec(),
    })
}
fn collect(root: &Path, paths: &mut Vec<PathBuf>) -> Result<(), String> {
    let entries = match std::fs::read_dir(root) {
        Ok(entries) => entries,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(()),
        Err(error) => {
            return Err(format!(
                "cannot list transcript directory {}: {error}",
                root.display()
            ))
        }
    };
    let entries = entries
        .map(|entry| {
            let entry = entry.map_err(|error| {
                format!(
                    "cannot read transcript entry in {}: {error}",
                    root.display()
                )
            })?;
            let path = entry.path();
            let kind = entry.file_type().map_err(|error| {
                format!(
                    "cannot inspect transcript entry {}: {error}",
                    path.display()
                )
            })?;
            Ok((path, kind))
        })
        .collect::<Result<Vec<_>, String>>()?;
    let transcript_stems: BTreeSet<_> = entries
        .iter()
        .filter(|(path, kind)| kind.is_file() && path.extension().is_some_and(|ext| ext == "jsonl"))
        .filter_map(|(path, _)| path.file_stem())
        .collect();
    for (path, kind) in &entries {
        if kind.is_dir() {
            if !path
                .file_name()
                .is_some_and(|name| transcript_stems.contains(name))
            {
                collect(path, paths)?;
            }
        } else if kind.is_file()
            && path
                .extension()
                .is_some_and(|extension| extension == "jsonl")
        {
            paths.push(path.clone());
        }
    }
    Ok(())
}
fn same_file(before: &Stamp, after: &Stamp) -> bool {
    before.device == after.device && before.inode == after.inode && before.bytes <= after.bytes
}
/// The identities the user said in one transcript, from its shared snapshot,
/// reading only what was appended since it was taken.
fn identities_of(path: &Path, root: &Path) -> Result<BTreeSet<String>, String> {
    let key = format!("{:x}", Sha256::digest(path.as_os_str().as_encoded_bytes()));
    let lock_path = root.join(format!("{key}.lock"));
    let lock = OpenOptions::new()
        .create(true)
        .truncate(false)
        .write(true)
        .open(&lock_path)
        .map_err(|error| {
            format!(
                "cannot open transcript index lock {}: {error}",
                lock_path.display()
            )
        })?;
    match lock.try_lock() {
        Ok(()) => {}
        Err(std::fs::TryLockError::WouldBlock) => {
            blocking(
                Kind::Lock,
                "shared transcript identity refresh",
                path.display(),
                || lock.lock(),
            )
            .map_err(|error| {
                format!(
                    "cannot lock transcript index for {}: {error}",
                    path.display()
                )
            })?;
        }
        Err(error) => {
            return Err(format!(
                "cannot inspect transcript index lock for {}: {error}",
                path.display()
            ))
        }
    }
    let before = stamp(path)?;
    let cached = root.join(format!("{key}.json"));
    let extractor = format!(
        "user-message-identities:{}:{}:{}",
        super::EMAIL.as_str(),
        super::UUID.as_str(),
        super::FLAT.as_str()
    );
    let prior = match std::fs::read(&cached) {
        Ok(bytes) => {
            let snapshot: Snapshot = serde_json::from_slice(&bytes).map_err(|error| {
                format!(
                    "cannot decode transcript index {}: {error}",
                    cached.display()
                )
            })?;
            if snapshot.stamp == before && snapshot.extractor == extractor {
                if stamp(path)? != before {
                    return Err(format!(
                        "transcript {} changed while its cached identity set was read",
                        path.display()
                    ));
                }
                return Ok(snapshot.identities);
            }
            Some(snapshot)
        }
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => None,
        Err(error) => {
            return Err(format!(
                "cannot read transcript index {}: {error}",
                cached.display()
            ))
        }
    };
    let (mut identities, from, mut last) = match prior {
        Some(snapshot) => snapshot.resume(path, &before, &extractor)?,
        None => (BTreeSet::new(), None, None),
    };
    let tail = blocking(
        Kind::Process,
        "indexing the records appended to a user transcript",
        path.display(),
        || identities_from(path, from).map_err(std::io::Error::other),
    )
    .map_err(|error| error.to_string())?;
    identities.extend(tail.identities);
    if tail.last.is_some() {
        last = tail.last;
    }
    let after = stamp(path)?;
    if !same_file(&before, &after) {
        return Err(format!(
            "transcript {} was replaced or truncated during identity indexing; no mixed snapshot was published",
            path.display()
        ));
    }
    let snapshot = Snapshot {
        stamp: before,
        extractor,
        identities,
        consumed: Some(tail.consumed),
        last,
    };
    let bytes = serde_json::to_vec(&snapshot)
        .map_err(|error| format!("cannot encode transcript index: {error}"))?;
    let staged = cached.with_extension("staged");
    std::fs::write(&staged, bytes)
        .and_then(|()| std::fs::rename(&staged, &cached))
        .map_err(|error| {
            format!(
                "cannot publish transcript index {}: {error}",
                cached.display()
            )
        })?;
    Ok(snapshot.identities)
}

/// For each of `values` (lowercase), up to two stored transcripts in which
/// the user said it. The stores are walked once for the whole set, each
/// transcript's snapshot read once, and the walk ends as soon as every value
/// has two: a page carrying many identities no longer walks every transcript
/// once per value. A value no transcript holds has no entry; the caller asks
/// only when some value is still unsourced.
pub(super) fn sessions(
    root: &Path,
    values: &BTreeSet<String>,
) -> Result<BTreeMap<String, Vec<PathBuf>>, String> {
    let mut found: BTreeMap<String, Vec<PathBuf>> = BTreeMap::new();
    let mut paths = Vec::new();
    collect(root, &mut paths)?;
    paths.sort();
    let cache = tama_hooks::session_control::tama_state_root().join("identity-mentions");
    std::fs::create_dir_all(&cache).map_err(|error| {
        format!(
            "cannot create transcript identity index {}: {error}",
            cache.display()
        )
    })?;
    for path in paths {
        let settled = values.iter().all(|value| match found.get(value) {
            Some(sessions) => matches!(sessions.as_slice(), [_, _, ..]),
            None => false,
        });
        if settled {
            break;
        }
        let said = identities_of(&path, &cache)?;
        for value in values.iter().filter(|value| said.contains(*value)) {
            let sessions = found.entry(value.clone()).or_default();
            if !matches!(sessions.as_slice(), [_, _, ..]) {
                sessions.push(path.clone());
            }
        }
    }
    Ok(found)
}
