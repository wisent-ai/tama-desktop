//! The sessions that wrote a path together. When another session amended or
//! reformatted a session's hunk, neither session's own edits replay onto the
//! file any more. Staging names those sessions as co-authors (`--with`):
//! their edits of the paths the session itself edited are read into one run
//! with the session's own, in the order the transcripts recorded them, so
//! the file the named sessions left together is staged, and a line no named
//! session wrote still stands nowhere in that run and is refused as before.
//! The authors staged together, with the task a stopped predecessor's work
//! was taken over under (`takeover`), are kept beside the staged index, so
//! the commit check reads the same run for the same session.

use std::collections::BTreeSet;
use std::path::{Path, PathBuf};

use serde::{Deserialize, Serialize};

use super::receipts::{self, Edit};
use super::takeover;

/// The authors staged together into the index this record lies beside, and
/// the task under which a stopped co-author's whole work was taken over.
#[derive(Deserialize, Serialize)]
#[serde(rename_all = "camelCase")]
pub(super) struct Authors {
    pub session: String,
    pub with: Vec<String>,
    pub task: Option<String>,
}

/// Where the authors staged into the index of the staging area `area` are
/// kept: the area every staging of that index shares.
pub(super) fn record_path(area: &Path) -> PathBuf {
    area.join("authors.json")
}

/// The co-authors and taken-over task recorded for `session` beside the
/// index whose staging area is `area`; none when no record names it.
pub(super) fn recorded(
    area: &Path,
    session: &str,
) -> Result<(Vec<String>, Option<String>), String> {
    let path = record_path(area);
    let text = match std::fs::read_to_string(&path) {
        Ok(text) => text,
        Err(cause) if cause.kind() == std::io::ErrorKind::NotFound => {
            return Ok((Vec::new(), None))
        }
        Err(cause) => {
            return Err(format!(
                "cannot read the staged authors {}: {cause}",
                path.display()
            ))
        }
    };
    let authors: Authors = serde_json::from_str(&text).map_err(|cause| {
        format!(
            "the staged authors {} cannot be read: {cause}",
            path.display()
        )
    })?;
    Ok(if authors.session == session {
        (authors.with, authors.task)
    } else {
        (Vec::new(), None)
    })
}

/// Keeps the authors and task a staging of `session` published, or removes
/// the record when it named no co-author.
pub(super) fn keep(
    area: &Path,
    session: &str,
    with: &[String],
    task: Option<&str>,
) -> Result<(), String> {
    let path = record_path(area);
    if with.is_empty() {
        return match std::fs::remove_file(&path) {
            Ok(()) => Ok(()),
            Err(cause) if cause.kind() == std::io::ErrorKind::NotFound => Ok(()),
            Err(cause) => Err(format!(
                "cannot remove the staged authors {}: {cause}",
                path.display()
            )),
        };
    }
    let authors = Authors {
        session: session.to_owned(),
        with: with.to_vec(),
        task: task.map(str::to_owned),
    };
    let text = serde_json::to_string(&authors)
        .map_err(|cause| format!("cannot encode the staged authors: {cause}"))?;
    std::fs::write(&path, text)
        .map_err(|cause| format!("cannot keep the staged authors {}: {cause}", path.display()))
}

/// The session's own edits with every named co-author's edits of the same
/// paths, in the order the transcripts recorded their results. With `task`,
/// a co-author that held the task before the session and no longer runs
/// (`takeover`) contributes every path it edited. A co-author that is the
/// session itself, a task given with no co-author, or an edit whose time was
/// not recorded, refuses: the run's order could not be told.
pub(super) fn merged(
    root: &Path,
    session: &str,
    with: &[String],
    task: Option<&str>,
    own: Vec<Edit>,
) -> Result<Vec<Edit>, String> {
    if with.is_empty() {
        return match task {
            Some(task) => Err(format!(
                "--task {task} names no predecessor: name the session that held it with --with"
            )),
            None => Ok(receipts::resolve(root, own)),
        };
    }
    if let Some(author) = with.iter().find(|author| *author == session) {
        return Err(format!(
            "--with {author} names the session being staged; name the sessions that wrote with it"
        ));
    }
    let predecessors = match task {
        Some(task) => {
            let held = takeover::predecessors(task, session, with)?;
            for author in &held {
                takeover::stopped(author, task)?;
            }
            held
        }
        None => Vec::new(),
    };
    let paths: BTreeSet<PathBuf> = own.iter().map(|edit| edit.path.clone()).collect();
    let mut all = own;
    for author in with {
        let transcript = receipts::transcript(author)?;
        let edits = receipts::read(root, &transcript, Some(author))?;
        let whole = predecessors.contains(author);
        all.extend(
            edits
                .into_iter()
                .filter(|edit| whole || paths.contains(&edit.path)),
        );
    }
    if let Some(untimed) = all.iter().find(|edit| edit.at.is_none()) {
        return Err(format!(
            "edit {} of {} has no recorded time, so it cannot be ordered among its co-authors' edits",
            untimed.call,
            untimed.path.display()
        ));
    }
    all.sort_by(|left, right| left.at.cmp(&right.at));
    Ok(receipts::resolve(root, all))
}
