//! `tama request history/rebase`: `tama history rebase` for Tama Desktop,
//! through the same function and with the same refusals. The request names
//! the checkout (`repository`) and, with `"prefer": "upstream"`, the side
//! kept where Git cannot merge; it answers the document `--json` prints. A
//! request missing its checkout or naming another side is a bad request
//! naming it; a rebase that refuses is a failure with its cause.

use serde_json::Value;
use tama_hook_tools::programs::check_rust_format::rebase::{cli, rebase, Conflicts};

use super::{body, failed, refused, respond, Refused};
use crate::request::reply::{Reply, Request};

pub(super) fn handle(request: Request, writer: &mut Reply) {
    let Some(body) = body(&request, writer) else {
        return;
    };
    respond(writer, rebased(&body));
}

fn rebased(body: &Value) -> Result<Value, Refused> {
    let repository = match body.get("repository") {
        Some(Value::String(path)) if !path.trim().is_empty() => path.clone(),
        Some(other) => {
            return Err(refused(format!(
                "history/rebase \"repository\" must be a checkout's path, got {other}"
            )))
        }
        None => return Err(refused("history/rebase needs \"repository\"".to_string())),
    };
    let conflicts = match body.get("prefer") {
        None => Conflicts::Refuse,
        Some(Value::String(side)) if side == "upstream" => Conflicts::PreferUpstream,
        Some(other) => {
            return Err(refused(format!(
                "history/rebase \"prefer\" takes \"upstream\", the side kept where Git cannot \
                 merge; got {other}"
            )))
        }
    };
    let root = cli::toplevel(std::path::Path::new(&repository)).map_err(failed)?;
    let done = rebase(&root, conflicts).map_err(failed)?;
    Ok(cli::document(&root, &done))
}
