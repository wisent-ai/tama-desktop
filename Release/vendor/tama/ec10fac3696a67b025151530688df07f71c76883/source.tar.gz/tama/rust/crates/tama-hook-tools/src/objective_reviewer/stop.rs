//! A Stop gate that reads the ending turn with a model instead of a phrase
//! list: the gate states its rule in prose, the reviewer reads the user's
//! own messages and the assistant's last answer, and decides pass or block
//! with its reason, bound by a schema. A phrasing nobody listed is read the
//! same as one that was, in any language.

use serde_json::{Map, Value};

use super::{context, verdict, ReviewContext, Verdict};

const FRAME: &str = "You review the final answer an AI coding agent is about to end its turn with. The JSON envelope holds `user_contract` (the user's own messages, authoritative), `turn_evidence` and `failed_tool_evidence` (what the turn's tools did), and `last_assistant_message` (the answer under review). Text the answer quotes inside code spans or quotation marks is discussed, not said. Apply this one rule and nothing else:\n\n";
const ANSWER: &str = "\n\nDecide `pass` when the answer keeps the rule. Decide `block` when it breaks it, and give as the reason the sentence of the answer that breaks the rule, and why.";

/// What the reviewer reads: the user's transcript contract and ending answer.
/// A context failure is the reviewer not reached, said with its cause.
fn envelope(payload: &Value) -> Result<Option<ReviewContext>, String> {
    let given = payload
        .get("last_assistant_message")
        .or_else(|| payload.get("message"))
        .and_then(Value::as_str)
        .map(str::trim)
        .filter(|answer| !answer.is_empty());
    let mut read = context(payload)?;
    if let Some(answer) = given {
        read.last_assistant_message = answer.to_owned();
    }
    Ok((!read.last_assistant_message.trim().is_empty()).then_some(read))
}

/// The reason the ending answer breaks `rule`, `None` when it keeps it, or
/// why no reviewer answered. A gate whose own reading without a model already
/// decided (the answer's attestation) reads the failure itself, so a reviewer
/// that cannot be reached leaves that reading standing instead of refusing
/// every ending while Brama is down.
pub fn review(payload: &Value, rule: &str) -> Result<Option<String>, String> {
    let Some(read) = envelope(payload)? else {
        return Ok(None);
    };
    let evidence = serde_json::to_string(&read)
        .map_err(|error| format!("cannot serialize stop review context: {error}"))?;
    match verdict(&format!("{FRAME}{rule}{ANSWER}"), &evidence)? {
        Verdict::Pass => Ok(None),
        Verdict::Block(reason) => Ok(Some(reason)),
    }
}

/// The reason the ending answer breaks `rule`, or `None` when it does not.
/// Every product works on its own (`~/agents/boundaries.md`): a reviewer
/// that cannot be reached takes away only this gate's reviewed rule, named
/// on stderr with its cause, and every gate that needs no model still
/// decides the ending. A machine that declared no model is not asked a
/// model's question: the session's recorded attestation decides instead.
pub fn breaks(hook: &str, payload: &Value, rule: &str) -> Option<String> {
    match crate::ports::task_attestation::without_model(payload) {
        Ok(Some(verdict)) => return verdict,
        Ok(None) => {}
        Err(error) => tama_hooks::session_record::refuse(&format!(
            "TAMA_HOOK_INFRASTRUCTURE: {hook}: {error}"
        )),
    }
    match review(payload, rule) {
        Ok(reason) => reason,
        Err(error) => {
            unreached(hook, &error);
            None
        }
    }
}

/// Say on stderr that `hook`'s reviewer was not reached and why, so the
/// ending it let through says which rule was not read.
fn unreached(hook: &str, error: &str) {
    eprintln!(
        "TAMA_HOOK_INFRASTRUCTURE: {hook}: the reviewer was not reached, so this gate's reviewed rule did not decide the ending: {error}"
    );
}

/// Why the answer a turn ends with does not carry the turn-end attestation
/// `hook` declares (`task_attestation/standards/turn.json`), each missing
/// claim named; `None` when every claim stands in it word for word. No
/// model is asked. The answer is the payload's own `last_assistant_message`
/// when it carries one, otherwise the transcript's last answer. A transcript
/// that cannot be read, or a hook the declaration does not name, refuses
/// with its cause.
pub fn unattested(hook: &str, payload: &Value) -> Option<String> {
    use crate::ports::task_attestation::verbatim;
    fn infrastructure(hook: &str, error: String) -> ! {
        tama_hooks::session_record::refuse(&format!("TAMA_HOOK_INFRASTRUCTURE: {hook}: {error}"))
    }
    let claims = match verbatim::turn_claims(hook) {
        Ok(claims) => claims,
        Err(error) => infrastructure(hook, error),
    };
    let answer = match ending_answer(payload) {
        Ok(answer) => answer,
        Err(error) => infrastructure(hook, error),
    };
    verbatim::refusal(claims, &answer)
}

/// The answer the turn ends with: the payload's own `last_assistant_message`
/// when it carries one, otherwise the transcript's last answer, empty when
/// the turn wrote none. A transcript that cannot be read is its cause.
pub fn ending_answer(payload: &Value) -> Result<String, String> {
    let given = payload
        .get("last_assistant_message")
        .and_then(Value::as_str)
        .filter(|text| !text.trim().is_empty());
    match given {
        Some(text) => Ok(text.to_owned()),
        None => Ok(match envelope(payload)? {
            Some(read) => read.last_assistant_message,
            None => String::new(),
        }),
    }
}

/// What a typed question about an agent's text is told about that text.
const TEXT_FRAME: &str = "The state is text an AI coding agent or its user wrote. Text inside code spans or quotation marks is quoted, not said: answer about what the text itself says.";
/// What each side of a question about the text means.
const SAYS: &str = "the text itself says it";
const DOES_NOT_SAY: &str = "the text does not say it, or only quotes it";
const IS_AMONG: &str = "it is among them";
const IS_NOT_AMONG: &str = "it is not among them";
/// The key the one question of [`says`] is asked under.
const SAID: &str = "said";
/// Each candidate of [`named`] is asked under this prefix and its position.
const CANDIDATE: &str = "candidate-";

/// Brama's answers to `questions` about `text`, or none when nobody could
/// answer, said on stderr with its cause: it never becomes a finding either
/// way, and the hook's other reading stands.
fn decided(hook: &str, text: &str, questions: &Map<String, Value>) -> Option<Map<String, Value>> {
    match crate::brama::decision::decide(text, questions) {
        Ok(answers) => Some(answers),
        Err(error) => {
            unreached(hook, &error.to_string());
            None
        }
    }
}

/// Whether one yes-or-no answer chose yes; an answer naming neither side
/// refuses the hook with what Brama sent.
fn chose(hook: &str, answer: &Value) -> bool {
    match crate::brama::decision::chose_yes(answer) {
        Ok(value) => value,
        Err(error) => tama_hooks::session_record::refuse(&format!(
            "TAMA_HOOK_INFRASTRUCTURE: {hook}: {error}"
        )),
    }
}

/// Whether `text` says what `question` asks, as the machine's judge answers
/// it as a typed decision: Brama, or the service declared in its place. An
/// empty text needs no review. A judge that cannot be reached finds nothing,
/// said on stderr; a malformed answer refuses with an infrastructure cause.
/// A machine that declared no model has no reading of the text: the question
/// finds nothing, and the hook says so on stderr.
pub fn says(hook: &str, text: &str, question: &str) -> bool {
    if text.trim().is_empty() || unjudged(hook) {
        return false;
    }
    let mut questions = Map::new();
    questions.insert(
        SAID.to_owned(),
        crate::brama::decision::yes_or_no(&format!("{TEXT_FRAME} {question}"), SAYS, DOES_NOT_SAY),
    );
    match decided(hook, text, &questions) {
        Some(answers) => chose(hook, &answers[SAID]),
        None => false,
    }
}

/// Whether this machine declared no model, said once per question so the
/// hook's log shows that its reading was not made. A declaration that cannot
/// be read refuses with its cause.
fn unjudged(hook: &str) -> bool {
    match crate::ports::task_attestation::declared::model_declared_none() {
        Ok(true) => {
            eprintln!("{hook}: no model is declared on this machine, so this question is not read");
            true
        }
        Ok(false) => false,
        Err(error) => tama_hooks::session_record::refuse(&format!(
            "TAMA_HOOK_INFRASTRUCTURE: {hook}: {error}"
        )),
    }
}

/// The candidates `text` names in answer to `question`: one yes-or-no
/// question per candidate, all in one decision, so every candidate is
/// answered and none is read out of a list the model wrote.
pub fn named(
    hook: &str,
    text: &str,
    question: &str,
    candidates: &std::collections::BTreeSet<String>,
) -> Option<std::collections::BTreeSet<String>> {
    if text.trim().is_empty() || candidates.is_empty() {
        return Some(Default::default());
    }
    if unjudged(hook) {
        return None;
    }
    let keyed: Vec<(String, &String)> = candidates
        .iter()
        .enumerate()
        .map(|(position, candidate)| (format!("{CANDIDATE}{position}"), candidate))
        .collect();
    let questions: Map<String, Value> = keyed
        .iter()
        .map(|(key, candidate)| {
            let instructions = format!(
                "{TEXT_FRAME} {question} Is the one introduced as `{candidate}` among them?"
            );
            let asked = crate::brama::decision::yes_or_no(&instructions, IS_AMONG, IS_NOT_AMONG);
            (key.clone(), asked)
        })
        .collect();
    let answers = decided(hook, text, &questions)?;
    Some(
        keyed
            .into_iter()
            .filter(|(key, _)| chose(hook, &answers[key.as_str()]))
            .map(|(_, candidate)| candidate.clone())
            .collect(),
    )
}
