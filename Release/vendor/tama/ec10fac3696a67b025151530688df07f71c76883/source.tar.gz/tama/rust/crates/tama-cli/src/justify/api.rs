use serde::Deserialize;
use serde_json::{json, Value};

use super::{absolute, entry, registry, request};

#[derive(Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub(crate) struct RecordRequest {
    kind: String,
    file: String,
    justification: String,
    expires_at: Option<String>,
    /// The evidence `pre-edit-trajectory-evidence` reads for a trajectory,
    /// keeper or routine file, written beside the justification.
    trajectory_evidence: Option<String>,
}

pub(crate) fn record(input: RecordRequest) -> Result<Value, String> {
    if input.kind != "file" {
        return Err(
            "kind must be file; a test is approved with tama tests approve, and CUA uses the justifications/cua/record request".into(),
        );
    }
    let mut argv = vec![
        "--kind".into(),
        input.kind,
        "--file".into(),
        input.file.clone(),
        "--justification".into(),
        input.justification,
    ];
    if let Some(expires) = input.expires_at {
        argv.extend(["--expires-at".into(), expires]);
    }
    if let Some(evidence) = input.trajectory_evidence {
        argv.extend(["--trajectory-evidence".into(), evidence]);
    }
    let request = request(&argv).map_err(|(_, message)| message)?;
    let key = absolute(&input.file)?;
    let document = entry(&argv)?;
    let path = registry::registry_path(&request.home, request.kind);
    registry::ledger::file_record(&path, &key, document)?;
    Ok(json!({"recorded": key, "kind": request.kind.label(), "registry": path}))
}
