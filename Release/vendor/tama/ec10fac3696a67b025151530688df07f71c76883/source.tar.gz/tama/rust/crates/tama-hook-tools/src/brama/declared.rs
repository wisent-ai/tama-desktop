//! A model service declared in place of Brama with `tama model set`:
//! any OpenAI-compatible chat-completions service, for a machine without
//! Brama. The declaration lives at `TAMA_MODEL_PROVIDER_PATH`, else
//! `~/.tama/model-provider.json`.

use std::path::PathBuf;

/// The variable that moves the declaration elsewhere.
const PROVIDER_PATH_ENV: &str = "TAMA_MODEL_PROVIDER_PATH";
/// Where the declaration lives under the home directory otherwise.
const PROVIDER_HOME_PATH: &str = ".tama/model-provider.json";

/// The declared service: its origin, the model it is asked for and the key
/// it is asked with.
#[derive(serde::Serialize, serde::Deserialize)]
pub struct DeclaredProvider {
    pub origin: String,
    pub model: String,
    pub key: String,
}

/// Where the declaration is read from and written to.
pub fn provider_path() -> PathBuf {
    match std::env::var_os(PROVIDER_PATH_ENV).filter(|value| !value.is_empty()) {
        Some(path) => PathBuf::from(path),
        None => super::credentials::home_dir().join(PROVIDER_HOME_PATH),
    }
}

/// The declared provider, none when nothing is declared, or why the
/// declaration cannot be used. A machine that declared no model (`tama model
/// set --none`) has no provider to ask: a caller that reaches here without
/// asking `model_declared_none` first is told so by name, never with the
/// missing `origin` field a none declaration was once parsed for.
pub fn declared_provider() -> Result<Option<DeclaredProvider>, String> {
    let path = provider_path();
    // Only a declaration that is not there is none; one that cannot be read
    // is refused with its path and cause, never taken for no declaration.
    let text = match std::fs::read_to_string(&path) {
        Ok(text) => text,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(None),
        Err(error) => {
            return Err(format!(
                "the model provider declaration {} cannot be read: {error}",
                path.display()
            ))
        }
    };
    let document: serde_json::Value = serde_json::from_str(&text).map_err(|error| {
        format!(
            "{} is not a model provider declaration: {error}",
            path.display()
        )
    })?;
    if crate::ports::task_attestation::declared::declares_none(&document) {
        return Err(format!(
            "{} declares that this machine has no model (`tama model set --none`), so no model may be asked here; a gate reads the attestation alone on such a machine, or declare a model with `tama model set --origin URL --model MODEL`",
            path.display()
        ));
    }
    let found: DeclaredProvider = serde_json::from_value(document).map_err(|error| {
        format!(
            "{} is not a model provider declaration: {error}",
            path.display()
        )
    })?;
    if found.origin.is_empty() || found.model.is_empty() || found.key.is_empty() {
        return Err(format!(
            "{} names no complete model provider (origin, model and key); declare it again with `tama model set` or remove it with `tama model unset`",
            path.display()
        ));
    }
    Ok(Some(found))
}
