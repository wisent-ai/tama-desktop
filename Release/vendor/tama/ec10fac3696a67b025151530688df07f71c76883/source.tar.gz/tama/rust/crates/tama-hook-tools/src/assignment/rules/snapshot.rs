//! A session's open work as Oko settled it outside every hook (`oko tasks
//! snapshot --session ID --prompt N`, asked for by Tama's core after each
//! prompt and stop it answers): one file read in milliseconds instead of
//! settling the sessions inside a gate, which took longer than the harness
//! waits for a hook. A snapshot that states a lower prompt count than the
//! one Tama's core counted for the session (`prompt` in its
//! `open-work.<session>.json` against the snapshot's `prompt`) does not hold
//! the operator's latest prompt, and one settled from another version of
//! the session's task register than the one Oko counted last (every change
//! Oko makes to it, a reading or a task row, advances the version in
//! `<session>.mutated.json`; the snapshot records the version of every
//! session's register it was settled from in `versions`) does not hold that
//! register: each is refused by name, never read as current. Counts and
//! versions are compared, never times, so a prompt or a change in the same
//! instant as the settling still tells apart. The snapshot also carries
//! every other session holding open work; one whose register is at another
//! version than the snapshot's is not refused (its own refresher settles its
//! own snapshot, not this one), but its ledger is marked `staleSince` with
//! that change, so every gate that lists its tasks says they are as they
//! stood before it. A snapshot whose defect or blocker register was written
//! after it was settled (`sources`: each register's path and content digest
//! as Oko read it) is refused naming that register (`super::sources`).

use std::path::PathBuf;

use serde_json::Value;

/// Where Oko keeps the snapshots, as Oko's `store::location` reads it: the
/// variable that moves the directory, else Oko's application data.
const DIRECTORY_VARIABLE: &str = "OKO_OPEN_WORK";
const APPLICATION_DATA: &str = "Library/Application Support/Oko/open-work";
/// The record Tama's core writes when a prompt of the session arrives.
const PROMPT_PREFIX: &str = "open-work.";
const SUFFIX: &str = ".json";
/// The record Oko writes beside a snapshot with the version of the
/// session's task register and the time of its newest change.
const MUTATED_SUFFIX: &str = ".mutated.json";

/// One session's task register as Oko's change record states it: its
/// version (null when Oko counted none) and when it last changed.
struct Version {
    version: Value,
    at: Option<String>,
}

impl Version {
    /// The change, said on a ledger line or in a refusal.
    fn said(&self) -> String {
        match &self.at {
            Some(at) => format!("to version {} at {at}", self.version),
            None => format!("to version {}", self.version),
        }
    }
}

fn directory() -> PathBuf {
    match tama_core::path_variable(DIRECTORY_VARIABLE) {
        Some(directory) => directory,
        None => tama_core::home_dir().join(APPLICATION_DATA),
    }
}

fn location(session: &str) -> PathBuf {
    directory().join(format!("{session}{SUFFIX}"))
}

fn read_json(path: &PathBuf, what: &str) -> Result<Option<Value>, String> {
    match std::fs::read(path) {
        Ok(bytes) => serde_json::from_slice(&bytes)
            .map(Some)
            .map_err(|error| format!("{what} {} is not JSON: {error}", path.display())),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(None),
        Err(error) => Err(format!("cannot read {what} {}: {error}", path.display())),
    }
}

/// The operator's latest prompt of `session` as Tama's core counted it: the
/// series its count belongs to, the count, and when it arrived; none when
/// this core counted no prompt of the session (or wrote the record before
/// it counted prompts in series).
fn prompted(session: &str) -> Result<Option<(String, u64, String)>, String> {
    let path = tama_hooks::session_control::session_control_root()
        .join(format!("{PROMPT_PREFIX}{session}{SUFFIX}"));
    let Some(record) = read_json(&path, "the prompt record")? else {
        return Ok(None);
    };
    let at = match record.get("promptAt").and_then(Value::as_str) {
        Some(at) => at.to_owned(),
        None => {
            return Err(format!(
                "the prompt record {} names no promptAt: {record}",
                path.display()
            ))
        }
    };
    match (
        record.get("series").and_then(Value::as_str),
        record.get("prompt"),
    ) {
        (Some(series), Some(count)) => match count.as_u64() {
            Some(count) => Ok(Some((series.to_owned(), count, at))),
            None => Err(format!(
                "the prompt record {} counts its prompts as {count}, not a whole number",
                path.display()
            )),
        },
        _ => Ok(None),
    }
}

/// The version of `session`'s task register, as Oko counted it beside the
/// snapshot; a null version when it recorded no change, or recorded one
/// before it counted versions, as Oko reads the same record.
fn mutated(session: &str) -> Result<Version, String> {
    let path = directory().join(format!(
        "{}{MUTATED_SUFFIX}",
        tama_core::oko_session_key(session)
    ));
    let Some(record) = read_json(&path, "Oko's register-change record")? else {
        return Ok(Version {
            version: Value::Null,
            at: None,
        });
    };
    let version = match record.get("version") {
        Some(version) => version.clone(),
        None => Value::Null,
    };
    Ok(Version {
        version,
        at: record
            .get("mutatedAt")
            .and_then(Value::as_str)
            .map(str::to_owned),
    })
}

/// The version of `session`'s register `snapshot` was settled from: null
/// when it was settled from none, the same null [`mutated`] reads.
fn settled_version<'a>(snapshot: &'a Value, session: &str) -> &'a Value {
    &snapshot["versions"][tama_core::oko_session_key(session)]
}

/// Oko's snapshot of `session`'s open work when it holds the operator's
/// latest prompt and the current version of the session's task register.
/// `Err` names the snapshot that is missing, unreadable, settled before the
/// session's latest prompt or from an older version of its task register.
fn current(session: &str) -> Result<(PathBuf, Value), String> {
    let path = location(session);
    let writes = format!(
        "Tama's core asks Oko for it after each prompt and stop it answers; `oko tasks \
         snapshot --session {session}` writes it"
    );
    let snapshot = read_json(&path, "Oko's open-work snapshot")?.ok_or_else(|| {
        format!(
            "Oko has not written the open work of session {session} to {}: {writes}",
            path.display()
        )
    })?;
    if let Some((series, counted, at)) = prompted(session)? {
        // A snapshot holds the latest prompt when it was settled after a
        // prompt of the same series counted at least as far; a prompt of
        // another series is another count, never compared with this one.
        let held = &snapshot["prompt"];
        let held_series = held["series"].as_str();
        let held_count = held["count"].as_u64();
        let holds =
            held_series == Some(series.as_str()) && held_count.is_some_and(|held| held >= counted);
        if !holds {
            let settled = match (held_series, held_count) {
                (Some(other), Some(held)) if other != series => {
                    format!("after prompt {held} of another series ({other})")
                }
                (Some(_), Some(held)) => format!("after prompt {held}"),
                _ => "naming no prompt".to_string(),
            };
            return Err(format!(
                "Oko's open work of session {session} was settled {settled}, before the operator's \
                 prompt {counted} of series {series} (at {at}), so it does not hold that prompt's work; {writes}"
            ));
        }
    }
    let current = mutated(session)?;
    let settled_from = settled_version(&snapshot, session);
    if *settled_from != current.version {
        return Err(format!(
            "Oko's open work of session {session} was settled from version {settled_from} of its task register, \
             which has since changed {}, so it does not hold that change; {writes}",
            current.said()
        ));
    }
    if let Some(moved) = super::sources::moved(&snapshot) {
        return Err(format!(
            "Oko's open work of session {session} is not current: {moved}; {writes}"
        ));
    }
    Ok((path, snapshot))
}

/// The kind Oko's reading gives a message the operator asked as a question
/// (`reading.json` in Oko declares it).
pub const QUESTION: &str = "question";
/// The kind Oko's reading gives a message that forbids or restricts
/// something for the current turn only, such as his "nie koduj".
pub const ORDER: &str = "order";
/// The kind Oko's reading gives a message that reports something the agent
/// delivered is broken or wrong.
pub const DEFECT: &str = "defect";

/// Whether the operator's newest message of `session` reads as a question
/// in Oko's current snapshot (`newestMessage`: `{ordinal, kind}`, `{unread}`
/// with why Oko could not read it, or null without one): a question he
/// asked is owed its answer, so the gate that keeps prose from him while
/// work is open lets that answer through. `Ok(false)` while the message is
/// unread, reads as anything else, or Oko could not read it; `Err` as
/// [`current`] refuses a snapshot that is missing or not current.
pub fn owed_answer(session: &str) -> Result<bool, String> {
    newest_is(session, QUESTION)
}

/// Whether the operator's newest message of `session` reads as an order for
/// this turn alone. Such an order ("nie koduj") stops every tool call, so
/// the answer it is owed is words; read as [`owed_answer`] reads a question.
pub fn owed_order(session: &str) -> Result<bool, String> {
    newest_is(session, ORDER)
}

fn newest_is(session: &str, kind: &str) -> Result<bool, String> {
    Ok(newest_kind(session)?.as_deref() == Some(kind))
}

/// The kind Oko's current snapshot reads the operator's newest message of
/// `session` as; `None` while it is unread or the snapshot names none, `Err`
/// as [`current`] refuses a snapshot that is missing or not current.
pub fn newest_kind(session: &str) -> Result<Option<String>, String> {
    let (_, snapshot) = current(session)?;
    Ok(snapshot["newestMessage"]
        .get("kind")
        .and_then(Value::as_str)
        .map(str::to_string))
}

/// The owed report Oko settled for `session`: every session holding open
/// work, and `session` whole. `Err` as [`current`] refuses a snapshot.
pub(super) fn report(session: &str) -> Result<Vec<Value>, String> {
    let (path, snapshot) = current(session)?;
    let Some(Value::Array(sessions)) = snapshot.get("report") else {
        return Err(format!(
            "Oko's open-work snapshot {} carries no report array",
            path.display()
        ));
    };
    let mut ledgers = Vec::with_capacity(sessions.len());
    for ledger in sessions {
        let mut ledger = ledger.clone();
        let named = ledger
            .get("sessionId")
            .and_then(Value::as_str)
            .map(str::to_owned);
        let Some(other) = named else {
            // Oko's report names every ledger's session; one that names none
            // cannot be told from this session's or checked for staleness.
            ledger["staleUnread"] =
                Value::String("Oko's report names no sessionId for this ledger".to_owned());
            ledgers.push(ledger);
            continue;
        };
        if tama_core::oko_session_key(&other) == tama_core::oko_session_key(session) {
            ledgers.push(ledger);
            continue;
        }
        // Another session's change record decides only its own ledger: one
        // that cannot be read is named there, and the rest of the report
        // stands.
        match mutated(&other) {
            Ok(current) if *settled_version(&snapshot, &other) != current.version => {
                ledger["staleSince"] = Value::String(current.said())
            }
            Ok(_) => {}
            Err(cause) => ledger["staleUnread"] = Value::String(cause),
        }
        ledgers.push(ledger);
    }
    Ok(ledgers)
}
