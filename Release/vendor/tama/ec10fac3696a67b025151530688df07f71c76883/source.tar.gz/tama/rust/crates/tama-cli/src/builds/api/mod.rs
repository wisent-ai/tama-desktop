//! The build registry operations shared by the CLI and desktop backend.

mod approval;

use serde::Deserialize;
use serde_json::{json, Value};
use std::path::Path;

use super::{intent, policy, ration, REGISTRY_FILE};
use crate::justify::registry;
use ration::{ledger, Admission};

#[derive(Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub(crate) struct RecordRequest {
    kind: String,
    target: String,
    reason: String,
    revision: Option<String>,
    repository: Option<String>,
    completed_task: Option<String>,
    minutes: Option<u64>,
    approval_session: Option<String>,
    approval_quote: Option<String>,
}

impl RecordRequest {
    pub(crate) fn record(self, home: &Path) -> Result<Value, String> {
        let mut args = vec![
            "--kind".into(),
            self.kind,
            "--target".into(),
            self.target,
            "--reason".into(),
            self.reason,
        ];
        for (flag, value) in [
            ("--revision", self.revision),
            ("--repository", self.repository),
            ("--minutes", self.minutes.map(|value| value.to_string())),
            ("--completed-task", self.completed_task),
            ("--approval-session", self.approval_session),
            ("--approval-quote", self.approval_quote),
        ] {
            if let Some(value) = value {
                args.extend([flag.into(), value]);
            }
        }
        record(&args, home)
    }
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct CloseRequest {
    kind: String,
    target: String,
    #[serde(default)]
    not_started: Option<String>,
}

impl CloseRequest {
    pub(crate) fn close(self, home: &Path) -> Result<Value, String> {
        let mut argv = vec!["--kind".into(), self.kind, "--target".into(), self.target];
        if let Some(refusal) = self.not_started {
            argv.extend(["--not-started".into(), refusal]);
        }
        close(&argv, home)
    }
}

pub(crate) fn close(argv: &[String], home: &Path) -> Result<Value, String> {
    let kind = intent::kind_of(argv)?;
    let target = intent::target_of(argv)?;
    // `--not-started` takes the refusal that follows it.
    let not_started = argv
        .iter()
        .position(|arg| arg == "--not-started")
        .map(|index| {
            argv[index..]
                .split_first()
                .and_then(|(_, rest)| rest.first())
                .filter(|refusal| !refusal.trim().is_empty() && !refusal.starts_with("--"))
                .ok_or(
                    "--not-started needs the refusal that stopped the build before any job existed",
                )
        })
        .transpose()?;
    if not_started.is_some() && kind != "build" {
        return Err("--not-started applies to a build, not a restart".into());
    }
    let _lock = registry::Lock::acquire(&ledger::file(home))?;
    let path = home.join(".shared-hooks").join(REGISTRY_FILE);
    let key = format!("{kind}:{target}");
    let mut result = json!({"closed": key, "registry": path});
    if let Some(refusal) = not_started {
        let revision = ledger::mark_not_started(&ledger::file(home), &target, refusal)?;
        result["not_started"] = json!({"revision": revision, "refusal": refusal});
    }
    registry::forget(&path, &key)?;
    Ok(result)
}

pub(crate) fn record(argv: &[String], home: &Path) -> Result<Value, String> {
    let policy = policy::load(&policy::file(home))?;
    let kind = intent::kind_of(argv)?;
    let target = intent::target_of(argv)?;
    let mut document = intent::entry(argv, &policy, &kind, &target)?;
    let approval = approval::requested(
        argv,
        &kind,
        &target,
        document.get("revision").and_then(Value::as_str),
    )?;
    // Network access happens before the file lock; only local checks and writes
    // belong in the registry transaction.
    let fleet_remaining = (kind == "build" && approval.is_none())
        .then(ration::fleet::remaining)
        .flatten();
    let ledger_file = ledger::file(home);
    let _lock = registry::Lock::acquire(&ledger_file)?;
    if let Some(approval) = approval {
        if ledger::approval_used(&ledger_file, &approval)? {
            return Err("this operator message already authorized a build of this product; closing the entry does not renew consent".into());
        }
        document["user_approval"] = approval;
    }
    let at = intent::now()?;
    let (Some(expires), Some(recorded)) = (
        document["expires_at_epoch"].as_u64(),
        document["recorded_at_epoch"].as_u64(),
    ) else {
        return Err(format!(
            "the intent built for {kind}:{target} names no expires_at_epoch or recorded_at_epoch, so its window cannot be renewed: {document}"
        ));
    };
    let Some(window) = expires.checked_sub(recorded) else {
        return Err(format!(
            "the intent built for {kind}:{target} expires at {expires}, before it was recorded at {recorded}"
        ));
    };
    document["recorded_at_epoch"] = json!(at);
    document["expires_at_epoch"] = json!(at + window);
    let admission = Admission {
        at,
        fleet_remaining,
        approved: document.get("user_approval").is_some(),
    };
    ration::rationed(argv, &policy, &ledger_file, &kind, &target, &admission)?;
    let path = home.join(".shared-hooks").join(REGISTRY_FILE);
    let key = format!("{kind}:{target}");
    if let Some(approval) = document.get("user_approval") {
        approval::still_current(approval)?;
    }
    // Never publish an authorization before its evidence is durable. A failed
    // registry write leaves a spent, auditable intent, not unrecorded permission.
    ledger::append(&ledger_file, &document)?;
    registry::record(&path, &key, document.clone())?;
    let spent = ledger::spent(&ledger_file, &kind, at, policy::WINDOW_SECONDS)?.len();
    // A build's count is the fleet's when the fleet answered; the local
    // ledger then only records intents and is not a second ceiling.
    let mut result = json!({"recorded": key, "entry": document, "registry": path,
        "spent": spent, "allowed": policy.per_day(&kind)});
    if kind == "build" {
        if let Some(remaining) = fleet_remaining {
            result["fleet_remaining"] = json!(remaining);
        }
    }
    Ok(result)
}

pub(crate) fn list(home: &Path) -> Result<Value, String> {
    let path = home.join(".shared-hooks").join(REGISTRY_FILE);
    let entries = registry::load(&path)?;
    let at = intent::now()?;
    let policy = policy::load(&policy::file(home))?;
    let ledger_file = ledger::file(home);
    let rows: Vec<Value> = entries
        .into_iter()
        .map(|(key, entry)| {
            json!({"key": key, "open": intent::minutes_left(&entry, at).is_some()
            && entry.get("used_at_epoch").is_none(), "entry": entry})
        })
        .collect();
    let mut ration = Vec::new();
    for kind in policy::Kind::ALL.iter().map(|kind| kind.as_str()) {
        let spent = ledger::spent(&ledger_file, kind, at, policy::WINDOW_SECONDS)?.len();
        let allowed = policy.per_day(kind);
        let mut row = json!({"kind": kind, "spent": spent, "allowed": allowed,
            "left": allowed.saturating_sub(spent as u64)});
        if kind == "build" {
            if let Some(remaining) = ration::fleet::remaining() {
                row["fleet_remaining"] = json!(remaining);
            }
        }
        ration.push(row);
    }
    Ok(json!({"registry": path, "entries": rows, "ration": ration,
        "approval_history": ledger::approvals(&ledger_file)?}))
}

/// What `tama build approval` is given: the target and the revision. A
/// missing one is a usage error.
pub(crate) fn approval_arguments(argv: &[String]) -> Result<(String, String), String> {
    let target = intent::target_of(argv)?;
    let revision = intent::option(argv, "--revision")
        .filter(|value| !value.trim().is_empty())
        .ok_or("--revision is required: the source revision the approved build carries")?;
    Ok((target, revision))
}

/// The fleet reads this before spending an exception. A caller supplies only
/// coordinates; consent comes from the registry and its matching audit entry.
pub(crate) fn approval(argv: &[String], home: &Path) -> Result<Value, String> {
    let (target, revision) = approval_arguments(argv)?;
    let ledger_file = ledger::file(home);
    let _lock = registry::Lock::acquire(&ledger_file)?;
    let path = home.join(".shared-hooks").join(REGISTRY_FILE);
    let entries = registry::load(&path)?;
    let entry = entries
        .get(&format!("build:{target}"))
        .ok_or_else(|| format!("no recorded build approval for {target}"))?;
    // The guard marks the open entry used before Stado reads this approval.
    // The immutable audit receipt was recorded before that mark.
    let mut audited = entry.clone();
    audited
        .as_object_mut()
        .ok_or_else(|| format!("malformed build entry for {target} in {}", path.display()))?
        .remove("used_at_epoch");
    if entry["revision"].as_str() != Some(revision.as_str())
        || intent::minutes_left(entry, intent::now()?).is_none()
        || !entry["user_approval"].is_object()
        || !ledger::approvals(&ledger_file)?
            .iter()
            .any(|recorded| recorded == &audited)
    {
        return Err(format!(
            "no unexpired, audited user approval for {target} at {revision}"
        ));
    }
    Ok(entry.clone())
}
