//! The operator's sentences, each written once in the block injected at
//! session start and after every compaction.
//!
//! The operator repeats a standing rule when a session forgets it, and each
//! later version rewords the earlier one by inserting words into some of its
//! sentences while the others stand as they were, so the ledger holds several
//! variants of one instruction, and writing each in full would repeat them
//! after every compaction. A sentence the block has already written, word for word
//! (case and the punctuation around words aside), is not written again: each
//! variant keeps the sentences that are new in it and says how many of its
//! sentences stand above. Sentences are compared whole, never by the words
//! they share, because one inserted word ("nie") reverses an order: a
//! sentence that differs by a word is another sentence and is written.

use std::collections::HashSet;

/// The sentences the block has written, each by its words.
#[derive(Default)]
pub struct Written {
    seen: HashSet<String>,
}

impl Written {
    /// `text` as the block writes it: its sentences not written above, then
    /// how many of its sentences stand above, when any do.
    pub fn line(&mut self, text: &str) -> String {
        match self.fresh_line(text) {
            Some(line) => line,
            None => String::from("[every sentence of it is written above]"),
        }
    }

    /// [`Written::line`], or none when every sentence of `text` is written
    /// above, so a block that may leave such a text out can count it instead.
    pub fn fresh_line(&mut self, text: &str) -> Option<String> {
        let mut fresh: Vec<String> = Vec::new();
        let mut above: Vec<String> = Vec::new();
        for sentence in sentences(text) {
            let words = words(&sentence);
            if words.is_empty() || self.seen.insert(words) {
                fresh.push(sentence);
            } else {
                above.push(sentence);
            }
        }
        match (fresh.is_empty(), above.is_empty()) {
            (_, true) => Some(fresh.join(" ")),
            (true, false) => None,
            (false, false) => Some(format!(
                "{} [{} more sentence(s) of it are written above]",
                fresh.join(" "),
                above.len()
            )),
        }
    }
}

/// The sentences of a one-line text: a sentence ends where a full stop, an
/// exclamation or a question mark is followed by a space or the end of the
/// text, so a dotted name or a decimal number stays inside its sentence.
fn sentences(text: &str) -> Vec<String> {
    let mut out: Vec<String> = Vec::new();
    let mut open = String::new();
    for piece in text.split_inclusive(['.', '!', '?']) {
        if !open.is_empty() && !piece.starts_with(char::is_whitespace) {
            open.push_str(piece);
            continue;
        }
        let ended = std::mem::replace(&mut open, piece.to_string());
        if !ended.trim().is_empty() {
            out.push(ended.trim().to_string());
        }
    }
    if !open.trim().is_empty() {
        out.push(open.trim().to_string());
    }
    out
}

/// A sentence's words as two sentences are compared: lower case, without
/// the punctuation around each word.
fn words(sentence: &str) -> String {
    sentence
        .split_whitespace()
        .map(|word| {
            word.trim_matches(|mark: char| !mark.is_alphanumeric())
                .to_lowercase()
        })
        .filter(|word| !word.is_empty())
        .collect::<Vec<_>>()
        .join(" ")
}
