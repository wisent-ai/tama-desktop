//! tama-hook-tools: the standalone tools (`editor-save-guard`,
//! `editor-watch`, `generate-configs`, `run-one-session-hook`,
//! `install-oko-trajectory-boundary-hook`) and the `ports` tree holding
//! the registered hooks. Every hook and tool runs
//! as `tama hook <name>` through [`programs`]; this crate builds no binary.

// The programs were binaries of their own and name this crate by its
// published name; inside it that name now means the crate itself.
extern crate self as tama_hook_tools;

pub mod assignment;
pub mod attestation;
pub mod brama;
pub mod capability;
pub mod claims;
pub mod evidence;
pub mod objective_reviewer;
pub mod one_session;
pub mod ports;
pub mod programs;
pub mod registry;
pub mod tracker;
pub mod util;
