//! The SSH justification registry as a document: its schema line, its
//! authorizations, and the one locked transaction every change goes through.
//! The file's other top-level fields (the entry format the operator keeps
//! beside the entries) are carried through untouched.
use std::path::Path;

use serde_json::{json, Map, Value};

use super::super::registry;
use super::SCHEMA;

fn checked(mut document: Map<String, Value>, path: &Path) -> Result<Map<String, Value>, String> {
    if !tama_core::presence::present(path).map_err(|error| error.to_string())?
        && document.is_empty()
    {
        document.insert("schema".into(), json!(SCHEMA));
        document.insert("authorizations".into(), json!([]));
    }
    if document.get("schema").and_then(Value::as_str) != Some(SCHEMA) {
        return Err(format!(
            "{} is not a {SCHEMA} registry; nothing was changed",
            path.display()
        ));
    }
    if !document.get("authorizations").is_some_and(Value::is_array) {
        return Err(format!(
            "{} must contain an authorizations array; nothing was changed",
            path.display()
        ));
    }
    Ok(document)
}

pub(super) fn load(path: &Path) -> Result<Map<String, Value>, String> {
    checked(registry::load(path)?, path)
}

/// Record one entry. An entry already recorded for the same quote, targets
/// and operation is replaced, so recording the same consent twice keeps one.
pub(super) fn record(path: &Path, entry: Value) -> Result<(), String> {
    let kept = entry.clone();
    registry::update(path, |document| {
        let mut document = checked(document, path)?;
        let entries = document
            .get_mut("authorizations")
            .and_then(Value::as_array_mut)
            .ok_or("authorizations is not an array")?;
        entries.retain(|existing| {
            !(existing.get("userRequestQuote") == entry.get("userRequestQuote")
                && existing.get("allowedTargets") == entry.get("allowedTargets")
                && existing.get("allowedOperations") == entry.get("allowedOperations"))
        });
        // Newest first: `justify list` shows the latest grant at the top.
        let mut newest_first = vec![entry];
        newest_first.append(entries);
        *entries = newest_first;
        Ok(document)
    })?;
    registry::ledger::grant_kept(registry::Kind::Ssh, path, &kept)
}

/// Remove every entry recorded for `quote`; how many were removed.
pub(super) fn forget(path: &Path, quote: &str) -> Result<usize, String> {
    let mut removed = None;
    registry::update(path, |document| {
        let mut document = checked(document, path)?;
        let entries = document
            .get_mut("authorizations")
            .and_then(Value::as_array_mut)
            .ok_or("authorizations is not an array")?;
        let before = entries.len();
        entries
            .retain(|entry| entry.get("userRequestQuote").and_then(Value::as_str) != Some(quote));
        if entries.len() == before {
            return Err("no SSH grant is recorded for that quote".into());
        }
        removed = Some(before - entries.len());
        Ok(document)
    })?;
    registry::ledger::grant_withdrawn(registry::Kind::Ssh, path, quote)?;
    removed.ok_or_else(|| "the registry was not changed".to_string())
}
