//! What must hold before an install writes anything: the release digests to
//! its recorded id, every native binary the registry runs is packaged and
//! signed, and every approved hook source is present in the release.

use std::collections::BTreeSet;
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};
use std::process::Command;

use serde_json::Value;

use super::super::package::load_object;
use super::super::package::seal::{tree_digest, RELEASE_SCHEMA};
use super::super::package::stage::{command_program, NATIVE_MANIFEST_SCHEMA};

/// Execute permission for anyone: owner, group or others.
const EXECUTABLE_MODE_BITS: u32 = (libc::S_IXUSR | libc::S_IXGRP | libc::S_IXOTH) as u32;
const UNIFIED_CLI: &str = "tama";
const HOOK_PROGRAM_PREFIX: &str = "tama-";
const RUST_SOURCE: &str = ".rs";

/// The sealed release and the roots its registry was written for.
pub(super) struct Verified {
    pub release: Value,
    pub registry: Value,
    pub old_root: PathBuf,
    pub old_home: PathBuf,
}

pub(super) fn verified_release(release_root: &Path) -> Result<Verified, String> {
    let release = load_object(&release_root.join("release.json"))?;
    if release["schema"] != RELEASE_SCHEMA {
        return Err("Unsupported Tama hook release manifest".to_string());
    }
    if release["releaseId"].as_str() != Some(tree_digest(release_root)?.as_str()) {
        return Err("Bundled Tama hook release failed its integrity check".to_string());
    }
    let registry = load_object(&release_root.join("shared-hooks/registry.json"))?;
    let maintained = PathBuf::from(
        registry["catalog"]["maintainedIn"]
            .as_str()
            .ok_or("Hook registry names no catalog.maintainedIn source path".to_string())?,
    );
    let old_root = maintained
        .parent()
        .filter(|shared| {
            maintained.file_name() == Some("registry.json".as_ref())
                && shared.file_name() == Some("shared-hooks".as_ref())
        })
        .and_then(Path::parent)
        .ok_or("Hook registry does not identify its canonical source root".to_string())?
        .to_path_buf();
    let codex = PathBuf::from(
        registry["adapters"]["codex"]["path"]
            .as_str()
            .ok_or("Hook registry names no adapters.codex.path".to_string())?,
    );
    let old_home = codex
        .parent()
        .filter(|codex_dir| {
            codex.file_name() == Some("hooks.json".as_ref())
                && codex_dir.file_name() == Some(".codex".as_ref())
        })
        .and_then(Path::parent)
        .ok_or("Hook registry does not identify its canonical home".to_string())?
        .to_path_buf();
    Ok(Verified {
        release,
        registry,
        old_root,
        old_home,
    })
}

/// Programs the registry runs natively: `tama-*` names and any command whose
/// object names a Rust source.
pub(super) fn native_command_names(
    value: &Value,
    names: &mut BTreeSet<String>,
) -> Result<(), String> {
    match value {
        Value::Object(object) => {
            if let Some(command) = object.get("command").and_then(Value::as_str) {
                let program = command_program(command)?.ok_or("Hook command cannot be empty")?;
                let rust = object
                    .get("source")
                    .and_then(Value::as_str)
                    .is_some_and(|s| s.ends_with(RUST_SOURCE));
                if program.starts_with(HOOK_PROGRAM_PREFIX) || rust {
                    names.insert(program);
                }
            }
            object
                .values()
                .try_for_each(|nested| native_command_names(nested, names))
        }
        Value::Array(items) => items
            .iter()
            .try_for_each(|nested| native_command_names(nested, names)),
        _ => Ok(()),
    }
}

/// The native hook programs the release packages, each present, executable
/// and passing its code signature, and covering every native registry command.
pub(super) fn declared_native_binaries(
    release_root: &Path,
    registry: &Value,
) -> Result<BTreeSet<String>, String> {
    let manifest = load_object(&release_root.join("native-hook-binaries.json"))?;
    if manifest["schema"] != NATIVE_MANIFEST_SCHEMA {
        return Err("Unsupported native hook binary manifest".to_string());
    }
    let mut all = BTreeSet::new();
    let hooks = declared_in(release_root, &manifest, "hooks", true, &mut all)?;
    declared_in(
        release_root,
        &manifest,
        "additionalExecutables",
        false,
        &mut all,
    )?;
    let mut registered = BTreeSet::new();
    native_command_names(registry, &mut registered)?;
    let undeclared: Vec<&String> = registered.difference(&hooks).collect();
    if !undeclared.is_empty() {
        let undeclared: Vec<&str> = undeclared.iter().map(|name| name.as_str()).collect();
        return Err(format!(
            "Registry native hook commands lack packaged binaries: {}",
            undeclared.join(", ")
        ));
    }
    Ok(hooks)
}

/// The programs one array `field` of the native binary manifest declares,
/// each with its build identity, a valid unique name, an executable file
/// under `bin/` and a passing code signature; `rust_hooks` requires each to
/// be built from a Rust source. Every name is added to `all`.
fn declared_in(
    release_root: &Path,
    manifest: &Value,
    field: &str,
    rust_hooks: bool,
    all: &mut BTreeSet<String>,
) -> Result<BTreeSet<String>, String> {
    let entries = manifest[field]
        .as_array()
        .ok_or(format!("Native hook binary manifest is missing {field}"))?;
    let mut declared = BTreeSet::new();
    for entry in entries {
        let name = entry["name"].as_str().ok_or(format!(
            "Native hook binary manifest has an invalid {field} entry"
        ))?;
        let (Some(source), true) = (entry["source"].as_str(), entry["package"].is_string()) else {
            return Err(format!(
                "Native hook binary manifest lacks build identity for {name}"
            ));
        };
        if rust_hooks && !source.ends_with(RUST_SOURCE) {
            return Err(format!("Native hook source is not Rust: {name}: {source}"));
        }
        if name.contains('/') || !(name == UNIFIED_CLI || name.starts_with(HOOK_PROGRAM_PREFIX)) {
            return Err(format!("Invalid declared native binary name: {name}"));
        }
        if !all.insert(name.to_string()) {
            return Err(format!("Duplicate declared native binary: {name}"));
        }
        let binary = release_root.join("bin").join(name);
        let metadata = std::fs::metadata(&binary)
            .map_err(|error| format!("Declared native binary {name} cannot be read: {error}"))?;
        let executable = metadata.permissions().mode() & EXECUTABLE_MODE_BITS != 0;
        if !metadata.is_file() || !executable {
            return Err(format!(
                "Declared native binary is missing or not executable: {name}"
            ));
        }
        // A signature check that cannot run is no check: the install stops
        // naming why instead of installing an unverified binary.
        let mut verify = Command::new("codesign");
        verify.args(["--verify", "--strict"]).arg(&binary);
        let output = stado_wait::output(&mut verify).map_err(|error| {
            format!("cannot verify the code signature of {name} with codesign: {error}")
        })?;
        if !output.status.success() {
            return Err(format!(
                "Declared native binary fails its code signature: {name}: {}",
                String::from_utf8_lossy(&output.stderr).trim()
            ));
        }
        declared.insert(name.to_string());
    }
    Ok(declared)
}

/// `base` followed by `rest`; an empty `rest` (a path mapped whole) is `base`
/// itself, because joining it would add a trailing `/` that no file answers.
fn joined(base: &Path, rest: &Path) -> PathBuf {
    if rest.as_os_str().is_empty() {
        base.to_path_buf()
    } else {
        base.join(rest)
    }
}

/// Where the release holds a source the registry declares.
pub(super) fn source_candidate(
    source: &str,
    release_root: &Path,
    old_root: &Path,
    old_home: &Path,
    home: &Path,
) -> PathBuf {
    let source = Path::new(source);
    let mappings = [
        (
            old_root.join("shared-hooks"),
            release_root.join("shared-hooks"),
        ),
        (
            old_root.join("claude-hooks"),
            release_root.join("claude-hooks"),
        ),
        (
            old_root.join("codex-hooks"),
            release_root.join("codex-hooks"),
        ),
        (
            old_home.join(".shared-hooks"),
            release_root.join("shared-hooks"),
        ),
        (
            old_home.join(".claude/hooks"),
            release_root.join("claude-hooks"),
        ),
        (
            old_home.join(".codex/hooks"),
            release_root.join("codex-hooks"),
        ),
    ];
    for (from, to) in mappings {
        if let Ok(rest) = source.strip_prefix(&from) {
            return joined(&to, rest);
        }
    }
    match source.strip_prefix(old_home) {
        Ok(rest) => joined(home, rest),
        Err(_outside_home) => source.to_path_buf(),
    }
}

/// Refuse a release that lacks the source of any hook it approves.
pub(super) fn require_approved_sources(
    registry: &Value,
    mappings: &[(String, String)],
    release_root: &Path,
    verified: &Verified,
    home: &Path,
) -> Result<(), String> {
    for hook in registry["catalog"]["agentHooks"]
        .as_array()
        .into_iter()
        .flatten()
    {
        let Some(source) = hook["source"].as_str().filter(|s| !s.is_empty()) else {
            continue;
        };
        // A source under a mapped prefix lives where the mapping puts it;
        // any other is found where the release keeps the legacy roots.
        let mapped = mappings.iter().find_map(|(prefix, release_path)| {
            match Path::new(source).strip_prefix(prefix) {
                Ok(rest) => Some(joined(&release_root.join(release_path), rest)),
                Err(_elsewhere) => None,
            }
        });
        let candidate = match mapped {
            Some(candidate) => candidate,
            None => source_candidate(
                source,
                release_root,
                &verified.old_root,
                &verified.old_home,
                home,
            ),
        };
        if !candidate.is_file() {
            // A catalogue entry without an id is named by the entry itself,
            // not by an empty name.
            let named = match hook["id"].as_str() {
                Some(id) => id.to_string(),
                None => format!("a catalogue entry with no id ({hook})"),
            };
            return Err(format!(
                "Approved hook source is missing: {named}: {source} (looked for {})",
                candidate.display()
            ));
        }
    }
    Ok(())
}
