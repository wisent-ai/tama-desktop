//! The policy of `tama hook block-blocker-without-record`, a Stop gate.
//!
//! A blocker is an object every session shares: a record in Oko's blocker
//! register (`oko blockers record`), with the failed operation, its error and
//! what was tried, which Oko itself refuses when it waits on a decision. The
//! communication contract writes every answer as three headed parts in a fixed
//! order — what was done, the blockers, the next steps — and the last two are
//! where the operator reads what only he can do. So every item of those two
//! parts must name an open record of that register by its id. An item that
//! names none — a decision put to him, a build he could allow, work another
//! session is doing — is refused, and so is an item naming a record that is no
//! longer open. A part that holds one word, the contract's "none", passes.
//!
//! The parts are found by the answer's own structure, its headings and their
//! order, never by their wording; the register is read from Oko, never judged
//! by a model, so the gate holds while no model answers.

use std::process::{Command, Stdio};

use serde_json::Value;
use tama_hooks::session_record::{deny, last_assistant_message, read_payload};

use crate::assignment::rules::oko_cli;

/// The characters of a blocker's short id, the first group of its UUID.
// The group's length is the UUID format's: time_low is the first field of
// the string form, https://www.rfc-editor.org/rfc/rfc4122#section-3
const SHORT_ID_CHARS: usize = 8;

/// Whether a line is a markdown heading.
fn is_heading(line: &str) -> bool {
    line.trim_start().starts_with('#')
}

/// Every headed part of `said`, each as its items: one bullet with its
/// continuation lines, or one paragraph where the part has no bullets.
fn parts(said: &str) -> Vec<Vec<String>> {
    let mut parts: Vec<Vec<String>> = Vec::new();
    for line in said.lines() {
        if is_heading(line) {
            parts.push(Vec::new());
            continue;
        }
        let Some(items) = parts.last_mut() else {
            continue;
        };
        let trimmed = line.trim();
        let bullet = trimmed.starts_with("- ")
            || trimmed.starts_with("* ")
            || trimmed.split_once(". ").is_some_and(|(number, _)| {
                !number.is_empty() && number.chars().all(|c| c.is_ascii_digit())
            });
        if trimmed.is_empty() {
            if items.last().is_some_and(|item: &String| !item.is_empty()) {
                items.push(String::new());
            }
        } else if bullet || items.last().is_none_or(String::is_empty) {
            items.push(trimmed.to_string());
        } else if let Some(last) = items.last_mut() {
            last.push(' ');
            last.push_str(trimmed);
        }
    }
    for items in &mut parts {
        items.retain(|item| !item.is_empty());
    }
    parts
}

/// The blockers and next-steps parts: the last two of an answer written as
/// the contract's headed parts, what was done, the blockers and the next
/// steps; nothing for an answer with no part before those two.
fn guarded_parts(said: &str) -> Vec<Vec<String>> {
    let mut parts = parts(said);
    let Some(next_steps) = parts.pop() else {
        return Vec::new();
    };
    let Some(blockers) = parts.pop() else {
        return Vec::new();
    };
    if parts.is_empty() {
        return Vec::new();
    }
    vec![blockers, next_steps]
}

/// Whether a part says only that it is empty: one item of one word.
fn says_none(items: &[String]) -> bool {
    match items {
        [only] => {
            let mut words = only.trim_start_matches(['-', '*', ' ']).split_whitespace();
            words.next();
            words.next().is_none()
        }
        _ => items.is_empty(),
    }
}

/// The short ids an item names: every run of eight hexadecimal characters
/// standing alone or opening a UUID.
fn named_ids(item: &str) -> Vec<String> {
    item.split(|c: char| !(c.is_ascii_alphanumeric() || c == '-'))
        .filter_map(|word| word.split('-').next())
        .map(str::to_lowercase)
        .filter(|word| word.len() == SHORT_ID_CHARS && word.chars().all(|c| c.is_ascii_hexdigit()))
        .collect()
}

/// The short ids of every open record in Oko's blocker register.
fn open_blockers() -> Result<Vec<String>, String> {
    let program = oko_cli();
    let mut command = Command::new(&program);
    command
        .args(["blockers", "list", "--json"])
        .stdin(Stdio::null());
    let output = stado_wait::output(&mut command)
        .map_err(|error| format!("cannot run {program} blockers list --json: {error}"))?;
    if !output.status.success() {
        return Err(format!(
            "{program} blockers list --json exited {}: {}",
            output.status,
            String::from_utf8_lossy(&output.stderr).trim()
        ));
    }
    let records: Value = serde_json::from_slice(&output.stdout)
        .map_err(|error| format!("{program} blockers list --json is not JSON: {error}"))?;
    let records = records
        .as_array()
        .ok_or_else(|| format!("{program} blockers list --json printed no list: {records}"))?;
    Ok(records
        .iter()
        .filter_map(|record| record.get("id").and_then(Value::as_str))
        .filter_map(|id| id.split('-').next())
        .map(str::to_lowercase)
        .collect())
}

/// The items `said` writes in its blockers or next-steps part without naming
/// an open blocker record, each with the reason.
pub fn unrecorded(said: &str, open: &[String]) -> Vec<String> {
    let mut refused = Vec::new();
    for items in guarded_parts(said) {
        if says_none(&items) {
            continue;
        }
        for item in items {
            let named = named_ids(&item);
            if named.is_empty() {
                refused.push(format!("\"{item}\" names no blocker record"));
            } else if !named.iter().any(|id| open.contains(id)) {
                refused.push(format!(
                    "\"{item}\" names {}, none of them an open blocker record",
                    named.join(", ")
                ));
            }
        }
    }
    refused
}

pub fn run() {
    let payload = read_payload();
    // A stop with no assistant message has no parts to judge.
    let Some(said) = last_assistant_message(&payload) else {
        return;
    };
    if guarded_parts(said).iter().all(|items| says_none(items)) {
        return;
    }
    let open = match open_blockers() {
        Ok(open) => open,
        Err(reason) => {
            deny(format!(
                "BLOCKED: this answer lists blockers or next steps, and Oko's blocker register \
                 could not be read to check them: {reason}"
            ));
            return;
        }
    };
    let refused = unrecorded(said, &open);
    if refused.is_empty() {
        return;
    }
    deny(format!(
        "BLOCKED: every item of the blockers and next-steps parts must name an open record of \
         Oko's blocker register by its id, so the operator reads only what he alone can do and \
         every session reads the same blocker. Not so here:\n{}\nDo the work each item names; \
         record a real blocker with `oko blockers record` (Oko refuses a decision or a consent), \
         cite an open record from `oko blockers list`, or write the contract's one-word none.",
        refused
            .iter()
            .map(|line| format!("- {line}"))
            .collect::<Vec<_>>()
            .join("\n")
    ));
}
