use serde_json::Value;
use std::path::{Path, PathBuf};
use std::process::Command;

/// Who "we" are is whoever is signed in to GitHub here, and the
/// organisations that account belongs to. No organisation is built in: a
/// workshop under any account judges provenance against its own owners.
const SIGNED_IN_LOGIN: &str = "user";
const SIGNED_IN_ORGANISATIONS: &str = "user/orgs";
const GITHUB_REPOSITORY_API: &str = "repos";
// GitHub's fork provenance is stable; gh's bounded cache avoids a network call on every edit.
const PROVENANCE_CACHE: &str = "1h";
const DEPENDENCY_DIRECTORIES: &[&str] = &["node_modules", "site-packages", "Pods", "vendor"];

fn resolve(path: &Path, cwd: &Path) -> Result<PathBuf, String> {
    let absolute = if path.is_absolute() {
        path.to_path_buf()
    } else {
        cwd.join(path)
    };
    let mut existing = absolute.as_path();
    let mut suffix = Vec::new();
    while std::fs::symlink_metadata(existing).is_err() {
        suffix.push(
            existing
                .file_name()
                .ok_or("mutation path has no existing ancestor")?
                .to_owned(),
        );
        existing = existing
            .parent()
            .ok_or("mutation path has no existing ancestor")?;
    }
    let mut resolved = existing
        .canonicalize()
        .map_err(|error| format!("cannot resolve {}: {error}", existing.display()))?;
    for component in suffix.into_iter().rev() {
        resolved.push(component);
    }
    Ok(resolved)
}

/// The hosts gh is signed in to, as gh itself declares them: the top-level
/// keys of `hosts.yml` in its configuration directory (`GH_CONFIG_DIR`, else
/// `XDG_CONFIG_HOME/gh`, else `~/.config/gh`, as gh resolves it). No host is
/// built in: a workshop on any GitHub host judges its remotes by its own.
fn signed_in_hosts() -> Result<Vec<String>, String> {
    let directory = match (
        std::env::var_os("GH_CONFIG_DIR"),
        std::env::var_os("XDG_CONFIG_HOME"),
    ) {
        (Some(directory), _) => PathBuf::from(directory),
        (None, Some(config)) => PathBuf::from(config).join("gh"),
        (None, None) => crate::util::home_dir().join(".config").join("gh"),
    };
    let path = directory.join("hosts.yml");
    let text = std::fs::read_to_string(&path).map_err(|error| {
        format!(
            "the hosts gh is signed in to cannot be read from {}: {error}",
            path.display()
        )
    })?;
    let hosts: Vec<String> = text
        .lines()
        .filter(|line| !line.starts_with(char::is_whitespace) && !line.starts_with('#'))
        .filter_map(|line| line.trim_end().strip_suffix(':'))
        .map(|host| host.trim().to_owned())
        .filter(|host| !host.is_empty())
        .collect();
    if hosts.is_empty() {
        return Err(format!(
            "{} names no host gh is signed in to",
            path.display()
        ));
    }
    Ok(hosts)
}

/// The host and path a remote address names: `scheme://[user@]host[:port]/path`,
/// or the scp form `[user@]host:path`.
fn address(remote: &str) -> Option<(&str, &str)> {
    let (authority, path) = match remote.split_once("://") {
        Some((_, rest)) => rest.split_once('/')?,
        None => remote.split_once(':')?,
    };
    let host = authority.rsplit('@').next()?;
    let host = host.split(':').next()?;
    Some((host, path))
}

/// The `owner/name` of a remote on a host gh is signed in to; none for a
/// remote anywhere else or one whose path is not a repository.
fn github_repository<'a>(remote: &'a str, hosts: &[String]) -> Option<&'a str> {
    let (host, path) = address(remote)?;
    if !hosts.iter().any(|known| known.eq_ignore_ascii_case(host)) {
        return None;
    }
    let repository = path.trim_end_matches('/').trim_end_matches(".git");
    let mut parts = repository.split('/');
    let owner = parts.next()?;
    let name = parts.next()?;
    (!owner.is_empty()
        && !name.is_empty()
        && parts.next().is_none()
        && repository
            .chars()
            .all(|value| value.is_ascii_alphanumeric() || "-_/ .".contains(value))
        && !repository.contains(' '))
    .then_some(repository)
}

fn gh_lines(endpoint: &str, field: &str) -> Result<Vec<String>, String> {
    let mut command = Command::new("gh");
    command.args(["api", "--cache", PROVENANCE_CACHE, endpoint, "--jq", field]);
    let output = stado_wait::output(&mut command)
        .map_err(|error| format!("cannot ask GitHub for {endpoint}: {error}"))?;
    if !output.status.success() {
        return Err(format!(
            "GitHub {endpoint} failed: {}",
            String::from_utf8_lossy(&output.stderr).trim()
        ));
    }
    Ok(String::from_utf8_lossy(&output.stdout)
        .lines()
        .map(str::trim)
        .filter(|line| !line.is_empty())
        .map(str::to_owned)
        .collect())
}

/// The signed-in login and its organisations. A lookup that fails refuses
/// the edit with GitHub's own answer rather than guessing an owner.
fn our_owners() -> Result<Vec<String>, String> {
    let mut owners = gh_lines(SIGNED_IN_LOGIN, ".login")?;
    owners.extend(gh_lines(SIGNED_IN_ORGANISATIONS, ".[].login")?);
    if owners.is_empty() {
        return Err("GitHub names no signed-in account, so no repository owner is ours".into());
    }
    Ok(owners)
}

fn is_ours(owners: &[String], owner: &str) -> bool {
    owners.iter().any(|ours| ours.eq_ignore_ascii_case(owner))
}

fn source_owner(repository: &str) -> Result<Option<String>, String> {
    let owners = our_owners()?;
    if !repository
        .split('/')
        .next()
        .is_some_and(|owner| is_ours(&owners, owner))
    {
        return Ok(Some(repository.to_owned()));
    }
    let endpoint = format!("{GITHUB_REPOSITORY_API}/{repository}");
    let mut command = Command::new("gh");
    command.args(["api", "--cache", PROVENANCE_CACHE, &endpoint]);
    let result = stado_wait::output(&mut command)
        .map_err(|error| format!("cannot read GitHub provenance for {repository}: {error}"))?;
    if !result.status.success() {
        return Err(format!(
            "GitHub provenance for {repository} failed: {}",
            String::from_utf8_lossy(&result.stderr).trim()
        ));
    }
    let data: Value = serde_json::from_slice(&result.stdout)
        .map_err(|error| format!("invalid GitHub provenance for {repository}: {error}"))?;
    let owner = data
        .pointer("/owner/login")
        .and_then(Value::as_str)
        .ok_or("GitHub provenance has no repository owner")?;
    if !is_ours(&owners, owner) {
        let named = data["full_name"]
            .as_str()
            .ok_or("GitHub provenance has no repository full_name")?;
        return Ok(Some(named.to_owned()));
    }
    match data["fork"].as_bool() {
        Some(false) => Ok(None),
        Some(true) => {
            let source = data
                .pointer("/source/full_name")
                .or_else(|| data.pointer("/parent/full_name"))
                .and_then(Value::as_str)
                .ok_or("GitHub fork provenance has no upstream repository")?;
            if source
                .split('/')
                .next()
                .is_some_and(|owner| is_ours(&owners, owner))
            {
                Ok(None)
            } else {
                Ok(Some(source.to_owned()))
            }
        }
        None => Err("GitHub provenance has no fork status".into()),
    }
}

pub(super) fn refusal(path: &Path, cwd: &Path) -> Option<String> {
    match inspect(path, cwd) {
        Ok(None) => None,
        Ok(Some(reason)) => Some(format!("BLOCKED: {reason}. Do not patch externally owned source or installed dependencies. Use documented configuration, APIs or separately owned extensions; repair our integration instead. Use Jeden when the requirement would require changing OMP.")),
        Err(error) => Some(format!("BLOCKED: cannot establish source ownership for {}: {error}; no mutation was authorized", path.display())),
    }
}

fn inspect(path: &Path, cwd: &Path) -> Result<Option<String>, String> {
    let resolved = resolve(path, cwd)?;
    let text = resolved.to_string_lossy();
    if resolved.components().any(|part| {
        part.as_os_str()
            .to_str()
            .is_some_and(|name| DEPENDENCY_DIRECTORIES.contains(&name))
    }) || text.contains("/.cargo/registry/")
        || text.contains("/.build/checkouts/")
        || text.contains("/Carthage/Checkouts/")
    {
        return Ok(Some(format!(
            "{} resolves to installed dependency source {}",
            path.display(),
            resolved.display()
        )));
    }
    let Some(root) =
        tama_core::presence::checkout_root(&resolved).map_err(|error| error.to_string())?
    else {
        return Ok(None);
    };
    // Every remote the checkout declares, whatever it is called: a source
    // reached through a renamed remote is still the same source. git answers
    // a checkout with no remote at all with nothing on either stream.
    let remotes = ["config", "--get-regexp", r"^remote\..*\.url$"];
    let output = tama_core::git::Git::of(Some(root)).output(&remotes)?;
    if !output.status.success() && !(output.stdout.is_empty() && output.stderr.is_empty()) {
        return Err(format!(
            "git -C {} {} ended with {}: {}",
            root.display(),
            remotes.join(" "),
            output.status,
            String::from_utf8_lossy(&output.stderr).trim()
        ));
    }
    let listed = String::from_utf8_lossy(&output.stdout);
    // Read only for a checkout that declares a remote.
    let mut hosts: Option<Vec<String>> = None;
    for line in listed.lines() {
        let Some((name, remote)) = line.split_once(' ') else {
            return Err(format!(
                "unreadable remote line {line} at {}",
                root.display()
            ));
        };
        let remote = remote.trim();
        let known = match hosts.take() {
            Some(known) => known,
            None => signed_in_hosts()?,
        };
        let repository = github_repository(remote, &known).ok_or_else(|| {
            format!(
                "unsupported ownership provenance {name}={remote} at {}: it is no repository on a host gh is signed in to ({})",
                root.display(),
                known.join(", ")
            )
        });
        let repository = repository?.to_owned();
        hosts = Some(known);
        if let Some(owner) = source_owner(&repository)? {
            return Ok(Some(format!(
                "writing {} would modify {owner}, resolved through {name}={remote} at {}",
                resolved.display(),
                root.display()
            )));
        }
    }
    // An unpublished local repository has no third-party provenance. Ordinary
    // workspace and filesystem permissions still apply; no ownership is invented.
    Ok(None)
}
