//! The refusals read from a command's structure: an install whose failure
//! the register already describes, a compile while the build hold stands, a
//! Python run and a declared command path that recovers a session by hand.
//! What else a command does by hand, a process it ends among it, is read by
//! a model (`super::judged`).

mod installer;
mod recovery;
mod services;

pub(super) use installer::installer_refusal;
pub(super) use recovery::{path as recovery_path, refusal as recovery_refusal};
pub(super) use services::{compile_named, compile_refusal, python_run_refusal};
