//! An immutable source archive as the origin of a hook release's source.
//!
//! Tama Desktop's release entrypoint verifies a pinned `git archive` of the
//! hook source and unpacks it with a marker, `.tama-source-archive.json`,
//! naming the archive, its SHA-256 and its commit. The unpacked tree has no
//! `.git`; its identity is that commit, and every input must still be exactly
//! the archive's own — changed, missing and additional inputs are refused.

use std::collections::BTreeMap;
use std::io::Write;
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};

use serde_json::Value;

use super::{file_digest, input_entry, unpacked_paths};

pub(super) const MARKER: &str = ".tama-source-archive.json";
const MARKER_SCHEMA: u64 = 1;
const COMMIT_LENGTH: usize = 40;
const SHA256_LENGTH: usize = 64;
/// `git archive --prefix=tama/` roots every member here.
const ARCHIVE_PREFIX: &str = "tama";
const SCRATCH_PREFIX: &str = ".tama-source-verify-";
/// What `git get-tar-commit-id` reads: the pax global header record and the
/// record holding its `comment=<commit>` line, two 512-byte tar records.
const TAR_COMMIT_HEADER_BYTES: usize = 1024;

fn lowercase_hex(text: &str, length: usize) -> bool {
    text.len() == length
        && text
            .chars()
            .all(|c| c.is_ascii_digit() || ('a'..='f').contains(&c))
}

/// Run `program` with `input` on its standard input.
///
/// `input` is written whole before the output is read, so it must be small
/// enough to sit in the pipe: callers pass a header, never an archive.
fn piped(program: &str, arguments: &[&str], input: &[u8]) -> Result<std::process::Output, String> {
    Command::new(program)
        .args(arguments)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .and_then(|mut child| {
            if let Some(mut stdin) = child.stdin.take() {
                stdin.write_all(input)?;
            }
            stado_wait::child_output(child, format!("{program} {}", arguments.join(" ")))
        })
        .map_err(|error| format!("cannot run {program}: {error}"))
}

/// The commit `git archive` recorded in the archive's global header.
///
/// Only the header goes to git: the whole decompressed archive deadlocked
/// once gzip's output filled its pipe, and git closes its input after the
/// header, so writing more kills this process with SIGPIPE.
fn archive_commit(archive: &Path) -> Result<String, String> {
    let mut gzip = Command::new("gzip");
    gzip.arg("-dc").arg(archive);
    let unpacked =
        stado_wait::output(&mut gzip).map_err(|error| format!("cannot run gzip: {error}"))?;
    if !unpacked.status.success() {
        return Err(format!(
            "Immutable source archive is not gzip: {}: {}",
            archive.display(),
            String::from_utf8_lossy(&unpacked.stderr).trim()
        ));
    }
    let header = &unpacked.stdout[..unpacked.stdout.len().min(TAR_COMMIT_HEADER_BYTES)];
    let commit = piped("git", &["get-tar-commit-id"], header)?;
    // An archive with no commit header is git's failing exit with nothing
    // said; compared as an empty revision it was reported as a different one.
    if !commit.status.success() {
        return Err(format!(
            "git get-tar-commit-id finds no commit in {} ({}): {}",
            archive.display(),
            commit.status,
            String::from_utf8_lossy(&commit.stderr).trim()
        ));
    }
    Ok(String::from_utf8_lossy(&commit.stdout).trim().to_string())
}

/// Removes the scratch extraction however the comparison ends.
struct Scratch(PathBuf);

impl Drop for Scratch {
    fn drop(&mut self) {
        match std::fs::remove_dir_all(&self.0) {
            Err(error) if error.kind() != std::io::ErrorKind::NotFound => {
                eprintln!(
                    "tama: the source scratch {} is left behind: {error}",
                    self.0.display()
                );
            }
            _ => {}
        }
    }
}

/// The pinned commit and every source input the archive holds, keyed by path.
pub(super) fn archived_inputs(root: &Path) -> Result<(String, BTreeMap<String, Value>), String> {
    let marker = root.join(MARKER);
    let text = std::fs::read_to_string(&marker)
        .map_err(|error| format!("cannot read {}: {error}", marker.display()))?;
    let invalid = || format!("Invalid immutable source identity: {}", marker.display());
    let origin: Value = serde_json::from_str(&text).map_err(|_| invalid())?;
    let (Some(archive), Some(revision), Some(sha256)) = (
        origin["archive"].as_str(),
        origin["revision"].as_str(),
        origin["sha256"].as_str(),
    ) else {
        return Err(invalid());
    };
    if origin["schema"].as_u64() != Some(MARKER_SCHEMA)
        || !lowercase_hex(revision, COMMIT_LENGTH)
        || !lowercase_hex(sha256, SHA256_LENGTH)
    {
        return Err(invalid());
    }
    let archive = PathBuf::from(archive);
    if file_digest(&archive)? != sha256 {
        return Err(format!(
            "Immutable source archive digest changed: {}",
            archive.display()
        ));
    }
    if archive_commit(&archive)? != revision {
        return Err(format!(
            "Immutable source archive has a different Git revision: {}",
            archive.display()
        ));
    }
    let parent = root.parent().unwrap_or(root);
    let scratch = Scratch(parent.join(format!("{SCRATCH_PREFIX}{}", std::process::id())));
    // Leftovers of an earlier extraction would take part in the comparison.
    match std::fs::remove_dir_all(&scratch.0) {
        Err(error) if error.kind() != std::io::ErrorKind::NotFound => {
            return Err(format!("cannot clear {}: {error}", scratch.0.display()));
        }
        _ => {}
    }
    std::fs::create_dir_all(&scratch.0)
        .map_err(|error| format!("cannot create {}: {error}", scratch.0.display()))?;
    let mut tar = Command::new("tar");
    tar.arg("-xpzf").arg(&archive).arg("-C").arg(&scratch.0);
    let extracted =
        stado_wait::output(&mut tar).map_err(|error| format!("cannot run tar: {error}"))?;
    if !extracted.status.success() {
        return Err(format!(
            "Immutable source archive cannot be read: {}: {}",
            archive.display(),
            String::from_utf8_lossy(&extracted.stderr).trim()
        ));
    }
    let prefixed = scratch.0.join(ARCHIVE_PREFIX);
    let base = if prefixed.is_dir() {
        prefixed
    } else {
        scratch.0.clone()
    };
    let mut entries = BTreeMap::new();
    for relative in unpacked_paths(&base)? {
        let entry = input_entry(&base, &relative)?;
        entries.insert(relative, entry);
    }
    if entries.is_empty() {
        return Err(format!(
            "Immutable archive contains no Tama source inputs: {}",
            archive.display()
        ));
    }
    Ok((revision.to_string(), entries))
}
