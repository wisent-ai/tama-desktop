//! The adaptive doctor: evidence projection, the repair pipeline and its
//! command line.

pub mod cli;
pub mod evidence;
pub mod repair;
mod reports;
