//! Where a deletion needs no grant: inside a checkout's `.build/` or
//! `target/` folder that Git ignores, the build output a tool writes and
//! writes again. A tracked file is never under an ignored folder, so every
//! tracked file, every test among them, is outside it.

use std::path::{Component, Path, PathBuf};
use std::process::{Command, Stdio};

/// The folder names a checkout keeps its build output under.
const BUILD_FOLDERS: &[&str] = &[".build", "target"];
/// The characters a shell expands a word by.
const GLOB_CHARACTERS: &[char] = &['*', '?', '[', '{'];

/// Whether deleting what `word` names, read against `base`, stays inside an
/// ignored build folder. A word with a glob is judged by the folder before
/// its first expanded part, which every match lies inside.
pub(super) fn inside(base: &Path, word: &str) -> bool {
    let path = absolute(base, word);
    let mut fixed = PathBuf::new();
    let mut expanded = false;
    for component in path.components() {
        let text = component.as_os_str().to_string_lossy();
        if expanded {
            // A match is inside the fixed folder unless a later part climbs.
            if matches!(component, Component::ParentDir) {
                return false;
            }
            continue;
        }
        if text.contains(GLOB_CHARACTERS) {
            expanded = true;
            continue;
        }
        fixed.push(component);
    }
    match located(&fixed) {
        Some(real) => in_ignored_build_folder(&real),
        // Nothing there: the deletion removes nothing.
        None => true,
    }
}

/// `word` as an absolute path: `~` is the home, a relative word is read
/// against `base`.
pub(crate) fn absolute(base: &Path, word: &str) -> PathBuf {
    if word == "~" {
        return crate::util::home_dir();
    }
    if let Some(rest) = word.strip_prefix("~/") {
        return crate::util::home_dir().join(rest);
    }
    let path = Path::new(word);
    if path.is_absolute() {
        path.to_path_buf()
    } else {
        base.join(path)
    }
}

/// Where `path` really is: its folder with every link and `..` resolved,
/// then its own name, so a link is judged where it lies, not where it
/// points. `None` when nothing exists there.
fn located(path: &Path) -> Option<PathBuf> {
    if std::fs::symlink_metadata(path).is_err() {
        return None;
    }
    match (path.parent(), path.file_name()) {
        (Some(parent), Some(name)) => std::fs::canonicalize(parent)
            .ok()
            .map(|real| real.join(name)),
        _ => std::fs::canonicalize(path).ok(),
    }
}

/// Whether `real`, or a folder above it, is a build folder its checkout's
/// Git ignores.
fn in_ignored_build_folder(real: &Path) -> bool {
    real.ancestors().any(|folder| {
        folder
            .file_name()
            .and_then(|name| name.to_str())
            .is_some_and(|name| BUILD_FOLDERS.contains(&name))
            && folder
                .parent()
                .is_some_and(|checkout| ignored(checkout, folder))
    })
}

/// Whether Git, run in `checkout`, ignores `folder`: `git check-ignore -q`
/// ends 0 for an ignored path, 1 for one it keeps and 128 outside a
/// checkout (git-check-ignore(1), EXIT STATUS).
fn ignored(checkout: &Path, folder: &Path) -> bool {
    match Command::new("git")
        .arg("-C")
        .arg(checkout)
        .args(["check-ignore", "-q", "--"])
        .arg(folder)
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .status()
    {
        Ok(status) => status.success(),
        Err(error) => {
            eprintln!(
                "tama: git cannot run in {} to read whether it ignores {}: {error}",
                checkout.display(),
                folder.display()
            );
            false
        }
    }
}
