//! The identity of an Oko task reading, compared between the reading an
//! answer started from and the one its stop sees.

use serde_json::Value;
use tama_hooks::sha256::sha256_hex;

/// When a value was last observed, not what the ledger says. Oko rewrites
/// every qualification's `checkedAt` each time its control loop refreshes
/// the batch builds, which it does between the start and the end of a turn,
/// so a digest that covered it never matched the receipt `assignment show`
/// wrote and block-stale-assignment refused every stop.
const OBSERVATION_TIMES: &[&str] = &["checkedAt"];

/// The identity of what the ledger says: the index it came from and the
/// report without observation times. With `OKO_TRANSCRIPT_INDEX_PATH` unset
/// the reading came from Oko's own index, which the identity names as none.
pub fn ledger_digest(value: &Value) -> String {
    let mut identity = match std::env::var_os("OKO_TRANSCRIPT_INDEX_PATH") {
        Some(index) => index.into_encoded_bytes(),
        None => Vec::new(),
    };
    identity.push(b'\0');
    let mut stated = value.clone();
    strip_observation_times(&mut stated);
    serde_json::to_writer(&mut identity, &stated).expect("a JSON value always serialises");
    sha256_hex(&identity)
}

fn strip_observation_times(value: &mut Value) {
    match value {
        Value::Object(fields) => {
            fields.retain(|key, _| !OBSERVATION_TIMES.contains(&key.as_str()));
            fields.values_mut().for_each(strip_observation_times);
        }
        Value::Array(items) => items.iter_mut().for_each(strip_observation_times),
        _ => {}
    }
}
