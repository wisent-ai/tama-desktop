//! The one attestation primitive: every attestation Tama keeps — a session's
//! task attestation, a file justification, a CUA or SSH grant, a test
//! approval — is one record in one format, written and withdrawn through
//! `attest` and `withdraw` and read through `read`, in one ledger.
//!
//! The registries the gates read (`~/.shared-hooks/*_justifications.json`,
//! `~/.config/agent-policy/approved_tests.json`, the session attestation
//! records) stay where the hook catalogue declares them, as views each verb
//! writes beside the ledger, so no gate and no hook configuration changes.
//! A record names the view it was written to (`store`). Build consents are
//! the operator's answers kept in Oko and are read from Oko, not copied here.
//!
//! The ledger is `attestations/ledger.json` in Tama's state root, or the
//! file `TAMA_ATTESTATION_LEDGER` names. Every change takes the ledger's
//! lock, so two verbs never lose each other's record.

use std::fs::OpenOptions;
use std::path::PathBuf;

use serde::{Deserialize, Serialize};
use serde_json::Value;

/// The variable that moves the ledger.
pub const LEDGER_ENV: &str = "TAMA_ATTESTATION_LEDGER";

/// One attestation in the one format. `statement`, `scope` and `lifetime`
/// are the attester's own values; a kind that states none carries null.
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Attestation {
    /// Which claim: session, file, cua, ssh or test.
    pub kind: String,
    /// What is attested: a session id, a path, an application, a target.
    pub subject: String,
    pub statement: Value,
    /// The agent, for a record about its own work; the operator, for a
    /// consent or approval only he gives.
    pub attester: String,
    pub scope: Value,
    pub lifetime: Value,
    /// How it is checked: the transcript, the artifact, or a ruling.
    pub verification: String,
    /// The view the record was also written to, for the gate that reads it.
    pub store: String,
    pub recorded_at: String,
}

impl Attestation {
    /// Whether `other` is the same attestation: the same claim about the
    /// same subject in the same view, in the same words.
    fn same(&self, other: &Attestation) -> bool {
        self.kind == other.kind
            && self.subject == other.subject
            && self.store == other.store
            && self.statement == other.statement
    }
}

#[derive(Default, Serialize, Deserialize)]
struct Ledger {
    #[serde(default)]
    attestations: Vec<Attestation>,
}

/// Where the ledger is.
pub fn path() -> PathBuf {
    match std::env::var_os(LEDGER_ENV) {
        Some(file) if !file.is_empty() => PathBuf::from(file),
        _ => tama_hooks::session_control::tama_state_root()
            .join("attestations")
            .join("ledger.json"),
    }
}

/// Whether the ledger has ever been written: before `tama attestation
/// migrate` brings the views in, it holds nothing a view holds. A ledger
/// that cannot be examined is the error naming it, not one never written.
pub fn exists() -> Result<bool, String> {
    tama_core::presence::present(&path()).map_err(|error| error.to_string())
}

fn load(path: &std::path::Path) -> Result<Ledger, String> {
    match std::fs::read_to_string(path) {
        Ok(text) => serde_json::from_str(&text).map_err(|error| {
            format!(
                "the attestation ledger {} cannot be read: {error}",
                path.display()
            )
        }),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(Ledger::default()),
        Err(error) => Err(format!(
            "the attestation ledger {} cannot be read: {error}",
            path.display()
        )),
    }
}

/// Change the ledger under its lock and write it back; what `change` answered.
fn changed<R>(
    change: impl FnOnce(&mut Vec<Attestation>) -> Result<R, String>,
) -> Result<R, String> {
    let path = path();
    let folder = path
        .parent()
        .ok_or_else(|| format!("the attestation ledger {} has no folder", path.display()))?
        .to_path_buf();
    std::fs::create_dir_all(&folder).map_err(|error| {
        format!(
            "the attestation ledger's folder {} cannot be made: {error}",
            folder.display()
        )
    })?;
    let lock_path = path.with_extension("lock");
    let lock = OpenOptions::new()
        .create(true)
        .truncate(false)
        .write(true)
        .open(&lock_path)
        .map_err(|error| {
            format!(
                "the attestation ledger lock {} cannot be opened: {error}",
                lock_path.display()
            )
        })?;
    stado_wait::blocking(
        stado_wait::Kind::Lock,
        "the attestation ledger",
        path.display(),
        || lock.lock(),
    )
    .map_err(|error| {
        format!(
            "the attestation ledger {} cannot be locked: {error}",
            path.display()
        )
    })?;
    let mut ledger = load(&path)?;
    let answer = change(&mut ledger.attestations)?;
    let value = serde_json::to_value(&ledger)
        .map_err(|error| format!("the attestation ledger cannot be written out: {error}"))?;
    crate::util::atomic_write_json(&folder, &path, &value).map_err(|error| {
        format!(
            "the attestation ledger {} cannot be written: {error}",
            path.display()
        )
    })?;
    Ok(answer)
}

/// Every attestation the ledger holds, or those of `kind`.
pub fn read(kind: Option<&str>) -> Result<Vec<Attestation>, String> {
    Ok(load(&path())?
        .attestations
        .into_iter()
        .filter(|attestation| kind.is_none_or(|kind| attestation.kind == kind))
        .collect())
}

/// Keep `attestation`, replacing the same attestation recorded before;
/// whether it was new.
pub fn attest(attestation: Attestation) -> Result<bool, String> {
    changed(|all| {
        let before = all.len();
        all.retain(|kept| !kept.same(&attestation));
        let new = all.len() == before;
        all.push(attestation);
        Ok(new)
    })
}

/// Write the ledger as it stands, creating it empty when it has never been
/// written: what a migration that found no attestation leaves behind.
pub fn ensure() -> Result<(), String> {
    changed(|_| Ok(()))
}

/// Withdraw every attestation of `kind` in view `store` that `matches`
/// selects; how many were withdrawn.
pub fn withdraw(
    kind: &str,
    store: &str,
    matches: impl Fn(&Attestation) -> bool,
) -> Result<usize, String> {
    changed(|all| {
        let before = all.len();
        all.retain(|kept| !(kept.kind == kind && kept.store == store && matches(kept)));
        Ok(before - all.len())
    })
}
