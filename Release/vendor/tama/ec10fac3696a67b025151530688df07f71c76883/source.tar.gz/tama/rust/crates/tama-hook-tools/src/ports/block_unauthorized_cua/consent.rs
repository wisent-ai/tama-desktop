//! The consent sentence a refused CUA call hands the operator: the exact
//! words that, sent by him, become the grant this call needs, naming the
//! app the call drives and its action, so he never has to guess what to
//! say and the grant his words make covers exactly that call.
//!
//! The app is read from the call itself: the process a `pid` names, as `ps`
//! prints its program inside `<App>.app`; else an `<App>.app` path the call
//! carries; else the bundle id it launches. A call that names no app (the
//! driver's own `status`, `serve`, …) is named by the driver.

use std::process::Command;
use std::sync::LazyLock;

use regex::Regex;
use serde_json::Value;

use crate::ports::block_unauthorized_cua_detect as detect;
use crate::ports::pyvalue;
use crate::ports::tool_vocabulary::Call;
use crate::ports::transport_common as common;

const PS_BINARY: &str = "/bin/ps";
const CUA_TOOL: &str = "cua-driver";
/// An application bundle's folder in a path: its name between the slash
/// before it and `.app`.
static APP_FOLDER: LazyLock<Regex> =
    LazyLock::new(|| common::compile(r"/([^/\x22]+)\.app(?:/|\b)"));
/// A bundle id handed to the driver, as a JSON field or an option.
static BUNDLE_ID: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(r#"(?:"bundle_?id"\s*:\s*"|--bundle-id(?:=|\s+))([A-Za-z0-9.-]+)"#)
});

/// The app a running process belongs to, from the program `ps` names.
fn process_app(pid: &str) -> Option<String> {
    let mut probe = Command::new(PS_BINARY);
    probe.arg("-p").arg(pid).arg("-o").arg("command=");
    let output = stado_wait::output(&mut probe).ok()?;
    let program = String::from_utf8_lossy(&output.stdout).into_owned();
    let captures = APP_FOLDER.captures(&program)?;
    common::first_group(&captures).map(|name| name.as_str().to_string())
}

/// The app the CUA call in `payload` drives, as the operator names it.
pub(super) fn target_app(payload: &Value) -> Option<String> {
    let call = Call::of(payload);
    let probe = call.input().map(pyvalue::py_json_dumps).unwrap_or_default();
    let command = call.command().unwrap_or_default();
    let texts = [probe.as_str(), command];
    for text in texts {
        for found in detect::PID_RE.captures_iter(text) {
            if let Some(app) = common::first_group(&found).and_then(|pid| process_app(pid.as_str()))
            {
                return Some(app);
            }
        }
    }
    for pattern in [&*APP_FOLDER, &*BUNDLE_ID] {
        for text in texts {
            if let Some(found) = pattern
                .captures(text)
                .and_then(|captures| common::first_group(&captures))
            {
                return Some(found.as_str().to_string());
            }
        }
    }
    None
}

/// What the refusal of an ungranted call adds: the sentence the operator
/// sends, and how his sentence becomes the grant.
pub(super) fn sentence(payload: &Value) -> String {
    let action = detect::cua_action(payload).unwrap_or_else(|| CUA_TOOL.to_string());
    let spoken = action.replace('_', " ");
    let app = target_app(payload);
    let named = app.as_deref().unwrap_or(CUA_TOOL);
    format!(
        "To ask the operator once, give him this exact sentence to send, naming the app and \
         every action: \"Zgadzam się na CUA w aplikacji {named}: {spoken}, na czas tej sesji.\" \
         When he has sent it, record it word for word with `tama justify record --kind cua \
         --session <this session id> --app {named} --actions {action} --quote '<his exact \
         words>'` and request the session capability {{\"tool\": \"cua\"}}, which he confirms.{}",
        match app {
            Some(_) => String::new(),
            None => format!(
                " The call names no app, so the sentence names {CUA_TOOL}; a call that drives an \
                 app names it by its process id or bundle id."
            ),
        }
    )
}
