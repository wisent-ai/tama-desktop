//! Reading the key order of one top-level object straight out of the
//! registry text.

use std::fmt;

use serde::de::{DeserializeSeed, Deserializer, IgnoredAny, MapAccess, Visitor};

/// Extract the insertion order of keys of the object stored at top-level
/// `key` in raw JSON text. `serde_json` without `preserve_order` sorts map
/// keys, but JS `JSON.parse` preserves insertion order and the catalog output
/// depends on it, so the text is walked through serde's own map visitor,
/// which sees keys in the order they are written. A text without `key`, or
/// whose `key` holds no object, has no keys; text that cannot be walked is
/// refused with the parser's cause, never answered as no keys, which put
/// every event and adapter in the parsed map's alphabetical order unsaid.
pub(crate) fn top_level_object_key_order(text: &str, key: &str) -> Result<Vec<String>, String> {
    let mut deserializer = serde_json::Deserializer::from_str(text);
    let walked = TopLevel { key }.deserialize(&mut deserializer);
    match walked {
        Ok(Some(order)) => Ok(order),
        Ok(None) => Ok(Vec::new()),
        Err(error) => Err(format!(
            "the order of the {key} keys cannot be read from the registry text: {error}"
        )),
    }
}

/// The root object: finds `key` and reads its value's keys in order.
struct TopLevel<'k> {
    key: &'k str,
}

impl<'de> DeserializeSeed<'de> for TopLevel<'_> {
    type Value = Option<Vec<String>>;

    fn deserialize<D: Deserializer<'de>>(self, deserializer: D) -> Result<Self::Value, D::Error> {
        deserializer.deserialize_map(self)
    }
}

impl<'de> Visitor<'de> for TopLevel<'_> {
    type Value = Option<Vec<String>>;

    fn expecting(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
        formatter.write_str("a JSON object")
    }

    fn visit_map<A: MapAccess<'de>>(self, mut map: A) -> Result<Self::Value, A::Error> {
        let mut found = None;
        while let Some(entry) = map.next_key::<String>()? {
            if entry == self.key && found.is_none() {
                found = map.next_value_seed(ObjectKeys)?;
            } else {
                map.next_value::<IgnoredAny>()?;
            }
        }
        Ok(found)
    }
}

/// One object's keys, in the order they are written; `None` when the value
/// is not an object.
struct ObjectKeys;

impl<'de> DeserializeSeed<'de> for ObjectKeys {
    type Value = Option<Vec<String>>;

    fn deserialize<D: Deserializer<'de>>(self, deserializer: D) -> Result<Self::Value, D::Error> {
        deserializer.deserialize_any(self)
    }
}

impl<'de> Visitor<'de> for ObjectKeys {
    type Value = Option<Vec<String>>;

    fn expecting(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
        formatter.write_str("any JSON value")
    }

    fn visit_map<A: MapAccess<'de>>(self, mut map: A) -> Result<Self::Value, A::Error> {
        let mut keys = Vec::new();
        while let Some(entry) = map.next_key::<String>()? {
            map.next_value::<IgnoredAny>()?;
            keys.push(entry);
        }
        Ok(Some(keys))
    }

    fn visit_seq<A: serde::de::SeqAccess<'de>>(self, mut seq: A) -> Result<Self::Value, A::Error> {
        while seq.next_element::<IgnoredAny>()?.is_some() {}
        Ok(None)
    }

    fn visit_str<E>(self, _: &str) -> Result<Self::Value, E> {
        Ok(None)
    }

    fn visit_bool<E>(self, _: bool) -> Result<Self::Value, E> {
        Ok(None)
    }

    fn visit_i64<E>(self, _: i64) -> Result<Self::Value, E> {
        Ok(None)
    }

    fn visit_u64<E>(self, _: u64) -> Result<Self::Value, E> {
        Ok(None)
    }

    fn visit_f64<E>(self, _: f64) -> Result<Self::Value, E> {
        Ok(None)
    }

    fn visit_unit<E>(self) -> Result<Self::Value, E> {
        Ok(None)
    }
}
