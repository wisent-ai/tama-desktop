//! Whether a run of quoted words is a table the program keeps, or data it
//! hands to a call or back to its caller.

use std::sync::LazyLock;

use regex::Regex;

use super::super::super::transport_common as common;

/// A method call on the collection itself, whatever the language calls it.
static QUESTION: LazyLock<Regex> = LazyLock::new(|| common::compile("^[.\\?]\\s*\\p{L}+\\s*\\("));

/// Does the program keep this run of words, or consult it where it stands?
///
/// A classifier needs its words later: it binds them to a name, iterates
/// them, or asks the collection a question on the spot. Words handed to a
/// call are that call's data — the arguments of a command a test runs, the
/// three file descriptors in `spawn(cmd, { stdio: ['ignore', 'pipe',
/// 'pipe'] })` — and judging those made the guard cry wolf over
/// `runCLI(["tasks", "show", id])` in every journey there is. Words a
/// function returns are its caller's data the same way.
///
/// The walk leaves the collection outwards through its brackets, braces and
/// property keys, and stops at the first character that says what this text
/// is: `(` or `,` means an argument; a function body or a `return` means a
/// value the function produces; a binding, a `for … in`, or the start of a
/// statement means the program keeps it.
pub(super) fn kept_or_consulted(text: &str, start: usize, end: usize) -> bool {
    let before = text[..start].trim_end();
    // A binding keeps the run; `for … in` iterates it. Both are the shape
    // of a table the program consults.
    if before.ends_with('=') || before.ends_with(" in") {
        return true;
    }
    // Walk backwards out of whatever holds the collection. A closed group
    // in a sibling value — another call, another list, an arithmetic
    // expression — is skipped whole; an unclosed `[` or `{` is the
    // container this run sits in, so the walk steps out of it and keeps
    // going. What decides is `(`, which makes this an argument, the body
    // of a function or a `return`, which makes it a value the function
    // produces, or a statement boundary, which makes it something the
    // program keeps.
    let mut closed: Vec<char> = Vec::new();
    let mut handed_over = false;
    // Text inside a quoted literal is data, not code: a description that says
    // "harm; a hawk" holds no statement boundary. The walk goes backwards, so
    // an unescaped quote opens a literal that the next unescaped quote closes.
    let mut quoted = false;
    for (at, character) in before.char_indices().rev() {
        if character == '"' && !before[..at].ends_with('\\') {
            quoted = !quoted;
            continue;
        }
        if quoted {
            continue;
        }
        match character {
            ')' | ']' | '}' => closed.push(character),
            '(' if closed.is_empty() => {
                handed_over = true;
                break;
            }
            '{' | '[' if closed.is_empty() => {
                // `func … -> [String] { ["registry", "host", …] }`: a command
                // line a function hands back, not a table it keeps. The brace
                // of a function body follows its parameter list or its return
                // type — and a return type that is itself an array ends in
                // `]`, which is how Swift and TypeScript spell the very
                // function that builds a command line. A container a `return`
                // statement opens is the same value written out: the view a
                // function produces (a table's column headers, a card's
                // labels), handed to its caller.
                let outside = before[..at].trim_end();
                if returned(outside)
                    || (character == '{'
                        && (outside.ends_with(')')
                            || outside.ends_with('>')
                            || outside.ends_with(']')))
                {
                    handed_over = true;
                    break;
                }
                continue;
            }
            '(' | '[' | '{' => {
                closed.pop();
            }
            ';' | '=' if closed.is_empty() => break,
            _ => {}
        }
    }
    if !handed_over {
        return true;
    }
    let after = text[end..].trim_start();
    let after = match after.strip_prefix(']') {
        Some(rest) => rest.trim_start(),
        None => after,
    };
    // `["a", "b", "c"].contains(x)` asks the collection a question where it
    // stands, so it is a classifier even inside an argument list or a return.
    QUESTION.is_match(after)
}

/// Whether `outside` (the code before a container's opening bracket) ends in
/// the `return` keyword itself, not in a name that merely ends in its letters.
fn returned(outside: &str) -> bool {
    outside.strip_suffix("return").is_some_and(|head| {
        !head.ends_with(|character: char| {
            character.is_alphanumeric() || character == '_' || character == '$'
        })
    })
}
