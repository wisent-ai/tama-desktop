//! Logic for `tama-block-inline-execution`, registry hook
//! `block-inline-execution`: executable logic lives in a checked-in file that
//! can be reviewed, rerun and diffed — never in a command-line argument.
//!
//! Three ways a payload runs an inline program, and all three are refused:
//!
//!   * a tool whose whole purpose is inline execution — the evaluator, the
//!     notebook, the JavaScript kernel;
//!   * a tool that takes a program as an argument: a browser `run`, a
//!     debugger `evaluate`, or a write aimed at one of their devices;
//!   * a shell command carrying an interpreter program, a here-document, a
//!     process substitution, an `awk` or `jq` filter, or shell control flow.
//!
//! The first two are read from the tool's identity and its action field; a
//! write to a device whose arguments are not JSON is refused naming why.
//! The third is what the command does, read by a model (`patterns`) when the
//! command's syntax can carry source at all; a question the judge leaves
//! unanswered refuses with its cause (`model_judgement::unanswered`). The
//! refusal is the decision document the runner reads.

mod patterns;

use serde_json::Value;
use tama_hooks::session_record::read_payload;

use crate::ports::tool_vocabulary::{Call, WHOLE_FILE_TOOLS};

const RUN_ACTION: &str = "run";
const EVALUATE_ACTION: &str = "evaluate";
/// Tools that run the text handed to them, beyond the evaluation tools:
/// notebooks and the REPL device under its other names.
const ALWAYS_INLINE_TOOLS: &[&str] = &[
    "notebook",
    "functions.notebook",
    "node_repl",
    "node_repl/js",
];
const BROWSER_TOOLS: &[&str] = &["browser", "functions.browser"];
const DEBUG_TOOLS: &[&str] = &["debug", "functions.debug"];

const NODE_REPL_DEVICE: &str = "xd://mcp__node_repl_js";
const BROWSER_DEVICE: &str = "xd://browser";
const DEBUG_DEVICE: &str = "xd://debug";
const REFUSAL: &str = concat!(
    "BLOCKED: inline code execution is forbidden. ",
    "Put executable logic in a checked-in reusable file and run that file. ",
    "Detected: ",
);

/// What a write to the tool device `device` asks it to do: the operation in
/// the JSON arguments the write carries; nothing when the write carries no
/// text, and the refusal when that text is not JSON.
fn device_operation(call: &Call, device: &str) -> Result<Option<String>, String> {
    let Some(content) = call.content() else {
        return Ok(None);
    };
    let arguments: Value = serde_json::from_str(content).map_err(|error| {
        format!(
            "BLOCKED: the arguments written to {device} are not JSON ({error}), so what the device is asked to run cannot be read"
        )
    })?;
    let wrapped = serde_json::json!({ "input": arguments });
    Ok(Call::of(&wrapped).operation())
}

/// Why this payload is an inline program, if it is one; the error is the
/// whole refusal of a payload that cannot be read or a question the judge
/// left unanswered.
pub fn inline_execution_reason(payload: &Value) -> Result<Option<String>, String> {
    let call = Call::of(payload);
    if call.is_eval() || call.is_one_of(ALWAYS_INLINE_TOOLS) {
        let tool = match call.name() {
            Some(name) => name.to_lowercase(),
            None => String::new(),
        };
        return Ok(Some(format!("inline execution tool: {tool}")));
    }

    let action = call.operation();
    if call.is_one_of(BROWSER_TOOLS) && action.as_deref() == Some(RUN_ACTION) {
        return Ok(Some("inline JavaScript in browser run".to_string()));
    }
    if call.is_one_of(DEBUG_TOOLS) && action.as_deref() == Some(EVALUATE_ACTION) {
        return Ok(Some("inline debugger evaluation".to_string()));
    }

    if call.is_one_of(WHOLE_FILE_TOOLS) {
        let path = call.path();
        if path == Some(NODE_REPL_DEVICE) {
            return Ok(Some(
                "inline JavaScript in the Node REPL device".to_string(),
            ));
        }
        if let Some(device) = path.filter(|path| *path == BROWSER_DEVICE || *path == DEBUG_DEVICE) {
            let device_action = device_operation(&call, device)?;
            if path == Some(BROWSER_DEVICE) && device_action.as_deref() == Some(RUN_ACTION) {
                return Ok(Some("inline JavaScript in the browser device".to_string()));
            }
            if path == Some(DEBUG_DEVICE) && device_action.as_deref() == Some(EVALUATE_ACTION) {
                return Ok(Some(
                    "inline debugger evaluation through the debug device".to_string(),
                ));
            }
        }
    }

    let command = match call.command() {
        Some(command) => command.to_string(),
        None => match call.started_command() {
            Some(command) => command,
            None => return Ok(None),
        },
    };
    if command.is_empty() {
        return Ok(None);
    }
    // The model tells data from code itself, so it reads the command as
    // typed, quoted arguments included.
    Ok(patterns::inline_program(&command)?
        .map(|found| format!("inline program in a command: {found}")))
}

pub fn run() {
    match inline_execution_reason(&read_payload()) {
        Ok(None) => {}
        Ok(Some(reason)) => tama_hooks::session_record::refuse(&format!("{REFUSAL}{reason}")),
        Err(refusal) => tama_hooks::session_record::refuse(&refusal),
    }
}
