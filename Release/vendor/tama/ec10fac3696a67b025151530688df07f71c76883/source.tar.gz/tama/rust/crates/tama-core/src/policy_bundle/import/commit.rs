//! Writing an accepted bundle into the store: stage beside it, swap both
//! the bundle and the index into place, and put the old ones back if the
//! swap fails halfway.
//!
//! Split out of `policy_bundle.rs`, which had grown past the
//! three-hundred-line limit.

use std::fs::{self, OpenOptions};
use std::io::Write;
use std::path::Path;

use crate::Result;

use super::super::records::{BundleFileRecord, PolicyBundleRecord, Selection};
use super::super::store::{index_path, timestamp, transaction_id};
use super::super::{safe_join, set_mode};
use super::super::{PolicyBundleIndex, INACTIVE};

/// Copy the selected files into the store and record them in the index.
pub(super) fn commit(
    store: &Path,
    bundle_root: &Path,
    source: &Path,
    source_key: &str,
    selection: &Selection,
    index: &mut PolicyBundleIndex,
) -> Result<()> {
    let id = transaction_id()?;
    let stage_root = store.join(format!(".bundle-stage-{id}"));
    let backup_root = store.join(format!(".bundle-backup-{id}"));
    let stage_bundle = stage_root.join("bundle");
    for file in &selection.files {
        let destination = safe_join(&stage_bundle, &file.relative)?;
        if let Some(parent) = destination.parent() {
            fs::create_dir_all(parent)?;
        }
        let mut output = OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&destination)?;
        output.write_all(&file.bytes)?;
        output.flush()?;
        set_mode(&destination, file.mode)?;
    }

    let record = PolicyBundleRecord {
        source_key: source_key.to_string(),
        source_path: source.display().to_string(),
        source_digest: selection.digest.clone(),
        bundle_path: bundle_root.display().to_string(),
        imported_at_unix: timestamp()?,
        hook_count: selection.hook_count,
        activation: INACTIVE.to_string(),
        files: selection
            .files
            .iter()
            .map(|file| BundleFileRecord {
                path: file.relative.clone(),
                sha256: file.sha256.clone(),
                mode: file.mode,
            })
            .collect(),
    };
    index
        .bundles
        .retain(|bundle| bundle.source_key != source_key);
    index.bundles.push(record);
    index
        .bundles
        .sort_by(|left, right| left.source_path.cmp(&right.source_path));
    let staged_index = stage_root.join("index.json");
    fs::write(&staged_index, serde_json::to_vec_pretty(&index)?)?;
    set_mode(&staged_index, crate::OWNER_ONLY_FILE)?;

    fs::create_dir_all(store.join("bundles"))?;
    fs::create_dir_all(&backup_root)?;
    let current_index = index_path(store);
    let backup_bundle = backup_root.join("bundle");
    let backup_index = backup_root.join("index.json");
    let mut backed_bundle = false;
    let mut backed_index = false;
    let mut placed_bundle = false;
    let mut placed_index = false;
    let swap = (|| -> Result<()> {
        if crate::presence::present(bundle_root)? {
            fs::rename(bundle_root, &backup_bundle)?;
            backed_bundle = true;
        }
        if crate::presence::present(&current_index)? {
            fs::rename(&current_index, &backup_index)?;
            backed_index = true;
        }
        fs::rename(&stage_bundle, bundle_root)?;
        placed_bundle = true;
        fs::rename(&staged_index, &current_index)?;
        placed_index = true;
        Ok(())
    })();
    if let Err(error) = swap {
        // Every rollback step is checked: a restore that failed leaves the
        // previous bundle or index only in the backup, so the backup is kept
        // and named instead of being deleted with the stage.
        let mut unrestored: Vec<String> = Vec::new();
        if placed_index {
            if let Err(failure) = fs::remove_file(&current_index) {
                unrestored.push(format!("remove {}: {failure}", current_index.display()));
            }
        }
        if placed_bundle {
            if let Err(failure) = fs::remove_dir_all(bundle_root) {
                unrestored.push(format!("remove {}: {failure}", bundle_root.display()));
            }
        }
        if backed_index {
            if let Err(failure) = fs::rename(&backup_index, &current_index) {
                unrestored.push(format!("restore {}: {failure}", current_index.display()));
            }
        }
        if backed_bundle {
            if let Err(failure) = fs::rename(&backup_bundle, bundle_root) {
                unrestored.push(format!("restore {}: {failure}", bundle_root.display()));
            }
        }
        if let Err(failure) = fs::remove_dir_all(&stage_root) {
            unrestored.push(format!("remove stage {}: {failure}", stage_root.display()));
        }
        if !unrestored.is_empty() {
            return Err(format!(
                "{error}; the import could not be rolled back fully ({}); the previous bundle and index \
                 are kept in {}",
                unrestored.join("; "),
                backup_root.display()
            )
            .into());
        }
        if let Err(failure) = fs::remove_dir_all(&backup_root) {
            return Err(format!(
                "{error}; the import was rolled back, but its backup {} could not be removed: {failure}",
                backup_root.display()
            )
            .into());
        }
        return Err(error);
    }
    // The import is done; a stage or backup that stays is said, never dropped,
    // because each holds a full copy and nothing else ever removes it.
    for (what, leftover) in [("stage", &stage_root), ("backup", &backup_root)] {
        match fs::remove_dir_all(leftover) {
            Err(error) if error.kind() != std::io::ErrorKind::NotFound => eprintln!(
                "tama: the policy-bundle import {what} {} is left behind: {error}",
                leftover.display()
            ),
            _ => {}
        }
    }
    Ok(())
}
