//! Projection locks held by the kernel: one file per lock name, locked
//! exclusively with `File::lock`. The call returns once this process holds
//! the lock, and the kernel releases it when the holder drops the file or
//! exits, so a crashed holder needs no owner record, no liveness guess and
//! no retry loop.

use std::fs::{self, File, OpenOptions};
use std::path::{Path, PathBuf};

use super::super::Warn;

/// A held lock. Dropping it, or passing it to [`LockStore::release`],
/// releases the kernel lock.
pub struct LockOwnership {
    _file: File,
}

pub struct LockStore {
    lock_dir: PathBuf,
}

impl LockStore {
    pub fn open(state_dir: &Path, _warn: Warn) -> Self {
        LockStore {
            lock_dir: state_dir.join("projection-locks"),
        }
    }

    /// Hold the lock named `name`, waiting for the kernel to grant it. A
    /// failure to create the lock directory, open the lock file or lock it
    /// is returned with the path it concerned.
    pub fn acquire(&self, name: &str) -> std::io::Result<LockOwnership> {
        fs::create_dir_all(&self.lock_dir).map_err(|error| {
            std::io::Error::new(
                error.kind(),
                format!("cannot create {}: {error}", self.lock_dir.display()),
            )
        })?;
        let path = self.lock_dir.join(format!("{name}.lock"));
        let file = OpenOptions::new()
            .read(true)
            .write(true)
            .create(true)
            .truncate(false)
            .open(&path)
            .map_err(|error| {
                std::io::Error::new(
                    error.kind(),
                    format!("cannot open {}: {error}", path.display()),
                )
            })?;
        // Another holder may keep the lock; the wait says so while it lasts.
        stado_wait::blocking(
            stado_wait::Kind::Lock,
            format!("the projection lock {name}"),
            path.display(),
            || file.lock(),
        )
        .map_err(|error| {
            std::io::Error::new(
                error.kind(),
                format!("cannot lock {}: {error}", path.display()),
            )
        })?;
        Ok(LockOwnership { _file: file })
    }

    /// Release a held lock.
    pub fn release(&self, ownership: Option<LockOwnership>) {
        drop(ownership);
    }
}
