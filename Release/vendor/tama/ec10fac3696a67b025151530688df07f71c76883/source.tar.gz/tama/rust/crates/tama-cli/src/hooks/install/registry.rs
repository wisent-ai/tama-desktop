//! The registry an install writes to `~/.shared-hooks/registry.json`: every
//! path mapped from the checkout and home it was sealed for onto this home,
//! `node` commands pinned to the Node.js the install found, native commands
//! pinned to the stable runtime, and the checksum recomputed.

use std::collections::BTreeSet;
use std::path::{Path, PathBuf};
use std::process::Command;

use serde_json::{json, Value};
use tama_hook_tools::ports::python_stdlib::{shlex_join, shlex_quote, shlex_split};
use tama_hook_tools::registry::registry_checksum;

use super::verify::Verified;

const NODE_PROGRAM: &str = "node";
const PREFLIGHT: &str = "shared-hooks/node-runtime-preflight.cjs";
const VERSION_FLAG: &str = "--version";

/// The first Node.js on PATH that the release's own runtime preflight
/// accepts. The preflight states which Node.js the hooks need, so the
/// requirement is read from the release instead of restated here, and every
/// Node.js it refuses is named with what it said.
pub(super) fn require_supported_node(release_root: &Path) -> Result<(PathBuf, String), String> {
    let preflight = release_root.join(PREFLIGHT);
    if !preflight.is_file() {
        return Err(format!(
            "the approved hook release carries no Node.js runtime preflight at {}",
            preflight.display()
        ));
    }
    let path = std::env::var("PATH")
        .map_err(|error| format!("PATH cannot be read to find Node.js: {error}"))?;
    let mut seen = BTreeSet::new();
    let mut refused = Vec::new();
    for directory in std::env::split_paths(&path) {
        let candidate = directory.join(NODE_PROGRAM);
        if !candidate.is_file() || !seen.insert(candidate.clone()) {
            continue;
        }
        let mut check = Command::new(&candidate);
        check.arg(&preflight);
        let checked = match stado_wait::output(&mut check) {
            Ok(checked) => checked,
            Err(error) => {
                refused.push(format!("{} could not run: {error}", candidate.display()));
                continue;
            }
        };
        if !checked.status.success() {
            refused.push(format!(
                "{} ({}): {}",
                candidate.display(),
                checked.status,
                String::from_utf8_lossy(&checked.stderr).trim()
            ));
            continue;
        }
        let mut asked = Command::new(&candidate);
        asked.arg(VERSION_FLAG);
        let said = stado_wait::output(&mut asked).map_err(|error| {
            format!(
                "{} {VERSION_FLAG} could not run: {error}",
                candidate.display()
            )
        })?;
        if !said.status.success() {
            return Err(format!(
                "{} {VERSION_FLAG} failed ({}): {}",
                candidate.display(),
                said.status,
                String::from_utf8_lossy(&said.stderr).trim()
            ));
        }
        let version = String::from_utf8_lossy(&said.stdout).trim().to_string();
        let resolved = std::fs::canonicalize(&candidate)
            .map_err(|error| format!("cannot resolve {}: {error}", candidate.display()))?;
        return Ok((resolved, version));
    }
    if refused.is_empty() {
        return Err(format!(
            "no Node.js on PATH ({path}); the Tama hooks run on Node.js"
        ));
    }
    Err(format!(
        "no Node.js on PATH passes the release's runtime preflight: {}",
        refused.join("; ")
    ))
}

/// Replace each source prefix with its target in every string, quoting the
/// target inside `command` values; markers keep one replacement from
/// matching inside another's output.
fn transformed(value: &Value, replacements: &[(String, String)], field: Option<&str>) -> Value {
    match value {
        Value::String(text) => {
            let mut text = text.clone();
            let mut markers = Vec::new();
            for (index, (source, target)) in replacements.iter().enumerate() {
                let marker = format!("\u{0}TAMA_PATH_{index}\u{0}");
                text = text.replace(source.as_str(), &marker);
                let replacement = if field == Some("command") {
                    shlex_quote(target)
                } else {
                    target.clone()
                };
                markers.push((marker, replacement));
            }
            for (marker, target) in markers {
                text = text.replace(&marker, &target);
            }
            Value::String(text)
        }
        Value::Array(items) => Value::Array(
            items
                .iter()
                .map(|item| transformed(item, replacements, field))
                .collect(),
        ),
        Value::Object(object) => Value::Object(
            object
                .iter()
                .map(|(key, item)| (key.clone(), transformed(item, replacements, Some(key))))
                .collect(),
        ),
        other => other.clone(),
    }
}

fn pin_node_commands(registry: &mut Value, node: &Path, preflight: &Path) {
    let prefix = format!(
        "{} --require {}",
        shlex_quote(&node.to_string_lossy()),
        shlex_quote(&preflight.to_string_lossy())
    );
    let pin = |hooks: &mut Value| {
        for hook in hooks.as_array_mut().into_iter().flatten() {
            let command = hook
                .get("command")
                .and_then(Value::as_str)
                .map(str::to_string);
            if let Some(command) = command {
                if command == NODE_PROGRAM || command.starts_with("node ") {
                    let rest = &command[NODE_PROGRAM.len()..];
                    hook["command"] = json!(format!("{prefix}{rest}"));
                }
            }
        }
    };
    if let Some(events) = registry.get_mut("events").and_then(Value::as_object_mut) {
        for config in events.values_mut() {
            if let Some(hooks) = config.get_mut("hooks") {
                pin(hooks);
            }
        }
    }
    if let Some(hooks) = registry.pointer_mut("/catalog/agentHooks") {
        pin(hooks);
    }
}

fn pin_native_commands(
    value: &mut Value,
    native: &BTreeSet<String>,
    runtime: &Path,
    seen: &mut BTreeSet<String>,
) -> Result<(), String> {
    match value {
        Value::Object(object) => {
            let command = object
                .get("command")
                .and_then(Value::as_str)
                .map(str::to_string);
            if let Some(command) = command {
                let mut words = shlex_split(&command)
                    .filter(|words| !words.is_empty())
                    .ok_or_else(|| format!("Invalid hook command {command:?}"))?;
                let Some(program) = words.first_mut() else {
                    return Err(format!("Invalid hook command {command:?}"));
                };
                let name = Path::new(program.as_str())
                    .file_name()
                    .ok_or_else(|| {
                        format!("Hook command {command:?} runs {program:?}, which names no program")
                    })?
                    .to_string_lossy()
                    .to_string();
                if native.contains(&name) {
                    *program = runtime.join("bin").join(&name).display().to_string();
                    object.insert("command".to_string(), json!(shlex_join(&words)));
                    seen.insert(name);
                }
            }
            object
                .values_mut()
                .try_for_each(|nested| pin_native_commands(nested, native, runtime, seen))
        }
        Value::Array(items) => items
            .iter_mut()
            .try_for_each(|nested| pin_native_commands(nested, native, runtime, seen)),
        _ => Ok(()),
    }
}

/// The registry this home installs, and the Node.js preflight it pins.
pub(super) fn installed_registry(
    release_root: &Path,
    verified: &Verified,
    mappings: &[(String, String)],
    home: &Path,
    stable_runtime: &Path,
    node: &Path,
    native: &BTreeSet<String>,
) -> Result<(Value, std::path::PathBuf), String> {
    let mut replacements: Vec<(String, String)> = mappings
        .iter()
        .map(|(prefix, release_path)| {
            (
                prefix.clone(),
                stable_runtime.join(release_path).display().to_string(),
            )
        })
        .collect();
    let (root, old_home) = (&verified.old_root, &verified.old_home);
    for (from, to) in [
        (root.join("shared-hooks"), home.join(".shared-hooks")),
        (root.join("claude-hooks"), home.join(".claude/hooks")),
        (root.join("codex-hooks"), home.join(".codex/hooks")),
        (old_home.clone(), home.to_path_buf()),
    ] {
        replacements.push((from.display().to_string(), to.display().to_string()));
    }
    replacements.sort_by_key(|replacement| std::cmp::Reverse(replacement.0.len()));
    let preflight = stable_runtime.join(PREFLIGHT);
    if !release_root.join(PREFLIGHT).is_file() {
        return Err("Approved hook release is missing the Node.js runtime preflight".to_string());
    }
    let mut registry = transformed(&verified.registry, &replacements, None);
    pin_node_commands(&mut registry, node, &preflight);
    let mut pinned = BTreeSet::new();
    pin_native_commands(&mut registry, native, stable_runtime, &mut pinned)?;
    let unreferenced: Vec<&String> = native.difference(&pinned).collect();
    if !unreferenced.is_empty() {
        let unreferenced: Vec<&str> = unreferenced.iter().map(|name| name.as_str()).collect();
        return Err(format!(
            "Packaged native hook binaries are not referenced by the registry: {}",
            unreferenced.join(", ")
        ));
    }
    registry["releaseId"] = verified.release["releaseId"].clone();
    if let Some(catalog) = registry.get_mut("catalog").and_then(Value::as_object_mut) {
        catalog.remove("ompAdapters");
    }
    if let Some(object) = registry.as_object_mut() {
        object.remove("adapters");
    }
    registry["catalogChecksum"] = json!(registry_checksum(&registry));
    Ok((registry, preflight))
}
