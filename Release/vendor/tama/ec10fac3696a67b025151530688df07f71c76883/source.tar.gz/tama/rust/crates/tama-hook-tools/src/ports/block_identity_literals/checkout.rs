//! The written file's own checkout as a source of identities: what its
//! tracked files already carry.

use std::path::Path;

/// The values among `values` that a file the written path's own checkout
/// already tracks carries. A committed file is an artifact outside the
/// conversation that is writing now: it was written before this write,
/// through the same gate or before it existed, and a product's published
/// identifiers (a journey version id, a seed row's id) live there. Asked of
/// `git grep`, which reads only tracked files, once for every value of the
/// written file together: one search per value, with the walks behind each
/// miss, would hold an edit of a page carrying many identities past the hook
/// runner's limit. An address is also looked for as the identifier
/// that flattens it, every `@` and `.` a `-`: that is how such an identifier
/// is written and committed. The whole checkout is searched (`:/`), not only
/// the written file's folder: `git -C <folder> grep` reads that folder alone,
/// so a value tracked anywhere else in the repository would read as
/// unsourced. A
/// path outside any checkout (no ancestor holds `.git`) is not searched and
/// answers no value. Inside a checkout, a git that cannot start, ends on a
/// signal, or writes an error (a search that only found nothing writes none)
/// is the error, with its status and its own error output: the caller puts
/// it in every refusal of a value the checkout might have sourced, since
/// that refusal stands on a search that never answered.
pub fn tracked_in_checkout<'v>(
    path: &Path,
    values: impl IntoIterator<Item = &'v str>,
) -> Result<std::collections::HashSet<String>, String> {
    let mut tracked = std::collections::HashSet::new();
    let Some(directory) = path
        .parent()
        .and_then(|parent| parent.ancestors().find(|ancestor| ancestor.is_dir()))
    else {
        return Ok(tracked);
    };
    if tama_core::presence::checkout_root(directory)
        .map_err(|error| error.to_string())?
        .is_none()
    {
        return Ok(tracked);
    }
    let wanted: Vec<(String, String)> = values
        .into_iter()
        .map(|value| {
            (
                value.to_lowercase(),
                value.replace(['@', '.'], "-").to_lowercase(),
            )
        })
        .collect();
    if wanted.is_empty() {
        return Ok(tracked);
    }
    let mut args = vec![
        "grep",
        "--fixed-strings",
        "--ignore-case",
        "--only-matching",
        "-h",
    ];
    for (value, flattened) in &wanted {
        args.extend(["-e", value.as_str(), "-e", flattened.as_str()]);
    }
    args.extend(["--", ":/"]);
    // `git grep` that finds nothing ends unsuccessfully and says nothing, so
    // its output is read however it ended.
    let output = tama_core::git::Git::of(Some(directory)).output(&args)?;
    let failed =
        output.status.code().is_none() || (!output.status.success() && !output.stderr.is_empty());
    if failed {
        return Err(format!(
            "git grep in {} ended with {}: {}",
            directory.display(),
            output.status,
            String::from_utf8_lossy(&output.stderr).trim()
        ));
    }
    let found: std::collections::HashSet<String> = String::from_utf8_lossy(&output.stdout)
        .lines()
        .map(str::to_lowercase)
        .collect();
    for (value, flattened) in wanted {
        if found.contains(&value) || found.contains(&flattened) {
            tracked.insert(value);
        }
    }
    Ok(tracked)
}
