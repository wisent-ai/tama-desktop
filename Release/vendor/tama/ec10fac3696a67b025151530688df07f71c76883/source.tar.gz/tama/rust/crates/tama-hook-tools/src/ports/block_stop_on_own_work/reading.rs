//! What the answer says is read from the turn-end attestation it carries:
//! the claims `task_attestation/standards/turn.json` declares for this gate,
//! each in the answer word for word. No model reads the answer; a missing
//! claim refuses the ending and is named.

use super::HOOK;
use crate::ports::task_attestation::verbatim;

pub(super) fn refusal(answer: &str) -> Option<String> {
    let claims = match verbatim::turn_claims(HOOK) {
        Ok(claims) => claims,
        Err(error) => return Some(format!("{HOOK}: TAMA_HOOK_INFRASTRUCTURE: {error}")),
    };
    let missing = verbatim::refusal(claims, answer)?;
    Some(format!(
        "BLOCKED: {HOOK}: the answer this turn ends with does not carry its turn-end \
         attestation:\n{missing}\nCarry each claim word for word, and only when it is true: \
         while one is not, do the work it names instead of ending (`tama attestation standard \
         --turn` prints every claim)."
    ))
}
