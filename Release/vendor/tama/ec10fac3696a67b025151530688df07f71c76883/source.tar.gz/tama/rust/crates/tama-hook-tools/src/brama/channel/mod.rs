//! Whether a judge request may go out on its adapter, read from what this
//! machine and Brama declare, never from a guessed time limit:
//!
//! - Stado's resolver publishes every relayed connection still waiting for
//!   its service (`resolver-waiting.json`). A request is not added beside a
//!   waiting connection no running Tama hook owns: the refusal names the
//!   waiting requests and the hook processes that own them, from Tama's own
//!   register of requests in flight (`owner.rs`). Which connection is whose
//!   is read from the client address the resolver records for it, not from
//!   how many there are (`attribution.rs`). A connection a running hook owns
//!   is watched (below) and does not hold another hook's request back. A
//!   request whose hook process has ended is nobody's: its client
//!   is ended and the channel goes with the hook, so the next request is not
//!   held.
//! - Brama declares whether it can serve at all (`GET /readyz`). A Brama
//!   that declares itself not ready refuses the request in its own words
//!   before anything is sent, instead of leaving the request unanswered.
//! - While a request waits, Brama's readiness is asked on the same adapter
//!   (`watch.rs`) with the digest of the answer last read, and Brama answers
//!   once that answer changes; a Brama that stops declaring itself ready,
//!   or an adapter that stops answering readiness, ends the waiting client
//!   with that cause, so a request forwarded to a Brama that never answers
//!   does not wait without end. No guessed time limit is involved, and the
//!   watch makes one request per change of Brama's answer. The question it
//!   holds open is its hook's, as the judge request is (`attribution.rs`).

mod attribution;
mod owner;
mod watch;

use std::io::ErrorKind;
use std::process::{Child, Command, Stdio};

pub(super) use owner::{Held, CLIENT};
pub(super) use watch::Watch;

/// Stado resolver/report/waiting.rs publishes these fields, the bind and the
/// phase on every record; a record without them is refused by name when it
/// is decoded, since which adapter it holds would otherwise be unknown.
/// Unrelated newer fields remain tolerated.
#[derive(serde::Deserialize)]
struct PendingChannel {
    service: String,
    consumer: String,
    bind: String,
    active_host: String,
    endpoint: String,
    since: String,
    phase: String,
    /// The loopback address the held client connected from, which a newer
    /// resolver records: `lsof -nP -i :<port>` names the process holding it.
    client: Option<String>,
}

impl PendingChannel {
    /// The held connection in one sentence, with the client's port when the
    /// resolver recorded it.
    fn described(&self) -> String {
        let holder = match self.client_port() {
            Some((client, port)) => {
                format!(" held by the client at {client} (`lsof -nP -i :{port}` names its process)")
            }
            None => String::from(" whose client address the resolver did not record"),
        };
        format!(
            "service {} consumer {} phase {} to {} on {} since {}{holder}",
            self.service, self.consumer, self.phase, self.endpoint, self.active_host, self.since
        )
    }

    /// The client address the resolver recorded and its port, when it did.
    fn client_port(&self) -> Option<(&str, &str)> {
        let client = self.client.as_deref()?;
        client.rsplit_once(':').map(|(_, port)| (client, port))
    }
}

/// The `host:port` an endpoint `<scheme>://<authority>/…` is addressed to,
/// whatever its scheme: a resolver adapter serves plain HTTP on loopback,
/// and an endpoint of another scheme is read the same way, so it is checked
/// against the waiting connections rather than let through unread (none of
/// them is bound at a declared service's origin, so it passes by that, not
/// by its scheme). An endpoint without a scheme and authority is refused.
fn authority(endpoint: &str) -> Result<&str, String> {
    endpoint
        .split_once("://")
        .and_then(|(_, rest)| rest.split('/').next())
        .filter(|authority| !authority.is_empty())
        .ok_or_else(|| {
            format!(
                "judge endpoint {endpoint:?} names no scheme and authority to read its channel by"
            )
        })
}

/// Refuse to add a judge request to a resolver adapter on which a connection
/// waits that no running Tama hook owns, naming the waiting requests and
/// their owners. A connection a running hook owns is watched: its readiness
/// watch ends it once Brama stops declaring it serves, so it is a request
/// Brama is answering, not a dead channel, and another hook's request goes
/// out beside it after Brama's own readiness. A completed connection
/// disappears from Stado's published list; one whose hook ended is ended
/// here.
pub(super) fn check_channel(endpoint: &str) -> Result<(), String> {
    let authority = authority(endpoint)?;
    // The waiting connections are published beside the resolver's state.
    let path = super::route::published_state_path().with_file_name("resolver-waiting.json");
    let bytes = match std::fs::read(&path) {
        Ok(bytes) => bytes,
        Err(error) if error.kind() == ErrorKind::NotFound => return Ok(()),
        Err(error) => {
            return Err(format!(
                "cannot inspect resolver channel state {}: {error}",
                path.display()
            ));
        }
    };
    let waits: Vec<PendingChannel> = serde_json::from_slice(&bytes).map_err(|error| {
        format!(
            "cannot decode resolver channel state {}: {error}",
            path.display()
        )
    })?;
    let pending: Vec<_> = waits.iter().filter(|wait| wait.bind == authority).collect();
    if pending.is_empty() {
        return Ok(());
    }
    let owners = owner::holding(endpoint)?;
    let unwatched = attribution::unwatched(&pending, &owners)?;
    if unwatched.is_empty() {
        return Ok(());
    }
    let observed = pending
        .iter()
        .map(|wait| wait.described())
        .collect::<Vec<_>>()
        .join("; ");
    let owned = if owners.is_empty() {
        "no running Tama hook owns any of them: a judge request whose hook \
                 ended has had its client ended, so the connection is another \
                 consumer's or Stado's, to read with `stado resolver status`"
            .to_string()
    } else {
        format!(
            "running Tama hooks own {} request(s) ({}); {} of the connections is no \
             running hook's request: {}",
            owners.len(),
            owners
                .iter()
                .map(owner::Owner::described)
                .collect::<Vec<_>>()
                .join("; "),
            unwatched.len(),
            unwatched
                .iter()
                .map(|wait| wait.described())
                .collect::<Vec<_>>()
                .join("; ")
        )
    };
    Err(format!(
        "judge request to {endpoint} not started: resolver at {} reports {} unanswered \
         connection(s) on this adapter: {observed}; {owned}; another request is not sent \
         while a connection no running hook watches is waiting",
        path.display(),
        pending.len(),
    ))
}

/// Brama's readiness address beside `endpoint`: the same scheme and
/// authority, the `/readyz` path.
pub(in crate::brama) fn readiness_url(endpoint: &str) -> Result<String, String> {
    let Some((scheme, rest)) = endpoint.split_once("://") else {
        return Err(format!("the Brama endpoint {endpoint} names no scheme"));
    };
    let Some(authority) = rest.split('/').next() else {
        return Err(format!("the Brama endpoint {endpoint} names no host"));
    };
    Ok(format!("{scheme}://{authority}/readyz"))
}

/// Start asking Brama's own declaration that it can serve. With `after`,
/// the digest of the answer last read, Brama answers once its answer
/// differs from that one, so the client stands until then; its process is
/// returned so a watch that is over can end it.
pub(in crate::brama) fn ask_ready(readiness: &str, after: Option<&str>) -> Result<Child, String> {
    let question = match after {
        Some(digest) => format!("{readiness}?after={digest}"),
        None => readiness.to_owned(),
    };
    Command::new(CLIENT)
        .args([
            "--disable",
            "--silent",
            "--show-error",
            "--fail-with-body",
            &question,
        ])
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .map_err(|error| format!("cannot ask Brama at {readiness} whether it is ready: {error}"))
}

/// Brama's answer to a readiness question `client` asked: `/readyz` answers
/// its readiness report with a success status only when Brama declares
/// itself ready, and curl's `--fail-with-body` turns any error status into
/// a failed run carrying Brama's report. That report is the refusal. `Ok` is
/// Brama declaring itself ready, with the digest that names this answer,
/// `None` from a Brama that names none.
pub(in crate::brama) fn readiness_answer(
    endpoint: &str,
    readiness: &str,
    client: Child,
) -> Result<Option<String>, String> {
    let output = stado_wait::child_output(client, format!("Brama's readiness at {readiness}"))
        .map_err(|error| {
            format!("cannot read Brama's answer at {readiness} whether it is ready: {error}")
        })?;
    let body = String::from_utf8_lossy(&output.stdout);
    if !output.status.success() {
        return Err(format!(
            "judge request to {endpoint} not sent: Brama does not declare itself ready at \
             {readiness} ({}: {}): {}",
            output.status,
            String::from_utf8_lossy(&output.stderr).trim(),
            body.split_whitespace().collect::<Vec<_>>().join(" ")
        ));
    }
    let report: serde_json::Value = serde_json::from_str(&body).map_err(|error| {
        format!("Brama's readiness {readiness} answered a report that is not JSON: {error}")
    })?;
    match report.get("ready").and_then(serde_json::Value::as_bool) {
        Some(true) => Ok(report
            .get("digest")
            .and_then(serde_json::Value::as_str)
            .map(str::to_owned)),
        Some(false) => Err(format!(
            "judge request to {endpoint} not sent: Brama declares it serves no traffic at \
             {readiness}: {}",
            match report.get("reason").and_then(serde_json::Value::as_str) {
                Some(reason) => reason.to_owned(),
                None => report.to_string(),
            }
        )),
        None => Err(format!(
            "Brama's readiness {readiness} answered no boolean `ready`: {report}"
        )),
    }
}

/// Brama's readiness read before a request is sent.
pub(super) fn declared_ready(endpoint: &str) -> Result<(), String> {
    let readiness = readiness_url(endpoint)?;
    readiness_answer(endpoint, &readiness, ask_ready(&readiness, None)?).map(|_| ())
}
