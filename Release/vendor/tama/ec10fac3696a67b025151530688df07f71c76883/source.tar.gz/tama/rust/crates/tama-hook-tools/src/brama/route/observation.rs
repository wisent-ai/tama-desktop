//! Persist missing fleet declarations through Oko's model-independent intake.

use std::io::Write;
use std::process::{Command, Stdio};

use serde::Deserialize;
use serde_json::json;

#[derive(Deserialize)]
struct Receipt {
    source: String,
}

pub(super) fn record(
    machine: &str,
    service: &str,
    consumer: &str,
    cause: &str,
    state: &str,
) -> Result<String, String> {
    let program = crate::assignment::rules::oko_cli();
    let operation = format!("{program} reflection observe --input - --json");
    let body = serde_json::to_vec(&json!({
        "product": "stado", "machine": machine, "service": service,
        "operation": format!("service directory connect {service} --consumer {consumer}"),
        "cause": cause, "state": state,
    }))
    .map_err(|error| format!("cannot encode route observation: {error}"))?;
    let mut child = Command::new(&program)
        .args(["reflection", "observe", "--input", "-", "--json"])
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .map_err(|error| format!("{operation} did not start: {error}"))?;
    let supplied = match child.stdin.take() {
        Some(mut input) => input
            .write_all(&body)
            .map_err(|error| format!("{operation} input failed: {error}")),
        None => Err(format!("{operation} has no stdin pipe")),
    };
    if let Err(mut cause) = supplied {
        if let Err(error) = child.kill() {
            cause.push_str(&format!("; cannot terminate intake child: {error}"));
        }
        if let Err(error) = stado_wait::child_output(child, &operation) {
            cause.push_str(&format!("; cannot reap intake child: {error}"));
        }
        return Err(cause);
    }
    let output = stado_wait::child_output(child, &operation)
        .map_err(|error| format!("{operation} failed: {error}"))?;
    if !output.status.success() {
        return Err(format!(
            "{operation} exited {}: {}; response: {}",
            output.status,
            String::from_utf8_lossy(&output.stderr).trim(),
            String::from_utf8_lossy(&output.stdout).trim()
        ));
    }
    let receipt: Receipt = serde_json::from_slice(&output.stdout)
        .map_err(|error| format!("{operation} returned no observation receipt: {error}"))?;
    if receipt.source.trim().is_empty() {
        return Err(format!("{operation} returned an empty source identity"));
    }
    Ok(receipt.source)
}
