//! Whether a repository file run through a plain interpreter can start another
//! program, read from the modules it loads rather than from the interpreter.
//!
//! `node <file>.mjs` is not proof of a non-build: jeden's `test:context` script
//! runs a `.mjs` file that itself spawns `cargo test`, and entitlements-rotator's
//! `test` runs assertion files without `--test`. A file is cleared only when
//! every module it loads, followed through relative imports, is a runtime
//! builtin that neither starts a process nor asserts. A package import, a
//! load whose target is not a string literal, and a file that cannot be read
//! keep the script a build.

use std::collections::HashSet;
use std::path::{Path, PathBuf};

use super::super::vocabulary::{has, VOCABULARY};

/// Whether `file`, relative to `cwd`, and every file it loads start no program.
pub(super) fn spawns_nothing(cwd: &Path, file: &str) -> bool {
    let words = &*VOCABULARY;
    let mut seen: HashSet<PathBuf> = HashSet::new();
    let mut pending = vec![cwd.join(file)];
    while let Some(path) = pending.pop() {
        let path = match path.canonicalize() {
            Ok(path) => path,
            Err(error) => {
                eprintln!(
                    "block-one-off-repairs: {} cannot be resolved, so the script that loads it is judged a build: {error}",
                    path.display()
                );
                return false;
            }
        };
        if !seen.insert(path.clone()) {
            continue;
        }
        let text = match std::fs::read_to_string(&path) {
            Ok(text) => text,
            Err(error) => {
                eprintln!(
                    "block-one-off-repairs: {} cannot be read, so the script that loads it is judged a build: {error}",
                    path.display()
                );
                return false;
            }
        };
        let Some(specifiers) = specifiers(&text) else {
            return false;
        };
        let Some(dir) = path.parent() else {
            return false;
        };
        for specifier in specifiers {
            let relative = words
                .script_file_relative_prefixes
                .iter()
                .any(|prefix| specifier.starts_with(prefix.as_str()));
            if relative {
                pending.push(dir.join(specifier));
            } else if !specifier.starts_with(words.script_file_builtin_prefix.as_str())
                || has(&words.script_file_process_modules, specifier)
                || has(&words.script_file_test_modules, specifier)
            {
                return false;
            }
        }
    }
    true
}

/// Every module specifier `text` loads, or `None` when a call-form load
/// (`import(x)`, `require(x)`, `getBuiltinModule(x)`) takes anything but one
/// whole literal: `import('node:' + name)` is an expression, not `node:`.
fn specifiers(text: &str) -> Option<Vec<&str>> {
    let mut found = Vec::new();
    for loader in &VOCABULARY.script_file_loaders {
        for (at, _) in text.match_indices(loader.as_str()) {
            if text[..at]
                .chars()
                .next_back()
                .is_some_and(|c| is_ident(c) || is_quote(c))
            {
                continue;
            }
            let rest = &text[at + loader.len()..];
            if rest.chars().next().is_some_and(is_word) {
                continue;
            }
            let rest = rest.trim_start();
            let (call, rest) = match rest.strip_prefix('(') {
                Some(inner) => (true, inner.trim_start()),
                None => (false, rest),
            };
            let whole = literal(rest)
                .filter(|(_, after)| !call || after.trim_start().starts_with([')', ',']));
            match whole {
                Some((specifier, _)) => found.push(specifier),
                None if call => return None,
                None => {}
            }
        }
    }
    Some(found)
}

/// The quoted string `text` starts with and what follows its closing quote,
/// refusing one that interpolates.
fn literal(text: &str) -> Option<(&str, &str)> {
    let quote = text
        .chars()
        .next()
        .filter(|c| matches!(c, '"' | '\'' | '`'))?;
    let body = &text[1..];
    let end = body.find(quote)?;
    let specifier = &body[..end];
    (!specifier.contains("${")).then_some((specifier, &body[end + 1..]))
}

/// A character continuing an identifier; a loader preceded by `.` is still
/// read (`process.getBuiltinModule(...)`).
fn is_ident(c: char) -> bool {
    c.is_alphanumeric() || matches!(c, '_' | '$')
}

/// A character opening a string: a loader word right after one is the
/// string's text (`operation === "import"`), not a load.
fn is_quote(c: char) -> bool {
    matches!(c, '"' | '\'' | '`')
}

/// A character after a loader that makes it another name (`import.meta`).
fn is_word(c: char) -> bool {
    is_ident(c) || c == '.'
}
