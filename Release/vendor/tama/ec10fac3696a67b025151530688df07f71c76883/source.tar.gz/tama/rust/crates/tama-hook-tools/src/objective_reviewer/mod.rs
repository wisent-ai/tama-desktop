//! The Tama objective reviewer: what the user asked for, what the turn did,
//! and one authorization verdict. The gateway it asks lives in
//! `crate::brama`, which every Wisent component shares.

pub mod stop;

use serde::Serialize;
use serde_json::{json, Value};
use std::io::{BufRead, BufReader};
use std::path::PathBuf;
use tama_hooks::session_record::session_id_of;

#[derive(Serialize)]
pub struct ReviewContext {
    pub user_contract: Vec<String>,
    pub turn_evidence: Vec<String>,
    pub failed_tool_evidence: Vec<String>,
    pub last_assistant_message: String,
}

pub fn context(payload: &Value) -> Result<ReviewContext, String> {
    let path = match payload.get("transcript_path") {
        Some(Value::String(path)) if !path.is_empty() => PathBuf::from(path),
        Some(value) => {
            return Err(format!(
                "objective review transcript_path must be a nonempty string, received {value}"
            ));
        }
        None => transcript_path(&session_id_of(payload))?
            .ok_or("no transcript was found for the objective review session")?,
    };
    let mut context = contract_from_transcript(&path)?;
    if let Some(message) = payload
        .get("last_assistant_message")
        .and_then(Value::as_str)
        .filter(|message| !message.trim().is_empty())
    {
        context.last_assistant_message = message.to_owned();
    }
    Ok(context)
}

/// The session's newest transcript, found by the one locator every gate uses
/// (`tama_hooks::session_record::transcript_path`, every harness's session
/// folders; a folder it cannot read is named on stderr). A review with no
/// session identity has nothing to look for.
fn transcript_path(session: &str) -> Result<Option<PathBuf>, String> {
    if session.is_empty() {
        return Err("objective review has neither transcript_path nor session identity".to_owned());
    }
    Ok(tama_hooks::session_record::transcript_path(session))
}

fn text_content(message: &Value) -> String {
    if let Some(text) = message.get("content").and_then(Value::as_str) {
        return text.to_owned();
    }
    let Some(items) = message.get("content").and_then(Value::as_array) else {
        return String::new();
    };
    items
        .iter()
        .filter_map(|item| item.get("text").and_then(Value::as_str))
        .collect::<Vec<_>>()
        .join("\n")
}

fn record_message(record: &Value) -> Option<(&str, String)> {
    if let Some(message) = record.get("message").filter(|message| message.is_object()) {
        let role = message.get("role").and_then(Value::as_str)?;
        return Some((role, text_content(message)));
    }
    let kind = record.pointer("/payload/type").and_then(Value::as_str)?;
    let data = record.pointer("/payload/data")?;
    match kind {
        "user" => data
            .get("task")
            .and_then(Value::as_str)
            .map(|text| ("user", text.to_string())),
        "tool_result" => data
            .get("replayMessage")
            .and_then(Value::as_str)
            .map(|text| ("toolResult", text.to_string())),
        _ => None,
    }
}

fn contract_from_transcript(path: &PathBuf) -> Result<ReviewContext, String> {
    let file = std::fs::File::open(path).map_err(|error| {
        format!(
            "cannot open objective transcript {}: {error}",
            path.display()
        )
    })?;
    let mut users = Vec::new();
    let mut current_turn_evidence = Vec::new();
    let mut failed_tool_evidence = Vec::new();
    let mut last_assistant_message = String::new();
    for line in BufReader::new(file).lines() {
        let line = line.map_err(|error| {
            format!(
                "cannot read objective transcript {}: {error}",
                path.display()
            )
        })?;
        let record = serde_json::from_str::<Value>(&line).map_err(|error| {
            format!(
                "cannot decode objective transcript {}: {error}",
                path.display()
            )
        })?;
        let Some((role, text)) = record_message(&record) else {
            continue;
        };
        match role {
            "user" => {
                if !text.trim().is_empty() {
                    users.push(text);
                }
                current_turn_evidence.clear();
                failed_tool_evidence.clear();
                last_assistant_message.clear();
            }
            "toolResult" => {
                if !text.trim().is_empty() {
                    let message = record.get("message");
                    let failed = message
                        .and_then(|message| message.get("isError"))
                        .and_then(Value::as_bool)
                        == Some(true);
                    let evidence = match message
                        .and_then(|message| message.get("toolName"))
                        .and_then(Value::as_str)
                    {
                        Some(tool) => format!("{tool} (isError={failed}): {text}"),
                        None => format!("a tool result naming no tool (isError={failed}): {text}"),
                    };
                    if failed {
                        failed_tool_evidence.push(evidence.clone());
                    }
                    current_turn_evidence.push(evidence);
                }
            }
            "assistant" if !text.trim().is_empty() => {
                last_assistant_message = text;
            }
            _ => {}
        }
    }
    if users.is_empty() {
        return Err(format!(
            "no user-authored contract was found in objective transcript {}",
            path.display()
        ));
    }
    Ok(ReviewContext {
        user_contract: users,
        turn_evidence: current_turn_evidence,
        failed_tool_evidence,
        last_assistant_message,
    })
}

/// The key a reviewer's decision is answered under, and the two decisions.
pub const DECISION: &str = "decision";
pub const PASS: &str = "pass";
pub const BLOCK: &str = "block";
/// The key a blocking reviewer's reason is answered under.
const REASON: &str = "reason";
/// The name the verdict schema is sent under.
const VERDICT_NAME: &str = "tama_review_verdict";

/// What a reviewer decided about an action or an answer: it passes, or it is
/// blocked for the reason the reviewer gave.
#[derive(Debug, PartialEq, Eq)]
pub enum Verdict {
    Pass,
    Block(String),
}

/// A reviewer's decision as a schema property: `pass` or `block`.
pub fn decision_property() -> Value {
    json!({ "type": "string", "enum": [PASS, BLOCK] })
}

/// The schema a verdict is bound to: the decision, and the reason a block
/// gives (null on a pass).
fn verdict_schema() -> Value {
    json!({
        "type": "object",
        "additionalProperties": false,
        "properties": {
            DECISION: decision_property(),
            REASON: { "type": ["string", "null"] },
        },
        "required": [DECISION, REASON],
    })
}

/// The reviewer's answer to `evidence` under `system_prompt`, bound by the
/// strict JSON schema `schema` named `name`, through this machine's route.
pub fn judged(
    system_prompt: &str,
    evidence: &str,
    name: &str,
    schema: &Value,
) -> Result<Value, String> {
    crate::brama::request::object(
        &crate::brama::credentials::model_route()?,
        system_prompt,
        evidence,
        name,
        schema,
    )
}

/// The verdict a reviewer gives on `evidence` under `system_prompt`, bound
/// to a decision and a reason rather than read out of a line of prose. A
/// block that gives no reason, or an answer that decides neither, is the
/// refusal with what the reviewer sent, never read as a pass.
pub fn verdict(system_prompt: &str, evidence: &str) -> Result<Verdict, String> {
    let answer = judged(system_prompt, evidence, VERDICT_NAME, &verdict_schema())?;
    let reason = answer
        .get(REASON)
        .and_then(Value::as_str)
        .map(str::trim)
        .filter(|reason| !reason.is_empty());
    match (answer.get(DECISION).and_then(Value::as_str), reason) {
        (Some(PASS), _) => Ok(Verdict::Pass),
        (Some(BLOCK), Some(reason)) => Ok(Verdict::Block(reason.to_owned())),
        (Some(BLOCK), None) => Err(format!(
            "Brama reviewer blocked without a reason: {answer}"
        )),
        _ => Err(format!(
            "Brama reviewer returned no valid verdict; expected {DECISION} {PASS} or {BLOCK}: {answer}"
        )),
    }
}
