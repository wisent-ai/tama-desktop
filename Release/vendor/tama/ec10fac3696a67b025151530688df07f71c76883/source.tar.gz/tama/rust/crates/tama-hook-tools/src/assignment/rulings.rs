//! The operator's rulings on tasks and defects, read from Oko's ruling
//! register (`oko rulings`) by the identity of what they decide.
//!
//! A standing rule says how to work; a ruling says what was decided about
//! one item: a build consent given, a request refused, what counts as a
//! blocker. A session that did not hear a ruling asks him again, and
//! several sessions can re-raise the same ruled matter in one week. The
//! register is a file on this machine, read without running Oko
//! (`tama_hooks::oko_rulings`), so a hook stays inside its time.

use crate::ports::block_off_task_work::TaskScope;

/// The characters of the short defect id Oko prints (`oko defects list`),
/// which is also the first group of the whole id: a UUID's time_low field,
/// https://www.rfc-editor.org/rfc/rfc9562#section-4
const SHORT_ID_CHARS: usize = 8;

/// The ruling that stands on one subject.
pub struct Standing {
    /// The ruling's own identity in Oko's register.
    pub id: String,
    pub subject: String,
    pub session: String,
    pub ordinal: i64,
    pub said: String,
}

/// The newest ruling on every subject any ruling decides, the newest first.
/// No file is no ruling; a file that cannot be read is named.
pub fn standing() -> Result<Vec<Standing>, String> {
    let mut standing: Vec<Standing> = Vec::new();
    for ruling in tama_hooks::oko_rulings::rulings()? {
        for subject in &ruling.subjects {
            if !standing.iter().any(|held| &held.subject == subject) {
                standing.push(Standing {
                    id: ruling.id.clone(),
                    subject: subject.clone(),
                    session: ruling.session.clone(),
                    ordinal: ruling.ordinal,
                    said: ruling.said.clone(),
                });
            }
        }
    }
    Ok(standing)
}

/// The rulings standing on open work, one line each: a defect named by id,
/// or a task whose ledger line carries the task identity. An unreadable
/// register is one line saying so, never silence.
pub fn on_open_work(defect_ids: &[&str], task_lines: &[String]) -> Vec<String> {
    let standing = match standing() {
        Ok(standing) => standing,
        Err(reason) => return vec![format!("the ruling register could not be read: {reason}")],
    };
    standing
        .iter()
        .filter(|held| {
            defect_ids.iter().any(|id| names(&held.subject, id))
                || task_lines.iter().any(|line| line.contains(&held.subject))
        })
        .map(|held| {
            format!(
                "{} ({} #{}): {}",
                held.subject,
                held.session,
                held.ordinal,
                held.said.replace('\n', " ")
            )
        })
        .collect()
}

/// Whether `named` (a task identity, a whole defect id or its short form,
/// with or without `defect-`) names the subject `held`.
pub fn names(held: &str, named: &str) -> bool {
    let named = named.trim().trim_start_matches("defect-").to_lowercase();
    !named.is_empty() && held.to_lowercase().starts_with(&named)
}

/// The identities `text` names: task identities (`task-` and hex), whole
/// defect ids and their short form, with or without `defect-`.
fn identities(text: &str) -> Vec<String> {
    text.split(|c: char| !(c.is_ascii_alphanumeric() || c == '-'))
        .map(|word| word.trim_matches('-').to_lowercase())
        .filter(|word| {
            let bare = word.trim_start_matches("defect-");
            // The text before the first dash; `split` always yields it.
            let hex_head = match bare.split('-').next() {
                Some(head) => head,
                None => bare,
            };
            word.starts_with("task-")
                || (!hex_head.is_empty()
                    && hex_head.chars().all(|c| c.is_ascii_hexdigit())
                    && hex_head.chars().any(|c| c.is_ascii_digit())
                    && hex_head.len() == SHORT_ID_CHARS)
        })
        .collect()
}

/// The standing rulings whose subject `text` names, one line each with the
/// operator's words: what an answer would tell him about something he already
/// decided. An unreadable register is the error.
pub fn retold(text: &str) -> Result<Vec<String>, String> {
    let named = identities(text);
    if named.is_empty() {
        return Ok(Vec::new());
    }
    Ok(standing()?
        .iter()
        .filter(|held| named.iter().any(|id| names(&held.subject, id)))
        .map(|held| {
            format!(
                "{} ({} #{}): «{}»",
                held.subject,
                held.session,
                held.ordinal,
                held.said.replace('\n', " ")
            )
        })
        .collect())
}

/// Required rulings context; an unreadable register is not restored context.
/// One message often rules on several subjects, and a ruling is often a
/// standing rule's own words: each message is written once with every
/// subject it decides, and its sentences the block already wrote (`written`,
/// the standing rules above and the rulings before it) are not copied a
/// second time.
pub fn rulings_text(written: &mut super::rules::carried::Written) -> Result<String, String> {
    let standing = standing()?;
    if standing.is_empty() {
        return Ok(String::new());
    }
    let mut out = String::from(
        "# Operator's rulings on tasks and defects (`oko rulings list`). He already decided these; \
         never ask him again or list them as blockers or next steps.\n",
    );
    let mut messages: Vec<(&Standing, Vec<&str>)> = Vec::new();
    for held in &standing {
        match messages.iter_mut().find(|(first, _)| {
            first.session == held.session
                && first.ordinal == held.ordinal
                && first.said == held.said
        }) {
            Some((_, subjects)) => subjects.push(&held.subject),
            None => messages.push((held, vec![&held.subject])),
        }
    }
    for (held, subjects) in messages {
        let words = written.line(&held.said.trim().replace('\n', " "));
        out.push_str(&format!(
            "- {} ({} #{}): {words}\n",
            subjects.join(", "),
            held.session,
            held.ordinal
        ));
    }
    Ok(out)
}

/// The task and defect `session` declared as its work with `tama task scope
/// set`, lowercased, whichever instruction it was declared for; none when it
/// declared nothing. The declaration is read by the one reader of it
/// ([`TaskScope::read`]), so a file that exists and cannot be read or parsed
/// is the error: read as undeclared, the work it names would lose what was
/// ruled on it.
pub fn declared_work(session: &str) -> Result<Vec<String>, String> {
    match TaskScope::read(session, &crate::util::home_dir())? {
        Some(scope) => Ok(work_of(&scope)),
        None => Ok(Vec::new()),
    }
}

/// The task and defect `session` declared for the operator's current
/// instruction, lowercased: a declaration whose `turn_digest` is not the
/// digest of the instruction Tama captured last was written for an earlier
/// one and authorises nothing now, as `block-off-task-work` reads it. An
/// assignment that cannot be read is the error, naming its cause.
pub fn current_work(session: &str) -> Result<Vec<String>, String> {
    let Some(scope) = TaskScope::read(session, &crate::util::home_dir())? else {
        return Ok(Vec::new());
    };
    let instruction = super::load(session)
        .map_err(|error| format!("this session's assignment cannot be read: {error}"))?;
    match instruction {
        Some(assignment) if assignment.turn_digest == scope.turn_digest => Ok(work_of(&scope)),
        _ => Ok(Vec::new()),
    }
}

/// The register entries one declaration names, lowercased.
fn work_of(scope: &TaskScope) -> Vec<String> {
    [scope.task_id.as_str(), scope.defect.as_str()]
        .iter()
        .map(|id| id.trim().to_ascii_lowercase())
        .filter(|id| !id.is_empty())
        .collect()
}

/// The operator's rulings standing on the work `session` declared, one line
/// each with his words, headed by that work: what the session is shown
/// before each turn and after a compaction, so a ruling it never heard is in
/// front of it before it acts. None when it declared no work or no ruling
/// stands on it; a register that cannot be read is said in the text.
pub fn on_session_work(session: &str) -> Result<Option<String>, String> {
    let work = declared_work(session)?;
    if work.is_empty() {
        return Ok(None);
    }
    let ids: Vec<&str> = work.iter().map(String::as_str).collect();
    let lines = on_open_work(&ids, &[]);
    if lines.is_empty() {
        return Ok(None);
    }
    let listed: Vec<String> = lines.iter().map(|line| format!("- {line}")).collect();
    Ok(Some(format!(
        "# The operator's rulings on this session's work ({}). He already decided these; act on \
         them, and never ask him again or list them as blockers or next steps.\n{}\n",
        work.join(", "),
        listed.join("\n")
    )))
}
