//! Whether the user consented, in the current conversation, to run Weles's
//! browser on this computer.
//!
//! Weles may be opened on this computer with the user's consent. The consent
//! is a Tama session capability the agent records after the user gives it in
//! the conversation: `{ "tool": "weles", "actions": ["local-browser"] }`, with the
//! lifetime the user named (one call, until a time, or this session). The hook
//! runner passes a capability to the hook only after checking its session,
//! release and catalog, so the grant is read as already validated.
//!
//! The consent opens Weles only. A browser tool, Playwright, a bare Chromium
//! and every other direct runtime stay refused with or without it.

pub(super) const WELES_TOOL: &str = "weles";
pub(super) const LOCAL_BROWSER_ACTION: &str = "local-browser";

/// Whether the capability this hook process was started with grants the
/// local Weles browser: a `weles` grant with no action list (every action)
/// or one naming `local-browser`. Read through the capability module's one
/// reader, which names a capability it cannot parse instead of reading it
/// as no consent.
pub(super) fn local_weles_consented() -> bool {
    crate::capability::granted(WELES_TOOL, Some(LOCAL_BROWSER_ACTION))
}
