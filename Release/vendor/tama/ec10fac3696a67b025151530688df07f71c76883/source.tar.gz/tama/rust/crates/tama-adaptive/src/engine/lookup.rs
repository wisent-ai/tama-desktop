//! Reading the registry the engine reasons over: the command a hook runs,
//! and the file that command executes.
//!
//! Split out of `engine/mod.rs`, which had grown past the
//! three-hundred-line limit; the engine's own decisions stay there.

use std::fs;
use std::path::{Path, PathBuf};

use serde_json::Value;

use crate::util::shell_words;

/// The hook registry; one that cannot be read, does not parse or has no
/// `events` object is refused naming the file. Read as an empty registry, a
/// missing one left the engine reasoning over no hooks, with nothing said.
pub(super) fn load_registry(path: &Path) -> Result<Value, String> {
    let text = fs::read_to_string(path)
        .map_err(|error| format!("{} cannot be read: {error}", path.display()))?;
    let value = serde_json::from_str::<Value>(&text)
        .map_err(|error| format!("{} is not JSON: {error}", path.display()))?;
    match value.get("events") {
        Some(events) if events.is_object() => Ok(value),
        _ => Err(format!(
            "{} has no events object, so no hook can be reasoned about",
            path.display()
        )),
    }
}

/// `resolveFile(word, registryPath)`: the file `word` names, beside the
/// registry first and then in the working directory; none when neither
/// holds it. A path that cannot be examined, or a working directory that
/// cannot be read, is the error naming it: read as no file, the hook's
/// source would go unverified with nothing said.
fn resolve_file(word: &str, registry_path: &Path) -> Result<Option<PathBuf>, String> {
    let word_path = Path::new(word);
    let candidates: Vec<PathBuf> = if word_path.is_absolute() {
        vec![word_path.to_path_buf()]
    } else {
        let here = std::env::current_dir().map_err(|error| {
            format!("the working directory cannot be read to find {word}: {error}")
        })?;
        let beside = registry_path.parent().map(|parent| parent.join(word_path));
        beside.into_iter().chain([here.join(word_path)]).collect()
    };
    for path in candidates {
        match fs::metadata(&path) {
            Ok(metadata) if metadata.is_file() => return Ok(Some(path)),
            Ok(_) => {}
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
            Err(error) => {
                return Err(format!("{} cannot be examined: {error}", path.display()));
            }
        }
    }
    Ok(None)
}

/// The interpreter line a script starts with, as execve(2) reads it.
const SHEBANG: &str = "#!";

/// Whether the file at `path` is a script, which starts with a `#!` line,
/// or why it cannot be read.
fn is_script(path: &Path) -> Result<bool, String> {
    use std::io::Read;
    let mut head = Vec::new();
    fs::File::open(path)
        .and_then(|file| file.take(SHEBANG.len() as u64).read_to_end(&mut head))
        .map_err(|error| format!("{} cannot be read: {error}", path.display()))?;
    Ok(head == SHEBANG.as_bytes())
}

/// `commandFor(registry, hookId)` over the raw registry value: the command
/// of the first hook, in the registry's order, that has the id and a
/// command.
pub(super) fn command_for(registry: &Value, hook_id: &str) -> Option<String> {
    registry
        .get("events")?
        .as_object()?
        .values()
        .filter_map(|event| event.get("hooks").and_then(Value::as_array))
        .flatten()
        .filter(|hook| {
            hook.get("id")
                .is_some_and(|id| crate::util::js_string(id) == hook_id)
        })
        .find_map(|hook| {
            hook.get("command")
                .and_then(Value::as_str)
                .map(str::to_string)
        })
}

/// `sourceFor(command, registryPath)`: the file the command executes. A
/// program that is a script is its own source; otherwise the program reads
/// one, and the first operand that names a file is the source; a program
/// with no file operand, a native hook, is its own source.
pub(super) fn source_for(command: &str, registry_path: &Path) -> Result<Option<PathBuf>, String> {
    let words = shell_words(command);
    let Some((program, operands)) = words.split_first() else {
        return Ok(None);
    };
    let program = resolve_file(program, registry_path)?;
    if let Some(path) = &program {
        if is_script(path)? {
            return Ok(program);
        }
    }
    for word in operands.iter().filter(|word| !word.starts_with('-')) {
        if let Some(path) = resolve_file(word, registry_path)? {
            return Ok(Some(path));
        }
    }
    Ok(program)
}
