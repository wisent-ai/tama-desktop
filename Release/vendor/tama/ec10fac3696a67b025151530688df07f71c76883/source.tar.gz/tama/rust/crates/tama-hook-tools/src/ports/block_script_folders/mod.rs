//! Decision half of `tama hook block-script-folders` (hook id
//! `block-script-folders`): no file is written into a `scripts` folder of a
//! repository, unless the operator granted that exact write in his own words
//! ([`crate::ports::operator_grant`]).
//!
//! The operator banned one-off scripts, and a repository's `scripts` folder
//! is where they collect: each one a single repair or a single workflow
//! that a product command should own. Writing a new one, or changing one
//! that is there, keeps the folder alive; the work goes into the product's
//! own command instead, and a script that is there is moved into one or
//! deleted. Inline programs are `block-inline-execution`'s.
//!
//! A write is read from every path the file tools name
//! ([`crate::ports::block_off_task_work::written_paths`]), made absolute
//! against the call's working directory. It is refused when, between the
//! checkout's root and the file, a folder is named `scripts`. A path outside
//! every checkout is not a repository's and passes. No model, no network,
//! no lock; paths that cannot be read refuse nothing and say so on stderr.

use std::ffi::OsStr;
use std::path::{Component, Path, PathBuf};

use serde_json::Value;

use crate::ports::block_off_task_work::written_paths;
use crate::ports::operator_grant::{self, Request};
use crate::ports::tool_vocabulary::Call;

pub const HOOK_ID: &str = "block-script-folders";
pub const GRANT_KIND: &str = "script-folder";
const BANNER: &str = "BLOCKED: script folder: ";
/// The folder name one-off scripts collect under.
const SCRIPT_FOLDER: &str = "scripts";

/// The refusal for the call in `payload`, `None` when it writes nothing into
/// a repository's script folder or the operator granted exactly this write.
pub fn evaluate(payload: &Value) -> Option<String> {
    let call = Call::of(payload);
    let written = match written_paths(&call) {
        Ok(paths) => paths,
        Err(cause) => {
            eprintln!("{HOOK_ID}: the paths this call writes cannot be read: {cause}");
            return None;
        }
    };
    let cwd = call.cwd().map(PathBuf::from);
    let paths: Vec<String> = written
        .iter()
        .map(|path| absolute(path, cwd.as_deref()))
        .collect();
    let found: Vec<&String> = paths.iter().filter(|path| in_script_folder(path)).collect();
    if found.is_empty() {
        return None;
    }
    let request = Request {
        gate: HOOK_ID,
        command: None,
        paths: &paths,
    };
    if operator_grant::granted(payload, &request) {
        return None;
    }
    let listed: Vec<String> = found.iter().map(|path| format!("`{path}`")).collect();
    Some(format!(
        "{BANNER}{} would be written into a repository's `{SCRIPT_FOLDER}` folder. The operator \
         banned one-off scripts and script folders: put the work into the product's own command \
         (a subcommand of its CLI, with its test), and move a script that is there into one or \
         delete it. {}",
        listed.join(", "),
        operator_grant::how_to_grant(GRANT_KIND, HOOK_ID)
    ))
}

/// `path` made absolute against the call's working directory.
fn absolute(path: &str, cwd: Option<&Path>) -> String {
    match cwd {
        Some(cwd) if Path::new(path).is_relative() => cwd.join(path).display().to_string(),
        _ => path.to_string(),
    }
}

/// Whether a folder between the checkout holding `path` and the file is the
/// script folder.
fn in_script_folder(path: &str) -> bool {
    let file = Path::new(path);
    let Some(folder) = file.parent() else {
        return false;
    };
    let root = match tama_core::presence::checkout_root(folder) {
        Ok(Some(root)) => root,
        Ok(None) => return false,
        Err(cause) => {
            eprintln!("{HOOK_ID}: whether {path} is in a checkout cannot be read: {cause}");
            return false;
        }
    };
    let Ok(inside) = folder.strip_prefix(root) else {
        return false;
    };
    inside
        .components()
        .any(|component| component == Component::Normal(OsStr::new(SCRIPT_FOLDER)))
}
