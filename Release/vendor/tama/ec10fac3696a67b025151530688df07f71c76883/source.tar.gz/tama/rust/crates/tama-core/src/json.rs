//! The one way Tama turns its own data into JSON text.
//!
//! Every report, record and document Tama writes is plain data — strings,
//! numbers, lists and maps keyed by strings — which `serde_json` always
//! encodes. Each caller used to put an empty text in place of a failure, so
//! a failure would have printed, written or hashed nothing as if it were the
//! document. Here a failure stops the program naming the type that could not
//! be encoded, which is a bug in that type, never a state to carry on from.

use serde::Serialize;

fn failed<T: ?Sized>(error: serde_json::Error) -> ! {
    panic!(
        "{} cannot be encoded as JSON: {error}",
        std::any::type_name::<T>()
    )
}

/// `value` as compact JSON.
pub fn compact<T: Serialize + ?Sized>(value: &T) -> String {
    match serde_json::to_string(value) {
        Ok(text) => text,
        Err(error) => failed::<T>(error),
    }
}

/// `value` as JSON indented two spaces, as `JSON.stringify(value, null, 2)`.
pub fn pretty<T: Serialize + ?Sized>(value: &T) -> String {
    match serde_json::to_string_pretty(value) {
        Ok(text) => text,
        Err(error) => failed::<T>(error),
    }
}

/// `value` as a JSON `Value`, for a reply that is sent as one document.
pub fn value<T: Serialize + ?Sized>(value: &T) -> serde_json::Value {
    match serde_json::to_value(value) {
        Ok(encoded) => encoded,
        Err(error) => failed::<T>(error),
    }
}
