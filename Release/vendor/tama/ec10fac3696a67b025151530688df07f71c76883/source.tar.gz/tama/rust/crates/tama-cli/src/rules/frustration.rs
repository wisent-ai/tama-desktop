//! Oko owns correction evidence; Tama reads it through Oko's public CLI.
//! An unreadable source is not an empty history. A correction whose cause has
//! not been named remains visible without pretending to know that cause.

use std::collections::BTreeMap;
use std::process::Command;

use serde_json::{json, Value};
use sha2::{Digest, Sha256};

use super::decisions::CAUSE_PREFIX;

fn source(row: &Value) -> Value {
    json!({
        "id": row["id"], "session": row["session_id"],
        "quote": row["quote"], "cause": row["cause"],
        "defect": row["defect"], "markers": row["markers"],
        "repeats": row["repeats"]
    })
}

pub(super) fn proposals() -> Result<Vec<Value>, String> {
    let binary = tama_hook_tools::assignment::rules::oko_cli();
    let mut command = Command::new(&binary);
    command.args(["frustration", "list", "--json"]);
    let output = stado_wait::output(&mut command)
        .map_err(|error| format!("cannot run {binary} frustration list --json: {error}"))?;
    if !output.status.success() {
        return Err(format!(
            "{binary} frustration list --json exited {}: {}",
            output.status,
            String::from_utf8_lossy(&output.stderr).trim()
        ));
    }
    let rows: Vec<Value> = serde_json::from_slice(&output.stdout).map_err(|error| {
        format!("{binary} frustration list --json returned invalid JSON: {error}")
    })?;
    let mut groups: BTreeMap<String, Vec<Value>> = BTreeMap::new();
    let mut unexplained = Vec::new();
    for row in rows {
        if row.get("answered_at").is_some() {
            continue;
        }
        let Some(cause) = row
            .get("cause")
            .and_then(Value::as_str)
            .filter(|cause| !cause.trim().is_empty())
        else {
            unexplained.push(row);
            continue;
        };
        // Corrections tied to one defect share it; the rest group by their cause.
        let key = match row
            .get("defect")
            .and_then(Value::as_str)
            .filter(|id| !id.is_empty())
        {
            Some(defect) => defect.to_owned(),
            None => format!("{:x}", Sha256::digest(cause.as_bytes())),
        };
        groups.entry(key).or_default().push(row);
    }
    let mut proposals: Vec<Value> = groups.into_iter().filter_map(|(key, mut rows)| {
        rows.sort_by(|a, b| a["at"].as_str().cmp(&b["at"].as_str()));
        let latest = rows.last()?;
        let id = latest["id"].as_str()?;
        let cause = latest["cause"].as_str()?;
        let first = rows.first()?.get("at")?.clone();
        let last = latest.get("at")?.clone();
        let action = match latest["defect"].as_str() {
            Some(defect) => format!("oko defects show {defect}"),
            None => format!("oko frustration show {id}"),
        };
        let sources: Vec<Value> = rows.iter().map(source).collect();
        Some(json!({
            "id": format!("{CAUSE_PREFIX}{key}"),
            "kind": "lesson",
            "subject": cause,
            "evidence": rows.len(),
            "first": first,
            "last": last,
            "says": format!("{} unresolved operator correction(s) share this named cause; inspect the evidence and repair the producing process, not just the incident", rows.len()),
            "quote": latest["quote"],
            "action": action,
            "sources": sources,
        }))
    }).collect();
    unexplained.sort_by(|a, b| a["at"].as_str().cmp(&b["at"].as_str()));
    if let (Some(first), Some(latest)) = (unexplained.first(), unexplained.last()) {
        let sources: Vec<Value> = unexplained.iter().map(source).collect();
        proposals.push(json!({
            "id": "cause:unexplained",
            "kind": "lesson",
            "subject": "Operator corrections without a named cause",
            "evidence": sources.len(),
            "first": first["at"],
            "last": latest["at"],
            "says": "These corrections were recorded but their producing cause is not yet known. Inspect the source moments before naming a cause or repairing a process.",
            "quote": latest["quote"],
            "action": "oko frustration list --open",
            "sources": sources,
        }));
    }
    Ok(proposals)
}
