//! The source identity a seal stamps on a release, and the expectations a
//! build states about it.

use std::path::Path;

use serde_json::Value;

use super::super::identity::{source_identity, verify_source_identity};
use super::super::load_object;

/// A build states the revision and dirtiness it expects to seal; a tree that
/// differs is refused, so a release never carries another commit's name.
const EXPECTED_REVISION_ENV: &str = "TAMA_HOOK_SOURCE_REVISION";
const EXPECTED_DIRTY_ENV: &str = "TAMA_HOOK_SOURCE_DIRTY";

/// The identity the staged binaries were built from, checked against the tree.
pub(super) fn release_source_identity(root: &Path, source_root: &Path) -> Result<Value, String> {
    let manifest = root.join("native-hook-binaries.json");
    let present =
        |path: &Path| tama_core::presence::present(path).map_err(|error| error.to_string());
    let identity = if present(&manifest)? {
        let identity = load_object(&manifest)?["sourceIdentity"].clone();
        if !identity["revision"].is_string()
            || !identity["dirty"].is_boolean()
            || !identity["fingerprint"].is_string()
        {
            return Err(format!(
                "Native manifest has no recorded source identity: {}; restage the release",
                manifest.display()
            ));
        }
        verify_source_identity(source_root, &identity)?;
        identity
    } else if present(&root.join("bin"))? {
        return Err(format!(
            "Native release lacks source identity: {}; restage the release",
            root.display()
        ));
    } else {
        source_identity(source_root, None)?
    };
    let revision = identity["revision"].as_str().ok_or_else(|| {
        format!(
            "the source identity of {} names no revision: {identity}",
            source_root.display()
        )
    })?;
    let observed = [
        (EXPECTED_REVISION_ENV, revision.to_string()),
        (EXPECTED_DIRTY_ENV, identity["dirty"].to_string()),
    ];
    for (name, observed) in observed {
        // An expectation that is not text refuses: read as unset, the seal
        // would pass without the check its caller asked for.
        let expected = match std::env::var(name) {
            Ok(expected) => expected,
            Err(std::env::VarError::NotPresent) => continue,
            Err(error) => {
                return Err(format!(
                    "Hook source expectation {name} cannot be read: {error}"
                ))
            }
        };
        if expected != observed {
            return Err(format!(
                "Hook source expectation {name} differs at {}: expected {expected}, observed {observed}",
                source_root.display()
            ));
        }
    }
    Ok(identity)
}
