//! The immutable per-hook fact journal.

use sha2::{Digest, Sha256};
use std::fs::{self, OpenOptions};
use std::io::Write;
use std::path::{Path, PathBuf};

use super::super::Warn;

/// `keyOf(hookId)` — sha256 hex of the hook id string.
pub fn key_of(hook_id: &str) -> String {
    format!("{:x}", Sha256::digest(hook_id.as_bytes()))
}

pub struct FactJournal {
    root: PathBuf,
    warn: Warn,
}

impl FactJournal {
    /// `openFactJournal(stateDir, warn)` — creates the facts root eagerly.
    pub fn open(state_dir: &Path, warn: Warn) -> Self {
        let root = state_dir.join("facts");
        // Every later append would fail without saying why; the directory
        // that could not be made is named here, once.
        if let Err(error) = fs::create_dir_all(&root) {
            (warn)(&format!(
                "adaptive fact journal directory cannot be created: {}: {error}",
                root.display()
            ));
        }
        FactJournal { root, warn }
    }

    fn path_for(&self, hook_id: &str) -> PathBuf {
        self.root.join(format!("{}.jsonl", key_of(hook_id)))
    }

    /// `read(hookId)`: `Some(facts)` when the journal is healthy (a missing
    /// file is an empty journal), `None` when unreadable, torn, or corrupt.
    pub fn read(&self, hook_id: &str) -> Option<Vec<serde_json::Value>> {
        let path = self.path_for(hook_id);
        // A journal that cannot be examined is unreadable, not empty.
        match tama_core::presence::present(&path) {
            Ok(true) => {}
            Ok(false) => return Some(Vec::new()),
            Err(error) => {
                (self.warn)(&format!("adaptive fact journal unreadable: {error}"));
                return None;
            }
        }
        let source = match fs::read_to_string(&path) {
            Ok(source) => source,
            Err(error) => {
                (self.warn)(&format!(
                    "adaptive fact journal unreadable: {}: {}",
                    path.display(),
                    error
                ));
                return None;
            }
        };
        if !source.is_empty() && !source.ends_with('\n') {
            (self.warn)(&format!(
                "adaptive fact journal has an incomplete tail: {}",
                path.display()
            ));
            return None;
        }
        let mut facts = Vec::new();
        for line in source.split('\n') {
            if line.is_empty() {
                continue;
            }
            match parse_fact(line) {
                Ok(fact) => facts.push(fact),
                Err(error) => {
                    (self.warn)(&format!(
                        "adaptive fact journal is corrupt: {}: {}",
                        path.display(),
                        error
                    ));
                    return None;
                }
            }
        }
        Some(facts)
    }

    /// `append(hookId, fact)` — refuses to append after a torn/corrupt tail,
    /// and answers how many facts the journal holds with this one.
    pub fn append(&self, hook_id: &str, fact: &serde_json::Value) -> std::io::Result<usize> {
        let Some(mut facts) = self.read(hook_id) else {
            return Err(std::io::Error::new(
                std::io::ErrorKind::InvalidData,
                format!("adaptive fact journal is not appendable for {}", hook_id),
            ));
        };
        let path = self.path_for(hook_id);
        let existed = tama_core::presence::present(&path)?;
        let mut file = OpenOptions::new().append(true).create(true).open(&path)?;
        // A `Value` prints as JSON and cannot fail to; an empty row in place
        // of a failure would have torn the journal it appends to.
        file.write_all(fact.to_string().as_bytes())?;
        file.write_all(b"\n")?;
        file.sync_all()?;
        drop(file);
        if !existed {
            sync_directory(&self.root)?;
        }
        facts.push(fact.clone());
        Ok(facts.len())
    }
}

fn parse_fact(line: &str) -> Result<serde_json::Value, String> {
    let fact: serde_json::Value = serde_json::from_str(line).map_err(|e| e.to_string())?;
    let object = fact
        .as_object()
        .ok_or_else(|| "row is not an object".to_string())?;
    let kind = object.get("kind").and_then(serde_json::Value::as_str);
    if !matches!(kind, Some("outcome" | "contested-block")) {
        return Err(format!("unknown fact kind {kind:?}"));
    }
    let identity_ok = object.get("id").is_some_and(serde_json::Value::is_string)
        && object
            .get("hookId")
            .is_some_and(serde_json::Value::is_string);
    if !identity_ok {
        return Err("fact identity is invalid".to_string());
    }
    Ok(fact)
}

/// fsync a directory (`openSync(path, 'r')` + `fsyncSync`); a directory that
/// cannot be opened or flushed is answered with its path and cause, so a
/// journal entry is never taken as durable when its directory entry is not.
pub fn sync_directory(path: &Path) -> std::io::Result<()> {
    fs::File::open(path)
        .and_then(|dir| dir.sync_all())
        .map_err(|error| {
            std::io::Error::new(
                error.kind(),
                format!("{} cannot be flushed: {error}", path.display()),
            )
        })
}
