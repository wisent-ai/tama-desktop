//! Whether a package manager's `run <script>` compiles, read from the script
//! the checkout's `package.json` names rather than from the word `run`.
//!
//! A `npm run docs-page -- parts <page>` whose `scripts.docs-page` is
//! `node src/cli/docs-page.mjs` only reads and writes the docs source, and
//! refusing it as a build while the same command spelled out passes is a
//! gate reading the word `run` instead of the script. A script is
//! cleared only when every command in it runs one repository file through a
//! plain interpreter, and that file loads nothing that starts a program
//! (`modules`), or another script that does; anything else, and a manifest
//! or script that cannot be read, stays a compile.

use std::path::Path;

use serde_json::Value;

use crate::ports::python_stdlib::shell_tokens;
use crate::ports::shell_text;

use super::super::vocabulary::{has, is_flag, program_and_args, SCRIPT_RUNNER_VERB, VOCABULARY};
use super::modules::spawns_nothing;

const MANIFEST: &str = "package.json";
const SCRIPTS_KEY: &str = "scripts";
/// A script already on the chain of `run <script>` steps that reached it: a
/// cycle of scripts calling each other is not cleared.
fn on_chain(chain: &[String], script: &str) -> bool {
    chain.iter().any(|seen| seen == script)
}

/// Whether `program args`, run in `cwd`, is a script runner's `run <script>`
/// whose script compiles nothing.
pub(in super::super) fn runs_no_compile(program: &str, args: &[String], cwd: &Path) -> bool {
    script_name(program, args).is_some_and(|script| script_compiles_nothing(cwd, script, &[]))
}

/// The script `program run <script>` names, for a declared script runner.
fn script_name<'a>(program: &str, args: &'a [String]) -> Option<&'a str> {
    if !has(&VOCABULARY.script_runners, program) {
        return None;
    }
    let mut plain = args.iter().map(String::as_str).filter(|arg| !is_flag(arg));
    if plain.next()? != SCRIPT_RUNNER_VERB {
        return None;
    }
    plain.next()
}

/// `script` and every lifecycle script the runner runs around it
/// (`pre<script>`, `post<script>`) compile nothing.
fn script_compiles_nothing(cwd: &Path, script: &str, chain: &[String]) -> bool {
    if on_chain(chain, script) {
        return false;
    }
    let chain: Vec<String> = chain
        .iter()
        .cloned()
        .chain(std::iter::once(script.to_owned()))
        .collect();
    let Some(body) = script_body(cwd, script) else {
        return false;
    };
    VOCABULARY
        .script_lifecycle_prefixes
        .iter()
        .filter_map(|prefix| script_body(cwd, &format!("{prefix}{script}")))
        .all(|hook| body_compiles_nothing(cwd, &hook, &chain))
        && body_compiles_nothing(cwd, &body, &chain)
}

fn body_compiles_nothing(cwd: &Path, body: &str, chain: &[String]) -> bool {
    let pieces = shell_text::commands(body);
    !pieces.is_empty()
        && pieces.into_iter().all(|piece| {
            let tokens = shell_tokens(piece);
            let Some((program, args)) = program_and_args(&tokens) else {
                return false;
            };
            match script_name(program, args) {
                Some(inner) => script_compiles_nothing(cwd, inner, chain),
                None => runs_repository_file(cwd, program, args),
            }
        })
}

/// `scripts.<script>` of the `package.json` in `cwd`. A manifest that is not
/// there names no script; one that cannot be read or is not JSON is said on
/// stderr, since the script is then judged as a build without anyone being
/// told why its body was not read.
fn script_body(cwd: &Path, script: &str) -> Option<String> {
    let path = cwd.join(MANIFEST);
    let text = match std::fs::read_to_string(&path) {
        Ok(text) => text,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return None,
        Err(error) => {
            eprintln!("block-one-off-repairs: {} cannot be read, so script {script} is judged unread: {error}", path.display());
            return None;
        }
    };
    let manifest: Value = match serde_json::from_str(&text) {
        Ok(manifest) => manifest,
        Err(error) => {
            eprintln!("block-one-off-repairs: {} is not JSON, so script {script} is judged unread: {error}", path.display());
            return None;
        }
    };
    manifest
        .get(SCRIPTS_KEY)?
        .get(script)?
        .as_str()
        .map(str::to_owned)
}

/// `node <file>.mjs …` with no test flag, whose file starts no program: one
/// repository file run as it is.
fn runs_repository_file(cwd: &Path, program: &str, args: &[String]) -> bool {
    let words = &*VOCABULARY;
    has(&words.script_file_runners, program)
        && !args.iter().any(|arg| {
            // `--flag=value` names the flag before the `=`; a bare argument is its own name.
            let name = match arg.split_once('=') {
                Some((name, _value)) => name,
                None => arg.as_str(),
            };
            has(&words.script_file_runner_test_flags, name)
        })
        && args.iter().find(|arg| !is_flag(arg)).is_some_and(|file| {
            words
                .script_file_extensions
                .iter()
                .any(|extension| file.ends_with(extension.as_str()))
                && spawns_nothing(cwd, file)
        })
}
