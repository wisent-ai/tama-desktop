//! Durable, immutable telemetry
//! segments (open -> ready -> acked) with integrity footers.

mod reclaim;
mod status;
mod validate;

pub use validate::validate_segment;

use sha2::{Digest, Sha256};
use std::fs::{self, File, OpenOptions};
use std::io::Write;
use std::path::{Path, PathBuf};

use crate::state::journal::sync_directory;
use crate::state::Warn;

pub const PROTOCOL: &str = "hooks-telemetry-segment-v1";
pub const ACK_PROTOCOL: &str = "hooks-telemetry-ack-v1";

fn digest_bytes(value: &[u8]) -> String {
    format!("{:x}", Sha256::digest(value))
}

/// One JSON line; a `Value` prints as JSON and cannot fail to.
fn line(value: &serde_json::Value) -> String {
    format!("{value}\n")
}

pub fn segment_name(id: &str) -> String {
    format!("segment-{}.jsonl", id)
}

fn ack_name(id: &str) -> String {
    format!("segment-{}.ack.json", id)
}

fn write_all(descriptor: &mut File, text: &str) -> std::io::Result<()> {
    descriptor.write_all(text.as_bytes())
}

/// The names in the segment folder `path`. A folder that is not there holds
/// none: the writer makes it with its first segment.
fn folder_names(path: &Path) -> Result<Vec<String>, String> {
    let shown = path.display();
    let entries = match fs::read_dir(path) {
        Ok(entries) => entries,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(Vec::new()),
        Err(error) => {
            return Err(format!(
                "the segment folder {shown} cannot be listed: {error}"
            ))
        }
    };
    entries
        .map(|entry| {
            entry
                .map(|entry| entry.file_name().to_string_lossy().into_owned())
                .map_err(|error| format!("an entry of {shown} cannot be read: {error}"))
        })
        .collect()
}

/// The JSON object the `part` row `text` holds, or why it holds none.
fn parse_object(text: &str, part: &str) -> Result<serde_json::Value, String> {
    match serde_json::from_str::<serde_json::Value>(text) {
        Ok(value) if value.is_object() => Ok(value),
        Ok(value) => Err(format!("its {part} is {value}, not a JSON object")),
        Err(error) => Err(format!("its {part} is not JSON: {error}")),
    }
}

/// Whether `text` is a lowercase SHA-256 hex digest: as long as any digest
/// this module writes, in lowercase hex digits only.
fn is_hex_64(text: &str) -> bool {
    text.len() == digest_bytes(&[]).len()
        && text
            .bytes()
            .all(|b| b.is_ascii_hexdigit() && !b.is_ascii_uppercase())
}

/// A validated ready segment (`validateSegment`).
pub struct ValidSegment {
    pub segment_id: String,
    /// When the segment opened, in milliseconds since the Unix epoch.
    pub created_at: i64,
    pub event_count: usize,
    pub payload_sha256: String,
    pub source_sha256: String,
    pub source_size: usize,
    pub events: Vec<serde_json::Value>,
}

/// The closed segments waiting in `state_dir` for the lake, by path, in
/// name order, or why the ready folder cannot be listed.
pub fn ready_segments(state_dir: &Path) -> Result<Vec<PathBuf>, String> {
    let ready_dir = state_dir.join("telemetry-segments").join("ready");
    let mut names = folder_names(&ready_dir)?;
    names.retain(|name| name.ends_with(reclaim::READY_SUFFIX));
    names.sort();
    Ok(names.into_iter().map(|name| ready_dir.join(name)).collect())
}

/// `createSegmentWriter(stateDir, warn)`.
pub struct SegmentWriter {
    state_dir: PathBuf,
    open_dir: PathBuf,
    ready_dir: PathBuf,
    acked_dir: PathBuf,
    /// This process's writer, named once its first segment opens.
    invocation_id: Option<String>,
    producer_id: String,
    descriptor: Option<File>,
    open_path: PathBuf,
    ready_path: PathBuf,
    segment_id: String,
    payload_hash: Sha256,
    /// The byte length of each event frame the open segment holds; its
    /// length is the next event's sequence and the segment's event count.
    frames: Vec<usize>,
    closed: bool,
    failed: bool,
    warn: Warn,
}

impl SegmentWriter {
    pub fn create(state_dir: &Path, warn: Warn) -> Self {
        let root = state_dir.join("telemetry-segments");
        SegmentWriter {
            state_dir: state_dir.to_path_buf(),
            open_dir: root.join("open"),
            ready_dir: root.join("ready"),
            acked_dir: root.join("acked"),
            invocation_id: None,
            producer_id: format!("tama:{}", std::process::id()),
            descriptor: None,
            open_path: PathBuf::new(),
            ready_path: PathBuf::new(),
            segment_id: String::new(),
            payload_hash: Sha256::new(),
            frames: Vec::new(),
            closed: false,
            failed: false,
            warn,
        }
    }

    fn report(&self, error: &str) {
        (self.warn)(&format!("adaptive telemetry loss: {}", error));
    }

    fn ensure_open(&mut self) -> std::io::Result<()> {
        fs::create_dir_all(&self.open_dir)?;
        fs::create_dir_all(&self.ready_dir)?;
        fs::create_dir_all(&self.acked_dir)?;
        let uuid = || tama_core::random::random_uuid().map_err(std::io::Error::other);
        let invocation_id = match &self.invocation_id {
            Some(id) => id.clone(),
            None => uuid()?,
        };
        self.invocation_id = Some(invocation_id.clone());
        self.segment_id = uuid()?;
        self.open_path = self
            .open_dir
            .join(format!("{}.open", segment_name(&self.segment_id)));
        self.ready_path = self.ready_dir.join(segment_name(&self.segment_id));
        let mut descriptor = OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&self.open_path)?;
        self.payload_hash = Sha256::new();
        self.frames.clear();
        let header = line(&serde_json::json!({
            "kind": "segment_open",
            "protocol": PROTOCOL,
            "segmentId": self.segment_id,
            "producerId": self.producer_id,
            "invocationId": invocation_id,
            "createdAt": tama_core::clock::now_millis(),
            "source": { "producer": "tama" },
        }));
        write_all(&mut descriptor, &header)?;
        self.payload_hash.update(header.as_bytes());
        self.descriptor = Some(descriptor);
        Ok(())
    }

    fn abandon(&mut self) {
        if let Some(descriptor) = self.descriptor.take() {
            drop(descriptor);
        }
        self.failed = true;
    }

    fn append(&mut self, event: &serde_json::Value, retried: bool) -> bool {
        let attempt = |writer: &mut SegmentWriter| -> std::io::Result<()> {
            if writer.descriptor.is_none() {
                writer.ensure_open()?;
            }
            let frame = line(&serde_json::json!({
                "kind": "event",
                "sequence": writer.frames.len(),
                "event": event,
            }));
            let descriptor = writer.descriptor.as_mut().expect("descriptor opened above");
            write_all(descriptor, &frame)?;
            writer.payload_hash.update(frame.as_bytes());
            writer.frames.push(frame.len());
            Ok(())
        };
        match attempt(self) {
            Ok(()) => true,
            Err(error) => {
                self.abandon();
                // A full disk or an exhausted quota is retried once after
                // reclaiming the acknowledged segments.
                let full = matches!(
                    error.kind(),
                    std::io::ErrorKind::StorageFull | std::io::ErrorKind::QuotaExceeded
                );
                if !retried && full {
                    self.reclaim_acked();
                    self.failed = false;
                    return self.append(event, true);
                }
                self.report(&error.to_string());
                false
            }
        }
    }

    /// `record(event)`.
    pub fn record(&mut self, event: &serde_json::Value) -> bool {
        if self.closed || self.failed || !event.is_object() {
            return false;
        }
        self.append(event, false)
    }

    /// `close()`.
    pub fn close(&mut self) -> bool {
        if self.closed {
            return false;
        }
        self.closed = true;
        if self.descriptor.is_none() || self.failed {
            return false;
        }
        let attempt = |writer: &mut SegmentWriter| -> std::io::Result<()> {
            let digest = writer.payload_hash.clone().finalize();
            let footer = line(&serde_json::json!({
                "kind": "segment_close",
                "protocol": PROTOCOL,
                "segmentId": writer.segment_id,
                "eventCount": writer.frames.len(),
                "payloadSha256": format!("{:x}", digest),
                "closedAt": tama_core::clock::now_millis(),
            }));
            let mut descriptor = writer.descriptor.take().expect("checked above");
            write_all(&mut descriptor, &footer)?;
            descriptor.sync_all()?;
            drop(descriptor);
            fs::rename(&writer.open_path, &writer.ready_path)?;
            sync_directory(&writer.ready_dir)?;
            Ok(())
        };
        match attempt(self) {
            Ok(()) => true,
            Err(error) => {
                self.abandon();
                self.report(&error.to_string());
                false
            }
        }
    }
}
