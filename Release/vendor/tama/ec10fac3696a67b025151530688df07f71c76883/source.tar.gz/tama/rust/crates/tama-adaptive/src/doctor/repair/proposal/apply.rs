//! Applying a validated proposal to the live hook, behind the owner's
//! device consent, with a backup of what was there.
//!
//! Split out of `doctor/repair.rs`, which had grown past the
//! three-hundred-line limit.

use std::fs;
use std::path::Path;

use serde_json::Value;

use super::super::corpus::hook_paths;
use crate::engine::load_engine;
use crate::telemetry::open_telemetry;
use crate::util::extname;
use tama_core::exit;

const APPROVAL_ENV: &str = "DEVICE_HOOK_EDIT_APPROVED";
/// The value of [`APPROVAL_ENV`] that counts as the operator's hook-edit
/// consent, as the hook-management page declares it:
/// https://tama.wisent.com/docs/hook-management
const APPROVAL_VALUE: &str = "1";

/// Whether `path` is there, or why it cannot be examined.
fn present(path: &Path) -> Result<bool, String> {
    tama_core::presence::present(path).map_err(|error| error.to_string())
}

/// `applyProposal(proposalDir)`. Every refusal is the error naming its
/// cause, which `doctor/cli` prints as `doctor: <error>` and exits 1 with.
pub fn apply_proposal(proposal_dir: &str) -> Result<i32, String> {
    if std::env::var_os(APPROVAL_ENV).is_none_or(|value| value != APPROVAL_VALUE) {
        return Err(format!(
            "refusing to modify live hooks: {APPROVAL_ENV} is not {APPROVAL_VALUE}. Owner consent \
             flow: see https://tama.wisent.com/docs/hook-management"
        ));
    }
    let report_path = Path::new(proposal_dir).join("report.json");
    let text = fs::read_to_string(&report_path)
        .map_err(|error| format!("cannot read {}: {error}", report_path.display()))?;
    let report: Value = serde_json::from_str(&text)
        .map_err(|error| format!("{} is not JSON: {error}", report_path.display()))?;
    let hook_id = report
        .get("hookId")
        .and_then(Value::as_str)
        .ok_or_else(|| format!("{} names no hookId", report_path.display()))?;
    let core = load_engine()?;
    let paths = hook_paths(hook_id, &core)?;
    let live = paths
        .live
        .clone()
        .ok_or_else(|| format!("hook {hook_id} has no live script to apply the proposal to"))?;
    let proposed = match report.get("proposed").and_then(Value::as_str) {
        Some(proposed) => proposed.to_string(),
        // A report that names no proposed file keeps it beside itself, named
        // `proposed` with the live script's extension.
        None => Path::new(proposal_dir)
            .join(format!("proposed{}", extname(&live)))
            .to_string_lossy()
            .into_owned(),
    };
    if !present(Path::new(&proposed))? {
        return Err(format!(
            "the proposed file {proposed} for {hook_id} is not there"
        ));
    }
    let backup_dir = core.state_dir.join("backup");
    fs::create_dir_all(&backup_dir)
        .map_err(|error| format!("cannot create {}: {error}", backup_dir.display()))?;
    let backup_name = Path::new(&live)
        .file_name()
        .ok_or_else(|| format!("the live script {live} names no file"))?
        .to_string_lossy();
    let backup_path = backup_dir.join(format!("{backup_name}.{}", tama_core::clock::now_millis()));
    if present(Path::new(&live))? {
        fs::copy(&live, &backup_path).map_err(|error| {
            format!(
                "cannot back {live} up to {}: {error}",
                backup_path.display()
            )
        })?;
    }
    fs::copy(&proposed, &live)
        .map_err(|error| format!("cannot copy {proposed} over {live}: {error}"))?;
    let archive_note = match &paths.archive {
        Some(archive) => {
            fs::copy(&proposed, archive).map_err(|error| {
                format!("cannot copy {proposed} over {}: {error}", archive.display())
            })?;
            format!(", archive {}", archive.display())
        }
        None => String::new(),
    };
    let telemetry = open_telemetry(&core.state_dir);
    telemetry.warn(&format!(
        "doctor apply: {hook_id} <- {proposed} (backup {}{archive_note})",
        backup_path.display()
    ));
    telemetry.close();
    println!("applied {hook_id}; backup at {}", backup_path.display());
    Ok(exit::SUCCESS)
}
