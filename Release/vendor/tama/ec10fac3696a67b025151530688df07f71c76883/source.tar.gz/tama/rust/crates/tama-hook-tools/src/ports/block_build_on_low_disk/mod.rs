//! Decision half of `tama hook block-build-on-low-disk` (registry hook
//! `block-build-on-low-disk`).
//!
//! A local Rust or iOS build writes gigabytes of intermediate output
//! (`target/`, DerivedData) to the disk it runs on, and a build that fills
//! that disk stops every program on the machine. So a command that compiles
//! one (`vocabulary.json`: cargo, swift and xcodebuild with their compiling
//! verbs) is refused while the disk under the directory it runs in has less
//! free space than the reserve the operator stated, which
//! [`crate::ports::stated_numbers`] holds with his words. The free space is
//! measured, not assumed: `df -P -H` answers for that directory, and a disk
//! whose free space cannot be read refuses the build with the reason.
//!
//! The command is read the way a shell reads it, so `grep 'cargo build'` and
//! `cargo build --help` pass.

use std::cmp::Ordering;
use std::path::{Path, PathBuf};
use std::process::Command;
use std::sync::LazyLock;

use serde::Deserialize;
use serde_json::Value;

use crate::ports::python_stdlib::shell_tokens;
use crate::ports::shell_text;
use crate::ports::stated_numbers::stated;
use crate::ports::tool_vocabulary::Call;

const FLAG_PREFIX: char = '-';
/// `cargo +nightly build`: a toolchain choice, not the verb.
const TOOLCHAIN_PREFIX: char = '+';
const DECIMAL_POINT: char = '.';
const PATH_SEPARATOR: char = '/';
const HELP_FLAG: &str = "--help";
/// The operator's reserve, by its name in `numeric-provenance.json`.
const RESERVE: &str = "build_free_disk_gigabytes";

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Builder {
    program: String,
    /// The first plain word that makes the program compile; empty when every
    /// invocation compiles.
    command: String,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Read {
    program: String,
    flag: String,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Df {
    program: String,
    portable: String,
    decimal: String,
    available_column: String,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Vocabulary {
    #[allow(dead_code)]
    why: String,
    builders: Vec<Builder>,
    reads: Vec<Read>,
    df: Df,
    magnitudes: String,
    reserve_magnitude: String,
}

static VOCABULARY: LazyLock<Vocabulary> = LazyLock::new(|| {
    serde_json::from_str(include_str!("vocabulary.json"))
        .expect("block_build_on_low_disk/vocabulary.json is the gate's own data and must parse")
});

/// The last part of a program's path: `/usr/bin/cargo` is `cargo`.
fn basename(token: &str) -> &str {
    let trimmed = token.trim_end_matches(PATH_SEPARATOR);
    match trimmed.rsplit_once(PATH_SEPARATOR) {
        Some((_, name)) => name,
        None => trimmed,
    }
}

/// The command as written when it compiles a Rust or iOS product locally.
fn compiling(tokens: &[String]) -> Option<String> {
    let program = shell_text::program(tokens)?;
    let start = tokens.iter().position(|token| basename(token) == program)?;
    let (_, args) = tokens.get(start..)?.split_first()?;
    if args.iter().any(|arg| arg == HELP_FLAG) {
        return None;
    }
    let words = &*VOCABULARY;
    if words
        .reads
        .iter()
        .any(|read| read.program == program && args.contains(&read.flag))
    {
        return None;
    }
    let verb = args
        .iter()
        .find(|arg| !arg.starts_with(FLAG_PREFIX) && !arg.starts_with(TOOLCHAIN_PREFIX));
    words
        .builders
        .iter()
        .any(|builder| {
            builder.program == program
                && (builder.command.is_empty() || verb.is_some_and(|verb| *verb == builder.command))
        })
        .then(|| tokens.join(" "))
}

/// The free space `df` reports for the disk under `directory`, as it prints
/// it (`249G`).
fn available(directory: &Path) -> Result<String, String> {
    let df = &VOCABULARY.df;
    let mut command = Command::new(&df.program);
    command.arg(&df.portable).arg(&df.decimal).arg(directory);
    let output = stado_wait::output(&mut command)
        .map_err(|error| format!("{} could not run: {error}", df.program))?;
    let printed = String::from_utf8_lossy(&output.stdout);
    if !output.status.success() {
        return Err(format!(
            "{} {} {} {} exited with {}: {}",
            df.program,
            df.portable,
            df.decimal,
            directory.display(),
            output.status,
            String::from_utf8_lossy(&output.stderr).trim()
        ));
    }
    let mut lines = printed.lines();
    let header = lines
        .next()
        .ok_or_else(|| format!("{} printed nothing", df.program))?;
    let column = header
        .split_whitespace()
        .position(|name| name == df.available_column)
        .ok_or_else(|| {
            format!(
                "{} printed no {} column: {header}",
                df.program, df.available_column
            )
        })?;
    let row = lines
        .last()
        .ok_or_else(|| format!("{} printed no disk row", df.program))?;
    row.split_whitespace()
        .nth(column)
        .map(str::to_string)
        .ok_or_else(|| {
            format!(
                "{} printed no {} value: {row}",
                df.program, df.available_column
            )
        })
}

/// The place of a magnitude letter among `magnitudes`, smallest first; a
/// size printed without a letter is in the first of them, bytes.
fn rank(letter: Option<char>) -> Result<usize, String> {
    let magnitudes = &VOCABULARY.magnitudes;
    let letter = match (letter, magnitudes.chars().next()) {
        (Some(letter), _) => letter.to_ascii_uppercase(),
        (None, Some(bytes)) => bytes,
        (None, None) => {
            return Err(
                "block_build_on_low_disk/vocabulary.json declares no magnitudes".to_string(),
            )
        }
    };
    magnitudes
        .find(letter)
        .ok_or_else(|| format!("df printed the magnitude {letter}, which is none of {magnitudes}"))
}

/// Whether `free`, as df printed it, holds at least the operator's reserve.
fn holds_reserve(free: &str) -> Result<bool, String> {
    let split = match free.find(|c: char| !(c.is_ascii_digit() || c == DECIMAL_POINT)) {
        Some(split) => split,
        None => free.len(),
    };
    let (amount, magnitude) = free.split_at(split);
    let amount: f64 = amount.parse().map_err(|error| {
        format!("df printed the free space {free}, which is not a size: {error}")
    })?;
    let reserve_letter = VOCABULARY.reserve_magnitude.chars().next();
    Ok(
        match rank(magnitude.chars().next())?.cmp(&rank(reserve_letter)?) {
            Ordering::Greater => true,
            Ordering::Less => false,
            Ordering::Equal => amount >= stated(RESERVE) as f64,
        },
    )
}

/// The directory the command runs in: the one the call names, or this hook's
/// own working directory, which the harness starts in the session's.
fn directory_of(call: &Call) -> Result<PathBuf, String> {
    match call.cwd().filter(|cwd| !cwd.is_empty()) {
        Some(cwd) => Ok(PathBuf::from(cwd)),
        None => std::env::current_dir()
            .map_err(|error| format!("the directory it runs in cannot be read ({error})")),
    }
}

/// Why this command is refused, if it is: it compiles a Rust or iOS product
/// on a disk with less free space than the operator's reserve, or on one
/// whose free space cannot be read.
pub fn evaluate(payload: &Value) -> Option<String> {
    let call = Call::of(payload);
    let command = call.command()?;
    if command.trim().is_empty() {
        return None;
    }
    let acting = shell_text::effective_payload(payload, command);
    let build = shell_text::commands(&acting)
        .into_iter()
        .map(shell_tokens)
        .find_map(|tokens| compiling(&tokens))?;
    let directory = match directory_of(&call) {
        Ok(directory) => directory,
        Err(error) => {
            return Some(format!(
                "BLOCKED: `{build}` compiles locally, but {error}, so the free space on its disk is unknown."
            ))
        }
    };
    let reserve = format!("{} {}B", stated(RESERVE), VOCABULARY.reserve_magnitude);
    let refusal = |state: String| {
        format!(
            "BLOCKED: `{build}` compiles in {}, and {state}. A local Rust or iOS build needs at least \
             {reserve} free on its disk, the reserve the operator set, because a build that fills the \
             disk stops every program on this machine. Free space on that disk first (build output such \
             as target/ and DerivedData is the usual weight), or build on a Stado builder.",
            directory.display()
        )
    };
    let free = match available(&directory) {
        Ok(free) => free,
        Err(error) => {
            return Some(refusal(format!(
                "its free space could not be measured: {error}"
            )))
        }
    };
    match holds_reserve(&free) {
        Ok(true) => None,
        Ok(false) => Some(refusal(format!("its disk has {free} free (df -P -H)"))),
        Err(error) => Some(refusal(format!(
            "its free space could not be read: {error}"
        ))),
    }
}
