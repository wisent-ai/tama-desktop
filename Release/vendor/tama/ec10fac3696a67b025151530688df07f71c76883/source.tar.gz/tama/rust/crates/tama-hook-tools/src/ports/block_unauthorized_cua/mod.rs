//! Decision half of `tama hook block-unauthorized-cua` (hook id
//! `block-unauthorized-cua`): block CUA unless the operator's consent is
//! recorded as the Tama session capability `{ "tool": "cua" }` and a
//! current-session user quote scopes it.
//!
//! The gate is two-sided. `authorized_entries` finds every registry entry
//! whose verbatim `userRequestQuote` names the target app (and, under the
//! strict schema, every action) and really appears in this session's
//! transcript; the call passes when `operation_matches_entry` finds one of
//! them that covers the action and the process this call would actually drive.
//!
//! The patterns, `cua_action` and `is_cua_operation` live in
//! [`crate::ports::block_unauthorized_cua_detect`] and are re-exported here,
//! so this module is the whole port's surface. A call refused for want of
//! any grant also hands the operator the exact sentence that grants it
//! ([`consent`]).

mod consent;

use std::process::Command;

use serde_json::Value;

use crate::ports::block_unauthorized_cua_detect as detect;
use crate::ports::pystr;
use crate::ports::pyvalue;
use crate::ports::transport_common as common;

pub use crate::ports::block_unauthorized_cua_detect::{cua_action, is_cua_operation};

const TAMA_BUNDLE_ID: &str = "ai.wisent.tama.desktop";
const TAMA_EXECUTABLE: &str = "/Tama.app/Contents/MacOS/Tama";
const TAMA_APP_NAME: &str = "Tama";
const STRICT_SCHEMA: &str = "ai.wisent.tama.cua-justifications.vTwo";
const CUA_TOOL: &str = "cua-driver";
const SESSION_LIFETIME: &str = "current OMP session";
const LAUNCH_ACTION: &str = "launch_app";
const MANAGEMENT_ACTIONS: &[&str] = &["status", "check_permissions", "serve", "stop"];
const PS_BINARY: &str = "/bin/ps";
/// The variable that moves the registry this gate reads; every writer and
/// reader of the registry honours it, so they read the same file.
pub const JUSTIFICATIONS_ENV: &str = "TAMA_CUA_JUSTIFICATIONS";
const JUSTIFICATIONS_FILE: &str = "cua_justifications.json";
const BANNER: &str = "BLOCKED: unauthorized CUA: ";
/// The session capability tool that carries the operator's consent to CUA.
const CONSENT_TOOL: &str = "cua";

/// The CUA grant registry under `home`, or the file `JUSTIFICATIONS_ENV`
/// names: what this gate reads and `tama justify` writes, lists and revokes.
pub fn justifications_path_under(home: &std::path::Path) -> std::path::PathBuf {
    common::env_path(
        JUSTIFICATIONS_ENV,
        common::hook_registry(home, JUSTIFICATIONS_FILE),
    )
}

fn justifications_path() -> std::path::PathBuf {
    justifications_path_under(&common::home())
}

/// `str(value).replace("-", "_").lower()` — the registry side, which does not
/// strip the way the quote side does.
fn normalized(value: &Value) -> String {
    pyvalue::py_str(value).replace('-', "_").to_lowercase()
}

/// `quote_directly_authorizes`: the quote names the app and — under the
/// strict schema — every allowed action. Consent itself is not read from the
/// quote's words: it is the `cua` session capability ([`authorized_entries`]).
pub fn quote_directly_authorizes(entry: &Value, quote: &str, strict_actions: bool) -> bool {
    let bundle_id = entry.get("allowedBundleId").and_then(Value::as_str);
    // The app the grant names; a grant for Tama's own bundle that names no app
    // is Tama, and any other grant without a name names no app.
    let named = entry
        .get("allowedAppName")
        .and_then(Value::as_str)
        .filter(|named| !pystr::strip(named).is_empty());
    let app_name = match named {
        Some(named) => Some(named),
        None if bundle_id == Some(TAMA_BUNDLE_ID) => Some(TAMA_APP_NAME),
        None => None,
    };
    let lowered = quote.to_lowercase();
    let target_named = app_name.is_some_and(|name| lowered.contains(&name.to_lowercase()))
        || bundle_id.is_some_and(|id| lowered.contains(&id.to_lowercase()));
    if !target_named {
        return false;
    }
    if !strict_actions {
        return true;
    }
    let actions = match entry.get("allowedActions") {
        Some(Value::Array(items)) if !items.is_empty() => items,
        _ => return false,
    };
    actions.iter().all(|raw| quote_names_action(&lowered, raw))
}

/// Every spelling the Python builds for one allowed action: `open_app`,
/// `open-app`, `open app`.
fn quote_names_action(lowered: &str, raw: &Value) -> bool {
    let action = pystr::strip(&pyvalue::py_str(raw))
        .to_lowercase()
        .replace('-', "_");
    if action.is_empty() {
        return false;
    }
    lowered.contains(&action)
        || lowered.contains(&action.replace('_', "-"))
        || lowered.contains(&action.replace('_', " "))
}

/// `registry.get("authorizations", [])`.
///
/// Ported quirk: Python iterates a string's characters and a dict's keys —
/// neither yields a dict, so no entry can match — while a number, bool or
/// explicit `null` raises `TypeError` and the hook exits 1 without deciding.
fn authorizations(registry: &Value) -> Vec<Value> {
    match registry.get("authorizations") {
        None => Vec::new(),
        Some(Value::Array(items)) => items.clone(),
        Some(Value::String(_)) | Some(Value::Object(_)) => Vec::new(),
        Some(_) => common::python_crash("TypeError: 'authorizations' object is not iterable"),
    }
}

/// `authorized_entries`: every registry entry the current session's
/// transcript actually backs, while the operator's consent is recorded as the
/// Tama session capability `{ "tool": "cua" }`. Each grant the operator gave
/// keeps its own scope: a later grant for the same app does not hide an
/// earlier one.
pub fn authorized_entries(payload: &Value) -> Vec<Value> {
    if !crate::capability::granted(CONSENT_TOOL, None) {
        return Vec::new();
    }
    let Some(registry) = common::read_registry(&justifications_path()) else {
        return Vec::new();
    };
    if !registry.is_object() {
        return Vec::new();
    }
    let session_id = common::session_id_of(payload);
    let strict_actions = registry.get("schema").and_then(Value::as_str) == Some(STRICT_SCHEMA);
    authorizations(&registry)
        .into_iter()
        .filter(|entry| {
            let Some(Value::String(quote)) = entry.get("userRequestQuote") else {
                return false;
            };
            entry.get("allowedTool").and_then(Value::as_str) == Some(CUA_TOOL)
                && entry.get("allowedBundleId").is_some_and(Value::is_string)
                && entry.get("lifetime").and_then(Value::as_str) == Some(SESSION_LIFETIME)
                && quote_directly_authorizes(entry, quote, strict_actions)
                && common::quote_is_in_current_session(&session_id, quote)
        })
        .collect()
}

/// `pid_targets_entry`: the live process really is the app the grant names,
/// or why `ps` could not say which program the process runs. A grant that
/// names no executable names Tama's own when it is Tama's bundle, and no
/// app otherwise, which no process is.
pub fn pid_targets_entry(pid: &str, entry: &Value) -> Result<bool, String> {
    let configured = entry
        .get("allowedExecutable")
        .and_then(Value::as_str)
        .filter(|executable| !executable.is_empty());
    let tama_bundle = entry.get("allowedBundleId").and_then(Value::as_str) == Some(TAMA_BUNDLE_ID);
    let allowed = match (configured, tama_bundle) {
        (Some(executable), _) => executable,
        (None, true) => TAMA_EXECUTABLE,
        (None, false) => return Ok(false),
    };
    let mut probe = Command::new(PS_BINARY);
    probe.arg("-p").arg(pid).arg("-o").arg("command=");
    let output = stado_wait::output(&mut probe)
        .map_err(|error| format!("{PS_BINARY} could not say what process {pid} runs: {error}"))?;
    Ok(output.status.success() && String::from_utf8_lossy(&output.stdout).contains(allowed))
}

/// `action in {str(v).replace("-", "_").lower() for v in allowed}`, false
/// when `allowed` is absent or is not a list.
fn lists_action(allowed: Option<&Value>, action: &str) -> bool {
    match allowed {
        Some(Value::Array(items)) => items.iter().any(|item| normalized(item) == action),
        _ => false,
    }
}

/// `operation_matches_entry`: the action and its target are inside the scope
/// recorded with the quote.
pub fn operation_matches_entry(payload: &Value, entry: &Value) -> Result<bool, String> {
    let action = match cua_action(payload) {
        Some(action) => action,
        None => return Ok(false),
    };
    let allowed = entry.get("allowedActions").filter(|value| !value.is_null());
    if allowed.is_some() && !lists_action(allowed, &action) {
        return Ok(false);
    }
    let call = crate::ports::tool_vocabulary::Call::of(payload);
    let probe = match call.input() {
        Some(input) => pyvalue::py_json_dumps(input),
        None => pyvalue::py_json_dumps(&Value::Object(Default::default())),
    };
    let bundle_id = entry.get("allowedBundleId").and_then(Value::as_str);
    if action == LAUNCH_ACTION {
        return Ok(bundle_id.is_some_and(|id| probe.contains(id)));
    }
    // The CLI's JSON argument is a string inside the hook payload, so its
    // quotes are escaped in `probe`. Inspect the shell command itself too.
    let command = call.command().unwrap_or_default();
    let mut targeted = false;
    for found in detect::PID_RE
        .captures_iter(&probe)
        .chain(detect::PID_RE.captures_iter(command))
    {
        targeted = true;
        let Some(pid) = common::first_group(&found) else {
            return Ok(false);
        };
        if !pid_targets_entry(pid.as_str(), entry)? {
            return Ok(false);
        }
    }
    if targeted {
        return Ok(true);
    }
    // Starting, inspecting or stopping the driver has no target PID. An exact,
    // quoted management action is sufficient; later app actions still check
    // their target.
    let named_management =
        MANAGEMENT_ACTIONS.contains(&action.as_str()) && lists_action(allowed, &action);
    let legacy_tama_management = bundle_id == Some(TAMA_BUNDLE_ID)
        && allowed.is_none()
        && MANAGEMENT_ACTIONS.contains(&action.as_str());
    Ok(named_management
        || legacy_tama_management
        || (matches!(entry.get("allowUntargeted"), Some(Value::Bool(true)))
            && lists_action(allowed, &action)))
}

/// `evaluate_payload`: the deny banner when the call is refused, `None` when
/// it passes. The caller writes the banner to stderr and exits 2.
pub fn evaluate(payload: &Value) -> Option<String> {
    if !is_cua_operation(payload) {
        return None;
    }
    let grants = authorized_entries(payload);
    if grants.is_empty() {
        return Some(format!(
            "{BANNER}no direct current-session CUA grant in cua_justifications.json; \
             the verbatim user quote must explicitly name CUA, the target app, \
             and every allowed cua-driver action. {}",
            consent::sentence(payload)
        ));
    }
    // Every grant is tried; a grant whose target could not be checked
    // covers nothing, and when none covers the call the refusal names each
    // check that could not run instead of calling the call out of scope.
    let mut unchecked = Vec::new();
    for grant in &grants {
        match operation_matches_entry(payload, grant) {
            Ok(true) => return None,
            Ok(false) => {}
            Err(cause) => unchecked.push(cause),
        }
    }
    if unchecked.is_empty() {
        return Some(format!(
            "{BANNER}the CUA operation is outside the app/action scope of every user quote \
             recorded for this session"
        ));
    }
    Some(format!(
        "{BANNER}no recorded quote was shown to cover this CUA target: {}",
        unchecked.join("; ")
    ))
}
