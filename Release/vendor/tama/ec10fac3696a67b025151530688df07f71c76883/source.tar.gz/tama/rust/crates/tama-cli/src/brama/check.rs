//! `tama model check`: whether this machine can actually reach the
//! model service Tama asks, Brama or the declared one.
//!
//! Every Tama feature that needs a model — the objective reviewer and the
//! `clean` repair rounds — goes through that service. When one of them fails
//! the question is always the same three: which address did it use, does the
//! service accept this credential, and, for Brama, is the refusal about the
//! bearer or the route grant. This answers them without spending quota.

use tama_hook_tools::brama;

use crate::cli::output::print_json;

/// Diagnose the configured model service without changing provider or
/// routing. `--help` is answered from the command table before this runs.
pub fn doctor(args: &[String]) -> i32 {
    let mut json = false;
    for arg in args {
        match arg.as_str() {
            "--json" => json = true,
            other => {
                eprintln!("doctor: unexpected argument {other:?}; use tama doctor [--json]");
                return tama_core::exit::USAGE;
            }
        }
    }
    run(json)
}

/// One check, printed as JSON or as `key: value` lines; non-zero unless the
/// service accepted the credential at an address the client may use.
pub fn run(json: bool) -> i32 {
    match tama_hook_tools::ports::task_attestation::declared::model_declared_none() {
        Ok(false) => {}
        Ok(true) => {
            return refused(
                json,
                "no model is declared on this machine, so there is no service to check",
            )
        }
        Err(error) => return refused(json, &error),
    }
    match brama::reachability() {
        Ok(report) => {
            if json {
                print_json(&report);
            } else {
                print_report(&report);
            }
            if report.endpoint_allowed && report.accepted {
                tama_core::exit::SUCCESS
            } else {
                tama_core::exit::FAILURE
            }
        }
        Err(error) => refused(json, &error),
    }
}

fn refused(json: bool, error: &str) -> i32 {
    if json {
        print_json(&serde_json::json!({ "error": error }));
    }
    eprintln!("model check: {error}");
    tama_core::exit::FAILURE
}

fn print_report(report: &brama::probe::Reachability) {
    println!("provider: {}", report.provider);
    println!("endpoint: {}", report.endpoint);
    println!(
        "transport: {}",
        if report.endpoint_allowed {
            "allowed"
        } else {
            "refused by the client's own policy"
        }
    );
    println!(
        "probe: {} -> {}",
        report.probed,
        report
            .status
            .clone()
            .unwrap_or_else(|| "no answer".to_string())
    );
    println!("detail: {}", report.detail);
    println!("consumer: {}", report.consumer);
    println!("token file: {}", report.token_file);
    println!("route: {}", report.route);
    println!(
        "this machine's authority: {}",
        match report.local_grant {
            Some(true) => "grants this route on this bearer".to_string(),
            Some(false) => "does not grant this route to this consumer".to_string(),
            None => format!("not asked: {}", report.local_grant_detail),
        }
    );
    println!("verdict: {}", report.verdict);
}
