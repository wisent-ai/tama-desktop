//! `tama request policy-bundles/import`: the policy-bundle import the
//! terminal's `tama policy import` makes, with its refusals.

use std::path::Path;

use serde_json::Value;
use tama_core::policy_bundle::{import_policy_bundle, ImportPolicyBundleOptions};

use super::{body, refused, respond};
use crate::request::reply::{Reply, Request};

/// A bundle import; `replace` left out keeps an installed bundle of the same
/// name, which is the import's ordinary meaning.
pub(super) fn policy_import(request: Request, writer: &mut Reply) {
    let Some(body) = body(&request, writer) else {
        return;
    };
    let Some(source) = body
        .get("sourcePath")
        .and_then(Value::as_str)
        .filter(|source| !source.trim().is_empty())
    else {
        return respond::<Value>(writer, Err(refused("sourcePath is required")));
    };
    let replace = match body.get("replace") {
        None => false,
        Some(Value::Bool(replace)) => *replace,
        Some(other) => {
            return respond::<Value>(
                writer,
                Err(refused(format!(
                    "replace must be true or false, got {other}"
                ))),
            )
        }
    };
    let answer = import_policy_bundle(ImportPolicyBundleOptions {
        source: Path::new(source),
        home: None,
        replace,
    })
    .map_err(refused);
    respond(writer, answer);
}
