//! The operator's approvals of test code and `tama tests`, the one command
//! that records them.
//!
//! An approval names a file or a directory; everything under an approved
//! directory is approved with it. The record lives beside the other
//! device-level approvals in `~/.config/agent-policy/approved_tests.json`.
//! A session cannot write it: `block-unapproved-tests` refuses a write tool
//! aimed at it, a shell command that names it, and `tama tests approve`
//! run from a session, so an approval is always the operator's own. Each act
//! is kept in the attestation ledger first and the record is then replaced
//! whole, never removed ([`view`]); `tama tests restore` writes it again from
//! the ledger when something else removed it.

use std::path::{Component, Path, PathBuf};

use serde::{Deserialize, Serialize};

use crate::ports::python_stdlib::expanduser;

mod protect;
mod view;
pub use view::{from_ledger, previous, restore};

/// The record's file name; the hook refuses any session write that names it.
pub const STORE_NAME: &str = "approved_tests.json";
pub const USAGE: &str = "usage: tama tests approve <path>… [--json]  approve test code at each path (the operator's terminal only)
       tama tests revoke <path>… [--json]   withdraw an approval
       tama tests list [--json]      every approval, oldest first
       tama tests restore [--json]   write the record again from the attestation ledger (the operator's terminal only)
       tama tests audit [<root>…] [--remove] [--json]
                                     explicit repository or product-marked children of a directory; --remove deletes identified unapproved test files
       tama tests review <root>      ask the reviewer which unread tracked test files of a repository are smoke tests and keep the verdicts block-unapproved-tests decides writes by";
use tama_core::exit::{FAILURE as EXIT_FAILED, USAGE as EXIT_USAGE};

#[derive(Serialize, Deserialize, Default)]
pub struct Approvals {
    pub approved: Vec<Approval>,
}

#[derive(Serialize, Deserialize, Clone)]
pub struct Approval {
    pub path: String,
    pub approved_at: String,
}

/// Where the record lives.
pub fn store() -> PathBuf {
    PathBuf::from(expanduser("~/.config/agent-policy")).join(STORE_NAME)
}

/// Every approval; a record never written approves nothing. One that cannot
/// be read or parsed is an error naming it: read as approving nothing, an
/// approve rewrote the operator's record with the new path alone and an audit
/// with --remove deleted test files he had approved. So is a missing record
/// the ledger keeps approvals for ([`view`]): something removed it.
pub fn recorded() -> Result<Approvals, String> {
    let path = store();
    let text = match std::fs::read_to_string(&path) {
        Ok(text) => text,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
            view::missing()?;
            return Ok(Approvals::default());
        }
        Err(error) => {
            return Err(format!(
                "the test approvals {} cannot be read: {error}",
                path.display()
            ))
        }
    };
    serde_json::from_str(&text).map_err(|error| {
        format!(
            "the test approvals {} are not readable JSON: {error}",
            path.display()
        )
    })
}

/// `path` made absolute against `base`, with `~`, `.` and `..` resolved by
/// hand so a file that does not exist yet still compares.
pub fn absolute(path: &str, base: &Path) -> PathBuf {
    let expanded = PathBuf::from(expanduser(path));
    let joined = if expanded.is_absolute() {
        expanded
    } else {
        base.join(expanded)
    };
    let mut clean = PathBuf::new();
    for component in joined.components() {
        match component {
            Component::CurDir => {}
            Component::ParentDir => {
                clean.pop();
            }
            other => clean.push(other),
        }
    }
    clean
}

/// Whether an approval covers `path`: the same file, or a directory above it.
pub fn covers(approvals: &Approvals, path: &Path) -> bool {
    approvals
        .approved
        .iter()
        .any(|approval| path.starts_with(&approval.path))
}

/// Whether `path` is the approval record itself.
pub fn is_store(path: &Path) -> bool {
    path.file_name().and_then(|name| name.to_str()) == Some(STORE_NAME)
}

/// Approve or withdraw each of `paths`, resolved against `base`, and write the
/// record: the one change `tama tests` and Tama Desktop's Tests screen share.
/// Returns the absolute paths changed and the record as written.
pub fn change(
    paths: &[String],
    base: &Path,
    approve: bool,
) -> Result<(Vec<String>, Approvals), String> {
    if paths.is_empty() {
        return Err("name at least one path".to_string());
    }
    let mut approvals = recorded()?;
    let mut changed = Vec::new();
    for path in paths {
        let target = absolute(path, base).to_string_lossy().into_owned();
        approvals
            .approved
            .retain(|approval| approval.path != target);
        if approve {
            approvals.approved.push(Approval {
                path: target.clone(),
                approved_at: tama_core::clock::iso_now(),
            });
        }
        changed.push(target);
    }
    // The ledger keeps the act before the record changes, so a record that
    // fails to change is written again from the ledger, never lost.
    ledger(&changed, &approvals, approve)?;
    view::replace(&approvals).map_err(|error| {
        format!(
            "the attestation ledger keeps this change; writing the approval record failed: \
             {error}; `tama tests restore` writes the record from the ledger"
        )
    })?;
    Ok((changed, approvals))
}

/// Keep each changed approval in the attestation ledger, or withdraw it
/// there, beside the record the gate reads.
fn ledger(changed: &[String], approvals: &Approvals, approve: bool) -> Result<(), String> {
    use crate::attestation::{attest, withdraw, Attestation};
    let view = store().display().to_string();
    for target in changed {
        withdraw("test", &view, |kept| &kept.subject == target)?;
        let Some(approval) = approvals
            .approved
            .iter()
            .find(|approval| &approval.path == target)
        else {
            continue;
        };
        if approve {
            attest(Attestation {
                kind: "test".into(),
                subject: target.clone(),
                statement: serde_json::json!("approved test code"),
                attester: "operator".into(),
                scope: serde_json::json!({ "everything_below": true }),
                lifetime: serde_json::json!(approval.approved_at),
                verification: "artifact".into(),
                store: view.clone(),
                recorded_at: approval.approved_at.clone(),
            })?;
        }
    }
    Ok(())
}

fn change_command(args: &[String], approve: bool) -> i32 {
    let json = args.iter().any(|arg| arg == "--json");
    let paths: Vec<String> = args
        .iter()
        .filter(|arg| *arg != "--json")
        .cloned()
        .collect();
    let here = match std::env::current_dir() {
        Ok(here) => here,
        Err(error) => {
            eprintln!("tama tests: the paths to change are read against the working directory, which cannot be read: {error}");
            return EXIT_FAILED;
        }
    };
    match change(&paths, &here, approve) {
        Ok((changed, _)) => {
            let verb = if approve { "approved" } else { "revoked" };
            if json {
                println!(
                    "{}",
                    serde_json::json!({ "action": verb, "changed": changed })
                );
            } else {
                for target in changed {
                    println!("{verb} {target}");
                }
            }
            libc::EXIT_SUCCESS
        }
        Err(error) => {
            eprintln!("tama tests: {error}\n{USAGE}");
            if paths.is_empty() {
                EXIT_USAGE
            } else {
                EXIT_FAILED
            }
        }
    }
}

fn list(json: bool) -> i32 {
    let approvals = match recorded() {
        Ok(approvals) => approvals,
        Err(error) => {
            eprintln!("tama tests: {error}");
            return EXIT_FAILED;
        }
    };
    if json {
        println!("{}", tama_core::json::pretty(&approvals));
    } else if approvals.approved.is_empty() {
        println!("no test code is approved; record: {}", store().display());
    } else {
        for approval in &approvals.approved {
            println!("{}  {}", approval.approved_at, approval.path);
        }
    }
    libc::EXIT_SUCCESS
}

/// `tama tests review <root>` owns the foreground review requested after a
/// write identifies unread tracked test files; the write never starts it.
fn review(args: &[String]) -> i32 {
    let [root] = args else {
        eprintln!("{USAGE}");
        return EXIT_USAGE;
    };
    match crate::ports::smoke_tests::review_repository(Path::new(root)) {
        Ok(read) => {
            println!("{read}");
            libc::EXIT_SUCCESS
        }
        Err(refusal) => {
            eprintln!("tama tests review: {refusal}");
            EXIT_FAILED
        }
    }
}

/// `tama tests …`.
pub fn cli_main(args: &[String]) -> i32 {
    let Some((verb, rest)) = args.split_first() else {
        eprintln!("{USAGE}");
        return EXIT_USAGE;
    };
    match verb.as_str() {
        "approve" => change_command(rest, true),
        "revoke" => change_command(rest, false),
        "list" => list(rest.iter().any(|flag| flag == "--json")),
        "restore" => view::cli(rest.iter().any(|flag| flag == "--json")),
        "audit" => super::audit::cli_main(rest),
        "review" => review(rest),
        _ => {
            eprintln!("{USAGE}");
            EXIT_USAGE
        }
    }
}
