//! Tama's verdicts go into Oko's claim register (`oko claims`), the one
//! record of claims about work and the verdicts on them. A gate that judged
//! pushed commits records the claims and its verdicts there instead of
//! keeping a record of its own, so every reader that asks whether work was
//! verified (Oko's defect and work registers, Oko Desktop) sees the gate's
//! verdict without asking Tama. A machine without Oko records nothing and
//! says so: Tama runs without Oko.
//!
//! Every claim a gate judged goes to Oko in one `oko claims record --stdin`
//! call, which writes the register once: a push of hundreds of commits
//! started two Oko processes per commit, each reading and writing the whole
//! register, and held the push for many minutes after its review passed.

use std::io::Write;
use std::process::{Command, Stdio};

use serde_json::{json, Value};

use crate::assignment::rules::{oko_cli, oko_installed};

/// One claim a gate judged and what it found, in the words `oko claims`
/// takes: the class (`push`, `tool-call`), the verifier kind (`structural`,
/// `judge`) and the finding (`holds`, `broken`, `unavailable`).
pub struct Judged<'a> {
    pub class: &'a str,
    /// The item or commit it is about; a commit is `<repository>@<commit>`.
    pub subject: &'a str,
    pub assertion: &'a str,
    /// The revision it is about, `<repository>@<commit>`.
    pub revision: &'a str,
    pub kind: &'a str,
    /// The gate that judged it.
    pub by: &'a str,
    pub method: &'a str,
    pub evidence: &'a str,
    pub finding: &'a str,
}

/// `judged` as one entry of `oko claims record --stdin`: the claim and the
/// verdict on it.
fn entry(judged: &Judged<'_>) -> Value {
    json!({
        "class": judged.class,
        "subject": judged.subject,
        "assertion": judged.assertion,
        "revision": judged.revision,
        "evidence": judged.evidence,
        "verdict": {
            "finding": judged.finding,
            "kind": judged.kind,
            "by": judged.by,
            "method": judged.method,
            "evidence": judged.evidence,
            "revision": judged.revision,
        },
    })
}

/// Record every claim of `judged` with the gate's verdict on it, in one
/// write of Oko's register. `Ok(Some(count))` is how many Oko recorded;
/// `Ok(None)` when this machine has no Oko to record them in. The same
/// class, subject and revision recorded again is the claim Oko already
/// keeps, and the verdict is added to it.
pub fn record_all(judged: &[Judged<'_>]) -> Result<Option<usize>, String> {
    if !oko_installed() {
        return Ok(None);
    }
    let shown = format!("{} claims record --stdin --json", oko_cli());
    let entries = Value::Array(judged.iter().map(entry).collect());
    let mut child = Command::new(oko_cli())
        .args(["claims", "record", "--stdin", "--json"])
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .map_err(|error| format!("{shown} did not start: {error}"))?;
    // Oko reads the whole array before it writes; an array it never received
    // whole would record nothing, so a failed write is the failure.
    let sent = match child.stdin.take() {
        Some(mut stdin) => stdin.write_all(entries.to_string().as_bytes()),
        None => Err(std::io::Error::other("its standard input was not opened")),
    };
    let output = stado_wait::child_output(child, &shown)
        .map_err(|error| format!("{shown} did not run: {error}"))?;
    if let Err(error) = sent {
        return Err(format!("{shown} was not given the claims: {error}"));
    }
    if !output.status.success() {
        return Err(format!(
            "{shown} exited {}: {}",
            output.status,
            String::from_utf8_lossy(&output.stderr).trim()
        ));
    }
    let recorded: Vec<Value> = serde_json::from_slice(&output.stdout).map_err(|error| {
        format!(
            "{shown} printed no list of claims ({error}): {}",
            String::from_utf8_lossy(&output.stdout).trim()
        )
    })?;
    Ok(Some(recorded.len()))
}
