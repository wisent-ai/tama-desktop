//! What the install changes, recorded so it can be put back: each path is
//! backed up before it is first written or deleted, each disabled entrypoint
//! restored is remembered, and a rollback undoes both, naming every step that
//! fails.

use std::collections::BTreeSet;
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};

use super::super::super::package::copy_tree;

pub(super) struct Transaction {
    pub(super) backup_root: PathBuf,
    originals: Vec<(PathBuf, Option<PathBuf>)>,
    remembered: BTreeSet<PathBuf>,
    moves: Vec<(PathBuf, PathBuf)>,
}

/// Whether anything, a link included, is at `path`. A path that cannot be
/// examined is the error: read as absent, it was written over without the
/// backup a rollback restores.
pub(super) fn present(path: &Path) -> Result<bool, String> {
    match std::fs::symlink_metadata(path) {
        Ok(_) => Ok(true),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(false),
        Err(error) => Err(format!("{} cannot be examined: {error}", path.display())),
    }
}

/// Remove `path`, whatever it is. A path already absent is removed; any other
/// failure is named, since a leftover file is then installed or restored over.
pub(super) fn remove(path: &Path) -> Result<(), String> {
    let removed = match std::fs::symlink_metadata(path) {
        Ok(m) if m.is_dir() => std::fs::remove_dir_all(path),
        Ok(_) => std::fs::remove_file(path),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(()),
        Err(error) => Err(error),
    };
    removed.map_err(|error| format!("cannot remove {}: {error}", path.display()))
}

impl Transaction {
    pub(super) fn new(backup_root: PathBuf) -> Result<Self, String> {
        let parent = backup_root.parent().ok_or_else(|| {
            format!(
                "the backup folder {} has no parent folder",
                backup_root.display()
            )
        })?;
        std::fs::create_dir_all(parent)
            .map_err(|error| format!("cannot create {}: {error}", parent.display()))?;
        std::fs::create_dir(&backup_root)
            .map_err(|error| format!("cannot create {}: {error}", backup_root.display()))?;
        Ok(Self {
            backup_root,
            originals: Vec::new(),
            remembered: BTreeSet::new(),
            moves: Vec::new(),
        })
    }

    fn remember(&mut self, path: &Path) -> Result<(), String> {
        if !self.remembered.insert(path.to_path_buf()) {
            return Ok(());
        }
        if present(path)? {
            let backup = self.backup_root.join(self.originals.len().to_string());
            copy_tree(path, &backup)?;
            self.originals.push((path.to_path_buf(), Some(backup)));
        } else {
            self.originals.push((path.to_path_buf(), None));
        }
        Ok(())
    }

    pub(super) fn write(&mut self, path: &Path, data: &[u8], mode: u32) -> Result<(), String> {
        self.remember(path)?;
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent)
                .map_err(|error| format!("cannot create {}: {error}", parent.display()))?;
        }
        let Some(name) = path.file_name() else {
            return Err(format!(
                "cannot write {}: the path names no file",
                path.display()
            ));
        };
        let temporary = path.with_file_name(format!(
            "{}.tama-install-{}",
            name.to_string_lossy(),
            std::process::id()
        ));
        std::fs::write(&temporary, data)
            .map_err(|error| format!("cannot write {}: {error}", temporary.display()))?;
        std::fs::set_permissions(&temporary, std::fs::Permissions::from_mode(mode)).map_err(
            |error| {
                format!(
                    "cannot set the mode {mode:o} on {}: {error}",
                    temporary.display()
                )
            },
        )?;
        std::fs::rename(&temporary, path)
            .map_err(|error| format!("cannot replace {}: {error}", path.display()))
    }

    pub(super) fn delete(&mut self, path: &Path) -> Result<(), String> {
        self.remember(path)?;
        remove(path)?;
        Ok(())
    }

    pub(super) fn restore(&mut self, disabled: &Path, source: &Path) -> Result<(), String> {
        if present(source)? {
            return Err(format!(
                "Both active and disabled hook entrypoints exist: {}",
                source.display()
            ));
        }
        if !present(disabled)? {
            return Err(format!(
                "Missing disabled hook entrypoint: {}",
                disabled.display()
            ));
        }
        if let Some(parent) = source.parent() {
            std::fs::create_dir_all(parent)
                .map_err(|error| format!("cannot create {}: {error}", parent.display()))?;
        }
        std::fs::rename(disabled, source).map_err(|error| {
            format!(
                "cannot restore {} to {}: {error}",
                disabled.display(),
                source.display()
            )
        })?;
        self.moves
            .push((source.to_path_buf(), disabled.to_path_buf()));
        Ok(())
    }

    /// Put every move and original back; each step that fails is returned,
    /// so the caller keeps the backups those steps would have restored from.
    pub(super) fn rollback(&self) -> Vec<String> {
        let mut failed = Vec::new();
        for (source, disabled) in self.moves.iter().rev() {
            let moved_in = match present(source) {
                Ok(moved_in) => moved_in,
                Err(cause) => {
                    failed.push(cause);
                    continue;
                }
            };
            if moved_in {
                if let Some(parent) = disabled.parent() {
                    if let Err(error) = std::fs::create_dir_all(parent) {
                        failed.push(format!("create {}: {error}", parent.display()));
                        continue;
                    }
                }
                if let Err(error) = std::fs::rename(source, disabled) {
                    failed.push(format!(
                        "move {} back to {}: {error}",
                        source.display(),
                        disabled.display()
                    ));
                }
            }
        }
        for (path, backup) in self.originals.iter().rev() {
            if let Err(error) = remove(path) {
                failed.push(error);
                continue;
            }
            if let Some(backup) = backup {
                if let Err(error) = copy_tree(backup, path) {
                    failed.push(format!(
                        "restore {} from {}: {error}",
                        path.display(),
                        backup.display()
                    ));
                }
            }
        }
        failed
    }
}
