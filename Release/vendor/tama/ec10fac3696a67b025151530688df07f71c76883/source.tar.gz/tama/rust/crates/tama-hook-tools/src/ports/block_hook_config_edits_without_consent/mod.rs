//! Decision half of `tama hook block-hook-config-edits-without-consent`
//! (registry hook `block-hook-config-edits-without-consent`).
//!
//! Device-level guard: adding or editing hook sources and configs is refused
//! unless the user approved hook changes out of band with
//! `DEVICE_HOOK_EDIT_APPROVED=1`.
//!
//! One deliberate behaviour fix, and only this one. The Python matched
//! `PROTECTED_PATH_RE` against the raw path text, so `shared-hooks/x.py` typed
//! from the repository root walked straight through a gate that caught
//! `/…/tama/shared-hooks/x.py`. Here every candidate path — write-tool
//! targets and the tokens of execution-tool command text alike — is also
//! matched against its resolution under the payload's `cwd` (the process
//! directory when the payload carries none), so the relative and the absolute
//! spelling of the same write are refused together. Resolution only ever adds
//! matches, so nothing the Python blocked is let through.
//!
//! Second deliberate fix, on the operator's instruction that the registries
//! must be usable without granting hook-edit consent: the justification
//! registries under `.shared-hooks/` are exempt by the shape of their name
//! rather than by a two-entry list, in the raw and the resolved spelling
//! alike, and inside command text as well as write-tool paths. The list had
//! never grown past `file_justifications.json` and `ssh_justification.json`,
//! so `require-new-file-justification` demanded an entry in
//! `test_justifications.json` that no agent could add - a gate whose key was
//! locked behind this one. `bash_targets_hook_modification` is still not
//! ported: `main` never called it, so it has no behaviour to preserve.
//!
//! Third deliberate fix: a tool whose whole job is to write hook
//! configuration reaches none of the tests above, because the path it
//! writes is inside the tool and running a program is neither a redirect nor
//! a copy. `tama hook generate-configs --apply` can rewrite a machine's
//! Claude and Codex hook configurations from inside a session with nothing
//! for the guard to see. `writers` names those tools; a run that only
//! reports is still allowed.
//!
//! Fourth: an execution payload that names a protected path where the path
//! can act (outside a shell's quoted data, anywhere in code) is a change to
//! it, whatever program runs. The shell-writer, language-call and
//! patch-applier lists that decided it before let every writer they left
//! out through; reading a hook goes through the harness's read tool.

pub(crate) mod recovery;
mod tables;
pub(crate) mod writers;

use serde_json::Value;
use tama_hooks::session_record::{deny_tool_use, read_payload};

use super::block_hook_config_edits_without_consent_gate::Gate;
use super::pyvalue::py_json_dumps;
use super::tool_vocabulary::{Call, PATCH_TOOLS};

pub const APPROVAL_ENV: &str = "DEVICE_HOOK_EDIT_APPROVED";
/// The value the owner exports, as https://tama.wisent.com/docs/hook-management
/// states it: "DEVICE_HOOK_EDIT_APPROVED=1, exported outside the session".
const APPROVAL_VALUE: &str = "1";
const DOCS: &[&str] = &["https://tama.wisent.com/docs/hook-management"];
/// Tools that run something besides the shell, evaluation and process tools
/// `Call::runs` already reads: a remote shell, a debugger, a browser.
const EXECUTION_TOOLS: &[&str] = &["ssh", "debug", "browser", "node_repl"];
const HOOKSPATH_NEEDLE: &str = "hookspath";
const PATCH_TARGET_NOTE: &str = "apply_patch payload can create/edit hook source/config";

/// `"hookspath" in json.dumps(value, ensure_ascii=False).lower()`.
fn mentions_git_hookspath(value: &Value) -> bool {
    py_json_dumps(value)
        .to_lowercase()
        .contains(HOOKSPATH_NEEDLE)
}

fn block_reason(targets: &[String]) -> String {
    let docs = DOCS.join(" | ");
    let listed = targets.join(", ");
    format!(
        "BLOCKED: hook source/config changes are device-level protected, and the operator has not \
         consented to them in this session. Consent he gives in the conversation is recorded as \
         the Tama session capability {{\"tool\": \"tama\", \"actions\": [\"hook-edit\"]}} with the \
         lifetime he named; {APPROVAL_ENV}=1 in the session's environment counts too. Read hook \
         scope docs: {docs}. Target(s): {listed}"
    )
}

fn write_tool_targets(gate: &Gate, input: &Value, tool: &str) -> Result<Vec<String>, String> {
    let mut paths: Vec<String> = Vec::new();
    gate.candidate_paths(input, &mut paths)?;
    let mut targets: Vec<String> = paths
        .into_iter()
        .filter(|path| !path.is_empty())
        .filter(|path| {
            gate.protected_path(path)
                || (gate.git_config_path(path) && mentions_git_hookspath(input))
        })
        .collect();
    if targets.is_empty()
        && PATCH_TOOLS.contains(&tool)
        && (gate.command_mentions_protected_path(&py_json_dumps(input))
            || mentions_git_hookspath(input))
    {
        targets.push(PATCH_TARGET_NOTE.to_string());
    }
    Ok(targets)
}

pub fn run() {
    let parsed = read_payload();
    let payload = match parsed {
        Value::Object(_) => parsed,
        _ => Value::Object(Default::default()),
    };
    let call = Call::of(&payload);
    let tool = call.kind().unwrap_or_default();
    let is_write = call.is_write();
    let is_execution = call.runs() || call.is_one_of(EXECUTION_TOOLS);
    if !is_write && !is_execution {
        return;
    }
    let empty = Value::Object(Default::default());
    let input = match call.input() {
        Some(input) => input,
        None => &empty,
    };

    // The break-glass controls come first and have no consent switch: consent
    // to edit a hook is not consent to turn the enforcement off.
    let gate = match Gate::new(&payload) {
        Ok(gate) => gate,
        Err(why) => deny_tool_use(&format!(
            "BLOCKED: block-hook-config-edits-without-consent: {why}"
        )),
    };
    let breaks_glass = if is_write {
        match gate.operator_recovery_write_target(input) {
            Ok(recovery) => recovery,
            Err(cause) => deny_tool_use(&format!(
                "BLOCKED: hook-protection targets cannot be resolved: {cause}"
            )),
        }
    } else {
        gate.operator_recovery_execution_target(&payload)
    };
    if breaks_glass {
        deny_tool_use(recovery::BLOCK_REASON);
    }

    let targets = if is_write {
        match write_tool_targets(&gate, input, &tool) {
            Ok(targets) => targets,
            Err(cause) => deny_tool_use(&format!(
                "BLOCKED: hook-protection targets cannot be resolved: {cause}"
            )),
        }
    } else {
        match gate.execution_runs_hook_config_writer(&payload) {
            Some(reason) => {
                vec![format!(
                    "{tool} payload runs a hook-configuration writer: {reason}"
                )]
            }
            None => match gate.execution_hook_modification(&payload) {
                Some(why) => vec![format!(
                    "{tool} payload can create/edit hook source/config: {why}"
                )],
                None => Vec::new(),
            },
        }
    };

    if targets.is_empty() {
        return;
    }
    if matches!(std::env::var(APPROVAL_ENV), Ok(value) if value == APPROVAL_VALUE) {
        return;
    }
    // Consent the operator gave in this session's conversation counts as much
    // as consent he exported before it started; it arrives as the session
    // capability the runner validated.
    if super::hook_edit_consent::granted() {
        eprintln!("block-hook-config-edits-without-consent: allowed by the operator's tama hook-edit capability in this session");
        return;
    }
    deny_tool_use(&block_reason(&targets));
}
