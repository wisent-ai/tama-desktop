//! `tama reviews harsh record`: one round of a commit's harsh review, in
//! the two parts every review states. `--findings` lists what the reviewer
//! finds to improve in the change; `--improvements` lists what new the
//! change suggests would further improve the codebase (the same shape
//! elsewhere, the root cause, its visibility, the real case untested). Each
//! item quotes the patch or the message, `[]` when there is none, and
//! `tama hook review-commit` lets the commit through only on a round whose
//! two lists are empty ([`tama_hook_tools::ports::harsh_review::verdict`]).

pub(super) mod stale;

use tama_hook_tools::ports::harsh_review::{
    digest, keep, now_ms, queue, register, reviewer_here, staged_patch, staged_tree, unquoted,
    Entry, Finding,
};

use super::harsh::{option, repository, required, text};

/// The list of `{quote, problem, require}` in the file `name` names.
fn listed(args: &[String], name: &str) -> Result<Vec<Finding>, String> {
    serde_json::from_str(&text(required(args, name)?)?).map_err(|cause| {
        format!("the {name} file is not a list of {{quote, problem, require}}: {cause}")
    })
}

/// Record the round `args` names: on a queued candidate (`--queue`), on a
/// recorded attestation (`--attestation`), or on the candidate staged in
/// `--repository` with the message in `--message`. A staged round is kept,
/// then Oko's harsh-review queue is listed and every open entry queuing that
/// very candidate is marked reviewed ([`super::queue::open_for`]); a failure
/// after the round was kept fails the command with the round standing, and
/// the same record run again keeps no second copy and marks what is open.
pub(super) fn record(args: &[String]) -> Result<String, String> {
    let findings = listed(args, "--findings")?;
    let improvements = listed(args, "--improvements")?;
    if let Some(id) = option(args, "--queue") {
        return super::queue::record(id, findings, improvements);
    }
    if let Some(named) = option(args, "--attestation") {
        return super::attested::record(named, findings, improvements);
    }
    let repository = repository(args)?;
    let message = text(required(args, "--message")?)?;
    let patch = staged_patch(&repository)?;
    for items in [&findings, &improvements] {
        if let Some(unread) = unquoted(items, &patch, &message) {
            return Err(format!(
                "the item quoting {:?} quotes text found neither in the staged patch nor in the message",
                unread.quote
            ));
        }
    }
    let reviewer = reviewer_here()?;
    let path = register(&repository)?;
    let tree = staged_tree(&repository)?;
    // The reviewer names the tree it read (`--tree`); an index restaged
    // since then writes another tree, which no one read, so no round over it
    // is kept.
    if let Some(read) = option(args, "--tree") {
        if read != tree {
            return Err(format!(
                "the round names tree {read}, but the index of {} now writes tree {tree}: it was \
                 restaged after the review read it, so no round was kept; review the tree it holds now",
                repository.display()
            ));
        }
    }
    // A round admits a commit, so it is kept only over a tree the product's
    // own declared gates pass (its format gates, then its compile and lint
    // gates; test gates run with the build), on this exact tree before the
    // round is kept.
    tama_hook_tools::programs::quality_check::staged_gates(&repository, &tree)?;
    let parent = tama_hook_tools::ports::harsh_review::parent(&repository)?;
    let found = findings.len();
    let suggested = improvements.len();
    let added = keep(
        &path,
        &Entry::Round {
            tree: tree.clone(),
            parent: Some(parent.clone()),
            message: digest(&message),
            reviewer: reviewer.clone(),
            findings,
            improvements: Some(improvements),
            at_ms: now_ms()?,
        },
    )?;
    let kept = format!(
        "{} by {} over staged tree {tree}: {found} findings, {suggested} improvements, in {}",
        if added {
            "recorded a round"
        } else {
            "found this very round already kept"
        },
        reviewer.named(),
        path.display()
    );
    // The round is kept before Oko is asked, so a queue that cannot be read
    // or does not answer leaves the round standing; the same record run again
    // keeps no second copy (`keep`) and marks what is still open. A rerun
    // helps only once Oko lists its queue: an Oko without the harsh-review
    // queue never does, so that is said rather than promised away.
    const AGAIN: &str = "running this record again marks it and keeps no second round";
    let unlisted = |cause: String| {
        format!(
            "{kept}; no harsh-review queue entry was marked, since {cause}; the round stands, and \
             only once {} lists its harsh-review queue (an Oko without that queue never does) does \
             running this record again mark an entry, keeping no second round",
            tama_hook_tools::assignment::rules::oko_cli()
        )
    };
    let listing = queue::listed()
        .map_err(|cause| unlisted(format!("Oko's queue could not be listed: {cause}")))?;
    let open = super::queue::open_for(&listing, &path, &tree, &parent, &message, &reviewer)
        .map_err(|cause| unlisted(format!("Oko's listing is not its queue: {cause}")))?;
    let mut marked: Vec<String> = Vec::new();
    let mut answered_by_others: Vec<String> = Vec::new();
    let mut unmarked: Vec<String> = Vec::new();
    for covered in &open.covered {
        let id = &covered.id;
        // An entry Oko handed to a session is marked too; that session is
        // named, since Tama tells it nothing and its own round is refused.
        let shown = match &covered.holder {
            Some(holder) => format!("{id} (assigned to {holder})"),
            None => id.clone(),
        };
        let refused = match queue::done(id, &reviewer, found + suggested) {
            Ok(_) => {
                marked.push(shown);
                continue;
            }
            Err(refused) => refused,
        };
        // Oko may have kept a round since the entry was listed: another
        // reviewer's, which it keeps as the first, or this one's, written
        // before Oko's answer failed.
        match queue::entry(id) {
            Ok(since) => match since["reviewedBy"].as_str() {
                Some(by) if by == queue::named(&reviewer) => marked.push(shown),
                Some(by) => answered_by_others.push(format!("{id} (reviewed by {by})")),
                None => unmarked.push(format!("{id}: {refused}")),
            },
            Err(cause) => unmarked.push(format!(
                "{id}: {refused}, and it cannot be read again to tell whether a round marked it: {cause}"
            )),
        }
    }
    let mut said = kept;
    if !marked.is_empty() {
        said.push_str(&format!(
            "; Oko marks queue entry {} reviewed",
            marked.join(", ")
        ));
    }
    if !answered_by_others.is_empty() {
        said.push_str(&format!(
            "; queue entry {} was marked by another round meanwhile, which Oko keeps",
            answered_by_others.join(", ")
        ));
    }
    if !open.other_message.is_empty() {
        said.push_str(&format!(
            "; queue entry {} names this tree over this parent with another message, so this round does \
             not cover it and it stays open",
            open.other_message.join(", ")
        ));
    }
    if !unmarked.is_empty() {
        said.push_str(&format!(
            "; Oko did not mark harsh-review queue entry {}; {AGAIN}",
            unmarked.join("; entry ")
        ));
    }
    if !open.unplaced.is_empty() {
        said.push_str(&format!(
            "; queue entry {} queues this very candidate, but whether its author's commit reads this \
             round's register cannot be told",
            open.unplaced.join(", ")
        ));
    }
    if unmarked.is_empty() && open.unplaced.is_empty() {
        Ok(said)
    } else {
        Err(said)
    }
}
