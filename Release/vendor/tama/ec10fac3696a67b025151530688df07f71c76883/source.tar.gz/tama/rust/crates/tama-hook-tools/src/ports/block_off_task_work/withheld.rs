//! Whether the operator's rulings withhold a session's change to one
//! repository, over Oko's ruling register read as a file
//! (`tama_hooks::oko_rulings::edit`).

use std::cell::OnceCell;

use tama_hooks::oko_rulings::edit::{self as edit_rulings, Edit, Readable};

use crate::capability::standing::Ruled;

/// The action class a ruling constrains that changing a repository's files
/// is, as Oko names it.
const EDIT: &str = "edit";

/// Why the operator's rulings refuse this session's change to `repository`
/// now, read from Oko's register (`register`): his "nie koduj" to this
/// conversation is held as `no-edit@session:<id>` and refuses its edits
/// until a later ruling lets it code, while reading and planning stay
/// possible because neither writes. The refusal quotes the ruling, its id
/// and his words, so the session reads what he said before it asks him.
/// A consent scoped to a defect or a withdrawal a category releases depends
/// on Oko's defect register: when one is the newest that applies, Oko's
/// admission (`oko admit edit`) decides this call, the only one that starts
/// Oko. An unreadable entry whose subjects withdraw this change refuses it;
/// other unread entries are named beside a refusal and said when the change
/// passes ([`unread_note`]).
pub(super) fn edit_unadmitted(
    repository: &str,
    session: &str,
    register: &Readable,
) -> Option<String> {
    let unread = match register.unread_named().as_slice() {
        [] => String::new(),
        unread => format!(
            " (not read in the operator's ruling register: {})",
            unread.join("; ")
        ),
    };
    let later = format!(
        "Reading and planning stay possible; a later ruling of his on edit@session:{session} lets this session change files again{unread}."
    );
    match edit_rulings::decide(register, repository, session) {
        Edit::Admitted => None,
        Edit::Withheld(ruling, subject) => Some(format!(
            "BLOCKED: block-off-task-work: the operator's ruling {} ({subject}, said {}) withholds changing {repository} in this session; his words: \"{}\". {later}",
            ruling.id,
            ruling.when(),
            ruling.said.trim()
        )),
        Edit::Unreadable(entry, subject) => Some(format!(
            "BLOCKED: block-off-task-work: a ruling of the operator withholds changing {repository} in this session by {subject}, and it cannot be read ({}), so it stands until Oko's register reads it again (oko rulings list --subject '{subject}'). {later}",
            entry.cause
        )),
        Edit::Oko(ruling, subject) => match crate::capability::standing::ruled(EDIT, Some(repository), Some(session)) {
            Ruled::Consented(_) | Ruled::Unruled => None,
            Ruled::Forbidden(reason) | Ruled::Waiting(reason) => Some(format!(
                "BLOCKED: block-off-task-work: the operator's rulings withhold changing {repository} in this session, as Oko's admission reads his ruling {} ({subject}: \"{}\"): {reason}. {later}",
                ruling.id,
                ruling.said.trim()
            )),
            Ruled::Unread(cause) | Ruled::Undecidable(cause) => Some(format!(
                "BLOCKED: block-off-task-work: the operator's ruling {} ({subject}: \"{}\") is the newest that applies to changing {repository} in this session, and only Oko's admission can decide it, since it depends on Oko's defect register; that admission could not be read: {cause}. {later}",
                ruling.id,
                ruling.said.trim()
            )),
        },
    }
}

/// What a change that passed is told about the operator's ruling register
/// when part of it cannot be read: which entries, so a ruling of his that
/// Tama could not read is said, never silently dropped. `register` is the
/// read the decision was made on ([`super::evaluate`]), so the note names
/// exactly those entries. None when the whole register read, or when the
/// decision never needed it (the change reached no repository).
pub fn unread_note(register: &OnceCell<Readable>) -> Option<String> {
    let register = register.get()?;
    match register.unread_named().as_slice() {
        [] => None,
        unread => Some(format!(
            "block-off-task-work: this change passed on the operator's rulings that can be read; these could not be, and a ruling of his among them is not applied until they read again: {}",
            unread.join("; ")
        )),
    }
}
