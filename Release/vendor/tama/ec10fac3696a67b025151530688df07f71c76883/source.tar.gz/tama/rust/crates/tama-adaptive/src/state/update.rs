//! One transition: the lock it takes, the fact it journals, and the
//! projection it persists.
//!
//! Split out of `state/mod.rs`, which had grown past the
//! three-hundred-line limit; reading state stays there.

use super::lock::LockOwnership;
use super::projections::Projection;
use super::{key_of, valid_state, HookState, StateStore, TransitionResult};

impl StateStore {
    /// `update(hookId, transition, fact)`. A lock acquisition failure
    /// propagates like the JS throw outside the `try` block. `transition`
    /// is given the prior state and the id of the fact it is applied for.
    pub fn update<F>(
        &self,
        hook_id: &str,
        transition: F,
        fact: Option<serde_json::Value>,
    ) -> std::io::Result<TransitionResult>
    where
        F: FnOnce(&HookState, &str) -> Projection,
    {
        let id = hook_id.to_string();
        if id.is_empty() {
            return Ok(TransitionResult {
                ok: false,
                persisted: false,
                mode: String::new(),
                transition: None,
                reason: Some("missing-hook-id".to_string()),
                state: HookState::initial(&id),
            });
        }
        let ownership: LockOwnership = self.locks.acquire(&key_of(&id))?;
        let result = self.update_locked(&id, transition, fact);
        self.locks.release(Some(ownership));
        Ok(result)
    }

    fn update_locked<F>(
        &self,
        id: &str,
        transition: F,
        fact: Option<serde_json::Value>,
    ) -> TransitionResult
    where
        F: FnOnce(&HookState, &str) -> Projection,
    {
        match self.try_update(id, transition, fact) {
            Ok(result) => result,
            Err(error) => {
                (self.warn)(&format!(
                    "adaptive state persistence failed for {}: {}",
                    id, error
                ));
                TransitionResult {
                    ok: false,
                    persisted: false,
                    mode: String::new(),
                    transition: None,
                    reason: Some("persistence-failed".to_string()),
                    state: HookState::initial(id),
                }
            }
        }
    }

    fn try_update<F>(
        &self,
        id: &str,
        transition: F,
        fact: Option<serde_json::Value>,
    ) -> Result<TransitionResult, String>
    where
        F: FnOnce(&HookState, &str) -> Projection,
    {
        let prior = self.read_state(id, true)?;
        let fact = fact
            .filter(|f| f.is_object())
            .ok_or("missing adaptive transition fact")?;
        let fact_id = tama_core::random::random_uuid()?;
        let mut durable_fact = serde_json::Map::new();
        durable_fact.insert("id".into(), fact_id.as_str().into());
        durable_fact.insert("hookId".into(), id.into());
        if let serde_json::Value::Object(extra) = fact {
            durable_fact.extend(extra);
        }
        let durable_fact = serde_json::Value::Object(durable_fact);
        let result = transition(&prior, &fact_id);
        if !result.changed {
            let transition_name = result.transition;
            // JS: `transition` key only added when truthy; all projection
            // transition names are non-empty strings, so it is always set.
            return Ok(TransitionResult {
                ok: true,
                persisted: true,
                mode: String::new(),
                transition: Some(transition_name.to_string()),
                reason: None,
                state: prior,
            });
        }
        let transition_name = result.transition;
        let mut next = result.state;
        // A projection the store would refuse is refused before its fact is
        // journaled, so the journal never holds a fact no state follows.
        let invalid =
            |cause: String| format!("the projection {transition_name} of {id} is invalid: {cause}");
        valid_state(&next.to_value(), id).map_err(invalid)?;
        let journaled = self
            .journal
            .append(id, &durable_fact)
            .map_err(|error| format!("the fact journal of {id} cannot be appended to: {error}"))?;
        next.journal_count = i64::try_from(journaled)
            .map_err(|error| format!("the fact journal of {id} counts past i64: {error}"))?;
        let checked = valid_state(&next.to_value(), id).map_err(invalid)?;
        self.persist(id, &checked)
            .map_err(|error| format!("the projection of {id} cannot be persisted: {error}"))?;
        Ok(TransitionResult {
            ok: true,
            persisted: true,
            mode: String::new(),
            transition: Some(transition_name.to_string()),
            reason: None,
            state: checked,
        })
    }
}
