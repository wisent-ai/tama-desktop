//! Running git, and the three answers both checkout commands need from it.
//!
//! `worktrees` and `copies` ask git different questions about the same
//! machine, and both need the same plumbing: run a command inside a
//! directory, resolve a path the way the filesystem sees it, and say whether a
//! checkout carries uncommitted work. These lived privately in
//! `worktrees/porcelain.rs` until `copies` needed them; the worktree porcelain
//! parser stayed there, because only that command reads it.

use std::path::{Path, PathBuf};

use tama_core::git::Git;

/// Local inventory must not authenticate or fetch a partial clone's missing
/// objects.
const NO_LAZY_FETCH: &[(&str, &str)] = &[("GIT_NO_LAZY_FETCH", "1")];

/// `git -C <dir> <args>` through Tama's one Git runner, its standard output.
pub(crate) fn git(dir: &Path, args: &[&str]) -> Result<String, String> {
    let printed = Git::of(Some(dir)).variables(NO_LAZY_FETCH).bytes(args)?;
    Ok(String::from_utf8_lossy(&printed).into_owned())
}

/// A checkout is dirty when `git status --porcelain` prints anything. A path
/// git has already lost has no status to read and is not dirty; a status git
/// cannot give is the error, never read as clean, since a clean checkout is
/// one the cleanup may remove.
pub(crate) fn is_dirty(path: &Path) -> Result<bool, String> {
    if !path.is_dir() {
        return Ok(false);
    }
    git(path, &["status", "--porcelain"]).map(|text| !text.trim().is_empty())
}

/// The path as the filesystem knows it, so a symlinked or trailing-slashed
/// spelling compares equal to git's own answer. A path that cannot be
/// resolved is compared as written.
pub(crate) fn canonical(path: &Path) -> PathBuf {
    match std::fs::canonicalize(path) {
        Ok(resolved) => resolved,
        Err(_unresolved) => path.to_path_buf(),
    }
}

pub(crate) fn same_path(left: &str, right: &Path) -> bool {
    canonical(Path::new(left)) == canonical(right)
}

/// Git may silently walk up to a parent when a candidate's metadata is
/// damaged. Never use that parent's history to authorize deleting the child.
pub(crate) fn verify_repository(path: &Path) -> Result<(), String> {
    let bare = git(path, &["rev-parse", "--is-bare-repository"])?;
    let root_option = if bare.trim() == "true" {
        "--absolute-git-dir"
    } else {
        "--show-toplevel"
    };
    let root = git(path, &["rev-parse", root_option])?;
    if !same_path(root.trim(), path) {
        return Err(format!(
            "git resolved {} to a different repository: {}",
            path.display(),
            root.trim()
        ));
    }
    Ok(())
}
