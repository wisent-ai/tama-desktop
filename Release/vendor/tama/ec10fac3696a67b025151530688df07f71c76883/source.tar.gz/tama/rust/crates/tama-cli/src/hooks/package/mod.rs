//! Packaging a hook release, the half a release build runs:
//! `tama hooks stage` builds and places the native programs a prepared
//! release runs, and `tama hooks seal` makes it deployable and names it by
//! its digest. `release/build.sh` runs both with the `tama` it just built;
//! the installer that reads what they wrote is `hooks::install`.

mod cargo;
pub(crate) mod identity;
pub(crate) mod seal;
pub(crate) mod stage;

use std::path::{Path, PathBuf};

use serde_json::Value;
use tama_core::exit;

const SOURCE_ROOT: &str = "--source-root";

/// A JSON object read from `path`, or why it is not one.
pub(crate) fn load_object(path: &Path) -> Result<Value, String> {
    let text = std::fs::read_to_string(path)
        .map_err(|error| format!("cannot read {}: {error}", path.display()))?;
    let value: Value = serde_json::from_str(&text)
        .map_err(|error| format!("{} is not JSON: {error}", path.display()))?;
    if !value.is_object() {
        return Err(format!("Expected a JSON object: {}", path.display()));
    }
    Ok(value)
}

/// `value` written to `path` as indented JSON with a trailing newline.
pub(crate) fn write_json(path: &Path, value: &Value) -> Result<(), String> {
    let text = serde_json::to_string_pretty(value).map_err(|error| error.to_string())?;
    std::fs::write(path, format!("{text}\n"))
        .map_err(|error| format!("cannot write {}: {error}", path.display()))
}

/// Copy a file, or a directory with everything under it, keeping modes;
/// directories that already exist are merged into.
pub(crate) fn copy_tree(from: &Path, to: &Path) -> Result<(), String> {
    let metadata = std::fs::symlink_metadata(from)
        .map_err(|error| format!("cannot read {}: {error}", from.display()))?;
    if metadata.file_type().is_symlink() {
        let target = std::fs::read_link(from)
            .map_err(|error| format!("cannot read the link {}: {error}", from.display()))?;
        if let Some(parent) = to.parent() {
            std::fs::create_dir_all(parent)
                .map_err(|error| format!("cannot create {}: {error}", parent.display()))?;
        }
        if let Some(left) = tama_hooks::staging::remove(to) {
            return Err(format!(
                "cannot replace {} with a link: {left}",
                to.display()
            ));
        }
        return std::os::unix::fs::symlink(target, to)
            .map_err(|error| format!("cannot link {}: {error}", to.display()));
    }
    if metadata.is_dir() {
        std::fs::create_dir_all(to)
            .map_err(|error| format!("cannot create {}: {error}", to.display()))?;
        // An entry that cannot be read fails the copy: skipped, the package
        // would ship without it and say nothing.
        for entry in std::fs::read_dir(from)
            .map_err(|error| format!("cannot list {}: {error}", from.display()))?
        {
            let entry =
                entry.map_err(|error| format!("cannot list {}: {error}", from.display()))?;
            copy_tree(&entry.path(), &to.join(entry.file_name()))?;
        }
        return Ok(());
    }
    if let Some(parent) = to.parent() {
        std::fs::create_dir_all(parent)
            .map_err(|error| format!("cannot create {}: {error}", parent.display()))?;
    }
    std::fs::copy(from, to).map(|_| ()).map_err(|error| {
        format!(
            "cannot copy {} to {}: {error}",
            from.display(),
            to.display()
        )
    })
}

/// The value of `flag`, written as `--flag value` or `--flag=value`.
fn option(argv: &[String], flag: &str) -> Option<String> {
    let joined = format!("{flag}=");
    argv.iter()
        .find_map(|word| word.strip_prefix(&joined).map(str::to_string))
        .or_else(|| {
            let mut words = argv.iter();
            words.find(|word| *word == flag)?;
            words.next().cloned()
        })
}

/// A packaging step that could not be done: said, and the command fails.
fn refuse(message: &str) -> i32 {
    eprintln!("Tama hook release packaging refused: {message}");
    exit::FAILURE
}

/// A packaging command called wrongly: its usage is said, with the usage
/// status.
fn usage(line: &str) -> i32 {
    eprintln!("Tama hook release packaging refused: {line}");
    exit::USAGE
}

/// `tama hooks stage --source-root <tree> --release-root <release> --cargo <cargo>
/// [--codesign-identity <identity> --codesign-timestamp <flag>]`
pub fn stage_main(argv: &[String]) -> i32 {
    let (Some(source), Some(release), Some(cargo)) = (
        option(argv, SOURCE_ROOT),
        option(argv, "--release-root"),
        option(argv, "--cargo"),
    ) else {
        return usage(
            "usage: tama hooks stage --source-root <tree> --release-root <release> --cargo <cargo>",
        );
    };
    let cargo = PathBuf::from(cargo);
    if !cargo.is_file() {
        return refuse(&format!(
            "A usable Cargo executable is required: {}",
            cargo.display()
        ));
    }
    // Signing is asked for with both its identity and codesign's timestamp
    // flag (`--timestamp=none` signs without a timestamp server); either one
    // alone names half of a signing.
    let signing = match (
        option(argv, "--codesign-identity"),
        option(argv, "--codesign-timestamp"),
    ) {
        (Some(identity), Some(timestamp)) => Some(stage::Signing {
            identity,
            timestamp,
        }),
        (None, None) => None,
        (Some(_), None) | (None, Some(_)) => {
            return usage(
                "usage: --codesign-identity <identity> and --codesign-timestamp <flag> are given together",
            )
        }
    };
    let release = PathBuf::from(release);
    match stage::package_native_binaries(&release, Path::new(&source), &cargo, signing.as_ref()) {
        Ok(()) => {
            println!("{}", release.display());
            exit::SUCCESS
        }
        Err(error) => refuse(&error),
    }
}

/// `tama hooks seal [--source-root <tree>] <release>`
pub fn seal_main(argv: &[String]) -> i32 {
    // Without --source-root the checkout is this directory; one that cannot
    // be read is refused, since read as the empty path the release would be
    // sealed against whatever relative paths resolve to.
    let source = match option(argv, SOURCE_ROOT) {
        Some(source) => PathBuf::from(source),
        None => match std::env::current_dir() {
            Ok(source) => source,
            Err(error) => {
                return refuse(&format!(
                    "the working directory cannot be read and no --source-root names the checkout: {error}"
                ))
            }
        },
    };
    // The release is the one word that is neither the flag, its `=` form,
    // nor the value written after the flag.
    let joined = format!("{SOURCE_ROOT}=");
    let mut after_flag = false;
    let positional: Vec<&String> = argv
        .iter()
        .filter(|word| {
            let value = after_flag;
            after_flag = *word == SOURCE_ROOT;
            !after_flag && !value && !word.starts_with(&joined)
        })
        .collect();
    let [release] = positional.as_slice() else {
        return usage("usage: tama hooks seal [--source-root <checkout>] <release-root>");
    };
    match seal::seal(Path::new(release), &source) {
        Ok(id) => {
            println!("{id}");
            exit::SUCCESS
        }
        Err(error) => refuse(&error),
    }
}

/// `tama hooks identity --source-root <tree> [--shell]`: the identity
/// a release made from that tree would carry; `--shell` prints
/// `<revision> <dirty>` for a build script to read.
pub fn identity_main(argv: &[String]) -> i32 {
    let Some(source) = option(argv, SOURCE_ROOT) else {
        return usage("usage: tama hooks identity --source-root <tree> [--shell]");
    };
    match identity::source_identity(Path::new(&source), None) {
        Ok(identity) if argv.iter().any(|word| word == "--shell") => {
            let Some(revision) = identity["revision"].as_str() else {
                return refuse(&format!(
                    "the source identity names no revision: {identity}"
                ));
            };
            println!("{revision} {}", identity["dirty"]);
            exit::SUCCESS
        }
        Ok(identity) => {
            println!("{identity}");
            exit::SUCCESS
        }
        Err(error) => refuse(&error),
    }
}
