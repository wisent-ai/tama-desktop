//! Shared JSON types for `shared-hooks/registry.json` and
//! `shared-hooks/catalog-metadata.json`. Field names mirror the JSON exactly.

use serde::{Deserialize, Serialize};
use std::collections::{BTreeMap, BTreeSet};

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", default)]
pub struct Registry {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub version: Option<u64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub managed_by: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub generated_from: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub generated_at: Option<String>,
    pub events: BTreeMap<String, EventConfig>,
    #[serde(skip_serializing_if = "BTreeMap::is_empty")]
    pub adapters: BTreeMap<String, Adapter>,
    /// Tolerate unknown top-level fields.
    #[serde(flatten)]
    pub extra: BTreeMap<String, serde_json::Value>,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", default)]
pub struct EventConfig {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub blocking: Option<bool>,
    pub hooks: Vec<HookReg>,
    #[serde(flatten)]
    pub extra: BTreeMap<String, serde_json::Value>,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", default)]
pub struct HookReg {
    pub id: String,
    #[serde(rename = "type", skip_serializing_if = "Option::is_none")]
    pub hook_type: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub command: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub source: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub category: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub status: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub description: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub does: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub why: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub side_effects: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub status_message: Option<String>,
    pub justification_requirements: Vec<JustificationRequirement>,
    #[serde(flatten)]
    pub extra: BTreeMap<String, serde_json::Value>,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", default)]
pub struct JustificationRequirement {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub kind: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub registry_path: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub field: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub direct_user_quote_field: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub minimum_words: Option<i64>,
    #[serde(flatten)]
    pub extra: BTreeMap<String, serde_json::Value>,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", default)]
pub struct Adapter {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub path: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub mode: Option<String>,
    #[serde(flatten)]
    pub extra: BTreeMap<String, serde_json::Value>,
}

/// One entry of `catalog-metadata.json` (a map of hook-id -> docs).
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", default)]
pub struct HookDocs {
    #[serde(rename = "type", skip_serializing_if = "Option::is_none")]
    pub hook_type: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub category: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub status: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub description: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub why: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub side_effects: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub justification_requirements: Option<Vec<JustificationRequirement>>,
    #[serde(flatten)]
    pub extra: BTreeMap<String, serde_json::Value>,
}

pub type CatalogMetadata = BTreeMap<String, HookDocs>;

/// Insertion-ordered string-keyed map that serializes as a JSON object.
///
/// JS objects preserve key insertion order, while `serde_json` without the
/// `preserve_order` feature sorts `Map` keys alphabetically. Wherever the JS
/// code builds an object whose key order is observable (serialized output,
/// markdown sections), this type reproduces the JS behavior.
#[derive(Debug, Clone, Default, PartialEq)]
pub struct OrderedMap<V>(pub Vec<(String, V)>);

impl<V> OrderedMap<V> {
    pub fn new() -> Self {
        Self(Vec::new())
    }

    pub fn get(&self, key: &str) -> Option<&V> {
        let Self(entries) = self;
        entries.iter().find(|(k, _)| k == key).map(|(_, v)| v)
    }

    pub fn push(&mut self, key: String, value: V) {
        let Self(entries) = self;
        entries.push((key, value));
    }

    pub fn len(&self) -> usize {
        let Self(entries) = self;
        entries.len()
    }

    pub fn is_empty(&self) -> bool {
        let Self(entries) = self;
        entries.is_empty()
    }

    pub fn iter(&self) -> impl Iterator<Item = (&String, &V)> {
        let Self(entries) = self;
        entries.iter().map(|(k, v)| (k, v))
    }
}

impl OrderedMap<usize> {
    /// JS `counts[value] = (counts[value] || 0) + 1` preserving first-seen key order.
    pub fn increment(&mut self, key: &str) {
        let Self(entries) = self;
        let index = match entries.iter().position(|(k, _)| k == key) {
            Some(index) => index,
            None => {
                entries.push((key.to_string(), usize::default()));
                entries.len() - 1
            }
        };
        entries[index].1 += 1;
    }
}

impl<V: Serialize> Serialize for OrderedMap<V> {
    fn serialize<S: serde::Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        use serde::ser::SerializeMap;
        let Self(entries) = self;
        let mut map = serializer.serialize_map(Some(entries.len()))?;
        for (k, v) in entries {
            map.serialize_entry(k, v)?;
        }
        map.end()
    }
}

/// The catalog side of the drift question: a hook the registry's event wiring
/// declares that its own `catalog.agentHooks` list does not.
///
/// Two callers need this exact verdict — `tama validate` prints it, and the
/// release verification harness refuses to run live fixtures against a
/// catalog that fails it — so it reads the registry file directly and lives
/// with the registry types rather than in either caller.
pub fn wired_without_catalog_errors(root: &std::path::Path) -> crate::Result<Vec<String>> {
    let registry_path = root.join("shared-hooks").join("registry.json");
    if !crate::presence::present(&registry_path)? {
        return Ok(Vec::new());
    }
    let text = std::fs::read_to_string(&registry_path)?;
    let registry: serde_json::Value = serde_json::from_str(&text)?;
    let shown = registry_path.display();
    // Wiring or a catalog this check cannot read is refused naming where:
    // read as empty, a malformed registry passed the drift check it fails.
    let Some(events) = registry
        .get("events")
        .and_then(serde_json::Value::as_object)
    else {
        return Err(format!("{shown} has no events object to check against its catalog").into());
    };
    let mut wired_events: BTreeMap<&str, BTreeSet<&str>> = BTreeMap::new();
    for (event, config) in events {
        let hooks = match config.get("hooks") {
            None => continue,
            Some(serde_json::Value::Array(hooks)) => hooks,
            Some(other) => {
                return Err(format!(
                    "{shown} event {event} lists hooks that are not a list: {other}"
                )
                .into())
            }
        };
        for hook in hooks {
            let Some(id) = hook.get("id").and_then(serde_json::Value::as_str) else {
                return Err(
                    format!("{shown} event {event} wires a hook without an id: {hook}").into(),
                );
            };
            wired_events.entry(id).or_default().insert(event);
        }
    }
    let Some(catalog) = registry
        .pointer("/catalog/agentHooks")
        .and_then(serde_json::Value::as_array)
    else {
        return Err(
            format!("{shown} has no catalog.agentHooks list to check its wiring against").into(),
        );
    };
    let mut catalog_ids: BTreeSet<&str> = BTreeSet::new();
    for hook in catalog {
        let Some(id) = hook.get("id").and_then(serde_json::Value::as_str) else {
            return Err(
                format!("{shown} catalog.agentHooks holds a hook without an id: {hook}").into(),
            );
        };
        catalog_ids.insert(id);
    }
    Ok(wired_events
        .into_iter()
        .filter(|(id, _)| !catalog_ids.contains(id))
        .map(|(id, events)| {
            let events = events.into_iter().collect::<Vec<_>>().join(", ");
            format!(
                "install drift: registry {events} {id} — runtime event wiring declares this hook for the event but the registry catalog does not declare it"
            )
        })
        .collect())
}
