//! `tama attestation pending [--repository PATH] [--json]`: every commit the
//! checkout's branch carries over its upstream, oldest first, as
//! `review-push` will read it, before anything is pushed.
//!
//! Each commit says whether its attestation stands, where it is carried, what
//! it lacks and what its harsh review names, as `check` answers it, and which
//! commits of the same range it patches without naming them on a `Repairs:
//! "<subject>" <defect>` line, measured from Git's blame
//! (`task_attestation::patches`), which `review-push` refuses the same way.
//! When some commit stands only in its
//! attestation note, the upstream's remote is asked whether it holds this
//! checkout's notes (`note::published`); when it does not, the report does
//! not stand and says which push carries them, as `review-push` refuses a
//! push that leaves them behind. Tama Desktop's `attestation/pending`
//! answers the same report. The commits' patches are measured on as many
//! threads as the operating system says this process can run at once (said
//! on stderr), and each commit's reading time is printed on stderr beside
//! each blame's, so a slow step is named while it runs.

use std::collections::{BTreeMap, BTreeSet};
use std::path::Path;
use std::sync::Mutex;

use serde_json::{json, Value};
use tama_hook_tools::ports::task_attestation::{note, patches, verbatim};

use crate::gitcmd::git;

/// The lock under the Git common directory a reading of the unpushed range
/// holds while it runs (`<git common dir>/tama-pending.lock`).
const READING: &str = "tama-pending";

/// What one commit's patches measured: the commits of the range it patches
/// without naming them, or why that could not be read.
type Unnamed = Result<BTreeSet<String>, String>;

/// The subject of every commit the branch carries over its upstream, by
/// full object name, from one `git log`.
fn subjects(repository: &Path) -> Result<BTreeMap<String, String>, String> {
    let logged = git(
        repository,
        &["log", "--format=%H%x1f%s", "@{upstream}..HEAD"],
    )?;
    logged
        .lines()
        .map(|line| {
            line.split_once('\x1f')
                .map(|(commit, subject)| (commit.to_string(), subject.trim().to_string()))
                .ok_or_else(|| {
                    format!("git log printed a line that is not a commit and its subject: {line:?}")
                })
        })
        .collect()
}

/// `patches::unnamed` of every commit of `read`, in its order, measured on
/// as many threads as the operating system reports this process can run at
/// once. Each blame keeps its own commit's lock (`patches`), so the threads
/// never wait on one another's Git.
fn measured(
    repository: &Path,
    read: &[(&String, String, note::Carried)],
    pushed: &BTreeSet<String>,
) -> Result<Vec<Unnamed>, String> {
    let workers = std::thread::available_parallelism().map_err(|cause| {
        format!("how many threads this process can run at once cannot be read: {cause}")
    })?;
    eprintln!(
        "pending: measuring the patches of {} commit(s) on {workers} thread(s)",
        read.len()
    );
    let queue = Mutex::new(read.iter().enumerate());
    let work = || {
        let mut done = Vec::new();
        loop {
            let next = match queue.lock() {
                Ok(mut queue) => queue.next(),
                Err(poisoned) => poisoned.into_inner().next(),
            };
            let Some((index, (commit, _, carried))) = next else {
                return done;
            };
            let started = std::time::Instant::now();
            let unnamed = patches::unnamed(Some(repository), commit, &carried.text, pushed);
            eprintln!(
                "pending: read {commit} in {} ms",
                started.elapsed().as_millis()
            );
            done.push((index, unnamed));
        }
    };
    let mut answers: Vec<Option<Unnamed>> = read.iter().map(|_| None).collect();
    std::thread::scope(|scope| {
        let workers: Vec<_> = std::iter::repeat_with(|| scope.spawn(work))
            .take(workers.get())
            .collect();
        for worker in workers {
            let done = worker.join().map_err(|panic| {
                let said = panic
                    .downcast_ref::<String>()
                    .map(String::as_str)
                    .or_else(|| panic.downcast_ref::<&str>().copied());
                format!(
                    "a thread measuring the range's patches panicked: {}",
                    said.unwrap_or("its panic carried no message")
                )
            })?;
            for (index, unnamed) in done {
                answers[index] = Some(unnamed);
            }
        }
        Ok::<(), String>(())
    })?;
    Ok(answers
        .into_iter()
        .zip(read)
        .map(|(answer, (commit, _, _))| {
            answer.unwrap_or_else(|| Err(format!("the patches of {commit} were not measured")))
        })
        .collect())
}

/// The upstream the branch at `repository`'s HEAD tracks, and every commit
/// HEAD carries over it, oldest first, by full object name. A branch with no
/// upstream is refused with Git's words: what would be pushed cannot be
/// named without one.
fn range(repository: &Path) -> Result<(String, Vec<String>), String> {
    let upstream = git(
        repository,
        &["rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{upstream}"],
    )
    .map_err(|error| {
        format!("pending reads the commits HEAD carries over its upstream, and HEAD names none: {error}")
    })?;
    let listed = git(repository, &["rev-list", "--reverse", "@{upstream}..HEAD"])?;
    Ok((
        upstream.trim().to_string(),
        listed.lines().map(str::to_string).collect(),
    ))
}

/// The remote the branch at HEAD pushes to and the ref it updates there,
/// read from the branch's upstream configuration.
fn destination(repository: &Path) -> Result<(String, String), String> {
    let branch = git(repository, &["rev-parse", "--symbolic-full-name", "HEAD"])?;
    let named = git(
        repository,
        &[
            "for-each-ref",
            "--format=%(upstream:remotename) %(upstream:remoteref)",
            branch.trim(),
        ],
    )?;
    match named.trim().split_once(' ') {
        Some((remote, remote_ref)) if !remote.is_empty() && !remote_ref.is_empty() => {
            Ok((remote.to_string(), remote_ref.to_string()))
        }
        _ => Err(format!(
            "the upstream of {} names no remote and remote branch (`git for-each-ref` printed {:?})",
            branch.trim(),
            named.trim()
        )),
    }
}

/// `{repository, upstream, stands, notes, commits: [{commit, subject,
/// stands, carriedIn, missing, findings, patches: [{commit, subject}]}]}`
/// for the checkout `repository` is in (the current directory when none is
/// named), named by its top-level directory. `notes` is null when no commit
/// stands only in its note, else `{remote, local, remoteNotes,
/// unpublished}`. The report stands when every commit's attestation stands,
/// every commit of the range a commit patches is named on its `Repairs:`
/// lines and the remote holds every note a commit stands on.
pub(crate) fn pending(repository: Option<&Path>) -> Result<Value, String> {
    let here = match repository {
        Some(repository) => repository.to_path_buf(),
        None => std::env::current_dir().map_err(|error| {
            format!("pending reads the current directory's checkout, and the current directory cannot be read: {error}")
        })?,
    };
    let repository = here.as_path();
    let top = git(repository, &["rev-parse", "--show-toplevel"])?;
    // One reading of a repository at a time: a reading started beside a
    // running one waits for it, then finds every blame it ran kept and asks
    // Git none of them again.
    let waited = std::time::Instant::now();
    let _reading = patches::hold(Some(repository), READING)?;
    eprintln!(
        "pending: took the reading of {} after {} ms",
        top.trim(),
        waited.elapsed().as_millis()
    );
    let (upstream, commits) = range(repository)?;
    let pushed: BTreeSet<String> = commits.iter().cloned().collect();
    // Every subject of the range from one `git log`, instead of one Git
    // process per commit and per patched commit.
    let subjects = subjects(repository)?;
    let subject = |commit: &str| {
        subjects.get(commit).cloned().ok_or_else(|| {
            format!("`git log @{{upstream}}..HEAD` printed no subject for {commit}, which the range holds")
        })
    };
    let mut read = Vec::new();
    for commit in &commits {
        let (full, message) = verbatim::commit_message(Some(repository), commit)?;
        let carried = note::carried(Some(repository), &full, &message)?;
        read.push((commit, full, carried));
    }
    let measured = measured(repository, &read, &pushed)?;
    let mut reports = Vec::new();
    let mut noted = Vec::new();
    let mut all = true;
    for ((commit, full, carried), unnamed) in read.into_iter().zip(measured) {
        let note::Carried {
            unmet, carried_in, ..
        } = carried;
        // A commit whose patches cannot be measured (a malformed `Repairs:`
        // line, a blame Git refused) does not stand, and its row says why;
        // the rest of the range is still read, so one such line no longer
        // hides every other commit's standing behind a single refusal.
        let mut patched = Vec::new();
        let mut patches_failure = None;
        match unnamed {
            Ok(earlier) => {
                for earlier in earlier {
                    patched.push(json!({ "commit": earlier, "subject": subject(&earlier)? }));
                }
            }
            Err(cause) => patches_failure = Some(cause),
        }
        let stands = unmet.stands() && patched.is_empty() && patches_failure.is_none();
        all &= stands;
        if stands && carried_in == Some(note::REF) {
            noted.push(full.clone());
        }
        reports.push(json!({
            "commit": full, "subject": subject(commit)?, "stands": stands,
            "carriedIn": carried_in, "missing": unmet.missing, "findings": unmet.findings,
            "patches": patched, "patchesFailure": patches_failure,
        }));
    }
    let notes = if noted.is_empty() {
        Value::Null
    } else {
        let (remote, remote_ref) = destination(repository)?;
        let published = note::published(Some(repository), &remote)?;
        let unpublished = note::unpublished(&published, &remote, &remote_ref, &noted);
        all &= unpublished.is_none();
        json!({
            "remote": remote, "local": published.local, "remoteNotes": published.remote,
            "unpublished": unpublished,
        })
    };
    Ok(json!({
        "repository": top.trim(), "upstream": upstream,
        "stands": all, "notes": notes, "commits": reports,
    }))
}

/// The report as a person reads it: one line per commit, then what it lacks,
/// names and patches.
pub(crate) fn print_pending(report: &Value) {
    let text = |value: &Value| match value.as_str() {
        Some(text) => text.to_string(),
        None => value.to_string(),
    };
    println!(
        "attestation: {} over {}, oldest first:",
        text(&report["repository"]),
        text(&report["upstream"])
    );
    for each in report["commits"].as_array().into_iter().flatten() {
        let head = format!("{} {}", text(&each["commit"]), text(&each["subject"]));
        match (each["stands"].as_bool(), each["carriedIn"].as_str()) {
            (Some(true), Some(place)) => println!("attestation: {head}: stands in its {place}"),
            _ => println!("attestation: {head}: does not stand"),
        }
        for claim in each["missing"].as_array().into_iter().flatten() {
            println!("    missing: \"{}\"", text(claim));
        }
        for finding in each["findings"].as_array().into_iter().flatten() {
            println!("    finding: \"{}\"", text(finding));
        }
        for earlier in each["patches"].as_array().into_iter().flatten() {
            println!(
                "    patches: {} {}",
                text(&earlier["commit"]),
                text(&earlier["subject"])
            );
        }
        if let Some(cause) = each["patchesFailure"].as_str() {
            println!("    patches unread: {cause}");
        }
    }
    if let Some(reason) = report["notes"]["unpublished"].as_str() {
        println!("attestation: {reason}");
    }
}
