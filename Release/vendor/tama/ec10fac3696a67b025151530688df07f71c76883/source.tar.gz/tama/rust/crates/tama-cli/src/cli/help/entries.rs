//! The entry of every command in [`super::table::COMMANDS`]: each takes the
//! words after the command's name and, for commands that read a checkout,
//! the checkout `main` resolved, and answers the status the process exits
//! with.

use std::path::Path;
use std::process::ExitCode;

use super::group_refusal;
use crate::{exit_code, group_verb};
use tama_core::exit;

/// The words of a command line after the command's name and its verb.
fn verb(rest: &[String]) -> (Option<&str>, &[String]) {
    match rest.split_first() {
        Some((verb, arguments)) => (Some(verb.as_str()), arguments),
        None => (None, &[]),
    }
}

pub(super) fn hook(rest: &[String]) -> ExitCode {
    let (name, arguments) = verb(rest);
    let Some(name) = name else {
        return unknown_program("hook", tama_hook_tools::programs::names().collect());
    };
    match tama_hook_tools::programs::run(name, arguments) {
        Some(code) => code,
        None => unknown_program("hook", tama_hook_tools::programs::names().collect()),
    }
}

fn unknown_program(kind: &str, names: Vec<&str>) -> ExitCode {
    eprintln!(
        "usage: tama {kind} <name> [arguments]\n\nnames: {}",
        names.join(" ")
    );
    exit_code(exit::USAGE)
}

pub(super) fn run_hook(rest: &[String]) -> ExitCode {
    exit_code(tama_run_hook::entry::main(rest))
}

pub(super) fn owned_hook(rest: &[String]) -> ExitCode {
    exit_code(tama_run_hook::owned_hook_main(rest))
}

/// `tama mcp config` prints how an editor starts this server; `tama mcp`
/// alone is the server itself, the argv every installed config runs.
pub(super) fn mcp(rest: &[String]) -> ExitCode {
    match verb(rest) {
        (Some("config"), _) => match crate::mcp_config() {
            Ok(config) => {
                crate::cli::output::print_json(&config);
                ExitCode::SUCCESS
            }
            Err(cause) => {
                eprintln!("mcp config: {cause}");
                exit_code(exit::FAILURE)
            }
        },
        _ => match tama_mcp_server::main() {
            Ok(()) => ExitCode::SUCCESS,
            Err(cause) => {
                eprintln!("mcp: {cause}");
                exit_code(exit::FAILURE)
            }
        },
    }
}

pub(super) fn onboarding(argv: &[String], root: &Path) -> ExitCode {
    exit_code(crate::cli::commands::onboarding(argv, root))
}
pub(super) fn policy(argv: &[String], _: &Path) -> ExitCode {
    exit_code(crate::cli::commands::policy(argv))
}
pub(super) fn list(argv: &[String], root: &Path) -> ExitCode {
    exit_code(crate::cli::commands::list(argv, root))
}
pub(super) fn show(argv: &[String], root: &Path) -> ExitCode {
    exit_code(crate::cli::commands::show(argv, root))
}
pub(super) fn validate(argv: &[String], root: &Path) -> ExitCode {
    exit_code(crate::cli::commands::validate(argv, root))
}
pub(super) fn install(argv: &[String], root: &Path) -> ExitCode {
    exit_code(match group_verb(argv) {
        (Some("plan"), _) => crate::cli::commands::install_plan(argv, root),
        _ => crate::cli::commands::install(argv, root),
    })
}
pub(super) fn uninstall(argv: &[String], _: &Path) -> ExitCode {
    exit_code(crate::cli::commands::uninstall(argv))
}
pub(super) fn justify(argv: &[String], _: &Path) -> ExitCode {
    exit_code(crate::justify::main(rest_of(argv)))
}
pub(super) fn build(argv: &[String], _: &Path) -> ExitCode {
    exit_code(crate::builds::main(rest_of(argv)))
}
pub(super) fn hooks(argv: &[String], root: &Path) -> ExitCode {
    exit_code(crate::hooks::main(rest_of(argv), root))
}
pub(super) fn rules(argv: &[String], _: &Path) -> ExitCode {
    crate::rules::main(rest_of(argv))
}
pub(super) fn violations(argv: &[String], _: &Path) -> ExitCode {
    exit_code(match group_verb(argv) {
        (Some("find"), arguments) => tama_violations::scan_repos::main(arguments),
        (Some("clean"), arguments) => tama_violations::clean::main(arguments),
        (Some("root"), arguments) => tama_violations::declare_root::main(arguments),
        _ => group_refusal("violations"),
    })
}
pub(super) fn vocabulary(argv: &[String], _: &Path) -> ExitCode {
    match group_verb(argv) {
        (Some("report"), arguments) => tama_violations::vocabulary_report::main(arguments),
        _ => exit_code(group_refusal("vocabulary")),
    }
}
pub(super) fn format(argv: &[String], _: &Path) -> ExitCode {
    use tama_hook_tools::programs::check_rust_format::fold::cli;
    match group_verb(argv) {
        (Some("fold"), arguments) => match cli::cli(arguments) {
            Ok(said) => {
                println!("{said}");
                exit_code(exit::SUCCESS)
            }
            Err(cause) => {
                eprintln!("format fold: {cause}");
                exit_code(exit::FAILURE)
            }
        },
        _ => exit_code(group_refusal("format")),
    }
}
pub(super) fn history(argv: &[String], _: &Path) -> ExitCode {
    use tama_hook_tools::programs::check_rust_format::rebase::cli;
    match group_verb(argv) {
        (Some("rebase"), arguments) => match cli::cli(arguments) {
            Ok(said) => {
                println!("{said}");
                exit_code(exit::SUCCESS)
            }
            Err(cause) => {
                eprintln!("history rebase: {cause}");
                exit_code(exit::FAILURE)
            }
        },
        _ => exit_code(group_refusal("history")),
    }
}
pub(super) fn standing(argv: &[String], _: &Path) -> ExitCode {
    match tama_hook_tools::evidence::commit_standing::cli::cli(rest_of(argv)) {
        Ok(said) => {
            println!("{said}");
            exit_code(exit::SUCCESS)
        }
        Err(cause) => {
            eprintln!("standing: {cause}");
            exit_code(exit::FAILURE)
        }
    }
}
pub(super) fn session(argv: &[String], _: &Path) -> ExitCode {
    match tama_hook_tools::evidence::edit_lease::cli::cli(rest_of(argv)) {
        Ok(said) => {
            println!("{said}");
            exit_code(exit::SUCCESS)
        }
        Err(cause) => {
            eprintln!("session: {cause}");
            exit_code(exit::FAILURE)
        }
    }
}
pub(super) fn model_provider(argv: &[String], _: &Path) -> ExitCode {
    exit_code(crate::brama::provider::main(rest_of(argv)))
}
pub(super) fn doctor(argv: &[String], _: &Path) -> ExitCode {
    exit_code(crate::brama::check::doctor(rest_of(argv)))
}
pub(super) fn enforcement(argv: &[String], root: &Path) -> ExitCode {
    exit_code(crate::enforcement::main(rest_of(argv), root))
}
pub(super) fn provider(argv: &[String], _: &Path) -> ExitCode {
    exit_code(match group_verb(argv) {
        (Some("config"), arguments) => crate::provider_config::main(arguments),
        _ => group_refusal("provider"),
    })
}
pub(super) fn request(argv: &[String], root: &Path) -> ExitCode {
    exit_code(crate::request::main(rest_of(argv), root))
}
pub(super) fn adaptive(argv: &[String], _: &Path) -> ExitCode {
    exit_code(tama_adaptive::doctor::cli::main(rest_of(argv)))
}
pub(super) fn adaptive_bridge(_: &[String], _: &Path) -> ExitCode {
    exit_code(tama_adaptive::bridge::main())
}
pub(super) fn sessions(argv: &[String], root: &Path) -> ExitCode {
    exit_code(crate::cli::sessions::main(argv, root))
}
pub(super) fn worktrees(argv: &[String], _: &Path) -> ExitCode {
    exit_code(crate::worktrees::main(rest_of(argv)))
}
pub(super) fn copies(argv: &[String], _: &Path) -> ExitCode {
    exit_code(crate::copies::main(rest_of(argv)))
}
pub(super) fn contributions(argv: &[String], _: &Path) -> ExitCode {
    exit_code(crate::contributions::main(rest_of(argv)))
}
pub(super) fn reviews(argv: &[String], _: &Path) -> ExitCode {
    exit_code(crate::reviews::main(argv))
}
pub(super) fn stage(argv: &[String], _: &Path) -> ExitCode {
    match tama_hook_tools::evidence::session_changes::interface::cli(rest_of(argv)) {
        Ok(()) => exit_code(exit::SUCCESS),
        Err(cause) => {
            eprintln!("stage: {cause}");
            exit_code(exit::FAILURE)
        }
    }
}
pub(super) fn index(argv: &[String], _: &Path) -> ExitCode {
    match tama_hook_tools::evidence::index_objects::cli(rest_of(argv)) {
        Ok(()) => exit_code(exit::SUCCESS),
        Err(cause) => {
            eprintln!("index: {cause}");
            exit_code(exit::FAILURE)
        }
    }
}
pub(super) fn assignment(argv: &[String], _: &Path) -> ExitCode {
    exit_code(tama_hook_tools::assignment::cli_main(rest_of(argv)))
}
pub(super) fn attestation(argv: &[String], _: &Path) -> ExitCode {
    exit_code(match group_verb(argv) {
        (Some(verb), arguments) => crate::attestation::main(verb, arguments),
        (None, _) => group_refusal("attestation"),
    })
}
pub(super) fn task(argv: &[String], _: &Path) -> ExitCode {
    exit_code(tama_hook_tools::ports::block_off_task_work::scope_cli::cli_main(rest_of(argv)))
}
pub(super) fn tests(argv: &[String], _: &Path) -> ExitCode {
    exit_code(tama_hook_tools::ports::block_unapproved_tests::approvals::cli_main(rest_of(argv)))
}
pub(super) fn commands(argv: &[String], _: &Path) -> ExitCode {
    exit_code(match group_verb(argv) {
        (Some("judge"), [request]) => {
            tama_hook_tools::ports::block_one_off_commands::verdicts::judge_cli(request)
        }
        _ => group_refusal("commands"),
    })
}
pub(super) fn judgement(argv: &[String], _: &Path) -> ExitCode {
    use tama_hook_tools::ports::model_judgement::Choice;
    let result = match group_verb(argv) {
        (Some("ask"), [request]) => {
            return exit_code(tama_hook_tools::ports::model_judgement::ask_cli(request));
        }
        (Some("show"), [request]) => Choice::inspect(Path::new(request)),
        (Some("revoke"), [request]) => Choice::revoke(Path::new(request)),
        (Some("attest"), [request, choice_flag, choice, reason_flag, reason])
            if choice_flag == "--choice" && reason_flag == "--reason" =>
        {
            Choice::attest(Path::new(request), choice, reason)
        }
        _ => return exit_code(group_refusal("judgement")),
    };
    match result
        .and_then(|value| serde_json::to_string_pretty(&value).map_err(|error| error.to_string()))
    {
        Ok(document) => {
            println!("{document}");
            ExitCode::SUCCESS
        }
        Err(cause) => {
            eprintln!("judgement: {cause}");
            ExitCode::FAILURE
        }
    }
}
pub(super) fn calls(argv: &[String], _: &Path) -> ExitCode {
    exit_code(tama_run_hook::calls_cli(rest_of(argv)))
}

/// The words after the command's own name.
fn rest_of(argv: &[String]) -> &[String] {
    match argv.split_first() {
        Some((_, rest)) => rest,
        None => argv,
    }
}
