use serde::{Deserialize, Serialize};
use std::path::{Component, Path, PathBuf};

mod attested;
mod cli;
pub(crate) mod harsh;
mod queue;
mod round;
mod run;
pub(crate) use cli::main;

#[derive(Deserialize, Serialize)]
#[serde(rename_all = "snake_case")]
pub(crate) enum Outcome {
    Pass,
    SourceFinding,
    ReviewFailure,
}

#[derive(Deserialize, Serialize)]
pub(crate) struct ResultRecord {
    pub(crate) outcome: Outcome,
    #[serde(deserialize_with = "Option::deserialize")]
    pub(crate) detail: Option<String>,
}

#[derive(Serialize)]
pub(crate) struct Record {
    pub(crate) id: String,
    pub(crate) directory: PathBuf,
    pub(crate) result: Option<ResultRecord>,
    pub(crate) error: Option<String>,
}

pub(crate) enum ShowError {
    InvalidId(String),
    Directory(String),
}

impl std::fmt::Display for ShowError {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::InvalidId(cause) | Self::Directory(cause) => formatter.write_str(cause),
        }
    }
}

#[derive(Serialize)]
pub(crate) struct Listing {
    pub(crate) directory: PathBuf,
    pub(crate) records: Vec<Record>,
}

fn directory() -> PathBuf {
    tama_hooks::session_control::tama_state_root().join("review-push")
}

fn regular_directory(path: &Path) -> Result<(), String> {
    let metadata = std::fs::symlink_metadata(path).map_err(|cause| {
        format!(
            "cannot inspect review directory {}: {cause}",
            path.display()
        )
    })?;
    if !metadata.file_type().is_dir() {
        return Err(format!(
            "review directory {} is not a regular directory; symbolic links are not followed",
            path.display()
        ));
    }
    Ok(())
}

fn result(directory: &Path) -> Result<ResultRecord, String> {
    regular_directory(directory)?;
    let path = directory.join("result.json");
    let metadata = std::fs::symlink_metadata(&path).map_err(|cause| {
        format!(
            "cannot inspect retained review result {}: {cause}",
            path.display()
        )
    })?;
    if !metadata.file_type().is_file() {
        return Err(format!(
            "retained review result {} is not a regular file; symbolic links are not followed",
            path.display()
        ));
    }
    let bytes = std::fs::read(&path).map_err(|cause| {
        format!(
            "cannot read retained review result {}: {cause}",
            path.display()
        )
    })?;
    let result: ResultRecord = serde_json::from_slice(&bytes).map_err(|cause| {
        format!(
            "cannot decode retained review result {}: {cause}",
            path.display()
        )
    })?;
    match (&result.outcome, result.detail.as_deref()) {
        (Outcome::Pass, None) => {}
        (Outcome::SourceFinding | Outcome::ReviewFailure, Some(detail)) if !detail.trim().is_empty() => {}
        _ => return Err(format!(
            "invalid retained review result {}: pass requires null detail; source_finding and review_failure require their actual nonempty cause",
            path.display()
        )),
    }
    Ok(result)
}

fn record(id: String, directory: PathBuf) -> Record {
    match result(&directory) {
        Ok(result) => Record {
            id,
            directory,
            result: Some(result),
            error: None,
        },
        Err(error) => Record {
            id,
            directory,
            result: None,
            error: Some(error),
        },
    }
}

pub(crate) fn list() -> Result<Listing, String> {
    let directory = directory();
    regular_directory(&directory)?;
    let entries = std::fs::read_dir(&directory).map_err(|cause| {
        format!(
            "cannot list retained reviews in {}: {cause}",
            directory.display()
        )
    })?;
    let mut records = Vec::new();
    for entry in entries {
        let entry = entry.map_err(|cause| {
            format!(
                "cannot read a retained review entry in {}: {cause}",
                directory.display()
            )
        })?;
        let id = entry.file_name().into_string().map_err(|name| {
            format!(
                "retained review entry in {} has a non-UTF-8 name: {name:?}",
                directory.display()
            )
        })?;
        records.push(record(id, entry.path()));
    }
    records.sort_by(|left, right| right.id.cmp(&left.id));
    Ok(Listing { directory, records })
}

pub(crate) fn show(id: &str) -> Result<Record, ShowError> {
    if id.contains('\0') {
        return Err(ShowError::InvalidId(format!(
            "invalid retained review id {id:?}: NUL is not valid in a filesystem entry name"
        )));
    }
    let mut parts = Path::new(id).components();
    if !matches!(parts.next(), Some(Component::Normal(_)))
        || parts.next().is_some()
        || Path::new(id).file_name().and_then(|name| name.to_str()) != Some(id)
    {
        return Err(ShowError::InvalidId(format!("invalid retained review id {id:?}: use one exact entry from tama reviews list, not a path")));
    }
    let root = directory();
    regular_directory(&root).map_err(ShowError::Directory)?;
    Ok(record(id.to_owned(), root.join(id)))
}
