//! `tama model show|set|unset|check`: which model service Tama's
//! model calls (the objective reviewer, the stop review, frustration drafting,
//! adaptive disputes) ask, and whether it answers. Brama is the default; a
//! machine without Brama declares any OpenAI-compatible chat-completions
//! service instead, or declares that it has no model at all, so Tama works
//! where neither Brama nor any model is installed. The key is read from
//! standard input, kept owner-only, and never printed.

use std::io::Read;
use std::os::unix::fs::PermissionsExt;

use serde_json::{json, Value};
use tama_hook_tools::brama::credentials::{allowed_endpoint, model_route};
use tama_hook_tools::brama::declared::{declared_provider, provider_path, DeclaredProvider};
use tama_hook_tools::ports::task_attestation::declared::{model_declared_none, none_declaration};

use crate::cli::output::print_json;

/// The word after the option `name`, when one follows it.
fn value(args: &[String], name: &str) -> Option<String> {
    let mut rest = args.iter();
    rest.find(|arg| *arg == name)?;
    rest.next()
        .filter(|value| !value.starts_with("--"))
        .map(|value| value.trim().to_string())
}

/// The model service Tama asks, as `show` prints it and Desktop reads it.
/// A Brama route that cannot be resolved is refused, not shown empty.
pub(crate) fn choice() -> Result<Value, String> {
    if model_declared_none()? {
        return Ok(json!({
            "provider": "none", "model": null,
            "declaredIn": provider_path().display().to_string(),
            "judgedBy": "the recorded attestations (tama attestation record --file FILE --session ID | --commit REV)",
        }));
    }
    Ok(match declared_provider()? {
        Some(found) => json!({
            "provider": "openai-compatible", "origin": found.origin, "model": found.model,
            "declaredIn": provider_path().display().to_string(),
        }),
        None => json!({ "provider": "brama", "model": model_route()?, "declaredIn": null }),
    })
}

fn show(json_output: bool) -> i32 {
    let report = match choice() {
        Ok(report) => report,
        Err(error) => {
            eprintln!("model: {error}");
            return tama_core::exit::FAILURE;
        }
    };
    if json_output {
        print_json(&report);
    } else if let Some(fields) = report.as_object() {
        for (name, field) in fields {
            match field {
                Value::String(text) => println!("{name}: {text}"),
                Value::Null => println!("{name}: (not declared)"),
                other => println!("{name}: {other}"),
            }
        }
    }
    tama_core::exit::SUCCESS
}

fn write_owner_only(text: &str) -> Result<(), String> {
    let path = provider_path();
    let written =
        |error: std::io::Error| format!("{} could not be written: {error}", path.display());
    // A declaration path is a file under a folder; the folder is made first.
    let folder = path.parent().ok_or_else(|| {
        format!(
            "{} names no folder to write the declaration in",
            path.display()
        )
    })?;
    std::fs::create_dir_all(folder).map_err(written)?;
    std::fs::write(&path, text).map_err(written)?;
    // The declaration holds a key, so it is the owner's to read and write.
    std::fs::set_permissions(
        &path,
        std::fs::Permissions::from_mode(tama_core::OWNER_ONLY_FILE),
    )
    .map_err(written)
}

/// Declare that this machine has no model; the CLI's `set --none` and the
/// Desktop's Model service section both write it here.
pub(crate) fn declare_none() -> Result<(), String> {
    write_owner_only(&none_declaration().to_string())
}

/// Remove whatever was declared, returning Tama to Brama; refused with the
/// path when nothing was declared.
pub(crate) fn remove() -> Result<(), String> {
    let path = provider_path();
    // Only a declaration that does not exist is absent; one that cannot be
    // removed for any other cause is refused with that cause.
    match std::fs::remove_file(&path) {
        Ok(()) => Ok(()),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Err(format!(
            "no model provider is declared in {}; Tama already asks Brama",
            path.display()
        )),
        Err(error) => Err(format!("{} could not be removed: {error}", path.display())),
    }
}

fn set(args: &[String], json_output: bool) -> i32 {
    if args.iter().any(|arg| arg == "--none") {
        if let Err(error) = declare_none() {
            eprintln!("model: {error}");
            return tama_core::exit::FAILURE;
        }
        return show(json_output);
    }
    let (Some(origin), Some(model)) = (value(args, "--origin"), value(args, "--model")) else {
        eprintln!("model: set needs --origin URL and --model MODEL (the API key is read from standard input), or --none for a machine with no model");
        return tama_core::exit::USAGE;
    };
    let origin = origin.trim_end_matches('/').to_string();
    if !allowed_endpoint(&format!("{origin}/v1/chat/completions")) || model.is_empty() {
        eprintln!(
            "model: --origin must be HTTPS, or HTTP on loopback, with no credentials, query or fragment, and --model must name a model: got {origin:?} and {model:?}"
        );
        return tama_core::exit::USAGE;
    }
    let mut key = String::new();
    if let Err(error) = std::io::stdin().read_to_string(&mut key) {
        eprintln!("model: the API key could not be read from standard input: {error}");
        return tama_core::exit::FAILURE;
    }
    let key = key.trim().to_string();
    if key.is_empty() {
        eprintln!("model: the API key is read from standard input, and standard input was empty");
        return tama_core::exit::USAGE;
    }
    let written = serde_json::to_string_pretty(&DeclaredProvider { origin, model, key })
        .map_err(|error| error.to_string())
        .and_then(|text| write_owner_only(&text));
    if let Err(error) = written {
        eprintln!("model: {error}");
        return tama_core::exit::FAILURE;
    }
    show(json_output)
}

fn unset(json_output: bool) -> i32 {
    if let Err(error) = remove() {
        eprintln!("model: {error}");
        return tama_core::exit::FAILURE;
    }
    show(json_output)
}

pub fn main(args: &[String]) -> i32 {
    if args.iter().any(|arg| arg == "--help" || arg == "-h") {
        println!(
            "tama model [show | set --origin URL --model MODEL < KEY | set --none | unset | check] [--json]

Which model service Tama's model calls ask: Brama by default, or an
OpenAI-compatible chat-completions service declared with set, whose API key is
read from standard input and kept owner-only in ~/.tama/model-provider.json
(TAMA_MODEL_PROVIDER_PATH names another file). set --none declares that this
machine has no model: the stop gates that would ask one then read the
session's own attestation, recorded with `tama attestation record --file FILE
--session ID`, and a question only a model could read finds nothing and says
so. review-push and the turn-end stop gates ask no model on any machine: they
read the attestation a commit's message or an answer carries (`tama
attestation standard`). unset returns Tama to Brama.
Each of show, set and unset prints the choice that stands afterwards.

check presents the credential of the service in force to its bearer-only
GET /v1/models, which is not billable and calls no provider, and reports the
address, whether it passes the client's transport policy, what the service
answered and, for Brama, whether this machine's Skarbiec grants the route.
Brama's address comes from TAMA_OBJECTIVE_AUTHORITY_MODEL_ROUTER_URL,
STADO_MODEL_ROUTER_URL or BRAMA_URL when one is set, otherwise from the current
published resolver adapter for TAMA_BRAMA_ADAPTER_CONSUMER (tama by default),
or caller-owned `stado service directory connect` discovery. No URL is cached.
If local routing is unavailable, Stado can carry the request through a
caller-owned resolver relay. A terminal fleet declaration or consumer refusal
is returned without opening a relay. No public hostname is substituted.
check exits non-zero unless the service accepted the credential."
        );
        return tama_core::exit::SUCCESS;
    }
    let json_output = args.iter().any(|arg| arg == "--json");
    let verb = args
        .iter()
        .find(|arg| !arg.starts_with("--"))
        .map(String::as_str);
    match verb {
        Some("show") | None => show(json_output),
        Some("set") => set(args, json_output),
        Some("unset") => unset(json_output),
        Some("check") => super::check::run(json_output),
        Some(other) => {
            eprintln!("model: takes show, set, unset or check; got {other}");
            tama_core::exit::USAGE
        }
    }
}
