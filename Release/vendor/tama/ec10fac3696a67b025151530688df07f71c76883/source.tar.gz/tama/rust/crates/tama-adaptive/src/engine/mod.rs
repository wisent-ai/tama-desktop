//! The threshold-free adaptive engine.
//! Projections persist independently from telemetry.

mod identity;
mod lookup;
mod policy;
mod startup;

pub use policy::{Autonomy, Policy};
use startup::{invalid_observation, snapshot_hook};
pub use startup::{load_engine, load_engine_with};

use std::path::PathBuf;

use tama_core::registry::Registry;

use crate::state::projections::{
    project_contested_block, project_outcome, IdentityFacts, Projection,
};
use crate::state::{
    EpisodeBlockInput, EpisodeWriteResult, HookState, StateStore, TransitionResult,
};

/// A hook's tier as the policy declares it.
#[derive(Debug, Clone)]
pub struct Tier {
    pub name: String,
    pub enforce_verdict: bool,
    pub on_infra_failure: String,
    pub demotable: bool,
}

/// `SourceIdentity` from `engine.mjs`.
#[derive(Debug, Clone)]
pub struct SourceIdentity {
    pub hook_id: String,
    pub command: Option<String>,
    pub source_path: Option<String>,
    pub digest: Option<String>,
    pub verifiable: bool,
    /// Why the source could not be identified, when it could not: a source
    /// that could not be examined or read was unverifiable without a word.
    pub unverifiable: Option<String>,
}

impl SourceIdentity {
    pub fn to_value(&self) -> serde_json::Value {
        serde_json::json!({
            "hookId": self.hook_id,
            "command": self.command,
            "sourcePath": self.source_path,
            "digest": self.digest,
            "verifiable": self.verifiable,
            "unverifiable": self.unverifiable,
        })
    }

    fn facts(&self) -> IdentityFacts {
        IdentityFacts {
            verifiable: self.verifiable,
            digest: self.digest.clone(),
        }
    }
}

/// `OutcomeObservation` — fields may be missing like a partial JS object.
#[derive(Debug, Clone, Default)]
pub struct OutcomeObservation {
    pub hook_id: Option<String>,
    pub outcome: Option<String>,
}

pub struct Engine {
    pub state_dir: PathBuf,
    pub registry_path: PathBuf,
    pub policy: Policy,
    pub registry: Registry,
    /// Raw registry JSON, kept for insertion-order-faithful iteration where
    /// JS uses `Object.values(registry.events)`.
    registry_value: serde_json::Value,
    store: StateStore,
}

impl Engine {
    /// `tierOf(hookId)`.
    pub fn tier_of(&self, hook_id: &str) -> Tier {
        self.policy.tier_of(hook_id)
    }

    /// `finish(hookId, result)` — computes the mode on persisted results, or
    /// says why the hook's state cannot give it.
    fn finish(
        &self,
        hook_id: &str,
        mut result: TransitionResult,
    ) -> std::io::Result<TransitionResult> {
        result.mode = if result.persisted {
            self.effective_mode(hook_id)
                .map_err(std::io::Error::other)?
                .to_string()
        } else {
            "enforce".to_string()
        };
        Ok(result)
    }

    /// `recordOutcome(observation)`. Lock-acquisition I/O errors propagate
    /// like the JS throw outside `update`'s `try` block. An observation
    /// without a hook or a known outcome is refused as invalid, against the
    /// state of the hook it names.
    pub fn record_outcome(
        &self,
        observation: Option<&OutcomeObservation>,
    ) -> std::io::Result<TransitionResult> {
        let valid = |outcome: &&str| matches!(*outcome, "pass" | "infra_failure" | "block");
        let named = observation.and_then(|observation| observation.hook_id.as_deref());
        let outcome = observation.and_then(|observation| observation.outcome.as_deref());
        let hook = named.filter(|hook_id| !hook_id.is_empty());
        let (Some(hook_id), Some(outcome)) = (hook, outcome.filter(valid)) else {
            let hook_id = named.unwrap_or_default();
            let state = snapshot_hook(&self.store, hook_id).map_err(std::io::Error::other)?;
            return self.finish(hook_id, invalid_observation(state));
        };
        let tier = self.tier_of(hook_id);
        let identity = self.source_identity(hook_id);
        let facts = identity.facts();
        let outcome_for_projection = outcome.to_string();
        let tier_name = tier.name.clone();
        let result = self.store.update(
            hook_id,
            move |prior: &HookState, event_id: &str| -> Projection {
                project_outcome(prior, &outcome_for_projection, &tier_name, &facts, event_id)
            },
            Some(serde_json::json!({
                "kind": "outcome",
                "outcome": outcome,
                "tier": tier.name,
                "identity": identity.to_value(),
            })),
        )?;
        self.finish(hook_id, result)
    }

    /// `recordContestedBlock(observation)` — `hook_id` empty models the JS
    /// missing-observation case.
    pub fn record_contested_block(&self, hook_id: &str) -> std::io::Result<TransitionResult> {
        if hook_id.is_empty() {
            let state = snapshot_hook(&self.store, "").map_err(std::io::Error::other)?;
            return self.finish("", invalid_observation(state));
        }
        let tier = self.tier_of(hook_id);
        let identity = self.source_identity(hook_id);
        let facts = identity.facts();
        let tier_name = tier.name.clone();
        let result = self.store.update(
            hook_id,
            move |prior: &HookState, event_id: &str| -> Projection {
                project_contested_block(prior, &tier_name, &facts, event_id)
            },
            Some(serde_json::json!({
                "kind": "contested-block",
                "tier": tier.name,
                "identity": identity.to_value(),
            })),
        )?;
        self.finish(hook_id, result)
    }

    /// `recordEpisodeBlock(observation)`.
    pub fn record_episode_block(&self, input: &EpisodeBlockInput) -> EpisodeWriteResult {
        self.store.record_episode_block(input)
    }

    /// `consumeLatestEpisodeBlocks(sessionId)`.
    pub fn consume_latest_episode_blocks(
        &self,
        session_id: Option<&str>,
    ) -> Vec<serde_json::Value> {
        self.store.consume_latest_episode_blocks(session_id)
    }

    /// `engine.registry?.events?.[event]` — raw entry JSON (falsy entries
    /// behave like missing ones, as in the runner checks).
    pub fn registry_event(&self, event: &str) -> Option<serde_json::Value> {
        let entry = self.registry_value.get("events")?.get(event)?.clone();
        if crate::util::js_truthy(&entry) {
            Some(entry)
        } else {
            None
        }
    }

    /// `stateSnapshot(hookId?)`: one hook's state, or every stored state and
    /// every registered hook's, or why one of them cannot be read.
    pub fn state_snapshot(&self, hook_id: Option<&str>) -> Result<serde_json::Value, String> {
        if let Some(hook_id) = hook_id {
            return self.store.snapshot(Some(hook_id));
        }
        let mut states = self.store.snapshot(None)?;
        let registered = self
            .registry_value
            .get("events")
            .and_then(serde_json::Value::as_object)
            .into_iter()
            .flat_map(|events| events.values())
            .filter_map(|config| config.get("hooks").and_then(serde_json::Value::as_array))
            .flatten()
            .filter_map(|hook| hook.get("id").and_then(serde_json::Value::as_str))
            .filter(|id| !id.is_empty());
        for id in registered {
            let state = self.store.snapshot(Some(id))?;
            if let Some(states_map) = states.as_object_mut() {
                states_map.insert(id.to_string(), state);
            }
        }
        Ok(states)
    }
}
