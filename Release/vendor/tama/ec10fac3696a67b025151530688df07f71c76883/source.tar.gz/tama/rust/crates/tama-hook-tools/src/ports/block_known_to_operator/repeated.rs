//! The sentences of an answer this session already told the operator, word
//! for word once case, punctuation and spacing are set aside. No model is
//! asked: a sentence said before is found in the transcript itself, so a
//! repetition is refused even while Brama gives no verdict.

/// The marks that end a sentence, and the line break that ends a list item.
const SENTENCE_ENDS: &[char] = &['.', '!', '?', '\n'];

/// One sentence reduced to its words: lowercase letters and digits, every
/// run of anything else one space.
fn words(sentence: &str) -> String {
    sentence
        .split(|character: char| !character.is_alphanumeric())
        .filter(|word| !word.is_empty())
        .map(str::to_lowercase)
        .collect::<Vec<_>>()
        .join(" ")
}

/// The sentences of `text` as written and as words; a sentence of one word
/// (a heading, a lone status word) says nothing a reader could have been
/// told before.
fn sentences(text: &str) -> impl Iterator<Item = (&str, String)> {
    text.split(SENTENCE_ENDS).filter_map(|sentence| {
        let reduced = words(sentence);
        reduced.contains(' ').then(|| (sentence.trim(), reduced))
    })
}

/// Every sentence of `answer` some earlier answer in `told` already said,
/// as the answer writes it, in its order.
pub(super) fn sentences_told(told: &[String], answer: &str) -> Vec<String> {
    let earlier: std::collections::BTreeSet<String> = told
        .iter()
        .flat_map(|said| sentences(said).map(|(_, reduced)| reduced))
        .collect();
    sentences(answer)
        .filter(|(_, reduced)| earlier.contains(reduced))
        .map(|(written, _)| written.to_string())
        .collect()
}
