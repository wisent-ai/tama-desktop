//! The adaptive telemetry façade over
//! immutable per-invocation segments. Observability failures never alter
//! hook enforcement: each is said on stderr as a loss and the call answers
//! false.

use std::cell::RefCell;
use std::path::Path;

use serde_json::{Map, Value};

use crate::segments::index::SegmentWriter;
use crate::state::Warn;
use std::sync::Arc;

/// `reportLoss(text)`: a telemetry row that was not kept, said on stderr.
fn report_loss(text: &str) {
    eprintln!("{text}");
}

fn loss_warn() -> Warn {
    Arc::new(|text: &str| report_loss(text))
}

/// The fields `value` spreads into a frame, as JavaScript's `{...value}`
/// spreads an object and nothing for an absent value. Any other value is a
/// caller's mistake, said as a loss naming what it was given for: spread as
/// nothing, the row would be kept without the fields it is meant to carry.
fn spread(value: &Value, given_for: &str) -> Option<Map<String, Value>> {
    match value {
        Value::Object(fields) => Some(fields.clone()),
        Value::Null => Some(Map::new()),
        other => {
            report_loss(&format!(
                "adaptive telemetry loss: the {given_for} is {other}, not an object of fields"
            ));
            None
        }
    }
}

/// A frame of `kind` stamped now, holding `fields`.
fn frame(kind: &str, mut fields: Map<String, Value>) -> Value {
    fields.insert("ts".to_string(), tama_core::clock::now_millis().into());
    fields.insert("type".to_string(), kind.into());
    Value::Object(fields)
}

pub struct Telemetry {
    segment: RefCell<SegmentWriter>,
}

impl Telemetry {
    /// `safely(action)` — telemetry errors report a loss and return false.
    fn safely(&self, action: impl FnOnce(&mut SegmentWriter) -> bool) -> bool {
        let mut segment = self.segment.borrow_mut();
        let result =
            std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| action(&mut segment)));
        match result {
            Ok(flag) => flag,
            Err(payload) => {
                report_loss(&format!(
                    "adaptive telemetry loss: the telemetry action panicked: {}",
                    tama_core::panic_text(payload.as_ref())
                ));
                false
            }
        }
    }

    fn keep(&self, row: Value) -> bool {
        self.safely(|segment| segment.record(&row))
    }

    /// `record(entry)`.
    pub fn record(&self, entry: &Value) -> bool {
        match spread(entry, "decision entry") {
            Some(fields) => self.keep(frame("decision", fields)),
            None => false,
        }
    }

    /// `warn(text)`.
    pub fn warn(&self, text: &str) -> bool {
        let mut fields = Map::new();
        fields.insert("text".to_string(), text.into());
        self.keep(frame("warning", fields))
    }

    /// `corpusAdd(id, payload, meta)` — `id` is rendered with JS `String()`.
    pub fn corpus_add(&self, id: &Value, payload: &Value, meta: &Value) -> bool {
        let Some(meta) = spread(meta, "corpus entry's meta") else {
            return false;
        };
        let mut fields = Map::new();
        fields.insert("id".to_string(), crate::util::js_string(id).into());
        fields.insert("label".to_string(), "unlabeled".into());
        fields.insert("payload".to_string(), payload.clone());
        fields.extend(meta);
        self.keep(frame("corpus_add", fields))
    }

    /// `corpusLabel(id, label)` — a string label becomes `{ label }`, an
    /// object label is spread.
    pub fn corpus_label(&self, id: &Value, label: &Value) -> bool {
        let mut fields = Map::new();
        fields.insert("id".to_string(), crate::util::js_string(id).into());
        match label {
            Value::String(text) => {
                fields.insert("label".to_string(), text.clone().into());
            }
            other => match spread(other, "corpus label") {
                Some(spread) => fields.extend(spread),
                None => return false,
            },
        }
        self.keep(frame("corpus_label", fields))
    }

    /// `frustration(value)`.
    pub fn frustration(&self, value: &Value) -> bool {
        match spread(value, "frustration entry") {
            Some(fields) => self.keep(frame("frustration", fields)),
            None => false,
        }
    }

    /// `queueRepair(value)`.
    pub fn queue_repair(&self, value: &Value) -> bool {
        match spread(value, "repair proposal") {
            Some(fields) => self.keep(frame("repair_proposal", fields)),
            None => false,
        }
    }

    pub fn close(&self) -> bool {
        self.segment.borrow_mut().close()
    }

    /// What the segment folders hold, or why one cannot be listed.
    pub fn status(&self) -> Result<Value, String> {
        self.segment.borrow().status()
    }
}

/// `openTelemetry(stateDir)`.
pub fn open_telemetry(state_dir: &Path) -> Telemetry {
    Telemetry {
        segment: RefCell::new(SegmentWriter::create(state_dir, loss_warn())),
    }
}
