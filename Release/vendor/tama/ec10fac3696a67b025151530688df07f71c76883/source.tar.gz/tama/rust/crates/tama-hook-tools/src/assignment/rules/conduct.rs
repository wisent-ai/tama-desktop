//! The operator's rejections charged to the model a session runs on.
//!
//! Each moment he lost patience with one of his agents is charged in Oko to
//! the model whose answer he was answering (`oko scorecard conduct`). A later
//! session of that model starts without having seen it, and repeats it. This
//! puts in front of it the rejections of the newest session of its model he
//! rejected, in his words, newest first, beside the standing rules. That is
//! the bound: one session's rejections, which the next session of the model
//! receives, as each earlier one was received by the session after it. The
//! older ones are counted and the command listing them is named. Each of his
//! sentences is written once in the whole block (`carried`), and a rejection
//! whose every sentence stands above is left out and counted too.

use serde_json::Value;

use super::carried::Written;

/// The heading of a block that could not be read, before the reason.
const UNREAD: &str = "# The operator's rejections of this session's model";

/// The block a session reads: the rejections of the newest rejected session
/// of the model it runs on, newest first, each sentence once across the whole
/// injected block. A session whose model cannot be read yet (it has made no
/// model call) is told why instead of being given another model's charges.
pub fn conduct_text(session: &str, written: &mut Written) -> String {
    let asked = ["scorecard", "conduct", "--session", session, "--json"];
    match super::read_oko(&asked) {
        Ok(answer) => listed(&answer, written),
        Err(cause) => format!("{UNREAD}: not read: {cause}\n"),
    }
}

/// The rejections `oko scorecard conduct --json` answered, oldest first, as
/// the block: those of the session the newest one was said in, one line each.
/// An answer that is not the conduct report is named as such, never copied
/// into the block, where its text would read as rules.
fn listed(answer: &Value, written: &mut Written) -> String {
    let model = match answer.get("model").and_then(Value::as_str) {
        Some(model) => model,
        None => return format!("{UNREAD}: Oko's answer names no model.\n"),
    };
    let heading = format!("# The operator's rejections of {model}");
    let rules = match answer.get("rules").and_then(Value::as_array) {
        Some(rules) => rules,
        None => return format!("{heading}: Oko's answer holds no list of rules.\n"),
    };
    let session_of = |rule: &Value| {
        rule.get("session")
            .and_then(Value::as_str)
            .map(str::to_owned)
    };
    let newest = match rules.last() {
        Some(rule) => session_of(rule),
        None => return format!("{heading}: none charged in Oko.\n"),
    };
    let mut lines = Vec::new();
    let mut above = Vec::new();
    let mut older = Vec::new();
    for rule in rules.iter().rev() {
        if session_of(rule) != newest {
            older.push(rule);
            continue;
        }
        let text = |field: &str| rule.get(field).and_then(Value::as_str).map(str::to_owned);
        let ordinal = rule.get("ordinal").map(Value::to_string);
        match (text("saidAt"), text("session"), ordinal, text("said")) {
            (Some(at), Some(session), Some(ordinal), Some(said)) => {
                match written.fresh_line(&said.trim().replace('\n', " ")) {
                    Some(fresh) => lines.push(format!("- {at} ({session} #{ordinal}): {fresh}\n")),
                    None => above.push(at),
                }
            }
            _ => lines.push(
                "- a rejection Oko answered without its time, session, turn or words\n".to_string(),
            ),
        }
    }
    let mut out = format!(
        "{heading}'s conduct in its newest rejected session, newest first. Never repeat them.\n"
    );
    lines.iter().for_each(|line| out.push_str(line));
    if !above.is_empty() {
        out.push_str(&format!(
            "- {} more of them say only what is written above.\n",
            above.len()
        ));
    }
    if !older.is_empty() {
        out.push_str(&format!(
            "- {} earlier rejection(s) of {model} in other sessions: `oko scorecard conduct --model {model}` lists them.\n",
            older.len()
        ));
    }
    out
}
