//! `tama hooks calls --item <id> [--json]`: every tool call
//! `block-unclaimed-calls` admitted for an item, from every session.
//!
//! The gate keeps each call it admits, with the items the session held, its
//! tool, its declared purpose and its time, in `calls.<session>.jsonl` beside
//! the sessions' control files. This reads those files for one item, so the
//! calls that served a task or defect are listed beside it: by Oko's
//! `oko defects show` and by anyone asking which calls a piece of work took.
//!
//! An item matches as Oko names it in either spelling: its full id or the
//! first group a register prints, in either case. A file that cannot be read,
//! or a complete line in it that is no record, is reported with its cause and
//! the command exits with failure, so a listing never stands for calls it
//! could not read. A last line still without its newline is a call being
//! written and is not read yet.

use std::path::Path;

use serde_json::{json, Value};

use super::abandoned::plain;

const USAGE: &str = "usage: tama hooks calls --item <id> [--json]";
const PREFIX: &str = "calls.";
const SUFFIX: &str = ".jsonl";

/// Whether a held item names the asked one, in Oko's long or short spelling.
fn names(held: &str, asked: &str) -> bool {
    let (held, asked) = (held.to_lowercase(), asked.to_lowercase());
    !held.is_empty() && !asked.is_empty() && (held.starts_with(&asked) || asked.starts_with(&held))
}

/// The calls one session's file holds for `item`.
fn session_calls(path: &Path, session: &str, item: &str) -> Result<Vec<Value>, String> {
    let text = std::fs::read_to_string(path)
        .map_err(|error| format!("cannot read {}: {error}", path.display()))?;
    let records = tama_hooks::jsonl::records(&text)
        .map_err(|cause| format!("{}: {cause}", path.display()))?;
    Ok(records
        .values
        .into_iter()
        .filter(|call| {
            call["items"].as_array().is_some_and(|items| {
                items
                    .iter()
                    .filter_map(Value::as_str)
                    .any(|held| names(held, item))
            })
        })
        .map(|mut call| {
            call["session"] = json!(session);
            call
        })
        .collect())
}

/// Every call kept for `item` under `root`, oldest first, and each file that
/// could not be read.
fn calls(root: &Path, item: &str) -> Result<(Vec<Value>, Vec<String>), String> {
    let entries = std::fs::read_dir(root)
        .map_err(|error| format!("cannot list {}: {error}", root.display()))?;
    let mut found = Vec::new();
    let mut errors = Vec::new();
    for entry in entries {
        let entry = entry
            .map_err(|error| format!("cannot read an entry of {}: {error}", root.display()))?;
        let name = entry.file_name().to_string_lossy().into_owned();
        let Some(session) = name
            .strip_prefix(PREFIX)
            .and_then(|rest| rest.strip_suffix(SUFFIX))
        else {
            continue;
        };
        match session_calls(&entry.path(), session, item) {
            Ok(kept) => found.extend(kept),
            Err(cause) => errors.push(cause),
        }
    }
    found.sort_by_key(|call| call["atMs"].as_u64());
    Ok((found, errors))
}

pub fn main(argv: &[String]) -> i32 {
    let mut item = None;
    let mut json_output = false;
    let mut arguments = argv.iter();
    while let Some(argument) = arguments.next() {
        match argument.as_str() {
            "--item" => match arguments.next() {
                Some(value) => item = Some(value.clone()),
                None => {
                    eprintln!("--item requires an item id\n{USAGE}");
                    return tama_core::exit::USAGE;
                }
            },
            "--json" => json_output = true,
            "--help" | "-h" => {
                println!("{USAGE}");
                return tama_core::exit::SUCCESS;
            }
            other => {
                eprintln!("unknown argument {other}\n{USAGE}");
                return tama_core::exit::USAGE;
            }
        }
    }
    let Some(item) = item else {
        eprintln!("{USAGE}");
        return tama_core::exit::USAGE;
    };
    let root = tama_hooks::session_control::session_control_root();
    let (found, errors) = match calls(&root, &item) {
        Ok(read) => read,
        Err(cause) => {
            eprintln!("tama hooks calls: {cause}");
            return tama_core::exit::FAILURE;
        }
    };
    if json_output {
        println!(
            "{}",
            json!({ "item": item, "root": root, "calls": found, "errors": errors })
        );
    } else {
        for error in &errors {
            eprintln!("tama hooks calls: {error}");
        }
        if found.is_empty() {
            println!("no call kept for {item} under {}", root.display());
        }
        for call in &found {
            println!(
                "{} {} {}: {}",
                call["atMs"],
                plain(&call["session"]),
                plain(&call["tool"]),
                plain(&call["purpose"])
            );
        }
    }
    if errors.is_empty() {
        tama_core::exit::SUCCESS
    } else {
        tama_core::exit::FAILURE
    }
}
