//! Prose and the stories it tells.
//!
//! Narration is judged only where a line is written for a reader: a date or a
//! hash inside code is data, and the same date inside a comment, a doc page,
//! a changelog line or a message string tells the story of one incident,
//! which belongs in Oko, not in a product.
//!
//! The decision reads the line's own shape, never its file's extension: a
//! line mostly of plain words is prose wherever it sits (a doc paragraph, a
//! docstring body); otherwise the tail after a comment marker is, and so is
//! each quoted string. A prose part is a sentence when plain words are most of
//! its tokens; a date or a hash outnumbering the words around it is a label or
//! a field.

use std::sync::LazyLock;

use regex::Regex;

use crate::ports::transport_common as common;

const HEADING: char = '#';
/// The separator a code path writes between a module and its item.
const PATH_SEPARATOR: &str = "::";
/// The joiner between the words of a package or crate name.
const WORD_JOINER: char = '-';
pub const DATE_KIND: &str = "date of an incident";
pub const HASH_KIND: &str = "commit, build, job or defect id";

/// Comment openers across the languages the workspace writes. A marker found
/// inside a quoted string is not one.
static MARKER: LazyLock<Regex> =
    LazyLock::new(|| common::compile(r"(?:^|\s)(?://+!?|/\*+|<!--|#+|--)\s"));
static QUOTED: LazyLock<Regex> =
    LazyLock::new(|| common::compile(r#""(?P<text>(?:[^"\\]|\\.)*)""#));
/// A token that is a plain word, trailing sentence punctuation allowed.
static PLAIN: LazyLock<Regex> =
    LazyLock::new(|| common::compile(r"^[*>\-]?[A-Za-z][A-Za-z'’]*[.,;:!?)]*$"));
/// A calendar date.
static DATE: LazyLock<Regex> =
    LazyLock::new(|| common::compile(r"\b(?:19|20)\d{2}-[01]\d-[0-3]\d\b"));
/// A commit, build, job, session or defect hash: seven or more hex digits,
/// in either case, since Oko writes a defect's full id in capitals.
static HASH: LazyLock<Regex> = LazyLock::new(|| common::compile(r"\b[0-9a-fA-F]{7,64}\b"));

/// Whether plain words are most of the tokens of `text`.
fn mostly_words(text: &str) -> bool {
    let tokens: Vec<&str> = text.split_whitespace().collect();
    let plain = tokens.iter().filter(|token| PLAIN.is_match(token)).count();
    plain > tokens.len() - plain
}

fn inside_quotes(code: &str, at: usize) -> bool {
    QUOTED
        .find_iter(code)
        .any(|found| found.start() < at && at < found.end())
}

/// The parts of `line` written for a reader, in order.
pub fn prose_segments(line: &str) -> Vec<&str> {
    if mostly_words(line) {
        return vec![line];
    }
    let comment = MARKER
        .find_iter(line)
        .find(|found| !inside_quotes(line, found.start()));
    let (code, tail) = match comment {
        Some(found) => (&line[..found.start()], Some(&line[found.end()..])),
        None => (line, None),
    };
    let mut segments: Vec<&str> = QUOTED
        .captures_iter(code)
        .filter_map(|caps| caps.name("text"))
        .map(|found| found.as_str())
        .collect();
    segments.extend(tail);
    segments
}

fn is_sentence(text: &str) -> bool {
    !text.trim_start().starts_with(HEADING) && mostly_words(text)
}

/// A hash carries both a letter and a digit, and its letters share one case:
/// git writes them small and Oko writes them capital. An all-digit run is a
/// number, an all-letter run a word, and a run that mixes cases, as the name
/// of a signature scheme or a curve does, is a name.
fn is_hash(candidate: &str) -> bool {
    let letters = || candidate.chars().filter(char::is_ascii_alphabetic);
    candidate.chars().any(|c| c.is_ascii_digit())
        && letters().next().is_some()
        && (letters().all(|c| c.is_ascii_lowercase()) || letters().all(|c| c.is_ascii_uppercase()))
}

/// Whether the run at `start..end` of `text` is one part of a longer name: a
/// segment of a code path (`crypto::…::verify`), or the first word of a
/// hyphenated package name whose next word is not hex (`…-dalek`). A full
/// UUID joins its groups with the same hyphen, but every group is hex, so a
/// defect's whole id stays an id.
fn in_compound_name(text: &str, start: usize, end: usize) -> bool {
    let (before, after) = (&text[..start], &text[end..]);
    if before.ends_with(PATH_SEPARATOR) || after.starts_with(PATH_SEPARATOR) {
        return true;
    }
    match after.strip_prefix(WORD_JOINER) {
        Some(rest) => rest
            .chars()
            .take_while(char::is_ascii_alphanumeric)
            .any(|c| !c.is_ascii_hexdigit()),
        None => false,
    }
}

/// Every date and hash a sentence narrates, as (kind, text as written).
pub fn narration(text: &str) -> Vec<(&'static str, String)> {
    if !is_sentence(text) {
        return Vec::new();
    }
    let dates = DATE
        .find_iter(text)
        .map(|hit| (DATE_KIND, hit.as_str().to_string()));
    let hashes = HASH
        .find_iter(text)
        .filter(|hit| is_hash(hit.as_str()) && !in_compound_name(text, hit.start(), hit.end()))
        .map(|hit| (HASH_KIND, hit.as_str().to_string()));
    dates.chain(hashes).collect()
}
