//! JS `detectRuntimeInstallDrift(root)` from `coverage-analysis.mjs`: for the
//! two providers whose config this product writes, which catalogued hooks
//! their config does not install.
//!
//! The second half of this change lives here. When the adapter config could
//! not be indexed the report said "adapter config unreadable" and refused,
//! for three different states of the world: a registry that declares no
//! adapter path, a declared path with nothing at it, and a file that would
//! not parse. Only the last two are drift. The first is the normal state of
//! an installed registry, which is stamped without its adapter block, so
//! refusing there made every installed machine permanently red while saying
//! nothing an operator could act on.

use std::collections::{BTreeMap, HashSet};
use std::path::Path;

use serde::Serialize;
use serde_json::Value;

use super::adapter_config::{
    adapter_command_index_result, AdapterCommandIndex, AdapterConfigProblem,
};
use super::claims::{runtime_actually_installs_hook, RuntimeSpec};
use super::{js_str, load_registry, CLAUDE_EVENTS, CODEX_EVENTS};
use crate::Result;

/// One entry of JS `detectRuntimeInstallDrift(root)`. `acknowledged` is
/// `None` for an adapter-level entry, matching the JS object which lacks the
/// key there.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct DriftEntry {
    pub runtime: String,
    pub event: Option<String>,
    pub hook_id: Option<String>,
    pub required_live_coverage: bool,
    pub unsupported_event: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub acknowledged: Option<bool>,
    pub material: bool,
    pub reason: String,
}

const DRIFT_CHECKED_RUNTIMES: &[(&str, &[&str])] =
    &[("codex", CODEX_EVENTS), ("claude", CLAUDE_EVENTS)];

const UNINSTALLED_REASON: &str =
    "registry catalog declares this hook for the event but the runtime adapter does not install it";

/// Is this state of the adapter config drift, or only an absent declaration?
fn problem_is_drift(problem: &AdapterConfigProblem) -> bool {
    !matches!(problem, AdapterConfigProblem::Undeclared { .. })
}

/// The events an adapter declares it cannot cover live; an adapter that
/// declares no such list leaves every event coverable.
fn unsupported_events(adapter: Option<&crate::registry::Adapter>) -> HashSet<&str> {
    adapter
        .and_then(|a| a.extra.get("unsupportedLiveCoverageEvents"))
        .and_then(Value::as_array)
        .into_iter()
        .flatten()
        .filter_map(Value::as_str)
        .collect()
}

/// The `event:hookId` pairs an adapter acknowledges leaving uninstalled, each
/// with a stated reason; an acknowledgement without one does not count.
fn acknowledged_hooks(adapter: Option<&crate::registry::Adapter>) -> HashSet<String> {
    adapter
        .and_then(|a| a.extra.get("acknowledgedUninstalledHooks"))
        .and_then(Value::as_array)
        .into_iter()
        .flatten()
        .filter(|entry| {
            entry
                .get("reason")
                .and_then(Value::as_str)
                .is_some_and(|reason| !reason.trim().is_empty())
        })
        .map(|entry| {
            format!(
                "{}:{}",
                js_str(entry.get("event")),
                js_str(entry.get("hookId"))
            )
        })
        .collect()
}

/// JS `detectRuntimeInstallDrift(root)`.
pub fn detect_runtime_install_drift(root: &Path) -> Result<Vec<DriftEntry>> {
    let registry = load_registry(root)?;
    let mut drift: Vec<DriftEntry> = Vec::new();
    for &(runtime, events) in DRIFT_CHECKED_RUNTIMES {
        let adapter = registry.adapters.get(runtime);
        let required_live_coverage =
            adapter.and_then(|a| a.extra.get("requiredLiveCoverage")) != Some(&Value::Bool(false));
        let unsupported_events = unsupported_events(adapter);
        let acknowledged = acknowledged_hooks(adapter);
        let index = match adapter_command_index_result(&registry, runtime) {
            Ok(index) => index,
            Err(problem) => {
                drift.push(DriftEntry {
                    runtime: runtime.to_string(),
                    event: None,
                    hook_id: None,
                    required_live_coverage,
                    unsupported_event: false,
                    acknowledged: None,
                    material: required_live_coverage && problem_is_drift(&problem),
                    reason: problem.reason(),
                });
                continue;
            }
        };
        let mut adapter_commands: BTreeMap<String, AdapterCommandIndex> = BTreeMap::new();
        adapter_commands.insert(runtime.to_string(), index);
        for (event, config) in &registry.events {
            if !events.contains(&event.as_str()) {
                continue;
            }
            for hook in &config.hooks {
                let spec = RuntimeSpec {
                    runtime: runtime.to_string(),
                    runtime_event: Some(event.clone()),
                };
                // JS passes no registry here (defaults to null).
                if runtime_actually_installs_hook(
                    &adapter_commands,
                    &spec,
                    &hook.id,
                    hook.command.as_deref(),
                    None,
                ) {
                    continue;
                }
                let unsupported_event = unsupported_events.contains(event.as_str());
                let is_acknowledged = acknowledged.contains(&format!("{event}:{}", hook.id));
                drift.push(DriftEntry {
                    runtime: runtime.to_string(),
                    event: Some(event.clone()),
                    hook_id: Some(hook.id.clone()),
                    required_live_coverage,
                    unsupported_event,
                    acknowledged: Some(is_acknowledged),
                    material: required_live_coverage && !unsupported_event && !is_acknowledged,
                    reason: UNINSTALLED_REASON.to_string(),
                });
            }
        }
    }
    // Ordered by runtime, then event, then hook; an adapter-level entry, which
    // names neither, comes first in its runtime.
    drift.sort_by(|a, b| {
        (&a.runtime, &a.event, &a.hook_id).cmp(&(&b.runtime, &b.event, &b.hook_id))
    });
    Ok(drift)
}
