//! What a release takes off the machine: launch agents the registry records
//! as installed but not active, names a program used to be installed under,
//! and the separate hook programs Tama shipped before it was one program.
//!
//! A unit declared `installed-not-active` does no work, yet a plist left in
//! `~/Library/LaunchAgents` with `KeepAlive` keeps launchd restarting it. A
//! release brings the machine to what the registry says, so it retires such
//! a unit: booted out, and its plist removed, so a later emergency re-enable
//! finds nothing to bootstrap.

use std::os::unix::fs::MetadataExt;
use std::path::Path;
use std::process::Command;

use serde_json::Value;

const INACTIVE: &str = "installed-not-active";
const LAUNCH_AGENTS: &str = "Library/LaunchAgents/";
const HOME_TOKEN: &str = "$HOME/";

/// Retires every registry launch agent marked inactive that is still on
/// disk, and says what it did. A failure is reported, never fatal: the hooks
/// themselves are installed already.
pub(super) fn inactive_launch_agents(registry: &Path, home: &Path) {
    // The read failures are reported like every other failure here; returning
    // silently left inactive agents running with nothing saying why.
    let text = match std::fs::read_to_string(registry) {
        Ok(text) => text,
        Err(error) => {
            println!(
                "could not retire inactive launch agents: cannot read {}: {error}",
                registry.display()
            );
            return;
        }
    };
    let document = match serde_json::from_str::<Value>(&text) {
        Ok(document) => document,
        Err(error) => {
            println!(
                "could not retire inactive launch agents: {} is not JSON: {error}",
                registry.display()
            );
            return;
        }
    };
    let Some(adapters) = document
        .pointer("/catalog/editorAdapters")
        .and_then(Value::as_array)
    else {
        println!(
            "could not retire inactive launch agents: {} holds no /catalog/editorAdapters array",
            registry.display()
        );
        return;
    };
    // The agent is booted out of the user's GUI domain before its plist is
    // removed; without the user id it cannot be, and removing the plist alone
    // would leave the agent loaded with nothing on disk to say so.
    let uid = match std::fs::metadata(home) {
        Ok(meta) => Some(meta.uid()),
        Err(error) => {
            println!(
                "could not retire inactive launch agents: the owner of {} cannot be read: {error}",
                home.display()
            );
            return;
        }
    };
    for adapter in adapters {
        if adapter.get("status").and_then(Value::as_str) != Some(INACTIVE) {
            continue;
        }
        let Some(source) = adapter.get("source").and_then(Value::as_str) else {
            continue;
        };
        let Some(relative) = source.strip_prefix(HOME_TOKEN) else {
            continue;
        };
        if !relative.starts_with(LAUNCH_AGENTS) {
            continue;
        }
        let plist = home.join(relative);
        if !plist.is_file() {
            continue;
        }
        let id = match adapter.get("id").and_then(Value::as_str) {
            Some(id) => id.to_string(),
            None => format!("the adapter at {}", plist.display()),
        };
        if let Some(uid) = uid {
            if let Err(cause) = unloaded(&format!("gui/{uid}"), &plist) {
                println!("could not retire {id}: {cause}");
                continue;
            }
        }
        match std::fs::remove_file(&plist) {
            Ok(()) => println!(
                "retired {id}: {} is {INACTIVE} in the registry",
                plist.display()
            ),
            Err(error) => println!("could not retire {id} at {}: {error}", plist.display()),
        }
    }
}

/// Unload the agent `plist` names from `domain`. Not loaded is the state
/// wanted, so a refused bootout is read against launchd itself: an agent it
/// still knows was not unloaded, and the caller keeps its file so a loaded
/// agent is not left with nothing on disk. A launchctl that cannot run, or a
/// plist whose label cannot be read from its name, is the error.
fn unloaded(domain: &str, plist: &Path) -> Result<(), String> {
    let mut bootout = Command::new("launchctl");
    bootout.arg("bootout").arg(domain).arg(plist);
    let output = stado_wait::output(&mut bootout)
        .map_err(|error| format!("launchctl cannot be asked to unload it: {error}"))?;
    if output.status.success() {
        return Ok(());
    }
    let label = plist
        .file_stem()
        .and_then(|stem| stem.to_str())
        .ok_or_else(|| format!("{} names no launchd label", plist.display()))?;
    let mut print = Command::new("launchctl");
    print.arg("print").arg(format!("{domain}/{label}"));
    let known = stado_wait::output(&mut print)
        .map_err(|error| format!("launchctl cannot be asked whether {label} is loaded: {error}"))?;
    if known.status.success() {
        return Err(format!(
            "launchctl bootout exited {} and launchd still knows {label}: {}",
            output.status,
            String::from_utf8_lossy(&output.stderr).trim()
        ));
    }
    Ok(())
}

/// Removes each retired program name from `~/.local/bin` and says so. An old
/// copy left there keeps answering under the name it was renamed from, at
/// whatever build it last was.
pub(super) fn renamed_programs(home: &Path, names: &[&str]) {
    for name in names {
        let path = home.join(".local/bin").join(name);
        let removed = match std::fs::symlink_metadata(&path) {
            Ok(meta) if meta.is_dir() => std::fs::remove_dir_all(&path),
            Ok(_) => std::fs::remove_file(&path),
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => continue,
            Err(error) => Err(error),
        };
        match removed {
            Ok(()) => println!(
                "retired {}: the program is installed as tama",
                path.display()
            ),
            Err(error) => println!("could not retire {}: {error}", path.display()),
        }
    }
}

/// The test runners earlier releases installed as `tama-<name>`; the test kit
/// that built them was removed, and a machine may still hold the programs.
const RETIRED_TEST_RUNNERS: &[&str] = &[
    "require-live-runtime",
    "generate-configs-integrity",
    "session-overrides",
];

/// Removes from `~/.local/bin` every separate program Tama used to install —
/// each hook and tool `tama hook` now runs, the three test runners an earlier
/// release shipped, and every other name an earlier release recorded —
/// together with the `.d` folder of build artefacts beside it, and says so.
/// Only the recorded names were removed at first, and a machine kept 60
/// programs and folders nothing recorded, each answering at the build it
/// last was.
pub(super) fn separate_hook_programs(
    home: &Path,
    recorded: &std::collections::BTreeMap<String, String>,
    program: &str,
) {
    let mut names: Vec<String> = recorded
        .keys()
        .filter(|name| name.as_str() != program)
        .cloned()
        .collect();
    names.extend(
        tama_hook_tools::programs::names()
            .chain(RETIRED_TEST_RUNNERS.iter().copied())
            .map(|name| format!("{program}-{name}")),
    );
    for name in names {
        for path in [
            home.join(".local/bin").join(&name),
            home.join(".local/bin").join(format!("{name}.d")),
        ] {
            let removed = match std::fs::symlink_metadata(&path) {
                Ok(meta) if meta.is_dir() => std::fs::remove_dir_all(&path),
                Ok(_) => std::fs::remove_file(&path),
                Err(error) if error.kind() == std::io::ErrorKind::NotFound => continue,
                Err(error) => Err(error),
            };
            match removed {
                Ok(()) => println!("retired {}: it was a separate program", path.display()),
                Err(error) => println!("could not retire {}: {error}", path.display()),
            }
        }
    }
}
