//! What `tama` says when asked for help or given no command it knows: the
//! usage text, and the lines of it that describe one command of the tree.
//! Both are read from the one command table dispatch runs from.

mod entries;
pub(crate) mod table;
mod table_text;

use tama_core::exit;

/// A group command that names none of its verbs: the group's usage lines on
/// stderr and the usage exit.
pub fn group_refusal(group: &str) -> i32 {
    match command_usage(&[group]) {
        Some(text) => eprintln!("{text}"),
        None => usage(),
    }
    tama_core::exit::USAGE
}

/// `--help` or `-h` after a command answers with that command's lines of the
/// usage text and never runs it: run, `tama show --help` would look up a hook
/// named --help and `tama install --help` would install. The command is
/// the words before the first option, so `tama violations find --help`
/// describes `violations find`, not the whole group. Returns when the line
/// asks no help this text can give, for the command's own usage to answer.
pub fn answer_if_asked(argv: &[String]) {
    let asks_help = argv
        .split_first()
        .is_some_and(|(_, after)| after.iter().any(|word| word == "--help" || word == "-h"));
    if !asks_help {
        return;
    }
    let path: Vec<&str> = argv
        .iter()
        .map(String::as_str)
        .take_while(|word| !word.starts_with('-'))
        .collect();
    if let Some(text) = command_usage(&path) {
        println!("{text}");
        std::process::exit(exit::SUCCESS);
    }
}

/// The usage text: the head line and every command's summary lines, in the
/// order the command table lists them.
fn usage_text() -> String {
    let lines: Vec<&str> = table::COMMANDS
        .iter()
        .filter_map(|command| command.summary)
        .collect();
    format!("tama <command>\n\nCommands:\n{}\n", lines.join("\n"))
}

/// The usage text after a command line that names no command: it goes to
/// stderr, beside the refusal's exit status.
pub fn usage() {
    eprintln!("{}", usage_text());
}

/// The usage text asked for with `help`, `--help` or `-h`: an answer, so it
/// goes to stdout where a pager or a pipe reads it.
pub fn help() {
    println!("{}", usage_text());
}

/// The lines of the usage text that describe the deepest command `path`
/// names: `tama violations find --help` answers with the `violations find`
/// lines and `tama violations --help` with every `violations` line, each
/// headed by the command it describes, so each level of the tree has its own
/// help. Words after the deepest command (a hook id, a path) are its
/// arguments, not commands. `None` when the usage lists no command on the path.
pub fn command_usage(path: &[&str]) -> Option<String> {
    std::iter::successors(Some(path), |shorter| {
        shorter
            .split_last()
            .map(|(_, rest)| rest)
            .filter(|rest| !rest.is_empty())
    })
    .find_map(usage_of)
}

/// Whether a USAGE entry's leading words name `path`: each word is the
/// entry's word there, or one of a `<a|b|c>` alternation. A `<command>`
/// placeholder names no verb, so a verb only a group's own usage lists is
/// answered with that group's lines.
fn names(entry: &str, path: &[&str]) -> bool {
    let mut words = entry.split_whitespace();
    path.iter().all(|wanted| match words.next() {
        Some(word) if word == *wanted => true,
        Some(word) => word
            .strip_prefix('<')
            .and_then(|inner| inner.strip_suffix('>'))
            .is_some_and(|inner| inner.split('|').any(|choice| choice == *wanted)),
        None => false,
    })
}

fn usage_of(path: &[&str]) -> Option<String> {
    // A group that writes its own verb lines describes each verb more
    // closely than the summary's one line for the whole group.
    if let Some(own) = own_verb_usage(path) {
        return Some(own);
    }
    let mut lines = Vec::new();
    let mut inside = false;
    let text = usage_text();
    for line in text.lines() {
        let entry = line
            .strip_prefix("  ")
            .filter(|rest| !rest.starts_with(' '));
        match entry {
            Some(rest) => inside = names(rest, path),
            None if !line.starts_with("    ") => inside = false,
            None => {}
        }
        if inside {
            lines.push(line);
        }
    }
    if lines.is_empty() {
        return None;
    }
    Some(format!("tama {}\n\n{}", path.join(" "), lines.join("\n")))
}

/// The usage a group writes for its own verbs, where the summary lists the
/// group without them.
fn group_usage(group: &str) -> Option<&'static str> {
    table::find(group)?.own_usage
}

/// `tama <group> <verb>`'s lines of the group's own usage: each line whose
/// first word is the verb, or that spells the command out as `tama <group>
/// <verb> …`.
fn own_verb_usage(path: &[&str]) -> Option<String> {
    let [group, verb] = path else {
        return None;
    };
    let spelled = format!(" {group} {verb} ");
    let lines: Vec<&str> = group_usage(group)?
        .lines()
        .filter(|line| {
            line.split_whitespace().next() == Some(*verb) || format!("{line} ").contains(&spelled)
        })
        .collect();
    (!lines.is_empty()).then(|| format!("tama {group} {verb}\n\n{}", lines.join("\n")))
}
