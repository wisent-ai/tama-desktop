//! Branches and pull requests.
//!
//! A repository has one line of work, `main`, in its one checkout. A branch
//! is a second line beside it: what is parked there drifts from `main`, and
//! bringing it back is a merge made without reading what other sessions did
//! meanwhile — the bulk merge that destroyed their work. A pull request is
//! the same branch handed to a review queue. So nothing opens either here:
//!
//! - `git branch <name>` that starts or copies a branch (`-c`, `-C`,
//!   `--copy`, or a name with no other mode); listing, deleting, renaming
//!   and upstream settings pass;
//! - `git checkout -b|-B|--orphan` and `git switch -c|-C|--create|
//!   --force-create|--orphan`;
//! - `gh pr create`.
//!
//! Switching to a branch that already exists, and deleting one, still pass:
//! that is how the stray lines are brought back and removed.

/// The `git` subcommands that can start a branch.
const BRANCH: &str = "branch";
const CHECKOUT: &str = "checkout";
const SWITCH: &str = "switch";
/// `git checkout` options that start a new branch (git-checkout(1)).
const CHECKOUT_CREATES: &[&str] = &["-b", "-B", "--orphan"];
/// `git switch` options that start a new branch (git-switch(1)).
const SWITCH_CREATES: &[&str] = &["-c", "-C", "--create", "--force-create", "--orphan"];
/// `git branch` options that copy a branch into a new one (git-branch(1)).
const BRANCH_COPIES: &[&str] = &["-c", "-C", "--copy"];
/// `git branch` options under which its operands are no branch to start:
/// list, delete, rename, upstream and description modes (git-branch(1)).
const BRANCH_OTHER_MODES: &[&str] = &[
    "-d",
    "-D",
    "--delete",
    "-m",
    "-M",
    "--move",
    "-l",
    "--list",
    "-a",
    "--all",
    "-r",
    "--remotes",
    "--show-current",
    "--edit-description",
    "-u",
    "--set-upstream-to",
    "--unset-upstream",
    "--contains",
    "--no-contains",
    "--merged",
    "--no-merged",
    "--points-at",
    "--format",
    "--sort",
    "--column",
];
/// The code host's command line and its pull-request command.
pub(super) const GH_PROGRAM: &str = "gh";
const PULL_REQUEST: &str = "pr";
const CREATE: &str = "create";

const REASON: &str = "BLOCKED: a branch or a pull request opens a second line of work beside \
                      main, and bringing it back is a merge made blind to what other sessions \
                      did meanwhile. Work on main in the one checkout: commit your own paths, \
                      'git pull --no-rebase --no-edit', 'git push'. Switching to a branch that \
                      exists and deleting one still pass.";

/// The option's name: `--create=x` is `--create`.
fn option_name(argument: &str) -> &str {
    match argument.split_once('=') {
        Some((name, _)) => name,
        None => argument,
    }
}

/// Whether any argument is one of `options`.
fn carries(arguments: &[String], options: &[&str]) -> bool {
    arguments
        .iter()
        .any(|argument| options.contains(&option_name(argument)))
}

/// Whether `git branch <arguments>` starts a branch: it copies one, or it
/// names one under no list, delete, rename or upstream mode.
fn branch_starts(arguments: &[String]) -> bool {
    if carries(arguments, BRANCH_COPIES) {
        return true;
    }
    if carries(arguments, BRANCH_OTHER_MODES) {
        return false;
    }
    arguments.iter().any(|argument| !argument.starts_with('-'))
}

/// The refusal a `git <subcommand> <arguments>` call earns for starting a
/// branch, if any.
pub(super) fn refusal(subcommand: &str, arguments: &[String]) -> Option<&'static str> {
    let starts = (subcommand == BRANCH && branch_starts(arguments))
        || (subcommand == CHECKOUT && carries(arguments, CHECKOUT_CREATES))
        || (subcommand == SWITCH && carries(arguments, SWITCH_CREATES));
    starts.then_some(REASON)
}

/// The refusal a `gh <arguments>` call earns for opening a pull request, if
/// any: `pr` then `create` among its words, wherever global options stand.
pub(super) fn pull_request_refusal(arguments: &[String]) -> Option<&'static str> {
    let words: Vec<&str> = arguments
        .iter()
        .map(String::as_str)
        .filter(|argument| !argument.starts_with('-'))
        .collect();
    let opens = words
        .windows(2)
        .any(|pair| pair[0] == PULL_REQUEST && pair[1] == CREATE);
    opens.then_some(REASON)
}
