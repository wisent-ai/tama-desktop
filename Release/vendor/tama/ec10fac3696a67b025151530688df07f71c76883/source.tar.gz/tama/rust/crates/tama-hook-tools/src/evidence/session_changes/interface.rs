//! Typed request used by terminal and native Desktop staging.
use super::Report;
use serde::Deserialize;
use std::path::PathBuf;

pub const USAGE: &str = "tama stage --session <session> [--with <session>]... [--task <task>] [--repo <checkout>] [--path <file>]... [--from-head] [--json] [--inspect]";

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Request {
    pub session: String,
    pub repository: PathBuf,
    #[serde(default)]
    pub inspect: bool,
    /// Only the session's edits of these paths; every edit when empty.
    #[serde(default)]
    pub paths: Vec<PathBuf>,
    /// The sessions that wrote the session's paths together with it; none
    /// when empty.
    #[serde(default)]
    pub with: Vec<String>,
    /// The Oko task the session took over from a stopped session named in
    /// `with`, whose every edited path is then staged with its own.
    #[serde(default)]
    pub task: Option<String>,
    /// Read the index from HEAD before staging, so an index read on an
    /// older HEAD carries only the session's change.
    #[serde(default, rename = "fromHead")]
    pub from_head: bool,
}

impl Request {
    pub fn execute(&self) -> Result<Report, String> {
        super::stage(
            &self.repository,
            &self.session,
            !self.inspect,
            &self.paths,
            &self.with,
            self.task.as_deref(),
            self.from_head,
        )
    }
}

pub fn request(body: serde_json::Value) -> Result<Report, String> {
    serde_json::from_value::<Request>(body)
        .map_err(|cause| format!("invalid staging request: {cause}"))?
        .execute()
}

pub fn cli(arguments: &[String]) -> Result<(), String> {
    let mut session = None;
    let mut repository = None;
    let mut inspect = false;
    let mut json = false;
    let mut paths = Vec::new();
    let mut with = Vec::new();
    let mut task = None;
    let mut from_head = false;
    let mut args = arguments.iter();
    while let Some(argument) = args.next() {
        match argument.as_str() {
            "--session" if session.is_none() => {
                session = Some(
                    args.next()
                        .ok_or("--session requires a recorded session identity")?
                        .clone(),
                );
            }
            "--repo" if repository.is_none() => {
                repository = Some(PathBuf::from(
                    args.next().ok_or("--repo requires a checkout path")?,
                ));
            }
            "--path" => {
                paths.push(PathBuf::from(
                    args.next()
                        .ok_or("--path requires a file the session edited")?,
                ));
            }
            "--with" => {
                with.push(
                    args.next()
                        .ok_or("--with requires a session that wrote with this one")?
                        .clone(),
                );
            }
            "--task" if task.is_none() => {
                task = Some(
                    args.next()
                        .ok_or("--task requires the Oko task taken over from a --with session")?
                        .clone(),
                );
            }
            "--inspect" if !inspect => inspect = true,
            "--from-head" if !from_head => from_head = true,
            "--json" if !json => json = true,
            "--help" => {
                println!("{USAGE}");
                return Ok(());
            }
            unknown => {
                return Err(format!(
                    "unexpected or repeated stage argument {unknown}; {USAGE}"
                ))
            }
        }
    }
    let request = Request {
        session: session.ok_or_else(|| format!("stage requires --session; {USAGE}"))?,
        repository: match repository {
            Some(repository) => repository,
            None => std::env::current_dir().map_err(|cause| {
                format!("cannot resolve current checkout: {cause}; supply --repo")
            })?,
        },
        inspect,
        paths,
        with,
        task,
        from_head,
    };
    let report = request.execute()?;
    if json {
        println!(
            "{}",
            serde_json::to_string_pretty(&report)
                .map_err(|cause| format!("cannot encode staging result: {cause}"))?
        );
    } else {
        let action = if report.applied {
            "Staged"
        } else {
            "Inspected"
        };
        println!(
            "{action} recorded edits for {} in {}",
            report.session,
            report.repository.display()
        );
        for path in &report.paths {
            println!("  {}", path.display());
        }
        for left in &report.omitted {
            println!("  left out {}: {}", left.path.display(), left.cause);
        }
        println!("Index tree: {}", report.tree);
        match (report.paths.is_empty(), report.omitted.is_empty()) {
            (true, true) => println!("No unstaged recorded text changes remain."),
            (true, false) => println!(
                "Nothing was staged: {} recorded change(s) remain unstaged, left out above with their causes.",
                report.omitted.len()
            ),
            (false, _) => {}
        }
    }
    Ok(())
}
