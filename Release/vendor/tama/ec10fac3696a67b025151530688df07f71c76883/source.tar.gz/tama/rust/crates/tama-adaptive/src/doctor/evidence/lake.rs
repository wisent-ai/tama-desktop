//! Reading committed evidence out of the transcript lake: the cursor
//! store, the segment outputs it names, and the digest each one has to
//! match. A commit whose outputs do not prove it is an error naming the
//! commit and the check, not evidence left out in silence.
//!
//! Split out of `doctor/evidence.rs`, which had grown past the
//! three-hundred-line limit.

use std::collections::HashSet;
use std::fs;
use std::path::{Component, Path, PathBuf};

use serde_json::Value;
use sha2::{Digest, Sha256};

use super::{canonical_evidence, object, Evidence};
use crate::util::home_dir;

/// Where the lake keeps its data unless `LAKE_DATA` names another place.
const LAKE_FOLDER: &str = ".transcript-lake";
/// The cursor-store key prefix of a hook telemetry segment.
const HOOKS_KEY: &str = "hooks:";

pub(super) fn read_lake_evidence() -> Result<(Vec<Evidence>, HashSet<String>), String> {
    let lake_root = match tama_core::path_variable("LAKE_DATA") {
        Some(root) => root,
        None => home_dir().join(LAKE_FOLDER),
    };
    let cursor_path = lake_root.join("cursors.json");
    let shown = cursor_path.display();
    // Only a cursor store that does not exist means no committed evidence.
    let text = match fs::read_to_string(&cursor_path) {
        Ok(text) => text,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
            return Ok((Vec::new(), HashSet::new()));
        }
        Err(error) => {
            return Err(format!(
                "the lake cursor store {shown} cannot be read: {error}"
            ))
        }
    };
    let store = object(&text).map_err(|cause| format!("the lake cursor store {shown} {cause}"))?;
    let hooks_dir = lake_root.join("events").join("runtime=hooks");
    let mut rows = Vec::new();
    let mut segment_ids = HashSet::new();
    for (key, commit) in &store {
        let Some(segment_id) = key.strip_prefix(HOOKS_KEY) else {
            continue;
        };
        let closed = commit.get("kind").and_then(Value::as_str) == Some("closed-segment")
            && commit.get("state").and_then(Value::as_str) == Some("committed");
        if !closed {
            continue;
        }
        let evidence = committed(segment_id, commit, &hooks_dir).map_err(|cause| {
            format!("the lake commit {key} in {shown} is not evidence: {cause}")
        })?;
        rows.extend(evidence);
        segment_ids.insert(segment_id.to_string());
    }
    Ok((rows, segment_ids))
}

/// The evidence one committed segment carries, or the check it failed.
fn committed(segment_id: &str, commit: &Value, hooks_dir: &Path) -> Result<Vec<Evidence>, String> {
    if segment_id.is_empty() {
        return Err("it names no segment".to_string());
    }
    if commit.get("segmentId").and_then(Value::as_str) != Some(segment_id) {
        return Err(format!("its segmentId is not {segment_id}"));
    }
    let outputs = match commit.get("outputs").and_then(Value::as_array) {
        Some(outputs) if !outputs.is_empty() => outputs,
        _ => return Err("it lists no outputs".to_string()),
    };
    let expected_name = format!("segment-{segment_id}.ndjson");
    let mut rows = Vec::new();
    let mut seen = HashSet::new();
    for output in outputs {
        let (Some(path), Some(digest)) = (
            output.get("path").and_then(Value::as_str),
            output.get("sha256").and_then(Value::as_str),
        ) else {
            return Err("an output names no path and sha256".to_string());
        };
        let file_path = resolve_path(path)?;
        if !in_date_partition(&file_path, hooks_dir, &expected_name) {
            return Err(format!(
                "its output {path} is not {}/date=YYYY-MM-DD/{expected_name}",
                hooks_dir.display()
            ));
        }
        if !seen.insert(file_path.clone()) {
            return Err(format!("it lists the output {path} twice"));
        }
        let source = fs::read_to_string(&file_path)
            .map_err(|error| format!("its output {path} cannot be read: {error}"))?;
        if format!("{:x}", Sha256::digest(source.as_bytes())) != digest {
            return Err(format!(
                "its output {path} no longer has the digest the commit names"
            ));
        }
        let body = source
            .strip_suffix('\n')
            .ok_or_else(|| format!("the last row of its output {path} is not terminated"))?;
        for text in body.split('\n') {
            let row = object(text).map_err(|cause| format!("a row of {path} {cause}"))?;
            if let Some(evidence) = canonical_evidence(&row, segment_id)
                .map_err(|cause| format!("a row of {path} {cause}"))?
            {
                rows.push(evidence);
            }
        }
    }
    Ok(rows)
}

fn resolve_path(path: &str) -> Result<PathBuf, String> {
    let given = PathBuf::from(path);
    if given.is_absolute() {
        return Ok(given);
    }
    let cwd = std::env::current_dir().map_err(|error| {
        format!("lake output {path} is relative and the working directory cannot be read: {error}")
    })?;
    Ok(cwd.join(given))
}

/// Whether `path` is `<hooks_dir>/date=YYYY-MM-DD/<name>`.
fn in_date_partition(path: &Path, hooks_dir: &Path, name: &str) -> bool {
    let Ok(relative) = path.strip_prefix(hooks_dir) else {
        return false;
    };
    let parts: Vec<Component> = relative.components().collect();
    let [Component::Normal(partition), Component::Normal(file)] = parts.as_slice() else {
        return false;
    };
    let date = partition
        .to_str()
        .and_then(|text| text.strip_prefix("date="));
    *file == name && date.is_some_and(|date| tama_core::clock::parse_date(date).is_ok())
}
