//! The justification registries' side of the one attestation primitive
//! (`tama_hook_tools::attestation`): every file justification and every CUA
//! or SSH grant a verb writes into its registry is kept in the attestation
//! ledger in the one format, and withdrawn there when the verb removes it.
//! The registry stays the view its gate reads.

use std::path::Path;

use serde_json::{json, Value};
use tama_core::clock::iso_now;
use tama_hook_tools::attestation::{attest, withdraw, Attestation};

/// The file justification registry's kind in the ledger.
const FILE: &str = "file";
/// Record the file justification `entry` for `key` in its registry `view`
/// and keep it in the ledger.
pub(crate) fn file_record(view: &Path, key: &str, entry: Value) -> Result<(), String> {
    super::record(view, key, entry.clone())?;
    file_kept(view, key, &entry)
}

/// Remove the file justification for `key` from `view` and the ledger.
pub(crate) fn file_forget(view: &Path, key: &str) -> Result<(), String> {
    super::forget(view, key)?;
    file_withdrawn(view, key)
}

/// Move the file justification from `from` to `to` in `view` and the ledger.
pub(crate) fn file_rename(view: &Path, from: &str, to: &str) -> Result<(), String> {
    let entry = super::load(view)?.get(from).cloned();
    super::rename(view, from, to)?;
    file_withdrawn(view, from)?;
    match entry {
        Some(entry) => file_kept(view, to, &entry),
        None => Ok(()),
    }
}

/// Keep the file justification `entry` for `key` written to `view`.
fn file_kept(view: &Path, key: &str, entry: &Value) -> Result<(), String> {
    let store = view.display().to_string();
    withdraw(FILE, &store, |kept| kept.subject == key)?;
    attest(Attestation {
        kind: FILE.into(),
        subject: key.into(),
        statement: entry["justification"].clone(),
        attester: "agent".into(),
        scope: json!({}),
        lifetime: entry["expires_at"].clone(),
        verification: "artifact".into(),
        store,
        recorded_at: iso_now(),
    })
    .map(|_| ())
}

/// Withdraw the file justification for `key` from the ledger's `view`.
fn file_withdrawn(view: &Path, key: &str) -> Result<(), String> {
    withdraw(FILE, &view.display().to_string(), |kept| {
        kept.subject == key
    })
    .map(|_| ())
}

/// The ledger's kind of a grant registry, the field naming what a grant is
/// for, and the field naming what it admits: the one reading of a grant's
/// shape, which the attestation listing uses too.
pub(crate) fn grant_fields(kind: super::Kind) -> (&'static str, &'static str, &'static str) {
    match kind {
        super::Kind::Cua => ("cua", "allowedBundleId", "allowedActions"),
        _ => ("ssh", "allowedTargets", "allowedOperations"),
    }
}

/// Keep the operator's grant `entry` of registry `kind` written to `view`:
/// its subject what it is for, its statement his cited sentence, its scope
/// what it admits in which session.
pub(crate) fn grant_kept(kind: super::Kind, view: &Path, entry: &Value) -> Result<(), String> {
    let (name, subject_field, scope_field) = grant_fields(kind);
    // What the grant is for may be one name or a list of targets, kept as
    // the attestation listing reads it; a grant that names nothing, or
    // cites no sentence, is refused rather than kept as "null".
    let subject = match &entry[subject_field] {
        Value::Null => {
            return Err(format!(
                "a {name} grant written to {} carries no {subject_field}, so the attestation ledger cannot keep it",
                view.display()
            ))
        }
        Value::String(text) => text.clone(),
        other => other.to_string(),
    };
    let statement = match &entry["userRequestQuote"] {
        Value::Null => {
            return Err(format!(
                "the {name} grant for {subject} in {} cites no userRequestQuote, so the attestation ledger cannot keep it",
                view.display()
            ))
        }
        quote => quote.clone(),
    };
    let store = view.display().to_string();
    withdraw(name, &store, |kept| {
        kept.subject == subject && kept.statement == statement
    })?;
    attest(Attestation {
        kind: name.into(),
        subject,
        statement,
        attester: "operator".into(),
        scope: json!({ "admits": entry[scope_field], "session": entry["sessionId"] }),
        lifetime: entry["lifetime"].clone(),
        verification: "transcript".into(),
        store,
        recorded_at: iso_now(),
    })
    .map(|_| ())
}

/// Withdraw every grant of registry `kind` in `view` that cites `quote`.
pub(crate) fn grant_withdrawn(kind: super::Kind, view: &Path, quote: &str) -> Result<(), String> {
    let (name, _, _) = grant_fields(kind);
    withdraw(name, &view.display().to_string(), |kept| {
        kept.statement.as_str() == Some(quote)
    })
    .map(|_| ())
}
