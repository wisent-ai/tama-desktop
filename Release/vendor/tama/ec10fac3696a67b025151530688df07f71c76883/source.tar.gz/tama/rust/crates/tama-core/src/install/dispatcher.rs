//! The managed Git dispatcher: the script it writes, where it writes it,
//! and the bypass that refuses the write.
//!
//! Split out of `install/mod.rs`, which had grown past the
//! three-hundred-line limit. The level plan stays there.

use serde::Serialize;
use std::fs;
use std::path::Path;

use super::MANAGED_HEADER;
use crate::{err, Result};

/// The managed dispatcher for one Git hook, the one script both `tama
/// install` and a release install write. Every push, of any repository,
/// first passes `tama hook review-push`, which reads the attestation each
/// pushed commit carries in its message and refuses a commit that lacks a
/// claim, naming it; no model or other product is asked, so it answers in
/// moments, and a push it refuses spends no minutes on checks whose verdict
/// could not let it through. Only then does the dispatcher run the Rust
/// formatting gate and `tama hook quality-check` with Git's pre-push
/// records, which runs `stado quality check --pre-push --if-declared`: Stado
/// reads the release manifest each pushed commit carries and runs that
/// commit's gates on its own tree, writing nothing, so a commit the
/// installation would refuse is refused before it reaches main instead of
/// failing every other session's build of that product, and another
/// session's uncommitted work in the one shared checkout neither refuses nor
/// admits it; a commit that declares no gate is Stado's printed answer, not
/// a guess made here from the manifest's text, and a refusal is restated in
/// Stado's own terms (a formatting gate's prescribes `stado quality format`,
/// any other names Stado's failure point, error code and detail). Every move
/// of a branch ref passes `tama hook
/// review-ref-move` from the `reference-transaction` dispatcher: a rewrite
/// or reset that would drop a commit the defect register names, with no
/// commit of the same patch under the new tip, is refused before Git lets
/// the old history go, and a rewrite that keeps every named patch has the
/// register follow the new ids once the refs have moved.
pub fn dispatcher_body(root: &str, hook_name: &str, backup_path: &str) -> String {
    let json = crate::json::compact::<str>;
    let repo_hook = format!("${{repo_root}}/.githooks/{hook_name}");
    let mut out = String::new();
    out.push_str("#!/bin/sh\n");
    out.push_str(MANAGED_HEADER);
    out.push('\n');
    if hook_name == "reference-transaction" {
        out.push_str("# tama reference-move preflight\n");
    }
    out.push_str("set -eu\n");
    out.push_str("ROOT=");
    out.push_str(&json(root));
    out.push('\n');
    out.push_str("PATH=\"$ROOT/bin:$PATH\"\nexport PATH\n");
    out.push_str("HOOK_NAME=");
    out.push_str(&json(hook_name));
    out.push('\n');
    out.push_str("if [ \"$HOOK_NAME\" = reference-transaction ] && [ \"${1:-}\" = move ]; then\n  exec tama hook review-ref-move \"$@\"\nfi\n");
    out.push_str("BACKUP=");
    out.push_str(&json(backup_path));
    out.push('\n');
    #[cfg(target_os = "macos")]
    out.push_str(
        "STATE_ROOT=\"${HOME:?Tama Git hooks require HOME}/Library/Application Support/Tama\"\n",
    );
    #[cfg(not(target_os = "macos"))]
    out.push_str("STATE_ROOT=\"${XDG_STATE_HOME:-${HOME:?Tama Git hooks require HOME}/.local/state}/tama\"\n");
    out.push_str("umask u=rwx,go=\n");
    out.push_str("mkdir -p \"$STATE_ROOT/git-dispatch\"\n");
    out.push_str("INPUT_DIR=\"$(mktemp -d \"$STATE_ROOT/git-dispatch/$HOOK_NAME.XXXXXXXX\")\" || { echo 'tama: cannot allocate private Git hook input in its state directory' >&2; exit 1; }\n");
    out.push_str("INPUT_FILE=\"$INPUT_DIR/stdin\"\n");
    out.push_str("trap 'rm -f \"$INPUT_FILE\"; rmdir \"$INPUT_DIR\"' EXIT\n");
    out.push_str("trap 'exit 1' HUP INT TERM\n");
    out.push_str("if [ \"$HOOK_NAME\" = pre-push ] || [ \"$HOOK_NAME\" = reference-transaction ]; then cat > \"$INPUT_FILE\"; else : > \"$INPUT_FILE\"; fi\n");
    out.push_str("repo_root=\"$(git rev-parse --show-toplevel 2>/dev/null || true)\"\n");
    out.push_str("archive_hook=''\n");
    out.push_str("if [ -n \"$repo_root\" ]; then\n");
    out.push_str("  repo_base=\"$(basename \"$repo_root\")\"\n");
    out.push_str("  archive_hook=\"$ROOT/repo-githooks/$repo_base/$HOOK_NAME\"\n");
    out.push_str("fi\n");
    // One commit at a time per checkout: Git writes its one message file
    // after pre-commit and reads it back after commit-msg, so the lock is
    // taken here for the git process ($PPID) and released by that process's
    // ref transaction. The lock prints its own cause (the holder it names,
    // or why it could not be taken), so the dispatcher never claims another
    // commit is running when none was seen.
    out.push_str("if [ \"$HOOK_NAME\" = pre-commit ]; then\n");
    out.push_str("  tama hook commit-lock take \"$PPID\" || { echo \"tama: the commit lock of ${repo_root:-this repository} refused this commit for the cause printed above; no commit created\" >&2; false; }\n");
    out.push_str("fi\n");
    out.push_str("if [ \"$HOOK_NAME\" = pre-push ]; then\n");
    out.push_str("  tama hook review-push \"$@\" < \"$INPUT_FILE\" || { echo \"tama: the review refused this push of ${repo_root:-this repository}\" >&2; false; }\n");
    out.push_str("fi\n");
    out.push_str("if [ \"$HOOK_NAME\" = pre-push ]; then\n");
    out.push_str("  \"$ROOT/repo-githooks/rust/pre-push\" \"$@\" < \"$INPUT_FILE\" || { echo \"tama: Rust formatting refused this push; the formatter diagnostics above name the files and cause\" >&2; false; }\n");
    out.push_str("fi\n");
    // Whether a pushed commit declares quality gates is that commit's to say:
    // the check reads each pushed commit, never the working tree, which holds
    // other sessions' uncommitted work, so it is not chosen by a manifest
    // there either. It gets Git's pre-push records like every other gate.
    out.push_str("if [ \"$HOOK_NAME\" = pre-push ] && [ -n \"$repo_root\" ]; then\n");
    out.push_str(
        "  (cd \"$repo_root\" && tama hook quality-check \"$@\" < \"$INPUT_FILE\") || false\n",
    );
    out.push_str("fi\n");
    out.push_str("if [ \"$HOOK_NAME\" = reference-transaction ]; then\n");
    out.push_str("  tama hook review-ref-move \"$@\" \"$PPID\" < \"$INPUT_FILE\" || { echo \"tama: the review refused this move of a branch of ${repo_root:-this repository}\" >&2; false; }\n");
    out.push_str("fi\n");
    out.push_str("if [ \"$HOOK_NAME\" = reference-transaction ] && { [ \"${1:-}\" = committed ] || [ \"${1:-}\" = aborted ]; }; then\n");
    // The candidate review-commit admitted for this Git process becomes the
    // admission of the commit it moved its branch to. The process's commit
    // lock is let go whatever that answered, and a failed admission is said
    // after it.
    out.push_str("  admission_failed=''\n");
    out.push_str(
        "  tama hook commit-admission \"$1\" \"$PPID\" < \"$INPUT_FILE\" || admission_failed=yes\n",
    );
    out.push_str("  tama hook commit-lock release \"$PPID\" || { echo \"tama: the commit lock of ${repo_root:-this repository} was not released\" >&2; false; }\n");
    out.push_str("  [ -z \"$admission_failed\" ] || { echo \"tama: the admission of this commit of ${repo_root:-this repository} was not kept\" >&2; false; }\n");
    out.push_str("fi\n");
    out.push_str(&format!(
        "if [ -n \"$repo_root\" ] && [ -x \"{repo_hook}\" ]; then\n"
    ));
    out.push_str(&format!("  \"{repo_hook}\" \"$@\" < \"$INPUT_FILE\"\n"));
    out.push_str("elif [ -n \"$archive_hook\" ] && [ -x \"$archive_hook\" ]; then\n");
    out.push_str("  \"$archive_hook\" \"$@\" < \"$INPUT_FILE\"\n");
    out.push_str("fi\n");
    out.push_str("if [ -x \"$BACKUP\" ]; then\n");
    out.push_str("  \"$BACKUP\" \"$@\" < \"$INPUT_FILE\"\n");
    out.push_str("fi\n");
    // Review after chained hooks: a preserved commit-msg hook may edit the
    // message. Nothing is compiled here: the agent reads its own code.
    out.push_str("if [ \"$HOOK_NAME\" = commit-msg ]; then\n");
    out.push_str("  tama hook review-commit \"$@\" || { echo \"tama: commit message or staged change refused; no commit created\" >&2; false; }\n");
    out.push_str("fi\n");
    out.push_str("exit 0\n");
    out
}

/// JS `expandHome(value, home)`.
pub(super) fn expand_home(value: &str, home: &str) -> String {
    if value.is_empty() {
        return value.to_string();
    }
    if value == "~" {
        return home.to_string();
    }
    if let Some(rest) = value.strip_prefix("~/") {
        return join_path(home, rest);
    }
    value.to_string()
}

/// Node `path.join(base, part)` for the simple cases used here.
pub(super) fn join_path(base: &str, part: &str) -> String {
    format!("{}/{}", base.trim_end_matches('/'), part)
}

/// Node `path.resolve(value)`: make absolute against the CWD and normalize
/// `.`/`..`/duplicate slashes, without resolving symlinks.
pub(super) fn resolve_path(value: &str) -> Result<String> {
    let absolute = if value.starts_with('/') {
        value.to_string()
    } else {
        let cwd = std::env::current_dir()?;
        format!("{}/{}", cwd.to_string_lossy().trim_end_matches('/'), value)
    };
    let mut parts: Vec<&str> = Vec::new();
    for segment in absolute.split('/') {
        match segment {
            "" | "." => {}
            ".." => {
                parts.pop();
            }
            segment => parts.push(segment),
        }
    }
    Ok(format!("/{}", parts.join("/")))
}

#[cfg(unix)]
fn chmod_755(path: &str) -> std::io::Result<()> {
    use std::os::unix::fs::PermissionsExt;
    fs::set_permissions(path, fs::Permissions::from_mode(0o755)) // https://pubs.opengroup.org/onlinepubs/9799919799/utilities/chmod.html
}

#[cfg(not(unix))]
fn chmod_755(_path: &str) -> std::io::Result<()> {
    Ok(())
}

/// One installed dispatcher: `{ target, backup }`.
#[derive(Debug, Clone, Serialize)]
pub struct InstalledHook {
    pub target: String,
    pub backup: Option<String>,
}

/// JS `installOne(root, hooksPath, hookName)`: back up a pre-existing
/// non-managed hook, then write the managed dispatcher (mode 0755).
pub(super) fn install_one(root: &str, hooks_path: &str, hook_name: &str) -> Result<InstalledHook> {
    let target = join_path(hooks_path, hook_name);
    let backup = join_path(hooks_path, &format!("{hook_name}.before-tama"));
    if crate::presence::present(Path::new(&target))? {
        let bytes = fs::read(&target)?;
        let text = String::from_utf8_lossy(&bytes);
        let mut lines = text.split('\n');
        let is_managed = matches!(
            (lines.next(), lines.next()),
            (Some("#!/bin/sh"), Some(second)) if second == MANAGED_HEADER
        );
        let backed_up = crate::presence::present(Path::new(&backup))?;
        if !is_managed && backed_up && fs::read(&backup)? != bytes {
            return Err(err(format!(
                "Cannot preserve foreign hook {target}: {backup} already contains a different hook. Neither hook was overwritten."
            )));
        }
        if !is_managed && !backed_up {
            fs::copy(&target, &backup)?;
            chmod_755(&backup)?;
        }
    }
    fs::write(&target, dispatcher_body(root, hook_name, &backup))?;
    chmod_755(&target)?;
    Ok(InstalledHook {
        target,
        backup: if crate::presence::present(Path::new(&backup))? {
            Some(backup)
        } else {
            None
        },
    })
}

/// Where the bypass records that it is holding policy aside.
///
/// The path is the emergency controller's, and it is read rather than
/// inferred: a machine is bypassed only when this document says so.
fn emergency_state_path(home: &str) -> String {
    join_path(
        home,
        "Library/Application Support/Tama/hook-emergency-state.json",
    )
}

/// Whether the emergency state records a bypass. No state file records
/// none; a file that cannot be read, is not JSON or carries another schema
/// is an error naming it, since read as no bypass an install would write
/// over the entrypoint the bypass holds aside.
pub(super) fn bypass_is_recorded(home: &str) -> Result<bool> {
    let path = emergency_state_path(home);
    let body = match fs::read_to_string(&path) {
        Ok(body) => body,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(false),
        Err(error) => {
            return Err(err(format!(
                "the emergency state {path} cannot be read, so whether a bypass holds the hooks is unknown: {error}"
            )))
        }
    };
    let state = serde_json::from_str::<serde_json::Value>(&body).map_err(|error| {
        err(format!(
            "the emergency state {path} is not JSON, so whether a bypass holds the hooks is unknown: {error}"
        ))
    })?;
    if state.get("schema").and_then(serde_json::Value::as_str)
        != Some("ai.wisent.tama.hook-emergency-state.v1")
    {
        return Err(err(format!(
            "the emergency state {path} is not a Tama emergency state document"
        )));
    }
    Ok(state.get("disabled") == Some(&serde_json::Value::Bool(true)))
}

/// Refuse to write a dispatcher the bypass is holding aside.
///
/// The bypass moves an entrypoint to `<name>.tama-disabled` and records the
/// pair, and a re-enable restores it. Writing a fresh dispatcher at the same
/// path while both exist makes the machine unrestorable: the re-enable
/// refuses that state, correctly, and the only way out is deleting files by
/// hand. So the install refuses first, and says which file and what to do
/// about it.
pub(super) fn refuse_install_during_bypass(
    home: &str,
    hooks_path: &str,
    hook_name: &str,
) -> Result<()> {
    if !bypass_is_recorded(home)? {
        return Ok(());
    }
    let disabled = join_path(hooks_path, &format!("{hook_name}.tama-disabled"));
    if !crate::presence::present(Path::new(&disabled))? {
        return Ok(());
    }
    Err(err(format!(
        "Tama hooks are disabled and {disabled} is the entrypoint the bypass is holding. \
Installing {hook_name} here would leave both files in place, which a re-enable refuses. \
Re-enable policy first, then install."
    )))
}
