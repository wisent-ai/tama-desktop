//! Which waiting connection is a running judge request, by the connection
//! itself rather than by how many there are.
//!
//! A newer resolver records the loopback address each held client connected
//! from (`client`). The processes holding a socket on that port, and their
//! parents, are asked of `lsof`; the connection is a running hook's when one
//! of them is the client process a running hook recorded (`owner.rs`), or a
//! process that hook started: its readiness watch holds a question open on
//! the same adapter until Brama's answer changes (`watch.rs`). Counting
//! alone let a connection nobody watches through whenever a running hook had
//! a request of its own recorded that the resolver did not list, or no
//! longer listed. A resolver that records no client address leaves its
//! connections known only by count: each needs a running request no named
//! connection matched.

use std::process::{Command, Stdio};

use super::owner::Owner;
use super::PendingChannel;

/// The program that names the processes holding a socket; found on `PATH`,
/// as the refusal's own `lsof -nP -i :<port>` advice is.
const LISTER: &str = "lsof";

/// One process holding a socket, the process that started it, and the TCP
/// ports its sockets name at either end.
struct Holder {
    pid: u32,
    parent: Option<u32>,
    ports: Vec<String>,
}

/// A process id `lsof` printed in field `field`.
fn process_id(field: &str, value: &str, ports: &str) -> Result<u32, String> {
    value.trim().parse::<u32>().map_err(|error| {
        format!("{LISTER} named `{value}` as the {field} of a process holding loopback port(s) {ports}: {error}")
    })
}

/// The ports a socket name `<address>:<port>[-><address>:<port>]` carries.
fn socket_ports(name: &str) -> impl Iterator<Item = String> + '_ {
    name.split("->").filter_map(|end| {
        end.rsplit_once(':')
            .map(|(_, port)| port.trim().to_string())
    })
}

/// The processes holding a TCP socket on any of the loopback `ports`, read
/// from one `lsof` over all of them (`-iTCP:<port>,<port>,…`) in field
/// output: `p<pid>` opens a process, `R<ppid>` names its parent, `n<name>`
/// names one of its sockets; other fields are not read.
fn holders(ports: &[&str]) -> Result<Vec<Holder>, String> {
    let listed_ports = ports.join(",");
    let selector = format!("-iTCP:{listed_ports}");
    let output = stado_wait::output(
        Command::new(LISTER)
            .args(["-nP", "-FpRn", &selector])
            .stdin(Stdio::null()),
    )
    .map_err(|error| {
        format!("cannot ask {LISTER} which process holds loopback port(s) {listed_ports}: {error}")
    })?;
    let listed = String::from_utf8_lossy(&output.stdout);
    let said = String::from_utf8_lossy(&output.stderr);
    // lsof ends unsuccessfully, saying nothing, when no process holds the ports.
    if !output.status.success() && !(listed.trim().is_empty() && said.trim().is_empty()) {
        return Err(format!(
            "{LISTER} could not say which process holds loopback port(s) {listed_ports} ({}): {}",
            output.status,
            said.trim()
        ));
    }
    let mut found: Vec<Holder> = Vec::new();
    for line in listed.lines() {
        if let Some(pid) = line.strip_prefix('p') {
            found.push(Holder {
                pid: process_id("process id", pid, &listed_ports)?,
                parent: None,
                ports: Vec::new(),
            });
            continue;
        }
        let Some(holder) = found.last_mut() else {
            return Err(format!(
                "{LISTER} printed {line:?} before any process holding loopback port(s) {listed_ports}"
            ));
        };
        if let Some(parent) = line.strip_prefix('R') {
            holder.parent = Some(process_id("parent process id", parent, &listed_ports)?);
        } else if let Some(name) = line.strip_prefix('n') {
            holder.ports.extend(socket_ports(name));
        }
    }
    Ok(found)
}

/// Whether `holder` is `owner`'s judge client or a process its hook started.
fn owned_by(holder: &Holder, owner: &Owner) -> bool {
    holder.pid == owner.client_pid || holder.parent == Some(owner.hook_pid)
}

/// The waiting connections among `pending` that no running hook's request
/// among `owners` is. Every named connection's holders come from one `lsof`.
pub(super) fn unwatched<'a>(
    pending: &[&'a PendingChannel],
    owners: &[Owner],
) -> Result<Vec<&'a PendingChannel>, String> {
    let ports: Vec<&str> = pending
        .iter()
        .filter_map(|wait| wait.client_port().map(|(_, port)| port))
        .collect();
    let holding = if ports.is_empty() {
        Vec::new()
    } else {
        holders(&ports)?
    };
    let mut matched = vec![false; owners.len()];
    let mut unwatched = Vec::new();
    let mut unnamed = Vec::new();
    for wait in pending {
        let Some((_, port)) = wait.client_port() else {
            unnamed.push(*wait);
            continue;
        };
        match owners.iter().position(|owner| {
            holding.iter().any(|holder| {
                holder.ports.iter().any(|held| held == port) && owned_by(holder, owner)
            })
        }) {
            Some(index) => matched[index] = true,
            None => unwatched.push(*wait),
        }
    }
    let free = matched.iter().filter(|taken| !**taken).count();
    if unnamed.len() > free {
        unwatched.extend(unnamed);
    }
    Ok(unwatched)
}
