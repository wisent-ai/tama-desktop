//! YAML command vectors are sequences in a command declaration, not vocabularies.
//! The syntax tree retains byte ranges and recognizes complete mapping subtrees
//! inside an edit fragment. An incomplete or ambiguous declaration stays judged.

use std::borrow::Cow;
use std::ops::Range;

use tree_sitter::{Node, Parser};

/// Hide only proven command sequences, preserving newlines and every other list.
/// `argv` includes the executable; `args` requires a string-valued sibling `program`;
/// every step of `after_install` is one argv.
pub(super) fn without_commands(text: &str) -> Cow<'_, str> {
    let mut parser = Parser::new();
    parser
        .set_language(&tree_sitter_yaml::LANGUAGE.into())
        .expect("the compiled YAML grammar matches tree-sitter");
    let tree = parser
        .parse(text, None)
        .expect("YAML parsing was not cancelled");
    let mut ranges = Vec::new();
    commands(tree.root_node(), text, &mut ranges);
    if ranges.is_empty() {
        return Cow::Borrowed(text);
    }
    ranges.sort_by_key(|range| range.start);
    let mut judged = text.to_owned();
    for range in ranges.into_iter().rev() {
        let blank = super::blank(&text[range.clone()]);
        judged.replace_range(range, &blank);
    }
    Cow::Owned(judged)
}

fn commands(node: Node<'_>, text: &str, out: &mut Vec<Range<usize>>) {
    if matches!(node.kind(), "block_mapping" | "flow_mapping") && !node.has_error() {
        let mut cursor = node.walk();
        let has_program = node.named_children(&mut cursor).any(|pair| {
            field(pair, "key", text) == Some("program")
                && field(pair, "value", text).is_some_and(|value| !value.is_empty())
        });
        let mut cursor = node.walk();
        for pair in node.named_children(&mut cursor) {
            let Some(value) = pair.child_by_field_name("value").and_then(sequence) else {
                continue;
            };
            let vectors = match field(pair, "key", text) {
                Some(super::COMMAND_FIELD) => vec![value],
                Some("args") if has_program => vec![value],
                Some(STEPS_FIELD) => steps(value),
                _ => Vec::new(),
            };
            for vector in vectors {
                let mut cursor = vector.walk();
                if vector
                    .named_children(&mut cursor)
                    .all(|item| item.kind() == "comment" || string(item, text).is_some())
                {
                    out.push(vector.byte_range());
                }
            }
        }
    }
    let mut cursor = node.walk();
    for child in node.named_children(&mut cursor) {
        commands(child, text, out);
    }
}

/// Stado's catalog recipe field whose value lists the commands run after an
/// install; Stado refuses any step that is not an array of strings
/// (stado-rs/product/src/catalog/validation.rs, `after_install commands must
/// be argv arrays`), so each step is a command vector, never a vocabulary.
const STEPS_FIELD: &str = "after_install";

/// Each step of an `after_install` sequence, when every step is itself a
/// sequence; a step of any other shape leaves the whole list judged.
fn steps(list: Node<'_>) -> Vec<Node<'_>> {
    let mut cursor = list.walk();
    let items: Vec<Node<'_>> = list
        .named_children(&mut cursor)
        .filter(|item| item.kind() != "comment")
        .collect();
    let vectors: Vec<Node<'_>> = items
        .iter()
        .filter_map(|item| match item.kind() {
            "block_sequence_item" => sequence(only_child(*item)?),
            _ => sequence(*item),
        })
        .collect();
    if vectors.len() == items.len() {
        vectors
    } else {
        Vec::new()
    }
}

fn field<'a>(pair: Node<'_>, name: &str, text: &'a str) -> Option<&'a str> {
    string(pair.child_by_field_name(name)?, text)
}

fn only_child(node: Node<'_>) -> Option<Node<'_>> {
    let mut cursor = node.walk();
    let mut children = node
        .named_children(&mut cursor)
        .filter(|child| child.kind() != "comment");
    let child = children.next()?;
    children.next().is_none().then_some(child)
}

fn sequence(node: Node<'_>) -> Option<Node<'_>> {
    match node.kind() {
        "block_sequence" | "flow_sequence" => Some(node),
        "block_node" | "flow_node" => sequence(only_child(node)?),
        _ => None,
    }
}

fn string<'a>(node: Node<'_>, text: &'a str) -> Option<&'a str> {
    if node.has_error() {
        return None;
    }
    match node.kind() {
        "string_scalar" => Some(text[node.byte_range()].trim()),
        "single_quote_scalar" => text[node.byte_range()]
            .strip_prefix('\'')?
            .strip_suffix('\''),
        "double_quote_scalar" => text[node.byte_range()].strip_prefix('"')?.strip_suffix('"'),
        "flow_node" | "block_node" | "plain_scalar" | "block_sequence_item" => {
            string(only_child(node)?, text)
        }
        _ => None,
    }
}
