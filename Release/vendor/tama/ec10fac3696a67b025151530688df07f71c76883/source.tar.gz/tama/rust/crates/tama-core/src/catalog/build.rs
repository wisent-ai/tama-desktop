//! JS `buildCatalog(root)` and `findHook(id, root)`: the catalogue a reader
//! sees, one record per hook.
//!
//! Moved verbatim out of the single catalogue file during a split by
//! responsibility.

use serde::Serialize;
use std::collections::{HashMap, HashSet};
use std::path::Path;

use crate::registry::{JustificationRequirement, OrderedMap};
use crate::Result;

use super::fs_scan::extname;
use super::key_order::top_level_object_key_order;
use super::{
    command_source_path, list_repo_git_hooks, list_source_files, load_catalog_metadata,
    load_registry_raw, RepoGitHook,
};

/// Per-event entry of a catalog hook: `{ event, blocking, statusMessage }`.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CatalogHookEvent {
    pub event: String,
    pub blocking: bool,
    pub status_message: Option<String>,
}

/// One hook entry of the built catalog (JS object shape preserved).
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CatalogHook {
    pub id: String,
    #[serde(rename = "type")]
    pub hook_type: String,
    pub command: String,
    pub source_path: Option<String>,
    pub category: Option<String>,
    pub status: Option<String>,
    pub description: Option<String>,
    pub why: Option<String>,
    pub side_effects: Option<String>,
    pub events: Vec<CatalogHookEvent>,
    pub justification_requirements: Vec<JustificationRequirement>,
}

/// Result of JS `buildCatalog(root)`.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Catalog {
    /// The registry's declared version; absent from a registry that declares
    /// none, never a number nobody stated.
    pub version: Option<u64>,
    pub generated_at: Option<String>,
    pub hooks: Vec<CatalogHook>,
    pub orphan_sources: Vec<String>,
    /// Adapters in `registry.json` insertion order (not alphabetical).
    pub adapters: OrderedMap<crate::registry::Adapter>,
    pub repo_git_hooks: Vec<RepoGitHook>,
}

/// The keys of `section` in the order `registry.json`'s own text lists them,
/// then any key the parsed registry holds that the text scan missed. A
/// registry with no file has no text and no keys; text whose order cannot be
/// read refuses the catalogue.
fn ordered_keys<'a>(
    raw: Option<&str>,
    section: &str,
    parsed: impl Iterator<Item = &'a String>,
) -> Result<Vec<String>> {
    let mut order = match raw {
        Some(text) => top_level_object_key_order(text, section)?,
        None => Vec::new(),
    };
    for key in parsed {
        if !order.iter().any(|listed| listed == key) {
            order.push(key.clone());
        }
    }
    Ok(order)
}

/// JS `buildCatalog(root)`. Field-level merge priorities:
/// `type`: docs.type, then hook.type; `category`/`status`/`why`/`sideEffects`:
/// hook.*, then docs.*, then the hook's `catalog.agentHooks` entry;
/// `description`: hook.description, hook.does, docs.description, then the
/// `catalog.agentHooks` entry; `justificationRequirements`: docs.*, then
/// hook.*. A hook entry that declares no type or no command, and an event
/// that does not say whether it blocks, refuse the catalogue naming them.
pub fn build_catalog(root: &Path) -> Result<Catalog> {
    let (registry, raw) = load_registry_raw(root)?;
    let event_order = ordered_keys(raw.as_deref(), "events", registry.events.keys())?;
    let adapter_order = ordered_keys(raw.as_deref(), "adapters", registry.adapters.keys())?;
    let metadata = load_catalog_metadata(root)?;

    let mut by_id: HashMap<String, CatalogHook> = HashMap::new();
    for event in &event_order {
        let config = &registry.events[event];
        let blocking = config.blocking.ok_or_else(|| {
            format!("registry.json event {event} does not say whether it blocks (no `blocking`)")
        })?;
        for hook in &config.hooks {
            // JS: `hook.source ? commandSourcePath(hook.source) : commandSourcePath(hook.command)`
            let source_path = match hook.source.as_deref() {
                Some(source) if !source.is_empty() => command_source_path(Some(source), root)?,
                _ => command_source_path(hook.command.as_deref(), root)?,
            };
            let docs = metadata.get(&hook.id);
            if !by_id.contains_key(&hook.id) {
                let hook_type = docs
                    .and_then(|docs| docs.hook_type.clone())
                    .or_else(|| hook.hook_type.clone())
                    .ok_or_else(|| {
                        format!(
                            "hook {} declares no type in registry.json event {event} or catalog-metadata.json",
                            hook.id
                        )
                    })?;
                let command = hook.command.clone().ok_or_else(|| {
                    format!(
                        "hook {} declares no command in registry.json event {event}",
                        hook.id
                    )
                })?;
                let justification_requirements =
                    match docs.and_then(|docs| docs.justification_requirements.clone()) {
                        Some(requirements) => requirements,
                        None => hook.justification_requirements.clone(),
                    };
                by_id.insert(
                    hook.id.clone(),
                    CatalogHook {
                        id: hook.id.clone(),
                        hook_type,
                        command,
                        source_path: source_path.clone(),
                        category: hook
                            .category
                            .clone()
                            .or_else(|| docs.and_then(|docs| docs.category.clone())),
                        status: hook
                            .status
                            .clone()
                            .or_else(|| docs.and_then(|docs| docs.status.clone())),
                        description: hook
                            .description
                            .clone()
                            .or_else(|| hook.does.clone())
                            .or_else(|| docs.and_then(|docs| docs.description.clone())),
                        why: hook
                            .why
                            .clone()
                            .or_else(|| docs.and_then(|docs| docs.why.clone())),
                        side_effects: hook
                            .side_effects
                            .clone()
                            .or_else(|| docs.and_then(|docs| docs.side_effects.clone())),
                        events: Vec::new(),
                        justification_requirements,
                    },
                );
            }
            let entry = by_id.get_mut(&hook.id).ok_or_else(|| {
                format!("hook {} was not kept in the catalogue being built", hook.id)
            })?;
            entry.events.push(CatalogHookEvent {
                event: event.clone(),
                blocking,
                status_message: hook.status_message.clone(),
            });
            if entry.source_path.is_none() && source_path.is_some() {
                entry.source_path = source_path;
            }
        }
    }
    // `catalog.agentHooks` is the human-authored list registration writes: the
    // only place a ported hook names its source, and where a hook declared
    // after `catalog-metadata.json` stopped being written carries its
    // category, status, description, why and side effects. Every native
    // hook's event entry carries `source: null` and a `tama hook <id>` command
    // that maps to no file, so its source comes from here; a field neither the
    // event entry nor the catalogue metadata states comes from here too, so a
    // declared hook never enters the catalogue with its metadata null.
    let agent_hooks = match registry
        .extra
        .get("catalog")
        .and_then(|catalog| catalog.get("agentHooks"))
    {
        Some(listed) => listed
            .as_array()
            .ok_or("registry.json catalog.agentHooks is not a list")?
            .as_slice(),
        None => &[],
    };
    for hook in agent_hooks {
        let Some(id) = hook.get("id").and_then(serde_json::Value::as_str) else {
            continue;
        };
        let Some(entry) = by_id.get_mut(id) else {
            continue;
        };
        let declared = |field: &str| {
            hook.get(field)
                .and_then(serde_json::Value::as_str)
                .map(str::to_string)
        };
        for (slot, field) in [
            (&mut entry.category, "category"),
            (&mut entry.status, "status"),
            (&mut entry.description, "description"),
            (&mut entry.why, "why"),
            (&mut entry.side_effects, "sideEffects"),
        ] {
            if slot.is_none() {
                *slot = declared(field);
            }
        }
        if entry.source_path.is_some() {
            continue;
        }
        entry.source_path = match command_source_path(declared("source").as_deref(), root)? {
            Some(path) => Some(path),
            None => command_source_path(declared("command").as_deref(), root)?,
        };
    }
    let mut hooks: Vec<CatalogHook> = by_id.into_values().collect();
    hooks.sort_by(|a, b| a.id.cmp(&b.id));
    let registered_sources: HashSet<&str> = hooks
        .iter()
        .filter_map(|h| h.source_path.as_deref())
        .filter(|s| !s.is_empty())
        .collect();
    let orphan_sources: Vec<String> = list_source_files(root)?
        .into_iter()
        .filter(|p| [".py", ".sh", ".mjs", ".js"].contains(&extname(p)))
        .filter(|p| !registered_sources.contains(p.as_str()))
        .collect();
    let mut adapters = OrderedMap::new();
    for name in &adapter_order {
        if let Some(adapter) = registry.adapters.get(name) {
            adapters.push(name.clone(), adapter.clone());
        }
    }
    Ok(Catalog {
        version: registry.version,
        generated_at: registry.generated_at.clone(),
        hooks,
        orphan_sources,
        adapters,
        repo_git_hooks: list_repo_git_hooks(root)?,
    })
}

/// JS `findHook(id, root)`.
pub fn find_hook(id: &str, root: &Path) -> Result<Option<CatalogHook>> {
    Ok(build_catalog(root)?
        .hooks
        .into_iter()
        .find(|hook| hook.id == id))
}
