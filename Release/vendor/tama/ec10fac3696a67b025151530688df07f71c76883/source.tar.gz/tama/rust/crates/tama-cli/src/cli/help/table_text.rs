//! The usage-summary lines of the commands whose description runs long,
//! kept beside [`super::table`] so the table stays one screen per command.

pub(super) const TESTS: &str = "  tests <approve|revoke|list|restore|audit|review> [...]
                             The operator's approvals of test code: approve PATH… records one in
                             ~/.config/agent-policy/approved_tests.json; block-unapproved-tests
                             refuses every other test write and refuses approve or restore run from a session.
                             restore writes the record again from the attestation ledger after something else removed it.
                             audit [<root>…] [--remove] [--json] inventories approved and unapproved test paths in a repository or product-marked children.
                             review <root> asks the reviewer which unread tracked test files of a repository are smoke tests and keeps the verdicts the hook decides writes by.";

pub(super) const COMMANDS_JUDGE: &str = "  commands judge <request>   Ask the judge about the commands a write declared and block-one-off-commands
                             refused as not yet read; owns the foreground review and refuses a request
                             already owned by another review; keeps and prints `<name>: PASS|BLOCK: <why>`;
                             exit 0 when every command passed, 1 otherwise.";

pub(super) const JUDGEMENT_ASK: &str =
    "  judgement ask <request>    Ask the model outside its hook; keep its exact answer.
  judgement show <request>   Read the exact question, every recorded failed attempt and the caller's
                             local alternative, including storage and attribution errors.
  judgement attest <request> --choice CHOICE --reason TEXT
                             Record an explicit local attestation for this question and calling
                             session, not a model review; choose only a declared option and state
                             what was checked. No Brama, Oko or model-provider change is needed.
  judgement revoke <request> Withdraw the local alternative, not the sealed model answer.
                             Prints JSON; exit 0 completed, 1 refused, 2 invalid invocation.";

pub(super) const CALLS: &str = "  calls failed --session ID  The session's calls that failed or a gate refused, kept by call identity;
                             the same call repeated unchanged is refused until a file changes, the hook
                             catalog changes, Oko binds its functionality, or a retry says why.
  calls retry <call> --session ID --because TEXT
                             Keep why a repeat of the failed call differs; it runs once more.
                             Prints JSON; exit 0 completed, 1 refused, 2 invalid invocation.";

pub(super) const ASSIGNMENT: &str = "  assignment show --session ID [--json]
                             The session's open tasks as Oko reads them; block-stale-assignment
                             requires this reading before a stop.";

pub(super) const ATTESTATION: &str = "  attestation standard (--commit | --turn | --session ID) [--json]
  attestation check (--commit REV [--repository PATH] | --turn HOOK --file PATH) [--json]
                             The attestation read word for word, with no model: a commit carries the
                             commit standard's claims in its message and review-push refuses a pushed
                             commit that lacks one, naming each missing claim; an answer that ends a
                             turn carries the claims each stop hook declares. standard --commit prints
                             the block to paste into a commit message; check names what is missing.
  attestation attest --commit REV --file PATH [--repository PATH] [--json]
                             Keep FILE as the attestation of an existing commit, in
                             refs/notes/attestation, when it carries every claim, replacing a note
                             kept before; the commit is unchanged.
  attestation pending [--repository PATH] [--json]
                             Every commit the branch carries over its upstream, oldest first: whether
                             each attestation stands, what it lacks, and which commits of the range it patches.
  attestation <record|show|list|remove> [--file PATH] [--session ID] [--json]
                             A session's attestation that its task is finished: record judges FILE
                             (every claim confirmed and explained, next steps and the harsh review's
                             findings empty) and keeps it only when it stands; show, list and remove
                             read or delete kept records.
  attestation <verify|revoke|migrate> [--kind KIND] [--subject SUBJECT] [--json]
                             Every attestation every registry holds as one ledger: verify re-reads what
                             each names, revoke withdraws one, migrate brings the registries into the ledger.";

pub(super) const PROVIDER: &str =
    "  provider config --provider <id> --dispatcher <command> [--json]
                             Print the hook block an install writes into that provider's config";

pub(super) const REQUEST: &str = "  request <operation> [--root <release>]
                             Answer one Tama Desktop request: JSON body on stdin, NDJSON events on stdout";

pub(super) const DOCTOR: &str = "  doctor [--json]            Diagnose model discovery, credentials and catalogue access; not a judge verdict
                             Reports the actual discovery, credential or HTTP failure of the configured
                             model catalogue; catalogue acceptance is not a judge verdict.";

pub(super) const ADAPTIVE: &str =
    "  adaptive <command> [...]   Adaptive layer doctor: status|drift|queue|repair|apply";

pub(super) const WORKTREES: &str =
    "  worktrees <command> [...]  Linked git worktrees under a tree: list|remove";

pub(super) const COPIES: &str =
    "  copies <command> [...]     Second full checkouts under a tree: list|remove";

pub(super) const CONTRIBUTIONS: &str =
    "  contributions pending|report --repository PATH --ref REF [--since REV] [--ledger URL] [--json]
                             The commits that reached a remote branch with a standing attestation, as
                             code.accepted contributions of their git authors to Wisent's contribution
                             ledger; pending lists them (held or not, with a ledger named), report sends
                             the ones the ledger does not hold yet, the commit id as event id";

pub(super) const REVIEWS: &str =
    "  reviews list|show [...]     Inspect retained commit-review outcomes and exact failures
  reviews harsh record|dispose|show [...]
                             Record a harsh review round by a reviewer that is not the author, record a
                             finding as an Oko defect, or show the rounds and the verdict review-commit gives
  reviews admitted --commit <rev> [--repository <path>] [--json]
                             Name the session that made a commit and the rounds review-commit admitted it on";

pub(super) const STAGE: &str = "  stage --session <id> [--path <file>]... [...]  Stage only successful recorded session edits, of the named files when --path is given; --inspect reads the candidate";

pub(super) const INDEX: &str = "  index repair [--repo <path>] [--apply] [--json]
                             Name each index entry whose object the store lacks; --apply copies it from
                             a checkout holding it, else restages the working file and names the loss";

pub(super) const FORMAT: &str =
    "  format fold [--repository <path>] [--through <commit>] [--reword <commit> --message <file>]... [--json]
                             Fold the formatters' form into unpublished commits; --through formats
                             only the inclusive prefix and carries later source without qualifying it;
                             --reword writes a named commit with the message the file holds";

pub(super) const HISTORY: &str =
    "  history rebase [--repository <path>] [--prefer upstream] [--json]
                             Write the unpublished commits again on the upstream's current tip,
                             each merged by Git, notes and rewrite records kept; a place Git cannot
                             merge refuses, or keeps the upstream's side with --prefer upstream";
