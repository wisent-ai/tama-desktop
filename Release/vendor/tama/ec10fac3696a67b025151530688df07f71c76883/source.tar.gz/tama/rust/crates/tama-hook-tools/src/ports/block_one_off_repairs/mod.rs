//! Decision half of `tama-block-one-off-repairs` (registry hook
//! `block-one-off-repairs`).
//!
//! Oko's one-off repair detector reads the harness files for commands that
//! change live machine state by hand instead of through a product path: a
//! service cycled, a grant written into a vault past Stado, a row, a key or a
//! setting changed, a built binary copied over an installed one, a hook's
//! own file touched, time passed instead of an outcome read, a tree searched
//! once, an older version put back. Each refusal names the product command,
//! because a gate that refuses a method without naming the outcome's route
//! is worked around (`~/agents/finishing.md`).
//!
//! Two readings decide. What the command's structure states is read here:
//! an install whose failure the register already describes
//! (`interrupted`, `refusals::installer`), a compile Oko's one admission
//! decision does not admit (the toolchains' own subcommands, `vocabulary`;
//! `oko admit build --session` and the operator's consents in `consent`, the
//! build penalty in `admission`), and a Python run. What a command does by
//! hand otherwise is read by a model against the operator's rule and each
//! outcome's route (`judged`), because which verb of which launcher, client
//! or store does it is not a list anybody can finish. A question the judge
//! leaves unanswered refuses with its cause; the compile gate never depends on one.
//!
//! The command is read the way a shell reads it: cut at separators outside
//! quotes, quoted text blanked, wrappers stepped over
//! ([`crate::ports::shell_text`]).

mod admission;
mod consent;
mod interrupted;
mod judged;
mod refusals;
mod vocabulary;

pub use consent::BUILD_TOOL;

use std::path::PathBuf;

use serde_json::Value;

use crate::ports::python_stdlib::shell_tokens;
use crate::ports::shell_text;
use crate::ports::tool_vocabulary::Call;

use refusals::*;
use vocabulary::{program_and_args, BANNER};

const SESSION_KEY: &str = "session_id";

/// Why this payload is a one-off repair, if it is one.
pub fn evaluate(payload: &Value) -> Option<String> {
    let call = Call::of(payload);
    let command = call.command()?;
    if command.trim().is_empty() {
        return None;
    }
    // A payload that names no session reads the build history and the
    // recorded open work of none, and the build hold says so by name.
    let session = match payload.get(SESSION_KEY).and_then(Value::as_str) {
        Some(session) => session.to_string(),
        None => String::new(),
    };
    // Where the command runs: a package manager's script is read from the
    // `package.json` there.
    let declared = call.cwd().map(PathBuf::from);
    let cwd = match declared {
        Some(cwd) => cwd,
        None => match std::env::current_dir() {
            Ok(cwd) => cwd,
            Err(error) => {
                return Some(format!(
                    "{BANNER}the payload names no working directory and this process cannot \
                     read its own ({error}), so whether `{}` compiles cannot be read",
                    command.trim()
                ))
            }
        },
    };
    let acting = shell_text::effective_payload(payload, command);
    // Whether a compile on this line passed every gate: its build attestation
    // is then spent once, however many compiles the line runs.
    let admitted_build = std::cell::Cell::new(false);
    let refused = shell_text::commands(&acting)
        .into_iter()
        .map(shell_tokens)
        .find_map(|tokens| {
            let (program, args) = program_and_args(&tokens)?;
            interrupted::interrupted_install_refusal(program, args)
                // Before any admission, consented or not: an install whose
                // failure the register already describes spends the build.
                .or_else(|| {
                    installer_refusal(program, args, crate::assignment::open_defects::listed_open)
                })
                // The penalty of a model that wasted builds applies before
                // any consent or readiness admits the next one.
                .or_else(|| {
                    // `npm run <script>` whose script only runs a repository
                    // file compiles nothing, so no build gate applies to it.
                    if admission::runs_no_compile(program, args, &cwd) {
                        return None;
                    }
                    compile_named(program, args)
                        .and_then(|name| admission::penalty_refusal(payload, &session, &name, args))
                })
                .or_else(|| {
                    // Whether a compile may run is Oko's one admission
                    // decision (`oko admit build --session`): the operator's
                    // standing rulings, and where none decides, his rule
                    // that a session's build waits until every open item
                    // carries its pushed repair, with the items a build
                    // itself unblocks excepted. No answer to a build
                    // question and no session capability admits one: no
                    // build is asked of him. Asked only of a compile: the
                    // build attestation is spent on the call that used it,
                    // and a line that builds nothing must not say so.
                    if admission::runs_no_compile(program, args, &cwd) {
                        return None;
                    }
                    let name = compile_named(program, args)?;
                    // The session's own build attestation comes first: no
                    // consent admits a build its agent did not attest.
                    if let Some(unattested) = consent::attested::refusal(&name, &session) {
                        return Some(unattested);
                    }
                    match consent::build_consented(program, args, &cwd, &session) {
                        Err(refused) => Some(compile_refusal(program, args, &refused)),
                        Ok(_) => {
                            admitted_build.set(true);
                            None
                        }
                    }
                })
                .or_else(|| python_run_refusal(program, args))
                // A declared session-recovery path is refused even with no
                // model declared. A defect reference is not permission for
                // a manual recovery; a process ended by hand is the model's.
                .or_else(|| {
                    recovery_path(program, args).map(|path| recovery_refusal(&path, command))
                })
        })
        .or_else(|| judged::judged_refusal(command));
    match (refused, admitted_build.get()) {
        (None, true) => consent::attested::spend(&session).err(),
        (refused, _) => refused,
    }
}

/// What a shell line compiles or runs as a suite, if it does, for a reader
/// that holds commands another program will run — a CI workflow's steps —
/// rather than a command this shell runs: the compiles the gate knows,
/// `cargo install` among them, named.
pub fn build_in(command: &str) -> Option<String> {
    let acting = shell_text::effective_command(command);
    shell_text::commands(&acting)
        .into_iter()
        .map(shell_tokens)
        .find_map(|tokens| {
            let (program, args) = program_and_args(&tokens)?;
            compile_named(program, args).map(|name| format!("`{name}` builds, compiles or tests"))
        })
}
