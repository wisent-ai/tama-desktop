//! Decision half of `tama hook block-credential-copies` (registry hook
//! `block-credential-copies`).
//!
//! A harness's credential store holds OAuth refresh tokens, and a refresh
//! token is spent when it is used. A process that refreshes an account from
//! a copy of the store voids the token the original holds: a test that ran a
//! harness on a copied store signed the operator out of every account the
//! copy carried, on every run. A store is shared by linking it or reading it
//! in place, never copied.
//!
//! The gate reads the source files a write leaves, tests included, and the
//! shell commands a session runs. It refuses a statement that copies a
//! declared store (`stores.json`): one naming both a store and a copy
//! construct, or a copy of a name an earlier statement bound to a store. A
//! statement runs to its `;` or to the end of a line that no `.`/`?` chain
//! continues, with parentheses and brackets kept together. A write whose
//! resulting file cannot be rebuilt is refused with the cause.

use std::sync::LazyLock;

use regex::Regex;
use serde::Deserialize;
use serde_json::Value;

use crate::ports::check_numeric_literals_payload::path_texts;
use crate::ports::tool_vocabulary::Call;

const TAG: &str = "block-credential-copies";

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Named {
    pattern: String,
    name: String,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Declared {
    #[allow(dead_code)]
    why: String,
    sources: Vec<String>,
    stores: Vec<Named>,
    copies: Vec<Named>,
}

struct Compiled {
    sources: Vec<String>,
    stores: Vec<(Regex, String)>,
    copies: Vec<(Regex, String)>,
}

fn compiled(named: Vec<Named>) -> Vec<(Regex, String)> {
    named
        .into_iter()
        .map(|entry| {
            (
                Regex::new(&entry.pattern).expect("every stores.json pattern compiles"),
                entry.name,
            )
        })
        .collect()
}

static DECLARED: LazyLock<Compiled> = LazyLock::new(|| {
    let declared: Declared = serde_json::from_str(include_str!("stores.json"))
        .expect("block_credential_copies/stores.json is the gate's own data and must parse");
    Compiled {
        sources: declared.sources,
        stores: compiled(declared.stores),
        copies: compiled(declared.copies),
    }
});

/// A name a statement binds: `let`, `let mut`, `const`, `var` or a bare
/// assignment (a shell variable included).
static BINDING: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r"^\s*(?:let\s+(?:mut\s+)?|const\s+|var\s+|export\s+)?(?P<name>[A-Za-z_][A-Za-z0-9_]*)\s*(?::[^=]*)?=[^=]")
        .expect("the binding pattern compiles")
});

/// The statements of `text`: each runs to its `;` or to the end of a line no
/// `.`/`?` chain continues, parentheses and brackets kept together.
fn statements(text: &str) -> Vec<String> {
    let mut joined = String::with_capacity(text.len());
    let mut rest = text.lines();
    while let Some(line) = rest.next() {
        joined.push_str(line);
        let next = rest.clone().find(|later| !later.trim().is_empty());
        let chained = next.is_some_and(|later| {
            let start = later.trim_start();
            start.starts_with('.') || start.starts_with('?')
        });
        joined.push(if chained { ' ' } else { '\n' });
    }
    let mut found = Vec::new();
    let mut current = String::new();
    let mut open: Vec<char> = Vec::new();
    for character in joined.chars() {
        match character {
            '(' | '[' => open.push(character),
            ')' | ']' => {
                open.pop();
            }
            ';' | '\n' if open.is_empty() => {
                if !current.trim().is_empty() {
                    found.push(current.trim().to_string());
                }
                current.clear();
                continue;
            }
            _ => {}
        }
        current.push(character);
    }
    if !current.trim().is_empty() {
        found.push(current.trim().to_string());
    }
    found
}

/// Every copy of a store `text` makes: (store, copy, statement).
pub fn findings(text: &str) -> Vec<(String, String, String)> {
    let mut bound: Vec<(String, String)> = Vec::new();
    let mut found = Vec::new();
    for statement in statements(text) {
        let store = DECLARED
            .stores
            .iter()
            .find(|(pattern, _)| pattern.is_match(&statement))
            .map(|(_, name)| name.clone());
        let through = bound.iter().find(|(name, _)| {
            Regex::new(&format!(r"\b{}\b", regex::escape(name)))
                .is_ok_and(|word| word.is_match(&statement))
        });
        let copied = store
            .clone()
            .or_else(|| through.map(|(_, store)| store.clone()));
        if let (Some(store), Some((_, copy))) = (
            copied,
            DECLARED
                .copies
                .iter()
                .find(|(pattern, _)| pattern.is_match(&statement)),
        ) {
            found.push((store, copy.clone(), statement.clone()));
        }
        if let (Some(store), Some(binding)) = (store, BINDING.captures(&statement)) {
            bound.push((binding["name"].to_string(), store));
        }
    }
    found
}

/// Whether the file at `path` is source the gate reads.
fn is_source(path: &str) -> bool {
    std::path::Path::new(path)
        .extension()
        .and_then(|extension| extension.to_str())
        .is_some_and(|extension| DECLARED.sources.iter().any(|source| source == extension))
}

/// Why this call is refused, if it is: a shell command or a file a write
/// leaves copies a credential store, or the file cannot be rebuilt to judge.
pub fn evaluate(payload: &Value) -> Option<String> {
    let call = Call::of(payload);
    let mut lines = Vec::new();
    if call.is_shell() {
        if let Some(command) = call.command() {
            for (store, copy, statement) in findings(command) {
                lines.push(format!(
                    "  the shell command: {copy} of {store}: {statement}"
                ));
            }
        }
    } else {
        let input = call.input()?;
        let texts = match path_texts(input, call.session_cwd()) {
            Ok(texts) => texts,
            Err(error) => {
                return Some(format!(
                    "{TAG}: BLOCKED: the file this write leaves cannot be rebuilt to judge it: \
                     {error}"
                ))
            }
        };
        for (path, text) in texts.iter().filter(|(path, _)| is_source(path)) {
            for (store, copy, statement) in findings(text) {
                lines.push(format!("  {path}: {copy} of {store}: {statement}"));
            }
        }
    }
    if lines.is_empty() {
        return None;
    }
    Some(format!(
        "{TAG}: BLOCKED: this copies a credential store, whose OAuth refresh tokens a process using the copy \
         spends, voiding the ones the original holds and signing its accounts out:\n{}\nLink the store \
         (`ln -s`, `std::os::unix::fs::symlink`) so every process refreshes the one store, or read what you \
         need from it in place, read-only. The stores and copies are declared in \
         block_credential_copies/stores.json.",
        lines.join("\n")
    ))
}
