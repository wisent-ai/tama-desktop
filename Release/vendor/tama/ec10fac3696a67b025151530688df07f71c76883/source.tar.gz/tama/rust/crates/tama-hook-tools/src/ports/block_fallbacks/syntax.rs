//! The fallback constructs of each language, recognised in the file's own
//! syntax tree.
//!
//! `constructs.json` names, per file extension, the tree-sitter grammar that
//! parses it, the family of constructs its language shares and the language's
//! name; each construct is a tree-sitter query whose `@fallback` capture is
//! the construct. A query matches syntax, never text: a construct named in a
//! string or a comment is not one, and one written over several lines is.
//! A construct may also declare an `except` query over the same grammar: a
//! node it captures as `@fallback` is the same syntax standing where the
//! language makes it something else (Rust's `.ok()` as the condition of an
//! `if` is a `bool` predicate of the receiver's own type, never
//! `Result::ok`), so it is not a finding.

use std::collections::{BTreeMap, BTreeSet};
use std::sync::LazyLock;

use serde::Deserialize;
use tree_sitter::{Language, Parser, Query, QueryCursor, StreamingIterator};

/// The capture every construct's query names its construct with.
const CAPTURE: &str = "fallback";

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Construct {
    name: String,
    query: String,
    except: Option<String>,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Extension {
    grammar: String,
    family: String,
    language: String,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Declared {
    #[allow(dead_code)]
    why: String,
    rule: String,
    extensions: BTreeMap<String, Extension>,
    families: BTreeMap<String, Vec<Construct>>,
}

/// One construct compiled for one grammar, and the name a finding gives it.
struct Compiled {
    label: String,
    query: Query,
    capture: u32,
    except: Option<(Query, u32)>,
}

/// The grammar of one file extension and its constructs compiled for it.
struct Reader {
    grammar: Language,
    constructs: Vec<Compiled>,
}

/// The operator's rule and every extension's reader, or why the declaration
/// cannot be read.
struct Readers {
    rule: String,
    by_extension: BTreeMap<String, Reader>,
}

static READERS: LazyLock<Result<Readers, String>> = LazyLock::new(readers);

/// The grammar a declaration names: the ones linked into Tama.
fn grammar(name: &str) -> Result<Language, String> {
    Ok(match name {
        "rust" => tree_sitter_rust::LANGUAGE.into(),
        "javascript" => tree_sitter_javascript::LANGUAGE.into(),
        "typescript" => tree_sitter_typescript::LANGUAGE_TYPESCRIPT.into(),
        "tsx" => tree_sitter_typescript::LANGUAGE_TSX.into(),
        "python" => tree_sitter_python::LANGUAGE.into(),
        "swift" => tree_sitter_swift::LANGUAGE.into(),
        "bash" => tree_sitter_bash::LANGUAGE.into(),
        other => {
            return Err(format!(
                "block_fallbacks/constructs.json names the grammar {other:?}, which Tama does not carry"
            ))
        }
    })
}

fn readers() -> Result<Readers, String> {
    let declared: Declared = serde_json::from_str(include_str!("constructs.json"))
        .map_err(|error| format!("block_fallbacks/constructs.json cannot be read: {error}"))?;
    let mut by_extension = BTreeMap::new();
    for (extension, entry) in declared.extensions {
        let grammar = grammar(&entry.grammar)?;
        let family = declared.families.get(&entry.family).ok_or_else(|| {
            format!(
                "block_fallbacks/constructs.json gives .{extension} the construct family {:?}, which it does not declare",
                entry.family
            )
        })?;
        let mut constructs = Vec::new();
        for construct in family {
            let query = Query::new(&grammar, &construct.query).map_err(|error| {
                format!(
                    "the {} construct {:?} in block_fallbacks/constructs.json is no {} query: {error}",
                    entry.language, construct.name, entry.grammar
                )
            })?;
            let capture = query.capture_index_for_name(CAPTURE).ok_or_else(|| {
                format!(
                    "the {} construct {:?} in block_fallbacks/constructs.json captures no @{CAPTURE} node",
                    entry.language, construct.name
                )
            })?;
            let except = match &construct.except {
                None => None,
                Some(source) => {
                    let except = Query::new(&grammar, source).map_err(|error| {
                        format!(
                            "the except query of the {} construct {:?} in block_fallbacks/constructs.json is no {} query: {error}",
                            entry.language, construct.name, entry.grammar
                        )
                    })?;
                    let index = except.capture_index_for_name(CAPTURE).ok_or_else(|| {
                        format!(
                            "the except query of the {} construct {:?} in block_fallbacks/constructs.json captures no @{CAPTURE} node",
                            entry.language, construct.name
                        )
                    })?;
                    Some((except, index))
                }
            };
            constructs.push(Compiled {
                label: format!("{} {}", entry.language, construct.name),
                query,
                capture,
                except,
            });
        }
        by_extension.insert(
            extension,
            Reader {
                grammar,
                constructs,
            },
        );
    }
    Ok(Readers {
        rule: declared.rule,
        by_extension,
    })
}

fn extension(path: &str) -> Option<&str> {
    let name = path.rsplit('/').next()?;
    name.rsplit_once('.').map(|(_, extension)| extension)
}

/// The grammar `constructs.json` gives the file at `path`, `None` for a file
/// of an extension it declares none for, or why the declaration cannot be
/// read.
pub fn grammar_of(path: &str) -> Result<Option<Language>, String> {
    let readers = READERS.as_ref().map_err(String::clone)?;
    Ok(extension(path)
        .and_then(|extension| readers.by_extension.get(extension))
        .map(|reader| reader.grammar.clone()))
}

/// The operator's rule the refusal quotes, as `constructs.json` records it.
pub fn rule() -> Result<&'static str, String> {
    READERS
        .as_ref()
        .map(|readers| readers.rule.as_str())
        .map_err(String::clone)
}

/// Every fallback the file at `path`, holding `text`, carries, once per
/// construct and line, in line order: (construct, `line N: <the line>`). A
/// file of a language no extension declares carries none.
pub fn findings(path: &str, text: &str) -> Result<Vec<(String, String)>, String> {
    let readers = READERS.as_ref().map_err(String::clone)?;
    let Some(reader) = extension(path).and_then(|extension| readers.by_extension.get(extension))
    else {
        return Ok(Vec::new());
    };
    let mut parser = Parser::new();
    parser
        .set_language(&reader.grammar)
        .map_err(|error| format!("the grammar that parses {path} does not load: {error}"))?;
    let tree = parser
        .parse(text, None)
        .ok_or_else(|| format!("{path} could not be parsed"))?;
    let mut found: BTreeSet<(usize, &str)> = BTreeSet::new();
    for construct in &reader.constructs {
        let mut excepted: BTreeSet<usize> = BTreeSet::new();
        if let Some((except, index)) = &construct.except {
            let mut cursor = QueryCursor::new();
            let mut matches = cursor.matches(except, tree.root_node(), text.as_bytes());
            while let Some(matched) = matches.next() {
                for capture in matched
                    .captures
                    .iter()
                    .filter(|capture| capture.index == *index)
                {
                    excepted.insert(capture.node.id());
                }
            }
        }
        let mut cursor = QueryCursor::new();
        let mut matches = cursor.matches(&construct.query, tree.root_node(), text.as_bytes());
        while let Some(matched) = matches.next() {
            for capture in matched.captures.iter().filter(|capture| {
                capture.index == construct.capture && !excepted.contains(&capture.node.id())
            }) {
                found.insert((capture.node.start_position().row, construct.label.as_str()));
            }
        }
    }
    found
        .into_iter()
        .map(|(row, label)| {
            let line = text
                .lines()
                .nth(row)
                .ok_or_else(|| format!("{path} has no line {row} that its syntax tree names"))?;
            Ok((
                label.to_string(),
                format!("line {}: {}", row + tama_core::lines::FIRST, line.trim()),
            ))
        })
        .collect()
}
