//! An install or update of a product whose last installation of that
//! surface stopped half way, while its checkout still stands on the commit
//! that installation was built from.
//!
//! Stado resumes such an installation from the plan it retained: it builds
//! nothing new and only repeats the step that failed. (When the checkout has
//! moved on, Stado supersedes the unfinished record and builds afresh, so
//! that run passes.) A resuming run is never the build the agent means to
//! make, and whatever consent to a build the session holds is spent on
//! nothing. The command is refused before it runs, naming the retained
//! revision and the failed step, so the agent reads the installation state
//! first. An installation record, HEAD or ref that exists and cannot be read
//! refuses too, naming the file and the cause: read as absent, it would let
//! a resuming run through.

use std::path::{Path, PathBuf};

use serde_json::Value;

use super::vocabulary::{self, VOCABULARY};

/// The Stado verbs that install a product surface and so resume an
/// interrupted installation of it.
enum InstallVerb {
    Install,
    Update,
}

impl InstallVerb {
    /// The verb a `stado product` word is, by its exact spelling.
    fn named(word: &str) -> Option<InstallVerb> {
        match word {
            "install" => Some(InstallVerb::Install),
            "update" => Some(InstallVerb::Update),
            _ => None,
        }
    }
}

const PRODUCT_NOUN: &str = "product";
const SURFACE_FLAG: &str = "--surface";
/// Where Stado keeps each product surface's installation record.
const RECORDS_DIR: &str = ".stado/products";
const RECORD_EXTENSION: &str = "json";
const STATUS_KEY: &str = "status";
/// The status Stado leaves on a record whose installation stopped half way.
const UNFINISHED_STATUS: &str = "installing";
const REVISION_KEY: &str = "source_revision";
const RECIPE_KEY: &str = "recipe";
const REPOSITORY_KEY: &str = "repository";
const READINESS_KEY: &str = "readiness";
const DETAIL_KEY: &str = "detail";
const GIT_DIR: &str = ".git";
const HEAD_FILE: &str = "HEAD";
const SYMBOLIC_REF_PREFIX: &str = "ref: ";
const PACKED_REFS_FILE: &str = "packed-refs";
/// The branch Stado advances a clean checkout to before it plans.
const ORIGIN_MAIN_REF: &str = "refs/remotes/origin/main";

/// The product and surface a `stado product install|update` names: its
/// words that are no flag are the noun, the verb and the product, and the
/// surface is the first `--surface` value, written after `=` or as the next
/// word.
fn target(args: &[String]) -> Option<(String, String)> {
    let mut surface = None;
    let mut positional = Vec::new();
    let mut words = args.iter();
    while let Some(arg) = words.next() {
        match arg.strip_prefix(SURFACE_FLAG) {
            Some("") => {
                let value = words.next().cloned();
                surface = surface.or(value);
            }
            Some(rest) => {
                if let Some(value) = rest.strip_prefix('=') {
                    surface = surface.or(Some(value.to_owned()));
                }
            }
            None if arg.starts_with(vocabulary::FLAG_PREFIX) => {}
            None => positional.push(arg),
        }
    }
    let [noun, verb, product, ..] = positional.as_slice() else {
        return None;
    };
    if *noun != PRODUCT_NOUN || InstallVerb::named(verb).is_none() {
        return None;
    }
    Some(((*product).clone(), surface?))
}

/// The installation record under the one HOME reader: read from HOME alone,
/// an unset HOME would skip the records and let a resuming install through.
/// `Ok(None)` only when no record exists; one that cannot be read or is not
/// JSON is the error, naming the file: read as absent, it would let a
/// resuming install through.
fn record(product: &str, surface: &str) -> Result<Option<Value>, String> {
    let path = crate::util::home_dir()
        .join(RECORDS_DIR)
        .join(product)
        .join(surface)
        .with_extension(RECORD_EXTENSION);
    let text = match std::fs::read_to_string(&path) {
        Ok(text) => text,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(None),
        Err(error) => return Err(format!("cannot read {}: {error}", path.display())),
    };
    serde_json::from_str(&text)
        .map(Some)
        .map_err(|error| format!("{} is not JSON: {error}", path.display()))
}

/// The workspace checkout's git directory for `repository` (`owner/name`).
fn git_dir(repository: &str) -> Option<PathBuf> {
    let name = repository.rsplit('/').next()?;
    Some(crate::util::workshop_root().join(name).join(GIT_DIR))
}

/// The commit `reference` (`refs/…`) names in `git`, loose or packed;
/// `Ok(None)` when neither holds it. A ref file or packed-refs that exists
/// and cannot be read is the error.
fn resolve(git: &Path, reference: &str) -> Result<Option<String>, String> {
    let loose = git.join(reference);
    match std::fs::read_to_string(&loose) {
        Ok(text) => return Ok(Some(text.trim().to_owned())),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
        Err(error) => return Err(format!("cannot read {}: {error}", loose.display())),
    }
    let packed = git.join(PACKED_REFS_FILE);
    let text = match std::fs::read_to_string(&packed) {
        Ok(text) => text,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(None),
        Err(error) => return Err(format!("cannot read {}: {error}", packed.display())),
    };
    Ok(text.lines().find_map(|line| {
        let (commit, name) = line.split_once(' ')?;
        (name == reference).then(|| commit.to_owned())
    }))
}

/// The commit the checkout stands on; `Ok(None)` when it has no HEAD.
fn checkout_head(git: &Path) -> Result<Option<String>, String> {
    let path = git.join(HEAD_FILE);
    let head = match std::fs::read_to_string(&path) {
        Ok(head) => head,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(None),
        Err(error) => return Err(format!("cannot read {}: {error}", path.display())),
    };
    let head = head.trim();
    match head.strip_prefix(SYMBOLIC_REF_PREFIX) {
        Some(reference) => resolve(git, reference),
        None => Ok(Some(head.to_owned())),
    }
}

/// The refusal for an install or update that would only resume an
/// interrupted installation.
pub(super) fn interrupted_install_refusal(program: &str, args: &[String]) -> Option<String> {
    if program != VOCABULARY.fleet_program || args.iter().any(|arg| arg == vocabulary::HELP_FLAG) {
        return None;
    }
    let (product, surface) = target(args)?;
    let unreadable = |cause: String| {
        format!(
            "{}whether `{} {PRODUCT_NOUN} … {product} --surface {surface}` would only resume a \
             half-finished installation cannot be told: {cause}",
            vocabulary::BANNER,
            VOCABULARY.fleet_program,
        )
    };
    let state = match record(&product, &surface) {
        Ok(Some(state)) => state,
        Ok(None) => return None,
        Err(cause) => return Some(unreadable(cause)),
    };
    if state.get(STATUS_KEY).and_then(Value::as_str) != Some(UNFINISHED_STATUS) {
        return None;
    }
    let revision = state.get(REVISION_KEY).and_then(Value::as_str)?;
    let repository = state
        .get(RECIPE_KEY)
        .and_then(|recipe| recipe.get(REPOSITORY_KEY))
        .and_then(Value::as_str)?;
    // Stado first advances a clean checkout to origin/main, and supersedes
    // the record when that moves it; only a checkout that stays on the
    // recorded commit resumes the retained plan.
    let git = git_dir(repository)?;
    let (head, main) = match (checkout_head(&git), resolve(&git, ORIGIN_MAIN_REF)) {
        (Ok(head), Ok(main)) => (head, main),
        (Err(cause), _) | (_, Err(cause)) => return Some(unreadable(cause)),
    };
    if head.as_deref() != Some(revision) || main.as_deref() != Some(revision) {
        return None;
    }
    let stopped = match state
        .get(READINESS_KEY)
        .and_then(|readiness| readiness.get(DETAIL_KEY))
        .and_then(Value::as_str)
    {
        Some(detail) => format!("({detail})"),
        None => "(the record names no failed step)".to_string(),
    };
    Some(format!(
        "{}`{} {PRODUCT_NOUN} … {product} --surface {surface}` would not build anything: the last \
         installation of {product}/{surface} stopped half way {stopped} at source revision \
         {revision}, the checkout of {repository} still stands on that commit, and Stado resumes \
         such an installation from its retained plan, repeating only the step that failed. Read \
         `stado product status {product} --surface {surface}` and the open install defects of \
         {product} and Stado, commit and push the repair of the failed step, and run again once the \
         checkout stands on it; a rollback is not the way on.",
        vocabulary::BANNER,
        VOCABULARY.fleet_program,
    ))
}
