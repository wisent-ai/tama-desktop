//! `tama hooks undeclare --file <declaration.json>`: take one hook back out of
//! the registry, the catalogue and the seal, the reverse of `declare`, with
//! one command.
//!
//! The same declaration that put the hook in names what comes out: its id,
//! the command its bindings run and every event it binds. The registry
//! bindings go first, because the registry describes hooks the catalogue
//! carries; then the catalogue entry; then the sources are reconciled and the
//! registry resealed once, exactly as `declare` finishes; then the declaration
//! file goes, so nothing declares a hook the registry no longer holds. Every
//! step is idempotent: a binding already gone and an entry already absent are
//! reported, so a rerun after a partial withdrawal finishes it.
//!
//! The consent rule is `declare`'s: without the owner's consent (his shell
//! variable or his word in the conversation) it refuses before changing
//! anything and says how to give it.

use std::path::Path;

use super::declare::{consent, consent_route, is_bound, refuse, run, writer, Declaration};

pub const USAGE: &str = "usage: tama hooks undeclare --file <declaration.json> [--dry-run]\n\
     \n\
     The declaration that declared the hook names what is withdrawn: its id, the command its\n\
     bindings run and every event they bind. Bindings go first, then the catalogue entry,\n\
     then one reseal; the declaration file is removed last.";

pub fn main(argv: &[String], root: &Path) -> i32 {
    if argv.iter().any(|arg| arg == "--help" || arg == "-h") {
        println!("{USAGE}");
        return 0;
    }
    let Some(file) = argv
        .iter()
        .position(|arg| arg == "--file")
        .and_then(|at| argv.get(at + 1))
    else {
        return refuse(USAGE);
    };
    let dry_run = argv.iter().any(|arg| arg == "--dry-run");
    let text = match std::fs::read_to_string(file) {
        Ok(text) => text,
        Err(error) => return refuse(&format!("cannot read {file}: {error}")),
    };
    let declaration: Declaration = match serde_json::from_str(&text) {
        Ok(declaration) => declaration,
        Err(error) => return refuse(&format!("{file} is not a hook declaration: {error}")),
    };
    if !dry_run {
        if let Err(cause) = consent() {
            return refuse(&format!(
                "BLOCKED: hook source and configuration are device-level protected: {cause}. {}",
                consent_route(&format!(
                    "tama hooks undeclare --file {}",
                    root.join(file).display()
                ))
            ));
        }
    }
    withdraw(&declaration, root, file, dry_run)
}

fn withdraw(declaration: &Declaration, root: &Path, file: &str, dry_run: bool) -> i32 {
    let catalogue = root.join("shared-hooks/catalog-metadata.json");
    let registry = root.join("shared-hooks/registry.json");
    let id = &declaration.id;
    let mut bound: Vec<&str> = Vec::new();
    for binding in &declaration.events {
        match is_bound(&registry, id, &binding.event) {
            Ok(true) => bound.push(binding.event.as_str()),
            Ok(false) => {}
            Err(cause) => return refuse(&cause),
        }
    }
    if dry_run {
        for binding in &declaration.events {
            let state = if bound.contains(&binding.event.as_str()) {
                "would unbind"
            } else {
                "already unbound"
            };
            println!("{state}: {id} on {}", binding.event);
        }
        println!("would remove the catalogue entry for {id}, reconcile sources, reseal {} and remove {file}", registry.display());
        return 0;
    }
    for event in &bound {
        let args = [
            "node".to_string(),
            "shared-hooks/register-hook.mjs".to_string(),
            id.clone(),
            (*event).to_string(),
            declaration.command.clone(),
            "--remove".to_string(),
        ];
        match run(Path::new("/usr/bin/env"), &args, root) {
            Ok(said) => println!("registry: {said}"),
            Err(error) => return refuse(&error),
        }
    }
    for binding in &declaration.events {
        if !bound.contains(&binding.event.as_str()) {
            println!("registry: {id} was not bound to {}", binding.event);
        }
    }
    let removed = writer(
        "record-hook-metadata",
        &[
            "--remove".to_string(),
            catalogue.display().to_string(),
            id.clone(),
        ],
    )
    .and_then(|(program, args)| run(&program, &args, root));
    match removed {
        Ok(said) => println!("catalogue: {said}"),
        Err(error) => return refuse(&error),
    }
    let reconciled = writer(
        "reconcile-registry-sources",
        &[registry.display().to_string()],
    )
    .and_then(|(program, args)| run(&program, &args, root));
    match reconciled {
        Ok(said) => println!("sources: {said}"),
        Err(error) => return refuse(&error),
    }
    let sealed = run(
        Path::new("/usr/bin/env"),
        &[
            "node".to_string(),
            "shared-hooks/seal-registry.mjs".to_string(),
            registry.display().to_string(),
        ],
        root,
    );
    match sealed {
        Ok(said) => println!("seal: {said}"),
        Err(error) => return refuse(&error),
    }
    if let Err(error) = std::fs::remove_file(file) {
        return refuse(&format!(
            "{id} is withdrawn from the registry and the catalogue, but its declaration {file} could not be removed: {error}"
        ));
    }
    println!(
        "{id} is undeclared and {file} is removed. Machines stop running it once the release is installed."
    );
    0
}
