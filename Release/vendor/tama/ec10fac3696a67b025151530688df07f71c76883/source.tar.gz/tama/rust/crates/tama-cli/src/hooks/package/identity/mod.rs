//! The source identity a hook release is packaged and sealed against: the
//! commit, whether the tree held uncommitted work, and a fingerprint of every
//! source input, so a tree that changes between staging and sealing is
//! refused instead of sealed under the wrong name.
//!
//! Three sources exist. A Stado build unpacks exactly the committed tree of the
//! commit it names in `WISENT_SOURCE_COMMIT`, with no `.git` to ask; Tama
//! Desktop unpacks a pinned archive beside its marker (see [`archive`]); an
//! operator's checkout is read through git.

mod archive;

use std::collections::BTreeSet;
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};

use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use tama_core::git::Git;

/// What a hook release is made of; `rust/` is compiled, not shipped.
pub(super) const SOURCE_INPUTS: [&str; 6] = [
    "package.json",
    "shared-hooks",
    "claude-hooks",
    "codex-hooks",
    "repo-githooks",
    "rust",
];
/// Generators that only write configuration in a checkout; a release drops them.
pub(crate) const PRUNED_GENERATORS: &[&str] = &[
    "shared-hooks/providers.json",
    "shared-hooks/run-one-session-hook.js",
];
const COMMIT_ENV: &str = "WISENT_SOURCE_COMMIT";
const FULL_COMMIT_LENGTH: usize = 40;
const COMPILED_OUTPUT: &str = "rust/target";
const BYTECODE_DIRECTORY: &str = "__pycache__";
const BYTECODE_SUFFIX: &str = ".pyc";
const PERMISSION_BITS: u32 = 0o7777;

/// The variables a Git hook hands its children, cleared so `-C <root>` alone
/// names the repository whose identity is read.
const INHERITED_REPOSITORY: &[&str] = &["GIT_DIR", "GIT_WORK_TREE", "GIT_INDEX_FILE"];

fn git(root: &Path, arguments: &[&str]) -> Result<String, String> {
    let printed = Git::of(Some(root))
        .cleared(INHERITED_REPOSITORY)
        .bytes(arguments)
        .map_err(|cause| format!("reading hook source identity: {cause}"))?;
    Ok(String::from_utf8_lossy(&printed).to_string())
}

pub(crate) fn file_digest(path: &Path) -> Result<String, String> {
    let bytes =
        std::fs::read(path).map_err(|error| format!("cannot read {}: {error}", path.display()))?;
    Ok(format!("{:x}", Sha256::digest(bytes)))
}

/// Every source input file under an unpacked tree, as paths relative to it.
fn unpacked_paths(root: &Path) -> Result<BTreeSet<String>, String> {
    let mut paths = BTreeSet::new();
    let mut pending: Vec<PathBuf> = Vec::new();
    for name in SOURCE_INPUTS {
        let path = root.join(name);
        // Only an input that does not exist is left out of the identity; one
        // that cannot be inspected fails it instead of vanishing from it.
        let metadata = match std::fs::symlink_metadata(&path) {
            Ok(metadata) => metadata,
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => continue,
            Err(error) => return Err(format!("cannot read {}: {error}", path.display())),
        };
        if metadata.is_dir() {
            pending.push(path);
        } else {
            paths.insert(name.to_string());
        }
    }
    while let Some(directory) = pending.pop() {
        if directory == root.join(COMPILED_OUTPUT) {
            continue;
        }
        let entries = std::fs::read_dir(&directory)
            .map_err(|error| format!("cannot list {}: {error}", directory.display()))?;
        for entry in entries {
            let entry =
                entry.map_err(|error| format!("cannot list {}: {error}", directory.display()))?;
            let path = entry.path();
            let name = entry.file_name().to_string_lossy().to_string();
            let file_type = entry
                .file_type()
                .map_err(|error| format!("cannot read {}: {error}", path.display()))?;
            if file_type.is_dir() {
                if name != BYTECODE_DIRECTORY {
                    pending.push(path);
                }
            } else if !name.ends_with(BYTECODE_SUFFIX) {
                let relative = path.strip_prefix(root).unwrap_or(&path);
                paths.insert(relative.to_string_lossy().to_string());
            }
        }
    }
    Ok(paths)
}

/// One input's path, permission bits, symlink target and content digest;
/// all but the path are null when the input is gone. An input that cannot be
/// inspected, or a link whose target cannot be read, fails the identity.
fn input_entry(root: &Path, relative: &str) -> Result<Value, String> {
    let path = root.join(relative);
    let mut entry = json!({ "path": relative, "mode": null, "target": null, "digest": null });
    let metadata = match std::fs::symlink_metadata(&path) {
        Ok(metadata) => metadata,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(entry),
        Err(error) => return Err(format!("cannot read {}: {error}", path.display())),
    };
    entry["mode"] = json!(metadata.permissions().mode() & PERMISSION_BITS);
    if metadata.file_type().is_symlink() {
        let target = std::fs::read_link(&path)
            .map_err(|error| format!("cannot read the link {}: {error}", path.display()))?;
        entry["target"] = json!(target.to_string_lossy().to_string());
    }
    if !path.is_file() {
        return Err(format!(
            "Hook source input is not a readable file: {}",
            path.display()
        ));
    }
    entry["digest"] = json!(file_digest(&path)?);
    Ok(entry)
}

/// The identity of the source tree at `root`; with `release`, also that each
/// staged, shipped input still has the bytes of its source.
pub(crate) fn source_identity(root: &Path, release: Option<&Path>) -> Result<Value, String> {
    // Unset is no declared commit; a value that is not text is refused, where
    // it was read as unset and the identity silently came from Git instead.
    let commit = match std::env::var(COMMIT_ENV) {
        Ok(commit) => commit,
        Err(std::env::VarError::NotPresent) => String::new(),
        Err(error) => return Err(format!("{COMMIT_ENV} cannot be read: {error}")),
    };
    let mut archived = None;
    // Each presence is examined, not read off exists(): a marker, checkout or
    // staged file that cannot be stat'ed refuses with its cause.
    let present =
        |path: &Path| tama_core::presence::present(path).map_err(|error| error.to_string());
    let checkout = present(&root.join(".git"))?;
    let (revision, dirty, paths) = if present(&root.join(archive::MARKER))? {
        if checkout {
            return Err(format!(
                "Source cannot be both a checkout and an immutable archive: {}",
                root.display()
            ));
        }
        let (revision, entries) = archive::archived_inputs(root)?;
        let mut paths = unpacked_paths(root)?;
        paths.extend(entries.keys().cloned());
        archived = Some(entries);
        (revision, false, paths)
    } else if !commit.is_empty() && !checkout {
        if commit.len() != FULL_COMMIT_LENGTH || !commit.chars().all(|c| c.is_ascii_hexdigit()) {
            return Err(format!("{COMMIT_ENV} is not a full commit: {commit}"));
        }
        (commit, false, unpacked_paths(root)?)
    } else {
        let top = PathBuf::from(git(root, &["rev-parse", "--show-toplevel"])?.trim());
        let canonical = |path: &Path| {
            std::fs::canonicalize(path)
                .map_err(|error| format!("{} cannot be resolved: {error}", path.display()))
        };
        if canonical(&top)? != canonical(root)? {
            return Err(format!(
                "Hook source root {} is not the Git checkout root {}",
                root.display(),
                top.display()
            ));
        }
        let revision = git(root, &["rev-parse", "--verify", "HEAD"])?
            .trim()
            .to_string();
        let dirty = !git(root, &["status", "--porcelain", "--untracked-files=normal"])?.is_empty();
        let mut arguments = vec![
            "ls-files",
            "--cached",
            "--others",
            "--exclude-standard",
            "-z",
            "--",
        ];
        arguments.extend(SOURCE_INPUTS);
        let listed = git(root, &arguments)?;
        let paths = listed
            .split('\0')
            .filter(|p| !p.is_empty())
            .map(str::to_string)
            .collect();
        (revision, dirty, paths)
    };
    let mut fingerprint = Sha256::new();
    for relative in &paths {
        let path = root.join(relative);
        let entry = input_entry(root, relative)?;
        if let Some(release) = release.filter(|_| !relative.starts_with("rust/")) {
            let staged = release.join(relative);
            if entry["digest"].is_null() {
                if present(&staged)? {
                    return Err(format!(
                        "Deleted hook source remains staged: {}; restage the release",
                        staged.display()
                    ));
                }
            } else {
                let pruned = PRUNED_GENERATORS.contains(&relative.as_str()) && !present(&staged)?;
                if !pruned && (!staged.is_file() || json!(file_digest(&staged)?) != entry["digest"])
                {
                    return Err(format!(
                        "Staged hook source differs from {}: {}; restage the release",
                        path.display(),
                        staged.display()
                    ));
                }
            }
        }
        if let Some(archived) = &archived {
            let Some(expected) = archived.get(relative) else {
                return Err(format!(
                    "Additional source input is not in the pinned archive: {}",
                    path.display()
                ));
            };
            if &entry != expected {
                return Err(format!(
                    "Immutable source input differs from its pinned archive: {}",
                    path.display()
                ));
            }
        }
        fingerprint.update(entry.to_string().as_bytes());
        fingerprint.update(b"\n");
    }
    Ok(json!({
        "revision": revision,
        "dirty": dirty,
        "fingerprint": format!("{:x}", fingerprint.finalize()),
    }))
}

/// Refuse a source tree that changed since `expected` was read.
pub(crate) fn verify_source_identity(root: &Path, expected: &Value) -> Result<(), String> {
    let observed = source_identity(root, None)?;
    if &observed != expected {
        return Err(format!(
            "Hook source changed after staging at {}: expected {expected}, observed {observed}; \
             restage the release",
            root.display()
        ));
    }
    Ok(())
}
