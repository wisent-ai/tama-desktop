//! Persistent operator dismissal state for learning proposals.

use std::collections::BTreeMap;
use std::path::PathBuf;

use serde_json::Value;

const DECISIONS: &str = ".shared-hooks/rule_decisions.json";
pub(super) const DECISIONS_KEY: &str = "dismissed";
pub(super) const CAUSE_PREFIX: &str = "cause:";

pub(super) fn decisions_path() -> PathBuf {
    tama_core::home_dir().join(DECISIONS)
}

/// A damaged decisions file cannot silently reopen dismissed proposals or
/// be overwritten by the next operator decision.
pub(super) fn dismissed() -> Result<BTreeMap<String, Value>, String> {
    let path = decisions_path();
    let text = match std::fs::read_to_string(&path) {
        Ok(text) => text,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(BTreeMap::new()),
        Err(error) => return Err(format!("cannot read {}: {error}", path.display())),
    };
    let doc: Value = serde_json::from_str(&text)
        .map_err(|error| format!("cannot parse {}: {error}", path.display()))?;
    let decisions = doc
        .get(DECISIONS_KEY)
        .and_then(Value::as_object)
        .ok_or_else(|| format!("{} needs a {DECISIONS_KEY} object", path.display()))?;
    for (id, decision) in decisions {
        let count = decision.as_u64().is_some();
        let seen = decision
            .get("seen")
            .and_then(Value::as_array)
            .is_some_and(|ids| ids.iter().all(Value::is_string));
        if !count && !(id.starts_with(CAUSE_PREFIX) && seen) {
            return Err(format!(
                "{} has an invalid decision for {id}",
                path.display()
            ));
        }
    }
    Ok(decisions
        .iter()
        .map(|(id, decision)| (id.clone(), decision.clone()))
        .collect())
}
