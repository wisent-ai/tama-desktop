//! Whether a record still holds, by re-reading what it names; no model.

use std::path::Path;

use serde_json::{json, Value};
use tama_hook_tools::ports::task_attestation::subject;

use super::{list, Kind, Record};
use crate::justify::cua::transcript;

/// A field a record must carry to be verified, or the refusal naming it.
fn field<'a>(record: &'a Record, name: &str, value: &'a Value) -> Result<&'a str, String> {
    value
        .as_str()
        .filter(|text| !text.is_empty())
        .ok_or_else(|| {
            format!(
                "the {} attestation of {} carries no {name} to verify it by (read from {})",
                record.kind.name(),
                record.subject,
                record.store
            )
        })
}

/// Why one record does not verify, by name; `None` when it does. An agent's
/// record verifies by its artifact: the subject exists and, for a session, the
/// kept record stands against today's standard. An operator's grant verifies
/// by his words: the cited sentence must stand in the session's transcript,
/// so a sentence an agent wrote into the registry itself is refused here.
pub(crate) fn failure(record: &Record) -> Result<Option<String>, String> {
    let kind = record.kind;
    let subject = record.subject.as_str();
    Ok(match kind {
        Kind::Session => match subject::Subject::session(subject).and_then(|kept| kept.refusal()) {
            Ok(none_or_why) => none_or_why,
            Err(why) => Some(why),
        },
        // `Path::exists` reads a path it may not examine as absent; the
        // examination that fails says why instead.
        Kind::File | Kind::Test => match Path::new(subject).try_exists() {
            Ok(true) => None,
            Ok(false) => Some(format!(
                "{} attestation of {subject}: the path no longer exists",
                kind.name()
            )),
            Err(error) => Some(format!(
                "{} attestation of {subject}: whether the path exists cannot be examined: {error}",
                kind.name()
            )),
        },
        Kind::Cua | Kind::Ssh => {
            let session = field(record, "session", &record.scope["session"])?;
            let quote = field(record, "statement", &record.statement)?;
            transcript::select(session, quote)
                .err()
                .map(|why| format!("{} grant for {subject}: {why}", kind.name()))
        }
        Kind::Build => None,
    })
}

/// Every record of `kind` (or every kind), or the ones naming `subject`,
/// each with how it verifies: `{record, verified, failure}`. Asked of every
/// subject, each place the ledger and a registry view disagree follows as
/// one more unverified entry with no record, naming the disagreement.
pub(crate) fn verify(kind: Option<Kind>, subject: Option<&str>) -> Result<Vec<Value>, String> {
    let chosen: Vec<Record> = list(kind)?
        .into_iter()
        .filter(|record| subject.is_none_or(|wanted| record.subject == wanted))
        .collect();
    if let (true, Some(subject)) = (chosen.is_empty(), subject) {
        return Err(format!("no attestation names {subject}"));
    }
    let mut verified = chosen
        .into_iter()
        .map(|record| {
            let failure = failure(&record)?;
            let record = record.value()?;
            Ok(json!({ "record": record, "verified": failure.is_none(), "failure": failure }))
        })
        .collect::<Result<Vec<Value>, String>>()?;
    if subject.is_none() {
        verified.extend(
            super::migrate::drift(kind)?
                .into_iter()
                .map(|why| json!({ "record": Value::Null, "verified": false, "failure": why })),
        );
    }
    Ok(verified)
}
