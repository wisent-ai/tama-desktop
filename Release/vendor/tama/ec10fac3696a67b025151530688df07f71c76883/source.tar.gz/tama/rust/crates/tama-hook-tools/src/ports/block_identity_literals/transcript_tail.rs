//! The identities a transcript's user messages carry, read from a byte
//! offset on.
//!
//! A transcript grows: the harness appends one record per line. A session in
//! progress changes its transcript on every turn, and its transcript runs to
//! a hundred megabytes and more, so reading it whole on every change spent
//! more than a minute of a write's hook budget on records already read. The
//! index keeps how far it has read and a mark of the last record it read
//! (`mention_index`); while the file still holds that record where it was,
//! the file was only appended to and only what follows is read. A file
//! rewritten in place no longer holds the mark and is read from its start. A
//! last line without its newline is a record still being written: it is not
//! consumed, and the next read starts at it.
use serde::{Deserialize, Serialize};
use serde_json::Value;
use sha2::{Digest, Sha256};
use std::collections::BTreeSet;
use std::fs::File;
use std::io::{BufRead, BufReader, Read, Seek, SeekFrom};
use std::path::Path;

/// The last complete record a read consumed: where it starts and the digest
/// of its bytes, up to the offset the read stopped at.
#[derive(Clone, Serialize, Deserialize, PartialEq, Eq)]
pub(super) struct Mark {
    start: u64,
    digest: String,
}

/// What one read found: the identities, the offset just past the last
/// complete record, and that record's mark (none when no record was read).
pub(super) struct Tail {
    pub(super) identities: BTreeSet<String>,
    pub(super) consumed: u64,
    pub(super) last: Option<Mark>,
}

fn digest(bytes: &[u8]) -> String {
    format!("{:x}", Sha256::digest(bytes))
}

fn open_at(path: &Path, offset: u64) -> Result<File, String> {
    let mut file = File::open(path)
        .map_err(|error| format!("cannot open transcript {}: {error}", path.display()))?;
    file.seek(SeekFrom::Start(offset)).map_err(|error| {
        format!(
            "cannot seek transcript {} to byte {offset}: {error}",
            path.display()
        )
    })?;
    Ok(file)
}

/// Whether `path` still holds `mark`'s record ending at `consumed`: the file
/// was appended to since it was read, not rewritten.
pub(super) fn holds(path: &Path, mark: &Mark, consumed: u64) -> Result<bool, String> {
    let Some(length) = consumed.checked_sub(mark.start) else {
        return Ok(false);
    };
    let mut record = Vec::new();
    open_at(path, mark.start)?
        .take(length)
        .read_to_end(&mut record)
        .map_err(|error| {
            format!(
                "cannot read transcript {} at byte {}: {error}",
                path.display(),
                mark.start
            )
        })?;
    Ok(record.len() as u64 == length && digest(&record) == mark.digest)
}

/// The identities user messages carry in the complete records of `path` from
/// byte `from` on (from its start when `None`).
pub(super) fn identities_from(path: &Path, from: Option<u64>) -> Result<Tail, String> {
    let mut file = File::open(path)
        .map_err(|error| format!("cannot open transcript {}: {error}", path.display()))?;
    if let Some(offset) = from {
        file = open_at(path, offset)?;
    }
    let mut consumed = file.stream_position().map_err(|error| {
        format!(
            "cannot read the position in transcript {}: {error}",
            path.display()
        )
    })?;
    let mut reader = BufReader::new(file);
    let mut tail = Tail {
        identities: BTreeSet::new(),
        consumed,
        last: None,
    };
    let mut line = Vec::new();
    loop {
        line.clear();
        let read = reader.read_until(b'\n', &mut line).map_err(|error| {
            format!(
                "cannot read transcript {} at byte {consumed}: {error}",
                path.display()
            )
        })?;
        if line.last() != Some(&b'\n') {
            tail.consumed = consumed;
            return Ok(tail);
        }
        let text = std::str::from_utf8(&line).map_err(|error| {
            format!(
                "transcript {} record at byte {consumed} is not UTF-8: {error}",
                path.display()
            )
        })?;
        if !text.trim().is_empty() {
            let record: Value = serde_json::from_str(text).map_err(|error| {
                format!(
                    "cannot decode transcript {} record at byte {consumed}: {error}",
                    path.display()
                )
            })?;
            user_identities(&record, &mut tail.identities);
        }
        tail.last = Some(Mark {
            start: consumed,
            digest: digest(&line),
        });
        consumed += read as u64;
    }
}

fn user_identities(record: &Value, identities: &mut BTreeSet<String>) {
    let holder = match record.get("message").filter(|message| message.is_object()) {
        Some(message) => message,
        None => record,
    };
    if holder.get("role").and_then(Value::as_str) != Some("user") {
        return;
    }
    let mut add = |text: &str| {
        identities.extend(
            super::identities(text)
                .into_iter()
                .map(|(_, identity, _)| identity),
        );
    };
    match holder.get("content") {
        Some(Value::String(text)) => add(text),
        Some(Value::Array(parts)) => {
            for part in parts {
                if let Some(text) = part.get("text").and_then(Value::as_str) {
                    add(text);
                }
            }
        }
        _ => {}
    }
}
