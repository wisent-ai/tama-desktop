//! `tama session handover|leases`: pass one session's lease on a file to
//! another, and read who holds which file.
//!
//! Any session may hand over any session's lease, whether that session still
//! runs or has ended: work in a checkout belongs to no session alone, and a
//! session that stalls must not keep its edits from the one carrying them on.
//! The file must hold uncommitted edits under the holder's lease; the
//! handover records the bytes it held then, whoever wrote them, and who ran
//! it, and the receiving session holds the lease from then on. It names no
//! author of those bytes and makes no co-author.

use std::path::PathBuf;

use serde_json::json;

use super::{change, checkout_of, digest, read, unchanged, Handover, REGISTER};
use crate::ports::owner_consent::recorded_session;

pub const USAGE: &str = "tama session handover --path P --from A --to B [--json]
tama session leases [--repository PATH] [--json]";

/// The value following `flag` in `args`.
fn value<'a>(args: &'a [String], flag: &str) -> Option<&'a str> {
    let mut words = args.iter();
    words.find(|arg| *arg == flag)?;
    words.next().map(String::as_str)
}

fn required<'a>(args: &'a [String], flag: &str) -> Result<&'a str, String> {
    value(args, flag)
        .filter(|given| !given.is_empty())
        .ok_or_else(|| format!("{flag} is required\n{USAGE}"))
}

/// The session this command runs in, or `operator` for one nobody's recorded
/// agent runs.
fn caller() -> Result<String, String> {
    Ok(match recorded_session()? {
        (Some((_, session)), _) => session,
        (None, _) => "operator".to_owned(),
    })
}

fn handover(args: &[String]) -> Result<String, String> {
    let path = PathBuf::from(required(args, "--path")?);
    let from = required(args, "--from")?;
    let to = required(args, "--to")?;
    if from == to {
        return Err(format!(
            "--from and --to both name session {from}; a session holds its own edits"
        ));
    }
    let checked =
        checkout_of(&path)?.ok_or_else(|| format!("{} is in no Git checkout", path.display()))?;
    if unchanged(&checked)? {
        return Err(format!(
            "{} is what HEAD holds: no uncommitted edits are there to hand over",
            path.display()
        ));
    }
    let by = caller()?;
    let bytes =
        std::fs::read(&path).map_err(|error| format!("cannot read {}: {error}", path.display()))?;
    let content_sha256 = digest(&bytes);
    let at = tama_core::clock::iso_now_seconds();
    let record = Handover {
        path: checked.relative.clone(),
        from: from.to_owned(),
        to: to.to_owned(),
        content_sha256: content_sha256.clone(),
        by,
        at,
    };
    change(&checked.common, |register| {
        match register.leases.get(&checked.relative) {
            Some(lease) if lease.session == from => {}
            Some(lease) => {
                return Err(format!(
                    "{} is held by session {} since {}, not by {from}; only the holder's lease is handed over",
                    path.display(),
                    lease.session,
                    lease.since
                ))
            }
            None => {
                return Err(format!(
                    "{} holds no lease of session {from}; edits nobody's lease names are not handed over",
                    path.display()
                ))
            }
        }
        let head = super::lease::head_blob(&checked)?;
        let lease = super::lease::taken(to, head, true, None);
        register.leases.insert(checked.relative.clone(), lease);
        register.handovers.push(record.clone());
        Ok(())
    })?;
    Ok(if args.iter().any(|arg| arg == "--json") {
        json!(record).to_string()
    } else {
        format!(
            "session {from}'s lease on {} passes to session {to} (content {content_sha256}); a change {to} commits built on those bytes counts as {to}'s work",
            checked.relative
        )
    })
}

fn leases(args: &[String]) -> Result<String, String> {
    let repository = match value(args, "--repository") {
        Some(repository) => PathBuf::from(repository),
        None => std::env::current_dir()
            .map_err(|error| format!("cannot read the current directory: {error}"))?,
    };
    // A path inside the repository names its checkout; the file need not exist.
    let checked = checkout_of(&repository.join(REGISTER))?
        .ok_or_else(|| format!("{} is in no Git checkout", repository.display()))?;
    let register = read(&checked.common.join(REGISTER))?;
    if args.iter().any(|arg| arg == "--json") {
        return serde_json::to_string(&register)
            .map_err(|error| format!("cannot encode the leases: {error}"));
    }
    let mut lines: Vec<String> = register
        .leases
        .iter()
        .map(|(path, lease)| format!("{path}  held by {} since {}", lease.session, lease.since))
        .collect();
    lines.extend(register.handovers.iter().map(|handover| {
        format!(
            "{}  handed from {} to {} by {} at {}",
            handover.path, handover.from, handover.to, handover.by, handover.at
        )
    }));
    if lines.is_empty() {
        lines.push(format!("no file of {} is held", checked.root.display()));
    }
    Ok(lines.join("\n"))
}

/// `tama session ARGS`.
pub fn cli(args: &[String]) -> Result<String, String> {
    let mut words = args.iter();
    let verb = words.next().map(String::as_str);
    let rest: Vec<String> = words.cloned().collect();
    match verb {
        Some("handover") => handover(&rest),
        Some("leases") => leases(&rest),
        _ => Err(USAGE.to_owned()),
    }
}
