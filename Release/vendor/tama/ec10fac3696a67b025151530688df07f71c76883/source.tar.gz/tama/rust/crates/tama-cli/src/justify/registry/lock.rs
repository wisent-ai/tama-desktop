//! Exclusive access to one registry across the whole read, splice and replace.
//!
//! Recording reads the document, splices one entry into that copy, and renames
//! the result over the file. Two commands doing it at once would each splice
//! into the same base, and the second rename would drop the first entry while
//! both printed the success line. The read and the replace belong inside one
//! lock, so they are.
//!
//! The lock is the kernel's: a second command waits until the first releases
//! it or exits, and a crashed holder releases it by exiting, so there is no
//! stale lock file to guess about. The holder releases it by closing the
//! file when the lock is dropped; no separate unlock can fail unsaid.

use std::fs::{self, File, OpenOptions};
use std::path::Path;

pub(crate) struct Lock {
    /// Held, not read: closing it when the lock is dropped releases the lock.
    _held: File,
}

impl Lock {
    pub(crate) fn acquire(registry: &Path) -> Result<Self, String> {
        let path = registry.with_extension("lock");
        // The first recording on a machine creates the registry directory, and
        // the lock sits beside the document, so the directory has to exist
        // before the lock rather than when the document is finally written.
        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent)
                .map_err(|error| format!("cannot create {}: {error}", parent.display()))?;
        }
        let file = OpenOptions::new()
            .write(true)
            .create(true)
            .truncate(false)
            .open(&path)
            .map_err(|error| format!("cannot open {}: {error}", path.display()))?;
        // Another recording may hold the lock; the wait says so while it lasts.
        stado_wait::blocking(
            stado_wait::Kind::Lock,
            "the justification registry",
            path.display(),
            || file.lock(),
        )
        .map_err(|error| format!("cannot lock {}: {error}", path.display()))?;
        Ok(Self { _held: file })
    }
}
