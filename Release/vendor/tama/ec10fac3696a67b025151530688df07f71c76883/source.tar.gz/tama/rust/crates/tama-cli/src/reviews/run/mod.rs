//! `tama reviews harsh run`: a round by a reviewer session the author starts,
//! which ends when its round is recorded.
//!
//! An author cannot review its own candidate, and its commit should not wait
//! for another session to be free. `run` prepares a directory of its own for
//! the run, briefs the reviewer (`brief.md`) with the index the candidate is
//! staged in, its tree, the message and the item the author's work is for,
//! copies the Tama program into the directory, and runs the reviewer session
//! (`watch`) to its end. An OMP session starts `run` as a call OMP defers, so
//! the author works on while the reviewer reads and OMP delivers the
//! outcome into the transcript when it ends; the operator sees the call and
//! can stop it there. Every run keeps its brief, events, errors, findings,
//! improvements and outcome in `runs/<tree>/<start in ms>` beside the
//! rounds' register in the repository's Git directory.

use std::fs::File;
use std::path::{Path, PathBuf};

use tama_hook_tools::ports::harsh_review::{now_ms, read, register, staged_tree, RUNS_DIRECTORY};

mod watch;

const PRINT_MODE: &[&str] = &["-p", "--mode", "json"];
const BRIEF: &str = include_str!("brief.md");
/// The options `tama task scope set` names an item with.
const SCOPES: &[&str] = &["--defect", "--task"];

/// An absolute path for `path`, read against the current directory.
fn absolute(path: &Path) -> Result<PathBuf, String> {
    std::path::absolute(path)
        .map_err(|cause| format!("{} has no absolute path: {cause}", path.display()))
}

/// A new file at `path`, for the reviewer's output.
fn create(path: &Path) -> Result<File, String> {
    File::create(path).map_err(|cause| format!("cannot create {}: {cause}", path.display()))
}

/// The `--defect <id>` or `--task <id>` the author's work is for: exactly
/// one of them, as `tama task scope set` takes it.
fn scope(args: &[String]) -> Result<String, String> {
    let given: Vec<String> = SCOPES
        .iter()
        .filter_map(|name| super::harsh::option(args, name).map(|id| format!("{name} {id}")))
        .collect();
    match given.as_slice() {
        [one] => Ok(one.clone()),
        _ => Err(format!(
            "name the item the reviewed work is for with exactly one of {}",
            SCOPES
                .iter()
                .map(|name| format!("{name} <id>"))
                .collect::<Vec<_>>()
                .join(" or ")
        )),
    }
}

/// What the reviewer session of one run is given and read against.
struct Run {
    harness: String,
    repository: PathBuf,
    index: String,
    tree: String,
    register: PathBuf,
    /// How many entries the register held before the reviewer started, so
    /// a round is read only from what the reviewer added.
    before: usize,
}

const OUTCOME_FILE: &str = "outcome.txt";
const BRIEF_FILE: &str = "brief.md";
const EVENTS_FILE: &str = "events.jsonl";
const ERRORS_FILE: &str = "stderr.log";
const PROGRAM_FILE: &str = "tama";

pub(super) fn run(args: &[String]) -> Result<(String, bool), String> {
    let repository = absolute(&super::harsh::repository(args)?)?;
    let message = absolute(Path::new(super::harsh::required(args, "--message")?))?;
    let text = super::harsh::text(&message.to_string_lossy())?;
    if text.trim().is_empty() {
        return Err(format!("the message {} is empty", message.display()));
    }
    let scope = scope(args)?;
    let Some(harness) = crate::omp::program(&tama_core::home_dir())? else {
        return Err(
            "no OMP program to run the reviewer in: name it in TAMA_OMP, or put omp on PATH or in \
             ~/.local/bin"
                .to_string(),
        );
    };
    // The index this command reads, which GIT_INDEX_FILE names when the
    // candidate is staged in a private one: the reviewer reads that index.
    let index = crate::gitcmd::git(
        &repository,
        &["rev-parse", "--path-format=absolute", "--git-path", "index"],
    )?
    .trim()
    .to_string();
    let tree = staged_tree(&repository)?;
    let kept = register(&repository)?;
    let Some(rounds) = kept.parent() else {
        return Err(format!("the register {} has no directory", kept.display()));
    };
    let runs = rounds.join(RUNS_DIRECTORY).join(&tree);
    std::fs::create_dir_all(&runs)
        .map_err(|cause| format!("cannot create {}: {cause}", runs.display()))?;
    // A directory of its own: a run that finds its name taken is refused, so
    // no run writes into another's files.
    let directory = runs.join(now_ms()?.to_string());
    std::fs::create_dir(&directory)
        .map_err(|cause| format!("cannot create {}: {cause}", directory.display()))?;
    let running = std::env::current_exe()
        .map_err(|cause| format!("this program's own path cannot be read: {cause}"))?;
    let tama = directory.join(PROGRAM_FILE);
    std::fs::copy(&running, &tama).map_err(|cause| {
        format!(
            "cannot copy {} to {}: {cause}",
            running.display(),
            tama.display()
        )
    })?;
    let brief = BRIEF
        .replace("{tama}", &tama.to_string_lossy())
        .replace("{repository}", &repository.to_string_lossy())
        .replace("{index}", &index)
        .replace("{tree}", &tree)
        .replace("{message}", &message.to_string_lossy())
        .replace("{scope}", &scope)
        .replace("{directory}", &directory.to_string_lossy());
    std::fs::write(directory.join(BRIEF_FILE), &brief)
        .map_err(|cause| format!("cannot keep the brief in {}: {cause}", directory.display()))?;
    eprintln!(
        "reviews harsh: a reviewer session reviews tree {tree}; its events are written to {}",
        directory.join(EVENTS_FILE).display()
    );
    let run = Run {
        harness,
        repository,
        index,
        tree,
        before: read(&kept)?.len(),
        register: kept,
    };
    watch::reviewed(&directory, &run, &brief, &text)
}
