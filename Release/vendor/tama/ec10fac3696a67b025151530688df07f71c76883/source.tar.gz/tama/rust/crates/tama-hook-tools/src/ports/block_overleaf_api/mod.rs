//! Logic for `tama-block-overleaf-api`, registry hook id `block-overleaf-api`.
//!
//! Device-level PreToolUse gate: block raw Overleaf API usage. The allowed
//! path is a dedicated Weles UI trajectory that drives Overleaf like a user.
//! The forbidden path is a direct call to an Overleaf project JSON/history
//! endpoint, whether it arrives as a shell command, an inline snippet, or a
//! checked-in helper script the command is about to run.
//!
//! No lifetime annotation or character literal appears below on purpose: the
//! `block-numeric-literals` guard strips strings with a scanner that reads a
//! lifetime tick as an opening quote, which would desync it over the bounded
//! repetitions in the patterns.

use std::path::Path;

use regex::Regex;
use serde_json::Value;
use tama_hooks::session_record::{all_strings, deny_tool_use, read_payload};

use super::check_numeric_literals_payload::{line_at, path_texts};
use super::codex_api_guard as guard;
use super::tool_vocabulary::Call;

const MESSAGE: &str = "YOU FUCKING RETARD USE THE DEDICATED WELES TRAJECTORY NOT THE OVERLEAF API";

const SCAN_EDIT_SUFFIXES: &[&str] = &[
    ".py", ".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx", ".sh", ".ipynb", ".json", ".jsonl",
];

const READ_ONLY_SHELL_COMMANDS: &[&str] = &[
    "sed", "cat", "nl", "less", "head", "tail", "wc", "ls", "find", "jq", "sqlite3",
];

const ALLOWLIST_PATH_FRAGMENTS: &[&str] =
    &["/.codex/hooks/block_overleaf_api.py", "/.codex/hooks.json"];

const SHELL_LABEL: &str = "<shell command>";
const EDIT_LABEL: &str = "<edit payload>";
const NEWLINE: &str = "\n";

const PROJECT_ID: &str = "[0-9a-fA-F]{24}";
const PROJECT_VAR: &str = "\\$\\{?[A-Za-z_][A-Za-z0-9_]*\\}?";
const PROJECT_CONCAT: &str = "['\"]?\\s*\\+\\s*[A-Za-z_][A-Za-z0-9_]*\\s*\\+\\s*['\"]?";
const OVERLEAF_HOST: &str = "(?:https?://(?:www\\.)?overleaf\\.com)?";
const ENDPOINTS: &str = "(?:updates|diff|changes/users|latest/history|entities)";
/// `[\s\S]{0,500}` — the span the Python allows between an HTTP client name
/// and the endpoint it targets.
const CLIENT_GAP: &str = "[\\s\\S]{0,500}";

type Patterns = [(String, Regex)];

fn compiled(reason: &str, pattern: &str) -> (String, Regex) {
    let expression = Regex::new(pattern).expect("forbidden Overleaf pattern must compile");
    (reason.to_string(), expression)
}

/// `FORBIDDEN_PATTERNS`, in source order. Python's `re.I` becomes `(?i)` and
/// `re.DOTALL` becomes `(?s)`; the latter is inert in both languages, since no
/// unescaped `.` appears, but it is kept so the translation reads next to the
/// original.
fn forbidden_patterns() -> Vec<(String, Regex)> {
    let prefix = format!("{OVERLEAF_HOST}/project/(?:{PROJECT_ID}|{PROJECT_VAR}|{PROJECT_CONCAT})");
    let id_or_var = format!("(?:{PROJECT_ID}|{PROJECT_VAR})");
    vec![
        compiled(
            "Overleaf updates endpoint",
            &format!("(?i){prefix}/updates\\b"),
        ),
        compiled("Overleaf diff endpoint", &format!("(?i){prefix}/diff\\b")),
        compiled(
            "Overleaf changes/users endpoint",
            &format!("(?i){prefix}/changes/users\\b"),
        ),
        compiled(
            "Overleaf latest/history endpoint",
            &format!("(?i){prefix}/latest/history\\b"),
        ),
        compiled(
            "Overleaf entities endpoint",
            &format!("(?i){prefix}/entities\\b"),
        ),
        compiled(
            "browser fetch of Overleaf project API",
            &format!("(?is)\\bfetch\\s*\\([^)]*/project/{id_or_var}[^)]*/{ENDPOINTS}\\b"),
        ),
        compiled(
            "HTTP client against Overleaf project API",
            &format!(
                "(?i)\\b(?:curl|wget|httpx?|requests\\.|urllib\\.request|fetch\\()\\b{CLIENT_GAP}\
                 (?:overleaf\\.com)?/project/{id_or_var}[^'\"\\s)]*/{ENDPOINTS}\\b"
            ),
        ),
    ]
}

/// Every forbidden pattern `text` holds, each with the line of each place it
/// matches, as `reason (line N: …; line M: …)`.
fn scan_text(patterns: &Patterns, text: &str, label: &str) -> Vec<String> {
    if guard::is_allowlisted(label, ALLOWLIST_PATH_FRAGMENTS) {
        return Vec::new();
    }
    patterns
        .iter()
        .filter_map(|(reason, pattern)| {
            let places: Vec<String> = pattern
                .find_iter(text)
                .map(|found| line_at(text, found.start()))
                .collect();
            (!places.is_empty()).then(|| format!("{reason} ({})", places.join("; ")))
        })
        .collect()
}

fn report(label: &str, hits: &[String]) -> ! {
    deny_tool_use(&format!(
        "{MESSAGE}\nBLOCKED: raw Overleaf API usage detected in {label}\nmatched: {}",
        guard::matched_list(hits)
    ))
}

fn check_shell(patterns: &Patterns, call: &Call) {
    let Some(command) = call.command() else {
        return;
    };

    let hits = scan_text(patterns, command, SHELL_LABEL);
    if !hits.is_empty() {
        report(SHELL_LABEL, &hits);
    }

    let executable = guard::first_executable(command);
    let cwd = match call.working_dir() {
        Ok(cwd) => cwd,
        Err(error) => deny_tool_use(&format!(
            "{MESSAGE}\nBLOCKED: the scripts this command runs cannot be found: {error}"
        )),
    };
    let scripts = guard::resolve_script_paths(command, &cwd);

    if scripts.is_empty() && READ_ONLY_SHELL_COMMANDS.contains(&executable.as_str()) {
        return;
    }

    for path in scripts {
        let shown = path.to_string_lossy().into_owned();
        if guard::is_allowlisted(&shown, ALLOWLIST_PATH_FRAGMENTS) {
            continue;
        }
        let text = match guard::read_source(&path) {
            Ok(Some(text)) => text,
            Ok(None) => continue,
            Err(cause) => deny_tool_use(&format!("BLOCKED: {cause}")),
        };
        let hits = scan_text(patterns, &text, &shown);
        if !hits.is_empty() {
            report(&shown, &hits);
        }
    }
}

/// Whether a file with this path is one the gate reads: a script, a notebook
/// or a JSON document, and not one of the gate's own sources.
fn scanned_path(label: &str) -> bool {
    if guard::is_allowlisted(label, ALLOWLIST_PATH_FRAGMENTS) {
        return false;
    }
    let suffix = guard::suffix_of(Path::new(label));
    suffix.is_empty() || SCAN_EDIT_SUFFIXES.contains(&suffix.as_str())
}

/// A write is judged by each file as it leaves it — a hashline section, a
/// string edit, a patch or a notebook cell edit replayed on the file, a
/// written file's content — so a call the file already holds is seen on its
/// next edit and text being removed is not judged as written. A write the
/// replay cannot rebuild is refused with the cause, never judged by its
/// fragment. A call that names no tool is judged by everything it carries.
fn check_edit(patterns: &Patterns, data: &Value, call: &Call) {
    let Some(input) = call.input() else {
        if call.name().is_none() {
            let text = all_strings(data).join(NEWLINE);
            let hits = scan_text(patterns, &text, EDIT_LABEL);
            if !hits.is_empty() {
                report(EDIT_LABEL, &hits);
            }
        }
        return;
    };
    let texts = match path_texts(input, call.cwd()) {
        Ok(texts) => texts,
        Err(cause) => deny_tool_use(&format!(
            "{MESSAGE}\nBLOCKED: block-overleaf-api: the file this write leaves cannot be rebuilt to judge it: {cause}"
        )),
    };
    for (path, text) in texts {
        if !scanned_path(&path) {
            continue;
        }
        let hits = scan_text(patterns, &text, &path);
        if !hits.is_empty() {
            report(&path, &hits);
        }
    }
}

pub fn run() {
    let data = read_payload();
    let call = Call::of(&data);
    let patterns = forbidden_patterns();
    let unnamed = call.name().is_none();
    if unnamed || call.is_shell() {
        check_shell(&patterns, &call);
    }
    if unnamed || call.is_write() {
        check_edit(&patterns, &data, &call);
    }
}
