//! Where a recorded run keeps its evidence: frames, DOM dumps, failure
//! states and the visual summary a check requires before it lets an agent
//! read the logs.
//!
//! The checks once spelled that as `<cwd>/.work/<label>/`. The operator's
//! rule is one checkout per repository with nothing of ours written beside
//! the code, and Weles writes its run output to its own state directory. A
//! check still looking at the old path would find nothing, pass every payload
//! and enforce nothing while appearing to work, which is the defect shape this
//! workshop calls a check that measures nothing.
//!
//! `WELES_RUN_OUTPUT_DIR` moves the root, exactly as it does for the
//! trajectories that write there, so a run driven against another root is
//! still checked against the evidence it actually produced.

use std::path::PathBuf;

/// The path segment the payload patterns match, as it appears inside an
/// absolute path: `…/.weles/runs/<label>/frame_<sha8>_001.png`.
pub const EVIDENCE_SEGMENT: &str = r"\.weles/runs";

/// The same segment for a plain `contains` check rather than a regex.
pub const EVIDENCE_PATH_SEGMENT: &str = "/.weles/runs/";

/// The run-output root. `WELES_RUN_OUTPUT_DIR` wins; otherwise the product
/// state directory. A relative override is ignored rather than resolved
/// against whatever directory the hook happens to run in — that ambiguity is
/// the whole reason the old location was abandoned.
pub fn evidence_root() -> PathBuf {
    let configured = std::env::var_os("WELES_RUN_OUTPUT_DIR")
        .map(PathBuf::from)
        .filter(|path| path.is_absolute());
    if let Some(root) = configured {
        return root;
    }
    crate::util::home_dir().join(".weles").join("runs")
}

/// The evidence directory of one label.
pub fn evidence_dir(label: &str) -> PathBuf {
    evidence_root().join(label)
}
