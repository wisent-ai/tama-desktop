//! Two more ways a begged command fails that its usage line cannot show
//! (91924820).
//!
//! A pairing clap enforces with `requires` — `--release-version` needs
//! `--source-commit` — is not in the usage line, so a step can carry every
//! option the line marks and still be refused. A program that offers
//! `--check-arguments` parses the whole line and exits without acting; the
//! step is asked with it.
//!
//! `stado release submit --source <checkout> | --build <id>` only queues a
//! build, so an install of that product's release later in the same chain
//! runs before anything is published and is refused. The product a
//! `--source` submit releases is the checkout's own manifest `product` (and
//! the checkout's name); a `--build` submit names no product on its line, so
//! any release install after it is refused.

use std::path::Path;
use std::process::{Command, Stdio};

/// The option through which a program checks a command line without acting.
const CHECK_ARGUMENTS: &str = "--check-arguments";

/// `step` without the `NAME=value` assignments a shell sets before the program.
pub fn without_assignments(step: &[String]) -> Vec<String> {
    step.iter()
        .skip_while(|word| !word.starts_with('-') && word.contains('='))
        .cloned()
        .collect()
}

/// The refusal `program` gives `step` under `--check-arguments`, when its
/// help offers that option; `None` when it accepts the line or offers no check.
pub fn refused_by_program(step: &[String], program: &Path, help: &str) -> Option<String> {
    if !help.split_whitespace().any(|word| word == CHECK_ARGUMENTS) {
        return None;
    }
    let (_, arguments) = step.split_first()?;
    let mut command = Command::new(program);
    command
        .args(arguments)
        .arg(CHECK_ARGUMENTS)
        .stdin(Stdio::null());
    let output = match stado_wait::output(&mut command) {
        Ok(output) => output,
        Err(error) => {
            return Some(format!(
                "`{}` could not be checked with its own `{CHECK_ARGUMENTS}`: {error}",
                step.join(" ")
            ))
        }
    };
    if output.status.success() {
        return None;
    }
    let said = String::from_utf8_lossy(&output.stderr).into_owned()
        + &String::from_utf8_lossy(&output.stdout);
    let lines: Vec<&str> = said
        .lines()
        .filter(|line| !line.trim().is_empty())
        .collect();
    Some(format!(
        "`{}` is refused by its own `{CHECK_ARGUMENTS}`:\n{}",
        step.join(" "),
        lines.join("\n")
    ))
}

/// The refusal for a chain that installs a product's release after a step
/// that only queued that product's build; `None` otherwise.
pub fn installs_what_it_only_queued(steps: &[Vec<String>]) -> Option<String> {
    let mut queued: Vec<String> = Vec::new();
    let mut queued_build = false;
    for step in steps {
        if let Some(submission) = submitted(step) {
            match submission {
                Submission::Source(names) => queued.extend(names),
                Submission::Build => queued_build = true,
            }
            continue;
        }
        let Some(product) = release_install(step) else {
            continue;
        };
        if queued_build || queued.iter().any(|name| name == product) {
            return Some(format!(
                "`{}` installs a release of {product} after `stado release submit` in the same \
                 command, but a submit only queues the build: nothing is published when the \
                 install runs. Beg with the submit alone, and with the install once \
                 `stado release status {product}` shows the version published",
                step.join(" ")
            ));
        }
    }
    None
}

/// What a `stado release submit` step queues.
enum Submission {
    /// `--source <checkout>`: the checkout's name and its manifest's product.
    Source(Vec<String>),
    /// `--build <id>`: a build whose product the line does not name.
    Build,
}

/// The command path of a Stado step that queues a release build.
const RELEASE_SUBMIT: &str = "release submit";

/// The submission a `stado release submit` step makes, read from its
/// `--source` or `--build` option as the command's usage declares them.
fn submitted(step: &[String]) -> Option<Submission> {
    let (program, words) = step.split_first()?;
    let path: Vec<&str> = RELEASE_SUBMIT.split(' ').collect();
    if !is_stado(program)
        || !words
            .iter()
            .map(String::as_str)
            .take(path.len())
            .eq(path.iter().copied())
    {
        return None;
    }
    let rest = &words[path.len()..];
    if option_value(rest, "--build").is_some() {
        return Some(Submission::Build);
    }
    let source = Path::new(option_value(rest, "--source")?);
    let mut names: Vec<String> = source
        .file_name()
        .map(|name| name.to_string_lossy().into_owned())
        .into_iter()
        .collect();
    // The checkout's own manifest names its product; a manifest that is not
    // there names none, and one that cannot be read or is not JSON is said,
    // since the step is then matched by the folder name alone.
    let path = source.join(".wisent-release.json");
    let manifest = match std::fs::read(&path) {
        Ok(bytes) => {
            match serde_json::from_slice::<serde_json::Value>(&bytes) {
                Ok(document) => Some(document),
                Err(error) => {
                    eprintln!("block-stop-on-own-work: {} is not JSON, so its product is not read: {error}", path.display());
                    None
                }
            }
        }
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => None,
        Err(error) => {
            eprintln!(
                "block-stop-on-own-work: {} cannot be read, so its product is not read: {error}",
                path.display()
            );
            None
        }
    };
    if let Some(product) = manifest
        .as_ref()
        .and_then(|document| document.get("product"))
        .and_then(serde_json::Value::as_str)
    {
        names.push(product.to_owned());
    }
    Some(Submission::Source(names))
}

/// The value of `--name value` or `--name=value` in `words`.
fn option_value<'a>(words: &'a [String], name: &str) -> Option<&'a str> {
    let joined = format!("{name}=");
    words.iter().enumerate().find_map(|(index, word)| {
        if word == name {
            return words.get(index + 1).map(String::as_str);
        }
        word.strip_prefix(&joined)
    })
}

/// The option through which a `stado product` command installs a published
/// release instead of building the product's checkout.
pub const RELEASE_VERSION: &str = "--release-version";

/// The product a `stado product <verb> <product>` step names, and whether the
/// step pins a published release with [`RELEASE_VERSION`]. Which verbs
/// install is not listed here: a step that pins a release is one (Stado
/// refuses the option on any other), and a step that does not is a source
/// build when its own help offers the option (`chain::unformatted_source`).
pub fn product_step(step: &[String]) -> Option<(&str, bool)> {
    match step {
        [program, group, _verb, product, rest @ ..]
            if is_stado(program) && group == "product" && !product.starts_with('-') =>
        {
            let pinned = rest.iter().any(|word| word.starts_with(RELEASE_VERSION));
            Some((product.as_str(), pinned))
        }
        _ => None,
    }
}

/// The product a release-installing `stado product` step installs.
fn release_install(step: &[String]) -> Option<&str> {
    product_step(step)
        .filter(|(_, pinned)| *pinned)
        .map(|(product, _)| product)
}

fn is_stado(program: &str) -> bool {
    Path::new(program)
        .file_name()
        .is_some_and(|name| name == "stado")
}
