//! The telemetry segment writer and its index.

pub mod index;
