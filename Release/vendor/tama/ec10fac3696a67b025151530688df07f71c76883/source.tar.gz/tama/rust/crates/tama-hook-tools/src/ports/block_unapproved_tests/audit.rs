//! `tama tests audit`: how much test code each repository carries, how much
//! of it the operator approved, and — with `--remove` — the deletion of every
//! unapproved test file.
//!
//! Test code is what `block-unapproved-tests` itself refuses: a tracked file
//! whose path follows a test convention ([`is_test_path`]), or a tracked
//! source file that carries a test marker ([`carries_test_code`]). A whole
//! file on a test path is deleted by `--remove` only when it runs as a test
//! by its own contents ([`runs_as_test`]); data and tooling kept under
//! `tests/` are retained as unresolved review paths. A test module inside a
//! source file is listed for its owner to cut out and never deleted, since a
//! file deletion would take the source with it. `node_modules` is skipped.

use std::path::{Path, PathBuf};

use serde_json::{json, Value};

use super::approvals::{self, Approvals};
use super::detect::{carries_test_code, is_test_path};

mod formats;
mod repositories;

use formats::{format_of, runs_as_test, INLINE_TEST_FORMATS};

use tama_core::exit::{FAILURE as EXIT_FAILED, SUCCESS as EXIT_SUCCESS, USAGE as EXIT_USAGE};

/// One repository's test code, split by whether the operator approved it.
struct Audit {
    repository: PathBuf,
    approved: Vec<String>,
    unapproved_files: Vec<String>,
    unapproved_inline: Vec<String>,
    /// Files on a test path that were not identified by `runs_as_test`.
    /// Some are data or helpers, but an executable journey with a plain
    /// filename also lands here. They require review, not a passing audit.
    review: Vec<String>,
}

fn tracked(repository: &Path) -> Result<Vec<String>, String> {
    Ok(tama_core::git::at(repository, &["ls-files", "-z"])?
        .split('\0')
        .filter(|path| !path.is_empty())
        .map(str::to_string)
        .collect())
}

fn audit(repository: &Path, record: &Approvals) -> Result<Audit, String> {
    let mut audit = Audit {
        repository: repository.to_path_buf(),
        approved: Vec::new(),
        unapproved_files: Vec::new(),
        unapproved_inline: Vec::new(),
        review: Vec::new(),
    };
    for relative in tracked(repository)? {
        // A committed dependency tree is another project's code: its tests are
        // that package's, and deleting them changes a dependency, not a product.
        if relative
            .split('/')
            .any(|component| component == "node_modules")
        {
            continue;
        }
        let path = repository.join(&relative);
        let whole_file = is_test_path(&relative);
        // A marker is test code only in the language that runs it: the same
        // text inside a transcript, a log or a page is a quotation. A file that
        // cannot be read as text carries no marker a reader could find.
        let source =
            format_of(&relative).is_some_and(|format| INLINE_TEST_FORMATS.contains(&format));
        let inline = !whole_file
            && source
            && std::fs::read_to_string(&path).is_ok_and(|text| carries_test_code(&text));
        if !whole_file && !inline {
            continue;
        }
        if approvals::covers(record, &path) {
            audit.approved.push(relative);
        } else if whole_file && runs_as_test(&relative, &path) {
            audit.unapproved_files.push(relative);
        } else if whole_file {
            audit.review.push(relative);
        } else {
            audit.unapproved_inline.push(relative);
        }
    }
    Ok(audit)
}

fn remove(audit: &Audit) -> Vec<String> {
    let mut failures = Vec::new();
    for relative in &audit.unapproved_files {
        let path = audit.repository.join(relative);
        if let Err(error) = std::fs::remove_file(&path) {
            failures.push(format!("{}: {error}", path.display()));
        }
    }
    failures
}

fn report(audit: &Audit, removed: bool) -> Value {
    json!({
        "repository": audit.repository.display().to_string(),
        "test_code": audit.approved.len() + audit.unapproved_files.len() + audit.unapproved_inline.len(),
        "approved": audit.approved,
        "unapproved_files": audit.unapproved_files,
        "unapproved_inline": audit.unapproved_inline,
        "review": audit.review,
        "files_removed": removed,
    })
}

/// Every selected repository's audit, the unmarked repositories left out and
/// what could not be read or removed.
struct Gathered {
    audits: Vec<Audit>,
    excluded: Value,
    repositories_read: usize,
    failures: Vec<String>,
    removing: bool,
}

impl Gathered {
    /// Test code the audit leaves behind: unapproved files it did not remove,
    /// inline modules (never deleted whole) and files requiring review.
    fn leaves_code(&self) -> bool {
        self.audits.iter().any(|audit| {
            !audit.unapproved_inline.is_empty()
                || !audit.review.is_empty()
                || (!self.removing && !audit.unapproved_files.is_empty())
        })
    }

    fn document(&self) -> Value {
        let approved: usize = self.audits.iter().map(|audit| audit.approved.len()).sum();
        let unapproved: usize = self
            .audits
            .iter()
            .map(|audit| audit.unapproved_files.len() + audit.unapproved_inline.len())
            .sum();
        let requires_review: usize = self.audits.iter().map(|audit| audit.review.len()).sum();
        let removed: usize = self
            .audits
            .iter()
            .filter(|_| self.removing)
            .map(|audit| audit.unapproved_files.len())
            .sum();
        let rows: Vec<Value> = self
            .audits
            .iter()
            .map(|audit| report(audit, self.removing))
            .collect();
        json!({
            "approval_record": approvals::store().display().to_string(),
            "repositories_read": self.repositories_read,
            "repositories_excluded": self.excluded,
            "approved": approved,
            "unapproved": unapproved,
            "requires_review": requires_review,
            "remaining": unapproved - removed + requires_review,
            "repositories": rows,
            "failures": self.failures,
        })
    }
}

/// Audit explicitly named repositories and product-marked repositories under
/// directory roots, removing identified unapproved test files first when
/// `removing`.
fn gather(roots: &[String], removing: bool) -> Result<Gathered, String> {
    let (repositories, excluded) = repositories::select(roots)?;
    let record = approvals::recorded()?;
    let mut gathered = Gathered {
        audits: Vec::new(),
        excluded: json!(excluded),
        repositories_read: repositories.len(),
        failures: Vec::new(),
        removing,
    };
    for repository in &repositories {
        match audit(repository, &record) {
            Ok(found) => {
                if removing {
                    gathered.failures.extend(remove(&found));
                }
                gathered.audits.push(found);
            }
            Err(error) => gathered.failures.push(error),
        }
    }
    Ok(gathered)
}

/// The audit of explicitly named repositories and product-marked repositories
/// under directory roots as one document, removing identified unapproved test
/// files first when `removing`. `remaining` includes inline modules and
/// unclassified test-path files: neither is silently approved or removed.
pub fn document(roots: &[String], removing: bool) -> Result<Value, String> {
    gather(roots, removing).map(|gathered| gathered.document())
}

/// `tama tests audit [<root>…] [--remove] [--json]`.
pub fn cli_main(args: &[String]) -> i32 {
    let json_output = args.iter().any(|arg| arg == "--json");
    let removing = args.iter().any(|arg| arg == "--remove");
    if let Some(unknown) = args
        .iter()
        .find(|arg| arg.starts_with("--") && *arg != "--json" && *arg != "--remove")
    {
        eprintln!("tama tests audit takes [<root>…] [--remove] [--json]; unknown option {unknown}");
        return EXIT_USAGE;
    }
    let roots: Vec<String> = args
        .iter()
        .filter(|arg| !arg.starts_with("--"))
        .cloned()
        .collect();
    let gathered = match gather(&roots, removing) {
        Ok(gathered) => gathered,
        Err(error) => {
            eprintln!("{error}");
            return EXIT_FAILED;
        }
    };
    let document = gathered.document();
    if json_output {
        println!("{}", tama_core::json::pretty(&document));
    } else {
        for audit in &gathered.audits {
            let test_code =
                audit.approved.len() + audit.unapproved_files.len() + audit.unapproved_inline.len();
            if audit.approved.is_empty()
                && audit.unapproved_files.is_empty()
                && audit.unapproved_inline.is_empty()
                && audit.review.is_empty()
            {
                continue;
            }
            println!(
                "{}: {test_code} test code path(s), {} approved",
                audit.repository.display(),
                audit.approved.len()
            );
            let verb = if removing {
                "removed"
            } else {
                "unapproved file"
            };
            for file in &audit.unapproved_files {
                println!("  {verb} {file}");
            }
            for file in &audit.unapproved_inline {
                println!("  unapproved test module inside {file} (cut it out of the source; never deleted whole)");
            }
            for file in &audit.review {
                println!("  unclassified test-path file, kept for review: {file}");
            }
        }
        println!(
            "{} approved, {} unapproved, {} requiring review across {} repositories ({} unmarked repositories excluded); approvals: {}",
            document["approved"],
            document["unapproved"],
            document["requires_review"],
            gathered.repositories_read,
            gathered.excluded,
            approvals::store().display()
        );
        for failure in &gathered.failures {
            eprintln!("{failure}");
        }
    }
    if !gathered.failures.is_empty() || gathered.leaves_code() {
        EXIT_FAILED
    } else {
        EXIT_SUCCESS
    }
}
