//! The summary a proposal is read from: what failed, where the hook lives,
//! and the command that applies it.
//!
//! Split out of `doctor/repair.rs`, which had grown past the
//! three-hundred-line limit.

use crate::util::js_string;

/// `summaryText(report)`.
pub(super) fn summary_text(report: &serde_json::Value) -> String {
    let failures = report.get("failures").and_then(|v| v.as_array());
    // A field the report does not carry is said as not recorded, by name;
    // never "undefined" or "unknown", which read as values.
    let stated =
        |value: Option<&serde_json::Value>, name: &str| match value.filter(|v| !v.is_null()) {
            Some(value) => js_string(value),
            None => format!("(no {name} recorded)"),
        };
    let fail_lines: Vec<String> = match failures {
        Some(list) if !list.is_empty() => list
            .iter()
            .map(|failure| {
                format!(
                    "- {}: {}",
                    stated(failure.get("kind"), "kind"),
                    stated(failure.get("detail"), "detail")
                )
            })
            .collect(),
        _ => vec!["- none".to_string()],
    };
    let render = |key: &str, name: &str| stated(report.get(key), name);
    let mut lines = vec![
        format!("# Repair proposal: {}", render("hookId", "hook id")),
        String::new(),
        format!("Live path: {}", render("livePath", "live path")),
        format!("Archive path: {}", render("archivePath", "archive path")),
        format!("Corpus runs: {}", render("checked", "corpus run count")),
        String::new(),
        "## Validation failures".to_string(),
    ];
    lines.extend(fail_lines);
    lines.push(String::new());
    lines.push(format!(
        "Apply with: doctor apply {}",
        render("proposalDir", "proposal directory")
    ));
    lines.push(
        "Requires DEVICE_HOOK_EDIT_APPROVED set by the owner outside the session.".to_string(),
    );
    lines.push(String::new());
    lines.join("\n")
}
