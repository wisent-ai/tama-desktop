//! The hook is detached, so its recorded outcome is the only evidence that a
//! draft actually reached the gateway. A successful models probe is not proof.

const LOG: &str = ".shared-hooks/auto_rules.log";
/// Where the RFC 3339 date-time the hook stamps each line with
/// (`YYYY-MM-DDTHH:MM:SS…`) carries its first `-` and its `T`.
/// https://www.rfc-editor.org/rfc/rfc3339#section-5.6
const YEAR_END: usize = 4;
const DATE_END: usize = 10;

/// The newest drafting outcome the detached hook logged, when it is a
/// failure. The whole log is read: a window cut at a guessed size could end
/// before the newest failure's line began and read it as no failure.
pub(super) fn failure() -> Option<String> {
    let Some(home) = std::env::var_os("HOME").filter(|home| !home.is_empty()) else {
        return Some(format!("HOME is not set, so ~/{LOG} cannot be read"));
    };
    let path = std::path::PathBuf::from(home).join(LOG);
    let bytes = match std::fs::read(&path) {
        Ok(bytes) => bytes,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return None,
        Err(error) => return Some(format!("cannot read {}: {error}", path.display())),
    };
    let text = String::from_utf8_lossy(&bytes);
    for line in text.lines().rev() {
        let Some((stamp, outcome)) = line.split_once(" | ") else {
            continue;
        };
        let at = stamp.as_bytes();
        if at.get(YEAR_END) != Some(&b'-') || at.get(DATE_END) != Some(&b'T') {
            continue;
        }
        for failed in [
            "CLASSIFY_FAILED",
            "DRAFT_REFUSED",
            "NOT_RECORDED",
            "DISPATCH_FAILED",
            "NO_SELF_PATH",
        ] {
            if outcome == failed
                || outcome
                    .strip_prefix(failed)
                    .is_some_and(|rest| rest.starts_with(' '))
            {
                return Some(format!("{stamp}: {outcome}"));
            }
        }
        if outcome == "NOT_FRUSTRATED"
            || outcome.starts_with("RECORDED ")
            || outcome.starts_with("LOW_CONF ")
        {
            return None;
        }
    }
    None
}
