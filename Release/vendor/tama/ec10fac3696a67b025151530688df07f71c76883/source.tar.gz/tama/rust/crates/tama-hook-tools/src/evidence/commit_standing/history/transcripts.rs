//! The commit calls the session transcripts hold: each OMP `bash` call whose
//! command names `commit` and a repository, with when it was made and when
//! its result came back.

use std::collections::HashMap;
use std::io::BufRead;
use std::path::{Path, PathBuf};
use std::time::{Duration, UNIX_EPOCH};

use serde_json::Value;

/// One shell call of a session that may have made a commit, with when it was
/// made and when its result came back, in seconds since the epoch.
pub(super) struct Call {
    pub(super) session: String,
    pub(super) started: i64,
    pub(super) answered: i64,
}

/// Every shell call, in every transcript written since `earliest`, whose
/// command names `commit` and the repository at `root`.
pub(super) fn commit_calls(root: &Path, earliest: i64) -> Result<Vec<Call>, String> {
    let seconds = u64::try_from(earliest)
        .map_err(|error| format!("commit time {earliest} precedes the epoch: {error}"))?;
    let since = UNIX_EPOCH + Duration::from_secs(seconds);
    let name = root
        .file_name()
        .and_then(|name| name.to_str())
        .ok_or_else(|| {
            format!(
                "the repository {} has no name a command could carry",
                root.display()
            )
        })?;
    let mut transcripts = Vec::new();
    for directory in tama_hooks::session_record::live_roots() {
        collect(&directory, since, &mut transcripts)?;
    }
    let mut calls = Vec::new();
    for transcript in transcripts {
        calls.extend(calls_in(&transcript, name)?);
    }
    Ok(calls)
}

/// Every transcript below `directory` written since `since`. A folder named
/// after a transcript beside it holds that transcript's artifacts, not
/// sessions, and is not entered; a harness root that does not exist holds
/// no session.
fn collect(
    directory: &Path,
    since: std::time::SystemTime,
    found: &mut Vec<PathBuf>,
) -> Result<(), String> {
    let entries = match std::fs::read_dir(directory) {
        Ok(entries) => entries,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(()),
        Err(error) => {
            return Err(format!(
                "cannot list session transcripts in {}: {error}",
                directory.display()
            ))
        }
    };
    for entry in entries {
        let path = entry
            .map_err(|error| format!("cannot read an entry of {}: {error}", directory.display()))?
            .path();
        if path.is_dir() {
            if !path.with_extension("jsonl").is_file() {
                collect(&path, since, found)?;
            }
            continue;
        }
        if path.extension().and_then(|extension| extension.to_str()) != Some("jsonl") {
            continue;
        }
        let modified = std::fs::metadata(&path)
            .and_then(|metadata| metadata.modified())
            .map_err(|error| format!("cannot read when {} was written: {error}", path.display()))?;
        if modified >= since {
            found.push(path);
        }
    }
    Ok(())
}

/// The session a transcript is of: its file name after the last `_`.
fn session_of(path: &Path) -> Option<String> {
    let stem = path.file_stem()?.to_str()?;
    let (_, session) = stem.rsplit_once('_')?;
    Some(session.to_string())
}

/// The shell calls of one transcript whose command names `commit` and
/// `repository` and whose result came back.
fn calls_in(path: &Path, repository: &str) -> Result<Vec<Call>, String> {
    let Some(session) = session_of(path) else {
        return Ok(Vec::new());
    };
    let file = std::fs::File::open(path)
        .map_err(|error| format!("cannot open {}: {error}", path.display()))?;
    let mut pending: HashMap<String, i64> = HashMap::new();
    let mut calls = Vec::new();
    for line in std::io::BufReader::new(file).lines() {
        let line = line.map_err(|error| format!("cannot read {}: {error}", path.display()))?;
        let calls_commit =
            line.contains("\"toolCall\"") && line.contains("commit") && line.contains(repository);
        let answers = !pending.is_empty() && line.contains("\"toolResult\"");
        if !calls_commit && !answers {
            continue;
        }
        let record: Value = serde_json::from_str(&line)
            .map_err(|error| format!("a line of {} is not JSON: {error}", path.display()))?;
        let message = &record["message"];
        if message["role"] == "toolResult" {
            let Some(started) = message["toolCallId"]
                .as_str()
                .and_then(|id| pending.remove(id))
            else {
                continue;
            };
            let millis = message["timestamp"].as_i64().ok_or_else(|| {
                format!(
                    "a result in {} carries no time in milliseconds",
                    path.display()
                )
            })?;
            let answered = tama_core::clock::from_millis(millis)?.timestamp();
            calls.push(Call {
                session: session.clone(),
                started,
                answered,
            });
            continue;
        }
        if message["role"] != "assistant" {
            continue;
        }
        let Some(stamp) = record["timestamp"].as_str() else {
            return Err(format!("a call in {} carries no time", path.display()));
        };
        let started = tama_core::clock::parse(stamp)
            .map_err(|cause| {
                format!(
                    "a call in {} has an unreadable time: {cause}",
                    path.display()
                )
            })?
            .timestamp();
        for content in message["content"].as_array().into_iter().flatten() {
            let names_commit = content["arguments"]["command"]
                .as_str()
                .is_some_and(|command| command.contains("commit") && command.contains(repository));
            if content["type"] == "toolCall" && content["name"] == "bash" && names_commit {
                if let Some(id) = content["id"].as_str() {
                    pending.insert(id.to_string(), started);
                }
            }
        }
    }
    Ok(calls)
}
