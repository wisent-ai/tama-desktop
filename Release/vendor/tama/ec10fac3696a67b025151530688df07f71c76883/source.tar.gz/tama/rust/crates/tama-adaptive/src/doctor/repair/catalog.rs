//! The minimal `src/core/catalog.mjs` surface the doctor needs: where a
//! command's source lives, the hooks the registry declares, and finding one.
//!
//! Split out of `doctor/repair.rs`, which had grown past the
//! three-hundred-line limit.

use std::collections::BTreeMap;
use std::fs;
use std::path::Path;

use tama_core::registry::Registry;

/// `commandSourcePath(command)` from `src/core/catalog.mjs`: the source in
/// the Tama checkout `root` of the hook script `command` runs, by the
/// directory each harness installs hook scripts into.
pub fn command_source_path(command: &str, root: &Path) -> Option<String> {
    let home = crate::util::home_dir();
    let installed = [
        (home.join(".shared-hooks"), "shared-hooks/"),
        (home.join(".codex/hooks"), "codex-hooks/"),
        (home.join(".claude/hooks"), "claude-hooks/"),
        (root.join("shared-hooks"), "shared-hooks/"),
        (root.join("codex-hooks"), "codex-hooks/"),
        (root.join("claude-hooks"), "claude-hooks/"),
    ];
    installed.iter().find_map(|(folder, repo_dir)| {
        let prefix = format!("{}/", folder.display());
        let (_, rest) = command.split_once(prefix.as_str())?;
        let script = rest.split_whitespace().next()?;
        Some(format!("{repo_dir}{script}"))
    })
}

/// The catalog view the doctor needs (`buildCatalog().hooks`).
#[derive(Debug, Clone)]
pub struct CatalogHook {
    pub id: String,
    /// The command the registry runs the hook with, when it names one.
    pub command: Option<String>,
    pub source_path: Option<String>,
}

/// The repository's hook registry. One that cannot be read or parsed is an
/// error naming the file: read as declaring no hooks, the doctor would report
/// no drift and find no hook to repair, and say nothing about why.
fn load_repo_registry(root: &Path) -> Result<Registry, String> {
    let path = root.join("shared-hooks").join("registry.json");
    let text = fs::read_to_string(&path)
        .map_err(|error| format!("cannot read the hook registry {}: {error}", path.display()))?;
    serde_json::from_str(&text)
        .map_err(|error| format!("{} is not a hook registry: {error}", path.display()))
}

/// `buildCatalog(root).hooks` reduced to id/command/sourcePath, sorted by
/// id. A hook bound to several events keeps the first command and the
/// first source any binding names.
pub fn build_catalog_hooks(root: &Path) -> Result<Vec<CatalogHook>, String> {
    let registry = load_repo_registry(root)?;
    let mut by_id: BTreeMap<String, CatalogHook> = BTreeMap::new();
    for hook in registry.events.values().flat_map(|event| &event.hooks) {
        let command = hook.command.clone().filter(|command| !command.is_empty());
        let source = [&hook.source, &command]
            .into_iter()
            .flatten()
            .find_map(|named| command_source_path(named, root));
        let entry = by_id.entry(hook.id.clone()).or_insert_with(|| CatalogHook {
            id: hook.id.clone(),
            command,
            source_path: None,
        });
        if entry.source_path.is_none() {
            entry.source_path = source;
        }
    }
    Ok(by_id.into_values().collect())
}

/// `findHook(id, root)`.
pub fn find_hook(id: &str, root: &Path) -> Result<Option<CatalogHook>, String> {
    Ok(build_catalog_hooks(root)?
        .into_iter()
        .find(|hook| hook.id == id))
}
