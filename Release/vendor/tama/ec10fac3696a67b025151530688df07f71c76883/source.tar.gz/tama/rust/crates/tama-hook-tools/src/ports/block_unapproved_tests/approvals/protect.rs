//! The operator's record kept from removal by anything but its replacement.
//!
//! A session once removed the record with a shell loop that ran `rm` on every
//! word another command printed; the record's path was one of those words,
//! and nothing named it for the hook to refuse. The record and its previous
//! copy carry the user-immutable flag (`chflags(2)`, `UF_IMMUTABLE`), so the
//! kernel refuses to remove, rename or rewrite them; only [`super::view`]
//! lifts the flag for the moment it renames the replacement into place.

use std::path::Path;

/// Set or lift the user-immutable flag on `path`, keeping every other flag
/// it carries. A file that does not exist has nothing to keep.
#[cfg(target_os = "macos")]
pub(super) fn immutable(path: &Path, on: bool) -> Result<(), String> {
    use std::os::macos::fs::MetadataExt;
    use std::os::unix::ffi::OsStrExt;
    let flags = match std::fs::symlink_metadata(path) {
        Ok(metadata) => metadata.st_flags(),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(()),
        Err(error) => return Err(format!("{} cannot be examined: {error}", path.display())),
    };
    let wanted = if on {
        flags | libc::UF_IMMUTABLE
    } else {
        flags & !libc::UF_IMMUTABLE
    };
    if wanted == flags {
        return Ok(());
    }
    let named = std::ffi::CString::new(path.as_os_str().as_bytes())
        .map_err(|error| format!("{} cannot be named to the kernel: {error}", path.display()))?;
    // SAFETY: `named` is a NUL-terminated path that lives across the call.
    let answer = unsafe { libc::chflags(named.as_ptr(), wanted) };
    if answer == 0 {
        return Ok(());
    }
    let action = if on {
        "kept from removal"
    } else {
        "released for its replacement"
    };
    Err(format!(
        "{} cannot be {action}: {}",
        path.display(),
        std::io::Error::last_os_error()
    ))
}

#[cfg(not(target_os = "macos"))]
pub(super) fn immutable(path: &Path, _: bool) -> Result<(), String> {
    Err(format!(
        "{} is kept from removal with the macOS user-immutable flag, which this system does \
         not have",
        path.display()
    ))
}
