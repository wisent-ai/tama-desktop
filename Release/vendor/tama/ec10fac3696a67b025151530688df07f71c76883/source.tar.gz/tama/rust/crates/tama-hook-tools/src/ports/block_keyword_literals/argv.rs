//! A command line bound to a name is not a vocabulary.
//!
//! `let args = ["build", "status", id.as_str(), "--json"]` binds a run of
//! two quoted words, which reads like a table the program keeps; it is the
//! argument vector of a process the next line runs. What tells the two
//! apart is the collection around the run: a vocabulary is words and
//! nothing else, while a command line carries a value computed elsewhere or
//! an option (`--json`) among its words. A command line built a step at a
//! time (`var args = ["crawl", "start"]`, then `args.append("--catalog")`)
//! carries its options in the later steps, so the binding's later calls
//! that hand it an option are read as its members. A binding the program
//! later hands to a process as its arguments (`process.arguments = args`,
//! `command.args(&args)`, `spawn(file, args)`) is that command line whatever
//! words it holds. A collection the program then asks a question where it
//! stands (`[…].contains(x)`) is consulted, so it stays a classifier
//! whatever it holds.

use super::finder::is_word;

const OPENERS: &str = "[({";
const CLOSERS: &str = "])}";
const QUOTES: &str = "\"'";

/// Whether the run of quoted words at `start..end` sits in a collection that
/// also holds something other than a quoted word, and is not consulted where
/// it stands.
pub(super) fn argument_vector(text: &str, start: usize, end: usize) -> bool {
    let (Some(open), Some(close)) = (opener(&text[..start]), closer(&text[end..])) else {
        return false;
    };
    let close = end + close;
    let after = text[close..]
        .trim_start_matches(|c| CLOSERS.contains(c))
        .trim_start();
    if after.starts_with('.') || after.starts_with('?') {
        return false;
    }
    members(&text[open..close])
        .iter()
        .any(|member| !quoted_word(member))
        || bound_name(text, open).is_some_and(|name| {
            grown_with_options(text, name, close) || handed_to_process(text, name, close)
        })
}

/// The name the collection opening at `open` (just past its bracket) is
/// bound to: `let args = [`, `var args: [String] = [`, `args = [`; `None`
/// when it is not the right side of an assignment.
fn bound_name(text: &str, open: usize) -> Option<&str> {
    let assigned = text[..open]
        .strip_suffix(|character: char| OPENERS.contains(character))?
        .trim_end()
        .strip_suffix('=')?;
    if assigned.ends_with(|character: char| "=!<>".contains(character)) {
        return None;
    }
    let statement = assigned.rsplit(['\n', ';']).next()?;
    let target = statement.split(':').next()?.trim_end();
    let name = match target
        .char_indices()
        .rev()
        .find(|(_, character)| !(character.is_alphanumeric() || *character == '_'))
    {
        Some((at, character)) => &target[at + character.len_utf8()..],
        None => target,
    };
    (!name.is_empty()).then_some(name)
}

/// Whether, after `from`, the program hands `name` an option: a call on it
/// (`args.append("--catalog")`) or an addition to it (`args += ["--json"]`)
/// whose first argument is a quoted word starting with `-`.
fn grown_with_options(text: &str, name: &str, from: usize) -> bool {
    let rest = &text[from..];
    rest.match_indices(name).any(|(at, _)| {
        let joined = rest[..at]
            .chars()
            .next_back()
            .is_some_and(|character| character.is_alphanumeric() || character == '_');
        if joined {
            return false;
        }
        let after = rest[at + name.len()..].trim_start();
        let argument = match after.strip_prefix('.') {
            Some(call) => call
                .trim_start_matches(|character: char| {
                    character.is_alphanumeric() || character == '_'
                })
                .strip_prefix('('),
            None => after
                .strip_prefix("+=")
                .and_then(|added| added.trim_start().strip_prefix('[')),
        };
        argument.is_some_and(|argument| {
            let argument = argument.trim_start();
            QUOTES.chars().any(|quote| {
                argument
                    .strip_prefix(quote)
                    .is_some_and(|inner| inner.starts_with('-'))
            })
        })
    })
}

/// Whether, after `from`, the program hands `name` to a process as its
/// argument vector, whatever words it holds: Foundation's
/// `process.arguments = name`, Rust's `command.args(name)` or
/// `.args(&name)`, Node's `spawn(file, name)` or `execFile(file, name)` and
/// their `Sync` forms.
/// https://developer.apple.com/documentation/foundation/process/arguments
/// https://doc.rust-lang.org/std/process/struct.Command.html#method.args
/// https://nodejs.org/api/child_process.html#child_processspawncommand-args-options
fn handed_to_process(text: &str, name: &str, from: usize) -> bool {
    let name = regex::escape(name);
    let handed = [
        format!("\\.arguments\\s*=\\s*{name}\\b"),
        format!("\\.args\\(\\s*&?\\s*{name}\\b"),
        format!("\\b(?:spawn|execFile)(?:Sync)?\\([^,()]*,\\s*{name}\\b"),
    ];
    handed.iter().any(|pattern| {
        regex::Regex::new(pattern)
            .expect("an escaped name keeps the argument pattern valid")
            .is_match(&text[from..])
    })
}

/// Where the collection holding `before`'s end opens: just past its unmatched
/// opening bracket.
fn opener(before: &str) -> Option<usize> {
    let mut nested: Vec<char> = Vec::new();
    for (at, character) in before.char_indices().rev() {
        if CLOSERS.contains(character) {
            nested.push(character);
        } else if OPENERS.contains(character) && nested.pop().is_none() {
            return Some(at + character.len_utf8());
        }
    }
    None
}

/// Where the collection holding `after`'s start closes: the offset of its
/// unmatched closing bracket.
fn closer(after: &str) -> Option<usize> {
    let mut nested: Vec<char> = Vec::new();
    for (at, character) in after.char_indices() {
        if OPENERS.contains(character) {
            nested.push(character);
        } else if CLOSERS.contains(character) && nested.pop().is_none() {
            return Some(at);
        }
    }
    None
}

/// The collection's members: its text split on the commas that stand
/// outside any quote or nested bracket.
fn members(body: &str) -> Vec<String> {
    let mut found = Vec::new();
    let mut current = String::new();
    let mut nested: Vec<char> = Vec::new();
    let mut quote: Option<char> = None;
    for character in body.chars() {
        match quote {
            Some(open) if character == open => quote = None,
            Some(_) => {}
            None if QUOTES.contains(character) => quote = Some(character),
            None if OPENERS.contains(character) => nested.push(character),
            None if CLOSERS.contains(character) => {
                nested.pop();
            }
            None if character == ',' && nested.is_empty() => {
                found.push(std::mem::take(&mut current));
                continue;
            }
            None => {}
        }
        current.push(character);
    }
    found.push(current);
    found
        .into_iter()
        .map(|member| member.trim().to_owned())
        .filter(|member| !member.is_empty())
        .collect()
}

/// A member that is one quoted word or phrase, nothing around it.
fn quoted_word(member: &str) -> bool {
    QUOTES.chars().any(|quote| {
        member
            .strip_prefix(quote)
            .and_then(|inner| inner.strip_suffix(quote))
            .is_some_and(is_word)
    })
}
