use super::reply::{json_body, send_error, send_json, Reply, Request};
use http::StatusCode;
use serde_json::Value;

pub(super) fn inspect(request: Request, writer: &mut Reply) {
    let body = match json_body(&request) {
        Ok(body) => body,
        Err((status, cause)) => return send_error(writer, status, &cause),
    };
    let document = match request.operation.as_str() {
        "reviews/list" => crate::reviews::list().and_then(|listing| {
            serde_json::to_value(listing)
                .map_err(|cause| format!("cannot encode retained review listing: {cause}"))
        }),
        "reviews/show" => {
            let Some(id) = body.get("id").and_then(Value::as_str) else {
                return send_error(
                    writer,
                    StatusCode::BAD_REQUEST.as_u16(),
                    "reviews/show requires id: one exact entry from tama reviews list",
                );
            };
            let record = match crate::reviews::show(id) {
                Ok(record) => record,
                Err(crate::reviews::ShowError::InvalidId(cause)) => {
                    return send_error(writer, StatusCode::BAD_REQUEST.as_u16(), &cause);
                }
                Err(crate::reviews::ShowError::Directory(cause)) => {
                    return send_error(writer, StatusCode::INTERNAL_SERVER_ERROR.as_u16(), &cause);
                }
            };
            serde_json::to_value(record)
                .map_err(|cause| format!("cannot encode retained review record: {cause}"))
        }
        "reviews/harsh" => {
            let Some(repository) = body.get("repository").and_then(Value::as_str) else {
                return send_error(
                    writer,
                    StatusCode::BAD_REQUEST.as_u16(),
                    "reviews/harsh requires repository: the checkout whose commit is being made",
                );
            };
            let message = body.get("message").and_then(Value::as_str);
            crate::reviews::harsh::rounds_document(std::path::Path::new(repository), message)
                .map(|(document, _)| document)
        }
        "reviews/admitted" => {
            let (Some(repository), Some(commit)) = (
                body.get("repository").and_then(Value::as_str),
                body.get("commit").and_then(Value::as_str),
            ) else {
                return send_error(
                    writer,
                    StatusCode::BAD_REQUEST.as_u16(),
                    "reviews/admitted requires repository and commit: the checkout and the commit \
                     whose admission is read",
                );
            };
            let repository = std::path::Path::new(repository);
            tama_hook_tools::evidence::admission::admitted(repository, commit).and_then(|found| {
                serde_json::to_value(found)
                    .map_err(|cause| format!("cannot encode the commit's admission: {cause}"))
            })
        }
        "reviews/cutover" => {
            let Some(repository) = body.get("repository").and_then(Value::as_str) else {
                return send_error(
                    writer,
                    StatusCode::BAD_REQUEST.as_u16(),
                    "reviews/cutover requires repository: the checkout whose admission cutover is read",
                );
            };
            // `cutover` is null while review-commit admitted no commit there.
            tama_hook_tools::evidence::admission::cutover(std::path::Path::new(repository))
                .and_then(|kept| {
                    serde_json::to_value(serde_json::json!({ "cutover": kept }))
                        .map_err(|cause| format!("cannot encode the admission cutover: {cause}"))
                })
        }
        operation => Err(format!(
            "unsupported retained review operation {operation:?}"
        )),
    };
    match document {
        Ok(document) => send_json(writer, StatusCode::OK.as_u16(), &document),
        Err(cause) => send_error(writer, StatusCode::INTERNAL_SERVER_ERROR.as_u16(), &cause),
    }
}
