//! UUIDv4 from the system's random source, laid out as RFC 9562 gives the
//! version and variant bits.

use std::io::Read;

/// The system's random source every UUID is read from.
const RANDOM_SOURCE: &str = "/dev/urandom";
/// Bytes in a UUID: https://www.rfc-editor.org/rfc/rfc9562#section-4
const UUID_BYTES: usize = 16;
/// The byte whose high nibble holds the version:
/// https://www.rfc-editor.org/rfc/rfc9562#section-5.4
const VERSION_BYTE: usize = 6;
/// The bits of that byte the version leaves random:
/// https://www.rfc-editor.org/rfc/rfc9562#section-5.4
const VERSION_KEPT: u8 = 0x0f;
/// Version 4 in the high nibble:
/// https://www.rfc-editor.org/rfc/rfc9562#section-5.4
const VERSION_FOUR: u8 = 0x40;
/// The byte whose two high bits hold the variant:
/// https://www.rfc-editor.org/rfc/rfc9562#section-4.1
const VARIANT_BYTE: usize = 8;
/// The bits of that byte the variant leaves random:
/// https://www.rfc-editor.org/rfc/rfc9562#section-4.1
const VARIANT_KEPT: u8 = 0x3f;
/// The RFC variant in the two high bits:
/// https://www.rfc-editor.org/rfc/rfc9562#section-4.1
const VARIANT_RFC: u8 = 0x80;
/// The hex digits of each dash-separated group of a written UUID:
/// https://www.rfc-editor.org/rfc/rfc9562#section-4
const GROUPS: [usize; 5] = [8, 4, 4, 4, 12];

/// JS `crypto.randomUUID()` (UUIDv4, lowercase), or why the random source
/// could not give one. A source that cannot be read is the error: mixed
/// from the time and process id instead, names two processes could share.
pub fn random_uuid() -> Result<String, String> {
    let wanted = u64::try_from(UUID_BYTES).map_err(|error| error.to_string())?;
    let mut bytes = Vec::with_capacity(UUID_BYTES);
    std::fs::File::open(RANDOM_SOURCE)
        .and_then(|file| file.take(wanted).read_to_end(&mut bytes))
        .map_err(|error| format!("cannot read a UUID from {RANDOM_SOURCE}: {error}"))?;
    if bytes.len() != UUID_BYTES {
        return Err(format!(
            "{RANDOM_SOURCE} gave {} of the {UUID_BYTES} bytes a UUID needs",
            bytes.len()
        ));
    }
    bytes[VERSION_BYTE] = (bytes[VERSION_BYTE] & VERSION_KEPT) | VERSION_FOUR;
    bytes[VARIANT_BYTE] = (bytes[VARIANT_BYTE] & VARIANT_KEPT) | VARIANT_RFC;
    let hex: String = bytes.iter().map(|byte| format!("{byte:02x}")).collect();
    let mut rest = hex.as_str();
    let mut groups = Vec::with_capacity(GROUPS.len());
    for width in GROUPS {
        let (group, after) = rest.split_at(width);
        groups.push(group);
        rest = after;
    }
    Ok(groups.join("-"))
}
