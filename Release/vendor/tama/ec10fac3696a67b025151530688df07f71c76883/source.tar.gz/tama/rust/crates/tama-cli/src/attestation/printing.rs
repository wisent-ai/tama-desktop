//! What `tama attestation` prints for a person; `--json` prints the report
//! itself instead.

use serde_json::Value;

/// The usage text of `tama attestation`, printed with every usage refusal.
pub(super) const USAGE: &str =
    "usage: tama attestation standard (--commit | --turn | --session ID) [--json]
       tama attestation check (--commit REV [--repository PATH] | --turn HOOK --file PATH) [--json]
       tama attestation attest --commit REV --file PATH [--repository PATH] [--json]
       tama attestation pending [--repository PATH] [--json]
       tama attestation unjudged [--repository PATH] [--json]
       tama attestation record --file PATH --session ID [--json]
       tama attestation record --kind KIND --subject SUBJECT --statement TEXT [--json]
       tama attestation show --session ID [--json]
       tama attestation remove --session ID [--json]
       tama attestation list [--kind session|file|cua|ssh|test|build] [--json]
       tama attestation verify [--kind KIND] [--subject SUBJECT] [--json]
       tama attestation revoke --kind KIND --subject SUBJECT [--json]
       tama attestation migrate [--json]";

/// What `verb` answered, as a person reads it; `session_standard` when
/// `standard` printed a session's task standard.
pub(super) fn print_human(verb: &str, report: &Value, session_standard: bool) {
    match verb {
        "list" => {
            let mut any = false;
            for record in report.as_array().into_iter().flatten() {
                any = true;
                print_record(record);
            }
            if !any {
                println!("attestation: no attestation is recorded");
            }
        }
        "verify" => {
            for each in report.as_array().into_iter().flatten() {
                print_verified(each);
            }
        }
        "migrate" => println!(
            "attestation: brought {} attestation(s) into the ledger {}",
            text(report, "brought"),
            text(report, "ledger")
        ),
        "revoke" => println!(
            "attestation: revoked the {} attestation of {}",
            text(report, "kind"),
            text(report, "subject")
        ),
        "record" if report.get("registry").is_some() => println!(
            "attestation: recorded the {} attestation of {} in {}",
            text(report, "kind"),
            text(report, "recorded"),
            text(report, "registry")
        ),
        "remove" => {
            if let Some(path) = report["removed"].as_str() {
                println!("attestation: removed {path}");
            }
        }
        "standard" if session_standard => print_session_standard(report),
        "standard" => super::carried::print_standard(report),
        "check" => super::carried::print_checked(report),
        "attest" => super::carried::print_checked(report),
        "pending" => super::carried::pending::print_pending(report),
        "unjudged" => super::carried::unjudged::print_unjudged(report),
        _ => print_report(report),
    }
}

/// One field of a report as a person reads it: a string without its quotes.
fn text(value: &Value, field: &str) -> String {
    match &value[field] {
        Value::String(text) => text.clone(),
        other => other.to_string(),
    }
}

/// A judged session record: whether it stands, every refusal, where it is
/// kept.
fn print_report(report: &Value) {
    let named = match (report["kind"].as_str(), report["id"].as_str()) {
        (Some(kind), Some(id)) => format!("{kind} {id}"),
        _ => report.to_string(),
    };
    match report["stands"].as_bool() {
        Some(true) => println!("attestation: {named} stands"),
        _ => println!("attestation: {named} does not stand"),
    }
    for refusal in report["refusals"].as_array().into_iter().flatten() {
        if let Some(refusal) = refusal.as_str() {
            println!("attestation: {refusal}");
        }
    }
    if let Some(path) = report["recorded"].as_str() {
        println!("attestation: recorded at {path}");
    }
    match report.get("review") {
        Some(Value::String(why)) => println!("attestation: its harsh review: {why}"),
        Some(Value::Null) => println!("attestation: passed by a reviewer other than its author"),
        _ => {}
    }
}

/// One registry record as a person reads it: who attests what, verified how.
/// The fields are the record's own JSON values, strings without their quotes.
fn print_record(record: &Value) {
    println!(
        "attestation: {} {} by the {}, verified by {}, from {}",
        text(record, "kind"),
        text(record, "subject"),
        text(record, "attester"),
        text(record, "verification"),
        text(record, "store")
    );
}

/// One verification: the record, and what fails when it does not verify. A
/// disagreement between the ledger and a view carries no record.
fn print_verified(each: &Value) {
    if !each["record"].is_null() {
        print_record(&each["record"]);
    }
    match each["failure"].as_str() {
        Some(failure) => println!("attestation:   does not verify: {failure}"),
        None => println!("attestation:   verifies"),
    }
}

/// The task standard a session's recorded attestation confirms.
fn print_session_standard(report: &Value) {
    let standard = &report["standard"];
    for claim in standard["required"].as_array().into_iter().flatten() {
        println!("attestation: claim {}: {}", claim["key"], claim["claim"]);
    }
    for list in standard["must_be_empty"].as_array().into_iter().flatten() {
        println!("attestation: empty {}: {}", list["key"], list["why"]);
    }
    for list in standard["must_name"].as_array().into_iter().flatten() {
        println!("attestation: name {}: {}", list["key"], list["why"]);
    }
}
