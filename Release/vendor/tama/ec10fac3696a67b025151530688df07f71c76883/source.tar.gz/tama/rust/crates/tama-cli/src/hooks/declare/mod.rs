//! `tama hooks declare --file <declaration.json>`: put one hook into the
//! catalogue, the registry and the seal, in the documented order, with one
//! command.
//!
//! Adding a hook takes four writers in a fixed order — `record-hook-metadata`,
//! `shared-hooks/register-hook.mjs`, `reconcile-registry-sources`,
//! `shared-hooks/seal-registry.mjs` — and the order is not a preference: the
//! registry writer refuses a hook the catalogue does not describe, and the
//! seal refuses a release whose source entry does not resolve. The hook is
//! described once, as data in the repository, and this runs the product's own
//! writers over it. It is idempotent: a catalogue entry that already matches
//! is left alone, an event already bound is reported and skipped, and the
//! reseal runs only when something changed.
//!
//! A binding names only its event. The engine waits for every hook's answer,
//! so a binding carries no deadline, and a declaration that still gives one
//! is refused naming the field instead of having it dropped.
//!
//! Hook source and configuration are device-level protected, so without the
//! owner's consent this refuses before writing anything and says how to give
//! it: `DEVICE_HOOK_EDIT_APPROVED=1` in his own shell, or his word in the
//! conversation, recorded as the session capability
//! `{"tool": "tama", "actions": ["hook-edit"]}` ([`consent`]).

mod plan;

pub use plan::is_bound;

use std::path::{Path, PathBuf};
use std::process::Command;

use serde::Deserialize;
use tama_hook_tools::ports::owner_consent::HOOK_CHANGE;

pub const USAGE: &str =
    "usage: tama hooks declare --file <declaration.json> [--dry-run]\n\
     \n\
     The declaration carries the hook's id, its catalogue entry and the events it binds:\n\
     {\"id\":\"…\",\"category\":\"…\",\"description\":\"…\",\"why\":\"…\",\"sideEffects\":\"…\",\n\
      \"command\":\"$HOME/.local/bin/tama hook …\",\"events\":[{\"event\":\"pre_tool_use:bash\"}]}\n\
     A binding names only its event: the engine waits for every hook's answer.";

pub use tama_hook_tools::ports::block_hook_config_edits_without_consent::APPROVAL_ENV as CONSENT_ENV;
/// The value the owner's consent switch takes, as the hook management docs
/// state it:
/// https://tama.wisent.com/docs/hook-management/#owner-consent-for-a-hook-change
pub const CONSENT_VALUE: &str = "1";

#[derive(Deserialize)]
pub struct Declaration {
    pub id: String,
    pub category: String,
    pub description: String,
    pub why: String,
    #[serde(rename = "sideEffects")]
    pub side_effects: String,
    pub command: String,
    pub events: Vec<Binding>,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Binding {
    pub event: String,
}

/// A refusal of the command: the cause on stderr, the failure status.
pub fn refuse(message: &str) -> i32 {
    eprintln!("{message}");
    tama_core::exit::FAILURE
}

/// The owner's consent: `DEVICE_HOOK_EDIT_APPROVED=1` in this process's
/// environment, or the capability
/// `{"tool": "tama", "actions": ["hook-edit"]}` recorded by the session this
/// command runs in — the operator's consent given in that conversation. No
/// other session's capability is read. A consent found in the session is
/// handed to the catalogue and registry writers this command starts, which
/// read the variable, so one consent covers the whole change it was given
/// for. A variable that is set but not text is refused naming it; the refusal
/// otherwise names the session and the capability it lacks, or that no
/// session runs this command.
pub fn consent() -> Result<(), String> {
    match std::env::var(CONSENT_ENV) {
        Ok(value) if value == CONSENT_VALUE => return Ok(()),
        Ok(_) | Err(std::env::VarError::NotPresent) => {}
        Err(error) => return Err(format!("{CONSENT_ENV} cannot be read: {error}")),
    }
    let session = HOOK_CHANGE.granting_session()?;
    eprintln!("owner consent: the hook-edit capability recorded in session {session}, which runs this command");
    std::env::set_var(CONSENT_ENV, CONSENT_VALUE);
    Ok(())
}

/// [`consent`] for a caller that refuses with its own sentence: the cause of
/// a refusal is written to standard error before it answers false.
pub fn consented() -> bool {
    match consent() {
        Ok(()) => true,
        Err(cause) => {
            eprintln!("owner consent refused: {cause}");
            false
        }
    }
}

/// How the owner gives consent, for every refusal that asks for it.
pub fn consent_route(command: &str) -> String {
    format!(
        "Either say in the conversation that you agree, and the agent records it as the Tama \
         session capability {}, or run this in your own shell, outside any agent session:\n\n  \
         {CONSENT_ENV}={CONSENT_VALUE} {command}\n\nRead why: \
         https://tama.wisent.com/docs/hook-management/#owner-consent-for-a-hook-change",
        HOOK_CHANGE.grant()
    )
}

/// The command that runs one of the catalogue and registry writers: this
/// same program, as `tama hook <name> <args>`.
pub fn writer(name: &str, args: &[String]) -> Result<(PathBuf, Vec<String>), String> {
    let program = std::env::current_exe()
        .map_err(|error| format!("cannot name the running tama program: {error}"))?;
    let mut all = vec![
        tama_hooks::hook_exec::HOOK_SUBCOMMAND.to_string(),
        name.to_string(),
    ];
    all.extend_from_slice(args);
    Ok((program, all))
}

pub fn run(program: &Path, args: &[String], cwd: &Path) -> Result<String, String> {
    let mut command = Command::new(program);
    command.args(args).current_dir(cwd);
    let output = stado_wait::output(&mut command)
        .map_err(|error| format!("cannot run {}: {error}", program.display()))?;
    let text = format!(
        "{}{}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    // The status as the system reports it: a writer ended by a signal has
    // no exit code, and reading it as 0 would say it exited cleanly.
    if output.status.success() {
        Ok(text.trim().to_string())
    } else {
        Err(format!(
            "{} ended with {}: {}",
            program.display(),
            output.status,
            text.trim()
        ))
    }
}

/// The word after the flag `name`, when the flag is given.
pub fn option<'a>(argv: &'a [String], name: &str) -> Option<&'a String> {
    let mut words = argv.iter();
    words.find(|word| *word == name)?;
    words.next()
}

pub fn main(argv: &[String], root: &Path) -> i32 {
    let Some(file) = option(argv, "--file") else {
        eprintln!("{USAGE}");
        return tama_core::exit::USAGE;
    };
    let dry_run = argv.iter().any(|arg| arg == "--dry-run");
    let text = match std::fs::read_to_string(file) {
        Ok(text) => text,
        Err(error) => return refuse(&format!("cannot read {file}: {error}")),
    };
    let declaration: Declaration = match serde_json::from_str(&text) {
        Ok(declaration) => declaration,
        Err(error) => return refuse(&format!("{file} is not a hook declaration: {error}")),
    };
    if declaration.events.is_empty() {
        return refuse(&format!(
            "{file} binds no event; a hook that runs nowhere is not a hook"
        ));
    }
    if !dry_run {
        if let Err(cause) = consent() {
            return refuse(&format!(
                "BLOCKED: hook source and configuration are device-level protected: {cause}. {}",
                consent_route(&format!(
                    "tama hooks declare --file {}",
                    root.join(file).display()
                ))
            ));
        }
    }
    plan::plan(&declaration, root, file, dry_run)
}
