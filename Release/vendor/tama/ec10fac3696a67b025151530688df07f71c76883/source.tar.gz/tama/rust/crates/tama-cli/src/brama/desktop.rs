//! What Tama Desktop asks of the model choice, answered by the same
//! functions the commands run: `model-provider` shows the choice and, unless
//! no model is declared, its check; `model-provider/set` declares no model;
//! `model-provider/unset` returns Tama to Brama. Each refusal carries the
//! command's own sentence.

use http::StatusCode;
use serde_json::{json, Value};
use tama_hook_tools::ports::task_attestation::declared::model_declared_none;

/// A refusal the request answers with: a status and the sentence.
pub(crate) type Refused = (StatusCode, String);

/// The choice, and what checking it found. A machine with no model has no
/// service to check, so the check says so instead of probing Brama.
pub(crate) fn model_provider() -> Result<Value, Refused> {
    let failed = |error| (StatusCode::INTERNAL_SERVER_ERROR, error);
    let choice = super::provider::choice().map_err(failed)?;
    let check = if model_declared_none().map_err(failed)? {
        json!({
            "provider": "none",
            "verdict": "no model is declared on this machine, so there is no service to check; the stop gates that would ask a model read the session's recorded attestation (tama attestation record), and review-push and the turn-end gates read the attestation commits and answers carry, as they do on every machine",
        })
    } else {
        match tama_hook_tools::brama::reachability()
            .and_then(|report| serde_json::to_value(report).map_err(|error| error.to_string()))
        {
            Ok(report) => report,
            Err(error) => json!({ "error": error }),
        }
    };
    Ok(json!({ "choice": choice, "check": check }))
}

/// `{"none": true}` declares that this machine has no model. A service with
/// its key is declared in the terminal, where the key is read from standard
/// input and never crosses a request.
pub(crate) fn model_provider_set(body: &Value) -> Result<Value, Refused> {
    if body.get("none").and_then(Value::as_bool) != Some(true) {
        return Err((
            StatusCode::BAD_REQUEST,
            "model-provider/set takes {\"none\": true}; a service and its key are declared with `tama model set --origin URL --model MODEL < KEY`".to_string(),
        ));
    }
    super::provider::declare_none().map_err(|error| (StatusCode::INTERNAL_SERVER_ERROR, error))?;
    model_provider()
}

/// Remove the declaration, returning Tama to Brama.
pub(crate) fn model_provider_unset() -> Result<Value, Refused> {
    super::provider::remove().map_err(|error| (StatusCode::BAD_REQUEST, error))?;
    model_provider()
}
