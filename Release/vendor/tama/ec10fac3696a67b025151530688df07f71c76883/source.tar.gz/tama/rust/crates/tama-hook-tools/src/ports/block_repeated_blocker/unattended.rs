//! Defects this session recorded that nothing has started to repair.
//!
//! Recording a defect changes nothing by itself: the register grows and the
//! session goes back to what it was doing. A defect found in this session is
//! the session's first work, so a stop is refused while one it recorded has
//! neither a fix nor a repair plan. The plan is what `oko defects plan`
//! writes (`repair_plan`), or the older convention of a note that opens with
//! `REPAIR PLAN`.

use serde_json::Value;
use tama_hooks::session_record::session_id_of;

use super::register::{short_id, DEFECTS_KEY, FIXED_KEY, FOUND_IN_KEY, TITLE_KEY};

const NOTES_KEY: &str = "notes";
const TEXT_KEY: &str = "text";
const PLAN_KEY: &str = "repair_plan";
const PLAN_MARKER: &str = "REPAIR PLAN";

fn non_empty(defect: &Value, key: &str) -> bool {
    defect
        .get(key)
        .and_then(Value::as_str)
        .is_some_and(|text| !text.trim().is_empty())
}

/// Whether this defect has a repair under way: a fix, or a plan.
pub(crate) fn attended(defect: &Value) -> bool {
    non_empty(defect, FIXED_KEY)
        || non_empty(defect, PLAN_KEY)
        || defect
            .get(NOTES_KEY)
            .and_then(Value::as_array)
            .is_some_and(|notes| {
                notes.iter().any(|note| {
                    note.get(TEXT_KEY)
                        .and_then(Value::as_str)
                        .is_some_and(|text| text.contains(PLAN_MARKER))
                })
            })
}

/// Whether `session` recorded this defect. Oko keeps what the recorder typed
/// as `found_in`, and a recorder writes "session <id>" as often as the bare
/// id; an exact comparison let such a defect go unattended unnoticed.
pub(crate) fn found_in(defect: &Value, session: &str) -> bool {
    defect
        .get(FOUND_IN_KEY)
        .and_then(Value::as_str)
        .is_some_and(|recorded| recorded.contains(session))
}

/// The refusal for the first defect this session recorded without a repair.
pub(super) fn refusal(payload: &Value, document: &Value) -> Option<String> {
    let session = session_id_of(payload);
    if session.trim().is_empty() {
        return None;
    }
    let Some(defects) = document.get(DEFECTS_KEY).and_then(Value::as_array) else {
        return Some(format!(
            "block-repeated-blocker: TAMA_HOOK_INFRASTRUCTURE: whether this session left a \
             defect unattended cannot be judged: the defect register answered without its \
             {DEFECTS_KEY} list"
        ));
    };
    let defect = defects
        .iter()
        .find(|defect| found_in(defect, &session) && !attended(defect))?;
    let id = short_id(defect)?;
    let named = match defect.get(TITLE_KEY).and_then(Value::as_str) {
        Some(title) => format!("{id} — \"{title}\" —"),
        None => id.clone(),
    };
    Some(format!(
        "block-repeated-blocker: this session recorded defect {named} and nothing \
         repairs it yet: it has no fix and no repair plan. A defect found in this session is its \
         first work, before the work it was doing when it found it. Write the plan with \
         `oko defects plan {id} --text <mechanism and sweep>` and start it, then stop."
    ))
}
