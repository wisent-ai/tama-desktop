//! The instruction of a session whose prompt the capture hook never saw.
//!
//! A launcher hands a session's first prompt over at spawn, and the harness
//! raises no prompt event for it, so `record-current-assignment` records
//! nothing and the scope gate would refuse every write while its own remedy,
//! `tama task scope set`, had no instruction to bind to. The newest
//! operator-side message of the session's transcript is recorded as its
//! instruction instead, as the capture hook would have recorded it.

use crate::assignment::{self, Assignment};

/// Record and return the newest operator-side message of `session`'s
/// transcript as its instruction, saying so on stderr. A transcript that
/// holds none, or cannot be read, refuses naming why.
pub(super) fn transcript_instruction(session: &str) -> Result<Assignment, String> {
    let said = tama_hooks::session_record::last_operator_message(session).map_err(|cause| {
        format!(
            "no operator instruction is recorded for session {session}, and its transcript \
             cannot give one: {cause}"
        )
    })?;
    let Some(text) = said else {
        return Err(format!(
            "no operator instruction is recorded for session {session}, and its transcript \
             holds no message from the operator's side; the capture hook records one when the \
             operator writes"
        ));
    };
    let captured = assignment::capture(session, &text).map_err(|error| {
        format!(
            "the instruction read from the transcript of session {session} cannot be recorded: \
             {error}"
        )
    })?;
    let instruction = captured.ok_or_else(|| {
        format!("the newest operator message in the transcript of session {session} is empty")
    })?;
    eprintln!(
        "session {session} had no captured instruction (its prompt reached it without a prompt \
         event); its newest operator message in the transcript is recorded as the instruction"
    );
    Ok(instruction)
}
