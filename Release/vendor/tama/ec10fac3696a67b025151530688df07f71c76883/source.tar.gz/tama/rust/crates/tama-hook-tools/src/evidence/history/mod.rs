//! Git history read once per run, for every gate that asks something of it.
//!
//! A gate that asks Git one question per item it judges (a `git log
//! --find-object` per staged blob, a patch-id and an author date per
//! rewritten commit, a blame per replaced line) walks the same history once
//! per item, and on a repository with a long unpushed history that is hours
//! of Git while a commit or a ref lock waits. Here each kind of question is
//! asked once over the whole range a run needs, and its answer is kept for
//! the rest of the process under the repository and the range, so the gate
//! answers every item from memory: [`commits`] lists the commits of a range
//! with their parents and author instants, [`patch_ids`] gives every
//! commit's `git patch-id --stable` from one `diff-tree --stdin` piped into
//! one `patch-id`, and [`blobs`] gives every blob a range's commits wrote,
//! by path. Each read says on stderr what it read, over which range, how
//! many answers and how long Git took. `tama attestation pending` (its
//! range's commits), `review-ref-move` (commits and patch-ids of a move),
//! and the session replay of `tama stage` and `review-commit` (which of a
//! session's states a commit already took,
//! `session_changes::history::committed`) read history through this module.

use std::collections::{BTreeMap, BTreeSet};
use std::ffi::OsStr;
use std::os::unix::ffi::OsStrExt;
use std::path::{Path, PathBuf};
use std::sync::{LazyLock, Mutex};

use tama_core::git::Git;

/// One commit as a read of history lists it.
#[derive(Clone)]
pub struct Commit {
    pub id: String,
    pub parents: Vec<String>,
    /// The author instant, as `%aI` prints it.
    pub authored: String,
}

/// What a read is kept under: the repository as given, the kind of
/// question and the range's arguments.
type Key = (String, &'static str, Vec<String>);

static COMMITS: LazyLock<Mutex<BTreeMap<Key, Vec<Commit>>>> =
    LazyLock::new(|| Mutex::new(BTreeMap::new()));
static PATCH_IDS: LazyLock<Mutex<BTreeMap<Key, BTreeMap<String, String>>>> =
    LazyLock::new(|| Mutex::new(BTreeMap::new()));
/// The blobs a range's commits wrote, by the path they wrote each at.
type Blobs = BTreeMap<PathBuf, BTreeSet<String>>;
static BLOBS: LazyLock<Mutex<BTreeMap<Key, Blobs>>> = LazyLock::new(|| Mutex::new(BTreeMap::new()));

/// The answer kept under `key` in `store`, or the one `read` gives, which is
/// then kept and said on stderr with its count and time.
fn kept<T: Clone>(
    store: &Mutex<BTreeMap<Key, T>>,
    key: Key,
    count: impl Fn(&T) -> usize,
    read: impl FnOnce() -> Result<T, String>,
) -> Result<T, String> {
    if let Some(known) = store
        .lock()
        .map_err(|_| {
            format!(
                "the kept {} reads are held by a thread that panicked",
                key.1
            )
        })?
        .get(&key)
    {
        return Ok(known.clone());
    }
    let started = std::time::Instant::now();
    let answer = read()?;
    eprintln!(
        "history: read {} over {} in {}: {} answer(s) in {} ms",
        key.1,
        key.2.join(" "),
        key.0,
        count(&answer),
        started.elapsed().as_millis()
    );
    store
        .lock()
        .map_err(|_| {
            format!(
                "the kept {} reads are held by a thread that panicked",
                key.1
            )
        })?
        .insert(key, answer.clone());
    Ok(answer)
}

fn key(repository: &Path, kind: &'static str, range: &[&str]) -> Key {
    (
        repository.display().to_string(),
        kind,
        range.iter().map(|argument| argument.to_string()).collect(),
    )
}

/// Every commit `range` names (`git log` arguments: tips, `--not`, `^<sha>`,
/// `--no-walk`, `--since=`), newest first, from one `git log`.
pub fn commits(repository: &Path, range: &[&str]) -> Result<Vec<Commit>, String> {
    kept(
        &COMMITS,
        key(repository, "commits", range),
        Vec::len,
        || {
            let mut arguments = vec!["log", "--format=%H%x09%P%x09%aI"];
            arguments.extend_from_slice(range);
            let listed = Git::of(Some(repository)).text(&arguments)?;
            listed
                .lines()
                .map(|line| match line.split('\t').collect::<Vec<_>>()[..] {
                    [id, parents, authored] => Ok(Commit {
                        id: id.to_string(),
                        parents: parents.split_whitespace().map(str::to_string).collect(),
                        authored: authored.to_string(),
                    }),
                    _ => Err(format!(
                        "git log printed a commit line it does not write: {line:?}"
                    )),
                })
                .collect()
        },
    )
}

/// `git patch-id --stable` of every commit `range` names, by commit: the
/// commits' patches from one `git diff-tree --stdin -p --root`, read by one
/// `git patch-id`. A commit with no patch of its own (a merge, an empty
/// commit) has no patch-id and is absent.
pub fn patch_ids(repository: &Path, range: &[&str]) -> Result<BTreeMap<String, String>, String> {
    kept(
        &PATCH_IDS,
        key(repository, "patch-ids", range),
        BTreeMap::len,
        || {
            let listed: Vec<String> = commits(repository, range)?
                .into_iter()
                .map(|commit| commit.id)
                .collect();
            if listed.is_empty() {
                return Ok(BTreeMap::new());
            }
            let listed = listed.join("\n") + "\n";
            let patches = Git::of(Some(repository)).input(listed.as_bytes()).text(&[
                "diff-tree",
                "--stdin",
                "-p",
                "--root",
                "--no-color",
                "--no-ext-diff",
            ])?;
            let ids = Git::of(Some(repository))
                .input(patches.as_bytes())
                .text(&["patch-id", "--stable"])?;
            ids.lines()
                .map(|line| match line.split_once(' ') {
                    Some((patch, commit)) => Ok((commit.to_string(), patch.to_string())),
                    None => Err(format!(
                        "git patch-id printed a line it does not write: {line:?}"
                    )),
                })
                .collect()
        },
    )
}

/// Every blob the commits `range` names wrote, by the path they wrote it
/// at, from one `git log --raw -z` (`:<old mode> <new mode> <old blob> <new
/// blob> <status>`, then the path as its own NUL-ended field, so a path is
/// read byte for byte whatever it holds). Root commits count, renames are
/// read as the paths they write, and a deletion writes no blob.
pub fn blobs(repository: &Path, range: &[&str]) -> Result<Blobs, String> {
    let count = |found: &Blobs| found.values().map(BTreeSet::len).sum();
    kept(&BLOBS, key(repository, "blobs", range), count, || {
        let mut arguments = vec![
            "log",
            "--raw",
            "--no-abbrev",
            "--no-renames",
            "--root",
            "-z",
            "--format=",
        ];
        arguments.extend_from_slice(range);
        let listed = Git::of(Some(repository)).bytes(&arguments)?;
        let mut fields = listed.split(|byte| *byte == b'\0');
        let mut found: Blobs = BTreeMap::new();
        while let Some(field) = fields.next() {
            let Some(change) = field.trim_ascii_start().strip_prefix(b":") else {
                continue;
            };
            let shown = String::from_utf8_lossy(field);
            let parts: Vec<&[u8]> = change.split(|byte| *byte == b' ').collect();
            let [_, _, _, written, _] = parts.as_slice() else {
                return Err(format!(
                    "git log --raw printed an unreadable change: {shown}"
                ));
            };
            let Some(path) = fields.next() else {
                return Err(format!("git log --raw printed no path after {shown}"));
            };
            let written = String::from_utf8_lossy(written).into_owned();
            if !written.bytes().all(|byte| byte == b'0') {
                found
                    .entry(PathBuf::from(OsStr::from_bytes(path)))
                    .or_default()
                    .insert(written);
            }
        }
        Ok(found)
    })
}
