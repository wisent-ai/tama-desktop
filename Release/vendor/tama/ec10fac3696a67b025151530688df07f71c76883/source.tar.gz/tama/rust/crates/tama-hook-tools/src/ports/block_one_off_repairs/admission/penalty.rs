//! The penalty of the model that runs this session, read from Oko's register
//! of wasted builds (`oko shame penalty --model <model> --json`), applied to
//! a build before any consent or readiness admits it.
//!
//!   * `no-build` and `no-code` refuse every build;
//!   * `check-before-build` refuses a build of a product until this turn has
//!     read that product's installation state with `stado product status
//!     <product>` - the check whose absence wasted a build before.
//!
//! The model is the one the session's transcript last switched to (its
//! `model_change` record); a session whose transcript records none runs no
//! model the register could name. A transcript or register that cannot be
//! read refuses the build naming the cause: imposing nothing then would let a
//! model the register holds back build whenever the register is unreadable.

use std::io::BufRead;
use std::path::PathBuf;

use serde_json::Value;
use tama_hooks::session_record::{transcript_path, Turn};

use super::super::vocabulary::{self, program_and_args, VOCABULARY};
use crate::ports::python_stdlib::shell_tokens;
use crate::ports::shell_text;

/// The prefix of the record a harness writes when the session's model
/// changes; only such lines are parsed while the transcript is scanned.
const MODEL_CHANGE_PREFIX: &str = "{\"type\":\"model_change\"";
const MODEL_KEY: &str = "model";
const LEVEL_KEY: &str = "level";
const REFUSED_KEY: &str = "buildRefused";
const RULE_KEY: &str = "rule";
const CHECK_LEVEL: &str = "check-before-build";
const PRODUCT_NOUN: &str = "product";
const STATUS_VERB: &str = "status";
const BASH_TOOL: &str = "bash";
const COMMAND_KEY: &str = "command";
const TRANSCRIPT_KEY: &str = "transcript_path";

fn transcript(payload: &Value, session: &str) -> Option<PathBuf> {
    match payload.get(TRANSCRIPT_KEY).and_then(Value::as_str) {
        Some(path) if !path.is_empty() => Some(PathBuf::from(path)),
        _ => transcript_path(session),
    }
}

/// The model the transcript last switched to; `None` when it records none.
fn session_model(path: &PathBuf) -> Result<Option<String>, String> {
    let file = std::fs::File::open(path)
        .map_err(|error| format!("cannot open the transcript {}: {error}", path.display()))?;
    let mut model = None;
    for line in std::io::BufReader::new(file).lines() {
        let line = line
            .map_err(|error| format!("cannot read the transcript {}: {error}", path.display()))?;
        if !line.starts_with(MODEL_CHANGE_PREFIX) {
            continue;
        }
        let record: Value = serde_json::from_str(&line).map_err(|error| {
            format!("a model change in {} is not JSON: {error}", path.display())
        })?;
        if let Some(named) = record.get(MODEL_KEY).and_then(Value::as_str) {
            model = Some(named.to_string());
        }
    }
    Ok(model)
}

fn penalty(model: &str) -> Result<Value, String> {
    let read = format!("oko shame penalty --model {model} --json");
    let mut command = std::process::Command::new(crate::assignment::rules::oko_cli());
    command.args(["shame", "penalty", "--model", model, "--json"]);
    let output = stado_wait::output(&mut command)
        .map_err(|error| format!("{read} could not run: {error}"))?;
    if !output.status.success() {
        return Err(format!(
            "{read} failed ({}): {}",
            output.status,
            String::from_utf8_lossy(&output.stderr).trim()
        ));
    }
    serde_json::from_slice(&output.stdout)
        .map_err(|error| format!("{read} printed no JSON: {error}"))
}

fn words(args: &[String]) -> impl Iterator<Item = &str> {
    args.iter()
        .map(String::as_str)
        .filter(|arg| !vocabulary::is_flag(arg))
}

/// The product a `stado product <verb> <product>` names.
fn product_named(args: &[String]) -> Option<&str> {
    let mut plain = words(args);
    (plain.next()? == PRODUCT_NOUN).then_some(())?;
    plain.next()?;
    plain.next()
}

/// Whether `command` runs `stado product status <product>`.
fn reads_status(command: &str, product: &str) -> bool {
    shell_text::commands(&shell_text::effective_command(command))
        .into_iter()
        .map(shell_tokens)
        .any(|tokens| {
            program_and_args(&tokens).is_some_and(|(program, args)| {
                program == VOCABULARY.fleet_program && {
                    let expected = [PRODUCT_NOUN, STATUS_VERB, product];
                    words(args).take(expected.len()).eq(expected)
                }
            })
        })
}

/// Whether this turn ran `stado product status <product>` successfully.
fn status_read(turn: &Turn, product: &str) -> bool {
    let successful = turn.successful_call_ids();
    turn.tool_calls().into_iter().any(|(_, call)| {
        call.name == BASH_TOOL
            && successful.contains(&call.id)
            && call
                .arguments
                .get(COMMAND_KEY)
                .and_then(Value::as_str)
                .is_some_and(|command| reads_status(command, product))
    })
}

/// The refusal a model's penalty imposes on the build `name` (already known
/// to be a build, compile or test).
pub(crate) fn penalty_refusal(
    payload: &Value,
    session: &str,
    name: &str,
    args: &[String],
) -> Option<String> {
    let path = transcript(payload, session)?;
    let unread = |cause: String| {
        Some(format!(
            "{}`{name}` is refused: the wasted-build register's penalty for this session cannot be \
             read: {cause}",
            vocabulary::BANNER
        ))
    };
    let model = match session_model(&path) {
        Ok(Some(model)) => model,
        Ok(None) => return None,
        Err(cause) => return unread(cause),
    };
    let penalty = match penalty(&model) {
        Ok(penalty) => penalty,
        Err(cause) => return unread(cause),
    };
    let rule = match penalty.get(RULE_KEY).and_then(Value::as_str) {
        Some(rule) => rule.to_string(),
        None => format!("the register states no rule for {model}"),
    };
    if penalty.get(REFUSED_KEY).and_then(Value::as_bool) == Some(true) {
        return Some(format!(
            "{}`{name}` is refused by the wasted-build register: {rule}",
            vocabulary::BANNER
        ));
    }
    if penalty.get(LEVEL_KEY).and_then(Value::as_str) != Some(CHECK_LEVEL) {
        return None;
    }
    let product = product_named(args)?;
    let Some(turn) = Turn::for_payload(payload) else {
        return unread(format!(
            "this turn of the transcript {} cannot be read",
            path.display()
        ));
    };
    if status_read(&turn, product) {
        return None;
    }
    Some(format!(
        "{}`{name}` of {product} waits for the check the wasted-build register requires of {model}: {rule}. \
         Run `stado product status {product} --surface <SURFACE>` and read the open defects of {product} and \
         Stado (`oko defects list --open`) in this turn first.",
        vocabulary::BANNER
    ))
}
