//! Logic for `tama-block-stop-on-own-work`, registry hook id
//! `block-stop-on-own-work`.
//!
//! A Stop gate. It refuses a turn that ends on a report instead of on the
//! work the report itself describes.
//!
//! Everything is checked by structure, with no model: an ending a stop guard
//! already refused said again, a turn with no source change since that
//! refusal, a section repeated inside one answer, a defect recorded and
//! nothing repaired, a plea that hands over more than one command, one not
//! on the clipboard, or one that cannot run. What the answer says — no
//! invented limit, no declared stop, no decision handed back, no own work
//! under blockers — is the turn-end attestation it carries, every claim of
//! this gate's in `task_attestation/standards/turn.json` word for word
//! (`reading.rs`).
//!
//! Why: a session that has found the defect and has the file open can still
//! write that it has no capacity left, put the repository under Blokery,
//! write "Następne kroki: Żadnych", and issue the same report again after a
//! refusal, while no open task moves. Nothing the operator writes stands a
//! shape down.

mod mistakes;
mod reading;
mod repeat;
mod sections;
mod titles;
mod transcript;

use std::path::Path;

use serde_json::Value;
use tama_hooks::session_record::{deny, read_payload, refusal_once};

use crate::ports::transport_common as common;
use sections::Report;
use transcript::Transcript;

const HOOK: &str = "block-stop-on-own-work";
/// The one item named when the refusal is already held: the register to read.
const NEXT: &str = "`oko defects list`";

/// A report a stop guard already refused, said again. Its next steps do not
/// exempt it: six answers in a row carrying the same blockers and the same
/// steps after each refusal are the loop, whatever the steps say.
fn repeated_ending(transcript: &Transcript) -> Option<String> {
    repeat::repeated(&transcript.final_message, &transcript.refused_endings)?;
    Some(format!(
        "{HOOK}: BLOCKED: this ending is, word for word, the report a stop guard already \
         refused. A report re-issued after a refusal is the body of a loop, not progress: the \
         work it describes is still undone. Do that work, then write what changed since the \
         refusal."
    ))
}

/// An ending written after a stop guard refused the previous one, with no
/// change to source between them. A new ending with nothing done is the old
/// one reworded (nine endings in a row, each edited to pass the last
/// refusal), and one after re-timing a reading and writing a note is the
/// same: only an edit, a write or a commit is work. It is not that when
/// every open defect already carries a recorded repair: then no item is left
/// to change in source, what remains is the build that proves the repairs,
/// and demanding another edit only loops the session.
fn reworded_without_work(transcript: &Transcript, session: &str) -> Option<String> {
    if transcript.changed_since_refusal? || every_open_defect_repaired() {
        return None;
    }
    match tama_hooks::supervisor_stop::is_supervisor(session) {
        Ok(true) => return supervisor_without_delegation(transcript, session),
        Ok(false) => {}
        Err(cause) => {
            return Some(format!(
                "{HOOK}: TAMA_HOOK_INFRASTRUCTURE: whether this session supervises others \
                 cannot be read from Oko: {cause}"
            ))
        }
    }
    // The listings are the completion refusal's own: `oko tasks --open`
    // settles every live transcript's ledger before it answers, which is a
    // write across every session, not a read of what is owed.
    Some(format!(
        "{HOOK}: BLOCKED: a stop guard refused the previous ending and nothing since then \
         changed source (no edit, write or git commit): measurements, reads and register \
         notes are not work on an item. Take the next open task or defect of any session or \
         product that can be changed in source ({}, {}), change it, commit it, and end only \
         after that.",
        crate::assignment::completion::summary::LIST_TASKS,
        crate::assignment::completion::summary::LIST_UNREPAIRED
    ))
}

/// For a session Oko records as a supervisor, work since a refusal is its
/// executors' progress: a call to Oko's session management handing out,
/// resuming or interrupting their work. Its own edits are not asked for — a
/// gate that demands source changes from a supervisor turns it into another
/// executor while its executors stand idle. The refusal names the executors
/// recorded under it, to hand the next item to.
fn supervisor_without_delegation(transcript: &Transcript, session: &str) -> Option<String> {
    if transcript
        .delegations_since_refusal
        .as_ref()
        .is_some_and(|calls| !calls.is_empty())
    {
        return None;
    }
    let executors = match tama_hooks::supervisor_stop::executors_of(session) {
        Ok(executors) => executors,
        Err(cause) => {
            return Some(format!(
                "{HOOK}: TAMA_HOOK_INFRASTRUCTURE: the executors under this supervisor cannot \
                 be read from Oko: {cause}"
            ))
        }
    };
    Some(format!(
        "{HOOK}: BLOCKED: a stop guard refused the previous ending and this supervisor has \
         not managed an executor since (no oko sessions call). A supervisor's work is its \
         executors' progress, not its own source changes: read their state with oko sessions \
         agents and hand the next open task or defect to one that is idle or stopped. \
         Executors under this session: {}.",
        executors.join(", ")
    ))
}

/// Whether Oko's defect register answers that every open defect carries a
/// recorded repair. A register that cannot be read answers no, so the
/// refusal stands rather than being waived on a failed read.
pub(crate) fn every_open_defect_repaired() -> bool {
    crate::assignment::open_defects::listed_open()
        .is_ok_and(|defects| defects.iter().all(|defect| defect.repaired_in.is_some()))
}

/// The macOS clipboard reader: what `pbcopy` put there, `pbpaste` gives back.
const CLIPBOARD_READER: &str = "pbpaste";

/// What the clipboard holds, or `None` where there is no clipboard reader
/// (it cannot start) or it refuses; a refusal is said on stderr.
fn clipboard() -> Option<String> {
    let mut command = std::process::Command::new(CLIPBOARD_READER);
    command.stdin(std::process::Stdio::null());
    let output = match stado_wait::output(&mut command) {
        Ok(output) => output,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return None,
        Err(error) => {
            eprintln!("{HOOK}: {CLIPBOARD_READER} could not run: {error}");
            return None;
        }
    };
    if !output.status.success() {
        eprintln!(
            "{HOOK}: {CLIPBOARD_READER} failed ({}): {}",
            output.status,
            String::from_utf8_lossy(&output.stderr).trim()
        );
        return None;
    }
    Some(String::from_utf8_lossy(&output.stdout).trim().to_owned())
}

/// A report that begs hands the operator exactly one command, and has put it
/// on his clipboard: he pastes one line, he does not read a description,
/// choose between ways or assemble a command. `clipboard` is what the
/// clipboard holds, `None` where the machine has none to read.
fn begging_without_one_command(report: &Report, clipboard: Option<&str>) -> Option<String> {
    let commands = report.begged_commands()?;
    let [command] = commands.as_slice() else {
        return Some(format!(
            "{HOOK}: BLOCKED: this report begs with {} commands. A begging report hands the \
             operator exactly one command, written once as a code span, with its full path, and \
             already on his clipboard: copy it with `printf '%s' '<command>' | pbcopy`, write that \
             it is in the clipboard, and nothing else under Następne kroki.",
            commands.len()
        ));
    };
    match clipboard {
        Some(held) if held != *command => Some(format!(
            "{HOOK}: BLOCKED: this report begs with `{command}`, but the clipboard holds \
             something else. Copy the command before answering — `printf '%s' '{command}' | \
             pbcopy` — so the operator pastes one line."
        )),
        _ => None,
    }
}

/// A plea whose one command omits an option its own program requires: the
/// operator would spend his run on a refusal.
fn unrunnable_plea(report: &Report, home: &Path) -> Option<String> {
    let commands = report.begged_commands()?;
    let [command] = commands.as_slice() else {
        return None;
    };
    sections::chain::unrunnable(command, home).map(|problem| {
        format!(
            "{HOOK}: BLOCKED: this report begs with a command that cannot succeed: \
             {problem}."
        )
    })
}

/// One answer carries each section once. A second `Blokady` or `Następne
/// kroki` is the same report said twice inside one message.
fn repeated_section(report: &Report) -> Option<String> {
    let heading = report.repeated_heading.as_deref()?;
    Some(format!(
        "{HOOK}: BLOCKED: this answer carries the section \"{heading}\" twice. One answer has \
         each section once; a second copy is the same report repeated, not new work. Remove the \
         duplicate and, if the report was refused before, do work that changes a task or a \
         blocker before answering again."
    ))
}

/// The refusal for this payload, judged against the install root under `home`.
pub fn check(payload: &Value, home: &Path) -> Option<String> {
    let transcript = match Transcript::from_payload(payload) {
        Ok(transcript) => transcript,
        Err(error) => {
            return Some(format!(
                "{HOOK}: TAMA_HOOK_INFRASTRUCTURE: this ending cannot be judged: {error}"
            ))
        }
    };
    if transcript.final_message.trim().is_empty() {
        return None;
    }
    let report = Report::parse(&transcript.final_message);
    reworded_without_work(&transcript, &common::session_id_of(payload))
        .or_else(|| repeated_section(&report))
        .or_else(|| mistakes::recorded_without_repair(&transcript))
        .or_else(|| mistakes::restated_ending(&transcript))
        .or_else(|| mistakes::report_shown_again(&transcript))
        .or_else(|| repeated_ending(&transcript))
        .or_else(|| begging_without_one_command(&report, clipboard().as_deref()))
        .or_else(|| unrunnable_plea(&report, home))
        .or_else(|| reading::refusal(&transcript.final_message))
}

/// Runs the gate. A refusal the session already holds since the operator's
/// last message is given as one line, so an ending refused again and again
/// does not feed the session, nor show the operator, the same paragraph each
/// time.
pub fn run() {
    let payload = read_payload();
    if let Some(problem) = check(&payload, &common::home()) {
        let session = common::session_id_of(&payload);
        deny(refusal_once(&payload, &session, problem, NEXT));
    }
}
