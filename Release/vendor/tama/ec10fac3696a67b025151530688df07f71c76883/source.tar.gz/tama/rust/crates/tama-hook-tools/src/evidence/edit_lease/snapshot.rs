//! Immutable pre-write bytes, bound to the admitted session, call and path.
//! A successful numbered receipt can use these bytes even when formatting or
//! another author changed the file since its previous recorded edit.
use std::fs::{self, OpenOptions};
use std::io::{BufReader, BufWriter, Write};
use std::path::{Path, PathBuf};

use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

use super::Checked;

const DIRECTORY: &str = "tama-edit-snapshots";

#[derive(Deserialize, Serialize)]
struct Snapshot {
    session: String,
    call: String,
    path: String,
    before: Option<Vec<u8>>,
}

fn location(common: &Path, path: &str, session: &str, call: &str) -> PathBuf {
    let mut digest = Sha256::new();
    for field in [session, call, path] {
        digest.update(field.as_bytes());
        digest.update(b"\0");
    }
    common
        .join(DIRECTORY)
        .join(format!("{:x}.json", digest.finalize()))
}

fn read(path: &Path) -> Result<Option<Snapshot>, String> {
    let file = match fs::File::open(path) {
        Ok(file) => file,
        Err(cause) if cause.kind() == std::io::ErrorKind::NotFound => return Ok(None),
        Err(cause) => {
            return Err(format!(
                "cannot open pre-write snapshot {}: {cause}",
                path.display()
            ))
        }
    };
    serde_json::from_reader(BufReader::new(file))
        .map(Some)
        .map_err(|cause| {
            format!(
                "cannot decode pre-write snapshot {}: {cause}",
                path.display()
            )
        })
}

fn belongs(snapshot: &Snapshot, path: &str, session: &str, call: &str) -> bool {
    snapshot.session == session && snapshot.call == call && snapshot.path == path
}

/// Capture before the tool writes, never replace an earlier observation of
/// the same invocation. A repeated gate must observe the same input bytes.
pub(super) fn capture(checked: &Checked, session: &str, call: &str) -> Result<(), String> {
    let target = checked.root.join(&checked.relative);
    let before = match fs::read(&target) {
        Ok(bytes) => Some(bytes),
        Err(cause) if cause.kind() == std::io::ErrorKind::NotFound => None,
        Err(cause) => {
            return Err(format!(
                "cannot capture {} before edit {call}: {cause}",
                target.display()
            ))
        }
    };
    let path = location(&checked.common, &checked.relative, session, call);
    if let Some(kept) = read(&path)? {
        if belongs(&kept, &checked.relative, session, call) && kept.before == before {
            return Ok(());
        }
        return Err(format!(
            "pre-write snapshot {} already records different input for edit {call} of {}; nothing was replaced",
            path.display(), target.display()
        ));
    }
    let directory = path.parent().expect("a snapshot is below its directory");
    fs::create_dir_all(directory).map_err(|cause| {
        format!(
            "cannot create pre-write snapshot directory {}: {cause}",
            directory.display()
        )
    })?;
    let file = OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(&path)
        .map_err(|cause| {
            format!(
                "cannot create pre-write snapshot {} for edit {call}: {cause}",
                path.display()
            )
        })?;
    let snapshot = Snapshot {
        session: session.to_owned(),
        call: call.to_owned(),
        path: checked.relative.clone(),
        before,
    };
    let mut writer = BufWriter::new(file);
    serde_json::to_writer(&mut writer, &snapshot).map_err(|cause| {
        format!(
            "cannot encode pre-write snapshot {}: {cause}",
            path.display()
        )
    })?;
    writer
        .flush()
        .and_then(|()| writer.get_ref().sync_all())
        .map_err(|cause| {
            format!(
                "cannot persist pre-write snapshot {}: {cause}",
                path.display()
            )
        })
}

/// Resolve the repository once, not once for each historical receipt.
pub(crate) struct Reader {
    common: PathBuf,
}

impl Reader {
    pub(crate) fn open(root: &Path) -> Result<Option<Self>, String> {
        let common = tama_core::git::Git::of(Some(root)).text(&[
            "rev-parse",
            "--path-format=absolute",
            "--git-common-dir",
        ])?;
        let common = PathBuf::from(common.trim());
        let directory = common.join(DIRECTORY);
        match fs::metadata(&directory) {
            Ok(metadata) if metadata.is_dir() => Ok(Some(Self { common })),
            Ok(_) => Err(format!(
                "pre-write snapshot store {} is not a directory",
                directory.display()
            )),
            Err(cause) if cause.kind() == std::io::ErrorKind::NotFound => Ok(None),
            Err(cause) => Err(format!(
                "cannot inspect pre-write snapshot store {}: {cause}",
                directory.display()
            )),
        }
    }

    /// None means an older call has no capture; Some(None) records absence.
    /// Unreadable or mismatched evidence is an error, never missing evidence.
    pub(crate) fn before(
        &self,
        path: &Path,
        session: &str,
        call: &str,
    ) -> Result<Option<Option<String>>, String> {
        let relative = path
            .to_str()
            .ok_or_else(|| format!("snapshot path {} is not text", path.display()))?;
        let location = location(&self.common, relative, session, call);
        let Some(snapshot) = read(&location)? else {
            return Ok(None);
        };
        if !belongs(&snapshot, relative, session, call) {
            return Err(format!(
                "pre-write snapshot {} does not belong to session {session}, edit {call}, path {}; no bytes were inferred",
                location.display(), path.display()
            ));
        }
        snapshot
            .before
            .map(String::from_utf8)
            .transpose()
            .map(Some)
            .map_err(|cause| {
                format!(
                    "pre-write snapshot {} of {} is not text: {cause}",
                    location.display(),
                    path.display()
                )
            })
    }
}
