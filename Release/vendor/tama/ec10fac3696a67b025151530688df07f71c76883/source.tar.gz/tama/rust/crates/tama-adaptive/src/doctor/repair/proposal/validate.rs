//! Running a candidate against the labelled corpus: everything that must
//! block still blocks, everything that must pass passes, and an empty
//! payload does not crash it.
//!
//! A candidate runs through the interpreter its own `#!` line names, the
//! way the kernel runs the live hook; a table of extensions had decided
//! which program reads which file.
//!
//! Split out of `doctor/repair.rs`, which had grown past the
//! three-hundred-line limit.

use std::fs;

use serde_json::{json, Value};

use super::super::corpus::{hook_paths, split_corpus};
use super::super::spawn::{block_verdict, spawn_sync_capture, Ended, SpawnOutcome};
use crate::engine::load_engine;
use crate::util::{extname, shell_words};
use tama_core::exit;

/// The interpreter line a script starts with, as execve(2) reads it.
const SHEBANG: &str = "#!";

/// The program and arguments the `#!` line of `text` names.
fn interpreter_of(text: &str) -> Option<(String, Vec<String>)> {
    let line = text.lines().next()?.strip_prefix(SHEBANG)?;
    let mut words = shell_words(line.trim()).into_iter();
    let program = words.next()?;
    Some((program, words.collect()))
}

/// A report that ran nothing: it carries no run count, only why.
fn not_run(kind: &str, detail: String) -> Value {
    json!({ "ok": false, "failures": [{ "kind": kind, "detail": detail }] })
}

/// `validateCandidate(hookId, candidateFilePath)` — the report object
/// (`{ ok, checked, failures, staged }`, or `{ ok, failures }` when nothing
/// could be run), or why the candidate could not be run at all.
pub fn validate_candidate(hook_id: &str, candidate_file_path: &str) -> Result<Value, String> {
    let core = load_engine()?;
    let paths = hook_paths(hook_id, &core)?;
    let text = fs::read_to_string(candidate_file_path)
        .map_err(|error| format!("cannot read the candidate {candidate_file_path}: {error}"))?;
    let Some((program, mut arguments)) = interpreter_of(&text) else {
        let detail = format!("{candidate_file_path} has no {SHEBANG} line naming its interpreter");
        return Ok(not_run("setup", detail));
    };
    let corpus = split_corpus(&core.state_dir, hook_id)?;
    if corpus.must_block.is_empty() && corpus.must_pass.is_empty() {
        let detail = "no labeled corpus cases in validated closed telemetry segments".to_string();
        return Ok(not_run("insufficient-evidence", detail));
    }
    // The staged copy keeps the candidate's extension, or the live hook's
    // when the candidate has none, so it reads as the hook it replaces.
    let ext = match extname(candidate_file_path) {
        ext if !ext.is_empty() => ext,
        _ => paths.live.as_deref().map(extname).into_iter().collect(),
    };
    let tmp_dir = core.state_dir.join("tmp");
    fs::create_dir_all(&tmp_dir)
        .map_err(|error| format!("cannot create {}: {error}", tmp_dir.display()))?;
    let staged = tmp_dir.join(format!("{hook_id}-under-test{ext}"));
    fs::copy(candidate_file_path, &staged).map_err(|error| {
        format!(
            "cannot stage {candidate_file_path} as {}: {error}",
            staged.display()
        )
    })?;
    let staged_text = staged.to_string_lossy().into_owned();
    arguments.push(staged_text.clone());
    let run = |payload: &Value| -> Result<SpawnOutcome, String> {
        spawn_sync_capture(&program, &arguments, &payload.to_string())
    };
    let payload_of = |row: &Value| -> Result<Value, String> {
        row.get("payload")
            .cloned()
            .ok_or_else(|| format!("a corpus entry of hook {hook_id} carries no payload: {row}"))
    };
    let mut failures: Vec<Value> = Vec::new();
    let mut runs: Vec<&str> = Vec::new();
    for row in &corpus.must_block {
        runs.push("must-block");
        let result = run(&payload_of(row)?)?;
        if !block_verdict(&result) && result.ended == Ended::Status(exit::SUCCESS) {
            failures.push(json!({
                "kind": "must-block",
                "ts": row.get("ts"),
                "detail": "payload that must block passed",
            }));
        }
    }
    for row in &corpus.must_pass {
        runs.push("must-pass");
        let result = run(&payload_of(row)?)?;
        let detail = match (block_verdict(&result), result.ended) {
            (true, _) => Some("explicit block verdict".to_string()),
            (false, Ended::Status(exit::SUCCESS)) => None,
            (false, ended) => Some(ended.to_string()),
        };
        if let Some(detail) = detail {
            failures.push(json!({ "kind": "must-pass", "ts": row.get("ts"), "detail": detail }));
        }
    }
    // The smoke run: an empty object payload must not crash the script.
    runs.push("smoke");
    let smoke = run(&json!({}))?;
    if let Ended::Signal(signal) = smoke.ended {
        failures.push(json!({
            "kind": "smoke",
            "detail": format!("crashed on empty payload: signal {signal}"),
        }));
    }
    Ok(json!({
        "ok": failures.is_empty(),
        "checked": runs.len(),
        "failures": failures,
        "staged": staged_text,
    }))
}
