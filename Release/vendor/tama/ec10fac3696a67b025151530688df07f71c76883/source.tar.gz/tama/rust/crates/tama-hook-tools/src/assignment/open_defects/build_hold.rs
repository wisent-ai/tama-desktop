//! The items a build may go ahead without, as Oko decides them.
//!
//! A session's build waits until every open item carries its pushed repair
//! (`oko admit build --session`). An item whose repair is refused by an
//! installed hook or command, while that refuser's own defect is repaired in
//! source, can never get one before the build installs that repair: the
//! build and the item would wait on each other. Oko holds such an item for
//! the build when an open record of its blocker register names the item and
//! waits on (`--waits-on`) an open defect whose repair is pushed, and `oko
//! blockers held --json` prints those items. The stop gate reads that list
//! rather than its own reading of the blocker's prose, so the gate that
//! admits a build and the gate that ends a turn hold the same items.

use super::read_json;

/// The short ids of every item the build itself unblocks, as `oko blockers
/// held --json` prints them. `Err` when Oko could not be read, or printed
/// something other than a list of ids.
pub fn held_for_build() -> Result<Vec<String>, String> {
    let held = read_json(&["blockers", "held", "--json"])?;
    let items = held
        .as_array()
        .ok_or_else(|| format!("oko blockers held printed no list: {held}"))?;
    items
        .iter()
        .map(|item| {
            item.as_str()
                .map(str::to_lowercase)
                .ok_or_else(|| format!("oko blockers held printed an item that is no id: {item}"))
        })
        .collect()
}

/// `lines` without the items held for the build: a line is held when it opens
/// with a held id or names it in parentheses, the two ways open-work lines
/// name their item.
pub fn waiting_on_repair(lines: Vec<String>, held: &[String]) -> Vec<String> {
    lines
        .into_iter()
        .filter(|line| {
            let lower = line.to_lowercase();
            !held.iter().any(|id| {
                lower.starts_with(&format!("{id} ")) || lower.contains(&format!("({id})"))
            })
        })
        .collect()
}
