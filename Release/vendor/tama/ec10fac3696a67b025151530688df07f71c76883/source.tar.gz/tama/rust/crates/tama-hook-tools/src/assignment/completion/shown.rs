//! How a refusal names a request: by what identifies it, never by quoting it.
//!
//! A refusal is injected into the agent's context after every Stop, so its
//! size is the agent's to carry. An operator message can be an attachment of
//! megabytes, and a reading-model error can be pages long; quoting either
//! whole made a refusal larger than any model's request limit, and the
//! session could neither continue nor compact. A refusal therefore names a
//! task by the name its session gave it, else by its id, and points to the
//! command that prints the whole text. Nothing is cut at a length nobody
//! stated: what is shown is short because it is an identifier.

/// Every item, joined by `; `. Each item is already an identifier line.
pub fn listed(items: &[String]) -> String {
    items.join("; ")
}

/// The message numbers `ordinals` as `#3; #5; #9`.
pub fn ordinals(ordinals: &[i64]) -> String {
    let numbers: Vec<String> = ordinals
        .iter()
        .map(|ordinal| format!("#{ordinal}"))
        .collect();
    listed(&numbers)
}

/// One line naming an open task: its Oko name when the session gave it one,
/// else no part of the request, only the command that prints it whole.
pub fn task(task: &serde_json::Value, id: &str) -> String {
    let named = task
        .pointer("/contract/name")
        .and_then(serde_json::Value::as_str)
        .map(str::trim)
        .filter(|name| !name.is_empty());
    match named {
        Some(name) => format!("{name} (whole request: `oko tasks show {id}`)"),
        None => format!("not named yet (the request: `oko tasks show {id}`)"),
    }
}
