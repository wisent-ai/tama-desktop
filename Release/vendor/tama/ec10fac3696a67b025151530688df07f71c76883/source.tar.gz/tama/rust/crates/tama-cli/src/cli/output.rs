//! Output helpers extracted from the crate root: JSON printers and the
//! key-order workaround shared by the command handlers.

use std::io::Write;

use serde::Serialize;

use tama_core::policy_bundle::PolicyBundleImportResult;

/// `console.log(JSON.stringify(value, null, 2))` — one synchronous
/// `write_all` + `flush` so a following `process::exit` cannot truncate it.
pub fn print_json<T: Serialize>(value: &T) {
    write_stdout(&encoded(value));
}

/// The value's pretty JSON. A value serde cannot encode ends the command
/// naming serde's cause; printing `null` in its place told the caller the
/// command found nothing.
fn encoded<T: Serialize>(value: &T) -> String {
    match serde_json::to_string_pretty(value) {
        Ok(text) => text,
        Err(error) => {
            eprintln!("tama: the answer cannot be encoded as JSON: {error}");
            std::process::exit(libc::EXIT_FAILURE);
        }
    }
}

/// Writes `text` and a newline to standard output in one locked write. A
/// write or flush that fails ends the command naming the cause, so a reader
/// whose pipe closed or whose disk filled is not shown a success.
fn write_stdout(text: &str) {
    let stdout = std::io::stdout();
    let mut out = stdout.lock();
    let written = out
        .write_all(text.as_bytes())
        .and_then(|()| out.write_all(b"\n"))
        .and_then(|()| out.flush());
    if let Err(error) = written {
        eprintln!("tama: the answer cannot be written to standard output: {error}");
        std::process::exit(libc::EXIT_FAILURE);
    }
}

pub fn print_policy_import(result: &PolicyBundleImportResult, json: bool) {
    if json {
        print_json(result);
        return;
    }
    println!(
        "{}: {} imported, {} unchanged, {} removed, {} conflicting, {} rejected",
        result.status,
        result.imported,
        result.unchanged,
        result.removed,
        result.conflicting,
        result.rejected
    );
    println!("source: {}", result.source_path);
    println!("store: {}", result.store_path);
    println!("activation: inactive (0 installed, 0 enabled)");
    for conflict in &result.conflicts {
        println!("CONFLICT {}: {}", conflict.path, conflict.reason);
    }
    for rejection in &result.rejections {
        println!("REJECTED {rejection}");
    }
    for ignored in &result.ignored_paths {
        println!("IGNORED {ignored}");
    }
}

/// JS library calls throw on I/O errors; Node exits 1 with the error on
/// stderr. Reproduce the exit code and message (not the stack trace).
pub fn unwrap_or_exit<T>(result: tama_core::Result<T>) -> T {
    match result {
        Ok(value) => value,
        Err(error) => {
            eprintln!("{error}");
            std::process::exit(1);
        }
    }
}

/// JS truthiness for an optional string (`if (hook.description)`).
pub fn truthy(value: &Option<String>) -> Option<&str> {
    value.as_deref().filter(|s| !s.is_empty())
}

/// Prints catalog/hook JSON. Works around a tama-core fidelity gap:
/// `JustificationRequirement` flattens unknown keys (`title`) after the named
/// fields, while JS `JSON.parse` preserves the source order
/// (`kind, title, registryPath, field, ..., minimumWords`). Each `"title"`
/// line inside a `justificationRequirements` object is moved right after
/// `"kind"` in the pretty-printed text.
pub fn print_catalog_json<T: Serialize>(value: &T) {
    write_stdout(&restore_requirement_key_order(&encoded(value)));
}

fn restore_requirement_key_order(text: &str) -> String {
    let lines: Vec<&str> = text.split('\n').collect();
    let mut out: Vec<String> = Vec::with_capacity(lines.len());
    let mut i = 0;
    while i < lines.len() {
        let line = lines[i];
        let trimmed = line.trim_start();
        if trimmed != "\"justificationRequirements\": [" {
            out.push(line.to_string());
            i += 1;
            continue;
        }
        let base_indent = line.len() - trimmed.len();
        out.push(line.to_string());
        i += 1;
        while i < lines.len() {
            let l = lines[i];
            let t = l.trim_start();
            let indent = l.len() - t.len();
            if indent <= base_indent && t.starts_with(']') {
                out.push(l.to_string());
                i += 1;
                break;
            }
            if t == "{" {
                let mut object: Vec<String> = vec![l.to_string()];
                i += 1;
                while i < lines.len() {
                    let l2 = lines[i];
                    let t2 = l2.trim_start();
                    let indent2 = l2.len() - t2.len();
                    object.push(l2.to_string());
                    i += 1;
                    if indent2 == indent && (t2 == "}" || t2 == "},") {
                        break;
                    }
                }
                reorder_title(&mut object);
                out.extend(object);
            } else {
                out.push(l.to_string());
                i += 1;
            }
        }
    }
    out.join("\n")
}

/// Moves the `"title"` property line of one justification-requirement object
/// (including its braces) to directly after `"kind"`, preserving commas.
fn reorder_title(object: &mut Vec<String>) {
    let Some(title_pos) = object
        .iter()
        .position(|l| l.trim_start().starts_with("\"title\":"))
    else {
        return;
    };
    let mut title = object.remove(title_pos);
    // `object` still holds the braces; property lines sit between them.
    let property_count = object.len().saturating_sub(2);
    if property_count == 0 {
        object.insert(1, title);
        return;
    }
    if !title.trim_end().ends_with(',') {
        // `title` was the last property: transfer its missing comma.
        title.push(',');
        let last = object.len() - 2;
        if object[last].ends_with(',') {
            object[last].pop();
        }
    }
    let insert_at = object
        .iter()
        .position(|l| l.trim_start().starts_with("\"kind\":"))
        .map(|pos| pos + 1)
        .unwrap_or(1);
    object.insert(insert_at, title);
}
