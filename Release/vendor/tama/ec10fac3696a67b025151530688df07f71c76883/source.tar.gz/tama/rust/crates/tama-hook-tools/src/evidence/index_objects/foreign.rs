//! Entries an index holds that belong to no state of its checkout.
//!
//! A checkout's index is overwritten whole (another repository's index
//! copied over it) or filled with other sessions' staging. Two shapes of
//! that are read here from HEAD, the index and the working tree, with no
//! judgement of anyone's intent:
//!
//! - `foreign`: a staged path HEAD does not track and the working tree does
//!   not hold. No edit in this checkout produced it, and a commit would add
//!   a file nobody here has. `--apply` takes it out of the index; its object
//!   stays in the store and the answer names it.
//! - `dropped`: a path HEAD tracks, missing from the index, whose working
//!   file is present and not ignored. The index then deletes a file the
//!   checkout still has and still tracks by every other reading. `--apply`
//!   reads its entry back from HEAD, which loses nothing: HEAD holds that
//!   content and the working file is not touched. A path stopped being
//!   tracked on purpose is ignored by then (`git rm --cached` beside a
//!   `.gitignore` line), so it is left as it is.
//!
//! Both repairs are one `git reset -q HEAD -- <paths>` with literal
//! pathspecs, which writes the index only.

use std::path::{Path, PathBuf};

use serde::Serialize;

use tama_core::git::Git;

/// One entry of either shape, and what `--apply` did with it.
#[derive(Serialize)]
pub struct Stray {
    pub path: String,
    /// `foreign` or `dropped`, as the module says.
    pub shape: &'static str,
    /// The staged object of a foreign entry, kept in the store when the
    /// entry is taken out.
    pub object: Option<String>,
    pub repaired: bool,
}

/// Whether `path` names a file in the working tree `root`; a path whose
/// state cannot be read is refused naming it.
fn present(root: &Path, path: &str) -> Result<bool, String> {
    match root.join(path).symlink_metadata() {
        Ok(_) => Ok(true),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(false),
        Err(error) => Err(format!(
            "the working file {} cannot be read: {error}",
            root.join(path).display()
        )),
    }
}

/// The paths of `paths` the checkout `root` ignores.
fn ignored(root: &Path, paths: &[&str]) -> Result<Vec<String>, String> {
    if paths.is_empty() {
        return Ok(Vec::new());
    }
    let mut input = Vec::new();
    for path in paths {
        input.extend_from_slice(path.as_bytes());
        input.push(b'\0');
    }
    let output = Git::of(Some(root)).input(&input).output(&[
        "check-ignore",
        "--no-index",
        "-z",
        "--stdin",
    ])?;
    // check-ignore fails silently when it names no path, and says why when
    // it cannot read them; only the latter refuses.
    if !output.status.success() && !output.stderr.is_empty() {
        return Err(format!(
            "git check-ignore could not read the dropped paths of {} ({}): {}",
            root.display(),
            output.status,
            String::from_utf8_lossy(&output.stderr).trim()
        ));
    }
    Ok(output
        .stdout
        .split(|byte| *byte == b'\0')
        .filter(|name| !name.is_empty())
        .map(|name| String::from_utf8_lossy(name).into_owned())
        .collect())
}

/// Every foreign and dropped entry of the index `root` reads, repaired with
/// `apply`. A checkout whose HEAD names no commit yet has neither.
pub fn read(root: &Path, apply: bool) -> Result<Vec<Stray>, String> {
    let (born, _) =
        Git::of(Some(root)).answered(&["rev-parse", "--verify", "--quiet", "HEAD^{commit}"])?;
    if !born {
        return Ok(Vec::new());
    }
    // `--raw -z` writes `:<old mode> <new mode> <old id> <new id> <status>`
    // and then the path, each ended by NUL.
    let listed = Git::of(Some(root)).bytes(&[
        "diff-index",
        "--cached",
        "--raw",
        "-z",
        "--no-renames",
        "HEAD",
    ])?;
    let mut fields = listed
        .split(|byte| *byte == b'\0')
        .filter(|field| !field.is_empty())
        .map(|field| String::from_utf8_lossy(field).into_owned());
    let mut strays = Vec::new();
    let mut deleted = Vec::new();
    while let Some(head) = fields.next() {
        let path = fields
            .next()
            .ok_or_else(|| format!("git diff-index printed an entry without its path: {head}"))?;
        let words: Vec<&str> = head.split_whitespace().collect();
        let [_, _, _, staged, status] = words.as_slice() else {
            return Err(format!(
                "git diff-index printed an unreadable entry for {path}: {head}"
            ));
        };
        match status.chars().next() {
            Some('A') if !present(root, &path)? => strays.push(Stray {
                object: Some((*staged).to_owned()),
                path,
                shape: "foreign",
                repaired: false,
            }),
            Some('D') if present(root, &path)? => deleted.push(path),
            _ => {}
        }
    }
    let named: Vec<&str> = deleted.iter().map(String::as_str).collect();
    let kept_out = ignored(root, &named)?;
    strays.extend(
        deleted
            .into_iter()
            .filter(|path| !kept_out.contains(path))
            .map(|path| Stray {
                path,
                shape: "dropped",
                object: None,
                repaired: false,
            }),
    );
    if apply && !strays.is_empty() {
        let paths: Vec<PathBuf> = strays
            .iter()
            .map(|stray| PathBuf::from(&stray.path))
            .collect();
        let named: Vec<&Path> = paths.iter().map(PathBuf::as_path).collect();
        Git::of(Some(root))
            .variables(&[("GIT_LITERAL_PATHSPECS", "1")])
            .paths(&named)
            .bytes(&["reset", "-q", "HEAD", "--"])?;
        for stray in &mut strays {
            stray.repaired = true;
        }
    }
    Ok(strays)
}
