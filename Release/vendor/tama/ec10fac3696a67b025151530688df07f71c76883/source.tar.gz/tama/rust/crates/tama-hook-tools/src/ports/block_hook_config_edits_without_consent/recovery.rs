//! The operator's break-glass controls, which no agent may touch.
//!
//! Turning every hook off at once is how the operator recovers a machine a
//! hook has wedged. It is his control, not a tool: an agent that can disable
//! the gates has no gates. So the emergency state file, its backup directory,
//! the per-session override files and the commands that drive them are refused
//! outright, with their own banner, before the consent question is even asked
//! — consent to edit a hook is not consent to switch the enforcement off.
//!
//! An execution that names a break-glass file is refused whatever program it
//! runs: the write-shape and patch-applier lists that used to decide whether
//! it changed the file let every writer they left out through, and reading
//! the file goes through the harness's read tool.

use super::super::block_hook_config_edits_without_consent_patterns::Patterns;

pub(crate) const BLOCK_REASON: &str = concat!(
    "BLOCKED: global Tama emergency disable/re-enable is an operator-only ",
    "break-glass control and cannot be invoked or mutated by an agent.",
);

fn normalize(text: &str) -> String {
    text.replace('\\', "/")
}

/// Whether a write tool aims at a break-glass file.
pub(crate) fn write_tool_target(patterns: &Patterns, paths: &[String]) -> bool {
    paths
        .iter()
        .any(|path| patterns.operator_recovery_path.is_match(&normalize(path)))
}

/// Whether an execution payload drives a break-glass control: naming one of
/// its commands or one of its files is enough.
pub(crate) fn execution_target(patterns: &Patterns, text: &str) -> bool {
    let normalized = normalize(text);
    patterns.operator_recovery_command.is_match(&normalized)
        || patterns.operator_recovery_path.is_match(&normalized)
}
