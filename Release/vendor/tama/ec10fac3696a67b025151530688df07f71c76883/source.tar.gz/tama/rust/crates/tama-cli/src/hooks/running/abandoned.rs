//! The dispatches the harness stopped waiting for: each session's last one,
//! as its core wrote it (`abandoned.<session>.json`), so a tool call the
//! harness refused at its own limit names the hooks Tama was still running
//! for it, how long they had run, and the signal that proved the harness had
//! moved on.

use serde_json::Value;

/// A record's field as it reads in a sentence: a string without its JSON
/// quotes, anything else as JSON.
pub(super) fn plain(value: &Value) -> String {
    match value.as_str() {
        Some(text) => text.to_owned(),
        None => value.to_string(),
    }
}

/// Print one line per session: the `still running in Tama` sentence, the
/// session, when, which core, and why the core knows nobody waits.
pub(super) fn print(abandoned: &Value) {
    for document in abandoned.as_array().into_iter().flatten() {
        let text = match document["text"].as_str() {
            Some(text) => text.to_owned(),
            None => format!("an abandoned-dispatch record names no hooks: {document}"),
        };
        println!(
            "{text} — session {}, core pid {}, at {} ms since the epoch: {}",
            plain(&document["session"]),
            plain(&document["corePid"]),
            plain(&document["abandonedAtMs"]),
            plain(&document["reason"])
        );
    }
}

/// `tama hooks abandoned [--json]`: only the register, without inspecting
/// or signalling any process, so another product may read it on every look.
/// `argv` starts at the verb.
pub fn main(argv: &[String]) -> i32 {
    let json_output = match argv {
        [_] => false,
        [_, flag] if flag == "--json" => true,
        _ => {
            eprintln!("usage: tama hooks abandoned [--json]");
            return tama_core::exit::USAGE;
        }
    };
    let root = super::root();
    let report = match tama_run_hook::inspect_abandoned_dispatches(&root) {
        Ok(report) => report,
        Err(error) => {
            eprintln!("{error}");
            return libc::EXIT_FAILURE;
        }
    };
    let errors = report["errors"].as_array().into_iter().flatten();
    let mut exit = libc::EXIT_SUCCESS;
    for error in errors {
        eprintln!("abandoned-dispatch register: {error}");
        exit = libc::EXIT_FAILURE;
    }
    if json_output {
        println!("{report}");
    } else if report["abandoned"].as_array().is_some_and(Vec::is_empty) {
        println!(
            "no dispatch the harness stopped waiting for is recorded ({})",
            root.display()
        );
    } else {
        print(&report["abandoned"]);
    }
    exit
}
