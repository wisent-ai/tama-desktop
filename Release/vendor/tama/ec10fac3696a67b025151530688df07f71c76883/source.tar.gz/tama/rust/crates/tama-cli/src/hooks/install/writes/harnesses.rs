//! The hook file of every harness `tama_core::harnesses` declares that this
//! machine has, wired to the installed dispatcher: the block `tama provider
//! config` renders for it, merged into the file the harness already keeps.
//! A harness that is not on this machine is not written to.

use std::path::Path;

use serde_json::Value;
use tama_core::harnesses::{self, Shape};

use super::{base_config, pretty, provider_hook_block, Writes};

/// The text of `target`, or nothing when the file does not exist yet.
fn existing_text(target: &Path, display: &str) -> Result<String, String> {
    match std::fs::read_to_string(target) {
        Ok(text) => Ok(text),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(String::new()),
        Err(error) => Err(format!(
            "{} cannot be read to wire {display}'s hooks: {error}",
            target.display()
        )),
    }
}

/// Plan the hook file of every declared harness present under `home`.
pub(in crate::hooks::install) fn harness_writes(
    writes: &mut Writes,
    release_root: &Path,
    home: &Path,
    registry: &Value,
    dispatcher: &str,
    manifest: &Value,
    backup: Option<&Path>,
) -> Result<(), String> {
    for adapter in harnesses::all().iter() {
        if !adapter.present(home).map_err(|error| {
            format!(
                "whether {} is installed cannot be told: {error}",
                adapter.display
            )
        })? {
            continue;
        }
        let target = adapter.config_path(home);
        let label = format!("{}-hooks", adapter.id);
        let block = provider_hook_block(release_root, registry, &adapter.id, dispatcher)?;
        let bytes = match adapter.shape {
            Shape::KimiToml => {
                harnesses::merged_toml(&existing_text(&target, &adapter.display)?, &block)
                    .map_err(|error| format!("{}: {error}", target.display()))?
                    .into_bytes()
            }
            Shape::EventMap => {
                let mut config = base_config(&target, &label, manifest, backup, |source| {
                    adapter.read_config(source)
                })?;
                super::merge::hooks(&mut config, block, &adapter.id, adapter.shape)
                    .map_err(|error| format!("{}: {error}", target.display()))?;
                pretty(&config, &target)?
            }
            Shape::SettingsHooks | Shape::CursorFlat | Shape::CopilotFlat | Shape::WindsurfFlat => {
                let mut config = base_config(&target, &label, manifest, backup, |source| {
                    adapter.read_config(source)
                })?;
                super::merge::nested(&mut config, block, &adapter.id, adapter.shape)
                    .map_err(|error| format!("{}: {error}", target.display()))?;
                pretty(&config, &target)?
            }
        };
        writes.insert(target, (bytes, tama_core::OWNER_ONLY_FILE));
    }
    Ok(())
}
