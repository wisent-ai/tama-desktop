//! `tama hooks <command>`: the three halves of adding, changing or keeping a
//! hook, each behind one verb. `declare` writes the repository documents —
//! the catalogue entry, the registry binding, the reconciled sources and the
//! seal. `release` activates the installed sealed release, connects the Git
//! dispatchers, and reports their wiring. `warm` runs each installed binary
//! once so the operating
//! system's first-execution assessment is paid outside a live event, where
//! it would be taken for a hook that does not answer.

pub mod declare;
pub mod declared;
pub mod install;
pub mod integrity;
pub mod package;
pub mod reach;
pub mod release;
pub mod running;
#[path = "running/status.rs"]
pub mod status;
pub mod undeclare;
pub mod warm;

use std::path::Path;

pub(crate) const USAGE: &str = "usage: tama hooks <declare|undeclare|declared|reach|release|warm|running|abandoned|calls|status|stage|seal|identity|install-release|integrity|digest> [...]\n\
     \n\
     declare --file <declaration.json> [--dry-run]   catalogue entry, registry binding, reseal\n\
     undeclare --file <declaration.json> [--dry-run] the reverse: bindings, catalogue entry, reseal, declaration\n\
     declared [--registry PATH] [--json]             each committed declaration and whether the registry binds its events\n\
     reach [--catalogue PATH] [--json]               whether the active gates leave every session role a next step\n\
     release [--dry-run] [--enforce <hook-id>,…]     activate installed sealed release and connect Git dispatchers\n\
     warm [--only <hook-id>,…] [--json]              run each installed binary once, report timings\n\
     running [--json]                                the hook each session runtime is running now, and for how long\n\
     abandoned [--json]                              each session's last dispatch the harness stopped waiting for, and its hooks\n\
     calls --item <id> [--json]                      every tool call block-unclaimed-calls admitted for a task or defect\n\
     status [--home PATH] [--json]                   configured global Git hooks and preserved original hook chains\n\
     stage --source-root <tree> --release-root <release> --cargo <cargo>\n\
                                                     build the native programs into a prepared release\n\
     seal [--source-root <tree>] <release>           make a staged release deployable and name it by digest\n\
     identity --source-root <tree> [--shell]          the revision and dirtiness a release of that tree carries\n\
     install-release --release <dir> --home <dir> [--emergency-manifest <file>] [--session-control-only]\n\
                                                     install a sealed release, as one transaction\n\
     integrity [--release <dir>] [--home <dir>]      report whether a release and the installed ones still match their seal\n\
     digest <file-or-release>                        the digest a release or an artifact is named by";

/// `tama hooks digest <path>`: a directory's release digest, or a file's SHA-256.
fn digest(argv: &[String]) -> i32 {
    let [path] = argv else {
        eprintln!("usage: tama hooks digest <file-or-release>");
        return tama_core::exit::USAGE;
    };
    let path = Path::new(path);
    let answer = if path.is_dir() {
        package::seal::tree_digest(path)
    } else if path.is_file() {
        package::identity::file_digest(path)
    } else {
        Err(format!("artifact not found: {}", path.display()))
    };
    match answer {
        Ok(digest) => {
            println!("{digest}");
            tama_core::exit::SUCCESS
        }
        Err(error) => {
            eprintln!("{error}");
            tama_core::exit::FAILURE
        }
    }
}

pub fn main(argv: &[String], root: &Path) -> i32 {
    let Some((command, rest)) = argv.split_first() else {
        println!("{USAGE}");
        return tama_core::exit::SUCCESS;
    };
    match command.as_str() {
        "declare" => declare::main(rest, root),
        "undeclare" => undeclare::main(rest, root),
        "declared" => declared::main(rest, root),
        "reach" => reach::main(rest, root),
        "release" => release::main(rest, root),
        "warm" => warm::main(rest, root),
        "running" => running::main(rest),
        "abandoned" => running::abandoned::main(argv),
        "calls" => running::calls::main(rest),
        "status" => status::main(rest, root),
        "stage" => package::stage_main(rest),
        "seal" => package::seal_main(rest),
        "identity" => package::identity_main(rest),
        "install-release" => install::main(rest),
        "integrity" => integrity::main(rest),
        "digest" => digest(rest),
        "--help" | "-h" | "help" => {
            println!("{USAGE}");
            tama_core::exit::SUCCESS
        }
        other => {
            eprintln!("unknown hooks command {other}\n{USAGE}");
            tama_core::exit::USAGE
        }
    }
}
