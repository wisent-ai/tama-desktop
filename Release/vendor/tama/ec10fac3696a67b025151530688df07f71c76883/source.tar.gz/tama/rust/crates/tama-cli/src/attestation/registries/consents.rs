//! The operator's consents read as records: CUA and SSH grants cited from the
//! session transcript, and his standing build rulings.

use std::path::Path;

use serde_json::{json, Value};

use super::{text_of, Attester, Kind, Record, Verification};
use crate::justify::registry;

/// Every CUA or SSH grant: the operator's sentence, cited from the session's
/// transcript, admitting named actions on a named application or target. A
/// registry that exists without its `authorizations` list is refused, as its
/// own verbs refuse it.
pub(super) fn grants(home: &Path, kind: Kind) -> Result<Vec<Record>, String> {
    let registry_kind = match kind {
        Kind::Cua => registry::Kind::Cua,
        _ => registry::Kind::Ssh,
    };
    let (_, subject_field, scope_field) = registry::ledger::grant_fields(registry_kind);
    let store = registry::registry_path(home, registry_kind);
    let document = registry::load(&store)?;
    let entries = match document.get("authorizations") {
        Some(Value::Array(entries)) => entries,
        None if document.is_empty() => return Ok(Vec::new()),
        _ => {
            return Err(format!(
                "{} must contain an authorizations array",
                store.display()
            ))
        }
    };
    entries
        .iter()
        .map(|entry| {
            Ok(Record {
                kind,
                subject: text_of(entry, subject_field, &store)?,
                statement: entry["userRequestQuote"].clone(),
                attester: Attester::Operator,
                scope: json!({ "admits": entry[scope_field], "session": entry["sessionId"] }),
                lifetime: entry["lifetime"].clone(),
                verification: Verification::Transcript,
                store: store.display().to_string(),
            })
        })
        .collect()
}

/// Every build consent: each standing ruling that consents to builds of
/// every product or of one, read from Oko's one ruling authority through
/// [`tama_hook_tools::capability::standing`], the reader the build gate
/// admits through, so the listing and the gate never disagree about which
/// consent stands.
pub(super) fn builds() -> Result<Vec<Record>, String> {
    use tama_hook_tools::capability::standing;
    use tama_hook_tools::ports::block_one_off_repairs::BUILD_TOOL;
    Ok(standing::consents(BUILD_TOOL)?
        .into_iter()
        .filter_map(|verdict| verdict.ruling)
        .map(|ruling| Record {
            kind: Kind::Build,
            subject: ruling.subject.clone(),
            statement: json!(ruling.said),
            attester: Attester::Operator,
            scope: json!({ "ruling": ruling.id, "session": ruling.session, "ordinal": ruling.ordinal }),
            lifetime: json!("until withdrawn"),
            verification: Verification::Ruling,
            store: String::from("oko rulings"),
        })
        .collect())
}
