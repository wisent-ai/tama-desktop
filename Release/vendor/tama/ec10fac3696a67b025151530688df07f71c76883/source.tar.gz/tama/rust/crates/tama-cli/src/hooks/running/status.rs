//! Inspect user-global Git dispatcher wiring, and whether one repository's own
//! `core.hooksPath` takes Git away from it. This is not a push verdict;
//! Desktop's install plan displays the same dispatcher descriptions.
//!
//! Git reads one hooks directory per repository, and a repository's own
//! `core.hooksPath` wins over the global one. A repository that sets it runs
//! that directory instead of the dispatcher, so none of the dispatcher's gates
//! (Rust format, quality check, review-push) run on its commits and pushes,
//! and nothing said so: its pushes simply went out unreviewed.
use std::path::{Path, PathBuf};
use tama_core::git::Git;
use tama_core::install::level_plan;

pub fn main(argv: &[String], root: &Path) -> i32 {
    match inspect(argv, root) {
        Ok(Verdict::Dispatched) => libc::EXIT_SUCCESS,
        Ok(Verdict::Bypassed | Verdict::Unwired) => libc::EXIT_FAILURE,
        Err(error) => {
            eprintln!("tama hooks status: {error}");
            libc::EXIT_FAILURE
        }
    }
}

enum Verdict {
    Dispatched,
    Bypassed,
    /// No global `core.hooksPath` names a hooks directory: Git runs no
    /// dispatcher in any repository that sets none of its own, so no commit
    /// or push on the machine passes Tama's review, and nothing else says so.
    Unwired,
}

/// A repository whose own hooks path Git runs instead of the dispatcher.
#[derive(serde::Serialize)]
#[serde(rename_all = "camelCase")]
struct RepositoryHooks {
    repository: String,
    /// The repository's own core.hooksPath; absent when it sets none.
    hooks_path: Option<String>,
    /// True when Git runs the repository's own directory, not the dispatcher.
    bypasses_dispatcher: bool,
    description: String,
}

/// `git -C <repository> <args>`: its answer, `None` for a key Git reports
/// unset (a failing exit with nothing said), or why Git could not answer.
fn git(repository: &Path, args: &[&str]) -> Result<Option<String>, String> {
    let output = Git::of(Some(repository)).output(args)?;
    let said = String::from_utf8_lossy(&output.stderr).trim().to_string();
    if !output.status.success() {
        if said.is_empty() {
            return Ok(None);
        }
        return Err(format!(
            "git -C {} {} ended with {}: {said}",
            repository.display(),
            args.join(" "),
            output.status
        ));
    }
    let answer = String::from_utf8_lossy(&output.stdout).trim().to_string();
    Ok((!answer.is_empty()).then_some(answer))
}

fn repository_hooks(repository: &Path, global: Option<&str>) -> Result<RepositoryHooks, String> {
    let top = git(repository, &["rev-parse", "--show-toplevel"])?.ok_or_else(|| {
        format!(
            "{} has no work tree, so it has no hooks to run",
            repository.display()
        )
    })?;
    let hooks_path = git(
        Path::new(&top),
        &["config", "--local", "--get", "core.hooksPath"],
    )?;
    let bypasses_dispatcher = match (&hooks_path, global) {
        (None, _) => false,
        (Some(own), Some(global)) => own != global,
        (Some(_), None) => true,
    };
    let description = match &hooks_path {
        Some(own) if bypasses_dispatcher => format!(
            "Repository {top} sets its own core.hooksPath {own}: Git runs that directory instead of the global dispatcher, so the Rust format check, the quality check and review-push do not run on its commits and pushes. The dispatcher already runs {top}/.githooks/<hook> after its own gates; remove the override with `git -C {top} config --local --unset core.hooksPath`."
        ),
        Some(own) => format!("Repository {top} names the global hooks directory {own} itself; Git runs the dispatcher for it."),
        None => format!("Repository {top} sets no core.hooksPath of its own; Git runs the global dispatcher for it."),
    };
    Ok(RepositoryHooks {
        repository: top,
        hooks_path,
        bypasses_dispatcher,
        description,
    })
}

fn inspect(argv: &[String], root: &Path) -> Result<Verdict, String> {
    let mut home = None;
    let mut repository = None;
    let mut json = false;
    let mut arguments = argv.iter();
    while let Some(argument) = arguments.next() {
        match argument.as_str() {
            "--json" => json = true,
            "--home" => home = Some(arguments.next().ok_or("--home requires a path")?.clone()),
            "--repo" => {
                repository = Some(PathBuf::from(
                    arguments
                        .next()
                        .ok_or("--repo requires a repository path")?,
                ))
            }
            "--help" | "-h" => {
                println!("usage: tama hooks status [--repo PATH] [--home PATH] [--json]");
                println!("  --repo PATH  also say whether that repository's own core.hooksPath takes Git away from the dispatcher; exits non-zero when it does");
                println!("  exits non-zero as well when no global core.hooksPath is configured, since Git then runs no dispatcher");
                return Ok(Verdict::Dispatched);
            }
            other => return Err(format!("unknown argument {other}")),
        }
    }
    let home = match home {
        Some(home) => home,
        None => std::env::var("HOME")
            .map_err(|error| format!("HOME is unavailable and --home was not supplied: {error}"))?,
    };
    let level = level_plan(root, None, Some(&home)).levels.user_global_git;
    let repository = match repository {
        Some(path) => Some(repository_hooks(
            &path,
            level.current_hooks_path.as_deref(),
        )?),
        None => None,
    };
    if json {
        let document = serde_json::json!({ "userGlobalGit": level, "repository": repository });
        println!(
            "{}",
            serde_json::to_string(&document)
                .map_err(|error| format!("cannot encode Git hook status: {error}"))?
        );
    } else {
        match (&level.current_hooks_path, &level.hooks_path_error) {
            (Some(path), _) => println!("Global core.hooksPath: {path}"),
            (None, Some(error)) => println!("Global core.hooksPath cannot be read: {error}"),
            (None, None) => println!(
                "Global core.hooksPath is not configured: Git runs no Tama dispatcher, so commits and pushes in every repository without its own hooks path pass with no review-commit, review-push or quality check; `tama install --set-git-config` writes the dispatchers and sets it again"
            ),
        }
        for state in &level.dispatcher_states {
            println!("{}", state.description);
        }
        match &repository {
            Some(repository) => println!("{}", repository.description),
            None => println!("Pass --repo <path> to say whether a repository's own core.hooksPath takes Git away from the dispatcher."),
        }
    }
    Ok(match repository {
        Some(repository) if repository.bypasses_dispatcher => Verdict::Bypassed,
        _ if level.current_hooks_path.is_none() => Verdict::Unwired,
        _ => Verdict::Dispatched,
    })
}
