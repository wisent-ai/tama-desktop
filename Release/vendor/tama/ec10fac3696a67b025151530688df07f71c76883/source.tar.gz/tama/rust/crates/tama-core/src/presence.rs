//! Whether a path is there, told apart from whether it can be examined.
//!
//! `Path::exists` answers false for a path it cannot stat (a permission or
//! I/O fault), so a registry, catalog or bundle index read through it would
//! be taken as absent: an empty registry, no catalog metadata, an empty
//! index. Only a path that does not exist is absent here; every other cause
//! is an error that names the path.

use std::io;
use std::path::{Path, PathBuf};

/// True when `path` exists, false when it does not; a path that cannot be
/// examined is an error of the same kind naming the path and the cause.
pub fn present(path: &Path) -> io::Result<bool> {
    match std::fs::metadata(path) {
        Ok(_) => Ok(true),
        Err(error) if error.kind() == io::ErrorKind::NotFound => Ok(false),
        Err(error) => Err(io::Error::new(
            error.kind(),
            format!("{} cannot be examined: {error}", path.display()),
        )),
    }
}

/// Why a command cannot use the `what` it was given at `path`: `<what> not
/// found: <path>` when it is not there, `<what> <path> cannot be examined:
/// <cause>` when it cannot be told; none when it is there.
pub fn absence(path: &Path, what: &str) -> Option<String> {
    match present(path) {
        Ok(true) => None,
        Ok(false) => Some(format!("{what} not found: {}", path.display())),
        Err(error) => Some(format!("{what} {error}")),
    }
}

/// The nearest of `start` and its ancestors that holds `.git`: the checkout
/// `start` is in, or none. An ancestor whose `.git` cannot be examined is the
/// error: passed over, a path inside a checkout read as outside every one.
pub fn checkout_root(start: &Path) -> io::Result<Option<&Path>> {
    for ancestor in start.ancestors() {
        if present(&ancestor.join(".git"))? {
            return Ok(Some(ancestor));
        }
    }
    Ok(None)
}

/// The checkout the file at `path` belongs to: `path` made absolute, then the
/// nearest of its folder and that folder's ancestors holding `.git`; none
/// outside every checkout. Resolved first because a relative path's ancestors
/// end at an empty path, which is no folder. A path that cannot be resolved,
/// or an ancestor whose `.git` cannot be examined, is the error.
pub fn checkout_of_file(path: &Path) -> io::Result<Option<PathBuf>> {
    let absolute = std::fs::canonicalize(path).map_err(|error| {
        io::Error::new(
            error.kind(),
            format!("{} cannot be resolved: {error}", path.display()),
        )
    })?;
    let Some(folder) = absolute.parent() else {
        return Ok(None);
    };
    Ok(checkout_root(folder)?.map(Path::to_path_buf))
}
