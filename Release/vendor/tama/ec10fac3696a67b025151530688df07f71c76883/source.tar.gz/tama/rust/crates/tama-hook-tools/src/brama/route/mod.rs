//! Caller-owned fleet discovery reads the resolver's current publication per request.
use std::process::{Command, Stdio};

use super::credentials::adapter_consumer;

mod observation;
mod published;
mod refusal;

use published::published_adapter;
pub(super) use published::published_state_path;

/// The caller owns the Stado child until its real exit. In a native hook this
/// inherits the hook lifetime group; no detached thread or PID ledger survives it.
/// Background model assessment is owned by the harness adapter, not this reader.
///
/// A published listening adapter is read for each request. Otherwise Stado
/// resolves the current fleet declaration or owns a relay for this request.
/// Bare URL files cannot establish resolver lifetime, generation or admission
/// and are neither read nor written.
pub(super) fn fleet_route() -> Result<(String, Option<super::relay::Relay>), String> {
    if let Some(url) = published_adapter() {
        super::credentials::router_endpoint(&url).map_err(|error| {
            format!(
                "invalid Brama adapter published by this host's resolver in {}: {error}",
                published_state_path().display()
            )
        })?;
        return Ok((url, None));
    }
    let program = crate::assignment::rules::stado_cli()?;
    let adapter = adapter_consumer()?;
    let operation =
        format!("{program} service directory connect brama --consumer {adapter} --json");
    let asked = stado_wait::output(
        Command::new(&program)
            .args([
                "service",
                "directory",
                "connect",
                "brama",
                "--consumer",
                &adapter,
                "--json",
            ])
            .stdin(Stdio::null()),
    );
    let failure = match asked {
        Ok(output) if output.status.success() => Ok(output),
        Ok(output) => {
            if let Some(cause) = refusal::terminal(&output)? {
                return Err(cause);
            }
            Err(format!(
                "Brama route discovery {operation} failed ({}): {}; response: {}",
                output.status,
                String::from_utf8_lossy(&output.stderr).trim(),
                String::from_utf8_lossy(&output.stdout).trim()
            ))
        }
        Err(error) => Err(format!(
            "cannot resolve Brama route with {operation}: {error}"
        )),
    };
    let output = match failure {
        Ok(output) => output,
        // The relay is the other route this host's Stado answers; when it
        // fails too, the refusal names both causes.
        Err(failure) => return super::relay::open(&failure).map(|(url, relay)| (url, Some(relay))),
    };
    let answer: serde_json::Value = serde_json::from_slice(&output.stdout)
        .map_err(|error| format!("cannot decode Brama route from {operation}: {error}"))?;
    let url = answer
        .get("url")
        .and_then(serde_json::Value::as_str)
        .filter(|url| !url.trim().is_empty())
        .ok_or_else(|| {
            format!("Brama route discovery {operation} returned no nonempty text url")
        })?;
    super::credentials::router_endpoint(url)
        .map_err(|error| format!("invalid Brama route from {operation}: {error}"))?;
    Ok((url.to_owned(), None))
}
