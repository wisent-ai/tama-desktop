//! `tama reviews harsh record --findings <file> --attestation <kind>:<session>`:
//! a round of harsh review on a session's recorded task (`session`) or build
//! (`build`) attestation, which stands only once a reviewer other than its
//! author passed it (`ports::harsh_review::attested`).

use tama_hook_tools::ports::harsh_review::{attested, Finding};
use tama_hook_tools::ports::task_attestation::subject::Subject;

/// The recorded attestation `named` names: `<kind>:<session id>`.
fn subject(named: &str) -> Result<Subject, String> {
    match named.split_once(':') {
        Some(("session", id)) => Subject::session(id),
        Some(("build", id)) => Subject::build(id),
        _ => Err(format!(
            "--attestation takes session:<session id> or build:<session id>, not {named:?}"
        )),
    }
}

/// Record the round `findings` and `improvements` on the attestation `named`.
pub(crate) fn record(
    named: &str,
    findings: Vec<Finding>,
    improvements: Vec<Finding>,
) -> Result<String, String> {
    let subject = subject(named)?;
    let shown = subject.show()?;
    attested::record_round(
        &subject.path(),
        subject.id(),
        &shown["attestation"],
        findings,
        improvements,
    )
}
