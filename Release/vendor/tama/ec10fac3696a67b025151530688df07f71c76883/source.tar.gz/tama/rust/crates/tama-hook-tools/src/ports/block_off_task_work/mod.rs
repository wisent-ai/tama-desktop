//! Decision half of `tama-block-off-task-work` (registry hook
//! `block-off-task-work`).
//!
//! A session asked for one thing drifts into repairing whatever else it
//! finds broken, none of which anybody asked for. Each repair is of something
//! really broken, which is what makes the drift hard to see from inside: the
//! work looks like work, and none of it is the task.
//!
//! Relatedness cannot be guessed by a gate, and a gate that guessed it would
//! be wrong in both directions. So it is declared: a session states, in the
//! operator's own words, what it was asked for and which repositories that
//! touches (`tama task scope set`). Every mutation is then checked against
//! that declaration:
//!
//!   * nothing declared — the first write is refused until the session says
//!     what it is working on, which costs one command and makes the answer
//!     to "what is your task" a thing the machine holds, not a memory;
//!   * a repository outside the declaration — refused, naming what was
//!     declared and the instruction that authorised it, so widening the
//!     scope means quoting the operator asking for it;
//!   * a change the operator withheld — his "nie koduj, tylko plan" to this
//!     conversation, recorded as the ruling `no-edit@session:<id>`, refuses
//!     every file this session's edit, write, patch or structural-rewrite
//!     tool would change, in any harness's spelling of that tool, the
//!     repository a `git commit` of it publishes from, and a shell command
//!     that redirects into or changes a repository he withheld (the shared
//!     shell reading, [`shell_changes`]), until his later
//!     `edit@session:<id>`. The rulings are read from Oko's ruling register
//!     as a file (`tama_hooks::oko_rulings::edit`), so no copy of the rule
//!     lives here and no write waits on an Oko process; a scope declared
//!     before his ruling authorises nothing it withholds.
//!
//! The scope is per session and lives beside the other hook state under
//! `~/.tama/task-scope/<session>.json`. Reads are never refused: reading the
//! fleet to answer a question is how a session learns it has drifted.

use std::cell::OnceCell;
use std::path::{Path, PathBuf};

use serde_json::Value;

use crate::ports::python_stdlib::expanduser;
use crate::ports::shell_changes;
use crate::ports::tool_vocabulary::{paths_in, Call, AST_EDIT_DEVICE, WHOLE_FILE_TOOLS};
use tama_hooks::oko_rulings::edit::{self as edit_rulings, Readable};

/// This gate's name, as a model question it leaves unanswered names it.
const GATE: &str = "block-off-task-work";
/// The schema the judge's reading of a shell command under a withheld edit
/// is kept under.
const WITHHELD_CHANGE: &str = "withheld_repository_change";

mod delivery;
mod registers;
mod scope;
pub mod scope_cli;
mod withheld;

use delivery::delivery_paths;
pub use scope::{refusal, repository_of, TaskScope};
pub(crate) use scope::{SCOPE_HOME_RELATIVE, WORKSPACE_HOME_RELATIVE};
use withheld::edit_unadmitted;
pub use withheld::unread_note;

/// Every path a call would write; `block-unapproved-tests` reads the same.
/// A structural rewrite whose request cannot be read is an error: read as
/// naming no file, the files it changes would never be logged or judged.
pub fn written_paths(call: &Call) -> Result<Vec<String>, String> {
    let mut paths = Vec::new();
    if !call.changes_files() {
        return Ok(paths);
    }
    if let Some(input) = call.input() {
        paths.extend(paths_in(input).into_iter().map(str::to_string));
    }
    if let Some(patch) = call.patch() {
        paths.extend(crate::ports::write_payload::hashline::touched_paths(patch)?);
    }
    if call.path() == Some(AST_EDIT_DEVICE) {
        paths.extend(ast_edit_paths(call)?);
    }
    Ok(paths)
}

/// The targets a structural rewrite names, so the files it changes count as
/// this session's writes like those of any other edit.
fn ast_edit_paths(call: &Call) -> Result<Vec<String>, String> {
    let content = call.content().ok_or_else(|| {
        format!("the {AST_EDIT_DEVICE} request carries no content naming its targets")
    })?;
    let request: Value = serde_json::from_str(content).map_err(|error| {
        format!("the {AST_EDIT_DEVICE} request is not JSON, so its targets cannot be read: {error}")
    })?;
    Ok(paths_in(&request).into_iter().map(str::to_string).collect())
}

/// Why this payload is work outside the session's declared task, if it is.
/// `register` holds the operator's ruling register as this decision reads
/// it: read at most once, and only when a change reaches a repository, so
/// the note a passing change gets ([`unread_note`]) names the entries this
/// decision was made on, and a caller deciding many calls passes a fresh
/// cell for each.
pub fn evaluate(payload: &Value, register: &OnceCell<Readable>) -> Option<String> {
    let home = PathBuf::from(expanduser("~"));
    let session = tama_hooks::session_record::session_id_of(payload);
    let call = Call::of(payload);
    let input = match call.input() {
        Some(input) => input,
        None => &Value::Null,
    };
    let mut paths = match written_paths(&call) {
        Ok(paths) => paths,
        Err(error) => return Some(format!("BLOCKED: block-off-task-work: {error}")),
    };
    // Only a whole-file write replaces another session's unfinished change.
    // An anchored edit applies to the file as it is now, that session's
    // change included, which is two sessions working on one piece of code;
    // the operator's rule is that they do (~/agents/finishing.md).
    if call.is_one_of(WHOLE_FILE_TOOLS) {
        if let Some(refusal) = delivery::foreign_overwrite(&home, &session, &paths, input) {
            return Some(refusal);
        }
    }
    delivery::record_writes(&home, &session, &paths, input);
    if call.is_shell() {
        if let Some(command) = call.command() {
            match delivery_paths(command, input) {
                Ok(delivered) => paths.extend(delivered),
                Err(refusal) => return Some(refusal),
            }
            if let Some(refusal) = shell_edit_unadmitted(command, input, &session, &home, register)
            {
                return Some(refusal);
            }
        }
    }
    // Tama captures the operator's prompt verbatim per session; the digest
    // of the current one is what a scope has to be declared against, so a
    // scope written for the previous instruction stops authorising work the
    // moment a new one arrives. An assignment that cannot be read is said:
    // read as no instruction, every scope would be judged against an empty one.
    let instruction = match crate::assignment::load(&session) {
        Ok(assignment) => assignment.map(|assignment| assignment.turn_digest),
        Err(error) => {
            return Some(format!(
                "BLOCKED: block-off-task-work: this session's assignment cannot be read, so the work's scope cannot be judged: {error}"
            ))
        }
    };
    // A session holding the supervisor role reads, records, assigns and
    // sends; a change to a product repository is handed to an executor, so
    // its executors are watched while the change is made. Its role is read
    // once, for the first path that lies in a repository.
    let mut supervising: Option<bool> = None;
    for path in paths {
        let repository = match repository_of(&path, &home) {
            Ok(Some(repository)) => repository,
            Ok(None) => continue,
            Err(error) => return Some(format!("BLOCKED: block-off-task-work: {error}")),
        };
        let supervisor = match supervising {
            Some(known) => known,
            None => match tama_hooks::supervisor_stop::is_supervisor(&session) {
                Ok(known) => {
                    supervising = Some(known);
                    known
                }
                Err(error) => {
                    return Some(format!(
                        "BLOCKED: block-off-task-work: this session's Oko role cannot be read, so whether it may change {repository} cannot be judged: {error}"
                    ))
                }
            },
        };
        if supervisor {
            return Some(supervisor_refusal(&session, &repository));
        }
        if let Some(found) = edit_unadmitted(
            &repository,
            &session,
            register.get_or_init(edit_rulings::readable),
        ) {
            return Some(found);
        }
        if let Some(found) = refusal(&repository, &session, instruction.as_deref(), &home) {
            return Some(found);
        }
    }
    None
}

/// Why a shell `command` of this session is refused under a ruling of the
/// operator that withholds its edits: it reaches a workspace repository the
/// ruling withholds and either redirects output into it, which writes it by
/// the shell's grammar, or changes it as a model reads the command
/// ([`shell_changes`]). Nothing is read further while no ruling withholds
/// this session's edits, so a session he left alone runs its shell as before;
/// a command that only reads a withheld repository passes, since reading and
/// planning stay possible. Each repository the command reaches is decided by
/// [`edit_unadmitted`] over the register read once.
fn shell_edit_unadmitted(
    command: &str,
    input: &Value,
    session: &str,
    home: &Path,
    register: &OnceCell<Readable>,
) -> Option<String> {
    let register = register.get_or_init(edit_rulings::readable);
    if !edit_rulings::withholds_any(register, session) {
        return None;
    }
    let cwd = match delivery::working_directory(input) {
        Ok(cwd) => cwd,
        Err(error) => return Some(format!("BLOCKED: block-off-task-work: {error}")),
    };
    let place = |path: &Path, cwd: &Path| -> Option<String> {
        let absolute = cwd.join(path);
        match repository_of(&absolute.to_string_lossy(), home) {
            Ok(Some(repository)) => edit_unadmitted(&repository, session, register),
            Ok(None) => None,
            Err(error) => Some(format!("BLOCKED: block-off-task-work: {error}")),
        }
    };
    match shell_changes::reach(command, &cwd, &place) {
        Ok(reached) => shell_changes::judged(GATE, WITHHELD_CHANGE, command, &reached),
        Err(reason) => Some(reason),
    }
}

/// Why a supervisor session may not change `repository`, naming the
/// executors recorded under it to hand the change to, the commands that do,
/// or why they could not be read.
fn supervisor_refusal(session: &str, repository: &str) -> String {
    let handed = match tama_hooks::supervisor_stop::executors_of(session) {
        Ok(executors) if executors.is_empty() => {
            "no executor is recorded under it yet: start one with oko sessions start and record it with oko sessions role set <id> executor --supervisor <this session>".to_string()
        }
        Ok(executors) => format!("hand it to an executor recorded under it: {}", executors.join(", ")),
        Err(error) => format!("its executors could not be read: {error}"),
    };
    format!(
        "BLOCKED: block-off-task-work: session {session} holds the supervisor role, which reads registers and transcripts, records, assigns and sends, and does not edit or commit product repositories; the change to {repository} is an executor's: {handed}. Record it (oko defects record), assign it (oko defects assign <id> --owner <executor>) and send it (oko sessions send <executor> --defect <id> --text ...)."
    )
}
