//! Which of a session's states a commit already took, read from history once.
//!
//! The replay asks, for each edit, whether the bytes it left are what a
//! commit HEAD reaches recorded at that path. The blobs every commit since
//! the session began wrote, by path, are read once through
//! [`crate::evidence::history::blobs`] the first time a state is asked
//! about, and each question is answered from that.

use std::cell::OnceCell;
use std::collections::{BTreeMap, BTreeSet};
use std::fs;
use std::path::{Path, PathBuf};

use super::git;

pub(super) struct Committed<'a> {
    transaction: &'a git::Transaction,
    since: Option<String>,
    written: OnceCell<BTreeMap<PathBuf, BTreeSet<String>>>,
}

impl<'a> Committed<'a> {
    /// The states commits HEAD reaches made since `since` (a commit date;
    /// every commit when none), read when first asked.
    pub(super) fn new(transaction: &'a git::Transaction, since: Option<String>) -> Self {
        Self {
            transaction,
            since,
            written: OnceCell::new(),
        }
    }

    /// Every blob a commit since `since` wrote, by the path it wrote it at.
    fn read(&self) -> Result<BTreeMap<PathBuf, BTreeSet<String>>, String> {
        let since = self.since.as_ref().map(|since| format!("--since={since}"));
        let mut range = vec!["HEAD"];
        range.extend(since.as_deref());
        crate::evidence::history::blobs(&self.transaction.root, &range)
    }

    /// Whether `text` is what `path` holds in a commit HEAD reaches made since
    /// the session began: a state of the session's that a commit already took.
    pub(super) fn took(&self, path: &Path, text: &str) -> Result<bool, String> {
        let written = match self.written.get() {
            Some(written) => written,
            None => {
                let read = self.read()?;
                self.written.get_or_init(|| read)
            }
        };
        let file = self.transaction.area.join("committed");
        fs::write(&file, text)
            .map_err(|cause| format!("cannot write {}: {cause}", file.display()))?;
        let object = self
            .transaction
            .git()
            .paths(&[file.as_path()])
            .text(&["hash-object", "--"])?;
        Ok(written
            .get(path)
            .is_some_and(|blobs| blobs.contains(object.trim())))
    }
}
