//! Refuse model training, and whole-set model runs, on the operator's own
//! workstation.
//!
//! A training run started on the operator's workstation because a
//! checkpoint was in the local cache and the binary was already built takes
//! the machine from every other job he has open, for as long as it runs.
//! That is a critical mistake, not an inconvenience, and it is refused.
//!
//! The rule was already written: heavy work goes through Stado onto a host
//! the fleet places it on, and the queue is how the operator sees what a
//! machine is doing. This gate is the half no configuration covers — the
//! command that trains, or reads a whole labelled set through a model, typed
//! as if the workstation were a training host.
//!
//! Whether a command trains a model, or runs a whole labelled set through
//! one, is what the command does, not its words: a list of trainer programs,
//! modules and script names is the keyword logic `block-keyword-literals`
//! forbids, misses every launcher nobody listed, and refuses any script that
//! happens to be called `train.py`. The command the call would run is read
//! by a model through Oko's model call (`ports::model_judgement`), with the
//! operator's rule in the prompt (`judge-prompt.md`). A command whose program
//! is `stado` passes without a question: `stado submit` is the route the rule
//! names. A question the judge leaves unanswered refuses with its cause, as
//! for every model-judged gate (`model_judgement::unanswered`). A session in which the operator, outside
//! the agent, exported `LOCAL_MODEL_TRAINING_APPROVED=1` passes — the same
//! shape the hook-edit gate uses, so the key is never inside the agent's
//! reach.

use std::path::Path;

use serde_json::Value;

use crate::ports::model_judgement;
use crate::ports::python_stdlib::shell_tokens;
use crate::ports::shell_text;
use crate::ports::tool_vocabulary::Call;

const TAG: &str = "block-local-model-training";
const PROMPT: &str = include_str!("judge-prompt.md");
const COMMAND_SLOT: &str = "{command}";
/// The schema the judge answers under and the two options it chooses from.
const JUDGEMENT: &str = "local_model_training";
const PASS: &str = "PASS";
const BLOCK: &str = "BLOCK";

/// Set by the operator outside the agent session; never by an agent.
pub const APPROVAL_VARIABLE: &str = "LOCAL_MODEL_TRAINING_APPROVED";
/// The value of [`APPROVAL_VARIABLE`] that approves, as the operator's
/// approvals page declares it: https://tama.wisent.com/docs/hook-management
const APPROVED: &str = "1";

/// The fleet's own placement command; anything it wraps runs elsewhere.
const FLEET_PROGRAM: &str = "stado";

fn refusal(detected: &str) -> String {
    format!(
        "BLOCKED: model training and whole-set model runs are forbidden on this workstation \
         so they cannot monopolize resources needed for interactive work. Submit the work to \
         the fleet instead — `stado submit` places it on a training host and \
         the queue shows it. Only the operator, outside the agent session, may allow a local run \
         by exporting {APPROVAL_VARIABLE}={APPROVED}. Detected: {detected}"
    )
}

fn program_is(token: &str, program: &str) -> bool {
    Path::new(token).file_name().and_then(|name| name.to_str()) == Some(program)
}

/// Whether every segment of the command hands its work to the fleet.
fn placed_on_fleet(command: &str) -> bool {
    let segments = shell_text::commands(command);
    !segments.is_empty()
        && segments.iter().all(|segment| {
            shell_tokens(segment)
                .first()
                .is_some_and(|program| program_is(program, FLEET_PROGRAM))
        })
}

/// The refusal the model's reading of `command` earns when it trains or runs
/// a whole set through a model here, or the refusal an unanswered question
/// earns (`model_judgement::unanswered`); nothing when it passes. The model
/// is never asked inside the hook, where every call would wait on it: a
/// command not yet judged is refused naming `tama judgement ask`.
fn command_refusal(command: &str) -> Option<String> {
    if placed_on_fleet(command) {
        return None;
    }
    let prompt = PROMPT.replace(COMMAND_SLOT, command.trim());
    match model_judgement::choose_deferred(&prompt, JUDGEMENT, &[PASS, BLOCK]) {
        Ok(judged) => (judged.choice == BLOCK).then(|| refusal(&judged.reason)),
        Err(unanswered) => model_judgement::unanswered::refusal(TAG, &unanswered, Some(command)),
    }
}

/// The executable text this call carries, read as its tool's language.
fn executable_text(payload: &Value) -> String {
    let call = Call::of(payload);
    let Some(text) = call.executable() else {
        return String::new();
    };
    let tool = call.kind().unwrap_or_default();
    shell_text::effective_for_tool(&tool, &text)
}

/// The refusal this call earns, or `None` when it passes.
pub fn evaluate(payload: &Value, approval: Option<&str>) -> Option<String> {
    if approval.map(str::trim) == Some(APPROVED) {
        return None;
    }
    let text = executable_text(payload);
    if text.trim().is_empty() {
        return None;
    }
    command_refusal(&text)
}
