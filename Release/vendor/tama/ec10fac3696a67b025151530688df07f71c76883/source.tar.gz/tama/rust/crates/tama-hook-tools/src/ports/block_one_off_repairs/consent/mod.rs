//! Whether the operator's rulings admit a build, and whether Oko holds it.
//!
//! One record carries that word: the operator's standing ruling (`build`,
//! `build:<product>` and their withdrawals `no-build`, `no-build:<product>`),
//! as Oko's one admission decision answers it
//! ([`crate::capability::standing`]); a withdrawal that stands refuses the
//! build, quoting the ruling. Where no ruling decides it, Oko holds a
//! session's build until every open item carries its pushed repair. No
//! build is ever asked of him, and no answer to a build question or session
//! capability `build` admits one: the capability device refuses to request
//! it, and what he says in the conversation is read into his rulings.
//!
//! Without a ruling that consents, a build of a product outside the
//! repositories the session declared its task touches (`tama task scope set
//! --repository`) is refused: a session builds what its task changes, never
//! another product on its own judgement ([`outside_task`]).

use std::path::Path;

use crate::capability::standing;
use crate::ports::block_off_task_work::TaskScope;

pub(crate) mod attested;
mod subjects;

/// The action class a build ruling is recorded under.
pub const BUILD_TOOL: &str = "build";

/// What Oko's admission says about `session`'s build of every product in
/// `subjects` (`None`: the products cannot be established, so only a ruling
/// on every product decides it): forbidden when one product's build is,
/// unread or waiting when one product's is, consented when every product's
/// is, otherwise undecided. The session's open defects are the build's
/// purposes, and Oko's open-work rule applies.
fn standing_build(subjects: Option<&[String]>, session: &str) -> standing::Ruled {
    let Some(products) = subjects else {
        return standing::ruled(BUILD_TOOL, None, Some(session));
    };
    let mut consented = Vec::new();
    let mut held = None;
    let mut undecided = false;
    for product in products {
        match standing::ruled(
            BUILD_TOOL,
            Some(product.to_lowercase().as_str()),
            Some(session),
        ) {
            standing::Ruled::Forbidden(reason) => return standing::Ruled::Forbidden(reason),
            standing::Ruled::Unread(cause) => return standing::Ruled::Unread(cause),
            standing::Ruled::Undecidable(cause) => return standing::Ruled::Undecidable(cause),
            standing::Ruled::Waiting(reason) => held = Some(reason),
            standing::Ruled::Consented(reason) => consented.push(reason),
            standing::Ruled::Unruled => undecided = true,
        }
    }
    if let Some(reason) = held {
        return standing::Ruled::Waiting(reason);
    }
    if undecided || consented.is_empty() {
        standing::Ruled::Unruled
    } else {
        standing::Ruled::Consented(consented.join("; "))
    }
}

/// Whether the build `program args` runs from `cwd` in `session`, as Oko's
/// one admission decision answers it (`oko admit build`): a standing
/// withdrawal refuses, a standing consent admits, and while no ruling decides
/// and open items carry no pushed repair, Oko holds it until they do. `Err`
/// quotes what refused it: the ruling, the items it waits on, or why Oko
/// could not be read. `Ok(false)`: nothing decides it and nothing holds it.
pub(crate) fn build_consented(
    program: &str,
    args: &[String],
    cwd: &Path,
    session: &str,
) -> Result<bool, String> {
    let subjects = subjects::build_subjects(program, args, cwd);
    let ruled = standing_build(subjects.as_deref(), session);
    // Only the operator's word admits a product the session's task never
    // names: a standing ruling that consents to its build.
    if !matches!(ruled, standing::Ruled::Consented(_)) {
        if let Some(outside) = outside_task(subjects.as_deref(), session)? {
            return Err(outside);
        }
    }
    match ruled {
        standing::Ruled::Forbidden(reason) | standing::Ruled::Waiting(reason) => Err(reason),
        standing::Ruled::Unread(cause) => Err(format!(
            "Oko's admission could not be read ({cause}); an unread answer is not an admission"
        )),
        standing::Ruled::Undecidable(skew) => Err(format!(
            "{skew}; until that Oko is installed the build waits: never ask the operator for it"
        )),
        standing::Ruled::Consented(admitted_by) => {
            eprintln!("block-one-off-repairs: build admitted by {admitted_by}");
            Ok(true)
        }
        standing::Ruled::Unruled => Ok(false),
    }
}

/// Why a build of `subjects` is outside the repositories this session
/// declared its task touches (`tama task scope set --repository`), when it
/// declared any: a build serves the task, so a product the task never names
/// is not built on the session's own judgement, and no build of it is asked
/// of the operator. A declaration that cannot be read refuses with its cause.
fn outside_task(subjects: Option<&[String]>, session: &str) -> Result<Option<String>, String> {
    let Some(products) = subjects else {
        return Ok(None);
    };
    let Some(scope) = TaskScope::read(session, &crate::util::home_dir())? else {
        return Ok(None);
    };
    if scope.repositories.is_empty() {
        return Ok(None);
    }
    let outside: Vec<&str> = products
        .iter()
        .filter(|product| {
            !scope
                .repositories
                .iter()
                .any(|repository| repository.eq_ignore_ascii_case(product))
        })
        .map(String::as_str)
        .collect();
    if outside.is_empty() {
        return Ok(None);
    }
    Ok(Some(format!(
        "the build of {} is outside this session's task, which touches {}: build only what the \
         task changes, and never ask the operator for a build of another product",
        outside.join(", "),
        scope.repositories.join(", ")
    )))
}
