//! Reading a stored projection back: what a valid state looks like, and
//! the result one transition returns.
//!
//! Split out of `state/mod.rs`, which had grown past the
//! three-hundred-line limit; the store itself stays there.

use super::{phase, projections, HookState};

/// `validState(value, hookId)`: the hook state `value` holds for `hook_id`,
/// or the check it failed. Unknown keys are kept in `extra`.
pub fn valid_state(value: &serde_json::Value, hook_id: &str) -> Result<HookState, String> {
    let state: HookState = serde_json::from_value(value.clone())
        .map_err(|error| format!("it is not an adaptive hook state: {error}"))?;
    if state.schema != projections::SCHEMA {
        return Err(format!(
            "its schema is {:?}, not {:?}",
            state.schema,
            projections::SCHEMA
        ));
    }
    if state.hook_id != hook_id {
        return Err(format!(
            "it is the state of {:?}, not of {hook_id:?}",
            state.hook_id
        ));
    }
    if !phase::ALL.contains(&state.phase.as_str()) {
        return Err(format!(
            "its phase {:?} is none of {:?}",
            state.phase,
            phase::ALL
        ));
    }
    if state.phase == phase::WARNING && state.warning_source_digest.is_none() {
        return Err("it warns without the source digest it warns about".to_string());
    }
    if state.journal_count.is_negative() {
        return Err(format!(
            "its journal count {} is negative",
            state.journal_count
        ));
    }
    Ok(state)
}

/// Result of `store.update` / engine `finish` (`TransitionResult` in JS).
#[derive(Debug, Clone)]
pub struct TransitionResult {
    pub ok: bool,
    pub persisted: bool,
    pub mode: String,
    pub transition: Option<String>,
    pub reason: Option<String>,
    pub state: HookState,
}

impl TransitionResult {
    pub fn to_value(&self) -> serde_json::Value {
        let mut map = serde_json::Map::new();
        map.insert("ok".into(), self.ok.into());
        map.insert("persisted".into(), self.persisted.into());
        map.insert("mode".into(), self.mode.clone().into());
        if let Some(transition) = &self.transition {
            map.insert("transition".into(), transition.clone().into());
        }
        if let Some(reason) = &self.reason {
            map.insert("reason".into(), reason.clone().into());
        }
        map.insert("state".into(), self.state.to_value());
        serde_json::Value::Object(map)
    }
}
