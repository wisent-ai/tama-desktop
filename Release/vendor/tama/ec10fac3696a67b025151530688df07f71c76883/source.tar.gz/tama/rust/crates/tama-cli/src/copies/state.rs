//! Git's answers about one candidate checkout. This file reads; the
//! classification in [`super::discovery`] decides.

use std::collections::HashSet;
use std::fs;
use std::path::Path;

use crate::gitcmd::git;

/// A linked worktree has a private Git directory and a distinct common Git
/// directory. A submodule also has a `.git` file, but owns its metadata and
/// remains a dependency checkout rather than a linked worktree.
pub(super) fn is_linked_worktree(dir: &Path) -> bool {
    if !dir.join(".git").is_file() {
        return false;
    }
    let Ok(paths) = git(
        dir,
        &[
            "rev-parse",
            "--path-format=absolute",
            "--git-dir",
            "--git-common-dir",
        ],
    ) else {
        return false;
    };
    let mut paths = paths.lines();
    matches!((paths.next(), paths.next()), (Some(private), Some(common)) if private != common)
}

/// Linked worktrees registered by a full checkout, including ones outside
/// the root being walked. Directly discovered entries are deduplicated later.
/// A checkout with no `worktrees` record owns none; git metadata that exists
/// and cannot be read is an error naming it. Read as owning none, a copy
/// whose worktrees could not be listed was removable and its worktrees left
/// orphaned.
pub(super) fn linked_worktrees(dir: &Path) -> Result<Vec<String>, String> {
    let metadata = if dir.join(".git").is_dir() {
        dir.join(".git")
    } else {
        std::path::PathBuf::from(git(dir, &["rev-parse", "--absolute-git-dir"])?.trim())
    };
    let listing = metadata.join("worktrees");
    let entries = match fs::read_dir(&listing) {
        Ok(entries) => entries,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(Vec::new()),
        Err(error) => return Err(format!("cannot list {}: {error}", listing.display())),
    };
    let mut paths = Vec::new();
    for entry in entries {
        let entry = entry.map_err(|error| format!("cannot list {}: {error}", listing.display()))?;
        let record = entry.path().join("gitdir");
        let text = fs::read_to_string(&record)
            .map_err(|error| format!("cannot read {}: {error}", record.display()))?;
        let recorded = text.trim();
        let path = match recorded.strip_suffix("/.git") {
            Some(stripped) => stripped,
            None => recorded,
        };
        if !path.is_empty() {
            paths.push(path.to_string());
        }
    }
    Ok(paths)
}

pub(super) fn owns_worktrees(dir: &Path) -> Result<bool, String> {
    Ok(!linked_worktrees(dir)?.is_empty())
}

pub(super) fn dirty(dir: &Path) -> Result<bool, String> {
    if git(dir, &["rev-parse", "--is-bare-repository"])?.trim() == "true" {
        return Ok(false);
    }
    Ok(!git(dir, &["status", "--porcelain"])?.trim().is_empty())
}

/// Where this checkout came from. Two directories are the same repository
/// when they were cloned from the same place, so the origin URL is the
/// comparison, and a checkout with no `origin` cannot be compared at all.
pub(super) fn origin(dir: &Path) -> Option<String> {
    let url = git(dir, &["remote", "get-url", "origin"]).ok()?;
    let trimmed = url.trim();
    if trimmed.is_empty() {
        return None;
    }
    Some(trimmed.to_string())
}

/// `git@github.com:wisent-ai/lem.git`, `https://github.com/wisent-ai/lem.git`
/// and `https://github.com/wisent-ai/lem` name one repository to a reader and
/// three different strings to `==`. What is kept is the host and the path;
/// what is dropped is only spelling: the scheme, any user prefix, a `.git`
/// suffix and a trailing slash.
pub(super) fn normalize_origin(url: &str) -> String {
    let without_scheme = url.split_once("://").map_or(url, |(_, rest)| rest);
    let after_user = without_scheme
        .rsplit_once('@')
        .map_or(without_scheme, |(_, rest)| rest);
    let unified = after_user.replacen(':', "/", 1);
    let trimmed = unified.trim_end_matches('/');
    trimmed
        .strip_suffix(".git")
        .unwrap_or(trimmed)
        .to_lowercase()
}

/// The commits this checkout's history starts from, sorted and joined. Two
/// checkouts whose origins differ can still be one repository: a repository
/// GitHub moved keeps its old address in every checkout cloned before the
/// move, and that address never compares equal to the new one. Their first
/// commits are the same, and no move changes them. None when git cannot
/// answer, as in a repository with no commit yet.
pub(super) fn first_commits(dir: &Path) -> Option<String> {
    let listed = git(dir, &["rev-list", "--max-parents=0", "HEAD"]).ok()?;
    let mut roots: Vec<&str> = listed
        .lines()
        .map(str::trim)
        .filter(|line| !line.is_empty())
        .collect();
    if roots.is_empty() {
        return None;
    }
    roots.sort_unstable();
    Some(roots.join(","))
}

/// An origin that names a directory on this filesystem rather than a server:
/// what `git clone /path/to/repo` and `git clone file:///path` write. The
/// answer is the path itself, so the caller can ask whether that path is one
/// of the canonical checkouts it already found.
pub(super) fn local_origin_path(url: &str) -> Option<String> {
    let path = match url.split_once("://") {
        Some(("file", rest)) => rest,
        Some(_) => return None,
        None => url,
    };
    // An scp-style `user@host:path` has a colon before any slash; a Windows
    // drive letter cannot occur on this machine.
    if let Some(colon) = path.find(':') {
        path[..colon].find('/')?;
    }
    let trimmed = path.trim_end_matches('/');
    let without_git = trimmed.strip_suffix("/.git").unwrap_or(trimmed);
    Some(without_git.to_string())
}

/// Account for every stored object, including dangling commits and annotated
/// tags. A canonical witness must retain the objects through its own refs and
/// storage, not through an alternate object directory that removal could lose.
pub(super) fn history<'a>(
    dir: &Path,
    owner: Option<&str>,
    canonicals: impl Iterator<Item = &'a str>,
) -> Result<(bool, Option<String>), String> {
    if git(dir, &["rev-parse", "--verify", "--quiet", "HEAD"]).is_err() {
        git(dir, &["symbolic-ref", "--quiet", "HEAD"])?;
    }
    let objects = git(
        dir,
        &[
            "--no-replace-objects",
            "cat-file",
            "--batch-all-objects",
            "--batch-check=%(objecttype) %(objectname)",
        ],
    )?;
    let remote = git(
        dir,
        &[
            "--no-replace-objects",
            "rev-list",
            "--objects",
            "--remotes",
            "--no-object-names",
            "--missing=print",
        ],
    )?;
    if remote.lines().any(|line| line.starts_with('?')) {
        return Err(format!(
            "{}: remote-tracking history has missing Git objects; no retention proof is available",
            dir.display()
        ));
    }
    let published: HashSet<_> = remote.lines().collect();
    let ids: Vec<_> = objects
        .lines()
        .filter_map(|line| line.split_once(' ').map(|(_, id)| id))
        .collect();
    let unpublished = ids.iter().any(|id| !published.contains(id));
    if !unpublished || ids.is_empty() {
        return Ok((unpublished, None));
    }
    for candidate in canonicals {
        if owner.is_some_and(|owner| owner != candidate) {
            continue;
        }
        let candidate = Path::new(candidate);
        let reachable = git(
            candidate,
            &[
                "--no-replace-objects",
                "rev-list",
                "--objects",
                "--all",
                "--no-object-names",
                "--missing=print",
            ],
        )?;
        if reachable.lines().any(|line| line.starts_with('?')) {
            continue;
        }
        let retained: HashSet<_> = reachable.lines().collect();
        if !ids.iter().all(|id| retained.contains(id)) {
            continue;
        }
        if !independent_objects(candidate)? {
            continue;
        }
        return Ok((unpublished, Some(candidate.to_string_lossy().into_owned())));
    }
    Ok((unpublished, None))
}

fn independent_objects(repository: &Path) -> Result<bool, String> {
    crate::gitcmd::verify_repository(repository)?;
    let git_directory = git(repository, &["rev-parse", "--absolute-git-dir"])?;
    let git_directory = Path::new(git_directory.trim());
    let physical = fs::canonicalize(git_directory)
        .map_err(|error| format!("{}: {error}", git_directory.display()))?;
    if physical != git_directory || !physical.starts_with(crate::gitcmd::canonical(repository)) {
        return Ok(false);
    }
    let counts = git(repository, &["count-objects", "-v"])?;
    if counts.lines().any(|line| line.starts_with("alternate:")) {
        return Ok(false);
    }
    object_storage_has_no_links(&git_directory.join("objects"))
}

fn object_storage_has_no_links(path: &Path) -> Result<bool, String> {
    let metadata =
        fs::symlink_metadata(path).map_err(|error| format!("{}: {error}", path.display()))?;
    if metadata.file_type().is_symlink() {
        return Ok(false);
    }
    if metadata.is_dir() {
        for entry in fs::read_dir(path).map_err(|error| format!("{}: {error}", path.display()))? {
            let entry = entry.map_err(|error| format!("{}: {error}", path.display()))?;
            if !object_storage_has_no_links(&entry.path())? {
                return Ok(false);
            }
        }
    }
    Ok(true)
}
