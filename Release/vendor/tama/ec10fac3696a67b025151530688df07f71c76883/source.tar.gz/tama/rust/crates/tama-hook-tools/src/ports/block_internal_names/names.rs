//! Where the internal names come from. Nothing here lists a name: each is
//! read at run time from what owns it — the Stado host registry, the vault
//! listing and this account's own home — so a renamed host or item is known
//! the moment its owner knows it.

use std::collections::BTreeSet;
use std::path::PathBuf;
use std::process::Command;

use serde_json::Value;

/// A registry file to read instead of this machine's, so a test runs against
/// a fixture.
const REGISTRY_ENV: &str = "TAMA_INTERNAL_NAMES_REGISTRY";
const REGISTRY_DEFAULT: &str = "~/.stado/local-storage/registry.json";
/// A file holding a vault listing (`stado credentials ls --json` output) to
/// read instead of asking Stado, so a test runs against a fixture.
const VAULT_LISTING_ENV: &str = "TAMA_INTERNAL_NAMES_VAULT_LISTING";
const HOME_ROOTS: &[&str] = &["/Users/", "/home/"];
/// The release manifest a product checkout carries, which names its release.
pub(super) const RELEASE_MANIFEST: &str = ".wisent-release.json";
/// The vault tag that names the role an item plays.
const ROLE_TAG: &str = "stado:role:";

pub struct Names {
    /// Host names, host addresses and account names: refused anywhere.
    pub everywhere: BTreeSet<String>,
    /// Vault item ids: refused anywhere, since a secret is asked for by role.
    pub vault_items: BTreeSet<String>,
    /// Why a source could not be read; printed, never silently dropped.
    pub unread: Vec<String>,
}

pub fn expand(path: &str) -> PathBuf {
    match path.strip_prefix("~/") {
        Some(rest) => crate::util::home_dir().join(rest),
        None => PathBuf::from(path),
    }
}

fn keep(set: &mut BTreeSet<String>, value: &str) {
    let value = value.trim().to_lowercase();
    if !value.is_empty() {
        set.insert(value);
    }
}

/// The account a `/Users/<name>/…` or `/home/<name>/…` string belongs to.
fn account_of(text: &str) -> Option<&str> {
    HOME_ROOTS.iter().find_map(|root| {
        let rest = text.split_once(root)?.1;
        rest.split('/').next().filter(|name| !name.is_empty())
    })
}

fn collect_accounts(value: &Value, found: &mut BTreeSet<String>) {
    match value {
        Value::String(text) => {
            if let Some(account) = account_of(text) {
                keep(found, account);
            }
        }
        Value::Array(items) => items.iter().for_each(|item| collect_accounts(item, found)),
        Value::Object(map) => map.values().for_each(|item| collect_accounts(item, found)),
        _ => {}
    }
}

fn strings(value: Option<&Value>) -> impl Iterator<Item = &str> {
    value
        .and_then(Value::as_array)
        .into_iter()
        .flatten()
        .filter_map(Value::as_str)
}

fn override_or(env: &str, default: &str) -> PathBuf {
    match std::env::var(env) {
        Ok(value) if !value.is_empty() => expand(&value),
        _ => expand(default),
    }
}

fn registry_names(found: &mut BTreeSet<String>, unread: &mut Vec<String>) {
    let path = override_or(REGISTRY_ENV, REGISTRY_DEFAULT);
    let document: Value = match std::fs::read(&path).map(|bytes| serde_json::from_slice(&bytes)) {
        Ok(Ok(document)) => document,
        Ok(Err(error)) => return unread.push(format!("{}: {error}", path.display())),
        Err(error) => return unread.push(format!("{}: {error}", path.display())),
    };
    for target in document
        .get("targets")
        .and_then(Value::as_array)
        .into_iter()
        .flatten()
    {
        if let Some(name) = target.get("name").and_then(Value::as_str) {
            keep(found, name);
        }
        for hostname in strings(target.get("hostnames")) {
            keep(found, hostname);
            if let Some((short, _)) = hostname.split_once('.') {
                keep(found, short);
            }
        }
        for identity in target
            .get("identities")
            .and_then(Value::as_array)
            .into_iter()
            .flatten()
        {
            if let Some(user) = identity.get("user").and_then(Value::as_str) {
                keep(found, user);
            }
        }
    }
    collect_accounts(&document, found);
}

/// Fleet host identities, or the registry operation and cause that prevented reading them.
pub fn registry_hosts() -> Result<BTreeSet<String>, String> {
    let mut found = BTreeSet::new();
    let mut unread = Vec::new();
    registry_names(&mut found, &mut unread);
    unread
        .is_empty()
        .then_some(found)
        .ok_or_else(|| unread.join("; "))
}

/// Where the last vault listing Stado gave is kept: item ids and tags, no
/// secret, read again when Stado's vault does not answer.
fn kept_listing() -> PathBuf {
    crate::util::home_dir()
        .join(".tama")
        .join("internal-names")
        .join("vault-listing.json")
}

/// Keep `bytes`, the listing Stado just gave, for the next vault outage.
fn keep_listing(bytes: &[u8]) -> std::io::Result<()> {
    let kept = kept_listing();
    if let Some(parent) = kept.parent() {
        std::fs::create_dir_all(parent)?;
    }
    std::fs::write(&kept, bytes)
}

/// Read the declared listing or Stado's current answer, keeping each answer
/// Stado gives. When Stado's vault does not answer, the names are the last
/// listing it gave: every service runs on its own, and a commit message is
/// judged for names, which an hour-old listing still holds. That listing's
/// age and why Stado did not answer are said on stderr every time it is
/// used. With no listing ever kept, the failed read stays unread.
fn vault_listing(unread: &mut Vec<String>) -> Option<Vec<u8>> {
    if let Ok(path) = std::env::var(VAULT_LISTING_ENV) {
        if !path.is_empty() {
            return match std::fs::read(expand(&path)) {
                Ok(bytes) => Some(bytes),
                Err(error) => {
                    unread.push(format!("{path}: {error}"));
                    None
                }
            };
        }
    }
    // Announced on stderr while it waits: a Stado that cannot reach its
    // vault holds this read, and every edit naming a candidate waits with it.
    let failed = match stado_wait::output(Command::new("stado").args([
        "credentials",
        "ls",
        "--json",
    ])) {
        Ok(output) if output.status.success() => {
            if let Err(error) = keep_listing(&output.stdout) {
                eprintln!(
                    "block-internal-names: the vault listing Stado gave could not be kept at {}: {error}; \
                     a later vault outage will find no listing to judge by",
                    kept_listing().display()
                );
            }
            return Some(output.stdout);
        }
        Ok(output) => format!(
            "stado credentials ls --json exited {}: {}",
            output.status,
            String::from_utf8_lossy(&output.stderr).trim()
        ),
        Err(error) => format!("stado credentials ls --json: {error}"),
    };
    let kept = kept_listing();
    let read =
        std::fs::read(&kept).and_then(|bytes| Ok((bytes, std::fs::metadata(&kept)?.modified()?)));
    match read {
        Ok((bytes, modified)) => {
            let age = match std::time::SystemTime::now().duration_since(modified) {
                Ok(age) => format!("written {}s ago", age.as_secs()),
                Err(error) => format!("written {}s in the future", error.duration().as_secs()),
            };
            eprintln!(
                "block-internal-names: Stado's vault did not answer ({failed}); the names are the last \
                 listing it gave, kept at {} ({age})",
                kept.display()
            );
            Some(bytes)
        }
        Err(error) => {
            unread.push(format!(
                "{failed}; and no earlier listing is kept at {}: {error}",
                kept.display()
            ));
            None
        }
    }
}

/// Whether a vault item id names something internal: an id shaped like an
/// environment variable names a setting, a one-word id is a product or a
/// word, an id equal to a product's name is that product's own name, and an id
/// equal to a role some item plays is the role, which is how a secret is
/// asked for in the open (`role#field`).
fn internal_item(id: &str, public: &BTreeSet<String>) -> bool {
    let setting = id
        .chars()
        .all(|c| c.is_ascii_uppercase() || c.is_ascii_digit() || c == '_');
    let joined = id.contains(['-', '_', ':', '.', '/']);
    joined && !setting && !public.contains(&id.to_lowercase())
}

fn vault_items(unread: &mut Vec<String>) -> BTreeSet<String> {
    let mut found = BTreeSet::new();
    let Some(bytes) = vault_listing(unread) else {
        return found;
    };
    let listing: Value = match serde_json::from_slice(&bytes) {
        Ok(listing) => listing,
        Err(error) => {
            unread.push(format!("vault listing is not JSON: {error}"));
            return found;
        }
    };
    let Some(items) = listing.as_array() else {
        unread.push("vault listing must be an array of item records".to_string());
        return found;
    };
    let mut public = super::products::product_names(unread);
    for item in items {
        for tag in strings(item.get("tags")) {
            if let Some(role) = tag.strip_prefix(ROLE_TAG) {
                public.insert(role.to_lowercase());
            }
        }
    }
    for (index, item) in items.iter().enumerate() {
        let Some(id) = item.get("id").and_then(Value::as_str) else {
            unread.push(format!(
                "vault listing item at index {index} has no string id"
            ));
            continue;
        };
        if internal_item(id, &public) {
            keep(&mut found, id);
        }
    }
    found
}

/// Every name this machine knows as internal. The fleet's host registry and
/// vault listing are Stado's: on a machine without Stado installed they do
/// not exist, the names are this account's own, and the absence is said on
/// stderr; a Stado that is installed and cannot answer stays unread.
pub fn load() -> Names {
    let mut unread = Vec::new();
    let mut everywhere = BTreeSet::new();
    let stado_installed = crate::assignment::rules::program_installed("stado");
    if stado_installed {
        registry_names(&mut everywhere, &mut unread);
    } else {
        eprintln!(
            "block-internal-names: Stado is not installed on this machine, so no fleet registry \
             and no vault listing name hosts or items here; this account's own names are judged"
        );
    }
    let home = crate::util::home_dir().to_string_lossy().into_owned();
    if let Some(account) = account_of(&home) {
        keep(&mut everywhere, account);
    }
    if let Ok(user) = std::env::var("USER") {
        keep(&mut everywhere, &user);
    }
    let vault_items = if stado_installed {
        vault_items(&mut unread)
    } else {
        BTreeSet::new()
    };
    Names {
        everywhere,
        vault_items,
        unread,
    }
}
