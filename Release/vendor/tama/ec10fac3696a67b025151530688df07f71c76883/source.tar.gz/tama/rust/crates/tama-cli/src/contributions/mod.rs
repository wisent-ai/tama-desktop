//! `tama contributions pending|report --repository PATH --ref REF [--since REV]
//! [--ledger URL] [--json]`: the commits that reached a repository's remote
//! with a standing attestation, reported to Wisent's contribution ledger.
//!
//! A commit is accepted code when it is reachable from `--ref` — the remote's
//! branch as this checkout last fetched it — and its message or attestation
//! note carries every claim of the commit standard and a harsh review with no
//! finding, exactly as `tama attestation check` reads it. Each is one
//! `code.accepted` contribution of its git author, whose email is the
//! identity the ledger credits: the author links it to their Wisent account
//! by its verified address on the Rewards page, so no one can link an
//! address that is not theirs. The commit id is the event id,
//! so reporting a range again records nothing twice. `--since` leaves out
//! what that revision already holds.
//!
//! Both verbs ask the ledger once which events it already holds: `pending`
//! lists the events, marking each held or not when a ledger is named, and
//! `report` sends only the unheld ones and answers per commit what the
//! ledger recorded or refused, or that it never answered, and which ids it
//! already held ([`report`]).

mod git;
mod report;
pub(crate) mod requests;

use std::sync::LazyLock;

use serde::Deserialize;
use serde_json::{json, Value};
use tama_core::exit::{FAILURE, SUCCESS, USAGE};

#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
struct Declared {
    usage: String,
    product: String,
    role: String,
    bearer_field: String,
    ledger_env: String,
    kind: String,
    unit: String,
    client: String,
}

static DECLARED: LazyLock<Declared> = LazyLock::new(|| {
    serde_json::from_str(include_str!("contributions.json"))
        .expect("contributions.json is the declared contribution reporter")
});

/// What the command was asked to do.
enum Verb {
    Pending,
    Report,
}

struct Arguments<'a> {
    verb: Verb,
    repository: &'a str,
    reference: &'a str,
    since: Option<&'a str>,
    ledger: Option<&'a str>,
    json: bool,
}

/// The flag `name`'s value, or why it is missing.
fn flag<'a>(value: Option<&'a str>, name: &str, names: &str) -> Result<&'a str, String> {
    match value {
        Some(value) => Ok(value),
        None => Err(format!("{name} names {names}: {}", DECLARED.usage)),
    }
}

fn parse(argv: &[String]) -> Result<Arguments<'_>, String> {
    let usage = &DECLARED.usage;
    let Some((verb, rest)) = argv.split_first() else {
        return Err(format!("name a verb: {usage}"));
    };
    let verb = match verb.as_str() {
        "pending" => Verb::Pending,
        "report" => Verb::Report,
        other => return Err(format!("{other} is not a verb of {usage}")),
    };
    let (mut repository, mut reference, mut since, mut ledger) = (None, None, None, None);
    let mut json = false;
    let mut words = rest.iter();
    while let Some(word) = words.next() {
        let named = word.as_str();
        let mut value = || match words.next() {
            Some(value) => Ok(Some(value.as_str())),
            None => Err(format!("{named} names no value")),
        };
        match named {
            "--repository" => repository = value()?,
            "--ref" => reference = value()?,
            "--since" => since = value()?,
            "--ledger" => ledger = value()?,
            "--json" => json = true,
            other => return Err(format!("{other} is not an argument of {usage}")),
        }
    }
    Ok(Arguments {
        verb,
        repository: flag(repository, "--repository", "the checkout")?,
        reference: flag(reference, "--ref", "the remote branch the commits reached")?,
        since,
        ledger,
        json,
    })
}

/// Every commit of the range whose attestation stands, as the event the
/// ledger records.
fn accepted_code(arguments: &Arguments<'_>) -> Result<Vec<Value>, String> {
    let repository = std::path::Path::new(arguments.repository);
    let mut events = Vec::new();
    for commit in git::reached(repository, arguments.reference, arguments.since)? {
        let checked = git::attestation(repository, &commit)?;
        if checked["stands"].as_bool() != Some(true) {
            continue;
        }
        let (author, committed) = git::author(repository, &commit)?;
        // An event names the commits it reports, and its quantity is how
        // many it names.
        let commits = vec![Value::from(commit.as_str())];
        let evidence = json!({
            "commits": commits,
            "ref": arguments.reference,
            "carried_in": checked["carriedIn"],
        });
        events.push(json!({
            "source_event_id": commit,
            "kind": DECLARED.kind,
            "contributor_id": author,
            "quantity": commits.len(),
            "unit": DECLARED.unit,
            "evidence": evidence,
            "occurred_at": committed,
        }));
    }
    Ok(events)
}

/// The ledger `--ledger` names, else the declared environment variable;
/// `None` when neither names one.
fn named_ledger(flag: Option<&str>) -> Result<Option<String>, String> {
    let named = match flag {
        Some(url) => url.to_string(),
        None => match std::env::var(&DECLARED.ledger_env) {
            Ok(url) => url,
            Err(std::env::VarError::NotPresent) => return Ok(None),
            Err(std::env::VarError::NotUnicode(_)) => {
                return Err(format!("{} is not valid Unicode", DECLARED.ledger_env))
            }
        },
    };
    let url = named.trim().trim_end_matches('/');
    if url.is_empty() {
        return Ok(None);
    }
    Ok(Some(url.to_string()))
}

/// The ledger's `route` at `url`, asked as Tama with `bearer`.
fn request<'a>(url: &'a str, route: &'a str, bearer: &'a str) -> git::Request<'a> {
    git::Request {
        client: &DECLARED.client,
        ledger: url,
        route,
        bearer,
        product: &DECLARED.product,
    }
}

/// Which of `events` the ledger at `url` already holds from Tama, asked in
/// one request.
fn held(url: &str, bearer: &str, events: &[Value]) -> Result<Vec<Value>, String> {
    let ids: Vec<&Value> = events
        .iter()
        .map(|event| &event["source_event_id"])
        .collect();
    let asked = request(url, "/api/v1/contributions/events/held", bearer);
    let answer = git::post(&asked, &json!({"source_event_ids": ids}))
        .map_err(|cause| format!("asking the ledger what it holds failed: {cause}"))?;
    match answer.get("held").and_then(Value::as_array) {
        Some(held) => Ok(held.clone()),
        None => Err(format!("the ledger's answer names no held list: {answer}")),
    }
}

/// The events, each marked held or not when a ledger is named.
fn pending_document(arguments: &Arguments<'_>) -> Result<Value, String> {
    let mut events = accepted_code(arguments)?;
    if let Some(url) = named_ledger(arguments.ledger)? {
        let bearer = git::bearer(&DECLARED.role, &DECLARED.bearer_field)?;
        let held = held(&url, &bearer, &events)?;
        for event in &mut events {
            event["held"] = Value::from(held.contains(&event["source_event_id"]));
        }
    }
    Ok(Value::from(events))
}

fn pending(arguments: &Arguments<'_>) -> Result<Option<String>, String> {
    let events = pending_document(arguments)?;
    if arguments.json {
        return print(&events).map(|()| None);
    }
    for event in events.as_array().into_iter().flatten() {
        let state = match event.get("held").and_then(Value::as_bool) {
            Some(true) => " (held)",
            Some(false) => " (not held)",
            None => "",
        };
        let (commit, author) = (&event["source_event_id"], &event["contributor_id"]);
        println!("{commit} {author} {}{state}", event["occurred_at"]);
    }
    Ok(None)
}

fn print(value: &Value) -> Result<(), String> {
    let text = serde_json::to_string_pretty(value)
        .map_err(|error| format!("the answer cannot be encoded: {error}"))?;
    println!("{text}");
    Ok(())
}

pub(crate) fn main(argv: &[String]) -> i32 {
    let arguments = match parse(argv) {
        Ok(arguments) => arguments,
        Err(error) => {
            eprintln!("contributions: {error}");
            return USAGE;
        }
    };
    let outcome = match arguments.verb {
        Verb::Pending => pending(&arguments),
        Verb::Report => report::report(&arguments),
    };
    match outcome {
        Ok(None) => SUCCESS,
        Ok(Some(failure)) => {
            eprintln!("contributions: {failure}");
            FAILURE
        }
        Err(error) => {
            eprintln!("contributions: {error}");
            FAILURE
        }
    }
}
