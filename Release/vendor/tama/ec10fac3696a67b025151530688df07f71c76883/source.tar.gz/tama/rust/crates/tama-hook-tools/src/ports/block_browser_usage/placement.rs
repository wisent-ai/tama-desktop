//! Whether this host is allowed to run a Weles browser runtime.
//!
//! Weles may drive its patched browser, but only on a host the canonical Stado
//! registry selects for it. An API client on another machine is still allowed:
//! it launches no local browser. So the question is exactly "does a target in
//! the registry carry a Weles placement policy and name this host".

use serde_json::Value;

use crate::ports::python_stdlib::expanduser;

const REGISTRY_ENV: &str = "STADO_BROWSER_POLICY_REGISTRY";
const REGISTRY_DEFAULT: &str = "~/.stado/local-storage/registry.json";
const TARGETS_KEY: &str = "targets";
const WELES_KEY: &str = "weles";
const ENABLED_KEY: &str = "enabled";
const ACTIONS_KEY: &str = "actions";
const NAME_KEY: &str = "name";
const HOSTNAMES_KEY: &str = "hostnames";
const LOCAL_SUFFIX: &str = ".local";

pub(crate) fn registry_path() -> String {
    match std::env::var(REGISTRY_ENV) {
        Ok(value) if !value.is_empty() => value,
        _ => expanduser(REGISTRY_DEFAULT),
    }
}

fn short(host: &str) -> &str {
    match host.strip_suffix(LOCAL_SUFFIX) {
        Some(short) => short,
        None => host,
    }
}

fn carries_a_weles_policy(target: &Value) -> bool {
    let Some(weles) = target.get(WELES_KEY) else {
        return false;
    };
    if weles.get(ENABLED_KEY) == Some(&Value::Bool(true)) {
        return true;
    }
    match weles.get(ACTIONS_KEY) {
        Some(Value::Array(actions)) => !actions.is_empty(),
        _ => false,
    }
}

fn names_this_host(target: &Value, host: &str) -> bool {
    let mut names: Vec<String> = Vec::new();
    if let Some(Value::String(name)) = target.get(NAME_KEY) {
        names.push(name.clone());
    }
    if let Some(Value::Array(hostnames)) = target.get(HOSTNAMES_KEY) {
        for entry in hostnames {
            if let Value::String(name) = entry {
                names.push(name.clone());
            }
        }
    }
    names
        .iter()
        .map(|name| name.to_lowercase())
        .any(|name| name == host || short(&name) == short(host))
}

/// Whether the registry at `path` places a Weles browser runtime on `host`.
/// No registry places nothing; one that cannot be read or does not parse is
/// refused naming the file: read as "no placement", a typo in it refused
/// every placed Weles run with a sentence that never named the file.
pub(crate) fn allows_weles_runtime(path: &str, host: &str) -> Result<bool, String> {
    let text = match std::fs::read_to_string(path) {
        Ok(text) => text,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(false),
        Err(error) => return Err(format!("the Stado registry {path} cannot be read: {error}")),
    };
    let doc = serde_json::from_str::<Value>(&text)
        .map_err(|error| format!("the Stado registry {path} is not valid JSON: {error}"))?;
    let Some(Value::Array(targets)) = doc.get(TARGETS_KEY) else {
        return Ok(false);
    };
    Ok(targets
        .iter()
        .any(|target| carries_a_weles_policy(target) && names_this_host(target, host)))
}
