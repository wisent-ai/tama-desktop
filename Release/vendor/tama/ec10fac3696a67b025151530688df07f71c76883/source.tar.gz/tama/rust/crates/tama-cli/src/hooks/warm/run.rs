//! Reading the registry for the hooks the one `tama` program runs, and
//! running one of them once.
//!
//! Split from `warm.rs` because a source file here stays at three hundred
//! lines or fewer: the command surface is one half, what it measures is this
//! one.

use std::io::Write;
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::time::Instant;

use serde_json::Value;

/// A hook that cannot see its input must not act, so an empty object
/// exercises process start-up and nothing else.
const WARM_PAYLOAD: &str = "{}";
/// Scratch `HOME` for warm runs, under the checkout's ignored build tree, so
/// a hook that does write state writes it there and never into the
/// operator's.
const WARM_HOME: &str = "rust/target/hook-warm-home";
/// What a registry command held when each hook was a program of its own,
/// `…/bin/tama-<name>`. A release refuses a registry that still says so.
pub const SEPARATE_PROGRAM_MARKER: &str = "bin/tama-";
/// Where a machine keeps the release its engine actually executes.
const RELEASE_BIN_DIR: &str = "Library/Application Support/Tama/hooks-runtime/current/bin";

/// One hook the registry names: the `tama` program and the arguments that
/// select the hook.
#[derive(Clone)]
pub struct HookBinary {
    pub id: String,
    pub command: String,
    pub path: PathBuf,
    pub args: Vec<String>,
}

/// What one warm run observed.
pub struct Warmed {
    pub hook: HookBinary,
    pub elapsed_ms: u128,
    pub code: Option<i32>,
    pub state: State,
    /// Why an unrunnable hook could not run, as the operating system said.
    pub cause: Option<String>,
}

#[derive(PartialEq, Eq, Clone, Copy)]
pub enum State {
    /// It ran and exited; `elapsed_ms` says what that cost.
    Warm,
    /// The registry names it and the install directory does not hold it.
    Missing,
    /// The file is there and could not be started or waited for; reported
    /// as missing, a permission or format failure sent the reader to look
    /// for a file that was present.
    Unrunnable,
}

impl State {
    pub fn text(self) -> &'static str {
        match self {
            State::Warm => "warm",
            State::Missing => "missing",
            State::Unrunnable => "unrunnable",
        }
    }
}

/// `$HOME/.local/bin/tama`, `${HOME}/…`, `~/…` and an absolute path all name
/// the same file; the registry carries every spelling.
fn expand_home(command: &str) -> PathBuf {
    let home = tama_core::home_dir();
    for prefix in ["$HOME/", "${HOME}/", "~/"] {
        if let Some(rest) = command.strip_prefix(prefix) {
            return Path::new(&home).join(rest);
        }
    }
    PathBuf::from(command)
}

/// Every `(id, command)` in the registry, depth first, in document order.
fn commands(value: &Value, found: &mut Vec<(String, String)>) {
    match value {
        Value::Array(items) => items.iter().for_each(|item| commands(item, found)),
        Value::Object(map) => {
            if let Some(command) = map.get("command").and_then(Value::as_str) {
                // An entry that states no id is named by the command it runs.
                let id = match map.get("id").and_then(Value::as_str) {
                    Some(id) => id,
                    None => command,
                };
                found.push((id.to_string(), command.to_string()));
            }
            map.values().for_each(|nested| commands(nested, found));
        }
        _ => {}
    }
}

/// The registry document, or a refusal naming its path and the read or parse
/// cause.
pub fn read_registry(registry: &Path) -> Result<Value, String> {
    let text = std::fs::read_to_string(registry)
        .map_err(|error| format!("{} cannot be read: {error}", registry.display()))?;
    serde_json::from_str::<Value>(&text)
        .map_err(|error| format!("{} is not JSON: {error}", registry.display()))
}

/// Every `(id, command)` the registry names, or the refusal naming its path
/// and the read or parse cause. Printed and answered as "no hooks", a broken
/// registry let a release ship with nothing warmed and nothing listed.
fn registry_commands(registry: &Path) -> Result<Vec<(String, String)>, String> {
    let value = read_registry(registry)?;
    let mut found = Vec::new();
    commands(&value, &mut found);
    Ok(found)
}

/// Every hook the registry runs through the `tama` program, in registry
/// order, each command once; a registry that cannot be read is refused.
pub fn registry_hooks(registry: &Path) -> Result<Vec<HookBinary>, String> {
    let mut found: Vec<HookBinary> = Vec::new();
    for (id, command) in registry_commands(registry)? {
        let Some(hook) = tama_hooks::hook_exec::tama_hook(&command) else {
            continue;
        };
        if found.iter().any(|known| known.command == command) {
            continue;
        }
        found.push(HookBinary {
            id,
            path: expand_home(&hook.program),
            args: vec![
                tama_hooks::hook_exec::HOOK_SUBCOMMAND.to_string(),
                hook.name,
            ],
            command,
        });
    }
    Ok(found)
}

/// Every registry entry whose command still runs a separate `tama-<name>`
/// program, as `(id, command)`, each command once; a registry that cannot be
/// read is refused.
pub fn separate_programs(registry: &Path) -> Result<Vec<(String, String)>, String> {
    let mut found: Vec<(String, String)> = Vec::new();
    for (id, command) in registry_commands(registry)? {
        if command.contains(SEPARATE_PROGRAM_MARKER)
            && !found.iter().any(|(_, known)| *known == command)
        {
            found.push((id, command));
        }
    }
    Ok(found)
}

/// The `tama` program itself, which runs on the same path as every hook and
/// pays the same first-run cost.
pub fn runtime_binary(name: &str, path: PathBuf) -> HookBinary {
    HookBinary {
        id: name.to_string(),
        command: path.display().to_string(),
        path,
        args: Vec::new(),
    }
}

/// The same hooks, run by the `tama` in the sealed release under
/// `~/Library/Application Support/Tama/hooks-runtime/current/bin`.
///
/// That is the copy the engine executes. It is a separate file from the one
/// in `~/.local/bin` the registry names, so it owes the operating system its
/// own first assessment, which a warm registry copy does not pay for it.
/// Refused, naming the path, when the release holds no `tama`: live events
/// would run a release nothing warmed, and a warm that left it out without a
/// word reported success over it.
pub fn release_hooks(home: &Path, hooks: &[HookBinary]) -> Result<Vec<HookBinary>, String> {
    let sealed = home
        .join(RELEASE_BIN_DIR)
        .join(tama_hooks::hook_exec::PROGRAM);
    let metadata = std::fs::metadata(&sealed).map_err(|error| {
        format!(
            "the sealed hook release holds no {} the live events run ({error}); \
             `tama hooks release` activates the release Stado installed",
            sealed.display()
        )
    })?;
    if !metadata.is_file() {
        return Err(format!(
            "the sealed hook release's {} is not a file; `tama hooks release` activates \
             the release Stado installed",
            sealed.display()
        ));
    }
    Ok(hooks
        .iter()
        .map(|hook| HookBinary {
            path: sealed.clone(),
            ..hook.clone()
        })
        .collect())
}

fn observed(hook: &HookBinary, started: Instant, code: Option<i32>, state: State) -> Warmed {
    Warmed {
        hook: hook.clone(),
        elapsed_ms: started.elapsed().as_millis(),
        code,
        state,
        cause: None,
    }
}

fn unrunnable(hook: &HookBinary, started: Instant, cause: String) -> Warmed {
    Warmed {
        cause: Some(cause),
        ..observed(hook, started, None, State::Unrunnable)
    }
}

fn warm_one(hook: &HookBinary, home: &Path) -> Warmed {
    let started = Instant::now();
    if !hook.path.is_file() {
        return observed(hook, started, None, State::Missing);
    }
    let mut command = Command::new(&hook.path);
    command
        .args(&hook.args)
        .env_clear()
        .env("HOME", home)
        .stdin(Stdio::piped())
        .stdout(Stdio::null())
        .stderr(Stdio::null());
    // PATH as the operating system holds it: read as a string, a PATH that
    // is not UTF-8 was handed to the hook as an empty one.
    if let Some(path) = std::env::var_os("PATH") {
        command.env("PATH", path);
    }
    let mut child = match command.spawn() {
        Ok(child) => child,
        Err(error) => return unrunnable(hook, started, format!("cannot start: {error}")),
    };
    // A hook that stops reading before the payload ends has run, which is all
    // warming needs; any other failure to hand it the payload is said, since
    // the run then measured a hook that never saw an event.
    if let Some(mut stdin) = child.stdin.take() {
        if let Err(error) = stdin.write_all(WARM_PAYLOAD.as_bytes()) {
            if error.kind() != std::io::ErrorKind::BrokenPipe {
                eprintln!(
                    "tama hooks warm: {}: the warm payload was not delivered: {error}",
                    hook.path.display()
                );
            }
        }
    }
    // Nothing here ends a slow run: paying the operating system's
    // first-execution assessment is the whole point of this command, and what
    // it costs is the measurement, not a failure.
    // Its output goes nowhere, so collecting it collects nothing.
    match stado_wait::child_output(child, format!("warming {}", hook.path.display())) {
        Ok(output) => observed(hook, started, output.status.code(), State::Warm),
        Err(error) => unrunnable(hook, started, format!("cannot be waited for: {error}")),
    }
}

/// Warm every hook given, in order, and report what each run observed.
pub fn warm_hooks(root: &Path, hooks: &[HookBinary]) -> Vec<Warmed> {
    let home = root.join(WARM_HOME);
    // Hooks run with stderr discarded, so a home that is missing is said
    // here: every warm run would otherwise fail for a reason nobody sees.
    if let Err(error) = std::fs::create_dir_all(&home) {
        eprintln!(
            "tama: cannot create the warm home {}: {error}",
            home.display()
        );
    }
    let warmed = hooks.iter().map(|hook| warm_one(hook, &home)).collect();
    match std::fs::remove_dir_all(&home) {
        Err(error) if error.kind() != std::io::ErrorKind::NotFound => {
            eprintln!(
                "tama: the warm home {} is left behind: {error}",
                home.display()
            );
        }
        _ => {}
    }
    warmed
}
