//! Which session a transcript is, where it is kept, and when it began: what
//! the receipts are read from and what the replay and the handover register
//! read about the session.

use std::collections::BTreeSet;
use std::fs::File;
use std::io::{BufRead, BufReader};
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};

use serde_json::Value;

/// The transcript of `session`, which every receipt of it is read from;
/// refused when it has none ([`written`]).
pub(in super::super) fn transcript(session: &str) -> Result<PathBuf, String> {
    written(session)?.ok_or_else(|| format!("no recorded transcript for session {session}"))
}

/// The transcript `session` writes: the one its recorded agent process
/// holds open for writing now, or, when no running process of it holds one,
/// the newest of its transcripts (`moved::newest`); none when it has none.
/// OMP moves a session to a new transcript, named after a new id and naming
/// the one it moved from as `parentSession`, with every earlier record
/// copied in, while its process keeps the first id; the moved transcript is
/// then the only one that holds the session's edits since, during the
/// process's life and after it. A transcript another process writes is that
/// process's and is never read for this one while it runs. Several
/// transcripts held by the session's processes refuse, naming them.
pub(in super::super) fn written(session: &str) -> Result<Option<PathBuf>, String> {
    use crate::ports::owner_consent::{exists, recorded_holders};
    let mut held = BTreeSet::new();
    for (pid, (_, recorded)) in recorded_holders()? {
        if recorded == session && exists(pid)? {
            held.extend(written_by(pid)?);
        }
    }
    let mut found = held.iter();
    match (found.next(), found.next()) {
        (Some(only), None) => Ok(Some(only.clone())),
        (None, _) => super::moved::newest(session),
        (Some(_), Some(_)) => {
            let named: Vec<String> = held.iter().map(|path| path.display().to_string()).collect();
            Err(format!(
                "the running processes of session {session} write several transcripts ({}), so \
                 which one holds its edits cannot be told",
                named.join(", ")
            ))
        }
    }
}

/// Where `lsof` is installed: run by its path, so the caller's `PATH` does
/// not choose the program that says which file a process writes.
#[cfg(target_os = "macos")]
const LSOF: &str = "/usr/sbin/lsof";
#[cfg(not(target_os = "macos"))]
const LSOF: &str = "/usr/bin/lsof";

/// The session transcripts process `pid` holds open for writing, as `lsof`
/// lists its open files: a file under a harness's live root, ending in
/// `.jsonl`, opened for writing or for reading and writing. A process that
/// no longer runs holds none; an `lsof` that cannot run, or that fails
/// saying why, refuses with its words.
fn written_by(pid: u32) -> Result<Vec<PathBuf>, String> {
    let mut lsof = Command::new(LSOF);
    lsof.args(["-n", "-P", "-a", "-p"])
        .arg(pid.to_string())
        .arg("-Fan");
    let shown = format!("{lsof:?}");
    let child = lsof
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .map_err(|cause| format!("cannot run {shown}: {cause}"))?;
    let output = stado_wait::child_output(child, shown.clone())
        .map_err(|cause| format!("{shown}: {cause}"))?;
    let said = String::from_utf8_lossy(&output.stderr);
    if !output.status.success() && !said.trim().is_empty() {
        return Err(format!(
            "{shown} ended with {}: {}",
            output.status,
            said.trim()
        ));
    }
    let roots = tama_hooks::session_record::live_roots();
    let listed = String::from_utf8_lossy(&output.stdout);
    let mut writing = false;
    let mut written = Vec::new();
    for line in listed.lines() {
        if let Some(access) = line.strip_prefix('a') {
            writing = access.chars().any(|mode| "wu".contains(mode));
        } else if let Some(name) = line.strip_prefix('n') {
            let path = Path::new(name);
            let transcript = path
                .extension()
                .is_some_and(|extension| extension == "jsonl");
            if writing && transcript && roots.iter().any(|root| path.starts_with(root)) {
                written.push(path.to_path_buf());
            }
        } else if line.starts_with('f') {
            writing = false;
        }
    }
    Ok(written)
}

/// Each record of `transcript`, in order, until `found` answers one.
fn first<T>(transcript: &Path, found: impl Fn(&Value) -> Option<T>) -> Result<Option<T>, String> {
    let file = File::open(transcript)
        .map_err(|cause| format!("cannot open {}: {cause}", transcript.display()))?;
    for line in BufReader::new(file).lines() {
        let line =
            line.map_err(|cause| format!("cannot read {}: {cause}", transcript.display()))?;
        let record: Value = serde_json::from_str(&line).map_err(|cause| {
            format!(
                "{} holds a line that is not JSON: {cause}",
                transcript.display()
            )
        })?;
        if let Some(answer) = found(&record) {
            return Ok(Some(answer));
        }
    }
    Ok(None)
}

/// When the session `transcript` records began: the `timestamp` of its
/// first record that carries one (OMP's `session` header, the first turn of
/// other harnesses). A header that names a `parentSession` heads a moved
/// transcript, written when the session moved, and the copied history after
/// it begins when the session did, so its own time is passed over. A commit
/// the session made is younger than that, so history before it holds none
/// of the session's states. `None` when no record carries a timestamp: the
/// whole history is then searched.
pub(in super::super) fn session_started(transcript: &Path) -> Result<Option<String>, String> {
    first(transcript, |record| {
        if record.get("parentSession").is_some() {
            return None;
        }
        record
            .get("timestamp")
            .and_then(Value::as_str)
            .map(str::to_owned)
    })
}

/// The session `transcript` records: the `id` of its `type: session`
/// record, the identity the receipts are checked against. A transcript
/// with no such record names no session and is refused.
pub(in super::super) fn session_of(transcript: &Path) -> Result<String, String> {
    let identity = first(transcript, |record| {
        match record.get("type").and_then(Value::as_str) {
            Some("session") => record.get("id").and_then(Value::as_str).map(str::to_owned),
            _ => None,
        }
    })?;
    identity.ok_or_else(|| {
        format!(
            "transcript {} contains no session identity",
            transcript.display()
        )
    })
}

/// The id the session `transcript` records is kept under by its process:
/// a transcript OMP moved the session to names the first id as its
/// `providerPromptCacheKey`, which the session's process and its records
/// (its staged co-authors among them) still carry; any other transcript's
/// own `id`.
pub(in super::super) fn kept_session_of(transcript: &Path) -> Result<String, String> {
    let identity = first(transcript, |record| {
        if record.get("type").and_then(Value::as_str) != Some("session") {
            return None;
        }
        match (
            record.get("providerPromptCacheKey").and_then(Value::as_str),
            record.get("id").and_then(Value::as_str),
        ) {
            (Some(kept), _) => Some(kept.to_owned()),
            (None, Some(id)) => Some(id.to_owned()),
            (None, None) => None,
        }
    })?;
    identity.ok_or_else(|| {
        format!(
            "transcript {} contains no session identity",
            transcript.display()
        )
    })
}
