//! Decision half of `tama hook block-calls-before-answer` (hook id
//! `block-calls-before-answer`): what the operator's newest message asks of
//! the session comes before any other tool call.
//!
//! The operator's rules: a question, a plan or a correction is answered
//! first, directly and briefly, in words, before any tool call; once he says
//! "nie koduj" or bans tool calls, nothing more is edited, built or run until
//! he lifts it; and a problem he reports is a defect, recorded through Oko
//! and repaired, not something the session carries on past with its own
//! plan. Agents instead sent him another grant request, ran another build,
//! denied what he reported, or went on with their plan.
//!
//! Nothing here classifies his words. What his newest message is comes from
//! Oko's reading of it in the session's current open-work snapshot
//! (`newestMessage.kind`, the reading `block-text-outside-tool-calls`
//! already lets an answer in words through on):
//!
//! - `question`: every call is refused until an assistant message carrying
//!   words stands after his message in the session's transcript;
//! - `order` (forbids or restricts something for this turn): every call is
//!   refused until his next message, which Oko reads again; the turn's
//!   answer is words, which the text gate lets through;
//! - `defect` (he reports that something delivered is broken or wrong):
//!   every call but Oko's own is refused until a successful call after his
//!   message has run `oko defects` on one defect (`record` a new one, or
//!   `show`, `assign`, `reopen` the one it already is); a listing alone is
//!   not that.
//!
//! A snapshot that is missing, not current, or unreadable, another reading,
//! and a transcript that cannot be read pass: the gate decides only on a
//! reading it holds, and fails open on its own failure. The operator can let
//! one exact shell command through with his own recorded words (`tama
//! justify record --kind before-answer`). Nothing here starts a process,
//! takes a lock or asks a model: two small files are read.

use serde_json::Value;
use tama_hooks::session_record::Turn;

use crate::assignment::rules;
use crate::ports::command_path;
use crate::ports::operator_grant::{self, Request};
use crate::ports::tool_vocabulary::Call;
use crate::ports::transport_common as common;

pub const HOOK_ID: &str = "block-calls-before-answer";
pub const GRANT_KIND: &str = "before-answer";
/// Oko's program, whose own commands a reported defect leaves running.
const OKO: &str = "oko";
/// The words after `oko` that read or change the defect register.
const DEFECTS: &str = "defects";
/// The one `oko defects` verb that names no defect of its own.
const LISTING: &str = "list";

/// The refusal when the operator's newest message holds the session to
/// something it has not done yet, `None` when the call passes.
pub fn evaluate(payload: &Value) -> Option<String> {
    let session = common::session_id_of(payload);
    if session.is_empty() {
        return None;
    }
    let kind = rules::newest_kind(&session).ok().flatten()?;
    let call = Call::of(payload);
    let command = call.is_shell().then(|| call.command()).flatten();
    let turn = Turn::for_payload(payload)?;
    let said = turn
        .operator_messages()
        .last()
        .and_then(|message| message.lines().next())
        .unwrap_or_default()
        .trim();
    let what = match kind.as_str() {
        rules::QUESTION if !turn.answered_since_operator() => format!(
            "the operator asked you something and has no answer yet: \"{said}\". Answer him \
             first, directly and briefly, in words — no tool call, no code change, no other work \
             before the answer. Once you have answered, the work goes on."
        ),
        rules::ORDER => format!(
            "the operator's newest message stops the work for this turn: \"{said}\". No tool \
             runs, nothing is edited, built or changed, until he writes again; answer him in \
             words."
        ),
        rules::DEFECT if !runs_oko(payload) && !defect_taken(&turn) => format!(
            "the operator reported a problem: \"{said}\". It is a defect, taken before your own \
             plan: check it, record it (`oko defects record --product <product> --title ...`) or \
             take the one it already is (`oko defects show <id>`), then repair it."
        ),
        _ => return None,
    };
    let request = Request {
        gate: HOOK_ID,
        command,
        paths: &[],
    };
    if command.is_some() && operator_grant::granted(payload, &request) {
        return None;
    }
    Some(format!(
        "BLOCKED: {what} {}",
        operator_grant::how_to_grant(GRANT_KIND, HOOK_ID)
    ))
}

/// Whether the call runs Oko, which reads and records the defect.
fn runs_oko(payload: &Value) -> bool {
    command_path::reaches(payload, &[OKO.to_string()]).unwrap_or(false)
}

/// Whether a successful call after the operator's newest message ran
/// `oko defects` on one defect: any verb but the listing.
fn defect_taken(turn: &Turn) -> bool {
    let Some(&asked) = turn.operator_positions().last() else {
        return false;
    };
    let successful = turn.successful_call_ids();
    turn.tool_calls().iter().any(|(position, call)| {
        *position > asked
            && successful.contains(&call.id)
            && call
                .arguments
                .get("command")
                .and_then(Value::as_str)
                .is_some_and(names_one_defect)
    })
}

/// Whether `command` runs `oko defects <verb>` with a verb other than the
/// listing, read word by word as the shell splits it.
fn names_one_defect(command: &str) -> bool {
    let words: Vec<&str> = command.split_whitespace().collect();
    words.windows(3).any(|run| {
        run[0].rsplit('/').next() == Some(OKO)
            && run[1] == DEFECTS
            && !run[2].starts_with('-')
            && run[2] != LISTING
    })
}
