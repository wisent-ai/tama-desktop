//! Who holds the uncommitted edits of each file in a shared checkout.
//!
//! Work in a shared checkout belongs to no session alone: any session edits
//! and commits any file, whoever edited it before and whether that session
//! still runs, so one that stalls holds nothing back. The lease names one
//! session per file, its holder: the first session to edit the file while it
//! held no uncommitted change. Edits other sessions make of a held file are
//! admitted and are not named on the lease, and nothing here sees a change
//! made by a shell command or by a process no recorded session runs.
//! `pre-write-edit` records each edit here with the snapshot of the call
//! making it. Another session's lease or edits never refuse an edit. Every
//! read the record needs refuses the edit when it fails, with that read's
//! cause in the refusal, since an edit whose record cannot be kept cannot be
//! read back by the commit review: placing the file in its checkout, its
//! state and `HEAD`'s blob, the register, both sessions' transcripts, the
//! running sessions and the snapshot store are such reads (examples, not a
//! closed list). Besides a failed read, an edit is refused when its call
//! already has a snapshot holding other input, since replacing it would
//! change the evidence the commit review reads; and so is an edit whose
//! relative path comes with no working directory. When
//! the lease ends, and why a file that already differs from `HEAD` takes none, is
//! in [`lease`].
//!
//! `tama session handover --path P --from A --to B` passes A's lease on P to
//! B and records the bytes P held then, whoever wrote them: when the commit
//! review names the session that makes a commit, B's change of P built on
//! those bytes counts as B's work. The record names A, B and the session that
//! ran it, not who wrote the bytes, and no co-author or commit trailer is
//! made from it. Any session runs it, whether A still runs or has ended.
//!
//! The register is one JSON document in the repository's common Git
//! directory (`tama-edit-leases.json`), shared by every index and worktree,
//! changed under an exclusive lock on its sibling lock file and replaced
//! whole through a renamed file.

pub mod cli;
mod lease;
pub(crate) mod snapshot;
mod transcript;

pub use lease::record;

use std::collections::BTreeMap;
use std::fs::OpenOptions;
use std::os::fd::AsRawFd;
use std::path::{Path, PathBuf};

use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

use tama_core::git::Git;

const REGISTER: &str = "tama-edit-leases.json";
const LOCK: &str = "tama-edit-leases.lock";

/// A file's lease: its holder (the first session to edit the file while it
/// held no uncommitted change), since when; the blob `HEAD` held at the path
/// when the lease was taken, whether the holder's edit was seen in the file
/// since, and the holder's call that is writing it when its transcript names
/// one. Other sessions' edits of the file are not recorded here.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Lease {
    pub session: String,
    pub since: String,
    pub head_blob: Option<String>,
    pub written: bool,
    pub call: Option<String>,
}

/// One handover: `from`'s lease on `path` passed to `to`, when the file held
/// the bytes whose SHA-256 is `content_sha256`; `by` ran it.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Handover {
    pub path: String,
    pub from: String,
    pub to: String,
    pub content_sha256: String,
    pub by: String,
    pub at: String,
}

#[derive(Debug, Default, Serialize, Deserialize)]
pub struct Register {
    pub leases: BTreeMap<String, Lease>,
    pub handovers: Vec<Handover>,
}

/// What `git ARGS` prints in `directory`, trimmed, or why it could not answer.
fn git_text(directory: &Path, args: &[&str]) -> Result<String, String> {
    tama_core::git::at(directory, args).map(|text| text.trim().to_owned())
}

/// A file of a checkout: its worktree root, its common Git directory and its
/// path relative to the root, as Git spells it.
pub struct Checked {
    pub root: PathBuf,
    pub common: PathBuf,
    pub relative: String,
}

/// The checkout holding `path`, or `None` when no Git checkout does. A file
/// not written yet is located by the nearest directory that exists.
pub fn checkout_of(path: &Path) -> Result<Option<Checked>, String> {
    let mut directory = path.parent().map(Path::to_path_buf);
    while let Some(candidate) = directory.clone() {
        if candidate.is_dir() {
            break;
        }
        directory = candidate.parent().map(Path::to_path_buf);
    }
    let Some(directory) = directory else {
        return Ok(None);
    };
    let (inside, answer) =
        Git::of(Some(&directory)).answered(&["rev-parse", "--is-inside-work-tree"])?;
    if !inside || answer != "true" {
        return Ok(None);
    }
    let root = PathBuf::from(git_text(&directory, &["rev-parse", "--show-toplevel"])?);
    let common = PathBuf::from(git_text(
        &directory,
        &["rev-parse", "--path-format=absolute", "--git-common-dir"],
    )?);
    let canonical_root = root.canonicalize().map_err(|error| {
        format!(
            "cannot resolve the checkout root {}: {error}",
            root.display()
        )
    })?;
    let canonical_directory = directory
        .canonicalize()
        .map_err(|error| format!("cannot resolve {}: {error}", directory.display()))?;
    let below = canonical_directory
        .strip_prefix(&canonical_root)
        .map_err(|_| {
            format!(
                "{} is not below its checkout root {}",
                directory.display(),
                root.display()
            )
        })?;
    let rest = path
        .strip_prefix(&directory)
        .map_err(|_| format!("{} is not below {}", path.display(), directory.display()))?;
    let relative = below.join(rest).to_string_lossy().into_owned();
    Ok(Some(Checked {
        root,
        common,
        relative,
    }))
}

/// Whether the file is what `HEAD` holds: no staged or worktree change, and
/// not an untracked file.
pub fn unchanged(checked: &Checked) -> Result<bool, String> {
    let status = git_text(
        &checked.root,
        &[
            "status",
            "--porcelain",
            "--untracked-files=all",
            "--",
            &checked.relative,
        ],
    )?;
    Ok(status.is_empty())
}

/// The register at `common` read and changed under its lock: `change` sees
/// the register as it stands and answers what to tell the caller; the
/// register is written back whole when `change` answers `Ok`.
pub fn change<T>(
    common: &Path,
    change: impl FnOnce(&mut Register) -> Result<T, String>,
) -> Result<T, String> {
    let lock_path = common.join(LOCK);
    let lock = OpenOptions::new()
        .create(true)
        .append(true)
        .open(&lock_path)
        .map_err(|error| {
            format!(
                "cannot open the lease lock {}: {error}",
                lock_path.display()
            )
        })?;
    // SAFETY: an exclusive lock on a descriptor this process holds open for
    // the whole change; it is released when the file closes.
    if unsafe { libc::flock(lock.as_raw_fd(), libc::LOCK_EX) }.is_negative() {
        return Err(format!(
            "cannot lock {}: {}",
            lock_path.display(),
            std::io::Error::last_os_error()
        ));
    }
    let path = common.join(REGISTER);
    let mut register = read(&path)?;
    let answer = change(&mut register)?;
    let bytes = serde_json::to_vec_pretty(&register)
        .map_err(|error| format!("cannot encode {}: {error}", path.display()))?;
    let staged = common.join(format!("{REGISTER}.{}", std::process::id()));
    std::fs::write(&staged, bytes)
        .map_err(|error| format!("cannot write {}: {error}", staged.display()))?;
    std::fs::rename(&staged, &path)
        .map_err(|error| format!("cannot replace {}: {error}", path.display()))?;
    drop(lock);
    Ok(answer)
}

/// The register at `path`; the empty one when none was written yet.
pub fn read(path: &Path) -> Result<Register, String> {
    match std::fs::read(path) {
        Ok(bytes) => serde_json::from_slice(&bytes)
            .map_err(|error| format!("{} cannot be read: {error}", path.display())),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(Register::default()),
        Err(error) => Err(format!("{} cannot be read: {error}", path.display())),
    }
}

/// The SHA-256 of `bytes`, as lowercase hex.
pub fn digest(bytes: &[u8]) -> String {
    Sha256::digest(bytes)
        .iter()
        .map(|byte| format!("{byte:02x}"))
        .collect()
}

/// The digests of the contents `relative` held when edits of it were handed
/// to `session`: a change of the file built on one of them carries the handed
/// edits with the session's own.
pub fn handed_to(common: &Path, relative: &str, session: &str) -> Result<Vec<String>, String> {
    Ok(read(&common.join(REGISTER))?
        .handovers
        .into_iter()
        .filter(|handover| handover.path == relative && handover.to == session)
        .map(|handover| handover.content_sha256)
        .collect())
}
