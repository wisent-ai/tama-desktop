//! Removing one imported policy bundle: the inverse of an import. The index
//! entry and the bundle's directory leave the store together, under the same
//! lock an import takes; nothing installed or active is touched, because an
//! imported bundle is inactive.

use std::fs;
use std::path::Path;

use crate::{err, Result};

use super::set_mode;
use super::store::{index_path, lock_store, policy_bundle_store, read_index, transaction_id};

/// Remove the bundle imported from `source` (its source path or source key).
/// Returns the removed bundle's source path, or `None` when the store holds
/// no bundle from that source, so a repeated removal changes nothing.
pub fn remove_policy_bundle(home: Option<&Path>, source: &str) -> Result<Option<String>> {
    let store = policy_bundle_store(home)?;
    let _lock = lock_store(&store)?;
    let mut index = read_index(&store)?;
    let Some(position) = index
        .bundles
        .iter()
        .position(|bundle| bundle.source_path == source || bundle.source_key == source)
    else {
        return Ok(None);
    };
    let removed = index.bundles.remove(position);
    let bundle_root = Path::new(&removed.bundle_path);
    if !bundle_root.starts_with(store.join("bundles")) {
        return Err(err(format!(
            "the index names a bundle outside the store ({}); nothing was removed",
            removed.bundle_path
        )));
    }
    let staged_index = store.join(format!(".index.{}.json", transaction_id()?));
    fs::write(&staged_index, serde_json::to_vec_pretty(&index)?)?;
    set_mode(&staged_index, crate::OWNER_ONLY_FILE)?;
    fs::rename(&staged_index, index_path(&store))?;
    if crate::presence::present(bundle_root)? {
        fs::remove_dir_all(bundle_root).map_err(|error| {
            err(format!(
                "the index no longer lists {}, but its directory {} could not be removed: {error}",
                removed.source_path, removed.bundle_path
            ))
        })?;
    }
    Ok(Some(removed.source_path))
}
