//! Where a staging transaction's index starts and how it replaces the
//! checkout's own. A checkout whose index file is absent starts from `HEAD`:
//! Git reads a missing index as empty, and staging onto that would stage the
//! deletion of every tracked file. Publishing refuses an index that no longer
//! holds a path the index it replaces held while that file is still on disk:
//! a staged deletion removes the file, so such a drop is never what a session
//! staged.
use std::collections::BTreeSet;
use std::fs::{self, File};
use std::path::Path;

use super::{git, Transaction};

/// The paths an index holds, read through `GIT_INDEX_FILE`.
fn indexed(transaction: &Transaction, index: &Path) -> Result<BTreeSet<String>, String> {
    let listed = git(&transaction.root)
        .index(index)
        .text(&["ls-files", "-z"])?;
    Ok(listed
        .split('\0')
        .filter(|path| !path.is_empty())
        .map(str::to_owned)
        .collect())
}

/// Whether the checkout's `HEAD` names a commit: an unborn branch has none.
pub(in crate::evidence::session_changes) fn born(
    transaction: &Transaction,
) -> Result<bool, String> {
    let (answered, _) =
        transaction
            .git()
            .answered(&["rev-parse", "--quiet", "--verify", "HEAD^{tree}"])?;
    Ok(answered)
}

/// The paths the index being replaced holds: the checkout's index file, or
/// `HEAD`'s files when there is none.
fn replaced(transaction: &Transaction) -> Result<BTreeSet<String>, String> {
    match transaction.original.try_exists() {
        Ok(true) => indexed(transaction, &transaction.original),
        Ok(false) if born(transaction)? => Ok(transaction
            .git()
            .text(&["ls-tree", "-r", "-z", "--name-only", "HEAD"])?
            .split('\0')
            .filter(|path| !path.is_empty())
            .map(str::to_owned)
            .collect()),
        Ok(false) => Ok(BTreeSet::new()),
        Err(cause) => Err(format!(
            "cannot inspect index {}: {cause}",
            transaction.original.display()
        )),
    }
}

impl Transaction {
    pub(super) fn prepare(&mut self) -> Result<(), String> {
        fs::create_dir_all(&self.area)
            .map_err(|cause| format!("cannot create {}: {cause}", self.area.display()))?;
        if self
            .area
            .canonicalize()
            .map_err(|cause| format!("cannot resolve staging scratch: {cause}"))?
            != self.area
        {
            return Err(format!(
                "staging scratch {} resolves through a link",
                self.area.display()
            ));
        }
        match fs::metadata(&self.original) {
            Ok(_) => {
                fs::copy(&self.original, &self.index).map_err(|cause| {
                    format!("cannot snapshot index {}: {cause}", self.original.display())
                })?;
            }
            Err(cause) if cause.kind() == std::io::ErrorKind::NotFound => {
                match fs::remove_file(&self.index) {
                    Ok(()) => {}
                    Err(cause) if cause.kind() == std::io::ErrorKind::NotFound => {}
                    Err(cause) => {
                        return Err(format!(
                            "cannot remove stale staging index {}: {cause}",
                            self.index.display()
                        ))
                    }
                }
                if born(self)? {
                    self.git().bytes(&["read-tree", "HEAD"])?
                } else {
                    self.git().bytes(&["read-tree", "--empty"])?
                };
            }
            Err(cause) => {
                return Err(format!(
                    "cannot inspect index {}: {cause}",
                    self.original.display()
                ))
            }
        }
        Ok(())
    }

    /// Why the staged index may not replace the checkout's: the paths it
    /// dropped from the index it replaces whose files are still on disk,
    /// named with the checkout and both counts.
    fn dropped(&self) -> Result<Option<String>, String> {
        let before = replaced(self)?;
        let after = indexed(self, &self.index)?;
        let mut kept = Vec::new();
        for path in before.difference(&after) {
            match self.root.join(path).symlink_metadata() {
                Ok(_) => kept.push(path.as_str()),
                Err(cause) if cause.kind() == std::io::ErrorKind::NotFound => {}
                Err(cause) => {
                    return Err(format!(
                        "cannot inspect {path} in {}: {cause}",
                        self.root.display()
                    ))
                }
            }
        }
        let Some(first) = kept.first() else {
            return Ok(None);
        };
        Ok(Some(format!(
            "the staged index of {} holds {} path(s) where the index it replaces holds {}, and {} of the dropped paths are still files on disk (first: {first}); a staged deletion removes its file, so this index was not staged by a session and is not published. Read the index with `git -C {} status` and stage again",
            self.root.display(),
            after.len(),
            before.len(),
            kept.len(),
            self.root.display()
        )))
    }

    pub fn publish(mut self) -> Result<(), String> {
        if let Some(refusal) = self.dropped()? {
            return Err(refusal);
        }
        let Some(lock) = self.lock.as_mut() else {
            return Err(
                "this staging was begun as a read and holds no index lock to publish through"
                    .into(),
            );
        };
        let mut index = File::open(&self.index).map_err(|cause| {
            format!("cannot open staged index {}: {cause}", self.index.display())
        })?;
        std::io::copy(&mut index, &mut lock.file).map_err(|cause| {
            format!(
                "cannot write Git index lock {}: {cause}",
                lock.path.display()
            )
        })?;
        lock.file
            .sync_all()
            .map_err(|cause| format!("cannot sync Git index lock: {cause}"))?;
        fs::rename(&lock.path, &self.original).map_err(|cause| {
            format!(
                "cannot publish staged index {}: {cause}",
                self.original.display()
            )
        })?;
        self.published = true;
        Ok(())
    }
}
