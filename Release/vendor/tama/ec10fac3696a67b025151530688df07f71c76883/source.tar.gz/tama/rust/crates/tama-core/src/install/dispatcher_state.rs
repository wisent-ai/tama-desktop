//! What each user-global Git hook Tama manages holds right now.
//!
//! The level plan used to print only where the hooks path is, so a machine
//! whose dispatchers were moved aside to `<name>.tama-disabled` with no bypass
//! recorded, and whose `pre-push` another tool then rewrote, read exactly like
//! a machine whose dispatchers run: the push-time formatting gate stopped and
//! nothing said so. Each hook is reported as one of:
//!
//! * `managed` — Tama's dispatcher is in place;
//! * `held aside` — the dispatcher sits at `<name>.tama-disabled` and no
//!   managed dispatcher is in place, with whether a bypass is recorded (a
//!   re-enable restores only a recorded one) and what the hook path holds
//!   instead;
//! * `foreign` — another program's hook is in place and no dispatcher is held;
//! * `absent` — nothing is in place;
//! * `unreadable: <cause>` — a hook is in place that this process cannot
//!   read, so whether it is Tama's dispatcher cannot be told.

use std::fs;
use std::path::Path;

use serde::Serialize;

use super::dispatcher::{bypass_is_recorded, join_path};
use super::{current_global_hooks_path, MANAGED_HEADER};

const DISABLED_SUFFIX: &str = ".tama-disabled";

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct DispatcherState {
    pub hook: String,
    pub path: String,
    pub state: String,
    pub held_at: Option<String>,
    pub bypass_recorded: bool,
    pub in_place: Option<String>,
    /// The line `describe` writes, carried in the document so Tama Desktop
    /// shows the operator the same sentence the CLI prints.
    pub description: String,
    pub rust_format_connected: bool,
    pub preserved_hook: Option<String>,
}

impl DispatcherState {
    /// One line for a person: the hook, its path, its state, where a held
    /// dispatcher sits and whether a re-enable can restore it, and what is in
    /// place instead.
    pub fn describe(&self) -> String {
        let held = match (&self.held_at, self.bypass_recorded) {
            (Some(held), true) => format!("; dispatcher held at {held} by a recorded bypass"),
            (Some(held), false) => format!(
                "; dispatcher held at {held} with no bypass recorded, so no re-enable restores it"
            ),
            (None, _) => String::new(),
        };
        let in_place = match &self.in_place {
            Some(line) => format!("; in place: {line}"),
            None => String::new(),
        };
        let formatting = if self.hook == "pre-push" {
            format!(
                "; Rust formatting connected: {}",
                self.rust_format_connected
            )
        } else {
            String::new()
        };
        let preserved = match &self.preserved_hook {
            Some(path) => format!("; chained original hook: {path}"),
            None => String::new(),
        };
        format!(
            "{} ({}): {}{held}{in_place}{formatting}{preserved}",
            self.hook, self.path, self.state
        )
    }
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct UserGlobalGitLevel {
    pub level: String,
    pub active_by_archive_alone: bool,
    pub current_hooks_path: Option<String>,
    /// Why the configured hooks path could not be read, when it could not:
    /// the level then reads no dispatcher rather than taking it for unset.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub hooks_path_error: Option<String>,
    pub config_command: String,
    pub dispatchers: Vec<String>,
    /// Empty when no hooks path is configured: no hook of this level is read.
    pub dispatcher_states: Vec<DispatcherState>,
    pub install_command: String,
}

/// The user-global Git level of the plan: where the hooks path is and what
/// each managed hook there holds.
pub(super) fn user_global_git_level(hooks_path: Option<&str>, home: &str) -> UserGlobalGitLevel {
    let (current_hooks_path, hooks_path_error) = match hooks_path {
        Some(path) => (Some(path.to_string()), None),
        None => match current_global_hooks_path(Some(home)) {
            Ok(path) => (path, None),
            Err(error) => (None, Some(error.to_string())),
        },
    };
    let dispatchers = super::GIT_HOOKS
        .iter()
        .map(|hook| (*hook).to_string())
        .collect::<Vec<_>>();
    let states = match current_hooks_path.as_deref() {
        Some(path) => dispatcher_states(path, home, &dispatchers),
        None => Vec::new(),
    };
    UserGlobalGitLevel {
        level: "user-global-git".to_string(),
        active_by_archive_alone: false,
        current_hooks_path,
        hooks_path_error,
        config_command: "git config --global core.hooksPath <hooksPath>".to_string(),
        dispatchers,
        dispatcher_states: states,
        install_command: "tama install --git-hooks-path <path>".to_string(),
    }
}

fn managed(text: &str) -> bool {
    let mut lines = text.split('\n');
    lines.next() == Some("#!/bin/sh") && lines.next() == Some(MANAGED_HEADER)
}

fn rust_format_connected(body: &str) -> bool {
    if !managed(body) || !body.contains("repo-githooks/rust/pre-push") {
        return false;
    }
    let Some(root) = body.lines().find_map(|line| line.strip_prefix("ROOT=")) else {
        return false;
    };
    let Ok(root) = serde_json::from_str::<String>(root) else {
        return false;
    };
    Path::new(&root)
        .join("repo-githooks/rust/pre-push")
        .is_file()
}

/// The first line of the hook in place that is not its interpreter line: what
/// another program wrote there, enough to name it.
fn first_statement(text: &str) -> Option<String> {
    text.lines()
        .map(str::trim)
        .find(|line| !line.is_empty() && !line.starts_with("#!"))
        .map(str::to_string)
}

/// The state of each hook in `hooks` under `hooks_path` for the account at
/// `home`. An emergency state that cannot be read leaves every hook's state
/// unreadable with that cause: whether a bypass holds it aside is unknown.
pub fn dispatcher_states(hooks_path: &str, home: &str, hooks: &[String]) -> Vec<DispatcherState> {
    let (bypass_recorded, bypass_failure) = match bypass_is_recorded(home) {
        Ok(recorded) => (recorded, None),
        Err(error) => (false, Some(format!("unreadable: {error}"))),
    };
    hooks
        .iter()
        .map(|hook| {
            let path = join_path(hooks_path, hook);
            let held = join_path(hooks_path, &format!("{hook}{DISABLED_SUFFIX}"));
            let (read_failure, text) = match fs::read_to_string(&path) {
                Ok(text) => (None, Some(text)),
                Err(error) if error.kind() == std::io::ErrorKind::NotFound => (None, None),
                Err(error) => (Some(format!("unreadable: {error}")), None),
            };
            // A held copy that cannot be examined is said, not read as one
            // the bypass is not holding.
            let (held_failure, held_at) = match crate::presence::present(Path::new(&held)) {
                Ok(true) => (None, Some(held)),
                Ok(false) => (None, None),
                Err(error) => (Some(format!("unreadable: {error}")), None),
            };
            let unreadable = bypass_failure.clone().or(read_failure).or(held_failure);
            let state = match (unreadable, &text, &held_at) {
                (Some(cause), _, _) => cause,
                (None, Some(text), _) if managed(text) => "managed".to_string(),
                (None, _, Some(_)) => "held aside".to_string(),
                (None, Some(_), None) => "foreign".to_string(),
                (None, None, None) => "absent".to_string(),
            };
            let mut found = DispatcherState {
                hook: hook.clone(),
                path,
                state,
                held_at,
                bypass_recorded,
                in_place: text
                    .as_deref()
                    .filter(|text| !managed(text))
                    .and_then(first_statement),
                description: String::new(),
                rust_format_connected: text.as_deref().is_some_and(rust_format_connected),
                preserved_hook: {
                    let backup = join_path(hooks_path, &format!("{hook}.before-tama"));
                    (text.as_deref().is_some_and(managed) && Path::new(&backup).is_file())
                        .then_some(backup)
                },
            };
            found.description = found.describe();
            found
        })
        .collect()
}
