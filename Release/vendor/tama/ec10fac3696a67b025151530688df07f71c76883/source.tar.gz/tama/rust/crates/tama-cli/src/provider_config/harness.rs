//! The hook block for a harness `tama_core::harnesses` declares: the same
//! Claude Code matcher groups `build_hooks` makes for every registry event,
//! keyed by the harness's own event and matcher, rendered in the shape the
//! harness's file holds.

use serde_json::{Map, Value};
use tama_core::harnesses::{self, Adapter};
use tama_hook_tools::registry::{build_hooks, event_hooks, events, hook_config_generate};

/// The matcher groups for `adapter`, before rendering.
fn groups(
    registry: &Value,
    adapter: &Adapter,
    dispatcher: &str,
) -> Result<Map<String, Value>, String> {
    if adapter.claude_events {
        return build_hooks(registry, &adapter.id, dispatcher);
    }
    let mut out: Map<String, Value> = Map::new();
    for (event, entry) in events(registry)? {
        let Some(target) = adapter.events.get(event) else {
            continue;
        };
        let hooks: Vec<Value> = event_hooks(event, entry)?
            .iter()
            .map(|hook| hook_config_generate(event, hook, &adapter.id, dispatcher))
            .collect();
        let mut group = Map::new();
        group.insert("hooks".into(), Value::Array(hooks));
        if let Some(matcher) = &target.matcher {
            group.insert("matcher".into(), Value::String(matcher.clone()));
        }
        if let Value::Array(entries) = out
            .entry(target.key.clone())
            .or_insert_with(|| Value::Array(Vec::new()))
        {
            entries.push(Value::Object(group));
        }
    }
    Ok(out)
}

/// A harness's rendered block and the Claude Code groups it came from.
type Block = (Value, Map<String, Value>);

/// The rendered block and the Claude Code groups it came from, for the
/// harness `provider` names; none when no adapter is declared for it.
pub(super) fn block(
    registry: &Value,
    provider: &str,
    dispatcher: &str,
) -> Result<Option<Block>, String> {
    let Some(adapter) = harnesses::by_id(provider) else {
        return Ok(None);
    };
    let groups = groups(registry, adapter, dispatcher)?;
    Ok(Some((harnesses::render(adapter, &groups), groups)))
}

/// Every provider this command configures: Claude Code, Codex and each
/// declared harness.
pub(super) fn providers() -> Vec<String> {
    let mut all = vec![String::from("claude"), String::from("codex")];
    all.extend(harnesses::all().iter().map(|adapter| adapter.id.clone()));
    all
}
