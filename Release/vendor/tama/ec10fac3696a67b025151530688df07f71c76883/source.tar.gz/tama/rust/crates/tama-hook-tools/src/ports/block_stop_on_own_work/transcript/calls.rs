//! What one tool call of the turn did, read from its structure: whether it
//! changed source, and whether it recorded a defect. The call is read as the
//! gates read a live call ([`Call`]): a file tool that changes files by its
//! name, and a shell line by the command paths it runs
//! ([`command_path::reaches`]), so text that only names a command is no call.

use serde_json::{json, Value};

use crate::ports::command_path;
use crate::ports::tool_vocabulary::Call;

/// The command that commits a change to source.
const GIT_COMMIT: &[&str] = &["git", "commit"];
/// The command that records a defect in Oko's register.
const DEFECT_RECORD: &[&str] = &["oko", "defects", "record"];

/// One transcript call, `name` with `arguments`, as a hook payload.
pub(super) fn payload(name: &str, arguments: &Value) -> Value {
    json!({ "tool_name": name, "tool_input": arguments })
}

/// Whether the call changed source: a tool that changes files, or a commit.
pub(super) fn changes_source(call: &Value) -> bool {
    Call::of(call).changes_files() || runs(call, GIT_COMMIT)
}

/// Whether the call recorded a defect.
pub(super) fn records_defect(call: &Value) -> bool {
    runs(call, DEFECT_RECORD)
}

/// Whether the call runs `path`; a shell line that cannot be read is said on
/// stderr and counted as not running it.
fn runs(call: &Value, path: &[&str]) -> bool {
    let path: Vec<String> = path.iter().map(|word| word.to_string()).collect();
    command_path::reaches(call, &path).unwrap_or_else(|cause| {
        eprintln!(
            "block-stop-on-own-work: whether a call runs `{}` cannot be read: {cause}",
            path.join(" ")
        );
        false
    })
}
