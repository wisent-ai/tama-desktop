//! The consent the operator gives in one conversation ([`granted`]), as the
//! runner passes it to a hook process after validating it through
//! `tama_hooks::session_capability`; the consent he gives as standing, for
//! every session, is read by [`standing`].

pub mod standing;

use serde_json::Value;

pub const CAPABILITY_ENV: &str = "AGENT_STRUCTURED_CAPABILITY";

/// Whether `capability` grants `tool`: a grant for that tool with no action
/// list (every action) or one naming `action`; with no `action` asked, any
/// grant for the tool.
pub fn grants(capability: &Value, tool: &str, action: Option<&str>) -> bool {
    let Some(grants) = capability.get("grants").and_then(Value::as_array) else {
        return false;
    };
    grants.iter().any(|grant| {
        grant.get("tool").and_then(Value::as_str) == Some(tool)
            && match (grant.get("actions"), action) {
                (None | Some(Value::Null), _) | (_, None) => true,
                (Some(Value::Array(actions)), Some(wanted)) => {
                    actions.iter().any(|item| item.as_str() == Some(wanted))
                }
                (Some(_), Some(_)) => false,
            }
    })
}

/// Whether the capability this hook process was started with grants `tool`
/// (and `action`, when one is asked). This is how an operator's consent
/// given in this conversation reaches a gate: the agent records it as a Tama
/// session capability with the lifetime he named, and the runner validates
/// its session, release and catalog before it passes it here. No gate reads
/// consent out of words. A consent he gives as standing, which holds in every
/// session, is a ruling read through [`standing`] by the gates that accept
/// one; SSH, a local browser and hook edits are consented per conversation.
pub fn granted(tool: &str, action: Option<&str>) -> bool {
    let admitted = session_capability().is_some_and(|capability| grants(&capability, tool, action));
    if admitted {
        note_used();
    }
    admitted
}

/// The capability this hook process was started with, the one reader of
/// [`CAPABILITY_ENV`] every consent gate goes through: none when the runner
/// passed none. A capability that is present and unreadable admits nothing,
/// and says so on stderr: read as absent, the refusal that follows would tell
/// the agent no consent was recorded while the operator's grant stands in a
/// form nobody parsed.
pub fn session_capability() -> Option<Value> {
    match std::env::var(CAPABILITY_ENV) {
        Err(std::env::VarError::NotPresent) => None,
        Err(error) => {
            eprintln!("tama: the session capability {CAPABILITY_ENV} cannot be read ({error}), so it admits nothing");
            None
        }
        Ok(text) => match serde_json::from_str::<Value>(&text) {
            Ok(capability) => Some(capability),
            Err(error) => {
                eprintln!(
                    "tama: the session capability {CAPABILITY_ENV} is not JSON ({error}), so it admits nothing"
                );
                None
            }
        },
    }
}

/// Say, once per hook process, that this gate admitted the call with the
/// session's capability: `{"capabilityUsed":true}` on stdout. The runner puts
/// it on the hook's result record and the harness spends a single-use grant
/// on that call only; before, every passing call spent it, so a read made
/// between the grant and the build it was given for used it up. A refusal the
/// gate prints after it is still its last line and still refuses.
pub fn note_used() {
    static NOTED: std::sync::Once = std::sync::Once::new();
    NOTED.call_once(|| println!("{}", serde_json::json!({"capabilityUsed": true})));
}
