//! What the guard reads out of a Stop payload: the message the turn ends on,
//! everything the assistant said or thought since the operator last spoke,
//! the operator's last words, and every earlier ending a stop guard refused.
//!
//! The OMP transcript is one JSON object per line. A spoken or thought turn
//! is `{"type":"message","message":{"role":"assistant","content":[{"type":
//! "text","text":…},{"type":"thinking","thinking":…}]}}`; the operator is
//! `role: "user"` with text blocks; and a stop guard's refusal comes back as
//! `{"type":"custom_message","customType":"session-stop-continuation",
//! "content":"<banner>"}`. That last record is how a refused ending is told
//! apart from any other assistant message: it is the prose that immediately
//! preceded a continuation.

mod calls;

use serde::Deserialize;
use serde_json::Value;

use crate::ports::tool_vocabulary::transcript_tool_call;

/// Where a Stop payload carries its transcript: records inline, or the path
/// of the JSONL file that holds them. Each is read in this order.
#[derive(Default, Deserialize)]
#[serde(default)]
struct TranscriptSources {
    transcript: Value,
    messages: Value,
    events: Value,
    transcript_path: Value,
}

const MESSAGE_KEYS: &[&str] = &[
    "last_assistant_message",
    "final_message",
    "assistant_message",
    "response",
];
const MESSAGE_KEY: &str = "message";
const CONTENT_KEY: &str = "content";
const ROLE_KEY: &str = "role";
const ATTRIBUTION_KEY: &str = "attribution";
const AGENT_ATTRIBUTION: &str = "agent";
const TYPE_KEY: &str = "type";
const TEXT_KEY: &str = "text";
const THINKING_KEY: &str = "thinking";
const CUSTOM_TYPE_KEY: &str = "customType";
const ASSISTANT_ROLE: &str = "assistant";
const USER_ROLE: &str = "user";
const TEXT_BLOCK: &str = "text";
const THINKING_BLOCK: &str = "thinking";
const CUSTOM_MESSAGE: &str = "custom_message";
const STOP_CONTINUATION: &str = "session-stop-continuation";
const LINE_JOIN: &str = "\n";
/// A tool call's arguments as the transcript keeps them, as one text.
fn arguments_text(arguments: &Value) -> String {
    arguments.to_string()
}
/// The Oko command surface through which a supervisor hands out, resumes and
/// interrupts its executors' work.
const SESSION_MANAGEMENT: &str = "oko sessions ";
/// The transcript as the guard sees it, folded once from the payload.
#[derive(Debug, Default, PartialEq, Eq)]
pub struct Transcript {
    /// The prose the turn ends on.
    pub final_message: String,
    /// Text and thinking the assistant produced after the operator's last
    /// message, the final message included.
    pub ending_turn: String,
    /// The operator's newest message.
    pub last_operator_message: String,
    /// Every assistant prose that a stop guard then refused, oldest first.
    pub refused_endings: Vec<String>,
    /// Whether a tool call made since the operator last spoke, continuations
    /// included, recorded a defect (`oko defects record`), so what the agent
    /// did about his message is read across every attempt.
    pub recorded_defect: bool,
    /// Whether a tool call made since the operator last spoke changed source
    /// (a tool that changes files, or `git commit`).
    pub changed_source: bool,
    /// The last prose of each earlier operator turn, oldest first: what the
    /// agent ended on before the operator spoke again.
    pub earlier_endings: Vec<String>,
    /// Whether a source change (a tool that changes files, or `git commit`)
    /// was made since the newest stop-guard refusal in this turn; `None`
    /// when no guard refused an ending since the operator spoke.
    pub changed_since_refusal: Option<bool>,
    /// Calls to Oko's session management (`oko sessions …`) made since the
    /// newest stop-guard refusal in this turn, as called: a supervisor's work
    /// on its executors. `None` when no guard refused an ending since the
    /// operator spoke.
    pub delegations_since_refusal: Option<Vec<String>>,
}

impl Transcript {
    /// The transcript the payload carries. A transcript file it names that
    /// cannot be read, or a record in it that does not parse, is refused
    /// naming the file: read as no records, the guard judged an empty turn
    /// and let every ending through.
    pub fn from_payload(payload: &Value) -> Result<Transcript, String> {
        let mut transcript = fold(&records(payload)?);
        if let Some(inline) = inline_final_message(payload) {
            if transcript.ending_turn.is_empty() {
                transcript.ending_turn = inline.clone();
            }
            transcript.final_message = inline;
        }
        Ok(transcript)
    }
}

/// An explicit final message in the payload wins over the transcript.
fn inline_final_message(payload: &Value) -> Option<String> {
    MESSAGE_KEYS.iter().find_map(|key| match payload.get(*key) {
        Some(Value::String(text)) if !text.trim().is_empty() => Some(text.clone()),
        Some(value) if value.is_object() => blocks_text(value.get(CONTENT_KEY)?, TEXT_BLOCK),
        _ => None,
    })
}

/// Every record the payload carries inline or names by path, in order.
fn records(payload: &Value) -> Result<Vec<Value>, String> {
    let sources = TranscriptSources::deserialize(payload)
        .map_err(|error| format!("the Stop payload's transcript fields are malformed: {error}"))?;
    let mut found = Vec::new();
    for source in [
        &sources.transcript,
        &sources.messages,
        &sources.events,
        &sources.transcript_path,
    ] {
        match source {
            Value::Array(items) => {
                found.extend(items.iter().filter(|item| item.is_object()).cloned());
            }
            Value::String(path) => {
                let text = std::fs::read_to_string(path)
                    .map_err(|error| format!("the transcript {path} cannot be read: {error}"))?;
                // One record per line; the parser's error names the line and
                // column of a record that does not parse.
                for record in serde_json::Deserializer::from_str(&text).into_iter::<Value>() {
                    found.push(record.map_err(|error| {
                        format!("the transcript {path} holds a record that is not JSON: {error}")
                    })?);
                }
            }
            _ => {}
        }
    }
    Ok(found)
}

/// The text of every block of one kind, or of a bare string content.
fn blocks_text(content: &Value, kind: &str) -> Option<String> {
    let text = match content {
        Value::String(text) if kind == TEXT_BLOCK => text.clone(),
        Value::Array(blocks) => blocks
            .iter()
            .filter(|block| block.get(TYPE_KEY).and_then(Value::as_str) == Some(kind))
            .filter_map(|block| {
                block
                    .get(if kind == THINKING_BLOCK {
                        THINKING_KEY
                    } else {
                        TEXT_KEY
                    })
                    .and_then(Value::as_str)
            })
            .collect::<Vec<_>>()
            .join(LINE_JOIN),
        _ => return None,
    };
    let trimmed = text.trim();
    (!trimmed.is_empty()).then(|| trimmed.to_owned())
}

fn fold(records: &[Value]) -> Transcript {
    let mut transcript = Transcript::default();
    let mut last_prose = String::new();
    let mut ending_turn: Vec<String> = Vec::new();
    for record in records {
        if record.get(TYPE_KEY).and_then(Value::as_str) == Some(CUSTOM_MESSAGE) {
            if record.get(CUSTOM_TYPE_KEY).and_then(Value::as_str) == Some(STOP_CONTINUATION) {
                if !last_prose.is_empty() {
                    transcript
                        .refused_endings
                        .push(std::mem::take(&mut last_prose));
                }
                // The refused attempt has been judged; what the agent says and
                // thinks after the refusal is the next attempt, judged on its
                // own. Otherwise one sentence in a refused attempt would refuse
                // every attempt after it until the operator spoke — a gate whose
                // key is out of reach (~/agents/policy.md).
                ending_turn.clear();
                transcript.changed_since_refusal = Some(false);
                transcript.delegations_since_refusal = Some(Vec::new());
            }
            continue;
        }
        let message = match record.get(MESSAGE_KEY).filter(|value| value.is_object()) {
            Some(message) => message,
            None if record.get(ROLE_KEY).is_some() => record,
            None => continue,
        };
        let Some(content) = message.get(CONTENT_KEY) else {
            continue;
        };
        match message.get(ROLE_KEY).and_then(Value::as_str) {
            // Harness-injected user-role records carry `attribution: "agent"`.
            // They do not replace the operator's instruction or end the turn.
            Some(USER_ROLE)
                if message.get(ATTRIBUTION_KEY).and_then(Value::as_str)
                    == Some(AGENT_ATTRIBUTION) => {}
            Some(USER_ROLE) => {
                if let Some(text) = blocks_text(content, TEXT_BLOCK) {
                    transcript.last_operator_message = text;
                }
                ending_turn.clear();
                transcript.recorded_defect = false;
                transcript.changed_source = false;
                transcript.changed_since_refusal = None;
                transcript.delegations_since_refusal = None;
                if !transcript.final_message.is_empty() {
                    transcript
                        .earlier_endings
                        .push(std::mem::take(&mut transcript.final_message));
                }
                last_prose.clear();
            }
            Some(ASSISTANT_ROLE) => {
                if let Some(thought) = blocks_text(content, THINKING_BLOCK) {
                    ending_turn.push(thought);
                }
                if let Some(spoken) = blocks_text(content, TEXT_BLOCK) {
                    ending_turn.push(spoken.clone());
                    transcript.final_message = spoken.clone();
                    last_prose = spoken;
                }
                // A tool call in either harness's record: Claude Code's
                // `tool_use` with `input`, OMP's `toolCall` with `arguments`.
                for (name, arguments) in content
                    .as_array()
                    .into_iter()
                    .flatten()
                    .filter_map(transcript_tool_call)
                {
                    let call = calls::payload(name, arguments);
                    let changed = calls::changes_source(&call);
                    transcript.changed_source |= changed;
                    transcript.recorded_defect |= calls::records_defect(&call);
                    let arguments = arguments_text(arguments);
                    if let Some(changed_since) = transcript.changed_since_refusal.as_mut() {
                        // A measurement, a read or a register note is not work on the
                        // item: only a change to source counts.
                        *changed_since |= changed;
                    }
                    if let Some(delegations) = transcript.delegations_since_refusal.as_mut() {
                        if arguments.contains(SESSION_MANAGEMENT) {
                            delegations.push(arguments.clone());
                        }
                    }
                }
            }
            _ => {}
        }
    }
    transcript.ending_turn = ending_turn.join(LINE_JOIN);
    transcript
}
