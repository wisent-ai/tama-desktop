//! Read completed edit snapshots, never infer ownership from a touched path.
use std::collections::{BTreeMap, BTreeSet};
use std::fs::File;
use std::io::{BufRead, BufReader};
use std::path::{Component, Path, PathBuf};

use serde_json::Value;

#[path = "history/commanded.rs"]
pub(super) mod commanded;
#[path = "history/identity.rs"]
mod identity;
#[path = "history/moved.rs"]
mod moved;
#[path = "history/numbered.rs"]
mod numbered;
pub(super) use identity::{kept_session_of, session_of, session_started, transcript, written};
pub(super) use moved::moved;
pub(super) use numbered::resolve;

pub(super) struct Edit {
    pub call: String,
    pub session: Option<std::sync::Arc<str>>,
    pub path: PathBuf,
    pub before: Option<String>,
    pub after: Option<String>,
    /// Kept until named co-authors' receipts have been ordered together.
    pub diff: Option<String>,
    /// Whole-file write; its unobserved base comes from earlier state.
    pub whole: bool,
    /// Unestablished bytes refuse this path alone.
    pub refused: Option<String>,
    pub at: Option<String>,
}

const WRITTEN: &str = "content";

fn text<'a>(value: &'a Value, key: &str) -> Result<&'a str, String> {
    value
        .get(key)
        .and_then(Value::as_str)
        .ok_or_else(|| format!("recorded edit has no text {key}"))
}

fn relative(root: &Path, path: &str) -> Result<PathBuf, String> {
    let path = Path::new(path);
    let relative = path.strip_prefix(root).map_err(|_| {
        format!(
            "recorded edit {} is outside {}",
            path.display(),
            root.display()
        )
    })?;
    if relative.as_os_str().is_empty()
        || relative
            .components()
            .any(|part| !matches!(part, Component::Normal(_)))
    {
        return Err(format!(
            "recorded edit path {} is not a repository file",
            path.display()
        ));
    }
    Ok(relative.to_path_buf())
}

fn append(
    edits: &mut Vec<Edit>,
    root: &Path,
    call: &str,
    details: &Value,
    arguments: Option<&Value>,
) -> Result<(), String> {
    let listed = match (details.get("changes"), details.get("perFileResults")) {
        (Some(changes), _) => Some(changes),
        (None, per_file) => per_file,
    };
    if let Some(changes) = listed {
        let changes = changes.as_array().ok_or_else(|| {
            format!("edit {call} has invalid changes; expected complete file receipts")
        })?;
        for change in changes {
            append(edits, root, call, change, arguments)?;
        }
        return Ok(());
    }
    let target = match details.get("resolvedPath") {
        Some(target) => target
            .as_str()
            .ok_or_else(|| format!("edit {call} has invalid resolvedPath"))?,
        None => text(details, "path")?,
    };
    if !Path::new(target).starts_with(root) {
        return Ok(());
    }
    let Some(operation) = details.get("op").and_then(Value::as_str) else {
        let written = arguments
            .and_then(|arguments| arguments.get(WRITTEN))
            .and_then(Value::as_str);
        let refused = match written {
            Some(_) => None,
            None => Some(format!(
                "edit {call} of {target} has no observed file transition and no {WRITTEN} argument holding the \
                 whole file; recorded arguments or a resolved path cannot establish its bytes"
            )),
        };
        edits.push(Edit {
            call: call.to_owned(),
            session: None,
            path: relative(root, target)?,
            before: None,
            after: written.map(str::to_owned),
            diff: None,
            whole: true,
            refused,
            at: None,
        });
        return Ok(());
    };
    let side = |key: &str| {
        match details.get(key).and_then(Value::as_str) {
        Some(text) => Ok(text.to_owned()),
        None => Err(format!(
            "edit {call} of {target} ({operation}) carries no {key}, so its bytes cannot be established"
        )),
    }
    };
    let diff = match (
        operation,
        details.get("oldText"),
        details.get("diff").and_then(Value::as_str),
    ) {
        ("update", None, Some(diff)) => Some(diff.to_owned()),
        _ => None,
    };
    let transition = match (operation, diff.as_ref()) {
        ("update", Some(_)) => Ok((None, None)),
        ("update", _) => {
            side("oldText").and_then(|old| side("newText").map(|new| (Some(old), Some(new))))
        }
        ("create", _) => side("newText").map(|new| (None, Some(new))),
        ("delete", _) => side("oldText").map(|old| (Some(old), None)),
        (operation, _) => Err(format!(
            "edit {call} of {target} uses {operation} without a supported complete file transition"
        )),
    };
    let (before, after, refused) = match transition {
        Ok((before, after)) => (before, after, None),
        Err(cause) => (None, None, Some(cause)),
    };
    edits.push(Edit {
        call: call.to_owned(),
        session: None,
        path: relative(root, target)?,
        before,
        after,
        diff,
        whole: false,
        refused,
        at: None,
    });
    Ok(())
}

pub(super) fn read_at(
    root: &Path,
    path: &Path,
    expected: Option<&str>,
) -> Result<Vec<Edit>, String> {
    let edits = read(root, path, expected)?;
    if edits.is_empty() {
        return Err(format!(
            "session {} has no completed before/after edit receipts in {}; no files were staged",
            path.display(),
            root.display()
        ));
    }
    Ok(edits)
}

/// Read successful receipts, validating the original or moved identity.
pub(super) fn read(root: &Path, path: &Path, expected: Option<&str>) -> Result<Vec<Edit>, String> {
    let session = path.display();
    let file = File::open(path)
        .map_err(|cause| format!("cannot open session {}: {cause}", path.display()))?;
    let mut calls = BTreeMap::new();
    let mut completed = BTreeSet::new();
    let mut edits = Vec::new();
    let mut identified = false;
    let mut recorded_session = None;
    for (position, line) in BufReader::new(file).lines().enumerate() {
        let line = line.map_err(|cause| {
            format!("cannot read {} record {position}: {cause}", path.display())
        })?;
        let record: Value = serde_json::from_str(&line).map_err(|cause| {
            format!(
                "invalid session {} record {position}: {cause}",
                path.display()
            )
        })?;
        if record.get("type").and_then(Value::as_str) == Some("session") {
            let identity = text(&record, "id")?;
            let moved_from = record.get("providerPromptCacheKey").and_then(Value::as_str);
            if let Some(expected) = expected {
                if expected != identity && moved_from.is_none_or(|first| first != expected) {
                    return Err(format!(
                        "transcript {} does not belong to session {expected}",
                        path.display()
                    ));
                }
            }
            let original = match moved_from {
                Some(original) => original,
                None => identity,
            };
            recorded_session = Some(std::sync::Arc::<str>::from(original));
            identified = true;
        }
        let Some(message) = record.get("message") else {
            continue;
        };
        if message.get("role").and_then(Value::as_str) == Some("assistant") {
            if let Some(content) = message.get("content").and_then(Value::as_array) {
                for item in content {
                    if item.get("type").and_then(Value::as_str) == Some("toolCall") {
                        let id = text(item, "id")?.to_owned();
                        let name = text(item, "name")?.to_owned();
                        let arguments = item.get("arguments").cloned();
                        if calls.insert(id.clone(), (name, arguments)).is_some() {
                            return Err(format!("session {session} repeats tool call {id}"));
                        }
                    }
                }
            }
            continue;
        }
        if message.get("role").and_then(Value::as_str) != Some("toolResult") {
            continue;
        }
        let Some(details) = message.get("details") else {
            continue;
        };
        if details.get("oldText").is_none()
            && details.get("newText").is_none()
            && details.get("resolvedPath").is_none()
            && details.get("diff").is_none()
            && details.get("changes").is_none()
            && details.get("perFileResults").is_none()
        {
            continue;
        }
        let call = text(message, "toolCallId")?;
        let name = text(message, "toolName")?;
        let (invocation, arguments) = calls.get(call).ok_or_else(|| {
            format!("session {session} edit result {call} has no matching invocation")
        })?;
        if invocation != name {
            return Err(format!(
                "session {session} edit result {call} has no matching invocation"
            ));
        }
        // Only a file-changing tool's successful result authorizes bytes.
        if !crate::ports::tool_vocabulary::Call::of(&serde_json::json!({ "name": name }))
            .changes_files()
        {
            continue;
        }
        if !completed.insert(call.to_owned()) {
            return Err(format!("session {session} repeats edit result {call}"));
        }
        match message.get("isError").and_then(Value::as_bool) {
            Some(true) => continue,
            Some(false) => {}
            None => {
                return Err(format!(
                    "session {session} edit {call} has no observed success state"
                ))
            }
        }
        let added = edits.len();
        append(&mut edits, root, call, details, arguments.as_ref())?;
        let at = record
            .get("timestamp")
            .and_then(Value::as_str)
            .map(str::to_owned);
        edits[added..].iter_mut().for_each(|edit| {
            edit.at.clone_from(&at);
            edit.session.clone_from(&recorded_session);
        });
    }
    if !identified {
        return Err(format!(
            "transcript {} contains no session identity",
            path.display()
        ));
    }
    Ok(edits)
}
