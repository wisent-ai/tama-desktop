//! `tama attestation standard|check|attest|pending|record|show|list|verify|revoke|remove|migrate`.
//!
//! A commit carries its attestation in its message or in the note `attest`
//! keeps beside it, and a turn end in its answer; `carried` reads both with no
//! model: `standard` prints what to carry, `check` names what one text lacks,
//! and `pending` reads every commit a branch carries over its upstream.
//!
//! A session's finished-task attestation is recorded instead (`record`,
//! `show`, `remove`, `standard --session ID`); `list` and `verify` read every
//! registry as one record with no model (`registries`), and Tama Desktop's
//! `attestation/*` requests (`requests`) run the same functions.

mod carried;
mod printing;
mod registries;
pub(crate) mod requests;

/// Bring every registry into the attestation ledger (`migrate`, and a release install).
pub(crate) fn migrate() -> Result<Value, String> {
    registries::migrate::migrate()
}

use std::path::Path;

use printing::{print_human, USAGE};
use serde_json::Value;
use tama_hook_tools::ports::{harsh_review::attested, task_attestation::subject::Subject};

use crate::cli::output::print_json;

#[derive(Default)]
struct Arguments {
    file: Option<String>,
    session: Option<String>,
    commit: Option<String>,
    repository: Option<String>,
    turn: Option<String>,
    kind: Option<String>,
    subject: Option<String>,
    /// What `record --kind` attests of its subject.
    statement: Option<String>,
    /// Under `standard`, `--commit` and `--turn` name a standard and take no value.
    commit_standard: bool,
    turn_standard: bool,
    json: bool,
}

/// The flags after the verb; an unknown flag, a flag without its value or a
/// stray word is refused by name.
fn arguments(verb: &str, words: &[String]) -> Result<Arguments, String> {
    let mut parsed = Arguments::default();
    let mut words = words.iter();
    while let Some(word) = words.next() {
        let slot = match (verb, word.as_str()) {
            (_, "--json") => {
                parsed.json = true;
                continue;
            }
            ("standard", "--commit") => {
                parsed.commit_standard = true;
                continue;
            }
            ("standard", "--turn") => {
                parsed.turn_standard = true;
                continue;
            }
            (_, "--file") => &mut parsed.file,
            (_, "--session") => &mut parsed.session,
            (_, "--commit") => &mut parsed.commit,
            (_, "--repository") => &mut parsed.repository,
            (_, "--turn") => &mut parsed.turn,
            (_, "--kind") => &mut parsed.kind,
            (_, "--subject") => &mut parsed.subject,
            (_, "--statement") => &mut parsed.statement,
            (_, other) => return Err(format!("{other} is not an option of this command")),
        };
        match words.next().filter(|value| !value.starts_with("--")) {
            Some(value) if slot.is_none() => *slot = Some(value.clone()),
            Some(_) => return Err(format!("{word} is given twice")),
            None => return Err(format!("{word} needs a value")),
        }
    }
    Ok(parsed)
}

impl Arguments {
    /// A recorded attestation's verbs take `--session ID`, `record` also
    /// `--file PATH`, and nothing that names a commit or a turn: those carry
    /// their attestation in their own text.
    fn only_session(&self, verb: &str, file: bool) -> Result<(), String> {
        let carried = self.commit.is_some() || self.repository.is_some() || self.turn.is_some();
        match (self.session.is_some(), file, self.file.is_some(), carried) {
            (false, _, _, _) => Err(format!("{verb} needs --session ID")),
            (true, true, false, _) => Err(format!("{verb} needs --file PATH")),
            (true, false, true, _) => Err(format!("{verb} takes no --file")),
            (true, _, _, true) => Err(format!(
                "{verb} takes no --commit, --repository or --turn: a commit or a turn carries its attestation in its own text, which tama attestation check reads"
            )),
            _ => Ok(()),
        }
    }

    /// Whether the flags fit the verb, before anything is read or changed:
    /// every refusal here is a usage error.
    fn shape(&self, verb: &str) -> Result<(), String> {
        let named = (
            self.commit_standard,
            self.turn_standard,
            self.session.is_some(),
            self.file.is_some() || self.repository.is_some() || self.commit.is_some(),
        );
        match verb {
            "standard" => match named {
                (true, false, false, false) | (false, true, false, false) => Ok(()),
                (false, false, true, false) => Ok(()),
                _ => Err("standard prints one standard: --commit, --turn or --session ID".into()),
            },
            "check" => match (&self.commit, &self.turn, &self.file, &self.session) {
                (Some(_), None, None, None) => Ok(()),
                (None, Some(_), Some(_), None) if self.repository.is_none() => Ok(()),
                _ => Err(
                    "check reads one text: --commit REV [--repository PATH], or --turn HOOK --file PATH"
                        .into(),
                ),
            },
            "attest" => match (&self.commit, &self.turn, &self.file, &self.session) {
                (Some(_), None, Some(_), None) => Ok(()),
                _ => Err("attest keeps one commit's attestation: --commit REV --file PATH [--repository PATH]".into()),
            },
            "pending" => self.only_repository(verb),
            "unjudged" => self.only_repository(verb),
            "record" if self.kind.is_some() => self.only_registries(verb).and_then(|()| {
                match (&self.subject, &self.statement) {
                    (Some(_), Some(_)) => Ok(()),
                    _ => Err("record --kind attests one subject: --subject SUBJECT --statement TEXT".into()),
                }
            }),
            "record" => self.only_session(verb, true),
            "show" => self.only_session(verb, false),
            "remove" => self.only_session(verb, false),
            "list" => self.only_registries(verb),
            "verify" => self.only_registries(verb),
            "migrate" => match (&self.kind, &self.subject, &self.statement) {
                (None, None, None) => self.only_registries(verb),
                _ => Err("migrate brings every registry into the ledger and takes only --json".into()),
            },
            "revoke" => self.only_registries(verb).and_then(|()| match (&self.kind, &self.subject) {
                (Some(_), Some(_)) => Ok(()),
                _ => Err("revoke withdraws one attestation: --kind KIND --subject SUBJECT".into()),
            }),
            other => Err(format!("{other} is not a verb of tama attestation")),
        }
    }

    /// `pending` and `unjudged` read one checkout's unpushed commits and take
    /// only `--repository` and `--json`.
    fn only_repository(&self, verb: &str) -> Result<(), String> {
        let other = self.commit.is_some()
            || self.turn.is_some()
            || self.file.is_some()
            || self.session.is_some();
        if other || self.kind.is_some() || self.subject.is_some() || self.statement.is_some() {
            Err(format!(
                "{verb} reads one checkout's unpushed commits: [--repository PATH]"
            ))
        } else {
            Ok(())
        }
    }

    fn subject(&self) -> Result<Subject, String> {
        match &self.session {
            Some(session) => Subject::session(session),
            None => Err("no session is named".to_string()),
        }
    }

    /// `list`, `verify`, `revoke` and `record --kind` address the registries,
    /// so they take only `--kind`, `--subject` (not `list`), `--statement`
    /// (only `record`) and `--json`.
    fn only_registries(&self, verb: &str) -> Result<(), String> {
        let other = self.file.is_some()
            || self.session.is_some()
            || self.commit.is_some()
            || self.turn.is_some()
            || self.repository.is_some();
        if other {
            return Err(format!(
                "{verb} addresses the registries, so it takes only --kind, --subject, --statement and --json"
            ));
        }
        if verb == "list" && self.subject.is_some() {
            return Err(format!("{verb} takes no --subject; verify and revoke do"));
        }
        if verb != "record" && self.statement.is_some() {
            return Err(format!("{verb} takes no --statement; record --kind does"));
        }
        Ok(())
    }

    /// The kind `--kind` names, if any.
    fn kind(&self) -> Result<Option<registries::Kind>, String> {
        self.kind
            .as_deref()
            .map(registries::Kind::parse)
            .transpose()
    }
}

fn read_text(file: &str) -> Result<String, String> {
    std::fs::read_to_string(file).map_err(|error| format!("{file} cannot be read: {error}"))
}

/// What one verb answers, and whether its effect happened. The flags already
/// fit the verb (`Arguments::shape`).
fn run(verb: &str, parsed: &Arguments) -> Result<(Value, bool), String> {
    let stands = |report: Value| {
        let stands = report["stands"] == Value::Bool(true);
        (report, stands)
    };
    match verb {
        "list" => Ok((Value::Array(registries::listed(parsed.kind()?)?), true)),
        "migrate" => Ok((registries::migrate::migrate()?, true)),
        "verify" => {
            let verified = registries::verify::verify(parsed.kind()?, parsed.subject.as_deref())?;
            let all = verified
                .iter()
                .all(|each| each["verified"] == Value::Bool(true));
            Ok((Value::Array(verified), all))
        }
        "revoke" => match (parsed.kind()?, parsed.subject.as_deref()) {
            (Some(kind), Some(subject)) => Ok((registries::revoke::revoke(kind, subject)?, true)),
            _ => Err("revoke withdraws one attestation: --kind KIND --subject SUBJECT".into()),
        },
        "record" if parsed.kind.is_some() => {
            match (parsed.kind()?, &parsed.subject, &parsed.statement) {
                (Some(kind), Some(subject), Some(statement)) => {
                    Ok((registries::record::record(kind, subject, statement)?, true))
                }
                _ => Err(
                    "record --kind attests one subject: --subject SUBJECT --statement TEXT".into(),
                ),
            }
        }
        "show" => Ok((attested::shown(&parsed.subject()?)?, true)),
        "remove" => Ok((parsed.subject()?.remove()?, true)),
        "standard" if parsed.session.is_some() => Ok((parsed.subject()?.standard()?, true)),
        "standard" => Ok((carried::standard(parsed.commit_standard), true)),
        "attest" => carried::attest_file(parsed).map(stands),
        "pending" => Ok(stands(carried::pending::pending(
            parsed.repository.as_deref().map(Path::new),
        )?)),
        "unjudged" => Ok(stands(carried::unjudged::unjudged(
            parsed.repository.as_deref().map(Path::new),
        )?)),
        "check" => {
            let answer = match &parsed.file {
                Some(file) => Some(read_text(file)?),
                None => None,
            };
            let turn = parsed.turn.as_deref().zip(answer.as_deref());
            let repository = parsed.repository.as_deref().map(Path::new);
            Ok(stands(carried::checked(
                parsed.commit.as_deref(),
                repository,
                turn,
            )?))
        }
        _ => {
            let file = parsed
                .file
                .as_deref()
                .ok_or_else(|| format!("{verb} needs --file PATH"))?;
            let document: Value = serde_json::from_str(&read_text(file)?)
                .map_err(|error| format!("{file} is not JSON: {error}"))?;
            Ok(stands(parsed.subject()?.record(&document)?))
        }
    }
}

pub(crate) fn main(verb: &str, rest: &[String]) -> i32 {
    let parsed = match arguments(verb, rest).and_then(|parsed| parsed.shape(verb).map(|()| parsed))
    {
        Ok(parsed) => parsed,
        Err(error) => {
            eprintln!("attestation {verb}: {error}\n{USAGE}");
            return tama_core::exit::USAGE;
        }
    };
    let (report, done) = match run(verb, &parsed) {
        Ok(answer) => answer,
        Err(error) => {
            eprintln!("attestation {verb}: {error}");
            return tama_core::exit::FAILURE;
        }
    };
    if parsed.json {
        print_json(&report);
    } else {
        print_human(verb, &report, parsed.session.is_some());
    }
    if done {
        tama_core::exit::SUCCESS
    } else {
        tama_core::exit::FAILURE
    }
}
