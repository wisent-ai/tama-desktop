//! `tama request standing/list|show|score|withdraw`: the commit standing
//! register `tama standing` reads and changes, for Tama Desktop, through the
//! same functions and with the same refusals. A request missing what it
//! needs is a bad request naming it; a register, repository or transcript
//! that refuses or cannot be read is a failure naming it.

use serde_json::{json, Value};
use tama_hook_tools::evidence::commit_standing::{all, history, standing, withdraw};

use super::{body, failed, refused, respond, Refused};
use crate::request::reply::{Reply, Request};

pub(super) fn handle(request: Request, writer: &mut Reply) {
    let Some(body) = body(&request, writer) else {
        return;
    };
    let answer = match request.operation.as_str() {
        "standing/list" => all().map(|all| json!(all)).map_err(failed),
        "standing/show" => text(&body, "session").and_then(|session| {
            standing(&session)
                .map(|standing| json!(standing))
                .map_err(failed)
        }),
        "standing/score" => score(&body),
        "standing/withdraw" => take_back(&body),
        other => Err(refused(format!(
            "{other} is no standing operation: list, show, score or withdraw"
        ))),
    };
    respond(writer, answer);
}

/// Charge the commits of `range` in `repository` to the sessions that made
/// them, as `tama standing score` does.
fn score(body: &Value) -> Result<Value, Refused> {
    let repository = text(body, "repository")?;
    let range = text(body, "range")?;
    let scored = history::score(std::path::Path::new(&repository), &range).map_err(failed)?;
    Ok(json!(scored))
}

/// Take one charge back with the reason it was recorded in error.
fn take_back(body: &Value) -> Result<Value, Refused> {
    let id = text(body, "id")?;
    let reason = text(body, "reason")?;
    let (taken, standing) = withdraw(&id, &reason).map_err(failed)?;
    Ok(json!({ "withdrawn": taken, "standing": standing }))
}

/// The non-empty text the request names under `key`.
fn text(body: &Value, key: &str) -> Result<String, Refused> {
    match body.get(key) {
        Some(Value::String(value)) if !value.trim().is_empty() => Ok(value.clone()),
        Some(other) => Err(refused(format!(
            "standing \"{key}\" must be non-empty text, got {other}"
        ))),
        None => Err(refused(format!("standing needs \"{key}\" in the request"))),
    }
}
