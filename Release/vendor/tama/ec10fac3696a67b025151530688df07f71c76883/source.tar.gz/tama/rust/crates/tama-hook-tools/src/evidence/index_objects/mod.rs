//! `tama index repair`: the index entries whose object the repository's
//! store does not hold, and their repair.
//!
//! An index that names an object its store lacks makes `git status`, every
//! diff and every commit of the checkout fail, and Tama's review replays a
//! session's edits against that index, so one such entry stops every commit
//! of the repository. The entries are read once (`git ls-files -s -z`) and
//! the store's objects once (`git cat-file --batch-check
//! --batch-all-objects`). Without `--apply` the answer only names each
//! missing entry. With `--apply` each is repaired in place: an object
//! another checkout of the workspace holds under the same id is copied from
//! there (read with `cat-file blob`, written with `hash-object -w`, the id
//! checked equal); with none, the path is staged again from its working
//! file, or removed from the index when the working file is gone, and the
//! answer names the staged content as lost. The index the commands read is
//! Git's own, or the one `GIT_INDEX_FILE` names.
//!
//! An index that holds no entry while HEAD tracks files is named too
//! (`Emptied`): every tracked file then reads as staged for deletion. With
//! `--apply` it is read back from HEAD (`git read-tree HEAD`, which writes
//! the index only), so the working files keep every change they hold.
//!
//! An index overwritten by another repository's or filled with staging no
//! state of this checkout holds is named entry by entry (`strays`, read in
//! `foreign.rs`), and with `--apply` those entries are read back from HEAD.

use std::collections::BTreeSet;
use std::path::{Path, PathBuf};

use serde::Serialize;

mod foreign;
mod store;

use store::{entry, repair, siblings};
use tama_core::git::Git;

pub const USAGE: &str = "tama index repair [--repo <checkout>] [--apply] [--json]";

/// One index entry whose object the store does not hold, and what was done.
#[derive(Serialize)]
pub struct Missing {
    pub path: String,
    pub object: String,
    /// The checkout the object was copied from, when one held it.
    pub copied_from: Option<PathBuf>,
    /// The repair made: `copied`, `restaged from the working file`,
    /// `removed from the index`, or none without `--apply`.
    pub repair: Option<String>,
    /// Whether the staged content is lost (no checkout held its object).
    pub lost: bool,
}

#[derive(Serialize)]
pub struct Report {
    pub repository: PathBuf,
    /// The index file every command read: Git's own, or the one
    /// `GIT_INDEX_FILE` names, which is not the checkout's when it was set
    /// for another checkout or another purpose.
    pub index: PathBuf,
    /// `GIT_INDEX_FILE` as this process read it, when set.
    pub index_variable: Option<String>,
    pub entries: usize,
    pub missing: Vec<Missing>,
    /// The index lost every entry while HEAD tracks files: how many HEAD
    /// tracks, and whether `--apply` read them back into the index.
    pub emptied: Option<Emptied>,
    /// Entries that belong to no state of the checkout (`foreign.rs`);
    /// none are read for an emptied index, which `emptied` names whole.
    pub strays: Vec<foreign::Stray>,
    pub applied: bool,
}

/// An index that holds no entry while HEAD tracks `head_entries` files.
/// Every tracked file then reads as staged for deletion, and one plain
/// commit deletes the repository; no writer leaves that on purpose.
#[derive(Serialize)]
pub struct Emptied {
    pub head_entries: usize,
    /// `git read-tree HEAD` wrote HEAD's entries into the index; the working
    /// tree is not touched.
    pub restored: bool,
}

/// How many files HEAD tracks in `root`, or none when HEAD names no commit
/// yet or tracks no file.
fn head_entries(root: &Path) -> Result<Option<usize>, String> {
    let (born, _) =
        Git::of(Some(root)).answered(&["rev-parse", "--verify", "--quiet", "HEAD^{commit}"])?;
    if !born {
        return Ok(None);
    }
    let listed = Git::of(Some(root)).bytes(&["ls-tree", "-r", "-z", "--name-only", "HEAD"])?;
    let names: Vec<&[u8]> = listed
        .split(|byte| *byte == b'\0')
        .filter(|name| !name.is_empty())
        .collect();
    Ok((!names.is_empty()).then_some(names.len()))
}

/// Every missing entry of the index `directory` reads, repaired with `apply`.
pub fn run(directory: &Path, apply: bool) -> Result<Report, String> {
    let root = PathBuf::from(
        Git::of(Some(directory))
            .text(&["rev-parse", "--show-toplevel"])?
            .trim(),
    );
    let index = PathBuf::from(
        Git::of(Some(&root))
            .text(&["rev-parse", "--path-format=absolute", "--git-path", "index"])?
            .trim(),
    );
    let index_variable =
        std::env::var_os("GIT_INDEX_FILE").map(|value| value.to_string_lossy().into_owned());
    let stored: BTreeSet<String> = Git::of(Some(&root))
        .text(&[
            "cat-file",
            "--batch-check=%(objectname)",
            "--batch-all-objects",
        ])?
        .lines()
        .map(str::to_owned)
        .collect();
    let listed = Git::of(Some(&root)).bytes(&["ls-files", "-s", "-z"])?;
    let records: Vec<String> = listed
        .split(|byte| *byte == b'\0')
        .filter(|record| !record.is_empty())
        .map(|record| String::from_utf8_lossy(record).into_owned())
        .collect();
    let mut missing = Vec::new();
    for record in &records {
        let (path, object) = entry(record)?;
        if !stored.contains(&object) {
            missing.push(Missing {
                path,
                object,
                copied_from: None,
                repair: None,
                lost: false,
            });
        }
    }
    if apply && !missing.is_empty() {
        let others = siblings(&root)?;
        for entry in &mut missing {
            repair(&root, entry, &others)?;
        }
    }
    let tracked = if records.is_empty() {
        head_entries(&root)?
    } else {
        None
    };
    let emptied = match tracked {
        Some(head_entries) => {
            if apply {
                Git::of(Some(&root)).bytes(&["read-tree", "HEAD"])?;
            }
            Some(Emptied {
                head_entries,
                restored: apply,
            })
        }
        None => None,
    };
    let strays = match emptied {
        Some(_) => Vec::new(),
        None => foreign::read(&root, apply)?,
    };
    Ok(Report {
        repository: root,
        index,
        index_variable,
        entries: records.len(),
        missing,
        emptied,
        strays,
        applied: apply,
    })
}

/// The native `index/repair` request Desktop sends: the same reading as
/// `tama index repair`, its answer the same report.
#[derive(serde::Deserialize)]
#[serde(deny_unknown_fields)]
struct Request {
    repository: PathBuf,
    apply: bool,
}

/// `index/repair` from Desktop: `{"repository": String, "apply": Boolean}`.
pub fn request(body: serde_json::Value) -> Result<Report, String> {
    let request: Request = serde_json::from_value(body)
        .map_err(|cause| format!("invalid index repair request: {cause}"))?;
    run(&request.repository, request.apply)
}

/// `tama index repair` (module doc).
pub fn cli(arguments: &[String]) -> Result<(), String> {
    let mut repository = None;
    let (mut apply, mut json) = (false, false);
    let mut args = arguments.iter();
    match args.next().map(String::as_str) {
        Some("repair") => {}
        Some(other) => return Err(format!("{other} is not a verb of tama index; {USAGE}")),
        None => return Err(format!("tama index needs its verb; {USAGE}")),
    }
    while let Some(argument) = args.next() {
        match argument.as_str() {
            "--repo" if repository.is_none() => {
                repository = Some(
                    args.next()
                        .ok_or_else(|| format!("--repo needs a checkout; {USAGE}"))?
                        .clone(),
                )
            }
            "--apply" if !apply => apply = true,
            "--json" if !json => json = true,
            other => {
                return Err(format!(
                    "{other} is not an option of tama index repair; {USAGE}"
                ))
            }
        }
    }
    let directory = match repository {
        Some(repository) => PathBuf::from(repository),
        None => std::env::current_dir()
            .map_err(|cause| format!("the current directory cannot be read: {cause}"))?,
    };
    let report = run(&directory, apply)?;
    if json {
        let text = serde_json::to_string_pretty(&report)
            .map_err(|cause| format!("cannot encode the answer: {cause}"))?;
        println!("{text}");
        return Ok(());
    }
    println!(
        "{}: {} index entries, {} naming an object the store does not hold",
        report.repository.display(),
        report.entries,
        report.missing.len()
    );
    if let Some(variable) = &report.index_variable {
        println!(
            "  read the index {} that GIT_INDEX_FILE={variable} names, not necessarily the checkout's own",
            report.index.display()
        );
    }
    if let Some(emptied) = &report.emptied {
        if emptied.restored {
            println!(
                "  the index held no entry while HEAD tracks {} files; read back from HEAD, the working tree untouched",
                emptied.head_entries
            )
        } else {
            println!(
                "  the index holds no entry while HEAD tracks {} files, so every tracked file reads as staged for deletion (run with --apply to read the index back from HEAD)",
                emptied.head_entries
            )
        }
    }
    for stray in &report.strays {
        let done = if stray.repaired {
            "read back from HEAD"
        } else {
            "run with --apply to read it back from HEAD"
        };
        match &stray.object {
            Some(object) => println!("  {} {object}: {}, {done}", stray.path, stray.shape),
            None => println!("  {}: {}, {done}", stray.path, stray.shape),
        }
    }
    for entry in &report.missing {
        match (&entry.repair, &entry.copied_from) {
            (Some(done), Some(from)) => println!(
                "  {} {}: {done} from {}",
                entry.path,
                entry.object,
                from.display()
            ),
            (Some(done), None) => println!(
                "  {} {}: {done}; its staged content is lost",
                entry.path, entry.object
            ),
            (None, _) => println!(
                "  {} {}: missing (run with --apply to repair)",
                entry.path, entry.object
            ),
        }
    }
    Ok(())
}
