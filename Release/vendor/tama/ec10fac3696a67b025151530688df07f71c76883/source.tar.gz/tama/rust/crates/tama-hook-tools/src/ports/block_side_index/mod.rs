//! Decision half of `tama hook block-side-index` (hook id
//! `block-side-index`): a shell line that stages work in an index other than
//! the checkout's own is refused unless the operator granted that exact
//! command in his own words ([`crate::ports::operator_grant`]).
//!
//! A private index is a waiting room: changes parked in it stand on the
//! `HEAD` it was read from, and a commit made from it later takes back
//! everything `main` gained meanwhile. Work is staged in the checkout's own
//! index, where every session and every check sees it.
//!
//! The line is read by the words the shell runs, so quoted data (a prompt,
//! a message) that names the variable is no staging:
//!
//! - `GIT_INDEX_FILE=<path>` as an assignment, after `export` or `env`, or
//!   `export GIT_INDEX_FILE`, `declare -x GIT_INDEX_FILE`;
//! - `git read-tree --index-output=<path>` (or `--index-output <path>`),
//!   which writes a second index.

use serde_json::Value;

use crate::ports::operator_grant::{self, Request};
use crate::ports::tool_vocabulary::Call;

pub const HOOK_ID: &str = "block-side-index";
const GRANT_KIND: &str = "side-index";
const BANNER: &str = "BLOCKED: private index: ";
/// The variable that points Git at another index (git(1), ENVIRONMENT).
const INDEX_VARIABLE: &str = "GIT_INDEX_FILE";
/// The `git read-tree` option that writes the index somewhere else.
const INDEX_OUTPUT: &str = "--index-output";
/// The words that export a variable already set, named next: `export` and
/// the `-x` of `declare -x` and `typeset -x`.
const EXPORTS: &[&str] = &["export", "-x"];

/// The refusal when the call stages in a private index with no grant, `None`
/// when it passes.
pub fn evaluate(payload: &Value) -> Option<String> {
    let call = Call::of(payload);
    if !call.is_shell() {
        return None;
    }
    let command = call.command()?;
    let found = side_indexes(&crate::ports::shell_text::effective_payload(
        payload, command,
    ));
    if found.is_empty() {
        return None;
    }
    let request = Request {
        gate: HOOK_ID,
        command: Some(command),
        paths: &[],
    };
    if operator_grant::granted(payload, &request) {
        return None;
    }
    Some(format!(
        "{BANNER}{}. Changes parked in an index of their own go stale against main, and a commit \
         made from it takes back what main gained meanwhile; stage in the checkout's own index \
         with `git add` and commit from it. {}",
        found.join("; "),
        operator_grant::how_to_grant(GRANT_KIND, HOOK_ID)
    ))
}

/// What in `command` chooses an index other than the checkout's, each said
/// once.
fn side_indexes(command: &str) -> Vec<String> {
    let words: Vec<&str> = command
        .split(|character: char| character.is_whitespace() || ";|&()`'\"".contains(character))
        .filter(|word| !word.is_empty())
        .collect();
    let mut found = Vec::new();
    let assigned = format!("{INDEX_VARIABLE}=");
    let mut previous = "";
    let mut exported = false;
    for &word in &words {
        exported |= EXPORTS.contains(&previous) && word == INDEX_VARIABLE;
        previous = word;
    }
    if exported || words.iter().any(|word| word.starts_with(&assigned)) {
        found.push(format!("`{INDEX_VARIABLE}` points Git at a private index"));
    }
    if words
        .iter()
        .any(|word| *word == INDEX_OUTPUT || word.starts_with(&format!("{INDEX_OUTPUT}=")))
    {
        found.push(format!(
            "`git read-tree {INDEX_OUTPUT}` writes a private index"
        ));
    }
    found
}
