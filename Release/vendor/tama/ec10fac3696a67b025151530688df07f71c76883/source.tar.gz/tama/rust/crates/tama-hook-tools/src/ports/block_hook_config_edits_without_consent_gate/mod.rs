//! Detection half of the consent guard (registry hook
//! `block-hook-config-edits-without-consent`): which paths count as hook
//! sources or configs, and which command text can reach them.
//!
//! The deliberate behaviour changes are listed in the sibling
//! `block_hook_config_edits_without_consent.rs`; `matches_protected` here is
//! the one that resolves a relative path under the payload's `cwd`.

use regex::Regex;
use serde_json::Value;

use super::block_hook_config_edits_without_consent::{recovery, writers};
use super::block_hook_config_edits_without_consent_patterns::Patterns;
use super::pystr;
use super::python_stdlib::join_under;
use super::tool_vocabulary;

/// The arguments after which a shell command's next word is the directory
/// the rest of it runs in: `cd <dir> && …`, `pushd <dir>`, `git -C <dir> …`
/// (and every program that spells it `-C`, such as `make` and `tar`).
const DIRECTORY_CHANGES: &[&str] = &["cd", "pushd", "-C"];
const EDITS_KEY: &str = "edits";
const TARGET_GROUP: &str = "target";
/// Justification registries under `.shared-hooks/` are exempt: they are data
/// the authorization gates require an agent to write, so protecting them
/// deadlocks the gate that asks for them. The exemption is now a name shape
/// (`*justification.json`, `*justifications.json`) recognised in both the raw
/// and the cwd-resolved spelling, and the same paths are exempt inside command
/// text. Before that it was a two-entry list of absolute suffixes, so
/// `test_justifications.json` was refused, `cua_justifications.json` was
/// refused, and a relative spelling of either exempt file was refused too.
/// Quote and bracket noise stripped off a shell token before it is judged
/// (`token.strip()` with an explicit character set).
const TOKEN_TRIM: &[char] = &['"', '\'', '[', ']', '{', '}', ':', ','];

mod text;

use text::{acting_text, executed_text, execution_text, git_configures_hookspath};

pub struct Gate {
    patterns: Patterns,
    cwd: String,
}

impl Gate {
    /// The directory relative paths resolve under: the one the call names
    /// (the shell tool's `cwd`, resolved under the session's), else the
    /// session's, else this process's, so a command the shell tool runs in
    /// another checkout is judged against that checkout's files. When no
    /// directory is named and this process's cannot be read, no relative
    /// path can be judged, and the error says so.
    pub fn new(payload: &Value) -> Result<Self, String> {
        let call = tool_vocabulary::Call::of(payload);
        let session = match call.session_cwd().filter(|cwd| !cwd.is_empty()) {
            Some(cwd) => cwd.to_string(),
            None => std::env::current_dir()
                .map_err(|error| {
                    format!(
                        "the hook payload names no working directory (cwd beside the call, \
                         the raw event's cwd or project_dir) and this process's own cannot be \
                         read, so a relative path in the call cannot be resolved: {error}"
                    )
                })?
                .to_string_lossy()
                .into_owned(),
        };
        let cwd = match call.cwd().filter(|cwd| !cwd.is_empty()) {
            Some(named) => join_under(&session, named),
            None => session,
        };
        Ok(Self {
            patterns: Patterns::compile(),
            cwd,
        })
    }

    /// A candidate is protected if its text matches or if the place it
    /// resolves to under `base` does, so `shared-hooks/x.py` typed from the
    /// repository root is caught as its absolute spelling is.
    fn matches_protected(&self, base: &str, normalized: &str) -> bool {
        self.patterns.protected_path.is_match(normalized)
            || self
                .patterns
                .protected_path
                .is_match(&join_under(base, normalized))
    }

    /// A registry is exempt however it is spelled: the raw text, or the place
    /// it resolves to under `base`.
    fn justification_registry(&self, base: &str, normalized: &str) -> bool {
        self.patterns
            .justification_registry_path
            .is_match(normalized)
            || self
                .patterns
                .justification_registry_path
                .is_match(&join_under(base, normalized))
    }

    pub fn protected_path(&self, path: &str) -> bool {
        self.protected_under(&self.cwd, path)
    }

    fn protected_under(&self, base: &str, path: &str) -> bool {
        let normalized = path.replace('\\', "/");
        if self.justification_registry(base, &normalized) {
            return false;
        }
        self.matches_protected(base, &normalized)
    }

    pub fn git_config_path(&self, path: &str) -> bool {
        let normalized = path.replace('\\', "/");
        self.patterns.git_config_path.is_match(&normalized)
            || self
                .patterns
                .git_config_path
                .is_match(&join_under(&self.cwd, &normalized))
    }

    /// The whole-text match is taken after every justification-registry path is
    /// removed, so a shell write to one of those files is not refused merely
    /// because `.shared-hooks/` appears in the command. Every other mention of
    /// a protected directory still matches, and the token scan below judges
    /// each argument on its own.
    pub fn command_mentions_protected_path(&self, command: &str) -> bool {
        self.protected_mention(command).is_some()
    }

    /// The protected path `command` names, as the text that named it: the
    /// whole-text match, or the argument the token scan judged. Each argument
    /// resolves under the directory the command has moved to by then —
    /// `cd <dir>`, `pushd <dir>`, `git -C <dir>` — starting from the call's
    /// own, so `git -C <product> restore src/…` judges the product's file.
    fn protected_mention(&self, command: &str) -> Option<String> {
        let normalized = command.replace('\\', "/");
        let scrubbed = self
            .patterns
            .justification_registry_in_command
            .replace_all(&normalized, " ");
        if let Some(found) = self.patterns.protected_path.find(&scrubbed) {
            return Some(found.as_str().to_string());
        }
        let mut base = self.cwd.clone();
        let mut moves = false;
        for token in self.patterns.command_token_split.split(&normalized) {
            let stripped = token.trim_matches(TOKEN_TRIM);
            if stripped.is_empty() {
                continue;
            }
            if self.protected_under(&base, stripped) {
                return Some(stripped.to_string());
            }
            if moves {
                base = join_under(&base, stripped);
            }
            moves = DIRECTORY_CHANGES.contains(&stripped);
        }
        None
    }

    /// Which hook-configuration writer this call runs, if it runs one. The
    /// test below reads the text for a path and a write; a tool that writes
    /// hook configuration by itself shows neither. A shell call runs its
    /// command, not its description or directory (`text::executed_text`).
    pub fn execution_runs_hook_config_writer(&self, payload: &Value) -> Option<&'static str> {
        let text = executed_text(payload).replace('\\', "/");
        if text.is_empty() {
            None
        } else {
            writers::runs_hook_config_writer(&text)
        }
    }

    /// Why this call reaches hook configuration, when it does: it sets git's
    /// hooks path, or it names a protected path where the path can act —
    /// outside a shell's quoted data, anywhere in code. Which program or call
    /// would change the file is not read: a list of writers, patch appliers
    /// and language calls would let every writer it left out through, and
    /// reading a hook goes through the harness's read tool, which changes
    /// nothing. The answer quotes the acting text that named
    /// the path, so a refusal of a path the shell only held as data shows
    /// which construct was read as acting.
    ///
    /// A shell call is judged by its command alone (`text::executed_text`).
    pub fn execution_hook_modification(&self, payload: &Value) -> Option<String> {
        let text = executed_text(payload);
        if text.is_empty() {
            return None;
        }
        let normalized = text.replace('\\', "/");
        // Only the quote-aware cut decides: a regex over the raw text read a
        // sentence quoting the setting, and a read of it, as a change.
        if git_configures_hookspath(&normalized) {
            return Some("it sets git's core.hooksPath".to_string());
        }
        let acting = acting_text(payload, &text);
        let named = self.protected_mention(&acting)?;
        let line = acting
            .lines()
            .find(|line| line.replace('\\', "/").contains(&named));
        Some(match line {
            Some(line) => format!("`{named}` stands where it acts, in `{}`", line.trim()),
            None => format!("`{named}` stands where it acts"),
        })
    }

    /// Whether a write tool aims at one of the operator's break-glass files.
    pub fn operator_recovery_write_target(&self, input: &Value) -> Result<bool, String> {
        let mut paths: Vec<String> = Vec::new();
        self.candidate_paths(input, &mut paths)?;
        Ok(recovery::write_tool_target(&self.patterns, &paths))
    }

    /// Whether an execution payload drives one of the break-glass controls.
    pub fn operator_recovery_execution_target(&self, payload: &Value) -> bool {
        recovery::execution_target(&self.patterns, &execution_text(payload))
    }

    fn captured(pattern: &Regex, line: &str) -> Option<String> {
        pattern.captures(line).and_then(|caps| {
            caps.name(TARGET_GROUP)
                .map(|found| found.as_str().to_string())
        })
    }

    /// Paths named by a patch body: hashline headers, `*** Add File:` headers
    /// and unified-diff headers. The hashline target is taken unstripped, the
    /// other two stripped — exactly as the Python does.
    fn patch_candidate_paths(&self, text: &str, found: &mut Vec<String>) -> Result<(), String> {
        let hashline = super::write_payload::hashline::touched_paths(text)?;
        if !hashline.is_empty() {
            found.extend(hashline);
            return Ok(());
        }
        for raw_line in pystr::splitlines(text) {
            let line = pystr::strip(raw_line);
            if let Some(target) = Self::captured(&self.patterns.patch_bracket, line) {
                found.push(target);
                continue;
            }
            if let Some(target) = Self::captured(&self.patterns.patch_file_header, line) {
                found.push(pystr::strip(&target).to_string());
                continue;
            }
            if let Some(target) = Self::captured(&self.patterns.patch_diff_header, line) {
                found.push(pystr::strip(&target).to_string());
            }
        }
        Ok(())
    }

    pub fn candidate_paths(&self, value: &Value, found: &mut Vec<String>) -> Result<(), String> {
        match value {
            Value::String(text) => found.push(text.clone()),
            Value::Object(map) => {
                for text in tool_vocabulary::paths_in(value) {
                    found.push(text.to_string());
                }
                for text in tool_vocabulary::patches_in(value) {
                    self.patch_candidate_paths(text, found)?;
                }
                if let Some(Value::Array(edits)) = map.get(EDITS_KEY) {
                    for edit in edits {
                        self.candidate_paths(edit, found)?;
                    }
                }
            }
            Value::Array(items) => {
                for item in items {
                    self.candidate_paths(item, found)?;
                }
            }
            _ => {}
        }
        Ok(())
    }
}
