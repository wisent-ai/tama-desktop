//! The standing each agent session earns by the commits it makes.
//!
//! Every commit an agent session makes is recorded when Git's `commit-msg`
//! hook reviews it: a commit whose staged files are all in their formatter's
//! form (rustfmt's for Rust, the one the tree's `.tama/formatters.json`
//! declares for any other extension) earns the session one point, and one
//! that stages a file out of that form costs it one point and names the
//! files. The commit is made
//! either way; the session pays for it afterwards. Its standing is the points
//! it earned less the points it lost, and a session whose standing falls
//! below zero has committed more unformatted work than formatted, so
//! `block-negative-commit-standing` refuses its tool calls. The operator takes
//! a charge back with its reason; it then counts toward nothing.
//!
//! The register is one JSON document under Tama's state directory, or the
//! file [`PATH_VARIABLE`] names. Commits are reviewed one at a time under the
//! commit lock, and each write replaces the document whole through a file
//! renamed into place, so a reader never sees half a write.

use std::path::PathBuf;

use serde::{Deserialize, Serialize};

pub mod cli;
pub mod history;

/// The variable that names another register for one process, as the
/// journeys under tests/ set it.
pub const PATH_VARIABLE: &str = "TAMA_COMMIT_STANDING_PATH";

/// One commit an agent session made, as its review found it.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Commit {
    pub id: String,
    pub session: String,
    /// The agent that runs the session, as its recorded process names it.
    pub agent: String,
    /// The checkout the commit was made in.
    pub repository: String,
    /// The commit's tree, as `git write-tree` wrote it during the review.
    pub tree: String,
    /// The staged files out of their formatter's form; none for a commit
    /// that earned its point.
    pub unformatted: Vec<String>,
    pub recorded_at: String,
}

/// A charge the operator took back, and why.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Withdrawn {
    pub commit: Commit,
    pub reason: String,
    pub withdrawn_at: String,
}

#[derive(Debug, Default, Serialize, Deserialize)]
pub struct Document {
    #[serde(default)]
    pub commits: Vec<Commit>,
    #[serde(default)]
    pub withdrawn: Vec<Withdrawn>,
}

/// A session's points, and the charges that lost them.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Standing {
    pub session: String,
    pub earned: usize,
    pub lost: usize,
    pub standing: i64,
    pub blocked: bool,
    pub charges: Vec<Commit>,
    /// What the standing means for the session, in one sentence.
    pub rule: String,
}

/// The register's file: the one [`PATH_VARIABLE`] names, or Tama's own.
pub fn path() -> PathBuf {
    match tama_core::path_variable(PATH_VARIABLE) {
        Some(path) => path,
        None => tama_core::home_dir()
            .join("Library/Application Support/Tama")
            .join("commit-standing.json"),
    }
}

/// The whole register; a register nothing was recorded in yet is empty.
pub fn document() -> Result<Document, String> {
    let path = path();
    let present = tama_core::presence::present(&path).map_err(|error| {
        format!(
            "cannot examine the commit standing register {}: {error}",
            path.display()
        )
    })?;
    if !present {
        return Ok(Document::default());
    }
    let text = std::fs::read_to_string(&path).map_err(|error| {
        format!(
            "cannot read the commit standing register {}: {error}",
            path.display()
        )
    })?;
    serde_json::from_str(&text).map_err(|error| {
        format!(
            "the commit standing register {} is not its document: {error}",
            path.display()
        )
    })
}

fn write(document: &Document) -> Result<(), String> {
    let path = path();
    let folder = path.parent().ok_or_else(|| {
        format!(
            "the commit standing register {} names no folder",
            path.display()
        )
    })?;
    std::fs::create_dir_all(folder)
        .map_err(|error| format!("cannot create {}: {error}", folder.display()))?;
    let staged = path.with_extension(format!("{}.tmp", std::process::id()));
    std::fs::write(&staged, tama_core::json::pretty(document))
        .map_err(|error| format!("cannot write {}: {error}", staged.display()))?;
    std::fs::rename(&staged, &path).map_err(|error| {
        format!(
            "cannot move {} into place as {}: {error}",
            staged.display(),
            path.display()
        )
    })
}

/// Record one commit of `session` and answer its standing after it.
pub fn record(
    session: &str,
    agent: &str,
    repository: &str,
    tree: &str,
    unformatted: Vec<String>,
) -> Result<Standing, String> {
    let mut document = document()?;
    document.commits.push(Commit {
        id: tama_core::random::random_uuid()?,
        session: session.to_string(),
        agent: agent.to_string(),
        repository: repository.to_string(),
        tree: tree.to_string(),
        unformatted,
        recorded_at: tama_core::clock::iso_now_seconds(),
    });
    write(&document)?;
    standing_in(&document, session)
}

/// The standing of `session` now.
pub fn standing(session: &str) -> Result<Standing, String> {
    standing_in(&document()?, session)
}

/// Every session the register holds commits of, blocked ones first.
pub fn all() -> Result<Vec<Standing>, String> {
    let document = document()?;
    let mut sessions: Vec<&str> = Vec::new();
    for commit in &document.commits {
        if !sessions.contains(&commit.session.as_str()) {
            sessions.push(&commit.session);
        }
    }
    let mut all = sessions
        .iter()
        .map(|session| standing_in(&document, session))
        .collect::<Result<Vec<_>, _>>()?;
    all.sort_by_key(|standing| (!standing.blocked, standing.standing));
    Ok(all)
}

/// Take back the charge `id` (a whole id or a prefix naming one charge),
/// saying why; it then counts toward nothing.
pub fn withdraw(id: &str, reason: &str) -> Result<(Withdrawn, Standing), String> {
    if reason.trim().is_empty() {
        return Err("a charge is taken back with the reason it was recorded in error".into());
    }
    if id.trim().is_empty() {
        return Err("a charge is taken back by its id".into());
    }
    let mut document = document()?;
    let matching: Vec<usize> = document
        .commits
        .iter()
        .enumerate()
        .filter(|(_, commit)| !commit.unformatted.is_empty() && commit.id.starts_with(id))
        .map(|(position, _)| position)
        .collect();
    let [position] = matching.as_slice() else {
        return Err(format!(
            "{id:?} names {} charges in the commit standing register {}, not one",
            matching.len(),
            path().display()
        ));
    };
    let commit = document.commits.remove(*position);
    let taken = Withdrawn {
        commit,
        reason: reason.to_string(),
        withdrawn_at: tama_core::clock::iso_now_seconds(),
    };
    document.withdrawn.push(taken.clone());
    write(&document)?;
    let standing = standing_in(&document, &taken.commit.session)?;
    Ok((taken, standing))
}

fn standing_in(document: &Document, session: &str) -> Result<Standing, String> {
    let own: Vec<&Commit> = document
        .commits
        .iter()
        .filter(|commit| commit.session == session)
        .collect();
    let charges: Vec<Commit> = own
        .iter()
        .filter(|commit| !commit.unformatted.is_empty())
        .map(|commit| (*commit).clone())
        .collect();
    let lost = charges.len();
    let earned = own.len() - lost;
    let count = |value: usize| {
        i64::try_from(value).map_err(|error| {
            format!("session {session}'s commit count {value} exceeds a standing: {error}")
        })
    };
    let standing = count(earned)? - count(lost)?;
    let blocked = standing.is_negative();
    let rule = if blocked {
        format!(
            "session {session} made {lost} commit(s) with files out of their formatter's form and {earned} in it: \
             its standing is {standing}, so every tool call it makes is refused"
        )
    } else {
        format!(
            "session {session} stands at {standing}: {earned} formatted commit(s), {lost} charged"
        )
    };
    Ok(Standing {
        session: session.to_string(),
        earned,
        lost,
        standing,
        blocked,
        charges,
        rule,
    })
}
