//! Record an existing user grant to reach a host over SSH, in the registry
//! `block-unauthorized-ssh` reads, without changing the policy that reads it.
//!
//! The gate admits an SSH call only when the operator's consent is the Tama
//! session capability `{"tool": "ssh"}`, the operator's own words name every
//! target and are a verbatim user message of this session, and
//! `ssh_justification.json` holds an entry covering the exact target,
//! operation and path or command. The entry is data; the numeric gate reads
//! its typed consent fields as grant text, while hook-directory protection
//! still governs direct edits. This command is the supported writer and asks
//! the gate's `entry_matches` whether the entry covers each recorded request.

mod command;
mod storage;

use std::path::Path;

use serde::Deserialize;
use serde_json::{json, Value};
use tama_hook_tools::ports::{block_unauthorized_ssh as policy, transport_common};

pub(super) use command::main;

pub(crate) const SCHEMA: &str = "ai.wisent.tama.ssh-justification.v1";
const TOOL: &str = "ssh";
const LIFETIME: &str = "current OMP session";

#[derive(Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub(crate) struct RecordRequest {
    pub session_id: String,
    pub targets: Vec<String>,
    /// The gate's word for what the call does: read, write, exec, transfer,
    /// tunnel or git. Read and write are covered by exact paths, the rest by
    /// exact commands; the gate's own matcher decides which.
    pub operation: String,
    pub paths: Vec<String>,
    pub commands: Vec<String>,
    pub quote: Option<String>,
    pub quote_match: Option<String>,
}

fn nonempty(values: Vec<String>, what: &str) -> Result<Vec<String>, String> {
    let mut kept = Vec::new();
    for value in values {
        let value = value.trim().to_string();
        if value.is_empty() {
            return Err(format!("{what} must not be empty"));
        }
        if !kept.contains(&value) {
            kept.push(value);
        }
    }
    Ok(kept)
}

pub(crate) fn record_request(request: RecordRequest, home: &Path) -> Result<Value, String> {
    if request.session_id.is_empty()
        || !request
            .session_id
            .chars()
            .all(|c| c.is_ascii_alphanumeric() || c == '-')
    {
        return Err("sessionId must be the exact OMP session identifier".into());
    }
    let quote = match (request.quote, request.quote_match) {
        (Some(quote), None) if !quote.trim().is_empty() => quote,
        (None, Some(needle)) if !needle.trim().is_empty() => {
            super::cua::transcript::select(&request.session_id, &needle)?
        }
        _ => return Err("supply exactly one nonempty quote or quoteMatch".into()),
    };
    let targets = nonempty(request.targets, "a target")?;
    if targets.is_empty() {
        return Err("targets must name at least one exact SSH destination".into());
    }
    let operation = request.operation.trim().to_lowercase();
    if operation.is_empty() {
        return Err("operation must name what the call does, in the gate's words".into());
    }
    let paths = nonempty(request.paths, "a path")?;
    let commands = nonempty(request.commands, "a command")?;
    if paths.is_empty() == commands.is_empty() {
        return Err(
            "give exact paths (--path, for read and write) or exact full commands (--command, \
             for exec, transfer, tunnel and git), not both and not neither"
                .into(),
        );
    }
    if !policy::quote_authorizes_targets(&quote, &targets) {
        return Err(
            "the quote must name every target; consent itself is the Tama session capability \
             {\"tool\": \"ssh\"}"
                .into(),
        );
    }
    if !transport_common::quote_is_in_current_session(&request.session_id, &quote) {
        return Err(format!(
            "the quote is not a verbatim user message in OMP session {} under {}",
            request.session_id,
            transport_common::session_root().display()
        ));
    }
    let entry = json!({
        "userRequestQuote": quote,
        "allowedTool": TOOL,
        "allowedTargets": targets,
        "allowedOperations": [operation],
        "allowedPaths": paths,
        "allowedCommands": commands,
        "lifetime": LIFETIME,
        "sessionId": request.session_id,
    });
    // The entry must cover what it was recorded for, by the gate's own
    // reading of it: one request per target and path or command. The gate
    // decides whether the operation is covered by paths or by commands.
    for target in &targets {
        for (path, command) in cases(&paths, &commands) {
            let request = policy::SshRequest {
                operation: operation.clone(),
                targets: vec![target.clone()],
                paths: path.into_iter().collect(),
                command,
            };
            if !policy::entry_matches(&entry, &request, &request_session(&entry)) {
                return Err(format!(
                    "the gate would not admit {operation} to {target} from this entry (an \
                     operation the gate does not know, or paths where it reads commands, or \
                     commands where it reads paths); nothing was recorded"
                ));
            }
        }
    }
    let registry = super::registry::registry_path(home, super::registry::Kind::Ssh);
    storage::record(&registry, entry.clone())?;
    Ok(json!({
        "kind": "ssh",
        "registry": registry,
        "sessionId": entry["sessionId"],
        "authorization": entry,
    }))
}

/// Every (path, command) pair one entry is asked about: one per path when
/// paths were given, one per command otherwise.
fn cases(paths: &[String], commands: &[String]) -> Vec<(Option<String>, Option<String>)> {
    if !paths.is_empty() {
        return paths
            .iter()
            .map(|path| (Some(path.clone()), None))
            .collect();
    }
    commands
        .iter()
        .map(|command| (None, Some(command.clone())))
        .collect()
}

fn request_session(entry: &Value) -> String {
    match entry["sessionId"].as_str() {
        Some(session) => session.to_string(),
        None => String::new(),
    }
}

pub(crate) fn list_document(home: &Path) -> Result<Value, String> {
    let registry = super::registry::registry_path(home, super::registry::Kind::Ssh);
    let document = storage::load(&registry)?;
    Ok(json!({"kind": "ssh", "registry": registry, "authorizations": document["authorizations"]}))
}

/// The one recorded quote that contains `needle`.
pub(crate) fn recorded_quote(home: &Path, needle: &str) -> Result<String, String> {
    if needle.trim().is_empty() {
        return Err("--quote-match must name a fragment of one recorded quote".into());
    }
    let registry = super::registry::registry_path(home, super::registry::Kind::Ssh);
    let document = storage::load(&registry)?;
    let mut quotes: Vec<String> = document["authorizations"]
        .as_array()
        .into_iter()
        .flatten()
        .filter_map(|entry| entry.get("userRequestQuote").and_then(Value::as_str))
        .filter(|quote| quote.contains(needle))
        .map(str::to_string)
        .collect();
    quotes.sort();
    quotes.dedup();
    match quotes.as_slice() {
        [one] => Ok(one.clone()),
        [] => Err(format!("no recorded SSH quote contains {needle:?}")),
        several => Err(format!(
            "{} recorded SSH quotes contain {needle:?}; give a fragment only one of them holds: {}",
            several.len(),
            several.join(" | ")
        )),
    }
}

pub(crate) fn remove_document(home: &Path, quote: &str) -> Result<Value, String> {
    if quote.trim().is_empty() {
        return Err("quote must name the recorded sentence to remove".into());
    }
    let registry = super::registry::registry_path(home, super::registry::Kind::Ssh);
    let count = storage::forget(&registry, quote)?;
    Ok(json!({"kind": "ssh", "registry": registry, "removed": quote, "count": count}))
}
