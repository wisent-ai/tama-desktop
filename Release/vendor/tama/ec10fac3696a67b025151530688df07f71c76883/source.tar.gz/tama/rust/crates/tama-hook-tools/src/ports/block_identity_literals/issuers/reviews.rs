//! Oko's harsh-review queue as an issuer of identities: the program that
//! generates each entry's id. Only those ids count; a UUID quoted in a
//! candidate's message is text its author wrote, not something Oko issued.

use std::collections::HashSet;

use serde_json::Value;

/// The lowercased id of every entry the queue issued. An absent queue issued
/// none; a queue that cannot be read, is not JSON, or is not Oko's
/// `{"entries":[{"id":…}]}` document is refused naming its path and cause.
/// The queue is located as Oko locates it
/// (`store::location("OKO_HARSH_REVIEW_QUEUE", "harsh-review-queue.json")`).
pub(super) fn issued() -> Result<HashSet<String>, String> {
    let path = tama_core::oko_register("OKO_HARSH_REVIEW_QUEUE", "harsh-review-queue.json")?;
    let bytes = match std::fs::read(&path) {
        Ok(bytes) => bytes,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(HashSet::new()),
        Err(error) => {
            return Err(format!(
                "Oko's review queue {} cannot be read: {error}",
                path.display()
            ))
        }
    };
    let document: Value = serde_json::from_slice(&bytes)
        .map_err(|error| format!("Oko's review queue {} is not JSON: {error}", path.display()))?;
    let entries = document
        .get("entries")
        .and_then(Value::as_array)
        .ok_or_else(|| {
            format!(
                "Oko's review queue {} holds no entries array",
                path.display()
            )
        })?;
    entries
        .iter()
        .enumerate()
        .map(|(index, entry)| {
            entry
                .get("id")
                .and_then(Value::as_str)
                .map(str::to_lowercase)
                .ok_or_else(|| {
                    format!(
                        "Oko's review queue {} entry {index} has no id",
                        path.display()
                    )
                })
        })
        .collect()
}
