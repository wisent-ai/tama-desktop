//! The adaptive policy, `adaptive/policy.json`, compiled into the release
//! and read once and whole: its default tier, each tier's declaration, each
//! hook's tier and the autonomy the layer is allowed. Every tier a hook or
//! the default names must be declared, so the tier of any hook is always one
//! the policy declares; a policy that names a tier it does not declare is
//! refused naming the file. Read with defaults, a missing or broken policy
//! put every hook on whatever tier the code assumed. It is compiled in
//! because a policy read at run time from the source tree the binary was
//! built in vanished with that tree, and from then on no refusal of any hook
//! was recorded for the layer.

use std::collections::BTreeMap;
use std::path::Path;

use serde::Deserialize;

use super::Tier;

/// One tier as the policy declares it.
#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
struct TierDeclaration {
    enforce_verdict: bool,
    on_infra_failure: String,
    demotable: bool,
}

#[derive(Debug, Clone, Deserialize)]
struct Defaults {
    tier: String,
}

#[derive(Debug, Clone, Deserialize)]
struct HookEntry {
    tier: String,
}

/// How far the layer may act on its own.
#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Autonomy {
    pub automatic_ceiling: String,
    pub lexical_frustration_and_model: String,
    pub explicit_causal_correction: String,
    pub repair: String,
}

#[derive(Debug, Clone, Deserialize)]
struct Declared {
    defaults: Defaults,
    autonomy: Autonomy,
    tiers: BTreeMap<String, TierDeclaration>,
    hooks: BTreeMap<String, HookEntry>,
}

/// The policy with every tier name resolved to its declaration.
#[derive(Debug, Clone)]
pub struct Policy {
    pub autonomy: Autonomy,
    default: Tier,
    hooks: BTreeMap<String, Tier>,
}

/// `name`'s declaration as a [`Tier`], or the refusal naming who asked for
/// a tier the policy does not declare.
fn resolved(declared: &Declared, name: &str, named_by: &str, path: &Path) -> Result<Tier, String> {
    let declaration = declared.tiers.get(name).ok_or_else(|| {
        format!(
            "{} gives {named_by} the tier {name:?}, which its tiers do not declare",
            path.display()
        )
    })?;
    Ok(Tier {
        name: name.to_string(),
        enforce_verdict: declaration.enforce_verdict,
        on_infra_failure: declaration.on_infra_failure.clone(),
        demotable: declaration.demotable,
    })
}

/// The policy this release was built with.
const DECLARED: &str = include_str!("../../../../../adaptive/policy.json");
/// Where the compiled-in policy comes from, as a refusal names it.
const SOURCE: &str = "adaptive/policy.json";

impl Policy {
    /// The policy this release was built with, or why it cannot be the one
    /// the engine runs.
    pub fn declared() -> Result<Self, String> {
        let path = Path::new(SOURCE);
        let declared: Declared = serde_json::from_str(DECLARED)
            .map_err(|error| format!("{} is not an adaptive policy: {error}", path.display()))?;
        let default = resolved(&declared, &declared.defaults.tier, "the default", path)?;
        let mut hooks = BTreeMap::new();
        for (key, entry) in &declared.hooks {
            let tier = resolved(&declared, &entry.tier, &format!("hook {key}"), path)?;
            hooks.insert(key.clone(), tier);
        }
        Ok(Self {
            autonomy: declared.autonomy,
            default,
            hooks,
        })
    }

    /// `policyEntry(id)` then its tier: the exact key first, then the
    /// longest key that is a prefix of the hook id (two distinct keys of one
    /// length can never both prefix one id, so key order never matters),
    /// and the policy's default tier for a hook it does not name.
    pub fn tier_of(&self, hook_id: &str) -> Tier {
        if let Some(tier) = self.hooks.get(hook_id) {
            return tier.clone();
        }
        let prefixed = self
            .hooks
            .iter()
            .filter(|(key, _)| hook_id.starts_with(key.as_str()))
            .max_by_key(|(key, _)| key.len());
        match prefixed {
            Some((_, tier)) => tier.clone(),
            None => self.default.clone(),
        }
    }
}
