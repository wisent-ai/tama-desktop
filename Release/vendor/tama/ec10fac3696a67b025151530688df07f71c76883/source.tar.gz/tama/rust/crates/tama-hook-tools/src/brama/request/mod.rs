//! One request through Brama, with the bearer and nothing else: a chat
//! completion (`chat`) or any other JSON request on the same transport
//! (`exchange`), which `decision` uses for `POST /v1/decisions`.
//!
//! There used to be an agent HMAC here: a second vault item, a hex encoder,
//! an HMAC implementation and three `x-agent-*` headers. Brama's own
//! contract says a generic model call authorizes on the bearer alone, and
//! the signature only binds caller-scoped subscription operations, which
//! Tama does not make. Worse, the signed agent had to match the identity the
//! bearer resolves to, so signing as one product with another product's
//! token was a 403 waiting to happen. The token carries the identity now.
//!
//! The endpoint and headers reach curl as a `--config` document on standard
//! input, so the bearer never enters an argument vector; the request body
//! reaches it as a file curl reads by path (`body.rs`), because a config
//! line has a length curl will not read past and a prompt that carries a
//! transcript passes it.

use std::io::Write;
use std::process::{Command, Stdio};

use serde_json::Value;

mod body;

use super::credentials::{allowed_endpoint, read};
use body::{config_report, BodyFile};

/// One value inside a curl `--config` document read from standard input,
/// which is how a bearer reaches curl without entering its argv.
pub(super) fn curl_config_value(value: &str) -> String {
    let mut escaped = String::with_capacity(value.len());
    for character in value.chars() {
        match character {
            '\\' => escaped.push_str("\\\\"),
            '"' => escaped.push_str("\\\""),
            '\n' => escaped.push_str("\\n"),
            '\r' => escaped.push_str("\\r"),
            '\t' => escaped.push_str("\\t"),
            character => escaped.push(character),
        }
    }
    escaped
}

fn collapsed(value: &str) -> String {
    value.split_whitespace().collect::<Vec<_>>().join(" ")
}

/// One chat completion through Brama. `route` is a Brama route, not a
/// provider model name: Brama decides which provider answers it, and the
/// token's own `call:brama#<route>` grants decide whether this caller may
/// ask for it. The exchange runs until Brama answers or the connection
/// fails, and either outcome is what the caller gets. No token budget is
/// sent: how long an answer may be is the route's own setting.
pub fn chat(route: &str, system_prompt: &str, user_prompt: &str) -> Result<String, String> {
    completion(route, system_prompt, user_prompt, None)
}

/// One chat completion through Brama whose answer is bound by the strict
/// JSON schema `schema`, named `name` (`response_format` `json_schema`), and
/// the JSON value it answered. An answer that is not JSON is the refusal,
/// with what Brama sent.
pub fn object(
    route: &str,
    system_prompt: &str,
    user_prompt: &str,
    name: &str,
    schema: &Value,
) -> Result<Value, String> {
    let format = serde_json::json!({
        "type": "json_schema",
        "json_schema": { "name": name, "strict": true, "schema": schema },
    });
    let text = completion(route, system_prompt, user_prompt, Some(format))?;
    serde_json::from_str(&text).map_err(|error| {
        format!("Brama protocol failure: the {name} answer is not the JSON its schema asks for ({error}): {text}")
    })
}

fn completion(
    route: &str,
    system_prompt: &str,
    user_prompt: &str,
    format: Option<Value>,
) -> Result<String, String> {
    let credentials = read()?;
    let waiting = stado_wait::begin(
        stado_wait::Kind::Network,
        format!("judge chat route {route}"),
        &credentials.endpoint,
    );
    let result = chat_with_credentials(route, system_prompt, user_prompt, format, &credentials);
    match &result {
        Ok(_) => waiting.done(),
        Err(error) => waiting.failed(error),
    }
    result
}

fn chat_with_credentials(
    route: &str,
    system_prompt: &str,
    user_prompt: &str,
    format: Option<Value>,
    credentials: &super::credentials::Credentials,
) -> Result<String, String> {
    // Dynamic routes can resolve to models that reject explicit sampling options.
    // Leave temperature absent so Brama preserves the provider's supported default.
    let mut request = serde_json::json!({
        "model": route,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
    });
    if let Some(format) = format {
        request["response_format"] = format;
    }
    let decoded = exchange(route, &credentials.endpoint, &request, credentials)?;
    let content = decoded
        .pointer("/choices/0/message/content")
        .ok_or("Brama protocol failure: response has no /choices/0/message/content")?;
    let text = content.as_str().ok_or_else(|| {
        let kind = match content {
            Value::Null => "null",
            Value::Bool(_) => "boolean",
            Value::Number(_) => "number",
            Value::Array(_) => "array",
            Value::Object(_) => "object",
            Value::String(_) => "string",
        };
        format!("Brama protocol failure: /choices/0/message/content must be text, received {kind}")
    })?;
    let text = text.trim();
    if text.is_empty() {
        return Err(
            "Brama protocol failure: /choices/0/message/content contains no review text".into(),
        );
    }
    Ok(text.to_owned())
}

/// One JSON `request` posted to `url` with this machine's credentials, and
/// the JSON document Brama answered with a 200. `url` shares the scheme and
/// authority of `credentials.endpoint`, the chat endpoint this client was
/// resolved to; only the path differs. Any other status is the refusal,
/// with Brama's whole answer in it.
pub(super) fn exchange(
    route: &str,
    url: &str,
    request: &Value,
    credentials: &super::credentials::Credentials,
) -> Result<Value, String> {
    if !allowed_endpoint(&credentials.endpoint) {
        return Err(format!(
            "this client refuses the resolved Brama endpoint {}: a bearer is never posted in the \
             clear off loopback, and the path must be the chat completions path",
            credentials.endpoint
        ));
    }
    super::channel::check_channel(url)?;
    // A provider declared with `tama model set` is any
    // OpenAI-compatible service and declares no readiness; Brama does, and
    // is asked before the request is sent and again while it waits.
    let brama = super::declared::declared_provider()?.is_none();
    if brama {
        super::channel::declared_ready(url)?;
    }
    let body = serde_json::to_string(request)
        .map_err(|error| format!("cannot serialize Brama request for route {route}: {error}"))?;
    let body = BodyFile::write(&body)?;
    let config = format!(
        "url = \"{}\"\nrequest = \"POST\"\nheader = \"Authorization: Bearer {}\"\nheader = \"Content-Type: application/json\"\nheader = \"Accept: application/json\"\ndata-binary = \"@{}\"\nsilent\nshow-error\nwrite-out = \"\\n%{{http_code}}\\nlookup=%{{time_namelookup}} connect=%{{time_connect}} tls=%{{time_appconnect}} first_byte=%{{time_starttransfer}} total=%{{time_total}}\"\n",
        curl_config_value(url),
        curl_config_value(&credentials.bearer),
        curl_config_value(&body.path().to_string_lossy()),
    );
    let mut child = Command::new(super::channel::CLIENT)
        .args(["--disable", "--config", "-"])
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .map_err(|error| format!("cannot start Brama HTTP client: {error}"))?;
    // The request belongs to this hook process from here until it ends; a
    // client this process leaves behind is ended by the next judge request.
    let held = super::channel::Held::take(route, url, child.id());
    let written = match &held {
        Err(cause) => Err(cause.clone()),
        Ok(_) => child
            .stdin
            .take()
            .ok_or_else(|| "Brama HTTP client has no input pipe".to_string())
            .and_then(|mut input| {
                input
                    .write_all(config.as_bytes())
                    .map_err(|error| format!("cannot write Brama request: {error}"))
            }),
    };
    if let Err(error) = written {
        let termination = child.kill();
        let reaped =
            stado_wait::child_output(child, "Brama HTTP client after request input failure");
        let mut cause = error;
        if let Err(error) = termination {
            cause.push_str(&format!("; cannot terminate Brama HTTP client: {error}"));
        }
        match reaped {
            Ok(output) => cause.push_str(&format!(
                "; Brama HTTP client ended with {}: {}",
                output.status,
                String::from_utf8_lossy(&output.stderr).trim()
            )),
            Err(error) => cause.push_str(&format!(
                "; cannot collect Brama HTTP client termination: {error}"
            )),
        }
        return Err(cause);
    }
    // While the client waits, Brama's readiness is asked again and again;
    // a Brama that stops declaring it serves ends the client, and the
    // request is refused with that cause instead of waiting without end.
    let watch = brama.then(|| super::channel::Watch::over(url, child.id()));
    let output = stado_wait::child_output(child, "Brama HTTP response");
    let ended_by_watch = watch.and_then(super::channel::Watch::finish);
    // The channel is free once the client has ended, whatever it brought.
    drop(held);
    if let Some(cause) = ended_by_watch {
        return Err(cause);
    }
    let output = output.map_err(|error| format!("Brama request did not complete: {error}"))?;
    if !output.status.success() {
        let stderr = String::from_utf8_lossy(&output.stderr);
        // curl names neither the line nor the limit when it cannot read its
        // --config document, so every failure names the document's own
        // lines, by option and length, with the body file curl was to read;
        // which of them curl refused is curl's own sentence beside it.
        return Err(format!(
            "Brama request failed ({}): {}; {}",
            output.status,
            stderr.trim(),
            config_report(&config, &body)
        ));
    }
    let response = String::from_utf8(output.stdout)
        .map_err(|error| format!("Brama returned a non-UTF-8 response: {error}"))?;
    let (response, timing) = response
        .rsplit_once('\n')
        .ok_or_else(|| "Brama response omitted its HTTP timing record".to_string())?;
    eprintln!("Brama HTTP phases for {url} route {route}: {timing}");
    let (body, status) = response
        .rsplit_once('\n')
        .ok_or_else(|| "Brama response omitted its HTTP status".to_string())?;
    if status.trim() != "200" {
        return Err(format!(
            "Brama rejected the request from consumer {} with HTTP {} ({timing}): {}",
            super::credentials::consumer()?,
            status.trim(),
            collapsed(body)
        ));
    }
    serde_json::from_str(body)
        .map_err(|error| format!("Brama returned invalid response JSON: {error}"))
}
