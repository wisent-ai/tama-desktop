//! The operator's answers to the excuses agents give most often for leaving
//! work undone or for writing to him (`excuses.json` beside this module).
//!
//! Every answer is printed at session start and after every compaction,
//! beside the standing rules (`inject-operator-rules`), so it stands in the
//! session's context for every later turn; a completion refusal does not
//! repeat it. No answer is chosen by reading the agent's text, so no word
//! list decides which one applies; an agent reads all of them before it can
//! give any.

use std::sync::LazyLock;

use serde::Deserialize;

#[derive(Deserialize)]
struct Catalogue {
    answers: Vec<Answer>,
}

#[derive(Deserialize)]
struct Answer {
    excuse: String,
    answer: String,
}

static CATALOGUE: LazyLock<Catalogue> = LazyLock::new(|| {
    serde_json::from_str(include_str!("excuses.json"))
        .expect("completion/excuses.json is the operator's declared answers and must parse")
});

/// Every excuse with the operator's answer to it, one line each.
pub fn answers_text() -> String {
    let mut out = String::from(
        "# The operator's answers to the excuses agents give. None of these excuses ends a \
         turn, stands an item aside or reaches the operator.\n",
    );
    for answer in &CATALOGUE.answers {
        out.push_str(&format!("- \"{}\" → {}\n", answer.excuse, answer.answer));
    }
    out
}
