//! Decision half of `tama hook block-local-model-server` (hook id
//! `block-local-model-server`): a shell call that fetches, installs or
//! starts a model server on this machine is refused unless the operator
//! granted that exact command in his own words
//! ([`crate::ports::operator_grant`]).
//!
//! Pushes held for want of a model reviewer sent a session looking for a
//! local model server to stand in for the reviewer. The operator's route is
//! Tama's attestation: `tama hook review-push` reads the attestation each
//! commit carries against the commit standard, with no model, no key and no
//! Brama, and `tama attestation check --commit` reads it the same way.
//!
//! Which calls start a server is declared in `servers.json` as command paths
//! (a program and the command words its CLI spells), read by the reading
//! every command-path gate shares ([`crate::ports::command_path`]): wrappers
//! stepped over, `bash -c` lines read, options set aside. A call whose words
//! cannot be read passes with the cause on stderr: the gate fails open on
//! its own failure, never on a reading it holds.

use std::sync::LazyLock;

use serde::Deserialize;
use serde_json::Value;

use crate::ports::command_path;
use crate::ports::operator_grant::{self, Request};
use crate::ports::tool_vocabulary::Call;

pub const HOOK_ID: &str = "block-local-model-server";
pub const GRANT_KIND: &str = "model-server";
const BANNER: &str = "BLOCKED: local model server: ";

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Server {
    program: String,
    command: String,
    name: String,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Servers {
    #[allow(dead_code)]
    why: String,
    servers: Vec<Server>,
}

/// The declared command paths, each with what it starts; empty, with the
/// cause on stderr, when the gate's own data does not read.
static SERVERS: LazyLock<Vec<(Vec<String>, String)>> = LazyLock::new(
    || match serde_json::from_str::<Servers>(include_str!("servers.json")) {
        Ok(declared) => declared
            .servers
            .into_iter()
            .map(|server| {
                let path = std::iter::once(server.program)
                    .chain(server.command.split_whitespace().map(str::to_string))
                    .collect();
                (path, server.name)
            })
            .collect(),
        Err(error) => {
            eprintln!("{HOOK_ID}: servers.json does not read, so nothing is refused: {error}");
            Vec::new()
        }
    },
);

/// The refusal when the call starts a local model server with no grant,
/// `None` when it passes.
pub fn evaluate(payload: &Value) -> Option<String> {
    let call = Call::of(payload);
    if !call.is_shell() {
        return None;
    }
    let command = call.command()?;
    let mut found = Vec::new();
    for (path, name) in SERVERS.iter() {
        match command_path::reaches(payload, path) {
            Ok(true) => found.push(format!("`{}` ({name})", path.join(" "))),
            Ok(false) => {}
            Err(cause) => eprintln!(
                "{HOOK_ID}: whether this call runs `{}` cannot be read: {cause}",
                path.join(" ")
            ),
        }
    }
    if found.is_empty() {
        return None;
    }
    let request = Request {
        gate: HOOK_ID,
        command: Some(command),
        paths: &[],
    };
    if operator_grant::granted(payload, &request) {
        return None;
    }
    Some(format!(
        "{BANNER}this call runs {}. No local model stands in for a reviewer or a judge: a push \
         held for want of a model reviewer is answered by the commit's Tama attestation, which \
         `tama hook review-push` and `tama attestation check --commit` read with no model at \
         all. Write or repair the attestation instead. {}",
        found.join(", "),
        operator_grant::how_to_grant(GRANT_KIND, HOOK_ID)
    ))
}
