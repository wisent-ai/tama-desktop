//! The Git commands that put an earlier version back, read from their words
//! as git(1) documents them, with no repository opened.
//!
//! A revision is told from a path by its shape alone: a word with `~`, `^`
//! or `@{`, an object name (hexadecimal digits only, a decimal digit among
//! them, so a branch called `feed` stays a branch), one of the pseudo-refs
//! `ORIG_HEAD`, `FETCH_HEAD`, `@`, and for `git reset` every operand before
//! a `--`. A branch name is no revision here, so switching to a branch
//! passes; checking out one of its files does not.

use serde_json::Value;

use crate::ports::block_unauthorized_host_change::words;
use crate::ports::command_path;

/// The pseudo-refs that name an earlier state of `HEAD`.
const PSEUDO_REFS: &[&str] = &["ORIG_HEAD", "FETCH_HEAD", "@"];
/// The modes of `git reset` that put the working tree back.
const RESET_MODES: &[&str] = &["--hard", "--keep", "--merge"];
/// The options that end a revert in progress instead of reverting.
const REVERT_ENDS: &[&str] = &["--abort", "--quit"];
/// The options of `git checkout` and `git switch` that create a branch,
/// which starts new work and puts nothing back.
const CREATES_BRANCH: &[&str] = &[
    "-b",
    "-B",
    "--orphan",
    "-c",
    "-C",
    "--create",
    "--force-create",
];
const SEPARATOR: &str = "--";

/// Every Git rollback the shell line in `payload` makes.
pub(super) fn rollbacks(payload: &Value) -> Result<Vec<String>, String> {
    let mut found = Vec::new();
    for words_after in each(payload, "revert")? {
        if !words_after
            .iter()
            .any(|word| REVERT_ENDS.contains(&word.as_str()))
        {
            found.push("`git revert` undoes committed work".to_string());
        }
    }
    for words_after in each(payload, "reset")? {
        if let Some(cause) = reset(&words_after) {
            found.push(cause);
        }
    }
    for words_after in each(payload, "checkout")? {
        if let Some(cause) = checkout(&words_after) {
            found.push(cause);
        }
    }
    for words_after in each(payload, "restore")? {
        if let Some(cause) = restore(&words_after) {
            found.push(cause);
        }
    }
    for words_after in each(payload, "switch")? {
        if !creates_branch(&words_after) && operands(&words_after).any(revision) {
            found.push("`git switch` onto a revision puts an earlier version back".to_string());
        }
    }
    Ok(found)
}

/// The words after `subcommand` of every `git <subcommand>` the line runs.
fn each(payload: &Value, subcommand: &str) -> Result<Vec<Vec<String>>, String> {
    let reached = command_path::reached(payload, &words(&["git", subcommand]))?;
    Ok(reached
        .into_iter()
        .map(
            |reached| match reached.args.iter().position(|word| word == subcommand) {
                Some(at) => reached.args[at + 1..].to_vec(),
                None => Vec::new(),
            },
        )
        .collect())
}

/// The words that are no option, up to a `--`.
fn operands(words_after: &[String]) -> impl Iterator<Item = &str> {
    words_after
        .iter()
        .map(String::as_str)
        .take_while(|word| *word != SEPARATOR)
        .filter(|word| !word.starts_with('-'))
}

/// Whether `word` has the shape of a revision rather than a path or branch.
fn revision(word: &str) -> bool {
    word.contains('~')
        || word.contains('^')
        || word.contains("@{")
        || PSEUDO_REFS.contains(&word)
        || (word.chars().all(|character| character.is_ascii_hexdigit())
            && word.chars().any(|character| character.is_ascii_digit()))
}

fn creates_branch(words_after: &[String]) -> bool {
    words_after
        .iter()
        .any(|word| CREATES_BRANCH.contains(&word.as_str()))
}

fn separated(words_after: &[String]) -> bool {
    words_after.iter().any(|word| word == SEPARATOR)
}

/// Why a `git reset` with `words_after` is a rollback: a mode that puts the
/// working tree back, or a move of the branch onto a revision.
fn reset(words_after: &[String]) -> Option<String> {
    if let Some(mode) = words_after
        .iter()
        .find(|word| RESET_MODES.contains(&word.as_str()))
    {
        return Some(format!("`git reset {mode}` puts the working tree back"));
    }
    let onto = if separated(words_after) {
        operands(words_after).next()
    } else {
        operands(words_after).find(|word| revision(word))
    };
    onto.filter(|word| *word != "HEAD")
        .map(|word| format!("`git reset {word}` moves the branch back"))
}

/// Why a `git checkout` with `words_after` is a rollback: files put back
/// from the index or a revision, or the tree onto a revision.
fn checkout(words_after: &[String]) -> Option<String> {
    if creates_branch(words_after) {
        return None;
    }
    if separated(words_after) || operands(words_after).any(|word| word == ".") {
        return Some("`git checkout` of paths puts their earlier version back".to_string());
    }
    operands(words_after)
        .find(|word| revision(word))
        .map(|word| format!("`git checkout {word}` puts an earlier version back"))
}

/// Why a `git restore` with `words_after` is a rollback: it writes the
/// working tree, or the index from a `--source`. Only unstaging passes.
fn restore(words_after: &[String]) -> Option<String> {
    let has = |names: &[&str]| {
        words_after
            .iter()
            .map(String::as_str)
            .take_while(|word| *word != SEPARATOR)
            .any(|word| {
                names.iter().any(|name| {
                    word == *name
                        || word
                            .strip_prefix(*name)
                            .is_some_and(|rest| rest.starts_with('='))
                })
            })
    };
    let unstages_only = has(&["--staged", "-S"]) && !has(&["--worktree", "-W", "--source", "-s"]);
    (!unstages_only).then(|| "`git restore` puts files back to an earlier version".to_string())
}
