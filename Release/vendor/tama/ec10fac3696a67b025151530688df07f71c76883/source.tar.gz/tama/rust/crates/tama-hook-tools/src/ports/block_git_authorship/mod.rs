//! Logic for `tama-block-git-authorship`, registry hook id
//! `block-git-authorship`.
//!
//! Git authorship is not evidence in this workshop. Every agent commits
//! through the operator's git identity, so an author line, a blame line, a
//! shortlog or a mailmap can only ever name him — and an agent that reads one
//! concludes the operator decided something an agent did. Asked who required
//! a change, a session that answers with `git log --format="%an %ae"` names
//! the operator, when the only record that could answer is the transcript.
//!
//! So this gate refuses the question rather than the answer: every way git can
//! be asked who wrote something is blocked, and the refusal names Oko, which
//! keeps the transcripts.
//!
//! No character literal appears below on purpose: the numeric-literal guard
//! strips strings with a scanner that reads a lifetime tick as an opening
//! quote.

use std::sync::LazyLock;

use regex::Regex;
use tama_hooks::session_record::{deny_tool_use, read_payload};

use crate::ports::block_unauthorized_ssh_detect::command_text;
use crate::ports::tool_vocabulary::Call;
use crate::ports::transport_common as common;

/// A git invocation: bare, absolute, environment-prefixed, or reached through
/// a pipeline, command list, substitution or backtick.
static GIT_RE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(?i)(?:^|[;&|`($]|&&|\\|\\||\\s)",
        "(?:[A-Za-z_][A-Za-z_0-9]*=[^\\s]*\\s+)*",
        "(?:[^\\s;&|\"']*/)?git(?:\\s|$)",
    ))
});

/// Git's subcommands whose whole purpose is to name a person.
const BLAME: &str = "blame";
const ANNOTATE: &str = "annotate";
const SHORTLOG: &str = "shortlog";
const CHECK_MAILMAP: &str = "check-mailmap";
/// Git's options that select or group commits by who made them.
const AUTHOR_OPTION: &str = "author";
const COMMITTER_OPTION: &str = "committer";
const USE_MAILMAP_OPTION: &str = "use-mailmap";
const MAILMAP_OPTION: &str = "mailmap";
/// Git's identity placeholders in the `log` spelling: author and committer
/// name, email and local part.
const AUTHOR_NAME: &str = "an";
const AUTHOR_EMAIL: &str = "ae";
const AUTHOR_LOCAL: &str = "al";
const COMMITTER_NAME: &str = "cn";
const COMMITTER_EMAIL: &str = "ce";
const COMMITTER_LOCAL: &str = "cl";
/// The identity atoms of the `for-each-ref` spelling, and their suffixes.
const TAGGER_ATOM: &str = "tagger";
const NAME_SUFFIX: &str = "name";
const EMAIL_SUFFIX: &str = "email";
/// The format options, and git's built-in formats that print an `Author:`
/// or `author ` line.
const PRETTY_OPTION: &str = "pretty";
const FORMAT_OPTION: &str = "format";
const MEDIUM_FORMAT: &str = "medium";
const FULL_FORMAT: &str = "full";
const FULLER_FORMAT: &str = "fuller";
const RAW_FORMAT: &str = "raw";
const EMAIL_FORMAT: &str = "email";
const MBOXRD_FORMAT: &str = "mboxrd";
/// Git's history commands whose default format prints the author line.
const LOG: &str = "log";
const SHOW: &str = "show";
const WHATCHANGED: &str = "whatchanged";
/// The options by which a caller chooses an output format.
const ONELINE_OPTION: &str = "oneline";
const NO_PATCH_OPTION: &str = "no-patch";

fn alternation(names: &[&str]) -> String {
    names.join("|")
}

/// Where a git subcommand follows `git` and its own leading options: git's
/// global options that take their value as the next word
/// ([`crate::ports::git_invocation::SPACED_VALUE_OPTIONS`]) are stepped over
/// with that value, so the word after `-C <path>` is not read as the
/// subcommand; reading only dash-words let `git -C repo blame` through.
fn git_subcommand() -> String {
    format!(
        r"(?i)(?:^|[;&|`($]|\s)git\s+(?:(?:{})\s+[^\s]+\s+|-[^\s]+\s+)*",
        alternation(crate::ports::git_invocation::SPACED_VALUE_OPTIONS)
    )
}

/// The subcommands whose whole purpose is to name a person.
static WHO_WROTE_IT_RE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        r"{}(?:{})(?:\s|$)",
        git_subcommand(),
        alternation(&[BLAME, ANNOTATE, SHORTLOG, CHECK_MAILMAP])
    ))
});

/// Selecting or grouping commits by who made them.
static IDENTITY_FILTER_RE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        r"(?i)(?:^|\s)--(?:{})(?:=|\s|$)",
        alternation(&[
            AUTHOR_OPTION,
            COMMITTER_OPTION,
            USE_MAILMAP_OPTION,
            MAILMAP_OPTION
        ])
    ))
});

/// An identity placeholder in a `--format` or `--pretty` string, in both the
/// `log` spelling (`%an`) and the `for-each-ref` spelling (`%(authorname)`).
static IDENTITY_PLACEHOLDER_RE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        r"(?i)%(?:{}|\((?:{})(?:{})?\))",
        alternation(&[
            AUTHOR_NAME,
            AUTHOR_EMAIL,
            AUTHOR_LOCAL,
            COMMITTER_NAME,
            COMMITTER_EMAIL,
            COMMITTER_LOCAL
        ]),
        alternation(&[AUTHOR_OPTION, COMMITTER_OPTION, TAGGER_ATOM]),
        alternation(&[NAME_SUFFIX, EMAIL_SUFFIX]),
    ))
});

/// The built-in formats that print an `Author:` or `author ` line.
static IDENTITY_FORMAT_RE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        r"(?i)--(?:{})=(?:{})(?:\s|$)",
        alternation(&[PRETTY_OPTION, FORMAT_OPTION]),
        alternation(&[
            MEDIUM_FORMAT,
            FULL_FORMAT,
            FULLER_FORMAT,
            RAW_FORMAT,
            EMAIL_FORMAT,
            MBOXRD_FORMAT
        ]),
    ))
});

/// The history commands whose default format prints the author line, so
/// asking for no format at all is still asking who wrote it.
static DEFAULT_HISTORY_RE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        r"{}(?:{})(?:\s|$)",
        git_subcommand(),
        alternation(&[LOG, SHOW, WHATCHANGED])
    ))
});

/// A format the caller chose. When one is present the placeholder and
/// built-in tests above decide; when none is present the default format does.
static CHOSEN_FORMAT_RE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        r"(?i)(?:^|\s)--(?:{})",
        alternation(&[
            ONELINE_OPTION,
            PRETTY_OPTION,
            FORMAT_OPTION,
            NO_PATCH_OPTION
        ])
    ))
});

const BLAME_REASON: &str =
    "git blame, annotate, shortlog or check-mailmap answers only with a name";
const FILTER_REASON: &str = "--author, --committer or a mailmap selects commits by who made them";
const PLACEHOLDER_REASON: &str = "the format asks for an author or committer identity";
const FORMAT_REASON: &str = "that built-in format prints the author line";
const DEFAULT_REASON: &str =
    "git log, show and whatchanged print the author line unless a format says otherwise";

/// Which way this command asks git who wrote something, if it does.
pub fn authorship_request(command: &str) -> Option<&'static str> {
    if !GIT_RE.is_match(command) {
        return None;
    }
    if WHO_WROTE_IT_RE.is_match(command) {
        return Some(BLAME_REASON);
    }
    if IDENTITY_FILTER_RE.is_match(command) {
        return Some(FILTER_REASON);
    }
    if IDENTITY_PLACEHOLDER_RE.is_match(command) {
        return Some(PLACEHOLDER_REASON);
    }
    if IDENTITY_FORMAT_RE.is_match(command) {
        return Some(FORMAT_REASON);
    }
    if DEFAULT_HISTORY_RE.is_match(command) && !CHOSEN_FORMAT_RE.is_match(command) {
        Some(DEFAULT_REASON)
    } else {
        None
    }
}

fn refusal(reason: &str) -> String {
    format!(
        "BLOCKED: SPRAWDZ TRANSKRYPTY DEBILU, GIT CI NIC NIE POWIE\n  reason: {reason}\n\nEvery \
         agent in this workshop commits through the operator's git identity, so an author line, a \
         blame line, a shortlog or a mailmap names him whatever an agent did. Git cannot tell you \
         who decided anything here.\n\nAsk the transcripts instead:\n  oko tasks \
         --session <session-id> --full\n  oko tasks rules --session <session-id>\n  \
         history://<agent-id>\n  the stored turns themselves, under ~/.omp/agent/sessions\n\nThere \
         is no read-only, local, capability or session exception. A formatted history without an \
         identity placeholder still works: git log --oneline, --format=%h, --format=%s, \
         --format=%ad."
    )
}

pub fn run() {
    let data = read_payload();
    let call = Call::of(&data);
    if !call.runs() {
        return;
    }
    let command = command_text(&call);
    if let Some(reason) = authorship_request(&command) {
        deny_tool_use(&refusal(reason));
    }
}
