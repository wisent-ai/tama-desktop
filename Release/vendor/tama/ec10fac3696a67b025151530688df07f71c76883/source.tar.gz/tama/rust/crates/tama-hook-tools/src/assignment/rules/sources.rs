//! The registers Oko's open-work snapshot was settled from beside the task
//! registers (`sources` in the snapshot: the defect register and the
//! blocker register, each with its path and the SHA-256 of its content as
//! Oko read it). A register written since holds work the snapshot does not:
//! the snapshot is refused naming that register. The content's digest is
//! compared, never a time.

use sha2::{Digest, Sha256};

/// Why `snapshot` no longer holds one of its source registers, or `None`
/// while every one still reads as Oko read it. A source that names no path
/// or digest, or a register that cannot be read, is the refusal.
pub(super) fn moved(snapshot: &serde_json::Value) -> Option<String> {
    for source in snapshot["sources"].as_array().into_iter().flatten() {
        let (Some(name), Some(path), Some(held)) = (
            source["name"].as_str(),
            source["path"].as_str(),
            source["sha256"].as_str(),
        ) else {
            return Some(format!(
                "the snapshot names a source register without a name, path or digest: {source}"
            ));
        };
        let current = match std::fs::read(path) {
            Ok(bytes) => format!("{:x}", Sha256::digest(&bytes)),
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => "absent".to_string(),
            Err(error) => {
                return Some(format!(
                    "the {name} {path} cannot be read to compare with the snapshot: {error}"
                ))
            }
        };
        if current != held {
            return Some(format!(
                "the {name} {path} was written after the snapshot was settled from it, so the snapshot does not hold that change"
            ));
        }
    }
    None
}
