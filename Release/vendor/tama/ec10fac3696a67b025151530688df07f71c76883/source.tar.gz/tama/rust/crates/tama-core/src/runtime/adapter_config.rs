//! What a provider adapter config says, and what it actually installs.
//!
//! Expand portable home-directory placeholders before reading an adapter's
//! configuration or comparing its installed coverage with the catalogue.
//! Diagnostics distinguish an undeclared path, a missing file and unreadable
//! JSON so the caller can identify the failed operation.

use std::collections::BTreeMap;
use std::fs;

use serde_json::Value;

use super::js_str;
use crate::registry::Registry;
use crate::{err, Result};

const HOME_ENV: &str = "HOME";
const HOME_VARIABLE: &str = "$HOME";
const HOME_VARIABLE_BRACED: &str = "${HOME}";
const HOME_TILDE: &str = "~";

/// One `{ event, command }` pair extracted from an adapter config.
#[derive(Debug, Clone)]
pub struct AdapterHookEntry {
    pub event: String,
    pub command: String,
}

/// JS `adapterCommandIndex`: event name -> installed command strings.
pub type AdapterCommandIndex = BTreeMap<String, Vec<String>>;

/// Why an adapter config could not be indexed. Each variant is a different
/// state of the world, and the drift report names them apart.
#[derive(Debug, Clone)]
pub enum AdapterConfigProblem {
    /// This registry document declares no path for the runtime. An installed
    /// registry is stamped without its adapter block, so this is the normal
    /// state there and says nothing about coverage.
    Undeclared { runtime: String },
    /// The registry declares a path and nothing is there.
    Missing { runtime: String, path: String },
    /// The file is there and could not be read or parsed.
    Unreadable {
        runtime: String,
        path: String,
        detail: String,
    },
}

impl AdapterConfigProblem {
    /// The sentence a report prints for this state.
    pub fn reason(&self) -> String {
        match self {
            Self::Undeclared { runtime } => format!(
                "this registry declares no {runtime} adapter path, so what that runtime installs \
                 was not compared"
            ),
            Self::Missing { runtime, path } => {
                format!("the {runtime} adapter config declared at {path} is not on this machine")
            }
            Self::Unreadable {
                runtime,
                path,
                detail,
            } => format!("the {runtime} adapter config at {path} could not be read: {detail}"),
        }
    }
}

/// A registry path made usable on this machine: `$HOME`, `${HOME}` and a
/// leading `~` all stand for the home directory. An unset home leaves the
/// text as written, so the reader reports the path it actually tried.
pub fn expand_home_path(value: &str) -> String {
    let Ok(home) = std::env::var(HOME_ENV) else {
        return value.to_string();
    };
    let home = home.trim_end_matches('/');
    if value == HOME_TILDE || value == HOME_VARIABLE || value == HOME_VARIABLE_BRACED {
        return home.to_string();
    }
    for prefix in [HOME_VARIABLE_BRACED, HOME_VARIABLE, HOME_TILDE] {
        if let Some(rest) = value.strip_prefix(&format!("{prefix}/")) {
            return format!("{home}/{rest}");
        }
    }
    value.to_string()
}

/// JS `adapterCommandIndex(registry, runtime)`, with the state named when it
/// cannot be built.
pub fn adapter_command_index_result(
    registry: &Registry,
    runtime: &str,
) -> std::result::Result<AdapterCommandIndex, AdapterConfigProblem> {
    if let Some(adapter) = crate::harnesses::by_id(runtime) {
        let path = expand_home_path(&adapter.config);
        let problem = |detail| AdapterConfigProblem::Unreadable {
            runtime: runtime.to_string(),
            path: path.clone(),
            detail,
        };
        let config = crate::harnesses::installed::read(adapter, std::path::Path::new(&path))
            .map_err(problem)?;
        let native_index = crate::harnesses::installed::index(adapter, &config).map_err(problem)?;
        if !adapter.claude_events {
            return Ok(native_index);
        }
        let mut by_event: AdapterCommandIndex = BTreeMap::new();
        for entry in hook_entries_from_adapter_config(&config) {
            by_event.entry(entry.event).or_default().push(entry.command);
        }
        return Ok(by_event);
    }
    let declared = registry
        .adapters
        .get(runtime)
        .and_then(|adapter| adapter.path.clone())
        .filter(|path| !path.is_empty())
        .ok_or_else(|| AdapterConfigProblem::Undeclared {
            runtime: runtime.to_string(),
        })?;
    let path = expand_home_path(&declared);
    let text = fs::read_to_string(&path).map_err(|error| match error.kind() {
        std::io::ErrorKind::NotFound => AdapterConfigProblem::Missing {
            runtime: runtime.to_string(),
            path: path.clone(),
        },
        _ => AdapterConfigProblem::Unreadable {
            runtime: runtime.to_string(),
            path: path.clone(),
            detail: error.to_string(),
        },
    })?;
    let config: Value =
        serde_json::from_str(&text).map_err(|error| AdapterConfigProblem::Unreadable {
            runtime: runtime.to_string(),
            path: path.clone(),
            detail: error.to_string(),
        })?;
    let mut by_event: AdapterCommandIndex = BTreeMap::new();
    for entry in hook_entries_from_adapter_config(&config) {
        by_event.entry(entry.event).or_default().push(entry.command);
    }
    Ok(by_event)
}

/// The same index for callers that only need an error message.
pub fn adapter_command_index(registry: &Registry, runtime: &str) -> Result<AdapterCommandIndex> {
    adapter_command_index_result(registry, runtime).map_err(|problem| err(problem.reason()))
}

/// One Claude Code hook-config place for a registry event: the key its
/// group sits under and the matcher the group carries.
#[derive(Debug, Clone, Copy)]
pub struct EventTarget {
    pub key: &'static str,
    pub matcher: Option<&'static str>,
}

/// Where Tama installs each registry event in a Claude Code hook config.
/// Every config this module reads back was written from this table (Claude
/// Code, Codex and each harness that takes Claude Code's events), so it is
/// also the only reading of which tools a matcher there stands for.
pub fn event_to_codex(event: &str) -> Option<EventTarget> {
    let (key, matcher) = match event {
        "stop" => ("Stop", None),
        "user_prompt_submit" => ("UserPromptSubmit", None),
        "post_tool_use:bash" => ("PostToolUse", Some("Bash")),
        // Every tool: no matcher, so the provider runs it after each call.
        "post_tool_use:any" => ("PostToolUse", None),
        "session_start:compact" => ("SessionStart", Some("compact")),
        "pre_tool_use:bash" => (PRE_TOOL_USE_KEY, Some("Bash")),
        "pre_tool_use:read" => (PRE_TOOL_USE_KEY, Some("Read")),
        // A provider fires one matcher for both tools, and the dispatcher
        // separates them by payload; a hook declared only for `write` or
        // `multiedit` needs its own group or nothing installs it at all.
        "pre_tool_use:edit" | "pre_tool_use:write" => {
            (PRE_TOOL_USE_KEY, Some("apply_patch|Edit|Write"))
        }
        "pre_tool_use:multiedit" => (PRE_TOOL_USE_KEY, Some("MultiEdit")),
        "pre_tool_use:task" => (PRE_TOOL_USE_KEY, Some("Task|Agent")),
        "pre_tool_use:todo" => (PRE_TOOL_USE_KEY, Some("Todo|todo")),
        "pre_tool_use:goal" => (PRE_TOOL_USE_KEY, Some("Goal|goal")),
        "pre_tool_use:lookup" => (
            PRE_TOOL_USE_KEY,
            Some("Grep|grep|Glob|glob|Search|LSP|lsp|AstGrep|ast_grep"),
        ),
        "pre_tool_use:notebook" => (PRE_TOOL_USE_KEY, Some("NotebookEdit")),
        "pre_tool_use:wait" => (PRE_TOOL_USE_KEY, Some("Monitor|ScheduleWakeup")),
        "pre_tool_use:eval" => (
            PRE_TOOL_USE_KEY,
            Some("Eval|eval|execute_code|mcp__node_repl_js|node_repl/js"),
        ),
        "pre_tool_use:ssh" => (PRE_TOOL_USE_KEY, Some("SSH|ssh")),
        _ => return None,
    };
    Some(EventTarget { key, matcher })
}

const PRE_TOOL_USE_KEY: &str = "PreToolUse";
const MATCHER_SEPARATOR: char = '|';

/// The tools a matcher names, compared without case as the providers do.
fn matcher_tools(matcher: &str) -> impl Iterator<Item = String> + '_ {
    matcher
        .split(MATCHER_SEPARATOR)
        .map(|tool| tool.trim().to_lowercase())
        .filter(|tool| !tool.is_empty())
}

/// The pre-tool registry events a `PreToolUse`-style matcher stands for: each
/// event [`event_to_codex`] installs under that key with a matcher naming one
/// of the same tools.
fn tool_events_from_matcher(matcher: &str) -> Vec<String> {
    let tools: Vec<String> = matcher_tools(matcher).collect();
    super::CLAUDE_EVENTS
        .iter()
        .filter(|event| {
            event_to_codex(event).is_some_and(|target| {
                target.key == PRE_TOOL_USE_KEY
                    && target
                        .matcher
                        .is_some_and(|own| matcher_tools(own).any(|tool| tools.contains(&tool)))
            })
        })
        .map(|event| event.to_string())
        .collect()
}

/// JS `adapterEvents(adapterEvent, matcher)`.
fn adapter_events(adapter_event: &str, matcher: &str) -> Vec<String> {
    let key = adapter_event.to_lowercase();
    match key.as_str() {
        "stop" => vec!["stop".to_string()],
        "userpromptsubmit" | "user_prompt_submit" => vec!["user_prompt_submit".to_string()],
        "sessionstart" | "session_start" => vec!["session_start:compact".to_string()],
        // A PostToolUse block with no matcher, or `*`, runs after every tool.
        "posttooluse" | "post_tool_use" if matches!(matcher.trim(), "" | "*") => {
            vec!["post_tool_use:any".to_string()]
        }
        "posttooluse" | "post_tool_use" => tool_events_from_matcher(matcher)
            .into_iter()
            .filter_map(|event| {
                event
                    .strip_prefix("pre_tool_use:")
                    .map(|tool| format!("post_tool_use:{tool}"))
            })
            .collect(),
        "pretooluse" | "pre_tool_use" => tool_events_from_matcher(matcher),
        _ => Vec::new(),
    }
}

/// JS `hookEntriesFromAdapterConfig(config)`.
fn hook_entries_from_adapter_config(config: &Value) -> Vec<AdapterHookEntry> {
    let mut entries = Vec::new();
    // A block or hook list that is absent holds no entries.
    let hooks_root = config.get("hooks").and_then(Value::as_object);
    if let Some(hooks_root) = hooks_root {
        for (adapter_event, blocks) in hooks_root {
            for block in blocks.as_array().into_iter().flatten() {
                let matcher = js_str(block.get("matcher"));
                for event in adapter_events(adapter_event, &matcher) {
                    for hook in block
                        .get("hooks")
                        .and_then(Value::as_array)
                        .into_iter()
                        .flatten()
                    {
                        // JS: `if (hook.command)` — truthy (non-empty) string.
                        if let Some(command) = hook
                            .get("command")
                            .and_then(Value::as_str)
                            .filter(|c| !c.is_empty())
                        {
                            entries.push(AdapterHookEntry {
                                event: event.clone(),
                                command: command.to_string(),
                            });
                        }
                    }
                }
            }
        }
    }
    entries
}
