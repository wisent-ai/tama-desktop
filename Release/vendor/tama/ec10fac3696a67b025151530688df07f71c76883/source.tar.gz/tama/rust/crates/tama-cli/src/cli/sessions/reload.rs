//! Reload the adapter inside an existing OMP process, with its own receipt.
use super::super::{
    args::{has, option_value},
    output::print_json,
};
use serde_json::{json, Value};
use std::path::{Path, PathBuf};
use tama_core::random::random_uuid;
use tama_hook_tools::util::atomic_write_json;
use tama_hooks::session_control::{session_context, session_control_root, SESSION_CONTROL_SCHEMA};

#[path = "watch.rs"]
mod watch;

pub(super) fn run(argv: &[String]) -> i32 {
    let Some(session) = option_value(argv, "--session").filter(|s| !s.trim().is_empty()) else {
        eprintln!("usage: tama sessions reload --session <ID> [--json]");
        return tama_core::exit::USAGE;
    };
    match reload(&session) {
        Ok(receipt) => {
            if has(argv, "--json") {
                print_json(&receipt);
            } else {
                println!(
                    "OMP session {session}: loaded adapter {}; changed={}",
                    receipt["state"]["runtime"]["adapterDigest"], receipt["changed"]
                );
            }
            tama_core::exit::SUCCESS
        }
        Err(error) => {
            if has(argv, "--json") {
                print_json(&json!({"ok": false, "sessionId": session, "error": error}));
            } else {
                eprintln!("cannot reload OMP session {session}: {error}");
            }
            tama_core::exit::FAILURE
        }
    }
}

fn read_json(path: &Path) -> Result<Value, String> {
    let bytes = std::fs::read(path).map_err(|e| format!("read {}: {e}", path.display()))?;
    serde_json::from_slice(&bytes).map_err(|e| format!("decode {}: {e}", path.display()))
}

fn reload(session: &str) -> Result<Value, String> {
    let context = session_context("omp", Some(&json!({"sessionId": session})))
        .ok_or_else(|| "invalid OMP session identity".to_string())?;
    let root = session_control_root();
    let key = &context.control_key;
    let state = read_json(&root.join(format!("{key}.session.json")))?;
    if state["schema"] != SESSION_CONTROL_SCHEMA
        || state["sessionId"] != session
        || state["agentId"] != "omp"
        || state["controlKey"] != *key
    {
        return Err("session record does not match the requested OMP session".into());
    }
    let pid = state["pid"]
        .as_u64()
        .ok_or_else(|| "the session record names no process id".to_string())?;
    if !super::running(pid)? {
        return Err("session process is not running".into());
    }
    if state["runtime"]["adapterReloadSupported"] != true {
        return Err("the loaded adapter does not support remote reload; use tama_reload_hook_runtime in that existing OMP terminal, then inspect its loaded adapter digest".into());
    }
    let request_id = random_uuid()?;
    let request = root.join(format!("{key}.{request_id}.request.json"));
    let response = root.join(format!("{key}.{request_id}.response.json"));
    let mut watch = watch::DirectoryWatch::new(&root, pid)?;
    let _cleanup = RequestFiles {
        request: request.clone(),
        response: response.clone(),
    };
    atomic_write_json(
        &root,
        &request,
        &json!({
            "schema": SESSION_CONTROL_SCHEMA, "sessionId": session, "controlKey": key,
            "requestId": request_id, "confirmed": true, "operation": "reload-adapter",
        }),
    )
    .map_err(|e| format!("write {}: {e}", request.display()))?;
    loop {
        // A receipt that cannot be examined is the error: read as not yet
        // written, the wait would go on for a receipt already there.
        if tama_core::presence::present(&response).map_err(|error| error.to_string())? {
            let receipt = read_json(&response)?;
            if receipt["schema"] != SESSION_CONTROL_SCHEMA || receipt["requestId"] != request_id {
                return Err("invalid reload receipt identity".into());
            }
            if receipt["ok"] != true {
                return Err(match receipt["error"].as_str() {
                    Some(error) => error.to_string(),
                    None => format!(
                        "reload receipt {} rejected the operation without an error reason",
                        response.display()
                    ),
                });
            }
            let updated = &receipt["state"];
            if updated["schema"] != SESSION_CONTROL_SCHEMA
                || updated["sessionId"] != session
                || updated["controlKey"] != *key
                || updated["agentId"] != "omp"
                || updated["pid"].as_u64() != Some(pid)
                || !updated["runtime"]["adapterDigest"]
                    .as_str()
                    .is_some_and(|s| !s.is_empty())
            {
                return Err(
                    "reload receipt does not identify the same process and its loaded adapter"
                        .into(),
                );
            }
            if !super::running(pid)? {
                return Err(format!(
                    "OMP process {pid} exited after sending its reload receipt"
                ));
            }
            return Ok(receipt);
        }
        if !super::running(pid)? {
            return Err(format!("OMP process {pid} exited without a reload receipt"));
        }
        watch.next()?;
    }
}

struct RequestFiles {
    request: PathBuf,
    response: PathBuf,
}
impl Drop for RequestFiles {
    fn drop(&mut self) {
        for path in [&self.request, &self.response] {
            if let Some(left) = tama_hooks::staging::remove(path) {
                eprintln!("tama sessions reload: {left}");
            }
        }
    }
}
