//! Each session's last turn ending, as its core recorded it
//! (`turn-end.<session id>.json`): when the stop was received, whether and
//! when the core answered it, and what that answer means, so a turn that
//! ended while work was open is traced to a gate that passed, a refusal the
//! harness did not wait for, or a stop the core never answered.

use serde_json::Value;

use super::abandoned::plain;

/// One hook of the decision: its exit code and run time, or that it was
/// skipped.
fn hook_line(result: &Value) -> String {
    match result.get("skipped") {
        Some(_) => format!("  {}: skipped", plain(&result["id"])),
        None => format!(
            "  {}: exit {} after {} ms (started in {} ms)",
            plain(&result["id"]),
            plain(&result["code"]),
            plain(&result["ms"]),
            plain(&result["startMs"]),
        ),
    }
}

/// Print one line per session with the record's `reading`, the hook that
/// refused when one did, and every hook the decision ran.
pub(super) fn print(ends: &Value) {
    for record in ends.as_array().into_iter().flatten() {
        println!(
            "turn end of session {} (core pid {}, received at {} ms, answered at {} ms since the epoch): {}",
            plain(&record["sessionId"]),
            plain(&record["corePid"]),
            plain(&record["startedAtMs"]),
            plain(&record["finishedAtMs"]),
            plain(&record["reading"]),
        );
        if let Some(hook) = record["decision"].get("blockedHookId") {
            println!("  refused by {}", plain(hook));
        }
        for result in record["decision"]["results"]
            .as_array()
            .into_iter()
            .flatten()
        {
            println!("{}", hook_line(result));
        }
    }
}
