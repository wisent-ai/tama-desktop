//! Inventory and classify repository copies; inspection and removal are separate.

use std::collections::{BTreeMap, BTreeSet};
use std::path::Path;

use serde::Serialize;
use tama_violations::repo_discovery::{
    discover_checkouts_at_root_reporting, discover_every_checkout_deep_reporting,
    UnreadableDirectory,
};
use tama_violations::resolve_path;

use super::state;
use super::CommandError;
use crate::gitcmd::canonical;

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub(crate) struct Copy {
    pub path: String,
    pub owner: Option<String>,
    pub origin: Option<String>,
    pub bytes: u64,
    /// Unknown observations serialize as null, never as a clean checkout.
    pub dirty: Option<bool>,
    pub unpublished: Option<bool>,
    pub history_retained_by: Option<String>,
    pub inspection_error: Option<String>,
    pub owns_worktrees: Option<bool>,
    #[serde(default)]
    pub named: bool,
}

/// Two checkouts of one repository that this pass removes neither of: two
/// canonical siblings of the same origin, or two checkouts that start from the
/// same commits under different origins. Deleting is left to the operator.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub(crate) struct Twin {
    pub path: String,
    pub twin: String,
    /// The shared origin, or for [`FIRST_COMMITS`] the shared first commits.
    pub origin: String,
    /// [`SAME_ORIGIN`] or [`FIRST_COMMITS`]: what makes the two one repository.
    pub basis: &'static str,
}

/// Both checkouts name the same origin.
pub(crate) const SAME_ORIGIN: &str = "origin";
/// The origins differ, the history is one: a repository GitHub moved keeps its
/// old address in every checkout cloned before the move. Matching on first
/// commits only reports; a fork starts from the same commits too, so removal
/// ownership stays with the origin and a fork is never deleted as a copy.
pub(crate) const FIRST_COMMITS: &str = "first-commits";

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub(crate) struct ListDocument {
    pub schema_version: u32,
    pub roots: Vec<String>,
    pub copies: Vec<Copy>,
    pub copy_count: usize,
    pub bytes: u64,
    pub linked_worktrees: Vec<String>,
    pub twins: Vec<Twin>,
    /// Paths Git cannot identify as repositories; never silently omitted.
    pub unreadable: Vec<String>,
    pub unreadable_directories: Vec<UnreadableDirectory>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub(crate) struct Refusal {
    pub path: String,
    pub reason: &'static str,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub(crate) struct RemoveDocument {
    pub schema_version: u32,
    pub roots: Vec<String>,
    pub copies: Vec<Copy>,
    pub copy_count: usize,
    pub bytes: u64,
    pub linked_worktrees: Vec<String>,
    pub twins: Vec<Twin>,
    pub unreadable: Vec<String>,
    pub unreadable_directories: Vec<UnreadableDirectory>,
    pub excepted: Vec<String>,
    pub applied: bool,
    pub removed: Vec<String>,
    pub refused: Vec<Refusal>,
}

/// A root and its direct repository children are canonical, never copies.
fn is_canonical(path: &Path, root: &Path) -> bool {
    let real = canonical(path);
    let root = canonical(root);
    real == root || real.parent() == Some(root.as_path())
}

fn owner_of(candidate_origin: &str, canonicals: &[(String, String)]) -> Option<String> {
    let normalized = state::normalize_origin(candidate_origin);
    if let Some((_, path)) = canonicals
        .iter()
        .find(|(origin, _)| state::normalize_origin(origin) == normalized)
    {
        return Some(path.clone());
    }
    let local = state::local_origin_path(candidate_origin)?;
    let real = canonical(Path::new(&local));
    canonicals
        .iter()
        .find(|(_, path)| canonical(Path::new(path)) == real)
        .map(|(_, path)| path.clone())
}

pub(crate) fn list_document(
    roots: &[String],
    only: &[String],
) -> Result<ListDocument, CommandError> {
    if roots.is_empty() {
        return Err(CommandError::MissingRoot);
    }
    // A root the working directory cannot anchor is refused with its cause,
    // never walked as a path under `/` the operator did not name.
    let resolved_roots: Vec<String> = roots
        .iter()
        .map(|root| resolve_path(&[Path::new(root)]))
        .map(|resolved| resolved.map(|path| path.to_string_lossy().into_owned()))
        .collect::<Result<_, _>>()
        .map_err(CommandError::Operational)?;
    let mut copies = Vec::new();
    let mut linked_worktrees = Vec::new();
    let mut twins = Vec::new();
    let mut unreadable = Vec::new();
    let mut unreadable_directories = Vec::new();
    let mut checkouts = BTreeSet::new();
    for root in &resolved_roots {
        let walked = if only.is_empty() {
            discover_every_checkout_deep_reporting(Path::new(root))
        } else {
            discover_checkouts_at_root_reporting(Path::new(root))
        };
        unreadable_directories.extend(walked.unreadable);
        checkouts.extend(walked.checkouts);
    }
    if !only.is_empty() {
        let bounds: BTreeSet<_> = resolved_roots
            .iter()
            .map(|root| canonical(Path::new(root)))
            .collect();
        let selected: BTreeSet<_> = only.iter().map(|path| canonical(Path::new(path))).collect();
        for path in &selected {
            if !bounds.iter().any(|root| path.starts_with(root))
                || bounds.contains(path)
                || path.parent().is_some_and(|parent| bounds.contains(parent))
                || path
                    .ancestors()
                    .skip(1)
                    .any(|parent| selected.contains(parent))
            {
                continue;
            }
            let walked = discover_every_checkout_deep_reporting(path);
            unreadable_directories.extend(walked.unreadable);
            checkouts.extend(walked.checkouts);
        }
    }
    let mut canonicals = Vec::new();
    let mut candidates = Vec::new();
    for checkout in checkouts {
        let path = Path::new(&checkout);
        if crate::gitcmd::verify_repository(path).is_err() {
            unreadable.push(checkout);
            continue;
        }
        if state::is_linked_worktree(path) {
            linked_worktrees.push(checkout);
            continue;
        }
        // A checkout whose worktree records cannot be read is reported with
        // the cause, and the pass that cannot see them removes nothing.
        match state::linked_worktrees(path) {
            Ok(found) => linked_worktrees.extend(found),
            Err(reason) => {
                unreadable_directories.push(UnreadableDirectory {
                    path: checkout,
                    reason,
                });
                continue;
            }
        }
        if resolved_roots
            .iter()
            .any(|root| is_canonical(path, Path::new(root)))
        {
            if let Some(origin) = state::origin(path) {
                canonicals.push((origin, checkout));
            }
        } else {
            candidates.push(checkout);
        }
    }
    // All roots contribute before ownership is resolved.
    for candidate in candidates {
        let origin = state::origin(Path::new(&candidate));
        let owner = origin.as_deref().and_then(|url| owner_of(url, &canonicals));
        copies.push(super::inspection::inspect(
            candidate,
            origin,
            owner,
            &canonicals,
        ));
    }
    let mut by_origin: BTreeMap<String, Vec<String>> = BTreeMap::new();
    for (origin, path) in &canonicals {
        by_origin
            .entry(state::normalize_origin(origin))
            .or_default()
            .push(path.clone());
    }
    for (origin, mut paths) in by_origin {
        if paths.len() < 2 {
            continue;
        }
        paths.sort();
        let first = paths[0].clone();
        for path in paths.into_iter().skip(1) {
            twins.push(Twin {
                path,
                twin: first.clone(),
                origin: origin.clone(),
                basis: SAME_ORIGIN,
            });
        }
    }
    // A copy with an owner is already paired by its origin; every canonical
    // checkout and every ownerless copy is paired here by where its history
    // starts, whenever the origins disagree.
    let unpaired = canonicals
        .iter()
        .map(|(origin, path)| (path.clone(), Some(origin.clone())))
        .chain(
            copies
                .iter()
                .filter(|copy| copy.owner.is_none())
                .map(|copy| (copy.path.clone(), copy.origin.clone())),
        );
    let mut by_history: BTreeMap<String, Vec<(String, Option<String>)>> = BTreeMap::new();
    for (path, origin) in unpaired {
        if let Some(roots) = state::first_commits(Path::new(&path)) {
            by_history
                .entry(roots)
                .or_default()
                .push((path, origin.as_deref().map(state::normalize_origin)));
        }
    }
    for (roots, mut members) in by_history {
        if members.len() < 2 {
            continue;
        }
        members.sort();
        let (first, first_origin) = members[0].clone();
        for (path, origin) in members.into_iter().skip(1) {
            if origin.is_some() && origin == first_origin {
                continue;
            }
            twins.push(Twin {
                path,
                twin: first.clone(),
                origin: roots.clone(),
                basis: FIRST_COMMITS,
            });
        }
    }
    copies.sort_by(|left, right| left.path.cmp(&right.path));
    linked_worktrees.sort();
    linked_worktrees.dedup();
    twins.sort_by(|left, right| left.path.cmp(&right.path));
    unreadable.sort();
    unreadable_directories.sort_by(|left, right| left.path.cmp(&right.path));
    unreadable_directories.dedup();
    Ok(ListDocument {
        schema_version: 1,
        roots: resolved_roots,
        copy_count: copies.len(),
        bytes: copies.iter().map(|copy| copy.bytes).sum(),
        copies,
        linked_worktrees,
        twins,
        unreadable,
        unreadable_directories,
    })
}
