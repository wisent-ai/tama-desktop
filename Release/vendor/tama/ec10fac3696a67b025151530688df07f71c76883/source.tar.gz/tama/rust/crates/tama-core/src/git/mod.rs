//! Tama's one Git runner, for every Tama crate: `tama-core` and each crate
//! above it. A call names the repository it runs in, or runs in the current
//! directory; it may use an index other than the repository's own, read
//! standard input and end with paths passed to Git byte for byte. Every
//! failure says, in one wording, the command with that repository and what
//! Git said, and the wait for Git is announced as every process wait is.

use std::io::Write;
use std::path::Path;
use std::process::{Child, Command, Output, Stdio};

#[cfg(test)]
#[path = "../../../../../tests/history/git_transport.rs"]
mod transport;

/// The variable that keeps Git LFS payloads as pointers when a tree is
/// written out to be judged: a verdict on source never downloads assets.
pub const LFS_POINTERS: &[(&str, &str)] = &[("GIT_LFS_SKIP_SMUDGE", "1")];

/// The variables that turn a path into a pathspec with magic. `git
/// check-ignore` takes path names and refuses every one of them ("pathspec
/// magic not supported by this command"), even one the caller's environment
/// set, so its calls run without them.
/// https://git-scm.com/docs/git#Documentation/git.txt-GITLITERALPATHSPECS
pub const PATHSPEC_MAGIC: &[&str] = &[
    "GIT_LITERAL_PATHSPECS",
    "GIT_GLOB_PATHSPECS",
    "GIT_NOGLOB_PATHSPECS",
    "GIT_ICASE_PATHSPECS",
];

/// One Git call: the repository it runs in, the working tree and the index
/// it uses instead of the repository's own, the variables it is run with
/// and those it is run without, the bytes it reads on standard input and
/// the paths that end its arguments.
#[derive(Clone, Copy, Default)]
pub struct Git<'a> {
    repository: Option<&'a Path>,
    work_tree: Option<&'a Path>,
    index: Option<&'a Path>,
    variables: &'a [(&'a str, &'a str)],
    cleared: &'a [&'a str],
    input: Option<&'a [u8]>,
    paths: &'a [&'a Path],
}

impl<'a> Git<'a> {
    /// A call in `repository`, or in the current directory when none.
    pub fn of(repository: Option<&'a Path>) -> Self {
        Self {
            repository,
            ..Self::default()
        }
    }

    /// The same call reading and writing `index` (`GIT_INDEX_FILE`).
    pub fn index(self, index: &'a Path) -> Self {
        Self {
            index: Some(index),
            ..self
        }
    }

    /// The same call writing files into `work_tree` (`--work-tree`), not the
    /// repository's own working tree.
    pub fn work_tree(self, work_tree: &'a Path) -> Self {
        Self {
            work_tree: Some(work_tree),
            ..self
        }
    }

    /// The same call run with each of `variables` set, such as
    /// `GIT_LFS_SKIP_SMUDGE`, `GIT_LITERAL_PATHSPECS` or the `HOME` whose
    /// global configuration a `git config --global` reads and writes.
    pub fn variables(self, variables: &'a [(&'a str, &'a str)]) -> Self {
        Self { variables, ..self }
    }

    /// The same call run without each of `cleared`, such as the `GIT_DIR`
    /// a Git hook inherits, so `-C` alone names the repository.
    pub fn cleared(self, cleared: &'a [&'a str]) -> Self {
        Self { cleared, ..self }
    }

    /// The same call handed `input` on standard input. The input is written
    /// beside the read of the output, so a long input never waits on an
    /// output pipe nobody empties.
    pub fn input(self, input: &'a [u8]) -> Self {
        Self {
            input: Some(input),
            ..self
        }
    }

    /// The same call with `paths` after its arguments, each passed as the
    /// operating system holds it, so a path that is not UTF-8 reaches Git
    /// whole.
    pub fn paths(self, paths: &'a [&'a Path]) -> Self {
        Self { paths, ..self }
    }

    /// `git` and `args` as a failure names them, with the repository and the
    /// working tree it ran in and the paths that end them.
    fn shown(&self, args: &[&str]) -> String {
        let mut words = args.join(" ");
        for path in self.paths {
            words.push(' ');
            words.push_str(&path.to_string_lossy());
        }
        if let Some(work_tree) = self.work_tree {
            words = format!("--work-tree {} {words}", work_tree.display());
        }
        match self.repository {
            Some(repository) => format!("git -C {} {words}", repository.display()),
            None => format!("git {words}"),
        }
    }

    /// `program` run as Git runs one of its hooks for this call: in the
    /// repository, with this call's index (`GIT_INDEX_FILE`), working tree
    /// (`GIT_WORK_TREE`) and variables. The caller adds its arguments and
    /// waits for it.
    pub fn hook(&self, program: &Path) -> Command {
        let mut command = Command::new(program);
        if let Some(repository) = self.repository {
            command.current_dir(repository);
        }
        if let Some(index) = self.index {
            command.env("GIT_INDEX_FILE", index);
        }
        if let Some(work_tree) = self.work_tree {
            command.env("GIT_WORK_TREE", work_tree);
        }
        command.envs(self.variables.iter().copied());
        command
    }

    /// The Git command of this call, its standard input piped when it reads
    /// any.
    fn command(&self, args: &[&str], piped: bool) -> Command {
        let mut command = Command::new("git");
        if let Some(repository) = self.repository {
            command.arg("-C").arg(repository);
        }
        if let Some(work_tree) = self.work_tree {
            command.arg("--work-tree").arg(work_tree);
        }
        if let Some(index) = self.index {
            command.env("GIT_INDEX_FILE", index);
        }
        command.envs(self.variables.iter().copied());
        let check_ignore = args.first() == Some(&"check-ignore");
        let magic = if check_ignore { PATHSPEC_MAGIC } else { &[] };
        for name in self.cleared.iter().chain(magic) {
            command.env_remove(name);
        }
        command
            .args(args)
            .args(self.paths)
            .stdin(if piped { Stdio::piped() } else { Stdio::null() })
            .stdout(Stdio::piped())
            .stderr(Stdio::piped());
        command
    }

    /// A started Git that reads what its caller writes to its standard input,
    /// for a transaction whose input depends on the process itself (such as
    /// `update-ref --stdin`, whose admission records its pid first), and the
    /// command as a failure names it.
    pub fn spawn(self, args: &[&str]) -> Result<(Child, String), String> {
        let shown = self.shown(args);
        let child = self
            .command(args, true)
            .spawn()
            .map_err(|error| format!("{shown} could not run: {error}"))?;
        Ok((child, shown))
    }

    /// What Git answered, whatever its exit status. A transport failure
    /// retains both the input error and Git's observed result when available.
    pub fn output(self, args: &[&str]) -> Result<Output, String> {
        let shown = self.shown(args);
        let mut child = self
            .command(args, self.input.is_some())
            .spawn()
            .map_err(|error| format!("{shown} could not run: {error}"))?;
        std::thread::scope(|scope| {
            let writer = match (self.input, child.stdin.take()) {
                (Some(input), Some(mut stdin)) => Some(scope.spawn(move || stdin.write_all(input))),
                (Some(_), None) => return Err(format!("{shown} opened no input")),
                (None, _) => None,
            };
            let output = stado_wait::child_output(child, shown.clone());
            let written = writer.map(|writer| match writer.join() {
                Ok(written) => written,
                Err(panic) => std::panic::resume_unwind(panic),
            });
            match (output, written) {
                (Ok(output), Some(Err(error))) => Err(format!(
                    "cannot hand {shown} its input: {error}; {shown} ended with {}: {}",
                    output.status,
                    String::from_utf8_lossy(&output.stderr).trim()
                )),
                (Err(error), Some(Err(written))) => Err(format!(
                    "{shown}: {error}; cannot hand {shown} its input: {written}"
                )),
                (output, _) => output.map_err(|error| format!("{shown}: {error}")),
            }
        })
    }

    /// Git's standard output; a Git that ended unsuccessfully is an error
    /// carrying its exit status and what it said on standard error.
    pub fn bytes(self, args: &[&str]) -> Result<Vec<u8>, String> {
        let output = self.output(args)?;
        if !output.status.success() {
            return Err(format!(
                "{} ended with {}: {}",
                self.shown(args),
                output.status,
                String::from_utf8_lossy(&output.stderr).trim()
            ));
        }
        Ok(output.stdout)
    }

    /// [`Git::bytes`] as text.
    pub fn text(self, args: &[&str]) -> Result<String, String> {
        String::from_utf8(self.bytes(args)?)
            .map_err(|error| format!("{} printed non-text: {error}", self.shown(args)))
    }

    /// Whether Git succeeded, and its standard output trimmed: for a
    /// question Git answers by its exit status, such as `rev-parse --verify`.
    pub fn answered(self, args: &[&str]) -> Result<(bool, String), String> {
        let output = self.output(args)?;
        Ok((
            output.status.success(),
            String::from_utf8_lossy(&output.stdout).trim().to_string(),
        ))
    }
}

/// [`Git::text`] in `repository`, or in the current directory when none.
pub fn text(repository: Option<&Path>, args: &[&str]) -> Result<String, String> {
    Git::of(repository).text(args)
}

/// [`Git::text`] in `repository`.
pub fn at(repository: &Path, args: &[&str]) -> Result<String, String> {
    Git::of(Some(repository)).text(args)
}

/// [`Git::text`] in the current directory.
pub fn here(args: &[&str]) -> Result<String, String> {
    Git::of(None).text(args)
}
