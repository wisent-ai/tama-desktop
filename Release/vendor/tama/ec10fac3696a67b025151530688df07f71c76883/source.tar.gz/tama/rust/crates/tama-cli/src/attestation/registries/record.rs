//! `tama attestation record --kind KIND --subject SUBJECT --statement TEXT`:
//! one verb that records an attestation whichever registry keeps it, through
//! that registry's own writer, so `list` shows it and the gate that reads the
//! registry admits what it attests.
//!
//! An agent records what it attests itself: a file justification, written
//! as `tama justify record --kind file` writes it. What only the operator
//! gives is not written by this verb, each refused by name with the act that
//! records it: a CUA or SSH grant cites his own sentence through `tama
//! justify record --kind cua|ssh --quote`, a test approval is his act from
//! his terminal (`tama tests approve`), and a build consent is his answer in
//! Oko. A session's attestation is judged against its task standard by
//! `record --file PATH --session ID`.

use serde_json::{json, Value};

use super::Kind;
use crate::justify::api;

/// Record that `statement` holds of `subject` in the registry of `kind`;
/// what the registry answered, or the refusal naming the act that records
/// that kind.
pub(crate) fn record(kind: Kind, subject: &str, statement: &str) -> Result<Value, String> {
    match kind {
        Kind::File => {
            let request = serde_json::from_value(json!({
                "kind": "file",
                "file": subject,
                "justification": statement,
            }))
            .map_err(|error| format!("the file justification of {subject} cannot be formed: {error}"))?;
            api::record(request)
        }
        Kind::Session => Err(format!(
            "session {subject} attests its task by the record judged against its standard: `tama attestation record --file PATH --session {subject}`"
        )),
        Kind::Cua | Kind::Ssh => Err(format!(
            "a {} grant for {subject} is the operator's consent and cites his own sentence: `tama justify record --kind {} --quote <his sentence> ...` records it",
            kind.name(),
            kind.name()
        )),
        Kind::Test => Err(format!(
            "the approval of {subject} is the operator's own act; he gives it from his terminal with `tama tests approve {subject}`"
        )),
        Kind::Build => Err(format!(
            "build consent {subject} is the operator's answer in Oko; an agent records none"
        )),
    }
}
