//! `tama justify <record|list|show|remove> --kind ssh`: the flags, their
//! refusals, and the exit each one carries.
use serde_json::Value;

use super::super::{lines, misused, option, refuse, report, Request};
use super::{list_document, record_request, recorded_quote, remove_document, RecordRequest};

/// Why `execute` stopped: the invocation itself was wrong (exit 2), or a
/// well-formed request was refused by the registry or the gate (exit 1).
enum Refused {
    Usage(String),
    Failed(String),
}

impl From<String> for Refused {
    fn from(message: String) -> Self {
        Refused::Failed(message)
    }
}

impl From<&str> for Refused {
    fn from(message: &str) -> Self {
        Refused::Failed(message.to_string())
    }
}

/// Every value of a repeatable flag, in the order given: each word that
/// follows the flag and is not itself a flag.
fn repeated(argv: &[String], name: &str) -> Vec<String> {
    let mut values = Vec::new();
    let mut value_follows = false;
    for item in argv {
        if value_follows {
            if !item.starts_with("--") {
                values.push(item.clone());
            }
            value_follows = false;
        } else if item == name {
            value_follows = true;
        }
    }
    values
}

pub(in crate::justify) fn main(action: &str, argv: &[String], request: &Request) -> i32 {
    match execute(action, argv, request) {
        Ok(document) => report(request, &lines(&document), document),
        Err(Refused::Usage(message)) => misused(&message),
        Err(Refused::Failed(message)) => refuse(&message),
    }
}

fn execute(action: &str, argv: &[String], request: &Request) -> Result<Value, Refused> {
    for argument in argv.iter().filter(|arg| arg.starts_with("--")) {
        if ![
            "--kind",
            "--home",
            "--json",
            "--quote",
            "--quote-match",
            "--session",
            "--target",
            "--operation",
            "--path",
            "--command",
        ]
        .contains(&argument.as_str())
        {
            return Err(Refused::Usage(format!("unknown SSH option: {argument}")));
        }
    }
    let required = |flag| {
        option(argv, flag)
            .filter(|value| !value.starts_with("--"))
            .ok_or_else(|| Refused::Usage(format!("{flag} is required")))
    };
    // `show` and `remove` name a recorded grant by its whole quote or by a
    // fragment only that quote holds.
    let recorded = || match (option(argv, "--quote"), option(argv, "--quote-match")) {
        (Some(quote), None) if !quote.starts_with("--") => Ok(quote),
        (None, Some(needle)) if !needle.starts_with("--") => {
            recorded_quote(&request.home, &needle).map_err(Refused::Failed)
        }
        _ => Err(Refused::Usage(
            "give exactly one of --quote or --quote-match".into(),
        )),
    };
    match action {
        "record" => Ok(record_request(
            RecordRequest {
                session_id: required("--session")?,
                targets: repeated(argv, "--target"),
                operation: required("--operation")?,
                paths: repeated(argv, "--path"),
                commands: repeated(argv, "--command"),
                quote: option(argv, "--quote"),
                quote_match: option(argv, "--quote-match"),
            },
            &request.home,
        )?),
        "list" => Ok(list_document(&request.home)?),
        "show" => {
            let quote = recorded()?;
            let mut document = list_document(&request.home)?;
            let entries = document["authorizations"]
                .as_array_mut()
                .ok_or("authorizations is not an array")?;
            entries.retain(|entry| {
                entry.get("userRequestQuote").and_then(Value::as_str) == Some(&quote)
            });
            if entries.is_empty() {
                return Err("no SSH grant is recorded for that quote".into());
            }
            Ok(document)
        }
        "remove" => Ok(remove_document(&request.home, &recorded()?)?),
        other => Err(Refused::Usage(format!("unknown action {other}"))),
    }
}
