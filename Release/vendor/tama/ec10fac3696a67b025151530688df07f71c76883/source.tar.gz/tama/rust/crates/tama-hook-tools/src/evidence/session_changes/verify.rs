//! Read the index against the same recorded deltas that staging applies.
mod written;

use super::{changes, committed::Committed, git, receipts, transition};
use std::ffi::OsStr;
use std::os::unix::ffi::OsStrExt;
use std::path::{Path, PathBuf};

/// Whether any staged path holds exactly what this session's recorded edits
/// make of it; one they do not replay onto is read as `staged_against` says. A
/// session without receipts ([`NO_RECEIPTS`]) carries nothing: the answer here.
pub fn index_carries(directory: &Path, transcript: &Path) -> Result<bool, String> {
    match staged_against(directory, transcript) {
        Ok(read) => Ok(read.iter().any(Option::is_none)),
        Err(cause) if cause.contains(NO_RECEIPTS) => Ok(false),
        Err(cause) => Err(cause),
    }
}

/// What the receipt reader says of a session that recorded no completed edit
/// in the repository it reads.
const NO_RECEIPTS: &str = "has no completed before/after edit receipts in";

/// Each staged path read against the session's recorded edits: `None` when
/// the indexed bytes are what those edits make of the file, the finding
/// otherwise; one they do not replay onto ends the read with its cause,
/// unless [`written::admits`] it.
fn staged_against(directory: &Path, transcript: &Path) -> Result<Vec<Option<String>>, String> {
    let transaction = git::Transaction::begin(directory, false)?;
    let staged =
        transaction
            .git()
            .text(&["diff", "--cached", "--no-renames", "--name-only", "-z"])?;
    if staged.is_empty() {
        return Ok(Vec::new());
    }
    // The co-authors a published staging of this session named are read
    // into the same run of edits staging read (`authors`); staging names the
    // session by the id its process keeps, which a moved transcript records
    // as its providerPromptCacheKey.
    let session = receipts::kept_session_of(transcript)?;
    let (with, task) = super::authors::recorded(&transaction.shared, &session)?;
    let own = receipts::read(&transaction.root, transcript, None)?;
    let edits = super::authors::merged(&transaction.root, &session, &with, task.as_deref(), own)?;
    let cut: Vec<PathBuf> = edits
        .iter()
        .filter(|edit| edit.refused.is_some())
        .map(|edit| edit.path.clone())
        .collect();
    let taken = Committed::new(&transaction, receipts::session_started(transcript)?);
    // A whole-file write is read against what the commit's HEAD held, and a
    // state of the session's an earlier commit took starts its change again.
    let (changes, _) = changes(
        edits,
        &transaction.area,
        |path| Ok(transaction.head(path)?.map(|(_, text)| text)),
        |path, text| taken.took(path, text),
    )?;
    let mut read = Vec::new();
    let mut admitted = Vec::new();
    for path in staged.split('\0').filter(|path| !path.is_empty()) {
        let relative = PathBuf::from(path);
        let owned = changes.get(&relative);
        let indexed = transaction.entry(&relative)?;
        let head = transaction.head(&relative)?;
        // A staged mode stands when it is the working file's: `git add` or
        // `git update-index --chmod` staged it from there. One that is
        // neither HEAD's nor the working file's was written into the index
        // by hand. A change of mode alone carries nobody's text edit, so it
        // is the checkout's own state, read as no session's work.
        if let (Some((mode, text)), Some((head_mode, head_text))) = (&indexed, &head) {
            if mode != head_mode {
                match transaction.working_mode(&relative, mode)? {
                    Some(working) if working == *mode => {}
                    Some(working) => {
                        read.push(Some(format!(
                            "staged mode {mode} of {path} is neither HEAD's ({head_mode}) nor its working file's ({working}), so it was written into the index by hand; stage the mode the file holds with git update-index --chmod"
                        )));
                        continue;
                    }
                    None => {
                        read.push(Some(format!(
                            "staged mode {mode} of {path} differs from HEAD's ({head_mode}) and the working file it was staged from no longer stands; restore the file or unstage {path}"
                        )));
                        continue;
                    }
                }
                if text == head_text {
                    continue;
                }
            }
        }
        let Some(owned) = owned else {
            let indexed_text = indexed.as_ref().map(|(_, text)| text.as_str());
            let left = receipts::commanded::left_by_command(
                &transaction.root,
                transcript,
                &relative,
                indexed_text,
            )?;
            read.push((!left).then(|| {
                format!(
                    "staged path {path} holds no recorded edit or command output of this session"
                )
            }));
            continue;
        };
        let head_text = head.as_ref().map(|(_, text)| text.as_str());
        let indexed_text = indexed.as_ref().map(|(_, text)| text.as_str());
        // The staged bytes are the session's when its whole change, or a
        // newer run of its edits that `tama stage` staged once an older one
        // was undone (`staging::later_runs`), applied to HEAD gives them. A
        // whole change that does not replay is the primary cause, not the
        // end of the reading: the later runs are still read, as `tama stage`
        // reads them. Any run that does not replay accounts for nothing; the
        // causes are named when no run accounts for the bytes.
        let mut accounted = false;
        let mut unreplayed = Vec::new();
        if owned.conflict.is_none() {
            match transition(
                &transaction.area,
                head_text,
                owned.base.as_deref(),
                owned.owned.as_deref(),
                &relative,
            ) {
                Ok(expected) => accounted = expected.as_deref() == indexed_text,
                Err(cause) => unreplayed.push(format!("its whole change: {cause}")),
            }
        }
        let mut runs = super::staging::later_runs(&transaction.area, &relative, owned);
        while !accounted {
            let Some((from, run)) = runs.next() else {
                break;
            };
            let expected = run.and_then(|(base, changed)| {
                transition(
                    &transaction.area,
                    head_text,
                    base.as_deref(),
                    changed.as_deref(),
                    &relative,
                )
            });
            match expected {
                Ok(expected) => accounted = expected.as_deref() == indexed_text,
                Err(cause) => unreplayed.push(format!("from edit {from}: {cause}")),
            }
        }
        if accounted
            || built_on_handover(&transaction, transcript, path, owned)?
                && owned.owned.as_deref() == indexed_text
        {
            read.push(None);
        } else if let Some(cause) = &owned.conflict {
            let refused = cut.contains(&relative);
            if !written::admits(owned, refused, head_text, indexed_text) {
                return Err(cause.clone());
            }
            admitted.push(format!("{path}: the edits of session {session} there do not replay ({cause}); HEAD holds their newest state and the index nothing they wrote, so it carries nothing of that session"));
            read.push(Some(cause.clone()));
        } else {
            let unreplayed = if unreplayed.is_empty() {
                String::new()
            } else {
                format!(
                    " (runs of its edits that do not replay: {})",
                    unreplayed.join("; ")
                )
            };
            read.push(Some(format!(
                "staged bytes of {path} differ from this session's recorded edits{unreplayed}"
            )));
        }
    }
    admitted.iter().for_each(|note| eprintln!("{note}"));
    Ok(read)
}

/// Whether the session's change of `path` starts from a content handed to it
/// (`tama session handover`): its first edit after the handover saw the file
/// as handed, so its recorded base is exactly the handed content, and the
/// change counts as this session's work when the review names who commits.
/// The handover names no author of the handed bytes and makes no co-author.
fn built_on_handover(
    transaction: &git::Transaction,
    transcript: &Path,
    path: &str,
    owned: &super::Change,
) -> Result<bool, String> {
    let Some(base) = owned.base.as_deref() else {
        return Ok(false);
    };
    let session = receipts::session_of(transcript)?;
    let common =
        transaction
            .git()
            .text(&["rev-parse", "--path-format=absolute", "--git-common-dir"])?;
    let handed = crate::evidence::edit_lease::handed_to(Path::new(common.trim()), path, &session)?;
    Ok(handed.contains(&crate::evidence::edit_lease::digest(base.as_bytes())))
}

/// The `edits` a commit of the repository at `root` can carry: a path the
/// repository ignores and does not track is part of no commit, so a session's
/// notes and scratch files there are neither staged nor refuse staging.
/// check-ignore takes path names, not pathspecs; the Git runner runs it
/// without pathspec magic. It reads the paths NUL-separated on standard
/// input, the one form in which Git accepts `-z`, so a path holding any byte
/// is read whole; it fails printing nothing when no path is ignored and
/// printing why when it cannot read them, and only that refuses.
pub(super) fn committable(
    root: &Path,
    mut edits: Vec<receipts::Edit>,
) -> Result<Vec<receipts::Edit>, String> {
    if edits.is_empty() {
        return Ok(edits);
    }
    let mut paths = Vec::new();
    for edit in &edits {
        paths.extend_from_slice(edit.path.as_os_str().as_bytes());
        paths.push(b'\0');
    }
    let check = tama_core::git::Git::of(Some(root)).input(&paths);
    let arguments = ["check-ignore", "--stdin", "-z"];
    let output = check.output(&arguments)?;
    if !output.status.success() && !output.stderr.is_empty() {
        return Err(format!(
            "git -C {} {} failed ({}): {}",
            root.display(),
            arguments.join(" "),
            output.status,
            String::from_utf8_lossy(&output.stderr)
        ));
    }
    let ignored: Vec<&Path> = output
        .stdout
        .split(|byte| *byte == b'\0')
        .filter(|path| !path.is_empty())
        .map(|path| Path::new(OsStr::from_bytes(path)))
        .collect();
    edits.retain(|edit| !ignored.contains(&edit.path.as_path()));
    Ok(edits)
}
