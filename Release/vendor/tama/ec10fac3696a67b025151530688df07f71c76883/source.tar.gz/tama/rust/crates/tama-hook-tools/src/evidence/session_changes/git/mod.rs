//! Git owns the index format and lock protocol; staging never writes the tree.
//! Every Git call here goes through Tama's one runner
//! ([`tama_core::git`]), so a failure names the command, its repository
//! and what Git said in one wording.
mod index;
pub(super) use index::born;

use sha2::{Digest, Sha256};
use std::fs::{self, File, OpenOptions};
use std::path::{Path, PathBuf};

use tama_core::git::Git;

/// Git reads this Boolean variable as `true`, so a path is a path and never
/// a pathspec:
/// https://git-scm.com/docs/git#Documentation/git.txt-GITLITERALPATHSPECS
pub(super) const LITERAL_PATHSPECS: &[(&str, &str)] = &[("GIT_LITERAL_PATHSPECS", "true")];
/// The object type `git ls-tree` names a file's content with.
const BLOB: &str = "blob";
/// The radix Git prints an entry's mode in.
const OCTAL: u32 = 8; // https://git-scm.com/docs/git-fast-import ("<mode> is the type of file entry, specified in octal.")

/// A Git call in `root` reading paths literally.
pub(super) fn git(root: &Path) -> Git<'_> {
    Git::of(Some(root)).variables(LITERAL_PATHSPECS)
}

/// Whether the octal entry `mode` is a regular file, executable or not: the
/// only file content staging replaces (a link or submodule is not text).
fn regular(mode: &str) -> bool {
    u32::from_str_radix(mode, OCTAL)
        .is_ok_and(|mode| mode & u32::from(libc::S_IFMT) == u32::from(libc::S_IFREG))
}

/// Git's index lock, held only by a transaction that will publish.
struct Lock {
    path: PathBuf,
    file: File,
}

pub(super) struct Transaction {
    pub root: PathBuf,
    pub area: PathBuf,
    /// The staging area every staging and read of this index shares, where
    /// what a published staging keeps about the index is found.
    pub shared: PathBuf,
    pub index: PathBuf,
    original: PathBuf,
    lock: Option<Lock>,
    published: bool,
}

impl Transaction {
    /// A private copy of the index to stage into. Only a transaction that
    /// `publishes` takes Git's index lock: a read (`--inspect`, the commit
    /// check) leaves none behind however it ends, a closed pipe included.
    pub fn begin(directory: &Path, publishes: bool) -> Result<Self, String> {
        let root = PathBuf::from(
            git(directory)
                .text(&["rev-parse", "--show-toplevel"])?
                .trim(),
        );
        let root = root
            .canonicalize()
            .map_err(|cause| format!("cannot resolve {}: {cause}", root.display()))?;
        let original = PathBuf::from(
            git(&root)
                .text(&["rev-parse", "--path-format=absolute", "--git-path", "index"])?
                .trim(),
        );
        let identity = format!(
            "{:x}",
            Sha256::digest(original.as_os_str().as_encoded_bytes())
        );
        let area = root.join(".build/tama-stage").join(identity);
        // check-ignore takes path names, not pathspecs; the Git runner runs it
        // without pathspec magic (`tama_core::git::PATHSPEC_MAGIC`).
        Git::of(Some(&root))
            .paths(&[area.as_path()])
            .bytes(&["check-ignore", "--quiet", "--no-index", "--"])
            .map_err(|cause| {
                format!(
                    "staging scratch {} must be ignored: {cause}",
                    area.display()
                )
            })?;
        // A read holds no lock, so it never shares the publishing scratch.
        let shared = area.clone();
        let area = if publishes {
            area
        } else {
            area.join(format!("read-{}", std::process::id()))
        };
        let lock = if publishes {
            let mut name = original.as_os_str().to_os_string();
            name.push(".lock");
            let path = PathBuf::from(name);
            let file = OpenOptions::new().write(true).create_new(true).open(&path)
                .map_err(|cause| format!("cannot acquire Git index lock {}: {cause}; no index or working-tree changes made", path.display()))?;
            Some(Lock { path, file })
        } else {
            None
        };
        let mut transaction = Self {
            root,
            index: area.join("index"),
            area,
            shared,
            original,
            lock,
            published: false,
        };
        transaction.prepare()?;
        Ok(transaction)
    }

    /// The index file this staging reads and publishes to: Git's own, or the
    /// one `GIT_INDEX_FILE` names.
    pub fn original(&self) -> &Path {
        &self.original
    }

    /// Replace every entry of this staging's index with HEAD's, so an index
    /// read on an older HEAD carries nothing but what is staged into it
    /// next: its stale entries would otherwise take back every commit that
    /// landed since it was read.
    pub fn reset_to_head(&self) -> Result<(), String> {
        self.git()
            .text(&["read-tree", "HEAD"])
            .map(|_| ())
            .map_err(|cause| format!("cannot read HEAD into the staging index: {cause}"))
    }

    /// A Git call in the checkout reading and writing this staging's index.
    pub fn git(&self) -> Git<'_> {
        git(&self.root).index(&self.index)
    }

    /// The indexed mode and content of `path`, none when it is not tracked.
    /// A path Git lists unmerged is refused: its sides are not text a
    /// staging can replace.
    pub fn entry(&self, path: &Path) -> Result<Option<(String, String)>, String> {
        if !self
            .git()
            .paths(&[path])
            .text(&["ls-files", "--unmerged", "-z", "--"])?
            .is_empty()
        {
            return Err(format!(
                "{} is an unresolved merge; resolve it before staging",
                path.display()
            ));
        }
        let entries = self
            .git()
            .paths(&[path])
            .text(&["ls-files", "--stage", "-z", "--"])?;
        let rows: Vec<_> = entries.split('\0').filter(|row| !row.is_empty()).collect();
        if rows.is_empty() {
            return Ok(None);
        }
        let [row] = rows.as_slice() else {
            return Err(format!("{} has no single tracked index entry; untracked files and unresolved merges need complete creation or resolution receipts", path.display()));
        };
        let (metadata, _) = row
            .split_once('\t')
            .ok_or("Git index entry has no path separator")?;
        let parts: Vec<_> = metadata.split_whitespace().collect();
        let [mode, object, _stage] = parts.as_slice() else {
            return Err("Git index entry has invalid metadata".into());
        };
        if !regular(mode) {
            return Err(format!(
                "{} is not a regular text file (mode {mode})",
                path.display()
            ));
        }
        let contents = self.git().text(&["cat-file", BLOB, object])?;
        Ok(Some(((*mode).to_owned(), contents)))
    }

    pub fn head(&self, path: &Path) -> Result<Option<(String, String)>, String> {
        let listing = self
            .git()
            .paths(&[path])
            .text(&["ls-tree", "-z", "HEAD", "--"])?;
        if listing.is_empty() {
            return Ok(None);
        }
        let (metadata, _) = listing
            .split_once('\t')
            .ok_or("Git tree entry has no path separator")?;
        let fields: Vec<_> = metadata.split_whitespace().collect();
        let [mode, kind, object] = fields.as_slice() else {
            return Err("Git tree entry has invalid metadata".into());
        };
        if *kind != BLOB || !regular(mode) {
            return Err(format!("{} is not a regular HEAD file", path.display()));
        }
        Ok(Some((
            (*mode).to_owned(),
            self.git().text(&["cat-file", BLOB, object])?,
        )))
    }

    /// The mode the working file of `path` holds, as Git reads it against
    /// the entry indexed with `indexed`: that mode when the file matches its
    /// entry, the working side of `git diff --raw` when it does not, and
    /// `None` when no working file stands there.
    pub fn working_mode(&self, path: &Path, indexed: &str) -> Result<Option<String>, String> {
        let raw = self
            .git()
            .paths(&[path])
            .text(&["diff", "--raw", "-z", "--"])?;
        let Some(entry) = raw.split('\0').find(|field| field.starts_with(':')) else {
            return Ok(Some(indexed.to_owned()));
        };
        // `:<index mode> <working mode> <index object> <working object> <status>`
        let fields: Vec<_> = entry.split_whitespace().collect();
        let [_, working, _, _, status] = fields.as_slice() else {
            return Err(format!(
                "git diff --raw printed an unreadable entry for {}: {entry}",
                path.display()
            ));
        };
        Ok((!status.starts_with('D')).then(|| (*working).to_owned()))
    }

    pub fn create(&self, path: &Path, bytes: &str) -> Result<(), String> {
        self.git()
            .paths(&[path])
            .bytes(&["add", "--intent-to-add", "--"])?;
        let (mode, _) = self
            .entry(path)?
            .ok_or_else(|| format!("Git did not prepare a new entry for {}", path.display()))?;
        self.replace(path, &mode, bytes)
    }

    pub fn remove(&self, path: &Path) -> Result<(), String> {
        self.git()
            .paths(&[path])
            .bytes(&["update-index", "--force-remove", "--"])?;
        Ok(())
    }

    pub fn replace(&self, path: &Path, mode: &str, bytes: &str) -> Result<(), String> {
        let file = self.area.join("candidate");
        fs::write(&file, bytes)
            .map_err(|cause| format!("cannot write {}: {cause}", file.display()))?;
        let object = self
            .git()
            .paths(&[file.as_path()])
            .text(&["hash-object", "-w", "--"])?;
        // The entry names only an object this repository's store holds: an
        // index naming one it does not makes every status and commit fail.
        self.git()
            .bytes(&["cat-file", "-e", object.trim()])
            .map_err(|cause| {
                format!(
                    "the object {} for {} is not in this repository's store: {cause}",
                    object.trim(),
                    path.display()
                )
            })?;
        let path = path.to_str().ok_or("index path is not UTF-8")?;
        self.git().bytes(&[
            "update-index",
            "--cacheinfo",
            &format!("{mode},{},{path}", object.trim()),
        ])?;
        Ok(())
    }
}

impl Drop for Transaction {
    fn drop(&mut self) {
        if self.lock.is_none() {
            if let Err(cause) = fs::remove_dir_all(&self.area) {
                eprintln!(
                    "staging read scratch {} remains: {cause}",
                    self.area.display()
                );
            }
        }
        let Some(lock) = self.lock.as_ref().filter(|_| !self.published) else {
            return;
        };
        if let Err(cause) = fs::remove_file(&lock.path) {
            eprintln!(
                "staging index lock {} remains: {cause}",
                lock.path.display()
            );
        }
    }
}
