//! A table a data document carries: one list of labels beside a list of rows,
//! every row exactly as long as the labels. The labels name the rows'
//! columns and each row is a record with one cell per column, so neither is
//! a set of alternatives a program compares input against: a classifier is
//! one flat list of words, not a header with records under it. A
//! documentation page's table (`"columns": ["Command", "Setting", "Default"]`
//! beside its `"rows"`) is recognised by that shape, whatever its keys are
//! called; no key name is read.

use serde_json::{Map, Value};

/// The keys of `fields` whose arrays form a table: a header holding only
/// strings, and a sibling non-empty array whose every item is a row holding
/// as many items as the header.
pub(super) fn table_keys(fields: &Map<String, Value>) -> Vec<&str> {
    let mut keys = Vec::new();
    for (header_key, header) in fields {
        let Some(labels) = header.as_array() else {
            continue;
        };
        if !labels.iter().all(Value::is_string) {
            continue;
        }
        for (rows_key, rows) in fields {
            if rows_of(rows, labels.len()) {
                keys.push(header_key.as_str());
                keys.push(rows_key.as_str());
            }
        }
    }
    keys
}

/// Whether `rows` is a non-empty array of arrays, each `width` items long.
fn rows_of(rows: &Value, width: usize) -> bool {
    rows.as_array().is_some_and(|rows| {
        !rows.is_empty()
            && rows
                .iter()
                .all(|row| row.as_array().is_some_and(|cells| cells.len() == width))
    })
}

/// The cells of a table field: each row's items, which are read for what
/// they hold beyond text (a nested list or object is still judged), while
/// the header and the rows themselves are not judged as word lists.
pub(super) fn cells(field: &Value) -> impl Iterator<Item = &Value> {
    field
        .as_array()
        .into_iter()
        .flatten()
        .filter_map(Value::as_array)
        .flatten()
}
