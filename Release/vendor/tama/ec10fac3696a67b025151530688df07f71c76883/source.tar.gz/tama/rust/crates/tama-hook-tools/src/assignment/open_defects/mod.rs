//! The open defects of every product, and the work other sessions declared.
//!
//! The Stop guard counts every defect that has not recorded the revision
//! that fixed it. Counting only a session's declared products, and letting
//! an entry in Oko's blocker register stand a defect aside, let an agent
//! write blockers on everything and then stop with nothing repaired. Whether
//! a build may run is not read here: it is Oko's admission (`oko admit`).

use std::path::{Path, PathBuf};
use std::process::Command;

use serde_json::Value;

use super::rules::oko_cli;
use crate::ports::block_off_task_work::TaskScope;

pub mod build_hold;
mod register;
mod snapshot;

/// Where a session's declaration lives, under the home directory.
const SCOPE_HOME_RELATIVE: &str = ".tama/task-scope";
/// How many hex digits Oko prints for a defect in its short form: a UUID's
/// time_low field, https://www.rfc-editor.org/rfc/rfc9562#section-4
const SHORT_ID_DIGITS: usize = 8;

/// One open defect this turn would leave behind.
pub struct OpenDefect {
    pub id: String,
    pub product: String,
    pub title: String,
    /// Oko's repair plan, empty when none was written.
    pub repair: String,
    /// The pushed revision `oko defects repaired` recorded, before a build
    /// proves it; the stop gate counts a defect carrying one as repaired.
    pub repaired_in: Option<String>,
    /// The session Oko records as working on it, when one is recorded.
    pub owner: Option<String>,
}

/// The repositories the session declared: none when it declared no scope
/// (no file). A file that cannot be read, is not JSON, or carries
/// `repositories` that is not a list is refused with its path and cause: an
/// unreadable declaration is not an empty one.
fn declared_repositories(home: &Path, session: &str) -> Result<Vec<String>, String> {
    let path: PathBuf = home
        .join(SCOPE_HOME_RELATIVE)
        .join(format!("{session}.json"));
    let text = match std::fs::read_to_string(&path) {
        Ok(text) => text,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(Vec::new()),
        Err(error) => {
            return Err(format!(
                "cannot read task scope {}: {error}",
                path.display()
            ))
        }
    };
    let scope = serde_json::from_str::<Value>(&text)
        .map_err(|error| format!("task scope {} is not JSON: {error}", path.display()))?;
    match scope.get("repositories") {
        None => Ok(Vec::new()),
        Some(Value::Array(items)) => Ok(items
            .iter()
            .filter_map(Value::as_str)
            .map(str::to_string)
            .collect()),
        Some(other) => Err(format!(
            "task scope {} names repositories that are not a list: {other}",
            path.display()
        )),
    }
}

/// One Oko reading of the registers, said on stderr through the shared wait
/// mechanism before it waits and when it ends, so a gate standing on it names
/// the command it stands on.
fn read_json(args: &[&str]) -> Result<Value, String> {
    let program = oko_cli();
    let output = stado_wait::output(Command::new(&program).args(args))
        .map_err(|error| format!("cannot run {program} {}: {error}", args.join(" ")))?;
    if !output.status.success() {
        return Err(format!(
            "{program} {} failed: {}",
            args.join(" "),
            String::from_utf8_lossy(&output.stderr).trim()
        ));
    }
    serde_json::from_slice(&output.stdout)
        .map_err(|error| format!("{program} {} printed no JSON: {error}", args.join(" ")))
}

fn short(id: &str) -> String {
    id.chars()
        .take(SHORT_ID_DIGITS)
        .collect::<String>()
        .to_lowercase()
}

/// Raw open records for presence and scope checks, as Oko last wrote them
/// beside its defect register (`snapshot`): read in milliseconds, without
/// starting Oko inside a gate. Whether a recorded repair comes after its
/// finding is Oko's to refuse when the repair is recorded.
pub fn listed_open() -> Result<Vec<OpenDefect>, String> {
    let register = snapshot::read()?;
    register::open_of(&register)
}

/// The open work a machine without Oko holds: the entry this session's own
/// task-scope declaration still names (`tama task scope set … --task <ID> |
/// --defect <ID>`), with the operator's words it was declared for. With no
/// register to record an instruction in, the scope gate makes that
/// declaration the entry, so it is also what the stop guard reads: a session
/// that declared its work and has not cleared it (`tama task scope clear`)
/// has not finished it. A declaration that cannot be read is the error, not
/// an empty one.
pub fn declared_locally(home: &Path, session: &str) -> Result<Option<String>, String> {
    Ok(TaskScope::read(session, home)?.and_then(|scope| scope.declared_entry()))
}

/// The next item `session` may take, as Oko's work queue orders it (`oko work
/// next --executor S [--product P] --json`): every unrepaired item first,
/// then repairs claimed and not verified. One decision of what is worked
/// next, read rather than re-derived here. `Err` when Oko could not be read.
pub fn work_next(session: &str, product: Option<&str>) -> Result<Value, String> {
    let mut args = vec!["work", "next", "--executor", session, "--json"];
    if let Some(product) = product {
        args.extend(["--product", product]);
    }
    read_json(&args)
}

/// The moments Oko's frustration register keeps for `session` (`oko
/// frustration list --session S --json`), each with the cause the session
/// named for it or none. `Err` when Oko could not be read.
pub fn frustration_of(session: &str) -> Result<Value, String> {
    read_json(&["frustration", "list", "--session", session, "--json"])
}

/// What `tama assignment show` prints about the register: how many defects
/// are open and carry no repair, the commands that list them, and the ones
/// this session owns with their repair plans, so the session answers with
/// the register at hand rather than recording the same defect again. Every
/// open defect of every product, each with its plan, made the reading larger
/// than any model's context; the register prints them on request.
pub fn reading(session: &str) -> String {
    match listed_open() {
        Err(reason) => format!("# Open defects are unavailable in this session: {reason}\n"),
        Ok(defects) if defects.is_empty() => "# Open defects of every product: none.\n".to_string(),
        Ok(defects) => {
            let unrepaired = defects
                .iter()
                .filter(|defect| defect.repaired_in.is_none())
                .count();
            let owned: Vec<&OpenDefect> = defects
                .iter()
                .filter(|defect| defect.owner.as_deref() == Some(session))
                .collect();
            let mut out = format!(
                "# Open defects of every product: {}, {unrepaired} with no pushed repair. List \
                 them with `oko defects list --unrepaired` and read one with `oko defects show \
                 ID` before recording a new one; record a pushed repair with `oko defects \
                 repaired`; `oko defects released --close` closes one once a published release \
                 carries that revision.\n# This session owns {} of them.\n",
                defects.len(),
                owned.len()
            );
            for defect in owned {
                let repair = match defect.repair.trim() {
                    "" => format!("no repair plan: `oko defects plan {} --text …`", defect.id),
                    plan => plan.to_string(),
                };
                out.push_str(&format!(
                    "- {} ({}): {}\n  repair: {repair}\n",
                    defect.id, defect.product, defect.title
                ));
            }
            out
        }
    }
}

/// The work other sessions declared on the same repositories: each scope
/// that shares a repository with this session's, with the task or defect it
/// serves and the operator's words it was declared for. A session that read
/// only its own ledger would deny work assigned in a parallel session; this
/// puts that work in the reading every answer starts from.
pub fn other_sessions(home: &Path, session: &str) -> String {
    let unreadable = |cause: String| {
        format!("# Work other sessions declared on these repositories could not be read: {cause}\n")
    };
    let mine = match declared_repositories(home, session) {
        Ok(mine) => mine,
        Err(cause) => return unreadable(cause),
    };
    if mine.is_empty() {
        return String::new();
    }
    let directory = home.join(SCOPE_HOME_RELATIVE);
    let entries = match std::fs::read_dir(&directory) {
        Ok(entries) => entries,
        Err(error) => return unreadable(format!("cannot list {}: {error}", directory.display())),
    };
    let mut failures: Vec<String> = Vec::new();
    let mut scopes: Vec<Value> = Vec::new();
    for entry in entries {
        let path = match entry {
            Ok(entry) => entry.path(),
            Err(error) => {
                failures.push(format!("cannot list {}: {error}", directory.display()));
                continue;
            }
        };
        let read = std::fs::read_to_string(&path).map_err(|error| error.to_string());
        let parsed = read.and_then(|text| {
            serde_json::from_str::<Value>(&text).map_err(|error| format!("not JSON: {error}"))
        });
        match parsed {
            Ok(scope) => scopes.push(scope),
            Err(cause) => failures.push(format!("{}: {cause}", path.display())),
        }
    }
    if !failures.is_empty() {
        return unreadable(failures.join("; "));
    }
    let mut lines: Vec<String> = scopes
        .iter()
        .filter(|scope| scope.get("session").and_then(Value::as_str) != Some(session))
        .filter_map(|scope| other_line(scope, &mine))
        .collect();
    if lines.is_empty() {
        return "# Work other sessions declared on these repositories: none.\n".to_string();
    }
    lines.sort();
    lines.reverse();
    format!(
        "# Work other sessions declared on these repositories ({}), newest first. It is the \
         operator's work too: read it before saying a task is not on the list.\n{}\n",
        lines.len(),
        lines.join("\n")
    )
}

/// One other session's declaration, when it shares a repository with `mine`
/// and names a task or a defect. A field the declaration lacks is said to be
/// missing in the line rather than printed as an empty one.
fn other_line(scope: &Value, mine: &[String]) -> Option<String> {
    let text = |key: &str| {
        scope
            .get(key)
            .and_then(Value::as_str)
            .map(str::trim)
            .filter(|value| !value.is_empty())
    };
    let shared: Vec<&str> = scope
        .get("repositories")?
        .as_array()?
        .iter()
        .filter_map(Value::as_str)
        .filter(|repository| mine.iter().any(|own| own == repository))
        .collect();
    let work = match (text("task_id"), text("defect")) {
        (Some(task), _) => task.to_string(),
        (None, Some(defect)) => format!("defect {defect}"),
        (None, None) => return None,
    };
    if shared.is_empty() {
        return None;
    }
    let said = match text("task").and_then(|words| words.lines().next()) {
        Some(line) => format!("\"{line}\""),
        None => "with no words of the operator recorded".to_string(),
    };
    let when = match text("declared_at") {
        Some(at) => at.to_string(),
        None => "undated".to_string(),
    };
    let session = match text("session") {
        Some(session) => format!("session {session}"),
        None => "a declaration naming no session".to_string(),
    };
    Some(format!(
        "- {when} {session} ({}): {work} — {said}",
        shared.join(", ")
    ))
}
