mod approvals;

use std::path::PathBuf;

use serde_json::Value;

use super::reply::{json_body, send_error, send_json, Reply, Request};
use crate::justify::{api, cua, ssh};

pub(in crate::request) fn handle(request: Request, writer: &mut Reply) {
    let home = match std::env::var_os("HOME") {
        Some(home) => PathBuf::from(home),
        None => return send_error(writer, 500, "HOME is not set"),
    };
    if request.operation == "justifications/cua" {
        return respond(writer, cua::list_document(&home));
    }
    if request.operation == "justifications/ssh" {
        return respond(writer, ssh::list_document(&home));
    }
    if request.operation == "tests/approvals" {
        return respond(writer, approvals::list());
    }
    if request.operation == "tests/restore" {
        return respond(writer, approvals::restore());
    }
    let body = match json_body(&request) {
        Ok(body) => body,
        Err((status, message)) => return send_error(writer, status, &message),
    };
    let result = match request.operation.as_str() {
        "justifications/cua/record" => serde_json::from_value::<cua::RecordRequest>(body)
            .map_err(|error| format!("invalid CUA record request: {error}"))
            .and_then(|input| cua::record_request(input, &home)),
        "justifications/cua/remove" => body
            .get("quote")
            .and_then(Value::as_str)
            .ok_or_else(|| "quote is required".to_string())
            .and_then(|quote| cua::remove_document(&home, quote)),
        "justifications/ssh/record" => serde_json::from_value::<ssh::RecordRequest>(body)
            .map_err(|error| format!("invalid SSH record request: {error}"))
            .and_then(|input| ssh::record_request(input, &home)),
        "justifications/ssh/remove" => body
            .get("quote")
            .and_then(Value::as_str)
            .ok_or_else(|| "quote is required".to_string())
            .and_then(|quote| ssh::remove_document(&home, quote)),
        "justifications/record" => serde_json::from_value::<api::RecordRequest>(body)
            .map_err(|error| format!("invalid justification request: {error}"))
            .and_then(api::record),
        "tests/approve" => approvals::change(&body, &home, true),
        "tests/revoke" => approvals::change(&body, &home, false),
        "tests/audit" => audit(&body),
        "tests/review" => review(&body, &home),
        _ => Err("unknown justification operation".into()),
    };
    respond(writer, result);
}

/// `tests/audit`: `{roots, remove?}` → the document `tama tests audit --json`
/// prints, read against the same approvals.
fn audit(body: &Value) -> Result<Value, String> {
    let roots: Vec<String> = body
        .get("roots")
        .and_then(Value::as_array)
        .ok_or_else(|| {
            "roots is required: an array of repositories or directories holding them".to_string()
        })?
        .iter()
        .map(|root| {
            root.as_str()
                .map(str::to_string)
                .ok_or_else(|| "every root must be a path string".to_string())
        })
        .collect::<Result<_, _>>()?;
    // Absent is a report only; anything but a boolean is refused, since a
    // `"true"` read as false would report where removal was asked for.
    let removing = match body.get("remove") {
        None => false,
        Some(Value::Bool(removing)) => *removing,
        Some(other) => return Err(format!("remove must be true or false, not {other}")),
    };
    tama_hook_tools::ports::block_unapproved_tests::audit::document(&roots, removing)
}

/// Review one repository through the same owned foreground operation as the CLI.
fn review(body: &Value, home: &std::path::Path) -> Result<Value, String> {
    let root = body
        .get("root")
        .and_then(Value::as_str)
        .filter(|root| !root.is_empty())
        .ok_or("root is required: a nonempty repository path")?;
    let root = std::path::Path::new(root);
    let root = if root.is_absolute() {
        root.to_path_buf()
    } else {
        home.join(root)
    };
    tama_hook_tools::ports::smoke_tests::review_repository(&root)
        .map(|message| serde_json::json!({ "message": message }))
}

fn respond(writer: &mut Reply, result: Result<Value, String>) {
    match result {
        Ok(document) => send_json(writer, 200, &document),
        Err(error) => send_error(writer, 400, &error),
    }
}
