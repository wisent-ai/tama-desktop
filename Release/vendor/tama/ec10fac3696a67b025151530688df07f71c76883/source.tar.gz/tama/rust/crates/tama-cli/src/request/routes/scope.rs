//! `tama request task-scope/show|set|clear`: the declaration `tama task
//! scope` makes, for Tama Desktop, through the same functions and with the
//! same refusals. A declaration asked for wrongly is a bad request; a
//! register, instruction or scope file that refuses or cannot be read is a
//! failure naming it.

use serde_json::{json, Value};
use tama_hook_tools::ports::block_off_task_work::scope_cli::{
    cleared, declared, shown, Refused as Declaration,
};

use super::{body, failed, refused, respond, Refused};
use crate::request::reply::{Reply, Request};

pub(super) fn handle(request: Request, writer: &mut Reply) {
    let Some(body) = body(&request, writer) else {
        return;
    };
    let answer = match request.operation.as_str() {
        "task-scope/set" => set(&body),
        "task-scope/clear" => clear(&body),
        "task-scope/show" => show(&body),
        other => Err(refused(format!(
            "{other} is no task-scope operation: show, set or clear"
        ))),
    };
    respond(writer, answer);
}

/// Remove the scope a session declared; `"cleared": false` when it had none.
fn clear(body: &Value) -> Result<Value, Refused> {
    let session = session(body)?;
    let removed = cleared(&session).map_err(failed)?;
    Ok(json!({ "session": session, "cleared": removed }))
}

/// The scope a session declared, `"scope": null` when it declared none.
fn show(body: &Value) -> Result<Value, Refused> {
    let session = session(body)?;
    let scope = shown(&session).map_err(failed)?;
    Ok(json!({ "session": session, "scope": scope.map(|shown| shown.document()) }))
}

fn set(body: &Value) -> Result<Value, Refused> {
    let session = session(body)?;
    let repositories = repositories(body)?;
    let defect = optional(body, "defect")?;
    let task = optional(body, "task")?;
    let written = declared(&session, &repositories, defect.as_deref(), task.as_deref()).map_err(
        |refusal| match refusal {
            Declaration::Usage(said) => refused(said),
            Declaration::Failed(said) => failed(said),
        },
    )?;
    Ok(json!({ "session": session, "scope": written.document, "notice": written.notice }))
}

fn session(body: &Value) -> Result<String, Refused> {
    match body.get("session") {
        Some(Value::String(session)) if !session.is_empty() => Ok(session.clone()),
        _ => Err(refused(
            "task-scope needs {\"session\": <session id>}: a scope belongs to one session's \
             instruction, and no other session's instruction stands in for it",
        )),
    }
}

/// An entry named by `key`, absent or null when the request names none.
fn optional(body: &Value, key: &str) -> Result<Option<String>, Refused> {
    match body.get(key) {
        None | Some(Value::Null) => Ok(None),
        Some(Value::String(value)) if !value.is_empty() => Ok(Some(value.clone())),
        Some(other) => Err(refused(format!(
            "task-scope \"{key}\" must be a non-empty id or absent, got {other}"
        ))),
    }
}

/// The repositories named, none when the request names none, so the task's
/// Oko contract supplies them.
fn repositories(body: &Value) -> Result<Vec<String>, Refused> {
    match body.get("repositories") {
        None | Some(Value::Null) => Ok(Vec::new()),
        Some(Value::Array(names)) => names
            .iter()
            .map(|name| {
                name.as_str().map(str::to_owned).ok_or_else(|| {
                    refused(format!(
                        "task-scope \"repositories\" holds {name}, not a name"
                    ))
                })
            })
            .collect(),
        Some(other) => Err(refused(format!(
            "task-scope \"repositories\" must be a list of names, got {other}"
        ))),
    }
}
