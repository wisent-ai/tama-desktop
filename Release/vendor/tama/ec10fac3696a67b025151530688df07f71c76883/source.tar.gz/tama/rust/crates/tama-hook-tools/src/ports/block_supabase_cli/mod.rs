//! Logic for `tama-block-supabase-cli`, registry hook `block-supabase-cli`:
//! the Supabase CLI is not invoked from an agent session.
//!
//! Only fields that can start a process are inspected, so documentation and
//! source that merely mention the command stay writable. Quoted prose is
//! dropped before the match — unless a shell wrapper or `ssh` is there to run
//! the quote, which is the one place a quoted string executes.
//!
//! The refusal names no exception on purpose: not a subcommand, not
//! `--help`, not a read-only query, not a local instance, not a session
//! capability. The owning repository and its reviewed deployment path are the
//! route.
//!
//! The shell printed the refusal on stdout and failed with `false`, so that
//! is kept: exit 1 with the three lines on stdout. The channel is part of
//! what the operator has been reading in his sessions.

use std::sync::LazyLock;

use regex::Regex;
use serde_json::Value;
use tama_hooks::session_record::read_payload;

use crate::ports::check_numeric_literals_payload::path_texts;
use crate::ports::tool_vocabulary::{Call, WHOLE_FILE_TOOLS};
use crate::ports::transport_common as common;

/// Where a process tool's `start` names the program and its arguments.
const APPLICATION_KEY: &str = "application";
const ARGS_KEY: &str = "args";
const REFUSAL: &str = "BLOCKED: Supabase CLI use is forbidden in agent sessions.\n\
     Use the owning repository and its reviewed deployment path instead of invoking supabase \
     directly.\n\
     This hook has no command, subcommand, read-only, local, help, version, or session-capability \
     exception.";
/// The device that routes a write into the JavaScript kernel: a payload aimed
/// there executes its text.
static REPL_DEVICE: LazyLock<Regex> =
    LazyLock::new(|| common::compile("^xd://mcp__node_repl_js($|[/_-])"));

/// A shell wrapper or `ssh`: the one place quoted text runs.
static RUNS_A_QUOTE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile("(^|[[:space:]])(ssh|(ba|z|d)?sh[[:space:]]+-[a-z]*c)([[:space:]]|$)")
});

static QUOTED: LazyLock<Regex> =
    LazyLock::new(|| common::compile("'[^']*'|[\\x22][^\\x22]*[\\x22]"));

/// The binary through a bare or absolute path, an environment prefix, a
/// package runner, a pipeline, a command list, a substitution, or a wrapped
/// shell command.
static SUPABASE_INVOCATION: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(concat!(
        "(^|[|;&`(\\x27\\x22]|&&|\\|\\||[[:space:]])",
        "([a-z_][a-z0-9_]*=[^[:space:]]*[[:space:]]+)*",
        "((npx|bunx|pnpm[[:space:]]+dlx|yarn[[:space:]]+dlx)[[:space:]]+(--[a-z-]+[[:space:]]+)*)?",
        "([^[:space:]|;&\\x22\\x27]*/)?supabase([[:space:]]|$)",
    ))
});

/// `[.. | strings] | join("\n")` over the tool input.
fn every_string(input: &Value, cwd: Option<&str>) -> String {
    let texts = match path_texts(input, cwd) {
        Ok(texts) => texts,
        Err(error) => tama_hooks::session_record::refuse(&format!(
            "TAMA_HOOK_INFRASTRUCTURE: block-supabase-cli: {error}"
        )),
    };
    texts
        .into_iter()
        .map(|(_, text)| text)
        .collect::<Vec<_>>()
        .join("\n")
}

/// `[.application, (.args // [])[]] | join(" ")`.
fn process_text(input: &Value) -> String {
    let mut parts: Vec<String> = Vec::new();
    if let Some(Value::String(application)) = input.get(APPLICATION_KEY) {
        parts.push(application.clone());
    }
    if let Some(Value::Array(args)) = input.get(ARGS_KEY) {
        for arg in args {
            if let Value::String(text) = arg {
                parts.push(text.clone());
            }
        }
    }
    parts.join(" ")
}

/// The part of this payload that can start a process, lowercased.
fn executable_text(payload: &Value) -> String {
    let call = Call::of(payload);
    let text = if call.is_shell() {
        call.command().map(str::to_string)
    } else if call.is_eval() {
        call.code().map(str::to_string)
    } else if call.starts_process() {
        call.input().map(process_text)
    } else if call.is_one_of(WHOLE_FILE_TOOLS)
        && call
            .path()
            .is_some_and(|path| REPL_DEVICE.is_match(&path.to_lowercase()))
    {
        call.input()
            .map(|input| every_string(input, call.session_cwd()))
    } else {
        None
    };
    match text {
        Some(text) => text.to_lowercase(),
        None => String::new(),
    }
}

/// Whether this payload invokes the Supabase CLI.
pub fn invokes_supabase(payload: &Value) -> bool {
    let text = executable_text(payload);
    if text.is_empty() {
        return false;
    }
    let judged = if RUNS_A_QUOTE.is_match(&text) {
        text
    } else {
        QUOTED.replace_all(&text, " ").into_owned()
    };
    SUPABASE_INVOCATION.is_match(&judged)
}

pub fn run() {
    if invokes_supabase(&read_payload()) {
        tama_hooks::session_record::refuse(REFUSAL);
    }
}
