//! Shared drafted-rule document for the detached writer and the CLI reader.
//! A missing registry starts empty; an existing unreadable one is never reset.

use serde_json::{json, Value};
use std::fs::{self, File, OpenOptions};
use std::io::Write;
use std::path::Path;

/// The registry's lock, released by closing its file when it is dropped; no
/// separate unlock can fail unsaid.
pub struct Lock {
    _held: File,
}

impl Lock {
    pub fn acquire(path: &Path) -> Result<Self, String> {
        let lock_path = path.with_extension("lock");
        if let Some(parent) = lock_path.parent() {
            fs::create_dir_all(parent)
                .map_err(|error| format!("cannot create {}: {error}", parent.display()))?;
        }
        let file = OpenOptions::new()
            .write(true)
            .create(true)
            .truncate(false)
            .open(&lock_path)
            .map_err(|error| format!("cannot open {}: {error}", lock_path.display()))?;
        // Another writer may hold the lock; the wait says so while it lasts.
        stado_wait::blocking(
            stado_wait::Kind::Lock,
            "the learned-rule registry",
            path.display(),
            || file.lock(),
        )
        .map_err(|error| format!("cannot lock {}: {error}", lock_path.display()))?;
        Ok(Self { _held: file })
    }
}

pub fn read(path: &Path) -> Result<Value, String> {
    let text = match fs::read_to_string(path) {
        Ok(text) => text,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
            return Ok(json!({"rules": []}))
        }
        Err(error) => return Err(format!("cannot read {}: {error}", path.display())),
    };
    let doc: Value = serde_json::from_str(&text)
        .map_err(|error| format!("{} is not valid JSON: {error}", path.display()))?;
    if !doc.is_object() || !doc["rules"].is_array() {
        return Err(format!(
            "{} must be an object with a rules array",
            path.display()
        ));
    }
    Ok(doc)
}

/// Replace only after the caller locked, read and validated the old document.
pub fn replace(path: &Path, doc: &Value) -> Result<(), String> {
    let text = serde_json::to_vec_pretty(doc)
        .map_err(|error| format!("cannot encode {}: {error}", path.display()))?;
    let temporary = path.with_extension(format!("tmp{}", std::process::id()));
    let mut file = File::create(&temporary)
        .map_err(|error| format!("cannot create {}: {error}", temporary.display()))?;
    file.write_all(&text)
        .and_then(|()| file.write_all(b"\n"))
        .and_then(|()| file.sync_all())
        .map_err(|error| format!("cannot write {}: {error}", temporary.display()))?;
    fs::rename(&temporary, path)
        .map_err(|error| format!("cannot replace {}: {error}", path.display()))?;
    if let Some(parent) = path.parent() {
        File::open(parent)
            .and_then(|directory| directory.sync_all())
            .map_err(|error| format!("cannot sync {}: {error}", parent.display()))?;
    }
    Ok(())
}
