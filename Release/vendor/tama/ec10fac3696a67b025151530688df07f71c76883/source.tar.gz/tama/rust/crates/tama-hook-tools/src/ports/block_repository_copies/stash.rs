//! Stashes in the one checkout.
//!
//! Several sessions write to the same checkout at once, so its uncommitted
//! changes are not one session's to move. A stash takes all of them out of
//! the working tree: `git pull --rebase --autostash` stashed other sessions'
//! edits, the rebase then refused because another session wrote a file in
//! between, and the stash was never applied back, so their work vanished from
//! the tree while they were still writing it.
//!
//! So nothing stashes here: `git stash` that saves (bare, `push`, `save`, or
//! led by an option) and `--autostash` on `pull`, `rebase` or `merge` are
//! refused, and the refusal names the delivery that leaves the tree alone.
//! Reading or restoring a stash that already exists (`list`, `show`, `apply`,
//! `pop`, `branch`) still passes, because that is how stranded work comes
//! back.

const STASH: &str = "stash";
const AUTOSTASH: &str = "--autostash";

const REASON: &str = "BLOCKED: a stash in a shared checkout takes other sessions' uncommitted \
                      work out of the tree, and a refused rebase leaves it stranded. Commit only \
                      your own paths, then deliver with 'git pull --no-rebase --no-edit' (a \
                      merge that leaves unrelated uncommitted files alone and refuses naming \
                      any file both sides touched) and 'git push'. Work a stash already holds \
                      comes back with 'git stash list', 'git stash show -p' and 'git stash \
                      apply'.";

/// The refusal a `git <subcommand> <arguments>` call earns for stashing, if
/// any.
pub(super) fn refusal(subcommand: &str, arguments: &[String]) -> Option<&'static str> {
    if subcommand == STASH {
        return match arguments.first().map(String::as_str) {
            None | Some("push") | Some("save") => Some(REASON),
            Some(first) if first.starts_with('-') => Some(REASON),
            Some(_) => None,
        };
    }
    match subcommand {
        "pull" | "rebase" | "merge" if arguments.iter().any(|argument| argument == AUTOSTASH) => {
            Some(REASON)
        }
        _ => None,
    }
}
