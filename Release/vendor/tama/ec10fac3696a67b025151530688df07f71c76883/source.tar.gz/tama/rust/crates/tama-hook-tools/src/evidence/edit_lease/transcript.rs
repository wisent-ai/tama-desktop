//! A lease holder's own transcript, read from its end: which of its calls
//! names the leased file, and whether that call has its result yet.
//!
//! The transcript is the one the session writes now, as the commit review
//! reads it (`session_changes::session_transcript`), so a session OMP moved
//! to a new transcript is read where its calls are. Only the tail back to
//! the call is decoded, a block of the file system's own size at a time, so
//! a long transcript is not read whole inside another session's pre-write
//! hook. A path a call names relative to the session's working directory
//! (its `session` record's `cwd`) is resolved there and compared whole. The
//! records read are OMP's: an assistant `message` whose content holds
//! `toolCall` items, and a `toolResult` message naming its `toolCallId`; a
//! line still being written (no newline after it yet) is not read.

use std::fs::File;
use std::io::{BufRead, BufReader, Read, Seek, SeekFrom};
use std::os::unix::fs::MetadataExt;
use std::path::{Path, PathBuf};

use serde_json::Value;
use tama_hooks::session_record::ToolCall;

/// Where a call stands in its session's transcript.
#[derive(Debug, PartialEq, Eq)]
pub(super) enum Call {
    /// Its result is recorded and is no error: the call did its work.
    Answered,
    /// Its result is recorded as an error (`isError`): a gate refused it or
    /// the tool failed, so it changed no file.
    Failed,
    /// It is recorded and its result is not: it still runs.
    Running,
    /// The transcript does not hold it.
    Absent,
}

/// The transcript `session` writes now; none when it has none.
pub(super) fn of(session: &str) -> Result<Option<PathBuf>, String> {
    crate::evidence::session_changes::session_transcript(session)
}

/// The working directory the `session` record that opens `transcript`
/// names, as OMP writes one first; none when the first record is no such
/// record or names no directory, and then none of its calls can be matched
/// to a file by a relative path.
fn cwd(transcript: &Path) -> Result<Option<PathBuf>, String> {
    let file = File::open(transcript)
        .map_err(|error| format!("cannot open {}: {error}", transcript.display()))?;
    let Some(line) = BufReader::new(file).lines().next() else {
        return Ok(None);
    };
    let line = line.map_err(|error| format!("cannot read {}: {error}", transcript.display()))?;
    let record: Value = serde_json::from_str(&line).map_err(|error| {
        format!(
            "{} opens with a line that is not a record: {error}",
            transcript.display()
        )
    })?;
    if record.get("type").and_then(Value::as_str) != Some("session") {
        return Ok(None);
    }
    Ok(record.get("cwd").and_then(Value::as_str).map(PathBuf::from))
}

/// The tool calls an assistant record makes; none for any other record.
fn calls(record: &Value) -> Option<Vec<ToolCall>> {
    let message = record.get("message")?;
    if message.get("role").and_then(Value::as_str) != Some("assistant") {
        return None;
    }
    let mut calls = Vec::new();
    for item in message.get("content")?.as_array()? {
        if item.get("type").and_then(Value::as_str) != Some("toolCall") {
            continue;
        }
        calls.push(ToolCall {
            id: item.get("id").and_then(Value::as_str)?.to_owned(),
            name: item.get("name").and_then(Value::as_str)?.to_owned(),
            arguments: item.get("arguments")?.clone(),
        });
    }
    if calls.is_empty() {
        None
    } else {
        Some(calls)
    }
}

/// Each complete record of `transcript`, newest first, until `visit`
/// answers `true`.
fn back(transcript: &Path, mut visit: impl FnMut(&Value) -> bool) -> Result<(), String> {
    let named = |error: std::io::Error| format!("cannot read {}: {error}", transcript.display());
    let mut file = File::open(transcript).map_err(named)?;
    let metadata = file.metadata().map_err(named)?;
    let block = metadata.blksize();
    let mut end = metadata.len();
    let mut carried: Vec<u8> = Vec::new();
    // Until the file's last newline is passed, the bytes read belong to a
    // line the harness is still writing.
    let mut unfinished = true;
    loop {
        let reached_start = end <= block;
        let start = end.saturating_sub(block);
        file.seek(SeekFrom::Start(start)).map_err(named)?;
        let mut bytes = Vec::new();
        let mut part = Read::by_ref(&mut file).take(end - start);
        part.read_to_end(&mut bytes).map_err(named)?;
        bytes.extend_from_slice(&carried);
        if unfinished {
            match bytes.iter().rposition(|byte| *byte == b'\n') {
                Some(last) => {
                    bytes.truncate(last);
                    unfinished = false;
                }
                None => bytes.clear(),
            }
        }
        // The part before this block's first newline may begin in the block
        // before it, which the next turn reads.
        let first = bytes.iter().position(|byte| *byte == b'\n');
        let complete = match (reached_start, first) {
            (true, _) => {
                carried = Vec::new();
                bytes
            }
            (false, Some(first)) => {
                carried = bytes[..first].to_vec();
                bytes[first..].to_vec()
            }
            (false, None) => {
                carried = bytes;
                Vec::new()
            }
        };
        let lines = complete.split(|byte| *byte == b'\n');
        for line in lines.rev().filter(|line| !line.is_empty()) {
            let record: Value = serde_json::from_slice(line).map_err(|error| {
                format!(
                    "{} holds a line that is not a record: {error}",
                    transcript.display()
                )
            })?;
            if visit(&record) {
                return Ok(());
            }
        }
        if reached_start {
            return Ok(());
        }
        end = start;
    }
}

/// Whether `call` names `file`: one of its path arguments is the file's
/// whole path, a relative one once resolved against `cwd`; with no working
/// directory known, a relative path names no file.
fn names(call: &ToolCall, cwd: Option<&Path>, file: &Path) -> bool {
    let matches = |path: &str| {
        let path = Path::new(path);
        match (path.is_absolute(), cwd) {
            (true, _) => path == file || crate::util::normalize_path(path) == file,
            (false, Some(cwd)) => crate::util::normalize_path(&cwd.join(path)) == file,
            (false, None) => false,
        }
    };
    call.target().is_some_and(|path| matches(&path))
        || call.paths().iter().any(|path| matches(path))
}

/// The id of the call in `transcript`'s newest assistant record with tool
/// calls that names `file`; none when that record names it in no call.
pub(super) fn call_on(transcript: &Path, file: &Path) -> Result<Option<String>, String> {
    let cwd = cwd(transcript)?;
    let mut found = None;
    back(transcript, |record| match calls(record) {
        Some(calls) => {
            let named = calls
                .into_iter()
                .find(|call| names(call, cwd.as_deref(), file));
            found = named.map(|call| call.id);
            true
        }
        None => false,
    })?;
    Ok(found)
}

/// Where `call` stands in `transcript`, read back from its end to the call.
pub(super) fn state(transcript: &Path, call: &str) -> Result<Call, String> {
    let mut found = Call::Absent;
    back(transcript, |record| {
        let message = record.get("message");
        let field = |key: &str| message.and_then(|message| message.get(key)?.as_str());
        if field("role") == Some("toolResult") && field("toolCallId") == Some(call) {
            let failed = message
                .and_then(|message| message.get("isError")?.as_bool())
                .is_some_and(|failed| failed);
            found = if failed { Call::Failed } else { Call::Answered };
            return true;
        }
        let made = calls(record);
        if made.is_some_and(|made| made.iter().any(|each| each.id == call)) {
            found = Call::Running;
            return true;
        }
        false
    })?;
    Ok(found)
}
