//! Who holds a judge channel. A judge request is sent by one hook process
//! through one HTTP client it starts; while the request waits, a record
//! under `~/.tama/judge-channels/` names both processes by pid and start,
//! the hook's command line, the route and the endpoint. The record goes when
//! the request ends, and a record whose hook process has ended is the
//! channel of nobody: its client, if it still runs, is ended so the
//! connection goes with the hook that opened it. A process now running under
//! a recorded pid but started at another time is another process: the
//! recorded one has ended.

use std::io::ErrorKind;
use std::path::PathBuf;
use std::time::{SystemTime, UNIX_EPOCH};

use serde::{Deserialize, Serialize};

use super::super::credentials::home_dir;
use crate::util::process_start as start;

/// The HTTP client every judge request runs; a process that is not this
/// program is never ended in a record's name.
pub(in crate::brama) const CLIENT: &str = "/usr/bin/curl";

fn directory() -> PathBuf {
    home_dir().join(".tama").join("judge-channels")
}

/// One judge request in flight, as its hook process recorded it.
#[derive(Serialize, Deserialize)]
pub(in crate::brama) struct Owner {
    pub hook_pid: u32,
    pub client_pid: u32,
    /// When each process started, as the kernel said when the record was
    /// written. A record written before starts were kept has none, and its
    /// processes are known by pid alone, as that record was written.
    pub hook_start: Option<String>,
    pub client_start: Option<String>,
    pub command: String,
    pub route: String,
    pub endpoint: String,
    pub since_epoch_seconds: u64,
}

impl Owner {
    /// The request and its owner, as a refusal names them.
    pub(in crate::brama) fn described(&self) -> String {
        let held = match SystemTime::now().duration_since(UNIX_EPOCH) {
            Ok(now) => format!(
                "for {} s",
                now.as_secs().saturating_sub(self.since_epoch_seconds)
            ),
            Err(error) => format!("since an instant this clock cannot place: {error}"),
        };
        format!(
            "route {} to {} sent by hook process {} (`{}`) through client process {}, waiting {held}",
            self.route, self.endpoint, self.hook_pid, self.command, self.client_pid
        )
    }
}

/// The record of the request this process is waiting on; removed when the
/// request ends, however it ends.
pub(in crate::brama) struct Held {
    path: PathBuf,
}

impl Held {
    pub(in crate::brama) fn take(
        route: &str,
        endpoint: &str,
        client_pid: u32,
    ) -> Result<Held, String> {
        let since_epoch_seconds = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map_err(|error| format!("cannot date the judge request: {error}"))?
            .as_secs();
        let hook_pid = std::process::id();
        let hook_start = start::of(hook_pid)?
            .ok_or_else(|| format!("the kernel holds no start for this hook process {hook_pid}"))?;
        // The client reads its request from its input before it does
        // anything, so it is still running here.
        let client_start = start::of(client_pid)?.ok_or_else(|| {
            format!("the judge client {client_pid} ended before its request was written")
        })?;
        let owner = Owner {
            hook_pid,
            client_pid,
            hook_start: Some(hook_start),
            client_start: Some(client_start),
            command: std::env::args().collect::<Vec<_>>().join(" "),
            route: route.to_owned(),
            endpoint: endpoint.to_owned(),
            since_epoch_seconds,
        };
        let directory = directory();
        std::fs::create_dir_all(&directory).map_err(|error| {
            format!(
                "cannot create the judge channel register {}: {error}",
                directory.display()
            )
        })?;
        let path = directory.join(format!("{}-{client_pid}.json", owner.hook_pid));
        let text = serde_json::to_string(&owner)
            .map_err(|error| format!("cannot encode the judge channel record: {error}"))?;
        std::fs::write(&path, text).map_err(|error| {
            format!(
                "cannot record the judge channel {}: {error}",
                path.display()
            )
        })?;
        Ok(Held { path })
    }
}

impl Drop for Held {
    fn drop(&mut self) {
        if let Err(error) = std::fs::remove_file(&self.path) {
            if error.kind() != ErrorKind::NotFound {
                eprintln!(
                    "tama: the judge channel record {} stays behind: {error}",
                    self.path.display()
                );
            }
        }
    }
}

/// The program `pid` runs when it is the process a record named: running,
/// and started when the record says. None when no process runs there or a
/// later one took the pid. A record without a start names it by pid alone.
fn recorded(pid: u32, started: Option<&str>) -> Result<Option<String>, String> {
    if let Some(recorded) = started {
        match start::of(pid)? {
            Some(now) if now == recorded => {}
            _ => return Ok(None),
        }
    }
    program(pid)
}

/// The program process `pid` runs, read from the kernel; none when no such
/// process exists.
#[cfg(target_os = "macos")]
fn program(pid: u32) -> Result<Option<String>, String> {
    let capacity = libc::PROC_PIDPATHINFO_MAXSIZE;
    let mut buffer: Vec<u8> = Vec::with_capacity(
        usize::try_from(capacity).map_err(|error| format!("the kernel's path size: {error}"))?,
    );
    let length = unsafe {
        libc::proc_pidpath(
            start::pid_of(pid)?,
            buffer.as_mut_ptr().cast(),
            capacity.unsigned_abs(),
        )
    };
    if !length.is_positive() {
        let error = std::io::Error::last_os_error();
        return match error.raw_os_error() {
            Some(libc::ESRCH) => Ok(None),
            _ => Err(format!("cannot read the program of process {pid}: {error}")),
        };
    }
    let length = usize::try_from(length)
        .map_err(|error| format!("process {pid}'s program path length is not a size: {error}"))?;
    // The kernel wrote `length` bytes of the path into the buffer.
    unsafe { buffer.set_len(length) };
    String::from_utf8(buffer)
        .map(Some)
        .map_err(|error| format!("process {pid} runs a path that is not text: {error}"))
}

#[cfg(not(target_os = "macos"))]
fn program(pid: u32) -> Result<Option<String>, String> {
    match std::fs::read_link(format!("/proc/{pid}/exe")) {
        Ok(path) => Ok(Some(path.display().to_string())),
        Err(error) if error.kind() == ErrorKind::NotFound => Ok(None),
        Err(error) => Err(format!("cannot read the program of process {pid}: {error}")),
    }
}

/// Every request recorded on `endpoint` whose hook process still runs. A
/// record whose hook ended is removed, and its client, still running the
/// judge client, is ended: the channel goes with the hook that opened it.
/// Each ended orphan is said on stderr.
pub(in crate::brama) fn holding(endpoint: &str) -> Result<Vec<Owner>, String> {
    let directory = directory();
    let entries = match std::fs::read_dir(&directory) {
        Ok(entries) => entries,
        Err(error) if error.kind() == ErrorKind::NotFound => return Ok(Vec::new()),
        Err(error) => {
            return Err(format!(
                "cannot list the judge channel register {}: {error}",
                directory.display()
            ))
        }
    };
    let mut owners = Vec::new();
    for entry in entries {
        let path = entry
            .map_err(|error| format!("cannot list {}: {error}", directory.display()))?
            .path();
        let text = std::fs::read_to_string(&path).map_err(|error| {
            format!(
                "cannot read judge channel record {}: {error}",
                path.display()
            )
        })?;
        let owner: Owner = serde_json::from_str(&text).map_err(|error| {
            format!(
                "cannot decode judge channel record {}: {error}",
                path.display()
            )
        })?;
        if owner.endpoint != endpoint {
            continue;
        }
        if recorded(owner.hook_pid, owner.hook_start.as_deref())?.is_some() {
            owners.push(owner);
            continue;
        }
        if recorded(owner.client_pid, owner.client_start.as_deref())?.as_deref() == Some(CLIENT) {
            if unsafe { libc::kill(start::pid_of(owner.client_pid)?, libc::SIGTERM) }.is_negative()
            {
                return Err(format!(
                    "cannot end the orphaned judge client of {}: {}",
                    owner.described(),
                    std::io::Error::last_os_error()
                ));
            }
            eprintln!(
                "tama: ended the judge client its hook left behind: {}",
                owner.described()
            );
        }
        std::fs::remove_file(&path).map_err(|error| {
            format!(
                "cannot remove the ended judge channel record {}: {error}",
                path.display()
            )
        })?;
    }
    Ok(owners)
}
