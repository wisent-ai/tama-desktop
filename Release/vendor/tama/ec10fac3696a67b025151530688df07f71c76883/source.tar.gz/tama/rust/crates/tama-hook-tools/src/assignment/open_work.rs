//! The one reading of what is still owed: every open Oko task of every
//! session and every open defect of every product. `block-stop-with-open-work`
//! refuses to end a turn on it: an item counts there until Oko records it
//! done or fixed, and a blocker entry does not stand it aside. Whether a
//! build, a compile or a test may run is not read here: it is Oko's one
//! admission decision (`oko admit build --session`).

use std::collections::BTreeSet;

use super::{completion, open_defects, rules};

/// What Oko holds open for one session.
pub struct OpenWork {
    /// The session's task ledger, read once for every question asked of it.
    pub ledger: rules::TaskLedger,
    /// Executable tasks, one line each, as Oko's ledger renders them: every
    /// open task of this session, and each open task of another session that
    /// carries no repair yet.
    pub tasks: Vec<String>,
    /// This session's own open tasks, the head of `tasks`.
    pub own: Vec<String>,
    /// Open tasks of other sessions whose owner already recorded a commit or
    /// a report as their proof. They wait on that owner and on the build,
    /// not on this session, so they are named as the owner's, not assigned.
    pub owned_elsewhere: Vec<String>,
    /// The executable tasks that carry no repair yet.
    pub unrepaired_tasks: Vec<String>,
    /// Every open defect of every product.
    pub defects: Vec<open_defects::OpenDefect>,
    /// The open tasks of other sessions in `tasks`, each with the products
    /// its contract is scoped to, for `confine_to`.
    others: Vec<(String, BTreeSet<String>)>,
}

impl OpenWork {
    pub fn is_empty(&self) -> bool {
        self.tasks.is_empty() && self.defects.is_empty()
    }

    /// Keep only the work inside `scope`, the products this session's task
    /// contracts name: this session's own tasks, other sessions'
    /// tasks whose contract names one of those products, and those products'
    /// defects. What is left out is another session's work: a session the
    /// operator gave one product is not sent to every other one. An empty
    /// scope keeps everything. Answers the tasks and the defects it left out.
    pub fn confine_to(
        &mut self,
        scope: &BTreeSet<String>,
    ) -> (BTreeSet<String>, Vec<open_defects::OpenDefect>) {
        let outside: BTreeSet<String> = self
            .others
            .iter()
            .filter(|(_, products)| !scope.is_empty() && products.is_disjoint(scope))
            .map(|(line, _)| line.clone())
            .collect();
        self.tasks.retain(|line| !outside.contains(line));
        self.unrepaired_tasks.retain(|line| !outside.contains(line));
        self.others.retain(|(line, _)| !outside.contains(line));
        let (kept, left_out): (Vec<_>, Vec<_>) = std::mem::take(&mut self.defects)
            .into_iter()
            .partition(|defect| scope.is_empty() || scope.contains(&defect.product));
        self.defects = kept;
        (outside, left_out)
    }

    /// Every open item as one line, tasks first.
    pub fn lines(&self) -> Vec<String> {
        self.tasks
            .iter()
            .cloned()
            .chain(self.defects.iter().map(defect_line))
            .collect()
    }

    /// Every open item that carries no repair yet, one line each, tasks
    /// first: what a build still waits on.
    pub fn unrepaired_lines(&self) -> Vec<String> {
        self.unrepaired_tasks
            .iter()
            .cloned()
            .chain(
                self.defects
                    .iter()
                    .filter(|defect| defect.repaired_in.is_none())
                    .map(defect_line),
            )
            .collect()
    }
}

/// One open defect as one line: its id and product. `oko defects show <id>`
/// prints the rest; a title is not quoted, so a refusal over every open
/// defect stays a list of identifiers.
pub fn defect_line(defect: &open_defects::OpenDefect) -> String {
    format!("{} ({})", defect.id, defect.product)
}

/// One open defect named for the session that takes it: its line and title.
pub fn defect_named(defect: &open_defects::OpenDefect) -> String {
    format!("{}: {}", defect_line(defect), defect.title)
}

/// The products the operator limited this session to: the union of
/// `contract.terms.scope` over its tasks Oko holds not done whose contract the
/// operator confirmed (`contract.terms.confirmedAt`). A scope a session wrote
/// into its own contract limits nothing: a session that named one product
/// on its own contracts was let go while every other product's work stayed
/// open, against the operator's order that every session answers
/// for every task and defect. A finished task's products are past work, not
/// the session's current scope. Empty when no confirmed open contract names
/// a scope, which leaves every product's work this session's.
pub fn session_scope(ledger: &rules::TaskLedger) -> BTreeSet<String> {
    ledger.value["tasks"]
        .as_array()
        .into_iter()
        .flatten()
        .filter(|task| task["status"].as_str() == Some("not done"))
        .filter(|task| {
            task.pointer("/contract/terms/confirmedAt")
                .is_some_and(|at| !at.is_null())
        })
        .flat_map(completion::contract_scope)
        .collect()
}

/// Read the session's open work from Oko, in one reading: the session's own
/// ledger is taken from the report of every open session, which holds it
/// whenever the session wrote in the report's window, and read on its own
/// only when it is absent. Two readings - the session's, then everyone's -
/// each had the gate's whole budget to themselves and together spent twice
/// it. `Err` when Oko could not be read: an unreadable ledger or register is
/// not an empty one.
pub fn read(session: &str) -> Result<OpenWork, String> {
    if session.trim().is_empty() {
        return Err("the payload contains no session identity".to_owned());
    }
    let ledgers = rules::open_ledgers(session)?;
    let ledger = match ledgers
        .iter()
        .find(|ledger| ledger.value.get("sessionId").and_then(|id| id.as_str()) == Some(session))
    {
        Some(own) => rules::TaskLedger {
            value: own.value.clone(),
            digest: own.digest.clone(),
        },
        None => rules::task_ledger(session)?,
    };
    from_ledgers(ledger, &ledgers)
}

/// A task another session already carries a repair for is that session's:
/// nothing is left to write for it, and the owner and the one batch build
/// close it. A task of another session with no proof is still counted, so
/// work nobody carries is never dropped.
///
/// This session's own open tasks come first. Every open task still holds the
/// turn, whichever session it came from; the order only says where the
/// reader starts, and the refusal's "start now" names this session's first
/// open task while it has one.
fn from_ledgers(ledger: rules::TaskLedger, open: &[rules::TaskLedger]) -> Result<OpenWork, String> {
    let session = ledger.value["sessionId"]
        .as_str()
        .ok_or_else(|| {
            format!(
                "the task ledger read for this session names no sessionId, so its own tasks \
                 cannot be told from other sessions': {}",
                ledger.value
            )
        })?
        .to_owned();
    let (mut tasks, mut others) = (Vec::new(), Vec::new());
    let mut unrepaired_tasks = Vec::new();
    let mut owned_elsewhere = Vec::new();
    // The session's own ledger read on its own (it wrote nothing in the
    // report's window) is still this session's work, and still first.
    if !open
        .iter()
        .any(|each| each.value["sessionId"].as_str() == Some(session.as_str()))
    {
        tasks.extend(completion::pending_from(&ledger)?);
        unrepaired_tasks.extend(completion::unrepaired_from(&ledger)?);
    }
    for each in open {
        if each.value["sessionId"].as_str() == Some(session.as_str()) {
            tasks.extend(completion::pending_from(each)?);
            unrepaired_tasks.extend(completion::unrepaired_from(each)?);
        } else {
            // A ledger whose register changed after the snapshot was settled
            // is listed as it stood then, and each line says so; one whose
            // change record cannot be read says that, with its cause.
            // `snapshot::report` sets them on a ledger that names its session.
            let stale = match (
                each.value["staleSince"].as_str(),
                each.value["staleUnread"].as_str(),
                each.value["sessionId"].as_str(),
            ) {
                (Some(change), _, Some(other)) => {
                    format!(" (as Oko settled it before session {other}'s task register changed {change})")
                }
                (None, Some(cause), Some(other)) => {
                    format!(" (whether session {other}'s task register changed after Oko settled it cannot be read: {cause})")
                }
                _ => String::new(),
            };
            // Only a task whose owner recorded its repair is the owner's. An
            // unread message of another session carries no repair; listing
            // it here called thousands of unread messages repaired work.
            owned_elsewhere.extend(
                completion::repaired_from(each)?
                    .into_iter()
                    .map(|line| format!("{line}{stale}")),
            );
            others.extend(
                completion::unrepaired_scoped_from(each)?
                    .into_iter()
                    .map(|(line, scope)| (format!("{line}{stale}"), scope)),
            );
        }
    }
    let own = tasks.clone();
    tasks.extend(others.iter().map(|(line, _)| line.clone()));
    unrepaired_tasks.extend(others.iter().map(|(line, _)| line.clone()));
    let defects = open_defects::listed_open()?;
    Ok(OpenWork {
        ledger,
        tasks,
        own,
        owned_elsewhere,
        unrepaired_tasks,
        defects,
        others,
    })
}
