//! The `tama sessions` command, extracted from the crate root: lists every
//! agent session record, whether its process is still there, and the hook
//! state it reported, merged with the machine-wide enforcement status.
//!
//! A record whose runtime never reported used to print `?/?`, which reads as
//! a broken session and says nothing about which of the two it is. The row
//! now says `no runtime report` and carries the process state beside it, so
//! the operator can tell a session that ended from one that is running
//! without publishing its hook state.

use std::path::{Path, PathBuf};

use super::args::{has, option_value};
use super::output::print_json;
use crate::enforcement;

pub(crate) mod capability;
mod records;
mod reload;
mod ungated;

/// The kernel's id for the process a record names. A record whose process
/// id names no single process (beyond the kernel's range, or the id that
/// `kill` reads as "every process") is the error naming it, never an answer.
fn process_id(pid: u64) -> Result<u32, String> {
    let id = u32::try_from(pid)
        .map_err(|error| format!("process id {pid} is beyond the kernel's range: {error}"))?;
    if id == 0 {
        return Err(format!("process id {pid} names no single process"));
    }
    Ok(id)
}

/// Is the process that wrote this record still there, asked of the kernel's
/// record of that one process as the consent walk asks it
/// (`owner_consent::exists`): a sandbox answers a signal probe with EPERM
/// whether the process exists or not.
fn running(pid: u64) -> Result<bool, String> {
    tama_hook_tools::ports::owner_consent::exists(process_id(pid)?)
}

/// Whether the kernel refuses this user the record of the process now at the
/// record's pid (`owner_consent::refused`): another user's process, which the
/// gates read as a later process under the agent's reused pid, so the record
/// names no live agent.
fn refused(pid: u64) -> Result<bool, String> {
    tama_hook_tools::ports::owner_consent::refused(process_id(pid)?)
}

const REMIND_USAGE: &str = "usage: tama sessions remind (--session <ID> | --default) [--text <SENTENCE> | --clear] [--json]";

/// `tama sessions remind`: the sentence the `remind-open-work` hook puts after
/// every tool result. `--session ID --text S` sets that session's sentence,
/// given after every call; `--default --text S` the machine-wide one, given
/// while Oko holds open work; `--clear` removes it; neither prints it.
fn remind(argv: &[String]) -> i32 {
    use tama_hooks::session_control::{default_reminder, session_reminder, write_reminder};
    let session = option_value(argv, "--session").filter(|id| !id.trim().is_empty());
    let machine_wide = has(argv, "--default");
    if session.is_some() == machine_wide {
        eprintln!("name exactly one of --session <ID> and --default\n{REMIND_USAGE}");
        return tama_core::exit::USAGE;
    }
    let text = option_value(argv, "--text").filter(|text| !text.trim().is_empty());
    let clear = has(argv, "--clear");
    if text.is_some() && clear {
        eprintln!("--text and --clear cannot be given together\n{REMIND_USAGE}");
        return tama_core::exit::USAGE;
    }
    if text.is_some() || clear {
        if let Err(error) = write_reminder(session.as_deref(), text.as_deref()) {
            eprintln!(
                "cannot write {}: {error}",
                tama_hooks::session_control::reminders_path().display()
            );
            return tama_core::exit::FAILURE;
        }
    }
    let current = match &session {
        Some(session) => session_reminder(session),
        None => default_reminder(),
    };
    let scope = match &session {
        Some(session) => session.clone(),
        None => "default".to_string(),
    };
    if has(argv, "--json") {
        print_json(&serde_json::json!({ "scope": scope, "sentence": current }));
    } else {
        match current {
            Some(sentence) => println!("{scope}: {sentence}"),
            None => println!("{scope}: no sentence set"),
        }
    }
    tama_core::exit::SUCCESS
}

/// `tama sessions self [--json]`: the agent session the calling process runs
/// under — the one OMP names (`PI_SESSION_ID`, else the header of the
/// transcript `PI_SESSION_FILE` names) when a record carries it, else the
/// one OMP names when its transcript's `parentSession` chain reaches a
/// session recorded at the agent process the caller runs under, else the
/// session whose recorded agent process is it or one of its ancestors;
/// `via` says which (`record`, `parentSession`, `process`). A process no
/// recorded session holds (a command the operator runs himself) is answered
/// with no session and the processes walked, and one several recorded
/// sessions share with no session named is answered with no session and
/// `ambiguous`, not refused; a register or process table that cannot be read
/// is the error.
fn calling(argv: &[String]) -> i32 {
    let reading = match tama_hook_tools::ports::owner_consent::read_session() {
        Ok(reading) => reading,
        Err(error) => {
            eprintln!("the agent session this process runs under cannot be read: {error}");
            return tama_core::exit::FAILURE;
        }
    };
    let (agent, session) = match &reading.holder {
        Some((agent, session)) => (Some(agent.as_str()), Some(session.as_str())),
        None => (None, None),
    };
    let via = reading.via.map(|via| via.word());
    let walked = &reading.walked;
    if has(argv, "--json") {
        print_json(&serde_json::json!({
            "agent": agent, "session": session, "via": via, "walked": walked,
            "ambiguous": reading.ambiguous,
        }));
        return tama_core::exit::SUCCESS;
    }
    match (agent, session, &reading.ambiguous) {
        (Some(agent), Some(session), _) => match via {
            Some(via) => println!("{session} ({agent}, via {via})"),
            None => println!("{session} ({agent})"),
        },
        (_, _, Some(ambiguous)) => println!("no session named: {ambiguous}"),
        _ => {
            let chain = walked
                .iter()
                .map(u32::to_string)
                .collect::<Vec<_>>()
                .join(" <- ");
            println!("no recorded agent session holds this process (processes {chain})");
        }
    }
    tama_core::exit::SUCCESS
}

pub fn main(argv: &[String], root: &Path) -> i32 {
    if let [_, words @ ..] = argv {
        if let [verb, ..] = words {
            match verb.as_str() {
                "capability" => return capability::main(words),
                "remind" => return remind(argv),
                "reload" => return reload::run(argv),
                "self" => return calling(argv),
                verb if !verb.starts_with('-') => {
                    eprintln!("unknown sessions command {verb:?}; expected capability, reload, remind, self, or listing options");
                    return tama_core::exit::USAGE;
                }
                _ => {}
            }
        }
    }
    let home = match option_value(argv, "--home") {
        Some(home) => PathBuf::from(home),
        None => match std::env::var_os("HOME").filter(|home| !home.is_empty()) {
            Some(home) => PathBuf::from(home),
            None => {
                eprintln!("HOME is not set and --home was not given, so the session-control directory cannot be located");
                return tama_core::exit::USAGE;
            }
        },
    };
    let control_dir = home.join("Library/Application Support/Tama/session-control");

    let sessions = match records::load(&control_dir) {
        Ok(sessions) => sessions,
        Err(error) => {
            eprintln!("{error}");
            return tama_core::exit::FAILURE;
        }
    };
    // An OMP whose pid and session no record names never loaded Tama's
    // adapter for that session: it runs ungated, and only a process that
    // loads the adapter gates it.
    let recorded: Vec<(u64, Option<String>)> = sessions
        .iter()
        .filter_map(|s| {
            let pid = s.get("pid").and_then(serde_json::Value::as_u64)?;
            let session = s.get("sessionId").and_then(serde_json::Value::as_str);
            Some((pid, session.map(str::to_owned)))
        })
        .collect();
    let ungated = match ungated::find(&home, &recorded) {
        Ok(ungated) => ungated,
        Err(error) => {
            eprintln!("which OMP processes run ungated cannot be read: {error}");
            return tama_core::exit::FAILURE;
        }
    };
    let machine_enforcement = match enforcement::status_for_home(root, std::path::Path::new(&home))
    {
        Ok(status) => status,
        Err(error) => {
            eprintln!("{error}");
            return tama_core::exit::FAILURE;
        }
    };
    enforcement::report_read_error(&machine_enforcement);
    let exit_code = if machine_enforcement.read_error.is_some() {
        tama_core::exit::FAILURE
    } else {
        tama_core::exit::SUCCESS
    };

    if has(argv, "--json") {
        print_json(&serde_json::json!({
            "machineEnforcement": &machine_enforcement,
            "sessions": sessions,
            "ungated": ungated,
        }));
    } else {
        println!("{}", enforcement::session_summary(&machine_enforcement));
        let mut live: Vec<&str> = Vec::new();
        let mut ended: Vec<&str> = Vec::new();
        let mut unusable: Vec<&str> = Vec::new();
        let mut silent: Vec<&str> = Vec::new();
        for s in &sessions {
            let (Some(agent), Some(session_id)) = (
                s.get("agentId").and_then(|v| v.as_str()),
                s.get("sessionId").and_then(|v| v.as_str()),
            ) else {
                eprintln!("a session record names no agentId or sessionId: {s}");
                continue;
            };
            let alive = s.get("processAlive").and_then(|v| v.as_bool());
            let refused = s.get("processRecordRefused").and_then(|v| v.as_bool()) == Some(true);
            let process = match alive {
                Some(true) if refused => {
                    ended.push(session_id);
                    "gone (its pid now runs another user's process)"
                }
                Some(true) => {
                    live.push(session_id);
                    "running"
                }
                Some(false) => {
                    ended.push(session_id);
                    "gone"
                }
                None => {
                    unusable.push(session_id);
                    "no usable pid"
                }
            };
            let globally_disabled =
                s.get("globallyDisabled").and_then(|v| v.as_bool()) == Some(true);
            let reported = s.get("runtimeReported").and_then(|v| v.as_bool()) == Some(true);
            let count = |field: &str| match s.get(field).and_then(|v| v.as_i64()) {
                Some(count) => count.to_string(),
                None => "no count".to_string(),
            };
            let hooks = if !reported {
                silent.push(session_id);
                "no runtime report".to_string()
            } else if globally_disabled {
                match s.get("enabledHookIds").and_then(|v| v.as_array()) {
                    Some(enabled) if enabled.is_empty() => "allowlist: empty".to_string(),
                    Some(enabled) => {
                        let names: Vec<&str> = enabled.iter().filter_map(|x| x.as_str()).collect();
                        format!("allowlist: {}", names.join(", "))
                    }
                    None => "allowlist: not recorded".to_string(),
                }
            } else {
                format!(
                    "{}/{}",
                    count("loadedHookCount"),
                    count("registeredHookCount")
                )
            };
            println!("{agent}\t{session_id}\t{process}\t{hooks}");
            if let Some(digest) = s["adapterDigest"].as_str() {
                println!("  adapter: {digest}");
            }
            if let Some(error) = s["lastReloadError"].as_str() {
                eprintln!("  {session_id}: last reload failed: {error}");
            }
        }
        for row in &ungated {
            println!("{}", row.said());
        }
        println!(
            "session records\t{}\trunning={}\tgone={}\tno-usable-pid={}\tno-runtime-report={}\tungated-omp={}",
            sessions.len(),
            live.len(),
            ended.len(),
            unusable.len(),
            silent.len(),
            ungated.len()
        );
    }
    exit_code
}
