//! Regex sources for `shared-hooks/block_hook_config_edits_without_consent.py`
//! (registry hook `block-hook-config-edits-without-consent`).
//!
//! Translation notes, all mechanical:
//!   * `re.IGNORECASE` becomes the inline `(?i)` flag.
//!   * Python's non-multiline `$` matches at the end of the text *or* just
//!     before a single trailing newline. The Rust `regex` crate has no
//!     lookahead and its `$` is end-of-text only, so every `$` is written
//!     `\n?\z`, which accepts the same two positions.
//!   * The character class `['\"]` is written `[\x27\x22]`: the same two
//!     characters, without putting a bare double quote inside the source.
//!
//! No pattern used a backreference or a lookaround, so nothing needed
//! restructuring.

use regex::Regex;

const PROTECTED_PATH: &str = concat!(
    r"(?i)(",
    r"(^|/)\.git/hooks(/|\n?\z)",
    r"|(^|/)\.githooks(/|\n?\z)",
    r"|(^|/)repo-githooks(/|\n?\z)",
    r"|(^|/)\.husky(/|\n?\z)",
    r"|(^|/)lefthook\.ya?ml\n?\z",
    r"|(^|/)\.pre-commit-config\.ya?ml\n?\z",
    r"|(^|/)\.claude/(settings[^/]*\.json|hooks(/|\n?\z))",
    r"|(^|/)\.codex/(hooks\.json|hooks(/|\n?\z))",
    r"|(^|/)\.omp/agent/hooks(/|\n?\z)",
    r"|(^|/)\.kimi-code/(config\.toml\n?\z|hooks(/|\n?\z))",
    r"|(^|/)\.shared-hooks(/|\n?\z)",
    r"|(^|/)tama/(shared-hooks|codex-hooks|claude-hooks|repo-githooks|src)(/|\n?\z)",
    r")",
);

/// The operator's break-glass controls: the emergency state file, its backup
/// directory, the per-session override files, and the commands that drive
/// them. Python spells the tail of each path as a lookahead; the Rust engine
/// has none, so the same one character is consumed instead, which for a
/// yes/no search is the same answer.
const OPERATOR_RECOVERY_PATH: &str = concat!(
    r"(?i)(",
    r"(^|/)Library/Application Support/Tama/hook-emergency-state\.json(\n?\z|[\s\x27\x22;])",
    r"|(^|/)Library/Application Support/Tama/emergency-backup(/|\n?\z|[\s\x27\x22;])",
    r"|(^|/)Library/Application Support/Tama/session-control/",
    r"[^/\s\x27\x22;]+\.override\.json(\n?\z|[\s\x27\x22;])",
    r")",
);
const OPERATOR_RECOVERY_COMMAND: &str = concat!(
    r"(?i)(^|[/\s])emergency_disable_hooks([\s\x27\x22;]|\n?\z)",
    r"|\bTAMA_EMERGENCY_ACTION\b",
);

const GIT_CONFIG_PATH: &str = r"(?i)(^|/)\.git/config\n?\z";

/// A justification registry, as a path and as it appears inside command text.
///
/// These files are DATA the authorization gates require an agent to write;
/// they are not hook source and not hook configuration. The name shape is the
/// rule rather than a list, because a list was written when there were two of
/// them and never grew when `test_justifications.json` and
/// `cua_justifications.json` arrived - so the gate that demands an entry in
/// one of those two demanded something nothing inside a session could add.
const JUSTIFICATION_REGISTRY_PATH: &str =
    r"(?i)(^|/)\.shared-hooks/[^/]*justifications?\.json\n?\z";
const JUSTIFICATION_REGISTRY_IN_COMMAND: &str =
    r"(?i)[^\s;&|<>()\x27\x22]*\.shared-hooks/[^/\s;&|<>()\x27\x22]*justifications?\.json";

/// `re.split` source: command word boundaries. Cutting a payload into
/// commands is `shell_text::commands`, which reads quotes; a regex cannot.
const COMMAND_TOKEN_SPLIT: &str = r"[\s;&|<>()]+";

/// The three envelopes a patch names its file in, from the one
/// declaration in [`super::patch_envelope`].
use super::patch_envelope;

/// Every compiled pattern the guard needs, built once per process.
pub struct Patterns {
    pub protected_path: Regex,
    pub justification_registry_path: Regex,
    pub justification_registry_in_command: Regex,
    pub git_config_path: Regex,
    pub command_token_split: Regex,
    pub patch_bracket: Regex,
    pub patch_file_header: Regex,
    pub patch_diff_header: Regex,
    pub operator_recovery_path: Regex,
    pub operator_recovery_command: Regex,
}

impl Patterns {
    /// A pattern that fails to compile is a defect in this file, not a payload
    /// the guard should silently wave through.
    pub fn compile() -> Self {
        let build = |source: &str| Regex::new(source).expect(source);
        Self {
            protected_path: build(PROTECTED_PATH),
            justification_registry_path: build(JUSTIFICATION_REGISTRY_PATH),
            justification_registry_in_command: build(JUSTIFICATION_REGISTRY_IN_COMMAND),
            git_config_path: build(GIT_CONFIG_PATH),
            command_token_split: build(COMMAND_TOKEN_SPLIT),
            patch_bracket: build(patch_envelope::BRACKET_HEADER),
            patch_file_header: build(&patch_envelope::file_header()),
            patch_diff_header: build(patch_envelope::DIFF_HEADER),
            operator_recovery_path: build(OPERATOR_RECOVERY_PATH),
            operator_recovery_command: build(OPERATOR_RECOVERY_COMMAND),
        }
    }
}
