//! Built-in rule definitions and additional operator-owned registry rows.
//! Rule matching belongs to the caller; this module describes the records
//! and reads their declared storage.

use serde_json::Value;

use super::{Rule, Target};
use crate::ports::python_stdlib::expanduser;

const REGISTRY_PATH: &str = "~/.shared-hooks/auto_rules.json";
const RULES_KEY: &str = "rules";
const ID_KEY: &str = "id";
/// What a refusal names a row by when the row records no id.
const NO_ID: &str = "(no id)";
const TARGET_KEY: &str = "target";
const PATTERN_KEY: &str = "pattern";
const MESSAGE_KEY: &str = "message";

/// Built-in policy definitions and their publication metadata.
pub(crate) const DEFAULTS: &[Rule] = &[
    Rule {
        id: "registry-as-markdown",
        added: "2026-06-09",
        target: Target::Path,
        pattern: "[Rr][Ee][Gg][Ii][Ss][Tt][Rr][Yy][^/]*\\.md$",
        message: "BLOCKED: Registries must be structured data (.json), never .md — write the \
                  registry as JSON instead.",
        why: "Tools consume registries as structured data; prose cannot supply that contract.",
    },
    Rule {
        id: "page-limited-manuscript",
        added: "2026-05-17",
        target: Target::Path,
        pattern: "paper_revised_35pageslimit\\.(tex|pdf)",
        message: "BLOCKED: Blocked: paper_revised_35pageslimit is a page-limited shared \
                  artifact. Verify page count vs the 35-page limit and confirm with the user \
                  before writing/merging.",
        why: "A shared page-limited artifact must satisfy its stated page limit before a change.",
    },
    Rule {
        id: "pseudo-extension-source",
        added: "2026-07-19",
        target: Target::Path,
        pattern: "\\.source$",
        message: "BLOCKED: pseudo-extension .source is forbidden. Write real modules \
                  (.js/.mjs/.ts/.py/...) with ordinary imports/exports, not source fragments \
                  glued back at runtime.",
        why: "Real language suffixes and ordinary imports let compilers and source checks \
              inspect the modules that will run.",
    },
];

/// The auto-rules registry: the one place the frustration detector writes
/// and the auto-rules gate reads.
pub(crate) fn registry_path() -> String {
    expanduser(REGISTRY_PATH)
}

fn target_of(value: &Value) -> Option<Target> {
    Target::named(value.get(TARGET_KEY).and_then(Value::as_str)?)
}

/// One row the registry adds: its id, what it reads, matches and says.
pub(super) struct Learned {
    pub(super) id: String,
    pub(super) target: Target,
    pub(super) pattern: String,
    pub(super) message: String,
}

/// The rows the registry adds. A registry that does not exist adds none; one
/// that cannot be read, is not JSON or has no rules array is an error naming
/// the file, never read as no rules, which would let every learned rule go
/// unenforced without a word.
pub(super) fn recorded(path: &str) -> Result<Vec<Learned>, String> {
    let text = match std::fs::read_to_string(path) {
        Ok(text) => text,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(Vec::new()),
        Err(error) => return Err(format!("cannot read the learned rules {path}: {error}")),
    };
    let doc = serde_json::from_str::<Value>(&text)
        .map_err(|error| format!("the learned rules {path} are not JSON: {error}"))?;
    let Some(Value::Array(rows)) = doc.get(RULES_KEY) else {
        return Err(format!(
            "the learned rules {path} hold no {RULES_KEY} array"
        ));
    };
    Ok(rows
        .iter()
        .filter_map(|row| {
            let target = target_of(row)?;
            let pattern = row.get(PATTERN_KEY).and_then(Value::as_str)?;
            let message = row.get(MESSAGE_KEY).and_then(Value::as_str)?;
            let id = match row.get(ID_KEY).and_then(Value::as_str) {
                Some(id) => id,
                None => NO_ID,
            };
            Some(Learned {
                id: id.to_string(),
                target,
                pattern: pattern.to_string(),
                message: message.to_string(),
            })
        })
        .collect())
}
