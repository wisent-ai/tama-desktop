//! Handing one prompt to the feedback bridge, without waiting for it.
//!
//! Both entry points that see an owner prompt call this: the legacy
//! per-provider runner, and the shared runtime the providers talk to now. A
//! runtime that does not hands no prompt to the bridge, so nothing is ever
//! contested and the repair queue stays empty however often hooks block.
//!
//! The child is the running executable with the `adaptive-bridge` argument, so
//! whichever binary calls this has to route that argument to `bridge::main`.
//! A failure never changes a verdict — feedback attribution may not — but it
//! is said on stderr with its cause: a silent one would leave the repair
//! queue empty with no word about why. The bridge outlives the dispatch that
//! started it.

use std::io::Write;
use std::os::unix::process::CommandExt;
use std::process::{Command, Stdio};

pub fn dispatch(normalized: &str) {
    let attempt = || -> std::io::Result<()> {
        let exe = std::env::current_exe()?;
        let mut child = unsafe {
            Command::new(exe)
                .arg("adaptive-bridge")
                .stdin(Stdio::piped())
                .stdout(Stdio::null())
                .stderr(Stdio::null())
                .pre_exec(|| {
                    detach_session();
                    Ok(())
                })
                .spawn()?
        };
        if let Some(mut stdin) = child.stdin.take() {
            stdin.write_all(normalized.as_bytes())?;
        }
        Ok(())
    };
    if let Err(error) = attempt() {
        eprintln!("tama: the feedback bridge was not handed this prompt: {error}");
    }
}

extern "C" {
    fn setsid() -> i32;
}

fn detach_session() {
    unsafe {
        setsid();
    }
}
