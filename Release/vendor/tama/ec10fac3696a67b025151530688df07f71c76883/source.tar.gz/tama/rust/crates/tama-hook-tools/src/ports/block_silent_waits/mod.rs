//! Decision half of `tama hook block-silent-waits` (registry hook
//! `block-silent-waits`).
//!
//! A program that waits on the network, a child process, a lock or a
//! connection without a word cannot be told from one that is stuck, nor
//! the thing it is stuck on: agents and the operator watched commands stand
//! still for hours. The operator's rule is that no command waits silently:
//! every wait goes through the program's one wait mechanism (`stado::wait`
//! in Stado, `crate::wait` in Oko, the shared `stado_wait` crate in consumers),
//! which says on stderr what it waits for, where and since when. This gate
//! judges the whole Rust file as the write leaves it — a hashline section or
//! a string edit replayed on the file, a written file's content — and
//! refuses a blocking call (`constructs.json`) that is not an argument of a
//! call to that mechanism, nor in the body of a function that takes the
//! caller's open wait (the mechanism's `Waiting` handle) as a parameter,
//! whoever wrote it: a lock taken inside `wait::blocking` passes, a bare one
//! does not, and a silent wait a file already held is refused on its next
//! edit until it is moved. A write whose resulting file cannot be rebuilt is
//! refused with the cause, never judged by its added fragment.

use std::sync::LazyLock;

use regex::Regex;
use serde::Deserialize;
use serde_json::Value;

use crate::ports::check_numeric_literals_payload::path_texts;
use crate::ports::tool_vocabulary::Call;

/// The files this gate reads: Rust sources.
const RUST: &str = ".rs";
/// The directory a repository's tests live in (`tests/<area>/`). A test
/// drives the product from outside and waits for it as its caller; the
/// program's own waits are what must say what they wait on.
const TESTS: &str = "tests";

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Construct {
    pattern: String,
    name: String,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Declared {
    #[allow(dead_code)]
    why: String,
    mechanism: String,
    handle: String,
    constructs: Vec<Construct>,
}

struct Compiled {
    mechanism: Regex,
    handle: Regex,
    constructs: Vec<(Regex, String)>,
}

static DECLARED: LazyLock<Compiled> = LazyLock::new(|| {
    let declared: Declared = serde_json::from_str(include_str!("constructs.json"))
        .expect("block_silent_waits/constructs.json is the gate's own data and must parse");
    Compiled {
        mechanism: Regex::new(&declared.mechanism)
            .expect("the declared mechanism pattern compiles"),
        handle: Regex::new(&declared.handle).expect("the declared wait handle pattern compiles"),
        constructs: declared
            .constructs
            .into_iter()
            .map(|construct| {
                (
                    Regex::new(&construct.pattern).expect("every constructs.json pattern compiles"),
                    construct.name,
                )
            })
            .collect(),
    }
});

/// Whether the call at byte `at` of `added` is an argument of a call to
/// the wait mechanism: walking back, every parenthesis opened and not
/// closed before `at` encloses it, and one of those openers is a
/// `wait::<verb>(`.
fn through_mechanism(added: &str, at: usize) -> bool {
    let before = &added[..at];
    let mut closed = Vec::new();
    for (index, character) in before.char_indices().rev() {
        match character {
            ')' => closed.push(index),
            '(' if closed.pop().is_none() && DECLARED.mechanism.is_match(&before[..index]) => {
                return true
            }
            _ => {}
        }
    }
    false
}

/// Whether the call at byte `at` of `text` lies in the body of a function
/// whose parameters take the caller's open wait (the mechanism's handle):
/// the caller announced the wait before calling, and the function runs
/// inside it. A function that returns a handle without taking one opens a
/// wait of its own and is judged like any other.
fn inside_handed_wait(text: &str, at: usize) -> bool {
    let before = &text[..at];
    let Some(function) = FUNCTION.find_iter(before).last() else {
        return false;
    };
    let Some(body) = before[function.start()..].find('{') else {
        return false;
    };
    let signature = &before[function.start()..function.start() + body];
    signature
        .split("->")
        .next()
        .is_some_and(|parameters| DECLARED.handle.is_match(parameters))
}

/// A Rust function's opening: `fn name`.
static FUNCTION: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r"\bfn\s+[A-Za-z_][A-Za-z0-9_]*").expect("the function pattern compiles")
});

/// The whole line of `added` that holds byte `at`.
fn line_at(added: &str, at: usize) -> String {
    let start = added[..at]
        .rsplit('\n')
        .next()
        .into_iter()
        .collect::<String>();
    let end = added[at..]
        .split('\n')
        .next()
        .into_iter()
        .collect::<String>();
    format!("{start}{end}").trim().to_string()
}

/// Every silent wait `text`, the file at `path` as the write leaves it,
/// carries: (construct, its line). A file under a `tests` directory is not
/// read.
pub fn findings(path: &str, text: &str) -> Vec<(String, String)> {
    if !path.ends_with(RUST) || path.split('/').any(|part| part == TESTS) {
        return Vec::new();
    }
    let mut found = Vec::new();
    for (pattern, name) in &DECLARED.constructs {
        for call in pattern.find_iter(text) {
            if !through_mechanism(text, call.start()) && !inside_handed_wait(text, call.start()) {
                found.push((name.clone(), line_at(text, call.start())));
            }
        }
    }
    found
}

/// Why this write is refused, if it is: the file it leaves holds a wait
/// that says nothing, or the file it leaves cannot be rebuilt to judge it.
pub fn evaluate(payload: &Value) -> Option<String> {
    let call = Call::of(payload);
    let input = call.input()?;
    let texts = match path_texts(input, call.session_cwd()) {
        Ok(texts) => texts,
        Err(error) => {
            return Some(format!(
                "block-silent-waits: BLOCKED: the file this write leaves cannot be rebuilt to judge it: {error}"
            ))
        }
    };
    let mut lines = Vec::new();
    for (path, text) in texts {
        for (construct, said) in findings(&path, &text) {
            lines.push(format!("  {path}: {construct}: {said}"));
        }
    }
    if lines.is_empty() {
        return None;
    }
    Some(format!(
        "block-silent-waits: BLOCKED: the file this write leaves holds a wait that says nothing while it waits, whoever wrote it:\n{}\n\
         Make the call an argument of the program's wait mechanism — `stado::wait::{{until, blocking, send}}` in \
         Stado, `crate::wait::blocking` in Oko, or the shared `stado_wait::blocking` crate API — so it writes on stderr what it waits for, where and since when \
         before it waits, and how it ended. Files under tests/ are not read. The constructs are declared in \
         block_silent_waits/constructs.json; the line format is on Stado's Machine Interface page.",
        lines.join("\n")
    ))
}
