//! Whether a shell line changes externally owned source.
//!
//! The protected place is externally owned source, as `provenance` reads a
//! path: dependency directories and forks. Where the command reaches it and
//! whether the command changes it are the shared shell reading
//! ([`crate::ports::shell_changes`]): a redirection into it is refused by
//! the shell's grammar, and any other reach is judged by a model.

use super::provenance;
use crate::ports::shell_changes;
use std::path::Path;

const TAG: &str = "block-external-source-edits";
/// The schema the judge's answer is kept under.
const JUDGEMENT: &str = "external_source_change";

pub(super) fn refusal(command: &str, initial_cwd: &Path) -> Option<String> {
    let place = |path: &Path, cwd: &Path| provenance::refusal(path, cwd);
    match shell_changes::reach(command, initial_cwd, &place) {
        Ok(reached) => shell_changes::judged(TAG, JUDGEMENT, command, &reached),
        Err(reason) => Some(reason),
    }
}
