//! The product names of the workspace: what a vault item named after a
//! product carries in the open, since the product's own site and release
//! already print it.

use std::collections::BTreeSet;

use serde_json::Value;

use super::names::{expand, RELEASE_MANIFEST};
use crate::ports::block_off_task_work::WORKSPACE_HOME_RELATIVE;

/// The repositories of the workspace, by directory name, and the release
/// product each declares in its `.wisent-release.json` (`weles-worker` for
/// Weles). A vault item named after either carries that product's own name,
/// which its public site and its release already print.
pub(crate) fn product_names(unread: &mut Vec<String>) -> BTreeSet<String> {
    let root = expand(&format!("~/{WORKSPACE_HOME_RELATIVE}"));
    let mut names = BTreeSet::new();
    let entries = match std::fs::read_dir(&root) {
        Ok(entries) => entries,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return names,
        Err(error) => {
            unread.push(format!(
                "list product workspace {}: {error}",
                root.display()
            ));
            return names;
        }
    };
    for entry in entries {
        let entry = match entry {
            Ok(entry) => entry,
            Err(error) => {
                unread.push(format!("read product entry in {}: {error}", root.display()));
                continue;
            }
        };
        match std::fs::metadata(entry.path()) {
            Ok(metadata) if !metadata.is_dir() => continue,
            Ok(_) => {}
            Err(error) => {
                unread.push(format!(
                    "inspect product entry {}: {error}",
                    entry.path().display()
                ));
                continue;
            }
        }
        if let Ok(name) = entry.file_name().into_string() {
            names.insert(name.to_lowercase());
        }
        let path = entry.path().join(RELEASE_MANIFEST);
        let bytes = match std::fs::read(&path) {
            Ok(bytes) => bytes,
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => continue,
            Err(error) => {
                unread.push(format!(
                    "read product declaration {}: {error}",
                    path.display()
                ));
                continue;
            }
        };
        let declared: Value = match serde_json::from_slice(&bytes) {
            Ok(declared) => declared,
            Err(error) => {
                unread.push(format!(
                    "decode product declaration {}: {error}",
                    path.display()
                ));
                continue;
            }
        };
        if let Some(product) = declared.get("product").and_then(Value::as_str) {
            names.insert(product.to_lowercase());
        }
    }
    names
}
