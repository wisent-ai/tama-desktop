//! Word lists written as named constants: each word bound to a name of its
//! own (`const WRITE_TOOL: &str = "write";`) and the names used together as
//! one class — a collection of the names (`&[WRITE_TOOL, EDIT_TOOL]`), the
//! arms of a pattern joined with `|` (`matches!(tool, WRITE_TOOL |
//! EDIT_TOOL)`), or a chain comparing one input with them (`tool ==
//! WRITE_TOOL || tool == EDIT_TOOL`). Moving a list's words into names
//! changes how it is spelled, not what it decides, so `tama vocabulary
//! report` counts these sets with the words the names hold.
//!
//! Within one file, a name bound to two different words is a variable rather
//! than a word and is left out, and a collection or pattern that also holds a
//! name bound to no word is not a set of words. Across a repository,
//! [`word_bindings`] and [`named_decisions`] let a report follow a name from
//! the file that binds it to every file that decides by it.

use std::collections::BTreeMap;
use std::sync::LazyLock;

use regex::Regex;

use super::super::transport_common as common;
use super::data;
use super::finder::{is_word, line_of};
use super::is_list;

const NAME: &str = "name";
const QUOTED: &str = "quoted";
const LAST: &str = "last";
const LEFT: &str = "left";
const LEFT_NAME: &str = "left_name";
const RIGHT: &str = "right";
const RIGHT_NAME: &str = "right_name";
const QUOTES: &[char] = &['"', '\''];

/// A name bound to one quoted literal and nothing else on its line, after
/// whatever lowercase keywords the language declares it with (`pub(crate)
/// const`, `export const`, `static`, `let`, or none in Python and Go).
static BINDING: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(
        "(?m)^[ \\t]*(?:[a-z]+(?:\\([^)\\n]*\\))?[ \\t]+)*(?P<name>[A-Za-z_$][\\w$]*)[ \\t]*(?::[^=\\n]+)?=[ \\t]*(?P<quoted>\"(?:[^\"\\\\\\n]|\\\\.)*\"|'(?:[^'\\\\\\n]|\\\\.)*')[ \\t]*;?[ \\t]*$",
    )
});
/// One name, possibly reached through a module or an object
/// (`tool_vocabulary::WRITE_TOOL`, `Tools.WRITE`); its last segment is `last`.
static PATH: LazyLock<Regex> = LazyLock::new(|| {
    common::compile("(?:[A-Za-z_$][\\w$]*(?:::|\\.))*(?P<last>[A-Za-z_$][\\w$]*)")
});
/// A bracketed collection of two or more names, borrowed or not.
static COLLECTION: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(
        "\\[\\s*&?\\s*(?:[A-Za-z_$][\\w$]*(?:::|\\.))*[A-Za-z_$][\\w$]*(?:\\s*,\\s*&?\\s*(?:[A-Za-z_$][\\w$]*(?:::|\\.))*[A-Za-z_$][\\w$]*)+\\s*,?\\s*\\]",
    )
});
/// Two or more names joined by single `|`: the arms of a pattern.
static PATTERN: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(
        "(?:[A-Za-z_$][\\w$]*(?:::|\\.))*[A-Za-z_$][\\w$]*(?:\\s*\\|\\s*(?:[A-Za-z_$][\\w$]*(?:::|\\.))*[A-Za-z_$][\\w$]*)+",
    )
});
/// One name compared with another by `==`, `!=`, `===` or `!==`.
static COMPARED: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(
        "(?P<left>(?:[A-Za-z_$][\\w$]*(?:::|\\.))*(?P<left_name>[A-Za-z_$][\\w$]*))\\s*[=!]==?\\s*(?P<right>(?:[A-Za-z_$][\\w$]*(?:::|\\.))*(?P<right_name>[A-Za-z_$][\\w$]*))",
    )
});
/// A collection asked whether it holds one name: `.contains(NAME)` or
/// `.contains(&NAME)`.
static CONTAINED: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(
        "\\.contains\\(\\s*&?\\s*(?P<path>(?:[A-Za-z_$][\\w$]*(?:::|\\.))*[A-Za-z_$][\\w$]*)\\s*\\)",
    )
});
const CONTAINED_PATH: &str = "path";

/// Every name in `text` bound to exactly one word.
fn bindings(text: &str) -> BTreeMap<String, String> {
    let mut held: BTreeMap<String, Option<String>> = BTreeMap::new();
    for caps in BINDING.captures_iter(text) {
        let (Some(name), Some(quoted)) = (caps.name(NAME), caps.name(QUOTED)) else {
            continue;
        };
        let word = quoted.as_str().trim_matches(QUOTES).to_string();
        let entry = held
            .entry(name.as_str().to_string())
            .or_insert_with(|| Some(word.clone()));
        if entry.as_deref() != Some(word.as_str()) {
            *entry = None;
        }
    }
    held.into_iter()
        .filter_map(|(name, word)| Some((name, word.filter(|word| is_word(word))?)))
        .collect()
}

/// The words of a run whose every name is bound to one, when they are two or
/// more different words.
fn bound_words(run: &str, bound: &BTreeMap<String, String>) -> Option<Vec<String>> {
    let mut words: Vec<String> = Vec::new();
    for caps in PATH.captures_iter(run) {
        let word = bound.get(caps.name(LAST)?.as_str())?;
        if !words.contains(word) {
            words.push(word.clone());
        }
    }
    is_list(&words).then_some(words)
}

/// Every input a line compares with two or more bound names, as (line,
/// words); the words are grouped by the expression on the other side, as
/// `compared.rs` groups quoted words.
fn comparisons(text: &str, bound: &BTreeMap<String, String>) -> Vec<(usize, Vec<String>)> {
    let mut grouped: BTreeMap<(usize, String), Vec<String>> = BTreeMap::new();
    for caps in COMPARED.captures_iter(text) {
        let (Some(left), Some(left_name), Some(right), Some(right_name)) = (
            caps.name(LEFT),
            caps.name(LEFT_NAME),
            caps.name(RIGHT),
            caps.name(RIGHT_NAME),
        ) else {
            continue;
        };
        let (input, word) = match bound.get(right_name.as_str()) {
            Some(word) => (left.as_str(), word),
            None => match bound.get(left_name.as_str()) {
                Some(word) => (right.as_str(), word),
                None => continue,
            },
        };
        let words = grouped
            .entry((line_of(text, left.start()), input.to_string()))
            .or_default();
        if !words.contains(word) {
            words.push(word.clone());
        }
    }
    grouped
        .into_iter()
        .filter(|(_, words)| is_list(words))
        .map(|((line, _), words)| (line, words))
        .collect()
}

/// Every set of named word constants used together in one code file, as
/// (line, words). A data file binds no names and yields none.
pub fn named_word_sets(path: &str, text: &str) -> Vec<(usize, Vec<String>)> {
    if data::is_data(path) {
        return Vec::new();
    }
    let bound = bindings(text);
    if bound.is_empty() {
        return Vec::new();
    }
    let mut found: Vec<(usize, Vec<String>)> = [&*COLLECTION, &*PATTERN]
        .into_iter()
        .flat_map(|shape| shape.find_iter(text))
        .filter_map(|run| {
            Some((
                line_of(text, run.start()),
                bound_words(run.as_str(), &bound)?,
            ))
        })
        .collect();
    found.extend(comparisons(text, &bound));
    found.sort();
    found
}

/// Every name a code file binds to exactly one word; a data file binds none.
pub fn word_bindings(path: &str, text: &str) -> BTreeMap<String, String> {
    if data::is_data(path) {
        return BTreeMap::new();
    }
    bindings(text)
}

/// The bound name a path ends in, if `bound` holds a word for it.
fn bound_name(path: &str, bound: &BTreeMap<String, String>) -> Option<String> {
    let last = PATH.captures(path)?.name(LAST)?.as_str().to_string();
    bound.contains_key(&last).then_some(last)
}

/// Every place a code file decides by a name `bound` holds a word for,
/// whichever file bound it: compared with `==`, `!=`, `===` or `!==`, an
/// arm of a `|` pattern, a member of a bracketed collection, or asked for by
/// `.contains`. As (line, name), one entry per name and line.
pub fn named_decisions(
    path: &str,
    text: &str,
    bound: &BTreeMap<String, String>,
) -> Vec<(usize, String)> {
    if data::is_data(path) || bound.is_empty() {
        return Vec::new();
    }
    let mut found: Vec<(usize, String)> = Vec::new();
    for run in COLLECTION.find_iter(text).chain(PATTERN.find_iter(text)) {
        let line = line_of(text, run.start());
        for caps in PATH.captures_iter(run.as_str()) {
            let Some(last) = caps.name(LAST) else {
                continue;
            };
            if bound.contains_key(last.as_str()) {
                found.push((line, last.as_str().to_string()));
            }
        }
    }
    for caps in COMPARED.captures_iter(text) {
        let (Some(left), Some(right)) = (caps.name(LEFT), caps.name(RIGHT)) else {
            continue;
        };
        let line = line_of(text, left.start());
        for side in [left.as_str(), right.as_str()] {
            if let Some(name) = bound_name(side, bound) {
                found.push((line, name));
            }
        }
    }
    for caps in CONTAINED.captures_iter(text) {
        let Some(path) = caps.name(CONTAINED_PATH) else {
            continue;
        };
        if let Some(name) = bound_name(path.as_str(), bound) {
            found.push((line_of(text, path.start()), name));
        }
    }
    found.sort();
    found.dedup();
    found
}
