//! Word lists written as comparisons rather than collections: a chain of
//! `==` against quoted words, and the arms of a `matches!` or `match`
//! pattern joined with `|`. Each decides by keyword as surely as a list
//! bound to a name does, and `finder.rs` had reached the file-size limit.

use std::collections::BTreeSet;
use std::sync::LazyLock;

use regex::Regex;
use tree_sitter::Node;

use super::super::transport_common as common;
use super::finder::{is_script, is_word, line_of};
use super::is_list;

/// A quoted word compared with `==`, `!=`, `===` or `!==`, on either side,
/// with the expression on the other side when there is one: a name or
/// property path (`payload.event`, `self.kind`, `item?.source`), a call on it
/// (`left.kind()`, `node.kind(cursor)`) or a subscript of it
/// (`after["current"]["status"]`, `receipt[state]`). A call or subscript is a
/// different input from its neighbour on the line; dropping it made two typed
/// fields read as one unnamed input compared with a vocabulary.
static COMPARED: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(
        "(?P<left>[A-Za-z_$][\\w$]*(?:\\??\\.[A-Za-z_$][\\w$]*|\\([^()\\n]*\\)|\\[[^\\[\\]\\n]*\\])*)?\\s*[=!]==?\\s*(?:\"(?P<after_double>(?:[^\"\\\\]|\\\\.)*)\"|'(?P<after_single>(?:[^'\\\\]|\\\\.)*)')|(?:\"(?P<before_double>(?:[^\"\\\\]|\\\\.)*)\"|'(?P<before_single>(?:[^'\\\\]|\\\\.)*)')\\s*[=!]==?\\s*(?P<right>[A-Za-z_$][\\w$]*(?:\\??\\.[A-Za-z_$][\\w$]*|\\([^()\\n]*\\)|\\[[^\\[\\]\\n]*\\])*)?",
    )
});
/// Quoted literals joined by `|` outside any string: the arms of a
/// `matches!` or `match` pattern, or a `case "a" | "b"` in Swift.
static PATTERN: LazyLock<Regex> = LazyLock::new(|| {
    common::compile("(?:\"(?:[^\"\\\\]|\\\\.)*\"\\s*\\|\\s*)+\"(?:[^\"\\\\]|\\\\.)*\"")
});
/// One double-quoted literal of a pattern, its body named.
static PATTERN_WORD: LazyLock<Regex> =
    LazyLock::new(|| common::compile("\"(?P<word>(?:[^\"\\\\]|\\\\.)*)\""));

/// Every run of words a line compares one input with, as (line, words):
/// `word == "okay" || word == "sure"` decides by keyword as surely as a
/// list does, one `==` per word. A line comparing one word with an input is
/// not a list, and neither is a line comparing different inputs with one word
/// each (`event !== "start" || source !== "compact"` checks two fields of a
/// protocol record): the words are grouped by the name compared with them, and
/// a word compared with no name joins the other unnamed ones on its line.
pub(super) fn word_comparisons(path: &str, text: &str) -> Vec<(usize, Vec<String>)> {
    let typed = typeof_operands(path, text);
    let mut by_line: std::collections::BTreeMap<(usize, Option<String>), Vec<String>> =
        Default::default();
    for found in COMPARED.find_iter(text) {
        let Some(compared) = COMPARED.captures(found.as_str()) else {
            continue;
        };
        let Some(literal) = [
            "after_double",
            "after_single",
            "before_double",
            "before_single",
        ]
        .into_iter()
        .find_map(|name| compared.name(name)) else {
            continue;
        };
        // The literal's opening quote, where the syntax tree starts its node.
        let quote = found.as_str()[..literal.start()]
            .chars()
            .next_back()
            .map(char::len_utf8);
        let opening = quote.map(|width| found.start() + literal.start() - width);
        if opening.is_some_and(|at| typed.contains(&at)) {
            continue;
        }
        let word = literal.as_str().to_owned();
        let operand = compared
            .name("left")
            .or_else(|| compared.name("right"))
            .map(|name| name.as_str().to_owned());
        if is_word(&word) {
            by_line
                .entry((line_of(text, found.start()), operand))
                .or_default()
                .push(word);
        }
    }
    by_line
        .into_iter()
        .filter(|(_, words)| is_list(words))
        .map(|((line, _), words)| (line, words))
        .collect()
}

/// The byte offsets of the string literals a script compares with the result
/// of `typeof`. The language defines those values, so a chain of them reads a
/// value's type; it does not choose by keyword. Read from the JavaScript
/// grammar's syntax tree, in which TypeScript's comparisons parse too; a
/// region the grammar cannot read yields no such operand and is judged as
/// before.
fn typeof_operands(path: &str, text: &str) -> BTreeSet<usize> {
    let mut found = BTreeSet::new();
    if !is_script(path) {
        return found;
    }
    let mut parser = tree_sitter::Parser::new();
    parser
        .set_language(&tree_sitter_javascript::LANGUAGE.into())
        .expect("the compiled JavaScript grammar matches tree-sitter");
    let Some(tree) = parser.parse(text, None) else {
        return found;
    };
    let mut cursor = tree.walk();
    loop {
        let node = cursor.node();
        if let (Some(left), Some(right)) = (
            node.child_by_field_name("left"),
            node.child_by_field_name("right"),
        ) {
            for (operand, other) in [(left, right), (right, left)] {
                if operand.kind() == "string" && is_typeof(other) {
                    found.insert(operand.start_byte());
                }
            }
        }
        if cursor.goto_first_child() {
            continue;
        }
        while !cursor.goto_next_sibling() {
            if !cursor.goto_parent() {
                return found;
            }
        }
    }
}

/// Whether `node` is a `typeof` expression.
fn is_typeof(node: Node<'_>) -> bool {
    node.kind() == "unary_expression"
        && node
            .child_by_field_name("operator")
            .is_some_and(|operator| operator.kind() == "typeof")
}

/// Every pattern of words in `text`, as (line, words): quoted literals an
/// arm joins with `|` (a `matches!` whose arms are three quoted words, or the
/// arm of a `match` before its `=>`), two or more of them, every one a word.
/// The same `|` between quoted literals elsewhere — a type that names the
/// values a field may hold, `kind: "task" | "detail"` — declares a shape and
/// matches nothing, so it is not judged here.
pub(super) fn word_patterns(text: &str) -> Vec<(usize, Vec<String>)> {
    let mut found = Vec::new();
    for pattern in PATTERN.find_iter(text) {
        let line = line_of(text, pattern.start());
        let before = text[..pattern.start()].trim_end();
        let after = text[pattern.end()..].trim_start();
        let matched_in_macro = before.ends_with(',')
            && text[..pattern.start()]
                .rsplit('\n')
                .next()
                .is_some_and(|same_line| same_line.contains("matches!("));
        let arm = after.starts_with("=>") || after.starts_with("if ") && after.contains("=>");
        if !matched_in_macro && !arm {
            continue;
        }
        let words: Vec<String> = PATTERN_WORD
            .captures_iter(pattern.as_str())
            .filter_map(|literal| literal.name("word"))
            .map(|word| word.as_str().to_owned())
            .collect();
        if is_list(&words) && words.iter().all(|word| is_word(word)) {
            found.push((line, words));
        }
    }
    found
}
