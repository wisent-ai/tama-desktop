//! The prose of a text: its plain words outside code, and the lines of an
//! answer the agent wrote itself.

/// The fence that opens and closes a block of code in Markdown.
const FENCE: &str = "```";
/// The mark around a code span.
const SPAN: char = '`';

/// The plain words of `text` outside fenced blocks and code spans: the
/// tokens made of letters alone, surrounding punctuation trimmed.
pub(super) fn words(text: &str) -> Vec<String> {
    let mut words = Vec::new();
    let mut in_block = false;
    for block in text.split(FENCE) {
        if !in_block {
            let mut in_span = false;
            for piece in block.split(SPAN) {
                if !in_span {
                    words.extend(letter_words(piece));
                }
                in_span = !in_span;
            }
        }
        in_block = !in_block;
    }
    words
}

/// The tokens of `piece` made of letters alone.
fn letter_words(piece: &str) -> impl Iterator<Item = String> + '_ {
    piece.split_whitespace().filter_map(|token| {
        let word = token.trim_matches(|character: char| !character.is_alphabetic());
        (!word.is_empty() && word.chars().all(char::is_alphabetic)).then(|| word.to_string())
    })
}

/// Whether `word` carries a letter beyond ASCII.
pub(super) fn beyond_ascii(word: &str) -> bool {
    !word.is_ascii()
}

/// The lines of `answer` the operator did not write himself: a line found,
/// whatever its case, in one of his `messages` is his sentence repeated
/// back, not the agent's language.
pub(super) fn own_lines(answer: &str, messages: &[String]) -> String {
    let said: Vec<String> = messages
        .iter()
        .map(|message| message.to_lowercase())
        .collect();
    answer
        .lines()
        .filter(|line| {
            let line = line.trim().to_lowercase();
            line.is_empty() || !said.iter().any(|message| message.contains(&line))
        })
        .collect::<Vec<_>>()
        .join("\n")
}
