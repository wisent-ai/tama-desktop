//! A known defect is told to the operator once per session, not in every
//! answer after that.
//!
//! A session can end answer after answer with the same blocker section,
//! each time naming the defect identifiers, which is exactly what the first
//! rule of this gate asks for, so nothing refuses it. Naming a defect makes
//! a report findable; naming it again in the next answer is the same report
//! again.
//! Once an answer the operator received has named a registered defect, a
//! later answer's blocker section may not name it: the register and the
//! earlier answer already hold it.

use std::collections::BTreeSet;

use serde_json::Value;

use super::register::{short_id, DEFECTS_KEY, SHORT_ID_LENGTH};
use crate::ports::block_unsearched_blocker_claim::{content_text, nested_message, records};

const ROLE_KEY: &str = "role";
const ASSISTANT_ROLE: &str = "assistant";
const USER_ROLE: &str = "user";

/// Every defect identifier the register holds, as Oko prints it. A register
/// document without its defects list is the error naming it: read as empty,
/// no defect could ever be found retold.
pub(super) fn registered_ids(document: &Value) -> Result<BTreeSet<String>, String> {
    match document.get(DEFECTS_KEY).and_then(Value::as_array) {
        Some(defects) => Ok(defects.iter().filter_map(short_id).collect()),
        None => Err(format!(
            "the defect register answered without its {DEFECTS_KEY} list"
        )),
    }
}

/// The registered defect identifiers a text names.
pub(super) fn named(text: &str, registered: &BTreeSet<String>) -> BTreeSet<String> {
    text.split(|letter: char| !letter.is_ascii_alphanumeric())
        .filter(|word| word.len() == SHORT_ID_LENGTH)
        .map(str::to_ascii_lowercase)
        .filter(|word| registered.contains(word))
        .collect()
}

/// The answers the operator received earlier in this session: the last
/// assistant prose before each of his messages. A transcript that cannot be
/// read is refused naming it.
pub(super) fn earlier_answers(payload: &Value) -> Result<Vec<String>, String> {
    let mut answers = Vec::new();
    let mut last = String::new();
    for record in records(payload)? {
        // A record either carries its message nested (one harness's shape)
        // or is the message itself (the other's).
        let holder = match nested_message(&record) {
            Some(message) => message,
            None => &record,
        };
        match holder.get(ROLE_KEY).and_then(Value::as_str) {
            Some(ASSISTANT_ROLE) => {
                if let Some(text) = content_text(holder).filter(|text| !text.trim().is_empty()) {
                    last = text;
                }
            }
            Some(USER_ROLE) if !last.is_empty() => answers.push(std::mem::take(&mut last)),
            _ => {}
        }
    }
    Ok(answers)
}

/// The refusal for a blocker section that names a defect an earlier answer
/// already told, or nothing.
pub(super) fn retold(told: &str, payload: &Value, document: &Value) -> Option<String> {
    let registered = match registered_ids(document) {
        Ok(registered) => registered,
        Err(error) => {
            return Some(format!(
                "block-repeated-blocker: TAMA_HOOK_INFRASTRUCTURE: whether this answer retells a \
                 defect cannot be judged: {error}"
            ))
        }
    };
    let now = named(told, &registered);
    if now.is_empty() {
        return None;
    }
    let earlier = match earlier_answers(payload) {
        Ok(earlier) => earlier,
        Err(error) => {
            return Some(format!(
                "block-repeated-blocker: TAMA_HOOK_INFRASTRUCTURE: the answers this session \
                 already gave cannot be read: {error}"
            ))
        }
    };
    let before: BTreeSet<String> = earlier
        .iter()
        .flat_map(|answer| named(answer, &registered))
        .collect();
    let repeated: Vec<&String> = now.intersection(&before).collect();
    if repeated.is_empty() {
        return None;
    }
    let list = repeated
        .iter()
        .map(|id| id.as_str())
        .collect::<Vec<_>>()
        .join(", ");
    Some(format!(
        "block-repeated-blocker: this answer's blocker section names defect(s) {list}, which an \
         earlier answer in this session already told the operator. He has it; the register holds \
         it. Telling him again is the report he has been handed in more than a thousand sessions. \
         Leave it out and answer with what this turn did."
    ))
}
