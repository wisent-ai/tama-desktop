//! Files a session's own commands wrote. A generator the session runs
//! through its shell (a lockfile resolver, a code generator, a tool that
//! rewrites the lockfiles of many checkouts from one place) changes files no
//! edit receipt records. Such a file is the session's when the file was last
//! changed while one of the session's successful shell commands ran: between
//! the record of the call and the record of its result, as the transcript
//! times them and the file system times the file. Where the command ran does
//! not decide it, since one command writes files of other checkouts; whether
//! anyone else could have written the file then does. A file changed while
//! another running session had a command running, or edited that file, is
//! no one session's (`others`).

use std::fs::File;
use std::io::{BufRead, BufReader};
use std::path::Path;
use std::time::UNIX_EPOCH;

use serde_json::Value;

use crate::ports::tool_vocabulary::{Call, TOOL_INPUT_KEY};

/// One successful shell command of the session: the times of its call and
/// result records in milliseconds since the epoch.
struct Ran {
    pub called: i64,
    pub answered: i64,
}

/// What one transcript records: its successful shell commands, and its
/// successful edit results with the paths each names and its time.
struct Activity {
    pub ran: Vec<Ran>,
    pub edited: Vec<(Vec<String>, i64)>,
}

/// The time a transcript record carries, in milliseconds since the epoch.
fn at(record: &Value, transcript: &Path) -> Result<Option<i64>, String> {
    match record.get("timestamp").and_then(Value::as_str) {
        Some(text) => tama_core::clock::parse(text)
            .map(|time| Some(time.timestamp_millis()))
            .map_err(|cause| format!("{}: {cause}", transcript.display())),
        None => Ok(None),
    }
}

/// The paths an edit result names: its own, and each of its listed files.
fn named(details: &Value, paths: &mut Vec<String>) {
    for key in ["path", "resolvedPath"] {
        if let Some(path) = details.get(key).and_then(Value::as_str) {
            paths.push(path.to_owned());
        }
    }
    for key in ["changes", "perFileResults"] {
        if let Some(listed) = details.get(key).and_then(Value::as_array) {
            for entry in listed {
                named(entry, paths);
            }
        }
    }
}

/// Every successful shell command and edit result `transcript` records.
fn activity(transcript: &Path) -> Result<Activity, String> {
    let shown = transcript.display();
    let file = File::open(transcript).map_err(|cause| format!("cannot open {shown}: {cause}"))?;
    let mut called: Vec<(String, bool, i64)> = Vec::new();
    let mut read = Activity {
        ran: Vec::new(),
        edited: Vec::new(),
    };
    for line in BufReader::new(file).lines() {
        let line = line.map_err(|cause| format!("cannot read {shown}: {cause}"))?;
        let record: Value = serde_json::from_str(&line)
            .map_err(|cause| format!("{shown} holds a line that is not JSON: {cause}"))?;
        let Some(message) = record.get("message") else {
            continue;
        };
        let Some(time) = at(&record, transcript)? else {
            continue;
        };
        if let Some(content) = message.get("content").and_then(Value::as_array) {
            for item in content {
                if item.get("type").and_then(Value::as_str) != Some("toolCall") {
                    continue;
                }
                // A transcript keeps the call's arguments under `arguments`;
                // the vocabulary reads them where a hook payload carries them.
                let mut payload = serde_json::Map::new();
                for (key, value) in [(TOOL_INPUT_KEY, "arguments"), ("name", "name")] {
                    if let Some(found) = item.get(value) {
                        payload.insert(key.to_owned(), found.clone());
                    }
                }
                let payload = Value::Object(payload);
                let call = Call::of(&payload);
                if let Some(id) = item.get("id").and_then(Value::as_str) {
                    called.push((id.to_owned(), call.is_shell(), time));
                }
            }
        }
        if message.get("role").and_then(Value::as_str) != Some("toolResult")
            || message.get("isError").and_then(Value::as_bool) != Some(false)
        {
            continue;
        }
        let Some(id) = message.get("toolCallId").and_then(Value::as_str) else {
            continue;
        };
        let Some((_, shell, started)) = called.iter().find(|(call, _, _)| call == id) else {
            continue;
        };
        if *shell {
            read.ran.push(Ran {
                called: *started,
                answered: time,
            });
        } else if let Some(details) = message.get("details") {
            let mut paths = Vec::new();
            named(details, &mut paths);
            if !paths.is_empty() {
                read.edited.push((paths, time));
            }
        }
    }
    Ok(read)
}

/// When the file at `root`/`path` last changed, in milliseconds since the
/// epoch; none when it is absent.
fn changed(root: &Path, path: &Path) -> Result<Option<i64>, String> {
    let file = root.join(path);
    let metadata = match std::fs::metadata(&file) {
        Ok(metadata) => metadata,
        Err(cause) if cause.kind() == std::io::ErrorKind::NotFound => return Ok(None),
        Err(cause) => {
            return Err(format!(
                "cannot read when {} changed: {cause}",
                file.display()
            ))
        }
    };
    let changed = metadata
        .modified()
        .map_err(|cause| format!("cannot read when {} changed: {cause}", file.display()))?
        .duration_since(UNIX_EPOCH)
        .map_err(|cause| format!("{} changed before the epoch: {cause}", file.display()))?
        .as_millis();
    i64::try_from(changed).map(Some).map_err(|cause| {
        format!(
            "the change time of {} is out of range: {cause}",
            file.display()
        )
    })
}

/// The command among `ran` that was running at `changed`.
fn writer(changed: i64, ran: &[Ran]) -> Option<&Ran> {
    ran.iter()
        .find(|command| command.called <= changed && changed <= command.answered)
}

/// Whether anything else in `other`'s activity could have written `file` at
/// `changed` while `command` ran: a command of its running at that moment,
/// or an edit of that file it finished inside the command's window.
fn others(other: &Activity, file: &Path, changed: i64, command: &Ran) -> bool {
    writer(changed, &other.ran).is_some()
        || other.edited.iter().any(|(paths, at)| {
            command.called <= *at
                && *at <= command.answered
                && paths.iter().any(|path| Path::new(path) == file)
        })
}

/// Whether a staged path no edit receipt names holds what one of the
/// session's successful shell commands left in it: that command was running
/// when the working file last changed, the index holds exactly the bytes the
/// file holds, and no other running session had a command running then or
/// finished an edit of that file inside the command's window. A running
/// session whose transcript cannot be found cannot be ruled out as the
/// writer, so the path is not read as this session's.
pub(in super::super) fn left_by_command(
    root: &Path,
    transcript: &Path,
    relative: &Path,
    indexed: Option<&str>,
) -> Result<bool, String> {
    let Some(changed) = changed(root, relative)? else {
        return Ok(false);
    };
    let mine = activity(transcript)?;
    let Some(command) = writer(changed, &mine.ran) else {
        return Ok(false);
    };
    let file = root.join(relative);
    let working = std::fs::read_to_string(&file)
        .map_err(|cause| format!("cannot read {}: {cause}", file.display()))?;
    if Some(working.as_str()) != indexed {
        return Ok(false);
    }
    for (_, session) in crate::ports::owner_consent::running_sessions()? {
        let Some(theirs) = crate::evidence::session_changes::session_transcript(&session)? else {
            return Ok(false);
        };
        if theirs != transcript && others(&activity(&theirs)?, &file, changed, command) {
            return Ok(false);
        }
    }
    Ok(true)
}
