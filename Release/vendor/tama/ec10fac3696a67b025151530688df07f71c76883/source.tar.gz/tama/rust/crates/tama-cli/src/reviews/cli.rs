use super::{list, show, Outcome, Record};
use tama_core::exit::{FAILURE, SUCCESS};

const USAGE: &str = "tama reviews list [--json]\ntama reviews show <id> [--json]\ntama reviews harsh record|dispose|show [...]\ntama reviews admitted --commit REV [--repository PATH] [--json]\ntama reviews cutover [--repository PATH] [--json]";

/// The repository a verb reads: the one named, else the directory it runs in.
fn repository(named: Option<&String>) -> Result<std::path::PathBuf, String> {
    match named {
        Some(path) => Ok(std::path::PathBuf::from(path)),
        None => std::env::current_dir()
            .map_err(|cause| format!("the directory it runs in cannot be read: {cause}")),
    }
}

/// `tama reviews cutover [--repository PATH] [--json]`: where admissions
/// started in the repository, the commit at the tip of every local branch
/// when review-commit admitted its first candidate there; refused when it
/// admitted none, so no pushed commit is yet judged by its admission.
fn cutover(args: &[String]) -> i32 {
    let mut named = None;
    let mut as_json = false;
    let mut words = args.iter();
    while let Some(word) = words.next() {
        match word.as_str() {
            "--repository" => named = words.next(),
            "--json" => as_json = true,
            other => {
                eprintln!("reviews cutover: {other} is no option of this command\n{USAGE}");
                return FAILURE;
            }
        }
    }
    let read = repository(named).and_then(|repository| {
        tama_hook_tools::evidence::admission::cutover(&repository).map(|kept| (repository, kept))
    });
    let kept = match read {
        Ok((_, Some(kept))) => kept,
        Ok((repository, None)) => {
            eprintln!(
                "reviews cutover: review-commit admitted no commit in {} yet, so no cutover is kept and no pushed commit is judged by its admission",
                repository.display()
            );
            return FAILURE;
        }
        Err(cause) => {
            eprintln!("reviews cutover: {cause}");
            return FAILURE;
        }
    };
    if as_json {
        return match json(&kept) {
            Ok(()) => SUCCESS,
            Err(cause) => {
                eprintln!("reviews cutover: {cause}");
                FAILURE
            }
        };
    }
    println!(
        "admissions started at {}; every commit these tips hold was made before them:",
        kept.at
    );
    for commit in &kept.commits {
        println!("  {commit}");
    }
    SUCCESS
}

/// `tama reviews admitted --commit REV [--repository PATH] [--json]`: the
/// session that made the commit and the rounds it was admitted on, as
/// review-commit kept them; refused naming the commit when none was kept.
fn admitted(args: &[String]) -> i32 {
    let mut commit = None;
    let mut named = None;
    let mut as_json = false;
    let mut words = args.iter();
    while let Some(word) = words.next() {
        match word.as_str() {
            "--commit" => commit = words.next(),
            "--repository" => named = words.next(),
            "--json" => as_json = true,
            other => {
                eprintln!("reviews admitted: {other} is no option of this command\n{USAGE}");
                return FAILURE;
            }
        }
    }
    let Some(commit) = commit else {
        eprintln!("reviews admitted: --commit names the commit to read\n{USAGE}");
        return FAILURE;
    };
    let repository = match repository(named) {
        Ok(repository) => repository,
        Err(cause) => {
            eprintln!("reviews admitted: {cause}");
            return FAILURE;
        }
    };
    let found = match tama_hook_tools::evidence::admission::admitted(&repository, commit) {
        Ok(found) => found,
        Err(cause) => {
            eprintln!("reviews admitted: {cause}");
            return FAILURE;
        }
    };
    if as_json {
        return match json(&found) {
            Ok(()) => SUCCESS,
            Err(cause) => {
                eprintln!("reviews admitted: {cause}");
                FAILURE
            }
        };
    }
    match &found.committer {
        Some(made) => println!(
            "committed by {} session {}{}",
            made.agent,
            made.session,
            if made.carried {
                ", outside its process tree, carrying its edits"
            } else {
                ""
            }
        ),
        None => println!("committed by no one named agent session: the operator's own commit, or one whose session could not be told when it was admitted"),
    }
    match &found.parent {
        Some(parent) => println!(
            "commit {} (tree {}) after {parent}",
            found.commit, found.tree
        ),
        None => println!(
            "commit {} (tree {}), a root commit",
            found.commit, found.tree
        ),
    }
    println!(
        "admitted at {}, committed at {}",
        found.admitted_at, found.committed_at
    );
    match &found.rounds {
        Some(rounds) => println!("{rounds}"),
        None => println!("no harsh-review rounds line: the declared judge decided alone"),
    }
    SUCCESS
}

fn print_record(record: &Record) {
    println!(
        "{}\n  retained at {}",
        record.id,
        record.directory.display()
    );
    if let Some(error) = &record.error {
        println!("  unreadable: {error}");
    }
    if let Some(result) = &record.result {
        let outcome = match result.outcome {
            Outcome::Pass => "pass",
            Outcome::SourceFinding => "source_finding",
            Outcome::ReviewFailure => "review_failure",
        };
        println!("  {outcome}");
        if let Some(detail) = &result.detail {
            println!("  {detail}");
        }
    }
}

fn json(value: &impl serde::Serialize) -> Result<(), String> {
    let text = serde_json::to_string_pretty(value)
        .map_err(|cause| format!("cannot encode retained review inspection: {cause}"))?;
    println!("{text}");
    Ok(())
}

fn run(args: &[String], as_json: bool) -> Result<bool, String> {
    match args {
        [verb] if verb == "list" => {
            let listing = list()?;
            if as_json {
                json(&listing)?;
            } else {
                println!("Retained reviews in {}", listing.directory.display());
                if listing.records.is_empty() {
                    println!("No retained review entries.");
                }
                for record in &listing.records {
                    print_record(record);
                }
            }
            Ok(listing.records.iter().any(|record| record.error.is_some()))
        }
        [verb, id] if verb == "show" => {
            let record = show(id).map_err(|cause| cause.to_string())?;
            if as_json {
                json(&record)?;
            } else {
                print_record(&record);
            }
            Ok(record.error.is_some())
        }
        _ => Err(format!(
            "unsupported retained review command; usage:\n{USAGE}"
        )),
    }
}

pub(crate) fn main(args: &[String]) -> i32 {
    let Some((_, args)) = args.split_first() else {
        eprintln!("{USAGE}");
        return FAILURE;
    };
    if let Some((verb, rest)) = args.split_first() {
        if verb == "harsh" {
            return super::harsh::main(rest);
        }
        if verb == "admitted" {
            return admitted(rest);
        }
        if verb == "cutover" {
            return cutover(rest);
        }
    }
    let (arguments, as_json) = match args.split_last() {
        Some((flag, rest)) if flag == "--json" => (rest, true),
        _ => (args, false),
    };
    match run(arguments, as_json) {
        Ok(failed) => {
            if failed {
                FAILURE
            } else {
                SUCCESS
            }
        }
        Err(error) => {
            eprintln!("reviews: {error}");
            FAILURE
        }
    }
}
