//! Decision half of `tama hook block-unauthorized-host-change` (hook id
//! `block-unauthorized-host-change`): a shell line that changes what runs on
//! a host is refused unless the operator granted that exact command in his
//! own words ([`crate::ports::operator_grant`]).
//!
//! A host change is read without a model, command by command as the shell
//! runs them ([`command_path`]):
//!
//! - installing a product or a release: `stado product install`, `stado
//!   release local install`;
//! - changing a service: `stado service restart|ensure|deploy|bootout`,
//!   `launchctl bootout|bootstrap|kickstart|load|unload|stop|kill|remove|enable|disable`,
//!   `systemctl restart|stop|start|reload|try-restart|reload-or-restart|kill|enable|disable|mask`;
//! - signalling a process the session did not start: `kill`, `pkill`,
//!   `killall` of anything but the session's own descendants ([`processes`]);
//! - any of these handed to another host by `stado host exec`.

mod processes;

use serde_json::{json, Value};

use crate::ports::command_path::{self, Reached};
use crate::ports::operator_grant::{self, Request};
use crate::ports::tool_vocabulary::Call;

pub const HOOK_ID: &str = "block-unauthorized-host-change";
const GRANT_KIND: &str = "host-change";
const BANNER: &str = "BLOCKED: unauthorized host change: ";

/// Each command path that changes a host, by its program and words.
const CHANGES: &[&[&str]] = &[
    &["stado", "product", "install"],
    &["stado", "release", "local", "install"],
    &["stado", "service", "restart"],
    &["stado", "service", "ensure"],
    &["stado", "service", "deploy"],
    &["stado", "service", "bootout"],
];
/// The `launchctl` subcommands that change a loaded service (launchctl(1)).
const LAUNCHCTL: &[&str] = &[
    "bootout",
    "bootstrap",
    "kickstart",
    "load",
    "unload",
    "stop",
    "kill",
    "remove",
    "enable",
    "disable",
];
/// The `systemctl` subcommands that change a unit (systemctl(1)).
const SYSTEMCTL: &[&str] = &[
    "restart",
    "stop",
    "start",
    "reload",
    "try-restart",
    "reload-or-restart",
    "kill",
    "enable",
    "disable",
    "mask",
];
/// The words of a Stado command in [`CHANGES`] that change a host, for a line
/// whose commands cannot be read.
const STADO_CHANGE_WORDS: &[&str] = &["install", "restart", "ensure", "deploy", "bootout"];

/// The refusal when the call changes a host with no grant, `None` when it
/// passes.
pub fn evaluate(payload: &Value) -> Option<String> {
    let call = Call::of(payload);
    if !call.is_shell() {
        return None;
    }
    let command = call.command()?;
    let changes = match changes(payload, false) {
        Ok(changes) => changes,
        Err(cause)
            if mentions_change(&crate::ports::shell_text::effective_payload(
                payload, command,
            )) =>
        {
            vec![format!("what it runs cannot be read: {cause}")]
        }
        Err(_) => Vec::new(),
    };
    if changes.is_empty() {
        return None;
    }
    let request = Request {
        gate: HOOK_ID,
        command: Some(command),
        paths: &[],
    };
    if operator_grant::granted(payload, &request) {
        return None;
    }
    Some(format!(
        "{BANNER}{}. Installing, restarting or stopping what runs on a host, or signalling a \
         process this session did not start, needs the operator's grant for this exact command. {}",
        changes.join("; "),
        operator_grant::how_to_grant(GRANT_KIND, HOOK_ID)
    ))
}

/// Every host change the shell line in `payload` makes, each said once. On
/// another host (`remote`) no process there is this session's own.
fn changes(payload: &Value, remote: bool) -> Result<Vec<String>, String> {
    let mut found = Vec::new();
    let mut add = |change: String| {
        if !found.contains(&change) {
            found.push(change);
        }
    };
    for path in CHANGES {
        if command_path::reaches(payload, &words(path))? {
            add(format!(
                "`{}` changes what runs on the host",
                path.join(" ")
            ));
        }
    }
    for (program, subcommands) in [("launchctl", LAUNCHCTL), ("systemctl", SYSTEMCTL)] {
        for subcommand in subcommands {
            if command_path::reaches(payload, &words(&[program, subcommand]))? {
                add(format!("`{program} {subcommand}` changes a service"));
            }
        }
    }
    /// Why one signalling command reaches a process the session did not start.
    type Judge = fn(&[String]) -> Option<String>;
    let signals: [(&str, Judge); 3] = [
        ("kill", processes::kill),
        ("pkill", processes::pkill),
        ("killall", processes::killall),
    ];
    for (program, judge) in signals {
        for Reached { args, .. } in command_path::reached(payload, &words(&[program]))? {
            let cause = if remote {
                Some("it signals a process on another host".to_string())
            } else {
                judge(&args)
            };
            if let Some(cause) = cause {
                add(format!("`{program}`: {cause}"));
            }
        }
    }
    for Reached { args, .. } in command_path::reached(payload, &words(&["stado", "host", "exec"]))?
    {
        if let Some(line) = remote_command(&args) {
            let handed = json!({ "tool_name": "bash", "tool_input": { "command": line } });
            for change in changes(&handed, true)? {
                add(format!("on another host, {change}"));
            }
        }
    }
    Ok(found)
}

pub(crate) fn words(path: &[&str]) -> Vec<String> {
    path.iter().map(|word| word.to_string()).collect()
}

/// The command `stado host exec [options] <host> [--] <command…>` runs on
/// the other host, as one line.
pub(crate) fn remote_command(args: &[String]) -> Option<String> {
    let exec = args.iter().position(|word| word == "exec")?;
    let mut rest = args[exec + 1..]
        .iter()
        .skip_while(|word| word.starts_with('-'));
    rest.next()?;
    let remote: Vec<&str> = rest
        .map(String::as_str)
        .skip_while(|word| *word == "--")
        .collect();
    (!remote.is_empty()).then(|| remote.join(" "))
}

/// Whether a command of the unreadable line `command` changes a host: a
/// signal, or a service program or Stado given one of its changing words.
fn mentions_change(command: &str) -> bool {
    crate::ports::operator_grant::segments::commands(command)
        .iter()
        .any(|words| match words.split_first() {
            Some((&"kill" | &"pkill" | &"killall", _)) => true,
            Some((&"launchctl", rest)) => rest.iter().any(|word| LAUNCHCTL.contains(word)),
            Some((&"systemctl", rest)) => rest.iter().any(|word| SYSTEMCTL.contains(word)),
            Some((&"stado", rest)) => rest.iter().any(|word| STADO_CHANGE_WORDS.contains(word)),
            _ => false,
        })
}
