//! The steps of a release that are not installing the program: saying where
//! the sealed runtime on this machine came from, and moving the hook
//! selection afterwards.
//!
//! Split out of `release.rs` because a source file here stays at three
//! hundred lines or fewer, and the warm step the release gained needed the
//! room.

use std::path::{Path, PathBuf};

/// Where the sealed runtime this machine loads was built from.
///
/// The hook binaries a release installs are built from `origin/main`, but
/// the sealed runtime is staged by a script that compiles the checkout's
/// working tree, and this checkout is shared: a live engine can carry
/// `"dirty": true`, meaning the gates enforcing policy include code nobody
/// has committed. The release records that fact; this is where it is shown,
/// so somebody can act on it.
///
/// No manifest means no sealed runtime and nothing to say; a manifest that
/// cannot be read, or that does not state its revision and whether the
/// checkout was dirty, is said to leave the provenance unknown, never read as
/// a clean build.
pub(super) fn installed_provenance(home: &Path) -> Option<String> {
    let manifest: PathBuf = home
        .join("Library/Application Support/Tama/hooks-runtime/current")
        .join("native-hook-binaries.json");
    let text = match std::fs::read_to_string(&manifest) {
        Ok(text) => text,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return None,
        Err(error) => {
            return Some(format!(
                "installed runtime: provenance unknown, {} cannot be read: {error}",
                manifest.display()
            ))
        }
    };
    Some(match provenance(&text) {
        Ok(line) => line,
        Err(cause) => format!(
            "installed runtime: provenance unknown, {}: {cause}",
            manifest.display()
        ),
    })
}

fn provenance(text: &str) -> Result<String, String> {
    let value: serde_json::Value =
        serde_json::from_str(text).map_err(|error| format!("not JSON: {error}"))?;
    let identity = value.get("sourceIdentity").ok_or("no sourceIdentity")?;
    let revision = identity
        .get("revision")
        .and_then(serde_json::Value::as_str)
        .ok_or("sourceIdentity names no revision")?;
    let dirty = identity
        .get("dirty")
        .and_then(serde_json::Value::as_bool)
        .ok_or("sourceIdentity does not say whether the checkout was dirty")?;
    Ok(if dirty {
        format!(
            "installed runtime: built from {revision} with uncommitted changes in the checkout, \
         so the engine enforcing policy is not the code that was pushed",
        )
    } else {
        format!("installed runtime: built from {revision}, with nothing uncommitted")
    })
}

/// The machine's hook selection, through the command that owns it. `--enforce`
/// adds (`tama enforcement add`): a release that installed one new gate must
/// not silently drop the gates the operator already chose, and the union is
/// made from the selection as it is when it is written, so a gate another
/// session turned on meanwhile stays. A machine that enforces every installed
/// hook keeps doing so.
pub(super) fn enforce_selection(root: &Path, enforce: &[String]) -> i32 {
    if enforce.is_empty() {
        println!(
            "this machine's hook selection is unchanged; read it with `tama enforcement status` \
             and change it with `tama enforcement only <hook-id>…`"
        );
        return tama_core::exit::SUCCESS;
    }
    crate::enforcement::main(&[&["add".to_string()], enforce].concat(), root)
}
