//! A copy's apparent size, read from the folders and files it holds.

use std::fs::{self, DirEntry};
use std::io;
use std::path::Path;

/// Apparent size of the candidate, so the operator sees what a pass returns.
/// Symlinks are counted as links and never followed: a copy that links to
/// something outside itself must not have that thing's size attributed to it,
/// and must never have it walked. A folder or entry that cannot be read adds
/// nothing and is named in `unread`, so the size is shown as a floor of what
/// was readable, not as the copy's whole size.
pub(super) fn bytes(dir: &Path, unread: &mut Vec<String>) -> u64 {
    let mut sizes: Vec<u64> = Vec::new();
    match fs::read_dir(dir) {
        Ok(entries) => {
            for entry in entries {
                if let Some(size) = entry_bytes(dir, entry, unread) {
                    sizes.push(size);
                }
            }
        }
        Err(error) => unread.push(format!(
            "{} cannot be listed for its size: {error}",
            dir.display()
        )),
    }
    sizes.iter().sum()
}

/// One entry's size: a folder's walked size, a file's length, nothing for a
/// link or for an entry that cannot be read (named in `unread`).
fn entry_bytes(dir: &Path, entry: io::Result<DirEntry>, unread: &mut Vec<String>) -> Option<u64> {
    let entry = match entry {
        Ok(entry) => entry,
        Err(error) => {
            unread.push(format!(
                "an entry of {} cannot be read: {error}",
                dir.display()
            ));
            return None;
        }
    };
    let kind = match entry.file_type() {
        Ok(kind) => kind,
        Err(error) => {
            unread.push(format!(
                "{} has no readable type: {error}",
                entry.path().display()
            ));
            return None;
        }
    };
    if kind.is_symlink() {
        return None;
    }
    if kind.is_dir() {
        return Some(bytes(&entry.path(), unread));
    }
    match entry.metadata() {
        Ok(metadata) => Some(metadata.len()),
        Err(error) => {
            unread.push(format!(
                "{} has no readable size: {error}",
                entry.path().display()
            ));
            None
        }
    }
}
