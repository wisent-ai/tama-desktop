//! Decision half of `tama hook block-unapproved-tests`: no test code the
//! operator did not approve.
//!
//! Test code can decide whether a release ships, so its approval belongs to
//! the operator. He gives it either with `tama tests approve <path>` in his
//! own terminal, which approves that path for good, or in the conversation,
//! which the agent records as the Tama session capability `{"tool": "tests"}`
//! with the lifetime he named and the hook runner validates
//! ([`crate::ports::owner_consent::TEST_CODE`]); that consent admits test code
//! anywhere for as long as the grant lives. An agent cannot grant it to itself.
//!
//! What is refused, before the tool runs:
//!
//!   * a write or an edit of a file that is test code by its path, or whose
//!     change carries its language's test marker, outside every approval;
//!   * a shell redirection into such a file;
//!   * any session write to the approval record, and every command that
//!     records the operator's own decision ([`operator_acts`]) run from a
//!     session: `tama tests approve`, `oko tasks close`, and any `oko`
//!     command given `--by operator`. What the agent grants itself is not his.
//!   * a smoke test, and any write into a repository whose tracked test
//!     files hold one, whatever was approved ([`crate::ports::smoke_tests`]):
//!     the operator never approves a smoke test.
//!
//! Reading test code is never refused, and neither is removing a test file
//! from the shell (`git rm`, `rm`): a shell command is judged only by what it
//! redirects into. A write tool aimed at an unapproved test file is refused
//! whatever it changes.

use std::path::{Path, PathBuf};
use std::sync::LazyLock;

use regex::Regex;
use serde_json::Value;

use crate::ports::block_off_task_work::written_paths;
use crate::ports::check_numeric_literals_payload::path_texts;
use crate::ports::owner_consent::TEST_CODE;
use crate::ports::tool_vocabulary::Call;
use crate::ports::transport_common as common;

pub mod approvals;
pub mod audit;
mod detect;
pub mod operator_acts;

use detect::test_code_lines;
pub use detect::{carries_test_code, is_test_path};

const HOOK: &str = "block-unapproved-tests";

/// The target of a shell redirection: the one way a shell command creates or
/// fills a file by itself.
static REDIRECTION: LazyLock<Regex> =
    LazyLock::new(|| common::compile(r#"\d*>>?\s*(?P<target>'[^']*'|"[^"]*"|[^\s;|&<>()]+)"#));

fn store_refusal() -> String {
    format!(
        "{HOOK}: BLOCKED: {} is the operator's record of approved tests. A session never \
         writes it: an approval the agent grants itself is not an approval.",
        approvals::store().display()
    )
}

/// The refusal of test code at `path`; `lines` are where in the whole file
/// the write leaves a test marker stands, none when its path alone makes it
/// test code.
fn refusal(path: &Path, lines: &[String]) -> String {
    let located = if lines.is_empty() {
        String::new()
    } else {
        format!(" (test markers at {})", lines.join("; "))
    };
    format!(
        "{HOOK}: BLOCKED: {}{located} is test code the operator has not approved. Tests are written only \
         where he asked for them. He approves them by saying so in the conversation, which the \
         agent records as the Tama session capability {}, or with `tama tests approve <path>` in \
         his own terminal; a session cannot run that command. Leave the test out until he does.",
        path.display(),
        TEST_CODE.grant()
    )
}

fn shell_refusal(command: &str, base: &Path, approved: &approvals::Approvals) -> Option<String> {
    if command.contains(approvals::STORE_NAME) {
        return Some(store_refusal());
    }
    if let Some(refused) = operator_acts::refusal(HOOK, command) {
        return Some(refused);
    }
    if TEST_CODE.granted_to_hook() {
        return None;
    }
    REDIRECTION
        .captures_iter(command)
        .filter_map(|found| found.name("target"))
        .map(|target| {
            target
                .as_str()
                .trim_matches(|quote| quote == '\'' || quote == '"')
        })
        .map(|target| approvals::absolute(target, base))
        .find(|path| is_test_path(&path.to_string_lossy()) && !approvals::covers(approved, path))
        .map(|path| refusal(&path, &[]))
}

/// Why this payload writes test code nobody approved, if it does. A write is
/// judged by each file as it leaves it (`path_texts`), so a test marker the
/// file already holds, or one only the whole file shows, is seen; a write
/// whose file cannot be rebuilt is refused with the cause.
pub fn evaluate(payload: &Value) -> Option<String> {
    let call = Call::of(payload);
    let base = match call.working_dir() {
        Ok(base) => base,
        Err(error) => {
            return Some(format!(
                "{HOOK}: BLOCKED: the paths this call writes cannot be placed: {error}"
            ))
        }
    };
    let approved = match approvals::recorded() {
        Ok(approved) => approved,
        Err(error) => {
            return Some(format!(
                "{HOOK}: BLOCKED: which test code is approved cannot be told: {error}"
            ))
        }
    };
    if call.is_shell() {
        let command = call.command()?;
        return shell_refusal(command, &base, &approved);
    }
    let input = match call.input() {
        Some(input) => input,
        None => &Value::Null,
    };
    let written = match written_paths(&call) {
        Ok(written) => written,
        Err(error) => return Some(format!("{HOOK}: BLOCKED: {error}")),
    };
    let paths: Vec<PathBuf> = written
        .iter()
        .map(|path| approvals::absolute(path, &base))
        .collect();
    if paths.iter().any(|path| approvals::is_store(path)) {
        return Some(store_refusal());
    }
    let texts = match path_texts(input, call.cwd()) {
        Ok(texts) => texts,
        Err(cause) => {
            return Some(format!(
                "{HOOK}: BLOCKED: the file this write leaves cannot be rebuilt to judge it, so the \
                 write is refused: {cause}"
            ))
        }
    };
    let text: String = texts
        .iter()
        .map(|(_, text)| text.as_str())
        .collect::<Vec<_>>()
        .join("\n");
    if let Some(refused) = crate::ports::smoke_tests::refusal(&paths, &text) {
        return Some(refused);
    }
    if TEST_CODE.granted_to_hook() {
        return None;
    }
    // A file the replay left is judged by its own text; a path the write
    // names without text (a move's destination) by its path alone.
    let marked: Vec<(PathBuf, Vec<String>)> = texts
        .iter()
        .map(|(path, text)| (approvals::absolute(path, &base), test_code_lines(text)))
        .filter(|(_, lines)| !lines.is_empty())
        .collect();
    paths.into_iter().find_map(|path| {
        let lines: &[String] = match marked.iter().find(|(marked, _)| *marked == path) {
            Some((_, lines)) => lines,
            None => &[],
        };
        let refused = (!lines.is_empty() || is_test_path(&path.to_string_lossy()))
            && !approvals::covers(&approved, &path);
        refused.then(|| refusal(&path, lines))
    })
}
