//! `tama standing`: read the commit standing register and take a charge back.

use serde_json::json;

use super::{all, path, standing, withdraw, Standing};

pub const USAGE: &str = "tama standing list [--json]
tama standing show --session ID [--json]
tama standing score --repository PATH --range RANGE [--json]
tama standing withdraw <charge id> --reason TEXT [--json]
tama standing location
  Every agent session's commit standing: one point earned for each commit
  whose staged files were all in their formatter's form (rustfmt's for Rust,
  the one the tree's .tama/formatters.json declares for any other
  extension), one lost for each that staged a file out of it. A session
  below zero has every tool call
  refused by block-negative-commit-standing. score charges the commits of a
  Git revision range made before each commit was scored: each is put to the
  session whose shell call naming commit and the repository was running when
  Git recorded it, read from the session transcripts; a commit no call or
  several calls cover is listed with that cause and not scored. withdraw takes
  one charge back, with the reason it was recorded in error; it then counts
  toward nothing.";

/// Run the verb the arguments name; what it prints.
pub fn cli(args: &[String]) -> Result<String, String> {
    let Some((verb, rest)) = args.split_first() else {
        return Err(format!("tama standing needs a verb\n{USAGE}"));
    };
    let mut session: Option<&str> = None;
    let mut reason: Option<&str> = None;
    let mut repository: Option<&str> = None;
    let mut range: Option<&str> = None;
    let mut subject: Option<&str> = None;
    let mut json_output = false;
    let mut words = rest.iter();
    while let Some(word) = words.next() {
        match word.as_str() {
            "--session" => session = Some(value(&mut words, "--session")?),
            "--reason" => reason = Some(value(&mut words, "--reason")?),
            "--repository" => repository = Some(value(&mut words, "--repository")?),
            "--range" => range = Some(value(&mut words, "--range")?),
            "--json" => json_output = true,
            other if !other.starts_with('-') && subject.is_none() => subject = Some(other),
            other => return Err(format!("unknown argument {other}\n{USAGE}")),
        }
    }
    match verb.as_str() {
        "list" => {
            let all = all()?;
            if json_output {
                return Ok(json!(all).to_string());
            }
            if all.is_empty() {
                return Ok(format!(
                    "no commit of an agent session is recorded in {}",
                    path().display()
                ));
            }
            Ok(all.iter().map(text).collect::<Vec<_>>().join("\n"))
        }
        "show" => {
            let session =
                session.ok_or_else(|| format!("tama standing show needs --session\n{USAGE}"))?;
            let standing = standing(session)?;
            Ok(if json_output {
                json!(standing).to_string()
            } else {
                text(&standing)
            })
        }
        "score" => {
            let repository = repository
                .ok_or_else(|| format!("tama standing score needs --repository\n{USAGE}"))?;
            let range =
                range.ok_or_else(|| format!("tama standing score needs --range\n{USAGE}"))?;
            let scored = super::history::score(std::path::Path::new(repository), range)?;
            if json_output {
                return Ok(json!(scored).to_string());
            }
            Ok(scored
                .iter()
                .map(scored_line)
                .collect::<Vec<_>>()
                .join("\n"))
        }
        "withdraw" => {
            let id = subject
                .ok_or_else(|| format!("tama standing withdraw needs the charge's id\n{USAGE}"))?;
            let reason =
                reason.ok_or_else(|| format!("tama standing withdraw needs --reason\n{USAGE}"))?;
            let (taken, standing) = withdraw(id, reason)?;
            Ok(if json_output {
                json!({ "withdrawn": taken, "standing": standing }).to_string()
            } else {
                format!(
                    "took back charge {} of session {}\n{}",
                    taken.commit.id,
                    taken.commit.session,
                    text(&standing)
                )
            })
        }
        "location" => Ok(path().display().to_string()),
        "--help" | "-h" => Ok(USAGE.to_string()),
        other => Err(format!(
            "tama standing takes list, show, score, withdraw or location; got {other}\n{USAGE}"
        )),
    }
}

fn value<'a>(words: &mut std::slice::Iter<'a, String>, flag: &str) -> Result<&'a str, String> {
    words
        .next()
        .map(String::as_str)
        .ok_or_else(|| format!("{flag} needs a value\n{USAGE}"))
}

fn text(standing: &Standing) -> String {
    let state = if standing.blocked { "blocked" } else { "free" };
    let mut lines = vec![format!("{}  {state}  {}", standing.session, standing.rule)];
    for commit in &standing.charges {
        lines.push(format!(
            "  charge {} {} in {}: {}",
            commit.id,
            commit.recorded_at,
            commit.repository,
            commit.unformatted.join(", ")
        ));
    }
    lines.join("\n")
}

/// One commit `score` read: whose it was and what it earned, or why it
/// was not scored, with the cause in place of a session it found none for.
fn scored_line(entry: &super::history::Scored) -> String {
    let outcome = match (&entry.session, &entry.cause) {
        (_, Some(cause)) => format!("not scored: {cause}"),
        (Some(session), None) if entry.unformatted.is_empty() => {
            format!("{session} earned a point")
        }
        (Some(session), None) => {
            format!("{session} lost a point: {}", entry.unformatted.join(", "))
        }
        (None, None) => "not scored: no session was found for it".to_string(),
    };
    format!("{} {}\n  {outcome}", entry.commit, entry.subject)
}
