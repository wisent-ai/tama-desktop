//! What a session declared it was asked for, and what that leaves out.
//!
//! Split out of `block_off_task_work/mod.rs`, which had grown past the
//! three-hundred-line limit; reading a hook payload stays there.

use std::path::{Path, PathBuf};

use serde::Deserialize;

use crate::ports::python_stdlib::expanduser;

mod elsewhere;

pub(super) use elsewhere::working_elsewhere;

/// Where a session's declaration lives.
pub(crate) const SCOPE_HOME_RELATIVE: &str = ".tama/task-scope";

/// The workspace every Wisent repository is checked out under, one level
/// deep: `<root>/<repository>`.
pub(crate) use crate::util::WORKSPACE_HOME_RELATIVE;
const BANNER: &str = "BLOCKED: this is not what the session was asked for. ";
/// The command the refusal prints, for the session the call runs under. It
/// carries `--session` with that session's id: the CLI requires it, and a
/// placeholder let a session declare its scope under another session's id
/// (one it had read elsewhere) and then read this refusal as the gate
/// ignoring the scope it had just declared.
fn declare(session: &str) -> String {
    format!(
        "`tama task scope set --session {session} --repository <NAME>… --defect <DEFECT ID> | \
         --task <TASK ID>` (this call runs under session {session}; a scope declared for \
         another session does not cover it), which copies the operator's current instruction \
         from Tama's own capture of it and refuses an entry the register does not hold open"
    )
}

/// What one session says the current instruction touches.
#[derive(Debug, Deserialize)]
pub struct TaskScope {
    /// Digest of the latest captured turn when this work was selected. A
    /// newer prompt invalidates the selection, but an earlier open task can
    /// be selected again without another operator message.
    #[serde(default)]
    pub turn_digest: String,
    /// The operator's own words, copied from the captured instruction.
    #[serde(default)]
    pub task: String,
    /// Repositories that instruction touches.
    #[serde(default)]
    pub repositories: Vec<String>,
    /// The defect this work belongs to, from Oko's defect register.
    #[serde(default)]
    pub defect: String,
    /// The task this work belongs to, from Oko's task register.
    #[serde(default)]
    pub task_id: String,
    /// When the declaration was written, as every Tama record writes a time.
    #[serde(default)]
    pub declared_at: String,
}

impl TaskScope {
    /// The declaration this session wrote, or `None` when it wrote none. A
    /// declaration that exists but cannot be read or parsed is the error,
    /// naming the file and cause, so the gates do not tell the session to
    /// declare a scope it already declared.
    pub fn read(session: &str, home: &Path) -> Result<Option<Self>, String> {
        if session.is_empty() {
            return Ok(None);
        }
        let path = location(session, home);
        let text = match std::fs::read_to_string(&path) {
            Ok(text) => text,
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(None),
            Err(error) => {
                return Err(format!(
                    "the task scope {} cannot be read: {error}",
                    path.display()
                ))
            }
        };
        serde_json::from_str(&text)
            .map(Some)
            .map_err(|error| format!("the task scope {} is not a scope: {error}", path.display()))
    }

    fn covers(&self, repository: &str) -> bool {
        self.repositories
            .iter()
            .any(|declared| declared == repository)
    }

    /// The register entry this work belongs to, as the refusal names it.
    fn entry(&self) -> String {
        match (self.defect.trim(), self.task_id.trim()) {
            ("", "") => String::new(),
            (defect, "") => format!("defect {defect}"),
            ("", task) => format!("task {task}"),
            (defect, task) => format!("defect {defect} and task {task}"),
        }
    }

    /// The register entry this declaration still names, with the first line
    /// of the operator's words it was declared for; `None` when it names no
    /// task and no defect. On a machine without Oko the declaration is the
    /// register: the session wrote it for the work it took, and clears it
    /// (`tama task scope clear`) when that work is done, so an entry still
    /// declared is work the session has not finished.
    pub fn declared_entry(&self) -> Option<String> {
        let entry = self.entry();
        if entry.is_empty() {
            return None;
        }
        match self.task.lines().next().map(str::trim) {
            Some(said) if !said.is_empty() => Some(format!("{entry} — \"{said}\"")),
            _ => Some(entry),
        }
    }

    fn declared(&self) -> String {
        if self.repositories.is_empty() {
            return "nothing".to_string();
        }
        self.repositories.join(", ")
    }
}

/// The file `tama task scope set` writes for `session` under `home`.
fn location(session: &str, home: &Path) -> PathBuf {
    home.join(SCOPE_HOME_RELATIVE)
        .join(format!("{session}.json"))
}

/// Which declaration a refusal was decided on: the file and when it was
/// last written, so a refusal judged on a scope the session already
/// replaced shows the time it read, not only the scope.
fn read_from(session: &str, home: &Path) -> String {
    let path = location(session, home);
    let written = std::fs::metadata(&path)
        .and_then(|held| held.modified())
        .map_err(|error| error.to_string())
        .and_then(|written| {
            written
                .duration_since(std::time::UNIX_EPOCH)
                .map_err(|error| error.to_string())
        })
        .and_then(|since| i64::try_from(since.as_millis()).map_err(|error| error.to_string()))
        .and_then(tama_core::clock::from_millis);
    match written {
        Ok(written) => format!(
            "read from {}, written {}",
            path.display(),
            tama_core::clock::iso(written)
        ),
        Err(error) => format!(
            "read from {}, whose write time cannot be read: {error}",
            path.display()
        ),
    }
}

/// The workspace repository one path belongs to, if any.
///
/// Paths outside the workspace — a product's installed files, the operator's
/// own state, anything under `/tmp` — are other gates' subject, not this
/// one's, and are left alone. A relative path while the working directory
/// cannot be read is an error: placed nowhere, its repository would go
/// unjudged.
pub fn repository_of(path: &str, home: &Path) -> Result<Option<String>, String> {
    let expanded = expanduser(path);
    let absolute = if Path::new(&expanded).is_absolute() {
        PathBuf::from(&expanded)
    } else {
        std::env::current_dir()
            .map_err(|error| {
                format!("{path} is relative and the working directory cannot be read: {error}")
            })?
            .join(&expanded)
    };
    let workspace = home.join(WORKSPACE_HOME_RELATIVE);
    let Ok(relative) = absolute.strip_prefix(&workspace) else {
        return Ok(None);
    };
    Ok(relative
        .components()
        .next()
        .map(|component| component.as_os_str().to_string_lossy().to_string())
        .filter(|name| !name.is_empty()))
}

/// The workspace repository name a `--repository` value declares. The gate
/// compares names, so a path is read as the checkout it points into; a path
/// outside the workspace names no repository the gate could ever match, and
/// is refused.
pub(super) fn declared_repository(value: &str) -> Result<String, String> {
    if !value.contains('/') && !value.starts_with('~') && !value.starts_with('.') {
        return Ok(value.to_string());
    }
    repository_of(value, &PathBuf::from(expanduser("~")))?.ok_or_else(|| {
        format!(
            "--repository {value} is not inside the workspace, so no change could ever match it; \
             name the repository, for example `--repository oko`"
        )
    })
}

/// The selection must be bound to the latest captured turn, so a new prompt
/// cannot silently inherit it. The registered defect or task identifies the
/// work, while the declared repositories bound its changes. An earlier open
/// task may be selected again after a smaller task is served; its original
/// words come from Oko rather than being inferred from the newest prompt.
/// A session with no captured prompt binds no scope until `tama task scope
/// set` records the newest operator message of its transcript as its
/// instruction, so the refusal's remedy is always one the session can run.
pub fn refusal(
    repository: &str,
    session: &str,
    instruction: Option<&str>,
    home: &Path,
) -> Option<String> {
    let scope = match TaskScope::read(session, home) {
        Ok(scope) => scope,
        Err(cause) => return Some(format!("{BANNER}{cause}")),
    };
    let Some(scope) = scope else {
        return Some(format!("{BANNER}This session has not said which defect or task the operator's current \
             instruction is, or which repositories it touches, and this call changes {repository}. Say it once \
             and every later change is checked against it: {}", declare(session)));
    };
    if Some(scope.turn_digest.as_str()) != instruction {
        return Some(format!("{BANNER}This session's scope ({} for {}, {}) was declared for an earlier \
             instruction than the operator's current one, and this call changes {repository}. Declare it \
             for the current instruction: {}", scope.declared(), scope.entry(), read_from(session, home), declare(session)));
    }
    let entry = scope.entry();
    if entry.is_empty() {
        return Some(format!(
            "{BANNER}The scope of this session names no defect and no task, so nothing says this \
             change to {repository} is part of anything. Record what is wrong with `oko \
             defects record`, or name the task it belongs to, and declare it: {}",
            declare(session)
        ));
    }
    if scope.covers(repository) {
        return None;
    }
    Some(format!(
        "{BANNER}This session is working on {entry}: {}. It was declared to touch {}, and this \
         call changes {repository} (the declaration was {}). Something really being broken is not \
         the same as being asked to fix it — record it where it will be read (`oko defects record`) \
         and say so in the answer. If this change really is part of that work, widen the scope: \
         {}",
        scope.task.trim(),
        scope.declared(),
        read_from(session, home),
        declare(session)
    ))
}
