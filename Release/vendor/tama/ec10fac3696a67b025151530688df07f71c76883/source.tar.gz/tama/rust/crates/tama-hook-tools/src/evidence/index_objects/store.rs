//! The object stores `tama index repair` reads and writes: whether a store
//! holds an object, the other checkouts of the workspace that may hold it,
//! copying it across, and the repair of one missing entry.

use std::path::{Path, PathBuf};

use super::Missing;
use tama_core::git::Git;

/// Whether `directory`'s store holds `object`. `cat-file -e` fails silently
/// for an object the store lacks and says why when it cannot read the store
/// at all; only the latter refuses, naming the checkout.
fn holds(directory: &Path, object: &str) -> Result<bool, String> {
    let output = Git::of(Some(directory)).output(&["cat-file", "-e", object])?;
    match (output.status.success(), output.stderr.is_empty()) {
        (true, _) => Ok(true),
        (false, true) => Ok(false),
        (false, false) => Err(format!(
            "whether {} holds {object} cannot be read: {}",
            directory.display(),
            String::from_utf8_lossy(&output.stderr).trim()
        )),
    }
}

/// The other checkouts beside `root` in its workspace: directories holding
/// a `.git`.
pub(super) fn siblings(root: &Path) -> Result<Vec<PathBuf>, String> {
    let Some(workspace) = root.parent() else {
        return Ok(Vec::new());
    };
    let entries = std::fs::read_dir(workspace).map_err(|cause| {
        format!(
            "the workspace {} cannot be listed: {cause}",
            workspace.display()
        )
    })?;
    let mut found = Vec::new();
    for entry in entries {
        let entry = entry.map_err(|cause| {
            format!(
                "an entry of {} cannot be read: {cause}",
                workspace.display()
            )
        })?;
        let path = entry.path();
        let checkout =
            tama_core::presence::present(&path.join(".git")).map_err(|error| error.to_string())?;
        if path != root && checkout {
            found.push(path);
        }
    }
    found.sort();
    Ok(found)
}

/// Copy `object` from `source`'s store into `root`'s, checking the id.
fn copy(root: &Path, source: &Path, object: &str) -> Result<(), String> {
    let bytes = Git::of(Some(source)).bytes(&["cat-file", "blob", object])?;
    let area = root.join(".build/tama-index-repair");
    std::fs::create_dir_all(&area)
        .map_err(|cause| format!("cannot create {}: {cause}", area.display()))?;
    let file = area.join(object);
    std::fs::write(&file, &bytes)
        .map_err(|cause| format!("cannot write {}: {cause}", file.display()))?;
    let written = Git::of(Some(root)).bytes(&["hash-object", "-w", "--", &file.to_string_lossy()]);
    let removed = std::fs::remove_file(&file);
    let written = String::from_utf8_lossy(&written?).trim().to_owned();
    removed.map_err(|cause| format!("{} is left behind: {cause}", file.display()))?;
    if written == object {
        Ok(())
    } else {
        Err(format!(
            "the object copied from {} stored as {written}, not {object}",
            source.display()
        ))
    }
}

/// Repair one missing entry (the parent module's doc).
pub(super) fn repair(root: &Path, entry: &mut Missing, others: &[PathBuf]) -> Result<(), String> {
    for other in others {
        if holds(other, &entry.object)? {
            copy(root, other, &entry.object)?;
            entry.copied_from = Some(other.clone());
            entry.repair = Some("copied".into());
            return Ok(());
        }
    }
    entry.lost = true;
    if root.join(&entry.path).is_file() {
        Git::of(Some(root)).bytes(&["add", "--", &entry.path])?;
        entry.repair = Some("restaged from the working file".into());
    } else {
        Git::of(Some(root)).bytes(&["update-index", "--force-remove", "--", &entry.path])?;
        entry.repair = Some("removed from the index".into());
    }
    Ok(())
}

/// One `git ls-files -s` record as its path and object id.
pub(super) fn entry(record: &str) -> Result<(String, String), String> {
    let (fields, path) = record
        .split_once('\t')
        .ok_or_else(|| format!("git ls-files -s gave an entry without a path: {record}"))?;
    let mut parts = fields.split_whitespace();
    let (Some(_mode), Some(object)) = (parts.next(), parts.next()) else {
        return Err(format!(
            "git ls-files -s gave an entry without an object: {record}"
        ));
    };
    Ok((path.to_owned(), object.to_owned()))
}
