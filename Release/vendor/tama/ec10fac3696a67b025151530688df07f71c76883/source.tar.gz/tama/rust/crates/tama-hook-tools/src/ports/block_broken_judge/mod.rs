//! Decision half of `tama-block-broken-judge` (registry hook
//! `block-broken-judge`).
//!
//! Oko records whether its judge can answer in `judge-health.json` beside
//! the transcript index. Verification passes update that record, and
//! `oko tasks judge --probe` checks availability with one
//! question. The refusal remains active while the recorded judge is
//! unavailable and clears when a probe records a successful answer.
//!
//! Nothing is classified here. The gate asks whether the call runs the
//! product's own command path from `vocabulary.json`
//! ([`crate::ports::command_path`], the reading every command-path gate
//! shares), and then asks Oko's file what the judge did last time anybody
//! asked it.

use std::sync::LazyLock;

use serde::Deserialize;
use serde_json::Value;

use crate::ports::command_path;
use crate::ports::model_judgement::recorded_health;

/// The operator's sentence, verbatim. It opens the refusal because it is the
/// refusal; everything after it is what to do about it.
const SENTENCE: &str = "SEDZIA NIE DZIALA. NIE UZYWAJ TEGO DOPOKI USTERKA NIE BEDZIE NAPRAWIONA";
const BANNER: &str = "BLOCKED: ";
const PROBE: &str = "oko tasks judge --probe";

/// The command this gate is about: the product's own path to it, as data
/// rather than a guess about what anyone meant.
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Vocabulary {
    #[allow(dead_code)]
    why: String,
    /// The program that judges tasks.
    program: String,
    /// The words after it that reach the judge, in order, as the CLI spells
    /// them: `tasks verify`.
    command: String,
}

static VOCABULARY: LazyLock<Vocabulary> = LazyLock::new(|| {
    serde_json::from_str(include_str!("vocabulary.json"))
        .expect("block_broken_judge/vocabulary.json is the gate's own data and must parse")
});

/// The declared path: the program, then the words that reach the judge.
fn path() -> Vec<String> {
    let words = &*VOCABULARY;
    std::iter::once(words.program.clone())
        .chain(words.command.split_whitespace().map(str::to_string))
        .collect()
}

/// Why this command is refused, if it is.
///
/// A judge that answered is not refused. A judge nobody has ever asked on
/// this machine is refused too: the gate is about spending a minute to learn
/// something the probe answers in a second, and an unread state is exactly
/// that question.
pub fn evaluate(payload: &Value) -> Option<String> {
    match command_path::reaches(payload, &path()) {
        Ok(true) => {}
        Ok(false) => return None,
        Err(cause) => {
            return Some(format!(
                "{BANNER}this call holds every word of `{}`, and whether it runs it cannot be read: {cause}",
                path().join(" ")
            ))
        }
    }
    match recorded_health() {
        Ok(Some(health)) if health.answering => None,
        Ok(Some(health)) => Some(format!(
            "{BANNER}{SENTENCE}. Oko last saw the judge refuse{}: {}. Nothing here is judged until \
             that is repaired; `{PROBE}` asks it one question and lifts this by itself when the \
             judge answers.",
            match health.checked_at {
                Some(at) => format!(" at {at}"),
                None => String::new(),
            },
            health.detail
        )),
        Ok(None) => Some(format!(
            "{BANNER}{SENTENCE}. Nothing on this machine has observed the judge, so a pass would \
             spend a minute to find out what `{PROBE}` answers in one question; run that first."
        )),
        Err(cause) => Some(format!(
            "{BANNER}{SENTENCE}. Oko's record of the judge cannot be read ({cause}), so nothing says \
             whether it answers; `{PROBE}` asks it one question and writes the record again."
        )),
    }
}
