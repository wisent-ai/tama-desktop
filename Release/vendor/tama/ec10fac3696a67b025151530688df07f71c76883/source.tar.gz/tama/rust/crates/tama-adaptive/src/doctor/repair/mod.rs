//! Corpus-driven validation of a candidate hook patch and its application
//! once the owner consents. Also reads the catalogue the doctor needs: a
//! hook's command source path, the catalogued hooks and one hook by id.

mod catalog;
mod corpus;
mod proposal;
mod spawn;

pub use catalog::{build_catalog_hooks, command_source_path, find_hook, CatalogHook};
pub use proposal::{apply_proposal, build_brief, propose, validate_candidate, Brief};
pub use spawn::{spawn_sync_capture, Ended, SpawnOutcome};

pub use super::evidence::{live_script_path, read_closed_telemetry_events};
