//! The hook-configuration writers this gate knows by name, and the words
//! that tell a writing subcommand from a reading one.
//!
//! Split out of `writers.rs`, which had grown past the three-hundred-line
//! limit; how a command is read stays there.
//!
//! A Rust writer is named by its hook name alone, because that name is in
//! both ways it can be run: `tama hook record-hook-metadata` and the
//! separate `tama-record-hook-metadata` program it used to be. Naming only
//! the old program would let `tama hook migrate-registry-to-rust --apply`
//! rewrite the registry from inside a session without a word.

/// Tools that write hook configuration every time they run.
pub(super) const ALWAYS: &[(&str, &str)] = &[
    (
        "register-hook.mjs",
        "register-hook.mjs writes the hook registry",
    ),
    (
        "prune-empty-catalog.mjs",
        "prune-empty-catalog.mjs rewrites the hook catalogue",
    ),
    (
        "install_oko_trajectory_boundary_hook.mjs",
        "that script installs a hook",
    ),
    (
        "install-oko-trajectory-boundary-hook",
        "it installs a hook into the Codex hook configuration",
    ),
    (
        "record-hook-metadata",
        "it writes the hook catalogue metadata",
    ),
];

/// Tools that write unless they are asked to only report.
pub(super) const UNLESS_CHECK: &[(&str, &str)] = &[
    (
        "seal-registry.mjs",
        "seal-registry.mjs reseals the hook registry",
    ),
    (
        "reconcile-registry-sources",
        "it rewrites the registry's source paths",
    ),
    (
        "portable-registry-paths",
        "it rewrites the registry's machine paths",
    ),
];

/// Tools that write only when told to apply what they computed.
pub(super) const WHEN_APPLY: &[(&str, &str)] = &[
    (
        "generate-configs",
        "generate-configs --apply rewrites the provider hook configurations",
    ),
    (
        "migrate-registry-to-rust",
        "it rewrites every hook command in the registry when told to apply",
    ),
];

pub(super) const CHECK_FLAG: &str = "--check";
pub(super) const APPLY_FLAG: &str = "--apply";
pub(super) const PREVIEW_FLAG: &str = "--preview";
pub(super) const TAMA_PROGRAM: &str = "tama";
pub(super) const OKO_PROGRAM: &str = "oko";
pub(super) const INSTALL_WORD: &str = "install";
pub(super) const ENFORCEMENT_WORD: &str = "enforcement";
/// The two `tama enforcement` verbs that only read. Every other verb writes
/// the machine's selection, and naming the writers instead of the readers
/// lets a verb added later through: a gate that knows only `only` and `all`
/// says nothing while a session turns a hook on with `add`. A verb this file
/// has never heard of is a selection change until it proves otherwise.
pub(super) const ENFORCEMENT_READS: &[&str] = &["status", "preflight"];
pub(super) const HOOKS_WORD: &str = "hooks";
pub(super) const OKO_HOOK_WRITES: &[&str] = &["install", "pull"];

pub(super) const TAMA_INSTALL_REASON: &str = "tama install writes this machine's hook dispatchers";
pub(super) const TAMA_ENFORCEMENT_REASON: &str =
    "tama enforcement changes which hooks this machine runs";
pub(super) const OKO_HOOKS_REASON: &str = "oko hooks writes hook files into this machine";
