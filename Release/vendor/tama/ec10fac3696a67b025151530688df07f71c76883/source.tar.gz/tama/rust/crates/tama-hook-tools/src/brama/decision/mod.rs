//! One typed decision through Brama: a state and typed questions in, one
//! typed answer each out (`POST /v1/decisions`). A hook that needs a yes or
//! a no reads the side Brama chose instead of searching a model's prose for
//! a word, so no answer format is negotiated in a prompt and no parser
//! decides what an unexpected reply meant.
//!
//! A yes-or-no question is asked as a `choice` between `yes` and `no`: Brama
//! takes the side with the most probability mass and says which, so no
//! cut-off on a probability is set here.
//!
//! The endpoint answers exactly two aliases. Tama's route is `best` unless
//! `TAMA_OBJECTIVE_AUTHORITY_MODEL_ROUTE` names another; `best` asks
//! `best-decision-model`, a decision alias is taken as written, and any
//! other route is refused naming the two that can answer. The bearer must
//! carry `call:brama#<alias>` for the alias asked.
//!
//! A service declared with `tama model set` in place of Brama is
//! asked the same typed questions as one chat completion bound to a strict
//! JSON Schema ([`schema_bound`]), so a machine without Brama reads them too.

use serde_json::{json, Map, Value};

use super::credentials::{model_route, read};
use super::declared::declared_provider;
use super::request::exchange;

mod schema_bound;

/// Brama's own selector, which the delegated decision alias stands for.
const BEST_ROUTE: &str = "best";
/// The decision alias answered by the caller's own subscription.
pub const BEST_DECISION_ALIAS: &str = "best-decision-model";
/// The decision alias answered by the route the gateway pays for.
pub const DECISION_ALIAS: &str = "decision-model";
const CHAT_PATH: &str = "/v1/chat/completions";
const DECISIONS_PATH: &str = "/v1/decisions";
const CHOICE: &str = "choice";
/// The two options of a yes-or-no question.
const YES: &str = "yes";
const NO: &str = "no";
/// The key a single question is asked under.
const SINGLE: &str = "answer";

/// The decision alias this machine asks, read from its route.
pub fn decision_alias() -> Result<&'static str, String> {
    let route = model_route()?;
    match route.as_str() {
        BEST_ROUTE | BEST_DECISION_ALIAS => Ok(BEST_DECISION_ALIAS),
        DECISION_ALIAS => Ok(DECISION_ALIAS),
        other => Err(format!(
            "route `{other}` cannot answer a typed question: Brama's POST {DECISIONS_PATH} \
             answers only `{DECISION_ALIAS}` and `{BEST_DECISION_ALIAS}` (`{BEST_ROUTE}` asks \
             the latter); set TAMA_OBJECTIVE_AUTHORITY_MODEL_ROUTE to one of them"
        )),
    }
}

/// The answers to `questions` about `state`, keyed as asked: Brama's
/// `POST /v1/decisions`, or the declared service's schema-bound chat
/// completion. A refusal, a body without `answers`, or a question left
/// unanswered is the error, naming what was sent back.
pub fn decide(state: &str, questions: &Map<String, Value>) -> Result<Map<String, Value>, String> {
    let credentials = read()?;
    if let Some(found) = declared_provider()? {
        let waiting = stado_wait::begin(
            stado_wait::Kind::Network,
            format!("judge decision {}", found.model),
            &credentials.endpoint,
        );
        let result = schema_bound::decide(
            &found.model,
            &credentials.endpoint,
            &credentials,
            state,
            questions,
        )
        .and_then(|document| answers(questions, document));
        match &result {
            Ok(_) => waiting.done(),
            Err(error) => waiting.failed(error),
        }
        return result;
    }
    let alias = decision_alias()?;
    let url = match credentials.endpoint.strip_suffix(CHAT_PATH) {
        Some(origin) => format!("{origin}{DECISIONS_PATH}"),
        None => {
            return Err(format!(
                "the resolved Brama endpoint {} is not a chat completions path, so its \
                 decisions path cannot be named",
                credentials.endpoint
            ))
        }
    };
    let waiting = stado_wait::begin(
        stado_wait::Kind::Network,
        format!("judge decision {alias}"),
        &url,
    );
    let request = json!({ "model": alias, "state": state, "questions": questions });
    let result = exchange(alias, &url, &request, &credentials)
        .and_then(|document| answers(questions, document));
    match &result {
        Ok(_) => waiting.done(),
        Err(error) => waiting.failed(error),
    }
    result
}

/// The answers object of a decision document, with every asked key in it.
/// The judge that answered is named by the caller's wait report; the cause
/// here says which part of its document is wrong.
fn answers(
    questions: &Map<String, Value>,
    mut document: Value,
) -> Result<Map<String, Value>, String> {
    let answers = match document.get_mut("answers").map(Value::take) {
        Some(Value::Object(answers)) => answers,
        Some(other) => {
            return Err(format!(
                "decision protocol failure: the decision document's `answers` is not an object: {other}"
            ))
        }
        None => {
            return Err(format!(
                "decision protocol failure: the decision document carries no `answers`: {document}"
            ))
        }
    };
    if let Some(missing) = questions.keys().find(|key| !answers.contains_key(*key)) {
        return Err(format!(
            "decision protocol failure: the decision answered no `{missing}`: {}",
            Value::Object(answers)
        ));
    }
    Ok(answers)
}

/// One yes-or-no question, as `POST /v1/decisions` takes it: a choice
/// between `yes` and `no`, each described by what it means here.
pub fn yes_or_no(instructions: &str, yes: &str, no: &str) -> Value {
    json!({
        "type": CHOICE,
        "instructions": instructions,
        "criteria": { YES: yes, NO: no },
    })
}

/// Whether a yes-or-no answer chose `yes`. A choice naming neither side is
/// refused with what Brama sent.
pub fn chose_yes(answer: &Value) -> Result<bool, String> {
    match answer.get(CHOICE).and_then(Value::as_str) {
        Some(YES) => Ok(true),
        Some(NO) => Ok(false),
        _ => Err(format!(
            "Brama protocol failure: a yes-or-no answer chose neither `{YES}` nor `{NO}`: {answer}"
        )),
    }
}

/// One yes-or-no question about `state`, answered by Brama.
pub fn asks(state: &str, instructions: &str, yes: &str, no: &str) -> Result<bool, String> {
    let mut questions = Map::new();
    questions.insert(SINGLE.to_owned(), yes_or_no(instructions, yes, no));
    let answers = decide(state, &questions)?;
    chose_yes(&answers[SINGLE])
}
