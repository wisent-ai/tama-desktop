//! A repair proposal: drafting a candidate, validating it against the
//! corpus, and writing the proposal directory a person reviews.
//!
//! A candidate the operator did not hand over with `--patch-file` is drafted
//! by a model through Brama, where every model call of this workshop goes.
//!
//! Split out of `doctor/repair.rs`, which had grown past the
//! three-hundred-line limit.

mod apply;
mod brief;
mod summary;
mod validate;

pub use apply::apply_proposal;
pub use brief::{build_brief, Brief};
pub use validate::validate_candidate;

use summary::summary_text;

use std::fs;
use std::path::{Path, PathBuf};

use serde_json::{json, Value};

use super::corpus::hook_paths;
use super::spawn::{spawn_sync_capture, Ended};
use crate::engine::load_engine;
use crate::util::extname;
use tama_core::exit;

/// What the model is asked to answer with.
const DRAFT_SYSTEM: &str =
    "You repair one hook script of an AI coding agent's workshop. The brief \
     names the hook, its source and the cases it must pass and block. Answer with the complete \
     corrected script and nothing else.";

/// `unfence(text)`: the answer without the code fence a model wraps it in.
fn unfence(text: &str) -> String {
    let fence = |line: &&str| line.starts_with("```");
    let lines: Vec<&str> = text.split('\n').collect();
    let mut body: &[&str] = &lines;
    if let Some((first, rest)) = body.split_first() {
        if fence(first) {
            body = rest;
        }
    }
    if let Some((last, rest)) = body.split_last() {
        if fence(last) {
            body = rest;
        }
    }
    body.join("\n")
}

/// A candidate script drafted from `brief` through Brama, written to
/// `out_path`, or why none could be drafted.
fn draft(brief: &str, out_path: &Path) -> Result<PathBuf, String> {
    let route = tama_hook_tools::brama::credentials::model_route()?;
    let answer = tama_hook_tools::brama::chat(&route, DRAFT_SYSTEM, brief)?;
    let body = unfence(answer.trim());
    if body.is_empty() {
        return Err(format!(
            "the model on route {route} drafted an empty script"
        ));
    }
    fs::write(out_path, format!("{body}\n"))
        .map_err(|error| format!("cannot write the draft {}: {error}", out_path.display()))?;
    Ok(out_path.to_path_buf())
}

/// A refused proposal, as `propose` reports one.
fn refused(hook_id: &str, reason: String) -> Value {
    json!({ "ok": false, "hookId": hook_id, "reason": reason })
}

/// `propose(hookId, { patchFile })`.
pub fn propose(hook_id: &str, patch_file: Option<&str>) -> Result<Value, String> {
    let core = load_engine()?;
    let paths = hook_paths(hook_id, &core)?;
    let script = match (&paths.live, &paths.archive) {
        (Some(live), _) => live.clone(),
        (None, Some(archive)) => archive.to_string_lossy().into_owned(),
        (None, None) => {
            return Ok(refused(
                hook_id,
                format!("unknown hook or no script path: {hook_id}"),
            ));
        }
    };
    let ext = extname(&script);
    let tmp_dir = core.state_dir.join("tmp");
    fs::create_dir_all(&tmp_dir)
        .map_err(|error| format!("cannot create {}: {error}", tmp_dir.display()))?;
    let source_file = match patch_file {
        Some(file) => file.to_string(),
        None => {
            let brief = build_brief(hook_id)?;
            let draft_path = tmp_dir.join(format!("{hook_id}-draft{ext}"));
            match draft(&brief.text, &draft_path) {
                Ok(path) => path.to_string_lossy().into_owned(),
                Err(reason) => {
                    return Ok(refused(
                        hook_id,
                        format!("{reason}; pass --patch-file to propose a script by hand"),
                    ));
                }
            }
        }
    };
    if !tama_core::presence::present(Path::new(&source_file)).map_err(|error| error.to_string())? {
        return Ok(refused(
            hook_id,
            format!("patch file not found: {source_file}"),
        ));
    }
    let Value::Object(mut report) = validate_candidate(hook_id, &source_file)? else {
        return Err(format!(
            "the validation of {source_file} for {hook_id} answered no report object"
        ));
    };
    if report.get("ok").and_then(Value::as_bool) != Some(true) {
        report.insert("hookId".into(), hook_id.into());
        report.insert("patchFile".into(), source_file.into());
        report.insert(
            "reason".into(),
            format!(
                "validation did not pass; artifacts left in {}",
                tmp_dir.display()
            )
            .into(),
        );
        return Ok(Value::Object(report));
    }
    let dir = core
        .state_dir
        .join("proposals")
        .join(format!("{hook_id}-{}", tama_core::clock::now_millis()));
    fs::create_dir_all(&dir)
        .map_err(|error| format!("cannot create {}: {error}", dir.display()))?;
    let proposed = dir.join(format!("proposed{ext}"));
    fs::copy(&source_file, &proposed).map_err(|error| {
        format!(
            "cannot copy {source_file} to {}: {error}",
            proposed.display()
        )
    })?;
    // A hook with only an archived script has no live one to diff against.
    // diff(1) exits 0 for identical files and 1 for files that differ, and
    // above that for trouble:
    // https://pubs.opengroup.org/onlinepubs/9799919799/utilities/diff.html
    let diff = match &paths.live {
        Some(live) => {
            let shown = proposed.to_string_lossy().into_owned();
            let arguments = ["-u".to_string(), live.clone(), shown.clone()];
            let ran = spawn_sync_capture("diff", &arguments, "")
                .map_err(|cause| format!("cannot diff {live} against {shown}: {cause}"))?;
            match ran.ended {
                Ended::Status(exit::SUCCESS | exit::FAILURE) => ran.stdout,
                ended => {
                    let said = ran.stderr.trim();
                    return Err(format!(
                        "diff of {live} against {shown} ended with {ended}: {said}"
                    ));
                }
            }
        }
        None => String::new(),
    };
    let diff_path = dir.join("proposed.diff");
    fs::write(&diff_path, diff)
        .map_err(|error| format!("cannot write {}: {error}", diff_path.display()))?;
    report.insert("hookId".into(), hook_id.into());
    report.insert(
        "proposalDir".into(),
        dir.to_string_lossy().into_owned().into(),
    );
    report.insert(
        "proposed".into(),
        proposed.to_string_lossy().into_owned().into(),
    );
    report.insert("livePath".into(), json!(paths.live));
    report.insert(
        "archivePath".into(),
        json!(paths
            .archive
            .as_ref()
            .map(|archive| archive.to_string_lossy().into_owned())),
    );
    let full = Value::Object(report);
    let report_path = dir.join("report.json");
    fs::write(
        &report_path,
        format!("{}\n", tama_core::json::pretty(&full)),
    )
    .map_err(|error| format!("cannot write {}: {error}", report_path.display()))?;
    let summary_path = dir.join("summary.md");
    fs::write(&summary_path, summary_text(&full))
        .map_err(|error| format!("cannot write {}: {error}", summary_path.display()))?;
    Ok(full)
}
