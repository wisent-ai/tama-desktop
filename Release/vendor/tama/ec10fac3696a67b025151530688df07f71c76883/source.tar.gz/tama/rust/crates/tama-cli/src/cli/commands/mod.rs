//! Command handlers extracted from the `main()` dispatch chain: onboarding,
//! policy, list, show, validate, install plan and install. Each
//! function reproduces the original inline branch — same argument validation,
//! same messages, same exit codes — but takes `argv`/`root` as parameters.

use std::path::Path;

use tama_core::catalog::{build_catalog, find_hook, validate_catalog};
mod install;
mod onboarding;

pub use install::{install, install_plan, uninstall};
pub use onboarding::onboarding;

use tama_core::policy_bundle::{
    import_policy_bundle, list_policy_bundles, remove_policy_bundle, ImportPolicyBundleOptions,
};

use super::args::{arg_after, has, option_value};
use super::help::usage;
use super::output::{print_catalog_json, print_json, print_policy_import, truthy, unwrap_or_exit};

pub fn policy(argv: &[String]) -> i32 {
    let operation = argv.get(1).map(String::as_str).unwrap_or("");
    if operation == "import" {
        let source = arg_after(argv, "--source")
            .filter(|value| !value.starts_with("--"))
            .unwrap_or_else(|| {
                eprintln!("policy import requires --source <dir>");
                std::process::exit(tama_core::exit::USAGE);
            });
        let home = option_value(argv, "--home").filter(|value| !value.starts_with("--"));
        if has(argv, "--home") && home.is_none() {
            eprintln!("--home requires a directory");
            return tama_core::exit::USAGE;
        }
        let allowed = [
            "policy",
            "import",
            "--source",
            "--replace",
            "--json",
            "--home",
        ];
        for (index, argument) in argv.iter().enumerate().skip(2) {
            if (argv[index - 1] == "--source" || argv[index - 1] == "--home")
                && !argument.starts_with("--")
            {
                continue;
            }
            if !allowed.contains(&argument.as_str()) {
                eprintln!("unknown policy import option: {argument}");
                return tama_core::exit::USAGE;
            }
        }
        let result = unwrap_or_exit(import_policy_bundle(ImportPolicyBundleOptions {
            source: Path::new(&source),
            home: home.as_deref().map(Path::new),
            replace: has(argv, "--replace"),
        }));
        print_policy_import(&result, has(argv, "--json"));
        return if result.failed() {
            libc::EXIT_FAILURE
        } else {
            libc::EXIT_SUCCESS
        };
    }
    if operation == "list" {
        let home = option_value(argv, "--home").filter(|value| !value.starts_with("--"));
        if has(argv, "--home") && home.is_none() {
            eprintln!("--home requires a directory");
            return tama_core::exit::USAGE;
        }
        let allowed = ["policy", "list", "--json", "--home"];
        for (index, argument) in argv.iter().enumerate().skip(2) {
            if argv[index - 1] == "--home" && !argument.starts_with("--") {
                continue;
            }
            if !allowed.contains(&argument.as_str()) {
                eprintln!("unknown policy list option: {argument}");
                return tama_core::exit::USAGE;
            }
        }
        let bundles = unwrap_or_exit(list_policy_bundles(home.as_deref().map(Path::new)));
        if has(argv, "--json") {
            print_json(&bundles);
        } else if bundles.bundles.is_empty() {
            println!("No inactive policy bundles imported.");
        } else {
            for bundle in bundles.bundles {
                println!(
                    "{}\t{}\t{} hooks\t{} files\tinactive",
                    bundle.source_path, bundle.source_digest, bundle.hook_count, bundle.file_count
                );
            }
        }
        return 0;
    }
    if operation == "remove" {
        let home = option_value(argv, "--home").filter(|value| !value.starts_with("--"));
        let Some(source) = option_value(argv, "--source").filter(|value| !value.starts_with("--"))
        else {
            eprintln!(
                "tama policy remove needs --source <path or source key> of an imported bundle"
            );
            return tama_core::exit::USAGE;
        };
        let removed = unwrap_or_exit(remove_policy_bundle(
            home.as_deref().map(Path::new),
            &source,
        ));
        if has(argv, "--json") {
            print_json(&serde_json::json!({ "source": source, "removed": removed.is_some() }));
        } else if let Some(path) = removed {
            println!("Removed the inactive policy bundle imported from {path}.");
        } else {
            println!("No imported policy bundle came from {source}; nothing changed.");
        }
        return 0;
    }
    eprintln!(
        "usage: tama policy import --source <dir> [--replace] [--json] [--home <path>] | tama policy list [--json] [--home <path>] | tama policy remove --source <path|key> [--json] [--home <path>]"
    );
    tama_core::exit::USAGE
}

pub fn list_hooks(root: &Path, json: bool) -> tama_core::Result<usize> {
    let catalog = build_catalog(root)?;
    let hook_count = catalog.hooks.len();
    if json {
        print_catalog_json(&catalog);
    } else {
        for hook in &catalog.hooks {
            let events: Vec<&str> = hook
                .events
                .iter()
                .map(|event| event.event.as_str())
                .collect();
            println!("{}\t{}\t{}", hook.id, source_text(hook), events.join(", "));
        }
    }
    Ok(hook_count)
}

/// Where a hook's source lives, or that the catalog records none; a dash read
/// as a path.
fn source_text(hook: &tama_core::catalog::CatalogHook) -> &str {
    match hook.source_path.as_deref() {
        Some(path) => path,
        None => "(no source recorded)",
    }
}

pub fn list(argv: &[String], root: &Path) -> i32 {
    unwrap_or_exit(list_hooks(root, has(argv, "--json")));
    0
}

pub fn show(argv: &[String], root: &Path) -> i32 {
    let id = argv.get(1);
    let Some(id) = id else {
        usage();
        return tama_core::exit::USAGE;
    };
    let hook = unwrap_or_exit(find_hook(id, root));
    let Some(hook) = hook else {
        eprintln!("not found: {id}");
        return 1;
    };
    if has(argv, "--json") {
        print_catalog_json(&hook);
    } else {
        println!("{}", hook.id);
        println!("source: {}", source_text(&hook));
        println!("command: {}", hook.command);
        if let Some(description) = truthy(&hook.description) {
            println!("does: {description}");
        }
        if let Some(why) = truthy(&hook.why) {
            println!("why: {why}");
        }
        println!("events:");
        for ev in &hook.events {
            println!("  - {} blocking={}", ev.event, ev.blocking);
        }
    }
    0
}

pub fn validate(argv: &[String], root: &Path) -> i32 {
    let mut result = unwrap_or_exit(validate_catalog(root));
    result.errors.extend(unwrap_or_exit(
        tama_core::registry::wired_without_catalog_errors(root),
    ));
    result.ok = result.errors.is_empty();
    if has(argv, "--json") {
        print_json(&result);
    } else {
        println!("hooks: {}", result.hook_count);
        println!("orphan sources: {}", result.orphan_source_count);
        for warning in &result.warnings {
            println!("WARN {warning}");
        }
        for error in &result.errors {
            eprintln!("ERROR {error}");
        }
    }
    if result.ok {
        0
    } else {
        1
    }
}
