//! A session's change of a file carried onto the file as it stands now.
//!
//! The change is the difference between the bytes an edit saw (`base`) and
//! the bytes it left (`changed`), as `git diff --no-index --unified=0` cuts
//! it into hunks. Each hunk is placed in `current` where the lines it
//! replaces stand: of the places they stand, the one whose surrounding
//! lines read most like the edit's own, then the nearest to where they
//! stood in `base` once the hunks before it are placed, so lines another
//! session wrote around it, above it or right beside it, uncommitted then
//! or committed since, stay where they are and are never read as a
//! conflict, and a hunk next to a repeated line (a closing brace, a blank
//! line) is placed by the text around it. A hunk that only adds lines
//! stands next to a line of `base` it followed or preceded; when the lines
//! it adds already stand there, between the very lines of `base` they went
//! between, it is already carried and not added twice. A hunk whose
//! lines stand nowhere but whose result does is already carried, and a
//! removal whose lines stand nowhere is done. A hunk that stands nowhere
//! after the previous one, or at two places alike in surroundings and
//! distance, is refused naming it: another change took the lines it changed.

mod place;

use std::fs;
use std::path::Path;

use serde::Deserialize;

use place::{already_added, nearest};

const NUMBERING: &str = include_str!("numbering.json");

#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
struct Numbering {
    first_line: usize,
}

/// The number unified diffs, and the edit tool's numbered diff, give a
/// file's first line, as `numbering.json` declares it with its source.
pub(super) fn first_line() -> Result<usize, String> {
    serde_json::from_str::<Numbering>(NUMBERING)
        .map(|numbering| numbering.first_line)
        .map_err(|cause| format!("Tama's diff numbering cannot be read: {cause}"))
}

/// One hunk, as indexes: the lines of the base before it and the lines it
/// removes, and in the changed text the lines before it and those it writes.
struct Hunk {
    before: usize,
    removed: usize,
    written_after: usize,
    written: usize,
}

/// A hunk side's lines before it, from Git's `<start>[,<count>]`: Git
/// numbers a side that holds lines by its first line, counting from
/// `first_line`, and one that holds none by the line it follows.
fn side(numbers: &str, holds: bool, first_line: usize) -> Result<usize, String> {
    let start = match numbers.split_once(',') {
        Some((start, _)) => start,
        None => numbers,
    };
    let start: usize = start
        .parse()
        .map_err(|cause| format!("git diff names a hunk at {numbers:?}: {cause}"))?;
    if holds {
        start
            .checked_sub(first_line)
            .ok_or_else(|| format!("git diff names a hunk holding lines at line {start}"))
    } else {
        Ok(start)
    }
}

/// The hunks that turn `base` into `changed`.
fn hunks(area: &Path, base: &str, changed: &str) -> Result<Vec<Hunk>, String> {
    let ancestor = area.join("base");
    let theirs = area.join("theirs");
    for (file, bytes) in [(&ancestor, base), (&theirs, changed)] {
        fs::write(file, bytes)
            .map_err(|cause| format!("cannot write {}: {cause}", file.display()))?;
    }
    let paths = [ancestor.as_path(), theirs.as_path()];
    let arguments = [
        "diff",
        "--no-index",
        "--no-color",
        "--no-ext-diff",
        "--no-textconv",
        "--unified=0",
        "--",
    ];
    let output = tama_core::git::Git::of(None)
        .paths(&paths)
        .output(&arguments)?;
    // It ends unsuccessfully whenever the two differ; a failure says why.
    if !output.stderr.is_empty() {
        return Err(format!(
            "git diff --no-index of the edit ended with {}: {}",
            output.status,
            String::from_utf8_lossy(&output.stderr).trim()
        ));
    }
    let diff = String::from_utf8(output.stdout)
        .map_err(|cause| format!("git diff --no-index printed no text: {cause}"))?;
    // Each hunk's header, then its removed and written lines.
    let mut parts: Vec<(&str, Vec<&str>)> = Vec::new();
    for line in diff.lines() {
        match (line.strip_prefix("@@ -"), parts.last_mut()) {
            (Some(header), _) => parts.push((header, Vec::new())),
            (None, Some((_, body))) => body.push(line),
            (None, None) => {}
        }
    }
    let first = first_line()?;
    let mut hunks = Vec::new();
    for (header, body) in parts {
        let (old, new) = match header.split_once(" @@") {
            Some((numbers, _)) => numbers.split_once(" +"),
            None => None,
        }
        .ok_or_else(|| format!("git diff printed a hunk header it does not write: {header:?}"))?;
        let removed: Vec<&&str> = body.iter().filter(|line| line.starts_with('-')).collect();
        let written: Vec<&&str> = body.iter().filter(|line| line.starts_with('+')).collect();
        hunks.push(Hunk {
            before: side(old, !removed.is_empty(), first)?,
            removed: removed.len(),
            written_after: side(new, !written.is_empty(), first)?,
            written: written.len(),
        });
    }
    Ok(hunks)
}

/// `current` with the change from `base` to `changed` carried onto it.
pub(super) fn carried(
    area: &Path,
    current: &str,
    base: &str,
    changed: &str,
    path: &Path,
) -> Result<String, String> {
    let base_lines: Vec<&str> = base.split_inclusive('\n').collect();
    let changed_lines: Vec<&str> = changed.split_inclusive('\n').collect();
    let now: Vec<&str> = current.split_inclusive('\n').collect();
    let mut carried: Vec<&str> = Vec::with_capacity(now.len());
    // The lines of `now` not yet copied, and of the base not yet passed.
    let mut unread: &[&str] = &now;
    let mut passed: &[&str] = &base_lines;
    for hunk in hunks(area, base, changed)? {
        let refused = |why: String| {
            format!(
                "session edits cannot be carried onto {}: the edit's hunk after line {} {why}; \
                 the index and working tree are unchanged",
                path.display(),
                hunk.before
            )
        };
        let free = now.len() - unread.len();
        let skipped = hunk
            .before
            .checked_sub(base_lines.len() - passed.len())
            .ok_or_else(|| refused("comes before the hunk above it".to_owned()))?;
        let expected = free + skipped;
        let (Some(removed), Some(written)) = (
            base_lines.get(hunk.before..hunk.before + hunk.removed),
            changed_lines.get(hunk.written_after..hunk.written_after + hunk.written),
        ) else {
            return Err(refused(
                "names lines past the end of the edit's text".to_owned(),
            ));
        };
        let around = (
            base_lines[..hunk.before].last().copied(),
            base_lines.get(hunk.before + hunk.removed).copied(),
        );
        // The base's lines before the hunk and after what it removes: the
        // surroundings a place in the file now is compared with.
        let context = (
            &base_lines[..hunk.before],
            &base_lines[hunk.before + hunk.removed..],
        );
        passed = &base_lines[hunk.before + hunk.removed..];
        if removed.is_empty() {
            if let Some(at) = already_added(&now, free, expected, written, around) {
                carried.extend_from_slice(&now[free..at + written.len()]);
                unread = &now[at + written.len()..];
                continue;
            }
        }
        if let Some(at) =
            nearest(&now, free, expected, removed, around, context).map_err(refused)?
        {
            carried.extend_from_slice(&now[free..at]);
            carried.extend_from_slice(written);
            unread = &now[at + removed.len()..];
            continue;
        }
        if written.is_empty() {
            // The lines it removes stand nowhere: the removal is done.
            continue;
        }
        match nearest(&now, free, expected, written, around, context).map_err(refused)? {
            Some(at) => {
                carried.extend_from_slice(&now[free..at + written.len()]);
                unread = &now[at + written.len()..];
            }
            None => {
                return Err(refused(format!(
                "stands nowhere after line {free} of the file now, and neither does what it writes"
            )))
            }
        }
    }
    carried.extend_from_slice(unread);
    Ok(carried.concat())
}
