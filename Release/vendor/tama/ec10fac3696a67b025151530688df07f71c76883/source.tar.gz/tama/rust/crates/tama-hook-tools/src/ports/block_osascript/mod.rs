//! Decision half of `tama hook block-osascript` (hook id `block-osascript`):
//! a call that runs `osascript` is refused unless the operator granted that
//! exact command in his own words ([`crate::ports::operator_grant`]).
//!
//! `osascript` runs AppleScript or JavaScript for Automation against any
//! application on the operator's Mac: it clicks, types, reads windows and
//! drives a browser page with his signed-in accounts, all outside every
//! other gate. A session that reaches for it is driving his desktop, which
//! is computer use and goes through `block-unauthorized-cua` and its grant,
//! or through the product's own command.
//!
//! The program is read from the words the call runs — a shell line, the
//! shell lines an evaluation tool hands a shell, and the command line a
//! process tool starts — through every shell handed a line (`bash -c '…'`),
//! so data that names the program is no call. No model, no network, no
//! lock; a grant that cannot be read admits nothing and says so on stderr.

use serde_json::Value;

use crate::ports::operator_grant::{self, Request};
use crate::ports::python_stdlib::shell_tokens;
use crate::ports::shell_text;
use crate::ports::tool_vocabulary::Call;

pub const HOOK_ID: &str = "block-osascript";
pub const GRANT_KIND: &str = "osascript";
const BANNER: &str = "BLOCKED: osascript drives the operator's applications: ";
/// The program that runs AppleScript and JavaScript for Automation
/// (osascript(1)).
const PROGRAM: &str = "osascript";

/// The refusal when the call runs `osascript` with no grant, `None` when it
/// passes.
pub fn evaluate(payload: &Value) -> Option<String> {
    let call = Call::of(payload);
    let executable = call.executable()?;
    if !runs_osascript(&shell_text::effective_payload(payload, &executable)) {
        return None;
    }
    let request = Request {
        gate: HOOK_ID,
        command: Some(&executable),
        paths: &[],
    };
    if operator_grant::granted(payload, &request) {
        return None;
    }
    Some(format!(
        "{BANNER}this call runs `{PROGRAM}`, which clicks, types and reads windows in his \
         applications outside every other gate. Driving an application is computer use: it goes \
         through the CUA route the operator grants (`block-unauthorized-cua`), or through the \
         product's own command that owns the action. {}",
        operator_grant::how_to_grant(GRANT_KIND, HOOK_ID)
    ))
}

/// Whether `line` runs the program, read through every shell it hands a
/// line to.
fn runs_osascript(line: &str) -> bool {
    shell_text::commands(line).into_iter().any(|segment| {
        let tokens = shell_tokens(segment);
        match shell_text::inner_command(&tokens) {
            Some(inner) => runs_osascript(&inner),
            None => shell_text::program(&tokens) == Some(PROGRAM),
        }
    })
}
