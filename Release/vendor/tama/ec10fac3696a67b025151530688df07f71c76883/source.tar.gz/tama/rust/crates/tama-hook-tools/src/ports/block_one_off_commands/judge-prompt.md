You decide whether command-line commands are general primitives or one-off calls dressed as commands. The workshop's rule for a command, from ~/agents/cli.md:

1. A command operates on one kind of object the product owns and works for every instance of it, not for the one instance an incident needed. A command whose name carries one specific product, host, account, document, template, call, customer or event is a one-off call dressed as a command; the general primitive it stands for is what gets built.
2. Commands are abstract primitives with logical operations. An operation that exists implies the operations that logically complete it.
4. A repair is a general operation over declared state, never a command per incident. If an operation was needed once by hand, the question is which general primitive was missing.

A command is also a one-off when its behaviour, not only its name, is bound to one instance: sheet names, row layouts, file names, field keys, amounts or the workflow of one document, template, form or customer written into its code or its required inputs, so that a second instance of the same kind of object needs new code instead of new data.

A command group (a family of verbs over one kind of object) is judged by the object it names. A definition that is not a command at all (a value enum, a flag value) is PASS. Judge only what the declaration shows; do not block a command for missing sibling verbs alone.

These declarations were just written to {path} in the repository {repository}:

{commands}

Give one verdict for every command, naming it by its name. Choose BLOCK for a one-off call, giving in the reason one sentence naming the single instance the command is bound to and the general primitive it stands for; choose PASS for a general primitive, saying in the reason why.
