//! Declaring and clearing a session's task scope: the one implementation the
//! `tama task scope` verbs and Tama Desktop's request route both call, so a
//! scope set from either is checked against Oko's registers the same way.

use std::io::Write;
use std::path::PathBuf;

use serde_json::{json, Value};

use crate::assignment;
use crate::ports::python_stdlib::expanduser;

use super::super::registers::{known_task, open_defect, record_task_scope, unplanned_defect};
use super::super::scope::{declared_repository, working_elsewhere};
use super::super::SCOPE_HOME_RELATIVE;
use super::transcript::transcript_instruction;

/// Why a declaration wrote nothing.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Refused {
    /// The declaration was asked for wrongly: no entry, no repository, a
    /// repository that is no name.
    Usage(String),
    /// A register, the instruction or the scope file could not be read or
    /// written, or refused the entry.
    Failed(String),
}

/// A written declaration: the document kept for the session, and the notice
/// that another session declared the same defect, when one did.
#[derive(Debug, Clone)]
pub struct Declared {
    pub document: Value,
    pub notice: Option<String>,
}

pub(super) fn scope_path(session: &str) -> PathBuf {
    PathBuf::from(expanduser("~"))
        .join(SCOPE_HOME_RELATIVE)
        .join(format!("{session}.json"))
}

/// Declare that `session` serves `defect` or `task` (at least one) in
/// `repositories`, or in the repositories the task's Oko contract lists when
/// none is named. The defect must be open, the task known to Oko, and the
/// declaration is bound to the session's newest captured instruction.
pub fn declared(
    session: &str,
    repositories: &[String],
    defect: Option<&str>,
    task: Option<&str>,
) -> Result<Declared, Refused> {
    let repositories = repositories
        .iter()
        .map(|named| declared_repository(named))
        .collect::<Result<Vec<String>, String>>()
        .map_err(Refused::Usage)?;
    if defect.is_none() && task.is_none() {
        return Err(Refused::Usage(
            "task scope set requires --defect <ID> or --task <ID>: every change belongs to a \
             defect in Oko's register or a task in its task register, and a change that belongs \
             to neither is the drift this gate exists to stop"
                .to_string(),
        ));
    }
    let defect = match defect {
        Some(id) => open_defect(id).map_err(Refused::Failed)?,
        // No defect named: the declaration records none.
        None => String::new(),
    };
    if let Some(refusal) = unplanned_defect(session, &defect) {
        return Err(Refused::Failed(refusal));
    }
    // Another session on the same defect is a colleague, not a lock: the
    // declaration goes ahead, and this session is told who else declared
    // it, so it reads that session's notes first.
    let notice = working_elsewhere(session, &defect);
    let (task_id, contract_scope, task_text) = match task {
        Some(id) => known_task(id).map_err(Refused::Failed)?,
        // No task named: the declaration records none and takes no contract.
        None => (String::new(), Vec::new(), String::new()),
    };
    // The task's contract holds its scope. Repositories named here are
    // written into it; none named means the contract's own list is used.
    let repositories = if repositories.is_empty() {
        contract_scope
    } else {
        if !task_id.is_empty() && repositories != contract_scope {
            record_task_scope(&task_id, &repositories, session).map_err(Refused::Failed)?;
        }
        repositories
    };
    if repositories.is_empty() {
        return Err(Refused::Usage(
            "task scope set requires at least one --repository, or a --task whose Oko contract \
             lists its scope (`oko tasks state <task> --scope <repo>`): work that \
             touches nothing changes nothing"
                .to_string(),
        ));
    }
    let instruction = match assignment::load(session) {
        Ok(Some(instruction)) => instruction,
        Ok(None) => transcript_instruction(session).map_err(Refused::Failed)?,
        Err(error) => {
            return Err(Refused::Failed(format!(
                "cannot read the instruction for session {session}: {error}"
            )))
        }
    };
    let path = scope_path(session);
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent).map_err(|error| {
            Refused::Failed(format!("cannot create {}: {error}", parent.display()))
        })?;
    }
    let task_text = if task_id.is_empty() {
        instruction.text
    } else {
        task_text
    };
    let document = json!({
        "session": session,
        "turn_digest": instruction.turn_digest,
        "task": task_text,
        "repositories": repositories,
        "defect": defect,
        "task_id": task_id,
        "declared_at": tama_core::clock::iso_now(),
    });
    let written = std::fs::File::create(&path).and_then(|mut file| writeln!(file, "{document}"));
    written
        .map_err(|error| Refused::Failed(format!("cannot write {}: {error}", path.display())))?;
    Ok(Declared { document, notice })
}

/// Remove the scope `session` declared. Answers whether there was one.
pub fn cleared(session: &str) -> Result<bool, String> {
    let path = scope_path(session);
    match std::fs::remove_file(&path) {
        Ok(()) => Ok(true),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(false),
        Err(error) => Err(format!("cannot remove {}: {error}", path.display())),
    }
}
