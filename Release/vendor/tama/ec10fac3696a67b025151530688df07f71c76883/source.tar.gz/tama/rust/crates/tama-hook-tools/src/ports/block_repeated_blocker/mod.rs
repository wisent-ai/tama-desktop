//! Logic for `tama-block-repeated-blocker`, registry hook id
//! `block-repeated-blocker`.
//!
//! A Stop gate. It refuses a final message that hands the operator a blocker
//! Oko's defect register already holds open, without naming the defect.
//!
//! A shared dependency failure can affect many sessions. Its existing
//! register entry identifies the problem without requiring another
//! explanation of the same symptoms.
//!
//! A known open defect is not news. Once it is in the register it has an
//! identifier, a date and a finder, and an answer that repeats its symptoms
//! without that identifier is asking the operator to receive the same report
//! again. So: name it by its id in one clause, or leave it out and answer
//! with the work. The register is the memory; prose is not.
//!
//! Keyword matches cannot distinguish a repeated outage report from a
//! legitimate reference to a field or command. The check instead uses
//! register structure: a blocker is identified by its recorded ID.
//!
//! The blocker section itself is a list, not prose: every line names an
//! open blocker from Oko's blocker register (`oko blockers`), existing or
//! just recorded, whose latest check says it still blocks and was made since
//! the operator's latest message. A blocker the agent can resolve is taken
//! off the list with `oko blockers check <id> --resolvable` and the work is
//! done instead.

mod blockers;
mod register;
mod told;
pub(crate) mod unattended;
mod while_open;

use serde_json::Value;
use tama_hooks::session_record::{deny_tool_use, read_payload, Turn};

use crate::ports::block_unsearched_blocker_claim::final_message;
use register::*;

/// The heading the workshop's answer contract gives the section where a
/// blocker is told, in the two languages it is written in. These are not a
/// guess at what a blocker sounds like: they are the operator's own declared
/// answer format, and the section under them is the only place an answer is
/// allowed to tell him something is stopping it.
const BLOCKER_HEADING_PL: &str = "blokery";
/// The same heading as answers in Polish actually write it. A gate that
/// reads only `blokery` lets every answer headed `Blokady` pass unread.
const BLOCKER_HEADING_PL_PLURAL: &str = "blokady";
const BLOCKER_HEADING_EN: &str = "blockers";
/// The headings of the section that hands the operator a step. A step only
/// the operator can take exists because something stopped the work, so it
/// is held to the same register as a blocker: an answer that tells him to
/// restore a host by hand under this heading while the Stado routes that
/// could restore it were never tried is the shape this refuses.
const NEXT_STEPS_HEADING_PL: &str = "następne kroki";
const NEXT_STEPS_HEADING_EN: &str = "next steps";
/// What the same contract says to write when nothing stopped the work.
const NOTHING_PL: &str = "brak";
const NOTHING_EN: &str = "none";

/// Whether the text carries an identifier as Oko prints one: eight
/// hexadecimal characters.
fn names_a_defect(text: &str) -> bool {
    text.split(|letter: char| !letter.is_ascii_alphanumeric())
        .any(|word| {
            word.len() == SHORT_ID_LENGTH && word.chars().all(|letter| letter.is_ascii_hexdigit())
        })
}

/// The lines under the first of `headings`, up to the next heading.
fn section(spoken: &str, headings: &[&str]) -> Option<String> {
    let mut lines = spoken.lines();
    lines.find(|line| {
        let line = line.trim_start_matches(['#', '*', ' ']).trim();
        headings.contains(&line)
    })?;
    let mut said = String::new();
    for line in lines {
        if line.trim_start().starts_with('#') {
            break;
        }
        said.push_str(line);
        said.push('\n');
    }
    Some(said)
}

/// What the answer tells the operator is stopping it.
fn blocker_section(spoken: &str) -> Option<String> {
    section(
        spoken,
        &[
            BLOCKER_HEADING_PL,
            BLOCKER_HEADING_PL_PLURAL,
            BLOCKER_HEADING_EN,
        ],
    )
}

/// What the answer hands the operator to do.
fn next_steps_section(spoken: &str) -> Option<String> {
    section(spoken, &[NEXT_STEPS_HEADING_PL, NEXT_STEPS_HEADING_EN])
}

/// The section with nothing to judge: empty, or the contract's word for none.
fn says_nothing(bare: &str) -> bool {
    // `Brak.` is how the contract's word is written at the end of a sentence;
    // comparing it with `brak` refused every answer that reported nothing.
    let word = bare.trim_end_matches(['.', '!']);
    bare.is_empty() || word == NOTHING_PL || word == NOTHING_EN
}

/// The refusal, or nothing when the answer reports no failure, or its
/// blocker section lists only registered blockers that were just re-checked.
pub fn check(payload: &Value) -> Option<String> {
    let message = match final_message(payload) {
        Ok(message) => message,
        Err(error) => {
            return Some(format!(
                "block-repeated-blocker: TAMA_HOOK_INFRASTRUCTURE: this answer cannot be judged: \
                 {error}"
            ))
        }
    };
    if message.trim().is_empty() {
        return None;
    }
    let spoken = message.to_ascii_lowercase();
    // An unreadable defect register is not an empty one: read as empty, a
    // defect this session recorded and left unattended would let the stop
    // through.
    let document = match document() {
        Ok(document) => document,
        Err(cause) => return Some(format!("block-repeated-blocker: BLOCKED: {cause}")),
    };
    if let Some(refusal) = unattended::refusal(payload, &document) {
        return Some(refusal);
    }
    // A blocker told in prose and written nowhere leaves the register empty
    // while the same outage is explained again and again: each session tells
    // the operator instead of recording it, so the next has nothing to read
    // and tells him again. A blocker worth his attention is worth an entry.
    // An unreadable register, or one holding an entry the gate cannot judge,
    // is not an empty one: a section judged against it would be refused as
    // unregistered, so it is refused for the read.
    let register = blockers::document().and_then(|document| blockers::blockers(&document));
    // A check counts when it was made after the operator last wrote: the
    // turn that answers him is the one that has to have looked.
    let turn_started = match Turn::for_payload(payload) {
        None => Err("this session's transcript cannot be read as a turn".to_string()),
        Some(turn) => match turn.latest_operator_at() {
            Some(at) => blockers::epoch_seconds(at),
            None => Err("the transcript records no time for it".to_string()),
        },
    };
    let serving = blockers::current_work(payload.get("session_id").and_then(Value::as_str));
    if let Some(section) = blocker_section(&spoken) {
        let bare = section.trim();
        if !says_nothing(bare) {
            if let Some(refusal) = while_open::refusal(payload, "Blokady") {
                return Some(refusal);
            }
            if names_a_defect(bare) {
                if let Some(retold) = told::retold(bare, payload, &document) {
                    return Some(retold);
                }
            }
            // The section is a list of registered blockers, each re-checked
            // before it is told; one the agent can resolve is off the list
            // and becomes work.
            let register = match &register {
                Ok(register) => register,
                Err(cause) => return Some(format!("block-repeated-blocker: BLOCKED: {cause}")),
            };
            let serving = match &serving {
                Ok(serving) => serving,
                Err(cause) => return Some(format!("block-repeated-blocker: BLOCKED: {cause}")),
            };
            if let Some(refusal) =
                blockers::refusal("blocker", bare, register, &turn_started, serving)
            {
                return Some(refusal);
            }
        }
    }
    // A step handed to the operator names the registered blocker it resumes,
    // re-checked like one; a step with no blocker behind it is the agent's.
    let steps = next_steps_section(&spoken)?;
    let bare = steps.trim();
    if says_nothing(bare) {
        return None;
    }
    if let Some(refusal) = while_open::refusal(payload, "Następne kroki") {
        return Some(refusal);
    }
    let register = match &register {
        Ok(register) => register,
        Err(cause) => return Some(format!("block-repeated-blocker: BLOCKED: {cause}")),
    };
    let serving = match &serving {
        Ok(serving) => serving,
        Err(cause) => return Some(format!("block-repeated-blocker: BLOCKED: {cause}")),
    };
    blockers::refusal("next-steps", bare, register, &turn_started, serving)
}

pub fn run() {
    let payload = read_payload();
    if let Some(problem) = check(&payload) {
        deny_tool_use(&problem);
    }
}
