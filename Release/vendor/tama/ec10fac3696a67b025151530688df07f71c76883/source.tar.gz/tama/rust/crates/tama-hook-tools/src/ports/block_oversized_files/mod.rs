//! Logic for `tama-block-oversized-files`, registry hook
//! `block-oversized-files`: no source file over 300 lines.
//!
//! Exempt formats are read or rendered as whole documents rather than edited
//! as source modules:
//!
//! - Structured data cannot be split without changing the loader's contract.
//! - A drawing is one rendered picture, even when its format is text.
//! - A manuscript follows the venue's document, bibliography and style layout.
//! - A log preserves an ordered record; splitting it is not module design.
//!
//! These exemptions concern length only, not whether a particular document
//! belongs in source control.
//!
//! A file the repository declared to the audit, with its reason beside it, is
//! exempt as well: a registry a loader reads whole stays editable, which it
//! was not while the declaration was read by the scanner alone.
//!
//! Every other rule still applies to those files: the folder file limit, the
//! new-file justification, the content gates.
//!
//! The count is the file as the write leaves it, rebuilt once by the shared
//! replay every write gate reads: a string edit, a hashline section with its
//! cuts and insertions, an `apply_patch` envelope or a whole write. An
//! estimate from the strings an editor sent lost the extent of a cut, so a
//! split that left a file under the limit was refused as over it.

use tama_hooks::session_record::{deny_tool_use, read_payload};

use crate::ports::check_numeric_literals_payload::path_texts;
use crate::ports::tool_vocabulary::Call;
use crate::ports::violations_declarations::file_is_declared;
use crate::ports::write_payload::{echoed_lines, WritePayload};

/// Structured data and the LaTeX family, matched case-insensitively. Public
/// because the fleet scanner's fast pass has to answer exactly as this hook
/// does, and a second copy of the list is a second answer waiting to drift.
pub const EXEMPT_SUFFIXES: &[&str] = &[
    ".json", ".jsonl", ".ndjson", ".toml", ".yml", ".yaml", ".lock", ".csv", ".tsv", ".svg",
    ".tex", ".bib", ".sty", ".bst", ".cls", ".log",
];

/// A migration is one statement of what was applied, kept by the name the
/// database recorded. Splitting one rewrites history that already ran:
/// `wisent-supabase-echo` carries a 5711-line baseline snapshot and
/// `trading-tools` a 331-line stock-context migration, and neither can be
/// two files without inventing a second applied revision. The folder rule
/// already leaves a migrations directory alone; this is the same ruling
/// about the documents inside it.
const EXEMPT_FOLDERS: &[&str] = &["/migrations/", "/supabase/migrations/"];

/// The operator's own limit: `max_file_lines` in `numeric-provenance.json`.
/// Public because review-commit reads the same limit for every staged file,
/// and a second reading of it is a second answer waiting to drift.
pub fn max_lines() -> Result<usize, String> {
    let stated = crate::ports::stated_numbers::stated("max_file_lines");
    usize::try_from(stated).map_err(|error| {
        format!("the operator's max_file_lines ({stated}) is not a line count here: {error}")
    })
}

/// Whether the line count leaves this path alone.
pub fn exempt(path: &str) -> bool {
    let lowered = path.to_lowercase();
    EXEMPT_SUFFIXES
        .iter()
        .any(|suffix| lowered.ends_with(suffix))
        || EXEMPT_FOLDERS.iter().any(|part| lowered.contains(part))
}

/// The refusal this write earns, if any: a file it leaves longer than the
/// operator's limit, counted in the file as the write leaves it.
pub fn check(payload: &serde_json::Value) -> Option<String> {
    let write = match WritePayload::read(payload) {
        Ok(write) => write,
        Err(error) => return Some(error),
    };
    if write.is_system {
        return None;
    }
    let limit = match max_lines() {
        Ok(limit) => limit,
        Err(error) => return Some(format!("BLOCKED: block-oversized-files: {error}")),
    };
    let call = Call::of(payload);
    let input = call.input()?;
    let files = match path_texts(input, call.cwd()) {
        Ok(files) => files,
        // A write that takes the whole file away leaves no file to count.
        Err(error) => {
            return if write.removes_only && write.content.is_empty() {
                None
            } else {
                Some(format!(
                "BLOCKED: block-oversized-files: the file this write leaves cannot be rebuilt to \
                     count its lines: {error}"
            ))
            }
        }
    };
    for (path, text) in files {
        if exempt(&path) {
            continue;
        }
        match file_is_declared(&path) {
            Ok(true) => continue,
            Ok(false) => {}
            Err(error) => return Some(format!("BLOCKED: {error}")),
        }
        let lines = echoed_lines(&text);
        if lines > limit {
            // The sentence `tama violations find` groups this rule by, the
            // same for an edit as for a file written whole.
            return Some(format!(
                "BLOCKED: File would be {lines} lines (max {limit}). Split into smaller modules."
            ));
        }
    }
    None
}

pub fn run() {
    if let Some(refusal) = check(&read_payload()) {
        deny_tool_use(&refusal);
    }
}
