//! The reviewer session of one run, followed to its end, and how it ended
//! written to `outcome.txt`: the verdict the rounds give the candidate, or
//! why no round was recorded.
//!
//! The reviewer is one session of the OMP program `crate::omp::program`
//! finds, in print mode, in the candidate's repository. It scopes its
//! session to the item (`tama task scope set` reads it from local registers
//! alone), reads the candidate, repairs what it finds, writes its findings
//! and improvements, and records its round with the copy of Tama in the
//! run's directory, so the round is written in the form the verdict reads
//! even when the program that started it was a build that does not outlive
//! the run. Print mode answers one prompt and exits, so the session ends with
//! its review; the brief tells it to stop and say so the moment a step of it
//! is refused.
//!
//! Every line of the stream is kept in the run's events file and the
//! reviewer's last answer is kept for the outcome. Two shapes stop the
//! reviewer as circling, because nothing it does from then on records a
//! round: a call refused twice with the same refusal, and an answer given
//! again with no call made since the one before it, which is a session a
//! stop gate keeps answering after it has nothing left to do. Both are read
//! from OMP's own events: `tool_execution_start` names the tool and its
//! arguments, `tool_execution_end` says with `isError` whether the call was
//! refused and what refused it, and `message_end` carries what the reviewer
//! answered and the calls it made. A call that is refused, then made again
//! after the reviewer corrected what it reads, meets a different refusal or
//! none, and is not circling.

use std::collections::HashMap;
use std::fs::File;
use std::io::{BufRead, BufReader, Write};
use std::path::Path;
use std::process::{Child, Command, Stdio};

use serde_json::Value;
use tama_hook_tools::ports::harsh_review::{read, staged_tree, Entry};

use super::{create, Run, ERRORS_FILE, EVENTS_FILE, OUTCOME_FILE, PRINT_MODE, PROGRAM_FILE};

/// The call named for a reviewer that answered again with no call between.
const ANSWERED_AGAIN: &str = "its answer, given again with no call made since the one before";

/// A call the reviewer made again and that was refused the same way twice.
pub(super) struct Circling {
    pub(super) call: String,
    pub(super) refusal: String,
}

/// What the reviewer's events showed by the time it ended or was stopped.
pub(super) struct Followed {
    pub(super) circling: Option<Circling>,
    pub(super) answer: Option<String>,
}

/// The tool and the arguments an event names: the identity of a call.
fn call(event: &Value) -> String {
    format!("{} {}", event["toolName"], event["args"])
}

/// The text parts of `content`, joined.
fn text(content: &Value) -> String {
    content
        .as_array()
        .into_iter()
        .flatten()
        .filter_map(|part| part["text"].as_str())
        .collect::<Vec<_>>()
        .join("\n")
}

/// Keep `child`'s standard output in `events` until it ends, keeping the
/// reviewer's last answer, and stop the child at the first call refused
/// twice with the same refusal.
pub(super) fn follow(child: &mut Child, events: &mut File) -> Result<Followed, String> {
    let Some(stdout) = child.stdout.take() else {
        return Err("the reviewer session's output was not captured".to_string());
    };
    let mut started: HashMap<String, String> = HashMap::new();
    let mut refused: HashMap<String, String> = HashMap::new();
    let mut answer: Option<String> = None;
    // Whether the reviewer's newest answer came with no call after the one
    // before it.
    let mut idle_answer = false;
    for line in BufReader::new(stdout).lines() {
        let line = line.map_err(|cause| format!("cannot read the reviewer's events: {cause}"))?;
        writeln!(events, "{line}")
            .map_err(|cause| format!("cannot keep the reviewer's events: {cause}"))?;
        // OMP writes its hooks' own notices into the same stream; they are
        // kept above and carry no event.
        let Ok(event) = serde_json::from_str::<Value>(&line) else {
            continue;
        };
        match event["type"].as_str() {
            Some("tool_execution_start") => {
                if let Some(id) = event["toolCallId"].as_str() {
                    started.insert(id.to_string(), call(&event));
                }
            }
            Some("tool_execution_end") if event["isError"] == Value::Bool(true) => {
                let Some(made) = event["toolCallId"].as_str().and_then(|id| started.get(id)) else {
                    continue;
                };
                let refusal = text(&event["result"]["content"]);
                if refused.get(made) == Some(&refusal) {
                    child
                        .kill()
                        .map_err(|cause| format!("cannot stop the circling reviewer: {cause}"))?;
                    let circling = Circling {
                        call: made.clone(),
                        refusal,
                    };
                    return Ok(Followed {
                        circling: Some(circling),
                        answer,
                    });
                }
                refused.insert(made.clone(), refusal);
            }
            Some("message_end") if event["message"]["role"] == "assistant" => {
                let content = &event["message"]["content"];
                let called = content
                    .as_array()
                    .into_iter()
                    .flatten()
                    .any(|part| part["type"] == "toolCall");
                let said = text(content);
                if called {
                    idle_answer = false;
                } else if idle_answer {
                    child
                        .kill()
                        .map_err(|cause| format!("cannot stop the circling reviewer: {cause}"))?;
                    let circling = Circling {
                        call: ANSWERED_AGAIN.to_string(),
                        refusal: said,
                    };
                    return Ok(Followed {
                        circling: Some(circling),
                        answer,
                    });
                } else {
                    idle_answer = true;
                }
                if !said.trim().is_empty() {
                    answer = Some(said);
                }
            }
            _ => {}
        }
    }
    Ok(Followed {
        circling: None,
        answer,
    })
}

/// Run the reviewer session of `run` to its end with `brief` as its prompt,
/// write how it ended to the run's outcome file, a failure included, and
/// answer the same: the verdict the rounds give the candidate whose message
/// is `text`, or why no round counts.
pub(super) fn reviewed(
    directory: &Path,
    run: &Run,
    brief: &str,
    text: &str,
) -> Result<(String, bool), String> {
    let outcome = session(directory, run, brief, text);
    let written = match &outcome {
        Ok((said, _)) => said.clone(),
        Err(cause) => format!("reviews harsh: {cause}"),
    };
    let kept = directory.join(OUTCOME_FILE);
    std::fs::write(&kept, format!("{written}\n")).map_err(|cause| {
        format!(
            "cannot write {}: {cause}; the run ended: {written}",
            kept.display()
        )
    })?;
    outcome
}

fn session(directory: &Path, run: &Run, brief: &str, text: &str) -> Result<(String, bool), String> {
    let tree = &run.tree;
    let mut reviewer = Command::new(&run.harness);
    reviewer
        .args(PRINT_MODE)
        .arg("--cwd")
        .arg(&run.repository)
        .arg(brief)
        .current_dir(&run.repository)
        .env("GIT_INDEX_FILE", &run.index)
        .stdout(Stdio::piped())
        .stderr(create(&directory.join(ERRORS_FILE))?);
    let mut child = reviewer.spawn().map_err(|cause| {
        format!(
            "cannot start the reviewer session ({}): {cause}",
            run.harness
        )
    })?;
    let mut kept_events = create(&directory.join(EVENTS_FILE))?;
    let (followed, status) = stado_wait::blocking(
        stado_wait::Kind::Process,
        format!("the reviewer session over tree {tree}"),
        directory.display(),
        || {
            let followed = follow(&mut child, &mut kept_events);
            // A reviewer whose events can no longer be read is stopped, so
            // it is never left running unwatched.
            if followed.is_err() {
                child.kill()?;
            }
            let status = child.wait()?;
            Ok::<_, std::io::Error>((followed, status))
        },
    )
    .map_err(|cause| format!("cannot read how the reviewer session ended: {cause}"))?;
    // The copy served the reviewer's record; the run keeps its events, not
    // a second program.
    let copy = directory.join(PROGRAM_FILE);
    std::fs::remove_file(&copy)
        .map_err(|cause| format!("cannot remove {}: {cause}", copy.display()))?;
    let kept_where = format!(
        "its brief, events and errors are in {}",
        directory.display()
    );
    let followed = followed?;
    let answered = match &followed.answer {
        Some(answer) => format!("; it answered: {answer}"),
        None => "; it answered nothing".to_string(),
    };
    if let Some(circling) = followed.circling {
        return Err(format!(
            "the reviewer session made the call {} again and was refused the same way, so it \
             was stopped; the refusal: {}; {kept_where}",
            circling.call, circling.refusal
        ));
    }
    if !status.success() {
        return Err(format!(
            "the reviewer session exited with {status}{answered}; {kept_where}"
        ));
    }
    // The reviewer repairs what it finds in the staged candidate, so its
    // round is over the tree staged now, which differs from the one it was
    // handed whenever it repaired anything.
    let staged = staged_tree(&run.repository)?;
    let recorded = read(&run.register)?
        .iter()
        .skip(run.before)
        .any(|entry| match entry {
            Entry::Round { tree: reviewed, .. } => reviewed == &staged,
            Entry::Disposed { .. } | Entry::Settled { .. } | Entry::Owed { .. } => false,
        });
    if !recorded {
        return Err(format!(
            "the reviewer session ended without recording a round over the staged tree {staged} \
             in {}{answered}; {kept_where}",
            run.register.display()
        ));
    }
    let (document, passes) = super::super::harsh::rounds_document(&run.repository, Some(text))?;
    let verdict = match &document["verdict"] {
        Value::String(said) => said.clone(),
        other => {
            return Err(format!(
                "the rounds gave tree {staged} no verdict text: {other}"
            ))
        }
    };
    let repaired = if &staged == tree {
        "it repaired nothing".to_string()
    } else {
        format!(
            "it repaired what it found, so read its repairs with `git diff {tree} {staged}` \
             before committing"
        )
    };
    Ok((
        format!(
            "reviewer session over tree {tree} ended; {repaired}; {kept_where}{answered}\n\
             {verdict}"
        ),
        passes,
    ))
}
