//! Fleet declaration refusals are not transport failures and must not open a relay.
use std::process::Output;

use serde_json::Value;

pub(super) fn terminal(output: &Output) -> Result<Option<String>, String> {
    // Only a JSON answer can carry Stado's route refusal; any other output is the
    // transport's own failure, which the caller reports from the full output.
    let answer: Value = match serde_json::from_slice(&output.stdout) {
        Ok(answer) => answer,
        Err(_not_a_refusal_document) => return Ok(None),
    };
    let Some(details) = answer.get("details") else {
        return Ok(None);
    };
    let Some(state) = details.get("route_state").and_then(Value::as_str) else {
        return Ok(None);
    };
    let field = |name| {
        details
            .get(name)
            .and_then(Value::as_str)
            .filter(|value| !value.is_empty())
            .ok_or_else(|| format!("Stado route refusal omitted details.{name}: {answer}"))
    };
    let machine = field("machine")?;
    let service = field("service")?;
    let consumer = field("consumer")?;
    let cause = answer
        .get("message")
        .and_then(Value::as_str)
        .ok_or_else(|| format!("Stado route refusal omitted message: {answer}"))?;
    // These are Stado's response schema identities, not words inferred from prose.
    let classification = match state {
        "undeclared" => "Brama undeclared",
        "invalid_declaration" => "Brama declaration invalid",
        "refused" => "Brama route refused",
        "unavailable" => "Brama route unavailable",
        _ => {
            return Err(format!(
                "Stado returned an unknown route_state {state:?}: {answer}"
            ))
        }
    };
    let intake = if matches!(state, "undeclared" | "invalid_declaration") {
        match super::observation::record(machine, service, consumer, cause, state) {
            Ok(source) => format!("; infrastructure observation retained in Oko as {source}; defect assessment pending"),
            Err(error) => format!("; infrastructure observation was not recorded: {error}"),
        }
    } else {
        String::new()
    };
    Ok(Some(format!(
        "{classification} on machine {machine} for service {service} consumer {consumer}: {cause}; no judge request was sent{intake}"
    )))
}
