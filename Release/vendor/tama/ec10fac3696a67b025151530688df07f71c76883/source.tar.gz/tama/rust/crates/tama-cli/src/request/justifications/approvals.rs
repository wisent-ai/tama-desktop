//! Tama Desktop's Tests screen: the operator's approvals of test code, read,
//! granted and withdrawn through the same record and the same change
//! `tama tests` makes. Desktop runs outside any agent session, so it is the
//! operator's own hand, as the terminal command is.

use std::path::Path;

use serde_json::{json, Value};

use tama_hook_tools::ports::block_unapproved_tests::approvals;

/// `tests/approvals`: every approval and where the record lives.
pub(super) fn list() -> Result<Value, String> {
    let record = approvals::recorded()?;
    Ok(json!({ "approved": record.approved, "record": approvals::store() }))
}

/// `tests/restore`: the record written again from the attestation ledger,
/// after something other than Tama removed it.
pub(super) fn restore() -> Result<Value, String> {
    let record = approvals::restore()?;
    Ok(json!({
        "action": "restored",
        "approved": record.approved,
        "record": approvals::store(),
        "previous": approvals::previous(),
    }))
}

/// `tests/approve` and `tests/revoke` with `{"paths": [...]}`; a relative
/// path is read against the operator's home, as Desktop has no working
/// directory of its own.
pub(super) fn change(body: &Value, home: &Path, approve: bool) -> Result<Value, String> {
    let paths: Vec<String> = body
        .get("paths")
        .and_then(Value::as_array)
        .ok_or_else(|| "paths is required: a list of files or directories".to_string())?
        .iter()
        .map(|path| {
            path.as_str()
                .map(str::to_owned)
                .ok_or_else(|| "every path is a string".to_string())
        })
        .collect::<Result<_, _>>()?;
    let (changed, record) = approvals::change(&paths, home, approve)?;
    Ok(json!({
        "changed": changed,
        "action": if approve { "approved" } else { "revoked" },
        "approved": record.approved,
        "record": approvals::store(),
    }))
}
