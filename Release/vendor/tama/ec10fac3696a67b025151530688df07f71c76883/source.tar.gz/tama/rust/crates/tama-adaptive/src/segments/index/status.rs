//! `status()` of the segment writer: what the open, ready and acked folders
//! hold, each ready segment that is not intact with why, and the legacy
//! telemetry files the state directory still keeps.

use std::fs;

use serde_json::{json, Value};

use super::reclaim::READY_SUFFIX;
use super::{folder_names, SegmentWriter};

/// The single-file telemetry an earlier layout kept beside the segments.
const LEGACY_NAMES: &[&str] = &[
    "telemetry.prev.jsonl",
    "telemetry.jsonl",
    "repair-queue.jsonl",
];

impl SegmentWriter {
    /// `status()`, or why a segment folder cannot be listed.
    pub fn status(&self) -> Result<Value, String> {
        let ending = |names: Vec<String>, suffix: &str| -> Vec<String> {
            names
                .into_iter()
                .filter(|name| name.ends_with(suffix))
                .collect()
        };
        let open = ending(folder_names(&self.open_dir)?, ".jsonl.open");
        let ready = ending(folder_names(&self.ready_dir)?, READY_SUFFIX);
        let acked = ending(folder_names(&self.acked_dir)?, ".ack.json");
        let mut valid = Vec::new();
        let mut invalid = Vec::new();
        for name in &ready {
            match self.inspect_ready(name) {
                Ok(item) => valid.push(item),
                Err(reason) => invalid.push(json!({ "name": name, "reason": reason })),
            }
        }
        let reclaimable = valid.iter().filter(|item| item.reclaimable).count();
        let mut legacy = Vec::new();
        for name in LEGACY_NAMES {
            let path = self.state_dir.join(name);
            match fs::metadata(&path) {
                Ok(meta) => legacy.push(json!({ "name": name, "size": meta.len() })),
                Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
                Err(error) => {
                    return Err(format!(
                        "the legacy file {} cannot be examined: {error}",
                        path.display()
                    ))
                }
            }
        }
        Ok(json!({
            "open": open.len(),
            "ready": ready.len(),
            "acked": acked.len(),
            "validReady": valid.len(),
            "invalidReady": invalid,
            "reclaimable": reclaimable,
            "legacy": legacy,
        }))
    }
}
