use super::reply::{json_body, send_error, send_json, Reply, Request};
use http::StatusCode;
use serde::Deserialize;

#[derive(Deserialize)]
struct Input {
    roots: Vec<String>,
    // The native contract makes these removal fields optional: no exclusions
    // and preview-only, non-forced operation unless the caller supplies them.
    #[serde(default)]
    except: Vec<String>,
    #[serde(default)]
    apply: bool,
    #[serde(default)]
    force: bool,
}

fn input(request: &Request) -> Result<Input, (u16, String)> {
    let body = json_body(request)?;
    let input: Input = serde_json::from_value(body).map_err(|cause| {
        (
            StatusCode::BAD_REQUEST.as_u16(),
            format!("invalid worktree request: {cause}"),
        )
    })?;
    if input.roots.is_empty() || input.roots.iter().any(String::is_empty) {
        return Err((
            StatusCode::BAD_REQUEST.as_u16(),
            crate::worktrees::MISSING_ROOT.to_string(),
        ));
    }
    if input.except.iter().any(String::is_empty) {
        return Err((
            StatusCode::BAD_REQUEST.as_u16(),
            "worktree exclusion paths must not be empty".to_owned(),
        ));
    }
    Ok(input)
}

fn answer(document: &impl serde::Serialize, writer: &mut Reply) {
    match serde_json::to_value(document) {
        Ok(value) => send_json(writer, StatusCode::OK.as_u16(), &value),
        Err(cause) => send_error(
            writer,
            StatusCode::INTERNAL_SERVER_ERROR.as_u16(),
            &format!("cannot encode worktree result: {cause}"),
        ),
    }
}

pub(super) fn list(request: Request, writer: &mut Reply) {
    let input = match input(&request) {
        Ok(input) => input,
        Err((status, cause)) => return send_error(writer, status, &cause),
    };
    match crate::worktrees::list_document(&input.roots) {
        Ok(document) => answer(&document, writer),
        Err(cause) => send_error(
            writer,
            StatusCode::INTERNAL_SERVER_ERROR.as_u16(),
            &cause.to_string(),
        ),
    }
}

pub(super) fn remove(request: Request, writer: &mut Reply) {
    let input = match input(&request) {
        Ok(input) => input,
        Err((status, cause)) => return send_error(writer, status, &cause),
    };
    match crate::worktrees::remove_document(&input.roots, &input.except, input.apply, input.force) {
        Ok(document) => answer(&document, writer),
        Err(cause) => send_error(
            writer,
            StatusCode::INTERNAL_SERVER_ERROR.as_u16(),
            &cause.to_string(),
        ),
    }
}
