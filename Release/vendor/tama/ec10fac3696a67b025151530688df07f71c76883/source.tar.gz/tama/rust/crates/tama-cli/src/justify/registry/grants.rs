//! Every kind of the operator's grant for one action a gate refuses by
//! default: the label `tama justify record --kind` names it by and the gate
//! that reads it. Every such grant is kept in the one registry
//! `operator_grant` reads, so a new kind is one row here; a gate with a grant
//! of its own that is missing here names a grant nobody can record.

use tama_hook_tools::ports::{
    block_agent_text_in_reply as reply, block_browser_usage, block_calls_before_answer,
    block_consent_switches as switches, block_local_model_server,
    block_narrowed_register_reads as narrowed, block_operator_screen as screen, block_osascript,
    block_repeat_hung_call as hung, block_reserved_changes as reserved, block_script_folders,
    block_side_index, block_unapproved_model as model, block_unauthorized_deletion,
    block_unauthorized_host_change, block_unauthorized_rollback, block_unauthorized_vault_write,
    block_uncleanable_writes as uncleanable, block_unowned_failures as unowned, block_wait_polling,
    pre_wait_tools,
};

/// An operator's grant for one action a gate refuses by default: the label
/// `--kind` names it by and the gate that reads it.
#[derive(PartialEq, Eq)]
pub struct ActionGrant {
    pub label: &'static str,
    pub gate: &'static str,
}

const fn grant(label: &'static str, gate: &'static str) -> ActionGrant {
    ActionGrant { label, gate }
}

/// Every action-grant kind, in the order the usage names them.
pub const ACTION_GRANTS: &[ActionGrant] = &[
    grant("deletion", block_unauthorized_deletion::HOOK_ID),
    grant("host-change", block_unauthorized_host_change::HOOK_ID),
    grant("vault-write", block_unauthorized_vault_write::HOOK_ID),
    grant("rollback", block_unauthorized_rollback::HOOK_ID),
    grant("side-index", block_side_index::HOOK_ID),
    grant(reply::GRANT_KIND, reply::HOOK_ID),
    grant(reserved::GRANT_KIND, reserved::HOOK_ID),
    grant(narrowed::GRANT_KIND, narrowed::HOOK_ID),
    grant(model::GRANT_KIND, model::HOOK_ID),
    grant(screen::GRANT_KIND, screen::HOOK_ID),
    grant(hung::GRANT_KIND, hung::HOOK_ID),
    grant(uncleanable::GRANT_KIND, uncleanable::HOOK_ID),
    grant(
        pre_wait_tools::deadline::GRANT_KIND,
        block_wait_polling::HOOK_ID,
    ),
    grant(
        block_calls_before_answer::GRANT_KIND,
        block_calls_before_answer::HOOK_ID,
    ),
    grant(
        block_local_model_server::GRANT_KIND,
        block_local_model_server::HOOK_ID,
    ),
    grant(
        block_browser_usage::GRANT_KIND,
        block_browser_usage::HOOK_ID,
    ),
    grant(
        block_script_folders::GRANT_KIND,
        block_script_folders::HOOK_ID,
    ),
    grant(block_osascript::GRANT_KIND, block_osascript::HOOK_ID),
    grant(unowned::GRANT_KIND, unowned::HOOK_ID),
    grant(switches::GRANT_KIND, switches::HOOK_ID),
];

/// Every action-grant label, joined as the usage lists them.
pub fn action_labels() -> String {
    ACTION_GRANTS
        .iter()
        .map(|grant| grant.label)
        .collect::<Vec<_>>()
        .join("|")
}
