//! What `tama hooks declare` writes, in the documented order, and the one
//! reading of whether the registry already binds an event to a hook.

use std::path::Path;

use serde_json::Value;

use super::{refuse, run, writer, Declaration};

/// Whether the registry binds this event to the hook. A registry that does
/// not exist yet binds nothing; one that cannot be read or is not JSON is
/// refused naming it: read as no binding, `declare` re-registered every
/// binding over it and `undeclare` reported bindings that were there as
/// already unbound.
pub fn is_bound(registry: &Path, id: &str, event: &str) -> Result<bool, String> {
    let text = match std::fs::read_to_string(registry) {
        Ok(text) => text,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(false),
        Err(error) => {
            return Err(format!(
                "cannot read the hook registry {}: {error}",
                registry.display()
            ))
        }
    };
    let document = serde_json::from_str::<Value>(&text).map_err(|error| {
        format!(
            "the hook registry {} is not valid JSON: {error}",
            registry.display()
        )
    })?;
    Ok(document["events"][event]["hooks"]
        .as_array()
        .into_iter()
        .flatten()
        .any(|hook| hook["id"].as_str() == Some(id)))
}

/// `node shared-hooks/register-hook.mjs <id> <event> <command>`, run in the
/// checkout.
fn register(declaration: &Declaration, event: &str, root: &Path) -> Result<String, String> {
    let args = [
        "node".to_string(),
        "shared-hooks/register-hook.mjs".to_string(),
        declaration.id.clone(),
        event.to_string(),
        declaration.command.clone(),
    ];
    run(Path::new("/usr/bin/env"), &args, root)
}

pub(super) fn plan(declaration: &Declaration, root: &Path, file: &str, dry_run: bool) -> i32 {
    let catalogue = root.join("shared-hooks/catalog-metadata.json");
    let registry = root.join("shared-hooks/registry.json");
    let mut pending: Vec<&str> = Vec::new();
    for binding in &declaration.events {
        match is_bound(&registry, &declaration.id, &binding.event) {
            Ok(true) => {}
            Ok(false) => pending.push(&binding.event),
            Err(cause) => return refuse(&cause),
        }
    }
    if dry_run {
        println!("would record the catalogue entry for {}", declaration.id);
        for binding in &declaration.events {
            let state = if pending.contains(&binding.event.as_str()) {
                "would register"
            } else {
                "already registered"
            };
            println!("{state}: {} on {}", declaration.id, binding.event);
        }
        println!("would reconcile sources and reseal {}", registry.display());
        return tama_core::exit::SUCCESS;
    }
    let record = [
        "--category".to_string(),
        declaration.category.clone(),
        "--description".to_string(),
        declaration.description.clone(),
        "--why".to_string(),
        declaration.why.clone(),
        "--side-effects".to_string(),
        declaration.side_effects.clone(),
        catalogue.display().to_string(),
        declaration.id.clone(),
    ];
    let recorded = writer("record-hook-metadata", &record)
        .and_then(|(program, args)| run(&program, &args, root));
    match recorded {
        Ok(said) => println!("catalogue: {said}"),
        Err(error) => return refuse(&error),
    }
    for event in &pending {
        match register(declaration, event, root) {
            Ok(said) => println!("registry: {said}"),
            Err(error) => return refuse(&error),
        }
    }
    for binding in &declaration.events {
        if !pending.contains(&binding.event.as_str()) {
            println!(
                "registry: {} already bound to {}",
                declaration.id, binding.event
            );
        }
    }
    // The registry carries its own copy of the catalogue entry, which the
    // registry writer refreshes from the catalogue whenever it binds an event.
    // A hook whose events are all bound already would keep the old
    // description, reason and side effects there, so the writer runs once over
    // a bound event: it refreshes the copy and adds no second binding.
    if pending.is_empty() {
        if let Some(binding) = declaration.events.first() {
            match register(declaration, &binding.event, root) {
                Ok(said) => println!("registry: refreshed the catalogue entry: {said}"),
                Err(error) => return refuse(&error),
            }
        }
    }
    let reconciled = writer(
        "reconcile-registry-sources",
        &[registry.display().to_string()],
    )
    .and_then(|(program, args)| run(&program, &args, root));
    match reconciled {
        Ok(said) => println!("sources: {said}"),
        Err(error) => return refuse(&error),
    }
    // The sealer's default is the installed `~/.shared-hooks/registry.json`,
    // so without the path it sealed the machine's copy and left the registry
    // this command had just written unsealed.
    match run(
        Path::new("/usr/bin/env"),
        &[
            "node".to_string(),
            "shared-hooks/seal-registry.mjs".to_string(),
            registry.display().to_string(),
        ],
        root,
    ) {
        Ok(said) => println!("seal: {said}"),
        Err(error) => return refuse(&error),
    }
    println!(
        "{} is declared. It runs where the registry says once the release is installed; \
         `tama enforcement only …` decides what this machine runs, and `tama show {} --json` \
         reads it back. Declaration: {file}",
        declaration.id, declaration.id
    );
    tama_core::exit::SUCCESS
}
