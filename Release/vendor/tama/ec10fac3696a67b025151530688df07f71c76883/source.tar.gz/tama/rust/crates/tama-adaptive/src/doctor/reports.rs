//! The three reads of `tama adaptive`: `status`, `drift` and `queue`. Each
//! builds one document and prints it either as the lines a person reads or,
//! with `--json`, as that document, so the two forms cannot disagree. A
//! state or row a read cannot render is the error naming it: rendered as
//! `undefined` or `?`, it read as a hook with no record.

use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::path::Path;

use super::evidence::live_script_path;
use super::repair::{build_catalog_hooks, read_closed_telemetry_events};
use crate::engine::Engine;
use crate::telemetry::open_telemetry;
use crate::util::{js_string, repo_root};
use tama_core::exit;

fn hook_ids(core: &Engine) -> Vec<String> {
    let mut ids: Vec<String> = Vec::new();
    for config in core.registry.events.values() {
        for hook in &config.hooks {
            if !hook.id.is_empty() && !ids.contains(&hook.id) {
                ids.push(hook.id.clone());
            }
        }
    }
    ids.sort();
    ids
}

fn print(document: &Value, lines: &[String], json_output: bool) {
    if json_output {
        println!("{}", tama_core::json::pretty(document));
    } else {
        for line in lines {
            println!("{line}");
        }
    }
}

/// The length of the list `state` keeps under `key`, `when_none` for a
/// state that keeps none yet, or why what it keeps is not a list.
fn listed(state: &Value, key: &str, when_none: &str, id: &str) -> Result<String, String> {
    match state.get(key) {
        Some(Value::Array(items)) => Ok(items.len().to_string()),
        Some(Value::Null) | None => Ok(when_none.to_string()),
        Some(other) => Err(format!(
            "the adaptive state of {id} keeps {other} under {key}, not a list"
        )),
    }
}

pub(super) fn status(core: &Engine, json_output: bool) -> Result<i32, String> {
    let states = core.state_snapshot(None)?;
    let mut ids = hook_ids(core);
    if let Some(map) = states.as_object() {
        for id in map.keys() {
            if !ids.contains(id) {
                ids.push(id.clone());
            }
        }
    }
    ids.sort();
    let autonomy = &core.policy.autonomy;
    let policy = json!({
        "autonomy": autonomy.automatic_ceiling,
        "lexical": autonomy.lexical_frustration_and_model,
        "explicitCorrection": autonomy.explicit_causal_correction,
        "repair": autonomy.repair,
    });
    let mut lines = vec![format!(
        "autonomy={} lexical={} explicitCorrection={} repair={}",
        autonomy.automatic_ceiling,
        autonomy.lexical_frustration_and_model,
        autonomy.explicit_causal_correction,
        autonomy.repair,
    )];
    let mut hooks = Vec::new();
    for id in &ids {
        let tier = core.tier_of(id);
        let state = core.state_snapshot(Some(id))?;
        let identity = core.source_identity(id);
        let phase = state
            .get("phase")
            .and_then(Value::as_str)
            .ok_or_else(|| format!("the adaptive state of {id} names no phase: {state}"))?;
        let baseline = listed(&state, "recoveredRecord", "cold", id)?;
        let open_run = listed(&state, "activeRun", "none", id)?;
        let contested = state
            .get("contestedBlockObserved")
            .and_then(|v| v.as_bool())
            == Some(true);
        let source = if identity.verifiable {
            "verified"
        } else {
            "unverified"
        };
        let mode = core.effective_mode(id)?;
        lines.push(format!(
            "{id} tier={} mode={mode} phase={phase} baseline={baseline} openRun={open_run} source={source} contested={contested}",
            tier.name
        ));
        hooks.push(json!({
            "id": id,
            "tier": tier.name,
            "mode": mode,
            "phase": phase,
            "baseline": baseline,
            "openRun": open_run,
            "source": source,
            "contested": contested,
        }));
    }
    let transport = open_telemetry(&core.state_dir);
    let telemetry = transport.status();
    transport.close();
    let telemetry = telemetry?;
    lines.push(format!(
        "telemetry={}",
        tama_core::json::compact(&telemetry)
    ));
    let document = json!({ "policy": policy, "hooks": hooks, "telemetry": telemetry });
    print(&document, &lines, json_output);
    Ok(exit::SUCCESS)
}

/// The file's SHA-256, or `None` when it is missing; a file that cannot be
/// examined or read is an error naming it, since drift would otherwise read
/// it as missing.
fn hash_file(path: Option<&Path>) -> Result<Option<String>, String> {
    let Some(path) = path else { return Ok(None) };
    if !tama_core::presence::present(path).map_err(|error| error.to_string())? {
        return Ok(None);
    }
    let bytes = std::fs::read(path)
        .map_err(|error| format!("{} cannot be read: {error}", path.display()))?;
    Ok(Some(format!("{:x}", Sha256::digest(&bytes))))
}

pub(super) fn drift(json_output: bool) -> Result<i32, String> {
    let root = repo_root()?;
    let mut lines = Vec::new();
    let mut hooks = Vec::new();
    let mut drifted = Vec::new();
    for hook in &build_catalog_hooks(&root)? {
        let Some(source_path) = &hook.source_path else {
            continue;
        };
        let live = match hook.command.as_deref() {
            Some(command) => live_script_path(command)?,
            None => None,
        };
        let archive = root.join(source_path);
        let live_hash = hash_file(live.as_deref().map(Path::new))?;
        let archive_hash = hash_file(Some(&archive))?;
        let verdict = if live_hash.is_none() || archive_hash.is_none() {
            "MISSING"
        } else if live_hash == archive_hash {
            "OK"
        } else {
            "DRIFT"
        };
        if live_hash.is_some() && live_hash == archive_hash {
            lines.push(format!("OK {}", hook.id));
        } else {
            drifted.push(hook.id.clone());
            lines.push(format!(
                "{verdict} {} live={} archive={}",
                hook.id,
                match &live {
                    Some(path) => path.clone(),
                    None => "(no live script found)".to_string(),
                },
                archive.display()
            ));
        }
        hooks.push(json!({
            "id": hook.id,
            "verdict": verdict,
            "live": live,
            "archive": archive.display().to_string(),
        }));
    }
    print(
        &json!({ "hooks": hooks, "drifted": drifted.len() }),
        &lines,
        json_output,
    );
    Ok(if drifted.is_empty() {
        exit::SUCCESS
    } else {
        exit::FAILURE
    })
}

/// The text a repair row keeps under `key`, or why it keeps none.
fn row_text(row: &Value, key: &str) -> Result<String, String> {
    match row.get(key) {
        Some(Value::Null) | None => Err(format!("the repair proposal {row} carries no {key}")),
        Some(value) => Ok(js_string(value)),
    }
}

pub(super) fn queue(core: &Engine, json_output: bool) -> Result<i32, String> {
    let rows: Vec<Value> = read_closed_telemetry_events(&core.state_dir)?
        .into_iter()
        .filter(|row| row.get("type").and_then(|v| v.as_str()) == Some("repair_proposal"))
        .collect();
    let mut lines = Vec::new();
    if rows.is_empty() {
        lines.push("repair queue empty".to_string());
    }
    for row in &rows {
        let millis = row
            .get("ts")
            .and_then(Value::as_i64)
            .ok_or_else(|| format!("the repair proposal {row} carries no time (ts)"))?;
        let timestamp = tama_core::clock::iso(tama_core::clock::from_millis(millis)?);
        lines.push(format!(
            "{timestamp} {} kind={} evidence={}",
            row_text(row, "id")?,
            row_text(row, "kind")?,
            row_text(row, "evidence")?
        ));
    }
    print(&json!({ "requests": rows }), &lines, json_output);
    Ok(exit::SUCCESS)
}
