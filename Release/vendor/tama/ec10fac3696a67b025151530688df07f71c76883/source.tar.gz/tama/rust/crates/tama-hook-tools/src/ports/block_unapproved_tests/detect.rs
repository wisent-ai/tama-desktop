//! What counts as test code: a file whose path follows a test convention of
//! its ecosystem, or a change that carries its language's test marker. Both
//! are read from structure — a directory or file-name convention, an
//! attribute, a collected function — never from the words of a sentence.

use std::sync::LazyLock;

use regex::Regex;

use crate::ports::transport_common as common;

/// A directory of tests at any depth: `tests/`, `test/`, `__tests__/`.
static TEST_DIRECTORY: LazyLock<Regex> = LazyLock::new(|| common::compile(r"(?i)(^|/)_*tests?_*/"));
/// A file whose stem ends in the convention: `parser_test.go`,
/// `parser.test.ts`, `parser-test.js`.
static TEST_SUFFIX: LazyLock<Regex> =
    LazyLock::new(|| common::compile(r"(?i)[_.-]test\.[a-z0-9]+$"));
/// Pytest's collected module, `test_parser.py`, and Rust's test module file,
/// `tests.rs`: the two ecosystems whose convention is a file-name prefix. A
/// page or a note merely called `tests` is not test code.
static PYTEST_MODULE: LazyLock<Regex> = LazyLock::new(|| common::compile(r"(^|/)test_[^/]*\.py$"));
static RUST_TEST_MODULE: LazyLock<Regex> = LazyLock::new(|| common::compile(r"(^|/)tests\.rs$"));
/// The JavaScript family's second spelling: `parser.spec.ts`.
static SPEC_SUFFIX: LazyLock<Regex> = LazyLock::new(|| common::compile(r"(?i)\.spec\.[a-z0-9]+$"));
/// Swift and Kotlin name the case class after its subject: `ParserTests.swift`.
static CAMEL_SUFFIX: LazyLock<Regex> =
    LazyLock::new(|| common::compile(r"[a-z0-9]Tests?\.[A-Za-z0-9]+$"));
/// Rust's test attribute, with or without a runtime path, and the test-only
/// configuration gate.
static RUST_MARKER: LazyLock<Regex> =
    LazyLock::new(|| common::compile(r"#\[(cfg\()?([A-Za-z_]+::)*test\)?\]"));
/// A Python function the test collector runs.
static PYTHON_MARKER: LazyLock<Regex> =
    LazyLock::new(|| common::compile(r"(?m)^\s*(async\s+)?def\s+test_[A-Za-z0-9_]*\s*\("));
/// Swift Testing's macro; the class-based framework is caught by its file name.
static SWIFT_MARKER: LazyLock<Regex> = LazyLock::new(|| common::compile(r"[@]Test\b"));
/// The directory Next.js's App Router serves routes from: every directory
/// below it is a URL segment, as
/// https://nextjs.org/docs/app/getting-started/project-structure declares.
const NEXT_APP_DIRECTORY: &str = "app";

/// Whether a file at `path` is test code by where it lives or what it is called.
///
/// A `test/` directory inside a Next.js `app/` tree is a URL segment:
/// `app/api/test/credit/route.ts` serves `/api/test/credit`. Every file below
/// it is product code by its place; a test there is caught by its name or by
/// the marker it carries.
pub fn is_test_path(path: &str) -> bool {
    let path = path.replace('\\', "/");
    let named = [
        &*TEST_SUFFIX,
        &*PYTEST_MODULE,
        &*RUST_TEST_MODULE,
        &*SPEC_SUFFIX,
        &*CAMEL_SUFFIX,
    ]
    .iter()
    .any(|convention| convention.is_match(&path));
    if named {
        return true;
    }
    TEST_DIRECTORY.find(&path).is_some_and(|directory| {
        !path[..directory.start()]
            .split('/')
            .any(|component| component == NEXT_APP_DIRECTORY)
    })
}

/// Whether `text` — what a change writes — carries a test marker.
pub fn carries_test_code(text: &str) -> bool {
    !test_code_lines(text).is_empty()
}

/// Every line of `text`, a whole file as a write leaves it, on which a test
/// marker starts, as `line N: …`.
pub fn test_code_lines(text: &str) -> Vec<String> {
    let mut starts: Vec<usize> = [&*RUST_MARKER, &*PYTHON_MARKER, &*SWIFT_MARKER]
        .iter()
        .flat_map(|marker| marker.find_iter(text).map(|found| found.start()))
        .collect();
    starts.sort_unstable();
    let mut lines: Vec<String> = starts
        .into_iter()
        .map(|start| crate::ports::check_numeric_literals_payload::line_at(text, start))
        .collect();
    lines.dedup();
    lines
}
