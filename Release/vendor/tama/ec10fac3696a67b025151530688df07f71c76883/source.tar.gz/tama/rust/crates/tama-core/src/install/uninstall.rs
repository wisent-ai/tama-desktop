//! `tama uninstall`: the reverse of `tama install`. Each managed dispatcher
//! is removed and the hook it displaced — kept beside it as
//! `<hook>.before-tama` — is put back; a hook Tama did not write is left
//! alone, by name. The global `core.hooksPath` is unset only when asked and
//! only when it still points at the directory Tama installed into, so a
//! person's own hooks path is never taken away.

use std::fs;
use std::path::Path;

use serde::Serialize;

use super::dispatcher::{expand_home, join_path, resolve_path};
use super::{current_global_hooks_path, home_or_env, MANAGED_HEADER};
use crate::git::Git;
use crate::{err, Result};

/// Options for [`uninstall_global_git`].
#[derive(Debug, Clone, Default)]
pub struct UninstallOptions {
    pub home: Option<String>,
    pub hooks_path: Option<String>,
    pub unset_global_config: bool,
}

/// What became of one hook name.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct RemovedHook {
    pub target: String,
    /// `removed`, `restored` (the displaced hook is back in place), `absent`,
    /// or `kept` (a hook Tama did not write).
    pub outcome: &'static str,
}

/// Result of [`uninstall_global_git`].
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct UninstallResult {
    pub hooks_path: String,
    pub pre_commit: RemovedHook,
    pub pre_push: RemovedHook,
    pub commit_msg: RemovedHook,
    pub reference_transaction: RemovedHook,
    pub unset_global_config: bool,
}

/// Whether the hook file at `path`, which exists, is a dispatcher Tama
/// wrote. One that cannot be read is the error, naming it: whether it is
/// Tama's to remove is unknown, so it is neither kept nor removed silently.
fn is_managed(path: &str) -> Result<bool> {
    let bytes = fs::read(path).map_err(|error| {
        err(format!(
            "cannot read the Git hook {path} to see whether Tama wrote it: {error}; make it readable and run the uninstall again"
        ))
    })?;
    let text = String::from_utf8_lossy(&bytes);
    let mut lines = text.split('\n');
    Ok(lines.next() == Some("#!/bin/sh") && lines.next() == Some(MANAGED_HEADER))
}

fn remove_one(hooks_path: &str, hook_name: &str) -> Result<RemovedHook> {
    let target = join_path(hooks_path, hook_name);
    let backup = join_path(hooks_path, &format!("{hook_name}.before-tama"));
    if !crate::presence::present(Path::new(&target))? {
        return Ok(RemovedHook {
            target,
            outcome: "absent",
        });
    }
    if !is_managed(&target)? {
        return Ok(RemovedHook {
            target,
            outcome: "kept",
        });
    }
    fs::remove_file(&target)?;
    if crate::presence::present(Path::new(&backup))? {
        fs::rename(&backup, &target)?;
        return Ok(RemovedHook {
            target,
            outcome: "restored",
        });
    }
    Ok(RemovedHook {
        target,
        outcome: "removed",
    })
}

/// Remove every managed dispatcher in `hooks_path` whose hook is not one of
/// `kept`, restoring what each displaced. A dispatcher an earlier build
/// wrote for a hook this build does not dispatch would call a `tama hook`
/// this build does not have, and Git would refuse every operation that hook
/// runs on with a usage error; installing a build leaves only its own.
pub(super) fn retire_others(hooks_path: &str, kept: &[&str]) -> Result<Vec<RemovedHook>> {
    // Every name is read before any is removed: restoring a displaced hook
    // renames inside the directory being listed.
    let mut names = Vec::new();
    for entry in fs::read_dir(hooks_path)? {
        names.push(entry?.file_name().to_string_lossy().into_owned());
    }
    let mut retired = Vec::new();
    for name in names {
        if kept.contains(&name.as_str()) {
            continue;
        }
        let path = join_path(hooks_path, &name);
        if !fs::metadata(&path)?.is_file() || !is_managed(&path)? {
            continue;
        }
        retired.push(remove_one(hooks_path, &name)?);
    }
    Ok(retired)
}

/// Remove the managed dispatchers from the hooks path `install` wrote to —
/// the one named, else the global `core.hooksPath`, else Tama's default —
/// restoring what they displaced. Both hooks are handled before the global
/// config is touched, and a hooks path that is not the configured one is
/// never unset.
pub fn uninstall_global_git(options: &UninstallOptions) -> Result<UninstallResult> {
    let home = home_or_env(options.home.as_deref());
    let configured = current_global_hooks_path(Some(&home))?;
    // The hooks path named, else the configured one, else the one `install`
    // writes to when neither is given.
    let target_path = match (options.hooks_path.clone(), configured.clone()) {
        (Some(named), _) => named,
        (None, Some(configured)) => configured,
        (None, None) => join_path(&home, ".config/git/hooks"),
    };
    let hooks_path = resolve_path(&expand_home(&target_path, &home))?;
    let pre_commit = remove_one(&hooks_path, "pre-commit")?;
    let pre_push = remove_one(&hooks_path, "pre-push")?;
    let commit_msg = remove_one(&hooks_path, "commit-msg")?;
    let reference_transaction = remove_one(&hooks_path, "reference-transaction")?;
    let mut unset = false;
    if options.unset_global_config {
        // A configured path that cannot be resolved is refused with its
        // cause, not taken as some other tool's.
        let still_configured = match configured.as_deref() {
            Some(path) => resolve_path(&expand_home(path, &home))? == hooks_path,
            None => false,
        };
        if !still_configured {
            return Err(err(format!(
                "core.hooksPath is not {hooks_path}, so it is not Tama's to unset; the dispatchers were handled first"
            )));
        }
        Git::of(None)
            .variables(&[("HOME", home.as_str())])
            .bytes(&["config", "--global", "--unset", "core.hooksPath"])
            .map_err(|error| err(format!("cannot unset core.hooksPath: {error}")))?;
        unset = true;
    }
    Ok(UninstallResult {
        hooks_path,
        pre_commit,
        pre_push,
        commit_msg,
        reference_transaction,
        unset_global_config: unset,
    })
}
