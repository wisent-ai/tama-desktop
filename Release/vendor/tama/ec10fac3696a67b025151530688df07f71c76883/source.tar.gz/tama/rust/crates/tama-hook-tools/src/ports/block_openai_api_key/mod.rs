//! Ports `shared-hooks/block_openai_api_key.py` (hook `block-openai-api-key`).
//!
//! A `PreToolUse` gate over three surfaces: the command of a shell call, the
//! file a write leaves (a hashline section, a string edit, a patch or a
//! notebook cell edit replayed on the file, a written file's content), and
//! the content of a read target that already exists on disk. A write whose
//! file the replay cannot rebuild is refused with the cause: the text a
//! patch or cell writes is not the file it leaves.
//!
//! It refuses credential material only, never a name or prose that mentions
//! one: a test called after the gate, a message naming the variable, a
//! document citing the endpoint all pass. Material is
//!
//! - a key-shaped value: `sk-`, an optional `proj-`, `svcacct-` or `admin-`,
//!   then at least [`KEY_BODY_MINIMUM`] characters of the key alphabet that
//!   mix digits, capitals and small letters, as OpenAI issues them;
//! - an assignment that gives one of the credential variables a value
//!   (`NAME=value`, `NAME: value`, `"NAME": "value"`), the variable spelled
//!   in capitals as the environment spells it;
//! - an authorization header that carries a bearer value in the same text
//!   as a request URL of the vendor's API endpoint; a header or a host named
//!   in prose carries no credential.

use regex::Regex;
use serde_json::Value;
use tama_hooks::session_record::deny_tool_use;

use crate::ports::check_numeric_literals_payload::path_texts;
use crate::ports::tool_vocabulary::Call;
use crate::ports::{pystr, python_stdlib};

/// A key's prefix, its optional kind, and the alphabet of its body.
const KEY_SHAPE: &str = r"\bsk-(?:proj-|svcacct-|admin-)?(?P<body>[A-Za-z0-9_-]+)";
/// The shortest key body OpenAI issues: a legacy key carries 48 characters
/// after `sk-`, a project key far more; 32 leaves no slug or branch name in.
const KEY_BODY_MINIMUM: usize = 32;
/// The credential variables, given a value. The value is anything up to
/// whitespace, a quote or a closing bracket; an empty one is no value.
const ASSIGNMENT: &str = concat!(
    r#"\b(?:OPENAI_API_(?:KEY|BASE|URL)|CHATGPT_RANK_API_KEY)["']?\s*[:=]\s*["']?"#,
    r#"(?P<value>[^\s"'`;,)}\]]+)"#
);
/// A request to the vendor's API endpoint: a URL, not a mention of the host.
const ENDPOINT: &str = r"(?i)\bhttps?://(?:api\.openai\.com|[^\s/]*openai\.com/v1)\b";
/// An authorization header that carries a credential: a bearer value read
/// from a variable, or one of at least eight token characters. A header
/// merely named (in prose or a table) carries none.
const AUTHORIZATION: &str = concat!(
    r"(?i)\b(?:authorization\s*:\s*)?bearer\s+",
    r"(?:\$\{?[A-Za-z_][A-Za-z0-9_]*|[A-Za-z0-9._~+/-]{8,})"
);

const BLOCK_HEAD: &str = "BLOCKED: OpenAI API-key usage is forbidden for this agent.";
const COMMAND_REASON: &str = "command carries OpenAI API credential material";
const READ_REASON: &str = "read target contains OpenAI API credential material: ";
const WRITE_REASON: &str = "the file this write leaves carries OpenAI API credential material: ";
const WRITE_UNREBUILT_REASON: &str = "the file this write leaves cannot be rebuilt to judge it: ";
/// How many characters of a matched key a refusal shows; the rest is not
/// echoed into the transcript.
const SHOWN_KEY_CHARACTERS: usize = 10;

/// What `str(Path(value))` splits and drops.
const SEPARATOR: &str = "/";
const CURRENT_DIR: &str = ".";

fn crash(cause: &str) -> ! {
    crate::ports::transport_common::python_crash(&format!("block_openai_api_key: {cause}"))
}

/// The gate's readings, compiled once per run.
struct Material {
    key: Regex,
    assignment: Regex,
    endpoint: Regex,
    authorization: Regex,
}

impl Material {
    fn new() -> Self {
        let compile = |pattern: &str| match Regex::new(pattern) {
            Ok(pattern) => pattern,
            Err(error) => crash(&format!(
                "the credential pattern {pattern} does not compile: {error}"
            )),
        };
        Self {
            key: compile(KEY_SHAPE),
            assignment: compile(ASSIGNMENT),
            endpoint: compile(ENDPOINT),
            authorization: compile(AUTHORIZATION),
        }
    }

    /// The credential material `text` carries: the exact text that holds it,
    /// which locates its lines, and what the refusal shows of it, which never
    /// repeats a key or a value. None when it carries none.
    fn find<'a>(&self, text: &'a str) -> Option<(&'a str, String)> {
        for found in self.key.captures_iter(text) {
            let body = found.name("body").map_or("", |body| body.as_str());
            if key_shaped(body) {
                let whole = found.get_match().as_str();
                let shown = pystr::head_chars(whole, SHOWN_KEY_CHARACTERS);
                return Some((whole, format!("{shown}…")));
            }
        }
        if let Some(found) = self.assignment.find(text) {
            let whole = found.as_str();
            let name_end = whole.find(['=', ':']).map_or(whole.len(), |at| at + 1);
            return Some((whole, format!("{}…", &whole[..name_end])));
        }
        if let (Some(endpoint), Some(_)) = (self.endpoint.find(text), self.authorization.find(text))
        {
            let endpoint = endpoint.as_str();
            return Some((endpoint, format!("an authorization header to {endpoint}")));
        }
        None
    }
}

/// Whether a body after `sk-` is a key: long enough and mixing digits,
/// capitals and small letters, as issued keys do and words never do.
fn key_shaped(body: &str) -> bool {
    body.len() >= KEY_BODY_MINIMUM
        && body.chars().any(|c| c.is_ascii_digit())
        && body.chars().any(|c| c.is_ascii_uppercase())
        && body.chars().any(|c| c.is_ascii_lowercase())
}

fn block(reason: &str, sample: &str) -> ! {
    let mut banner = format!("{BLOCK_HEAD}\nReason: {reason}");
    if !sample.is_empty() {
        banner.push_str(&format!("\nMatched: {sample}"));
    }
    deny_tool_use(&banner)
}

/// The payload as JSON. Blank input carries nothing to judge; a payload that
/// is not JSON, or not text, is a crash naming why.
fn payload() -> Value {
    let mut raw = String::new();
    if let Err(error) = std::io::Read::read_to_string(&mut std::io::stdin(), &mut raw) {
        crash(&format!("the payload cannot be read: {error}"));
    }
    if pystr::strip(&raw).is_empty() {
        return Value::Object(Default::default());
    }
    match serde_json::from_str(&raw) {
        Ok(data) => data,
        Err(error) => crash(&format!("the payload is not JSON: {error}")),
    }
}

/// `str(Path(value))` — repeated separators collapse and `.` components drop,
/// but `..` survives.
fn pure_path_text(path: &str) -> String {
    let absolute = path.starts_with(SEPARATOR);
    let joined = path
        .split(SEPARATOR)
        .filter(|part| !part.is_empty() && *part != CURRENT_DIR)
        .collect::<Vec<&str>>()
        .join(SEPARATOR);
    if absolute {
        return format!("{SEPARATOR}{joined}");
    }
    if joined.is_empty() {
        return CURRENT_DIR.to_string();
    }
    joined
}

/// The file a read names, `~` expanded, when it names one as text.
fn read_path(call: &Call) -> Option<String> {
    let text = call.path()?;
    Some(pure_path_text(&python_stdlib::expanduser(&pure_path_text(
        text,
    ))))
}

/// The text of `path` with undecodable bytes dropped (a lossy decode would
/// splice a replacement character into the middle of a candidate key). A
/// file that cannot be read is a refusal naming it: read as empty, a
/// credential in it would pass.
fn read_ignoring_errors(path: &str) -> String {
    let bytes = match std::fs::read(path) {
        Ok(bytes) => bytes,
        Err(error) => block(&format!("{READ_REASON}{path} cannot be read: {error}"), ""),
    };
    let mut out = String::new();
    let mut rest = bytes.as_slice();
    loop {
        match std::str::from_utf8(rest) {
            Ok(text) => {
                out.push_str(text);
                return out;
            }
            Err(error) => {
                let (good, bad) = rest.split_at(error.valid_up_to());
                out.push_str(&String::from_utf8_lossy(good));
                rest = match error.error_len() {
                    Some(length) => &bad[length..],
                    None => &[],
                };
            }
        }
    }
}

pub fn run() {
    let data = payload();
    if !data.is_object() {
        crash("the payload is not a mapping");
    }
    let call = Call::of(&data);
    let material = Material::new();
    if let Some(command) = call.command() {
        if let Some((_, shown)) = material.find(command) {
            block(COMMAND_REASON, &shown);
        }
        return;
    }
    // A write: the file it leaves, whoever wrote each line of it. A write
    // whose file the replay cannot rebuild is refused with the cause: the
    // text a patch or notebook cell writes is not the file it leaves.
    if call.is_write() {
        if let Some(input) = call.input() {
            match path_texts(input, call.session_cwd()) {
                Ok(texts) if !texts.is_empty() => {
                    for (path, text) in texts {
                        if let Some((held, shown)) = material.find(&text) {
                            // Only the line numbers: the line itself holds
                            // the material.
                            let lines: Vec<String> =
                                crate::ports::check_numeric_literals_payload::lines_holding(
                                    &text, held,
                                )
                                .iter()
                                .map(|line| line.split(':').next().unwrap_or_default().to_string())
                                .collect();
                            block(
                                &format!("{WRITE_REASON}{path} ({})", lines.join("; ")),
                                &shown,
                            );
                        }
                    }
                    return;
                }
                Ok(_) => {}
                Err(cause) => block(&format!("{WRITE_UNREBUILT_REASON}{cause}"), ""),
            }
        }
    }
    // A read of a file that exists.
    if let Some(path) = read_path(&call) {
        if std::fs::metadata(&path).is_ok_and(|meta| meta.is_file()) {
            let sample = read_ignoring_errors(&path);
            if let Some((_, shown)) = material.find(&sample) {
                block(&format!("{READ_REASON}{path}"), &shown);
            }
        }
    }
}
