//! What Tama Desktop asks of the attestations, answered by the functions
//! `tama attestation` runs.
//!
//! `attestation/required` answers the two carried standards: the claims a
//! commit message carries for `review-push`, and each stop hook's claims an
//! answer ends with. `attestation/check` names what one commit
//! (`"commit": "REV"` with the `"repository"` it is in, since the Desktop has
//! no working directory; its message or its attestation note) or one answer
//! (`"turn": "HOOK"` with `"answer"`) still lacks — the refusal the gate
//! would give. `attestation/attest-commit` keeps `"attestation"` as the note
//! of an existing `"commit"` in `"repository"` when it carries every claim,
//! and `attestation/pending` reads every commit `"repository"`'s branch
//! carries over its upstream, as `tama attestation pending` does.
//!
//! A session's recorded attestation: `attestation/record` judges
//! `{"attestation": {...}, "session": "ID"}` and keeps it when it stands,
//! `attestation/show` and `attestation/remove` read or delete one record,
//! `attestation/standard` reads the task standard and `attestation/list`
//! every session record. `attestation/registries` reads every attestation of
//! every registry as one record and `attestation/verify` re-reads what each
//! names (`registries`). Each refusal carries the command's own sentence.

use std::path::Path;

use http::StatusCode;
use serde_json::{json, Value};
use tama_hook_tools::ports::task_attestation::subject::{self, Subject};

use super::{carried, registries};
use crate::brama::desktop::Refused;

fn refused(sentence: String) -> Refused {
    (StatusCode::BAD_REQUEST, sentence)
}

fn failed(sentence: String) -> Refused {
    (StatusCode::INTERNAL_SERVER_ERROR, sentence)
}

/// A text field of the body, absent when it is missing or null.
fn named<'a>(operation: &str, body: &'a Value, field: &str) -> Result<Option<&'a str>, Refused> {
    match body.get(field) {
        None | Some(Value::Null) => Ok(None),
        Some(Value::String(text)) if !text.is_empty() => Ok(Some(text.as_str())),
        Some(other) => Err(refused(format!(
            "{operation}: {field} must be text, got {other}"
        ))),
    }
}

/// The session the body names.
fn subject_of(operation: &str, body: &Value) -> Result<Subject, Refused> {
    let Some(session) = named(operation, body, "session")? else {
        return Err(refused(format!(
            "{operation} needs \"session\": \"<session id>\""
        )));
    };
    Subject::session(session).map_err(|error| refused(format!("{operation}: {error}")))
}

/// The commit standard and the turn-end standard, as `standard --commit` and
/// `standard --turn` print them.
pub(crate) fn required() -> Value {
    json!({ "commit": carried::standard(true), "turn": carried::standard(false) })
}

/// What one commit message or one answer still lacks. A text that lacks a
/// claim is an answer (`stands: false` with `missing`), not a failed request.
pub(crate) fn check(body: &Value) -> Result<Value, Refused> {
    let operation = "attestation/check";
    let commit = named(operation, body, "commit")?;
    let repository = named(operation, body, "repository")?;
    let turn = named(operation, body, "turn")?;
    let answer = named(operation, body, "answer")?;
    match (commit, repository, turn, answer) {
        (Some(_), Some(_), None, None) | (None, None, Some(_), Some(_)) => {}
        _ => {
            return Err(refused(format!(
                "{operation} needs \"commit\" with \"repository\", or \"turn\" with \"answer\""
            )))
        }
    }
    carried::checked(commit, repository.map(Path::new), turn.zip(answer))
        .map_err(|error| refused(format!("{operation}: {error}")))
}

/// Keep the attestation of an existing commit beside it, as `tama
/// attestation attest` does. An attestation that lacks a claim is an answer
/// (`stands: false` with `missing`, nothing kept), not a failed request.
fn attest_commit(body: &Value) -> Result<Value, Refused> {
    let operation = "attestation/attest-commit";
    let commit = named(operation, body, "commit")?;
    let repository = named(operation, body, "repository")?;
    let attestation = named(operation, body, "attestation")?;
    let (Some(commit), Some(repository), Some(attestation)) = (commit, repository, attestation)
    else {
        return Err(refused(format!(
            "{operation} needs \"commit\", \"repository\" and \"attestation\""
        )));
    };
    carried::attest(Some(Path::new(repository)), commit, attestation)
        .map_err(|error| failed(format!("{operation}: {error}")))
}

/// Every commit the branch of `"repository"` carries over its upstream, with
/// what each attestation lacks and the commits of the range each patches. A
/// commit that does not stand is an answer (`stands: false`), not a failed
/// request.
fn pending(body: &Value) -> Result<Value, Refused> {
    let operation = "attestation/pending";
    let Some(repository) = named(operation, body, "repository")? else {
        return Err(refused(format!(
            "{operation} needs \"repository\": \"<checkout path>\""
        )));
    };
    carried::pending::pending(Some(Path::new(repository)))
        .map_err(|error| refused(format!("{operation}: {error}")))
}

/// The unpushed commits of `"repository"` whose attestation does not stand,
/// and whether the gates refuse work there, as `tama attestation unjudged`
/// answers. A checkout over the operator's limit is an answer (`stands:
/// false`), not a failed request.
fn unjudged(body: &Value) -> Result<Value, Refused> {
    let operation = "attestation/unjudged";
    let Some(repository) = named(operation, body, "repository")? else {
        return Err(refused(format!(
            "{operation} needs \"repository\": \"<checkout path>\""
        )));
    };
    carried::unjudged::unjudged(Some(Path::new(repository)))
        .map_err(|error| refused(format!("{operation}: {error}")))
}

/// Judge the attestation and keep it when it stands. A refused attestation
/// is an answer (`stands: false` with its refusals), not a failed request.
pub(crate) fn record(body: &Value) -> Result<Value, Refused> {
    let operation = "attestation/record";
    let Some(document) = body.get("attestation").filter(|value| value.is_object()) else {
        return Err(refused(format!(
            "{operation} needs {{\"attestation\": {{...}}}} and \"session\": \"<session id>\""
        )));
    };
    subject_of(operation, body)?
        .record(document)
        .map_err(failed)
}

/// One kept record, how it stands today, and its harsh review (`review`).
pub(crate) fn show(body: &Value) -> Result<Value, Refused> {
    let subject = subject_of("attestation/show", body)?;
    tama_hook_tools::ports::harsh_review::attested::shown(&subject).map_err(refused)
}

/// Delete one kept record.
pub(crate) fn remove(body: &Value) -> Result<Value, Refused> {
    subject_of("attestation/remove", body)?
        .remove()
        .map_err(refused)
}

/// The claims a session's attestation confirms and the lists it leaves
/// empty.
pub(crate) fn standard(body: &Value) -> Result<Value, Refused> {
    subject_of("attestation/standard", body)?
        .standard()
        .map_err(failed)
}

/// Every kept record and how each stands today.
pub(crate) fn list() -> Result<Value, Refused> {
    subject::list().map(Value::Array).map_err(failed)
}

/// The kind a body names under `"kind"`, if any, refused by name when it is
/// no kind of attestation.
fn kind_of(operation: &str, body: &Value) -> Result<Option<registries::Kind>, Refused> {
    named(operation, body, "kind")?
        .map(registries::Kind::parse)
        .transpose()
        .map_err(|error| refused(format!("{operation}: {error}")))
}

/// Every attestation of every registry as one record, as `tama attestation
/// list [--kind KIND]` prints it; `{"kind": "ssh"}` narrows it.
fn registries(body: &Value) -> Result<Value, Refused> {
    let kind = kind_of("attestation/registries", body)?;
    registries::listed(kind).map(Value::Array).map_err(failed)
}

/// Each record re-read against what it names, as `tama attestation verify`
/// does: `{"kind": KIND, "subject": SUBJECT}`, both optional.
fn verify(body: &Value) -> Result<Value, Refused> {
    let operation = "attestation/verify";
    let kind = kind_of(operation, body)?;
    let subject = named(operation, body, "subject")?;
    registries::verify::verify(kind, subject)
        .map(Value::Array)
        .map_err(|error| refused(format!("{operation}: {error}")))
}

/// One attestation withdrawn, as `tama attestation revoke` does:
/// `{"kind": KIND, "subject": SUBJECT}`, both required.
fn revoke(body: &Value) -> Result<Value, Refused> {
    let operation = "attestation/revoke";
    let kind = kind_of(operation, body)?;
    let subject = named(operation, body, "subject")?;
    let (Some(kind), Some(subject)) = (kind, subject) else {
        return Err(refused(format!(
            "{operation} needs \"kind\": \"<kind>\" and \"subject\": \"<subject>\""
        )));
    };
    registries::revoke::revoke(kind, subject)
        .map_err(|error| refused(format!("{operation}: {error}")))
}

/// One attestation recorded, as `tama attestation record --kind` does:
/// `{"kind": KIND, "subject": SUBJECT, "statement": TEXT}`, all required.
fn attest(body: &Value) -> Result<Value, Refused> {
    let operation = "attestation/attest";
    let kind = kind_of(operation, body)?;
    let subject = named(operation, body, "subject")?;
    let statement = named(operation, body, "statement")?;
    let (Some(kind), Some(subject), Some(statement)) = (kind, subject, statement) else {
        return Err(refused(format!(
            "{operation} needs \"kind\": \"<kind>\", \"subject\": \"<subject>\" and \"statement\": \"<text>\""
        )));
    };
    registries::record::record(kind, subject, statement)
        .map_err(|error| refused(format!("{operation}: {error}")))
}

/// The registry operations the Desktop sends: `attestation/kinds` (every
/// kind's name, to narrow or record by), `attestation/registries`,
/// `attestation/verify`, `attestation/attest`, `attestation/revoke`,
/// `attestation/attest-commit` and `attestation/pending`.
pub(crate) fn registry(operation: &str, body: &Value) -> Result<Value, Refused> {
    match operation {
        "attestation/kinds" => Ok(json!(registries::Kind::names())),
        "attestation/registries" => registries(body),
        "attestation/verify" => verify(body),
        "attestation/attest" => attest(body),
        "attestation/revoke" => revoke(body),
        "attestation/attest-commit" => attest_commit(body),
        "attestation/pending" => pending(body),
        "attestation/unjudged" => unjudged(body),
        "attestation/migrate" => registries::migrate::migrate().map_err(failed),
        other => Err(refused(format!(
            "{other} is not a registry operation of tama attestation"
        ))),
    }
}
