//! Where each part of a numbered diff stands in the session's state of the
//! path before the edit.
//!
//! A part (the lines between two empty ones) shows the lines it keeps around
//! its change as the file read when the edit was made. In a file several
//! sessions write, some of those kept lines can be another session's
//! uncommitted lines, which the session's own state (HEAD, then what its own
//! receipts left) does not hold. Such a line is context, never the session's
//! change: a part that reads nowhere as shown is read again with its outer
//! kept lines left out, fewest first, and stands where what remains reads,
//! so long as one place is nearest. A part that
//! changes the file at several places is placed one run of changes at a
//! time, each with the kept lines before it, so a line of another session
//! standing between two of its changes is outer context of the later run and
//! may be left out like any other. Its removed lines are never left out, so a
//! part whose change itself meets another session's lines still refuses.

use super::{parse, Line};

/// The diff's lines, each part moved as one block to where its kept and
/// removed lines stand in `old`: where its numbers say when it reads so
/// there, else at the nearest line after the part before it (the lines above
/// may have moved since: another session's commit now in HEAD, another
/// session's uncommitted lines then in the file). The outer kept lines a part
/// is placed without are not replayed; `apply` copies the state's own lines
/// there. A part that reads so nowhere after the previous one, or at two
/// places equally near, refuses. A part of added lines only moves as the part
/// before it moved.
pub(super) fn placed<'a>(old: &[&str], diff: &'a str) -> Result<Vec<Line<'a>>, String> {
    let mut placed = Vec::new();
    let mut part = Vec::new();
    // The lines of `old` after the last one an earlier part stands on, and
    // the (shown, found) numbers of the last part's first line.
    let mut rest: &[&str] = old;
    let mut moved: Option<(usize, usize)> = None;
    for line in diff.lines().chain(std::iter::once("")) {
        if let Some(line) = parse(line)? {
            part.push(line);
            continue;
        }
        let ordered = shown(&part);
        // Each part's kept and removed lines go down the file, so a line's
        // distance from the part's first is its number less the first's.
        if !ordered.is_sorted_by(|(above, _), (below, _)| above < below) {
            return Err(
                "the edit's diff shows a line after a later one; its lines are out of order"
                    .to_owned(),
            );
        }
        // Each run of changes stands on its own, with the kept lines that
        // lead to it; the kept lines after the last run close it.
        for kept in runs(std::mem::take(&mut part)) {
            // A run that only shows kept lines changes nothing: the edit tool
            // showed context alone (a lone blank line after the last change),
            // so it is neither placed nor replayed and cannot refuse the edit;
            // the state's own lines stand there.
            if kept.iter().all(|line| matches!(line, Line::Kept(..))) {
                continue;
            }
            let shown = shown(&kept);
            let mut kept = kept;
            if let Some(&(first, text)) = shown.first() {
                let (core, found, last) = standing(old, kept, old.len() - rest.len())
                    .map_err(|cause| format!("line {first}, shown as {text:?}, {cause}"))?;
                // `standing` found every line it kept, the last one included.
                rest = &old[found.1 + (last - found.0)..];
                moved = Some(found);
                kept = core;
            }
            for line in kept {
                placed.push(match moved {
                    None => line,
                    Some(by) => line.shifted(by)?,
                });
            }
        }
    }
    Ok(placed)
}

/// `part` cut before the kept lines that lead to each run of changed lines
/// after its first: every piece holds one run, the kept lines before it, and
/// the last piece also the kept lines after the last run.
fn runs(part: Vec<Line<'_>>) -> Vec<Vec<Line<'_>>> {
    let mut pieces = Vec::new();
    let mut piece = Vec::new();
    let mut since_change = Vec::new();
    let mut changed = false;
    for line in part {
        match line {
            Line::Kept(..) if changed => since_change.push(line),
            Line::Kept(..) => piece.push(line),
            Line::Added(..) | Line::Removed(..) => {
                if !since_change.is_empty() {
                    pieces.push(std::mem::take(&mut piece));
                    piece.append(&mut since_change);
                }
                piece.push(line);
                changed = true;
            }
        }
    }
    piece.append(&mut since_change);
    pieces.push(piece);
    pieces
}

/// The (number, text) of each kept or removed line of `part`.
fn shown<'a>(part: &[Line<'a>]) -> Vec<(usize, &'a str)> {
    part.iter()
        .filter_map(|line| match line {
            Line::Kept(number, text) | Line::Removed(number, text) => Some((*number, *text)),
            Line::Added(..) => None,
        })
        .collect()
}

/// The lines that place a part, the (shown, found) numbers of the first, and
/// the shown number of the last.
type Standing<'a> = (Vec<Line<'a>>, (usize, usize), usize);

/// The lines of `part` that place it, the (shown, found) numbers of the
/// first of them, and the shown number of the last: the whole part where it
/// reads as shown, else the part less the fewest outer kept lines that leaves
/// it reading at one nearest place.
fn standing<'a>(old: &[&str], part: Vec<Line<'a>>, free: usize) -> Result<Standing<'a>, String> {
    let kept = |line: &&Line<'a>| matches!(line, Line::Kept(..));
    let lead = part.iter().take_while(kept).count();
    let tail = part.iter().rev().take_while(kept).count();
    let mut whole = None;
    for left_out in counts(part.len(), lead + tail) {
        let mut places = Vec::new();
        for top in counts(part.len(), left_out.min(lead)) {
            let bottom = left_out - top;
            let (Some(end), true) = (part.len().checked_sub(bottom), bottom <= tail) else {
                continue;
            };
            let Some(core) = part.get(top..end) else {
                continue;
            };
            let shown = shown(core);
            let (Some(&(first, _)), Some(&(last, _))) = (shown.first(), shown.last()) else {
                continue;
            };
            match nearest(old, &shown, free) {
                Ok(found) => places.push((top, end, (first, found), last)),
                Err(cause) => {
                    whole.get_or_insert(cause);
                }
            }
        }
        match places[..] {
            [] => continue,
            [(top, end, found, last)] => {
                let core = part.into_iter().take(end).skip(top).collect();
                return Ok((core, found, last));
            }
            _ => {
                return Err(format!(
                    "reads as shown once {left_out} of the kept lines around it are left out, \
                     but in more than one way, so which lines the edit changed cannot be told"
                ))
            }
        }
    }
    Err(match whole {
        Some(cause) => cause,
        None => "is no line the diff shows".to_owned(),
    })
}

/// The counts from none up to `most`, as the indexes of a part of `len`
/// lines give them: a part is never read with all its lines left out.
fn counts(len: usize, most: usize) -> impl Iterator<Item = usize> {
    std::iter::repeat_n((), len)
        .enumerate()
        .map(|(count, ())| count)
        .take_while(move |count| *count <= most)
}

/// The number of the line of `old`, at index `free` or later, where the part
/// whose kept and removed lines are `shown` starts, nearest to the number it
/// shows for its first: the one place where each shown line reads as shown.
fn nearest(old: &[&str], shown: &[(usize, &str)], free: usize) -> Result<usize, String> {
    let Some(&(first, _)) = shown.first() else {
        return Err("is no line the diff shows".to_owned());
    };
    let reads = |start: usize| {
        shown.iter().all(|&(number, text)| {
            old.get(..start + (number - first))
                .and_then(<[&str]>::split_last)
                .is_some_and(|(line, _)| *line == text)
        })
    };
    // The diff numbers lines from the first line's number; `old` from zero.
    let origin = super::super::super::carry::first_line()?;
    let starts: Vec<usize> = (free..old.len())
        .map(|index| index + origin)
        .filter(|&start| reads(start))
        .collect();
    let Some(closest) = starts.iter().map(|start| start.abs_diff(first)).min() else {
        return Err(format!(
            "with the lines the diff shows around it, reads so nowhere after line {free} of the state before the edit"
        ));
    };
    let equally: Vec<usize> = starts
        .into_iter()
        .filter(|start| start.abs_diff(first) == closest)
        .collect();
    match equally[..] {
        [start] => Ok(start),
        _ => Err(format!(
            "reads as shown at lines {equally:?}, equally near, so which one the edit changed cannot be told"
        )),
    }
}

impl<'a> Line<'a> {
    /// The line moved as its part's first line moved, from number `shown`
    /// to number `found`.
    fn shifted(self, (shown, found): (usize, usize)) -> Result<Line<'a>, String> {
        let at = |number: usize| {
            match found.checked_sub(shown) {
                Some(down) => number.checked_add(down),
                None => number.checked_sub(shown - found),
            }
            .ok_or_else(|| format!("the edit's diff numbers line {number}, moved outside the file"))
        };
        Ok(match self {
            Line::Kept(number, text) => Line::Kept(at(number)?, text),
            Line::Removed(number, text) => Line::Removed(at(number)?, text),
            Line::Added(number, text) => Line::Added(at(number)?, text),
        })
    }
}
