//! Where a hunk of a session's change stands in the file as it is now.

/// Where in `current`, at index `free` or later, `block` stands. An empty
/// block stands where `around` reads: the line before it is the first of
/// `around`, or the line after it the second. Among the places it stands,
/// the one whose surroundings read most like the edit's own (`context`: the
/// base's lines before the hunk and after what it removes, compared outward
/// line by line until one differs) is taken, then the one nearest to
/// `expected`: a block that repeats in the file (a closing brace, a blank
/// line) is placed by the text around it, not by distance alone. `None`
/// when it stands nowhere; two places alike in both are refused.
pub(super) fn nearest(
    current: &[&str],
    free: usize,
    expected: usize,
    block: &[&str],
    around: (Option<&str>, Option<&str>),
    context: (&[&str], &[&str]),
) -> Result<Option<usize>, String> {
    let stands = |at: usize| match (block.is_empty(), around) {
        (false, _) => current[at..].starts_with(block),
        (true, (before, after)) => {
            before.is_some_and(|line| current[..at].last() == Some(&line))
                || after.is_some_and(|line| current.get(at) == Some(&line))
        }
    };
    // How many lines around a place read as the edit's surroundings did.
    let alike = |at: usize| {
        let above = context
            .0
            .iter()
            .rev()
            .zip(current[..at].iter().rev())
            .take_while(|(was, is)| was == is)
            .count();
        // A place stands only where the whole block fits, so the lines
        // after it are a tail of the file, empty at its end.
        let below = context
            .1
            .iter()
            .zip(current.get(at + block.len()..).into_iter().flatten())
            .take_while(|(was, is)| was == is)
            .count();
        above + below
    };
    let places: Vec<(usize, usize)> = (free..=current.len())
        .filter(|&at| stands(at))
        .map(|at| (at, alike(at)))
        .collect();
    let Some(best) = places.iter().map(|(_, alike)| *alike).max() else {
        return Ok(None);
    };
    let likest: Vec<usize> = places
        .into_iter()
        .filter(|(_, alike)| *alike == best)
        .map(|(at, _)| at)
        .collect();
    let Some(closest) = likest.iter().map(|at| at.abs_diff(expected)).min() else {
        return Ok(None);
    };
    let equally: Vec<usize> = likest
        .into_iter()
        .filter(|at| at.abs_diff(expected) == closest)
        .collect();
    match equally[..] {
        [at] => Ok(Some(at)),
        _ => Err(format!(
            "stands at indexes {equally:?} of the file now, equally near and alike in the {best} line(s) around them"
        )),
    }
}

/// Where in `current`, at index `free` or later, the lines a pure addition
/// writes already stand between the lines of `base` it went between
/// (`around`: the line before it and the line after it, at least one of
/// them in `base`), the place nearest `expected`; none when they stand
/// nowhere so. A block that only matches with other lines beside it is not
/// the addition, so an identical line added next to its twin is still added.
pub(super) fn already_added(
    current: &[&str],
    free: usize,
    expected: usize,
    written: &[&str],
    around: (Option<&str>, Option<&str>),
) -> Option<usize> {
    if around == (None, None) {
        return None;
    }
    (free..=current.len())
        .filter(|&at| current[at..].starts_with(written))
        .filter(|&at| {
            around
                .0
                .is_none_or(|line| current[..at].last() == Some(&line))
        })
        .filter(|&at| {
            around
                .1
                .is_none_or(|line| current.get(at + written.len()) == Some(&line))
        })
        .min_by_key(|at| at.abs_diff(expected))
}
