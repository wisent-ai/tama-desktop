//! Logic for `tama-block-keychain-prompt-commands`, registry hook id
//! `block-keychain-prompt-commands`.
//!
//! Block shell commands that can trigger a macOS Keychain permission prompt.
//! An auth-aware CLI reads secrets from the login keychain and raises native
//! UI the agent cannot answer, so the agent must use explicit
//! non-interactive credentials from already-approved paths instead.
//!
//! Which command can raise such a prompt is what the command does, and the
//! CLI, subcommand, option and keychain-name lists this module used to match
//! decided it by name: every CLI they left out prompted unseen. A model reads
//! the command through Oko's model call (`judge-prompt.md`) and names what
//! touches the keychain. A question the judge leaves unanswered refuses with
//! its cause (`model_judgement::unanswered`).

use tama_hooks::session_record::{deny_tool_use, read_payload};

use super::model_judgement;
use super::pyvalue::py_str;
use super::tool_vocabulary::Call;

const TAG: &str = "block-keychain-prompt-commands";
const PROMPT: &str = include_str!("judge-prompt.md");
const COMMAND_SLOT: &str = "{command}";
/// The schema the judge answers under and the two options it chooses from.
const JUDGEMENT: &str = "keychain_prompt";
const PASS: &str = "PASS";
const BLOCK: &str = "BLOCK";

/// The shell line the call carries, else its arguments rendered as Python
/// renders them.
fn command_from(call: &Call) -> String {
    if let Some(command) = call.command() {
        return command.to_string();
    }
    match call.input() {
        Some(input) => py_str(input),
        None => String::new(),
    }
}

/// The refusal the model's reading of `command` earns when it touches the
/// keychain, or the refusal an unanswered question earns
/// (`model_judgement::unanswered`); nothing when the command passes. The
/// model is never asked inside the hook, where every shell would wait on it:
/// a command not yet judged is refused naming `tama judgement ask`.
fn judged(command: &str) -> Option<String> {
    let prompt = PROMPT.replace(COMMAND_SLOT, command.trim());
    let judged = match model_judgement::choose_deferred(&prompt, JUDGEMENT, &[PASS, BLOCK]) {
        Ok(judged) => judged,
        Err(unanswered) => {
            return model_judgement::unanswered::refusal(TAG, &unanswered, Some(command))
        }
    };
    if judged.choice != BLOCK {
        return None;
    }
    let reason = judged.reason;
    Some(format!(
        "BLOCKED: command may trigger a native macOS Keychain/auth permission prompt.\n  reason: \
         {reason}\n\nUse a non-interactive path instead: already-approved env vars, an explicit \
         connection string, service-role API calls, or a checked-in migration script that does \
         not invoke a keychain-backed CLI."
    ))
}

pub fn run() {
    let data = read_payload();
    let call = Call::of(&data);
    if !call.is_shell() {
        return;
    }
    let command = command_from(&call);
    if command.trim().is_empty() {
        return;
    }
    if let Some(refusal) = judged(&command) {
        deny_tool_use(&refusal);
    }
}
