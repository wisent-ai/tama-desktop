//! `tama sessions capability show|revoke --session ID --agent omp|claude|codex
//! [--json]`: the capability one session holds — a consent the operator gave
//! in the conversation, such as a build, recorded by the harness — and its
//! withdrawal at once rather than at its expiry. The harness records a grant;
//! these read it and take it back. Tama Desktop's session screen sends the
//! same operations as `tama request sessions/capability` and
//! `sessions/capability/revoke` with `{"sessionId", "agent"}`.

use serde_json::{json, Value};

use super::super::args::{has, option_value};
use super::super::output::print_json;
use tama_hooks::session_control::{
    revoke_session_capability, session_context, session_override, CapabilityRevocation,
    SessionContext,
};

const USAGE: &str = "usage: tama sessions capability show --session <ID> --agent <harness> [--json]
       tama sessions capability revoke --session <ID> --agent <harness> [--json]";

/// Why an operation on a session's capability did not run: the caller named
/// it wrongly, or it ran and failed.
pub(crate) enum Refused {
    Usage(String),
    Failed(String),
}

/// The control context of `session` under `agent`. The harness is named,
/// never assumed: a session id read under the wrong harness names another
/// control file.
fn context_of(session: &str, agent: &str) -> Result<SessionContext, Refused> {
    let payload = json!({ "sessionId": session });
    session_context(agent, Some(&payload))
        .ok_or_else(|| Refused::Usage(format!("unknown agent {agent:?}")))
}

/// The capability the session's override holds now, as the build gate reads
/// it. An override or emergency switch that cannot be read is the failure
/// naming it, never shown as no capability.
fn shown(session: &str, agent: &str) -> Result<Value, Refused> {
    let context = context_of(session, agent)?;
    let held = session_override(&context, None)
        .map_err(|error| {
            Refused::Failed(format!("the session's override cannot be read: {error}"))
        })?
        .capability;
    Ok(json!({
        "agent": agent,
        "sessionId": session,
        "controlKey": context.control_key,
        "capability": held,
    }))
}

/// Withdraw the capability: the override keeps every other field and its
/// capability becomes null, so the grant stops admitting anything at once.
/// The answer and the sentence the terminal prints for it.
fn revoked(session: &str, agent: &str) -> Result<(Value, String), Refused> {
    let context = context_of(session, agent)?;
    let (outcome, revoked, message) = match revoke_session_capability(&context) {
        Ok(CapabilityRevocation::Revoked(capability)) => (
            "revoked",
            capability,
            format!("withdrew the capability granted to {agent} session {session}"),
        ),
        Ok(CapabilityRevocation::NoneHeld) => (
            "none-held",
            Value::Null,
            format!("{agent} session {session} holds no capability; nothing to withdraw"),
        ),
        Ok(CapabilityRevocation::NoOverride) => (
            "no-override",
            Value::Null,
            format!("no session-control override names {agent} session {session}; no capability was ever recorded for it"),
        ),
        Err(error) => {
            return Err(Refused::Failed(format!(
                "cannot withdraw the capability of {agent} session {session}: {error}"
            )))
        }
    };
    let answer = json!({
        "agent": agent,
        "sessionId": session,
        "controlKey": context.control_key,
        "outcome": outcome,
        "revoked": revoked,
    });
    Ok((answer, message))
}

/// The session and harness a Desktop request names.
fn requested(body: &Value) -> Result<(&str, &str), Refused> {
    let named = |field: &str| {
        body.get(field)
            .and_then(Value::as_str)
            .filter(|value| !value.trim().is_empty())
            .ok_or_else(|| {
                Refused::Usage(format!(
                    "the request names no {field}: send {{\"sessionId\": <ID>, \"agent\": <harness>}}"
                ))
            })
    };
    Ok((named("sessionId")?, named("agent")?))
}

/// `tama request sessions/capability`.
pub(crate) fn show_request(body: &Value) -> Result<Value, Refused> {
    let (session, agent) = requested(body)?;
    shown(session, agent)
}

/// `tama request sessions/capability/revoke`.
pub(crate) fn revoke_request(body: &Value) -> Result<Value, Refused> {
    let (session, agent) = requested(body)?;
    revoked(session, agent).map(|(answer, _)| answer)
}

/// The session `argv` names and the harness that runs it, or the usage
/// refusal's exit status.
fn named(argv: &[String]) -> Result<(String, String), i32> {
    let Some(session) = option_value(argv, "--session").filter(|id| !id.trim().is_empty()) else {
        eprintln!("name the session with --session\n{USAGE}");
        return Err(tama_core::exit::USAGE);
    };
    let Some(agent) = option_value(argv, "--agent").filter(|agent| !agent.trim().is_empty()) else {
        eprintln!("name the harness that runs the session with --agent\n{USAGE}");
        return Err(tama_core::exit::USAGE);
    };
    Ok((session, agent))
}

/// Print a refusal the way the terminal names it, and its exit status.
fn refusal(refused: Refused) -> i32 {
    match refused {
        Refused::Usage(said) => {
            eprintln!("{said}\n{USAGE}");
            tama_core::exit::USAGE
        }
        Refused::Failed(said) => {
            eprintln!("{said}");
            tama_core::exit::FAILURE
        }
    }
}

fn show(argv: &[String]) -> i32 {
    let (session, agent) = match named(argv) {
        Ok(named) => named,
        Err(code) => return code,
    };
    let answer = match shown(&session, &agent) {
        Ok(answer) => answer,
        Err(refused) => return refusal(refused),
    };
    if has(argv, "--json") {
        print_json(&answer);
    } else if answer["capability"].is_null() {
        println!("{agent} session {session} holds no capability");
    } else {
        println!("{agent} session {session} holds {}", answer["capability"]);
    }
    tama_core::exit::SUCCESS
}

fn revoke(argv: &[String]) -> i32 {
    let (session, agent) = match named(argv) {
        Ok(named) => named,
        Err(code) => return code,
    };
    let (answer, message) = match revoked(&session, &agent) {
        Ok(revoked) => revoked,
        Err(refused) => return refusal(refused),
    };
    if has(argv, "--json") {
        print_json(&answer);
    } else {
        println!("{message}");
    }
    tama_core::exit::SUCCESS
}

/// `tama sessions capability <verb> …`; `argv` starts at `capability`.
pub(super) fn main(argv: &[String]) -> i32 {
    let [_, verb, ..] = argv else {
        eprintln!("{USAGE}");
        return tama_core::exit::USAGE;
    };
    match verb.as_str() {
        "show" => show(argv),
        "revoke" => revoke(argv),
        other => {
            eprintln!("tama sessions capability takes show or revoke; got {other:?}\n{USAGE}");
            tama_core::exit::USAGE
        }
    }
}
