//! The operator's standing rules, read from Oko's ledger.
//!
//! A rule the operator gives lives in the transcript of the session it was
//! given in. The next session starts without it, and the operator says it
//! again, less patiently. Oko's ledger tells standing rules apart from turn
//! orders; this asks it for every standing rule, in the operator's own words,
//! with the session and message each came from.
//!
//! Turn orders such as "nie koduj" are deliberately not here: a "do not code"
//! that followed an agent into every session would freeze every agent.
//!
//! Every rule and ruling goes into the session-start context uncut. Claude
//! Code puts a context longer than it carries into a file the session reads,
//! so nothing is lost; a cut made here is what loses a rule.

pub mod carried;
mod conduct;
mod snapshot;
mod sources;
pub use snapshot::{newest_kind, owed_answer, owed_order, DEFECT, ORDER, QUESTION};

use std::process::{Command, Stdio};

use serde_json::Value;

use super::digest::ledger_digest;

#[derive(serde::Deserialize)]
pub struct Rule {
    #[serde(rename = "sessionId")]
    pub session: String,
    pub ordinal: i64,
    pub at: String,
    pub text: String,
}

/// The Oko program: the one `TAMA_OKO_CLI` names, else `oko` found on `PATH`.
pub fn oko_cli() -> String {
    match std::env::var("TAMA_OKO_CLI") {
        Ok(program) if !program.is_empty() => program,
        _ => "oko".to_string(),
    }
}

/// The program of `product` (`stado`, `skarbiec`): the one
/// `TAMA_<PRODUCT>_CLI` names, else `<product>` found on `PATH`, where the
/// product's installation links it, never a path written into Tama. A
/// variable that cannot be read is refused by name: read as unset, it would
/// hand the call to another program than the one it names.
pub fn product_cli(product: &str) -> Result<String, String> {
    let variable = format!("TAMA_{}_CLI", product.to_uppercase());
    match std::env::var(&variable) {
        Ok(program) if !program.is_empty() => Ok(program),
        Ok(_) | Err(std::env::VarError::NotPresent) => Ok(product.to_string()),
        Err(error) => Err(format!("{variable} cannot be read: {error}")),
    }
}

/// The Stado program ([`product_cli`]).
pub fn stado_cli() -> Result<String, String> {
    product_cli("stado")
}

/// Whether the Oko CLI is installed at all: the configured path is an
/// executable file, or a bare name resolves through `PATH`. A machine with
/// Tama and without Oko has no task register to read; that is a different
/// fact from an Oko that is installed and cannot be read.
pub fn oko_installed() -> bool {
    program_installed(&oko_cli())
}

/// Whether `program` is installed: a path to an executable file, or a bare
/// name that resolves through `PATH` to one. The one definition every hook
/// that asks another product something reads before asking, so a product
/// that is absent is told from one that is there and cannot answer.
pub fn program_installed(program: &str) -> bool {
    use std::os::unix::fs::PermissionsExt;
    // Any of the owner's, group's or others' execute bits, as <sys/stat.h>
    // declares them.
    let executable = u32::from(libc::S_IXUSR | libc::S_IXGRP | libc::S_IXOTH);
    let runnable = |path: &std::path::Path| {
        path.metadata()
            .is_ok_and(|meta| meta.is_file() && meta.permissions().mode() & executable != 0)
    };
    if program.contains('/') {
        return runnable(std::path::Path::new(program));
    }
    std::env::var_os("PATH").is_some_and(|paths| {
        std::env::split_paths(&paths).any(|directory| runnable(&directory.join(program)))
    })
}

fn read_oko(args: &[&str]) -> Result<Value, String> {
    let program = oko_cli();
    let mut command = Command::new(&program);
    // Oko writes each phase's and each request's wall time to stderr under
    // OKO_TRACE_REQUESTS=1, never to stdout, so the reading is unchanged and
    // an overrun names what it was still waiting on.
    command
        .args(args)
        .env("OKO_TRACE_REQUESTS", "1")
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped());
    if let Ok(database) = std::env::var("OKO_TRANSCRIPT_INDEX_PATH") {
        if !database.is_empty() {
            command.args(["--db", &database]);
        }
    }
    let operation = format!("{command:?}");
    // The reading runs to its end, said on stderr by stado_wait before it
    // waits and when it ends. A cut-off at a number of seconds turns a slow
    // first listing (a cold filesystem cache after a restart) into an
    // unreadable ledger and refuses every stop while Oko is answering.
    let output = stado_wait::output(&mut command)
        .map_err(|error| format!("cannot run {operation}: {error}"))?;
    if !output.status.success() {
        return Err(format!(
            "{operation} exited with {}: {}",
            output.status,
            String::from_utf8_lossy(&output.stderr)
        ));
    }
    serde_json::from_slice(&output.stdout).map_err(|error| {
        format!(
            "{operation} returned invalid JSON: {error}; output: {}",
            String::from_utf8_lossy(&output.stdout)
        )
    })
}

pub struct TaskLedger {
    pub value: Value,
    pub digest: String,
}

/// Oko owns task classification, evidence and verdict precedence. This reader
/// preserves its report instead of implementing a second task list in Tama:
/// the session's own ledger out of the open work Oko settled for it outside
/// every hook (`snapshot`).
pub fn task_ledger(session: &str) -> Result<TaskLedger, String> {
    let value = snapshot::report(session)?
        .into_iter()
        .find(|ledger| ledger.get("sessionId").and_then(Value::as_str) == Some(session))
        .ok_or_else(|| {
            format!(
                "Oko's open work of session {session} holds no ledger of it: Oko found no live \
                 transcript of the session on this machine"
            )
        })?;
    if !value.get("tasks").is_some_and(Value::is_array)
        || !value.get("operatorMessages").is_some_and(Value::is_u64)
    {
        return Err(format!(
            "Oko did not return a valid task ledger for session {session}"
        ));
    }
    Ok(TaskLedger {
        digest: ledger_digest(&value),
        value,
    })
}

/// The ledger of every session Oko holds open work for, each as Oko reports
/// it, and `session`'s own whole ledger, its unread messages included, as
/// Oko settled them outside every hook (`snapshot`). The gates judge the
/// operator's whole work, not one session's share: a session that only
/// counted its own ledger built and stopped while other sessions' tasks
/// stood open.
pub fn open_ledgers(session: &str) -> Result<Vec<TaskLedger>, String> {
    snapshot::report(session)?
        .into_iter()
        .map(|value| {
            if !value.get("tasks").is_some_and(Value::is_array) {
                return Err(format!(
                    "Oko returned a session report with no task array: {value}"
                ));
            }
            Ok(TaskLedger {
                digest: ledger_digest(&value),
                value,
            })
        })
        .collect()
}

/// The rules, newest first. The error names why they could not be read,
/// because a session that starts without them has to know it did.
/// Every rule the ledger holds is read, from every session however long ago
/// it was written: a standing rule binds every later session after every
/// compaction, not only the sessions of the last few days.
pub fn standing_rules() -> Result<Vec<Rule>, String> {
    let rules = read_oko(&["tasks", "rules", "--all", "--json"])?;
    let Value::Array(rows) = rules else {
        return Err("Oko tasks rules --all --json returned a non-array rules report".into());
    };
    let mut out = Vec::with_capacity(rows.len());
    for (index, row) in rows.into_iter().enumerate() {
        let rule: Rule = serde_json::from_value(row).map_err(|error| {
            format!("Oko tasks rules --all --json rule at index {index}: {error}")
        })?;
        out.push(rule);
    }
    out.reverse();
    Ok(out)
}

/// The rules as one block of text an agent reads. The operator says a
/// standing rule again whenever a session forgets it, so the ledger holds one
/// text under many sessions and messages, and later sayings reword it by
/// inserting words into some of its sentences; the block carries each
/// distinct text once, under the newest message it came from, with how many
/// times and since when he said it, and writes each of his sentences once
/// (`carried`): a variant keeps only the sentences new in it. A rule is lost
/// by cutting it, not by saying it once: every sentence of every text stands
/// in the block, and a session reads the rules rather than their repetitions.
pub fn rules_text(rules: &[Rule], written: &mut carried::Written) -> String {
    let mut out = String::from(
        "# Operator's standing rules (Oko ledger, every session). These bind this session.\n",
    );
    for group in distinct(rules) {
        let (newest, said) = match group.as_slice() {
            [newest, .., oldest] => (
                *newest,
                format!(", said {} times since {}", group.len(), oldest.at),
            ),
            [newest] => (*newest, String::new()),
            [] => continue,
        };
        out.push_str(&format!(
            "- {} ({} #{}{said}): {}\n",
            newest.at,
            short(&newest.session),
            newest.ordinal,
            written.line(&line_text(newest))
        ));
    }
    out
}

/// A rule's text as its line carries it: one line, with no whitespace at
/// the ends. Two messages that differ only in that are one rule.
fn line_text(rule: &Rule) -> String {
    rule.text.trim().replace('\n', " ")
}

/// The rules grouped by their line text, in the order given (newest first);
/// each group lists the messages carrying that text in that same order, so
/// its first member is the newest and its last the oldest.
fn distinct(rules: &[Rule]) -> Vec<Vec<&Rule>> {
    let mut groups: Vec<Vec<&Rule>> = Vec::new();
    let mut index: std::collections::HashMap<String, usize> = std::collections::HashMap::new();
    for rule in rules {
        let text = line_text(rule);
        match index.get(&text) {
            Some(&at) => groups[at].push(rule),
            None => {
                index.insert(text, groups.len());
                groups.push(vec![rule]);
            }
        }
    }
    groups
}

/// Required context: a failed ledger read is not restored rules. The
/// operator's rejections charged to the model `session` runs on follow the
/// rules and rulings.
pub fn rules_context(session: &str) -> Result<String, String> {
    let rules = standing_rules()?;
    // One ledger of written sentences for the rules and the rulings after
    // them, so a ruling in a standing rule's words is not copied again.
    let mut written = carried::Written::default();
    let text = if rules.is_empty() {
        "# Operator's standing rules: none recorded in Oko's ledger.\n".to_string()
    } else {
        rules_text(&rules, &mut written)
    };
    Ok(text
        + &super::rulings::rulings_text(&mut written)?
        + &super::completion::excuses::answers_text()
        + &conduct::conduct_text(session, &mut written))
}

/// How many characters of a session id its short form keeps: a UUID's
/// time_low field, https://www.rfc-editor.org/rfc/rfc9562#section-4
const SHORT_SESSION: usize = 8;

fn short(session: &str) -> &str {
    let key = match session.rsplit_once('_') {
        Some((_, key)) => key,
        None => session,
    };
    match key.char_indices().nth(SHORT_SESSION) {
        Some((end, _)) => &key[..end],
        None => key,
    }
}
