//! Every finished tool call of a transcript: its tool, how long it ran and
//! whether it ended in error, read from either harness's record — OMP's
//! `toolCall` block answered by a `toolResult` message, Claude Code's
//! `tool_use` block answered by a `tool_result` block in a user message.
//!
//! A call runs from the message that carries it to the record that answers
//! it. The instant of each is the message's own millisecond `timestamp` when
//! it has one, else the record's RFC 3339 `timestamp`. A call with no answer
//! yet is the one running now, or one the session never saw end, and is not
//! listed: nothing says how long it ran.

use std::collections::HashMap;

use serde_json::Value;

use crate::ports::tool_vocabulary::transcript_tool_call;

const MESSAGE_KEY: &str = "message";
const CONTENT_KEY: &str = "content";
const TIMESTAMP_KEY: &str = "timestamp";
const ROLE_KEY: &str = "role";
const TYPE_KEY: &str = "type";
const ID_KEY: &str = "id";
const TOOL_RESULT_ROLE: &str = "toolResult";
const TOOL_CALL_ID_KEY: &str = "toolCallId";
const IS_ERROR_KEY: &str = "isError";
const TOOL_RESULT_BLOCK: &str = "tool_result";
const TOOL_USE_ID_KEY: &str = "tool_use_id";
const BLOCK_ERROR_KEY: &str = "is_error";

/// One call that has its answer.
pub(super) struct Finished {
    /// The tool's name, lower-cased.
    pub(super) tool: String,
    pub(super) millis: i64,
    pub(super) failed: bool,
}

/// When `record` was written, in milliseconds since the epoch.
fn instant(record: &Value, message: &Value) -> Option<i64> {
    if let Some(millis) = message.get(TIMESTAMP_KEY).and_then(Value::as_i64) {
        return Some(millis);
    }
    let text = record.get(TIMESTAMP_KEY).and_then(Value::as_str)?;
    match tama_core::clock::parse(text) {
        Ok(at) => Some(at.timestamp_millis()),
        Err(cause) => {
            eprintln!("block-repeat-hung-call: {cause}");
            None
        }
    }
}

/// Every answered call of `records`, in the order the answers came.
pub(super) fn finished(records: &[Value]) -> Vec<Finished> {
    let mut started: HashMap<String, (String, i64)> = HashMap::new();
    let mut done = Vec::new();
    for record in records {
        let Some(message) = record.get(MESSAGE_KEY).filter(|value| value.is_object()) else {
            continue;
        };
        let Some(at) = instant(record, message) else {
            continue;
        };
        let mut answer = |id: &str, failed: bool| {
            if let Some((tool, from)) = started.remove(id) {
                done.push(Finished {
                    tool,
                    millis: at - from,
                    failed,
                });
            }
        };
        if message.get(ROLE_KEY).and_then(Value::as_str) == Some(TOOL_RESULT_ROLE) {
            if let Some(id) = message.get(TOOL_CALL_ID_KEY).and_then(Value::as_str) {
                let failed = message.get(IS_ERROR_KEY).and_then(Value::as_bool) == Some(true);
                answer(id, failed);
            }
            continue;
        }
        let Some(Value::Array(blocks)) = message.get(CONTENT_KEY) else {
            continue;
        };
        for block in blocks {
            if block.get(TYPE_KEY).and_then(Value::as_str) == Some(TOOL_RESULT_BLOCK) {
                if let Some(id) = block.get(TOOL_USE_ID_KEY).and_then(Value::as_str) {
                    let failed = block.get(BLOCK_ERROR_KEY).and_then(Value::as_bool) == Some(true);
                    answer(id, failed);
                }
            }
        }
        for block in blocks {
            let (Some((name, _)), Some(id)) = (
                transcript_tool_call(block),
                block.get(ID_KEY).and_then(Value::as_str),
            ) else {
                continue;
            };
            started.insert(id.to_string(), (name.to_lowercase(), at));
        }
    }
    done
}
