//! The OMP adapter among OMP's extensions, read and set through `omp config`.

use std::path::Path;
use std::process::Command;

use serde_json::{json, Value};
use tama_hook_tools::util::omp_extensions;

/// `omp config <arguments>` under `home`: its standard output, or what it
/// said when it failed, with its status.
pub(in super::super) fn omp_config(
    omp: &str,
    home: &Path,
    arguments: &[&str],
) -> Result<String, String> {
    let mut command = Command::new(omp);
    command.arg("config").args(arguments).env("HOME", home);
    let shown = format!("{omp} config {}", arguments.join(" "));
    let output = stado_wait::output(&mut command)
        .map_err(|error| format!("{shown} could not run: {error}"))?;
    if !output.status.success() {
        return Err(format!(
            "{shown} ended with {}: {}",
            output.status,
            String::from_utf8_lossy(&output.stderr).trim()
        ));
    }
    Ok(String::from_utf8_lossy(&output.stdout).to_string())
}

/// Put the OMP adapter among OMP's extensions: the program and the list
/// before, when this changed it. OMP's answer is read by
/// [`omp_extensions::listed`]: a setting OMP reports as unset lists none, and
/// any answer it cannot read as a list of paths refuses the install, since
/// writing the adapter alone over it would erase every extension the user had.
pub(in super::super) fn register_omp_adapter(
    home: &Path,
    adapter: &Path,
) -> Result<Option<(String, Value)>, String> {
    let Some(omp) = crate::omp::program(home)? else {
        return Ok(None);
    };
    let current = omp_config(&omp, home, &["get", "extensions", "--json"])
        .map_err(|e| format!("Could not read OMP extensions: {e}"))?;
    let previous: Vec<Value> = omp_extensions::listed(&current)?
        .into_iter()
        .map(Value::String)
        .collect();
    let obsolete = [
        home.join(".omp/agent/hooks/pre/shared-hooks.js"),
        home.join(".omp/agent/hooks.tama-disabled/pre/shared-hooks.js"),
    ];
    let retired = |value: &Value| {
        obsolete
            .iter()
            .any(|o| value.as_str() == Some(o.display().to_string().as_str()))
    };
    let mut updated: Vec<Value> = previous
        .iter()
        .filter(|value| !retired(value))
        .cloned()
        .collect();
    let adapter = json!(adapter.display().to_string());
    if !updated.contains(&adapter) {
        updated.push(adapter);
    }
    if updated == previous {
        return Ok(None);
    }
    omp_config(
        &omp,
        home,
        &["set", "extensions", &Value::Array(updated).to_string()],
    )
    .map_err(|e| format!("Could not register OMP hook adapter: {e}"))?;
    Ok(Some((omp, Value::Array(previous))))
}
