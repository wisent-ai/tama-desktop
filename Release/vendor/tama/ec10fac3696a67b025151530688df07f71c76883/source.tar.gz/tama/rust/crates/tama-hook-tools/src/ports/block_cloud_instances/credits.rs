//! A cloud operation the operator allowed by a standing ruling while the
//! credits it is billed to stay above a floor he named
//! (`oko_rulings::credit_floors`), admitted only on Stado's measurement of
//! that balance (`stado billing show --json`, the billing variant's
//! `available_balance` and `currency`). The floor comes from his ruling and
//! the balance from the measurement; neither is written here. A balance at
//! or under the floor is refused naming both, and a balance Stado cannot
//! give is refused naming why: no measurement is never a pass.

use std::process::Command;

use serde_json::Value;
use tama_hooks::oko_rulings::{credit_floors, CreditFloor};

const SHOWN: &str = "stado billing show --json";

/// What became of a cloud call billed to `billing` under the operator's
/// floors: admitted with the sentence saying on what, refused with its
/// sentence, or no floor of his names that billing at all.
pub(super) enum Floor {
    Admitted,
    Refused(String),
    Unruled,
}

/// The amount `balance` holds, as Stado writes a balance: a number, or a
/// decimal in text.
fn amount(billing: &str, balance: &Value) -> Result<f64, String> {
    let unread =
        |why: String| format!("{SHOWN} gives {billing}'s available_balance as {balance}: {why}");
    match balance {
        Value::Number(number) => number
            .as_f64()
            .ok_or_else(|| unread("a number no f64 holds".to_string())),
        Value::String(text) => text
            .parse::<f64>()
            .map_err(|error| unread(error.to_string())),
        _ => Err(unread("neither a number nor a decimal".to_string())),
    }
}

/// The measured balance of `billing`: its amount, currency and when Stado
/// reported it.
fn measured(billing: &str) -> Result<(f64, String, String), String> {
    let output = stado_wait::output(Command::new("stado").args(["billing", "show", "--json"]))
        .map_err(|error| format!("{SHOWN} cannot run: {error}"))?;
    if !output.status.success() {
        return Err(format!(
            "{SHOWN} failed: {}",
            String::from_utf8_lossy(&output.stderr).trim()
        ));
    }
    let document: Value = serde_json::from_slice(&output.stdout)
        .map_err(|error| format!("{SHOWN} printed no JSON: {error}"))?;
    let section = &document[billing];
    if section.get("status").and_then(Value::as_str) != Some("ok") {
        return Err(format!("{SHOWN} gives no {billing} balance: {section}"));
    }
    let amount = amount(billing, &section["available_balance"])?;
    let Some(currency) = section["currency"].as_str() else {
        return Err(format!(
            "{SHOWN} names no currency for {billing}: {section}"
        ));
    };
    let Some(reported) = document["reported_at"].as_str() else {
        return Err(format!("{SHOWN} names no reported_at for its balance"));
    };
    Ok((amount, currency.to_string(), reported.to_string()))
}

/// The floor decision for a call billed to `billing`.
pub(super) fn decide(billing: &str) -> Floor {
    let floors = match credit_floors() {
        Ok(floors) => floors,
        Err(cause) => {
            return Floor::Refused(format!(
                "the operator's credit floors cannot be read: {cause}"
            ))
        }
    };
    let ruled: Vec<&CreditFloor> = floors
        .iter()
        .filter(|floor| floor.billing == billing)
        .collect();
    // `credit_floors` gives the operator's newest ruling first: his latest
    // floor for this billing decides, as his latest word does elsewhere.
    let Some(floor) = ruled.first() else {
        return Floor::Unruled;
    };
    let (amount, currency, reported) = match measured(billing) {
        Ok(measured) => measured,
        Err(cause) => {
            return Floor::Refused(format!(
                "the operator allows it while {billing} credits stay above {} {} (ruling {}), and \
                 they were not measured: {cause}; no measurement is never a pass",
                floor.amount, floor.currency, floor.ruling
            ))
        }
    };
    if currency != floor.currency {
        return Floor::Refused(format!(
            "Stado measures {billing} credits in {currency}, and the operator's floor (ruling {}) \
             is in {}, so the two cannot be compared",
            floor.ruling, floor.currency
        ));
    }
    if amount > floor.amount {
        Floor::Admitted
    } else {
        Floor::Refused(format!(
            "{billing} credits are {amount} {currency} (reported {reported}), at or under the \
             floor of {} {currency} the operator set in ruling {}",
            floor.amount, floor.ruling
        ))
    }
}
