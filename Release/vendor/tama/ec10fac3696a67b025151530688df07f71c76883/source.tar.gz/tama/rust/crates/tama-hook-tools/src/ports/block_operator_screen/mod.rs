//! Decision half of `tama hook block-operator-screen` (hook id
//! `block-operator-screen`): a shell line that writes the operator's
//! clipboard or puts something on his screen is refused unless he granted
//! that exact command in his own words ([`crate::ports::operator_grant`]).
//!
//! His clipboard and his screen are his. Sessions used the clipboard as
//! their notebook — a command for him to paste, a report to read — and
//! opened documents in Preview over whatever he was doing. What a session
//! needs from him goes through Oko (`oko asks ask`), where his answer and his
//! frustration are recorded; what it made for him stays a file he opens.
//!
//! The programs are read from the words the shell runs, so data that names
//! one is no call, and a shell handed a line (`bash -c '…'`) is read for the
//! same programs:
//!
//! - `pbcopy`, the program that writes the clipboard (pbcopy(1));
//! - `open`, which hands a file, folder, URL or application to the desktop
//!   to show (open(1));
//! - `qlmanage`, which puts a Quick Look preview on the screen.

use serde_json::Value;

use crate::ports::operator_grant::{self, Request};
use crate::ports::python_stdlib::shell_tokens;
use crate::ports::shell_text;
use crate::ports::tool_vocabulary::Call;

pub const HOOK_ID: &str = "block-operator-screen";
pub const GRANT_KIND: &str = "screen";
const BANNER: &str = "BLOCKED: the operator's clipboard and screen are not the session's: ";
/// The program that writes the clipboard.
const CLIPBOARD_WRITER: &str = "pbcopy";
/// The program that hands a document or address to the desktop to show.
const OPENER: &str = "open";
/// The program that shows a Quick Look preview.
const QUICK_LOOK: &str = "qlmanage";

/// The refusal when the call writes the clipboard or shows something on the
/// screen with no grant, `None` when it passes.
pub fn evaluate(payload: &Value) -> Option<String> {
    let call = Call::of(payload);
    if !call.is_shell() {
        return None;
    }
    let command = call.command()?;
    let found = reached(&shell_text::effective_payload(payload, command));
    if found.is_empty() {
        return None;
    }
    let request = Request {
        gate: HOOK_ID,
        command: Some(command),
        paths: &[],
    };
    if operator_grant::granted(payload, &request) {
        return None;
    }
    Some(format!(
        "{BANNER}this line runs {}. Nothing goes on his clipboard or in front of him unasked: \
         a question or a consent he must give goes through `oko asks ask`, and a document or \
         command made for him stays a file in the checkout, named in the work's record. {}",
        found.join(", "),
        operator_grant::how_to_grant(GRANT_KIND, HOOK_ID)
    ))
}

/// The clipboard and screen programs `line` runs, each named once, read
/// through every shell it hands a line to.
fn reached(line: &str) -> Vec<String> {
    let mut found: Vec<String> = Vec::new();
    for segment in shell_text::commands(line) {
        let tokens = shell_tokens(segment);
        if let Some(inner) = shell_text::inner_command(&tokens) {
            for named in reached(&inner) {
                if !found.contains(&named) {
                    found.push(named);
                }
            }
            continue;
        }
        let Some(program) = shell_text::program(&tokens) else {
            continue;
        };
        let named = format!("`{program}`");
        if [CLIPBOARD_WRITER, OPENER, QUICK_LOOK].contains(&program) && !found.contains(&named) {
            found.push(named);
        }
    }
    found
}
