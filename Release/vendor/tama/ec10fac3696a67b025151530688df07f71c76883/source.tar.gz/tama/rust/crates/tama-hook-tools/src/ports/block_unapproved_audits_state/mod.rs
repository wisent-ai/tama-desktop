//! Consent state for `block_unapproved_audits`: the approval policy file,
//! read only, at the path the Python uses verbatim:
//! `$DEVICE_LEVEL_AUDITS_POLICY`, else `~/.config/agent-policy/device_level_audits.json`.
//! Approved when its JSON object has `device_level_audits_approved` set to
//! the boolean `true`, or when `DEVICE_LEVEL_AUDITS_APPROVED=1` is exported
//! outside the session.

use crate::util::home_dir;
use serde_json::Value;
use std::path::PathBuf;

pub const APPROVAL_ENV: &str = "DEVICE_LEVEL_AUDITS_APPROVED";
pub const POLICY_FIELD: &str = "device_level_audits_approved";
const APPROVAL_VALUE: &str = "1";
const POLICY_ENV: &str = "DEVICE_LEVEL_AUDITS_POLICY";
const POLICY_CONFIG_DIR: &str = ".config";
const POLICY_AGENT_DIR: &str = "agent-policy";
const POLICY_FILE: &str = "device_level_audits.json";

pub fn policy_path() -> PathBuf {
    match std::env::var(POLICY_ENV) {
        Ok(value) if !value.is_empty() => PathBuf::from(value),
        _ => home_dir()
            .join(POLICY_CONFIG_DIR)
            .join(POLICY_AGENT_DIR)
            .join(POLICY_FILE),
    }
}

/// `POLICY_PATH.name`.
pub fn policy_name() -> String {
    policy_path()
        .file_name()
        .map(|name| name.to_string_lossy().to_string())
        .unwrap_or_default()
}

/// Whether audits are approved: the approval variable, or the policy file's
/// approval field. A policy that does not exist approves nothing; one that
/// cannot be read or is not JSON is the error, so a refusal can say the
/// approval could not be read instead of that none was given.
pub fn approved() -> Result<bool, String> {
    if std::env::var(APPROVAL_ENV).ok().as_deref() == Some(APPROVAL_VALUE) {
        return Ok(true);
    }
    let path = policy_path();
    let text = match std::fs::read_to_string(&path) {
        Ok(text) => text,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(false),
        Err(error) => return Err(format!("{} cannot be read: {error}", path.display())),
    };
    let value: Value = serde_json::from_str(&text)
        .map_err(|error| format!("{} is not JSON: {error}", path.display()))?;
    Ok(value.get(POLICY_FIELD) == Some(&Value::Bool(true)))
}
