//! What one hook session needs:
//! provider catalog validation and launch-plan construction (including the
//! isolated CODEX_HOME / OMP agent transports). Which tool fires which
//! registry event in OMP is the extension's own reading
//! (`shared-hooks/omp/adapter.js`); nothing here keeps a second table of it.

mod catalog;
mod isolation;
mod launch;

pub use catalog::{
    expand_arguments, extension_path, load_provider_catalog, provider_catalog_path, registry_path,
    run_hook_path, work_root, PROVIDER_CATALOG_SCHEMA,
};
pub use isolation::isolated_codex_home;
pub use launch::{launch_for_provider, LaunchPlan};

use crate::util::home_dir;
use std::path::PathBuf;
use tama_core::{OWNER_ONLY_DIR, OWNER_ONLY_FILE};

/// OMP's agent directory override, as OMP itself reads it.
const AGENT_DIR_VARIABLE: &str = "PI_CODING_AGENT_DIR";

/// The top-level keys of OMP's `config.yml` that load extensions and hooks;
/// an isolated session runs only the one hook it was started for.
const DISABLED_EXTENSIONS_KEY: &str = "disabledExtensions";
const EXTENSIONS_KEY: &str = "extensions";
const HOOKS_KEY: &str = "hooks";
const EXCLUDED_CONFIG_KEYS: &[&str] = &[DISABLED_EXTENSIONS_KEY, EXTENSIONS_KEY, HOOKS_KEY];

/// OMP's databases an isolated session starts from, copied with the sqlite3
/// program's online backup so a live writer never tears the copy.
const OMP_DATABASES: &[&str] = &[AGENT_DATABASE, MODELS_DATABASE, HISTORY_DATABASE];
const AGENT_DATABASE: &str = "agent.db";
const MODELS_DATABASE: &str = "models.db";
const HISTORY_DATABASE: &str = "history.db";

/// Copy each of OMP's databases present in `source` into `target`.
fn snapshot_databases(source: &std::path::Path, target: &std::path::Path) -> Result<(), String> {
    for name in OMP_DATABASES {
        let from = source.join(name);
        if !tama_core::presence::present(&from).map_err(|error| error.to_string())? {
            continue;
        }
        let into = target.join(name);
        let mut command = std::process::Command::new("/usr/bin/sqlite3");
        command.arg("-readonly").arg(&from).arg(format!(
            ".backup '{}'",
            into.display().to_string().replace('\'', "''")
        ));
        let output = stado_wait::output(&mut command)
            .map_err(|e| format!("/usr/bin/sqlite3 {}: {e}", from.display()))?;
        if !output.status.success() {
            return Err(format!(
                "/usr/bin/sqlite3 .backup {}: {}",
                from.display(),
                String::from_utf8_lossy(&output.stderr).trim()
            ));
        }
    }
    Ok(())
}

/// The isolated OMP agent directory one hook session runs OMP under.
pub fn isolated_omp_agent() -> Result<PathBuf, String> {
    use std::os::unix::fs::PermissionsExt;
    let source = match std::env::var_os(AGENT_DIR_VARIABLE) {
        Some(directory) => PathBuf::from(directory),
        None => home_dir().join(".omp").join("agent"),
    };
    let path = work_root()?.join(format!("omp-agent-{}", tama_core::random::random_uuid()?));
    std::fs::create_dir_all(&path).map_err(|e| e.to_string())?;
    std::fs::set_permissions(&path, std::fs::Permissions::from_mode(OWNER_ONLY_DIR))
        .map_err(|e| e.to_string())?;
    let source_config = source.join("config.yml");
    if tama_core::presence::present(&source_config).map_err(|error| error.to_string())? {
        let text = std::fs::read_to_string(&source_config).map_err(|e| e.to_string())?;
        let lines: Vec<&str> = text.split('\n').collect();
        let mut kept: Vec<&str> = Vec::new();
        for (index, line) in lines.iter().enumerate() {
            // The key a line belongs to is the nearest line at or above it
            // that starts in the first column.
            let owner = lines[..=index]
                .iter()
                .rposition(|candidate| !candidate.starts_with(|c: char| c.is_whitespace()));
            let key = owner.and_then(|owner| parse_yaml_key(lines[owner]));
            if !key.is_some_and(|key| EXCLUDED_CONFIG_KEYS.contains(&key)) {
                kept.push(line);
            }
        }
        let config_path = path.join("config.yml");
        std::fs::write(&config_path, kept.join("\n")).map_err(|e| e.to_string())?;
        std::fs::set_permissions(
            &config_path,
            std::fs::Permissions::from_mode(OWNER_ONLY_FILE),
        )
        .map_err(|e| e.to_string())?;
    }
    if let Err(detail) = snapshot_databases(&source, &path) {
        // The refusal names a partial copy left behind, so it is never
        // mistaken for one that was cleaned up.
        let left = match std::fs::remove_dir_all(&path) {
            Ok(()) => String::new(),
            Err(error) => format!("; {} was left behind: {error}", path.display()),
        };
        return Err(format!(
            "Could not snapshot isolated OMP state: {detail}{left}"
        ));
    }
    let changelog = source.join("last-changelog-version");
    if tama_core::presence::present(&changelog).map_err(|error| error.to_string())? {
        let bytes = std::fs::read(&changelog).map_err(|e| e.to_string())?;
        std::fs::write(path.join("last-changelog-version"), bytes).map_err(|e| e.to_string())?;
    }
    Ok(path)
}

/// `lines[owner]?.match(/^([^#\s][^:]*):/)?.[1]`
fn parse_yaml_key(line: &str) -> Option<&str> {
    let first = line.chars().next()?;
    if first == '#' || first.is_whitespace() {
        return None;
    }
    let (key, _) = line.split_once(':')?;
    (!key.is_empty()).then_some(key)
}
