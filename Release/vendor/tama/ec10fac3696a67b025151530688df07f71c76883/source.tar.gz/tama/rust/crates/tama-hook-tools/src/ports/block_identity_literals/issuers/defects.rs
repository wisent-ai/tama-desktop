//! Oko issues defect identities in its register's `defects[].id` fields.
//! Evidence, notes and other quoted prose do not issue another identity.

use serde_json::Value;
use std::collections::HashSet;

/// Oko's defect register, located as Oko locates it.
fn location() -> Result<std::path::PathBuf, String> {
    tama_core::oko_register("OKO_DEFECT_REGISTER", "defects.json")
}

/// Read once per dispatch through Machine's issuer cache. No Oko register
/// means it issued no identities here; an unreadable or malformed register
/// is an unavailable source, not evidence that a real identity was invented.
pub(super) fn issued() -> Result<HashSet<String>, String> {
    let path = location()?;
    let bytes = match std::fs::read(&path) {
        Ok(bytes) => bytes,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(HashSet::new()),
        Err(error) => {
            return Err(format!(
                "Oko's defect register {} cannot be read: {error}",
                path.display()
            ))
        }
    };
    let document: Value = serde_json::from_slice(&bytes).map_err(|error| {
        format!(
            "Oko's defect register {} is not JSON: {error}",
            path.display()
        )
    })?;
    let defects = document
        .get("defects")
        .and_then(Value::as_array)
        .ok_or_else(|| {
            format!(
                "Oko's defect register {} holds no defects array",
                path.display()
            )
        })?;
    defects
        .iter()
        .enumerate()
        .map(|(index, defect)| {
            defect
                .get("id")
                .and_then(Value::as_str)
                .map(str::to_lowercase)
                .ok_or_else(|| {
                    format!(
                        "Oko's defect register {} defect {index} has no id",
                        path.display()
                    )
                })
        })
        .collect()
}
