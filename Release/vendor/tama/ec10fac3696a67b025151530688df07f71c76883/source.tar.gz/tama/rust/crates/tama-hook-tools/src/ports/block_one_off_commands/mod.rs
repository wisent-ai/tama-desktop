//! Logic for `tama hook block-one-off-commands`, registry hook id
//! `block-one-off-commands`.
//!
//! Refuses a write that adds a command-line command which is a one-off call
//! dressed as a command: a command bound, by its name or by its behaviour,
//! to one document, template, host, account, call or event, where the
//! workshop's rule (`~/agents/cli.md`, "A command is a general primitive,
//! not a one-off call") asks for the general primitive over that kind of
//! object. Whether a command is one is not a question of shape, so the
//! commands a write adds are read by shape (`commands`) and judged by the
//! model every Tama guard asks through Oko and Brama.
//!
//! A command nobody judged yet is not let through unread: this gate exists
//! because such commands were written while nothing checked them. While the
//! judge is down (no model declared, or Oko's record says it does not
//! answer) the gate's declared no-model alternative decides instead, the
//! file's recorded justification, and stderr names that alternative. The
//! judge is not asked inside the write, which the harness gives seconds and
//! the judge takes minutes over: the write is decided by the verdicts kept
//! for the same declarations ([`verdicts`]). Unknown declarations get a retained
//! request for the foreground `tama commands judge <request>` operation, while
//! the write is refused naming it. Every command the file declares as the
//! write leaves it is judged, whoever declared it, so a one-off command a
//! file already held is refused on its next edit until it is replaced;
//! `--audit` asks the judge directly instead of the kept verdicts, which is
//! what `tama violations find --one-off-commands` asks.

pub mod commands;
mod judged;
pub mod verdicts;

use std::path::Path;

use serde_json::Value;
use tama_hooks::session_record::{deny_tool_use, read_payload};

use crate::ports::pre_write_edit::resulting;
use crate::ports::violations_declarations::file_is_declared;
use crate::ports::write_payload::{is_system_path, WritePayload};

pub use commands::Command;
pub use judged::judge;

pub const HOOK_ID: &str = "block-one-off-commands";
/// The whole-file audit `tama violations find` asks for.
pub const AUDIT_FLAG: &str = "--audit";
/// The call this guard's judge makes (`model_judgement::object`): it follows
/// a refused declared route with the decision route, as `oko tasks judge
/// --probe` does, and is what has to answer before a command can be judged.
const PROBE: &str =
    "oko gateway object --prompt <question> --name command_generality --schema <schema>";
const ADVICE: &str = "A command operates on one kind of object the product owns and works for every \
    instance of it (~/agents/cli.md, \"A command is a general primitive, not a one-off call\"). Build the \
    general primitive the command stands for, with what logically completes it, and keep what one \
    instance needs (its sheets, rows, keys, amounts) in that instance's data, not in the command.";

/// What the judge said about one command: `None` passes, `Some` is why not.
pub type Verdict = (Command, Option<String>);

/// The repository a file belongs to, by the name of its top directory, or
/// the file's own directory when it is in none; empty for a file at the
/// filesystem root, which has neither. An ancestor whose `.git` cannot be
/// examined is the error, never read as outside every checkout.
pub fn repository(file_path: &str) -> Result<String, String> {
    let parent = Path::new(file_path).parent();
    let top = match parent {
        Some(parent) => {
            tama_core::presence::checkout_root(parent).map_err(|error| error.to_string())?
        }
        None => None,
    };
    Ok(match top.or(parent).and_then(|dir| dir.file_name()) {
        Some(name) => name.to_string_lossy().into_owned(),
        None => String::new(),
    })
}

/// The refusal for these verdicts in `file_path`, or `None` when every
/// command passed.
pub fn refusal(file_path: &str, verdicts: &[Verdict]) -> Option<String> {
    let blocked: Vec<String> = verdicts
        .iter()
        .filter_map(|(command, reason)| {
            reason
                .as_ref()
                .map(|reason| format!("  `{}`: {reason}", command.name))
        })
        .collect();
    (!blocked.is_empty()).then(|| {
        format!(
            "{HOOK_ID}: BLOCKED: {file_path} would declare one-off command(s):\n{}\n{ADVICE}",
            blocked.join("\n")
        )
    })
}

/// The refusal when the commands could not be judged.
pub fn unjudged(file_path: &str, found: &[Command], reason: &str) -> String {
    let names: Vec<&str> = found.iter().map(|command| command.name.as_str()).collect();
    format!(
        "{HOOK_ID}: BLOCKED: {file_path} would declare command(s) {} and nobody could judge whether each is a \
         general primitive: {reason}. The judge is asked with `{PROBE}` on Oko's chat route, which \
         `oko tasks judge --probe` does not test (it answers through the decision alias); write the commands \
         again once that call answers.",
        names.join(", ")
    )
}

/// The refusal naming the foreground operation for commands without a verdict.
pub fn pending(file_path: &str, found: &[Command], request: &str) -> String {
    let names: Vec<&str> = found.iter().map(|command| command.name.as_str()).collect();
    format!(
        "{HOOK_ID}: BLOCKED: {file_path} would declare command(s) {} that the judge has not read yet. \
         Run `tama commands judge {request}` to review the retained declarations and print \
         each verdict (exit 0 when every command passed). No background judge was started. \
         Write the commands again after it has answered: the write is then decided by those verdicts.",
        names.join(", ")
    )
}

/// The decision on a machine that declared no model, where no judge can read
/// a command: the file's recorded justification decides ([`justified`]).
/// `None` when a model is declared and the judge decides.
fn without_model(file_path: &str, found: &[Command]) -> Result<Option<Option<String>>, String> {
    if !crate::ports::task_attestation::declared::model_declared_none()? {
        return Ok(None);
    }
    justified(file_path, found, "no model is declared on this machine").map(Some)
}

/// The declared no-model alternative, used when `unjudged` says why no judge
/// reads the commands: the file's recorded justification (`tama justify
/// record --kind file`) is its attestation that each command it declares is
/// a general primitive, as it is for the numbers the constants gate reads,
/// and a file with none is refused naming the commands.
fn justified(file_path: &str, found: &[Command], unjudged: &str) -> Result<Option<String>, String> {
    let registry = crate::ports::check_unsubstantiated_constants::registry_path();
    let justified =
        crate::ports::check_unsubstantiated_constants::justification(&registry, file_path)?;
    let names: Vec<&str> = found.iter().map(|command| command.name.as_str()).collect();
    if justified.is_some() {
        return Ok(None);
    }
    // Which registry was read, and what it held, so a justification that
    // was recorded somewhere else is seen in the refusal, not guessed at.
    let read = match std::path::Path::new(&registry).try_exists() {
        Ok(true) => format!("{registry} holds no entry for the key {file_path}"),
        Ok(false) => format!("{registry} does not exist"),
        Err(error) => format!("whether {registry} exists cannot be read: {error}"),
    };
    Ok(Some(format!(
        "{HOOK_ID}: BLOCKED: {file_path} would declare command(s) {}, {unjudged} to judge whether \
         each is a general primitive, and no justification is recorded for this file ({read}). \
         {ADVICE} Record why each one is with `tama justify record --kind file --file {file_path} \
         --justification \"<why>\"`.",
        names.join(", ")
    )))
}

/// The refusal this write earns: every command each file declares as the
/// write leaves it, decided by the kept verdicts, or with `audit` by the
/// judge itself. Each file a write leaves is decided under its own path.
pub fn check(payload: &Value, audit: bool) -> Option<String> {
    let write = match WritePayload::read(payload) {
        Ok(write) => write,
        Err(error) => return Some(error),
    };
    if write.content.is_empty() {
        return None;
    }
    let files = match resulting(payload, &write) {
        Ok(Some(files)) => files,
        Ok(None) => return None,
        Err(error) => {
            return Some(format!(
                "{HOOK_ID}: BLOCKED: the file this write leaves cannot be rebuilt to find the commands it declares: {error}"
            ))
        }
    };
    files
        .iter()
        .filter(|(path, _)| !is_system_path(path))
        .find_map(|(path, text)| file_check(path, text, audit))
}

/// The refusal the file at `file_path`, holding `text`, earns.
fn file_check(file_path: &str, text: &str, audit: bool) -> Option<String> {
    match file_is_declared(file_path) {
        Ok(true) => return None,
        Ok(false) => {}
        Err(error) => return Some(format!("{HOOK_ID}: BLOCKED: {error}")),
    }
    let found = commands::declared(text);
    if found.is_empty() {
        return None;
    }
    match without_model(file_path, &found) {
        Ok(Some(decision)) => return decision,
        Ok(None) => {}
        Err(error) => return Some(format!("{HOOK_ID}: BLOCKED: {error}")),
    }
    let decided = if audit {
        judge(file_path, &found).map(Some)
    } else {
        verdicts::known(file_path, &found)
    };
    if let Ok(Some(verdicts)) = &decided {
        return refusal(file_path, verdicts);
    }
    // No verdict decides these commands and Oko recorded the judge as not
    // answering: the declared no-model alternative, the file's recorded
    // justification, decides them, and stderr says so.
    if let Some(outage) = crate::ports::model_judgement::recorded_outage() {
        eprintln!(
            "{HOOK_ID}: the judge does not answer ({outage}); {file_path} is decided by its recorded justification instead"
        );
        let cause = format!("no judge answers ({outage})");
        return justified(file_path, &found, &cause)
            .unwrap_or_else(|error| Some(format!("{HOOK_ID}: BLOCKED: {error}")));
    }
    match decided {
        Ok(Some(verdicts)) => refusal(file_path, &verdicts),
        Ok(None) => Some(match verdicts::request(file_path, &found) {
            Ok(request) => pending(file_path, &found, &request),
            Err(reason) => unjudged(file_path, &found, &reason),
        }),
        Err(reason) => Some(unjudged(file_path, &found, &reason)),
    }
}

pub fn run() {
    let payload = read_payload();
    let whole_file = crate::programs::args().any(|arg| arg == AUDIT_FLAG);
    if let Some(refusal) = check(&payload, whole_file) {
        deny_tool_use(&refusal);
    }
}
