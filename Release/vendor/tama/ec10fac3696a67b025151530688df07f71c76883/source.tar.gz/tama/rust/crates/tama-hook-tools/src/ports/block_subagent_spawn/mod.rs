//! Refuse launching a subagent on this machine (hook `block-subagent-spawn`).
//!
//! Subagents dividing work in a checkout do work nobody reviewed, and the
//! operator forbade launching them here. A block that is a sentence in a
//! report holds only until the next model reads its own promise differently;
//! this module is the enforcement, so whether a subagent can be launched
//! stops depending on who is reading.
//!
//! Three surfaces reach a subagent from inside a session, and each earns its
//! own refusal so the sentence names what was refused:
//!
//!   1. the delegation tools themselves, `task` and `agent`;
//!   2. a kernel payload that calls `agent(...)` or `workpool(...)`, or that
//!      reaches the delegation tool through the bridge as `tool.task(...)`;
//!   3. a shell command that starts an agent command line in headless mode,
//!      such as `claude -p`, `codex exec` or `omp --prompt`.
//!
//! The second and third surfaces carry as much weight as the first. A guard
//! that refused only the delegation tool would leave two working ways to
//! spawn the same worker while reading as settled, which is the exact shape
//! of the promise it replaces.
//!
//! The operator's escape is `DEVICE_SUBAGENT_SPAWN_APPROVED=1`, exported
//! outside the agent session — the shape the two consent gates in this crate
//! already use. A session cannot grant itself delegation, and the operator
//! re-allows it in one word without editing a hook.

use std::sync::LazyLock;

use regex::Regex;
use serde_json::Value;

use crate::ports::model_judgement;
use crate::ports::python_stdlib::shell_tokens;
use crate::ports::shell_text;
use crate::ports::tool_vocabulary::Call;
use crate::ports::transport_common as common;

pub const APPROVAL_ENV: &str = "DEVICE_SUBAGENT_SPAWN_APPROVED";
/// The value of [`APPROVAL_ENV`] that approves, as the operator's approvals
/// page declares it: https://tama.wisent.com/docs/hook-management
const APPROVAL_VALUE: &str = "1";
const TAG: &str = "block-subagent-spawn";
const PROMPT: &str = include_str!("judge-prompt.md");
const COMMANDS_SLOT: &str = "{commands}";
/// The schema the judge answers under and the two options it chooses from.
const JUDGEMENT: &str = "coding_agent_start";
const PASS: &str = "PASS";
const BLOCK: &str = "BLOCK";

/// Tools whose whole purpose is handing work to another agent.
const SPAWN_TOOLS: &[&str] = &["task", "functions.task", "agent", "functions.agent"];
/// Tools that run code able to call the spawn helpers or a command line.
const KERNEL_TOOLS: &[&str] = &["eval", "functions.eval", "node_repl", "mcp__node_repl_js"];

/// The arguments a coding agent's command line takes to run as a worker on
/// an instruction instead of an interactive program the operator watches.
/// Whether the program handed one is a coding agent is the model's reading:
/// a list of agent program names left out every agent it did not name.
const HEADLESS_ARGUMENTS: &[&str] = &["-p", "--print", "--prompt", "exec", "--headless", "--agent"];
/// `--prompt=…` and `--agent=…` carry the value in the same token.
const VALUE_JOINER: &str = "=";

const BANNER: &str = "BLOCKED: launching a subagent is forbidden on this machine.";
const ESCAPE: &str = "Do the work in the session that was asked for it. The operator re-allows \
                      delegation by exporting DEVICE_SUBAGENT_SPAWN_APPROVED=1 outside the agent \
                      session.";

/// `agent(...)` and `workpool(...)` as the kernel prelude exposes them. The
/// leading class keeps `myagent(` and `subagent(` out: a spawn is the bare
/// name, or a property access on the tool bridge below.
static SPAWN_CALL_RE: LazyLock<Regex> =
    LazyLock::new(|| common::compile(r"(?i)(?:\A|[^\w.$])(agent|workpool)\s*\("));
/// The same spawn reached through the tool bridge, `tool.task({...})`.
static BRIDGE_CALL_RE: LazyLock<Regex> =
    LazyLock::new(|| common::compile(r"(?i)\btool\s*\.\s*(task|agent)\s*\("));

/// Exported outside the session, so a session cannot write itself a grant;
/// an unset or other value approves nothing.
fn approved() -> bool {
    std::env::var_os(APPROVAL_ENV).is_some_and(|value| value == APPROVAL_VALUE)
}

fn refusal(detected: &str) -> String {
    format!("{BANNER} Detected: {detected}. {ESCAPE}")
}

/// The shell command a call carries: its line, else every string in the
/// payload, which is the shape the neighbouring shell guards already use.
fn command_from(call: &Call, payload: &Value) -> String {
    match call.command() {
        Some(command) => command.to_string(),
        None => common::strings(payload).join("\n"),
    }
}

/// The spawn helper this payload calls, named as the refusal will name it.
fn kernel_spawn_call(payload: &Value) -> Option<String> {
    let text = common::strings(payload).join("\n");
    if let Some(found) = SPAWN_CALL_RE.captures(&text) {
        let name = common::first_group(&found)?.as_str().to_lowercase();
        return Some(format!("this payload calls {name}(...)"));
    }
    let found = BRIDGE_CALL_RE.captures(&text)?;
    let name = common::first_group(&found)?.as_str().to_lowercase();
    Some(format!("this payload calls tool.{name}(...)"))
}

/// Is this argument one of the headless forms, in either spelling? A long
/// option may carry its value in the same token, `--prompt=do this`.
fn headless_argument(token: &str) -> bool {
    HEADLESS_ARGUMENTS.iter().any(|argument| {
        token == *argument || token.starts_with(&format!("{argument}{VALUE_JOINER}"))
    })
}

/// Whether one command segment hands its program a headless argument.
fn hands_headless_argument(segment: &str) -> bool {
    let tokens = shell_tokens(segment);
    let mut arguments = tokens.iter();
    arguments.next();
    arguments.any(|token| headless_argument(token))
}

/// The command segments of `command` that hand a program a headless
/// argument, an executor's quoted program read as a command of its own. The
/// cut is quote-aware, so a sentence naming `codex exec` inside a quoted
/// argument is not read as running it.
fn headless_candidates(command: &str) -> Vec<String> {
    let mut found = Vec::new();
    for segment in shell_text::commands(command) {
        if hands_headless_argument(segment) {
            found.push(segment.to_string());
        }
        let tokens = shell_tokens(segment);
        if let Some(inner) = shell_text::inner_command(&tokens) {
            if hands_headless_argument(&inner) {
                found.push(inner.to_string());
            }
        }
    }
    found
}

/// The refusal the model's reading of `candidates` earns when one starts a
/// coding agent, or the refusal an unanswered question earns
/// (`model_judgement::unanswered`); nothing when none does.
fn headless_agent_refusal(candidates: &[String]) -> Option<String> {
    if candidates.is_empty() {
        return None;
    }
    let listed = candidates.join("\n");
    let prompt = PROMPT.replace(COMMANDS_SLOT, &listed);
    match model_judgement::choose(&prompt, JUDGEMENT, &[PASS, BLOCK]) {
        Ok(judged) => (judged.choice == BLOCK).then(|| {
            refusal(&format!(
                "this command starts a coding agent: {}",
                judged.reason
            ))
        }),
        Err(unanswered) => model_judgement::unanswered::refusal(TAG, &unanswered, Some(&listed)),
    }
}

/// The refusal this call earns, or `None` when it passes. The caller writes
/// the sentence to stderr and exits with the blocking status.
pub fn evaluate(payload: &Value) -> Option<String> {
    if approved() {
        return None;
    }
    let call = Call::of(payload);
    // Providers spell the same tool `Task`, `task` and `functions.task`; the
    // refusal quotes the spelling the payload used.
    if call.is_one_of(SPAWN_TOOLS) {
        let tool = call.name().unwrap_or_default();
        return Some(refusal(&format!("the {tool} tool starts one")));
    }
    // The spawn helpers exist only in the kernel prelude, so only kernel code
    // is read for their calls. A shell command is judged by the command it
    // parses into; its quoted argument text is data, and prose there that
    // happens to read `name (` is not a call.
    let kernel = call.is_one_of(KERNEL_TOOLS);
    if kernel {
        if let Some(detected) = kernel_spawn_call(payload) {
            return Some(refusal(&detected));
        }
    }
    if kernel || call.is_shell() {
        return headless_agent_refusal(&headless_candidates(&command_from(&call, payload)));
    }
    None
}
