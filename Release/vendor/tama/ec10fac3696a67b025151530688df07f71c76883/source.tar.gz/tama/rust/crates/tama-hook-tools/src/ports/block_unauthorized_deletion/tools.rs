//! What a file tool or an evaluation deletes: a hashline section's `REM`, a
//! patch's `*** Delete File:`, and the deleting calls of Python and
//! JavaScript in an evaluation's code, whose path is read only where it is a
//! string written in the call; any other is a target that cannot be read.

use std::path::Path;
use std::sync::LazyLock;

use regex::Regex;
use serde_json::Value;

use super::Target;

/// A hashline section header: `[path#TAG]`.
static SECTION: LazyLock<Regex> =
    LazyLock::new(|| crate::ports::transport_common::compile(r"^\[([^#\]]+)#[0-9A-Fa-f]+\]$"));
/// A patch's deletion of a whole file.
const DELETE_FILE: &str = "*** Delete File:";
/// The hashline operation that deletes the section's file.
const REMOVE: &str = "REM";
/// A deleting call whose first argument is a string written in it.
static DELETING_CALL: LazyLock<Regex> = LazyLock::new(|| {
    crate::ports::transport_common::compile(
        r#"\b(?:os\.(?:remove|unlink|rmdir|removedirs)|shutil\.rmtree|send2trash|fs\.(?:promises\.)?(?:rm|rmSync|unlink|unlinkSync|rmdir|rmdirSync))\s*\(\s*(?:r?(?:"([^"\\]*)"|'([^'\\]*)')\s*[,)])?"#,
    )
});
/// A deleting method of an object whose path the code holds elsewhere.
static DELETING_METHOD: LazyLock<Regex> = LazyLock::new(|| {
    crate::ports::transport_common::compile(
        r"\.(?:unlink|rmdir|rmtree)\s*\(\s*(?:missing_ok\s*=\s*\w+\s*)?\)",
    )
});

/// The files a hashline or patch script in the call deletes.
pub(super) fn patched(payload: &Value, cwd: &Path) -> Vec<Target> {
    let mut found = Vec::new();
    for script in scripts(payload) {
        let mut section: Option<&str> = None;
        for line in script.lines() {
            let line = line.trim_end();
            if let Some(captures) = SECTION.captures(line) {
                section = captures.get(1).map(|path| path.as_str());
            } else if line == REMOVE {
                if let Some(path) = section {
                    found.push(path_target(path, cwd));
                }
            } else if let Some(path) = line.strip_prefix(DELETE_FILE) {
                found.push(path_target(path.trim(), cwd));
            }
        }
    }
    found
}

/// Every script the call carries: the harness's own tool input and the
/// normalized one each name it under `input` or `patch`.
fn scripts(payload: &Value) -> Vec<&str> {
    let inputs = [payload.pointer("/tool/input"), payload.get("tool_input")];
    inputs
        .into_iter()
        .flatten()
        .flat_map(|input| {
            ["input", "patch"]
                .into_iter()
                .filter_map(move |key| input.get(key))
        })
        .filter_map(Value::as_str)
        .collect()
}

fn path_target(path: &str, cwd: &Path) -> Target {
    Target::Paths(vec![super::area::absolute(cwd, path)])
}

/// What the code of an evaluation deletes. A line the evaluation runs as a
/// shell command (`!rm x`) is read as the shell reads it.
pub(super) fn evaluated(payload: &Value, code: &str, cwd: &Path) -> Vec<Target> {
    let mut found = Vec::new();
    for captures in DELETING_CALL.captures_iter(code) {
        match captures.get(1).or_else(|| captures.get(2)) {
            Some(path) => found.push(path_target(path.as_str(), cwd)),
            None => found.push(Target::Unknown(format!(
                "`{}` deletes a path the code computes",
                captures.get(0).map_or("", |call| call.as_str()).trim()
            ))),
        }
    }
    for method in DELETING_METHOD.find_iter(code) {
        found.push(Target::Unknown(format!(
            "`{}` deletes the path its object holds, which the code computes",
            method.as_str()
        )));
    }
    for line in code.lines() {
        if let Some(command) = line.trim_start().strip_prefix('!') {
            let shell = serde_json::json!({
                "tool_name": "bash",
                "tool_input": { "command": command },
                "cwd": cwd.to_string_lossy(),
                "session_id": payload.get("session_id"),
            });
            found.extend(super::shell::targets(&shell, cwd, command));
        }
    }
    found
}
