//! Which recorded edits one staging takes: every edit of the session, or
//! only the edits of the paths the caller names (`tama stage --path`).
//!
//! One session often makes unrelated changes in one checkout — a repair and
//! a separate feature, or a change another session's later work overlaps.
//! Staging all of them at once makes one commit of several capabilities, and
//! one path another session changed in between refuses the rest. Naming the
//! paths stages exactly one change, so it becomes one reviewable commit and
//! the other paths wait for their own. A named path the session never edited
//! is refused, so a misspelt path is never a staging of nothing.
use std::path::{Path, PathBuf};

use super::receipts::Edit;

/// `path` as the checkout names it: relative to `root`. An absolute path
/// outside the checkout is refused naming both.
fn in_checkout(root: &Path, path: &Path) -> Result<PathBuf, String> {
    if !path.is_absolute() {
        return Ok(path.to_path_buf());
    }
    match path.strip_prefix(root) {
        Ok(relative) => Ok(relative.to_path_buf()),
        Err(cause) => Err(format!(
            "--path {} is outside the checkout {}: {cause}; the index is unchanged",
            path.display(),
            root.display()
        )),
    }
}

/// The edits of `edits` that touch a path in `only`; every edit when `only`
/// is empty. A path in `only` no edit touches is refused by name.
pub(super) fn select(root: &Path, edits: Vec<Edit>, only: &[PathBuf]) -> Result<Vec<Edit>, String> {
    if only.is_empty() {
        return Ok(edits);
    }
    let wanted = only
        .iter()
        .map(|path| in_checkout(root, path))
        .collect::<Result<Vec<_>, _>>()?;
    let touched = edits
        .iter()
        .map(|edit| in_checkout(root, &edit.path))
        .collect::<Result<Vec<_>, _>>()?;
    if let Some(missing) = wanted.iter().find(|path| !touched.contains(path)) {
        return Err(format!(
            "--path {} names no recorded edit of this session in {}; the index is unchanged",
            missing.display(),
            root.display()
        ));
    }
    Ok(edits
        .into_iter()
        .zip(touched)
        .filter(|(_, path)| wanted.contains(path))
        .map(|(edit, _)| edit)
        .collect())
}
