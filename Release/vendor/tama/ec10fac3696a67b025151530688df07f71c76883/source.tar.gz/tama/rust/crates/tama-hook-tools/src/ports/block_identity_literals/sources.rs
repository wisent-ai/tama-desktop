//! Where an identity can come from, and how each place is asked.
//!
//! Three sources count, and the roots of all three are injectable so a test
//! runs against a small fixture instead of the real multi-gigabyte store.
//! Walking the real store per literal is what made an earlier version of this
//! gate take minutes per check.

use std::path::{Path, PathBuf};

use serde_json::Value;

use crate::ports::check_numeric_literals_provenance::quote_in_user_msg;

const PROVENANCE_ENV: &str = "IDENTITY_PROVENANCE_FILE";
const PROVENANCE_DEFAULT: &str = "~/.shared-hooks/identity_provenance.json";
const TRANSCRIPT_ENV: &str = "IDENTITY_TRANSCRIPT_ROOT";
const TRANSCRIPT_DEFAULT: &str = "~/.omp/agent/sessions";
const ARTIFACT_ENV: &str = "IDENTITY_ARTIFACT_ROOTS";
/// A token cache, a cloud profile, a machine registry, the names file: places
/// that know an identity because something outside a conversation issued it.
const ARTIFACT_DEFAULT: &[&str] = &[
    "~/.azure/msal_token_cache.json",
    "~/.azure/azureProfile.json",
    "~/.stado/local-storage/registry.json",
    "~/.stado/forwards",
    "~/NAMES.md",
];
/// Never opened while searching for an artifact: a vault is ciphertext and a
/// log is chat output under another name, so either would make the artifact
/// test meaningless.
const ARTIFACT_SKIP: &[&str] = &[".vault.json", ".jsonl", ".log", ".audit.jsonl"];
#[path = "issuers/defects.rs"]
mod defects;
#[path = "issuers/reviews.rs"]
mod reviews;
const USER_SAID_KEY: &str = "user_said";
fn expand(path: &str) -> PathBuf {
    match path.strip_prefix("~/") {
        Some(rest) => crate::util::home_dir().join(rest),
        None => PathBuf::from(path),
    }
}

fn from_env(name: &str, default: &str) -> PathBuf {
    match std::env::var(name) {
        Ok(value) if !value.is_empty() => expand(&value),
        _ => expand(default),
    }
}

fn artifact_roots() -> Vec<PathBuf> {
    match std::env::var(ARTIFACT_ENV) {
        Ok(value) if !value.is_empty() => value
            .split(':')
            .filter(|part| !part.is_empty())
            .map(expand)
            .collect(),
        _ => ARTIFACT_DEFAULT.iter().copied().map(expand).collect(),
    }
}

/// The entries of `folder`. A folder that does not exist holds nothing; one
/// that cannot be listed, or an entry that cannot be read, is said on stderr
/// with its cause, since nothing in it can source a value this write names.
fn listed(folder: &Path) -> Vec<PathBuf> {
    let entries = match std::fs::read_dir(folder) {
        Ok(entries) => entries,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Vec::new(),
        Err(error) => {
            eprintln!(
                "block-identity-literals: {} cannot be listed, so nothing in it sources a \
                 value: {error}",
                folder.display()
            );
            return Vec::new();
        }
    };
    let mut paths = Vec::new();
    for entry in entries {
        match entry {
            Ok(entry) => paths.push(entry.path()),
            Err(error) => eprintln!(
                "block-identity-literals: an entry of {} cannot be read: {error}",
                folder.display()
            ),
        }
    }
    paths
}

fn walk(root: &Path, found: &mut Vec<PathBuf>) {
    for path in listed(root) {
        if path.is_dir() {
            walk(&path, found)
        } else {
            found.push(path)
        }
    }
}

fn skipped(path: &Path) -> bool {
    let name = path.to_string_lossy().to_lowercase();
    ARTIFACT_SKIP.iter().any(|suffix| name.ends_with(suffix))
}

/// What the machine holds outside any conversation, read at most once per
/// dispatch: the stored transcripts' file names and the artifact files'
/// text. A page carrying many identity-looking values asked each of them
/// against a fresh listing of the whole transcript store and a fresh read of
/// every artifact file, so its edit stood past the hook runner's limit and was
/// refused by time instead of by a reading. Each part is loaded the first time
/// a value needs it, so a write whose every value the checkout already tracks
/// reads neither.
#[derive(Default)]
pub struct Machine {
    transcript_names: std::cell::OnceCell<Vec<String>>,
    artifact_texts: std::cell::OnceCell<Vec<String>>,
    issued_reviews: std::cell::OnceCell<Issued>,
    issued_defects: std::cell::OnceCell<Issued>,
}

impl Machine {
    /// True when something outside any conversation knows this identity.
    pub fn in_an_artifact(&self, value: &str) -> bool {
        let needle = value.to_lowercase();
        self.artifact_texts
            .get_or_init(artifact_texts)
            .iter()
            .any(|text| text.contains(&needle))
    }

    /// Whether a source outside every conversation carries this value: the
    /// written file's checkout (`tracked`), a transcript's name, an artifact
    /// or an issuing program: Oko's review queue (each entry's `id`) or its
    /// defect register (each defect's `id`), never an id quoted in their
    /// text. An absent issuer issued nothing. An issuer that issued the value
    /// settles it whatever the other answers; only when none did is the
    /// failure to ask returned, naming every issuer that could not be read.
    pub fn settles(
        &self,
        value: &str,
        tracked: &std::collections::HashSet<String>,
    ) -> Result<bool, String> {
        if tracked.contains(value) || self.names_a_transcript(value) || self.in_an_artifact(value) {
            return Ok(true);
        }
        let (queue, register) = (&self.issued_reviews, &self.issued_defects);
        let answers = [
            issued(queue, reviews::issued, value),
            issued(register, defects::issued, value),
        ];
        if answers.contains(&Ok(true)) {
            return Ok(true);
        }
        let failures: Vec<String> = answers.into_iter().filter_map(Result::err).collect();
        if failures.is_empty() {
            Ok(false)
        } else {
            Err(failures.join("; "))
        }
    }

    /// True when a stored transcript is named after this value: the harness
    /// issued it as that session's id, so it is an artifact outside any
    /// conversation. Only names are read, which keeps a session id — the
    /// identity a task, a ruling or an evidence report names most — from
    /// costing a read of every transcript on the machine. The folder a harness
    /// keeps beside each transcript, named like it without its extension,
    /// holds that session's artifacts and subagents, not sessions the store
    /// names, so it is not entered.
    pub fn names_a_transcript(&self, value: &str) -> bool {
        let needle = value.to_lowercase();
        self.transcript_names
            .get_or_init(transcript_names)
            .iter()
            .any(|name| name.contains(&needle))
    }
}

/// The lowercased ids an issuing program issued, or why it cannot be asked.
type Issued = Result<std::collections::HashSet<String>, String>;

/// Whether `issuer`, read once into `cell`, issued `value`; its failure to be
/// asked, named with its cause, otherwise.
fn issued(
    cell: &std::cell::OnceCell<Issued>,
    issuer: fn() -> Issued,
    value: &str,
) -> Result<bool, String> {
    match cell.get_or_init(issuer) {
        Ok(ids) => Ok(ids.contains(&value.to_lowercase())),
        Err(failure) => Err(failure.clone()),
    }
}

/// The lowercased text of every artifact file, a vault or a log excepted.
fn artifact_texts() -> Vec<String> {
    let mut files: Vec<PathBuf> = Vec::new();
    for root in artifact_roots() {
        if root.is_file() {
            files.push(root)
        } else {
            walk(&root, &mut files)
        }
    }
    let mut texts = Vec::new();
    for path in files.iter().filter(|path| !skipped(path)) {
        match std::fs::read(path) {
            Ok(bytes) => texts.push(String::from_utf8_lossy(&bytes).to_lowercase()),
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
            Err(error) => eprintln!(
                "block-identity-literals: artifact {} cannot be read, so it sources no \
                 value: {error}",
                path.display()
            ),
        }
    }
    texts
}

/// The lowercased file name of every stored transcript.
fn transcript_names() -> Vec<String> {
    let mut transcripts: Vec<PathBuf> = Vec::new();
    sessions(
        &from_env(TRANSCRIPT_ENV, TRANSCRIPT_DEFAULT),
        &mut transcripts,
    );
    transcripts
        .iter()
        .filter_map(|path| path.file_name())
        .map(|name| name.to_string_lossy().to_lowercase())
        .collect()
}

/// Every file below `root`, without entering a folder that sits beside a
/// file of its own name and an extension: a transcript's artifact folder.
fn sessions(root: &Path, found: &mut Vec<PathBuf>) {
    let entries = listed(root);
    let files: std::collections::HashSet<std::ffi::OsString> = entries
        .iter()
        .filter(|path| !path.is_dir())
        .filter_map(|path| path.file_stem().map(std::ffi::OsStr::to_os_string))
        .collect();
    for path in entries {
        match path.is_dir() {
            true if path.file_name().is_some_and(|name| files.contains(name)) => {}
            true => sessions(&path, found),
            false => found.push(path),
        }
    }
}

/// For each of `values` (lowercase), up to two stored sessions in which the
/// user said it, read in one walk of the shared per-transcript index.
pub fn user_sessions_mentioning(
    values: &std::collections::BTreeSet<String>,
) -> Result<std::collections::BTreeMap<String, Vec<PathBuf>>, String> {
    super::mention_index::sessions(&from_env(TRANSCRIPT_ENV, TRANSCRIPT_DEFAULT), values)
}

/// The provenance document, and the complaint when it cannot be read.
pub fn load_provenance() -> (Value, Option<String>) {
    let path = from_env(PROVENANCE_ENV, PROVENANCE_DEFAULT);
    let text = match std::fs::read_to_string(&path) {
        Ok(text) => text,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
            return (Value::Object(Default::default()), None);
        }
        Err(error) => {
            return (
                Value::Object(Default::default()),
                Some(format!(
                    "cannot read identity provenance {}: {error}",
                    path.display()
                )),
            );
        }
    };
    match serde_json::from_str::<Value>(&text) {
        Ok(Value::Object(map)) => (Value::Object(map), None),
        Ok(_) => (
            Value::Object(Default::default()),
            Some("identity_provenance.json must be an object: value -> {user_said}".to_string()),
        ),
        Err(error) => (
            Value::Object(Default::default()),
            Some(format!(
                "identity_provenance.json is not valid JSON: {error}"
            )),
        ),
    }
}

/// True when the document records a verbatim user quote declaring this value
/// and that quote is found in a real `role=user` message.
pub fn provenanced(value: &str, doc: &Value, sanitize: fn(&str) -> String) -> Result<bool, String> {
    let Some(map) = doc.as_object() else {
        return Ok(false);
    };
    for (recorded, entry) in map {
        if sanitize(recorded) != value {
            continue;
        }
        let quote = match entry.get(USER_SAID_KEY) {
            Some(Value::String(text)) => text.clone(),
            _ => return Ok(false),
        };
        if !quote.to_lowercase().contains(value) {
            return Ok(false);
        }
        return quote_in_user_msg(&quote);
    }
    Ok(false)
}
