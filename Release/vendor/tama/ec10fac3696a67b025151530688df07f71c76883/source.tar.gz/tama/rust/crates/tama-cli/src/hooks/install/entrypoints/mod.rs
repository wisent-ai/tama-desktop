//! The entrypoints outside the managed hook trees that a full install owns:
//! the global Git dispatchers, the approved repository hooks, and the OMP
//! adapter registered among OMP's extensions, and Tama named an announcer in
//! Oko for the adapter's grant announcements (`announcer.rs`). A
//! session-control install rewrites only the dispatchers that are already Tama's.

pub(super) mod announcer;
mod omp;

pub(super) use omp::{omp_config, register_omp_adapter};

use std::collections::{BTreeMap, BTreeSet};
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};

use tama_core::git::Git;

use super::writes::Writes;

/// Every permission bit of a file: read, write and execute for owner, group
/// and others.
const MODE_BITS: u32 = (libc::S_IRWXU | libc::S_IRWXG | libc::S_IRWXO) as u32;
/// A hook Git runs: its owner writes it, and anyone may read and run it.
const EXECUTABLE_FILE: u32 =
    (libc::S_IRWXU | libc::S_IRGRP | libc::S_IXGRP | libc::S_IROTH | libc::S_IXOTH) as u32;
const MANAGED_DISPATCHER_MARKER: &str = "tama managed";
use tama_core::install::GIT_HOOKS;

/// The global dispatcher for one Git hook: the one script `tama install`
/// writes too ([`tama_core::install::dispatcher_body`]), so a release install
/// and a plain install never disagree about what runs before a commit or a
/// push.
fn dispatcher_body(runtime: &Path, hook: &str, backup: &Path) -> Vec<u8> {
    tama_core::install::dispatcher_body(&runtime.to_string_lossy(), hook, &backup.to_string_lossy())
        .into_bytes()
}

/// Where Git runs global hooks. `git config --get` answers an unset key with a
/// failing exit and nothing said; only that means the default directory. A
/// git that cannot run, or a config it cannot read, is an error: read as
/// unset, the dispatchers went to a directory Git never runs and every
/// commit and push hook stopped running in silence.
fn global_hooks_path(home: &Path) -> Result<PathBuf, String> {
    let home_text = home.to_str().ok_or_else(|| {
        format!(
            "the home {} is not UTF-8, so Git cannot be told it to read core.hooksPath",
            home.display()
        )
    })?;
    let args = ["config", "--global", "--get", "core.hooksPath"];
    let output = Git::of(None)
        .variables(&[("HOME", home_text)])
        .output(&args)?;
    let said = String::from_utf8_lossy(&output.stderr).trim().to_string();
    if !output.status.success() && !said.is_empty() {
        return Err(format!(
            "git {} ended with {}: {said}",
            args.join(" "),
            output.status
        ));
    }
    let value = String::from_utf8_lossy(&output.stdout).trim().to_string();
    Ok(match value.as_str() {
        "" => home.join(".config/git/hooks"),
        "~" => home.to_path_buf(),
        other => match other.strip_prefix("~/") {
            Some(rest) => home.join(rest),
            None => PathBuf::from(other),
        },
    })
}

/// A file's bytes and permission bits, as a write; either unreadable is an
/// error naming the file rather than a hook installed with a guessed mode.
fn copied(file: &Path) -> Result<(Vec<u8>, u32), String> {
    let bytes =
        std::fs::read(file).map_err(|error| format!("cannot read {}: {error}", file.display()))?;
    let mode = std::fs::metadata(file)
        .map(|m| m.permissions().mode() & MODE_BITS)
        .map_err(|error| format!("cannot read the mode of {}: {error}", file.display()))?;
    Ok((bytes, mode))
}

/// The directories, or the files, directly in `directory`. A directory the
/// release does not carry holds none; one that cannot be listed, or an entry
/// that cannot be read, is an error: skipped, a repository's approved hooks
/// were not installed and nothing said so.
fn children(directory: &Path, directories: bool) -> Result<Vec<PathBuf>, String> {
    let entries = match std::fs::read_dir(directory) {
        Ok(entries) => entries,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(Vec::new()),
        Err(error) => return Err(format!("cannot list {}: {error}", directory.display())),
    };
    let mut found = Vec::new();
    for entry in entries {
        let path = entry
            .map_err(|error| format!("cannot read an entry of {}: {error}", directory.display()))?
            .path();
        if (directories && path.is_dir()) || (!directories && path.is_file()) {
            found.push(path);
        }
    }
    found.sort();
    Ok(found)
}

/// The global Git dispatchers and every approved repository hook.
pub(super) fn add_git_hook_writes(
    writes: &mut Writes,
    home: &Path,
    runtime_root: &Path,
    release_root: &Path,
    moved: &[(PathBuf, PathBuf)],
    old_root: &Path,
    old_home: &Path,
) -> Result<(), String> {
    let moved_by_source: BTreeMap<&PathBuf, &PathBuf> = moved.iter().map(|(s, d)| (s, d)).collect();
    // An entrypoint an emergency disable moved aside is written at the place
    // it was moved to; one it did not move is written where Git runs it.
    let redirected = |active: PathBuf| match moved_by_source.get(&active) {
        Some(disabled) => (*disabled).clone(),
        None => active,
    };
    let hooks_path = global_hooks_path(home)?;
    for hook in GIT_HOOKS {
        let backup = hooks_path.join(format!("{hook}.before-tama"));
        let body = dispatcher_body(&runtime_root.join("current"), hook, &backup);
        writes.insert(redirected(hooks_path.join(hook)), (body, EXECUTABLE_FILE));
    }
    let mut repo_targets = BTreeSet::new();
    for (source, disabled) in moved {
        let Some(parent) = source.parent() else {
            continue;
        };
        if parent.file_name() != Some(".githooks".as_ref()) {
            continue;
        }
        let project = named(parent.parent(), "the repository above a .githooks folder")?;
        let approved = release_root
            .join("repo-githooks")
            .join(project)
            .join(named(Some(source), "a moved repository hook")?);
        if !approved.is_file() {
            return Err(format!(
                "Approved repository hook is missing: {}",
                approved.display()
            ));
        }
        writes.insert(disabled.clone(), copied(&approved)?);
        repo_targets.insert(source.clone());
    }
    // The workshop is where the release was built, relative to the home it
    // was built in. A release built outside that home names no workshop, so
    // no repository's own hooks can be found; that is said, not skipped.
    let workshop = match old_root
        .parent()
        .map(|parent| parent.strip_prefix(old_home))
    {
        Some(Ok(workshop)) => home.join(workshop),
        _ => {
            eprintln!(
                "tama hooks install: the release was built at {}, outside {}, so no repository's own Git hooks are installed",
                old_root.display(),
                old_home.display()
            );
            return Ok(());
        }
    };
    for project in children(&release_root.join("repo-githooks"), true)? {
        let name = named(Some(&project), "a repo-githooks project")?;
        let candidates = [workshop.join(name), workshop.join("backends").join(name)];
        let Some(root) = candidates.into_iter().find(|candidate| candidate.is_dir()) else {
            continue;
        };
        for file in children(&project, false)? {
            let active = root
                .join(".githooks")
                .join(named(Some(&file), "a repo-githooks file")?);
            if !repo_targets.contains(&active) {
                writes.insert(redirected(active), copied(&file)?);
            }
        }
    }
    Ok(())
}

/// The global dispatchers a session-control install keeps working. Each one
/// runs the hooks of `<runtime>/current`, which this install replaces, so a
/// dispatcher an earlier release wrote calls a hook the new release may no
/// longer carry, and every commit or push it guards is refused. Each one that
/// is Tama's is rewritten for the new release in the same transaction; one
/// that is absent, set aside by an emergency disable, or not Tama's is left as
/// it is, since this install connects no Git hook that was not connected.
pub(super) fn add_managed_dispatcher_writes(
    writes: &mut Writes,
    home: &Path,
    runtime_root: &Path,
) -> Result<(), String> {
    let hooks_path = global_hooks_path(home)?;
    for hook in GIT_HOOKS {
        let active = hooks_path.join(hook);
        let bytes = match std::fs::read(&active) {
            Ok(bytes) => bytes,
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => continue,
            Err(error) => {
                return Err(format!(
                    "cannot read the Git dispatcher {}: {error}",
                    active.display()
                ))
            }
        };
        if managed_dispatcher(&bytes) {
            let backup = hooks_path.join(format!("{hook}.before-tama"));
            let body = dispatcher_body(&runtime_root.join("current"), hook, &backup);
            writes.insert(active, (body, EXECUTABLE_FILE));
        }
    }
    Ok(())
}

/// Whether a hook's bytes are a dispatcher Tama wrote.
fn managed_dispatcher(bytes: &[u8]) -> bool {
    let head: String = String::from_utf8_lossy(bytes)
        .lines()
        .take(MANAGED_DISPATCHER_MARKER.len())
        .collect();
    head.contains(MANAGED_DISPATCHER_MARKER)
}

/// The last component of `path`, or a refusal naming what it should name:
/// an empty name would install a hook beside the folder it belongs in.
fn named<'a>(path: Option<&'a Path>, what: &str) -> Result<&'a std::ffi::OsStr, String> {
    path.and_then(Path::file_name)
        .ok_or_else(|| format!("{what} has no name to install under: {path:?}"))
}

/// What an active entrypoint is, in the terms an operator decides in.
fn entrypoint_kind(path: &Path) -> String {
    match std::fs::read(path) {
        Ok(bytes) if managed_dispatcher(&bytes) => "tama-managed dispatcher".to_string(),
        Ok(_) => "not Tama-managed".to_string(),
        Err(error) => format!("unreadable: {error}"),
    }
}

/// Every conflict between an active entrypoint and its disabled copy, in one refusal.
pub(super) fn refuse_entrypoint_conflicts(moved: &[(PathBuf, PathBuf)]) -> Result<(), String> {
    let exists = |p: &Path| std::fs::symlink_metadata(p).is_ok();
    let conflicts: Vec<&(PathBuf, PathBuf)> = moved
        .iter()
        .filter(|(s, d)| exists(s) && exists(d))
        .collect();
    if conflicts.is_empty() {
        return Ok(());
    }
    let mut lines = vec![format!(
        "{} hook entrypoint(s) exist both active and disabled; resolve each one before restoring policy:",
        conflicts.len()
    )];
    for (source, disabled) in conflicts {
        lines.push(format!(
            "  {} ({})",
            source.display(),
            entrypoint_kind(source)
        ));
        lines.push(format!("    disabled copy: {}", disabled.display()));
    }
    Err(lines.join("\n"))
}
