use super::{by_id, Protocol};
use serde_json::{json, Value};
/// What reaches a harness on its standard output and standard error.
pub struct Adapted {
    pub stdout: String,
    pub stderr: String,
    /// Native JSON carries feedback only when the hook process succeeds.
    pub success_exit: bool,
}

/// The output `provider`'s harness reads for a decision Tama formatted as
/// `document`; none when the harness reads Tama's own document. A block's
/// reason is the document's `reason`, or the whole document when it has none.
pub fn adapted(provider: &str, event: &str, blocked: bool, document: &str) -> Option<Adapted> {
    let adapter = by_id(provider)?;
    // A decision written as plain text rather than JSON is its own reason and
    // carries no context.
    let parsed = serde_json::from_str::<Value>(document).ok();
    let context = parsed
        .as_ref()
        .and_then(|value| value.pointer("/hookSpecificOutput/additionalContext"))
        .and_then(Value::as_str);
    let stated = parsed
        .as_ref()
        .and_then(|value| value.get("reason"))
        .and_then(Value::as_str);
    let reason = match stated {
        Some(reason) => reason,
        None => document,
    };
    let quiet = String::new;
    match (adapter.decision, blocked) {
        (Protocol::Claude, _) => None,
        (Protocol::ExitStderr, false) => Some(Adapted {
            stdout: quiet(),
            stderr: quiet(),
            success_exit: false,
        }),
        (Protocol::ExitStderrContext, false) => Some(Adapted {
            stdout: match context {
                Some(text) => text.to_owned(),
                None => quiet(),
            },
            stderr: quiet(),
            success_exit: false,
        }),
        (Protocol::ExitStderrHookContext, false) => Some(Adapted {
            stdout: match parsed
                .as_ref()
                .and_then(|value| value.get("hookSpecificOutput"))
            {
                Some(output) if context.is_some() => {
                    let mut output = output.clone();
                    if let Some(target) = adapter.events.get(event).filter(|target| {
                        output["hookEventName"].as_str() != Some(target.key.as_str())
                    }) {
                        output["hookEventName"] = Value::String(target.key.clone());
                    }
                    let mut response = serde_json::Map::new();
                    response.insert("hookSpecificOutput".into(), output);
                    Value::Object(response).to_string()
                }
                _ => quiet(),
            },
            stderr: quiet(),
            success_exit: false,
        }),
        (Protocol::ExitStderrNestedContext | Protocol::ExitStderrDroidContext, false) => {
            Some(Adapted {
                stdout: match context {
                    Some(text)
                        if adapter.decision == Protocol::ExitStderrDroidContext
                            && event == "user_prompt_submit" =>
                    {
                        json!({ "additionalContext": text }).to_string()
                    }
                    Some(text) => {
                        json!({ "hookSpecificOutput": { "additionalContext": text } }).to_string()
                    }
                    None => quiet(),
                },
                stderr: quiet(),
                success_exit: false,
            })
        }
        (Protocol::CopilotPermission, false) => Some(Adapted {
            stdout: match context {
                Some(text) => json!({ "additionalContext": text }).to_string(),
                None => quiet(),
            },
            stderr: quiet(),
            success_exit: false,
        }),
        (
            Protocol::ExitStderr
            | Protocol::ExitStderrContext
            | Protocol::ExitStderrHookContext
            | Protocol::ExitStderrNestedContext
            | Protocol::ExitStderrDroidContext,
            true,
        ) => Some(Adapted {
            stdout: quiet(),
            stderr: reason.to_owned(),
            success_exit: false,
        }),
        (Protocol::CursorPermission, false) => Some(Adapted {
            stdout: json!({ "permission": "allow" }).to_string(),
            stderr: quiet(),
            success_exit: false,
        }),
        (Protocol::CursorPermission, true) => Some(Adapted {
            stdout:
                json!({ "permission": "deny", "user_message": reason, "agent_message": reason })
                    .to_string(),
            stderr: quiet(),
            success_exit: false,
        }),
        (Protocol::CopilotPermission, true) if event.starts_with("post_tool_use:") => {
            Some(Adapted {
                stdout: json!({ "additionalContext": reason }).to_string(),
                stderr: quiet(),
                success_exit: true,
            })
        }
        (Protocol::CopilotPermission, true) => Some(Adapted {
            stdout: json!({ "permissionDecision": "deny", "permissionDecisionReason": reason })
                .to_string(),
            stderr: quiet(),
            success_exit: false,
        }),
    }
}
