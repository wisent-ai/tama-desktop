//! A write into a checkout's scratch heap: an existing top-level directory of
//! the checkout that holds no tracked file and that git does not ignore.
//!
//! Such a directory is neither source nor the checkout's declared build
//! directory; whatever a session leaves there shows up as untracked files in
//! every other session's status and is published by the next broad commit.
//! The workshop puts a run's throwaway state under the checkout's ignored
//! `.build/` (`~/agents/operations.md`), so the refusal names that directory.
//! A directory that does not exist yet is a new part of the source being
//! written and passes, as do a file at the checkout's root, a directory that
//! holds tracked files, and an ignored one.

use std::collections::BTreeSet;
use std::path::{Component, Path, PathBuf};

use tama_hooks::session_record::deny_tool_use;

use tama_core::git::Git;

/// The directory the workshop declares for a run's throwaway state.
const BUILD_DIRECTORY: &str = ".build";
/// Git's own directory, which no tool call writes as source.
const GIT_DIRECTORY: &str = ".git";
/// `git check-ignore` exits with this status when none of the given paths is
/// ignored; any other failure is git's own error.
/// https://git-scm.com/docs/git-check-ignore#_exit_status
const NOT_IGNORED: i32 = 1;

/// Refuse a write whose target lands in a checkout's scratch heap, naming
/// the heap and the build directory the checkout declares instead.
pub(super) fn refuse(candidates: &[String]) {
    let mut heaps: BTreeSet<String> = BTreeSet::new();
    for path in candidates {
        let resolved = match super::normalized_paths(path) {
            Ok(spellings) => spellings.into_iter().last(),
            Err(error) => deny_tool_use(&format!(
                "BLOCKED: {path} cannot be resolved, so whether it lands in a checkout's scratch heap is not known: {error}"
            )),
        };
        let Some(resolved) = resolved else {
            continue;
        };
        match scratch_heap(Path::new(&resolved)) {
            Ok(Some((heap, build))) => {
                heaps.insert(format!(
                    "{path} lands in {}, which holds no tracked file and is not ignored; put a run's throwaway state under {}",
                    heap.display(),
                    build.display()
                ));
            }
            Ok(None) => {}
            Err(error) => deny_tool_use(&format!(
                "BLOCKED: whether {path} lands in a checkout's scratch heap cannot be read: {error}"
            )),
        }
    }
    if heaps.is_empty() {
        return;
    }
    let listed = heaps.into_iter().collect::<Vec<_>>().join(" | ");
    deny_tool_use(&format!(
        "BLOCKED: a write into a checkout directory that is neither source nor its ignored build directory: {listed}"
    ));
}

/// Where a write to `path` lands when it lands in a scratch heap: the heap's
/// directory and the build directory the checkout declares instead. `None`
/// for every other target. A checkout or a directory whose state cannot be
/// read is the error, naming it.
pub(super) fn scratch_heap(path: &Path) -> Result<Option<(PathBuf, PathBuf)>, String> {
    let Some(parent) = path.parent() else {
        return Ok(None);
    };
    let Some(root) =
        tama_core::presence::checkout_root(parent).map_err(|error| error.to_string())?
    else {
        return Ok(None);
    };
    let Ok(inside) = path.strip_prefix(root) else {
        return Ok(None);
    };
    let mut components = inside.components();
    let (Some(Component::Normal(top)), Some(_)) = (components.next(), components.next()) else {
        return Ok(None);
    };
    if top == GIT_DIRECTORY || top == BUILD_DIRECTORY {
        return Ok(None);
    }
    let directory = root.join(top);
    if !tama_core::presence::present(&directory).map_err(|error| error.to_string())? {
        return Ok(None);
    }
    if ignored(root, &directory)? || tracked(root, &directory)? {
        return Ok(None);
    }
    Ok(Some((directory, root.join(BUILD_DIRECTORY))))
}

/// Whether git ignores `directory` by the checkout's own rules.
fn ignored(root: &Path, directory: &Path) -> Result<bool, String> {
    let output =
        Git::of(Some(root))
            .paths(&[directory])
            .output(&["check-ignore", "--quiet", "--"])?;
    if output.status.success() {
        return Ok(true);
    }
    if output.status.code() == Some(NOT_IGNORED) {
        return Ok(false);
    }
    Err(format!(
        "git check-ignore {} in {} exited {}: {}",
        directory.display(),
        root.display(),
        output.status,
        String::from_utf8_lossy(&output.stderr).trim()
    ))
}

/// Whether the checkout tracks any file under `directory`.
fn tracked(root: &Path, directory: &Path) -> Result<bool, String> {
    let output = Git::of(Some(root))
        .paths(&[directory])
        .output(&["ls-files", "-z", "--"])?;
    if !output.status.success() {
        return Err(format!(
            "git ls-files {} in {} exited {}: {}",
            directory.display(),
            root.display(),
            output.status,
            String::from_utf8_lossy(&output.stderr).trim()
        ));
    }
    Ok(!output.stdout.is_empty())
}
