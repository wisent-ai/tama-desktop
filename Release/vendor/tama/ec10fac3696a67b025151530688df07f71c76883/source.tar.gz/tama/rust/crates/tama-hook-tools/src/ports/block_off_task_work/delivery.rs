//! Which shell lines publish work, `git commit`, and the repository they
//! publish from; and where a whole-file write would replace another
//! session's unfinished change.
//!
//! Every repository has one checkout and several sessions write in it at
//! once, and any of them stages and commits any work there, its own or
//! another session's. Every file a session writes is logged under its
//! session, and a whole-file write over another session's uncommitted change
//! is refused, telling the session to make it as an anchored edit, which
//! applies to the file with that change in it. A log, directory or git call
//! a guard cannot read refuses naming the cause.

use std::io::Write;
use std::path::{Path, PathBuf};

use serde_json::Value;

use tama_core::git::Git;

const TAG: &str = "block-off-task-work";
/// Where each session's written paths are kept, one absolute path per line.
pub(crate) const WRITES_RELATIVE: &str = ".tama/session-writes";
pub(crate) const LOG_SUFFIX: &str = ".log";

/// The repository a shell command would publish from: the working directory
/// of a `git commit`, which is where a session's work leaves its hands. A
/// push carries commits already made, each judged when it was made. A commit
/// whose working directory cannot be read is the error: passed unjudged, it
/// published from a repository the scope never saw.
pub(super) fn delivery_paths(command: &str, input: &Value) -> Result<Vec<String>, String> {
    if !crate::ports::pre_bash::guards::commit::runs_commit(command) {
        return Ok(Vec::new());
    }
    let directory =
        working_directory(input).map_err(|error| unread("the commit's repository", &error))?;
    Ok(vec![directory.to_string_lossy().to_string()])
}

/// The directory a payload runs in: its `cwd`, else the directory the
/// harness started this hook in, which is the session's.
pub(super) fn working_directory(input: &Value) -> Result<PathBuf, String> {
    if let Some(cwd) = input.get("cwd").and_then(Value::as_str) {
        return Ok(PathBuf::from(cwd));
    }
    std::env::current_dir().map_err(|error| {
        format!("the payload names no cwd and this hook's own directory cannot be read: {error}")
    })
}

pub(crate) fn writes_file(home: &Path, session: &str) -> PathBuf {
    home.join(WRITES_RELATIVE)
        .join(format!("{session}{LOG_SUFFIX}"))
}

/// Log the files this payload writes under the session that writes them.
pub(super) fn record_writes(home: &Path, session: &str, paths: &[String], input: &Value) {
    if session.is_empty() || paths.is_empty() {
        return;
    }
    let base = match working_directory(input) {
        Ok(base) => base,
        Err(error) => return eprintln!("{TAG}: writes not recorded: {error}"),
    };
    let file = writes_file(home, session);
    let parent = match file.parent() {
        Some(parent) => std::fs::create_dir_all(parent),
        None => Ok(()),
    };
    let recorded = parent.and_then(|()| {
        let mut log = std::fs::OpenOptions::new()
            .create(true)
            .append(true)
            .open(&file)?;
        paths
            .iter()
            .try_for_each(|path| writeln!(log, "{}", base.join(path).display()))
    });
    if let Err(error) = recorded {
        eprintln!("{TAG}: writes not recorded in {}: {error}", file.display());
    }
}

/// The refusal a guard gives when what it must read cannot be read.
fn unread(what: &str, error: &str) -> String {
    format!("BLOCKED: {TAG}: {what} cannot be told, so this call is refused unjudged: {error}")
}

/// Why writing the whole of `paths` would overwrite uncommitted changes
/// another session made, if it would: sessions share one checkout, and a
/// whole-file write over another session's unfinished file replaces its work.
/// Read before this payload is logged, so a file counts as this session's only
/// once it wrote it before.
pub(super) fn foreign_overwrite(
    home: &Path,
    session: &str,
    paths: &[String],
    input: &Value,
) -> Option<String> {
    if session.is_empty() || paths.is_empty() {
        return None;
    }
    let question = "whether this write replaces another session's unfinished work";
    let (base, own, others) = match working_directory(input)
        .and_then(|base| logs(home, session).map(|(own, others)| (base, own, others)))
    {
        Ok(read) => read,
        Err(error) => return Some(unread(question, &error)),
    };
    for path in paths {
        let path = base.join(path);
        let shown = path.display().to_string();
        // A logged directory (a structural rewrite's target) covers its files.
        let mine = own
            .iter()
            .any(|entry| shown == *entry || shown.starts_with(&format!("{entry}/")));
        let writer = others.iter().find(|(_, written)| written.contains(&shown));
        let Some((writer, _)) = writer.filter(|_| !mine) else {
            continue;
        };
        // A file that cannot be examined may hold that session's work.
        match tama_core::presence::present(&path) {
            Ok(there) if !there || !path.is_file() => continue,
            Ok(_) => {}
            Err(error) => return Some(unread(question, &error.to_string())),
        }
        let Some(directory) = path.parent() else {
            return Some(unread(
                question,
                &format!("{shown} has no parent directory"),
            ));
        };
        let asked = Git::of(Some(directory)).paths(&[path.as_path()]).text(&[
            "status",
            "--porcelain",
            "--",
        ]);
        let status = match asked {
            Ok(status) => status,
            Err(error) => return Some(unread(question, &error)),
        };
        if !status.trim().is_empty() {
            return Some(format!(
                "BLOCKED: {shown} holds uncommitted changes session {writer} made, and this session \
                 never wrote it; writing the whole file now replaces that session's unfinished \
                 work. Change it with an anchored edit instead: the edit applies to the file as it \
                 is, that session's change included, so both sessions work on it together."
            ));
        }
    }
    None
}

type Logs = (Vec<String>, Vec<(String, Vec<String>)>);

/// This session's written paths, and every other session's by session. A
/// log directory nobody created yet holds no session's writes.
fn logs(home: &Path, session: &str) -> Result<Logs, String> {
    let own = logged(&writes_file(home, session))?;
    let directory = home.join(WRITES_RELATIVE);
    let entries = match std::fs::read_dir(&directory) {
        Ok(entries) => entries,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok((own, Vec::new())),
        Err(error) => return Err(format!("cannot list {}: {error}", directory.display())),
    };
    let mut others = Vec::new();
    for entry in entries {
        let entry = entry
            .map_err(|error| format!("cannot read an entry of {}: {error}", directory.display()))?;
        let file_name = entry.file_name();
        let name = file_name.to_string_lossy();
        let Some(writer) = name.strip_suffix(LOG_SUFFIX) else {
            continue;
        };
        if writer != session {
            others.push((writer.to_string(), logged(&entry.path())?));
        }
    }
    Ok((own, others))
}

/// The paths one log holds; a log never written holds none.
pub(crate) fn logged(file: &Path) -> Result<Vec<String>, String> {
    match std::fs::read_to_string(file) {
        Ok(text) => Ok(text.lines().map(str::to_string).collect()),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(Vec::new()),
        Err(error) => Err(format!("cannot read {}: {error}", file.display())),
    }
}
