//! The operator's standing rulings on an action class (edit, build, compile,
//! test, install, release), as Oko's one admission decision answers them:
//! `oko admit <action> [--product P] --json` for one call and `oko rulings
//! constraints --json` for every standing constraint. Tama keeps no copy of
//! the rule. A file change is decided by `block-off-task-work` over Oko's
//! ruling register read as a file (`tama_hooks::oko_rulings::edit`), so no
//! write waits on an Oko process.
//!
//! A ruling on `<action>` or `<action>:<product>` is the operator's consent;
//! one on `no-<action>` or `no-<action>:<product>` withdraws it until a later
//! ruling consents again; `<action>[:<product>]@<defect>` consents only for
//! work whose purpose is that open defect. Oko reads which of them decides
//! for the purposes a run serves (`--session`: the open defects the session
//! owns); a gate reads the answer. Where no ruling decides a session's build,
//! compile or test, Oko holds it until every open item carries its pushed
//! repair, and answers which items it waits on ([`Ruled::Waiting`]). A run
//! that names no purpose, such as a push's format gate, is outside every
//! scoped consent and every open-work hold. A consent given in one session
//! holds in every later one without a dialog asking it again,
//! and a withdrawal refuses even a session capability, quoting the ruling.
//! Consent the operator gives per conversation (SSH, a local browser, hook
//! edits) is never read here; it stays a session capability
//! ([`granted`](super::granted)).

use std::process::Command;

use serde::Deserialize;

use crate::assignment::rules::{oko_cli, oko_installed};

/// The ruling Oko quotes for a verdict.
#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Deciding {
    pub id: String,
    pub subject: String,
    pub session: String,
    pub ordinal: i64,
    pub said: String,
}

/// Oko's answer to whether an action may run now, as `oko admit --json`
/// prints it.
#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Verdict {
    pub action: String,
    pub product: Option<String>,
    /// The session a ruling held to one session decides; none for a
    /// constraint on every session (and from an Oko that keeps none).
    #[serde(default)]
    pub session: Option<String>,
    pub allowed: bool,
    pub ruling: Option<Deciding>,
    pub reason: String,
}

/// What the operator's rulings say about one action, for a gate.
pub enum Ruled {
    /// A standing ruling consents; the reason quotes it.
    Consented(String),
    /// A standing ruling forbids it now; the reason quotes it.
    Forbidden(String),
    /// No ruling decides a session's build, and Oko's open-work rule holds it
    /// until every open item carries its pushed repair; the reason names what
    /// it waits on. A consent given in the conversation still admits it.
    Waiting(String),
    /// Oko is installed and could not answer; the cause says why. A gate that
    /// would run on Oko's admission refuses on it: unread is not admitted.
    Unread(String),
    /// The installed Oko refused `oko admit` as a usage error: it predates
    /// the admission decision, so it holds no answer to read. The cause names
    /// that version skew. Only the operator's consent in the conversation
    /// admits a build then, so the install that brings the newer Oko can run.
    Undecidable(String),
    /// No ruling decides it and nothing holds it, or no Oko is installed, so
    /// the gate reads its other consents.
    Unruled,
}

/// The status Oko exits with when it refuses a command line as a usage
/// error (`USAGE_STATUS` in Oko's `main.rs`), the status command-line
/// convention gives a usage error:
/// https://docs.rs/clap/latest/clap/error/struct.Error.html#method.exit
pub const OKO_USAGE_STATUS: i32 = 2;

/// Why Oko gave no answer: it refused the command line as a usage error,
/// printing nothing, or it could not answer at all.
enum Unanswered {
    Usage(String),
    Unread(String),
}

impl Unanswered {
    fn cause(self) -> String {
        match self {
            Unanswered::Usage(cause) | Unanswered::Unread(cause) => cause,
        }
    }
}

/// `oko <args>` printed as JSON of type `T`. Oko exits non-zero on a
/// forbidden verdict and still prints it, so the printed answer is read
/// whatever the exit; with nothing readable printed, Oko's own error is the
/// cause.
fn oko<T: serde::de::DeserializeOwned>(args: &[&str]) -> Result<T, Unanswered> {
    if !oko_installed() {
        return Err(Unanswered::Unread(format!(
            "{} is not installed, so no ruling can be read",
            oko_cli()
        )));
    }
    let shown = format!("{} {}", oko_cli(), args.join(" "));
    let mut command = Command::new(oko_cli());
    command.args(args);
    let output = stado_wait::output(&mut command)
        .map_err(|error| Unanswered::Unread(format!("{shown} did not run: {error}")))?;
    serde_json::from_slice(&output.stdout).map_err(|error| {
        let cause = format!(
            "{shown} exited {} without an answer ({error}): {}",
            output.status,
            String::from_utf8_lossy(&output.stderr).trim()
        );
        let usage = output.status.code() == Some(OKO_USAGE_STATUS) && output.stdout.is_empty();
        if usage {
            Unanswered::Usage(cause)
        } else {
            Unanswered::Unread(cause)
        }
    })
}

/// Whether the operator's rulings consent to, forbid or leave undecided
/// `action` for `product` (every product when none is named), for the open
/// defects `session` owns when one is named.
pub fn ruled(action: &str, product: Option<&str>, session: Option<&str>) -> Ruled {
    if !oko_installed() {
        return Ruled::Unruled;
    }
    let mut args = vec!["admit", action, "--json"];
    if let Some(product) = product {
        args.extend(["--product", product]);
    }
    if let Some(session) = session.filter(|session| !session.is_empty()) {
        args.extend(["--session", session]);
    }
    match oko::<Verdict>(&args) {
        Ok(verdict) if !verdict.allowed && verdict.ruling.is_none() => {
            Ruled::Waiting(verdict.reason)
        }
        Ok(verdict) if !verdict.allowed => Ruled::Forbidden(verdict.reason),
        Ok(verdict) if verdict.ruling.is_some() => Ruled::Consented(verdict.reason),
        Ok(_) => Ruled::Unruled,
        Err(Unanswered::Usage(cause)) => Ruled::Undecidable(format!(
            "the installed {} holds no admission decision: it refused `oko admit` as a usage error, so it predates that verb; install the Oko that carries it ({cause})",
            oko_cli()
        )),
        Err(Unanswered::Unread(cause)) => Ruled::Unread(cause),
    }
}

/// Why a gate that runs build tools on the repository checked out at `root`
/// runs none now: the product is named by the checkout's directory, and a
/// push serves no named purpose, so only an unscoped consent, or no ruling
/// with Oko admitting, lets it run. A forbidding ruling, Oko's open-work
/// rule holding the build, and an admission that could not be read are each
/// a reason, quoted; unread is not admitted. None when Oko admits the build
/// or no Oko is installed to rule on it.
pub fn build_unadmitted_in(root: &std::path::Path) -> Option<String> {
    let product = root
        .file_name()
        .map(|name| name.to_string_lossy().to_lowercase());
    match ruled(BUILD, product.as_deref(), None) {
        Ruled::Forbidden(reason) => Some(reason),
        Ruled::Waiting(reason) => Some(format!(
            "Oko does not admit a build of {} yet: {reason}",
            root.display()
        )),
        Ruled::Unread(cause) | Ruled::Undecidable(cause) => Some(format!(
            "whether a build of {} is admitted could not be read, so none runs: {cause}",
            root.display()
        )),
        Ruled::Consented(_) | Ruled::Unruled => None,
    }
}

/// The action class a ruling constrains that running a build tool is:
/// compiling, formatting, linting or checking a tree.
pub const BUILD: &str = "build";

/// The action class a ruling constrains that installing a sealed hook
/// release on a machine is (`tama hooks release`).
pub const RELEASE: &str = "release";

/// Every standing consent to `action`: the constraints Oko reads whose
/// deciding ruling allows it now. `Err` names why Oko could not answer.
pub fn consents(action: &str) -> Result<Vec<Verdict>, String> {
    let all: Vec<Verdict> =
        oko(&["rulings", "constraints", "--json"]).map_err(Unanswered::cause)?;
    Ok(all
        .into_iter()
        .filter(|verdict| verdict.action == action && verdict.allowed && verdict.ruling.is_some())
        .collect())
}
