//! The hook catalogue: building it from the registry and validating it.
//!
//! Notable fidelity choices:
//! - JS `JSON.parse` preserves object key insertion order. The typed
//!   [`Registry`] uses `BTreeMap`, so insertion order for observable event and
//!   adapter arrays is recovered from the raw JSON text.
//! - JS `.sort()` on the ASCII strings used here is byte-lexicographic, as is
//!   Rust's `str::cmp`. Non-ASCII locale ordering is outside this catalogue.
//!
//! One file grew past the limit, so the subject is four modules now: building
//! the catalogue a reader sees ([`build`]), the validation verdict
//! ([`validate`]), the filesystem primitives both need ([`fs_scan`]), and the
//! raw key-order scanner ([`key_order`]). What is left here is where the
//! archive is and how its documents are loaded. Every name this module
//! published before is re-exported, so `crate::catalog::…` paths are
//! unchanged.

pub mod build;
pub mod fs_scan;
pub mod key_order;
pub mod validate;

pub use build::{build_catalog, find_hook, Catalog, CatalogHook, CatalogHookEvent};
pub use validate::{validate_catalog, ValidationResult};

use serde::Serialize;
use std::fs;
use std::path::{Component, Path, PathBuf};

use crate::registry::{CatalogMetadata, Registry};
use crate::Result;

use fs_scan::{join_path, root_str, strip_root, walk};

/// Normalize `.`/`..` components without touching the filesystem
/// (like Node's `path.resolve`, which does not resolve symlinks).
pub(crate) fn normalize_path(path: &Path) -> PathBuf {
    let mut out = PathBuf::new();
    for component in path.components() {
        match component {
            Component::CurDir => {}
            Component::ParentDir => {
                out.pop();
            }
            other => out.push(other.as_os_str()),
        }
    }
    out
}

/// JS `readJson(path)` = `JSON.parse(readFileSync(path, 'utf8'))`.
pub fn read_json(path: &Path) -> Result<serde_json::Value> {
    Ok(serde_json::from_str(&fs::read_to_string(path)?)?)
}

/// JS `commandSourcePath(command)`: map a hook command or recorded source
/// back to its archived repo-relative path, or `None`. The last prefix is
/// wider than the JS list: a ported hook declares a Rust source under
/// `rust/crates/`, which none of the three hook directories covers, and an
/// unmapped source is a hook whose file nothing checks for existence.
///
/// The registry became portable, so `tama-reconcile-registry-sources` records
/// a repaired source repo-relative. The JS only ever matched absolute
/// prefixes, so those entries mapped to nothing: sixty-three hooks reported
/// "source path could not be mapped from command" while naming a file that
/// was right there, and nothing checked those files existed. A relative
/// spelling that resolves under the archive is accepted below.
///
/// The checkout prefixes are those of the Tama checkout on this machine
/// ([`crate::found_checkout`]), never the `--root` argument, as JS built
/// `SOURCE_PREFIXES` from the module-level `ROOT`; with no checkout there is
/// no checkout path to map, and one that cannot be examined is the error.
pub fn command_source_path(
    command: Option<&str>,
    root: &Path,
) -> std::result::Result<Option<String>, String> {
    let Some(command) = command.filter(|command| !command.is_empty()) else {
        return Ok(None); // JS: `if (!command || typeof command !== 'string') return null`
    };
    // An unset HOME made these `/.shared-hooks/` and friends, so no installed
    // hook command was ever traced to its source.
    let home = crate::home_dir().to_string_lossy().into_owned();
    let mut prefixes = vec![
        (format!("{home}/.shared-hooks/"), "shared-hooks/"),
        (format!("{home}/.codex/hooks/"), "codex-hooks/"),
        (format!("{home}/.claude/hooks/"), "claude-hooks/"),
    ];
    if let Some(checkout) = crate::found_checkout()? {
        let root_s = root_str(&checkout);
        for (directory, repo_dir) in [
            ("shared-hooks", "shared-hooks/"),
            ("codex-hooks", "codex-hooks/"),
            ("claude-hooks", "claude-hooks/"),
        ] {
            prefixes.push((format!("{}/", join_path(&root_s, directory)), repo_dir));
        }
        prefixes.push((format!("{root_s}/"), ""));
    }
    for (prefix, repo_dir) in &prefixes {
        if let Some(idx) = command.find(prefix.as_str()) {
            // Node `join('shared-hooks/', '')` normalizes to 'shared-hooks'.
            return Ok(Some(
                match command[idx + prefix.len()..].split_whitespace().next() {
                    Some(rest) => format!("{repo_dir}{rest}"),
                    None => repo_dir.trim_end_matches('/').to_string(),
                },
            ));
        }
    }
    let Some(relative) = command.split_whitespace().next() else {
        return Ok(None);
    };
    if !relative.starts_with('/') && root.join(relative).is_file() {
        return Ok(Some(relative.to_string()));
    }
    Ok(None)
}

/// JS catalog `loadRegistry(root)`: parsed `shared-hooks/registry.json`,
/// or `{ events: {} }` when the file does not exist.
pub fn load_registry(root: &Path) -> Result<Registry> {
    let (registry, _) = load_registry_raw(root)?;
    Ok(registry)
}

/// Registry plus the raw file text (needed to recover JSON key order).
pub(crate) fn load_registry_raw(root: &Path) -> Result<(Registry, Option<String>)> {
    let path = root.join("shared-hooks").join("registry.json");
    if !crate::presence::present(&path)? {
        return Ok((Registry::default(), None));
    }
    let raw = fs::read_to_string(path)?;
    Ok((serde_json::from_str(&raw)?, Some(raw)))
}

/// JS `loadCatalogMetadata(root)`: `shared-hooks/catalog-metadata.json` as a
/// map of hook id -> docs, empty when the file does not exist.
pub fn load_catalog_metadata(root: &Path) -> Result<CatalogMetadata> {
    let path = root.join("shared-hooks").join("catalog-metadata.json");
    if !crate::presence::present(&path)? {
        return Ok(CatalogMetadata::new());
    }
    Ok(serde_json::from_str(&fs::read_to_string(path)?)?)
}

/// JS `listSourceFiles(root)`: repo-relative paths of every file under
/// `claude-hooks`, `codex-hooks`, `shared-hooks`, `repo-githooks`
/// (skipping `.git`, `__pycache__`, `state`, `recall_dumps`), sorted.
pub fn list_source_files(root: &Path) -> Result<Vec<String>> {
    let root_s = root_str(root);
    let mut files = Vec::new();
    for dir in [
        "claude-hooks",
        "codex-hooks",
        "shared-hooks",
        "repo-githooks",
    ] {
        walk(&join_path(&root_s, dir), &mut files)?;
    }
    let mut rel: Vec<String> = files
        .iter()
        .map(|p| strip_root(&root_s, p).map(str::to_string))
        .collect::<Result<_>>()?;
    rel.sort();
    Ok(rel)
}

/// One entry of JS `listRepoGitHooks(root)`.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct RepoGitHook {
    pub project: String,
    pub event: String,
    pub source_path: String,
}

/// JS `listRepoGitHooks(root)`, sorted by `project:event`: every file at
/// `repo-githooks/<project>/<event>`. A file under `repo-githooks/` that does
/// not name both is the error, naming the file.
pub fn list_repo_git_hooks(root: &Path) -> Result<Vec<RepoGitHook>> {
    let mut hooks: Vec<RepoGitHook> = Vec::new();
    for path in list_source_files(root)? {
        let Some(inside) = path.strip_prefix("repo-githooks/") else {
            continue;
        };
        let mut parts = inside.split('/');
        let (Some(project), Some(event)) = (parts.next(), parts.next()) else {
            return Err(crate::err(format!(
                "{path} is not repo-githooks/<project>/<event>, so no project and git event can be read from it"
            )));
        };
        hooks.push(RepoGitHook {
            project: project.to_string(),
            event: event.to_string(),
            source_path: path,
        });
    }
    hooks.sort_by(|a, b| {
        format!("{}:{}", a.project, a.event).cmp(&format!("{}:{}", b.project, b.event))
    });
    Ok(hooks)
}
