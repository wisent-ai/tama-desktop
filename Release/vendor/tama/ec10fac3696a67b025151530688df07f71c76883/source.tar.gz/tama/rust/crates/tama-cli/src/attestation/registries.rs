//! Every attestation Tama holds, read as one record whatever registry keeps
//! it, and verified without a model (`verify`).
//!
//! Five registries grew five formats: a session's task attestation
//! (`attestations/session/<id>.json`), the file, CUA and SSH justifications
//! (`~/.shared-hooks/*_justifications.json`), the operator's test approvals
//! (`~/.config/agent-policy/approved_tests.json`) and his build consents
//! (Oko rulings and asks, with the spent ask ids beside the justifications).
//! Each had its own verbs, its own expiry reading and its own notion of who
//! attested what. This module reads them all into one [`Record`]:
//!
//! - `kind` ([`Kind`]): which registry and so which shape of claim;
//! - `subject`: what is attested — a session id, a path, a bundle, a target,
//!   an ask; an entry that names none is refused by its registry;
//! - `statement`: the words of the attestation, verbatim;
//! - `attester`: the agent for a record it wrote about its own work, or the
//!   operator for a consent, which is never the agent's to write: a CUA or
//!   SSH grant cites the operator's own sentence from the session transcript
//!   and a test approval is written from his terminal only;
//! - `scope`: what the attestation admits (actions, operations, session);
//! - `lifetime`: for how long it holds, as the registry states it;
//! - `verification`: how it is checked — the cited sentence must stand in
//!   the session's transcript, the subject must exist (and a session record
//!   stand against today's standard), or the Oko ask it cites;
//! - `store`: the registry file the record was read from.
//!
//! Every one of them is now written through the one attestation primitive
//! (`tama_hook_tools::attestation`): each verb (`tama justify`, `tama tests
//! approve|revoke`, `tama attestation record|remove|revoke`) keeps its
//! record in the one ledger beside the registry its gate reads, and `list`
//! reads the ledger. The registries are views; `migrate` brings what a view
//! held before the ledger existed into it, and `verify` names a view that
//! holds what the ledger does not, or the other way round. Build consents
//! are read from Oko, where the operator gives them.

mod consents;
pub(crate) mod migrate;
pub(crate) mod record;
pub(crate) mod revoke;
pub(crate) mod verify;

use std::path::{Path, PathBuf};

use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use tama_hook_tools::ports::block_unapproved_tests::approvals;
use tama_hook_tools::ports::task_attestation::subject;

use crate::justify::registry;

/// The registry a record comes from, and so the shape of its claim.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub(crate) enum Kind {
    Session,
    File,
    Cua,
    Ssh,
    Test,
    Build,
}

/// Every kind, in the order `list` reads them.
const KINDS: &[Kind] = &[
    Kind::Session,
    Kind::File,
    Kind::Cua,
    Kind::Ssh,
    Kind::Test,
    Kind::Build,
];

impl Kind {
    /// The kind `--kind` names, or a refusal naming every kind.
    pub(crate) fn parse(word: &str) -> Result<Self, String> {
        serde_json::from_value(Value::String(word.to_string())).map_err(|_| {
            format!(
                "{word} is not a kind of attestation; the kinds are {}",
                Self::names().join(", ")
            )
        })
    }

    pub(crate) fn name(self) -> String {
        match serde_json::to_value(self) {
            Ok(Value::String(name)) => name,
            other => unreachable!("a unit variant serializes to its name, not {other:?}"),
        }
    }

    /// Every kind's name, in the order `list` reads them: what a surface
    /// offers to narrow or record by, whether or not a record of it exists.
    pub(crate) fn names() -> Vec<String> {
        KINDS.iter().map(|kind| kind.name()).collect()
    }
}

/// Who attested.
#[derive(Clone, Copy, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub(crate) enum Attester {
    Agent,
    Operator,
}

/// How a record is verified.
#[derive(Clone, Copy, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub(crate) enum Verification {
    Transcript,
    Artifact,
    Ruling,
}

/// One record. `statement`, `lifetime` and `scope` are the registry's own
/// values, so a registry that states none shows null.
#[derive(Serialize)]
pub(crate) struct Record {
    pub(crate) kind: Kind,
    pub(crate) subject: String,
    pub(crate) statement: Value,
    pub(crate) attester: Attester,
    pub(crate) scope: Value,
    pub(crate) lifetime: Value,
    pub(crate) verification: Verification,
    pub(crate) store: String,
}

impl Record {
    pub(crate) fn value(&self) -> Result<Value, String> {
        serde_json::to_value(self)
            .map_err(|error| format!("an attestation record cannot be written out: {error}"))
    }
}

/// The operator's home, where the justification and approval registries are.
fn home() -> Result<PathBuf, String> {
    std::env::var_os("HOME")
        .map(PathBuf::from)
        .ok_or_else(|| "HOME is not set, so no registry location is known".to_string())
}

/// The text of `field` in a registry entry, or the refusal naming the
/// registry and the field.
fn text_of(entry: &Value, field: &str, store: &Path) -> Result<String, String> {
    match &entry[field] {
        Value::String(text) if !text.is_empty() => Ok(text.clone()),
        Value::Null => Err(format!(
            "an entry of {} carries no {field}",
            store.display()
        )),
        other => Ok(other.to_string()),
    }
}

/// Every session attestation, as `tama attestation list` kept them.
fn sessions() -> Result<Vec<Record>, String> {
    subject::list()?
        .into_iter()
        .map(|kept| {
            let store = PathBuf::from(text_of(
                &kept,
                "recorded",
                Path::new("the session attestation records"),
            )?);
            Ok(Record {
                kind: Kind::Session,
                subject: text_of(&kept, "id", &store)?,
                statement: kept["attestation"].clone(),
                attester: Attester::Agent,
                scope: json!({ "task": "finished" }),
                lifetime: Value::Null,
                verification: Verification::Artifact,
                store: store.display().to_string(),
            })
        })
        .collect()
}

/// Every file justification: the agent's own statement about one path.
fn files(home: &Path) -> Result<Vec<Record>, String> {
    let store = registry::registry_path(home, registry::Kind::File);
    Ok(registry::load(&store)?
        .into_iter()
        .map(|(path, entry)| Record {
            kind: Kind::File,
            subject: path,
            statement: entry["justification"].clone(),
            attester: Attester::Agent,
            scope: json!({}),
            lifetime: entry["expires_at"].clone(),
            verification: Verification::Artifact,
            store: store.display().to_string(),
        })
        .collect())
}

/// Every test approval: the operator's own act from his terminal. A record
/// that cannot be read is the error: read as approving nothing, the list
/// showed none of what he approved.
fn tests() -> Result<Vec<Record>, String> {
    let store = approvals::store();
    Ok(approvals::recorded()?
        .approved
        .into_iter()
        .map(|approval| Record {
            kind: Kind::Test,
            subject: approval.path,
            statement: json!("approved test code"),
            attester: Attester::Operator,
            scope: json!({ "everything_below": true }),
            lifetime: json!(approval.approved_at),
            verification: Verification::Artifact,
            store: store.display().to_string(),
        })
        .collect())
}

/// Every attestation every view holds, of every kind or of `kind` alone:
/// what `migrate` brings into the ledger and `verify` compares with it.
pub(crate) fn views(kind: Option<Kind>) -> Result<Vec<Record>, String> {
    let home = home()?;
    let mut all = Vec::new();
    for each in KINDS
        .iter()
        .copied()
        .filter(|each| kind.is_none_or(|kind| kind == *each))
    {
        all.extend(match each {
            Kind::Session => sessions()?,
            Kind::File => files(&home)?,
            Kind::Cua | Kind::Ssh => consents::grants(&home, each)?,
            Kind::Test => tests()?,
            Kind::Build => consents::builds()?,
        });
    }
    Ok(all)
}

/// One ledger attestation as a record, its kind and attester read by name.
fn from_ledger(kept: tama_hook_tools::attestation::Attestation) -> Result<Record, String> {
    let named = |what: &str, word: &str| {
        format!("the attestation ledger holds a {what} {word} Tama does not know")
    };
    Ok(Record {
        kind: Kind::parse(&kept.kind)?,
        attester: serde_json::from_value(json!(kept.attester))
            .map_err(|_| named("attester", &kept.attester))?,
        verification: serde_json::from_value(json!(kept.verification))
            .map_err(|_| named("verification", &kept.verification))?,
        subject: kept.subject,
        statement: kept.statement,
        scope: kept.scope,
        lifetime: kept.lifetime,
        store: kept.store,
    })
}

/// Every attestation of every kind, or of `kind` alone: the ledger's, and
/// the build consents Oko holds. A ledger never written is refused naming
/// the migration that writes it.
pub(crate) fn list(kind: Option<Kind>) -> Result<Vec<Record>, String> {
    use tama_hook_tools::attestation as ledger;
    if !ledger::exists()? {
        return Err(format!(
            "the attestation ledger {} has not been written; `tama attestation migrate` brings every registry into it",
            ledger::path().display()
        ));
    }
    let mut all: Vec<Record> = ledger::read(None)?
        .into_iter()
        .map(from_ledger)
        .collect::<Result<Vec<_>, String>>()?
        .into_iter()
        .filter(|record| kind.is_none_or(|kind| kind == record.kind))
        .collect();
    if kind.is_none_or(|kind| kind == Kind::Build) {
        all.extend(consents::builds()?);
    }
    Ok(all)
}

/// Every record as JSON, for the CLI and Tama Desktop.
pub(crate) fn listed(kind: Option<Kind>) -> Result<Vec<Value>, String> {
    list(kind)?.iter().map(Record::value).collect()
}
