//! The attestations carried in text: a commit's, in its own message or, for
//! a commit that already exists, in the note kept beside it, read by
//! `review-push`; a turn end's, in the answer the turn ends with, read by the
//! stop hooks. `standard --commit` and `standard --turn` print what is to be
//! carried, `check` names what a commit or an answer still lacks — the same
//! claims the gate would name — and `attest` keeps an existing commit's
//! attestation in `refs/notes/attestation` without changing the commit.
//! Tama Desktop's `attestation/required`, `attestation/check` and
//! `attestation/attest-commit` answer with these functions.

pub(crate) mod pending;
pub(crate) mod unjudged;

use std::path::Path;

use serde_json::{json, Value};
use tama_hook_tools::ports::task_attestation::{note, verbatim};

/// A text field as written; any other value as its JSON.
fn text(value: &Value) -> String {
    match value.as_str() {
        Some(text) => text.to_string(),
        None => value.to_string(),
    }
}

/// The commit or turn-end standard: `{kind: "commit", claims, trailers:
/// {required, mustBeEmpty}}` (each `{trailer, why}`) or `{kind: "turn",
/// hooks: {hook: [claims]}}`.
pub(crate) fn standard(commit: bool) -> Value {
    let named = |trailers: Vec<(String, String)>| {
        trailers
            .into_iter()
            .map(|(trailer, why)| json!({ "trailer": trailer, "why": why }))
            .collect::<Vec<_>>()
    };
    if commit {
        let (required, empty) = verbatim::commit_trailers();
        json!({
            "kind": "commit", "claims": verbatim::commit_claims(),
            "trailers": { "required": named(required), "mustBeEmpty": named(empty) },
        })
    } else {
        json!({ "kind": "turn", "hooks": verbatim::turn_standard() })
    }
}

/// The standard for a terminal. The commit standard is printed as the block
/// a commit message carries, nothing else on its lines, so it is pasted as
/// it is; the trailers its harsh review is written in are named on stderr,
/// since their values are the agent's own. The turn standard prints each
/// claim after its hook.
pub(crate) fn print_standard(report: &Value) {
    for claim in report["claims"].as_array().into_iter().flatten() {
        println!("{}", text(claim));
    }
    let trailers = &report["trailers"];
    for entry in trailers["required"].as_array().into_iter().flatten() {
        eprintln!(
            "attestation: carry at least one trailer {}: <attack> in the message's last paragraph: {}",
            text(&entry["trailer"]),
            text(&entry["why"])
        );
    }
    for entry in trailers["mustBeEmpty"].as_array().into_iter().flatten() {
        eprintln!(
            "attestation: carry no trailer {}: {}",
            text(&entry["trailer"]),
            text(&entry["why"])
        );
    }
    for (hook, claims) in report["hooks"].as_object().into_iter().flatten() {
        for claim in claims.as_array().into_iter().flatten() {
            println!("{hook}: {}", text(claim));
        }
    }
}

/// What a commit, or an answer a turn ends with, still lacks:
/// `{kind, id, stands, missing, findings, carriedIn}`. A commit stands when
/// its message or its attestation note carries every claim and the harsh
/// review's trailers with no finding; `carriedIn` names which.
pub(crate) fn checked(
    commit: Option<&str>,
    repository: Option<&Path>,
    turn: Option<(&str, &str)>,
) -> Result<Value, String> {
    let (kind, id, unmet, carried_in) = match (commit, turn) {
        (Some(revision), None) => {
            let (full, message) = verbatim::commit_message(repository, revision)?;
            let carried = note::carried(repository, &full, &message)?;
            ("commit", full, carried.unmet, carried.carried_in)
        }
        (None, Some((hook, answer))) => {
            let unmet = verbatim::Unmet {
                missing: verbatim::turn_missing(verbatim::turn_claims(hook)?, answer)
                    .into_iter()
                    .map(str::to_string)
                    .collect(),
                findings: Vec::new(),
            };
            let carried_in = unmet.stands().then_some("answer");
            ("turn", hook.to_string(), unmet, carried_in)
        }
        _ => return Err("name a commit, or a turn's hook and the answer it ends with".to_string()),
    };
    Ok(json!({
        "kind": kind, "id": id, "stands": unmet.stands(),
        "missing": unmet.missing, "findings": unmet.findings, "carriedIn": carried_in,
    }))
}

/// Keep `text` as the attestation of the existing commit `revision`, beside
/// it in `refs/notes/attestation`, only when it carries every claim of the
/// commit standard and the harsh review's trailers with no finding: `{kind,
/// id, stands, missing, findings, keptIn, replaced}`. The commit is not
/// changed; a note already kept for it is replaced by a text that stands,
/// and `replaced` is the note it replaced (null when none was kept).
pub(crate) fn attest(
    repository: Option<&Path>,
    revision: &str,
    text: &str,
) -> Result<Value, String> {
    let (full, _) = verbatim::commit_message(repository, revision)?;
    // A note kept now answers to the standard in force now.
    let unmet = verbatim::commit_unmet(text, None)?;
    let stands = unmet.stands();
    let replaced = if stands {
        note::keep(repository, &full, text)?
    } else {
        None
    };
    Ok(json!({
        "kind": "commit", "id": full, "stands": stands, "missing": unmet.missing,
        "findings": unmet.findings, "keptIn": stands.then_some(note::REF), "replaced": replaced,
    }))
}

/// `attest --commit REV --file PATH [--repository PATH]`: [`attest`] with the
/// file's text.
pub(super) fn attest_file(parsed: &super::Arguments) -> Result<Value, String> {
    let (Some(commit), Some(file)) = (&parsed.commit, &parsed.file) else {
        return Err("attest keeps one commit's attestation: --commit REV --file PATH".to_string());
    };
    let text = super::read_text(file)?;
    attest(parsed.repository.as_deref().map(Path::new), commit, &text)
}

pub(crate) fn print_checked(report: &Value) {
    let named = format!("{} {}", text(&report["kind"]), text(&report["id"]));
    match (report["stands"].as_bool(), report["keptIn"].as_str()) {
        (Some(true), Some(kept)) => {
            if report["replaced"].is_string() {
                println!(
                    "attestation: {named} is attested in {kept}, replacing the note kept before"
                )
            } else {
                println!("attestation: {named} is attested in {kept}")
            }
        }
        (Some(true), None) => println!(
            "attestation: {named} carries every claim in its {}",
            text(&report["carriedIn"])
        ),
        _ => println!("attestation: {named} does not carry its attestation"),
    }
    for claim in report["missing"].as_array().into_iter().flatten() {
        println!("    missing: \"{}\"", text(claim));
    }
    for finding in report["findings"].as_array().into_iter().flatten() {
        println!("    finding: \"{}\"", text(finding));
    }
}
