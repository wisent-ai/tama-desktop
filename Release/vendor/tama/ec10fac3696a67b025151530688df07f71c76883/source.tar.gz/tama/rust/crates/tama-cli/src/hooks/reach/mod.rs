//! `tama hooks reach [--catalogue PATH] [--json]`: whether the installed
//! gates leave every session a next step.
//!
//! Each gate is right on its own, and gates together can still refuse every
//! step a session has: the stop, the answer, every kind of call and the
//! claim of an item. A session caught so loops between them instead of being
//! told which step is left. So each gate declares, in its declaration under
//! `hook-declarations/` in this checkout, the steps it closes and for which
//! session (`closes`: a step to the roles it closes it for, each `open` —
//! while the session holds open work — or `any`), and this computes, for
//! every role Oko records and either state of its work, the steps no gate
//! the installed catalogue holds active closes. A state with none is named
//! with the gates that close each step.
//!
//! An active gate with no declaration, or whose declaration says nothing it
//! closes, makes the answer unknown: its steps are not guessed, and the gate
//! is named so its declaration is written. The report fails while any state
//! leaves no step or any active gate is undeclared.

use std::collections::BTreeMap;
use std::path::{Path, PathBuf};

use serde::{Deserialize, Serialize};
use serde_json::json;
use tama_hook_tools::ports::transport_common::HOOK_HOME;

use super::declare::{option, refuse};

mod registry;
mod report;

pub const USAGE: &str = "usage: tama hooks reach [--catalogue <catalog-metadata.json>] [--json]";

const CATALOGUE: &str = "catalog-metadata.json";
/// The registry the catalogue's gates are bound in, beside the catalogue.
const REGISTRY: &str = "registry.json";
/// The catalogue's status of a gate that runs.
const ACTIVE: &str = "active";

/// Who a session is, as Oko's role register records it.
#[derive(Clone, Copy, Debug, Deserialize, Serialize, PartialEq, Eq, PartialOrd, Ord)]
#[serde(rename_all = "lowercase")]
pub enum Role {
    Supervisor,
    Executor,
    Unrecorded,
}

/// When a gate closes a step for a role.
#[derive(Clone, Copy, Debug, Deserialize, Serialize, PartialEq, Eq)]
#[serde(rename_all = "lowercase")]
pub enum When {
    /// While the session holds open work, held or not.
    Open,
    /// While every open item of the session waits on someone else.
    Held,
    /// While the session holds no open work.
    Idle,
    /// Whatever the session holds.
    Any,
}

/// What a session holds: open work it can act on, open work every item of
/// which waits on another session or the operator (as Oko's blockers and
/// asks record it), or none.
#[derive(Clone, Copy, Debug, Serialize, PartialEq, Eq)]
#[serde(rename_all = "lowercase")]
pub enum Work {
    Open,
    Held,
    Idle,
}

const WORK: &[Work] = &[Work::Open, Work::Held, Work::Idle];

impl When {
    /// Whether a gate closing a step `self` closes it for `work`.
    fn closes(self, work: Work) -> bool {
        match self {
            When::Any => true,
            When::Open => work != Work::Idle,
            When::Held => work == Work::Held,
            When::Idle => work == Work::Idle,
        }
    }
}

/// A step a session can take next.
#[derive(Clone, Copy, Debug, Deserialize, Serialize, PartialEq, Eq, PartialOrd, Ord)]
#[serde(rename_all = "lowercase")]
pub enum Step {
    /// End the turn.
    Stop,
    /// Say something to the operator.
    Answer,
    /// A call that only reads.
    Read,
    /// A call that changes a file.
    Change,
    /// A shell command.
    Shell,
    /// Claim an item in Oko.
    Claim,
}

const ROLES: &[Role] = &[Role::Supervisor, Role::Executor, Role::Unrecorded];
const STEPS: &[Step] = &[
    Step::Stop,
    Step::Answer,
    Step::Read,
    Step::Change,
    Step::Shell,
    Step::Claim,
];

/// What one gate declares it closes: a step to the roles it closes it for.
type Closes = BTreeMap<Step, BTreeMap<Role, When>>;

/// The part of a catalogue entry this reads.
#[derive(Deserialize)]
struct Entry {
    status: Option<String>,
}

/// The part of a declaration this reads.
#[derive(Deserialize)]
struct Declared {
    id: String,
    closes: Option<Closes>,
}

/// One role in one state of its work, and what is left to it.
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct State {
    role: Role,
    work: Work,
    admitted: Vec<Step>,
    closed_by: BTreeMap<Step, Vec<String>>,
}

/// What each committed declaration under `root` says its gate closes, by
/// the gate's id; a declaration that says nothing maps to none.
fn declared(root: &Path) -> Result<BTreeMap<String, Option<Closes>>, String> {
    let mut closes = BTreeMap::new();
    for file in super::declared::files(root, Path::new(super::declared::DECLARATIONS))? {
        let full = root.join(&file);
        let text = std::fs::read_to_string(&full)
            .map_err(|error| format!("cannot read the declaration {}: {error}", full.display()))?;
        let read: Declared = serde_json::from_str(&text)
            .map_err(|error| format!("{} is not a hook declaration: {error}", full.display()))?;
        closes.insert(read.id, read.closes);
    }
    Ok(closes)
}

/// The gates that run: active in the catalogue and bound to an event in the
/// registry beside it, each with what its declaration says it closes, or
/// none when it has no declaration or its declaration says nothing.
fn active(
    catalogue: &Path,
    mut declared: BTreeMap<String, Option<Closes>>,
) -> Result<Vec<(String, Option<Closes>)>, String> {
    let bound = registry::bound(&catalogue.with_file_name(REGISTRY))?;
    let text = std::fs::read_to_string(catalogue)
        .map_err(|error| format!("cannot read the catalogue {}: {error}", catalogue.display()))?;
    let entries: BTreeMap<String, serde_json::Value> =
        serde_json::from_str(&text).map_err(|error| {
            format!(
                "the catalogue {} is not an object of gates: {error}",
                catalogue.display()
            )
        })?;
    let mut gates = Vec::new();
    for (id, value) in entries {
        let entry: Entry = serde_json::from_value(value).map_err(|error| {
            format!(
                "the catalogue entry of {id} in {} cannot be read: {error}",
                catalogue.display()
            )
        })?;
        if entry.status.as_deref() == Some(ACTIVE) && bound.contains(&id) {
            let closes = declared.remove(&id).flatten();
            gates.push((id, closes));
        }
    }
    Ok(gates)
}

/// What every role is left in each state of its work by the declared gates.
/// While every item a session holds waits on someone else, a call that
/// reads, changes or runs something moves none of them, so it is no step
/// left there: what is left is to stop, to answer, or to claim other work.
fn states(gates: &[(String, Option<Closes>)]) -> Vec<State> {
    let mut states = Vec::new();
    for &role in ROLES {
        for &work in WORK {
            let mut closed_by: BTreeMap<Step, Vec<String>> = BTreeMap::new();
            for (id, closes) in gates {
                let Some(closes) = closes else {
                    continue;
                };
                for (step, roles) in closes {
                    if roles.get(&role).is_some_and(|when| when.closes(work)) {
                        closed_by.entry(*step).or_default().push(id.clone());
                    }
                }
            }
            let moves = |step: &Step| {
                work != Work::Held || !matches!(step, Step::Read | Step::Change | Step::Shell)
            };
            let admitted = STEPS
                .iter()
                .copied()
                .filter(|step| !closed_by.contains_key(step) && moves(step))
                .collect();
            states.push(State {
                role,
                work,
                admitted,
                closed_by,
            });
        }
    }
    states
}

/// The states the active gates of `catalogue`, as their declarations under
/// `root` say, leave no step, each as the line `reach` prints for it; none
/// when every state keeps one. `tama hooks release` refuses a gate set with
/// any. Gates that declare nothing are not guessed here: `reach` names them.
pub fn stuck(root: &Path, catalogue: &Path) -> Result<Vec<String>, String> {
    let gates = active(catalogue, declared(root)?)?;
    Ok(states(&gates)
        .iter()
        .filter(|state| state.admitted.is_empty())
        .map(report::line)
        .collect())
}

pub fn main(argv: &[String], root: &Path) -> i32 {
    if argv.iter().any(|arg| arg == "--help" || arg == "-h") {
        println!("{USAGE}");
        return tama_core::exit::SUCCESS;
    }
    let catalogue = match option(argv, "--catalogue") {
        Some(path) => PathBuf::from(path),
        None => match std::env::var_os("HOME").filter(|home| !home.is_empty()) {
            Some(home) => PathBuf::from(home).join(HOOK_HOME).join(CATALOGUE),
            None => {
                return refuse("HOME is not set, so the installed catalogue cannot be located; name it with --catalogue")
            }
        },
    };
    let declarations = match declared(root) {
        Ok(declarations) => declarations,
        Err(cause) => {
            return refuse(&format!(
                "the committed declarations cannot be read: {cause}"
            ))
        }
    };
    let gates = match active(&catalogue, declarations) {
        Ok(gates) => gates,
        Err(cause) => return refuse(&cause),
    };
    let undeclared: Vec<&str> = gates
        .iter()
        .filter(|(_, closes)| closes.is_none())
        .map(|(id, _)| id.as_str())
        .collect();
    let states = states(&gates);
    let stuck = states.iter().any(|state| state.admitted.is_empty());
    if argv.iter().any(|arg| arg == "--json") {
        let document = json!({
            "catalogue": catalogue,
            "active": gates.len(),
            "undeclared": undeclared,
            "states": states,
            "stuck": stuck,
        });
        println!("{document}");
    } else {
        report::report(&catalogue, gates.len(), &undeclared, &states);
    }
    if stuck || !undeclared.is_empty() {
        tama_core::exit::FAILURE
    } else {
        tama_core::exit::SUCCESS
    }
}
