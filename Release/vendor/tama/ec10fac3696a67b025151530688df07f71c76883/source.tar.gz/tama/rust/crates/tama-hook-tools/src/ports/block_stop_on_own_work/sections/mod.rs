//! The three-part report the communication contract asks for — what was
//! done, blockers, next steps — read back as sections, and the commands a
//! plea under next steps hands the operator.
//!
//! Which line heads which part is read in `titles`: by the heading's
//! markdown form and its position from the end, not by its words. A section
//! runs to the next part's heading. What the lines mean is read by the model
//! in `reading.rs`.

pub mod chain;
mod runnable;

use super::titles::{repeated, titles, Title, LINE_JOIN};
use crate::ports::transport_common as common;

/// The report's blockers and next steps, when the message has those headings.
#[derive(Debug, Default, PartialEq, Eq)]
pub struct Report {
    pub done: Option<String>,
    pub blockers: Option<String>,
    pub next_steps: Option<String>,
    /// The first section heading the answer carries a second time, as
    /// written: one answer, one of each section.
    pub repeated_heading: Option<String>,
}

impl Report {
    pub fn parse(message: &str) -> Report {
        let lines: Vec<&str> = message.lines().collect();
        let mut report = Report {
            repeated_heading: repeated(&lines),
            ..Report::default()
        };
        let mut current: Option<Title> = None;
        let mut body: Vec<&str> = Vec::new();
        let close = |current: Option<Title>, body: &mut Vec<&str>, report: &mut Report| {
            let text = body.join(LINE_JOIN).trim().to_owned();
            match current {
                Some(Title::Done) => report.done = Some(text),
                Some(Title::Blockers) => report.blockers = Some(text),
                Some(Title::NextSteps) => report.next_steps = Some(text),
                None => {}
            }
            body.clear();
        };
        for (line, title) in lines.iter().copied().zip(titles(&lines)) {
            if let Some(title) = title {
                close(current, &mut body, &mut report);
                current = Some(title);
            } else if current.is_some() {
                body.push(line);
            }
        }
        close(current, &mut body, &mut report);
        report
    }

    /// The commands the next-steps section hands the operator: its code
    /// spans. The contract allows one, pleaded for and already on the
    /// clipboard; `None` when the section holds none.
    pub fn begged_commands(&self) -> Option<Vec<&str>> {
        let text = self.next_steps.as_deref()?;
        let commands: Vec<&str> = CODE_SPAN
            .captures_iter(text)
            .filter_map(|found| found.get(1))
            .map(|span| span.as_str().trim())
            .filter(|span| !span.is_empty())
            .collect();
        (!commands.is_empty()).then_some(commands)
    }
}

/// A command written in the answer as a code span.
static CODE_SPAN: std::sync::LazyLock<regex::Regex> =
    std::sync::LazyLock::new(|| common::compile("`([^`\\n]+)`"));
