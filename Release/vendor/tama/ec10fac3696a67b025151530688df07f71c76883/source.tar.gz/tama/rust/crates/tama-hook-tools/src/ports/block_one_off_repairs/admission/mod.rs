//! What decides whether a build may start, before the readiness gate: the
//! penalty the session's model carries for builds it wasted, and whether a
//! package-manager script is a build at all.

mod modules;
mod penalty;
mod scripts;

pub(super) use penalty::penalty_refusal;
pub(super) use scripts::runs_no_compile;
