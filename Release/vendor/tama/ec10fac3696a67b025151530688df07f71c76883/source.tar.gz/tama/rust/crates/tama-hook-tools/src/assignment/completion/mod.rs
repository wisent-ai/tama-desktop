//! Oko owns completion; a local plan cannot replace it.

pub mod excuses;
pub mod shown;
pub mod summary;

use std::collections::BTreeSet;

use super::rules;

pub fn pending(session: &str) -> Result<Vec<String>, String> {
    if session.trim().is_empty() {
        return Err("the Stop payload contains no session identity".to_owned());
    }
    pending_from(&rules::task_ledger(session)?)
}

/// The open requests in a ledger already read. A task counts until Oko
/// records it done: the operator's rule is that nothing is built
/// and no turn ends while any task is not really repaired. An entry in the
/// blocker register, a `blocked` verdict, or a wait on other open work does
/// not stand a task aside: blockers written on every open task would
/// otherwise let a build through with nothing repaired.
///
/// Duplicates are counted through their primary task. A task awaiting review
/// already carries a repair and a recorded inability of Oko's judge to rule;
/// it is not executable author work while that review remains unavailable.
pub fn pending_from(ledger: &rules::TaskLedger) -> Result<Vec<String>, String> {
    let mut pending = open_tasks(ledger, |task| !awaiting_review(task))?;
    pending.extend(unread_from(ledger)?);
    Ok(pending)
}

/// A task that carries its repair, or whose every acceptance check Oko
/// records as met with evidence (work with no commit or report, such as a
/// print job or an answer), and that the judge could not rule on.
pub fn awaiting_review(task: &serde_json::Value) -> bool {
    (carries_repair(task) || proven_by_checks(task)) && task["judgeOutage"]["at"].as_str().is_some()
}

/// A task Oko reports as proven by its own acceptance checks: `proof.checks`
/// is present only when every check is met with nonempty evidence.
fn proven_by_checks(task: &serde_json::Value) -> bool {
    task["proof"]["checks"]
        .as_array()
        .is_some_and(|checks| !checks.is_empty())
}

/// The operator messages Oko's reading model has not read, named in one line
/// per session with the judge's recorded state. An unread message may be an
/// instruction, so it holds the turn like an open task until the session
/// records what it is (`oko tasks kind`) or the model reads it.
/// Many messages are about one piece of work: only a message read as `task`
/// starts one, a `detail` adds to the newest task, and a question or a remark
/// is no work owed. One line per session, not per message: a reading model
/// that stays down leaves thousands unread, and each line repeated its whole
/// error.
fn unread_from(ledger: &rules::TaskLedger) -> Result<Vec<String>, String> {
    let Some(unread) = ledger.value.get("unread").filter(|value| !value.is_null()) else {
        return Ok(Vec::new());
    };
    let ordinals: Vec<i64> = unread["ordinals"]
        .as_array()
        .into_iter()
        .flatten()
        .filter_map(serde_json::Value::as_i64)
        .collect();
    if ordinals.is_empty() {
        return Ok(Vec::new());
    }
    let session = session_of(ledger)?;
    let reading = &unread["reading"];
    let state = match reading["answering"].as_bool() {
        Some(true) => "the reading model answers; run `oko tasks read`".to_string(),
        Some(false) => match reading["checked_at"].as_str() {
            Some(at) => format!(
                "the reading model did not answer at {at}; `oko tasks read` prints its answer"
            ),
            None => "the reading model did not answer, and Oko recorded no time for that \
                     check; `oko tasks read` prints its answer"
                .to_string(),
        },
        None => "nothing has observed the reading model".to_string(),
    };
    Ok(vec![format!(
        "{session} {} (unread): no model has read these operator messages; {state}. \
         Record what each one is with `oko tasks kind {session} <NUMBER> <KIND> --by {session}`: \
         task only for work no earlier message asked for, detail for a fact or correction to earlier work, \
         question, remark, order or another kind from `oko tasks --help`",
        shown::ordinals(&ordinals)
    )])
}

/// The session a task ledger is Oko's answer for. A ledger without one is
/// refused: its lines would name no session to record a kind or a repair
/// under.
fn session_of(ledger: &rules::TaskLedger) -> Result<&str, String> {
    ledger.value["sessionId"]
        .as_str()
        .ok_or_else(|| "Oko returned a task ledger without its sessionId".to_string())
}

/// Open tasks that carry their repair and still await their judge's ruling:
/// the work their owner already wrote. An unread message is never one.
pub fn repaired_from(ledger: &rules::TaskLedger) -> Result<Vec<String>, String> {
    open_tasks(ledger, |task| {
        carries_repair(task) && !awaiting_review(task)
    })
}

/// Open requests with neither a commit nor a report recorded as repair proof.
/// Build admission requires a repair for every item, not a completed review:
/// the build itself can supply evidence needed to judge a code repair.
pub fn unrepaired_from(ledger: &rules::TaskLedger) -> Result<Vec<String>, String> {
    open_tasks(ledger, |task| !carries_repair(task))
}

/// The same open requests with no repair, each with the products its
/// contract is scoped to (empty when its contract names none).
pub fn unrepaired_scoped_from(
    ledger: &rules::TaskLedger,
) -> Result<Vec<(String, BTreeSet<String>)>, String> {
    open_scoped(ledger, |task| !carries_repair(task))
}

/// The products one task's contract is scoped to: `contract.terms.scope`.
pub fn contract_scope(task: &serde_json::Value) -> BTreeSet<String> {
    task.pointer("/contract/terms/scope")
        .and_then(serde_json::Value::as_array)
        .into_iter()
        .flatten()
        .filter_map(serde_json::Value::as_str)
        .map(str::to_owned)
        .collect()
}

/// A task whose proof names a commit or a report.
fn carries_repair(task: &serde_json::Value) -> bool {
    let named = |key: &str| {
        task["proof"][key]
            .as_str()
            .is_some_and(|value| !value.trim().is_empty())
    };
    named("commit") || named("report")
}

fn open_tasks(
    ledger: &rules::TaskLedger,
    keep: impl Fn(&serde_json::Value) -> bool,
) -> Result<Vec<String>, String> {
    Ok(open_scoped(ledger, keep)?
        .into_iter()
        .map(|(line, _)| line)
        .collect())
}

fn open_scoped(
    ledger: &rules::TaskLedger,
    keep: impl Fn(&serde_json::Value) -> bool,
) -> Result<Vec<(String, BTreeSet<String>)>, String> {
    let tasks = ledger.value["tasks"]
        .as_array()
        .ok_or("Oko returned no task array")?;
    let session = session_of(ledger)?;
    let mut pending = Vec::new();
    for task in tasks {
        if !task_is_open(task)? || !keep(task) {
            continue;
        }
        let ordinal = task["ordinal"]
            .as_u64()
            .ok_or("Oko returned an open task without its ordinal")?;
        let id = task["id"]
            .as_str()
            .filter(|id| !id.trim().is_empty())
            .ok_or("Oko returned an open task without its identity")?;
        task["text"]
            .as_str()
            .filter(|text| !text.trim().is_empty())
            .ok_or("Oko returned an open task without its request")?;
        pending.push((
            format!("{session} #{ordinal} ({id}): {}", shown::task(task, id)),
            contract_scope(task),
        ));
    }
    Ok(pending)
}

/// Shared task eligibility for completion and the prepared executor reading.
pub(crate) fn task_is_open(task: &serde_json::Value) -> Result<bool, String> {
    match task["status"].as_str() {
        Some("not done") => {}
        Some(_) => return Ok(false),
        None => return Err(format!("Oko returned a task without a status: {task}")),
    }
    Ok(task["origin"].as_str() != Some("delegated") && duplicate_of(task).is_none())
}

/// The task Oko says this one duplicates.
fn duplicate_of(task: &serde_json::Value) -> Option<String> {
    task["relations"]
        .as_array()?
        .iter()
        .find(|relation| relation["name"].as_str() == Some("duplicate-of"))
        .and_then(|relation| relation["other"].as_str())
        .map(str::to_owned)
}

/// When Oko last recorded, on any task of this ledger, that its judge could
/// not answer. The before-stop pass refuses while the judge is down, so an
/// order to run it cannot be obeyed usefully: every Stop would spend minutes
/// printing the same refusal.
pub fn judge_down_since(ledger: &rules::TaskLedger) -> Option<String> {
    ledger.value["tasks"]
        .as_array()?
        .iter()
        .filter_map(|task| task["judgeOutage"]["at"].as_str())
        .max()
        .map(str::to_owned)
}

/// This refusal directs the session to executable open work rather than
/// treating the completion gate itself as an external blocker.
pub const NOT_A_BLOCKER: &str =
    "This refusal is the operator's instruction to keep working, not a \
    blocker: never list it under Blockers and never answer again without first working on the next \
    open item.";
