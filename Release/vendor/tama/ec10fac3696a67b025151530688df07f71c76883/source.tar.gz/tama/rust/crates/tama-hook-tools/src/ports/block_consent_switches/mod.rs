//! Decision half of `tama hook block-consent-switches` (hook id
//! `block-consent-switches`): no agent sets a variable Tama reads as the
//! operator's own consent or as turning its gates off, unless the operator
//! granted that exact command in his own words
//! ([`crate::ports::operator_grant`]).
//!
//! Tama's consent gates also accept a variable "exported by the owner
//! outside the session" (`DEVICE_HOOK_EDIT_APPROVED=1` and its kin), its
//! hook runner takes the hooks to skip from `TAMA_DISABLED_HOOKS` and
//! `TAMA_ONLY_HOOK_ID`, and the clean gate stands down on
//! `TAMA_CLEAN_DISABLED`. Nothing stopped an agent from putting one in front
//! of its own command (`DEVICE_HOOK_EDIT_APPROVED=1 tama hooks declare …`),
//! exporting it, handing it to `env`, or starting a nested session with it,
//! and so granting itself what only the operator grants. His consent is his
//! word in the conversation, recorded as a session capability for the
//! lifetime he named or as a grant (`tama justify record`); the variables
//! stay his, set in his own shell.
//!
//! The variables are the ones the owning gates read, named by their own
//! constants ([`SWITCHES`]). A shell line sets one when a word it runs,
//! through every shell handed a line, assigns it (`NAME=…`, as a prefix, an
//! `env` operand or an `export`/`declare`/`typeset` operand) or names it to a
//! program that sets a variable (`export NAME`, `setenv NAME …`,
//! `launchctl setenv NAME …`). A program an evaluation tool runs sets one
//! when its text names it, since a program sets a variable through its own
//! library call rather than a shell word. Reading one (`echo $NAME`) passes.
//! No model, no network, no lock; a grant that cannot be read admits
//! nothing.

use std::path::Path;

use serde_json::Value;

use crate::ports::operator_grant::{self, Request};
use crate::ports::python_stdlib::shell_tokens;
use crate::ports::shell_text;
use crate::ports::tool_vocabulary::Call;
use crate::ports::{
    block_hook_config_edits_without_consent as hook_edit, block_local_model_training,
    block_subagent_spawn, block_unapproved_audits_state, clean_violations_gate,
};

pub const HOOK_ID: &str = "block-consent-switches";
pub const GRANT_KIND: &str = "consent-switch";
const BANNER: &str = "BLOCKED: consent switch: ";

/// The operator's consent to test code, read by
/// `block-device-level-tests-without-consent`.
pub const TESTS_APPROVED: &str = "DEVICE_LEVEL_TESTS_APPROVED";
/// The hook ids the hook runner skips for one invocation.
pub const DISABLED_HOOKS: &str = "TAMA_DISABLED_HOOKS";
/// The one hook id the hook runner runs alone for one invocation.
pub const ONLY_HOOK: &str = "TAMA_ONLY_HOOK_ID";

/// Programs that set a variable they are handed by name, as their own
/// manuals state it (sh(1) export, bash(1) declare/typeset, csh(1) setenv,
/// launchctl(1) setenv).
const SETTERS: &[&str] = &["export", "declare", "typeset", "setenv", "launchctl"];

/// Every variable Tama reads as the operator's consent or as turning its
/// gates off, by the constant of the gate that reads it.
pub const SWITCHES: &[&str] = &[
    hook_edit::APPROVAL_ENV,
    TESTS_APPROVED,
    block_subagent_spawn::APPROVAL_ENV,
    block_unapproved_audits_state::APPROVAL_ENV,
    block_local_model_training::APPROVAL_VARIABLE,
    clean_violations_gate::DISABLE_ENV,
    crate::capability::CAPABILITY_ENV,
    DISABLED_HOOKS,
    ONLY_HOOK,
];

/// The refusal when the call sets a switch with no grant, `None` when it
/// passes.
pub fn evaluate(payload: &Value) -> Option<String> {
    let call = Call::of(payload);
    let executable = call.executable()?;
    let found: Vec<&str> = if call.is_eval() {
        SWITCHES
            .iter()
            .copied()
            .filter(|name| executable.contains(name))
            .collect()
    } else {
        let mut found = Vec::new();
        set_in_shell(&executable, &mut found);
        found
    };
    if found.is_empty() {
        return None;
    }
    let request = Request {
        gate: HOOK_ID,
        command: Some(&executable),
        paths: &[],
    };
    if operator_grant::granted(payload, &request) {
        return None;
    }
    let named: Vec<String> = found.iter().map(|name| format!("`{name}`")).collect();
    Some(format!(
        "{BANNER}this call sets {}, which Tama reads as the operator's own consent or as \
         turning its gates off. An agent never sets one: the operator's consent is his word in \
         the conversation, recorded as a session capability for the lifetime he named \
         (xd://tama_request_session_capability) or as a grant (`tama justify record`), and the \
         variable stays his, set in his own shell. {}",
        named.join(", "),
        operator_grant::how_to_grant(GRANT_KIND, HOOK_ID)
    ))
}

/// Push onto `found` each switch `line` sets, read through every shell it
/// hands a line to.
fn set_in_shell(line: &str, found: &mut Vec<&'static str>) {
    for segment in shell_text::commands(line) {
        let tokens = shell_tokens(segment);
        if let Some(inner) = shell_text::inner_command(&tokens) {
            set_in_shell(&inner, found);
        }
        let setter = tokens.iter().any(|token| {
            Path::new(token)
                .file_name()
                .and_then(|name| name.to_str())
                .is_some_and(|name| SETTERS.contains(&name))
        });
        for &name in SWITCHES {
            let assigned = tokens.iter().any(|token| {
                token
                    .strip_prefix(name)
                    .is_some_and(|rest| rest.starts_with('='))
            });
            let named = setter && tokens.iter().any(|token| token == name);
            if (assigned || named) && !found.contains(&name) {
                found.push(name);
            }
        }
    }
}
