//! Decision half of `tama hook block-reserved-changes` (hook id
//! `block-reserved-changes`): what the operator reserved is changed only on
//! his word. Each reservation is declared in `reserved.json` beside this
//! file, with the reason and the operator's own sentence it stands on:
//!
//! - `directories`: no file is written under a directory of that name (OMP's
//!   checkout, `oh-my-pi`; the financial model, `model_finansowy`);
//! - `files`: no file of that name is written (the model's inputs);
//! - `repositories` with `newFileWords`: no new file whose name holds one of
//!   those words is created in a checkout of that name (notes in the grant
//!   repositories);
//! - `commands`: no shell command runs the program with those words in that
//!   order (the model's rebuild; relinking a package), and with
//!   `commandsOnlyInside` only when the command names or runs in one of the
//!   reserved directories.
//!
//! A write is read from every path the file tools name
//! ([`crate::ports::block_off_task_work::written_paths`]), a shell line by
//! the words it runs ([`crate::ports::shell_text`]). The operator allows one
//! exact change with `tama justify record --kind reserved-change`, its
//! actions the command or the absolute paths ([`crate::ports::operator_grant`]).
//! No model, no network, no lock; a reservation list that cannot be read
//! refuses nothing and says so.

use std::path::{Component, Path, PathBuf};
use std::sync::LazyLock;

use serde::Deserialize;
use serde_json::Value;

use crate::ports::block_off_task_work::written_paths;
use crate::ports::operator_grant::{self, Request};
use crate::ports::python_stdlib::shell_tokens;
use crate::ports::shell_text;
use crate::ports::tool_vocabulary::Call;

pub const HOOK_ID: &str = "block-reserved-changes";
pub const GRANT_KIND: &str = "reserved-change";

#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
struct Reservation {
    subject: String,
    why: String,
    said: String,
    directories: Vec<String>,
    files: Vec<String>,
    repositories: Vec<String>,
    new_file_words: Vec<String>,
    commands: Vec<Vec<String>>,
    commands_only_inside: bool,
}

#[derive(Deserialize)]
struct Reservations {
    reserved: Vec<Reservation>,
}

static RESERVED: LazyLock<Result<Reservations, String>> = LazyLock::new(|| {
    serde_json::from_str(include_str!("reserved.json"))
        .map_err(|error| format!("{HOOK_ID}: reserved.json cannot be read: {error}"))
});

/// The refusal for the call in `payload`, `None` when it changes nothing
/// reserved or the operator granted exactly this change.
pub fn evaluate(payload: &Value) -> Option<String> {
    let reservations = match &*RESERVED {
        Ok(reservations) => reservations,
        Err(cause) => {
            eprintln!("{cause}; nothing is refused");
            return None;
        }
    };
    let call = Call::of(payload);
    let cwd = call.cwd().map(PathBuf::from);
    let (found, command, paths) = if call.is_shell() {
        let command = call.command()?;
        (
            commanded(reservations, payload, command, cwd.as_deref()),
            Some(command),
            Vec::new(),
        )
    } else {
        let paths: Vec<String> = match written_paths(&call) {
            Ok(paths) => paths,
            Err(cause) => {
                eprintln!("{HOOK_ID}: the paths this call writes cannot be read: {cause}");
                return None;
            }
        }
        .iter()
        .map(|path| absolute(path, cwd.as_deref()))
        .collect();
        (written(reservations, &paths), None, paths)
    };
    if found.is_empty() {
        return None;
    }
    let request = Request {
        gate: HOOK_ID,
        command,
        paths: &paths,
    };
    if operator_grant::granted(payload, &request) {
        return None;
    }
    Some(format!(
        "BLOCKED ({HOOK_ID}): {}. Leave what is reserved as it is and do the work that was asked. {}",
        found.join("; "),
        operator_grant::how_to_grant(GRANT_KIND, HOOK_ID)
    ))
}

/// `path` made absolute against the call's working directory.
fn absolute(path: &str, cwd: Option<&Path>) -> String {
    match cwd {
        Some(cwd) if Path::new(path).is_relative() => cwd.join(path).display().to_string(),
        _ => path.to_string(),
    }
}

fn components(path: &Path) -> Vec<String> {
    path.components()
        .filter_map(|component| match component {
            Component::Normal(name) => Some(name.to_string_lossy().into_owned()),
            _ => None,
        })
        .collect()
}

fn reason(reservation: &Reservation, what: String) -> String {
    format!(
        "{what} is reserved ({}: {}; the operator: \"{}\")",
        reservation.subject, reservation.why, reservation.said
    )
}

/// What each written path changes that a reservation holds.
fn written(reservations: &Reservations, paths: &[String]) -> Vec<String> {
    let mut found = Vec::new();
    for path in paths {
        let parts = components(Path::new(path));
        let name = parts.last().map(|name| name.to_lowercase());
        for reservation in &reservations.reserved {
            let under = reservation
                .directories
                .iter()
                .any(|directory| parts.contains(directory));
            let named = name.as_ref().is_some_and(|name| {
                reservation
                    .files
                    .iter()
                    .any(|file| file.to_lowercase() == *name)
            });
            let note = name.as_ref().is_some_and(|name| {
                reservation
                    .repositories
                    .iter()
                    .any(|repository| parts.contains(repository))
                    && !Path::new(path).exists()
                    && name
                        .split(|character: char| !character.is_alphanumeric())
                        .any(|word| reservation.new_file_words.iter().any(|kept| kept == word))
            });
            if under || named || note {
                found.push(reason(reservation, format!("`{path}`")));
            }
        }
    }
    found
}

/// What the shell line runs that a reservation holds.
fn commanded(
    reservations: &Reservations,
    payload: &Value,
    command: &str,
    cwd: Option<&Path>,
) -> Vec<String> {
    let starts = command_starts(payload, command);
    let mut found = Vec::new();
    for reservation in &reservations.reserved {
        let inside = || {
            let named = |text: &str| {
                let parts = components(Path::new(text));
                reservation
                    .directories
                    .iter()
                    .any(|directory| parts.contains(directory))
            };
            cwd.is_some_and(|cwd| named(&cwd.display().to_string()))
                || starts.iter().flatten().any(|word| named(word.as_str()))
        };
        for start in &starts {
            let Some(rule) = reservation.commands.iter().find(|rule| runs(rule, start)) else {
                continue;
            };
            if !reservation.commands_only_inside || inside() {
                found.push(reason(reservation, format!("`{}`", rule.join(" "))));
            }
        }
    }
    found
}

/// Every command the shell line runs, each as its program and words, past
/// assignments and wrappers.
pub(crate) fn command_starts(payload: &Value, command: &str) -> Vec<Vec<String>> {
    let acting = shell_text::effective_payload(payload, command);
    shell_text::commands(&acting)
        .into_iter()
        .map(shell_tokens)
        .filter_map(|tokens| shell_text::command_start(&tokens).map(<[String]>::to_vec))
        .collect()
}

/// Whether `start` (a program and its words) runs `rule`'s program with the
/// rule's other words among its own, in order.
pub(crate) fn runs(rule: &[String], start: &[String]) -> bool {
    let (Some((program, words)), Some((first, args))) = (rule.split_first(), start.split_first())
    else {
        return false;
    };
    let name = Path::new(first)
        .file_name()
        .map(|name| name.to_string_lossy());
    if name.as_deref() != Some(program.as_str()) {
        return false;
    }
    let mut args = args.iter();
    words.iter().all(|word| args.any(|arg| arg == word))
}
