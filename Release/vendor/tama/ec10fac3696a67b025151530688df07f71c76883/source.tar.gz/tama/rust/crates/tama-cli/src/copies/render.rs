//! The printed shapes of both leaves, text and JSON.
//!
//! Every refusal is worded once here, because the preview, an applied pass
//! and the stderr banner of a refused pass all print the same sentence and
//! must not drift apart.

use serde::Serialize;
use tama_violations::repo_discovery::UnreadableDirectory;

use super::discovery::{Copy, ListDocument, Refusal, RemoveDocument, FIRST_COMMITS};

const KIB: u64 = 1024;

/// Sizes an operator reads at a glance, since the reason this command exists
/// is a full boot volume.
fn size(bytes: u64) -> String {
    let gib = KIB * KIB * KIB;
    if bytes >= gib {
        return format!("{:.1} GiB", bytes as f64 / gib as f64);
    }
    format!("{:.1} MiB", bytes as f64 / (KIB * KIB) as f64)
}

/// The one place a refusal is worded.
pub(super) fn refusal_sentence(refusal: &Refusal) -> String {
    let path = &refusal.path;
    match refusal.reason {
        "unreadable-git-state" => format!("{path} has unreadable Git state; inspect the reported Git error before forcing removal."),
        "uncommitted-changes" => {
            format!("{path} has uncommitted changes; commit them there, then run the pass again.")
        }
        "commits-not-on-remote" => format!(
            "{path} holds Git history without a remote-tracking or canonical retention proof; retain that history before removing this directory."
        ),
        "no-origin-remote" => format!(
            "{path} has no origin remote, so this pass cannot prove its history exists anywhere else."
        ),
        "no-canonical-checkout" => format!(
            "{path} is the only checkout of its repository under the roots given, so it is not a copy of anything."
        ),
        "owns-linked-worktrees" => format!(
            "{path} owns linked worktrees; remove those first with 'tama worktrees remove --root <PATH> --apply'."
        ),
        other => format!("{path}: {other}"),
    }
}

fn print_copy(copy: &Copy) {
    let owner = copy.owner.as_deref().unwrap_or("(no canonical checkout)");
    let mut flags = String::new();
    for (set, label) in [
        (copy.dirty == Some(true), " dirty"),
        (copy.inspection_error.is_some(), " unreadable-git-state"),
        (
            copy.unpublished == Some(true) && copy.history_retained_by.is_none(),
            " unretained-history",
        ),
        (copy.owns_worktrees == Some(true), " owns-worktrees"),
    ] {
        if set {
            flags.push_str(label);
        }
    }
    println!("  {}  {}  of {owner}{flags}", copy.path, size(copy.bytes));
    if let Some(retained) = &copy.history_retained_by {
        println!("    Git history retained by {retained}");
    }
    if let Some(error) = &copy.inspection_error {
        eprintln!("    {error}");
    }
}

fn print_crossed(document: &ListDocument) {
    if !document.linked_worktrees.is_empty() {
        println!(
            "{} linked worktree(s) crossed; 'tama worktrees list' names them and removes them.",
            document.linked_worktrees.len()
        );
    }
    for twin in &document.twins {
        if twin.basis == FIRST_COMMITS {
            println!(
                "twin history: {} and {} start from the same commits ({}) under different origins, so they are one repository or a fork of it; this pass removes neither, because which one you keep is your call.",
                twin.path, twin.twin, twin.origin
            );
        } else {
            println!(
                "twin checkout: {} and {} are both checkouts of {}; this pass removes neither, because which one you keep is your call.",
                twin.path, twin.twin, twin.origin
            );
        }
    }
    for path in &document.unreadable {
        eprintln!("skipped {path}: git does not answer for it as a repository");
    }
    print_unreadable_directories(&document.unreadable_directories);
}

/// What the walk could not read, and what that costs the answer above. An
/// operator reading `0 copies` has to see this in the same breath, so it goes
/// to stderr on every leaf and the leaf exits non-zero.
pub(super) fn print_unreadable_directories(directories: &[UnreadableDirectory]) {
    for directory in directories {
        eprintln!("could not read {}: {}", directory.path, directory.reason);
    }
    if !directories.is_empty() {
        eprintln!("{}", incomplete_walk_sentence(directories));
    }
}

/// The one sentence a pass makes when it could not look everywhere.
pub(super) fn incomplete_walk_sentence(directories: &[UnreadableDirectory]) -> String {
    format!(
        "this pass could not read {} director{} under the roots, so it cannot say what they hold; nothing was removed",
        directories.len(),
        if directories.len() == 1 { "y" } else { "ies" }
    )
}

pub(super) fn print_list(document: &ListDocument) {
    for copy in &document.copies {
        print_copy(copy);
    }
    println!(
        "{} cop{} under {}, {}; {} of them a copy of a checkout that is also here",
        document.copy_count,
        if document.copy_count == 1 { "y" } else { "ies" },
        document.roots.join(", "),
        size(document.bytes),
        document
            .copies
            .iter()
            .filter(|copy| copy.owner.is_some())
            .count()
    );
    print_crossed(document);
}

pub(super) fn print_json<T: Serialize>(document: &T) {
    match serde_json::to_string_pretty(document) {
        Ok(text) => println!("{text}"),
        Err(error) => eprintln!("copies: {error}"),
    }
}

/// What `--except` held back, printed before anything the pass judged: kept
/// is the operator's choice, refused is the product's judgement, and printing
/// them together would read as one list of problems.
fn print_excepted(document: &RemoveDocument) {
    if document.excepted.is_empty() {
        return;
    }
    for path in &document.excepted {
        println!("kept {path}");
    }
}

/// The preview lists what would go and, separately, what would block the
/// pass. A refused `--apply` prints nothing here: its refusals go to stderr
/// with the exit code that carries them.
pub(super) fn print_remove(document: &RemoveDocument, apply: bool) {
    print_excepted(document);
    if document.applied {
        for path in &document.removed {
            println!("removed {path}");
        }
        println!(
            "removed {} cop{}, {}",
            document.removed.len(),
            if document.removed.len() == 1 {
                "y"
            } else {
                "ies"
            },
            size(document.bytes)
        );
        return;
    }
    if !apply {
        for copy in &document.copies {
            print_copy(copy);
        }
        let removable = document.copy_count - document.refused.len();
        println!(
            "would remove {removable} of {} cop{} under {}, {}",
            document.copy_count,
            if document.copy_count == 1 { "y" } else { "ies" },
            document.roots.join(", "),
            size(document.bytes)
        );
        for refusal in &document.refused {
            println!("would refuse: {}", refusal_sentence(refusal));
        }
    }
    if !document.linked_worktrees.is_empty() {
        println!(
            "{} linked worktree(s) crossed; 'tama worktrees remove' owns those.",
            document.linked_worktrees.len()
        );
    }
    for path in &document.unreadable {
        eprintln!("skipped {path}: git does not answer for it as a repository");
    }
    print_unreadable_directories(&document.unreadable_directories);
}
