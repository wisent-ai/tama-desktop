//! Install planning: what installing the catalogue's hooks writes, and where.

use serde::Serialize;
use std::fs;
use std::path::Path;

use crate::git::Git;
use crate::{err, Result};

mod dispatcher;
mod dispatcher_state;
mod uninstall;

pub use dispatcher::{dispatcher_body, InstalledHook};
use dispatcher::{expand_home, install_one, join_path, refuse_install_during_bypass, resolve_path};
pub use dispatcher_state::{dispatcher_states, DispatcherState, UserGlobalGitLevel};
pub use uninstall::{uninstall_global_git, RemovedHook, UninstallOptions, UninstallResult};
const MANAGED_HEADER: &str = "# tama managed global Git dispatcher";
pub const GIT_HOOKS: &[&str] = &[
    "pre-commit",
    "commit-msg",
    "pre-push",
    "reference-transaction",
];
/// How a repository's own hooks run. Git reads one hooks directory per
/// repository and a repository's own `core.hooksPath` wins over the global
/// one, so a repository that sets it runs none of the dispatcher's gates.
pub const REPO_PROJECT_NOTE: &str = "The user-global dispatcher runs each repository's own .githooks/<hook>, else this archive's repo-githooks/<repository>/<hook>, after its own gates (Rust format, quality check, review-push). A repository must not set core.hooksPath of its own: Git then runs that directory instead of the dispatcher and none of those gates run on its commits and pushes. `tama hooks status --repo <path>` names such an override.";

/// The given home, else HOME through [`crate::home_dir`], which stops naming
/// the variable when it is unset instead of answering an empty home.
fn home_or_env(home: Option<&str>) -> String {
    match home {
        Some(home) => home.to_string(),
        None => crate::home_dir().to_string_lossy().into_owned(),
    }
}

/// JS `currentGlobalHooksPath(home)`: `git config --global --get core.hooksPath`
/// with `HOME` overridden. `None` when it is unset or empty: git answers an
/// unset key with a failing exit and nothing said. A git that cannot run, or
/// one that says why it failed (a config it cannot read), is an error: read
/// as unset, install wrote the dispatchers where Git never runs them.
pub fn current_global_hooks_path(home: Option<&str>) -> Result<Option<String>> {
    let home = home_or_env(home);
    let output = Git::of(None)
        .variables(&[("HOME", home.as_str())])
        .output(&["config", "--global", "--get", "core.hooksPath"])
        .map_err(|error| err(format!("cannot read core.hooksPath: {error}")))?;
    let said = String::from_utf8_lossy(&output.stderr).trim().to_string();
    if !output.status.success() {
        if said.is_empty() {
            return Ok(None);
        }
        return Err(err(format!("git cannot read core.hooksPath: {said}")));
    }
    let value = String::from_utf8_lossy(&output.stdout).trim().to_string();
    if value.is_empty() {
        Ok(None)
    } else {
        Ok(Some(value))
    }
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AgentAppTargets {
    pub shared_hooks: String,
    pub codex_hooks: String,
    pub codex_settings: String,
    pub claude_hooks: String,
    pub claude_settings: String,
    pub omp_pre_tool_adapter: String,
    /// The hook file of every harness `crate::harnesses` declares, by id.
    pub harness_configs: std::collections::BTreeMap<String, String>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AgentAppLevel {
    pub level: String,
    pub active_by_archive_alone: bool,
    pub source_root: String,
    pub runtime_targets: AgentAppTargets,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct EditorTargets {
    pub editor_save_guard: String,
    pub editor_watch: String,
    pub editor_watch_pid: String,
    pub editor_watch_log: String,
    pub launch_agent: String,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct EditorLevel {
    pub level: String,
    pub active_by_archive_alone: bool,
    pub source_root: String,
    pub runtime_targets: EditorTargets,
    pub note: String,
}

#[derive(Debug, Clone, Serialize)]
pub struct McpTargets {
    pub server: String,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct McpLevel {
    pub level: String,
    pub active_by_archive_alone: bool,
    pub runtime_targets: McpTargets,
    pub config_command: String,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct RepoProjectLevel {
    pub level: String,
    pub active_by_archive_alone: bool,
    pub source_root: String,
    pub managed_projects: Vec<String>,
    pub note: String,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct OsLevel {
    pub level: String,
    pub active_by_archive_alone: bool,
    pub note: String,
}

/// The `levels` object; struct field order reproduces JS key insertion order.
#[derive(Debug, Clone, Serialize)]
pub struct Levels {
    #[serde(rename = "agent-app")]
    pub agent_app: AgentAppLevel,
    pub editor: EditorLevel,
    pub mcp: McpLevel,
    #[serde(rename = "user-global-git")]
    pub user_global_git: UserGlobalGitLevel,
    #[serde(rename = "repo-project")]
    pub repo_project: RepoProjectLevel,
    #[serde(rename = "os-level")]
    pub os_level: OsLevel,
}

/// Result of JS `levelPlan(root, hooksPath, home)`.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct LevelPlan {
    pub archive_root: String,
    pub levels: Levels,
}

/// JS `levelPlan(root, hooksPath = null, home = process.env.HOME ?? '')`.
pub fn level_plan(root: &Path, hooks_path: Option<&str>, home: Option<&str>) -> LevelPlan {
    let root_s = root.to_string_lossy().trim_end_matches('/').to_string();
    let home = home_or_env(home);
    let shared_hooks = join_path(&home, ".shared-hooks");
    LevelPlan {
        archive_root: root_s.clone(),
        levels: Levels {
            agent_app: AgentAppLevel {
                level: "agent-app".to_string(),
                active_by_archive_alone: false,
                source_root: root_s.clone(),
                runtime_targets: AgentAppTargets {
                    shared_hooks: shared_hooks.clone(),
                    codex_hooks: join_path(&home, ".codex/hooks"),
                    codex_settings: join_path(&home, ".codex/hooks.json"),
                    claude_hooks: join_path(&home, ".claude/hooks"),
                    claude_settings: join_path(&home, ".claude/settings.json"),
                    omp_pre_tool_adapter: join_path(&home, ".omp/agent/hooks/pre/shared-hooks.js"),
                    harness_configs: crate::harnesses::all()
                        .iter()
                        .map(|adapter| {
                            (adapter.id.clone(), adapter.config_path(Path::new(&home)).to_string_lossy().to_string())
                        })
                        .collect(),
                },
            },
            editor: EditorLevel {
                level: "editor".to_string(),
                active_by_archive_alone: false,
                source_root: join_path(&root_s, "shared-hooks"),
                runtime_targets: EditorTargets {
                    editor_save_guard: join_path(&shared_hooks, "editor-save-guard.mjs"),
                    editor_watch: join_path(&shared_hooks, "editor-watch.mjs"),
                    editor_watch_pid: join_path(&shared_hooks, "editor-hooks.pid"),
                    editor_watch_log: join_path(&shared_hooks, "editor-hooks.log"),
                    launch_agent: join_path(&home, "Library/LaunchAgents/com.wisent.editor-hooks.plist"),
                },
                note: "Editor watch is an adapter surface, not installed by the archive alone; the current catalog marks launchd installed-not-active and session watch report-only.".to_string(),
            },
            mcp: McpLevel {
                level: "mcp".to_string(),
                active_by_archive_alone: false,
                runtime_targets: McpTargets {
                    server: "tama mcp".to_string(),
                },
                config_command: "tama mcp config".to_string(),
            },
            user_global_git: dispatcher_state::user_global_git_level(hooks_path, &home),
            repo_project: RepoProjectLevel {
                level: "repo-project-git".to_string(),
                active_by_archive_alone: false,
                source_root: join_path(&root_s, "repo-githooks"),
                managed_projects: vec!["weles".to_string()],
                note: REPO_PROJECT_NOTE.to_string(),
            },
            os_level: OsLevel {
                level: "os-level".to_string(),
                active_by_archive_alone: false,
                note: "Not installed by this tool. Use macOS policy controls for whole-machine enforcement.".to_string(),
            },
        },
    }
}

/// Options for [`install_global_git`] (JS `options` object).
#[derive(Debug, Clone, Default)]
pub struct InstallOptions {
    pub home: Option<String>,
    pub hooks_path: Option<String>,
    pub set_global_config: bool,
}

/// Result of JS `installGlobalGit(root, options)`.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct InstallResult {
    pub hooks_path: String,
    pub pre_commit: InstalledHook,
    pub pre_push: InstalledHook,
    pub commit_msg: InstalledHook,
    pub reference_transaction: InstalledHook,
    /// Managed dispatchers an earlier build wrote for hooks this build does
    /// not dispatch, removed with what each displaced put back.
    pub retired: Vec<RemovedHook>,
    pub set_global_config: bool,
}

/// JS `installGlobalGit(root, options = {})`.
pub fn install_global_git(root: &Path, options: &InstallOptions) -> Result<InstallResult> {
    let home = home_or_env(options.home.as_deref());
    let target_path = match options.hooks_path.clone() {
        Some(path) => path,
        None => match current_global_hooks_path(Some(&home))? {
            Some(path) => path,
            None => join_path(&home, ".config/git/hooks"),
        },
    };
    let hooks_path = resolve_path(&expand_home(&target_path, &home))?;
    fs::create_dir_all(&hooks_path)?;
    let root_s = root.to_string_lossy().trim_end_matches('/').to_string();
    // Validate every dispatcher before writing any of them.
    for hook in GIT_HOOKS {
        refuse_install_during_bypass(&home, &hooks_path, hook)?;
    }
    let pre_commit = install_one(&root_s, &hooks_path, "pre-commit")?;
    let pre_push = install_one(&root_s, &hooks_path, "pre-push")?;
    let commit_msg = install_one(&root_s, &hooks_path, "commit-msg")?;
    let reference_transaction = install_one(&root_s, &hooks_path, "reference-transaction")?;
    let retired = uninstall::retire_others(&hooks_path, GIT_HOOKS)?;
    if options.set_global_config {
        Git::of(None)
            .variables(&[("HOME", home.as_str())])
            .bytes(&["config", "--global", "core.hooksPath", &hooks_path])
            .map_err(|error| err(format!("cannot set core.hooksPath: {error}")))?;
    }
    Ok(InstallResult {
        hooks_path,
        pre_commit,
        pre_push,
        commit_msg,
        reference_transaction,
        retired,
        set_global_config: options.set_global_config,
    })
}
