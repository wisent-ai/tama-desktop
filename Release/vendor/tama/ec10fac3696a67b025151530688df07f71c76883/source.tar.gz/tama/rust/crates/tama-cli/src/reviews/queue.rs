//! `tama reviews harsh request` and `tama reviews harsh show|record --queue
//! <id>`: an author's and a reviewer session's sides of Oko's harsh-review
//! queue (`ports::harsh_review::queue`).
//!
//! An author asks for a round on what it staged without a commit attempt
//! and without messaging anyone: the candidate goes to the queue, where
//! `oko work next` hands it to a free session that did not stage it.
//!
//! The candidate of a queue entry was staged by its author, possibly in an
//! index of its own, so the reviewer reads it from the repository's objects:
//! the entry's tree over the parent it follows, and the message the author's
//! commit attempt carried. Its round is kept in the register of that parent,
//! where the author's next commit attempt reads it, and the entry is marked
//! reviewed in Oko. The author of an entry is refused as its reviewer. A
//! round recorded over the staged candidate instead (`record --message`)
//! marks every open entry that queues that candidate ([`open_for`]).

use std::path::PathBuf;

use serde_json::json;
use tama_hook_tools::ports::harsh_review::{
    candidate_patch, digest, keep, now_ms, parent, queue, register_after, reviewer_here,
    staged_tree, unquoted, Entry, Finding,
};

/// What one queue entry asks to be reviewed.
struct Candidate {
    repository: PathBuf,
    parent: String,
    tree: String,
    message: String,
    author: String,
    /// Who recorded the round Oko keeps for it, once one did.
    reviewed_by: Option<String>,
}

fn candidate(id: &str) -> Result<Candidate, String> {
    let entry = queue::entry(id)?;
    let text = |name: &str| queue::field(&entry, name).map(str::to_string);
    Ok(Candidate {
        repository: PathBuf::from(text("repository")?),
        parent: text("parent")?,
        tree: text("tree")?,
        message: text("message")?,
        author: text("author")?,
        reviewed_by: entry["reviewedBy"].as_str().map(str::to_string),
    })
}

/// The candidate of entry `id`: its message and the patch its tree makes
/// over its parent, as the reviewer reads them. An entry a round already
/// answered is refused before its patch is read: Oko keeps that first round
/// and refuses a second ([`record`]), so a reviewer that read it would spend
/// the whole round on work nobody can record.
pub(super) fn show(id: &str, as_json: bool) -> Result<String, String> {
    let read = candidate(id)?;
    if let Some(by) = &read.reviewed_by {
        return Err(format!(
            "harsh-review entry {id} was already reviewed by {by}: its round stands and a second one is refused, \
             so there is nothing left to review here; `oko work next --executor <session>` hands the next entry"
        ));
    }
    let patch = candidate_patch(&read.repository, &read.parent, &read.tree)?;
    if as_json {
        return Ok(json!({
            "id": id, "repository": read.repository, "parent": read.parent, "tree": read.tree,
            "author": read.author, "message": read.message, "patch": patch,
        })
        .to_string());
    }
    Ok(format!(
        "harsh-review entry {id}: tree {} over {} in {}, by {}\n--- message ---\n{}\n--- patch ---\n{patch}",
        read.tree,
        read.parent,
        read.repository.display(),
        read.author,
        read.message
    ))
}

/// Record the round of this session over entry `id`, with `findings` and
/// the `improvements` the change suggests, and mark the entry reviewed in
/// Oko with how many items the round names in both parts. An entry another
/// reviewer's round already answered is refused before any round is kept:
/// Oko keeps the first round, and the author no longer waits. Recording the
/// same round again (after Oko failed to mark the entry) keeps no second copy
/// and marks the entry.
pub(super) fn record(
    id: &str,
    findings: Vec<Finding>,
    improvements: Vec<Finding>,
) -> Result<String, String> {
    let read = candidate(id)?;
    let reviewer = reviewer_here()?;
    let named = queue::named(&reviewer);
    if named == read.author {
        return Err(format!(
            "entry {id} was staged by {}, who cannot review it: a round counts only from a reviewer other than \
             the author",
            reviewer.named()
        ));
    }
    if let Some(by) = read.reviewed_by.as_deref().filter(|by| *by != named) {
        return Err(format!(
            "entry {id} was already reviewed by {by}, whose round Oko keeps, so no round of {} was kept; \
             `oko work next` hands out the entries still waiting",
            reviewer.named()
        ));
    }
    let patch = candidate_patch(&read.repository, &read.parent, &read.tree)?;
    for items in [&findings, &improvements] {
        if let Some(unread) = unquoted(items, &patch, &read.message) {
            return Err(format!(
                "the item quoting {:?} quotes text found neither in entry {id}'s patch nor in its message",
                unread.quote
            ));
        }
    }
    // A tree staged on a parent HEAD has moved past must carry the commits
    // landed since, or committing it takes them back unseen in its patch.
    super::round::stale::taken_back(&read.repository, &read.parent, &read.tree, &read.message)?;
    // A round admits a commit, so it is kept only over a tree the product's
    // own declared gates (all but its test gates) pass, as `record
    // --message` keeps it.
    tama_hook_tools::programs::quality_check::staged_gates(&read.repository, &read.tree)?;
    let path = register_after(&read.repository, &read.parent)?;
    let found = findings.len();
    let suggested = improvements.len();
    let added = keep(
        &path,
        &Entry::Round {
            tree: read.tree.clone(),
            parent: Some(read.parent.clone()),
            message: digest(&read.message),
            reviewer: reviewer.clone(),
            findings,
            improvements: Some(improvements),
            at_ms: now_ms()?,
        },
    )?;
    let kept = if added {
        "recorded a round"
    } else {
        "found this very round already kept"
    };
    let marked = match read.reviewed_by {
        Some(_) => "Oko keeps its mark from this reviewer's earlier round over the entry",
        None => {
            queue::done(id, &reviewer, found + suggested).map_err(|cause| {
                format!(
                    "{kept} by {} over entry {id} in {}, but Oko did not mark the entry reviewed: {cause}; \
                     running this record again marks it and keeps no second round",
                    reviewer.named(),
                    path.display()
                )
            })?;
            "Oko marks the entry reviewed"
        }
    };
    Ok(format!(
        "{kept} by {} over entry {id} (tree {}): {found} findings, {suggested} improvements, in {}; {marked}",
        reviewer.named(),
        read.tree,
        path.display()
    ))
}

/// Queue the candidate staged in `repository` (the index `GIT_INDEX_FILE`
/// names, else its own) with the message in `message`. `item` names what the
/// commit repairs, by which the queue ranks the entry; `within_minutes`
/// declares how long a round may take, past which the entry goes to the next
/// free session that asks. The entry names the repository by its absolute
/// path: its reviewer runs in another session's working directory, where a
/// relative `.` names some other checkout or none.
pub(super) fn request(
    repository: Result<PathBuf, String>,
    message: Option<&str>,
    item: Option<&str>,
    within_minutes: Option<&str>,
) -> Result<String, String> {
    let named = repository?;
    let repository = std::fs::canonicalize(&named).map_err(|cause| {
        format!(
            "the repository {} cannot be resolved: {cause}",
            named.display()
        )
    })?;
    let message_file =
        PathBuf::from(message.ok_or("tama reviews harsh request requires --message <file>")?);
    let text = std::fs::read_to_string(&message_file)
        .map_err(|cause| format!("cannot read {}: {cause}", message_file.display()))?;
    if text.trim().is_empty() {
        return Err(format!(
            "{} holds no message; a round covers the message too",
            message_file.display()
        ));
    }
    let author = reviewer_here()?;
    let parent = parent(&repository)?;
    let tree = staged_tree(&repository)?;
    let entry = queue::enqueue(&queue::Candidate {
        repository: &repository,
        parent: &parent,
        tree: &tree,
        message_file: &message_file,
        author: &author,
        item,
        within_minutes,
    })?;
    Ok(format!(
        "queued harsh-review entry {} for tree {tree} on {parent} in {}: {}; `oko work next` hands \
         it to a free session that did not stage it",
        queue::field(&entry, "id")?,
        repository.display(),
        queue::field(&entry, "state")?
    ))
}

/// The open queue entries a round over the staged tree meets: `covered`,
/// those that queue the very candidate (the same tree over the same parent
/// with the same message, queued from a checkout whose rounds go to the
/// register this round went to); `other_message`, those of the same tree and
/// parent whose message differs, which the round does not cover; and
/// `unplaced`, those queuing the very candidate from a checkout that cannot
/// be read to tell which register keeps their rounds, each with Git's cause.
pub(super) struct Open {
    pub(super) covered: Vec<Covered>,
    pub(super) other_message: Vec<String>,
    pub(super) unplaced: Vec<String>,
}

/// An entry a round covers, with the session Oko handed it to, if any.
pub(super) struct Covered {
    pub(super) id: String,
    pub(super) holder: Option<String>,
}

/// The entries of `listing` staged by someone other than `reviewer` that a
/// round of `reviewer` over `tree` on `parent` with `message`, kept in the
/// register `here`, answers: every entry no round has reviewed yet
/// (`reviewedAt` null), waiting or assigned alike, since Oko keeps the first
/// round whoever records it. Left open, its author keeps waiting for a
/// reviewer who already answered. Fails only on a listing Oko did not shape
/// as its queue.
pub(super) fn open_for(
    listing: &serde_json::Value,
    here: &std::path::Path,
    tree: &str,
    parent: &str,
    message: &str,
    reviewer: &tama_hook_tools::ports::harsh_review::Reviewer,
) -> Result<Open, String> {
    let entries = listing["entries"].as_array().ok_or_else(|| {
        format!("Oko's harsh-review queue listing carries no entries list: {listing}")
    })?;
    let named = queue::named(reviewer);
    let reviewed = digest(message);
    let mut open = Open {
        covered: Vec::new(),
        other_message: Vec::new(),
        unplaced: Vec::new(),
    };
    for entry in entries {
        if !entry["reviewedAt"].is_null()
            || queue::field(entry, "tree")? != tree
            || queue::field(entry, "parent")? != parent
            || queue::field(entry, "author")? == named
        {
            continue;
        }
        let id = queue::field(entry, "id")?.to_string();
        let same_message = digest(queue::field(entry, "message")?) == reviewed;
        let queued_in = PathBuf::from(queue::field(entry, "repository")?);
        match (register_after(&queued_in, parent), same_message) {
            (Ok(there), _) if there != here => {}
            (Ok(_), true) => open.covered.push(Covered {
                id,
                holder: entry["reviewer"].as_str().map(str::to_string),
            }),
            (Err(cause), true) => open.unplaced.push(format!(
                "{id} (queued from {}, which cannot be read: {cause}; `tama reviews harsh record --queue {id}` \
                 records a round where it was queued)",
                queued_in.display()
            )),
            (_, false) => open.other_message.push(id),
        }
    }
    Ok(open)
}
