//! A loop over written field names that only reads those fields.
//!
//! `for (const field of ["steering", "synthetic"]) { assert(message[field]) }`
//! iterates its words, so it looked like a classifier the program keeps. It
//! is not one: every word is the name of a property of a record, and the loop
//! only selects that property, `record[field]`. No input text is compared
//! with any word, so nothing is decided by keyword. The reader proves that
//! from the structure alone — the loop binds one name to the written list,
//! and every use of that name in the loop's body is a subscript key — instead
//! of holding a list of field names it allows. A loop that compares the name,
//! passes it to a call or returns it is still a vocabulary and still refused.

use std::sync::LazyLock;

use regex::Regex;

use super::common;

/// The end of `for (const field of [`, in JavaScript and TypeScript, whatever
/// the declaration keyword: the loop's bound name.
static FOR_OF: LazyLock<Regex> =
    LazyLock::new(|| common::compile(r"^for\s*\(\s*\w+\s+(?P<bound>\w+)\s+of\s*\[\s*$"));
/// The end of `for field in [`, in Rust: the loop's bound name.
static FOR_IN: LazyLock<Regex> =
    LazyLock::new(|| common::compile(r"^for\s+(?P<bound>\w+)\s+in\s*\[\s*$"));

/// True when the run of words between `start` and `end` is the list a loop
/// iterates and the loop's body uses the bound name only as a subscript key.
pub(super) fn field_selectors(text: &str, start: usize, end: usize) -> bool {
    let before = &text[..start];
    let Some(loop_start) = before.rfind("for") else {
        return false;
    };
    let head = &before[loop_start..];
    let bound = FOR_OF
        .captures(head)
        .or_else(|| FOR_IN.captures(head))
        .and_then(|captures| captures.name("bound"))
        .map(|name| name.as_str());
    let Some(bound) = bound else {
        return false;
    };
    match body(&text[end..]) {
        Some(body) => only_subscript_keys(body, bound),
        None => false,
    }
}

/// The braced body of the loop whose list ends at the start of `after`: past
/// the list's `]`, the `)` that closes a JavaScript loop head, and the `{`.
fn body(after: &str) -> Option<&str> {
    let after = after.trim_start().strip_prefix(']')?.trim_start();
    let after = match after.strip_prefix(')') {
        Some(rest) => rest.trim_start(),
        None => after,
    };
    let inside = after.strip_prefix('{')?;
    let mut open: Vec<char> = vec!['{'];
    for (at, character) in inside.char_indices() {
        match character {
            '{' => open.push(character),
            '}' => {
                open.pop();
                if open.is_empty() {
                    return Some(&inside[..at]);
                }
            }
            _ => {}
        }
    }
    None
}

/// True when `name` occurs in `body` and every occurrence stands alone
/// between `[` and `]`, the key of a subscript.
fn only_subscript_keys(body: &str, name: &str) -> bool {
    let occurrence = common::compile(&format!(r"\b{}\b", regex::escape(name)));
    let mut uses = occurrence.find_iter(body).peekable();
    if uses.peek().is_none() {
        return false;
    }
    uses.all(|found| {
        body[..found.start()].trim_end().ends_with('[')
            && body[found.end()..].trim_start().starts_with(']')
    })
}
