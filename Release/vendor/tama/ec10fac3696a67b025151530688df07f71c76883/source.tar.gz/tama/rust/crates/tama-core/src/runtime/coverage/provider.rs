//! JS `declaredProviderCoverage(root)`: what each provider's configuration
//! claims, and how much of that its own config really installs.
//!
//! Moved verbatim out of the single runtime file; the adapter reading now
//! comes from the [`crate::runtime::adapter_config`] module.

use std::collections::{BTreeMap, HashSet};
use std::path::Path;

use serde::Serialize;
use serde_json::Value;

use crate::registry::Registry;
use crate::runtime::adapter_config::{adapter_command_index, AdapterCommandIndex};
use crate::runtime::claims::{
    claimed_runtime_specs_for_event, runtime_actually_installs_hook, RuntimeSpec,
};
use crate::runtime::load_registry;
use crate::Result;

/// One mapping row of JS `declaredProviderCoverage`: a registry event claimed
/// by a runtime, or a catalogued Git hook.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ProviderCoverageMapping {
    pub provider: String,
    pub event: String,
    pub runtime_event: String,
    pub hook_id: String,
}

/// One provider entry of JS `declaredProviderCoverage`, serialized with the
/// exact keys the JS command printed.
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ProviderCoverage {
    pub provider: String,
    pub coverage_kind: String,
    pub mapping_count: usize,
    pub hook_count: usize,
    pub event_count: usize,
    pub adapter_path: Option<String>,
    /// Mappings found in an inspected configuration. `None` means this
    /// report did not inspect that provider's configuration, not zero hooks.
    pub installed_mapping_count: Option<usize>,
    pub required_live_coverage: Option<bool>,
    pub evidence: String,
    pub note: Option<String>,
    pub mappings: Vec<ProviderCoverageMapping>,
}

const FIXED_PROVIDERS: &[&str] = &[
    "claude",
    "codex",
    "omp",
    "editor-save-guard",
    "editor-watch-session",
    "git",
    "kimi",
];

fn git_mappings(registry: &Registry, mappings: &mut Vec<ProviderCoverageMapping>) {
    let Some(git_hooks) = registry
        .extra
        .get("catalog")
        .and_then(|catalog| catalog.get("gitHooks"))
        .and_then(Value::as_array)
    else {
        return;
    };
    for hook in git_hooks {
        let Some(id) = hook.get("id").and_then(Value::as_str) else {
            continue;
        };
        // A git hook runs on the hook its id names unless it declares another.
        let event = match hook.get("event").and_then(Value::as_str) {
            Some(event) => event,
            None => id,
        };
        mappings.push(ProviderCoverageMapping {
            provider: "git".to_string(),
            event: event.to_string(),
            runtime_event: event.to_string(),
            hook_id: id.to_string(),
        });
    }
}

/// How many covered mappings the provider config installs, or the exact
/// configuration read/parse failure when it cannot be inspected.
fn installed_mapping_count(
    registry: &Registry,
    provider: &str,
    covered: &[ProviderCoverageMapping],
) -> std::result::Result<usize, String> {
    let index = adapter_command_index(registry, provider).map_err(|error| error.to_string())?;
    let mut adapter_commands: BTreeMap<String, AdapterCommandIndex> = BTreeMap::new();
    adapter_commands.insert(provider.to_string(), index);
    Ok(covered
        .iter()
        .filter(|mapping| {
            let command = registry
                .events
                .get(&mapping.event)
                .and_then(|config| config.hooks.iter().find(|hook| hook.id == mapping.hook_id))
                .and_then(|hook| hook.command.clone());
            runtime_actually_installs_hook(
                &adapter_commands,
                &RuntimeSpec {
                    runtime: provider.to_string(),
                    runtime_event: Some(mapping.runtime_event.clone()),
                },
                &mapping.hook_id,
                command.as_deref(),
                None,
            )
        })
        .count())
}

/// JS `declaredProviderCoverage(root)` with no provider filter: every
/// provider the fixed list or the mappings name, sorted byte-lexicographically
/// (identical to `.sort()` for the ASCII provider ids involved).
pub fn declared_provider_coverage(root: &Path) -> Result<Vec<ProviderCoverage>> {
    let registry = load_registry(root)?;
    let mut mappings: Vec<ProviderCoverageMapping> = Vec::new();
    for (event, config) in &registry.events {
        for hook in &config.hooks {
            for spec in claimed_runtime_specs_for_event(event, Some(&registry)) {
                // A runtime that names no event of its own runs the hook under
                // the registry event's name.
                let runtime_event = match spec.runtime_event {
                    Some(runtime_event) => runtime_event,
                    None => event.clone(),
                };
                mappings.push(ProviderCoverageMapping {
                    runtime_event,
                    provider: spec.runtime,
                    event: event.clone(),
                    hook_id: hook.id.clone(),
                });
            }
            for adapter in crate::harnesses::all() {
                if adapter.events.contains_key(event)
                    || (adapter.claude_events
                        && crate::runtime::CLAUDE_EVENTS.contains(&event.as_str()))
                {
                    mappings.push(ProviderCoverageMapping {
                        provider: adapter.id.clone(),
                        event: event.clone(),
                        runtime_event: event.clone(),
                        hook_id: hook.id.clone(),
                    });
                }
            }
        }
    }
    git_mappings(&registry, &mut mappings);

    let mut providers: Vec<String> = FIXED_PROVIDERS
        .iter()
        .map(|provider| provider.to_string())
        .collect();
    for adapter in crate::harnesses::all() {
        if !providers.contains(&adapter.id) {
            providers.push(adapter.id.clone());
        }
    }
    for mapping in &mappings {
        if !providers.contains(&mapping.provider) {
            providers.push(mapping.provider.clone());
        }
    }
    providers.sort();

    Ok(providers
        .into_iter()
        .map(|provider| {
            let covered: Vec<ProviderCoverageMapping> = mappings
                .iter()
                .filter(|mapping| mapping.provider == provider)
                .cloned()
                .collect();
            // Declared coverage says what the registry claims; this says what
            // the provider's config on this machine would actually run. An
            // install that wrote an empty block used to leave the two
            // indistinguishable here.
            let harness = crate::harnesses::by_id(&provider);
            let (installed, inspection_error) = match installed_mapping_count(&registry, &provider, &covered) {
                Ok(count) => (Some(count), None),
                Err(error) => (None, Some(error)),
            };
            let adapter = registry.adapters.get(&provider);
            ProviderCoverage {
                coverage_kind: "declared".to_string(),
                mapping_count: covered.len(),
                hook_count: covered
                    .iter()
                    .map(|mapping| mapping.hook_id.as_str())
                    .collect::<HashSet<_>>()
                    .len(),
                event_count: covered
                    .iter()
                    .map(|mapping| mapping.event.as_str())
                    .collect::<HashSet<_>>()
                    .len(),
                adapter_path: harness
                    .map(|harness| crate::runtime::adapter_config::expand_home_path(&harness.config))
                    .or_else(|| adapter.and_then(|adapter| adapter.path.clone())),
                installed_mapping_count: installed,
                required_live_coverage: adapter
                    .and_then(|adapter| adapter.extra.get("requiredLiveCoverage"))
                    .and_then(Value::as_bool),
                evidence: "Registry-declared mappings; not live execution evidence.".to_string(),
                note: match (harness, inspection_error) {
                    (Some(harness), Some(error)) => Some(format!(
                        "Native hook adapter declared from {}. Installed configuration inspection failed: {error}",
                        harness.source
                    )),
                    (Some(harness), None) => Some(format!(
                        "Native hook adapter declared from {}. Installed configuration inspected; this does not prove live enforcement.",
                        harness.source
                    )),
                    (None, error) => error,
                },
                mappings: covered,
                provider,
            }
        })
        .collect())
}
