//! Decision half of `tama hook block-fallbacks` (registry hook
//! `block-fallbacks`).
//!
//! A fallback answers a missing or failed value with one nobody stated, or
//! drops the error that says why it failed, so the failure it hides never
//! reaches the person who could fix it. The operator's rule is no fallbacks:
//! a missing value is an error that names what is missing and why. This gate
//! judges the whole file as the write leaves it — a hashline section or a
//! string edit replayed on the file, a written file's content — and refuses
//! one whose syntax tree carries a fallback construct of the file's language
//! ([`syntax`], `constructs.json`), whoever wrote it: a fallback a file
//! already held is refused on its next edit until it is removed. A write
//! whose resulting file cannot be rebuilt or judged is refused with the
//! cause, never judged by its added fragment. `tama violations find
//! --fallbacks` lists the same findings across repositories.

mod syntax;

pub use syntax::{findings, grammar_of};

use serde_json::Value;

use crate::ports::check_numeric_literals_payload::path_texts;
use crate::ports::tool_vocabulary::Call;

/// Why this write is refused, if it is: the file it leaves holds a
/// fallback, or the file it leaves cannot be rebuilt or judged.
pub fn evaluate(payload: &Value) -> Option<String> {
    let call = Call::of(payload);
    let input = call.input()?;
    let texts = match path_texts(input, call.session_cwd()) {
        Ok(texts) => texts,
        Err(error) => {
            return Some(format!(
                "block-fallbacks: BLOCKED: the file this write leaves cannot be rebuilt to judge it: {error}"
            ))
        }
    };
    let mut lines = Vec::new();
    for (path, text) in texts {
        match findings(&path, &text) {
            Ok(found) => {
                for (construct, said) in found {
                    lines.push(format!("  {path}: {construct}: {said}"));
                }
            }
            Err(error) => {
                return Some(format!(
                    "block-fallbacks: BLOCKED: {path} cannot be judged for fallbacks: {error}"
                ))
            }
        }
    }
    if lines.is_empty() {
        return None;
    }
    let rule = match syntax::rule() {
        Ok(rule) => rule,
        Err(error) => return Some(format!("block-fallbacks: BLOCKED: {error}")),
    };
    Some(format!(
        "block-fallbacks: BLOCKED: the file this write leaves holds a fallback, which answers a missing or failed value with one nobody stated or drops the error that says why:\n{}\n\
         The operator's rule: \"{rule}\"\n\
         Make the missing value an error that names what is missing, where it was looked for and why it matters \
         (a Result or a thrown error carrying that sentence and the cause it was given), so the cause reaches whoever can supply it. \
         A fallback the file already held is removed in this write, whoever wrote it. \
         The constructs are declared in block_fallbacks/constructs.json as queries over each language's syntax tree; \
         `tama violations find --fallbacks` lists every one a repository still holds.",
        lines.join("\n")
    ))
}
