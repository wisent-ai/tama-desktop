//! The transcript a session's edits end in when no running process of it
//! holds one. OMP moves a session to a new transcript named after a new id,
//! whose `session` record names the transcript it moved from as
//! `parentSession` and the session's first id as `providerPromptCacheKey`,
//! with every earlier record copied in; a later move does the same again. The
//! transcripts of one session, its own and every one moved from it, form a
//! line from the first to the newest, and the newest holds every edit. Two
//! transcripts moved from the same one branch the line, and which of them
//! holds the session's work cannot be told once its process has ended.

use std::fs::File;
use std::io::{BufRead, BufReader};
use std::path::{Path, PathBuf};

use serde_json::Value;

/// What one transcript's `session` record says.
struct Header {
    id: String,
    moved_from: Option<String>,
    first: Option<String>,
    path: PathBuf,
}

/// The newest transcript of `session`: among the transcript whose `session`
/// record is the session's and every transcript that names the session as
/// its `providerPromptCacheKey`, the one no other of them was moved from.
/// The transcript named after the session when no transcript records such a
/// session header (a harness that writes none); none when it has none at
/// all. Several such transcripts refuse, naming them.
pub(super) fn newest(session: &str) -> Result<Option<PathBuf>, String> {
    let mut headers = Vec::new();
    for root in tama_hooks::session_record::live_roots() {
        collect(&root, &mut headers)?;
    }
    let own: Vec<&Header> = headers
        .iter()
        .filter(|header| header.id == session || header.first.as_deref() == Some(session))
        .collect();
    if own.is_empty() {
        return Ok(tama_hooks::session_record::transcript_path(session));
    }
    let newest: Vec<&&Header> = own
        .iter()
        .filter(|header| {
            !own.iter()
                .any(|other| other.moved_from.as_deref() == Some(header.id.as_str()))
        })
        .collect();
    match newest.as_slice() {
        [only] => Ok(Some(only.path.clone())),
        _ => {
            let named: Vec<String> = own
                .iter()
                .map(|header| header.path.display().to_string())
                .collect();
            Err(format!(
                "session {session} was moved into transcripts that branch ({}), and no running \
                 process of it holds one, so which holds its edits cannot be told",
                named.join(", ")
            ))
        }
    }
}

/// Whether a live transcript names `session` at either end of a move: as its
/// own id with another first id, or as the first id of a transcript with
/// another id. Oko's `session moved` binding condition reads the same heads.
pub(in super::super) fn moved(session: &str) -> Result<bool, String> {
    let mut headers = Vec::new();
    for root in tama_hooks::session_record::live_roots() {
        collect(&root, &mut headers)?;
    }
    Ok(headers.iter().any(|header| {
        header
            .first
            .as_deref()
            .is_some_and(|first| first != header.id && (header.id == session || first == session))
    }))
}

/// The `session` record of every transcript below `directory`, transcript
/// artifact folders (a folder beside a transcript of its name) left
/// unentered. A folder or transcript that cannot be read refuses, naming it:
/// a transcript left out could be the session's newest.
fn collect(directory: &Path, headers: &mut Vec<Header>) -> Result<(), String> {
    let entries = match std::fs::read_dir(directory) {
        Ok(entries) => entries,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(()),
        Err(error) => {
            return Err(format!(
                "session transcripts in {} cannot be listed: {error}",
                directory.display()
            ))
        }
    };
    for entry in entries {
        let path = entry
            .map_err(|error| {
                format!(
                    "an entry of {} cannot be read: {error}",
                    directory.display()
                )
            })?
            .path();
        if path.is_dir() {
            if !path.with_extension("jsonl").is_file() {
                collect(&path, headers)?;
            }
            continue;
        }
        if path
            .extension()
            .is_some_and(|extension| extension == "jsonl")
        {
            headers.extend(header(&path)?);
        }
    }
    Ok(())
}

/// The `session` record of the transcript at `path`. OMP writes it among
/// the leading records, after the title; a record of any other kind ends
/// the search, so a transcript of a harness that writes no such record is
/// not read to its end.
fn header(path: &Path) -> Result<Option<Header>, String> {
    let shown = path.display();
    let file = File::open(path)
        .map_err(|error| format!("transcript {shown} cannot be opened: {error}"))?;
    for line in BufReader::new(file).lines() {
        let line = line.map_err(|error| format!("transcript {shown} cannot be read: {error}"))?;
        let record: Value = serde_json::from_str(&line).map_err(|error| {
            format!("transcript {shown} holds a line that is not JSON: {error}")
        })?;
        match record.get("type").and_then(Value::as_str) {
            Some("title") => continue,
            Some("session") => {
                let text =
                    |field: &str| record.get(field).and_then(Value::as_str).map(str::to_owned);
                let Some(id) = text("id") else {
                    return Err(format!(
                        "transcript {shown} has a session record without an id"
                    ));
                };
                return Ok(Some(Header {
                    id,
                    moved_from: text("parentSession"),
                    first: text("providerPromptCacheKey"),
                    path: path.to_path_buf(),
                }));
            }
            _ => return Ok(None),
        }
    }
    Ok(None)
}
