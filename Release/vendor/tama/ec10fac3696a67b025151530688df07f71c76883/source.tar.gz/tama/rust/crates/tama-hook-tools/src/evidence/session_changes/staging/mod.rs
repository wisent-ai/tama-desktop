//! Staging a session's recorded change of each path into the private index.
//!
//! A path's change is the session's whole run of edits of it, from the state
//! its first edit saw (`base`) to the state its last left (`owned`). When
//! another session later undid one of the older edits, that whole change is
//! no longer in the working file, though the newer edits are. The path is
//! then staged from the newest run of its edits whose change is still there:
//! starting from each later edit in turn (its own before-text, the file as
//! the session saw it then), the edits from there on are replayed, and the
//! first such run present in the working file is staged. Older edits another
//! session undid are superseded, never brought back; a path none of whose
//! runs is present, down to its newest edit alone, is left out with the
//! newest edit's cause.

use std::path::{Path, PathBuf};

use super::{git, transition, working_file, Change, Omitted, Report, Step};

/// Stage the change from `base` to `owned` of `path`: whether it changed the
/// index, or why it cannot be staged (it is not in the working file, Git
/// will not take it).
fn stage_run(
    transaction: &git::Transaction,
    path: &Path,
    base: Option<&str>,
    owned: Option<&str>,
) -> Result<bool, String> {
    if base == owned {
        return Ok(false);
    }
    let current = working_file(&transaction.root.join(path))?;
    let indexed = transaction.entry(path)?;
    let indexed_text = indexed.as_ref().map(|(_, text)| text.as_str());
    let candidate = transition(&transaction.area, indexed_text, base, owned, path)?;
    if candidate.as_deref() == indexed_text {
        return Ok(false);
    }
    // The delta must already exist in the actual file. A later overwrite
    // cannot be resurrected silently from historical session receipts. A
    // file the index does not hold is the session's creation: other
    // sessions' lines added to it since stand between the session's own and
    // stay unstaged, so it is present when every line it stages stands in
    // the working file in order (`within`).
    let difference = match (indexed_text, candidate.as_deref(), current.as_deref()) {
        (None, Some(created), Some(working)) => {
            if within(created, working) {
                None
            } else {
                Some("its lines no longer all stand in the working file in order".to_owned())
            }
        }
        _ => {
            let applied = transition(
                &transaction.area,
                current.as_deref(),
                indexed_text,
                candidate.as_deref(),
                path,
            )?;
            differs(applied.as_deref(), current.as_deref())?
        }
    };
    if let Some(difference) = difference {
        return Err(format!(
            "recorded changes to {} are no longer present in the working tree: {difference}",
            path.display()
        ));
    }
    match (indexed, candidate) {
        (Some((mode, _)), Some(candidate)) => transaction.replace(path, &mode, &candidate)?,
        (None, Some(candidate)) => transaction.create(path, &candidate)?,
        (Some(_), None) => transaction.remove(path)?,
        (None, None) => return Ok(false),
    }
    Ok(true)
}

/// Whether every line of `created` stands in `working` in the same order,
/// other lines allowed between them: the working file holds the session's
/// creation, with only lines added around and between its own. Matching
/// each line at its first place after the previous one finds such an order
/// whenever one exists.
fn within(created: &str, working: &str) -> bool {
    let mut lines = working.split('\n');
    created
        .split('\n')
        .all(|wanted| lines.any(|line| line == wanted))
}

/// Where carrying the change onto the working file would change it: the
/// first line at which the two differ, numbered as the diff numbers lines,
/// with both texts; none when carrying it leaves the file as it is.
fn differs(applied: Option<&str>, working: Option<&str>) -> Result<Option<String>, String> {
    let (applied, working) = match (applied, working) {
        (applied, working) if applied == working => return Ok(None),
        (Some(applied), Some(working)) => (applied, working),
        (None, _) => return Ok(Some("carrying it would delete the file".to_owned())),
        (_, None) => return Ok(Some("the working file is gone".to_owned())),
    };
    let mut carried = applied.split_inclusive('\n');
    let mut held = working.split_inclusive('\n');
    let pairs = std::iter::from_fn(|| match (carried.next(), held.next()) {
        (None, None) => None,
        pair => Some(pair),
    });
    let quoted = |line: Option<&str>| match line {
        Some(line) => format!("{:?}", line.trim_end_matches('\n')),
        None => "the end of the file".to_owned(),
    };
    for (number, (left, right)) in (super::carry::first_line()?..).zip(pairs) {
        if left != right {
            return Ok(Some(format!(
                "carrying it would make line {number} {} where the file holds {}",
                quoted(left),
                quoted(right)
            )));
        }
    }
    Ok(None)
}

/// The change the edits `run` make, replayed from the before-text of its
/// first edit: that before-text and the state the last edit leaves.
fn replayed(
    area: &Path,
    path: &Path,
    run: &[Step],
) -> Result<(Option<String>, Option<String>), String> {
    let Some((first, later)) = run.split_first() else {
        return Err(format!("{} has no edit to replay from", path.display()));
    };
    let mut owned = first.after.clone();
    for step in later {
        owned = if step.whole {
            step.after.clone()
        } else {
            transition(
                area,
                owned.as_deref(),
                step.before.as_deref(),
                step.after.as_deref(),
                path,
            )?
        };
    }
    Ok((first.before.clone(), owned))
}

/// A later run's name and the file it leaves, before and after, or why it cannot be read.
pub(super) type LaterRun<'a> = (&'a str, Result<(Option<String>, Option<String>), String>);

/// The runs of `change`'s edits tried after its whole change, oldest start
/// first: from its second edit on when its edits replay as a whole (the
/// whole change is the run from the first), from its first when they do not.
/// Each is the call it starts at and the change it makes, or why its edits
/// do not replay. A run is replayed only when it is asked for: `tama stage`
/// stops at the first run present in the working file, and the commit check
/// at the first that accounts for the staged bytes.
pub(super) fn later_runs<'a>(
    area: &'a Path,
    path: &'a Path,
    change: &'a Change,
) -> impl Iterator<Item = LaterRun<'a>> + 'a {
    let first: &'a [Step] = match (&change.conflict, change.steps.split_first()) {
        (Some(_), _) => &change.steps,
        (None, Some((_, later))) => later,
        (None, None) => &[],
    };
    std::iter::successors(Some(first), |run| run.split_first().map(|(_, after)| after)).filter_map(
        move |run| {
            run.split_first()
                .map(|(from, _)| (from.call.as_str(), replayed(area, path, run)))
        },
    )
}

/// Stage one path: its whole change when it is in the working file, else
/// the newest run of its edits that is (module doc). Whether the index
/// changed, or the newest edit's cause when no run is present. A file the
/// session created and the index does not hold has no later run: a run
/// starts from the file as the session found it then, which the index does
/// not hold, so its creation's own cause is the path's.
fn stage_one(transaction: &git::Transaction, path: &Path, change: Change) -> Result<bool, String> {
    let mut cause = match change.conflict.clone() {
        Some(cause) => cause,
        None => match stage_run(
            transaction,
            path,
            change.base.as_deref(),
            change.owned.as_deref(),
        ) {
            Ok(staged) => return Ok(staged),
            Err(cause) => cause,
        },
    };
    if change.base.is_none() && transaction.entry(path)?.is_none() {
        return Err(format!(
            "{cause}; {} is a file the session created and the index does not hold, so its later edits cannot be staged without its creation",
            path.display()
        ));
    }
    for (from, run) in later_runs(&transaction.area, path, &change) {
        let staged = run.and_then(|(base, owned)| {
            stage_run(transaction, path, base.as_deref(), owned.as_deref())
        });
        match staged {
            Ok(staged) => {
                eprintln!(
                    "stage: {} staged from its edit {from} on; the older edits are no longer in the file: {cause}",
                    path.display()
                );
                return Ok(staged);
            }
            Err(newer) => cause = newer,
        }
    }
    Err(cause)
}

/// Why staging onto the checkout's index would publish the deletion of every
/// tracked file: the index file holds no entry while `HEAD` holds files (an
/// absent index file starts from `HEAD`, `git::index`). Every path staged
/// onto it would be read against nothing, and publishing it would keep that
/// state; such an index is never a result anyone staged, so the run refuses,
/// naming the checkout and both counts, before reading any path. A
/// repository whose `HEAD` has no commit yet is staged as before.
fn emptied(transaction: &git::Transaction) -> Result<Option<String>, String> {
    let indexed = transaction.git().text(&["ls-files", "-z"])?;
    if !indexed.is_empty() || !git::born(transaction)? {
        return Ok(None);
    }
    let tracked = transaction
        .git()
        .text(&["ls-tree", "-r", "-z", "--name-only", "HEAD"])?;
    let tracked: Vec<&str> = tracked
        .split('\0')
        .filter(|path| !path.is_empty())
        .collect();
    if tracked.is_empty() {
        return Ok(None);
    }
    // An index the caller's GIT_INDEX_FILE chose is not the checkout's own,
    // so the refusal says which file was read and why before calling it
    // emptied.
    let chosen = match std::env::var_os("GIT_INDEX_FILE") {
        Some(variable) => format!(
            " (GIT_INDEX_FILE={} chose it, not the checkout's own index; unset it if that is not meant)",
            variable.to_string_lossy()
        ),
        None => String::new(),
    };
    Ok(Some(format!(
        "the index {}{chosen} of {} holds no entry while HEAD holds {} file(s), so staging onto it would stage the deletion of every tracked file; nothing was staged. Find what emptied it (another session's git command, a removed .git/index), restore it from HEAD with `git -C {} read-tree HEAD` (it holds no staged change to lose), and stage again",
        transaction.original().display(),
        transaction.root.display(),
        tracked.len(),
        transaction.root.display()
    )))
}

/// Stage every path's recorded change; a path that cannot be staged is left
/// out and named with its cause (`omitted`) while the others are staged, so
/// one file a session moved or another rewrote no longer stops the rest. An
/// index emptied of every `HEAD` entry refuses the run (`emptied`).
pub(super) fn stage_changes(
    transaction: git::Transaction,
    session: &str,
    changes: std::collections::BTreeMap<PathBuf, Change>,
    calls: Vec<String>,
    apply: bool,
) -> Result<Report, String> {
    if let Some(refusal) = emptied(&transaction)? {
        return Err(refusal);
    }
    let (mut paths, mut omitted) = (Vec::new(), Vec::new());
    for (path, change) in changes {
        match stage_one(&transaction, &path, change) {
            Ok(true) => paths.push(path),
            Ok(false) => {}
            Err(cause) => omitted.push(Omitted { path, cause }),
        }
    }
    let tree = transaction.git().text(&["write-tree"])?.trim().to_owned();
    let report = Report {
        session: session.to_owned(),
        repository: transaction.root.clone(),
        paths,
        omitted,
        calls,
        tree,
        applied: apply,
    };
    if apply {
        transaction.publish()?;
    }
    Ok(report)
}
