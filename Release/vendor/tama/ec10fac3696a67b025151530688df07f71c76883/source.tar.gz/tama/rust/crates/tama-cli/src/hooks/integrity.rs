//! `tama hooks integrity`: the two digests the installer refuses on, reported
//! instead of enforced, and naming what changed.
//!
//! The installer's refusal — "failed its integrity check" — says that a tree
//! no longer digests to its `releaseId`, not which file moved. This reads the
//! same digest the installer computes and lists every file written after the
//! seal, so tampering, a later write and a permission change can be told
//! apart. It writes nothing.

use std::path::{Path, PathBuf};
use std::time::SystemTime;

use serde_json::Value;
use tama_core::exit;

use super::package::seal::tree_digest;

const USAGE: &str = "usage: tama hooks integrity [--release <release-root>] [--home <dir>]";
/// A tree that no longer digests to its id: the check ran and failed.
const DRIFTED: i32 = exit::FAILURE;
/// A check that could not be run, told apart from a drift by its own status.
const REFUSED: i32 = exit::USAGE;
const RELEASE_MANIFEST: &str = "release.json";
const RUNTIME: &str = "Library/Application Support/Tama/hooks-runtime";

/// The word after `flag`.
fn option(argv: &[String], flag: &str) -> Option<String> {
    let mut words = argv.iter();
    words.find(|word| *word == flag)?;
    words.next().cloned()
}

/// Every file under `root` modified after `after`, as paths below `root`,
/// and every directory, entry or time that could not be read, with its
/// cause: skipped, a file written into an unreadable directory after the
/// seal would be missing from the diagnosis of a drifted release.
fn written_after(root: &Path, after: SystemTime) -> (Vec<String>, Vec<String>) {
    let mut found = Vec::new();
    let mut unread = Vec::new();
    // Each directory is held by its path below `root`, so every file found
    // is named below `root` as it is reached.
    let mut pending = vec![PathBuf::new()];
    while let Some(below) = pending.pop() {
        let directory = root.join(&below);
        let entries = match std::fs::read_dir(&directory) {
            Ok(entries) => entries,
            Err(error) => {
                unread.push(format!("{}: {error}", directory.display()));
                continue;
            }
        };
        for entry in entries {
            let entry = match entry {
                Ok(entry) => entry,
                Err(error) => {
                    unread.push(format!("an entry of {}: {error}", directory.display()));
                    continue;
                }
            };
            let path = entry.path();
            let relative = below.join(entry.file_name());
            let kind = match entry.file_type() {
                Ok(kind) => kind,
                Err(error) => {
                    unread.push(format!("{}: {error}", path.display()));
                    continue;
                }
            };
            if kind.is_dir() {
                pending.push(relative);
                continue;
            }
            match std::fs::symlink_metadata(&path).and_then(|m| m.modified()) {
                Ok(time) if time > after => found.push(relative.display().to_string()),
                Ok(_) => {}
                Err(error) => unread.push(format!("{}: {error}", path.display())),
            }
        }
    }
    found.sort();
    unread.sort();
    (found, unread)
}

/// Report one sealed release; `true` when it still digests to its id.
fn report_release(root: &Path) -> Result<bool, String> {
    let manifest_path = root.join(RELEASE_MANIFEST);
    let text = std::fs::read_to_string(&manifest_path).map_err(|error| {
        if error.kind() == std::io::ErrorKind::NotFound {
            format!("no release manifest at {}", manifest_path.display())
        } else {
            format!("cannot read {}: {error}", manifest_path.display())
        }
    })?;
    let manifest: Value = serde_json::from_str(&text)
        .map_err(|error| format!("unreadable {}: {error}", manifest_path.display()))?;
    let recorded = manifest["releaseId"].as_str().ok_or_else(|| {
        format!(
            "{} records no releaseId, so the tree has nothing to be checked against",
            manifest_path.display()
        )
    })?;
    let actual = tree_digest(root)?;
    println!("release root: {}", root.display());
    println!("recorded releaseId: {recorded}");
    println!("actual tree digest: {actual}");
    println!(
        "sealed at: {}",
        manifest["sealedAt"].as_str().unwrap_or("unrecorded")
    );
    println!(
        "source revision: {}",
        manifest["sourceRevision"].as_str().unwrap_or("unrecorded")
    );
    println!("source dirty: {}", manifest["sourceDirty"]);
    if recorded == actual {
        println!("result: intact");
        return Ok(true);
    }
    println!("result: DRIFTED");
    let sealed = match std::fs::symlink_metadata(&manifest_path).and_then(|m| m.modified()) {
        Ok(sealed) => sealed,
        Err(error) => {
            println!(
                "the seal time of {} cannot be read ({error}), so the files written after it cannot be named",
                manifest_path.display()
            );
            return Ok(false);
        }
    };
    let (later, unread) = written_after(root, sealed);
    if !unread.is_empty() {
        println!("not read, so a file written there after the seal would not be named:");
        for path in &unread {
            println!("  {path}");
        }
    }
    if later.is_empty() {
        println!(
            "no file read is newer than the seal -- the drift is a permission change, a deletion, \
             a file whose timestamp was preserved on copy, or in a path not read above"
        );
    } else {
        println!("written after the seal:");
        for path in later {
            println!("  {path}");
        }
    }
    Ok(false)
}

/// Report every installed release under `home`; `true` when all are intact.
fn report_installed(home: &Path) -> Result<bool, String> {
    let runtime = home.join(RUNTIME);
    let releases = runtime.join("releases");
    // Nothing installed is intact; releases that cannot be listed are not
    // known to be, and answering "nothing installed" passed a tree it never saw.
    let entries = match std::fs::read_dir(&releases) {
        Ok(entries) => entries,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
            println!("nothing installed under {}", runtime.display());
            return Ok(true);
        }
        Err(error) => return Err(format!("cannot list {}: {error}", releases.display())),
    };
    // No `current` link is no current release; one that cannot be read is
    // named, since the report would otherwise mark no release as current.
    let current_link = runtime.join("current");
    let current = match std::fs::read_link(&current_link) {
        Ok(target) => target.file_name().map(|name| name.to_os_string()),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => None,
        Err(error) => return Err(format!("cannot read {}: {error}", current_link.display())),
    };
    let mut installed = Vec::new();
    for entry in entries {
        let entry =
            entry.map_err(|error| format!("cannot list {}: {error}", releases.display()))?;
        installed.push(entry.path());
    }
    installed.sort();
    let mut intact = true;
    for release in installed {
        let name = release
            .file_name()
            .map(|n| n.to_os_string())
            .ok_or_else(|| format!("{} names no release", release.display()))?;
        let verdict = if tree_digest(&release)? == name.to_string_lossy() {
            "intact"
        } else {
            intact = false;
            "DRIFTED"
        };
        let marker = if current.as_ref() == Some(&name) {
            "  <- current"
        } else {
            ""
        };
        println!("{verdict}  {}{marker}", release.display());
    }
    Ok(intact)
}

/// `tama hooks integrity [--release <root>] [--home <dir>]`: exits with
/// success when every named tree still digests to its id, with failure when
/// one drifted, and with the usage status when the check was refused.
pub fn main(argv: &[String]) -> i32 {
    let release = option(argv, "--release");
    // Without --release or --home the installed releases are read under HOME;
    // one that cannot be read is named: read as empty, only the usage line
    // would say anything.
    let home = match (option(argv, "--home"), &release) {
        (Some(home), _) => Some(home),
        (None, Some(_)) => None,
        (None, None) => match std::env::var("HOME") {
            Ok(home) if !home.is_empty() => Some(home),
            Ok(_) => {
                eprintln!("HOME is empty; name the home with --home <dir>\n{USAGE}");
                return REFUSED;
            }
            Err(error) => {
                eprintln!(
                    "HOME cannot be read ({error}); name the home with --home <dir>\n{USAGE}"
                );
                return REFUSED;
            }
        },
    };
    let mut intact = true;
    if let Some(release) = release {
        match report_release(Path::new(&release)) {
            Ok(verdict) => intact &= verdict,
            Err(error) => {
                eprintln!("Tama hook release integrity refused: {error}");
                return REFUSED;
            }
        }
    }
    if let Some(home) = home.filter(|home| !home.is_empty()) {
        match report_installed(Path::new(&home)) {
            Ok(verdict) => intact &= verdict,
            Err(error) => {
                eprintln!("Tama hook release integrity refused: {error}");
                return REFUSED;
            }
        }
    }
    if intact {
        exit::SUCCESS
    } else {
        DRIFTED
    }
}
