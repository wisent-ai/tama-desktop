//! Operation dispatch and the bounded handlers: enforcement updates and
//! policy-bundle imports with their exact refusals; streamed jobs are in `jobs`.
//! Statuses are HTTP's own (`http::StatusCode`), as the module doc names them.

use std::path::Path;

use http::StatusCode;
use serde::Serialize;
use serde_json::Value;
use tama_core::install::level_plan;
use tama_core::policy_bundle::list_policy_bundles;
use tama_core::runtime::declared_provider_coverage;

use super::reply::{json_body, send_error, send_json, Reply, Request};
use crate::attestation::requests as attestation;
use crate::brama::desktop;
use crate::cli::sessions::capability;
use crate::mcp_config;

mod enforcement;
mod history;
mod policy;
mod scope;
mod standing;

type Refused = (StatusCode, String);

/// Send an answer, or the refusal with its status. An answer that cannot be
/// encoded is a failure while the operation ran, named with its cause.
fn respond<T: Serialize>(writer: &mut Reply, answer: Result<T, Refused>) {
    let encoded = answer.and_then(|value| {
        serde_json::to_value(value).map_err(|error| {
            (
                StatusCode::INTERNAL_SERVER_ERROR,
                format!("the answer could not be encoded: {error}"),
            )
        })
    });
    match encoded {
        Ok(document) => send_json(writer, StatusCode::OK.as_u16(), &document),
        Err((status, message)) => send_error(writer, status.as_u16(), &message),
    }
}

fn failed(error: impl ToString) -> Refused {
    (StatusCode::INTERNAL_SERVER_ERROR, error.to_string())
}

fn refused(error: impl ToString) -> Refused {
    (StatusCode::BAD_REQUEST, error.to_string())
}

/// The request's JSON body, or its refusal sent; `None` when it was refused.
fn body(request: &Request, writer: &mut Reply) -> Option<Value> {
    match json_body(request) {
        Ok(body) => Some(body),
        Err((status, message)) => {
            send_error(writer, status, &message);
            None
        }
    }
}

pub(super) fn dispatch(request: Request, root: &Path, writer: &mut Reply) {
    match request.operation.as_str() {
        "enforcement" => respond(writer, crate::enforcement::status(root).map_err(failed)),
        "coverage" => respond(writer, declared_provider_coverage(root).map_err(failed)),
        "install/plan" => respond(writer, Ok(level_plan(root, None, None))),
        "mcp/config" => respond(writer, mcp_config().map_err(failed)),
        "model-provider" => respond(writer, desktop::model_provider()),
        "model-provider/unset" => respond(writer, desktop::model_provider_unset()),
        "model-provider/set" => {
            if let Some(body) = body(&request, writer) {
                respond(writer, desktop::model_provider_set(&body));
            }
        }
        "attestation/list" => respond(writer, attestation::list()),
        "attestation/record" => {
            if let Some(body) = body(&request, writer) {
                respond(writer, attestation::record(&body));
            }
        }
        "attestation/show" => {
            if let Some(body) = body(&request, writer) {
                respond(writer, attestation::show(&body));
            }
        }
        "attestation/remove" => {
            if let Some(body) = body(&request, writer) {
                respond(writer, attestation::remove(&body));
            }
        }
        "attestation/standard" => {
            if let Some(body) = body(&request, writer) {
                respond(writer, attestation::standard(&body));
            }
        }
        "attestation/required" => respond(writer, Ok(attestation::required())),
        "attestation/check" => {
            if let Some(body) = body(&request, writer) {
                respond(writer, attestation::check(&body));
            }
        }
        "attestation/kinds"
        | "attestation/registries"
        | "attestation/verify"
        | "attestation/attest"
        | "attestation/revoke"
        | "attestation/attest-commit"
        | "attestation/pending"
        | "attestation/unjudged"
        | "attestation/migrate" => {
            if let Some(body) = body(&request, writer) {
                respond(writer, attestation::registry(&request.operation, &body));
            }
        }
        "judgement/show" | "judgement/attest" | "judgement/revoke" => {
            if let Some(body) = body(&request, writer) {
                respond(writer, judgement(&request.operation, &body));
            }
        }
        "calls/failed" | "calls/retry" => {
            if let Some(body) = body(&request, writer) {
                let operation = request.operation.as_str();
                respond(
                    writer,
                    tama_run_hook::calls_native(operation, &body).map_err(refused),
                );
            }
        }
        "policy-bundles" => respond(writer, list_policy_bundles(None).map_err(failed)),
        "enforcement/update" => enforcement::enforcement_update(request, root, writer),
        "hooks/warm" => hooks_warm(request, root, writer),
        "policy-bundles/import" => policy::policy_import(request, writer),
        "task-scope/show" | "task-scope/set" | "task-scope/clear" => scope::handle(request, writer),
        "standing/list" | "standing/show" | "standing/score" | "standing/withdraw" => {
            standing::handle(request, writer)
        }
        "history/rebase" => history::handle(request, writer),
        "violations/scan" => super::jobs::scan_job(request, writer),
        "violations/clean" => super::jobs::clean_job(request, root, writer),
        "worktrees/list" => super::worktrees::list(request, writer),
        "worktrees/remove" => super::worktrees::remove(request, writer),
        "copies/list" => super::copies::list(request, writer),
        "copies/remove" => super::copies::remove(request, writer),
        "contributions/pending" | "contributions/report" => {
            if let Some(body) = body(&request, writer) {
                respond(writer, contributions(&request.operation, &body));
            }
        }
        "reviews/list" | "reviews/show" | "reviews/harsh" | "reviews/admitted"
        | "reviews/cutover" => super::reviews::inspect(request, writer),
        "sessions/capability" => {
            if let Some(body) = body(&request, writer) {
                respond(writer, session_capability(capability::show_request(&body)));
            }
        }
        "sessions/capability/revoke" => {
            if let Some(body) = body(&request, writer) {
                respond(
                    writer,
                    session_capability(capability::revoke_request(&body)),
                );
            }
        }
        "stage" => {
            if let Some(body) = body(&request, writer) {
                respond(
                    writer,
                    tama_hook_tools::evidence::session_changes::interface::request(body)
                        .map_err(refused),
                );
            }
        }
        "index/repair" => {
            if let Some(body) = body(&request, writer) {
                respond(
                    writer,
                    tama_hook_tools::evidence::index_objects::request(body).map_err(refused),
                );
            }
        }
        "builds" | "builds/record" | "builds/close" => super::builds::handle(request, writer),
        "justifications/cua"
        | "justifications/cua/record"
        | "justifications/cua/remove"
        | "justifications/ssh"
        | "justifications/ssh/record"
        | "justifications/ssh/remove"
        | "justifications/record"
        | "tests/approvals"
        | "tests/approve"
        | "tests/audit"
        | "tests/restore"
        | "tests/review"
        | "tests/revoke" => super::justifications::handle(request, writer),
        "rules/digest" => respond(writer, crate::rules::digest_document().map_err(failed)),
        "rules/dismiss" => rules_dismiss(request, writer),
        other => send_error(
            writer,
            StatusCode::NOT_FOUND.as_u16(),
            &format!("unknown operation: {other}"),
        ),
    }
}

/// A session-capability answer, its refusal a bad request when the request
/// named the session or harness wrongly and a failure when the override could
/// not be changed.
fn session_capability(answer: Result<Value, capability::Refused>) -> Result<Value, Refused> {
    use capability::Refused as Capability;
    answer.map_err(|refusal| match refusal {
        Capability::Usage(said) => refused(said),
        Capability::Failed(said) => failed(said),
    })
}

/// `tama contributions pending|report` as a desktop request: a body the
/// operation cannot read is a bad request, a failure while it ran a failure,
/// each in the command's own words.
fn contributions(operation: &str, body: &Value) -> Result<Value, Refused> {
    use crate::contributions::requests::{answer, Unanswered};
    answer(operation, body).map_err(|unanswered| match unanswered {
        Unanswered::Unreadable(said) => refused(said),
        Unanswered::Failed(said) => failed(said),
    })
}

/// `tama rules dismiss --id <ID>` as a desktop request, with the command's own
/// refusal as a bad request so the screen shows the same sentence the terminal
/// does.
fn rules_dismiss(request: Request, writer: &mut Reply) {
    let Some(body) = body(&request, writer) else {
        return;
    };
    let answer = match body.get("id").and_then(Value::as_str) {
        None => Err(refused("rules/dismiss needs {\"id\": <proposal-id>}")),
        Some(id) => crate::rules::dismiss_proposal(id)
            .map(|detail| serde_json::json!({ "dismissed": id, "detail": detail }))
            .map_err(refused),
    };
    respond(writer, answer);
}

/// Warming from the screen, with the answer the command prints. A machine
/// whose gates have never run pays the operating system's first-run
/// assessment inside the next live event, where everybody waits it out; the
/// desktop needs the same way out as the terminal. An empty body, or one that
/// names no `only` list, means every hook, which is the ordinary request.
fn hooks_warm(request: Request, root: &Path, writer: &mut Reply) {
    let Some(body) = body(&request, writer) else {
        return;
    };
    let only: Vec<String> = match body.get("only").cloned() {
        None => Vec::new(),
        Some(Value::Array(ids)) => {
            match ids.iter().map(Value::as_str).collect::<Option<Vec<_>>>() {
                Some(ids) => ids.into_iter().map(str::to_string).collect(),
                None => {
                    return respond::<Value>(
                        writer,
                        Err(refused("only must contain only hook id strings")),
                    )
                }
            }
        }
        Some(other) => {
            return respond::<Value>(
                writer,
                Err(refused(format!(
                    "only must be an array of hook ids, got {other}"
                ))),
            )
        }
    };
    let answer = crate::hooks::warm::select(root, &only)
        .map(|selected| {
            crate::hooks::warm::report_value(&crate::hooks::warm::warm_hooks(root, &selected))
        })
        .map_err(refused);
    respond(writer, answer);
}

/// The local alternative is an attributed statement, never a model verdict.
fn judgement(operation: &str, body: &Value) -> Result<Value, Refused> {
    use tama_hook_tools::ports::model_judgement::Choice;
    let field = |name: &str| {
        body.get(name)
            .and_then(Value::as_str)
            .filter(|value| !value.trim().is_empty())
            .ok_or_else(|| refused(format!("{operation} needs a nonempty {name}")))
    };
    let request = Path::new(field("request")?);
    let answer = match operation {
        "judgement/show" => Choice::inspect(request),
        "judgement/attest" => Choice::attest(request, field("choice")?, field("reason")?),
        "judgement/revoke" => Choice::revoke(request),
        _ => return Err(refused(format!("unknown judgement operation: {operation}"))),
    };
    answer.map_err(|cause| refused(format!("{operation}: {cause}")))
}
