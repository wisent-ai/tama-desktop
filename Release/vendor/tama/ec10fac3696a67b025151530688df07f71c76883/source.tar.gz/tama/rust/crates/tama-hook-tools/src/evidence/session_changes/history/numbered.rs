//! An edit receipt that carries only the edit tool's numbered diff (a large
//! file's receipt keeps no `oldText`/`newText`), read back into the file it
//! left.
//!
//! The diff is one line per changed or shown line: a sign (` ` a line kept,
//! `-` a line removed, `+` a line added), the line's number right-aligned,
//! `|`, then the line's text; a kept or removed line is numbered as it stood
//! before the edit, an added one as it stands after it, counting the file's
//! lines from its first, and an empty line separates distant parts. Each
//! part is read where its kept and removed lines stand in the path's state
//! before the edit, every one of them exactly as the diff shows it: at the
//! numbers it shows, or, when lines above it moved since (another session's
//! commit now in HEAD, another session's uncommitted lines then in the
//! file), at the one nearest place after the part before it. A part whose
//! outer kept lines are another session's uncommitted lines, which the
//! session's own state does not hold, is read without the fewest of them
//! that leaves it reading at one place (`placing`). A part read nowhere, or
//! at two places equally near, means the receipt does not describe that
//! state, and the path is refused naming the part's line.

use std::path::Path;

use super::{relative, Edit};

#[path = "numbered/placing.rs"]
mod placing;
use placing::placed;

/// Resolve numbered transitions after every named author's receipts are
/// ordered together, so an edit sees the preceding co-author's actual state.
pub(in super::super) fn resolve(root: &Path, mut edits: Vec<Edit>) -> Vec<Edit> {
    let snapshots = if edits.iter().any(|edit| edit.diff.is_some()) {
        crate::evidence::edit_lease::snapshot::Reader::open(root)
    } else {
        Ok(None)
    };
    for position in 0..edits.len() {
        let (earlier, remaining) = edits.split_at_mut(position);
        let Some(edit) = remaining.first_mut() else {
            unreachable!("split before an existing receipt");
        };
        let Some(diff) = edit.diff.take() else {
            continue;
        };
        let target = root.join(&edit.path);
        let captured = match &snapshots {
            Ok(Some(reader)) => edit
                .session
                .as_deref()
                .ok_or_else(|| format!("edit {} has no recorded session identity", edit.call))
                .and_then(|session| reader.before(&edit.path, session, &edit.call)),
            Ok(None) => Ok(None),
            Err(cause) => Err(cause.clone()),
        };
        let resolved = match captured {
            Ok(Some(Some(before))) => {
                apply(&before, &diff).map(|after| (Some(before), Some(after)))
            }
            Ok(Some(None)) => Err(format!(
                "the pre-write snapshot records no file at {} before update {}",
                edit.path.display(),
                edit.call
            )),
            Ok(None) => transition(earlier, root, &target.to_string_lossy(), &diff),
            Err(cause) => Err(cause),
        };
        match resolved {
            Ok((before, after)) => {
                edit.before = before;
                edit.after = after;
            }
            Err(cause) => {
                let baseline = earlier.iter().rev().find(|prior| prior.path == edit.path);
                let baseline = match baseline {
                    Some(prior) => format!("receipt {}", prior.call),
                    None => "HEAD (no earlier receipt of this path among the named authors)".into(),
                };
                edit.refused = Some(format!(
                    "cannot reconstruct edit {} after {baseline}: {cause}",
                    edit.call
                ));
            }
        }
    }
    edits
}

/// The (before, after) of an update whose receipt keeps only the numbered
/// diff: the diff applied to the session's last known state of the path
/// (the bytes its latest earlier receipt left) or, for its first edit, to
/// what HEAD holds there. A path whose earlier receipt was refused, or that
/// an earlier receipt deleted, has no known state, and a diff whose shown
/// lines do not read so in that state does not describe it: either refuses
/// the path, naming why. A path's refusals after its first unread edit name
/// that edit and its cause once, so the cause does not grow with each edit.
pub(super) fn transition(
    edits: &[Edit],
    root: &Path,
    target: &str,
    diff: &str,
) -> Result<(Option<String>, Option<String>), String> {
    let path = relative(root, target)?;
    let mut earlier = edits.iter().rev().filter(|edit| edit.path == path);
    let before = match earlier.next() {
        Some(Edit {
            refused: Some(cause),
            call,
            ..
        }) => {
            // The first of the unread edits the latest one ends: the one
            // whose own receipt could not be read, before any that merely
            // followed it.
            let mut first = (call, cause);
            for edit in earlier {
                match &edit.refused {
                    Some(cause) => first = (&edit.call, cause),
                    None => break,
                }
            }
            let (call, cause) = first;
            return Err(format!(
                "{target} has no known state since its edit {call}: {cause}"
            ));
        }
        Some(Edit {
            after: Some(after), ..
        }) => after.clone(),
        Some(Edit { after: None, .. }) => {
            return Err(format!(
                "{target} was deleted by the session before its edit"
            ))
        }
        None => committed(root, &path)?,
    };
    let after = apply(&before, diff)
        .map_err(|cause| format!("the numbered diff of {target} does not apply: {cause}"))?;
    Ok((Some(before), Some(after)))
}

/// One line of the numbered diff.
enum Line<'a> {
    Kept(usize, &'a str),
    Removed(usize, &'a str),
    Added(usize, &'a str),
}

fn parse(line: &str) -> Result<Option<Line<'_>>, String> {
    let mut characters = line.chars();
    let Some(sign) = characters.next() else {
        return Ok(None);
    };
    let Some((number, text)) = characters.as_str().split_once('|') else {
        return Err(format!(
            "the edit's diff holds a line without its number: {line:?}"
        ));
    };
    let number: usize = number
        .trim()
        .parse()
        .map_err(|error| format!("the edit's diff numbers a line {number:?}: {error}"))?;
    match sign {
        ' ' => Ok(Some(Line::Kept(number, text))),
        '-' => Ok(Some(Line::Removed(number, text))),
        '+' => Ok(Some(Line::Added(number, text))),
        _ => Err(format!(
            "the edit's diff holds a line with no sign it writes: {line:?}"
        )),
    }
}

/// The text `diff` leaves when applied to `before`, or why `before` is not
/// the state it was taken against.
pub(super) fn apply(before: &str, diff: &str) -> Result<String, String> {
    let old: Vec<&str> = before.split('\n').collect();
    let mut new: Vec<&str> = Vec::with_capacity(old.len());
    // The lines of `old` not yet copied or removed: always a tail of it.
    let mut unread: &[&str] = &old;
    for line in placed(&old, diff)? {
        match line {
            Line::Kept(number, text) | Line::Removed(number, text) => {
                // The `number`th line is the last of the file's first `number`.
                let Some((shown, earlier)) = old.get(..number).and_then(<[&str]>::split_last)
                else {
                    return Err(format!(
                        "the edit's diff shows line {number}, which the state before it does not hold"
                    ));
                };
                let Some(between) = earlier.get(old.len() - unread.len()..) else {
                    return Err(format!(
                        "the edit's diff shows line {number} after a later one; its lines are out of order"
                    ));
                };
                if shown != &text {
                    return Err(format!(
                        "line {number} reads {shown:?} before the edit, but its diff shows {text:?}"
                    ));
                }
                new.extend_from_slice(between);
                if let Line::Kept(..) = line {
                    new.push(shown);
                }
                let Some(rest) = old.get(number..) else {
                    return Err(format!(
                        "the edit's diff shows line {number} past the file's end"
                    ));
                };
                unread = rest;
            }
            Line::Added(number, text) => {
                // The added line takes the last of the positions up to its
                // number; the old lines before it fill the rest.
                let positions: Vec<usize> = (new.len()..number).collect();
                let Some((_, gap)) = positions.split_last() else {
                    return Err(format!(
                        "the edit's diff adds line {number} where the file already has it"
                    ));
                };
                let (Some(kept), Some(rest)) = (unread.get(..gap.len()), unread.get(gap.len()..))
                else {
                    return Err(format!(
                        "the edit's diff adds line {number} past the end of the state before it"
                    ));
                };
                new.extend_from_slice(kept);
                unread = rest;
                new.push(text);
            }
        }
    }
    new.extend_from_slice(unread);
    Ok(new.join("\n"))
}

/// What `path` holds in HEAD of the checkout `root`: the state an edit of
/// it starts from when the session has no earlier receipt of it, read
/// through Tama's one Git runner ([`tama_core::git`]).
pub(super) fn committed(root: &Path, path: &Path) -> Result<String, String> {
    let object = format!("HEAD:{}", path.display());
    tama_core::git::at(root, &["show", &object])
}
