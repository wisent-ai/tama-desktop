//! Where admissions start in a repository. A commit made before review-commit
//! kept admissions has none, and no rule that a pushed commit carries one can
//! judge it; every commit made after can be judged. So the first candidate
//! review-commit admits in a repository also keeps, once, the commit at the
//! tip of every local branch then: the cutover. It is linked into place only
//! where none is kept and never rewritten, so no later session moves it, and
//! `tama reviews cutover` prints it. A commit one of those tips holds was made
//! before admissions; any other commit after them.

use std::path::{Path, PathBuf};

use serde::{Deserialize, Serialize};

/// The cutover's file in the admission register.
const NAME: &str = "cutover.json";

/// Where admissions start in one repository.
#[derive(Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Cutover {
    /// When review-commit admitted its first candidate here.
    pub at: String,
    /// The tip of every local branch then.
    pub commits: Vec<String>,
}

fn path(repository: &Path) -> Result<PathBuf, String> {
    Ok(super::directory(repository)?.join(NAME))
}

/// Keep the cutover of `repository` when none is kept. The file is written
/// beside its place and linked there, so a reader never meets half of it and
/// a second admission racing the first keeps the first one's.
pub(super) fn start(repository: &Path) -> Result<(), String> {
    let path = path(repository)?;
    if path
        .try_exists()
        .map_err(|cause| format!("cannot inspect {}: {cause}", path.display()))?
    {
        return Ok(());
    }
    let tips = super::answer(
        repository,
        &["for-each-ref", "--format=%(objectname)", "refs/heads"],
    )?;
    let cutover = Cutover {
        at: tama_core::clock::iso_now(),
        commits: tips.lines().map(str::to_owned).collect(),
    };
    let written = path.with_extension(format!("{}.json", std::process::id()));
    super::write(&written, &cutover)?;
    let linked = std::fs::hard_link(&written, &path);
    std::fs::remove_file(&written)
        .map_err(|cause| format!("cannot remove {}: {cause}", written.display()))?;
    match linked {
        Ok(()) => Ok(()),
        Err(cause) if cause.kind() == std::io::ErrorKind::AlreadyExists => Ok(()),
        Err(cause) => Err(format!(
            "cannot keep the cutover at {}: {cause}",
            path.display()
        )),
    }
}

/// The cutover of `repository`, or none while review-commit admitted no
/// candidate here.
pub fn read(repository: &Path) -> Result<Option<Cutover>, String> {
    let path = path(repository)?;
    match std::fs::read_to_string(&path) {
        Ok(text) => serde_json::from_str(&text)
            .map(Some)
            .map_err(|cause| format!("{} holds no cutover: {cause}", path.display())),
        Err(cause) if cause.kind() == std::io::ErrorKind::NotFound => Ok(None),
        Err(cause) => Err(format!("cannot read {}: {cause}", path.display())),
    }
}

impl Cutover {
    /// Whether `commit`, which the repository holds, was made after the
    /// cutover: no tip kept then holds it. A kept tip Git has since pruned
    /// holds nothing.
    pub fn followed_by(&self, repository: &Path, commit: &str) -> Result<bool, String> {
        let mut args = vec![
            "rev-list",
            "--ignore-missing",
            "--max-count=1",
            commit,
            "--not",
        ];
        args.extend(self.commits.iter().map(String::as_str));
        Ok(!super::answer(repository, &args)?.is_empty())
    }
}
