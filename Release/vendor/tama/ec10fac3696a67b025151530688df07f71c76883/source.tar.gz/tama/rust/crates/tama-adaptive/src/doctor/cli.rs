//! The adaptive doctor CLI: threshold-free state, status and repair.

use super::repair::{apply_proposal, propose};
use super::reports;
use crate::engine::load_engine;
use tama_core::exit;

/// The doctor's usage, which `tama adaptive <verb> --help` also reads.
pub const USAGE: &str = "adaptive doctor <command> [--json]

Commands:
  status [--json]                                  Per-hook tier, mode, projected state, telemetry transport
  drift [--json]                                   Live hook scripts vs repo archive content hashes
  queue [--json]                                   Queued repair requests
  repair <hook-id> [--patch-file <path>] [--json]  Draft and validate a repair proposal
  apply <proposal-dir>                             Apply a validated proposal (owner consent required)

--json prints the answer as one JSON document instead of lines.";

fn usage() -> i32 {
    eprintln!("{USAGE}");
    exit::USAGE
}

/// A repair proposal as `key: value` lines, the nested fields compact.
fn print_proposal(report: &serde_json::Value) {
    match report.as_object() {
        Some(fields) => {
            for (key, value) in fields {
                match value {
                    serde_json::Value::String(text) => println!("{key}: {text}"),
                    serde_json::Value::Null => println!("{key}: (none)"),
                    other => println!("{key}: {other}"),
                }
            }
        }
        None => println!("{report}"),
    }
}

fn run(args: &[String]) -> Result<i32, String> {
    let json_output = args.iter().any(|arg| arg == "--json");
    let args: Vec<String> = args
        .iter()
        .filter(|arg| *arg != "--json")
        .cloned()
        .collect();
    let (command, rest) = match args.split_first() {
        Some((command, rest)) => (Some(command.as_str()), rest),
        None => (None, &[][..]),
    };
    match command {
        Some("status") => reports::status(&load_engine()?, json_output),
        Some("drift") => reports::drift(json_output),
        Some("queue") => reports::queue(&load_engine()?, json_output),
        Some("repair") => {
            let hook_id = rest.first().map(String::as_str);
            match hook_id {
                None => Ok(usage()),
                Some(id) if id.starts_with("--") => Ok(usage()),
                Some(id) => {
                    // The value of `--patch-file` is the argument after it.
                    let flag = rest.iter().position(|arg| arg == "--patch-file");
                    let patch_file = match flag {
                        Some(index) => match rest[index..].split_first() {
                            Some((_, [value, ..])) => Some(value.as_str()),
                            _ => return Ok(usage()),
                        },
                        None => None,
                    };
                    let report = propose(id, patch_file)?;
                    if json_output {
                        println!("{}", tama_core::json::pretty(&report));
                    } else {
                        print_proposal(&report);
                    }
                    let ok = report.get("ok").and_then(serde_json::Value::as_bool) == Some(true);
                    Ok(if ok { exit::SUCCESS } else { exit::FAILURE })
                }
            }
        }
        Some("apply") => {
            let Some(proposal_dir) = rest.first() else {
                return Ok(usage());
            };
            apply_proposal(proposal_dir)
        }
        _ => Ok(usage()),
    }
}

/// The doctor's entry: `args` excludes the program name.
pub fn main(args: &[String]) -> i32 {
    match run(args) {
        Ok(code) => code,
        Err(error) => {
            eprintln!("doctor: {error}");
            exit::FAILURE
        }
    }
}
