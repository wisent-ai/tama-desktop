//! The Brama client: the one authenticated, provider-neutral gateway every
//! Wisent component uses for model inference.
//!
//! It lived inside `objective_reviewer` while the reviewer was its only
//! caller. `tama violations clean` is the second caller, so the client sits on its own
//! here: credentials from Skarbiec, the signed HTTPS request, a chat
//! completion, and a typed decision. Nothing in this module knows what the
//! answer is for.

mod channel;
pub mod credentials;
pub mod decision;
pub mod declared;
pub mod probe;
pub mod relay;
pub mod request;
pub mod route;

pub use probe::reachability;
pub use request::chat;
