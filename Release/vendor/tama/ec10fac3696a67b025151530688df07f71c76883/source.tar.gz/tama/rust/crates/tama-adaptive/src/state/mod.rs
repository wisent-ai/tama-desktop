//! The durable per-hook projection store, with
//! fact-journal replay, episode block persistence, and legacy quarantine.
//!
//! The fact journal is the record; a hook's projection file is its cached
//! reading. A projection that is missing, unreadable or stale is rebuilt
//! from the journal, and one that cannot be read is said as a warning. A
//! journal fact that cannot be replayed is the error naming the hook: read
//! as a fresh hook, a damaged journal restarted the hook's record unseen.

mod durable;
mod episodes;
pub mod projections;
mod update;
mod valid;

pub use episodes::{EpisodeBlockInput, EpisodeWriteResult};
pub use valid::{valid_state, TransitionResult};

use std::fs::{self, OpenOptions};
use std::io::Write;
use std::path::{Path, PathBuf};

use serde_json::Value;

pub use durable::{journal, lock};

use journal::{key_of, FactJournal};
use lock::LockStore;
pub use projections::{
    project_contested_block, project_outcome, HookState, IdentityFacts, Projection,
};

use crate::util::pretty_json_line;

const LEGACY_NAMES: &[&str] = &[
    "overrides.json",
    "provenance-pending.json",
    "numeric-provenance.json",
];
/// The three phases a hook's adaptive state moves through, named here so
/// the words exist once. They were written out again at every transition —
/// `state.phase = "enforcing".to_string()` in four places, `phase ==
/// "warning"` in three — which is a state machine spelled by hand.
pub mod phase {
    /// Watching, refusing nothing.
    pub const OBSERVING: &str = "observing";
    /// Refusing.
    pub const WARNING: &str = "warning";
    /// Refusing and counted against the hook's own record.
    pub const ENFORCING: &str = "enforcing";

    /// Every phase a stored state may name.
    pub const ALL: &[&str] = &[OBSERVING, ENFORCING, WARNING];
}

/// Shared warn sink (`warn(text)`); failures inside it are swallowed by callers.
pub type Warn = std::sync::Arc<dyn Fn(&str) + Send + Sync>;

pub struct StateStore {
    state_dir: PathBuf,
    projection_dir: PathBuf,
    tmp_dir: PathBuf,
    quarantine_dir: PathBuf,
    episode_dir: PathBuf,
    journal: FactJournal,
    locks: LockStore,
    warn: Warn,
}

/// How many facts `facts` is, as a state counts them.
fn counted(facts: &[Value], hook_id: &str) -> Result<i64, String> {
    i64::try_from(facts.len())
        .map_err(|error| format!("the fact journal of {hook_id} counts past i64: {error}"))
}

impl StateStore {
    fn path_for(&self, hook_id: &str) -> PathBuf {
        self.projection_dir
            .join(format!("{}.json", key_of(hook_id)))
    }

    /// The persisted projection when it is there and valid. One that cannot
    /// be read, parsed or validated is said as a warning naming why; the
    /// journal rebuilds it.
    fn cached(&self, hook_id: &str) -> Option<HookState> {
        let path = self.path_for(hook_id);
        let shown = path.display();
        let text = match fs::read_to_string(&path) {
            Ok(text) => text,
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => return None,
            Err(error) => {
                (self.warn)(&format!(
                    "adaptive projection {shown} cannot be read, so it is rebuilt from the journal: {error}"
                ));
                return None;
            }
        };
        let checked = serde_json::from_str::<Value>(&text)
            .map_err(|error| format!("it is not JSON: {error}"))
            .and_then(|parsed| valid_state(&parsed, hook_id));
        match checked {
            Ok(state) => Some(state),
            Err(cause) => {
                (self.warn)(&format!(
                    "adaptive projection {shown} is not used, so it is rebuilt from the journal: {cause}"
                ));
                None
            }
        }
    }

    /// `readState(hookId, requireHealthy)`. A journal that cannot be read
    /// enforces the hook, unless the caller needs it healthy; a fact that
    /// cannot be replayed is the error naming it.
    fn read_state(&self, hook_id: &str, require_healthy: bool) -> Result<HookState, String> {
        let Some(facts) = self.journal.read(hook_id) else {
            if require_healthy {
                return Err("adaptive fact journal requires repair".to_string());
            }
            let mut enforced = HookState::initial(hook_id);
            enforced.phase = phase::ENFORCING.to_string();
            return Ok(enforced);
        };
        let count = counted(&facts, hook_id)?;
        if let Some(cached) = self.cached(hook_id) {
            if cached.journal_count == count {
                return Ok(cached);
            }
        }
        let mut rebuilt = HookState::initial(hook_id);
        for fact in &facts {
            let text = |key: &str| fact.get(key).and_then(Value::as_str);
            let (Some(kind), Some(event_id), Some(tier)) = (text("kind"), text("id"), text("tier"))
            else {
                return Err(format!(
                    "a fact in the journal of {hook_id} lacks its kind, id or tier: {fact}"
                ));
            };
            let identity = identity_facts_from(fact.get("identity"), hook_id)?;
            let projection = match (kind, text("outcome")) {
                ("outcome", Some(outcome)) => {
                    project_outcome(&rebuilt, outcome, tier, &identity, event_id)
                }
                ("contested-block", _) => {
                    project_contested_block(&rebuilt, tier, &identity, event_id)
                }
                _ => {
                    return Err(format!(
                        "the journal of {hook_id} holds a fact it cannot replay: {fact}"
                    ))
                }
            };
            if projection.changed {
                rebuilt = projection.state;
            }
        }
        rebuilt.journal_count = count;
        valid_state(&rebuilt.to_value(), hook_id).map_err(|cause| {
            format!("the state rebuilt from the journal of {hook_id} is not valid: {cause}")
        })
    }

    /// `persist(hookId, state)` — write tmp with `wx`, fsync-free rename.
    fn persist(&self, hook_id: &str, state: &HookState) -> std::io::Result<()> {
        fs::create_dir_all(&self.projection_dir)?;
        fs::create_dir_all(&self.tmp_dir)?;
        let name = tama_core::random::random_uuid().map_err(std::io::Error::other)?;
        let temporary = self.tmp_dir.join(format!("projection-{name}.json"));
        {
            let mut file = OpenOptions::new()
                .write(true)
                .create_new(true)
                .open(&temporary)?;
            file.write_all(pretty_json_line(&state.to_value()).as_bytes())?;
        }
        fs::rename(&temporary, self.path_for(hook_id))?;
        Ok(())
    }

    /// `snapshot(hookId?)` — a single hook state or a map of all states, or
    /// why one of them cannot be read.
    pub fn snapshot(&self, hook_id: Option<&str>) -> Result<Value, String> {
        if let Some(hook_id) = hook_id {
            return Ok(self.read_state(hook_id, false)?.to_value());
        }
        let mut states = serde_json::Map::new();
        let directory = &self.projection_dir;
        let entries = match fs::read_dir(directory) {
            Ok(entries) => entries,
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
                return Ok(Value::Object(states));
            }
            Err(error) => return Err(format!("{} cannot be listed: {error}", directory.display())),
        };
        for entry in entries {
            let path = entry
                .map_err(|error| format!("{} cannot be listed: {error}", directory.display()))?
                .path();
            if path.extension().is_none_or(|extension| extension != "json") {
                continue;
            }
            let text = fs::read_to_string(&path)
                .map_err(|error| format!("{} cannot be read: {error}", path.display()))?;
            let parsed: Value = serde_json::from_str(&text)
                .map_err(|error| format!("{} is not JSON: {error}", path.display()))?;
            let id = parsed
                .get("hookId")
                .and_then(Value::as_str)
                .ok_or_else(|| format!("{} names no hookId", path.display()))?;
            let replayed = self.read_state(id, false)?;
            states.insert(replayed.hook_id.clone(), replayed.to_value());
        }
        Ok(Value::Object(states))
    }

    /// `quarantineLegacy()` — move legacy artifacts aside, each move said.
    pub fn quarantine_legacy(&self) {
        for name in LEGACY_NAMES {
            let source = self.state_dir.join(name);
            match tama_core::presence::present(&source) {
                Ok(false) => continue,
                Ok(true) => {}
                Err(error) => {
                    (self.warn)(&format!(
                        "legacy adaptive artifact not quarantined: {error}"
                    ));
                    continue;
                }
            }
            let moved = (|| -> std::io::Result<PathBuf> {
                fs::create_dir_all(&self.quarantine_dir)?;
                let mark = tama_core::random::random_uuid().map_err(std::io::Error::other)?;
                let target = self.quarantine_dir.join(format!("{name}-{mark}"));
                fs::rename(&source, &target)?;
                Ok(target)
            })();
            match moved {
                Ok(target) => (self.warn)(&format!(
                    "quarantined legacy adaptive artifact {name} to {}",
                    target.display()
                )),
                Err(error) => (self.warn)(&format!(
                    "legacy adaptive artifact {} could not be quarantined: {error}",
                    source.display()
                )),
            }
        }
    }
}

/// `openStateStore(stateDir, warn)`.
pub fn open_state_store(state_dir: &Path, warn: Warn) -> StateStore {
    StateStore {
        state_dir: state_dir.to_path_buf(),
        projection_dir: state_dir.join("projections"),
        tmp_dir: state_dir.join("tmp"),
        quarantine_dir: state_dir.join("quarantine"),
        episode_dir: state_dir.join("episodes"),
        journal: FactJournal::open(state_dir, warn.clone()),
        locks: LockStore::open(state_dir, warn.clone()),
        warn,
    }
}

/// The identity facts a journal fact records. A fact journaled without an
/// identity carries none; one whose identity says nothing of whether its
/// source is verifiable is the error naming the hook.
fn identity_facts_from(value: Option<&Value>, hook_id: &str) -> Result<IdentityFacts, String> {
    let Some(value) = value else {
        return Ok(IdentityFacts::default());
    };
    let verifiable = value
        .get("verifiable")
        .and_then(Value::as_bool)
        .ok_or_else(|| {
            format!(
                "a fact in the journal of {hook_id} has an identity without verifiable: {value}"
            )
        })?;
    Ok(IdentityFacts {
        verifiable,
        digest: value
            .get("digest")
            .and_then(Value::as_str)
            .map(str::to_string),
    })
}
