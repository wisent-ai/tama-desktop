//! Line numbers as editors, compilers and diagnostics print them.

/// The number of a file's first line, as diagnostics count lines:
/// https://www.gnu.org/prep/standards/html_node/Errors.html
pub const FIRST: usize = 1;

/// Each line of `content` with the number a finding on it names.
pub fn numbered(content: &str) -> impl Iterator<Item = (usize, &str)> {
    (FIRST..).zip(content.lines())
}
