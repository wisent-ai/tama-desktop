//! `tama build pending` and `tama build fail`: where pushed work waits for the
//! batched build, and what a failed batched build gives back.
//!
//! A session's work ends at a commit and a push; the build runs later, over
//! everything that accumulated. `pending` is the reader of that queue for one
//! product: the revision its last recorded build carried, the commits pushed
//! since, how many lines they change against the policy's minimum, and the
//! Oko tasks whose evidence names those commits. `fail` is the other half:
//! when the batched build of a revision fails, every task whose evidence
//! names a commit that build carried is reopened in Oko with the failure as
//! its reason, so the work is somebody's again instead of waiting nowhere.

use std::path::Path;
use std::process::Command;

use serde_json::{json, Value};

use super::intent::{option, target_of};
use super::policy;
use super::ration::{change, ledger};
use crate::gitcmd::git;

/// The branch a batched build is cut from.
const MAIN: &str = "origin/main";
/// Who Oko records as reopening a task after a failed build.
const REPORTER: &str = "tama build fail";

/// The commits after `from` up to `to`, newest first; without an earlier
/// build, only `to` itself.
fn commits(repository: &Path, from: Option<&str>, to: &str) -> Result<Vec<String>, String> {
    let range = from.map(|from| format!("{from}..{to}"));
    let said = match &range {
        Some(range) => git(repository, &["log", "--format=%H", range])?,
        None => git(repository, &["log", "-1", "--format=%H", to])?,
    };
    Ok(said.lines().map(str::to_string).collect())
}

/// The Oko tasks whose evidence names one of `commits`.
fn carried(commits: &[String]) -> Result<Vec<Value>, String> {
    if commits.is_empty() {
        return Ok(Vec::new());
    }
    let program = tama_hook_tools::assignment::rules::oko_cli();
    let mut command = Command::new(&program);
    command.args(["tasks", "carried", "--json"]);
    for commit in commits {
        command.args(["--commit", commit]);
    }
    let output = stado_wait::output(&mut command)
        .map_err(|error| format!("cannot run {program} tasks carried: {error}"))?;
    if !output.status.success() {
        return Err(format!(
            "{program} tasks carried ended with {}: {}",
            output.status,
            String::from_utf8_lossy(&output.stderr).trim()
        ));
    }
    let answer: Value = serde_json::from_slice(&output.stdout)
        .map_err(|error| format!("{program} tasks carried printed no JSON: {error}"))?;
    // Anything but a list is not Oko's answer to the question: read as no
    // task, it would say no work waits on the build when Oko has not said so.
    match answer {
        Value::Array(tasks) => Ok(tasks),
        other => Err(format!(
            "{program} tasks carried answered with something other than a list of tasks: {other}"
        )),
    }
}

/// What waits for the next build of `--target` in `--repository`.
pub(crate) fn pending(argv: &[String], home: &Path) -> Result<Value, String> {
    let target = target_of(argv)?;
    let repository = change::repository(argv)?;
    let policy = policy::load(&policy::file(home))?;
    git(&repository, &["fetch", "--quiet", "origin"])?;
    let tip = git(&repository, &["rev-parse", MAIN])?.trim().to_string();
    let built = ledger::last_revision(&ledger::file(home), &target)?;
    let waiting = match built.as_deref() {
        Some(built) if built == tip => Vec::new(),
        built => commits(&repository, built, &tip)?,
    };
    let lines = match built.as_deref() {
        Some(built) => Some(change::changed_lines(&repository, built, &tip)?),
        None => None,
    };
    // With a recorded build the changed lines decide; with none, the target
    // has never been built and any waiting commit is due.
    let due = match lines {
        Some(lines) => lines >= policy.minimum_changed_lines,
        None => !waiting.is_empty(),
    };
    Ok(json!({
        "target": target,
        "repository": repository,
        "last_built": built,
        "tip": tip,
        "commits": waiting,
        "changed_lines": lines,
        "minimum_changed_lines": policy.minimum_changed_lines,
        "due": due,
        "tasks": carried(&waiting)?,
    }))
}

/// What `tama build fail` is given: the target, the revision the failed build
/// carried and what the build answered. A missing one is a usage error.
pub(crate) fn fail_arguments(argv: &[String]) -> Result<(String, String, String), String> {
    let target = target_of(argv)?;
    let revision = option(argv, "--revision")
        .filter(|value| !value.trim().is_empty())
        .ok_or("tama build fail requires --revision <the revision the failed build carried>")?;
    let failure = option(argv, "--failure")
        .filter(|value| !value.trim().is_empty())
        .ok_or("tama build fail requires --failure <what the build answered>")?;
    Ok((target, revision, failure))
}

/// Reopens the tasks the failed build of `--revision` carried.
pub(crate) fn fail(argv: &[String], home: &Path) -> Result<Value, String> {
    let (target, revision, failure) = fail_arguments(argv)?;
    let repository = change::repository(argv)?;
    let ledger_file = ledger::file(home);
    let before = ledger::built_before(&ledger_file, &target, &revision)?;
    let carried_commits = commits(&repository, before.as_deref(), &revision)?;
    let tasks = carried(&carried_commits)?;
    let reason = format!("the batched build of {target} at {revision} failed: {failure}");
    let program = tama_hook_tools::assignment::rules::oko_cli();
    let mut reopened = Vec::new();
    let mut refused = Vec::new();
    for task in &tasks {
        let Some(id) = task["task"].as_str() else {
            refused.push(json!({
                "task": task,
                "refusal": "the carried record names no task id, so its task cannot be reopened",
            }));
            continue;
        };
        let mut command = Command::new(&program);
        command.args(["tasks", "defect", id, "--reason", &reason, "--by", REPORTER]);
        let output = stado_wait::output(&mut command)
            .map_err(|error| format!("cannot run {program} tasks defect: {error}"))?;
        if output.status.success() {
            reopened.push(json!(id));
        } else {
            refused.push(json!({
                "task": id,
                "refusal": String::from_utf8_lossy(&output.stderr).trim(),
            }));
        }
    }
    let marked = ledger::mark_failed(&ledger_file, &target, &revision, &failure)?;
    Ok(json!({
        "target": target,
        "revision": revision,
        "since": before,
        "commits": carried_commits,
        "reopened": reopened,
        "refused": refused,
        "ledger_marked": marked,
    }))
}
