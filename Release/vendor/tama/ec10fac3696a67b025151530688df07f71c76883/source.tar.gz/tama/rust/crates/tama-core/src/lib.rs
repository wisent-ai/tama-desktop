//! tama-core: registry types, catalog building/validation, install planning.

pub mod catalog;
pub mod clock;
pub mod exit;
pub mod frustration;
pub mod git;
pub mod harnesses;
pub mod install;
pub mod json;
pub mod learning_registry;
pub mod lines;
pub mod policy_bundle;
pub mod presence;
pub mod random;
pub mod registry;
pub mod runtime;
pub mod setting;

/// Shared result type for filesystem/JSON/git operations. JS throws on I/O and
/// JSON parse errors; the Rust port propagates them through this type instead.
pub type Result<T> = std::result::Result<T, Box<dyn std::error::Error>>;

/// Where `tama hooks release` records the checkout it installed from,
/// relative to the operator's home. A released binary's compiled-in paths
/// name the build tree its build deleted, so this record is how an installed
/// copy finds the registry, the hook sources and the one-session extension.
pub const INSTALLED_CHECKOUT_FILE: &str = ".tama/installed-from";

/// The mode of a file only its owner may read and write, and of a directory
/// only its owner may list, enter and change: what every private Tama file
/// (a credential, a policy index, a session's state) is written with, stated
/// here once so a change of the policy for private state reaches every writer.
/// The values are POSIX's permission bits, S_IRUSR | S_IWUSR and S_IRWXU:
// https://pubs.opengroup.org/onlinepubs/9699919799/basedefs/sys_stat.h.html
pub const OWNER_ONLY_FILE: u32 = 0o600;
// https://pubs.opengroup.org/onlinepubs/9699919799/basedefs/sys_stat.h.html
pub const OWNER_ONLY_DIR: u32 = 0o700;

/// The operator's home, read from HOME. Every per-user Tama file (registry,
/// ledgers, releases, transcripts) lives under it. Without HOME there is no
/// home to read: answering `/`, `.` or an empty path made hooks read another
/// directory's absence as nothing to enforce, so this stops and names the
/// variable instead.
pub fn home_dir() -> std::path::PathBuf {
    std::env::var_os("HOME")
        .filter(|home| !home.is_empty())
        .map(std::path::PathBuf::from)
        .expect("HOME is not set, so per-user Tama state cannot be located")
}

/// The path the environment variable `name` declares, when it is set to
/// something. Read as bytes, so a path that is not Unicode is the one used:
/// read with `std::env::var`, it would be taken for unset and the default
/// path would stand in for the one the operator named.
pub fn path_variable(name: &str) -> Option<std::path::PathBuf> {
    std::env::var_os(name)
        .filter(|value| !value.is_empty())
        .map(std::path::PathBuf::from)
}

/// The path `variable` moves one of Oko's registers to, as Oko's
/// `store::moved` reads it: text trimmed, a path that is not Unicode kept
/// whole, an empty or blank value read as none.
pub fn oko_moved(variable: &str) -> Option<std::path::PathBuf> {
    let raw = std::env::var_os(variable)?;
    let path = match raw.to_str() {
        Some(text) => std::path::PathBuf::from(text.trim()),
        None => std::path::PathBuf::from(raw),
    };
    (!path.as_os_str().is_empty()).then_some(path)
}

/// What separates a harness's prefix from the session key Oko names a
/// session's records and rulings by.
const OKO_SESSION_KEY: char = '_';

/// The key Oko names `session` by (its `tasks::session_key`): the id after
/// a harness's prefix, or the whole id when it carries none. Every Tama
/// reader of an Oko record keyed by session compares by this one rule.
pub fn oko_session_key(session: &str) -> &str {
    match session.rsplit_once(OKO_SESSION_KEY) {
        Some((_, key)) => key,
        None => session,
    }
}

/// Where Oko keeps its register `name`, read as Oko's own `store::location`
/// reads it, so Tama and Oko address the same file: the path `variable`
/// moves it to, else `~/Library/Application Support/Oko/<name>` under an
/// absolute HOME. A HOME that cannot be read or is not absolute is the
/// error, as it is to Oko.
pub fn oko_register(variable: &str, name: &str) -> std::result::Result<std::path::PathBuf, String> {
    if let Some(path) = oko_moved(variable) {
        return Ok(path);
    }
    let home = std::env::var("HOME")
        .map(std::path::PathBuf::from)
        .map_err(|error| {
            format!("Oko's register {name} cannot be located because HOME cannot be read: {error}")
        })?;
    if !home.is_absolute() {
        return Err(format!(
            "Oko's register {name} cannot be located because HOME is {:?}, not an absolute path",
            home.display().to_string()
        ));
    }
    Ok(home.join("Library/Application Support/Oko").join(name))
}

/// A register Oko keeps beside its defect register, read as Oko's
/// `defects::register::beside` reads it: where `variable` moves it, else
/// `<defect register>.<extension>` when `OKO_DEFECT_REGISTER` moved the
/// defect register, else where [`oko_register`] keeps `name`.
pub fn oko_register_beside(
    variable: &str,
    extension: &str,
    name: &str,
) -> std::result::Result<std::path::PathBuf, String> {
    if let Some(path) = oko_moved(variable) {
        return Ok(path);
    }
    if let Some(defects) = oko_moved("OKO_DEFECT_REGISTER") {
        return Ok(defects.with_extension(extension));
    }
    oko_register(variable, name)
}

/// The variable that names another hook registry for one process, as the
/// journeys under tests/ and a hook dispatched for another home set it.
pub const HOOK_REGISTRY_VARIABLE: &str = "AGENT_HOOK_REGISTRY";

/// The hook registry every Tama program reads: the one
/// [`HOOK_REGISTRY_VARIABLE`] names, or the operator's own under
/// `~/.shared-hooks`, where `tama hooks` writes it.
pub fn hook_registry() -> std::path::PathBuf {
    match path_variable(HOOK_REGISTRY_VARIABLE) {
        Some(path) => path,
        None => home_dir().join(".shared-hooks").join("registry.json"),
    }
}

/// The checkout the installed release recorded, when it still holds a
/// registry. No record is no installed checkout. A record that cannot be
/// read, that names a checkout without a registry, or whose registry cannot
/// be examined, is said on stderr with the path and cause: answered as none
/// in silence, an installed copy would fall back to a build tree its release
/// deleted and refuse with a message about the registry instead of the
/// record.
pub fn installed_checkout() -> Option<std::path::PathBuf> {
    let home = home_dir();
    let record = home.join(INSTALLED_CHECKOUT_FILE);
    let recorded = match std::fs::read_to_string(&record) {
        Ok(recorded) => recorded,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return None,
        Err(error) => {
            eprintln!(
                "tama: the installed checkout record {} cannot be read: {error}",
                record.display()
            );
            return None;
        }
    };
    let root = std::path::PathBuf::from(recorded.trim());
    let registry = root.join("shared-hooks/registry.json");
    match presence::present(&registry) {
        Ok(true) if registry.is_file() => return Some(root),
        Ok(_) => eprintln!(
            "tama: the installed checkout record {} names {}, which holds no {}",
            record.display(),
            root.display(),
            registry.display()
        ),
        Err(error) => eprintln!(
            "tama: the installed checkout record {} names {}, whose registry {error}",
            record.display(),
            root.display()
        ),
    }
    None
}

/// The Tama checkout on this machine, if there is one: the one `TAMA_ROOT`
/// names, the one the installed release recorded ([`installed_checkout`]),
/// else the tree this program was built in while it still holds a registry.
/// An installed program is built in a tree its release deletes, so none of
/// them is no checkout, never that deleted tree; a tree that cannot be
/// examined is the error.
pub fn found_checkout() -> std::result::Result<Option<std::path::PathBuf>, String> {
    if let Some(root) = path_variable("TAMA_ROOT") {
        return Ok(Some(root));
    }
    if let Some(root) = installed_checkout() {
        return Ok(Some(root));
    }
    let built =
        catalog::normalize_path(&std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../../.."));
    match presence::present(&built.join("shared-hooks/registry.json")) {
        Ok(true) => Ok(Some(built)),
        Ok(false) => Ok(None),
        Err(error) => Err(format!(
            "the tree this program was built in, {}, cannot be examined: {error}",
            built.display()
        )),
    }
}

/// The Tama checkout a program reads its sources from ([`found_checkout`]),
/// or the refusal naming each place it was looked for.
pub fn checkout() -> std::result::Result<std::path::PathBuf, String> {
    found_checkout()?.ok_or_else(|| {
        format!(
            "no Tama checkout: TAMA_ROOT is unset, {} records none that holds a registry, and the tree this program was built in, {}, no longer holds one; set TAMA_ROOT to the Tama checkout",
            home_dir().join(INSTALLED_CHECKOUT_FILE).display(),
            std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../../..").display()
        )
    })
}

/// What a panic said, when it said it as text: the cause a joined thread's
/// failure carries, which a caller names instead of only saying it panicked.
pub fn panic_text(payload: &(dyn std::any::Any + Send)) -> String {
    match (
        payload.downcast_ref::<&str>(),
        payload.downcast_ref::<String>(),
    ) {
        (Some(text), _) => (*text).to_string(),
        (_, Some(text)) => text.clone(),
        (None, None) => "a panic whose payload is not text".to_string(),
    }
}

pub(crate) fn err(msg: impl Into<String>) -> Box<dyn std::error::Error> {
    std::io::Error::other(msg.into()).into()
}
