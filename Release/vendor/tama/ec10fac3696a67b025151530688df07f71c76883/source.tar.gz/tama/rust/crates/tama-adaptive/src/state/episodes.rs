//! Episode blocks: the causal record a block leaves for the session it
//! happened in, and the read that consumes the latest episode's blocks. The
//! per-hook projections are kept by the state module itself.

use std::fs::{self, OpenOptions};
use std::io::Write;
use std::path::PathBuf;

use serde_json::Value;

use super::{key_of, StateStore};
use crate::util::{js_truthy, pretty_json_line};

/// Input to `record_episode_block` (JS observation object).
#[derive(Debug, Clone, Default)]
pub struct EpisodeBlockInput {
    pub session_id: Option<String>,
    pub episode_id: Option<String>,
    pub hook_id: Option<String>,
    pub reason: Option<String>,
}

/// Whether an episode block was kept, and why not when it was not.
#[derive(Debug, Clone)]
pub struct EpisodeWriteResult {
    pub persisted: bool,
    pub reason: Option<String>,
}

impl StateStore {
    fn episode_path(&self, session_id: &str) -> PathBuf {
        self.episode_dir
            .join(format!("{}.json", key_of(session_id)))
    }

    /// Run `action` holding the session's episode lock, or say why the lock
    /// could not be taken.
    fn with_episode_lock<T>(
        &self,
        session_id: &str,
        action: impl FnOnce() -> Result<T, String>,
    ) -> Result<T, String> {
        let ownership = self
            .locks
            .acquire(&format!("episode-{}", key_of(session_id)))
            .map_err(|error| format!("adaptive episode lock could not be taken: {error}"))?;
        let result = action();
        self.locks.release(Some(ownership));
        result
    }

    /// The blocks the episode file at `path` holds; a missing file holds
    /// none, and one that cannot be read or is not a list is the error.
    fn episode_blocks(path: &std::path::Path) -> Result<Vec<Value>, String> {
        let text = match fs::read_to_string(path) {
            Ok(text) => text,
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(Vec::new()),
            Err(error) => return Err(format!("cannot read {}: {error}", path.display())),
        };
        match serde_json::from_str::<Value>(&text) {
            Ok(Value::Array(blocks)) => Ok(blocks),
            Ok(_) => Err(format!("{} is not a list of blocks", path.display())),
            Err(error) => Err(format!("{} is not JSON: {error}", path.display())),
        }
    }

    /// `recordEpisodeBlock(value)` — appends a causal block record. A block
    /// that could not be kept answers why, as its result's reason.
    pub fn record_episode_block(&self, value: &EpisodeBlockInput) -> EpisodeWriteResult {
        let named = |field: &Option<String>| field.clone().filter(|text| !text.is_empty());
        let (Some(session_id), Some(hook_id)) = (named(&value.session_id), named(&value.hook_id))
        else {
            return EpisodeWriteResult {
                persisted: false,
                reason: Some("missing-causal-identity".to_string()),
            };
        };
        let kept = self.with_episode_lock(&session_id, || {
            fs::create_dir_all(&self.episode_dir).map_err(|e| e.to_string())?;
            // Only a missing episode starts empty: appending to one that
            // could not be read or parsed would replace its blocks.
            let path = self.episode_path(&session_id);
            let mut blocks = Self::episode_blocks(&path)?;
            blocks.push(serde_json::json!({
                "id": tama_core::random::random_uuid()?,
                "hookId": hook_id,
                "episodeId": value.episode_id,
                "reason": value.reason,
            }));
            fs::create_dir_all(&self.tmp_dir).map_err(|e| e.to_string())?;
            let name = tama_core::random::random_uuid()?;
            let temporary = self.tmp_dir.join(format!("episode-{name}.json"));
            {
                let mut file = OpenOptions::new()
                    .write(true)
                    .create_new(true)
                    .open(&temporary)
                    .map_err(|e| e.to_string())?;
                file.write_all(pretty_json_line(&Value::Array(blocks)).as_bytes())
                    .map_err(|e| e.to_string())?;
            }
            fs::rename(&temporary, &path).map_err(|e| e.to_string())
        });
        match kept {
            Ok(()) => EpisodeWriteResult {
                persisted: true,
                reason: None,
            },
            Err(cause) => {
                (self.warn)(&format!("adaptive episode persistence failed: {cause}"));
                EpisodeWriteResult {
                    persisted: false,
                    reason: Some(cause),
                }
            }
        }
    }

    /// `consumeLatestEpisodeBlocks(sessionId)` — reads and removes the
    /// episode file, returning only blocks of the latest episode. One that
    /// cannot be read is kept and named, and gives no blocks this time:
    /// deleting it lost the episode's blocks for good.
    pub fn consume_latest_episode_blocks(&self, session_id: Option<&str>) -> Vec<Value> {
        let Some(id) = session_id.filter(|id| !id.is_empty()) else {
            return Vec::new();
        };
        let consumed = self.with_episode_lock(id, || {
            let path = self.episode_path(id);
            let blocks = Self::episode_blocks(&path)?;
            if blocks.is_empty() {
                return Ok(blocks);
            }
            if let Err(error) = fs::remove_file(&path) {
                (self.warn)(&format!(
                    "adaptive episode consumed but not removed: {}: {error}",
                    path.display()
                ));
            }
            // JS: `blocks[blocks.length - 1].episodeId` is `undefined` (not
            // null) when the key is missing or the entry is not an object;
            // `None` models `undefined` here.
            let latest_episode_id: Option<Value> =
                blocks.last().and_then(|b| b.get("episodeId")).cloned();
            Ok(blocks
                .into_iter()
                .filter(|block| {
                    js_truthy(block) && block.get("episodeId").cloned() == latest_episode_id
                })
                .collect())
        });
        match consumed {
            Ok(blocks) => blocks,
            Err(cause) => {
                (self.warn)(&format!("adaptive episode not consumed, kept: {cause}"));
                Vec::new()
            }
        }
    }
}
