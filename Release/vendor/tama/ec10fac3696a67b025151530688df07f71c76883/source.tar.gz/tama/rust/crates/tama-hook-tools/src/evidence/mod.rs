//! Where a recorded run keeps its evidence, and what the commits a session
//! made earned it; the checks read both from here.

pub mod admission;
pub mod commit_standing;
pub mod edit_lease;
pub mod history;
pub mod index_objects;
pub mod root;
pub mod session_changes;

pub use root::{evidence_dir, evidence_root, EVIDENCE_PATH_SEGMENT, EVIDENCE_SEGMENT};
