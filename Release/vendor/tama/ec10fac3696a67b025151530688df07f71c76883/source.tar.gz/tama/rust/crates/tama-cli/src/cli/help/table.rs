//! The one table of `tama`'s commands: the name dispatch matches, the lines
//! the usage summary prints for it, the usage its group writes for its own
//! verbs, and the entry that runs it. A command added here has its dispatch,
//! its summary line and its verb help at once; two tables kept apart let a
//! group reach dispatch with no help until someone remembered the other.

use std::path::Path;
use std::process::ExitCode;

use super::entries as run;

/// How a command runs.
pub(crate) enum Entry {
    /// A former program of its own (a hook, the hook engine, the MCP
    /// server): it runs inside tool calls, before the checkout is looked for
    /// and before the pipe disposition changes, and reads nothing the
    /// checkout decides.
    Program(fn(&[String]) -> ExitCode),
    /// An operator's command, given the whole command line and the checkout.
    Command(fn(&[String], &Path) -> ExitCode),
}

pub(crate) struct Command {
    pub(crate) name: &'static str,
    /// The command's lines in the usage summary; none for a command the
    /// summary leaves out on purpose.
    pub(crate) summary: Option<&'static str>,
    /// The usage the group writes for its own verbs, where the summary
    /// lists the group without them.
    pub(crate) own_usage: Option<&'static str>,
    pub(crate) entry: Entry,
}

const fn program(
    name: &'static str,
    summary: Option<&'static str>,
    entry: fn(&[String]) -> ExitCode,
) -> Command {
    Command {
        name,
        summary,
        own_usage: None,
        entry: Entry::Program(entry),
    }
}

const fn command(
    name: &'static str,
    summary: &'static str,
    own_usage: Option<&'static str>,
    entry: fn(&[String], &Path) -> ExitCode,
) -> Command {
    Command {
        name,
        summary: Some(summary),
        own_usage,
        entry: Entry::Command(entry),
    }
}

/// The command `name` names, when there is one.
pub(crate) fn find(name: &str) -> Option<&'static Command> {
    COMMANDS.iter().find(|command| command.name == name)
}

pub(crate) const COMMANDS: &[Command] = &[
    program("hook", None, run::hook),
    program("owned-hook", None, run::owned_hook),
    command("list", "  list [--json]              List hooks from the catalog", None, run::list),
    program("run-hook", None, run::run_hook),
    command("show", "  show <hook-id> [--json]    Show one hook", None, run::show),
    command("validate", "  validate [--json]          Validate catalog/source archive", None, run::validate),
    command("install", "  install plan [--json]      Show runtime scopes and target paths
  install                    Install user-global Git dispatchers; use --set-git-config to write Git config", None, run::install),
    command("uninstall", "  uninstall                  Remove the managed Git dispatchers and put back what they displaced; --unset-git-config clears core.hooksPath", None, run::uninstall),
    command("onboarding", "  onboarding [--reset] [--policy-bundle <dir>] [--replace] [--home <path>]
                             Show first use and optionally import an inactive policy bundle", None, run::onboarding),
    command("policy", "  policy import --source <dir> [--replace] [--json] [--home <path>]
                             Validate and persist an inactive policy bundle
  policy list [--json] [--home <path>]
                             List imported policy bundles and source identities
  policy remove --source <path|key> [--json] [--home <path>]
                             Remove one imported inactive policy bundle from the store", None, run::policy),
    command("justify", "  justify <record|show|remove|list> [--file <path>] [--justification <text>] [--kind file] [--expires-at <iso>] [--home <path>] [--json]
                             Record, read or remove a justification the authorization gates require", None, run::justify),
    command("rules", "  rules <list|remove|digest|dismiss> [--id <id>] [--json]
                             Read drafted rules; digest groups contested hooks and unresolved
                             corrections from Oko with evidence and source errors. Removing a rule
                             or dismissing a proposal needs DEVICE_HOOK_EDIT_APPROVED=1", None, run::rules),
    command("build", "  build <record|list|close> --kind build|restart --target <name> [--reason <text>] [--revision <rev>]
                             [--minutes N] [--home <path>] [--json]
                             Write or read the build and restart registry that
                             block-unregistered-build-or-restart reads before a build or a restart runs", None, run::build),
    Command {
        name: "mcp",
        summary: Some("  mcp config                 Print MCP server config snippet; `tama mcp` alone is the server"),
        own_usage: None,
        entry: Entry::Program(run::mcp),
    },
    command("violations", "  violations find (--repo <path> | --tree <dir> | --owner <gh-owner> | --me) [...] [--json]
                             Report existing hook rule violations in repositories (first hit per file)
  violations clean (same targets) [--rule size|all] [--model <brama-route>] --max-rounds N [--skip <fragment>] [--dry-run]
                             Ask Brama for one patch per repo to fix violations, apply it, then re-scan
  violations root (--repo <path> | --tree <dir>) [--apply] [--tidy] [--commit] [--push] [--withdraw] [--json]
                             Declare, or with --withdraw take back, a repository root whose files are all fixed there by a tool", None, run::violations),
    command("vocabulary", "  vocabulary report --repo <path> [--repo <path>...] [--json]
                             Every keyword list still in a repository, grouped by its words, the most
                             repeated set first; writes nothing", None, run::vocabulary),
    command("format", super::table_text::FORMAT, Some(tama_hook_tools::programs::check_rust_format::fold::cli::USAGE), run::format),
    command("history", super::table_text::HISTORY, Some(tama_hook_tools::programs::check_rust_format::rebase::cli::USAGE), run::history),
    command("standing", "  standing <list|show|score|withdraw|location> [...] [--json]
                             Each agent session's commit standing: a point earned for a commit whose
                             files are in their formatter's form, one lost for one out of it; below zero its tool calls
                             are refused. score --repository --range charges commits made before
                             scoring; withdraw <id> --reason takes a charge back", Some(tama_hook_tools::evidence::commit_standing::cli::USAGE), run::standing),
    command("session", "  session handover --path P --from A --to B | leases [--repository PATH] [--json]
                             Pass one session's uncommitted edits of a file to another, and read who holds
                             which file", Some(tama_hook_tools::evidence::edit_lease::cli::USAGE), run::session),
    command("model", "  model [show | set --origin URL --model MODEL < KEY | set --none | unset | check] [--json]
                             Which model service Tama asks: Brama, an OpenAI-compatible service
                             whose API key is read from standard input, or none; check asks it
                             whether it accepts this machine's credential", None, run::model_provider),
    command("sessions", "  sessions [--json] [--home <path>]  Show every live agent session and its hook state
  sessions self [--json]     The agent session this command runs under: the one OMP names when a record
                             carries it or its parentSession chain reaches the recorded agent process
                             this command runs under, else that process's one session; or none with the
                             processes walked. `via` says which: record, parentSession, process
  sessions reload --session <ID> [--json]
                             Reload the installed JavaScript adapter in that same OMP process;
                             require its loaded-digest receipt, refuse unsupported older entries
  sessions capability <show|revoke> --session <ID> --agent <omp|claude|codex> [--json]
                             Read, or withdraw at once, the capability granted to one session;
                             the gates stop admitting it immediately
  sessions remind (--session <ID> | --default) [--text <SENTENCE> | --clear] [--json]
                             Set, clear or show the sentence put after every tool result: a
                             session's own always, the default one while Oko holds open work", None, run::sessions),
    command("hooks", "  hooks <declare|undeclare|release> [...]
                             Add, change or withdraw a hook: declare --file <declaration.json> writes
                             the catalogue entry, the registry binding and the seal; undeclare --file
                             takes the same declaration back out and removes it; release builds the
                             native hooks from origin/main, installs the changed ones and installs
                             the live release. All three need the owner's consent: his word in
                             the conversation, recorded as the session capability
                             {\"tool\": \"tama\", \"actions\": [\"hook-edit\"]}, or DEVICE_HOOK_EDIT_APPROVED=1.", Some(crate::hooks::USAGE), run::hooks),
    command("enforcement", "  enforcement <command> [...] Configure machine hook selection: status|only|add|remove|all", Some(crate::enforcement::USAGE), run::enforcement),
    command("task", "  task scope <command> [...] What the operator's current instruction touches: show|set|clear.
                             `set --session ID --repository NAME…` copies the captured prompt and
                             binds the declaration to it; block-off-task-work reads it.", None, run::task),
    command("tests", super::table_text::TESTS, Some(tama_hook_tools::ports::block_unapproved_tests::approvals::USAGE), run::tests),
    command("commands", super::table_text::COMMANDS_JUDGE, None, run::commands),
    command("judgement", super::table_text::JUDGEMENT_ASK, None, run::judgement),
    command("calls", super::table_text::CALLS, None, run::calls),
    command("assignment", super::table_text::ASSIGNMENT, None, run::assignment),
    command("attestation", super::table_text::ATTESTATION, None, run::attestation),
    command("provider", super::table_text::PROVIDER, None, run::provider),
    command("request", super::table_text::REQUEST, None, run::request),
    command("doctor", super::table_text::DOCTOR, None, run::doctor),
    command("adaptive", super::table_text::ADAPTIVE, Some(tama_adaptive::doctor::cli::USAGE), run::adaptive),
    command("worktrees", super::table_text::WORKTREES, Some(crate::worktrees::USAGE), run::worktrees),
    command("copies", super::table_text::COPIES, Some(crate::copies::USAGE), run::copies),
    command("contributions", super::table_text::CONTRIBUTIONS, None, run::contributions),
    command("reviews", super::table_text::REVIEWS, None, run::reviews),
    command("stage", super::table_text::STAGE, Some(tama_hook_tools::evidence::session_changes::interface::USAGE), run::stage),
    command("index", super::table_text::INDEX, Some(tama_hook_tools::evidence::index_objects::USAGE), run::index),
    // Reached from `tama run-hook`, which spawns `<current exe>
    // adaptive-bridge`; left out of the summary on purpose.
    Command { name: "adaptive-bridge", summary: None, own_usage: None, entry: Entry::Command(run::adaptive_bridge) },
];
