//! The install as one transaction: every write backed up first, the runtime
//! link switched, disabled entrypoints restored, the OMP adapter registered
//! and `installed.json` written — and on any failure all of it put back.

use std::collections::BTreeSet;
use std::path::{Path, PathBuf};

use serde_json::{json, Value};

use super::entrypoints::{omp_config, register_omp_adapter};
use super::writes::Writes;

mod transaction;

use transaction::{present, remove, Transaction};

pub(super) const INSTALLED_SCHEMA: &str = "ai.wisent.tama.installed-hook-release.v1";

pub(super) struct Plan<'a> {
    pub runtime_root: &'a Path,
    pub installed_release: &'a Path,
    pub writes: &'a Writes,
    pub obsolete: &'a BTreeSet<PathBuf>,
    pub moved: &'a [(PathBuf, PathBuf)],
    pub home: &'a Path,
    pub record: Value,
}

pub(super) fn apply_install(plan: Plan) -> Result<Value, String> {
    let current = plan.runtime_root.join("current");
    let mut transaction = Transaction::new(
        plan.runtime_root
            .join(format!("transaction-{}", std::process::id())),
    )?;
    let mut previous_link = None;
    let mut omp_undo = None;
    let result = (|| -> Result<Value, String> {
        let home = plan.home;
        let retired = [
            home.join(".omp/agent/hooks/pre/shared-hooks.js"),
            home.join(".omp/agent/hooks.tama-disabled/pre/shared-hooks.js"),
            home.join("Library/Application Support/Tama/vscode-resume"),
            home.join(".vscode/extensions/tama.emergency-resume-1.0.0"),
        ];
        for path in plan.obsolete.iter().chain(retired.iter()) {
            if present(path)? {
                transaction.delete(path)?;
            }
        }
        for (path, (data, mode)) in plan.writes {
            transaction.write(path, data, *mode)?;
        }
        match std::fs::symlink_metadata(&current) {
            Ok(m) if m.file_type().is_symlink() => {
                previous_link = Some(std::fs::read_link(&current).map_err(|error| {
                    format!(
                        "cannot read where the Tama runtime link {} points, so it could not be restored: {error}",
                        current.display()
                    )
                })?)
            }
            Ok(_) => {
                return Err(format!(
                    "Tama runtime current path is not a symlink: {}",
                    current.display()
                ))
            }
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
            Err(error) => {
                return Err(format!(
                    "cannot read the Tama runtime link {}: {error}",
                    current.display()
                ))
            }
        }
        let temporary = plan
            .runtime_root
            .join(format!(".current-{}", std::process::id()));
        remove(&temporary)?;
        std::os::unix::fs::symlink(plan.installed_release, &temporary).map_err(|error| {
            format!(
                "cannot link {} to {}: {error}",
                temporary.display(),
                plan.installed_release.display()
            )
        })?;
        std::fs::rename(&temporary, &current).map_err(|error| {
            format!(
                "cannot switch the Tama runtime link {} to {}: {error}",
                current.display(),
                plan.installed_release.display()
            )
        })?;
        for (source, disabled) in plan.moved {
            transaction.restore(disabled, source)?;
        }
        omp_undo = register_omp_adapter(home, &home.join(".shared-hooks/omp-shared-hooks.js"))?;
        let mut record = plan.record.clone();
        record["schema"] = json!(INSTALLED_SCHEMA);
        record["installedAt"] = json!(tama_core::clock::iso_now());
        record["okoAnnouncer"] = super::entrypoints::announcer::name_in_oko();
        record["attestationLedger"] = match crate::attestation::migrate() {
            Ok(brought) => brought,
            Err(cause) => {
                eprintln!("tama: the attestation ledger was not brought up to date with the registries: {cause}");
                json!({ "cause": cause })
            }
        };
        let text = format!(
            "{}\n",
            serde_json::to_string_pretty(&record).map_err(|error| format!(
                "cannot encode the install record for {}: {error}",
                plan.runtime_root.join("installed.json").display()
            ))?
        );
        transaction.write(
            &plan.runtime_root.join("installed.json"),
            text.as_bytes(),
            tama_core::OWNER_ONLY_FILE,
        )?;
        Ok(record)
    })();
    if let Err(error) = &result {
        let mut failed: Vec<String> = Vec::new();
        if let Some((omp, previous)) = &omp_undo {
            if let Err(undo) = omp_config(
                omp,
                plan.home,
                &["set", "extensions", &previous.to_string()],
            ) {
                failed.push(format!("restore the omp extensions setting: {undo}"));
            }
        }
        failed.extend(transaction.rollback());
        match &previous_link {
            None => {
                if let Err(error) = remove(&current) {
                    failed.push(error);
                }
            }
            Some(link) => {
                let replacement = plan
                    .runtime_root
                    .join(format!(".current-rollback-{}", std::process::id()));
                if let Err(error) = remove(&replacement) {
                    failed.push(error);
                }
                let relinked = std::os::unix::fs::symlink(link, &replacement)
                    .and_then(|()| std::fs::rename(&replacement, &current));
                if let Err(relink) = relinked {
                    failed.push(format!(
                        "point {} back at {}: {relink}",
                        current.display(),
                        link.display()
                    ));
                }
            }
        }
        if !failed.is_empty() {
            return Err(format!(
                "{error}; the install could not be rolled back fully ({}); the backups are kept in {}",
                failed.join("; "),
                transaction.backup_root.display()
            ));
        }
        if let Err(cleanup) = std::fs::remove_dir_all(&transaction.backup_root) {
            return Err(format!(
                "{error}; the install was rolled back, but its backups {} could not be removed: {cleanup}",
                transaction.backup_root.display()
            ));
        }
        return result;
    }
    // The install itself succeeded; its leftover backups are said, not
    // turned into a failure of what was installed.
    if let Err(cleanup) = std::fs::remove_dir_all(&transaction.backup_root) {
        eprintln!(
            "tama hooks install: installed, but its backups {} could not be removed: {cleanup}",
            transaction.backup_root.display()
        );
    }
    result
}
