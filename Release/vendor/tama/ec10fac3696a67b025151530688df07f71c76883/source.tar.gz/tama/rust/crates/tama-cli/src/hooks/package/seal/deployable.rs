//! How a sealed release names the checkout its hooks are read from: the
//! declared spelling when one is declared, else the build's checkout under
//! `$HOME`, so the installer's rewrite table and its source check read the
//! same spelling on every machine.

use std::path::{Path, PathBuf};

use serde_json::{json, Value};
use tama_hook_tools::registry::registry_checksum;

use super::super::{load_object, write_json};

/// The checkout the installed hooks read, spelled with `$HOME`.
const DEPLOY_CHECKOUT_ENV: &str = "TAMA_DEPLOY_CHECKOUT";

/// The checkout spelling the release is declared to use, none when it is not
/// declared. A declaration that is not text is refused: read as none, the
/// release would name the build machine's checkout instead of the declared
/// one.
pub(super) fn declared_checkout() -> Result<Option<String>, String> {
    match std::env::var(DEPLOY_CHECKOUT_ENV) {
        Ok(declared) if !declared.is_empty() => Ok(Some(declared)),
        Ok(_) | Err(std::env::VarError::NotPresent) => Ok(None),
        Err(error) => Err(format!("{DEPLOY_CHECKOUT_ENV} cannot be read: {error}")),
    }
}

/// Every relative `source` restated under `prefix`, at any depth.
fn deployable_sources(value: &mut Value, prefix: &str) {
    match value {
        Value::Object(object) => {
            for (key, item) in object.iter_mut() {
                match item {
                    Value::String(text)
                        if key == "source"
                            && !text.is_empty()
                            && !text.starts_with(['/', '$', '~']) =>
                    {
                        *text = format!("{prefix}/{text}");
                    }
                    _ => deployable_sources(item, prefix),
                }
            }
        }
        Value::Array(items) => items
            .iter_mut()
            .for_each(|item| deployable_sources(item, prefix)),
        _ => {}
    }
}

/// Name the checkout in the release registry with `$HOME`, so the installer's
/// rewrite table and its source check read the same spelling.
pub(super) fn state_the_deployable_root(root: &Path, source_root: &Path) -> Result<Value, String> {
    let path = root.join("shared-hooks/registry.json");
    let mut registry = load_object(&path)?;
    // Read as the empty path, an unset HOME is a prefix of every path, and the
    // release would name every hook source `$HOME/<absolute path>`.
    let home = std::env::var("HOME").map(PathBuf::from).map_err(|error| {
        format!("HOME cannot be read, so the release cannot name the checkout: {error}")
    })?;
    let checkout = std::fs::canonicalize(source_root).map_err(|error| {
        format!(
            "the checkout {} cannot be resolved, so the release cannot name it: {error}",
            source_root.display()
        )
    })?;
    let prefix = match declared_checkout()? {
        Some(declared) => declared,
        None => match checkout.strip_prefix(&home) {
            Ok(relative) if checkout != home => format!("$HOME/{}", relative.display()),
            _ => checkout.display().to_string(),
        },
    };
    deployable_sources(&mut registry, &prefix);
    registry["catalog"]["maintainedIn"] = json!(format!("{prefix}/shared-hooks/registry.json"));
    registry["catalogChecksum"] = json!(registry_checksum(&registry));
    write_json(&path, &registry)?;
    Ok(registry)
}
