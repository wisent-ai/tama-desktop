//! Decision half of `tama hook block-hidden-subcommands` (registry hook
//! `block-hidden-subcommands`).
//!
//! A command-line entry point added for one incident — hidden from help,
//! named by joining a verb with a qualifier (`install-local`,
//! `free-port-local`), or kept as an alias after its replacement exists — is
//! a one-off call dressed as a command: it has no docs page, no GUI
//! counterpart and a second spelling of a verb, and every caller that
//! learns it makes the next rename harder. The operator's rule is that a
//! command is a general primitive over one kind of object, and a replaced
//! command goes in the same change. This gate judges the whole file as the
//! write leaves it — a hashline section or a string edit replayed on the
//! file, a written file's content — and refuses one that carries such a
//! construct of the file's CLI library (`constructs.json`), whoever wrote
//! it: an entry point a file already held is refused on its next edit until
//! it is folded away. A write whose resulting file cannot be rebuilt is
//! refused with the cause, never judged by its added fragment.
//!
//! A hyphen clap derives is caught too: a variant of a `Subcommand` enum
//! whose CamelCase name has more than one word and no `name` attribute is
//! given a hyphen-joined name by clap's kebab-casing ([`derived`]).

mod derived;

use std::sync::LazyLock;

use regex::Regex;
use serde::Deserialize;
use serde_json::Value;

use crate::ports::check_numeric_literals_payload::path_texts;
use crate::ports::tool_vocabulary::Call;

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Construct {
    extension: String,
    pattern: String,
    name: String,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Declared {
    #[allow(dead_code)]
    why: String,
    constructs: Vec<Construct>,
}

struct Compiled {
    extension: String,
    pattern: Regex,
    name: String,
}

static CONSTRUCTS: LazyLock<Vec<Compiled>> = LazyLock::new(|| {
    let declared: Declared = serde_json::from_str(include_str!("constructs.json"))
        .expect("block_hidden_subcommands/constructs.json is the gate's own data and must parse");
    declared
        .constructs
        .into_iter()
        .map(|construct| Compiled {
            pattern: Regex::new(&construct.pattern)
                .expect("every constructs.json pattern compiles"),
            extension: construct.extension,
            name: construct.name,
        })
        .collect()
});

fn extension(path: &str) -> Option<&str> {
    let name = path.rsplit('/').next()?;
    name.rsplit_once('.').map(|(_, extension)| extension)
}

/// Every one-off entry point `text`, the file at `path` as the write leaves
/// it, declares: (construct, the line). A Rust file is also read for the
/// clap variants whose names derive a hyphen without spelling one
/// ([`derived`]).
pub fn findings(path: &str, text: &str) -> Vec<(String, String)> {
    let Some(extension) = extension(path) else {
        return Vec::new();
    };
    let mut found = Vec::new();
    for line in text.lines() {
        for construct in CONSTRUCTS
            .iter()
            .filter(|construct| construct.extension == extension)
        {
            if construct.pattern.is_match(line) {
                found.push((construct.name.clone(), line.trim().to_string()));
            }
        }
    }
    if extension == "rs" {
        found.extend(
            derived::findings(text)
                .into_iter()
                .map(|line| (derived::CONSTRUCT.to_string(), line)),
        );
    }
    found
}

/// Why this write is refused, if it is: the file it leaves declares a
/// one-off entry point, or the file it leaves cannot be rebuilt to judge it.
pub fn evaluate(payload: &Value) -> Option<String> {
    let call = Call::of(payload);
    let input = call.input()?;
    let texts = match path_texts(input, call.session_cwd()) {
        Ok(texts) => texts,
        Err(error) => {
            return Some(format!(
                "block-hidden-subcommands: BLOCKED: the file this write leaves cannot be rebuilt to judge it: {error}"
            ))
        }
    };
    let mut lines = Vec::new();
    for (path, text) in texts {
        for (construct, said) in findings(&path, &text) {
            lines.push(format!("  {path}: {construct}: {said}"));
        }
    }
    if lines.is_empty() {
        return None;
    }
    Some(format!(
        "block-hidden-subcommands: BLOCKED: the file this write leaves declares a command-line entry point shaped for one incident, whoever wrote it:\n{}\n\
         Add the operation as a visible verb of the object it acts on (`release local install`, not \
         `release install-local`; `host port free`, not `host free-port-local`), with its docs page, GUI \
         counterpart and tests, and move every caller of an old name to it in the same change instead of \
         keeping the old name hidden or as an alias. The constructs are declared in \
         block_hidden_subcommands/constructs.json.",
        lines.join("\n")
    ))
}
