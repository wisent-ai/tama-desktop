//! Logic for `tama hook block-foreign-language-reply`, registry hook id
//! `block-foreign-language-reply`.
//!
//! A Stop gate: the operator is answered in his own language. When he
//! writes Polish, an answer in English is refused.
//!
//! No word list and no model decide which language a text is in; the
//! alphabet does. English is written in ASCII letters alone, and Polish (as
//! every language spelled with letters beyond ASCII) cannot be written at
//! any length without them. So:
//!
//! - the operator writes in such a language when a word of his own messages
//!   in his session carries a letter beyond ASCII (he often types without
//!   them, but not in every message of a session);
//! - the answer is in it when a word of its prose does. Prose is what the
//!   agent wrote itself ([`prose`]): fenced code, code spans, tokens that hold
//!   anything but letters, and every line the operator wrote himself (his
//!   own sentence repeated back) are left out.
//!
//! An answer whose prose has words and none of them carries such a letter,
//! to an operator whose words do, is refused. A subagent's session, whose
//! answers go to its supervisor, is not judged; an operator who never used
//! such a letter is not judged either. A transcript that cannot be read
//! refuses nothing and says so on stderr.

mod prose;

use serde_json::Value;
use tama_hooks::session_record::{deny, read_payload};

use crate::objective_reviewer::stop::ending_answer;
use crate::ports::operator_grant;

pub const HOOK_ID: &str = "block-foreign-language-reply";

/// The refusal for the answer the turn in `payload` ends with, `None` when
/// it is in the operator's language or his language cannot be read.
pub fn check(payload: &Value) -> Option<String> {
    let messages = operator_grant::operator_messages(payload)?;
    if !messages
        .iter()
        .flat_map(|message| prose::words(message))
        .any(|word| prose::beyond_ascii(&word))
    {
        return None;
    }
    let answer = match ending_answer(payload) {
        Ok(answer) => answer,
        Err(cause) => {
            eprintln!("{HOOK_ID}: the answer cannot be read: {cause}");
            return None;
        }
    };
    let own = prose::own_lines(&answer, &messages);
    let words = prose::words(&own);
    if words.is_empty() || words.iter().any(|word| prose::beyond_ascii(word)) {
        return None;
    }
    Some(format!(
        "{HOOK_ID}: BLOCKED: this answer is not written in the operator's language: his words \
         carry letters beyond ASCII and none of the {} words the answer writes itself has one, \
         so it answers in another language than his (English to a man who writes Polish). Write \
         it again in the language of his messages, in plain human sentences; code, paths and \
         names stay as they are.",
        words.len()
    ))
}

pub fn run() {
    let payload = read_payload();
    if let Some(refusal) = check(&payload) {
        deny(refusal);
    }
}
