//! Hook adapters for the coding-agent harnesses Tama wires besides Claude
//! Code, Codex and OMP (`harnesses.json`): where each keeps its hooks, how a
//! registry event becomes its event, how its payload becomes the Claude Code
//! payload every hook reads, and how a decision reaches it. The harness ids
//! are the runtime ids Oko and Transcript Lake use.

pub(crate) mod installed;
mod render;

pub use render::{merged_toml, render, TOML_BEGIN, TOML_END};

use std::collections::BTreeMap;
use std::path::{Path, PathBuf};
use std::sync::LazyLock;

use serde::Deserialize;
use serde_json::{json, Value};

/// How a harness's file holds its hooks.
#[derive(Clone, Copy, Debug, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "kebab-case")]
pub enum Shape {
    SettingsHooks,
    EventMap,
    CursorFlat,
    CopilotFlat,
    WindsurfFlat,
    KimiToml,
}

/// How a decision reaches a harness.
#[derive(Clone, Copy, Debug, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "kebab-case")]
pub enum Protocol {
    ExitStderr,
    ExitStderrContext,
    ExitStderrHookContext,
    ExitStderrNestedContext,
    ExitStderrDroidContext,
    Claude,
    CursorPermission,
    CopilotPermission,
}

/// The harness event and tool matcher one registry event becomes.
#[derive(Debug, Deserialize)]
pub struct Target {
    pub key: String,
    pub matcher: Option<String>,
}

/// The Claude Code payload built for an event whose payload names no tool.
#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Synthesis {
    pub tool_name: String,
    pub input: BTreeMap<String, String>,
    pub cwd: Option<String>,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Adapter {
    pub id: String,
    pub display: String,
    pub presence: String,
    pub config: String,
    pub shape: Shape,
    #[serde(default)]
    pub jsonc: bool,
    pub cwd_env: Option<String>,
    #[serde(default)]
    pub claude_events: bool,
    pub events: BTreeMap<String, Target>,
    #[serde(default)]
    pub tool_names: BTreeMap<String, String>,
    #[serde(default)]
    pub event_payloads: BTreeMap<String, Synthesis>,
    pub decision: Protocol,
    pub source: String,
}

#[derive(Deserialize)]
struct Declared {
    adapters: Vec<Adapter>,
}

static ADAPTERS: LazyLock<Vec<Adapter>> = LazyLock::new(|| {
    serde_json::from_str::<Declared>(include_str!("harnesses.json"))
        .expect("harnesses.json is the declared harness hook adapters")
        .adapters
});

/// Every declared adapter, in the declaration's order.
pub fn all() -> &'static [Adapter] {
    &ADAPTERS
}

/// The adapter of harness `id`.
pub fn by_id(id: &str) -> Option<&'static Adapter> {
    ADAPTERS.iter().find(|adapter| adapter.id == id)
}

fn under(template: &str, home: &Path) -> PathBuf {
    PathBuf::from(template.replace("$HOME", &home.to_string_lossy()))
}

impl Adapter {
    /// The path whose existence means the harness is on this machine.
    pub fn presence_path(&self, home: &Path) -> PathBuf {
        under(&self.presence, home)
    }

    /// The user-level file that holds the harness's hooks.
    pub fn config_path(&self, home: &Path) -> PathBuf {
        under(&self.config, home)
    }

    /// Read the native configuration with its declared syntax.
    pub fn read_config(&self, path: &Path) -> Result<Value, String> {
        installed::read(self, path)
    }

    /// Whether the harness is on this machine. A presence path that cannot be
    /// examined is the error: read as absent, the harness was installed
    /// without its hooks and nothing said so.
    pub fn present(&self, home: &Path) -> std::io::Result<bool> {
        crate::presence::present(&self.presence_path(home))
    }
}

fn at<'a>(value: &'a Value, path: &str) -> Option<&'a Value> {
    path.split('.').try_fold(value, |node, key| node.get(key))
}

/// The Claude Code payload the hooks read, built from what `provider`'s
/// harness sent for registry `event`; none for a provider without an adapter.
pub fn canonical_payload(
    provider: &str,
    event: &str,
    payload: &Value,
) -> Result<Option<Value>, String> {
    let Some(adapter) = by_id(provider) else {
        return Ok(None);
    };
    let mut canonical = payload.clone();
    let object = canonical.as_object_mut().ok_or_else(|| {
        format!("{provider} hook {event}: expected an object payload, observed {payload}")
    })?;
    if let Some(variable) = &adapter.cwd_env {
        let cwd = std::env::var(variable).map_err(|error| {
            format!(
                "{provider} hook {event}: cannot read native project directory {variable}: {error}"
            )
        })?;
        if cwd.is_empty() {
            return Err(format!(
                "{provider} hook {event}: native project directory {variable} is empty"
            ));
        }
        object.insert("cwd".into(), Value::String(cwd));
    }
    if provider == "devin" {
        devin_input(object, event)?;
    }
    if let Some(synthesis) = adapter.event_payloads.get(event) {
        let input: serde_json::Map<String, Value> = synthesis
            .input
            .iter()
            .map(|(field, path)| match at(payload, path) {
                None => Err(format!(
                    "{provider} hook {event}: missing required payload field {path} for {field}"
                )),
                Some(Value::Null) => Err(format!(
                    "{provider} hook {event}: required payload field {path} for {field} is null"
                )),
                Some(found) => Ok((field.clone(), found.clone())),
            })
            .collect::<Result<_, _>>()?;
        object.insert("tool_name".into(), json!(synthesis.tool_name));
        object.insert("tool_input".into(), Value::Object(input));
        if let Some(cwd) = synthesis.cwd.as_deref().and_then(|path| at(payload, path)) {
            object.insert("cwd".into(), cwd.clone());
        }
        return Ok(Some(canonical));
    }
    if event.starts_with("pre_tool_use:") || event.starts_with("post_tool_use:") {
        match object.get("tool_name") {
            Some(Value::String(name)) if !name.is_empty() => {}
            observed => {
                return Err(format!(
                "{provider} hook {event}: expected nonempty string tool_name, observed {observed:?}"
            ))
            }
        }
        match object.get("tool_input") {
            Some(Value::Object(_)) => {}
            observed => {
                return Err(format!(
                    "{provider} hook {event}: expected object tool_input, observed {observed:?}"
                ))
            }
        }
    }
    let renamed = object
        .get("tool_name")
        .and_then(Value::as_str)
        .and_then(|name| adapter.tool_names.get(name))
        .cloned();
    if let Some(name) = renamed {
        object.insert("tool_name".into(), json!(name));
    }
    Ok(Some(canonical))
}

pub mod decision;

/// Devin's native tool schema uses `workdir` and `raw_patch`.
fn devin_input(object: &mut serde_json::Map<String, Value>, event: &str) -> Result<(), String> {
    match object.get("tool_name").and_then(Value::as_str) {
        Some("exec") => {
            if let Some(workdir) = object
                .get("tool_input")
                .and_then(|input| input.get("workdir"))
            {
                match workdir {
                    Value::Null => {}
                    Value::String(path) if !path.is_empty() => {
                        object.insert("cwd".into(), workdir.clone());
                    }
                    _ => return Err(format!(
                        "devin hook {event}: expected nonempty string tool_input.workdir, observed {workdir}"
                    )),
                }
            }
        }
        Some("apply_patch") => {
            let input = object.get_mut("tool_input").ok_or_else(|| {
                format!("devin hook {event}: missing required tool_input for apply_patch")
            })?;
            let patch = match input {
                Value::String(text) => Value::String(std::mem::take(text)),
                Value::Object(fields) => fields.remove("raw_patch").ok_or_else(|| {
                    format!("devin hook {event}: missing required tool_input.raw_patch for apply_patch")
                })?,
                observed => return Err(format!(
                    "devin hook {event}: expected patch string or object tool_input, observed {observed}"
                )),
            };
            if !patch.is_string() {
                return Err(format!(
                    "devin hook {event}: expected string tool_input.raw_patch, observed {patch}"
                ));
            }
            let mut fields = serde_json::Map::new();
            fields.insert("patch".into(), patch);
            *input = Value::Object(fields);
        }
        _ => {}
    }
    Ok(())
}
