//! The hosts one command line reaches, read from the words a shell would run:
//! split out of `block_unauthorized_ssh/mod.rs` to keep it inside the
//! 300-line limit.

use std::collections::BTreeSet;

use super::{contains_ssh_command, targets, SSH_OPTIONS_WITH_VALUE};
use crate::ports::python_stdlib;

/// Shell words that end one command and start the next: an unquoted remote
/// command an `ssh` carries runs up to the first of them.
const COMMAND_SEPARATORS: &[&str] = &[";", "&&", "||", "|", "&"];
/// The same separators written onto the end of a word (`'remote command';`),
/// which ends the remote command after that word.
const SEPARATOR_ENDINGS: &[char] = &[';', '&', '|'];

/// The client that runs the words after its destination on the remote host.
/// scp, sftp and rsync name remote specs among their own operands instead.
const REMOTE_SHELL_PROGRAM: &str = "ssh";
/// The client whose operands are files, local or scp-style remote specs: its
/// first operand is a source file, not a host, so its hosts are its specs.
const COPY_PROGRAM: &str = "scp";

/// The SSH client program a shell word runs, lowercased, when it is one.
fn transport_program(token: &str) -> Option<String> {
    // The program is an SSH transport by the one pattern the detect module
    // reads every command with; this gate keeps no copy of it.
    let binary = token.rsplit('/').next()?.to_lowercase();
    contains_ssh_command(&binary).then_some(binary)
}

/// Where the destination of the transport at `index` stands: the first word
/// after the program that is neither an option nor an option's value;
/// `-o Foo host` steps over `-o` and `Foo` together.
fn destination(tokens: &[String], index: usize) -> Option<usize> {
    let mut arguments = tokens.iter().enumerate().skip(index);
    // The program itself.
    arguments.next();
    while let Some((position, candidate)) = arguments.next() {
        let candidate = candidate.as_str();
        if SSH_OPTIONS_WITH_VALUE.contains(&candidate) {
            arguments.next();
            continue;
        }
        if candidate.starts_with('-') {
            continue;
        }
        return Some(position);
    }
    None
}

/// `command_targets`: every host this command line would reach — from URLs,
/// from scp-style remote specs, and from the destination of every `ssh` and
/// `sftp`. The words an `ssh` runs on the remote host are that host's
/// command, not hosts of their own: `lsof -iTCP:8895` there names a port, so
/// remote specs are read from every word except those.
pub fn command_targets(command: &str) -> BTreeSet<String> {
    let mut found = targets::targets_from_urls(&targets::ssh_urls(command));
    let tokens = python_stdlib::shell_tokens(command);
    let mut remote_command = vec![false; tokens.len()];
    for (index, token) in tokens.iter().enumerate() {
        let Some(program) = transport_program(token) else {
            continue;
        };
        let Some(at) = destination(&tokens, index) else {
            continue;
        };
        if program != COPY_PROGRAM {
            if let Some(target) = targets::canonical_target(&tokens[at]) {
                found.insert(target);
            }
        }
        if program != REMOTE_SHELL_PROGRAM {
            continue;
        }
        for (position, word) in tokens.iter().enumerate().skip(at) {
            if position == at {
                continue;
            }
            if COMMAND_SEPARATORS.contains(&word.as_str()) {
                break;
            }
            remote_command[position] = true;
            if word.ends_with(SEPARATOR_ENDINGS) {
                break;
            }
        }
    }
    for (token, remote) in tokens.iter().zip(&remote_command) {
        if *remote {
            continue;
        }
        for captured in targets::REMOTE_SPEC_RE.captures_iter(token) {
            let Some(spec) = captured.name("spec") else {
                continue;
            };
            if let Some(target) = targets::canonical_target(spec.as_str()) {
                found.insert(target);
            }
        }
    }
    found
}
