//! The session's own build attestation, required before every build,
//! compile, format or test the gate reads, ahead of the operator's
//! admission: a document recorded with `tama attestation record --file FILE
//! --session ID` whose `"standard"` is `"build"`, attesting each claim of
//! `standards/build.json` in the agent's own words at the operator's word
//! minimum — the build is not marginal. Whether open work holds the build is
//! not attested here: it is Oko's one admission decision (`oko admit build`),
//! read from the operator's rulings, so a ruling that admits a session's
//! build is never contradicted by a copy of his policy kept in Tama. A build
//! it admits spends it, so the next build needs its own.

use super::super::vocabulary::BANNER;
use crate::ports::task_attestation::subject::Subject;

/// Why `name`, run in `session`, may not start: the session holds no build
/// attestation that stands, or it cannot be read.
pub(crate) fn refusal(name: &str, session: &str) -> Option<String> {
    let refused = match Subject::build(session).and_then(|subject| subject.refusal()) {
        Ok(None) => return None,
        Ok(Some(refused)) => refused,
        Err(cause) => format!("the session's build attestation cannot be read: {cause}"),
    };
    Some(format!(
        "{BANNER}`{name}` builds, compiles, formats or tests, and no build attestation of this \
         session admits it: {refused}. Each build needs its own, attesting that building is not \
         marginal; whether open work holds it is Oko's admission (`oko admit build`)."
    ))
}

/// Spend the session's build attestation on the build the gate admitted.
pub(crate) fn spend(session: &str) -> Result<(), String> {
    Subject::build(session)
        .and_then(|subject| subject.remove())
        .map(|_| ())
        .map_err(|cause| {
            format!(
                "{BANNER}the build was admitted, but its build attestation cannot be spent: {cause}"
            )
        })
}
