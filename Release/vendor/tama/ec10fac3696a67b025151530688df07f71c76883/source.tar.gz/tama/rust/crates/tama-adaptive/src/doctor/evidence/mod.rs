//! The doctor's evidence: a validated, immutable projection read by its
//! queue and repair commands.
//!
//! Evidence comes from two places: the segments the lake has committed, and
//! the closed segments still waiting for it. Either one that cannot be read
//! as intact is an error naming it: evidence left out in silence made the
//! repair queue and the replay corpus disagree with what was recorded.

mod lake;

use lake::read_lake_evidence;

use std::path::Path;

use serde_json::{Map, Value};

use crate::segments::index::{ready_segments, validate_segment};
use crate::util::{home_dir, shell_words};
use tama_core::catalog::fs_scan::names_interpreter;

/// The telemetry rows that are evidence for a repair.
const EVIDENCE_TYPES: &[&str] = &["repair_proposal", "corpus_add", "corpus_label"];

/// `liveScriptPath(command)`: the script the command runs, the first shell
/// word, `~` and `$HOME` expanded, that is a path to a file starting with
/// the `#!` line naming its interpreter. Only a word holding a path
/// separator is looked up: a bare word is found by the shell on `PATH`, or
/// by an interpreter in the directory the hook runs in, neither of which is
/// the directory drift runs in, so reading it here would judge whatever
/// file of that name drift's own directory holds. A path that names no file
/// is not the script; a file that cannot be read is the error, naming it,
/// since the drift it would be compared for cannot be told without it.
pub fn live_script_path(command: &str) -> Result<Option<String>, String> {
    let home = home_dir().to_string_lossy().into_owned();
    for word in shell_words(command) {
        let token = expand_home_word(&word, &home);
        if !token.contains(std::path::MAIN_SEPARATOR) {
            continue;
        }
        match std::fs::metadata(&token) {
            Ok(found) if found.is_file() => {
                if names_interpreter(&token).map_err(|error| error.to_string())? {
                    return Ok(Some(token));
                }
            }
            Ok(_) => {}
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
            Err(error) => {
                return Err(format!(
                    "cannot tell whether {token} is the script the hook command runs: {error}"
                ))
            }
        }
    }
    Ok(None)
}

/// `word` with `$HOME` and a leading `~` the way a shell expands them.
fn expand_home_word(word: &str, home: &str) -> String {
    let word = word.replace("$HOME", home);
    match word.strip_prefix('~') {
        Some(rest) if rest.is_empty() || rest.starts_with('/') => format!("{home}{rest}"),
        _ => word,
    }
}

/// The JSON object `text` holds, or what it holds instead.
pub(super) fn object(text: &str) -> Result<Map<String, Value>, String> {
    match serde_json::from_str::<Value>(text) {
        Ok(Value::Object(fields)) => Ok(fields),
        Ok(other) => Err(format!("is {other}, not a JSON object")),
        Err(error) => Err(format!("is not JSON: {error}")),
    }
}

/// One evidence row, with what orders it: when it happened, when its
/// segment opened, which segment, and where in it.
pub(super) struct Evidence {
    ts: i64,
    created_at: i64,
    segment_id: String,
    sequence: u64,
    row: Map<String, Value>,
}

impl Evidence {
    fn new(
        mut row: Map<String, Value>,
        ts: i64,
        created_at: i64,
        segment_id: &str,
        sequence: u64,
    ) -> Self {
        row.insert("ts".into(), ts.into());
        row.insert("__segmentCreatedAt".into(), created_at.into());
        row.insert("__segmentId".into(), segment_id.into());
        row.insert("__segmentSequence".into(), sequence.into());
        Evidence {
            ts,
            created_at,
            segment_id: segment_id.to_string(),
            sequence,
            row,
        }
    }
}

/// The value `fields` holds under `key` through `read`, or what is wrong.
fn field<'a, T>(
    fields: &'a Map<String, Value>,
    key: &str,
    read: impl Fn(&'a Value) -> Option<T>,
    what: &str,
) -> Result<T, String> {
    fields
        .get(key)
        .and_then(read)
        .ok_or_else(|| format!("has no {key} that is {what}"))
}

/// `canonicalEvidence(row, segmentId)`: the evidence a lake row carries,
/// none for a row that carries none, or why the row does not belong to
/// segment `segment_id`.
pub(super) fn canonical_evidence(
    row: &Map<String, Value>,
    segment_id: &str,
) -> Result<Option<Evidence>, String> {
    if row.get("runtime").and_then(Value::as_str) != Some("hooks")
        || row.get("event_type").and_then(Value::as_str) != Some("hook_decision")
    {
        return Err("is not a hook decision of the hooks runtime".to_string());
    }
    let extra = field(row, "extra", Value::as_object, "an object")?;
    let source_type = field(extra, "source_type", Value::as_str, "a string")?;
    if !EVIDENCE_TYPES.contains(&source_type) {
        return Ok(None);
    }
    let hook_id = field(extra, "hook_id", Value::as_str, "a string")?;
    if hook_id.is_empty() {
        return Err("names an empty hook_id".to_string());
    }
    if source_type == "corpus_add" && !extra.contains_key("payload") {
        return Err("adds to a corpus without a payload".to_string());
    }
    if source_type == "corpus_label" {
        field(extra, "label", Value::as_str, "a string")?;
    }
    if extra.get("segment_id").and_then(Value::as_str) != Some(segment_id) {
        return Err(format!("is not from segment {segment_id}"));
    }
    let sequence = field(extra, "sequence", Value::as_u64, "a whole number")?;
    let created_at = field(
        extra,
        "segment_created_at",
        Value::as_i64,
        "whole milliseconds",
    )?;
    let at = field(row, "ts", Value::as_str, "a string")?;
    let ts = tama_core::clock::parse(at)?.timestamp_millis();
    let mut out = Map::new();
    out.insert("type".into(), source_type.into());
    out.insert("id".into(), hook_id.into());
    let carried = [
        ("payload", "payload"),
        ("label", "label"),
        ("repair_kind", "kind"),
        ("evidence", "evidence"),
    ];
    for (from, to) in carried {
        if let Some(value) = extra.get(from) {
            out.insert(to.into(), value.clone());
        }
    }
    if let Some(payload_ts) = extra.get("payload_ts").filter(|value| value.is_number()) {
        out.insert("payloadTs".into(), payload_ts.clone());
    }
    Ok(Some(Evidence::new(
        out, ts, created_at, segment_id, sequence,
    )))
}

/// The evidence a closed local segment carries, or why it cannot be read.
fn local_evidence(path: &Path, rows: &mut Vec<Evidence>) -> Result<(), String> {
    let segment = validate_segment(path)?;
    let shown = path.display();
    for (index, event) in segment.events.into_iter().enumerate() {
        let Value::Object(fields) = event else {
            return Err(format!("the event {index} of {shown} is not an object"));
        };
        let kind = field(&fields, "type", Value::as_str, "a string")
            .map_err(|cause| format!("the event {index} of {shown} {cause}"))?;
        if !EVIDENCE_TYPES.contains(&kind) {
            continue;
        }
        let ts = field(&fields, "ts", Value::as_i64, "whole milliseconds")
            .map_err(|cause| format!("the event {index} of {shown} {cause}"))?;
        let sequence = u64::try_from(index)
            .map_err(|error| format!("the event {index} of {shown} counts past u64: {error}"))?;
        rows.push(Evidence::new(
            fields,
            ts,
            segment.created_at,
            &segment.segment_id,
            sequence,
        ));
    }
    Ok(())
}

/// `readClosedTelemetryEvents(stateDir)`: the lake's committed evidence and
/// the evidence of every closed segment the lake does not hold yet, in the
/// order it happened.
pub fn read_closed_telemetry_events(state_dir: &Path) -> Result<Vec<Value>, String> {
    let (mut rows, committed) = read_lake_evidence()?;
    for path in ready_segments(state_dir)? {
        let name = path.file_name().map(|name| name.to_string_lossy());
        let id = name
            .as_deref()
            .and_then(|name| name.strip_prefix("segment-")?.strip_suffix(".jsonl"));
        if id.is_some_and(|id| committed.contains(id)) {
            continue;
        }
        local_evidence(&path, &mut rows)?;
    }
    rows.sort_by(|left, right| {
        let order = |row: &Evidence| (row.ts, row.created_at, row.segment_id.clone(), row.sequence);
        order(left).cmp(&order(right))
    });
    Ok(rows
        .into_iter()
        .map(|evidence| Value::Object(evidence.row))
        .collect())
}
