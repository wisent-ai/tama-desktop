//! Where a hook's files are, and the labelled corpus a candidate has to
//! satisfy: what must pass and what must block.
//!
//! Split out of `doctor/repair.rs`, which had grown past the
//! three-hundred-line limit.

use std::path::{Path, PathBuf};

use serde_json::Value;

use super::catalog::{command_source_path, find_hook};
use crate::doctor::evidence::{live_script_path, read_closed_telemetry_events};
use crate::util::repo_root;

pub(super) struct HookPaths {
    pub(super) command: Option<String>,
    pub(super) live: Option<String>,
    pub(super) archive: Option<PathBuf>,
}

fn registry_command(hook_id: &str, core: &crate::engine::Engine) -> Option<String> {
    for event in core.registry.events.values() {
        for entry in &event.hooks {
            if entry.id == hook_id {
                if let Some(command) = &entry.command {
                    if !command.is_empty() {
                        return Some(command.clone());
                    }
                }
            }
        }
    }
    None
}

pub(super) fn hook_paths(hook_id: &str, core: &crate::engine::Engine) -> Result<HookPaths, String> {
    let root = repo_root()?;
    let catalog_hook = find_hook(hook_id, &root)?;
    // The registry's command wins over the catalogue's.
    let command = registry_command(hook_id, core)
        .or_else(|| catalog_hook.as_ref().and_then(|hook| hook.command.clone()));
    let live = match command.as_deref().filter(|c| !c.is_empty()) {
        Some(command) => live_script_path(command)?,
        None => None,
    };
    let archive_rel = catalog_hook.and_then(|h| h.source_path).or_else(|| {
        command
            .as_deref()
            .and_then(|command| command_source_path(command, &root))
    });
    let archive = archive_rel.map(|rel| root.join(rel));
    Ok(HookPaths {
        command,
        live,
        archive,
    })
}

pub(super) struct Corpus {
    pub(super) must_pass: Vec<serde_json::Value>,
    pub(super) must_block: Vec<serde_json::Value>,
}

/// The label that marks a payload as not judged yet.
const UNLABELED: &str = "unlabeled";
/// The labels that say a block was wrong, so the payload must pass.
const FALSE_POSITIVE: &[&str] = &["fp", "fp-suspect"];

/// The judgement `row` gives, none for an empty or `unlabeled` one.
fn label_of(row: &Value) -> Option<String> {
    row.get("label")
        .and_then(Value::as_str)
        .filter(|label| !label.is_empty() && *label != UNLABELED)
        .map(str::to_string)
}

/// `splitCorpus(stateDir, hookId)` — the latest label targeting a payload
/// wins; without `payloadTs` a label applies to the newest payload.
pub(super) fn split_corpus(state_dir: &Path, hook_id: &str) -> Result<Corpus, String> {
    let rows = read_closed_telemetry_events(state_dir)?;
    let mut payloads: Vec<(Value, Option<String>)> = Vec::new();
    for row in &rows {
        if row.get("id").and_then(Value::as_str) != Some(hook_id) {
            continue;
        }
        match row.get("type").and_then(Value::as_str) {
            Some("corpus_add") => payloads.push((row.clone(), label_of(row))),
            Some("corpus_label") => {
                let target = match row.get("payloadTs") {
                    Some(payload_ts) => payloads
                        .iter_mut()
                        .rev()
                        .find(|(payload, _)| payload.get("ts") == Some(payload_ts)),
                    None => payloads.last_mut(),
                };
                if let Some((_, label)) = target {
                    *label = label_of(row);
                }
            }
            _ => {}
        }
    }
    let mut must_pass = Vec::new();
    let mut must_block = Vec::new();
    for (row, label) in payloads {
        match label {
            Some(label) if FALSE_POSITIVE.contains(&label.as_str()) => must_pass.push(row),
            Some(_) => must_block.push(row),
            None => {}
        }
    }
    Ok(Corpus {
        must_pass,
        must_block,
    })
}
