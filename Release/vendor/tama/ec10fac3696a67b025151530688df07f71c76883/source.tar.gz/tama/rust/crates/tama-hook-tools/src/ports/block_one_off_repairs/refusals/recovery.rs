//! A session recovered by hand: resumed, interrupted or moved to another
//! model, or its harness import refreshed, by a command an agent typed into
//! a turn. Each is what Oko's supervision pass owns; done by hand it leaves
//! the cause in place, so the same recovery comes back with the next session
//! that stalls.
//!
//! The paths are the products' own command paths (`recovery.json`), declared
//! as their CLIs spell them, so this reads no meaning into any word: a call
//! runs one of them or it does not, and the rule holds on a machine that
//! declared no model. Ending or signalling a process is a different matter:
//! what a command does to a process is read by the model with every other
//! one-off repair (`judge-prompt.md`), not guessed from a program's name.
//!
//! Every hand recovery is refused, including the first one. Naming a defect
//! or claiming a repair does not turn an agent's command into an automatic
//! product operation; the supervision capability must own the recovery.

use std::sync::LazyLock;

use serde::Deserialize;

use super::super::vocabulary::{is_flag, BANNER};

/// The declared command paths that recover a session.
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Declared {
    #[allow(dead_code)]
    why: String,
    paths: Vec<Path>,
}

/// One product command path: the program, its command words as the CLI
/// spells them, and the option that makes the command a recovery, if one does.
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Path {
    program: String,
    command: String,
    #[serde(default)]
    option: Option<String>,
}

static DECLARED: LazyLock<Declared> = LazyLock::new(|| {
    serde_json::from_str(include_str!("recovery.json"))
        .expect("refusals/recovery.json is this gate's own data and must parse")
});

impl Path {
    /// Whether `name args` runs this path: its program, its command words as
    /// the first words that are no option, and its option when it has one.
    fn run_by(&self, name: &str, args: &[String]) -> bool {
        if name != self.program {
            return false;
        }
        let mut plain = args.iter().map(String::as_str).filter(|arg| !is_flag(arg));
        let words = self
            .command
            .split_whitespace()
            .all(|word| plain.next() == Some(word));
        let option = match &self.option {
            Some(option) => args.iter().any(|arg| arg == option),
            None => true,
        };
        words && option
    }
}

/// The declared recovery `program args` runs, if it runs one.
pub(crate) fn path(program: &str, args: &[String]) -> Option<String> {
    let name = std::path::Path::new(program).file_name()?.to_str()?;
    DECLARED
        .paths
        .iter()
        .find(|path| path.run_by(name, args))
        .map(|path| {
            let mut spoken = format!("{} {}", path.program, path.command);
            if let Some(option) = &path.option {
                spoken.push(' ');
                spoken.push_str(option);
            }
            spoken
        })
}

/// A hand recovery is never admitted by a defect reference or a repair claim.
pub(crate) fn refusal(path: &str, command: &str) -> String {
    format!(
        "{BANNER}`{}` runs `{path}`, which recovers a session by hand. Oko's supervision pass \
         owns this recovery: repair the reusable product capability and use `oko sessions \
         supervision run`; naming a defect or a claimed repair does not authorize a recovery \
         by hand.",
        command.trim()
    )
}
