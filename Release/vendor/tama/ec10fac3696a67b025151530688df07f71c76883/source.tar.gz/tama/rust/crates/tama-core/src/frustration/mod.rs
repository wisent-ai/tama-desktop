//! Who wrote a prompt, as the harness says it.
//!
//! Whether a prompt is a correction or frustration is a model's reading
//! (`tama-hook-tools`' frustration detector); no word list decides it. What
//! stays here is the one structural fact both the detector and the adaptive
//! bridge need first: a prompt the harness's own automation wrote is nobody's
//! correction.

/// The payload field in which a harness says who wrote a prompt.
pub const PROMPT_AUTHOR_KEY: &str = "prompt_author";
/// Its value when the harness's own automation wrote the prompt — a Pursuit
/// stage, an autonomy run, an automatic continuation — and not the operator.
pub const AUTOMATION_AUTHOR: &str = "automation";

/// Whether the harness said its own automation wrote this prompt. A stage
/// prompt that tells its model "do not execute commands" is not the operator
/// correcting an agent, and reading it as one drafted rules that refused every
/// shell command. A payload that names no author is the operator's: the
/// interactive harnesses submit only what a person typed.
pub fn written_by_automation(payload: &serde_json::Value) -> bool {
    let said = |object: &serde_json::Value| {
        object
            .get(PROMPT_AUTHOR_KEY)
            .and_then(serde_json::Value::as_str)
            == Some(AUTOMATION_AUTHOR)
    };
    said(payload) || payload.get("raw_event").is_some_and(said)
}
