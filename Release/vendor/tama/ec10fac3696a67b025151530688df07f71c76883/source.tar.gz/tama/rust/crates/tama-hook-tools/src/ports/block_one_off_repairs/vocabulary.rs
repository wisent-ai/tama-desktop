//! What a compile looks like to the build hold, and the small readings every
//! refusal shares: the command a payload carries, the program a command line
//! actually runs, and its flags.
//!
//! The build hold refuses a compile while an open item carries no repair,
//! and it must hold while no model answers, so a compile is read from the
//! toolchains' own interfaces: the program a line runs and the subcommand
//! that program documents as building, testing or running a suite. Those are
//! the identifiers of each toolchain's command grammar (and of the fleet's
//! own compile commands), and a Node script's module specifiers, not words
//! that guess at intent; what a command does by hand otherwise is read by a
//! model (`judged`).

use std::collections::BTreeMap;
use std::sync::LazyLock;

use crate::ports::shell_text;

pub(super) const HELP_FLAG: &str = "--help";
pub(super) const FLAG_PREFIX: char = '-';
pub(super) const PATH_SEPARATOR: char = '/';
/// The word a package manager puts its script name after, so the refusal can
/// quote `npm run test:context` rather than `npm run`.
pub(super) const SCRIPT_RUNNER_VERB: &str = "run";
pub(super) const BANNER: &str = "BLOCKED: one-off repair by hand. ";

const STADO: &str = "stado";
const CARGO: &str = "cargo";
const SWIFT: &str = "swift";
const XCRUN: &str = "xcrun";
const XCODEBUILD: &str = "xcodebuild";
const GO: &str = "go";
const NPM: &str = "npm";
const PNPM: &str = "pnpm";
const YARN: &str = "yarn";
const BUN: &str = "bun";
const NPX: &str = "npx";
const DOTNET: &str = "dotnet";
const MAVEN: &str = "mvn";
const GRADLE: &str = "gradle";
const GITHUB: &str = "gh";
const NODE: &str = "node";
const TSC: &str = "tsc";

const BUILD: &str = "build";
const CHECK: &str = "check";
const TEST: &str = "test";
const CLIPPY: &str = "clippy";
const BENCH: &str = "bench";
const DOC: &str = "doc";
const INSTALL: &str = "install";
const START: &str = "start";
const DEV: &str = "dev";
const CLEAN_INSTALL: &str = "ci";
const PUBLISH: &str = "publish";
const PACKAGE: &str = "package";
const ASSEMBLE: &str = "assemble";
const RERUN: &str = "rerun";
/// Cargo's subcommands that resolve and download dependencies: the lockfile
/// they write is the build's input, so the hold covers them as it covers
/// the build.
const UPDATE: &str = "update";
const FETCH: &str = "fetch";
const GENERATE_LOCKFILE: &str = "generate-lockfile";
/// Cargo's and the toolchain's formatter: the operator holds it like a build.
const FORMAT: &str = "fmt";

/// The fleet's own commands that compile, spelled by their two words: a
/// source recipe is compiled before it is installed.
const FLEET_HOST_BUILD: &str = "host build";
const FLEET_PRODUCT_CARGO: &str = "product cargo";
const FLEET_PRODUCT_SWIFT: &str = "product swift";
const FLEET_PRODUCT_INSTALL: &str = "product install";
const FLEET_PRODUCT_UPDATE: &str = "product update";
const FLEET_PRODUCT_SYNC: &str = "product sync";
const FLEET_BUILD_SUBMIT: &str = "build submit";
const FLEET_BUILD_NEWEST: &str = "build newest";
const FLEET_RELEASE_SUBMIT: &str = "release submit";
const FLEET_RELEASE_PREPARE: &str = "release prepare";
const FLEET_RELEASE_NEWEST: &str = "release newest";
/// An exact release install downloads published bytes; a dry run reports;
/// a plan reads what the command would do and changes nothing.
const RELEASE_VERSION_FLAG: &str = "--release-version";
const DRY_RUN_FLAG: &str = "--dry-run";
const PLAN_FLAG: &str = "--plan";

/// Front-end tools `npx` runs that compile, bundle or run a suite.
const VITE: &str = "vite";
const NEXT: &str = "next";
const JEST: &str = "jest";
const VITEST: &str = "vitest";
const PLAYWRIGHT: &str = "playwright";
const WEBPACK: &str = "webpack";
const ESBUILD: &str = "esbuild";

/// Compilers and build systems whose every invocation builds.
const MAKE: &str = "make";
const CMAKE: &str = "cmake";
const NINJA: &str = "ninja";
const SWIFTC: &str = "swiftc";
const RUSTC: &str = "rustc";
const GCC: &str = "gcc";
const GXX: &str = "g++";
const CLANG: &str = "clang";
const CLANGXX: &str = "clang++";
const RUSTFMT: &str = "rustfmt";

/// What Node itself documents: the lifecycle prefixes a runner runs around
/// `run <script>`, the endings of a module file, the flag that runs a test
/// suite, the builtin scheme, the builtins that start a program or only a
/// test loads, the forms that load a module, and a relative specifier.
const PRE_SCRIPT: &str = "pre";
const POST_SCRIPT: &str = "post";
const JS_FILE: &str = ".js";
const MODULE_FILE: &str = ".mjs";
const COMMONJS_FILE: &str = ".cjs";
const NODE_TEST_FLAG: &str = "--test";
const NODE_BUILTIN_SCHEME: &str = "node:";
const CHILD_PROCESS_MODULE: &str = "node:child_process";
const WORKER_THREADS_MODULE: &str = "node:worker_threads";
const CLUSTER_MODULE: &str = "node:cluster";
const MODULE_MODULE: &str = "node:module";
const TEST_MODULE: &str = "node:test";
const ASSERT_MODULE: &str = "node:assert";
const STRICT_ASSERT_MODULE: &str = "node:assert/strict";
const IMPORT_LOADER: &str = "import";
const REQUIRE_LOADER: &str = "require";
const FROM_LOADER: &str = "from";
const BUILTIN_LOADER: &str = "getBuiltinModule";
const SAME_DIRECTORY: &str = "./";
const PARENT_DIRECTORY: &str = "../";

/// The compile structure the build hold and the script admission read.
pub(super) struct Vocabulary {
    /// The fleet's own CLI, whose subcommands are read as two words.
    pub(super) fleet_program: String,
    pub(super) fleet_compile_commands: Vec<String>,
    pub(super) fleet_non_compile_flags: Vec<String>,
    /// The Rust toolchain's driver, whose subcommand is read as one word.
    pub(super) toolchain_program: String,
    pub(super) toolchain_compile_commands: Vec<String>,
    /// Drivers whose first word after the program says what it does, keyed
    /// by the program, valued by the words that build or test with it.
    pub(super) build_drivers: BTreeMap<String, Vec<String>>,
    pub(super) build_programs: Vec<String>,
    pub(super) script_runners: Vec<String>,
    pub(super) script_lifecycle_prefixes: Vec<String>,
    pub(super) script_file_runners: Vec<String>,
    pub(super) script_file_extensions: Vec<String>,
    pub(super) script_file_runner_test_flags: Vec<String>,
    pub(super) script_file_builtin_prefix: String,
    pub(super) script_file_process_modules: Vec<String>,
    pub(super) script_file_test_modules: Vec<String>,
    pub(super) script_file_loaders: Vec<String>,
    pub(super) script_file_relative_prefixes: Vec<String>,
    /// When a compile may run, named in every compile refusal.
    pub(super) compile_gate_route: String,
}

fn owned(words: &[&str]) -> Vec<String> {
    words.iter().map(|word| word.to_string()).collect()
}

/// The route every compile refusal names. The rule that decides is never
/// restated here: it is Oko's, read from the operator's rulings, and Oko's
/// answer quotes the ruling or the rule that decided, so a newer ruling
/// reaches every gate without a copy of it in Tama.
fn compile_gate_route() -> String {
    "Whether a build, a compile or a test runs is Oko's one admission decision, `oko admit \
     build --session <id>` (with `--purpose <item>` for the item it serves); its answer quotes \
     the operator's ruling or the rule that decided it. Never ask the operator for a build, \
     neither through his window nor through an Oko ask: what he says in the conversation is \
     read into his rulings. Every build, compile, format or test also needs the session's own \
     build attestation, recorded with `tama attestation record --file FILE --session <id>` from \
     a document whose \"standard\" is \"build\", attesting in the agent's own words that \
     building is not marginal; the build it admits spends it."
        .to_string()
}

pub(super) static VOCABULARY: LazyLock<Vocabulary> = LazyLock::new(|| {
    let node_package_verbs = [SCRIPT_RUNNER_VERB, BUILD, TEST, START, DEV, INSTALL];
    let mut npm_verbs = owned(&node_package_verbs);
    npm_verbs.push(CLEAN_INSTALL.to_string());
    Vocabulary {
        fleet_program: STADO.to_string(),
        fleet_compile_commands: owned(&[
            FLEET_HOST_BUILD,
            FLEET_PRODUCT_CARGO,
            FLEET_PRODUCT_SWIFT,
            FLEET_PRODUCT_INSTALL,
            FLEET_PRODUCT_UPDATE,
            FLEET_PRODUCT_SYNC,
            FLEET_BUILD_SUBMIT,
            FLEET_BUILD_NEWEST,
            FLEET_RELEASE_SUBMIT,
            FLEET_RELEASE_PREPARE,
            FLEET_RELEASE_NEWEST,
        ]),
        fleet_non_compile_flags: owned(&[RELEASE_VERSION_FLAG, DRY_RUN_FLAG, PLAN_FLAG]),
        toolchain_program: CARGO.to_string(),
        toolchain_compile_commands: owned(&[
            BUILD,
            CHECK,
            TEST,
            CLIPPY,
            SCRIPT_RUNNER_VERB,
            BENCH,
            DOC,
            INSTALL,
            UPDATE,
            FETCH,
            GENERATE_LOCKFILE,
            FORMAT,
        ]),
        build_drivers: BTreeMap::from([
            (SWIFT.to_string(), owned(&[BUILD, TEST, SCRIPT_RUNNER_VERB])),
            (XCRUN.to_string(), owned(&[SWIFT, XCODEBUILD])),
            (GO.to_string(), owned(&[BUILD, TEST, INSTALL])),
            (NPM.to_string(), npm_verbs),
            (PNPM.to_string(), owned(&node_package_verbs)),
            (YARN.to_string(), owned(&node_package_verbs)),
            (BUN.to_string(), owned(&node_package_verbs)),
            (
                NPX.to_string(),
                owned(&[TSC, VITE, NEXT, JEST, VITEST, PLAYWRIGHT, WEBPACK, ESBUILD]),
            ),
            (DOTNET.to_string(), owned(&[BUILD, TEST, PUBLISH])),
            (MAVEN.to_string(), owned(&[PACKAGE, INSTALL, TEST])),
            (GRADLE.to_string(), owned(&[BUILD, TEST, ASSEMBLE])),
            (GITHUB.to_string(), owned(&[SCRIPT_RUNNER_VERB, RERUN])),
        ]),
        build_programs: owned(&[
            XCODEBUILD, MAKE, CMAKE, NINJA, SWIFTC, RUSTC, GCC, GXX, CLANG, CLANGXX, TSC, RUSTFMT,
        ]),
        script_runners: owned(&[NPM, PNPM, YARN, BUN]),
        script_lifecycle_prefixes: owned(&[PRE_SCRIPT, POST_SCRIPT]),
        script_file_runners: owned(&[NODE]),
        script_file_extensions: owned(&[JS_FILE, MODULE_FILE, COMMONJS_FILE]),
        script_file_runner_test_flags: owned(&[NODE_TEST_FLAG]),
        script_file_builtin_prefix: NODE_BUILTIN_SCHEME.to_string(),
        script_file_process_modules: owned(&[
            CHILD_PROCESS_MODULE,
            WORKER_THREADS_MODULE,
            CLUSTER_MODULE,
            MODULE_MODULE,
        ]),
        script_file_test_modules: owned(&[TEST_MODULE, ASSERT_MODULE, STRICT_ASSERT_MODULE]),
        script_file_loaders: owned(&[IMPORT_LOADER, REQUIRE_LOADER, FROM_LOADER, BUILTIN_LOADER]),
        script_file_relative_prefixes: owned(&[SAME_DIRECTORY, PARENT_DIRECTORY]),
        compile_gate_route: compile_gate_route(),
    }
});

pub(super) fn has(list: &[String], word: &str) -> bool {
    list.iter().any(|item| item == word)
}

pub(super) fn basename(token: &str) -> &str {
    match token.rsplit_once(PATH_SEPARATOR) {
        Some((_, name)) => name,
        None => token,
    }
}

/// The program one command runs and the words after it, with the program's
/// directory dropped and the wrappers that run another program stepped over.
pub(super) fn program_and_args(tokens: &[String]) -> Option<(&str, &[String])> {
    let program = shell_text::program(tokens)?;
    let start = tokens.iter().position(|token| basename(token) == program)?;
    let (_, args) = tokens[start..].split_first()?;
    Some((program, args))
}

pub(super) fn is_flag(word: &str) -> bool {
    word.starts_with(FLAG_PREFIX)
}

pub(super) fn asks_for_help(args: &[String]) -> bool {
    args.iter().any(|arg| arg == HELP_FLAG)
}
