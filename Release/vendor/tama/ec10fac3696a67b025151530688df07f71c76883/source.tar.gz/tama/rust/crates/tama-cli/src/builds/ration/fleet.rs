//! What the fleet says is left of today's builds.
//!
//! A gate that keeps its own count of builds beside Stado's disagrees with
//! it: one counts intents recorded on this machine over a rolling day, the
//! other counts jobs the fleet actually charged over a UTC day, and two
//! ceilings enforced by different arithmetic mean nobody can say whether a
//! build is permitted.
//!
//! So the count belongs to the fleet, which is where a build is really spent,
//! and this gate asks it. What stays here is the judgement Stado does not
//! make: whether this particular build carries enough accumulated change to
//! be worth one of them.

use std::path::PathBuf;
use std::process::Command;

use serde_json::Value;

/// Where the fleet's own CLI lives, as every other Tama caller of it looks:
/// under `HOME` ([`tama_core::home_dir`] stops naming the variable when it is
/// unset), never under the working directory.
fn stado() -> PathBuf {
    tama_core::home_dir()
        .join(".local")
        .join("bin")
        .join("stado")
}

/// What the fleet says is left of today's builds, or `None` when the fleet
/// could not be asked at all — a missing binary, a refusal, or an answer this
/// build cannot read, each said on stderr. `None` is not permission: the
/// caller keeps its own count for that case.
pub fn remaining() -> Option<u64> {
    match asked() {
        Ok(remaining) => Some(remaining),
        Err(cause) => {
            eprintln!("tama build: the fleet's build budget is not known: {cause}");
            None
        }
    }
}

fn asked() -> Result<u64, String> {
    let binary = stado();
    if let Some(why) = tama_core::presence::absence(&binary, "the Stado program") {
        return Err(why);
    }
    let mut command = Command::new(&binary);
    command.args(["queue", "budget", "--json"]);
    let read = format!("{} queue budget --json", binary.display());
    let output = stado_wait::output(&mut command)
        .map_err(|error| format!("{read} could not run: {error}"))?;
    if !output.status.success() {
        return Err(format!(
            "{read} failed ({}): {}",
            output.status,
            String::from_utf8_lossy(&output.stderr).trim()
        ));
    }
    let document: Value = serde_json::from_slice(&output.stdout)
        .map_err(|error| format!("{read} printed no JSON: {error}"))?;
    document
        .get("remaining")
        .and_then(Value::as_u64)
        .ok_or_else(|| format!("{read} names no remaining count: {document}"))
}

/// The refusal when the fleet itself has nothing left today.
pub fn spent_refusal() -> String {
    String::from(
        "the fleet's daily build budget is spent: `stado queue budget` reports nothing left \
         today, and the count resets at midnight UTC. Gather the work into one build instead, \
         or record the user's explicit exception with `tama build record --approval-session \
         <id> --approval-quote <verbatim message>`. This leaves the default ceiling unchanged.",
    )
}
