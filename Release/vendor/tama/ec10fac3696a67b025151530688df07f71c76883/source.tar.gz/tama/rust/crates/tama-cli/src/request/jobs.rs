//! Streamed job operations: violation scan and clean, each mirroring the
//! corresponding CLI command as NDJSON log events plus one final result
//! event whose status is the command's exit code.

use std::path::Path;

use http::StatusCode;
use serde_json::Value;
use tama_violations::clean::{
    clean_repo, clean_summary_lines, CleanJsonOutput, CleanParams, CleanRule,
};
use tama_violations::scan_repos::{
    default_hook_path, failures, hook_missing_message, parse_scan_args, run_scan,
    scan_json_document,
};

use super::reply::{json_body, send_error, stream_job, Reply, Request};

/// `tama violations find --repo <path> --json [--<mode>] [--hook <id>]` as a
/// streamed job. `mode` names one of the in-process passes the CLI offers —
/// `size-only`, `duplicates`, `internal-names`, `time-limits`, `fallbacks` —
/// and its absence replays the hooks; `hook` narrows that replay to one
/// registered hook. Every step of the scan (which file which hook judges,
/// each finding, each file not judged) is a log event as it happens. The
/// usage rejections the command exits 2 on are 400 responses here, printed
/// before the job starts.
pub(super) fn scan_job(request: Request, writer: &mut Reply) {
    let body = match json_body(&request) {
        Ok(body) => body,
        Err((status, message)) => return send_error(writer, status, &message),
    };
    let Some(repo) = body.get("repo").and_then(Value::as_str).map(str::to_string) else {
        return send_error(
            writer,
            StatusCode::BAD_REQUEST.as_u16(),
            "scan requires repo: the absolute path of the repository to scan, as a string",
        );
    };
    let mut argv = vec!["--repo".to_string(), repo.clone(), "--json".to_string()];
    match body.get("mode").and_then(Value::as_str) {
        None | Some("") => {}
        Some(mode @ ("size-only" | "duplicates" | "internal-names" | "time-limits" | "fallbacks")) => {
            argv.push(format!("--{mode}"))
        }
        Some(other) => {
            return send_error(
                writer,
                StatusCode::BAD_REQUEST.as_u16(),
                &format!(
                    "unknown scan mode {other:?}: the modes are size-only, duplicates, internal-names, time-limits and fallbacks"
                ),
            )
        }
    }
    match body.get("hook") {
        None | Some(Value::Null) => {}
        Some(Value::String(hook)) if !hook.is_empty() => {
            if !tama_hook_tools::programs::names().any(|known| known == hook.as_str()) {
                return send_error(
                    writer,
                    StatusCode::BAD_REQUEST.as_u16(),
                    &format!("hook {hook:?} is no hook this program runs; `tama hook` names the hooks it runs"),
                );
            }
            argv.push("--hook".to_string());
            argv.push(hook.clone());
        }
        Some(other) => {
            return send_error(
                writer,
                StatusCode::BAD_REQUEST.as_u16(),
                &format!("hook must be the id of a registered hook, as a string; got {other}"),
            )
        }
    }
    let Some(args) = parse_scan_args(&argv) else {
        return send_error(
            writer,
            StatusCode::BAD_REQUEST.as_u16(),
            "scan requires a repo path",
        );
    };
    if args.replays_hook() {
        if let Some(refusal) = hook_refusal(Path::new(&args.hook_path), args.hook_explicit) {
            return send_error(writer, StatusCode::BAD_REQUEST.as_u16(), &refusal);
        }
    }
    if let Some(refusal) = tama_core::presence::absence(Path::new(&repo), "repo") {
        return send_error(writer, StatusCode::BAD_REQUEST.as_u16(), &refusal);
    }
    stream_job(writer, |emit| {
        let (reports, problems) = run_scan(&args, |progress| {
            emit("stderr", &format!("{}\n", progress.text()))
        });
        let total: usize = reports.iter().map(|report| report.violations.len()).sum();
        let document = scan_json_document(&reports, &problems);
        let status = if total > 0 || failures(&problems) > 0 {
            libc::EXIT_FAILURE
        } else {
            libc::EXIT_SUCCESS
        };
        (status, tama_core::json::value(&document))
    });
}

/// Why the hook tree at `hook` cannot be replayed: the CLI's own sentence
/// when it is not there, the examination failure when it cannot be told;
/// none when it is there.
fn hook_refusal(hook: &Path, explicit: bool) -> Option<String> {
    match tama_core::presence::present(hook) {
        Ok(true) => None,
        Ok(false) => Some(hook_missing_message(&hook.to_string_lossy(), explicit)),
        Err(error) => Some(format!("hook tree {error}")),
    }
}

/// `tama violations clean --repo <path> --max-rounds <n>` as a streamed job, with the
/// command's other defaults (the resolved route, no skip list, no note). Like
/// the command, the request names how many rounds the run may take as
/// `maxRounds`; nothing here chooses that number for the operator.
pub(super) fn clean_job(request: Request, root: &Path, writer: &mut Reply) {
    use tama_hook_tools::ports::clean_violations_gate::{switched_on, DISABLE_ENV};
    if switched_on(DISABLE_ENV) {
        return send_error(
            writer,
            StatusCode::FORBIDDEN.as_u16(),
            &format!("tama violations clean is disabled ({DISABLE_ENV} is set)"),
        );
    }
    let body = match json_body(&request) {
        Ok(body) => body,
        Err((status, message)) => return send_error(writer, status, &message),
    };
    let Some(repo) = body
        .get("repo")
        .and_then(Value::as_str)
        .filter(|repo| !repo.is_empty())
        .map(str::to_string)
    else {
        return send_error(
            writer,
            StatusCode::BAD_REQUEST.as_u16(),
            "clean requires repo: the absolute path of the repository to repair, as a string",
        );
    };
    let Some(max_rounds) = body
        .get("maxRounds")
        .and_then(Value::as_f64)
        .filter(|rounds| rounds.is_normal() && rounds.is_sign_positive())
    else {
        return send_error(
            writer,
            StatusCode::BAD_REQUEST.as_u16(),
            "clean requires maxRounds: how many repair rounds the run may take, a number above zero; tama violations clean --max-rounds has no default either",
        );
    };
    // The same default the CLI uses: this program's own registered guard.
    let hook = default_hook_path();
    if let Some(refusal) = hook_refusal(&hook, false) {
        return send_error(writer, StatusCode::BAD_REQUEST.as_u16(), &refusal);
    }
    if let Some(refusal) = tama_core::presence::absence(Path::new(&repo), "repo") {
        return send_error(writer, StatusCode::BAD_REQUEST.as_u16(), &refusal);
    }
    let hook_path = hook.to_string_lossy().into_owned();
    // The route is resolved before the job starts, so an unusable one is a
    // 400 the screen can read instead of a failure inside every round.
    let route = match tama_violations::clean::default_route() {
        Ok(route) => route,
        Err(message) => return send_error(writer, StatusCode::BAD_REQUEST.as_u16(), &message),
    };
    stream_job(writer, |emit| {
        emit(
            "stderr",
            &format!("[clean] {repo}: starting repair rounds\n"),
        );
        let result = clean_repo(&CleanParams {
            repo: &repo,
            hook_path: &hook_path,
            model: &route,
            max_rounds,
            dry_run: false,
            skip: &[],
            // The desktop repair screen is the whole-rule shape; the size
            // sweep is a CLI campaign across many repositories.
            rule: CleanRule::All,
            note: None,
            root,
        });
        for line in clean_summary_lines(&result) {
            emit("stdout", &format!("{line}\n"));
        }
        let unresolved = result.clean == Some(false) || result.locked == Some(true);
        let document = CleanJsonOutput {
            results: std::slice::from_ref(&result),
            problems: &[],
        };
        let status = if unresolved {
            libc::EXIT_FAILURE
        } else {
            libc::EXIT_SUCCESS
        };
        (status, tama_core::json::value(&document))
    });
}
