//! `tama task scope`: which registered work the session is serving.
//!
//! The gate beside this file checks writes against that work's repositories.
//! A task keeps its original operator words in Oko after later instructions;
//! `set --task` can select an earlier open task without asking the operator
//! to repeat it. The declaration is still bound to the latest captured turn,
//! so a future prompt cannot silently inherit it. The verbs print what
//! `declare` and `show` answer; Tama Desktop asks the same functions through
//! `tama request task-scope/…`.

mod declare;
mod show;
mod transcript;

pub use declare::{cleared, declared, Declared, Refused};
pub use show::{shown, Shown};

use tama_core::exit::USAGE as USAGE_EXIT;

const USAGE: &str = "usage: tama task scope show|set|clear --session ID \
                     [--repository NAME]… [--defect ID] [--task ID] [--json]";

/// `tama task scope …`.
pub fn cli_main(args: &[String]) -> i32 {
    let mut args = args.iter();
    if args.next().map(String::as_str) != Some("scope") {
        eprintln!("{USAGE}");
        return USAGE_EXIT;
    }
    let Some(verb) = args.next().map(String::as_str).map(str::to_owned) else {
        eprintln!("{USAGE}");
        return USAGE_EXIT;
    };
    let mut session: Option<String> = None;
    let mut repositories: Vec<String> = Vec::new();
    let mut defect: Option<String> = None;
    let mut task: Option<String> = None;
    let mut json = false;
    while let Some(argument) = args.next() {
        let slot = match argument.as_str() {
            "--json" => {
                json = true;
                continue;
            }
            "--session" => &mut session,
            "--defect" => &mut defect,
            "--task" => &mut task,
            "--repository" => match args.next() {
                Some(value) if !value.starts_with("--") => {
                    repositories.push(value.clone());
                    continue;
                }
                _ => {
                    eprintln!("{USAGE}");
                    return USAGE_EXIT;
                }
            },
            _ => {
                eprintln!("{USAGE}");
                return USAGE_EXIT;
            }
        };
        match args.next() {
            Some(value) if !value.starts_with("--") => *slot = Some(value.clone()),
            _ => {
                eprintln!("{USAGE}");
                return USAGE_EXIT;
            }
        }
    }
    let Some(session) = session else {
        eprintln!(
            "task scope requires --session ID: a scope belongs to one session's instruction, \
             and no other session's instruction stands in for it"
        );
        return USAGE_EXIT;
    };
    match verb.as_str() {
        "show" => show::show(&session, json),
        "set" => set(
            &session,
            &repositories,
            defect.as_deref(),
            task.as_deref(),
            json,
        ),
        "clear" => clear(&session),
        _ => {
            eprintln!("{USAGE}");
            USAGE_EXIT
        }
    }
}

fn set(
    session: &str,
    repositories: &[String],
    defect: Option<&str>,
    task: Option<&str>,
    json: bool,
) -> i32 {
    let Declared { document, notice } = match declared(session, repositories, defect, task) {
        Ok(declared) => declared,
        Err(Refused::Usage(refusal)) => {
            eprintln!("{refusal}");
            return USAGE_EXIT;
        }
        Err(Refused::Failed(refusal)) => {
            eprintln!("{refusal}");
            return libc::EXIT_FAILURE;
        }
    };
    if let Some(notice) = notice {
        eprintln!("{notice}");
    }
    if json {
        println!("{document}");
        return libc::EXIT_SUCCESS;
    }
    let text = |key: &str| document[key].as_str().map(str::to_owned);
    let repositories: Vec<&str> = document["repositories"]
        .as_array()
        .into_iter()
        .flatten()
        .filter_map(serde_json::Value::as_str)
        .collect();
    let entry = match (text("defect"), text("task_id")) {
        (Some(defect), Some(task)) if defect.is_empty() => format!("task {task}"),
        (Some(defect), Some(task)) if task.is_empty() => format!("defect {defect}"),
        (Some(defect), Some(task)) => format!("defect {defect} and task {task}"),
        _ => {
            eprintln!(
                "the declaration written for session {session} names no defect or task: {document}"
            );
            return libc::EXIT_FAILURE;
        }
    };
    println!(
        "task scope for session {session}: {} for {entry}",
        repositories.join(", ")
    );
    match text("task") {
        Some(task) => println!("instruction: {}", task.trim()),
        None => {
            eprintln!(
                "the declaration written for session {session} holds no instruction: {document}"
            );
            return libc::EXIT_FAILURE;
        }
    }
    libc::EXIT_SUCCESS
}

fn clear(session: &str) -> i32 {
    match cleared(session) {
        Ok(true) => {
            println!("task scope cleared for session {session}");
            libc::EXIT_SUCCESS
        }
        Ok(false) => {
            println!("session {session} had no task scope");
            libc::EXIT_SUCCESS
        }
        Err(cause) => {
            eprintln!("{cause}");
            libc::EXIT_FAILURE
        }
    }
}
