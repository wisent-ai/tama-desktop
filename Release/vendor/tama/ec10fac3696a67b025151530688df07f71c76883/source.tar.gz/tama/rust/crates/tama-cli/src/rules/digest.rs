//! `tama rules digest` and `tama rules dismiss`: one reading of what Tama
//! learned across sessions, grouped into proposals the operator can inspect.
//!
//! The adaptive bridge queues a repair proposal for each contested block.
//! The frustration drafter records rules in `auto_rules.json`. Oko records
//! operator corrections. Named causes form lessons; moments not yet explained
//! remain visible together instead of disappearing from the digest. It lists
//! drafted rules beside them and shows why a source could not be read.
//! A dismissal lasts until new evidence arrives; enforcement and dismissal
//! remain operator decisions.

use std::collections::BTreeMap;

use serde_json::{json, Value};

use super::decisions::{decisions_path, dismissed, CAUSE_PREFIX, DECISIONS_KEY};

const APPROVAL_ENV: &str = "DEVICE_HOOK_EDIT_APPROVED";
/// The value of [`APPROVAL_ENV`] that counts as the operator's hook-edit
/// consent, as the hook-management page declares it:
/// https://tama.wisent.com/docs/hook-management
const APPROVAL_VALUE: &str = "1";
const REPAIR_EVENT: &str = "repair_proposal";
const HOOK_PREFIX: &str = "hook:";
const RULE_PREFIX: &str = "rule:";

/// One proposal per contested hook, from the adaptive layer's closed rows.
fn repair_proposals() -> Result<Vec<Value>, String> {
    let engine = tama_adaptive::engine::load_engine()?;
    let rows = tama_adaptive::doctor::evidence::read_closed_telemetry_events(&engine.state_dir)?;
    let mut by_hook: BTreeMap<String, Vec<i64>> = BTreeMap::new();
    for row in rows
        .iter()
        .filter(|row| row.get("type").and_then(Value::as_str) == Some(REPAIR_EVENT))
    {
        // A repair row without its hook or its time cannot be counted: read
        // as nothing or as 1970, the digest would misstate what was contested.
        let hook = row.get("id").and_then(Value::as_str).ok_or_else(|| {
            format!("a {REPAIR_EVENT} row of the adaptive telemetry names no hook (id): {row}")
        })?;
        let at = row.get("ts").and_then(Value::as_i64).ok_or_else(|| {
            format!("the {REPAIR_EVENT} row for {hook} carries no time (ts): {row}")
        })?;
        by_hook.entry(hook.to_string()).or_default().push(at);
    }
    let mut proposals = Vec::with_capacity(by_hook.len());
    for (hook, times) in by_hook {
        // Every hook here was entered with its first time.
        let (Some(first), Some(last)) = (times.iter().min(), times.iter().max()) else {
            continue;
        };
        let when =
            |millis: i64| {
                tama_core::clock::from_millis(millis).map(tama_core::clock::iso).map_err(|error| {
                format!("the {REPAIR_EVENT} rows for {hook} carry a time that is no date: {error}")
            })
            };
        let count = times.len();
        proposals.push(json!({
            "id": format!("{HOOK_PREFIX}{hook}"),
            "kind": "repair",
            "subject": hook,
            "evidence": count,
            "first": when(*first)?,
            "last": when(*last)?,
            "says": format!("the operator contested {hook} {count} time(s); its false positives are labeled in the replay corpus"),
            "action": format!("tama adaptive repair {hook}"),
        }));
    }
    Ok(proposals)
}

/// One proposal per drafted rule identity, including all its recorded
/// evidence, and one unreadable entry per rule that names no identity: such
/// a rule cannot be grouped, removed or dismissed, and leaving it out made
/// the digest read as if it had never been drafted.
fn drafted_proposals(rules: &[Value]) -> (Vec<Value>, Vec<Value>) {
    let mut by_id: BTreeMap<&str, Vec<&Value>> = BTreeMap::new();
    let mut unreadable = Vec::new();
    for rule in rules {
        match rule.get("id").and_then(Value::as_str) {
            Some(id) => by_id.entry(id).or_default().push(rule),
            None => unreadable.push(json!({
                "source": "drafted-rules",
                "error": format!("a drafted rule names no id (id), so it cannot be grouped or removed: {rule}"),
            })),
        }
        // A row the gates do not apply, because its pattern matches every
        // subject, is named where the Learned screen shows what cannot act.
        let pattern = rule.get("pattern").and_then(Value::as_str);
        if pattern.is_some_and(tama_hook_tools::ports::auto_rules::reaches_every_subject) {
            unreadable.push(json!({
                "source": "drafted-rules",
                "error": format!(
                    "the drafted rule {} matches every {} and names no incident, so no gate \
                     applies it; remove it with `tama rules remove --id {}`",
                    rule["id"], rule["target"], rule["id"]
                ),
            }));
        }
    }
    let proposals = by_id
        .into_iter()
        .filter_map(|(id, mut rows)| {
            rows.sort_by(|a, b| a["added"].as_str().cmp(&b["added"].as_str()));
            let first = rows.first()?;
            let latest = rows.last()?;
            // A field the rule does not carry stays null, not a value nobody wrote.
            Some(json!({
                "id": format!("{RULE_PREFIX}{id}"),
                "kind": "drafted-rule",
                "subject": id,
                "evidence": rows.len(),
                "first": first.get("added"),
                "last": latest.get("added"),
                "says": latest.get("message"),
                "quote": latest.get("user_said"),
                "action": format!("tama rules remove --id {id}"),
            }))
        })
        .collect();
    (proposals, unreadable)
}

/// The digest document: open proposals, and why a source could not be read.
pub(super) fn document(rules: &[Value]) -> Result<Value, String> {
    Ok(document_with_hidden(rules, &dismissed()?))
}

fn document_with_hidden(rules: &[Value], hidden: &BTreeMap<String, Value>) -> Value {
    let (mut proposals, mut unreadable) = drafted_proposals(rules);
    match repair_proposals() {
        Ok(repairs) => proposals.extend(repairs),
        Err(error) => unreadable.push(json!({ "source": "adaptive", "error": error })),
    }
    match super::frustration::proposals() {
        Ok(lessons) => proposals.extend(lessons),
        Err(error) => unreadable.push(json!({ "source": "oko-frustration", "error": error })),
    }
    let open: Vec<Value> = proposals
        .into_iter()
        .filter(|proposal| {
            // Every proposal is built with its id; one without is never hidden.
            let Some((id, decision)) = proposal["id"]
                .as_str()
                .and_then(|id| hidden.get(id).map(|decision| (id, decision)))
            else {
                return true;
            };
            if id.starts_with(CAUSE_PREFIX) {
                if let Some(previous) = decision.as_u64() {
                    return proposal["evidence"]
                        .as_u64()
                        .is_some_and(|count| count > previous);
                }
                let seen = decision.get("seen").and_then(Value::as_array);
                proposal["sources"].as_array().is_some_and(|sources| {
                    sources
                        .iter()
                        .any(|source| !seen.is_some_and(|ids| ids.contains(&source["id"])))
                })
            } else {
                // `dismissed` refuses a count-less decision outside causes.
                proposal["evidence"].as_u64() > decision.as_u64()
            }
        })
        .collect();
    json!({ "proposals": open, "dismissed": hidden.len(), "unreadable": unreadable })
}

pub(super) fn digest(argv: &[String], doc: &Value) -> Result<(), String> {
    if argv.iter().any(|argument| argument == "--json") {
        println!("{doc}");
        return Ok(());
    }
    for failure in doc["unreadable"].as_array().into_iter().flatten() {
        println!("unreadable {}: {}", failure["source"], failure["error"]);
    }
    let proposals = doc["proposals"].as_array();
    if proposals.is_none_or(Vec::is_empty) {
        println!("nothing new to decide ({} dismissed)", doc["dismissed"]);
        return Ok(());
    }
    for proposal in proposals.into_iter().flatten() {
        println!(
            "{}\n  {}\n  evidence: {} ({} .. {})\n  action:   {}",
            shown(&proposal["id"]),
            shown(&proposal["says"]),
            proposal["evidence"],
            shown(&proposal["first"]),
            shown(&proposal["last"]),
            shown(&proposal["action"]),
        );
        for source in proposal["sources"].as_array().into_iter().flatten() {
            println!(
                "  source: {} session {}\n    operator: {}\n    cause: {}",
                shown(&source["id"]),
                shown(&source["session"]),
                shown(&source["quote"]),
                shown(&source["cause"]),
            );
            if let Some(defect) = source["defect"].as_str() {
                println!("    defect: {defect}");
            }
            for marker in source["markers"].as_array().into_iter().flatten() {
                println!("    read as: {}", shown(marker));
            }
            if let Some(repeats) = source["repeats"].as_i64().filter(|count| *count > 0) {
                println!("    earlier repeats: {repeats}");
            }
        }
    }
    Ok(())
}

/// A field as the operator reads it: text as written, anything else (an
/// absent field is `null`) as its JSON, so a missing value is never a blank.
fn shown(value: &Value) -> String {
    match value {
        Value::String(text) => text.clone(),
        other => other.to_string(),
    }
}

/// Hide one proposal until more evidence arrives than it has now.
pub(super) fn dismiss(id: &str, rules: &[Value]) -> Result<String, String> {
    if std::env::var_os(APPROVAL_ENV).is_none_or(|value| value != APPROVAL_VALUE) {
        return Err(format!(
            "refusing to dismiss {id}: which proposal the operator never sees again is his \
             decision. Set {APPROVAL_ENV}=1 outside the agent session to dismiss it."
        ));
    }
    let path = decisions_path();
    let _lock = crate::justify::registry::Lock::acquire(&path)?;
    let mut hidden = dismissed()?;
    let doc = document_with_hidden(rules, &hidden);
    let Some(proposal) = doc["proposals"]
        .as_array()
        .into_iter()
        .flatten()
        .find(|proposal| proposal["id"].as_str() == Some(id))
    else {
        return Err(format!("no open proposal {id} is in the digest"));
    };
    let decision = if id.starts_with(CAUSE_PREFIX) {
        json!({ "seen": proposal["sources"].as_array().into_iter().flatten()
            .filter_map(|source| source["id"].as_str()).collect::<Vec<_>>() })
    } else {
        proposal["evidence"].clone()
    };
    hidden.insert(id.to_string(), decision);
    let written = json!({ DECISIONS_KEY: hidden });
    crate::justify::registry::write_atomically(&path, &format!("{written:#}"))?;
    Ok(format!(
        "dismissed {id} at {} piece(s) of evidence; new evidence reopens it",
        proposal["evidence"]
    ))
}
