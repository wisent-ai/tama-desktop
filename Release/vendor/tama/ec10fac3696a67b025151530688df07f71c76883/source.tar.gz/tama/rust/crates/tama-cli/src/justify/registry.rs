//! The justification registries as data with an interface.
//!
//! `~/.shared-hooks/file_justifications.json` and its test sibling are the
//! documents the authorization gates require an agent to write, and until now
//! the only way to write one was to edit the file by hand. That is refused
//! three times over: the consent gate reads the whole `.shared-hooks`
//! directory as protected configuration, the file-length gate read a
//! 7880-line registry as an oversized source module, and the write gate
//! protects the directory outright. A registry is data, so it gets a command
//! rather than hand editing. The length gate exempts structured data, which
//! removes one of those three refusals; the consent and write gates still
//! stand, so this command remains the way in.
//!
//! The file is edited in place rather than re-serialised: it carries hundreds
//! of entries in the order an operator accumulated them, and rewriting it
//! through `serde_json` would sort every key. One entry is spliced in, and the
//! result is parsed back and compared against the intended document before
//! anything is written, so a splice can never publish a broken registry.

mod grants;
pub(crate) mod ledger;
mod lock;

use std::fs;
use std::path::{Path, PathBuf};

pub use grants::{action_labels, ActionGrant, ACTION_GRANTS};
pub(crate) use lock::Lock;

use serde_json::{Map, Value};

/// Which registry a justification belongs in.
#[derive(Clone, Copy, PartialEq, Eq)]
pub enum Kind {
    File,
    Cua,
    Ssh,
    /// The operator's grant for one gated action.
    Action(&'static ActionGrant),
}

impl Kind {
    pub fn parse(value: &str) -> Option<Self> {
        match value {
            "file" => Some(Self::File),
            "cua" => Some(Self::Cua),
            "ssh" => Some(Self::Ssh),
            other => ACTION_GRANTS
                .iter()
                .find(|grant| grant.label == other)
                .map(Self::Action),
        }
    }

    pub fn label(self) -> &'static str {
        match self {
            Self::File => "file",
            Self::Cua => "cua",
            Self::Ssh => "ssh",
            Self::Action(grant) => grant.label,
        }
    }

    /// Whether the kind is an operator's grant for one gated action, all
    /// kept in one registry.
    pub fn is_action_grant(self) -> bool {
        matches!(self, Self::Action(_))
    }
}

/// The registry file of `kind`, as the gate that reads it defines it under
/// `home` (honouring the variable the CUA or SSH gate reads its registry
/// from), so `tama justify` writes and `tama attestation` lists and revokes
/// the very grants the gate admits through, and no second spelling exists.
pub fn registry_path(home: &Path, kind: Kind) -> PathBuf {
    use tama_hook_tools::ports::{
        block_unauthorized_cua, block_unauthorized_ssh, check_unsubstantiated_constants,
        operator_grant,
    };
    match kind {
        Kind::File => check_unsubstantiated_constants::registry_path_under(home),
        Kind::Cua => block_unauthorized_cua::justifications_path_under(home),
        Kind::Ssh => block_unauthorized_ssh::justification_path_under(home),
        Kind::Action(_) => operator_grant::grants_path_under(home),
    }
}

/// The registry document, or a refusal naming what is wrong with it.
pub fn load(path: &Path) -> Result<Map<String, Value>, String> {
    if !tama_core::presence::present(path).map_err(|error| error.to_string())? {
        return Ok(Map::new());
    }
    let text = fs::read_to_string(path)
        .map_err(|error| format!("cannot read {}: {error}", path.display()))?;
    if text.trim().is_empty() {
        return Ok(Map::new());
    }
    match serde_json::from_str::<Value>(&text) {
        Ok(Value::Object(map)) => Ok(map),
        Ok(_) => Err(format!("{} is not a JSON object", path.display())),
        Err(error) => Err(format!("{} is not valid JSON: {error}", path.display())),
    }
}

/// The byte range of one top-level entry, including the comma that separates
/// it from the next one, so an entry can be replaced or removed in place. A
/// key that cannot be encoded is refused: read as absent, the entry stored
/// under it was written a second time or reported missing.
fn entry_span(text: &str, key: &str) -> Result<Option<(usize, usize)>, String> {
    let bytes = text.as_bytes();
    let needle = serde_json::to_string(key)
        .map_err(|error| format!("the registry key {key:?} cannot be encoded: {error}"))?;
    let mut index = 0usize;
    let mut depth = 0i32;
    let mut in_string = false;
    let mut escaped = false;
    let mut start: Option<usize> = None;
    while index < bytes.len() {
        let byte = bytes[index];
        if in_string {
            if escaped {
                escaped = false;
            } else if byte == b'\\' {
                escaped = true;
            } else if byte == b'"' {
                in_string = false;
            }
            index += 1;
            continue;
        }
        match byte {
            b'"' => {
                if depth == 1 && start.is_none() && text[index..].starts_with(&needle) {
                    start = Some(index);
                }
                in_string = true;
            }
            b'{' | b'[' => depth += 1,
            b'}' | b']' => {
                depth -= 1;
                if depth == 1 {
                    if let Some(begin) = start {
                        let mut end = index + 1;
                        while end < bytes.len() && (bytes[end] as char).is_whitespace() {
                            end += 1;
                        }
                        if end < bytes.len() && bytes[end] == b',' {
                            end += 1;
                        }
                        return Ok(Some((begin, end)));
                    }
                }
            }
            _ => {}
        }
        index += 1;
    }
    Ok(None)
}

fn entry_text(key: &str, entry: &Value) -> Result<String, String> {
    // An entry that cannot be encoded is refused: written as "" or {} it
    // replaced the justification the gate reads with nothing.
    let key_text = serde_json::to_string(key)
        .map_err(|error| format!("the registry key {key:?} cannot be encoded: {error}"))?;
    let body = serde_json::to_string_pretty(entry)
        .map_err(|error| format!("the registry entry for {key:?} cannot be encoded: {error}"))?;
    let indented = body.replace('\n', "\n  ");
    Ok(format!("{key_text}: {indented}"))
}

/// Splice `entry` in as `key`, replacing any entry already stored there.
fn spliced(text: &str, key: &str, entry: &Value) -> Result<String, String> {
    let rendered = entry_text(key, entry)?;
    if let Some((start, end)) = entry_span(text, key)? {
        let tail = &text[end..];
        let separator = if tail.trim_start().starts_with('}') {
            ""
        } else {
            ","
        };
        return Ok(format!("{}{rendered}{separator}{tail}", &text[..start]));
    }
    let open = text
        .find('{')
        .ok_or_else(|| "the registry has no JSON object to write into".to_string())?;
    let rest = &text[open + 1..];
    let separator = if rest.trim_start().starts_with('}') {
        ""
    } else {
        ","
    };
    Ok(format!(
        "{}\n  {rendered}{separator}{rest}",
        &text[..open + 1]
    ))
}

fn without(text: &str, key: &str) -> Result<String, String> {
    let (start, end) =
        entry_span(text, key)?.ok_or_else(|| format!("no justification is recorded for {key}"))?;
    let head = &text[..start];
    let tail = &text[end..];
    if tail.trim_start().starts_with('}') {
        // The removed entry was the last one, so the comma before it now
        // dangles ahead of the closing brace.
        let trimmed = head.trim_end();
        if let Some(head) = trimmed.strip_suffix(',') {
            return Ok(format!("{head}\n{tail}"));
        }
    }
    Ok(format!("{head}{tail}"))
}

pub(crate) fn write_atomically(path: &Path, text: &str) -> Result<(), String> {
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent)
            .map_err(|error| format!("cannot create {}: {error}", parent.display()))?;
    }
    let temporary = path.with_extension(format!("tmp{}", std::process::id()));
    fs::write(&temporary, text)
        .map_err(|error| format!("cannot write {}: {error}", temporary.display()))?;
    fs::rename(&temporary, path)
        .map_err(|error| format!("cannot replace {}: {error}", path.display()))
}

/// Record one entry, refusing rather than writing a document that does not
/// read back as the registry plus exactly that entry.
pub fn record(path: &Path, key: &str, entry: Value) -> Result<(), String> {
    let _lock = Lock::acquire(path)?;
    let mut expected = load(path)?;
    expected.insert(key.to_string(), entry.clone());
    let text = if tama_core::presence::present(path).map_err(|error| error.to_string())? {
        let existing = fs::read_to_string(path)
            .map_err(|error| format!("cannot read {}: {error}", path.display()))?;
        if existing.trim().is_empty() {
            String::from("{\n}\n")
        } else {
            existing
        }
    } else {
        String::from("{\n}\n")
    };
    let candidate = spliced(&text, key, &entry)?;
    verified(&candidate, &expected, path)?;
    write_atomically(path, &candidate)
}

/// Remove one entry, with the same read-back check.
pub fn forget(path: &Path, key: &str) -> Result<(), String> {
    let _lock = Lock::acquire(path)?;
    let mut expected = load(path)?;
    if expected.remove(key).is_none() {
        return Err(format!("no justification is recorded for {key}"));
    }
    let text = fs::read_to_string(path)
        .map_err(|error| format!("cannot read {}: {error}", path.display()))?;
    let candidate = without(&text, key)?;
    verified(&candidate, &expected, path)?;
    write_atomically(path, &candidate)
}

/// Move one entry to a new key when the file it justifies moved, with the
/// same read-back check; the product's own command, so a `git mv` is not
/// followed by an edit of these registries by hand.
pub fn rename(path: &Path, from: &str, to: &str) -> Result<(), String> {
    let _lock = Lock::acquire(path)?;
    let mut expected = load(path)?;
    if expected.contains_key(to) {
        return Err(format!(
            "a justification is already recorded for {to}; remove one of the two first"
        ));
    }
    let Some(entry) = expected.remove(from) else {
        return Err(format!("no justification is recorded for {from}"));
    };
    expected.insert(to.to_string(), entry.clone());
    let text = fs::read_to_string(path)
        .map_err(|error| format!("cannot read {}: {error}", path.display()))?;
    let candidate = spliced(&without(&text, from)?, to, &entry)?;
    verified(&candidate, &expected, path)?;
    write_atomically(path, &candidate)
}

fn verified(candidate: &str, expected: &Map<String, Value>, path: &Path) -> Result<(), String> {
    match serde_json::from_str::<Value>(candidate) {
        Ok(Value::Object(map)) if &map == expected => Ok(()),
        Ok(Value::Object(_)) => Err(format!(
            "the edit would have changed entries other than the one asked for, so {} is unchanged",
            path.display()
        )),
        Ok(_) => Err("the edit would not have produced a JSON object".to_string()),
        Err(error) => Err(format!(
            "the edit would have produced invalid JSON ({error}), so {} is unchanged",
            path.display()
        )),
    }
}

/// One locked transaction for registries with structured top-level metadata.
pub(super) fn update(
    path: &Path,
    mutation: impl FnOnce(Map<String, Value>) -> Result<Map<String, Value>, String>,
) -> Result<(), String> {
    let _lock = Lock::acquire(path)?;
    let expected = mutation(load(path)?)?;
    let candidate = serde_json::to_string_pretty(&expected)
        .map_err(|error| format!("cannot serialize {}: {error}", path.display()))?;
    verified(&candidate, &expected, path)?;
    write_atomically(path, &format!("{candidate}\n"))
}
