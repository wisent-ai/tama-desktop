//! `tama task scope show`: the scope a session declared, and whether it was
//! declared for the instruction being served now.

use std::path::PathBuf;

use serde_json::{json, Value};

use crate::assignment;
use crate::ports::block_off_task_work::TaskScope;
use crate::ports::python_stdlib::expanduser;

/// A declared scope and whether it serves the instruction being served now.
pub struct Shown {
    pub session: String,
    pub scope: TaskScope,
    pub serves_current: bool,
}

impl Shown {
    /// The document `--json` prints and Tama Desktop reads.
    pub fn document(&self) -> Value {
        json!({
            "session": self.session,
            "turn_digest": self.scope.turn_digest,
            "task": self.scope.task,
            "repositories": self.scope.repositories,
            "defect": self.scope.defect,
            "task_id": self.scope.task_id,
            "serves_current_instruction": self.serves_current,
        })
    }
}

/// The scope `session` declared, or `None` when it declared none. A scope or
/// an instruction that cannot be read is the error naming why: read as none,
/// the scope would be shown as declared for an earlier one with nobody
/// knowing.
pub fn shown(session: &str) -> Result<Option<Shown>, String> {
    let home = PathBuf::from(expanduser("~"));
    let Some(scope) = TaskScope::read(session, &home)? else {
        return Ok(None);
    };
    let current = assignment::load(session)
        .map_err(|error| {
            format!(
                "cannot read the instruction for session {session}, so whether its scope \
                 serves it cannot be said: {error}"
            )
        })?
        .map(|instruction| instruction.turn_digest);
    let serves_current =
        current.is_some_and(|digest| !digest.is_empty() && digest == scope.turn_digest);
    Ok(Some(Shown {
        session: session.to_string(),
        scope,
        serves_current,
    }))
}

pub(super) fn show(session: &str, json: bool) -> i32 {
    let shown = match shown(session) {
        Ok(Some(shown)) => shown,
        Ok(None) => {
            eprintln!(
                "session {session} has declared no task scope; declare it with \
                 `tama task scope set --session {session} --repository <NAME>`"
            );
            return libc::EXIT_FAILURE;
        }
        Err(cause) => {
            eprintln!("{cause}");
            return libc::EXIT_FAILURE;
        }
    };
    if json {
        println!("{}", shown.document());
        return libc::EXIT_SUCCESS;
    }
    let scope = &shown.scope;
    // The binding the gate enforces has to be visible to whoever reads a
    // session's scope; otherwise a session can claim one entry and be
    // checked against another without anyone seeing it.
    let entry = match (scope.defect.trim(), scope.task_id.trim()) {
        ("", "") => "nothing — this scope authorises no change".to_string(),
        (defect, "") => format!("defect {defect}"),
        ("", task) => format!("task {task}"),
        (defect, task) => format!("defect {defect} and task {task}"),
    };
    println!("working  {entry}");
    println!("task     {}", scope.task.trim());
    println!("touches  {}", scope.repositories.join(", "));
    println!(
        "current  {}",
        if shown.serves_current {
            "yes — this scope was declared for the instruction being served"
        } else {
            "no — the operator has spoken since; declare the scope of the new instruction"
        }
    );
    libc::EXIT_SUCCESS
}
