//! Oko-s defect register as this gate reads it: where it lives and how a
//! defect is named. The words inside a defect's record are not read: a gate
//! that treats every long hyphenated or underscored word of every open defect
//! as a trigger refuses, with a hundred defects open, an answer naming a
//! field (`source_revision`), a command (`enrol-authenticator`) or the consent
//! variable an install refusal prescribes as a repeated outage. That is
//! keyword logic, which is forbidden.

use serde_json::Value;

pub(super) const DEFECTS_KEY: &str = "defects";
pub(super) const FIXED_KEY: &str = "fixed_in";
pub(super) const ID_KEY: &str = "id";
pub(super) const TITLE_KEY: &str = "title";
pub(super) const FOUND_IN_KEY: &str = "found_in";
/// How Oko prints a defect identifier: the first group of its UUID,
/// lowercased. That is what a session is given when it records one and what
/// a later reader looks up, so that is what an answer has to carry.
// The group's length is the UUID format's: time_low is the first field of
// the string form, https://www.rfc-editor.org/rfc/rfc4122#section-3
pub(super) const SHORT_ID_LENGTH: usize = 8;

pub(super) fn short_id(defect: &Value) -> Option<String> {
    let id = defect.get(ID_KEY).and_then(Value::as_str)?;
    if id.len() < SHORT_ID_LENGTH {
        return None;
    }
    Some(id[..SHORT_ID_LENGTH].to_ascii_lowercase())
}

/// The defect register; a register that does not exist yet holds no
/// defects. One that cannot be read or parsed is the error, named with its
/// path: read as empty, an own defect left unattended would let the stop
/// through.
pub(super) fn document() -> Result<Value, String> {
    let path = tama_core::oko_register("OKO_DEFECT_REGISTER", "defects.json")?;
    let text = match std::fs::read_to_string(&path) {
        Ok(text) => text,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(Value::Null),
        Err(error) => {
            return Err(format!(
                "the defect register {} cannot be read: {error}",
                path.display()
            ))
        }
    };
    serde_json::from_str(&text).map_err(|error| {
        format!(
            "the defect register {} is not JSON: {error}",
            path.display()
        )
    })
}
