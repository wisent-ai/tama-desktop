//! `tama provider config` — the provider hook block an install writes into
//! `~/.claude/settings.json`, `~/.codex/hooks.json` and the hook file of every
//! harness `tama_core::harnesses` declares (Gemini CLI, Qwen Code, Factory
//! Droid, CodeBuddy Code, Cursor, GitHub Copilot CLI, Windsurf, Kimi Code, Devin CLI).
//!
//! The installer owns those files (backup, merge, mode, rollback); this
//! command owns the wiring, so the event/matcher table and the command shape
//! stay in one place: `tama_core::runtime::adapter_config::event_to_codex`
//! for Claude Code and Codex (the coverage report reads installed files back
//! through the same table), the harness declaration for the others.

use std::io::Read;

use serde_json::{Map, Value};
use tama_hook_tools::registry::build_hooks;

use tama_core::exit::{FAILURE, SUCCESS};

mod harness;

/// The command this module answers, as an install runs it from the release's
/// own `bin/tama`.
pub(crate) const COMMAND: &str = "provider config";

const USAGE: &str = "tama provider config --provider <id> --dispatcher <command> [--json]

Reads a registry on stdin and prints the hook block that provider's config
carries, in the shape its file holds it. The providers are claude, codex and
every harness Tama declares an adapter for. The dispatcher is the command an
install writes into the target home, pinned Node included; every printed
command runs it for one hook id.";

/// The value right after `flag`, when it is not another flag.
fn option_value(args: &[String], flag: &str) -> Option<String> {
    let mut rest = args.iter();
    while let Some(argument) = rest.next() {
        if argument == flag {
            return rest
                .next()
                .filter(|value| !value.starts_with("--"))
                .cloned();
        }
    }
    None
}

fn read_registry(text: &str) -> Result<Value, String> {
    let value: Value = serde_json::from_str(text)
        .map_err(|error| format!("{COMMAND} could not parse the registry on stdin: {error}"))?;
    if !value.is_object() {
        return Err(format!("{COMMAND} requires a registry object on stdin"));
    }
    Ok(value)
}

/// Every command the provider would run — what the block is actually worth.
fn commands(block: &Map<String, Value>) -> impl Iterator<Item = &Value> {
    block
        .values()
        .filter_map(Value::as_array)
        .flatten()
        .filter_map(|group| group.get("hooks"))
        .filter_map(Value::as_array)
        .flatten()
}

fn print_human(provider: &str, dispatcher: &str, block: &Map<String, Value>) {
    println!("provider: {provider}");
    println!("dispatcher: {dispatcher}");
    println!("commands: {}", commands(block).count());
    for (event, groups) in block {
        let Some(groups) = groups.as_array() else {
            println!("  {event}: not a list of hook groups: {groups}");
            continue;
        };
        let matchers: Vec<&str> = groups
            .iter()
            // A group that names no matcher runs for every tool, as the
            // provider's hook format reads it.
            .map(|group| {
                group
                    .get("matcher")
                    .and_then(Value::as_str)
                    .unwrap_or("every tool")
            })
            .collect();
        println!("  {event}: {}", matchers.join(", "));
    }
}

fn run(args: &[String]) -> Result<i32, String> {
    if args
        .iter()
        .any(|arg| arg == "help" || arg == "--help" || arg == "-h")
    {
        eprintln!("{USAGE}");
        return Ok(SUCCESS);
    }
    let (Some(provider), Some(dispatcher)) = (
        option_value(args, "--provider"),
        option_value(args, "--dispatcher"),
    ) else {
        eprintln!("{USAGE}");
        return Ok(tama_core::exit::USAGE);
    };
    let providers = harness::providers();
    if !providers.contains(&provider) {
        return Err(format!(
            "{COMMAND} does not configure the provider {provider}; it configures {}",
            providers.join(", ")
        ));
    }
    if dispatcher.trim().is_empty() {
        return Err(format!(
            "{COMMAND} requires a non-empty --dispatcher command"
        ));
    }
    let mut text = String::new();
    std::io::stdin()
        .read_to_string(&mut text)
        .map_err(|error| format!("{COMMAND} could not read the registry on stdin: {error}"))?;
    let registry = read_registry(&text)?;
    let (rendered, block) = match harness::block(&registry, &provider, &dispatcher)? {
        Some(found) => found,
        None => {
            let groups = build_hooks(&registry, &provider, &dispatcher)?;
            (Value::Object(groups.clone()), groups)
        }
    };
    // An empty block is the failure this command exists to name: a config
    // written from it leaves that provider running no policy at all.
    if commands(&block).next().is_none() {
        return Err(format!(
            "{COMMAND} produced no wiring for {provider}: the registry declares no event this provider supports"
        ));
    }
    if args.iter().any(|arg| arg == "--json") {
        let printed = serde_json::to_string_pretty(&rendered).map_err(|error| {
            format!("{COMMAND} could not encode the hook block for {provider}: {error}")
        })?;
        println!("{printed}");
    } else {
        print_human(&provider, &dispatcher, &block);
    }
    Ok(SUCCESS)
}

pub(crate) fn main(args: &[String]) -> i32 {
    match run(args) {
        Ok(code) => code,
        Err(error) => {
            eprintln!("{error}");
            FAILURE
        }
    }
}
