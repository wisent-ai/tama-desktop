//! Whether a signal a shell line sends reaches only processes its own
//! session started: every process `kill`, `pkill` or `killall` names must
//! descend from the agent process the session runs in (the OMP process the
//! core names as `TAMA_SESSION_OWNER_PID`). The processes are read from
//! `ps` and `pgrep`, local programs that answer at once.

use std::collections::HashMap;
use std::process::{Command, Stdio};

use crate::ports::command_path::{computed, shown};

/// The variable the core names the session's agent process in.
const OWNER_ENV: &str = "TAMA_SESSION_OWNER_PID";
/// The signal that only asks whether a process exists (kill(2)).
const PROBE_SIGNAL: &str = "0";

/// Why the signal `kill <args>` sends reaches a process the session did not
/// start, or `None` when it reaches only its own.
pub(super) fn kill(args: &[String]) -> Option<String> {
    let mut operands = Vec::new();
    let mut ended = false;
    let mut words = args.iter();
    while let Some(word) = words.next() {
        if ended || !word.starts_with('-') {
            operands.push(word.clone());
        } else if word == "--" {
            ended = true;
        } else if word == "-l" || word == "-L" {
            return None;
        } else if word == "-s" || word == "-n" {
            if words.next().is_some_and(|signal| signal == PROBE_SIGNAL) {
                return None;
            }
        } else if word.trim_start_matches('-') == PROBE_SIGNAL {
            return None;
        }
    }
    let mut pids = Vec::new();
    for operand in &operands {
        if operand.starts_with('%') {
            continue;
        }
        if computed(operand) {
            return Some(format!(
                "`kill {}` signals a process the shell computes",
                shown(operand)
            ));
        }
        match operand.parse::<i64>() {
            Ok(pid) => pids.push(pid.unsigned_abs()),
            Err(_) => return Some(format!("`kill {operand}` names no process id")),
        }
    }
    foreign(&pids)
}

/// Why `pkill <args>` reaches a process the session did not start: the
/// processes `pgrep` finds with the same selection, signal options aside.
pub(super) fn pkill(args: &[String]) -> Option<String> {
    let mut selection = Vec::new();
    let mut words = args.iter();
    while let Some(word) = words.next() {
        if word == "--signal" {
            words.next();
        } else if !(word.starts_with("--signal=") || is_signal_option(word)) {
            selection.push(word.clone());
        }
    }
    match matched(&selection) {
        Ok(pids) => foreign(&pids),
        Err(cause) => Some(cause),
    }
}

/// Why `killall <args>` reaches a process the session did not start: each
/// process named exactly, as `pgrep -x` finds it.
pub(super) fn killall(args: &[String]) -> Option<String> {
    let mut pids = Vec::new();
    for word in args {
        if is_signal_option(word) || matches!(word.as_str(), "-v" | "-q") {
            continue;
        }
        if word.starts_with('-') {
            return Some(format!(
                "`killall {word}` selects processes in a way this gate does not read"
            ));
        }
        match matched(&["-x".to_string(), word.clone()]) {
            Ok(found) => pids.extend(found),
            Err(cause) => return Some(cause),
        }
    }
    foreign(&pids)
}

/// `-TERM`, `-SIGKILL`, `-9`: a signal named in the option itself.
fn is_signal_option(word: &str) -> bool {
    let name = word.trim_start_matches('-');
    word.starts_with('-')
        && !word.starts_with("--")
        && !name.is_empty()
        && (name.chars().all(|character| character.is_ascii_digit())
            || name.chars().all(|character| character.is_ascii_uppercase()))
}

/// The processes `pgrep <selection>` finds. pgrep(1) ends 0 when one
/// matched, 1 when none did, and higher for a selection it cannot read.
fn matched(selection: &[String]) -> Result<Vec<u64>, String> {
    if let Some(word) = selection.iter().find(|word| computed(word)) {
        return Err(format!(
            "the selection `{}` is a value the shell computes",
            shown(word)
        ));
    }
    let output = Command::new("pgrep")
        .args(selection)
        .stdin(Stdio::null())
        .stderr(Stdio::null())
        .output()
        .map_err(|error| {
            format!("pgrep cannot run to read which processes are selected: {error}")
        })?;
    match output.status.code() {
        Some(0) => Ok(String::from_utf8_lossy(&output.stdout)
            .split_whitespace()
            .filter_map(|pid| pid.parse().ok())
            .collect()),
        Some(1) => Ok(Vec::new()),
        _ => Err(format!(
            "pgrep cannot read the selection `{}`",
            selection.join(" ")
        )),
    }
}

/// Why one of `pids` is a process the session did not start.
fn foreign(pids: &[u64]) -> Option<String> {
    if pids.is_empty() {
        return None;
    }
    let owner: u64 = match std::env::var(OWNER_ENV).ok().and_then(|pid| pid.parse().ok()) {
        Some(owner) => owner,
        None => return Some(format!("{OWNER_ENV} names no agent process, so which processes this session started cannot be read")),
    };
    let parents = match parents() {
        Ok(parents) => parents,
        Err(cause) => return Some(cause),
    };
    let strangers: Vec<String> = pids
        .iter()
        .filter(|pid| !descends(**pid, owner, &parents))
        .map(u64::to_string)
        .collect();
    (!strangers.is_empty()).then(|| {
        format!(
            "process {} was not started by this session (it does not descend from agent process {owner})",
            strangers.join(", ")
        )
    })
}

/// Whether `pid` is `owner` or one of its descendants.
fn descends(pid: u64, owner: u64, parents: &HashMap<u64, u64>) -> bool {
    let mut current = pid;
    for _ in 0..parents.len() + 1 {
        if current == owner {
            return true;
        }
        match parents.get(&current) {
            Some(&parent) if parent != current && parent != 0 => current = parent,
            _ => return false,
        }
    }
    false
}

/// Every process's parent, as `ps -A -o pid= -o ppid=` lists them.
fn parents() -> Result<HashMap<u64, u64>, String> {
    let output = Command::new("ps")
        .args(["-A", "-o", "pid=", "-o", "ppid="])
        .stdin(Stdio::null())
        .stderr(Stdio::null())
        .output()
        .map_err(|error| {
            format!("ps cannot run to read which processes this session started: {error}")
        })?;
    if !output.status.success() {
        return Err(
            "ps did not list the processes, so which ones this session started cannot be read"
                .to_string(),
        );
    }
    Ok(String::from_utf8_lossy(&output.stdout)
        .lines()
        .filter_map(|line| {
            let mut fields = line.split_whitespace();
            Some((fields.next()?.parse().ok()?, fields.next()?.parse().ok()?))
        })
        .collect())
}
