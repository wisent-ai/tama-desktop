//! Detection half of the `shared-hooks/block_unauthorized_ssh.py` port (hook
//! id `block-unauthorized-ssh`): the patterns, the tool tables, and the three
//! functions that read a command line's shape. Split from
//! [`crate::ports::block_unauthorized_ssh`] to stay inside the 300-line limit.
//!
//! Python `re.I` becomes `(?i)` and `re.S` becomes `(?s)`. Three of these
//! patterns cannot be transcribed: Rust's regex engine has no lookaround, and
//! its `$` is end-of-text where Python's also matches before one trailing
//! newline. Each rewrite is justified at its definition, and each preserves
//! the accepted language rather than approximating it.

use std::sync::LazyLock;

use regex::Regex;

use crate::ports::tool_vocabulary::Call;
use crate::ports::transport_common as common;

pub use crate::ports::tool_vocabulary::WRITE_TOOLS;

/// The operations an SSH grant names (the grant schema's own values).
pub const EXEC_OP: &str = "exec";
const TUNNEL_OP: &str = "tunnel";
const GIT_OP: &str = "git";
const TRANSFER_OP: &str = "transfer";

/// The OpenSSH suite's client programs, and rsync, which reaches a remote
/// over SSH whenever it names a remote spec: the transport is these programs'
/// identity, not a word in the command.
const SSH_PROGRAM: &str = "ssh";
const SCP_PROGRAM: &str = "scp";
const SFTP_PROGRAM: &str = "sftp";
const RSYNC_PROGRAM: &str = "rsync";
/// The client libraries that open an SSH connection from a program's own
/// code: Python's paramiko and asyncssh, Fabric's connection, Node's node-ssh
/// and ssh2.
const PARAMIKO_LIBRARY: &str = "paramiko";
const ASYNCSSH_LIBRARY: &str = "asyncssh";
const FABRIC_CONNECTION: &str = r"fabric\.Connection";
const NODE_SSH_LIBRARY: &str = "node-ssh";
const SSH2_LIBRARY: &str = "ssh2";

/// Where a program name starts in a command line, and what ends it.
const PROGRAM_START: &str = r"(?:^|[/\s;&|`(])";
const PROGRAM_END: &str = r"(?:\s|$)";

fn alternation(names: &[&str]) -> String {
    names.join("|")
}

/// `SSH_TOOL_RE`. Python's `$` also matches before one trailing newline, so
/// the alternative is spelled `\n?\z` rather than `$`.
pub static SSH_TOOL_RE: LazyLock<Regex> =
    LazyLock::new(|| common::compile(&format!(r"(?i)(?:^|[._:/-]){SSH_PROGRAM}(?:\n?\z|[._:/-])")));

/// An SSH suite client run as a program. The trailing `(?=\s|$)` lookahead of
/// the Python original is a consumed terminator: the result is only read as
/// a boolean and a candidate exists at the same offsets either way.
static SSH_BINARY_RE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        "(?i){PROGRAM_START}(?:{}){PROGRAM_END}",
        alternation(&[SSH_PROGRAM, SCP_PROGRAM, SFTP_PROGRAM])
    ))
});

/// rsync naming an `ssh://` URL or a `[user@]host:` remote spec. `rsync(?=\s|$).+?`
/// is `rsync\s.*?`: the lookahead's `$` branch can never complete a match.
static RSYNC_REMOTE_RE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        r"(?is){PROGRAM_START}{RSYNC_PROGRAM}\s.*?(?:ssh://|(?:[A-Za-z0-9._-]+@)?[A-Za-z0-9.-]+:)"
    ))
});

/// git naming an `ssh://` remote or a `git@host:` one, restructured the same
/// way as `RSYNC_REMOTE_RE`.
static GIT_SSH_RE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        r"(?is){PROGRAM_START}git\s.*?(?:ssh://|git@[A-Za-z0-9.-]+:)"
    ))
});

static SSH_LIBRARY_RE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        r"(?i)\b(?:{})\b",
        alternation(&[
            PARAMIKO_LIBRARY,
            ASYNCSSH_LIBRARY,
            FABRIC_CONNECTION,
            NODE_SSH_LIBRARY,
            SSH2_LIBRARY
        ])
    ))
});

/// ssh's own forwarding options (`-L`, `-R`, `-D`, `-W`, alone or at the end
/// of a cluster) make the connection a tunnel; Python compiles this without
/// `re.I`, because the options are case-sensitive.
static TUNNEL_RE: LazyLock<Regex> =
    LazyLock::new(|| common::compile(r"(?:^|\s)-(?:[A-Za-z]*[LRDW]|[LRDW])"));

/// A client of the suite whose job is copying files over SSH.
static TRANSFER_RE: LazyLock<Regex> = LazyLock::new(|| {
    common::compile(&format!(
        "(?i){PROGRAM_START}(?:{}){PROGRAM_END}",
        alternation(&[SCP_PROGRAM, SFTP_PROGRAM, RSYNC_PROGRAM])
    ))
});

/// `command_text`: the command line or program this call carries, whatever
/// the tool (an SSH tool carries one too), else the one a process start
/// assembles from its application and arguments; empty when it carries none.
pub fn command_text(call: &Call) -> String {
    if let Some(text) = call.command().or_else(|| call.code()) {
        return text.trim().to_string();
    }
    call.started_command().unwrap_or_default()
}

/// Detect transport in text already projected according to its source language.
pub fn contains_ssh_command(actionable: &str) -> bool {
    SSH_BINARY_RE.is_match(actionable)
        || RSYNC_REMOTE_RE.is_match(actionable)
        || GIT_SSH_RE.is_match(actionable)
        || SSH_LIBRARY_RE.is_match(actionable)
        || crate::ports::block_unauthorized_ssh_targets::SSH_URL_RE.is_match(actionable)
}

/// Classify the same projected text without parsing it again.
pub fn command_operation(actionable: &str) -> String {
    if TUNNEL_RE.is_match(actionable) {
        return TUNNEL_OP.to_string();
    }
    if GIT_SSH_RE.is_match(actionable) {
        return GIT_OP.to_string();
    }
    if TRANSFER_RE.is_match(actionable) {
        TRANSFER_OP.to_string()
    } else {
        EXEC_OP.to_string()
    }
}
