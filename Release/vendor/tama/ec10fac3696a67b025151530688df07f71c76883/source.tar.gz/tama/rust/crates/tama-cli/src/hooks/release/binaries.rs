//! How the one `tama` program lands in `~/.local/bin`, and what a release
//! records about the build it installed.
//!
//! Split out of `hooks/release.rs`, which had grown past the
//! three-hundred-line limit; the release run itself stays there.

use std::collections::BTreeMap;
use std::path::Path;

use sha2::{Digest, Sha256};

/// Where a release records the build of each program it installed, beside
/// the checkout the install came from.
pub(super) const BUILD_DIGESTS_FILE: &str = ".tama/installed-binaries.json";

/// The digest of an installed program; `None` when it is not there. One that
/// cannot be read is an error with its cause, not a missing program.
pub(super) fn build_digest(path: &Path) -> Result<Option<String>, String> {
    match std::fs::read(path) {
        Ok(bytes) => Ok(Some(format!("{:x}", Sha256::digest(bytes)))),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(None),
        Err(error) => Err(format!("cannot read {}: {error}", path.display())),
    }
}

/// What the last release installed: binary name to unsigned build digest.
/// No record is an empty one (a first release); a record that cannot be read
/// or parsed is an error, since the programs it names are removed from the
/// path and its history would otherwise be overwritten unread.
pub(super) fn installed_digests(home: &Path) -> Result<BTreeMap<String, String>, String> {
    let path = home.join(BUILD_DIGESTS_FILE);
    let text = match std::fs::read_to_string(&path) {
        Ok(text) => text,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(BTreeMap::new()),
        Err(error) => return Err(format!("cannot read {}: {error}", path.display())),
    };
    serde_json::from_str(&text).map_err(|error| {
        format!(
            "{} is not a record of installed programs: {error}",
            path.display()
        )
    })
}

/// Record what this release installed, so the next one can leave it alone.
pub(super) fn record_digests(
    home: &Path,
    digests: &BTreeMap<String, String>,
) -> Result<(), String> {
    let path = home.join(BUILD_DIGESTS_FILE);
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)
            .map_err(|error| format!("cannot create {}: {error}", parent.display()))?;
    }
    let text = serde_json::to_string_pretty(digests)
        .map_err(|error| format!("cannot describe what was installed: {error}"))?;
    std::fs::write(&path, format!("{text}\n"))
        .map_err(|error| format!("cannot write {}: {error}", path.display()))
}
