//! Refuse mutations of upstream-owned source, including locally renamed forks.
mod provenance;
mod shell;

use crate::ports::python_stdlib::expanduser;
use crate::ports::tool_vocabulary::{patches_in, paths_in, Call, AST_EDIT_DEVICE, EDITS_KEY};
use serde_json::Value;
use std::path::Path;

/// The structural rewrite a refactor device payload names its targets in.
const REFACTOR: &str = "refactor";

fn patch_paths(patch: &str, targets: &mut Vec<String>) -> Result<(), String> {
    let hashline = crate::ports::write_payload::hashline::touched_paths(patch)?;
    if !hashline.is_empty() {
        targets.extend(hashline);
        return Ok(());
    }
    for line in patch.lines() {
        if let Some(path) = [
            "*** Update File: ",
            "*** Add File: ",
            "*** Delete File: ",
            "*** Move to: ",
        ]
        .iter()
        .find_map(|prefix| line.strip_prefix(prefix))
        {
            targets.push(path.trim().trim_matches('"').to_owned());
        }
    }
    Ok(())
}

fn file_targets(refactor: bool, input: &Value) -> Result<Vec<String>, String> {
    let mut targets: Vec<String> = paths_in(input).into_iter().map(str::to_owned).collect();
    for patch in patches_in(input) {
        patch_paths(patch, &mut targets)?;
    }
    if let Some(patch) = input.as_str() {
        patch_paths(patch, &mut targets)?;
    }
    if let Some(operations) = input.get(EDITS_KEY).and_then(Value::as_array) {
        for operation in operations {
            targets.extend(file_targets(refactor, operation)?);
        }
    }
    if refactor && targets.iter().any(|path| path.contains(['*', '?', '['])) {
        return Err(
            "refactor targets must name concrete files so each source owner can be checked".into(),
        );
    }
    Ok(targets)
}

/// The targets of a write to a tool device: a structural rewrite's or an
/// applied LSP rename's files, read from the JSON the write carries; nothing
/// for any other device, which is no source mutation.
fn device_targets(path: &str, call: &Call) -> Result<Vec<String>, String> {
    if path != AST_EDIT_DEVICE && path != "xd://lsp" {
        return Ok(Vec::new());
    }
    let content = call.content().ok_or("refactor payload has no content")?;
    let refactor: Value =
        serde_json::from_str(content).map_err(|error| format!("unreadable refactor: {error}"))?;
    let changes = refactor["action"]
        .as_str()
        .is_some_and(|action| ["rename", "rename_file", "code_actions"].contains(&action));
    if path == "xd://lsp" && !changes {
        return Ok(Vec::new());
    }
    if refactor["apply"] == false {
        return Ok(Vec::new());
    }
    if path == "xd://lsp" && refactor["action"] == "code_actions" && refactor["apply"] != true {
        return Ok(Vec::new());
    }
    file_targets(true, &refactor)
}

pub fn evaluate(payload: &Value) -> Option<String> {
    let call = Call::of(payload);
    // A directory that cannot be read is no proof the edit stays in our
    // repositories: refused naming the cause, not passed as nothing to judge.
    let cwd = match call.working_dir() {
        Ok(cwd) => cwd,
        Err(error) => {
            return Some(format!(
                "BLOCKED: block-external-source-edits cannot place this call's paths: {error}"
            ))
        }
    };
    if call.is_shell() {
        return shell::refusal(call.command()?, &cwd);
    }
    if !call.changes_files() {
        return None;
    }
    let input = call.input()?;
    let targets = match call.path().filter(|path| path.starts_with("xd://")) {
        Some(device) => device_targets(device, &call),
        None => file_targets(call.is(REFACTOR), input),
    };
    let paths = match targets {
        Ok(paths) => paths,
        Err(error) => {
            return Some(format!(
                "BLOCKED: {error}; no source mutation was authorized"
            ))
        }
    };
    for path in paths {
        if path.contains("://") {
            return Some(format!("BLOCKED: cannot establish external source ownership for mutation target {path}; use the owning product's supported interface"));
        }
        let expanded = expanduser(&path);
        if let Some(reason) = provenance::refusal(Path::new(&expanded), &cwd) {
            return Some(reason);
        }
    }
    None
}
