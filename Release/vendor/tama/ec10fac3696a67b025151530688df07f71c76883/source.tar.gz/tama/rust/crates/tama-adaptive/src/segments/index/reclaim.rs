//! Reclaiming a ready segment once the lake has acknowledged it and every
//! decision in it is persisted.
//!
//! Split out of `segments/index/mod.rs`, which had grown past the
//! three-hundred-line limit; writing segments stays there.

use std::fs;
use std::path::PathBuf;

use super::validate::{decisions_persisted, validate_ack, validate_segment};
use super::{ack_name, folder_names, sync_directory, SegmentWriter};

/// The extension of a closed segment in the ready folder.
pub(super) const READY_SUFFIX: &str = ".jsonl";

pub(super) struct ReadyItem {
    pub(super) path: PathBuf,
    pub(super) ack_path: PathBuf,
    pub(super) reclaimable: bool,
}

impl SegmentWriter {
    /// The ready segment `name`, whether the lake's acknowledgement lets it
    /// go, or why it cannot be read as intact.
    pub(super) fn inspect_ready(&self, name: &str) -> Result<ReadyItem, String> {
        let path = self.ready_dir.join(name);
        let segment = validate_segment(&path)?;
        let ack_path = self.acked_dir.join(ack_name(&segment.segment_id));
        let ack = validate_ack(&ack_path, &segment)?;
        Ok(ReadyItem {
            path,
            ack_path,
            reclaimable: ack.is_some() && decisions_persisted(&segment),
        })
    }

    /// `reclaimAcked()`: removes every acknowledged segment with its
    /// acknowledgement and answers the names that went. A segment that
    /// cannot be read as intact stays and is reported; a removal that fails
    /// ends the sweep and is reported.
    pub fn reclaim_acked(&self) -> Vec<String> {
        let mut reclaimed = Vec::new();
        let names = match folder_names(&self.ready_dir) {
            Ok(names) => names,
            Err(cause) => {
                self.report(&cause);
                return reclaimed;
            }
        };
        for name in names
            .into_iter()
            .filter(|name| name.ends_with(READY_SUFFIX))
        {
            let item = match self.inspect_ready(&name) {
                Ok(item) if item.reclaimable => item,
                Ok(_) => continue,
                Err(cause) => {
                    self.report(&cause);
                    continue;
                }
            };
            let removed = fs::remove_file(&item.path)
                .and_then(|()| sync_directory(&self.ready_dir))
                .and_then(|()| fs::remove_file(&item.ack_path))
                .and_then(|()| sync_directory(&self.acked_dir));
            if let Err(error) = removed {
                self.report(&format!("the segment {name} cannot be reclaimed: {error}"));
                return reclaimed;
            }
            reclaimed.push(name);
        }
        reclaimed
    }
}
