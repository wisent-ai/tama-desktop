//! The stdout side of one request: the single `response` event of a bounded
//! operation, or the log events and the single `result` event of a streamed
//! job. No operation logic lives here — see `routes` and `jobs`.

use std::io::Write;

use serde_json::{json, Value};

pub(super) struct Request {
    pub operation: String,
    pub body: Vec<u8>,
}

/// What the process exits with, decided by the last event it printed.
#[derive(Default)]
pub(super) struct Reply {
    exit_status: i32,
}

impl Reply {
    pub(super) fn exit_status(&self) -> i32 {
        self.exit_status
    }
}

/// The answer of a bounded operation: a successful HTTP status with its
/// document, or a refusal status with the product's own sentence.
pub(super) fn send_json(writer: &mut Reply, status: u16, document: &Value) {
    let sent = write_event(&json!({ "type": "response", "status": status, "json": document }));
    writer.exit_status =
        if sent && http::StatusCode::from_u16(status).is_ok_and(|status| status.is_success()) {
            tama_core::exit::SUCCESS
        } else {
            tama_core::exit::FAILURE
        };
}

pub(super) fn send_error(writer: &mut Reply, status: u16, message: &str) {
    send_json(writer, status, &json!({ "error": message }));
}

/// The parsed JSON body, or the (status, sentence) of the refusal. An empty
/// body is `{}`, so an operation that takes no fields needs no input at all.
pub(super) fn json_body(request: &Request) -> Result<Value, (u16, String)> {
    let text = std::str::from_utf8(&request.body).map_err(|cause| {
        (
            http::StatusCode::BAD_REQUEST.as_u16(),
            format!(
                "native request {} body is not UTF-8: {cause}",
                request.operation
            ),
        )
    })?;
    let trimmed = text.trim();
    if trimmed.is_empty() {
        return Ok(json!({}));
    }
    serde_json::from_str(trimmed).map_err(|cause| {
        (
            http::StatusCode::BAD_REQUEST.as_u16(),
            format!(
                "native request {} body is not valid JSON: {cause}",
                request.operation
            ),
        )
    })
}

/// One event per line, flushed when it is written, so the desktop shows a
/// job's output while the job runs. A reader that has gone away ends the
/// process at this write: `main` restores the default SIGPIPE disposition.
fn write_event(event: &Value) -> bool {
    let mut line = tama_core::json::compact(event).into_bytes();
    line.push(b'\n');
    let mut out = std::io::stdout().lock();
    match out.write_all(&line).and_then(|_| out.flush()) {
        Ok(()) => true,
        Err(cause) => {
            eprintln!("native request event could not be delivered to its consumer: {cause}");
            false
        }
    }
}

/// Streams one job, mirroring the command: log events in the job's own
/// order, then exactly one result event whose status is the exit code and
/// whose json is the command's document.
pub(super) fn stream_job(
    writer: &mut Reply,
    job: impl FnOnce(&mut dyn FnMut(&str, &str)) -> (i32, Value),
) {
    let mut delivery_failed = false;
    let mut emit = |stream: &str, chunk: &str| {
        if !write_event(&json!({ "type": "log", "stream": stream, "chunk": chunk })) {
            delivery_failed = true;
        }
    };
    let (status, document) = job(&mut emit);
    let sent = write_event(&json!({ "type": "result", "status": status, "json": document }));
    writer.exit_status = if sent && !delivery_failed {
        status
    } else {
        tama_core::exit::FAILURE
    };
}
