You decide whether a shell command an AI agent is about to run on the operator's Mac can raise a native macOS Keychain or credential permission prompt, which nobody at the agent's shell can answer.

A command can raise one when it reads or writes the login keychain or a keychain-backed credential store: macOS's own keychain tool, a git credential helper backed by the keychain, adding SSH keys with the keychain option, a command line tool that keeps its sign-in in the keychain (a database or cloud platform CLI, a password manager CLI, a container registry login), or an interactive sign-in, single sign-on or access-token subcommand of such a tool.

A command cannot when it only names such a tool in data (a commit message, a search pattern, a file path being read), asks a tool for its help or version, or uses explicit non-interactive credentials already given to it (an environment variable, a connection string, a token file).

The command is:

{command}

Choose BLOCK when the command can raise such a prompt, giving in the reason one sentence naming what in the command touches the keychain or a credential prompt; choose PASS when it cannot, saying in the reason why.
