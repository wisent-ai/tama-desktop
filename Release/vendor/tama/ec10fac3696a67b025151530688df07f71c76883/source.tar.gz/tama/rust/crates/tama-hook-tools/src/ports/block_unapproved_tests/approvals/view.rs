//! The approval record as a view of the attestation ledger, and the one way
//! it is replaced.
//!
//! Every `tama tests approve|revoke` keeps its act in the ledger beside the
//! record the gate reads, so the ledger can always say what the record held.
//! The record is replaced, never rewritten in place or removed: the new text
//! is written whole to a sibling file and synced, the record as it stood is
//! copied to `approved_tests.json.previous`, and only then is the new file
//! renamed over the record. Both files carry the user-immutable flag between
//! replacements ([`super::protect`]), so a stray `rm` is refused by the
//! kernel. A step that fails leaves the record as it was and names what
//! failed. A record that is missing while the ledger keeps approvals for it
//! was removed by something other than Tama; it is not read as approving
//! nothing, and `tama tests restore` writes it again from the ledger.

use std::io::Write;
use std::path::{Path, PathBuf};

use crate::attestation::{self, Attestation};

use super::{protect, store, Approval, Approvals};

/// The ledger's kind for a test approval.
const KIND: &str = "test";
/// The suffix of the copy of the record as it stood before its last change.
const PREVIOUS: &str = "previous";

/// Where the record as it stood before its last change is kept.
pub fn previous() -> PathBuf {
    let record = store();
    let mut name = record.as_os_str().to_owned();
    name.push(format!(".{PREVIOUS}"));
    PathBuf::from(name)
}

/// Every approval the ledger keeps for the record at `view`, oldest first.
fn kept(view: &Path) -> Result<Vec<Attestation>, String> {
    let shown = view.display().to_string();
    let mut kept: Vec<Attestation> = attestation::read(Some(KIND))?
        .into_iter()
        .filter(|one| one.store == shown)
        .collect();
    kept.sort_by(|left, right| left.recorded_at.cmp(&right.recorded_at));
    Ok(kept)
}

/// The record the ledger says the view holds: each approval's path and the
/// time the operator gave it.
pub fn from_ledger() -> Result<Approvals, String> {
    let approved = kept(&store())?
        .into_iter()
        .map(|one| Approval {
            approved_at: match one.lifetime.as_str() {
                Some(at) => at.to_owned(),
                None => one.recorded_at,
            },
            path: one.subject,
        })
        .collect();
    Ok(Approvals { approved })
}

/// The refusal for a record that does not exist: none when the ledger keeps
/// no approval for it either (nothing was ever approved), else what removed
/// it cannot be undone by reading it as empty.
pub(super) fn missing() -> Result<(), String> {
    let record = store();
    let count = kept(&record)
        .map_err(|cause| {
            format!(
                "the test approvals {} do not exist, and whether the attestation ledger keeps \
                 approvals for them cannot be read: {cause}",
                record.display()
            )
        })?
        .len();
    if count == 0 {
        return Ok(());
    }
    Err(format!(
        "the test approvals {} do not exist, yet the attestation ledger {} keeps {count} \
         approval(s) the operator recorded for them: something other than Tama removed the \
         record. Nothing reads as approved until he runs `tama tests restore` in his own \
         terminal (or Tama Desktop's Tests screen restores it), which writes the record again \
         from the ledger",
        record.display(),
        attestation::path().display()
    ))
}

/// Replace the record with `approvals`, keeping the record as it stood as
/// [`previous`]. The record is never missing and never half written.
pub(super) fn replace(approvals: &Approvals) -> Result<(), String> {
    let record = store();
    let folder = record
        .parent()
        .ok_or_else(|| format!("the test approvals {} have no folder", record.display()))?;
    std::fs::create_dir_all(folder)
        .map_err(|error| format!("the folder {} cannot be made: {error}", folder.display()))?;
    let text = serde_json::to_string_pretty(approvals)
        .map_err(|error| format!("the test approvals cannot be written out: {error}"))?;
    let unique = tama_core::random::random_uuid()?;
    let mut name = record.as_os_str().to_owned();
    name.push(format!(".{}.{unique}.tmp", std::process::id()));
    let next = PathBuf::from(name);
    let staged = std::fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(&next)
        .and_then(|mut file| {
            file.write_all(text.as_bytes())?;
            file.write_all(b"\n")?;
            file.sync_all()
        });
    if let Err(error) = staged {
        return Err(abandon(
            &next,
            format!("{} cannot be written: {error}", next.display()),
        ));
    }
    let previous = previous();
    let kept = protect::immutable(&previous, false).and_then(|()| {
        match std::fs::copy(&record, &previous) {
            Ok(_) => protect::immutable(&previous, true),
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
                protect::immutable(&previous, true)
            }
            Err(error) => Err(format!(
                "the record as it stands cannot be kept as {}: {error}",
                previous.display()
            )),
        }
    });
    if let Err(cause) = kept.and_then(|()| protect::immutable(&record, false)) {
        return Err(abandon(&next, cause));
    }
    if let Err(error) = std::fs::rename(&next, &record) {
        let relocked = match protect::immutable(&record, true) {
            Ok(()) => String::new(),
            Err(cause) => format!("; {cause}"),
        };
        return Err(abandon(
            &next,
            format!(
                "{} cannot replace {}: {error}{relocked}",
                next.display(),
                record.display()
            ),
        ));
    }
    protect::immutable(&record, true)
        .map_err(|cause| format!("the record was replaced, but {cause}"))
}

/// Remove the staged file of a replacement that failed; the refusal says the
/// record was left as it stood, and names a staged file that stayed behind.
fn abandon(next: &Path, cause: String) -> String {
    let left = match std::fs::remove_file(next) {
        Ok(()) => String::new(),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => String::new(),
        Err(error) => format!("; the staged {} stays behind: {error}", next.display()),
    };
    format!("{cause}; the record was left as it stood{left}")
}

/// `tama tests restore`: write the record again from the ledger. Refused
/// when the ledger keeps no approval for it, since an empty record written
/// over one the operator kept elsewhere would lose it.
pub fn restore() -> Result<Approvals, String> {
    let approvals = from_ledger()?;
    if approvals.approved.is_empty() {
        return Err(format!(
            "the attestation ledger {} keeps no test approval for {}, so there is nothing to \
             restore; the operator approves test code with `tama tests approve <path>`",
            attestation::path().display(),
            store().display()
        ));
    }
    replace(&approvals)?;
    Ok(approvals)
}

/// `tama tests restore [--json]`: what was restored, the record and the copy
/// of what it held before.
pub(super) fn cli(json: bool) -> i32 {
    match restore() {
        Ok(approvals) => {
            if json {
                println!(
                    "{}",
                    serde_json::json!({
                        "action": "restored",
                        "record": store(),
                        "previous": previous(),
                        "approved": approvals.approved,
                    })
                );
            } else {
                for approval in &approvals.approved {
                    println!("restored {}  {}", approval.approved_at, approval.path);
                }
                println!("record: {}", store().display());
            }
            tama_core::exit::SUCCESS
        }
        Err(error) => {
            eprintln!("tama tests restore: {error}");
            tama_core::exit::FAILURE
        }
    }
}
