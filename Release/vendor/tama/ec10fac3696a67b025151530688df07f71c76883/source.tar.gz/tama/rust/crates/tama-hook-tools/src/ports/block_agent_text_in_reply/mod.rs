//! Decision half of `tama hook block-agent-text-in-reply` (hook id
//! `block-agent-text-in-reply`): an answer that ends a turn is written for
//! the operator, so it carries none of the agent's internal text — a commit,
//! build, job, session or defect id, a date of an incident, a fleet host or
//! account name, or a vault item id. The operator reads what changed and
//! why; the ids are Oko's and Git's to keep.
//!
//! The answer is read exactly as [`block_internal_names`] reads a file a
//! write leaves ([`block_internal_names::findings`]): a hash or a date counts
//! where a line is prose, so a path or a value inside a code fence is data,
//! and names are read from their owners, never listed here. An id the
//! operator himself asked to see passes once he said it: a grant recorded
//! with `tama justify record --kind reply-text` whose actions are the ids,
//! quoted from his own message ([`crate::ports::operator_grant`]).
//!
//! No model, no network, no lock: the payload, the name sources
//! `block-internal-names` reads, and on a finding the grant registry and the
//! session's transcript.

use serde_json::Value;
use tama_hooks::session_record::last_assistant_message;

use crate::ports::block_internal_names::{findings, load_names};
use crate::ports::operator_grant::{self, Request};

pub const HOOK_ID: &str = "block-agent-text-in-reply";
pub const GRANT_KIND: &str = "reply-text";

/// The refusal for the answer `payload` ends the turn with, `None` when it
/// carries no internal text or the operator granted every id it names.
pub fn evaluate(payload: &Value) -> Option<String> {
    let answer = last_assistant_message(payload)?;
    let found = findings(answer, &load_names());
    if found.is_empty() {
        return None;
    }
    let mut texts: Vec<String> = found.iter().map(|finding| finding.text.clone()).collect();
    texts.sort();
    texts.dedup();
    let request = Request {
        gate: HOOK_ID,
        command: None,
        paths: &texts,
    };
    if operator_grant::granted(payload, &request) {
        return None;
    }
    let listed = found
        .iter()
        .map(|finding| {
            format!(
                "{} `{}` in: {}",
                finding.kind, finding.text, finding.context
            )
        })
        .collect::<Vec<_>>()
        .join("; ");
    Some(format!(
        "BLOCKED ({HOOK_ID}): this answer carries the agent's internal text: {listed}. The \
         operator reads what changed and why in plain words; ids, incident dates, host, account \
         and vault item names stay in Oko and Git. Write the answer again without them. {}",
        operator_grant::how_to_grant(GRANT_KIND, HOOK_ID)
    ))
}
