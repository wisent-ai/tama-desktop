//! `tama hooks stage`: put the native programs a prepared hook release's
//! registry runs into its `bin/`, built from the source tree it was assembled
//! from, and write `native-hook-binaries.json` naming each one and the source
//! identity they were built from.

use std::collections::BTreeSet;
use std::path::{Path, PathBuf};
use std::process::Command;

use serde_json::{json, Value};
use tama_hook_tools::ports::python_stdlib::shlex_split;

use super::cargo;
use super::identity::{source_identity, verify_source_identity};
use super::{load_object, write_json};

pub(crate) const NATIVE_MANIFEST_SCHEMA: &str = "ai.wisent.tama.native-hook-binaries.v1";
/// The one program Tama builds; every hook is one of its subcommands.
const UNIFIED_CLI: &str = "tama";
const HOOK_PROGRAM_PREFIX: &str = "tama-";
const RUST_SOURCE: &str = ".rs";

/// The program a hook command runs, by file name.
pub(crate) fn command_program(command: &str) -> Result<Option<String>, String> {
    let words = shlex_split(command)
        .ok_or_else(|| format!("Invalid hook command {command:?}: unbalanced quoting"))?;
    let Some(first) = words.first() else {
        return Ok(None);
    };
    let name = Path::new(first).file_name().ok_or_else(|| {
        format!("Invalid hook command {command:?}: {first} names no program file")
    })?;
    Ok(Some(name.to_string_lossy().to_string()))
}

/// The programs of every `command` at any depth; with `rust_only`, only
/// those whose object also names a Rust `source`.
fn command_names(
    value: &Value,
    rust_only: bool,
    names: &mut BTreeSet<String>,
) -> Result<(), String> {
    match value {
        Value::Object(object) => {
            if let Some(command) = object.get("command").and_then(Value::as_str) {
                let rust = object
                    .get("source")
                    .and_then(Value::as_str)
                    .is_some_and(|source| source.ends_with(RUST_SOURCE));
                if !rust_only || rust {
                    if let Some(program) = command_program(command)? {
                        if !program.is_empty() {
                            names.insert(program);
                        }
                    }
                }
            }
            for nested in object.values() {
                command_names(nested, rust_only, names)?;
            }
        }
        Value::Array(items) => {
            for nested in items {
                command_names(nested, rust_only, names)?;
            }
        }
        _ => {}
    }
    Ok(())
}

fn codesign(identity: &str, timestamp: &str, binary: &Path) -> Result<(), String> {
    for arguments in [
        vec![
            "--force",
            "--sign",
            identity,
            "--options",
            "runtime",
            timestamp,
        ],
        vec!["--verify", "--strict"],
    ] {
        let status = stado_wait::status(Command::new("codesign").args(&arguments).arg(binary))
            .map_err(|error| format!("cannot run codesign: {error}"))?;
        if !status.success() {
            return Err(format!(
                "codesign {} {} exited {status}",
                arguments.join(" "),
                binary.display()
            ));
        }
    }
    Ok(())
}

/// The identity the native programs are signed with and the timestamp flag
/// codesign is given, both named by the caller.
pub(super) struct Signing {
    pub identity: String,
    pub timestamp: String,
}

pub(super) fn package_native_binaries(
    release: &Path,
    source_root: &Path,
    cargo_program: &Path,
    signing: Option<&Signing>,
) -> Result<(), String> {
    let identity = source_identity(source_root, Some(release))?;
    let registry = load_object(&release.join("shared-hooks/registry.json"))?;
    let metadata = cargo::metadata(cargo_program, source_root)?;
    let targets = cargo::binary_targets(&metadata)?;
    let mut registered = BTreeSet::new();
    command_names(&registry, false, &mut registered)?;
    let mut hook_names = BTreeSet::new();
    command_names(&registry, true, &mut hook_names)?;
    hook_names.extend(
        registered
            .into_iter()
            .filter(|name| name.starts_with(HOOK_PROGRAM_PREFIX)),
    );
    let missing: Vec<&String> = hook_names
        .iter()
        .filter(|name| !targets.contains_key(*name))
        .collect();
    if !missing.is_empty() {
        let missing: Vec<&str> = missing.iter().map(|name| name.as_str()).collect();
        return Err(format!(
            "Registry Rust hook commands lack Cargo binary targets: {}",
            missing.join(", ")
        ));
    }
    if hook_names.is_empty() {
        return Err("Registry does not reference any Cargo hook binaries".to_string());
    }
    let additional: Vec<&str> = [UNIFIED_CLI]
        .into_iter()
        .filter(|name| !hook_names.contains(*name))
        .collect();
    if let Some(name) = additional.iter().find(|name| !targets.contains_key(**name)) {
        return Err(format!(
            "Cargo metadata is missing requested binaries: {name}"
        ));
    }
    let selected: Vec<&cargo::Target> = hook_names
        .iter()
        .map(String::as_str)
        .chain(additional.iter().copied())
        .map(|name| &targets[name])
        .collect();
    let artifacts = cargo::build(cargo_program, &metadata, &selected)?;
    let binary_root = release.join("bin");
    // A previous build's binary that stays would be sealed into this release.
    match std::fs::remove_dir_all(&binary_root) {
        Err(error) if error.kind() != std::io::ErrorKind::NotFound => {
            return Err(format!("cannot clear {}: {error}", binary_root.display()));
        }
        _ => {}
    }
    std::fs::create_dir_all(&binary_root)
        .map_err(|error| format!("cannot create {}: {error}", binary_root.display()))?;
    for (name, artifact) in &artifacts {
        let destination = binary_root.join(name);
        // A copy keeps the permissions Cargo built the executable with.
        std::fs::copy(artifact, &destination).map_err(|error| {
            format!(
                "cannot copy {} to {}: {error}",
                artifact.display(),
                destination.display()
            )
        })?;
        if let Some(signing) = signing {
            codesign(&signing.identity, &signing.timestamp, &destination)?;
        }
    }
    let workspace = metadata["workspace_root"]
        .as_str()
        .map(PathBuf::from)
        .ok_or("cargo metadata names no workspace_root, so no target's source can be named")?;
    verify_source_identity(source_root, &identity)?;
    let entry = |name: &str| cargo::manifest_entry(&targets[name], &workspace);
    let hooks = hook_names
        .iter()
        .map(|name| entry(name))
        .collect::<Result<Vec<_>, String>>()?;
    let executables = additional
        .iter()
        .map(|name| entry(name))
        .collect::<Result<Vec<_>, String>>()?;
    let manifest = json!({
        "schema": NATIVE_MANIFEST_SCHEMA,
        "sourceIdentity": identity,
        "hooks": hooks,
        "additionalExecutables": executables,
    });
    write_json(&release.join("native-hook-binaries.json"), &manifest)
}
