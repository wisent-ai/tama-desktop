//! Brama reached over a relay this process owns, when this machine's own
//! resolver hands out no route.
//!
//! The fleet route is the host resolver's adapter: an address `stado service
//! directory connect` answers and the resolver's listener serves. A resolver
//! that stopped leaves that address unserved, and a judge, a review gate or
//! a `violations clean` on this workstation then had no Brama at all while
//! Brama answered on its own host and the fleet channel to that host was
//! open. `stado resolver relay` is the product's route for exactly that
//! case: it reads the directory from the authority, resolves Brama for this
//! consumer, binds a loopback address this host hands out and carries each
//! connection over its own SSH session to Brama's host, for as long as its
//! owner holds its standard input. This process is that owner: the relay is
//! started when the fleet route fails, lives inside the credentials for one
//! request, and is let go with them. Its URL is never remembered: it is this
//! process's, and dies with it.

use std::io::{BufRead, BufReader};
use std::net::Ipv4Addr;
use std::process::{Child, Command, Stdio};

use super::credentials::{adapter_consumer, router_endpoint};

/// A running `stado resolver relay` this process owns. Dropping it closes the
/// relay's standard input, which is how the relay learns its owner is gone,
/// and collects its end.
pub struct Relay {
    child: Option<Child>,
    operation: String,
}

impl Drop for Relay {
    fn drop(&mut self) {
        let Some(mut child) = self.child.take() else {
            return;
        };
        drop(child.stdin.take());
        let what = format!(
            "the Brama relay ending after its owner let go ({})",
            self.operation
        );
        if let Err(error) = stado_wait::child_output(child, what) {
            eprintln!("the Brama relay could not be collected after its owner let go: {error}");
        }
    }
}

impl Relay {
    /// The relay process this process owns, ended by closing its standard
    /// input.
    fn owning(child: Child, operation: String) -> Self {
        Self {
            child: Some(child),
            operation,
        }
    }
}

/// A loopback port this host hands out now, as the product binds one.
fn free_port(program: &str) -> Result<u16, String> {
    let operation = format!("{program} host local port");
    let output = stado_wait::output(
        Command::new(program)
            .args(["host", "local", "port"])
            .stdin(Stdio::null()),
    )
    .map_err(|error| format!("cannot take a port for the Brama relay with {operation}: {error}"))?;
    if !output.status.success() {
        return Err(format!(
            "{operation} failed ({}): {}",
            output.status,
            String::from_utf8_lossy(&output.stderr).trim()
        ));
    }
    let printed = String::from_utf8_lossy(&output.stdout);
    printed.trim().parse().map_err(|error| {
        format!(
            "{operation} printed {:?}, not a port: {error}",
            printed.trim()
        )
    })
}

/// The relay's first line: its announcement, or why none came.
pub(super) fn announcement(child: &mut Child, operation: &str) -> Result<String, String> {
    let stdout = child
        .stdout
        .as_mut()
        .ok_or_else(|| format!("the relay's standard output was not captured ({operation})"))?;
    let mut announced = String::new();
    stado_wait::blocking(
        stado_wait::Kind::Process,
        "the Brama relay's announcement",
        operation,
        || BufReader::new(stdout).read_line(&mut announced),
    )
    .map_err(|error| {
        format!("the relay's announcement could not be read ({operation}): {error}")
    })?;
    if announced.trim().is_empty() {
        return Err(format!(
            "the relay ended before announcing a route ({operation})"
        ));
    }
    Ok(announced)
}

/// What a relay that announced nothing said as it ended.
pub(super) fn ended_without_route(child: Child, operation: &str, cause: &str) -> String {
    let what = format!("the Brama relay ending without a route ({operation})");
    match stado_wait::child_output(child, what) {
        Ok(output) => format!(
            "{cause}; the relay refused ({}): {}",
            output.status,
            String::from_utf8_lossy(&output.stderr).trim()
        ),
        Err(error) => format!("{cause}; and it ended unreadably: {error}"),
    }
}

/// Brama over a relay this process owns: the URL to post to and the relay
/// itself. `fleet_failure` is why the fleet route could not be used, kept in
/// every refusal so a relay that fails too names both causes.
pub(super) fn open(fleet_failure: &str) -> Result<(String, Relay), String> {
    let program = crate::assignment::rules::stado_cli()
        .map_err(|error| format!("{fleet_failure}; and no relay could be opened: {error}"))?;
    let port = free_port(&program)
        .map_err(|error| format!("{fleet_failure}; and no relay could be opened: {error}"))?;
    let bind = format!("{}:{port}", Ipv4Addr::LOCALHOST);
    let adapter = adapter_consumer()
        .map_err(|error| format!("{fleet_failure}; and no relay could be opened: {error}"))?;
    let operation =
        format!("{program} resolver relay brama --consumer {adapter} --bind {bind} --json");
    let mut child = Command::new(&program)
        .args([
            "resolver",
            "relay",
            "brama",
            "--consumer",
            &adapter,
            "--bind",
            &bind,
            "--json",
        ])
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .map_err(|error| {
            format!("{fleet_failure}; and the relay could not start ({operation}): {error}")
        })?;
    let announced = match announcement(&mut child, &operation) {
        Ok(announced) => announced,
        Err(cause) => {
            return Err(format!(
                "{fleet_failure}; {}",
                ended_without_route(child, &operation, &cause)
            ))
        }
    };
    let relay = Relay::owning(child, operation.clone());
    let answer: serde_json::Value = serde_json::from_str(&announced).map_err(|error| {
        format!("{fleet_failure}; and the relay's announcement is not a document ({operation}): {error}: {announced:?}")
    })?;
    let url = answer
        .get("url")
        .and_then(serde_json::Value::as_str)
        .filter(|url| !url.trim().is_empty())
        .ok_or_else(|| {
            format!("{fleet_failure}; and the relay announced no url ({operation}): {announced:?}")
        })?;
    router_endpoint(url)
        .map_err(|error| format!("invalid Brama relay route from {operation}: {error}"))?;
    Ok((url.to_owned(), relay))
}
