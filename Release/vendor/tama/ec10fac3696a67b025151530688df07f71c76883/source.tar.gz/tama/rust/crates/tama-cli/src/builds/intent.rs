//! One recorded intent: the options that describe it, the document written
//! to the registry, and the sentences a later reader gets back.
//!
//! Split out of `builds/mod.rs` so both halves stay inside the
//! three-hundred-line limit; `mod.rs` keeps the command, this keeps what an
//! entry is.

use std::path::PathBuf;

use serde_json::{json, Value};

use super::policy;

/// Seconds in a minute, the non-SI unit the SI accepts at sixty seconds:
/// https://www.bipm.org/en/publications/si-brochure (Table 8, minute).
pub const SECONDS_PER_MINUTE: u64 = 60;
/// The field the gate reads to decide whether an entry still authorizes.
const EXPIRES_FIELD: &str = "expires_at_epoch";
/// A source revision is a full git object name, the forty hexadecimal digits
/// of a SHA-1 object id: https://git-scm.com/docs/gitglossary#def_object_name
const REVISION_CHARS: usize = 40;

/// The value that follows `name` in `argv`, when `name` is there and a value
/// follows it.
pub fn option(argv: &[String], name: &str) -> Option<String> {
    let mut items = argv.iter();
    items.find(|item| *item == name)?;
    items.next().cloned()
}

pub fn home(argv: &[String]) -> Result<PathBuf, String> {
    match option(argv, "--home") {
        Some(value) => Ok(PathBuf::from(value)),
        None => std::env::var_os("HOME")
            .map(PathBuf::from)
            .ok_or_else(|| String::from("HOME is not set, so the registry has no home")),
    }
}

/// Seconds since the epoch. A clock set before it has no time to record an
/// authorization at, or to judge one's window by: an entry recorded at zero
/// would expire at once or never, so the command refuses and says how far
/// before the epoch the clock reads.
pub fn now() -> Result<u64, String> {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|elapsed| elapsed.as_secs())
        .map_err(|error| {
            format!(
                "the system clock reads {:?} before 1970, so no authorization time can be \
                 recorded or compared",
                error.duration()
            )
        })
}

pub fn refuse(message: &str) -> i32 {
    eprintln!("{message}");
    tama_core::exit::FAILURE
}

pub fn kind_of(argv: &[String]) -> Result<String, String> {
    let Some(named) = option(argv, "--kind") else {
        return Err(String::from("--kind is required: build or restart"));
    };
    super::policy::Kind::parse(&named)
        .map(|kind| kind.as_str().to_string())
        .ok_or_else(|| format!("--kind is build or restart, not {named}"))
}

pub fn target_of(argv: &[String]) -> Result<String, String> {
    match option(argv, "--target") {
        Some(target) if !target.trim().is_empty() => Ok(target.trim().to_string()),
        _ => Err(String::from(
            "--target is required: the product a build carries or the unit a restart cycles",
        )),
    }
}

/// How long this entry authorizes. The policy's window is both the value when
/// the option is absent and the ceiling when it is present, so an entry cannot
/// outlast the operator's own number.
pub fn minutes_of(argv: &[String], policy: &policy::Policy) -> Result<u64, String> {
    let ceiling = policy.window_minutes;
    let Some(value) = option(argv, "--minutes") else {
        return Ok(ceiling);
    };
    let minutes: std::num::NonZeroU64 = value
        .parse()
        .map_err(|_| format!("--minutes is a whole number of minutes above zero, not {value}"))?;
    if minutes.get() > ceiling {
        return Err(format!(
            "--minutes is at most {ceiling}, the window this machine's policy allows; an \
             authorization that stands longer is a standing permission"
        ));
    }
    Ok(minutes.get())
}

pub fn entry(
    argv: &[String],
    policy: &policy::Policy,
    kind: &str,
    target: &str,
) -> Result<Value, String> {
    let reason = option(argv, "--reason")
        .filter(|reason| !reason.trim().is_empty())
        .ok_or_else(|| format!("--reason must say what this {kind} is for"))?;
    let revision = option(argv, "--revision");
    if kind == "build" {
        let named = revision.as_deref().ok_or_else(|| {
            String::from("--revision is required for a build: the source revision it carries")
        })?;
        if named.len() != REVISION_CHARS || !named.bytes().all(|byte| byte.is_ascii_hexdigit()) {
            return Err(format!(
                "--revision is a full {REVISION_CHARS}-character source revision, not {named}"
            ));
        }
    }
    let completed = if kind == "build" {
        let named = option(argv, "--completed-task")
            .filter(|completed| !completed.trim().is_empty())
            .ok_or_else(|| {
                String::from(
                    "--completed-task is required for a build: state which whole task is \
                     finished before building",
                )
            })?;
        Some(named.trim().to_string())
    } else {
        None
    };
    let recorded_at = now()?;
    let mut document = json!({
        "kind": kind,
        "target": target,
        "reason": reason,
        "recorded_at_epoch": recorded_at,
        "expires_at_epoch": recorded_at + minutes_of(argv, policy)? * SECONDS_PER_MINUTE,
    });
    if let Some(revision) = revision {
        document["revision"] = json!(revision);
    }
    if let Some(completed) = completed {
        document["completed_task"] = json!(completed);
    }
    // The recording session is named when the harness names it; a name that
    // is not text is refused rather than left off the entry unsaid.
    match std::env::var("TAMA_SESSION_ID") {
        Ok(session) => document["session"] = json!(session),
        Err(std::env::VarError::NotPresent) => {}
        Err(error) => {
            return Err(format!(
                "TAMA_SESSION_ID cannot name the session recording this {kind}: {error}"
            ))
        }
    }
    Ok(document)
}

/// `--json` prints the document; a plain run prints the sentence a person
/// reads, because a registry entry exists to be read later by somebody who was
/// not there when it was written.
pub fn emit(json: bool, said: &str, document: &Value) {
    if json {
        println!("{}", tama_core::json::pretty(document));
        return;
    }
    println!("{said}");
}

/// How much longer an entry authorizes, in whole minutes.
pub fn minutes_left(entry: &Value, at: u64) -> Option<u64> {
    entry
        .get(EXPIRES_FIELD)
        .and_then(Value::as_u64)
        .filter(|expiry| *expiry > at)
        .map(|expiry| (expiry - at).div_ceil(SECONDS_PER_MINUTE))
}

/// The sentence a later reader gets for one entry. `reason` is written into
/// every entry `entry` builds, so an entry without one was written by hand or
/// by another tool and says so; `revision` and `completed_task` are written
/// only for a build, so their absence is said by leaving them out.
pub fn described(key: &str, entry: &Value, at: u64) -> String {
    let reason = match entry.get("reason").and_then(Value::as_str) {
        Some(reason) => reason.to_string(),
        None => String::from("(the entry records no reason)"),
    };
    let revision = match entry.get("revision").and_then(Value::as_str) {
        Some(revision) => format!(" revision {revision}"),
        None => String::new(),
    };
    let completed = match entry.get("completed_task").and_then(Value::as_str) {
        Some(task) => format!("\n  completed task: {task}"),
        None => String::new(),
    };
    // An entry without an approval carries no exception; an approval missing
    // a field says which, instead of printing it blank.
    let consent = match entry.get("user_approval") {
        Some(approval) => {
            let field = |name: &str| match approval[name].as_str() {
                Some(text) => text.to_string(),
                None => format!("(the approval records no {name})"),
            };
            format!(
                "\n  user-approved daily-limit exception, session {}, turn {}: {}",
                field("session_id"),
                field("turn_digest"),
                field("quote")
            )
        }
        None => String::new(),
    };
    if entry.get("used_at_epoch").is_some() {
        return format!(
            "{key}: used, authorizes no further build,{revision} {reason}{completed}{consent}"
        );
    }
    match minutes_left(entry, at) {
        Some(left) => {
            format!("{key}: open for {left} more min,{revision} {reason}{completed}{consent}")
        }
        None => {
            format!("{key}: expired, authorizes nothing,{revision} {reason}{completed}{consent}")
        }
    }
}
