//! The report's headings, read by their structure.
//!
//! The contract asks for three parts under their own headings, in a fixed
//! order: what was done, blockers, next steps. A heading is a markdown
//! heading line (`#` marks) or a line that is nothing but bold text. A
//! heading's part is its position counted from the end among the headings of
//! the last heading's form: the last is next steps, the one before it
//! blockers, the one before that what was done — so a short answer carrying
//! only the last two reads the same way, and a deeper subheading inside a
//! part is not a part. Which words a heading uses is not read: the bilingual
//! title lists that used to decide it matched some spellings and missed the
//! rest. What a section's lines mean is read by the model in `reading.rs`.

pub(super) const LINE_JOIN: &str = "\n";
const ATX_MARK: char = '#';
const BOLD_MARK: &str = "**";
/// What may follow a bold heading's closing mark.
const BOLD_TRAILER: &[char] = &[':', '.', ' ', '\t'];

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(super) enum Title {
    Done,
    Blockers,
    NextSteps,
}

/// The contract's parts, from the last to the first.
const FROM_THE_END: &[Title] = &[Title::NextSteps, Title::Blockers, Title::Done];

/// How a heading line is written: its run of `#` marks, or bold.
#[derive(Debug, Clone, PartialEq, Eq)]
enum Form {
    Atx(String),
    Bold,
}

fn form_of(line: &str) -> Option<Form> {
    let line = line.trim();
    let text = line.trim_start_matches(ATX_MARK);
    if text.len() < line.len() {
        let marks = &line[..line.len() - text.len()];
        return (text.starts_with(char::is_whitespace) && !text.trim().is_empty())
            .then(|| Form::Atx(marks.to_string()));
    }
    let inner = line
        .strip_prefix(BOLD_MARK)?
        .trim_end_matches(BOLD_TRAILER)
        .strip_suffix(BOLD_MARK)?;
    (!inner.trim().is_empty() && !inner.contains(BOLD_MARK)).then_some(Form::Bold)
}

/// Each line's part when it is a part's heading, by position from the end.
pub(super) fn titles(lines: &[&str]) -> Vec<Option<Title>> {
    let forms: Vec<Option<Form>> = lines.iter().map(|line| form_of(line)).collect();
    let mut titles = vec![None; lines.len()];
    let Some(last) = forms.iter().rev().flatten().next().cloned() else {
        return titles;
    };
    let headings = forms
        .iter()
        .enumerate()
        .rev()
        .filter(|(_, form)| form.as_ref() == Some(&last))
        .map(|(index, _)| index);
    for (index, title) in headings.zip(FROM_THE_END) {
        titles[index] = Some(*title);
    }
    titles
}

/// The first heading, of the parts' form, that the answer writes a second
/// time, as written: one answer carries each part once.
pub(super) fn repeated(lines: &[&str]) -> Option<String> {
    let forms: Vec<Option<Form>> = lines.iter().map(|line| form_of(line)).collect();
    let last = forms.iter().rev().flatten().next().cloned()?;
    let mut seen: Vec<&str> = Vec::new();
    for (line, form) in lines.iter().zip(&forms) {
        if form.as_ref() != Some(&last) {
            continue;
        }
        let heading = line.trim();
        if seen.contains(&heading) {
            return Some(heading.to_owned());
        }
        seen.push(heading);
    }
    None
}
