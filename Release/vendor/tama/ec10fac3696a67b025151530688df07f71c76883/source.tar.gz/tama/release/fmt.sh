#!/usr/bin/env bash
# The formatting gate `.wisent-release.json` declares and `stado quality`
# reads. Every Rust file of the tree is put in the form rustfmt writes; with
# --check each one rustfmt would change is named and nothing is written.
# `cargo fmt` reaches only the files a crate's `mod` declarations lead it to,
# and Tama's hook programs are declared through a macro
# (`#[path = $path] pub mod $module;` in src/programs/mod.rs) that it cannot
# read, so those files were never formatted while the push gate, which checks
# each changed file on its own, refused them.
#
# In the checkout the files are the ones Git tracks or that are new and not
# ignored; `stado quality check` runs this in a committed revision exported
# without Git, where every Rust file present is one the revision holds.
#
# The edition is the one every package of the workspace declares; packages
# that declare different editions are refused by name, since one file list
# cannot then be checked under one edition.
set -euo pipefail
cd "$(dirname "$0")/.."

editions=$(sed -n 's/^edition *= *"\(.*\)"$/\1/p' rust/crates/*/Cargo.toml | LC_ALL=C sort -u)
if [[ -z "$editions" || "$editions" == *$'\n'* ]]; then
  printf 'the packages under rust/crates declare editions [%s], not one\n' "${editions//$'\n'/, }" >&2
  false
fi

mode=""
for word in "$@"; do
  case "$word" in
    --check) mode="--check" ;;
    *)
      printf 'usage: %s [--check]; got %s\n' "$0" "$word" >&2
      false
      ;;
  esac
done

sources() {
  if [[ -e .git ]]; then
    git ls-files --cached --others --exclude-standard -- '*.rs'
  else
    find . -type f -name '*.rs'
  fi
}

sources | xargs rustfmt --edition "$editions" --config skip_children=true $mode
