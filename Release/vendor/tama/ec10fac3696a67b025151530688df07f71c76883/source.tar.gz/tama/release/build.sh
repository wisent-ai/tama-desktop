#!/usr/bin/env bash
# Tama's Stado release: the one program and the sealed hook release it runs,
# both made from this commit and nothing else.
#
# The hook release used to be staged on the operator's machine by copying the
# runtime already installed there and adding the working tree on top, so a
# release carried whatever an earlier one had left (a src/ directory of the
# retired Node CLI rode along for a month) and whatever nobody had committed.
# Here it is assembled from the committed tree the build unpacked, sealed
# against WISENT_SOURCE_COMMIT, and shipped in the release archive under
# share/tama, which `stado product install tama --surface cli` places in
# ~/.stado/share/tama.
set -euo pipefail

source_dir=${WISENT_SOURCE_DIR:?WISENT_SOURCE_DIR is required}
: "${WISENT_SOURCE_COMMIT:?WISENT_SOURCE_COMMIT is required}"
# The manifest's stage map is read relative to WISENT_OUTPUT_DIR by both the
# signing step and packaging; a stage written into the source tree is
# "No such file or directory" to the signer.
output_dir=${WISENT_OUTPUT_DIR:?WISENT_OUTPUT_DIR is required}
if ! command -v cargo >/dev/null; then
  PATH="$HOME/.cargo/bin:$PATH"
  export PATH
fi
cargo=$(command -v cargo) || {
  printf 'cargo is not installed for this builder\n' >&2
  exit 69
}
cd "$source_dir"

cargo build --manifest-path rust/Cargo.toml --locked --release -p tama-cli --target-dir rust/target

stage="$output_dir/stage"
release="$stage/share/tama/hook-release"
rm -rf "$stage"
mkdir -p "$release" "$stage/bin"

# The four hook directories and the package description are the whole of a
# hook release's source; the binaries and the manifests are derived below.
cp package.json "$release/package.json"
# A directory with no committed file (codex-hooks holds only ignored
# caches) is absent from the source archive a fleet build unpacks, so it is
# created empty rather than copied.
for directory in shared-hooks claude-hooks codex-hooks repo-githooks; do
  mkdir -p "$release/$directory"
  if [ -d "$directory" ]; then
    cp -R "$directory/." "$release/$directory/"
  fi
done
# Generators that only write configuration in a checkout are not part of a
# release; the desktop bundle drops the same two.
find "$release" -name '__pycache__' -type d -prune -exec rm -rf {} +
rm -f \
  "$release/shared-hooks/providers.json" \
  "$release/shared-hooks/run-one-session-hook.js"

# The tama just built stages the native programs and seals the release; the
# installer is the same program (`tama hooks release`), so nothing travels
# beside it.
rust/target/release/tama hooks stage \
  --source-root "$source_dir" --release-root "$release" --cargo "$cargo"

# The installed hooks read the canonical checkout, not this job directory.
TAMA_DEPLOY_CHECKOUT='$HOME/Documents/CodingProjects/Wisent/tama' \
  rust/target/release/tama hooks seal --source-root "$source_dir" "$release"

cp rust/target/release/tama "$stage/bin/tama"
