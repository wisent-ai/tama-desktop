<!-- wisent-banner:start -->
<p align="center">
  <img src="assets/readme-banner.webp" alt="tama by Wisent" width="100%">
</p>
<!-- wisent-banner:end -->

<!-- wisent-readme-signals:start -->
[![Source](https://img.shields.io/badge/GitHub-Source-181717?logo=github)](https://github.com/wisent-ai/tama) [![Issues](https://img.shields.io/badge/GitHub-Issues-181717?logo=github)](https://github.com/wisent-ai/tama/issues) [![Wisent](https://img.shields.io/badge/Wisent-Website-0B0B0B)](https://wisent.com) [![Discord](https://img.shields.io/badge/Discord-Join-5865F2?logo=discord&logoColor=white)](https://discord.gg/qRjpkthq54) [![LinkedIn](https://img.shields.io/badge/LinkedIn-Follow-0A66C2?logo=linkedin&logoColor=white)](https://www.linkedin.com/company/wisent-ai/) [![X](https://img.shields.io/badge/X-Follow-000000?logo=x&logoColor=white)](https://x.com/wisentai) [![Enterprise](https://img.shields.io/badge/Enterprise-Book%20a%20call-0B0B0B?logo=calendly)](https://calendly.com/lbartoszcze)
<!-- wisent-readme-signals:end -->

# Tama

Runtime and CLI implementation for **Tama**, Wisent's coding-agent policy
product. The command is `tama`, both bundled and built from this checkout.
Tama Desktop runs one `tama request <operation>` process per operation: the
JSON body on stdin, NDJSON events on stdout, and no Tama process left running
between two operations.

## Tama CLI

Install the CLI through Stado; it places the program as `tama`:

```sh
stado product install tama --surface cli
```

Core commands:

```text
tama status --json
tama hooks list --json
tama hooks show <hook-id> --json
tama provider coverage --json
tama install plan --json
tama install
tama onboarding [--reset] [--policy-bundle <dir>] [--replace]
tama policy import --source <dir> [--replace] [--json]
tama policy list [--json]
tama mcp config
tama violations find --repo <path> --json
tama violations find --tree <dir> --size-only --json
tama violations find --tree <dir> --time-limits --json
tama violations clean --repo <path> --max-rounds <n>
```

The CLI owns catalog inspection, provider coverage, installation planning,
session runtime installation, repository scans and confirmed cleanup. Tama
Desktop is the native view over the same command contract.

`violations find` replays the real hook scripts, which costs two shell
processes per file: right for one repository, too slow for a machine full of
them. `--size-only` answers just the two size rules — max 300 lines per file,
max 5 files per folder — in process, over the same enumeration, with the same
skips and the same sentences. Use it to find what to fix, then re-scan that
one repository without the flag for the content rules the hooks own.

Every `--repo` and `--tree` is examined before any work starts. One that is
not there is refused as `repo not found: <path>`; one the command cannot
examine — a permission it lacks, a path running through a file — is refused
as `repo <path> cannot be examined: <cause>`, never read as absent. The same
holds for the hook tree `--rule all` replays and for the Desktop's scan and
clean jobs, which answer the same sentence.

`--time-limits` answers the workshop rule that no repository waits a guessed
interval, limits how long work may run, or kills work on a timer: it reports
every line, not the first per file, that pre-write-edit's time-limit gate would
refuse in a write, judged in process with that gate's own shapes. Switching a
library's own limit off — `(None)`, `(0)`, `: 0` — is the one spelling that
passes, because deleting an explicit value hands the call back to the
library's hidden one.

The line rule is about source a person edits and navigates, so two families are
exempt from it. Structured data — `.json`, `.jsonl`, `.ndjson`, `.lock`, `.csv`,
`.tsv` — passes the length check at any size because splitting a registry
breaks the reader that loads it; manuscript sources — `.tex`, `.bib`, `.sty`,
`.bst`, `.cls` — pass it because a chapter is not a module.
`block-oversized-files` decides that, and the in-process `--size-only` pass
reads the same list from it. Every other rule still applies to an exempt file —
the folder-file limit, the new-file justification and the content gates.

A repository declares its generated files to the audit in
`.tama/violations-ignore` — one relative path per line, `#` for a comment. A
line that names a directory covers everything below it, with or without a
trailing slash, so both spellings declare the same scope.
The original root-level `.tama-violations-ignore`
is still read; the folded form exists because the write guard refuses a sixth
file in any folder and a repository root usually holds five already, which left
repositories unable to declare anything. Exclusions cover the audit only: the
write guards still refuse an oversized file on the way in.

Third-party and generated trees are skipped by name — `vendor`, `venv`,
`.venv`, `dist`, `build`, `target`, `coverage` — but only where no source root
stands above them. A directory under `src/` or `crates/` is treated as product
code regardless of its name. A generated-directory name does not exempt
source modules from either size rule.

## One program

Tama is one program, `tama`. Every native hook is one of its
subcommands, `tama hook <name>`, and the registry runs each hook as
`$HOME/.local/bin/tama hook <id>`. The hook engine is `tama run-hook` and the
MCP server is `tama mcp`. `tama hook` with an unknown name prints every name it
answers to.

Tama is released through Stado like every other product, and one release
carries both halves of what a machine runs. The batch build (`release/build.sh`)
compiles `tama-cli`, assembles the hook release from the same commit
(`package.json`, `shared-hooks`, `claude-hooks`, `codex-hooks`,
`repo-githooks` and the built `tama`), stages and seals it against that commit
with the `tama` it just built (`tama hooks stage`, `tama hooks seal`), and ships it in the archive under
`share/tama` beside `bin/tama`. Nothing is built, staged or sealed on the
machine that runs Tama, and no hook release starts from a copy of the runtime
a machine already has.

The owner installs it, outside any agent session, with one command:

```sh
DEVICE_HOOK_EDIT_APPROVED=1 stado product install tama --surface cli
```

Stado places `tama` in `~/.stado/bin` (linked from `~/.local/bin/tama`) and
the release under `~/.stado/share/tama`, then runs `tama hooks release` as the
install's `after_install` step. That command activates the sealed hook release
Stado placed: it warms every registry hook through the installed `tama`,
removes the separate programs an earlier release installed (`tama-<hook>`,
`tama-run-hook`, `tama-mcp-server`), installs the release into
`~/Library/Application Support/Tama/hooks-runtime` with the installer the
release carries, and reports what the machine now runs. It refuses without
`DEVICE_HOOK_EDIT_APPROVED=1`, on a machine where Stado installed no hook
release, and for a release whose registry still runs a hook as a separate
`tama-<name>` program or whose adapter still launches `tama-run-hook`, naming
each entry and line. The registry is rewritten in the repository with
`DEVICE_HOOK_EDIT_APPROVED=1 tama hook migrate-registry-to-rust --registry shared-hooks/registry.json --apply`
and resealed with `node shared-hooks/seal-registry.mjs` before the commit.

## Common hook engine

`rust/crates/tama-run-hook` is the native hook engine as a Rust library; the
`tama` program runs it as `tama run-hook`. `tama run-hook --serve <agent-id>`
keeps it alive across JSON-line `status`, `reload`, and `dispatch` requests;
valid registry changes are also adopted automatically before dispatch. Failed
replacements preserve the last usable generation and refuse that dispatch
rather than reporting success. Each `dispatch` runs on its own thread against
the generation loaded when it arrived and is answered by its request `id` when
it finishes, so a hook that never ends holds only the tool call that started
it; `status` and `reload` are answered at once. Each hook runs in its own
process group. A session ends its turn and submits a prompt one at a time, so
when a `stop` or `user_prompt_submit` hook starts while the same hook of the
same session (`session_id` in the payload) still runs for the previous event,
nobody waits for the earlier run any more: the core ends its process group
(the hook and what it started, such as a model request that is never
answered) and says so on stderr. A newer tool call does not end an older one,
since a session runs tool calls side by side; the end of the turn does. The
harness sends `stop` only after every tool call of the turn is over and
`user_prompt_submit` only once the turn before it ended, so a tool hook of
that session still running then guards a call the harness has already
refused at its own handler limit, and the core ends its process group the
same way, and that tool call's dispatch starts none of its remaining hooks. A
serving core whose input closes ends every hook run it still holds, since its
caller is gone. `tama hooks running` lists every hook still running, the
session it runs for and for how long. Every `stop` a serving core receives is
recorded in `turn-end.<session id>.json` beside the session's control files:
written on receipt with `answered: false`, then completed with `finishedAtMs`
and the whole decision the harness was sent (each hook's verdict and run time)
or the error sent instead. After a turn ended, a record still `answered:
false` means the core never answered that stop; a `block` decision means the
core answered after the harness had settled the turn without it; `pass` means
every stop gate let the turn end. The core writes that meaning into the record
as `reading`, and `tama hooks running` and Tama Desktop's Session screen show
each session's last turn ending with it. Harness-specific response formatting
is outside the execution loop.

The OMP JavaScript adapter now forwards events and reload requests to a persistent
native engine; it no longer evaluates the event hook loop itself. The
[runtime protocol and integration status](https://tama.wisent.com/docs/enforcement-control/runtime/adapters/)
distinguish source, installed release, and the code an existing session has loaded.

The Node entrypoint used by Claude/Codex is only a process transport to the same
native engine. The former Rust OMP execution mirror and cross-hook policy sweeps
have been removed; each hook evaluates its own rule and the common engine owns
event dispatch.

## Tests only where the operator approved them

`block-unapproved-tests` refuses new test code — a file under a
`tests/`, `test/` or `__tests__/` directory, `x_test.go`, `x.test.ts`,
`x.spec.ts`, `test_x.py`, `tests.rs`, `XTests.swift`, or a change carrying
Rust's test attribute, a Python `test_` function or Swift Testing's macro —
unless the operator approved that path:

```sh
tama tests approve <path>…   # a file, or a directory that covers everything below it
tama tests list [--json]
tama tests revoke <path>…
tama tests audit [<root>…] [--remove] [--json]   # test code per repository against the approvals
tama tests review <root>   # the reviewer reads a repository's unread test files; verdicts kept
```

Approvals live in `~/.config/agent-policy/approved_tests.json`. The hook
refuses `tama tests approve` run from an agent session, a write tool aimed at
the record and a shell command naming it, so every approval is the operator's
own. Reading and removing test code are never refused.

An approval never covers a smoke test: test code whose only checks are that
something starts, builds, runs, does not crash or returns something. The hook
asks Brama's reviewer whether a test write is one and refuses it, and it
refuses every write into a git repository whose tracked test files hold one,
except a write to one of those files, until each is rewritten into a test of
the real product or removed with `git rm`. The reviewer reads a tracked test
file once per content; its verdict is kept by git blob id in
`smoke-test-verdicts.json` under Tama's state directory
(`~/Library/Application Support/Tama` on macOS). Tracked-file decisions use
the verdicts already kept. Unread files name `tama tests review <root>`;
the hook starts no background process. That foreground command owns the review
and refuses another active owner. Returned failures are retained in
`smoke-test-reviews/review.log`, with a separate cause if logging fails.
The direct review of proposed test content is a separate synchronous path.

`tests audit` given a workspace directory scans direct child repositories with
`.wisent-release.json`; an explicitly named repository is scanned even without
that product marker. This keeps externally owned checkouts out of a product-wide
count and, especially, out of `--remove`. The output is a path inventory against
operator approvals, not a verdict that a test meets the real-journey standard.
It reports unclassified files under test paths for review and exits nonzero
while any remain; a plain-named journey cannot make the audit pass by being
mistaken for a fixture. `--remove` deletes identified unapproved test files
only inside dedicated `test/`, `tests/`, or `__tests__/` directories; a test-like
file elsewhere stays in review, since a production route can share its name
and function marker. Shared helpers, data, and inline modules are never
deleted. Review all remaining paths: names and markers do not prove purpose.

## The operator's own acts

Some commands record a decision only the operator may make. The same hook
refuses each of them when a session runs it, however the program is reached
(bare, by path or by a quoted path):

- `tama tests approve` — his approval of test code;
- `oko tasks close <task> --reason TEXT` — his own "done" for a
  task;
- `oko tasks verdict … --by operator` — a verdict in his name.

## Cloud instances only with the operator's consent

`block-cloud-instances` refuses a shell command that runs a cloud provider's
command line — `gcloud`, `aws`, `az`, `vastai`, `runpodctl`, `doctl`,
`hcloud`, `oci`, `ibmcloud`, `linode-cli`, declared with the reason in
`ports/block_cloud_instances/programs.json` — until the operator's direct
consent is recorded as the Tama session capability `{"tool": "cloud"}`,
which he confirms himself. Every call waits, listing included; `--help` and
`-h` pass, and so do Stado's own commands. See
[cloud instances](https://tama.wisent.com/docs/cloud-instances/).

## Push review and tasks without the judge

How every push is reviewed, what a commit's attestation is and where an
existing commit keeps it, and how tasks close without a model are in
[docs/review/push-review.md](docs/review/push-review.md); how each commit an
agent session makes is scored, and a session below zero is stopped, in
[docs/review/commit-standing.md](docs/review/commit-standing.md).

## No model, policy bundles and recorded consent

Tama on a machine with no model, importing an existing policy bundle, and
recording CUA and SSH consent already given are in
[docs/no-model-and-consent.md](docs/no-model-and-consent.md).
