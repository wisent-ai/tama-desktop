# Keyword logic: what replaces it, and how to find what is left

No product in this workshop decides anything by matching words. A list of
words can decide spelling, never meaning, and every such list drifts from
its copies. This page says what each kind of keyword logic is replaced
with, names the replacements already made, and says how to list what is
left. The inventory is generated, never hand-kept.

## Reading the list

```bash
tama vocabulary report \
  --repo ~/Documents/CodingProjects/Wisent/tama \
  --repo ~/Documents/CodingProjects/Wisent/oko \
  --repo ~/Documents/CodingProjects/Wisent/stado \
  --repo ~/Documents/CodingProjects/Wisent/jeden \
  --repo ~/Documents/CodingProjects/Wisent/weles
```

That prints every flagged word set with every site that writes it,
most-copied first. It reads exactly what `block-keyword-literals` refuses:
lists of two or more words in code and in data files (JSON, YAML, TOML),
and alternations of two or more words inside a quoted literal or, in a
JavaScript or TypeScript file, a regex literal (`/Try again|Retry/i`).
No declaration exempts a list, and a list moved from code into a data file
is refused the same way.

The report also counts one shape the guard does not refuse: words bound one
by one to named constants in a file and used together as one class — a
collection of the names (`&[WRITE_TOOL, EDIT_TOOL]`), the arms of a pattern
(`matches!(tool, WRITE_TOOL | EDIT_TOOL)`) or a chain comparing one input
with them (`tool == WRITE_TOOL || tool == EDIT_TOOL`). Such a set is
reported with the words its names hold. Renaming a list's words is not
removing the list, and a count that fell for it would report a repair
nobody made. Names bound to something that is not a word (`functions.write`,
a path), a name bound to two different words (a variable), and a collection
that also holds a name bound to no word are not word sets.

The output is not kept in this repository: it is
wrong the day after it is written. Ask the command; it reads the tree as it
is now.

## What the guard does not judge

`block-keyword-literals` reports a word list only where the program keeps
or consults it, and only in code somebody here wrote:

- Words handed to a call are that call's arguments, and words a function
  hands back are a command line — including a function whose return type is
  itself an array, which is how Swift and TypeScript spell
  `listArguments(host:) -> [String]`.
- An options object inside a call is arguments too.
- A command line bound to a name before it runs —
  `let args = ["build", "status", id, "--json"]` — is the process's
  arguments: its collection also holds a value computed elsewhere or an
  option such as `--json`, which a vocabulary of words never does. A list
  of nothing but words bound to a name is still judged.
- A list asked a question where it stands — `[…].contains(x)` — is a
  classifier even inside an argument list, and is reported.
- Vendored trees, `node_modules`, package-manager checkouts,
  `site-packages`, built bundles and `.min.js` files are skipped.
- Prose files are not judged at all, and a list quoted in a comment is a
  report about a classifier rather than one.
- A release manifest's `argv` vectors are commands, and its
  `promotion.channels` are release states. Neither classifies input; other
  word arrays in the same JSON document are still judged.

## The kinds, and what replaces each

### 1. One vocabulary, many copies

A vocabulary retyped in several places — a shell list, a provider list,
a set of payload keys — is not a judgement; it is one fact copied, and the
copies drift.

**Replacement:** name the vocabulary once, where its owner lives, and have
every site read it. Where the owner is another product, ask that product.

Done: Tama's shells, interpreters, wrappers and source suffixes
(`ports/shell_text/vocabulary/*.json`), its payload keys
(`ports::tool_vocabulary`), the adaptive phases and the time-estimate
words; Stado's queue prefixes, API actions and service name keys; Jeden's
pinnable languages, communication vocabularies and lifecycle events; Oko's
model roles.

### 2. A vocabulary that belongs to another product

**Replacement:** ask the owner. Oko asks Transcript Lake for the transcript
runtimes; Stado validates the shape of a runtime token instead of keeping a
list, and reports `terminal` with every job so Oko asks the job rather than
matching its state words.

### 3. A guess at a shape

A list standing in for something the input itself says.

**Replacement:** match the shape, or derive the set from the thing itself.
`--provider <name>` accepts any provider Stado offers, the keeper entry
point any action Weles adds, `node --check` any JavaScript suffix, the topup
orchestrator any service that carries a `topup.mjs`.

### 4. A fact the input already carries as structure

The largest kind: a word in an error message standing in for the error's
kind, a word in a display name standing in for a record's type, a word in a
page's text standing in for the page's state.

**Replacement:** read the structure. Exit codes, HTTP statuses and typed
error kinds instead of error text (Stado's `release_cause::Refusal`,
`FailureKind` and `RepairRefused`; launchd absence by exit status; Brama's
`ReinstateRefused`; Probierz's `Code::Refused`). A harness's own flags
instead of message text (Claude's `promptSource`, `isMeta` and
`isCompactSummary`; OMP's `steering`, `synthetic` and `attribution`), read
by Transcript Lake into `extra.prompt_source` and by Oko's `decode`. A
record's own fields instead of its name: a Weles proxy row's provider from
its endpoint host and its pool type from the Skarbiec item's `proxy_type`,
with an undeclared row refused by name; a mail's sender domain and the link
it carries instead of words in its subject. On a web page, what the page
offers to act on instead of its prose: a control by role and accessible
name, a field by its `name` or `autocomplete` attribute, a frame by its
origin, the URL's host and path, the HTTP answer the page's own request
received, and the account's session cookies (Weles
`src/trajectories/_shared/page/offers.mjs`).

### 5. A classifier of prose

Phrase lists that decide what an operator meant, what an agent claimed, or
what a page is saying.

**Replacement:** a model judgement through Brama. `ports::model_judgement`
asks one prompt through `oko gateway send --prompt`; `objective_reviewer::stop` is the
Stop gates' route, where a gate states its rule in prose and `stop::breaks`
asks for a verdict bound by a strict JSON schema (`tama_review_verdict`: a
`decision`, `pass` or `block`, and the `reason` a block gives) over the
operator's own messages, the turn's tool evidence and the ending answer; the
objective-substitution guard and the build-limit consent read the same
verdict, and the commit reviewer binds its findings the same way
(`tama_commit_verdict`). A reviewer that cannot answer, or answers outside
the schema, is written to stderr as `TAMA_HOOK_INFRASTRUCTURE: <hook>: <error>` and the
gate lets the turn end: a judgement nobody obtained is never a denial. What
stays matched is structure: the contract's exact headings, the commands a
turn ran, where a label or a repository path is written.

Every Stop gate that judged prose reads the model this way. Oko's reading
of what each operator message is to the ledger — a task, a question, an
acknowledgement, a rule, a resume — is its model's reading too
(`oko tasks read`), kept per message; a message nobody has read
is reported as unread with the reading route's state, and never turned into
owed work by its words.

**What this costs:** while Brama cannot answer, these gates read nothing and
let turns end; the stderr line names each one that could not ask. A judge
that never answers is asked one question at a time per machine: the
waiting question holds `model-judgement.lock` in Tama's state
(`TAMA_JUDGEMENT_LOCK_PATH` moves it) with its process named inside, and
every other gate that finds it held is not asked and names that process,
so one silent judge costs one gated call instead of every call after it.
The lock's record is marked finished when its process is done with the
question, answered or not. A record left unfinished is a question whose
asker was ended first, because whatever runs the hook stopped waiting for
it: a judge slower than that wait. Then no gate asks again, each passes and
names that question, until Oko writes its judge record (`judge-health.json`,
`oko tasks judge --probe` writes it) after the question was asked, so a slow
judge costs one gated call per Oko reading instead of every call.
When several gates ask at once while the judge answers, only the first is
judged; the rest pass and say which question they waited behind. A machine
that declared no model (`tama model set --none`) asks nothing: every
gate that reads a model here passes at once and says no model is declared,
so a model route that hangs on such a machine stalls no tool call.

### 6. Consent

The operator's grant is not a phrase list either. Consent he gives in the
conversation is recorded as a Tama session capability with the lifetime he
named and read as data: `{ "tool": "ssh" }` for `block-unauthorized-ssh`,
`{ "tool": "cua" }` for `block-unauthorized-cua`,
`{ "tool": "tama", "actions": ["hook-edit"] }` for
`block-hook-config-edits-without-consent`, and the build and local-Weles
consents the same way. A verbatim quote from the session still scopes an
SSH or CUA grant to its target and actions; it no longer decides whether
there was one.
