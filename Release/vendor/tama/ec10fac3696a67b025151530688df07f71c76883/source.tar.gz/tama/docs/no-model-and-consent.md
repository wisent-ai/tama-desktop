# No model, policy bundles and recorded consent

## Tama with no model

Tama does not need Brama, or any model, to hold a session to its rules.
`tama model set --none` declares that this machine has none, and
Tama Desktop's *Model service* section declares the same. Deterministic hooks
enforce as before; a stop gate that would ask a model reads the session's
own attestation instead, and `review-push` reads each pushed commit's.

`tama attestation` keeps them. `record --file FILE --session ID` judges FILE
against `standards/task.json` (every claim confirmed and explained in at
least the operator's stated number of words, `next_steps` and
`harsh_senior_review_findings` empty) and keeps it only when it stands.
Recording again replaces the record, and a refused attestation leaves the kept
one as it was. `show`, `list` and `remove` read and delete kept records; each
takes `--json`. Tama Desktop's *Model service* section sends the same
operations as `tama request attestation/record|show|list|remove`.

```text
$ tama model set --none
provider: none
$ tama attestation record --file done.json --session "$SESSION"
attestation: session <session> stands
attestation: recorded at ~/Library/Application Support/Tama/attestations/session/<session>.json
$ tama attestation list
attestation: session <session> stands
attestation: recorded at ~/Library/Application Support/Tama/attestations/session/<session>.json
```

`unset` returns Tama to Brama. The tests are `tests/task-attestation/`.

A supervisor session (its Oko role is `supervisor`) ends a turn only with the
claim `block-unrepaired-negative-report` declares in `standards/turn.json`:
every failure the answer reports cites the Oko defect carrying its repair or
its owner, or the product action of the turn that answers it. The gate needs
no model either way. It refuses an answer without that claim, then reads each
defect identity the answer cites (a UUID or its first group; a commit is cited
as `repository@commit`) with `oko defects show <id> --json` and refuses one
with neither `repaired_in` nor an owner, naming it: `defect <id> has no
recorded repair and no session owns it`. `tama attestation standard --turn`
prints the claim; `tests/supervisor-stop/negative_report.rs` checks each case
against the real Oko register.

## Import an existing policy bundle

First setup can adopt policies from an existing self-contained Tama policy
bundle or sealed release directory without installing or enabling them:

```sh
tama onboarding --policy-bundle /absolute/path/to/tama-bundle
# The same operation remains available after onboarding:
tama policy import --source /absolute/path/to/tama-bundle
tama policy list
```

The supported bundle format contains `shared-hooks/registry.json` and regular,
non-symlink policy files under `shared-hooks/`, `claude-hooks/`,
`codex-hooks/`, `repo-githooks/`, `adaptive/`, `external-hooks/`, and `bin/`.
It also retains existing root `package.json`, `release.json`,
`external-sources.json`, `.wisent-release.json`, `README.md`, and `LICENSE`
files. Other top-level paths are returned in `ignoredPaths`; they are never silently
treated as policy definitions.

Before any store mutation, Tama parses the exact registry, validates the
established catalog, maps every registered source to a selected file, and, for
a sealed release, verifies the `release.json` tree identity. Invalid JSON,
missing source files, empty catalogs, seal mismatches, symlinks, and special
filesystem entries return a rejected result and leave the store unchanged.

Accepted bundles are copied to Tama's editable application-data store and
recorded in `index.json` with canonical source path, source digest, hook count,
timestamp, file modes, and per-file SHA-256 digests. Repeating the same source
and content is `unchanged`. A changed source returns all conflicts by default;
`--replace` updates only a bundle with no untracked or locally changed files.
Other imported bundles are always preserved.

Every result reports imported, unchanged, removed, conflicting, and rejected
counts. Imported bundles are explicitly `inactive`: the operation installs and
enables zero hooks and does not modify `~/.shared-hooks`, Git configuration,
agent configuration, the active Tama release, or the selected source. Activation
remains a separate, explicit install/runtime operation. Skipping import leaves
an empty, usable Tama.

## Record CUA consent already given

The CLI and **Justifications → CUA consent** can record, inspect and remove an
existing user grant without editing protected hook files. The application,
every requested action and the direct grant must appear in the real user
message from the specified OMP session.

```sh
tama justify record --kind cua --session <current-session-id> \
  --app Figma --actions list_windows,get_window_state \
  --quote-match "Zezwalam CUA" --json
tama justify list --kind cua --json
tama justify remove --kind cua --quote-match "Figma: list_windows" --json
```

`--quote-match` selects the original full message without retyping whitespace;
`--quote` accepts an exact quotation instead. For `show` and `remove`,
`--quote-match` names the one recorded quote that contains the fragment and is
refused when no quote or several quotes contain it. The hook reads a driver
call only from the command words a shell line runs, so a consent sentence
passed whole as a quoted argument is data and `--quote` works too. Tama derives the
installed app's bundle identifier and executable, reuses the hook's
validators, and writes the registry under a lock. Recording does not start Cua
Driver or prove an action ran. The hook still checks the current session and
target at use.
Every grant recorded for the session keeps its own scope: a call passes when
any backed grant covers its action and target, so a later grant for the same
app does not withdraw an earlier one. The quoted `serve`, `status`, `stop` and
`check_permissions` actions operate on the driver itself and have no app PID to
match. They are allowed only when named individually in the recorded grant.
`launch_app` still requires the granted bundle identifier, and later window
actions still require its live process.

## Record SSH consent already given

`block-unauthorized-ssh` admits an SSH call only when the operator's consent
is the Tama session capability `{"tool": "ssh"}`, the operator's own words
name every target and are a verbatim user message of the session, and
`~/.shared-hooks/ssh_justification.json` holds an entry covering the exact
target, operation and path or command. That file is data: writing it by
hand is refused by the gates that protect the hook directory, and by the
numeric-literals gate, which reads a host's address as a number. The CLI
records it instead:

```sh
tama justify record --kind ssh --session <current-session-id> \
  --quote-match "zgadzam sie na ssh" \
  --target "<the ssh destination the quote names>" --operation exec \
  --command "<the exact command, once per --command>" --json
tama justify list --kind ssh --json
tama justify show --kind ssh --quote-match "zgadzam sie na ssh" --json
tama justify remove --kind ssh --quote-match "zgadzam sie na ssh" --json
```

`--target` repeats for every destination the quote names; `read` and `write`
are covered by exact `ssh://` or `sftp://` URLs (`--path`, repeatable), every
other operation by exact full commands (`--command`, repeatable). Before
writing, the recorder asks the hook's own matcher whether the entry would
admit each target with each path or command, so an entry it records is one
the gate reads; a quote that does not name a target, a quote that is not a
user message of the session, an operation the gate does not know, paths
given for a command operation or commands for a path operation are refused
and nothing is written. The entry format kept beside the entries is carried
through unchanged. Recording does not grant anything: the capability and the
session's transcript are still read at use, by the hook.

The targets of a call are the `ssh://` and `sftp://` URLs it names, the
destination of every `ssh` and `sftp` client, and every scp-style remote
spec (host, colon, path) among the words of the command line; an `scp`
source file is not a host. The words an
`ssh` runs on the remote host after its destination (quoted or not, up to
the next `;`, `&&`, `||`, `|` or `&`) are that host's command and name no
host: `ssh <host> 'lsof -nP -iTCP:8895 -sTCP:LISTEN'` reaches only `<host>`.
A call the registry does not cover is refused with
`BLOCKED: unauthorized SSH: an exact current-session user authorization and
matching ssh_justification.json entry are both required (this call reaches
<targets>, operation <operation>)`; the targets and operation in the
parentheses are what an entry has to name for the call to pass.

The [CLI contract](https://tama.wisent.com/docs/cli/justify/) and
[desktop request contract](https://tama.wisent.com/docs/cli/request/) document
scope and refusals.
