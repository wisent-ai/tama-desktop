# Push review and tasks without the judge

## Every push is reviewed

`tama install` writes the global Git `pre-push` dispatcher. Before a push
leaves the machine it runs `tama hook review-push`, for every repository,
and only once the review lets the push through the Rust formatting gate
and the product's quality gate (`stado quality check`, when the release
manifest declares one): the review asks nothing and answers at once, so a
push it refuses spends no minutes on formatters.

`review-push` reads the commits each pushed ref adds over the remote and
requires each one to carry the commit attestation: every claim of
`standards/commit.json`, word for word, in its message or, for a commit that
already exists, in the note `tama attestation attest` keeps beside it under
`refs/notes/attestation`. The claims are a principal engineer's
standard — no defect, needless abstraction or duplication, swallowed error or
fallback value, guessed number, failure hidden by pausing or trying again,
narrating comment, host, account, date or internal id, test of a mock, commit
that only reformats or patches another, or docs that do not match the code —
plus no private information of ours and no one-off solution in place of a
general primitive. A commit carries them only when they are true. No model,
key, Brama or other product is asked, so a push is reviewed the same on a
machine with nothing but Git and Tama.

`tama hook check-rust-format` checks each Rust file a pushed commit changes
with `rustfmt --check` under the edition of the Cargo package that owns it,
read from the committed tree, never the working one. A file is owned by the
package whose target is that file (`[lib]`, `[[bin]]`, `[[test]]` and the
targets Cargo discovers: `src/lib.rs`, `src/main.rs`, `src/bin`, `tests`,
`examples`, `benches`), or that reaches it as a module, as rustc does: from
each target the gate follows every bodiless top-level `mod name;` (to
`name.rs` or `name/mod.rs` in the module directory: the declaring file's own
for a crate root, a `mod.rs` or a `#[path]` file, else `<directory>/<stem>/`)
and every `#[path = "…"]` module (against the declaring file's directory),
through every file they reach. So a test a library's nested module includes
through `#[path]` from outside the package is formatted under that library's
edition. A file no target reaches belongs to the target or package whose
directory holds it, the nearest one. A file no Cargo package owns, in a crate
compiled without Cargo, takes the `edition` of the nearest committed
`.rustfmt.toml` or `rustfmt.toml` above it, looked up as rustfmt does. A
declaration that resolves to no committed file, or to both `name.rs` and
`name/mod.rs`, refuses the push naming it; so does a file neither a package
nor a rustfmt configuration owns, a nearest configuration that sets no
edition, or owners that declare different editions.

The same check scores every commit an agent session makes, before it leaves
the machine: the commit is made either way, and the session earns or loses a
point by the form of its staged Rust files. A session below zero has its tool
calls refused; see [commit standing](commit-standing.md).

The harsh review the last claim speaks of is written in Git trailers, in the
message's last paragraph, and read with Git's own trailer grammar (`git
interpret-trailers --parse`): at least one `Harsh-Review-Attacked: <what was
attacked, what was checked, why the attack failed>`, and no
`Harsh-Review-Finding: <defect>`. A finding is a defect the claims above it
deny, so a commit whose review names one does not stand until the defect is
repaired in source; a note does not answer a finding the commit's own message
names. `required_trailers` in `standards/commit.json` and the `trailer` of its
`must_be_empty` list declare both, and `tama attestation standard --commit`
names them on stderr while it prints the claims on stdout.

A commit an agent session makes also needs a round of harsh review by a
reviewer that is not its author; the author starts one with `tama reviews
harsh run`, which [reviewer runs](reviewer-run.md) describes.

```text
$ git push origin main
review-push: BLOCKED: refs/heads/main -> refs/heads/main: commit <sha> carries no standing commit attestation in its message or in its refs/notes/attestation note:
    missing: "<claim>"
    missing: "Harsh-Review-Attacked: <why>"
    finding: "Harsh-Review-Finding: <defect>"
Each commit carries the commit attestation, ...
$ git commit --amend -m "<subject>

$(tama attestation standard --commit)

Harsh-Review-Attacked: <attack>"
$ tama attestation check --commit HEAD
attestation: commit <sha> carries every claim in its message
$ git push origin main
```

One claim is not taken on the attestation's word, because Git can answer it:
that every commit of the push a commit patches is named as repaired. For
each pushed commit `review-push` reads which lines its patch removes or
replaces in its first parent (`git diff -U0`) and asks Git's blame which
commits added them. A commit that changes lines another commit of the same
push added must name that commit by its subject, with the defect it
repairs there, on a line of its message or of its attestation note:

```text
Repairs: "<subject of the earlier commit>" <the defect it repairs there>
```

The subject, not the commit's object name, because a commit message
carries no commit ids. A repair stays a commit of its own, because folding
it into the commit it patches rewrites history that other work in the same
checkout already builds on. A patched commit no `Repairs:` line names
refuses the push with that commit named; a `Repairs:` line whose subject
is not quoted or that names no defect refuses it too, whatever the commit
patches, and so does a subject two patched commits share, since it cannot
say which of them it repairs. `tama attestation pending [--repository
PATH] [--json]` reads every commit the branch carries over its upstream the
same way before the push: whether each attestation stands, where, what it
lacks, what its review names and which commits it patches without naming
them. A commit whose patches cannot be measured — a malformed `Repairs:`
line, or a blame Git refused — does not stand and carries the cause on its
own row (`patchesFailure` in `--json`, `patches unread: <cause>` in lines),
while every other commit of the range is still read and reported.

The `Repairs:` lines read are the attestation note's when the commit's note
carries any, else the message's. A message cannot change once other work
builds on it, so a message whose `Repairs:` line is malformed or names the
wrong subject is corrected by `tama attestation attest --commit <sha> --file
<attestation>` with the right lines in the attestation; a note that carries
no `Repairs:` line leaves the message's lines in force.

The commit that was repaired is attested as the push leaves its lines: the
standard's claims about the lines it adds count a defect that a later
commit of the same push repairs and names it for as repaired. So a defect
found in an unpushed commit is repaired by a commit of its own, and both
are attested and pushed together; pushing the earlier commit without its
repair leaves the defect in place, and its claims no longer hold.

That claim only scopes the claims about a commit's lines to the push, so the
standard declares it implied by them (`implied_by` in
`standards/commit.json`): a text that carries every claim it scopes — no
defect, no needless abstraction or copy, no swallowed error, no guessed
number, no hidden failure, no narration or internal name — word for word
carries it too. A commit attested before the claim was declared states its
lines' claims unscoped, which says more, and stands without repeating it;
one that lacks any of the claims it scopes still lacks it.

```text
$ git push origin main
review-push: BLOCKED: refs/heads/main -> refs/heads/main: commit <sha> changes lines <earlier sha> of this push added and names none of them as repaired: add `Repairs: "<subject>" <the defect it repairs there>` for each to its message or to its attestation note (`tama attestation attest`); `tama attestation pending` lists every such pair
$ tama attestation pending
attestation: <checkout> over origin/main, oldest first:
attestation: <earlier sha> <subject>: stands in its message
attestation: <sha> <subject>: does not stand
    patches: <earlier sha> <subject>
attestation: <sha> <subject>: does not stand
    patches unread: `Repairs: <line>` does not quote the subject of the commit it repairs; write `Repairs: "<subject of the repaired commit>" <defect>`
```

A commit that already exists — made before the standard asked for an
attestation, or already shared — is not rewritten. Its attestation is kept
beside it, only when it carries every claim and the harsh review's trailers
with no finding, and the note is pushed with the branch; `review-push` lets
the notes ref through without reading Git's notes commits as work.

Git pushes no notes ref unless the push names it, and a note left in the
checkout leaves the remote's copy of the commit with no attestation at all.
So a push that adds a commit standing only in its note is refused unless the
same push carries `refs/notes/attestation`, or the remote's
`refs/notes/attestation` already names this checkout's notes commit (`git
ls-remote`). `tama attestation pending` asks the upstream's remote the same
question and reports it under `notes`; Tama Desktop's unpushed-commits
section shows the refusal above the commits.

```text
$ tama attestation attest --commit <sha> --file attestation.txt
attestation: commit <sha> is attested in refs/notes/attestation
$ git push origin main
review-push: BLOCKED: refs/heads/main: <sha> stand only in the refs/notes/attestation note kept beside them, and origin does not hold that note (it has no refs/notes/attestation; this checkout's names <notes commit>), so a clone of origin reads them with no attestation: push the note with the branch, `git push origin refs/heads/main refs/notes/attestation`; …
$ git push origin main refs/notes/attestation
```

When the remote's notes moved on from another checkout, Git refuses the
notes push as not a fast-forward; the refusal names the fetch and `git notes
merge` that bring both sets together before pushing again.

The same review reads every `Cargo.lock` in the pushed tip. Each Git commit a
lock file pins (`source = "git+<repository>?rev=…#<commit>"`) is fetched by id
from the repository it names, into a bare store under the pushing
repository's Git directory (`tama-locked-sources`), so a commit fetched once is
not asked for again. A commit that repository does not serve refuses the push:
the dependant would build only on the machine whose Cargo cache holds it.

```text
$ git push origin main
review-push: BLOCKED: refs/heads/main -> refs/heads/main: a pinned Git dependency is not published:
commit <commit> of https://github.com/<owner>/<dependency>, pinned for <package> (Cargo.lock), cannot be fetched from it: git --git-dir .git/tama-locked-sources fetch … failed: … not our ref …; push that commit to https://github.com/<owner>/<dependency> first
$ git -C ../<dependency> push origin main
$ git push origin main
```

The answer a turn ends with carries the claims `standards/turn.json` declares
for `check-stop-asking`, `block-false-blockers` and `block-stop-on-own-work`
the same way (`tama attestation standard --turn`). `tests/review/attested.rs`
pushes to a real bare remote with no Brama and reads the remote's branch
afterwards; `tests/review/push/noted.rs` keeps existing commits' attestations
as notes and pushes the same commits unchanged; `tests/task-attestation/turn.rs`
runs each turn-end gate.

Writes are checked before they happen as well: `block-internal-names`
refuses an edit that adds a fleet host, account or vault item name, or a date
or a commit, build, job, session or defect id in prose, to any file inside a
repository. A role (`stado:role:<role>` on a vault item) and a product's own
name, or the release name its `.wisent-release.json` declares, are not
internal: a secret is asked for by its role, and a product prints its own
name. `tama violations find --internal-names` reports the same judgement for
every line of a checkout.

## Tasks without the judge

Oko's judge is reached through Brama, and a machine may have neither. A task
then closes in one of two ways, and neither needs a model:

- the operator closes it with `oko tasks close` in his terminal,
  or with Close on Oko Desktop's Tasks screen; Oko asks for the task id on
  the terminal before it records anything;
- a judge's "done", when a judge answers.

`block-stop-with-open-work` does not count a task as open work while it
awaits review: the task carries its repair (a recorded commit or report) and
Oko recorded that the judge could not answer for it. A session that recorded
its repair is not held for a judge that is not there; the task stays in the
ledger for the operator to close or reopen.

### A session's scope

A session the operator limited to some products is held only by their work.
Its scope is the union of the products named by its open Oko task contracts
that the operator confirmed (`oko tasks state <task> --scope <product>
--confirm`, run by the operator). A scope a session wrote into its own
unconfirmed contracts limits nothing: the session answers for every
product's open work, as the operator ordered. With a scope,
`block-stop-with-open-work` lists the session's own open tasks, other
sessions' unrepaired tasks whose contract names one of those products, and
those products' open defects; it counts what it left out (`N open tasks of
other sessions and M open defects of other products are outside this
session's scope (…) and are not its work here`). A session with no confirmed
scope keeps every product's work. The build gate (`block-one-off-repairs`)
is not scoped: a build waits for every product's repairs unless Oko admits
it from the operator's standing rulings (`oko admit build --session <id>`),
so a scoped session whose own items all carry a repair is told that, and
never to ask him for a build. `tests/completion/refusal.rs`
(`a_scoped_session_is_held_only_by_work_in_its_scope`, pick the session with
`TAMA_SCOPED_SESSION`; `a_scope_the_session_wrote_does_not_narrow_its_stop`)
runs the built hook on the live ledger, read only.

### What the refusal quotes

A Stop refusal is injected into the conversation, so it stays small whatever
Oko holds. `block-stop-with-open-work`, `check-open-items-with-model` and
`block-stale-assignment` name a request by what identifies it, never by
quoting it, and nothing is cut at a length nobody stated:

- a task is one line: its Oko name when the session gave it one
  (`oko tasks state <task> --name …`), followed by
  ``(whole request: `oko tasks show <task>`)``, else
  ``not named yet (the request: `oko tasks show <task>`)``;
- unread operator messages are named by their numbers (`#3; #5; #9`);
- lists Oko holds (open defects, other sessions' repaired tasks, items with
  no repair) are not copied: the refusal gives the command that prints every
  one (`oko tasks owed`, `oko defects list`).

Only a task whose owner recorded a commit or report counts as another
session's repaired work. An unread message of another session is that
session's to record; it is neither listed nor counted as repaired.

### The operator's answers to agents' excuses

`rust/crates/tama-hook-tools/src/assignment/completion/excuses.json` holds
the excuses agents give most often for leaving work undone or for writing to
the operator, most frequent first as counted in Transcript Lake with
`oko transcripts occurrences --role assistant`, each with the operator's
answer in his own words: another session works on it (help it, it goes
faster), the work waits for his consent or decision (forbidden; no decision
is not a blocker), no consent to build or test (build and test once every
task and defect is finished; write and push every repair first), the judge
does not work (repair it), the item belongs to another session or product
(every task and defect is yours), and the operator has to be told (nothing
reaches him outside the escalation path: the Oko registers, and `oko asks
ask` for what only he can give). Every answer is printed every time, never
picked by reading the agent's text: at session start and after compaction
(`inject-operator-rules`, `tama assignment show`, after the standing rules
and rulings) and at the end of every refusal of `block-stop-with-open-work`
and `check-open-items-with-model`. A completion refusal while Oko records a
judge outage tells the session to repair the judge, not to wait for it.
