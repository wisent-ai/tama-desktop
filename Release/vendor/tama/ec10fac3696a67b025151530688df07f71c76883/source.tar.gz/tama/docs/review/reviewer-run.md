# Reviewer runs

A commit an agent session makes needs a round of harsh review by a reviewer
that is not its author (`tama reviews harsh record`). The author starts one
with:

```text
$ GIT_INDEX_FILE=<index> tama reviews harsh run --message <file> (--defect <id> | --task <id>) [--repository <path>]
reviews harsh: a reviewer session reviews tree <tree>; its events are written to <run>/events.jsonl
reviewer session over tree <tree> ended; it repaired what it found, so read its repairs with `git diff <tree> <staged tree>` before committing; its brief, events and errors are in <run>; it answered: <its last answer>
<the verdict the rounds give the candidate>
```

An agent session in OMP starts `run` as a call OMP defers (`async`): the
session works on while the reviewer reads, OMP names the call in the
transcript while it runs and delivers its outcome there when it ends, and the
operator can stop it from there.

`run` starts a session of the OMP program (`TAMA_OMP`, else `omp` on `PATH`
or in `~/.local/bin`) in print mode in the repository, briefed with the
staged candidate (the index `GIT_INDEX_FILE` names, its tree and the
message) and the item the author's work is for. The reviewer scopes its
session to that item, attacks every changed line, and repairs what it finds
in the files the candidate changes, staging each repair in the same index and
editing the message when a repair changes what it must say; then it attacks
its own repairs the same way. What it cannot repair inside those files goes
in its findings, what the change suggests for the rest of the codebase in its
improvements, both as lists of `{quote, problem, require}`. It records its
round over the tree staged when it is done, with a copy of the Tama program
kept in the run's directory, and ends when its answer is done. The copy is
removed once the reviewer has ended.

When `record` refuses the content of the reviewer's files, the reviewer
corrects them and records again; any other refused step ends the reviewer at
once, with the refusal as its answer. `run` reads the reviewer's events as
they come and stops a reviewer that circles: one that makes the same call
again and is refused the same way, and one that answers again with no call
made since its answer before, which is a session a stop gate keeps answering
after it has nothing left to do.

`run` writes how the run ended to `<run>/outcome.txt` and prints the same:
the verdict the rounds give the staged candidate and, when the reviewer
repaired anything, the command that shows its repairs, which the author reads
before committing, so no line is committed that only its writer has read. A
run that ends without a round says why instead: the reviewer circled, exited
with a failure, or recorded no round over the staged tree, with its last
answer. It exits nonzero unless the rounds admit the commit.

`run` refuses when no message, item or OMP program is given or found, when
two items are, when the message is empty, or when its run directory already
exists. Every run keeps its brief, the reviewer's event stream, error output,
findings, improvements and outcome in a directory of its own in the
repository's Git directory, `tama-harsh-review/runs/<tree>/<start in ms>/`.
A reviewer's files there quote the patch they review, so the time-limit
content rule does not judge them.

The refusals that come before a reviewer starts are proven by
`tests/harsh-review-run`; the paths that need a reviewer session (a recorded
round, repairs, circling, an ending without a round) have no test yet, and the
graphical surface has no action for a run yet.
