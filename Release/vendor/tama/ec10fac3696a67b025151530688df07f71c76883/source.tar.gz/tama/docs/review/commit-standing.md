# Commit standing

Every commit an agent session makes is scored, and a session that commits
more unformatted work than formatted is stopped.

## How a commit is scored

`tama hook review-commit`, which Git's `commit-msg` hook runs, writes the
staged candidate's tree with `git write-tree`, exports it into the checkout's
ignored build directory and checks there every file the candidate adds or
changes. A Rust file is checked with `rustfmt --check`, under the edition
and configuration the push gate reads ([push review](push-review.md)). Any
other file is checked with the formatter the tree's own
`.tama/formatters.json` declares for its extension:

```json
[{"extension": "swift", "argv": ["xcrun", "swift-format", "format", "--configuration", ".swift-format"]}]
```

The formatter runs in the exported tree with the file's path appended to
`argv` and writes the formatted text on standard output; a file whose
committed text differs is out of its form. A tree without that file declares
no formatter, and its other files are not judged. A declaration that cannot
be read or parsed, an entry with an empty `argv`, or a formatter that fails
is said beside the commit with its cause, and the commit is not scored. The
working tree is never read.

The commit is made either way. A commit whose staged files are all in their
formatter's form earns the session that makes it one point; a commit that
stages a file out of it costs the session one point and records the files.
The session is the one whose recorded agent process runs the commit; the
operator's own commit, and any commit no session's process runs, is not
scored. The commit's admission also names the one running session whose
recorded edits a commit started outside every session carries, and names
nobody when it carries several running sessions' edits or edits that cannot
be read, saying why beside the commit. Whose edits the index carries refuses
nothing: any session commits its own work and any other session's, running
or stopped, so a session that stalls never holds back the one carrying its
work on, and neither the commit review nor the shell guards before `git
commit` and `git add` refuse anything for whose work it is. The review runs
no formatter while Oko does not admit building the product, and says so; a
score that cannot be taken is said beside the commit with its cause.

```text
review-commit: the commit is made, and it costs omp session <ID> one point for file(s) out of their formatter's form: src/lib.rs. session <ID> made <n> commit(s) with files out of their formatter's form and <m> in it: its standing is <m-n>, so every tool call it makes is refused
```

The points are kept in `~/Library/Application Support/Tama/commit-standing.json`,
or the file `TAMA_COMMIT_STANDING_PATH` names.

## A session below zero

A session's standing is the points it earned less the points it lost. Below
zero it has committed more unformatted work than formatted, and the hook
`block-negative-commit-standing` refuses every tool call it makes, naming
each charged commit and its files. A register that cannot be read refuses
every tool call too, naming the cause, rather than freeing the held sessions.

Only the operator lifts the hold, by taking a charge back with the reason it
was recorded in error. A withdrawn charge stays in the register under
`withdrawn` with its reason and counts toward nothing.

```text
tama standing list [--json]                          every scored session, blocked ones first
tama standing show --session <ID> [--json]           one session's points and charges
tama standing withdraw <charge id> --reason <why> [--json]
tama standing location                               the register's file
```

`withdraw` takes the charge's id or a prefix that names exactly one charge,
and refuses an empty reason or an id that names none or several.

## Commits made before they were scored

A session's commits made before the commit review scored them, or in a
checkout whose Git hooks did not run Tama's, are charged with

```text
tama standing score --repository <path> --range <revision range> [--json]
```

Each commit of the range, merges aside, is put to the session that made it,
read from the session transcripts Tama finds (`~/.omp/agent/sessions` or
`TAMA_OMP_SESSION_ROOT`, `~/.claude/projects`, `~/.codex/sessions`) written
since the range's oldest commit: the session one of whose `bash` calls names
`commit` and the repository's folder, and was running when Git recorded the
commit, from the moment the call was made to the moment its result came
back. No author name and no guess decides it. Only OMP records its calls in
the shape read here, so a commit only a Claude or Codex session made is
listed as uncovered. A commit that no call covers (one a history rewrite
recorded again, for instance), or that calls of several sessions cover, is
listed with that cause and not scored.

The commit's added and changed files are checked in its own tree, by the
formatters that tree declares, as
the commit review checks a staged one, and the session earns or loses its
point. A commit whose tree the register already holds for that session is
not scored twice, so a range may be scored again.

```text
<commit> <subject>
  <session> lost a point: src/lib.rs
<commit> <subject>
  not scored: no session's shell call naming commit and this repository was running when Git recorded it
```

A transcript or a line of one that cannot be read refuses the run, naming it,
since a commit it holds would otherwise go unscored without a word.

## Dependencies pinned to unpublished revisions

`review-commit` also reads every staged `Cargo.toml` as the commit carries
it. Each table naming both `git` and `rev` is a pin, and the pinned
repository's default branch is fetched (commits only, no file contents) into
a cache under this checkout's Git directory (`tama/pinned-repositories/`). A
revision that branch does not hold is refused: "the commit pins Git
dependencies to revisions their repository's published default branch does
not carry, so no other checkout or builder can fetch them: `<manifest>` pins
`<repository>` at `<revision>`; push that repository's history first, or pin a
revision it publishes". A repository that cannot be fetched stops the commit
with Git's own words, since whether it carries the revision cannot be told.

## Tama Desktop

The Commit standing screen lists every session with its points and charges,
takes a charge back with its reason and scores a revision range, through
`tama request standing/list`, `standing/show` (`{"session"}`),
`standing/score` (`{"repository", "range"}`) and `standing/withdraw`
(`{"id", "reason"}`). They run the functions the verbs run and answer the
documents `--json` prints; `withdraw` answers `{"withdrawn", "standing"}`. A
request missing a field is a bad request naming it; a register, repository
or transcript that cannot be read is a failure naming it.
