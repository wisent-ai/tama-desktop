# How often agents give each excuse

Counted in Transcript Lake on one machine with
`oko transcripts occurrences "<words>" --role assistant` (default candidate
limit; a message counts once per query). Several phrasings were counted per
excuse; the table keeps the largest. Sessions whose transcripts are not on
this machine were not read. `completion/excuses.json` lists the excuses in
this order.

| excuse | query | messages | sessions |
|---|---|---|---|
| the operator must sign Brama in | answers pairing `Brama` or `subscription`/`subskrypcj` with `sign in`/`zaloguj`/`reauthori`/`odnow` within one sentence, read from the OMP transcripts of the last 31 days | 1040 | 111 |
| another session works on it | `inna sesja` | 939 | 32 |
| | `innej sesji` | 591 | 29 |
| | `another session` | 340 | 21 |
| waits for the operator's consent or decision | `Twojej zgody` | 706 | 45 |
| | `Twojej decyzji` | 253 | 28 |
| | `your consent` | 171 | 5 |
| no consent to build or test | `czeka na build` | 246 | 16 |
| | `bez buildu` | 123 | 10 |
| | `not built` | 120 | 15 |
| the judge does not work | `judge` | 624 | 45 |
| | `judge is down` | 10 | 7 |
| | `judge outage` | 7 | 4 |
| belongs to another session or product | `poza zakresem` | 13 | 10 |

`sędzia` (1745 messages in 39 sessions) and `Python` (803 in 49) match
far more than excuses and are left out of the ranking. A hook refusal
(`refused by`, 183 in 17; `hook odmawia`, 28 in 16) is frequent too, but the
operator has given no answer to it in his own words yet, so the catalogue
holds none.

The Brama sign-in row was counted without Transcript Lake: every assistant
text answer of the OMP transcripts on this machine, matched with one
case-insensitive expression for the pair. Agents asked it this often while
the catalogue held no answer to it; the operator has answered it, so it now
stands first and is printed in every session.
