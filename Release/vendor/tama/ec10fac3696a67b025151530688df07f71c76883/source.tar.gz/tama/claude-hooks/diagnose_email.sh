#!/bin/bash
# Diagnose email infrastructure for a domain.
# Usage: diagnose_email.sh <domain>
#
# Checks the domain's public DNS: MX, SPF, DKIM, DMARC. What the mail
# provider holds (domain status, received mail) is read through
# wisent-integrations, which owns every provider call and its credential;
# this script calls no provider and reads no key.

set -euo pipefail

DOMAIN="${1:-}"

if [[ -z "$DOMAIN" ]]; then
    echo "Usage: diagnose_email.sh <domain>"
    echo "Example: diagnose_email.sh example.com"
    exit 1
fi

PASS=0
FAIL=0
WARN=0

ok()   { echo "  ✅ $1"; PASS=$((PASS + 1)); }
fail() { echo "  ❌ $1"; FAIL=$((FAIL + 1)); }
warn() { echo "  ⚠️  $1"; WARN=$((WARN + 1)); }

echo "========================================="
echo "Email Infrastructure Diagnosis: $DOMAIN"
echo "========================================="
echo ""

# 1. MX Records
echo "1. MX Records"
MX=$(dig MX "$DOMAIN" +short 2>/dev/null)
if [[ -z "$MX" ]]; then
    fail "No MX records found for $DOMAIN"
else
    echo "  Found: $MX"
    if echo "$MX" | grep -qi "inbound-smtp"; then
        ok "MX points to inbound-smtp (AWS SES / Resend)"
    else
        warn "MX does not point to inbound-smtp. Emails may not reach Resend."
    fi
fi
echo ""

# 2. SPF Record
echo "2. SPF Record"
SPF=$(dig TXT "$DOMAIN" +short 2>/dev/null | grep -i "v=spf1" || true)
if [[ -z "$SPF" ]]; then
    fail "No SPF record found"
else
    echo "  Found: $SPF"
    if echo "$SPF" | grep -qi "resend.com"; then
        ok "SPF includes resend.com"
    else
        warn "SPF does not include resend.com"
    fi
    if echo "$SPF" | grep -qi "amazonses.com"; then
        ok "SPF includes amazonses.com"
    else
        warn "SPF does not include amazonses.com"
    fi
fi
echo ""

# 3. DKIM Record
echo "3. DKIM Record"
DKIM=$(dig TXT "resend._domainkey.$DOMAIN" +short 2>/dev/null || true)
if [[ -z "$DKIM" ]]; then
    fail "No DKIM record found at resend._domainkey.$DOMAIN"
else
    ok "DKIM record exists"
fi
echo ""

# 4. DMARC Record
echo "4. DMARC Record"
DMARC=$(dig TXT "_dmarc.$DOMAIN" +short 2>/dev/null || true)
if [[ -z "$DMARC" ]]; then
    warn "No DMARC record found (optional but recommended)"
else
    echo "  Found: $DMARC"
    ok "DMARC record exists"
fi
echo ""

# 5. Provider state
echo "5. Mail provider state"
echo "  Domain status and received mail come from wisent-integrations (content domain:"
echo "  resend.receiving.list, resend.deliverability.canary), not from this script."
echo ""

# Summary
echo "========================================="
echo "SUMMARY: $PASS passed, $FAIL failed, $WARN warnings"
echo "========================================="

if [[ "$FAIL" -gt 0 ]]; then
    echo "FIX THE FAILURES ABOVE before building email workarounds."
    exit 1
else
    echo "Infrastructure looks good. Run: touch ~/.claude/.email_infra_checked"
    exit 0
fi
