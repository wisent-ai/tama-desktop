//! What was already spent.
//!
//! The registry holds authorizations that are open right now, and `close`
//! removes them; a ration cannot be counted from a file that forgets. So every
//! recorded intent is also appended here, and this is what the day's count is
//! read from. Closing an entry ends the authorization and does not give the
//! build back.

use std::path::{Path, PathBuf};

use serde_json::{json, Value};

pub const FILE: &str = "build_restart_ledger.json";
/// Retention for ordinary intents. Approved exceptions remain as audit evidence
/// and prevent the same captured message from granting another exception.
const KEEP_SECONDS: u64 = 30 * 24 * 60 * 60;
const RECORDED: &str = "recorded";
const AT: &str = "recorded_at_epoch";

pub fn file(home: &Path) -> PathBuf {
    home.join(".shared-hooks").join(FILE)
}

fn rows(path: &Path) -> Result<Vec<Value>, String> {
    let text = match std::fs::read_to_string(path) {
        Ok(text) => text,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(Vec::new()),
        Err(error) => return Err(format!("{} cannot be read: {error}", path.display())),
    };
    if text.trim().is_empty() {
        return Ok(Vec::new());
    }
    let document: Value = serde_json::from_str(&text)
        .map_err(|error| format!("{} is not a readable ledger: {error}", path.display()))?;
    match document.get(RECORDED).and_then(Value::as_array) {
        Some(rows) => Ok(rows.clone()),
        None => Err(format!(
            "{} carries no {RECORDED} list, so nothing here says what was spent",
            path.display()
        )),
    }
}

fn moment(row: &Value) -> u64 {
    row.get(AT).and_then(Value::as_u64).unwrap_or_default()
}

/// Every intent of this kind recorded inside the window ending now.
pub fn spent(path: &Path, kind: &str, at: u64, window: u64) -> Result<Vec<Value>, String> {
    let since = at.saturating_sub(window);
    Ok(rows(path)?
        .into_iter()
        .filter(|row| row.get("kind").and_then(Value::as_str) == Some(kind))
        .filter(|row| moment(row) >= since)
        .collect())
}

/// The revision the last recorded build of this target carried, which is what
/// the next build's change is measured against.
pub fn last_revision(path: &Path, target: &str) -> Result<Option<String>, String> {
    let mut mine: Vec<Value> = rows(path)?
        .into_iter()
        .filter(|row| row.get("kind").and_then(Value::as_str) == Some("build"))
        .filter(|row| row.get("target").and_then(Value::as_str) == Some(target))
        .collect();
    mine.sort_by_key(moment);
    Ok(mine
        .last()
        .and_then(|row| row.get("revision"))
        .and_then(Value::as_str)
        .map(str::to_string))
}

/// One operator message may authorize a batch, but never a second build of
/// the same product. Closing the open registry entry does not erase consent use.
pub fn approval_used(path: &Path, approval: &Value) -> Result<bool, String> {
    Ok(rows(path)?.iter().any(|row| {
        row.get("user_approval").is_some_and(|used| {
            used.get("session_id") == approval.get("session_id")
                && used.get("turn_digest") == approval.get("turn_digest")
                && used.get("target") == approval.get("target")
        })
    }))
}

pub fn approvals(path: &Path) -> Result<Vec<Value>, String> {
    Ok(rows(path)?
        .into_iter()
        .filter(|row| row.get("user_approval").is_some())
        .collect())
}

/// Appends one spent intent and drops rows past the keeping period.
pub fn append(path: &Path, entry: &Value) -> Result<(), String> {
    let at = moment(entry);
    let mut kept: Vec<Value> = rows(path)?
        .into_iter()
        .filter(|row| row.get("user_approval").is_some() || moment(row) + KEEP_SECONDS >= at)
        .collect();
    kept.push(entry.clone());
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)
            .map_err(|error| format!("{} cannot be created: {error}", parent.display()))?;
    }
    let document = json!({ RECORDED: kept });
    let text = serde_json::to_string_pretty(&document)
        .map_err(|error| format!("cannot serialize build ledger: {error}"))?;
    crate::justify::registry::write_atomically(path, &format!("{text}\n"))
}

/// When the oldest spent intent in the window leaves it, which is when the
/// next one is authorized again.
pub fn frees_in_minutes(spent: &[Value], at: u64, window: u64) -> u64 {
    let oldest = spent.iter().map(moment).min().unwrap_or(at);
    (oldest + window).saturating_sub(at).div_ceil(60).max(1)
}

#[cfg(test)]
mod tests {
    use super::{append, frees_in_minutes, last_revision, spent, FILE};
    use serde_json::json;

    fn scratch(label: &str) -> std::path::PathBuf {
        let unique = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .expect("the clock follows the epoch")
            .as_nanos();
        // Throwaway state belongs in this checkout's ignored target
        // directory, never in a system temporary directory.
        let scratch = concat!(env!("CARGO_MANIFEST_DIR"), "/../../target/scratch");
        let path = std::path::Path::new(scratch).join(format!("tama-ledger-{label}-{unique:x}"));
        std::fs::create_dir_all(&path).expect("a scratch directory");
        path.join(FILE)
    }

    const DAY: u64 = 24 * 60 * 60;

    #[test]
    fn only_intents_of_that_kind_inside_the_window_are_spent() {
        let path = scratch("window");
        let now = 1_700_000_000;
        for (kind, at) in [
            ("build", now - 10),
            ("build", now - DAY - 10),
            ("restart", now - 20),
        ] {
            append(
                &path,
                &json!({"kind": kind, "target": "skarbiec", "recorded_at_epoch": at}),
            )
            .expect("append");
        }
        assert_eq!(spent(&path, "build", now, DAY).expect("read").len(), 1);
        assert_eq!(spent(&path, "restart", now, DAY).expect("read").len(), 1);
    }

    #[test]
    fn the_revision_measured_against_is_the_last_build_of_that_target() {
        let path = scratch("revision");
        let now = 1_700_000_000;
        append(
            &path,
            &json!({"kind": "build", "target": "tama", "revision": "aa", "recorded_at_epoch": now - 99}),
        )
        .expect("append");
        append(
            &path,
            &json!({"kind": "build", "target": "tama", "revision": "bb", "recorded_at_epoch": now}),
        )
        .expect("append");
        append(
            &path,
            &json!({"kind": "build", "target": "brama", "revision": "cc", "recorded_at_epoch": now}),
        )
        .expect("append");
        assert_eq!(
            last_revision(&path, "tama").expect("read"),
            Some(String::from("bb"))
        );
        assert_eq!(last_revision(&path, "oko").expect("read"), None);
    }

    #[test]
    fn the_wait_is_measured_from_the_oldest_spent_intent() {
        let now = 1_700_000_000;
        let rows = vec![
            json!({"recorded_at_epoch": now - DAY + 600}),
            json!({"recorded_at_epoch": now - 60}),
        ];
        assert_eq!(frees_in_minutes(&rows, now, DAY), 10);
    }

    #[test]
    fn a_malformed_ledger_is_refused_rather_than_counted_as_empty() {
        let path = scratch("malformed");
        std::fs::write(&path, "[1,2,3]").expect("write");
        let refusal = spent(&path, "build", 0, DAY).expect_err("a refusal");
        assert!(refusal.contains("carries no recorded list"), "{refusal}");
    }
}
