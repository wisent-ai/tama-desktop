//! The ration a recorded intent has to fit in: whether the fleet has a build
//! left today, and how much change this build carries against the revision
//! the last one carried.
//!
//! How many builds remain is Stado's count, read through [`fleet`], because
//! the fleet is where a build is actually spent; this gate's own ledger
//! answers for restarts, which Stado does not ration, and for the case where
//! the fleet cannot be asked. Two ceilings with different arithmetic is what
//! this replaced — on 2026-09-21 they disagreed in the same minute.
//!
//! Split out of `builds/mod.rs` with its readers — the ledger of what was
//! spent, the change measurement and the fleet's budget — so every file here
//! stays inside the three-hundred-line limit.

use serde_json::Value;

use super::intent::option;
use super::policy;

pub mod change;
pub mod fleet;
pub mod ledger;

pub(super) struct Admission {
    pub at: u64,
    pub fleet_remaining: Option<u64>,
    pub approved: bool,
}

/// The ration, checked before an intent is written: the day's count for this
/// kind, and — for a build — the size of the change it carries against the
/// revision the last recorded build of this target carried.
///
/// A retry after a failed build spends a slot, which is the whole point: the
/// evening this came from was nine submissions of work that a local
/// `cargo fmt --check` would have rejected in a minute.
pub(super) fn rationed(
    argv: &[String],
    policy: &policy::Policy,
    ledger_file: &std::path::Path,
    kind: &str,
    target: &str,
    admission: &Admission,
) -> Result<(), String> {
    // How many are left is the fleet's arithmetic, because the fleet is
    // where a build is actually spent. This gate keeps its own count only
    // for restarts, which Stado does not ration, and for the case where the
    // fleet cannot be asked at all — silence is not permission.
    let at = admission.at;
    match admission.fleet_remaining {
        _ if admission.approved => {}
        Some(0) => return Err(fleet::spent_refusal()),
        Some(_) => {}
        None => {
            let allowed = policy.per_day(kind);
            let spent = ledger::spent(ledger_file, kind, at, policy::WINDOW_SECONDS)?;
            if spent.len() as u64 >= allowed {
                let wait = ledger::frees_in_minutes(&spent, at, policy::WINDOW_SECONDS);
                let already = spent
                    .iter()
                    .filter_map(|row| row.get("target").and_then(Value::as_str))
                    .collect::<Vec<&str>>()
                    .join(", ");
                let exception = if kind == "build" {
                    " A user may instead authorize this build with `tama build record --approval-session <id> --approval-quote <verbatim message>`; the consent is retained without changing the limit."
                } else {
                    ""
                };
                return Err(format!(
                    "the policy allows {allowed} {kind}s in any 24 hours and this machine has \
                     spent all {allowed} ({already}). The next one is authorized in {wait} min. \
                     Gather the work into one {kind} instead, or have the operator raise the \
                     limit with `tama build policy --{kind}s-per-day <n>` and {} set outside the \
                     agent session.{exception}",
                    policy::CONSENT_ENV
                ));
            }
        }
    }
    if kind != "build" {
        return Ok(());
    }
    let Some(previous) = ledger::last_revision(ledger_file, target)? else {
        return Ok(());
    };
    let revision = option(argv, "--revision").unwrap_or_default();
    if previous == revision {
        return Err(format!(
            "the last recorded build of {target} carried {revision} already, so this build carries \
             no change at all"
        ));
    }
    let repository = change::repository(argv)?;
    let lines = change::changed_lines(&repository, &previous, &revision)?;
    if lines < policy.minimum_changed_lines {
        return Err(format!(
            "this build carries {lines} changed lines against {previous}, the revision the last \
             recorded build of {target} carried, and the policy calls a build serious at {} lines. \
             A build spends forty minutes of a builder the fleet has two of, so small changes \
             travel together: keep working and record the build once the change is worth it.",
            policy.minimum_changed_lines
        ));
    }
    Ok(())
}
