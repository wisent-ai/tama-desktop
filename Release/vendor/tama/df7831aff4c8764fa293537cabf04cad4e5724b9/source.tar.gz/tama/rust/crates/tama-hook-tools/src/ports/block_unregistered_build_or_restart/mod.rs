//! Decision half of `tama-block-unregistered-build-or-restart` (registry hook
//! `block-unregistered-build-or-restart`).
//!
//! A build and a restart both spend something that is not the agent's: a
//! builder the fleet has two of, and a service other work depends on. On
//! 2026-09-20 one session submitted brama 0.4.39, 0.4.40, 0.4.41, 0.4.42,
//! 0.4.43 and 0.4.46, stado 0.21.33, weles 0.7.16 and 0.7.28 and skarbiec
//! 0.3.11 — several of them failing on `cargo fmt --check` or a missing
//! rollback declaration, each after twenty to forty minutes of queue — and
//! installed, restarted and retired a launchd unit nobody had asked for. The
//! operator's words for the day were that his time went into incomplete
//! builds.
//!
//! So neither may happen unrecorded. The registry
//! `~/.shared-hooks/build_restart_registry.json` holds one entry per intended
//! build or restart: what it is for, which revision it carries, and when the
//! authorization stops. `tama-cli build record` writes it; this gate reads it
//! and refuses a command with no open entry, naming the exact command that
//! would record one. An entry is a statement before the fact, which is what a
//! plan is; a build nobody would write an entry for is a build nobody needed.
//!
//! The shape is [`crate::ports::block_one_off_repairs`]'s: a pure
//! [`evaluate`] over the payload, the vocabulary as data beside this file, and
//! the command read the way a shell reads it, so `grep 'cargo build' notes.md`
//! and `stado release submit --help` pass.

mod detect;
mod registry;

use serde_json::Value;

use crate::ports::pyvalue::{first_truthy_py_str, py_str, truthy};
use crate::ports::tool_vocabulary::{COMMAND_KEYS, TOOL_INPUT_KEY};

pub use detect::{Intent, Kind};

const BANNER: &str = "BLOCKED: unregistered ";
const HELP_FLAG: &str = "--help";

fn command_from(payload: &Value) -> String {
    let Some(raw) = payload.get(TOOL_INPUT_KEY).filter(|value| truthy(value)) else {
        return String::new();
    };
    if raw.is_object() {
        let named = first_truthy_py_str(raw, COMMAND_KEYS);
        if !named.is_empty() {
            return named;
        }
    }
    py_str(raw)
}

/// The refusal for one payload, or nothing when every command in it either
/// builds nothing, restarts nothing, or has an open registry entry.
pub fn evaluate(payload: &Value) -> Option<String> {
    let command = command_from(payload);
    if command.trim().is_empty() {
        return None;
    }
    if command.contains(HELP_FLAG) {
        return None;
    }
    let path = registry::registry_path()?;
    let entries = registry::open_entries(&path);
    detect::intents(&command)
        .into_iter()
        .find_map(|intent| refusal_for(&intent, &entries, &registry::ration(&path, intent.kind)))
}

fn refusal_for(
    intent: &Intent,
    entries: &[registry::Entry],
    ration: &registry::Ration,
) -> Option<String> {
    if entries
        .iter()
        .any(|entry| entry.covers(intent.kind, &intent.target))
    {
        return None;
    }
    Some(format!(
        "{BANNER}{kind}: `{command}` would {verb} {target}, and \
         ~/.shared-hooks/build_restart_registry.json holds no open entry for it. A build spends a \
         builder the fleet has two of and a restart spends a service other work depends on, so \
         each is stated before it runs, and the entries are rationed — `tama-cli build policy` \
         says how many a day this machine allows and how large a change a build has to carry. \
         This machine has spent {spent} {kind}(s) of the day's ration; the oldest of them leaves \
         the window in {frees} min, so a {kind} per small edit spends the day before the work is \
         worth delivering. Record the intent, then run the command again:\n  \
         tama-cli build record --kind {kind} --target {target} --reason \"<what this {kind} is \
         for>\"{revision}",
        kind = intent.kind.label(),
        command = intent.command,
        verb = intent.kind.verb(),
        target = intent.target,
        spent = ration.spent,
        frees = ration.frees_in_minutes,
        revision = match intent.kind {
            Kind::Build => " --revision <source revision this build carries>",
            Kind::Restart => "",
        }
    ))
}

#[cfg(test)]
mod tests {
    use super::{evaluate, registry};
    use serde_json::json;

    fn payload(command: &str) -> serde_json::Value {
        json!({"tool_input": {"command": command}})
    }

    fn refusal(command: &str) -> Option<String> {
        let entries: Vec<registry::Entry> = Vec::new();
        let ration = registry::Ration {
            spent: 3,
            frees_in_minutes: 47,
        };
        super::detect::intents(command)
            .into_iter()
            .find_map(|intent| super::refusal_for(&intent, &entries, &ration))
    }

    #[test]
    fn a_release_submit_with_no_entry_is_refused_and_names_the_recording_command() {
        let said = refusal("stado release submit --source . --version 0.4.46").expect("refused");
        assert!(said.contains("unregistered build"), "{said}");
        assert!(
            said.contains("tama-cli build record --kind build"),
            "{said}"
        );
        assert!(said.contains("--revision"), "{said}");
    }

    #[test]
    fn a_service_restart_with_no_entry_is_refused_without_asking_for_a_revision() {
        let said = refusal("stado service restart brama-grant-sync --host lukasz-macbook")
            .expect("refused");
        assert!(said.contains("unregistered restart"), "{said}");
        assert!(said.contains("--target brama-grant-sync"), "{said}");
        assert!(!said.contains("--revision"), "{said}");
    }

    #[test]
    fn a_command_that_builds_nothing_passes() {
        assert!(refusal("stado release status brama").is_none());
        assert!(refusal("grep 'cargo build' notes.md").is_none());
        assert!(refusal("cargo test --test identities").is_none());
    }

    /// Help is a read of a manual, not a build.
    #[test]
    fn asking_for_help_passes_through_the_payload_path() {
        assert_eq!(evaluate(&payload("stado release submit --help")), None);
        assert_eq!(evaluate(&payload("")), None);
    }

    /// The wrappers a repository actually offers. `make build` and
    /// `npm run build:rust` compile the same products `cargo build` does, and
    /// on 2026-09-21 a session ran both of them a dozen times without meeting
    /// this gate, while the day's three builds were spent elsewhere.
    ///
    /// A script name is not the evidence either. `npm run test:context`
    /// compiles the whole release binary before it runs a case, `npm run dev`
    /// compiles it and then keeps it running, and reading the word after `run`
    /// let both of them through — the operator's instruction on 2026-09-21 was
    /// to put every script a package manager runs beside `cargo build`.
    #[test]
    fn a_build_run_through_a_wrapper_is_still_a_build() {
        for command in [
            "make build",
            "make release",
            "make check",
            "make test",
            "npm run build:rust",
            "npm run build",
            "npm run test:context",
            "npm run dev",
            "npm run check",
            "npm test",
            "npm install",
            "pnpm run lint",
            "yarn test",
            "bun run build:mac",
        ] {
            let said = refusal(command).unwrap_or_else(|| panic!("{command} passed the gate"));
            assert!(said.contains("unregistered build"), "{command}: {said}");
        }
    }

    /// Reading a manual or a list of scripts builds nothing. Help is read on
    /// the payload path, where the gate answers it.
    #[test]
    fn reading_what_a_wrapper_offers_passes() {
        assert_eq!(evaluate(&payload("npm run --help")), None);
        assert_eq!(evaluate(&payload("make --help")), None);
    }

    /// What the refusal was missing: an agent could not see the ration until
    /// it had already spent it.
    #[test]
    fn the_refusal_says_what_the_day_has_left() {
        let said = refusal("cargo build --release").expect("refused");
        assert!(said.contains("spent 3 build(s) of the day's ration"), "{said}");
        assert!(said.contains("in 47 min"), "{said}");
    }
}
