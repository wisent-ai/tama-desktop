<!-- wisent-banner:start -->
<p align="center">
  <img src="assets/readme-banner.webp" alt="tama by Wisent" width="100%">
</p>
<!-- wisent-banner:end -->

<!-- wisent-readme-signals:start -->
[![Source](https://img.shields.io/badge/GitHub-Source-181717?logo=github)](https://github.com/wisent-ai/tama) [![Issues](https://img.shields.io/badge/GitHub-Issues-181717?logo=github)](https://github.com/wisent-ai/tama/issues) [![Wisent](https://img.shields.io/badge/Wisent-Website-0B0B0B)](https://wisent.com) [![Discord](https://img.shields.io/badge/Discord-Join-5865F2?logo=discord&logoColor=white)](https://discord.gg/qRjpkthq54) [![LinkedIn](https://img.shields.io/badge/LinkedIn-Follow-0A66C2?logo=linkedin&logoColor=white)](https://www.linkedin.com/company/wisent-ai/) [![X](https://img.shields.io/badge/X-Follow-000000?logo=x&logoColor=white)](https://x.com/wisentai) [![Enterprise](https://img.shields.io/badge/Enterprise-Book%20a%20call-0B0B0B?logo=calendly)](https://calendly.com/lbartoszcze)
<!-- wisent-readme-signals:end -->

# Tama

Runtime and CLI implementation for **Tama**, Wisent's coding-agent policy
product. The bundled command is documented as `tama`; the Rust source-checkout
binary is `tama-cli`. Tama Desktop uses its loopback backend.

## Tama CLI

Install the native source-checkout CLI:

```sh
cargo install --path rust/crates/tama-cli --root "$HOME/.local" --force
```

Core commands:

```text
tama status --json
tama hooks list --json
tama hooks show <hook-id> --json
tama provider coverage --json
tama install-plan --json
tama install
tama onboarding [--reset] [--policy-bundle <dir>] [--replace]
tama policy import --source <dir> [--replace] [--json]
tama policy list [--json]
tama mcp-config
tama find-violations --repo <path> --json
tama find-violations --tree <dir> --size-only --json
tama clean --repo <path>
```

The CLI owns catalog inspection, provider coverage, installation planning,
session runtime installation, repository scans and confirmed cleanup. Tama
Desktop is the native view over the same command contract.

`find-violations` replays the real hook scripts, which costs two shell
processes per file: right for one repository, too slow for a machine full of
them. `--size-only` answers just the two size rules — max 300 lines per file,
max 5 files per folder — in process, over the same enumeration, with the same
skips and the same sentences. Use it to find what to fix, then re-scan that
one repository without the flag for the content rules the hooks own.

The line rule is about source a person edits and navigates, so two families are
exempt from it. Structured data — `.json`, `.jsonl`, `.ndjson`, `.lock`, `.csv`,
`.tsv` — passes the length check at any size, on the operator's instruction
("wylacz limit dla plikow rejestrow", 2026-09-10), because splitting a registry
breaks the reader that loads it; manuscript sources — `.tex`, `.bib`, `.sty`,
`.bst`, `.cls` — pass it because a chapter is not a module.
`block-oversized-files` decides that, the in-process `--size-only` pass mirrors
the same list, and `find_violations::line_limit` carries a test that reads the
shipped hook and fails the moment the two disagree, so the fast pass can never
order a split the real guard would allow. `tests/oversized_files/verify.sh`
drives both halves against the hook itself: an exempt file over the limit is
written, a source module over the limit is refused. Every other rule still
applies to an exempt file — the folder-file limit, the new-file justification
and the content gates.

A repository declares its generated files to the audit in
`.tama/violations-ignore` — one relative path per line, a trailing slash for a
directory, `#` for a comment. The original root-level `.tama-violations-ignore`
is still read; the folded form exists because the write guard refuses a sixth
file in any folder and a repository root usually holds five already, which left
repositories unable to declare anything. Exclusions cover the audit only: the
write guards still refuse an oversized file on the way in.

Third-party and generated trees are skipped by name — `vendor`, `venv`,
`.venv`, `dist`, `build`, `target`, `coverage` — but only where no source root
stands above them. The same words are ordinary product code inside a source
tree: Stado keeps its coverage orchestrator at `stado-rs/src/coverage` and the
command that prints it at `src/cli/space/coverage`, and reading those as build
output exempted thirty-one hand-written modules from both size rules while
printing `vendored or build-output dir` beside each of them. A path segment
under `src/` or `crates/` is read as something a person wrote, whatever it is
called.

## Common hook engine

`rust/crates/tama-run-hook` exposes one native hook engine as a Rust library
and binary. `tama-run-hook --serve <agent-id>` keeps it alive across JSON-line
`status`, `reload`, and `dispatch` requests; valid registry changes are also
adopted automatically before dispatch. Failed replacements preserve the last
usable generation and refuse that dispatch rather than reporting success.
Harness-specific response formatting is outside the execution loop.

The OMP JavaScript adapter now forwards events and reload requests to a persistent
native engine; it no longer evaluates the event hook loop itself. The
[runtime protocol and integration status](https://tama.wisent.com/docs/enforcement-control/runtime/adapters/)
distinguish source, installed release, and the code an existing session has loaded.

The OMP adapter regression uses the real OMP SDK, its registered tool dispatcher,
and the native Tama binary, with an isolated session and filesystem:

```sh
npm ci
npm run test:omp-runtime
```

It checks executed replacement hooks, rejection and recovery, unchanged session
and process identities, absence of an inserted reload prompt, and correct refusal
ownership through real hook binaries. Reports remain under
`rust/target/omp-runtime-evidence/`. The test initializes the real OMP mode before
invoking its tools. `TAMA_TEST_OMP_ADAPTER` and `TAMA_TEST_NATIVE_BINARY` can
select installed artifacts for the same story.

The Node entrypoint used by Claude/Codex is only a process transport to the same
native engine. `npm run test:provider-runtime` checks real filesystem effects,
invalid-catalog refusal and missing-engine failure through that entrypoint.
`TAMA_TEST_PROVIDER_ADAPTER` selects its installed copy. The former Rust OMP
execution mirror and cross-hook policy sweeps have been removed; each hook
evaluates its own rule and the common engine owns event dispatch.

## Import an existing policy bundle

First setup can adopt policies from an existing self-contained Tama policy
bundle or sealed release directory without installing or enabling them:

```sh
tama onboarding --policy-bundle /absolute/path/to/tama-bundle
# The same operation remains available after onboarding:
tama policy import --source /absolute/path/to/tama-bundle
tama policy list
```

The supported bundle format contains `shared-hooks/registry.json` and regular,
non-symlink policy files under `shared-hooks/`, `claude-hooks/`,
`codex-hooks/`, `repo-githooks/`, `adaptive/`, `external-hooks/`, and `bin/`.
It also retains existing root `package.json`, `release.json`,
`external-sources.json`, `.wisent-release.json`, `README.md`, and `LICENSE`
files. Other top-level paths are returned in `ignoredPaths`; they are never silently
treated as policy definitions.

Before any store mutation, Tama parses the exact registry, validates the
established catalog, maps every registered source to a selected file, and, for
a sealed release, verifies the `release.json` tree identity. Invalid JSON,
missing source files, empty catalogs, seal mismatches, symlinks, and special
filesystem entries return a rejected result and leave the store unchanged.

Accepted bundles are copied to Tama's editable application-data store and
recorded in `index.json` with canonical source path, source digest, hook count,
timestamp, file modes, and per-file SHA-256 digests. Repeating the same source
and content is `unchanged`. A changed source returns all conflicts by default;
`--replace` updates only a bundle with no untracked or locally changed files.
Other imported bundles are always preserved.

Every result reports imported, unchanged, removed, conflicting, and rejected
counts. Imported bundles are explicitly `inactive`: the operation installs and
enables zero hooks and does not modify `~/.shared-hooks`, Git configuration,
agent configuration, the active Tama release, or the selected source. Activation
remains a separate, explicit install/runtime operation. Skipping import leaves
an empty, usable Tama.

## Record CUA consent already given

The CLI and **Justifications → CUA consent** can record, inspect and remove an
existing user grant without editing protected hook files. The application,
every requested action and the direct grant must appear in the real user
message from the specified OMP session.

```sh
tama-cli justify record --kind cua --session <current-session-id> \
  --app Figma --actions list_windows,get_window_state \
  --quote-match "Zezwalam CUA" --json
tama-cli justify list --kind cua --json
```

`--quote-match` selects the original full message without retyping whitespace;
`--quote` accepts an exact quotation instead. Tama derives the installed app's
bundle identifier and executable, reuses the hook's validators, and writes the
registry under a lock. Recording does not start Cua Driver or prove an action
ran. The hook still checks the current session and target at use.

The [CLI contract](https://tama.wisent.com/docs/cli/justify/) and
[backend contract](https://tama.wisent.com/docs/cli/serve/) document scope and
refusals. `cargo test -p tama-cli --test justify_cua -- --ignored --nocapture`
from `rust/` runs real CLI/API consent lifecycles with `TAMA_TEST_CUA_SESSION`,
`TAMA_TEST_CUA_APP`, `TAMA_TEST_CUA_MATCH` and `TAMA_TEST_CUA_ACTIONS` naming an
actual grant and installed application. It uses isolated registries, never
fabricated transcripts, and retains evidence in `rust/target/tmp/cua-*`.
